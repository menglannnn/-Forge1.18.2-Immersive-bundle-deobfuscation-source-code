/*      */ package discord4j.discordjson.json;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*      */ import com.fasterxml.jackson.annotation.JsonCreator;
/*      */ import com.fasterxml.jackson.annotation.JsonProperty;
/*      */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*      */ import discord4j.discordjson.possible.Possible;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import java.util.stream.Collectors;
/*      */ import java.util.stream.StreamSupport;
/*      */ import org.immutables.value.Generated;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Generated(from = "ChannelCreateRequest", generator = "Immutables")
/*      */ public final class ImmutableChannelCreateRequest
/*      */   implements ChannelCreateRequest
/*      */ {
/*      */   private final String name;
/*      */   private final Integer type_value;
/*      */   private final boolean type_absent;
/*      */   private final String topic_value;
/*      */   private final boolean topic_absent;
/*      */   private final Integer bitrate_value;
/*      */   private final boolean bitrate_absent;
/*      */   private final Integer userLimit_value;
/*      */   private final boolean userLimit_absent;
/*      */   private final Integer rateLimitPerUser_value;
/*      */   private final boolean rateLimitPerUser_absent;
/*      */   private final Integer position_value;
/*      */   private final boolean position_absent;
/*      */   private final List<OverwriteData> permissionOverwrites_value;
/*      */   private final boolean permissionOverwrites_absent;
/*      */   private final String parentId_value;
/*      */   private final boolean parentId_absent;
/*      */   private final Boolean nsfw_value;
/*      */   private final boolean nsfw_absent;
/*      */   private static final byte STAGE_INITIALIZING = -1;
/*      */   private static final byte STAGE_UNINITIALIZED = 0;
/*      */   private static final byte STAGE_INITIALIZED = 1;
/*      */   private volatile transient InitShim initShim;
/*      */   
/*      */   private ImmutableChannelCreateRequest(String name, Possible<Integer> type, Possible<String> topic, Possible<Integer> bitrate, Possible<Integer> userLimit, Possible<Integer> rateLimitPerUser, Possible<Integer> position, Possible<List<OverwriteData>> permissionOverwrites, Possible<String> parentId, Possible<Boolean> nsfw) {
/*  136 */     this.initShim = new InitShim(); this.name = Objects.<String>requireNonNull(name, "name"); Possible<Integer> type$impl = type; Possible<String> topic$impl = topic; Possible<Integer> bitrate$impl = bitrate; Possible<Integer> userLimit$impl = userLimit; Possible<Integer> rateLimitPerUser$impl = rateLimitPerUser; Possible<Integer> position$impl = position; Possible<List<OverwriteData>> permissionOverwrites$impl = permissionOverwrites; Possible<String> parentId$impl = parentId; Possible<Boolean> nsfw$impl = nsfw; this.type_value = type$impl.toOptional().orElse(null); this.type_absent = type$impl.isAbsent(); this.topic_value = topic$impl.toOptional().orElse(null); this.topic_absent = topic$impl.isAbsent(); this.bitrate_value = bitrate$impl.toOptional().orElse(null); this.bitrate_absent = bitrate$impl.isAbsent(); this.userLimit_value = userLimit$impl.toOptional().orElse(null); this.userLimit_absent = userLimit$impl.isAbsent(); this.rateLimitPerUser_value = rateLimitPerUser$impl.toOptional().orElse(null); this.rateLimitPerUser_absent = rateLimitPerUser$impl.isAbsent(); this.position_value = position$impl.toOptional().orElse(null); this.position_absent = position$impl.isAbsent(); this.permissionOverwrites_value = permissionOverwrites$impl.toOptional().orElse(null); this.permissionOverwrites_absent = permissionOverwrites$impl.isAbsent(); this.parentId_value = parentId$impl.toOptional().orElse(null); this.parentId_absent = parentId$impl.isAbsent(); this.nsfw_value = nsfw$impl.toOptional().orElse(null); this.nsfw_absent = nsfw$impl.isAbsent(); this.initShim = null; } private ImmutableChannelCreateRequest(ImmutableChannelCreateRequest original, String name, Possible<Integer> type, Possible<String> topic, Possible<Integer> bitrate, Possible<Integer> userLimit, Possible<Integer> rateLimitPerUser, Possible<Integer> position, Possible<List<OverwriteData>> permissionOverwrites, Possible<String> parentId, Possible<Boolean> nsfw) { this.initShim = new InitShim(); this.name = name; Possible<Integer> type$impl = type; Possible<String> topic$impl = topic; Possible<Integer> bitrate$impl = bitrate; Possible<Integer> userLimit$impl = userLimit; Possible<Integer> rateLimitPerUser$impl = rateLimitPerUser; Possible<Integer> position$impl = position; Possible<List<OverwriteData>> permissionOverwrites$impl = permissionOverwrites; Possible<String> parentId$impl = parentId; Possible<Boolean> nsfw$impl = nsfw; this.type_value = type$impl.toOptional().orElse(null); this.type_absent = type$impl.isAbsent(); this.topic_value = topic$impl.toOptional().orElse(null); this.topic_absent = topic$impl.isAbsent(); this.bitrate_value = bitrate$impl.toOptional().orElse(null); this.bitrate_absent = bitrate$impl.isAbsent(); this.userLimit_value = userLimit$impl.toOptional().orElse(null); this.userLimit_absent = userLimit$impl.isAbsent(); this.rateLimitPerUser_value = rateLimitPerUser$impl.toOptional().orElse(null); this.rateLimitPerUser_absent = rateLimitPerUser$impl.isAbsent(); this.position_value = position$impl.toOptional().orElse(null); this.position_absent = position$impl.isAbsent(); this.permissionOverwrites_value = permissionOverwrites$impl.toOptional().orElse(null); this.permissionOverwrites_absent = permissionOverwrites$impl.isAbsent();
/*      */     this.parentId_value = parentId$impl.toOptional().orElse(null);
/*      */     this.parentId_absent = parentId$impl.isAbsent();
/*      */     this.nsfw_value = nsfw$impl.toOptional().orElse(null);
/*      */     this.nsfw_absent = nsfw$impl.isAbsent();
/*  141 */     this.initShim = null; } @Generated(from = "ChannelCreateRequest", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/*  142 */       return "Cannot build ChannelCreateRequest, attribute initializers form cycle " + attributes; }
/*      */      }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("name")
/*      */   public String name() {
/*  152 */     return this.name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("type")
/*      */   public Possible<Integer> type() {
/*  161 */     return this.type_absent ? Possible.absent() : Possible.of(this.type_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("topic")
/*      */   public Possible<String> topic() {
/*  170 */     return this.topic_absent ? Possible.absent() : Possible.of(this.topic_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("bitrate")
/*      */   public Possible<Integer> bitrate() {
/*  179 */     return this.bitrate_absent ? Possible.absent() : Possible.of(this.bitrate_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("user_limit")
/*      */   public Possible<Integer> userLimit() {
/*  188 */     return this.userLimit_absent ? Possible.absent() : Possible.of(this.userLimit_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("rate_limit_per_user")
/*      */   public Possible<Integer> rateLimitPerUser() {
/*  197 */     return this.rateLimitPerUser_absent ? Possible.absent() : Possible.of(this.rateLimitPerUser_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("position")
/*      */   public Possible<Integer> position() {
/*  206 */     return this.position_absent ? Possible.absent() : Possible.of(this.position_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("permission_overwrites")
/*      */   public Possible<List<OverwriteData>> permissionOverwrites() {
/*  215 */     return this.permissionOverwrites_absent ? Possible.absent() : 
/*  216 */       Possible.of(this.permissionOverwrites_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("parent_id")
/*      */   public Possible<String> parentId() {
/*  225 */     return this.parentId_absent ? Possible.absent() : Possible.of(this.parentId_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("nsfw")
/*      */   public Possible<Boolean> nsfw() {
/*  234 */     return this.nsfw_absent ? Possible.absent() : Possible.of(this.nsfw_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableChannelCreateRequest withName(String value) {
/*  244 */     String newValue = Objects.<String>requireNonNull(value, "name");
/*  245 */     if (this.name.equals(newValue)) return this; 
/*  246 */     return new ImmutableChannelCreateRequest(this, newValue, 
/*      */ 
/*      */         
/*  249 */         type(), 
/*  250 */         topic(), 
/*  251 */         bitrate(), 
/*  252 */         userLimit(), 
/*  253 */         rateLimitPerUser(), 
/*  254 */         position(), 
/*  255 */         permissionOverwrites(), 
/*  256 */         parentId(), 
/*  257 */         nsfw());
/*      */   }
/*      */   
/*      */   public ImmutableChannelCreateRequest withType(Possible<Integer> value) {
/*  261 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/*  262 */     return new ImmutableChannelCreateRequest(this, this.name, newValue, 
/*      */ 
/*      */ 
/*      */         
/*  266 */         topic(), 
/*  267 */         bitrate(), 
/*  268 */         userLimit(), 
/*  269 */         rateLimitPerUser(), 
/*  270 */         position(), 
/*  271 */         permissionOverwrites(), 
/*  272 */         parentId(), 
/*  273 */         nsfw());
/*      */   }
/*      */   
/*      */   public ImmutableChannelCreateRequest withType(Integer value) {
/*  277 */     Possible<Integer> newValue = Possible.of(value);
/*  278 */     return new ImmutableChannelCreateRequest(this, this.name, newValue, 
/*      */ 
/*      */ 
/*      */         
/*  282 */         topic(), 
/*  283 */         bitrate(), 
/*  284 */         userLimit(), 
/*  285 */         rateLimitPerUser(), 
/*  286 */         position(), 
/*  287 */         permissionOverwrites(), 
/*  288 */         parentId(), 
/*  289 */         nsfw());
/*      */   }
/*      */   
/*      */   public ImmutableChannelCreateRequest withTopic(Possible<String> value) {
/*  293 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  294 */     return new ImmutableChannelCreateRequest(this, this.name, 
/*      */ 
/*      */         
/*  297 */         type(), newValue, 
/*      */         
/*  299 */         bitrate(), 
/*  300 */         userLimit(), 
/*  301 */         rateLimitPerUser(), 
/*  302 */         position(), 
/*  303 */         permissionOverwrites(), 
/*  304 */         parentId(), 
/*  305 */         nsfw());
/*      */   }
/*      */   
/*      */   public ImmutableChannelCreateRequest withTopic(String value) {
/*  309 */     Possible<String> newValue = Possible.of(value);
/*  310 */     return new ImmutableChannelCreateRequest(this, this.name, 
/*      */ 
/*      */         
/*  313 */         type(), newValue, 
/*      */         
/*  315 */         bitrate(), 
/*  316 */         userLimit(), 
/*  317 */         rateLimitPerUser(), 
/*  318 */         position(), 
/*  319 */         permissionOverwrites(), 
/*  320 */         parentId(), 
/*  321 */         nsfw());
/*      */   }
/*      */   
/*      */   public ImmutableChannelCreateRequest withBitrate(Possible<Integer> value) {
/*  325 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/*  326 */     return new ImmutableChannelCreateRequest(this, this.name, 
/*      */ 
/*      */         
/*  329 */         type(), 
/*  330 */         topic(), newValue, 
/*      */         
/*  332 */         userLimit(), 
/*  333 */         rateLimitPerUser(), 
/*  334 */         position(), 
/*  335 */         permissionOverwrites(), 
/*  336 */         parentId(), 
/*  337 */         nsfw());
/*      */   }
/*      */   
/*      */   public ImmutableChannelCreateRequest withBitrate(Integer value) {
/*  341 */     Possible<Integer> newValue = Possible.of(value);
/*  342 */     return new ImmutableChannelCreateRequest(this, this.name, 
/*      */ 
/*      */         
/*  345 */         type(), 
/*  346 */         topic(), newValue, 
/*      */         
/*  348 */         userLimit(), 
/*  349 */         rateLimitPerUser(), 
/*  350 */         position(), 
/*  351 */         permissionOverwrites(), 
/*  352 */         parentId(), 
/*  353 */         nsfw());
/*      */   }
/*      */   
/*      */   public ImmutableChannelCreateRequest withUserLimit(Possible<Integer> value) {
/*  357 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/*  358 */     return new ImmutableChannelCreateRequest(this, this.name, 
/*      */ 
/*      */         
/*  361 */         type(), 
/*  362 */         topic(), 
/*  363 */         bitrate(), newValue, 
/*      */         
/*  365 */         rateLimitPerUser(), 
/*  366 */         position(), 
/*  367 */         permissionOverwrites(), 
/*  368 */         parentId(), 
/*  369 */         nsfw());
/*      */   }
/*      */   
/*      */   public ImmutableChannelCreateRequest withUserLimit(Integer value) {
/*  373 */     Possible<Integer> newValue = Possible.of(value);
/*  374 */     return new ImmutableChannelCreateRequest(this, this.name, 
/*      */ 
/*      */         
/*  377 */         type(), 
/*  378 */         topic(), 
/*  379 */         bitrate(), newValue, 
/*      */         
/*  381 */         rateLimitPerUser(), 
/*  382 */         position(), 
/*  383 */         permissionOverwrites(), 
/*  384 */         parentId(), 
/*  385 */         nsfw());
/*      */   }
/*      */   
/*      */   public ImmutableChannelCreateRequest withRateLimitPerUser(Possible<Integer> value) {
/*  389 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/*  390 */     return new ImmutableChannelCreateRequest(this, this.name, 
/*      */ 
/*      */         
/*  393 */         type(), 
/*  394 */         topic(), 
/*  395 */         bitrate(), 
/*  396 */         userLimit(), newValue, 
/*      */         
/*  398 */         position(), 
/*  399 */         permissionOverwrites(), 
/*  400 */         parentId(), 
/*  401 */         nsfw());
/*      */   }
/*      */   
/*      */   public ImmutableChannelCreateRequest withRateLimitPerUser(Integer value) {
/*  405 */     Possible<Integer> newValue = Possible.of(value);
/*  406 */     return new ImmutableChannelCreateRequest(this, this.name, 
/*      */ 
/*      */         
/*  409 */         type(), 
/*  410 */         topic(), 
/*  411 */         bitrate(), 
/*  412 */         userLimit(), newValue, 
/*      */         
/*  414 */         position(), 
/*  415 */         permissionOverwrites(), 
/*  416 */         parentId(), 
/*  417 */         nsfw());
/*      */   }
/*      */   
/*      */   public ImmutableChannelCreateRequest withPosition(Possible<Integer> value) {
/*  421 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/*  422 */     return new ImmutableChannelCreateRequest(this, this.name, 
/*      */ 
/*      */         
/*  425 */         type(), 
/*  426 */         topic(), 
/*  427 */         bitrate(), 
/*  428 */         userLimit(), 
/*  429 */         rateLimitPerUser(), newValue, 
/*      */         
/*  431 */         permissionOverwrites(), 
/*  432 */         parentId(), 
/*  433 */         nsfw());
/*      */   }
/*      */   
/*      */   public ImmutableChannelCreateRequest withPosition(Integer value) {
/*  437 */     Possible<Integer> newValue = Possible.of(value);
/*  438 */     return new ImmutableChannelCreateRequest(this, this.name, 
/*      */ 
/*      */         
/*  441 */         type(), 
/*  442 */         topic(), 
/*  443 */         bitrate(), 
/*  444 */         userLimit(), 
/*  445 */         rateLimitPerUser(), newValue, 
/*      */         
/*  447 */         permissionOverwrites(), 
/*  448 */         parentId(), 
/*  449 */         nsfw());
/*      */   }
/*      */   
/*      */   public ImmutableChannelCreateRequest withPermissionOverwrites(Possible<List<OverwriteData>> possible) {
/*  453 */     Possible<List<OverwriteData>> newValue = Objects.<Possible<List<OverwriteData>>>requireNonNull(possible);
/*  454 */     return new ImmutableChannelCreateRequest(this, this.name, 
/*      */ 
/*      */         
/*  457 */         type(), 
/*  458 */         topic(), 
/*  459 */         bitrate(), 
/*  460 */         userLimit(), 
/*  461 */         rateLimitPerUser(), 
/*  462 */         position(), newValue, 
/*      */         
/*  464 */         parentId(), 
/*  465 */         nsfw());
/*      */   }
/*      */   
/*      */   public ImmutableChannelCreateRequest withPermissionOverwrites(Iterable<OverwriteData> elements) {
/*  469 */     Possible<List<OverwriteData>> newValue = Possible.of(
/*  470 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/*  471 */     return new ImmutableChannelCreateRequest(this, this.name, 
/*      */ 
/*      */         
/*  474 */         type(), 
/*  475 */         topic(), 
/*  476 */         bitrate(), 
/*  477 */         userLimit(), 
/*  478 */         rateLimitPerUser(), 
/*  479 */         position(), newValue, 
/*      */         
/*  481 */         parentId(), 
/*  482 */         nsfw());
/*      */   }
/*      */   
/*      */   @SafeVarargs
/*      */   public final ImmutableChannelCreateRequest withPermissionOverwrites(OverwriteData... elements) {
/*  487 */     Possible<List<OverwriteData>> newValue = Possible.of(Arrays.asList(elements));
/*  488 */     return new ImmutableChannelCreateRequest(this, this.name, 
/*      */ 
/*      */         
/*  491 */         type(), 
/*  492 */         topic(), 
/*  493 */         bitrate(), 
/*  494 */         userLimit(), 
/*  495 */         rateLimitPerUser(), 
/*  496 */         position(), newValue, 
/*      */         
/*  498 */         parentId(), 
/*  499 */         nsfw());
/*      */   }
/*      */   
/*      */   public ImmutableChannelCreateRequest withParentId(Possible<String> value) {
/*  503 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  504 */     return new ImmutableChannelCreateRequest(this, this.name, 
/*      */ 
/*      */         
/*  507 */         type(), 
/*  508 */         topic(), 
/*  509 */         bitrate(), 
/*  510 */         userLimit(), 
/*  511 */         rateLimitPerUser(), 
/*  512 */         position(), 
/*  513 */         permissionOverwrites(), newValue, 
/*      */         
/*  515 */         nsfw());
/*      */   }
/*      */   
/*      */   public ImmutableChannelCreateRequest withParentId(String value) {
/*  519 */     Possible<String> newValue = Possible.of(value);
/*  520 */     return new ImmutableChannelCreateRequest(this, this.name, 
/*      */ 
/*      */         
/*  523 */         type(), 
/*  524 */         topic(), 
/*  525 */         bitrate(), 
/*  526 */         userLimit(), 
/*  527 */         rateLimitPerUser(), 
/*  528 */         position(), 
/*  529 */         permissionOverwrites(), newValue, 
/*      */         
/*  531 */         nsfw());
/*      */   }
/*      */   
/*      */   public ImmutableChannelCreateRequest withNsfw(Possible<Boolean> value) {
/*  535 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/*  536 */     return new ImmutableChannelCreateRequest(this, this.name, 
/*      */ 
/*      */         
/*  539 */         type(), 
/*  540 */         topic(), 
/*  541 */         bitrate(), 
/*  542 */         userLimit(), 
/*  543 */         rateLimitPerUser(), 
/*  544 */         position(), 
/*  545 */         permissionOverwrites(), 
/*  546 */         parentId(), newValue);
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableChannelCreateRequest withNsfw(Boolean value) {
/*  551 */     Possible<Boolean> newValue = Possible.of(value);
/*  552 */     return new ImmutableChannelCreateRequest(this, this.name, 
/*      */ 
/*      */         
/*  555 */         type(), 
/*  556 */         topic(), 
/*  557 */         bitrate(), 
/*  558 */         userLimit(), 
/*  559 */         rateLimitPerUser(), 
/*  560 */         position(), 
/*  561 */         permissionOverwrites(), 
/*  562 */         parentId(), newValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object another) {
/*  572 */     if (this == another) return true; 
/*  573 */     return (another instanceof ImmutableChannelCreateRequest && 
/*  574 */       equalTo(0, (ImmutableChannelCreateRequest)another));
/*      */   }
/*      */   
/*      */   private boolean equalTo(int synthetic, ImmutableChannelCreateRequest another) {
/*  578 */     return (this.name.equals(another.name) && 
/*  579 */       type().equals(another.type()) && 
/*  580 */       topic().equals(another.topic()) && 
/*  581 */       bitrate().equals(another.bitrate()) && 
/*  582 */       userLimit().equals(another.userLimit()) && 
/*  583 */       rateLimitPerUser().equals(another.rateLimitPerUser()) && 
/*  584 */       position().equals(another.position()) && 
/*  585 */       Objects.equals(this.permissionOverwrites_value, another.permissionOverwrites_value) && 
/*  586 */       parentId().equals(another.parentId()) && 
/*  587 */       nsfw().equals(another.nsfw()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/*  596 */     int h = 5381;
/*  597 */     h += (h << 5) + this.name.hashCode();
/*  598 */     h += (h << 5) + type().hashCode();
/*  599 */     h += (h << 5) + topic().hashCode();
/*  600 */     h += (h << 5) + bitrate().hashCode();
/*  601 */     h += (h << 5) + userLimit().hashCode();
/*  602 */     h += (h << 5) + rateLimitPerUser().hashCode();
/*  603 */     h += (h << 5) + position().hashCode();
/*  604 */     h += (h << 5) + Objects.hashCode(this.permissionOverwrites_value);
/*  605 */     h += (h << 5) + parentId().hashCode();
/*  606 */     h += (h << 5) + nsfw().hashCode();
/*  607 */     return h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*  616 */     return "ChannelCreateRequest{name=" + this.name + ", type=" + 
/*      */       
/*  618 */       type().toString() + ", topic=" + 
/*  619 */       topic().toString() + ", bitrate=" + 
/*  620 */       bitrate().toString() + ", userLimit=" + 
/*  621 */       userLimit().toString() + ", rateLimitPerUser=" + 
/*  622 */       rateLimitPerUser().toString() + ", position=" + 
/*  623 */       position().toString() + ", permissionOverwrites=" + 
/*  624 */       Objects.toString(this.permissionOverwrites_value) + ", parentId=" + 
/*  625 */       parentId().toString() + ", nsfw=" + 
/*  626 */       nsfw().toString() + "}";
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonDeserialize
/*      */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*      */   @Generated(from = "ChannelCreateRequest", generator = "Immutables")
/*      */   static final class Json
/*      */     implements ChannelCreateRequest
/*      */   {
/*      */     String name;
/*      */ 
/*      */     
/*  641 */     Possible<Integer> type = Possible.absent();
/*      */ 
/*      */     
/*  644 */     Possible<String> topic = Possible.absent();
/*      */ 
/*      */     
/*  647 */     Possible<Integer> bitrate = Possible.absent();
/*      */ 
/*      */     
/*  650 */     Possible<Integer> userLimit = Possible.absent();
/*      */ 
/*      */     
/*  653 */     Possible<Integer> rateLimitPerUser = Possible.absent();
/*      */ 
/*      */     
/*  656 */     Possible<Integer> position = Possible.absent();
/*      */ 
/*      */     
/*  659 */     Possible<List<OverwriteData>> permissionOverwrites = Possible.absent();
/*      */ 
/*      */     
/*  662 */     Possible<String> parentId = Possible.absent();
/*      */ 
/*      */     
/*  665 */     Possible<Boolean> nsfw = Possible.absent();
/*      */     
/*      */     @JsonProperty("name")
/*      */     public void setName(String name) {
/*  669 */       this.name = name;
/*      */     }
/*      */     @JsonProperty("type")
/*      */     public void setType(Possible<Integer> type) {
/*  673 */       this.type = type;
/*      */     }
/*      */     @JsonProperty("topic")
/*      */     public void setTopic(Possible<String> topic) {
/*  677 */       this.topic = topic;
/*      */     }
/*      */     @JsonProperty("bitrate")
/*      */     public void setBitrate(Possible<Integer> bitrate) {
/*  681 */       this.bitrate = bitrate;
/*      */     }
/*      */     @JsonProperty("user_limit")
/*      */     public void setUserLimit(Possible<Integer> userLimit) {
/*  685 */       this.userLimit = userLimit;
/*      */     }
/*      */     @JsonProperty("rate_limit_per_user")
/*      */     public void setRateLimitPerUser(Possible<Integer> rateLimitPerUser) {
/*  689 */       this.rateLimitPerUser = rateLimitPerUser;
/*      */     }
/*      */     @JsonProperty("position")
/*      */     public void setPosition(Possible<Integer> position) {
/*  693 */       this.position = position;
/*      */     }
/*      */     @JsonProperty("permission_overwrites")
/*      */     public void setPermissionOverwrites(Possible<List<OverwriteData>> permissionOverwrites) {
/*  697 */       this.permissionOverwrites = permissionOverwrites;
/*      */     }
/*      */     @JsonProperty("parent_id")
/*      */     public void setParentId(Possible<String> parentId) {
/*  701 */       this.parentId = parentId;
/*      */     }
/*      */     @JsonProperty("nsfw")
/*      */     public void setNsfw(Possible<Boolean> nsfw) {
/*  705 */       this.nsfw = nsfw;
/*      */     }
/*      */     public String name() {
/*  708 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> type() {
/*  710 */       throw new UnsupportedOperationException();
/*      */     } public Possible<String> topic() {
/*  712 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> bitrate() {
/*  714 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> userLimit() {
/*  716 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> rateLimitPerUser() {
/*  718 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> position() {
/*  720 */       throw new UnsupportedOperationException();
/*      */     } public Possible<List<OverwriteData>> permissionOverwrites() {
/*  722 */       throw new UnsupportedOperationException();
/*      */     } public Possible<String> parentId() {
/*  724 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Boolean> nsfw() {
/*  726 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*      */   static ImmutableChannelCreateRequest fromJson(Json json) {
/*  737 */     Builder builder = builder();
/*  738 */     if (json.name != null) {
/*  739 */       builder.name(json.name);
/*      */     }
/*  741 */     if (json.type != null) {
/*  742 */       builder.type(json.type);
/*      */     }
/*  744 */     if (json.topic != null) {
/*  745 */       builder.topic(json.topic);
/*      */     }
/*  747 */     if (json.bitrate != null) {
/*  748 */       builder.bitrate(json.bitrate);
/*      */     }
/*  750 */     if (json.userLimit != null) {
/*  751 */       builder.userLimit(json.userLimit);
/*      */     }
/*  753 */     if (json.rateLimitPerUser != null) {
/*  754 */       builder.rateLimitPerUser(json.rateLimitPerUser);
/*      */     }
/*  756 */     if (json.position != null) {
/*  757 */       builder.position(json.position);
/*      */     }
/*  759 */     if (json.permissionOverwrites != null) {
/*  760 */       builder.permissionOverwrites(json.permissionOverwrites);
/*      */     }
/*  762 */     if (json.parentId != null) {
/*  763 */       builder.parentId(json.parentId);
/*      */     }
/*  765 */     if (json.nsfw != null) {
/*  766 */       builder.nsfw(json.nsfw);
/*      */     }
/*  768 */     return builder.build();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableChannelCreateRequest of(String name, Possible<Integer> type, Possible<String> topic, Possible<Integer> bitrate, Possible<Integer> userLimit, Possible<Integer> rateLimitPerUser, Possible<Integer> position, Possible<List<OverwriteData>> permissionOverwrites, Possible<String> parentId, Possible<Boolean> nsfw) {
/*  786 */     return new ImmutableChannelCreateRequest(name, type, topic, bitrate, userLimit, rateLimitPerUser, position, permissionOverwrites, parentId, nsfw);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableChannelCreateRequest copyOf(ChannelCreateRequest instance) {
/*  797 */     if (instance instanceof ImmutableChannelCreateRequest) {
/*  798 */       return (ImmutableChannelCreateRequest)instance;
/*      */     }
/*  800 */     return builder()
/*  801 */       .from(instance)
/*  802 */       .build();
/*      */   }
/*      */   
/*      */   public boolean isTypePresent() {
/*  806 */     return !this.type_absent;
/*      */   }
/*      */   
/*      */   public Integer typeOrElse(Integer defaultValue) {
/*  810 */     return !this.type_absent ? this.type_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isTopicPresent() {
/*  814 */     return !this.topic_absent;
/*      */   }
/*      */   
/*      */   public String topicOrElse(String defaultValue) {
/*  818 */     return !this.topic_absent ? this.topic_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isBitratePresent() {
/*  822 */     return !this.bitrate_absent;
/*      */   }
/*      */   
/*      */   public Integer bitrateOrElse(Integer defaultValue) {
/*  826 */     return !this.bitrate_absent ? this.bitrate_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isUserLimitPresent() {
/*  830 */     return !this.userLimit_absent;
/*      */   }
/*      */   
/*      */   public Integer userLimitOrElse(Integer defaultValue) {
/*  834 */     return !this.userLimit_absent ? this.userLimit_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isRateLimitPerUserPresent() {
/*  838 */     return !this.rateLimitPerUser_absent;
/*      */   }
/*      */   
/*      */   public Integer rateLimitPerUserOrElse(Integer defaultValue) {
/*  842 */     return !this.rateLimitPerUser_absent ? this.rateLimitPerUser_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isPositionPresent() {
/*  846 */     return !this.position_absent;
/*      */   }
/*      */   
/*      */   public Integer positionOrElse(Integer defaultValue) {
/*  850 */     return !this.position_absent ? this.position_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isPermissionOverwritesPresent() {
/*  854 */     return !this.permissionOverwrites_absent;
/*      */   }
/*      */   
/*      */   public List<OverwriteData> permissionOverwritesOrElse(List<OverwriteData> defaultValue) {
/*  858 */     return !this.permissionOverwrites_absent ? this.permissionOverwrites_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isParentIdPresent() {
/*  862 */     return !this.parentId_absent;
/*      */   }
/*      */   
/*      */   public String parentIdOrElse(String defaultValue) {
/*  866 */     return !this.parentId_absent ? this.parentId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isNsfwPresent() {
/*  870 */     return !this.nsfw_absent;
/*      */   }
/*      */   
/*      */   public Boolean nsfwOrElse(Boolean defaultValue) {
/*  874 */     return !this.nsfw_absent ? this.nsfw_value : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Builder builder() {
/*  896 */     return new Builder();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Generated(from = "ChannelCreateRequest", generator = "Immutables")
/*      */   public static final class Builder
/*      */   {
/*      */     private static final long INIT_BIT_NAME = 1L;
/*      */ 
/*      */ 
/*      */     
/*  909 */     private long initBits = 1L;
/*      */     
/*  911 */     private Possible<Integer> type_possible = Possible.absent();
/*  912 */     private Possible<String> topic_possible = Possible.absent();
/*  913 */     private Possible<Integer> bitrate_possible = Possible.absent();
/*  914 */     private Possible<Integer> userLimit_possible = Possible.absent();
/*  915 */     private Possible<Integer> rateLimitPerUser_possible = Possible.absent();
/*  916 */     private Possible<Integer> position_possible = Possible.absent();
/*  917 */     private List<OverwriteData> permissionOverwrites_list = null;
/*  918 */     private Possible<String> parentId_possible = Possible.absent();
/*  919 */     private Possible<Boolean> nsfw_possible = Possible.absent();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private String name;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(ChannelCreateRequest instance) {
/*  933 */       Objects.requireNonNull(instance, "instance");
/*  934 */       name(instance.name());
/*  935 */       type(instance.type());
/*  936 */       topic(instance.topic());
/*  937 */       bitrate(instance.bitrate());
/*  938 */       userLimit(instance.userLimit());
/*  939 */       rateLimitPerUser(instance.rateLimitPerUser());
/*  940 */       position(instance.position());
/*  941 */       permissionOverwrites(instance.permissionOverwrites());
/*  942 */       parentId(instance.parentId());
/*  943 */       nsfw(instance.nsfw());
/*  944 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("name")
/*      */     public final Builder name(String name) {
/*  954 */       this.name = Objects.<String>requireNonNull(name, "name");
/*  955 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/*  956 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("type")
/*      */     public Builder type(Possible<Integer> value) {
/*  961 */       this.type_possible = value;
/*  962 */       return this;
/*      */     }
/*      */     
/*      */     public Builder type(Integer value) {
/*  966 */       this.type_possible = Possible.of(value);
/*  967 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("topic")
/*      */     public Builder topic(Possible<String> value) {
/*  972 */       this.topic_possible = value;
/*  973 */       return this;
/*      */     }
/*      */     
/*      */     public Builder topic(String value) {
/*  977 */       this.topic_possible = Possible.of(value);
/*  978 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("bitrate")
/*      */     public Builder bitrate(Possible<Integer> value) {
/*  983 */       this.bitrate_possible = value;
/*  984 */       return this;
/*      */     }
/*      */     
/*      */     public Builder bitrate(Integer value) {
/*  988 */       this.bitrate_possible = Possible.of(value);
/*  989 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("user_limit")
/*      */     public Builder userLimit(Possible<Integer> value) {
/*  994 */       this.userLimit_possible = value;
/*  995 */       return this;
/*      */     }
/*      */     
/*      */     public Builder userLimit(Integer value) {
/*  999 */       this.userLimit_possible = Possible.of(value);
/* 1000 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("rate_limit_per_user")
/*      */     public Builder rateLimitPerUser(Possible<Integer> value) {
/* 1005 */       this.rateLimitPerUser_possible = value;
/* 1006 */       return this;
/*      */     }
/*      */     
/*      */     public Builder rateLimitPerUser(Integer value) {
/* 1010 */       this.rateLimitPerUser_possible = Possible.of(value);
/* 1011 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("position")
/*      */     public Builder position(Possible<Integer> value) {
/* 1016 */       this.position_possible = value;
/* 1017 */       return this;
/*      */     }
/*      */     
/*      */     public Builder position(Integer value) {
/* 1021 */       this.position_possible = Possible.of(value);
/* 1022 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addPermissionOverwrite(OverwriteData element) {
/* 1026 */       permissionOverwrites_getOrCreate().add(element);
/* 1027 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addAllPermissionOverwrites(List<OverwriteData> elements) {
/* 1031 */       permissionOverwrites_getOrCreate().addAll(elements);
/* 1032 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("permission_overwrites")
/*      */     public Builder permissionOverwrites(Possible<List<OverwriteData>> elements) {
/* 1037 */       this.permissionOverwrites_list = null;
/* 1038 */       elements.toOptional().ifPresent(e -> permissionOverwrites_getOrCreate().addAll(e));
/* 1039 */       return this;
/*      */     }
/*      */     
/*      */     public Builder permissionOverwrites(List<OverwriteData> elements) {
/* 1043 */       this.permissionOverwrites_list = new ArrayList<>(elements);
/* 1044 */       return this;
/*      */     }
/*      */     
/*      */     public Builder permissionOverwrites(Iterable<OverwriteData> elements) {
/* 1048 */       this.permissionOverwrites_list = (List<OverwriteData>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 1049 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("parent_id")
/*      */     public Builder parentId(Possible<String> value) {
/* 1054 */       this.parentId_possible = value;
/* 1055 */       return this;
/*      */     }
/*      */     
/*      */     public Builder parentId(String value) {
/* 1059 */       this.parentId_possible = Possible.of(value);
/* 1060 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("nsfw")
/*      */     public Builder nsfw(Possible<Boolean> value) {
/* 1065 */       this.nsfw_possible = value;
/* 1066 */       return this;
/*      */     }
/*      */     
/*      */     public Builder nsfw(Boolean value) {
/* 1070 */       this.nsfw_possible = Possible.of(value);
/* 1071 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ImmutableChannelCreateRequest build() {
/* 1080 */       if (this.initBits != 0L) {
/* 1081 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*      */       }
/* 1083 */       return new ImmutableChannelCreateRequest(null, this.name, 
/*      */ 
/*      */           
/* 1086 */           type_build(), 
/* 1087 */           topic_build(), 
/* 1088 */           bitrate_build(), 
/* 1089 */           userLimit_build(), 
/* 1090 */           rateLimitPerUser_build(), 
/* 1091 */           position_build(), 
/* 1092 */           permissionOverwrites_build(), 
/* 1093 */           parentId_build(), 
/* 1094 */           nsfw_build());
/*      */     }
/*      */     
/*      */     private String formatRequiredAttributesMessage() {
/* 1098 */       List<String> attributes = new ArrayList<>();
/* 1099 */       if ((this.initBits & 0x1L) != 0L) attributes.add("name"); 
/* 1100 */       return "Cannot build ChannelCreateRequest, some of required attributes are not set " + attributes;
/*      */     }
/*      */     
/*      */     private Possible<Integer> type_build() {
/* 1104 */       return this.type_possible;
/*      */     }
/*      */     
/*      */     private Possible<String> topic_build() {
/* 1108 */       return this.topic_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> bitrate_build() {
/* 1112 */       return this.bitrate_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> userLimit_build() {
/* 1116 */       return this.userLimit_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> rateLimitPerUser_build() {
/* 1120 */       return this.rateLimitPerUser_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> position_build() {
/* 1124 */       return this.position_possible;
/*      */     }
/*      */     
/*      */     private Possible<List<OverwriteData>> permissionOverwrites_build() {
/* 1128 */       return (this.permissionOverwrites_list == null) ? Possible.absent() : 
/* 1129 */         Possible.of(this.permissionOverwrites_list);
/*      */     }
/*      */     
/*      */     private List<OverwriteData> permissionOverwrites_getOrCreate() {
/* 1133 */       if (this.permissionOverwrites_list == null) {
/* 1134 */         this.permissionOverwrites_list = new ArrayList<>();
/*      */       }
/* 1136 */       return this.permissionOverwrites_list;
/*      */     }
/*      */     
/*      */     private Possible<String> parentId_build() {
/* 1140 */       return this.parentId_possible;
/*      */     }
/*      */     
/*      */     private Possible<Boolean> nsfw_build() {
/* 1144 */       return this.nsfw_possible;
/*      */     }
/*      */     
/*      */     private Builder() {}
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableChannelCreateRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */