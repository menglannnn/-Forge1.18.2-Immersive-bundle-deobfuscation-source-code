/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.Id;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ @JsonSerialize(as = ImmutableInteractionData.class)
/*    */ @JsonDeserialize(as = ImmutableInteractionData.class)
/*    */ @Immutable
/*    */ public interface InteractionData
/*    */ {
/*    */   static ImmutableInteractionData.Builder builder() {
/* 16 */     return ImmutableInteractionData.builder();
/*    */   }
/*    */   
/*    */   Id id();
/*    */   
/*    */   @JsonProperty("application_id")
/*    */   Id applicationId();
/*    */   
/*    */   int type();
/*    */   
/*    */   Possible<ApplicationCommandInteractionData> data();
/*    */   
/*    */   @JsonProperty("guild_id")
/*    */   Possible<Id> guildId();
/*    */   
/*    */   Possible<ChannelData> channel();
/*    */   
/*    */   @JsonProperty("channel_id")
/*    */   Possible<Id> channelId();
/*    */   
/*    */   Possible<MemberData> member();
/*    */   
/*    */   Possible<UserData> user();
/*    */   
/*    */   String token();
/*    */   
/*    */   int version();
/*    */   
/*    */   Possible<MessageData> message();
/*    */   
/*    */   Possible<String> locale();
/*    */   
/*    */   @JsonProperty("guild_locale")
/*    */   Possible<String> guildLocale();
/*    */   
/*    */   @JsonProperty("app_permissions")
/*    */   Possible<String> appPermissions();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\InteractionData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */