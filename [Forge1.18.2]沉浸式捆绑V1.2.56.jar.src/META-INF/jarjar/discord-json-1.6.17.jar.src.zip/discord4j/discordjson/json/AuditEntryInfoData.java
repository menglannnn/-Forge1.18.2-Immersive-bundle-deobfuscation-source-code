/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.Id;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ @JsonSerialize(as = ImmutableAuditEntryInfoData.class)
/*    */ @JsonDeserialize(as = ImmutableAuditEntryInfoData.class)
/*    */ @Immutable
/*    */ public interface AuditEntryInfoData
/*    */ {
/*    */   static ImmutableAuditEntryInfoData.Builder builder() {
/* 16 */     return ImmutableAuditEntryInfoData.builder();
/*    */   }
/*    */   
/*    */   @JsonProperty("delete_member_days")
/*    */   Possible<String> deleteMemberDays();
/*    */   
/*    */   @JsonProperty("members_removed")
/*    */   Possible<String> membersRemoved();
/*    */   
/*    */   @JsonProperty("channel_id")
/*    */   Possible<Id> channelId();
/*    */   
/*    */   @JsonProperty("message_id")
/*    */   Possible<Id> messageId();
/*    */   
/*    */   @JsonProperty("application_id")
/*    */   Possible<Id> applicationId();
/*    */   
/*    */   Possible<String> count();
/*    */   
/*    */   Possible<Id> id();
/*    */   
/*    */   Possible<String> type();
/*    */   
/*    */   @JsonProperty("role_name")
/*    */   Possible<String> roleName();
/*    */   
/*    */   @JsonProperty("auto_moderation_rule_name")
/*    */   Possible<String> autoModerationRuleName();
/*    */   
/*    */   @JsonProperty("auto_moderation_rule_trigger_type")
/*    */   Possible<String> autoModerationRuleTriggerType();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\AuditEntryInfoData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */