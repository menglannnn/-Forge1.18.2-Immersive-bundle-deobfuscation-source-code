/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import java.util.List;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ @JsonSerialize(as = ImmutableChannelCreateRequest.class)
/*    */ @JsonDeserialize(as = ImmutableChannelCreateRequest.class)
/*    */ @Immutable
/*    */ public interface ChannelCreateRequest
/*    */ {
/*    */   static ImmutableChannelCreateRequest.Builder builder() {
/* 17 */     return ImmutableChannelCreateRequest.builder();
/*    */   }
/*    */   
/*    */   String name();
/*    */   
/*    */   Possible<Integer> type();
/*    */   
/*    */   Possible<String> topic();
/*    */   
/*    */   Possible<Integer> bitrate();
/*    */   
/*    */   @JsonProperty("user_limit")
/*    */   Possible<Integer> userLimit();
/*    */   
/*    */   @JsonProperty("rate_limit_per_user")
/*    */   Possible<Integer> rateLimitPerUser();
/*    */   
/*    */   Possible<Integer> position();
/*    */   
/*    */   @JsonProperty("permission_overwrites")
/*    */   Possible<List<OverwriteData>> permissionOverwrites();
/*    */   
/*    */   @JsonProperty("parent_id")
/*    */   Possible<String> parentId();
/*    */   
/*    */   Possible<Boolean> nsfw();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ChannelCreateRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */