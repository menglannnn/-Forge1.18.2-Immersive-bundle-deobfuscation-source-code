/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.StreamSupport;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "ReadyData", generator = "Immutables")
/*     */ public final class ImmutableReadyData
/*     */   implements ReadyData
/*     */ {
/*     */   private final int v;
/*     */   private final UserData user;
/*     */   private final List<UnavailableGuildData> guilds;
/*     */   private final String sessionId;
/*     */   private final List<Integer> shard_value;
/*     */   private final boolean shard_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private ImmutableReadyData(int v, UserData user, Iterable<? extends UnavailableGuildData> guilds, String sessionId, Possible<List<Integer>> shard) {
/*  73 */     this.initShim = new InitShim(); this.v = v; this.user = Objects.<UserData>requireNonNull(user, "user"); this.guilds = createUnmodifiableList(false, createSafeList(guilds, true, false)); this.sessionId = Objects.<String>requireNonNull(sessionId, "sessionId"); Possible<List<Integer>> shard$impl = shard; this.shard_value = shard$impl.toOptional().orElse(null); this.shard_absent = shard$impl.isAbsent(); this.initShim = null; } private ImmutableReadyData(ImmutableReadyData original, int v, UserData user, List<UnavailableGuildData> guilds, String sessionId, Possible<List<Integer>> shard) { this.initShim = new InitShim(); this.v = v; this.user = user; this.guilds = guilds;
/*     */     this.sessionId = sessionId;
/*     */     Possible<List<Integer>> shard$impl = shard;
/*     */     this.shard_value = shard$impl.toOptional().orElse(null);
/*     */     this.shard_absent = shard$impl.isAbsent();
/*  78 */     this.initShim = null; } @Generated(from = "ReadyData", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/*  79 */       return "Cannot build ReadyData, attribute initializers form cycle " + attributes; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("v")
/*     */   public int v() {
/*  89 */     return this.v;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("user")
/*     */   public UserData user() {
/*  98 */     return this.user;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("guilds")
/*     */   public List<UnavailableGuildData> guilds() {
/* 107 */     return this.guilds;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("session_id")
/*     */   public String sessionId() {
/* 116 */     return this.sessionId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("shard")
/*     */   public Possible<List<Integer>> shard() {
/* 125 */     return this.shard_absent ? Possible.absent() : 
/* 126 */       Possible.of(this.shard_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableReadyData withV(int value) {
/* 136 */     if (this.v == value) return this; 
/* 137 */     return new ImmutableReadyData(this, value, this.user, this.guilds, this.sessionId, shard());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableReadyData withUser(UserData value) {
/* 147 */     if (this.user == value) return this; 
/* 148 */     UserData newValue = Objects.<UserData>requireNonNull(value, "user");
/* 149 */     return new ImmutableReadyData(this, this.v, newValue, this.guilds, this.sessionId, shard());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableReadyData withGuilds(UnavailableGuildData... elements) {
/* 158 */     List<UnavailableGuildData> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 159 */     return new ImmutableReadyData(this, this.v, this.user, newValue, this.sessionId, shard());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableReadyData withGuilds(Iterable<? extends UnavailableGuildData> elements) {
/* 169 */     if (this.guilds == elements) return this; 
/* 170 */     List<UnavailableGuildData> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 171 */     return new ImmutableReadyData(this, this.v, this.user, newValue, this.sessionId, shard());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableReadyData withSessionId(String value) {
/* 181 */     String newValue = Objects.<String>requireNonNull(value, "sessionId");
/* 182 */     if (this.sessionId.equals(newValue)) return this; 
/* 183 */     return new ImmutableReadyData(this, this.v, this.user, this.guilds, newValue, shard());
/*     */   }
/*     */   
/*     */   public ImmutableReadyData withShard(Possible<List<Integer>> possible) {
/* 187 */     Possible<List<Integer>> newValue = Objects.<Possible<List<Integer>>>requireNonNull(possible);
/* 188 */     return new ImmutableReadyData(this, this.v, this.user, this.guilds, this.sessionId, newValue);
/*     */   }
/*     */   
/*     */   public ImmutableReadyData withShard(Iterable<Integer> elements) {
/* 192 */     Possible<List<Integer>> newValue = Possible.of(
/* 193 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/* 194 */     return new ImmutableReadyData(this, this.v, this.user, this.guilds, this.sessionId, newValue);
/*     */   }
/*     */   
/*     */   @SafeVarargs
/*     */   public final ImmutableReadyData withShard(Integer... elements) {
/* 199 */     Possible<List<Integer>> newValue = Possible.of(Arrays.asList(elements));
/* 200 */     return new ImmutableReadyData(this, this.v, this.user, this.guilds, this.sessionId, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 209 */     if (this == another) return true; 
/* 210 */     return (another instanceof ImmutableReadyData && 
/* 211 */       equalTo(0, (ImmutableReadyData)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableReadyData another) {
/* 215 */     return (this.v == another.v && this.user
/* 216 */       .equals(another.user) && this.guilds
/* 217 */       .equals(another.guilds) && this.sessionId
/* 218 */       .equals(another.sessionId) && 
/* 219 */       Objects.equals(this.shard_value, another.shard_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 228 */     int h = 5381;
/* 229 */     h += (h << 5) + this.v;
/* 230 */     h += (h << 5) + this.user.hashCode();
/* 231 */     h += (h << 5) + this.guilds.hashCode();
/* 232 */     h += (h << 5) + this.sessionId.hashCode();
/* 233 */     h += (h << 5) + Objects.hashCode(this.shard_value);
/* 234 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 243 */     return "ReadyData{v=" + this.v + ", user=" + this.user + ", guilds=" + this.guilds + ", sessionId=" + this.sessionId + ", shard=" + 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 248 */       Objects.toString(this.shard_value) + "}";
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "ReadyData", generator = "Immutables")
/*     */   static final class Json
/*     */     implements ReadyData
/*     */   {
/*     */     int v;
/*     */     
/*     */     boolean vIsSet;
/*     */     
/*     */     UserData user;
/* 264 */     List<UnavailableGuildData> guilds = Collections.emptyList();
/*     */     
/*     */     String sessionId;
/* 267 */     Possible<List<Integer>> shard = Possible.absent();
/*     */     
/*     */     @JsonProperty("v")
/*     */     public void setV(int v) {
/* 271 */       this.v = v;
/* 272 */       this.vIsSet = true;
/*     */     }
/*     */     @JsonProperty("user")
/*     */     public void setUser(UserData user) {
/* 276 */       this.user = user;
/*     */     }
/*     */     @JsonProperty("guilds")
/*     */     public void setGuilds(List<UnavailableGuildData> guilds) {
/* 280 */       this.guilds = guilds;
/*     */     }
/*     */     @JsonProperty("session_id")
/*     */     public void setSessionId(String sessionId) {
/* 284 */       this.sessionId = sessionId;
/*     */     }
/*     */     @JsonProperty("shard")
/*     */     public void setShard(Possible<List<Integer>> shard) {
/* 288 */       this.shard = shard;
/*     */     }
/*     */     public int v() {
/* 291 */       throw new UnsupportedOperationException();
/*     */     } public UserData user() {
/* 293 */       throw new UnsupportedOperationException();
/*     */     } public List<UnavailableGuildData> guilds() {
/* 295 */       throw new UnsupportedOperationException();
/*     */     } public String sessionId() {
/* 297 */       throw new UnsupportedOperationException();
/*     */     } public Possible<List<Integer>> shard() {
/* 299 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableReadyData fromJson(Json json) {
/* 310 */     Builder builder = builder();
/* 311 */     if (json.vIsSet) {
/* 312 */       builder.v(json.v);
/*     */     }
/* 314 */     if (json.user != null) {
/* 315 */       builder.user(json.user);
/*     */     }
/* 317 */     if (json.guilds != null) {
/* 318 */       builder.addAllGuilds(json.guilds);
/*     */     }
/* 320 */     if (json.sessionId != null) {
/* 321 */       builder.sessionId(json.sessionId);
/*     */     }
/* 323 */     if (json.shard != null) {
/* 324 */       builder.shard(json.shard);
/*     */     }
/* 326 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableReadyData of(int v, UserData user, List<UnavailableGuildData> guilds, String sessionId, Possible<List<Integer>> shard) {
/* 339 */     return of(v, user, guilds, sessionId, shard);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableReadyData of(int v, UserData user, Iterable<? extends UnavailableGuildData> guilds, String sessionId, Possible<List<Integer>> shard) {
/* 352 */     return new ImmutableReadyData(v, user, guilds, sessionId, shard);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableReadyData copyOf(ReadyData instance) {
/* 363 */     if (instance instanceof ImmutableReadyData) {
/* 364 */       return (ImmutableReadyData)instance;
/*     */     }
/* 366 */     return builder()
/* 367 */       .from(instance)
/* 368 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isShardPresent() {
/* 372 */     return !this.shard_absent;
/*     */   }
/*     */   
/*     */   public List<Integer> shardOrElse(List<Integer> defaultValue) {
/* 376 */     return !this.shard_absent ? this.shard_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 393 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "ReadyData", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_V = 1L;
/*     */ 
/*     */     
/*     */     private static final long INIT_BIT_USER = 2L;
/*     */     
/*     */     private static final long INIT_BIT_SESSION_ID = 4L;
/*     */     
/* 408 */     private long initBits = 7L;
/*     */     
/* 410 */     private List<Integer> shard_list = null;
/*     */     private int v;
/*     */     private UserData user;
/* 413 */     private List<UnavailableGuildData> guilds = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String sessionId;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(ReadyData instance) {
/* 428 */       Objects.requireNonNull(instance, "instance");
/* 429 */       v(instance.v());
/* 430 */       user(instance.user());
/* 431 */       addAllGuilds(instance.guilds());
/* 432 */       sessionId(instance.sessionId());
/* 433 */       shard(instance.shard());
/* 434 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("v")
/*     */     public final Builder v(int v) {
/* 444 */       this.v = v;
/* 445 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 446 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("user")
/*     */     public final Builder user(UserData user) {
/* 456 */       this.user = Objects.<UserData>requireNonNull(user, "user");
/* 457 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 458 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addGuild(UnavailableGuildData element) {
/* 467 */       this.guilds.add(Objects.<UnavailableGuildData>requireNonNull(element, "guilds element"));
/* 468 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addGuilds(UnavailableGuildData... elements) {
/* 477 */       for (UnavailableGuildData element : elements) {
/* 478 */         this.guilds.add(Objects.<UnavailableGuildData>requireNonNull(element, "guilds element"));
/*     */       }
/* 480 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("guilds")
/*     */     public final Builder guilds(Iterable<? extends UnavailableGuildData> elements) {
/* 491 */       this.guilds.clear();
/* 492 */       return addAllGuilds(elements);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addAllGuilds(Iterable<? extends UnavailableGuildData> elements) {
/* 501 */       for (UnavailableGuildData element : elements) {
/* 502 */         this.guilds.add(Objects.<UnavailableGuildData>requireNonNull(element, "guilds element"));
/*     */       }
/* 504 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("session_id")
/*     */     public final Builder sessionId(String sessionId) {
/* 514 */       this.sessionId = Objects.<String>requireNonNull(sessionId, "sessionId");
/* 515 */       this.initBits &= 0xFFFFFFFFFFFFFFFBL;
/* 516 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addShard(Integer element) {
/* 520 */       shard_getOrCreate().add(element);
/* 521 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addAllShard(List<Integer> elements) {
/* 525 */       shard_getOrCreate().addAll(elements);
/* 526 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("shard")
/*     */     public Builder shard(Possible<List<Integer>> elements) {
/* 531 */       this.shard_list = null;
/* 532 */       elements.toOptional().ifPresent(e -> shard_getOrCreate().addAll(e));
/* 533 */       return this;
/*     */     }
/*     */     
/*     */     public Builder shard(List<Integer> elements) {
/* 537 */       this.shard_list = new ArrayList<>(elements);
/* 538 */       return this;
/*     */     }
/*     */     
/*     */     public Builder shard(Iterable<Integer> elements) {
/* 542 */       this.shard_list = (List<Integer>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 543 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableReadyData build() {
/* 552 */       if (this.initBits != 0L) {
/* 553 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 555 */       return new ImmutableReadyData(null, this.v, this.user, ImmutableReadyData.createUnmodifiableList(true, (List)this.guilds), this.sessionId, shard_build());
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 559 */       List<String> attributes = new ArrayList<>();
/* 560 */       if ((this.initBits & 0x1L) != 0L) attributes.add("v"); 
/* 561 */       if ((this.initBits & 0x2L) != 0L) attributes.add("user"); 
/* 562 */       if ((this.initBits & 0x4L) != 0L) attributes.add("sessionId"); 
/* 563 */       return "Cannot build ReadyData, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Possible<List<Integer>> shard_build() {
/* 567 */       return (this.shard_list == null) ? Possible.absent() : 
/* 568 */         Possible.of(this.shard_list);
/*     */     }
/*     */     
/*     */     private List<Integer> shard_getOrCreate() {
/* 572 */       if (this.shard_list == null) {
/* 573 */         this.shard_list = new ArrayList<>();
/*     */       }
/* 575 */       return this.shard_list;
/*     */     }
/*     */     private Builder() {} }
/*     */   
/*     */   private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
/*     */     ArrayList<T> list;
/* 581 */     if (iterable instanceof Collection) {
/* 582 */       int size = ((Collection)iterable).size();
/* 583 */       if (size == 0) return Collections.emptyList(); 
/* 584 */       list = new ArrayList<>();
/*     */     } else {
/* 586 */       list = new ArrayList<>();
/*     */     } 
/* 588 */     for (T element : iterable) {
/* 589 */       if (skipNulls && element == null)
/* 590 */         continue;  if (checkNulls) Objects.requireNonNull(element, "element"); 
/* 591 */       list.add(element);
/*     */     } 
/* 593 */     return list;
/*     */   }
/*     */   
/*     */   private static <T> List<T> createUnmodifiableList(boolean clone, List<T> list) {
/* 597 */     switch (list.size()) { case 0:
/* 598 */         return Collections.emptyList();
/* 599 */       case 1: return Collections.singletonList(list.get(0)); }
/*     */     
/* 601 */     if (clone) {
/* 602 */       return Collections.unmodifiableList(new ArrayList<>(list));
/*     */     }
/* 604 */     if (list instanceof ArrayList) {
/* 605 */       ((ArrayList)list).trimToSize();
/*     */     }
/* 607 */     return Collections.unmodifiableList(list);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableReadyData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */