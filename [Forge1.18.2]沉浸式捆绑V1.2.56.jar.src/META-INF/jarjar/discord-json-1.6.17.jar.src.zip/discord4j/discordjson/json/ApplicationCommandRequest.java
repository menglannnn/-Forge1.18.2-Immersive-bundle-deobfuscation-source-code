/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.Optional;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ @JsonSerialize(as = ImmutableApplicationCommandRequest.class)
/*    */ @JsonDeserialize(as = ImmutableApplicationCommandRequest.class)
/*    */ @Immutable
/*    */ public interface ApplicationCommandRequest
/*    */ {
/*    */   static ImmutableApplicationCommandRequest.Builder builder() {
/* 18 */     return ImmutableApplicationCommandRequest.builder();
/*    */   }
/*    */   
/*    */   String name();
/*    */   
/*    */   @JsonProperty("name_localizations")
/*    */   Possible<Optional<Map<String, String>>> nameLocalizations();
/*    */   
/*    */   Possible<String> description();
/*    */   
/*    */   @JsonProperty("description_localizations")
/*    */   Possible<Optional<Map<String, String>>> descriptionLocalizations();
/*    */   
/*    */   Possible<List<ApplicationCommandOptionData>> options();
/*    */   
/*    */   @JsonProperty("dm_permission")
/*    */   Possible<Boolean> dmPermission();
/*    */   
/*    */   @JsonProperty("default_permission")
/*    */   Possible<Boolean> defaultPermission();
/*    */   
/*    */   @JsonProperty("default_member_permissions")
/*    */   Optional<String> defaultMemberPermissions();
/*    */   
/*    */   Possible<Integer> type();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ApplicationCommandRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */