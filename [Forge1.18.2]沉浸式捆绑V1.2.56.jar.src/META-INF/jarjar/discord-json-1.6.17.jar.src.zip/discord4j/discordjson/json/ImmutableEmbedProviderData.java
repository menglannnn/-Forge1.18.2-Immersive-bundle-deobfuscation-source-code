/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "EmbedProviderData", generator = "Immutables")
/*     */ public final class ImmutableEmbedProviderData
/*     */   implements EmbedProviderData
/*     */ {
/*     */   private final String name_value;
/*     */   private final boolean name_absent;
/*     */   private final String url_value;
/*     */   private final boolean url_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private ImmutableEmbedProviderData(Possible<String> name, Possible<String> url) {
/*  33 */     Possible<String> name$impl = name;
/*  34 */     Possible<String> url$impl = url;
/*  35 */     this.name_value = name$impl.toOptional().orElse(null);
/*  36 */     this.name_absent = name$impl.isAbsent();
/*  37 */     this.url_value = url$impl.toOptional().orElse(null);
/*  38 */     this.url_absent = url$impl.isAbsent();
/*  39 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableEmbedProviderData(ImmutableEmbedProviderData original, Possible<String> name, Possible<String> url) {
/*  46 */     Possible<String> name$impl = name;
/*  47 */     Possible<String> url$impl = url;
/*  48 */     this.name_value = name$impl.toOptional().orElse(null);
/*  49 */     this.name_absent = name$impl.isAbsent();
/*  50 */     this.url_value = url$impl.toOptional().orElse(null);
/*  51 */     this.url_absent = url$impl.isAbsent();
/*  52 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  58 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "EmbedProviderData", generator = "Immutables")
/*     */   private final class InitShim {
/*     */     private String formatInitCycleMessage() {
/*  63 */       List<String> attributes = new ArrayList<>();
/*  64 */       return "Cannot build EmbedProviderData, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @JsonProperty("name")
/*     */   public Possible<String> name() {
/*  74 */     return this.name_absent ? Possible.absent() : Possible.of(this.name_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("url")
/*     */   public Possible<String> url() {
/*  83 */     return this.url_absent ? Possible.absent() : Possible.of(this.url_value);
/*     */   }
/*     */   
/*     */   public ImmutableEmbedProviderData withName(Possible<String> value) {
/*  87 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  88 */     return new ImmutableEmbedProviderData(this, newValue, url());
/*     */   }
/*     */   
/*     */   public ImmutableEmbedProviderData withName(String value) {
/*  92 */     Possible<String> newValue = Possible.of(value);
/*  93 */     return new ImmutableEmbedProviderData(this, newValue, url());
/*     */   }
/*     */   
/*     */   public ImmutableEmbedProviderData withUrl(Possible<String> value) {
/*  97 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  98 */     return new ImmutableEmbedProviderData(this, name(), newValue);
/*     */   }
/*     */   
/*     */   public ImmutableEmbedProviderData withUrl(String value) {
/* 102 */     Possible<String> newValue = Possible.of(value);
/* 103 */     return new ImmutableEmbedProviderData(this, name(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 112 */     if (this == another) return true; 
/* 113 */     return (another instanceof ImmutableEmbedProviderData && 
/* 114 */       equalTo(0, (ImmutableEmbedProviderData)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableEmbedProviderData another) {
/* 118 */     return (name().equals(another.name()) && 
/* 119 */       url().equals(another.url()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 128 */     int h = 5381;
/* 129 */     h += (h << 5) + name().hashCode();
/* 130 */     h += (h << 5) + url().hashCode();
/* 131 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 140 */     return "EmbedProviderData{name=" + 
/* 141 */       name().toString() + ", url=" + 
/* 142 */       url().toString() + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "EmbedProviderData", generator = "Immutables")
/*     */   static final class Json
/*     */     implements EmbedProviderData
/*     */   {
/* 156 */     Possible<String> name = Possible.absent();
/*     */ 
/*     */     
/* 159 */     Possible<String> url = Possible.absent();
/*     */     
/*     */     @JsonProperty("name")
/*     */     public void setName(Possible<String> name) {
/* 163 */       this.name = name;
/*     */     }
/*     */     @JsonProperty("url")
/*     */     public void setUrl(Possible<String> url) {
/* 167 */       this.url = url;
/*     */     }
/*     */     public Possible<String> name() {
/* 170 */       throw new UnsupportedOperationException();
/*     */     } public Possible<String> url() {
/* 172 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableEmbedProviderData fromJson(Json json) {
/* 183 */     Builder builder = builder();
/* 184 */     if (json.name != null) {
/* 185 */       builder.name(json.name);
/*     */     }
/* 187 */     if (json.url != null) {
/* 188 */       builder.url(json.url);
/*     */     }
/* 190 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableEmbedProviderData of(Possible<String> name, Possible<String> url) {
/* 200 */     return new ImmutableEmbedProviderData(name, url);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableEmbedProviderData copyOf(EmbedProviderData instance) {
/* 211 */     if (instance instanceof ImmutableEmbedProviderData) {
/* 212 */       return (ImmutableEmbedProviderData)instance;
/*     */     }
/* 214 */     return builder()
/* 215 */       .from(instance)
/* 216 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isNamePresent() {
/* 220 */     return !this.name_absent;
/*     */   }
/*     */   
/*     */   public String nameOrElse(String defaultValue) {
/* 224 */     return !this.name_absent ? this.name_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isUrlPresent() {
/* 228 */     return !this.url_absent;
/*     */   }
/*     */   
/*     */   public String urlOrElse(String defaultValue) {
/* 232 */     return !this.url_absent ? this.url_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 246 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "EmbedProviderData", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/* 258 */     private Possible<String> name_possible = Possible.absent();
/* 259 */     private Possible<String> url_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(EmbedProviderData instance) {
/* 272 */       Objects.requireNonNull(instance, "instance");
/* 273 */       name(instance.name());
/* 274 */       url(instance.url());
/* 275 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("name")
/*     */     public Builder name(Possible<String> value) {
/* 280 */       this.name_possible = value;
/* 281 */       return this;
/*     */     }
/*     */     
/*     */     public Builder name(String value) {
/* 285 */       this.name_possible = Possible.of(value);
/* 286 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("url")
/*     */     public Builder url(Possible<String> value) {
/* 291 */       this.url_possible = value;
/* 292 */       return this;
/*     */     }
/*     */     
/*     */     public Builder url(String value) {
/* 296 */       this.url_possible = Possible.of(value);
/* 297 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableEmbedProviderData build() {
/* 306 */       return new ImmutableEmbedProviderData(null, name_build(), url_build());
/*     */     }
/*     */     
/*     */     private Possible<String> name_build() {
/* 310 */       return this.name_possible;
/*     */     }
/*     */     
/*     */     private Possible<String> url_build() {
/* 314 */       return this.url_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableEmbedProviderData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */