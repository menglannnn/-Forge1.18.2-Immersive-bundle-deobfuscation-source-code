/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ @Generated(from = "NicknameModifyData", generator = "Immutables")
/*     */ public final class ImmutableNicknameModifyData
/*     */   implements NicknameModifyData
/*     */ {
/*     */   private final String nick;
/*     */   
/*     */   private ImmutableNicknameModifyData(Optional<String> nick) {
/*  27 */     this.nick = nick.orElse(null);
/*     */   }
/*     */   
/*     */   private ImmutableNicknameModifyData(ImmutableNicknameModifyData original, String nick) {
/*  31 */     this.nick = nick;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("nick")
/*     */   public Optional<String> nick() {
/*  40 */     return Optional.ofNullable(this.nick);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableNicknameModifyData withNick(String value) {
/*  49 */     String newValue = Objects.<String>requireNonNull(value, "nick");
/*  50 */     if (Objects.equals(this.nick, newValue)) return this; 
/*  51 */     return new ImmutableNicknameModifyData(this, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableNicknameModifyData withNick(Optional<String> optional) {
/*  61 */     String value = optional.orElse(null);
/*  62 */     if (Objects.equals(this.nick, value)) return this; 
/*  63 */     return new ImmutableNicknameModifyData(this, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/*  72 */     if (this == another) return true; 
/*  73 */     return (another instanceof ImmutableNicknameModifyData && 
/*  74 */       equalTo(0, (ImmutableNicknameModifyData)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableNicknameModifyData another) {
/*  78 */     return Objects.equals(this.nick, another.nick);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  87 */     int h = 5381;
/*  88 */     h += (h << 5) + Objects.hashCode(this.nick);
/*  89 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  98 */     StringBuilder builder = new StringBuilder("NicknameModifyData{");
/*  99 */     if (this.nick != null) {
/* 100 */       builder.append("nick=").append(this.nick);
/*     */     }
/* 102 */     return builder.append("}").toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "NicknameModifyData", generator = "Immutables")
/*     */   static final class Json
/*     */     implements NicknameModifyData
/*     */   {
/* 114 */     Optional<String> nick = Optional.empty();
/*     */     @JsonProperty("nick")
/*     */     public void setNick(Optional<String> nick) {
/* 117 */       this.nick = nick;
/*     */     }
/*     */     public Optional<String> nick() {
/* 120 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableNicknameModifyData fromJson(Json json) {
/* 131 */     Builder builder = builder();
/* 132 */     if (json.nick != null) {
/* 133 */       builder.nick(json.nick);
/*     */     }
/* 135 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableNicknameModifyData of(Optional<String> nick) {
/* 144 */     return new ImmutableNicknameModifyData(nick);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableNicknameModifyData copyOf(NicknameModifyData instance) {
/* 155 */     if (instance instanceof ImmutableNicknameModifyData) {
/* 156 */       return (ImmutableNicknameModifyData)instance;
/*     */     }
/* 158 */     return builder()
/* 159 */       .from(instance)
/* 160 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 173 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "NicknameModifyData", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private String nick;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Builder() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(NicknameModifyData instance) {
/* 198 */       Objects.requireNonNull(instance, "instance");
/* 199 */       Optional<String> nickOptional = instance.nick();
/* 200 */       if (nickOptional.isPresent()) {
/* 201 */         nick(nickOptional);
/*     */       }
/* 203 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder nick(String nick) {
/* 212 */       this.nick = Objects.<String>requireNonNull(nick, "nick");
/* 213 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("nick")
/*     */     public final Builder nick(Optional<String> nick) {
/* 223 */       this.nick = nick.orElse(null);
/* 224 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableNicknameModifyData build() {
/* 233 */       return new ImmutableNicknameModifyData(null, this.nick);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableNicknameModifyData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */