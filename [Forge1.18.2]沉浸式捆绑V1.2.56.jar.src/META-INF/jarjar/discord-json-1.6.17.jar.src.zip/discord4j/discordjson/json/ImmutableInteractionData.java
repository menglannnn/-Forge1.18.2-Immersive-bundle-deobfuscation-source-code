/*      */ package discord4j.discordjson.json;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*      */ import com.fasterxml.jackson.annotation.JsonCreator;
/*      */ import com.fasterxml.jackson.annotation.JsonProperty;
/*      */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*      */ import discord4j.discordjson.Id;
/*      */ import discord4j.discordjson.possible.Possible;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import org.immutables.value.Generated;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Generated(from = "InteractionData", generator = "Immutables")
/*      */ public final class ImmutableInteractionData
/*      */   implements InteractionData
/*      */ {
/*      */   private final long id_value;
/*      */   private final long applicationId_value;
/*      */   private final int type;
/*      */   private final ApplicationCommandInteractionData data_value;
/*      */   private final boolean data_absent;
/*      */   private final long guildId_value;
/*      */   private final boolean guildId_absent;
/*      */   private final ChannelData channel_value;
/*      */   private final boolean channel_absent;
/*      */   private final long channelId_value;
/*      */   private final boolean channelId_absent;
/*      */   private final MemberData member_value;
/*      */   private final boolean member_absent;
/*      */   private final UserData user_value;
/*      */   private final boolean user_absent;
/*      */   private final String token;
/*      */   private final int version;
/*      */   private final MessageData message_value;
/*      */   private final boolean message_absent;
/*      */   private final String locale_value;
/*      */   private final boolean locale_absent;
/*      */   private final String guildLocale_value;
/*      */   private final boolean guildLocale_absent;
/*      */   private final String appPermissions_value;
/*      */   private final boolean appPermissions_absent;
/*      */   private static final byte STAGE_INITIALIZING = -1;
/*      */   private static final byte STAGE_UNINITIALIZED = 0;
/*      */   private static final byte STAGE_INITIALIZED = 1;
/*      */   
/*      */   private ImmutableInteractionData(Id id, Id applicationId, int type, Possible<ApplicationCommandInteractionData> data, Possible<Id> guildId, Possible<ChannelData> channel, Possible<Id> channelId, Possible<MemberData> member, Possible<UserData> user, String token, int version, Possible<MessageData> message, Possible<String> locale, Possible<String> guildLocale, Possible<String> appPermissions) {
/*   68 */     Id id$impl = id;
/*   69 */     Id applicationId$impl = applicationId;
/*   70 */     this.type = type;
/*   71 */     Possible<ApplicationCommandInteractionData> data$impl = data;
/*   72 */     Possible<Id> guildId$impl = guildId;
/*   73 */     Possible<ChannelData> channel$impl = channel;
/*   74 */     Possible<Id> channelId$impl = channelId;
/*   75 */     Possible<MemberData> member$impl = member;
/*   76 */     Possible<UserData> user$impl = user;
/*   77 */     this.token = Objects.<String>requireNonNull(token, "token");
/*   78 */     this.version = version;
/*   79 */     Possible<MessageData> message$impl = message;
/*   80 */     Possible<String> locale$impl = locale;
/*   81 */     Possible<String> guildLocale$impl = guildLocale;
/*   82 */     Possible<String> appPermissions$impl = appPermissions;
/*   83 */     this.id_value = id$impl.asLong();
/*   84 */     this.applicationId_value = applicationId$impl.asLong();
/*   85 */     this.data_value = data$impl.toOptional().orElse(null);
/*   86 */     this.data_absent = data$impl.isAbsent();
/*   87 */     this
/*      */       
/*   89 */       .guildId_value = ((Long)guildId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*   90 */     this.guildId_absent = guildId$impl.isAbsent();
/*   91 */     this.channel_value = channel$impl.toOptional().orElse(null);
/*   92 */     this.channel_absent = channel$impl.isAbsent();
/*   93 */     this
/*      */       
/*   95 */       .channelId_value = ((Long)channelId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*   96 */     this.channelId_absent = channelId$impl.isAbsent();
/*   97 */     this.member_value = member$impl.toOptional().orElse(null);
/*   98 */     this.member_absent = member$impl.isAbsent();
/*   99 */     this.user_value = user$impl.toOptional().orElse(null);
/*  100 */     this.user_absent = user$impl.isAbsent();
/*  101 */     this.message_value = message$impl.toOptional().orElse(null);
/*  102 */     this.message_absent = message$impl.isAbsent();
/*  103 */     this.locale_value = locale$impl.toOptional().orElse(null);
/*  104 */     this.locale_absent = locale$impl.isAbsent();
/*  105 */     this.guildLocale_value = guildLocale$impl.toOptional().orElse(null);
/*  106 */     this.guildLocale_absent = guildLocale$impl.isAbsent();
/*  107 */     this.appPermissions_value = appPermissions$impl.toOptional().orElse(null);
/*  108 */     this.appPermissions_absent = appPermissions$impl.isAbsent();
/*  109 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ImmutableInteractionData(ImmutableInteractionData original, Id id, Id applicationId, int type, Possible<ApplicationCommandInteractionData> data, Possible<Id> guildId, Possible<ChannelData> channel, Possible<Id> channelId, Possible<MemberData> member, Possible<UserData> user, String token, int version, Possible<MessageData> message, Possible<String> locale, Possible<String> guildLocale, Possible<String> appPermissions) {
/*  129 */     Id id$impl = id;
/*  130 */     Id applicationId$impl = applicationId;
/*  131 */     this.type = type;
/*  132 */     Possible<ApplicationCommandInteractionData> data$impl = data;
/*  133 */     Possible<Id> guildId$impl = guildId;
/*  134 */     Possible<ChannelData> channel$impl = channel;
/*  135 */     Possible<Id> channelId$impl = channelId;
/*  136 */     Possible<MemberData> member$impl = member;
/*  137 */     Possible<UserData> user$impl = user;
/*  138 */     this.token = token;
/*  139 */     this.version = version;
/*  140 */     Possible<MessageData> message$impl = message;
/*  141 */     Possible<String> locale$impl = locale;
/*  142 */     Possible<String> guildLocale$impl = guildLocale;
/*  143 */     Possible<String> appPermissions$impl = appPermissions;
/*  144 */     this.id_value = id$impl.asLong();
/*  145 */     this.applicationId_value = applicationId$impl.asLong();
/*  146 */     this.data_value = data$impl.toOptional().orElse(null);
/*  147 */     this.data_absent = data$impl.isAbsent();
/*  148 */     this
/*      */       
/*  150 */       .guildId_value = ((Long)guildId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  151 */     this.guildId_absent = guildId$impl.isAbsent();
/*  152 */     this.channel_value = channel$impl.toOptional().orElse(null);
/*  153 */     this.channel_absent = channel$impl.isAbsent();
/*  154 */     this
/*      */       
/*  156 */       .channelId_value = ((Long)channelId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  157 */     this.channelId_absent = channelId$impl.isAbsent();
/*  158 */     this.member_value = member$impl.toOptional().orElse(null);
/*  159 */     this.member_absent = member$impl.isAbsent();
/*  160 */     this.user_value = user$impl.toOptional().orElse(null);
/*  161 */     this.user_absent = user$impl.isAbsent();
/*  162 */     this.message_value = message$impl.toOptional().orElse(null);
/*  163 */     this.message_absent = message$impl.isAbsent();
/*  164 */     this.locale_value = locale$impl.toOptional().orElse(null);
/*  165 */     this.locale_absent = locale$impl.isAbsent();
/*  166 */     this.guildLocale_value = guildLocale$impl.toOptional().orElse(null);
/*  167 */     this.guildLocale_absent = guildLocale$impl.isAbsent();
/*  168 */     this.appPermissions_value = appPermissions$impl.toOptional().orElse(null);
/*  169 */     this.appPermissions_absent = appPermissions$impl.isAbsent();
/*  170 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  176 */   private volatile transient InitShim initShim = new InitShim();
/*      */   
/*      */   @Generated(from = "InteractionData", generator = "Immutables")
/*      */   private final class InitShim {
/*      */     private String formatInitCycleMessage() {
/*  181 */       List<String> attributes = new ArrayList<>();
/*  182 */       return "Cannot build InteractionData, attribute initializers form cycle " + attributes;
/*      */     }
/*      */ 
/*      */     
/*      */     private InitShim() {}
/*      */   }
/*      */ 
/*      */   
/*      */   @JsonProperty("id")
/*      */   public Id id() {
/*  192 */     return Id.of(this.id_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("application_id")
/*      */   public Id applicationId() {
/*  201 */     return Id.of(this.applicationId_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("type")
/*      */   public int type() {
/*  210 */     return this.type;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("data")
/*      */   public Possible<ApplicationCommandInteractionData> data() {
/*  219 */     return this.data_absent ? Possible.absent() : Possible.of(this.data_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("guild_id")
/*      */   public Possible<Id> guildId() {
/*  228 */     return this.guildId_absent ? Possible.absent() : 
/*  229 */       Possible.of(Id.of(this.guildId_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("channel")
/*      */   public Possible<ChannelData> channel() {
/*  238 */     return this.channel_absent ? Possible.absent() : Possible.of(this.channel_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("channel_id")
/*      */   public Possible<Id> channelId() {
/*  247 */     return this.channelId_absent ? Possible.absent() : 
/*  248 */       Possible.of(Id.of(this.channelId_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("member")
/*      */   public Possible<MemberData> member() {
/*  257 */     return this.member_absent ? Possible.absent() : Possible.of(this.member_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("user")
/*      */   public Possible<UserData> user() {
/*  266 */     return this.user_absent ? Possible.absent() : Possible.of(this.user_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("token")
/*      */   public String token() {
/*  275 */     return this.token;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("version")
/*      */   public int version() {
/*  284 */     return this.version;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("message")
/*      */   public Possible<MessageData> message() {
/*  293 */     return this.message_absent ? Possible.absent() : Possible.of(this.message_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("locale")
/*      */   public Possible<String> locale() {
/*  302 */     return this.locale_absent ? Possible.absent() : Possible.of(this.locale_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("guild_locale")
/*      */   public Possible<String> guildLocale() {
/*  311 */     return this.guildLocale_absent ? Possible.absent() : Possible.of(this.guildLocale_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("app_permissions")
/*      */   public Possible<String> appPermissions() {
/*  320 */     return this.appPermissions_absent ? Possible.absent() : Possible.of(this.appPermissions_value);
/*      */   }
/*      */   
/*      */   public ImmutableInteractionData withId(long value) {
/*  324 */     Id newValue = Id.of(value);
/*  325 */     return new ImmutableInteractionData(this, newValue, 
/*      */ 
/*      */         
/*  328 */         applicationId(), this.type, 
/*      */         
/*  330 */         data(), 
/*  331 */         guildId(), 
/*  332 */         channel(), 
/*  333 */         channelId(), 
/*  334 */         member(), 
/*  335 */         user(), this.token, this.version, 
/*      */ 
/*      */         
/*  338 */         message(), 
/*  339 */         locale(), 
/*  340 */         guildLocale(), 
/*  341 */         appPermissions());
/*      */   }
/*      */   
/*      */   public ImmutableInteractionData withId(String value) {
/*  345 */     Id newValue = Id.of(value);
/*  346 */     return new ImmutableInteractionData(this, newValue, 
/*      */ 
/*      */         
/*  349 */         applicationId(), this.type, 
/*      */         
/*  351 */         data(), 
/*  352 */         guildId(), 
/*  353 */         channel(), 
/*  354 */         channelId(), 
/*  355 */         member(), 
/*  356 */         user(), this.token, this.version, 
/*      */ 
/*      */         
/*  359 */         message(), 
/*  360 */         locale(), 
/*  361 */         guildLocale(), 
/*  362 */         appPermissions());
/*      */   }
/*      */   
/*      */   public ImmutableInteractionData withApplicationId(long value) {
/*  366 */     Id newValue = Id.of(value);
/*  367 */     return new ImmutableInteractionData(this, 
/*      */         
/*  369 */         id(), newValue, this.type, 
/*      */ 
/*      */         
/*  372 */         data(), 
/*  373 */         guildId(), 
/*  374 */         channel(), 
/*  375 */         channelId(), 
/*  376 */         member(), 
/*  377 */         user(), this.token, this.version, 
/*      */ 
/*      */         
/*  380 */         message(), 
/*  381 */         locale(), 
/*  382 */         guildLocale(), 
/*  383 */         appPermissions());
/*      */   }
/*      */   
/*      */   public ImmutableInteractionData withApplicationId(String value) {
/*  387 */     Id newValue = Id.of(value);
/*  388 */     return new ImmutableInteractionData(this, 
/*      */         
/*  390 */         id(), newValue, this.type, 
/*      */ 
/*      */         
/*  393 */         data(), 
/*  394 */         guildId(), 
/*  395 */         channel(), 
/*  396 */         channelId(), 
/*  397 */         member(), 
/*  398 */         user(), this.token, this.version, 
/*      */ 
/*      */         
/*  401 */         message(), 
/*  402 */         locale(), 
/*  403 */         guildLocale(), 
/*  404 */         appPermissions());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableInteractionData withType(int value) {
/*  414 */     if (this.type == value) return this; 
/*  415 */     return new ImmutableInteractionData(this, 
/*      */         
/*  417 */         id(), 
/*  418 */         applicationId(), value, 
/*      */         
/*  420 */         data(), 
/*  421 */         guildId(), 
/*  422 */         channel(), 
/*  423 */         channelId(), 
/*  424 */         member(), 
/*  425 */         user(), this.token, this.version, 
/*      */ 
/*      */         
/*  428 */         message(), 
/*  429 */         locale(), 
/*  430 */         guildLocale(), 
/*  431 */         appPermissions());
/*      */   }
/*      */   
/*      */   public ImmutableInteractionData withData(Possible<ApplicationCommandInteractionData> value) {
/*  435 */     Possible<ApplicationCommandInteractionData> newValue = Objects.<Possible<ApplicationCommandInteractionData>>requireNonNull(value);
/*  436 */     return new ImmutableInteractionData(this, 
/*      */         
/*  438 */         id(), 
/*  439 */         applicationId(), this.type, newValue, 
/*      */ 
/*      */         
/*  442 */         guildId(), 
/*  443 */         channel(), 
/*  444 */         channelId(), 
/*  445 */         member(), 
/*  446 */         user(), this.token, this.version, 
/*      */ 
/*      */         
/*  449 */         message(), 
/*  450 */         locale(), 
/*  451 */         guildLocale(), 
/*  452 */         appPermissions());
/*      */   }
/*      */   
/*      */   public ImmutableInteractionData withData(ApplicationCommandInteractionData value) {
/*  456 */     Possible<ApplicationCommandInteractionData> newValue = Possible.of(value);
/*  457 */     return new ImmutableInteractionData(this, 
/*      */         
/*  459 */         id(), 
/*  460 */         applicationId(), this.type, newValue, 
/*      */ 
/*      */         
/*  463 */         guildId(), 
/*  464 */         channel(), 
/*  465 */         channelId(), 
/*  466 */         member(), 
/*  467 */         user(), this.token, this.version, 
/*      */ 
/*      */         
/*  470 */         message(), 
/*  471 */         locale(), 
/*  472 */         guildLocale(), 
/*  473 */         appPermissions());
/*      */   }
/*      */   
/*      */   public ImmutableInteractionData withGuildId(Possible<Id> value) {
/*  477 */     Possible<Id> newValue = Objects.<Possible<Id>>requireNonNull(value);
/*  478 */     return new ImmutableInteractionData(this, 
/*      */         
/*  480 */         id(), 
/*  481 */         applicationId(), this.type, 
/*      */         
/*  483 */         data(), newValue, 
/*      */         
/*  485 */         channel(), 
/*  486 */         channelId(), 
/*  487 */         member(), 
/*  488 */         user(), this.token, this.version, 
/*      */ 
/*      */         
/*  491 */         message(), 
/*  492 */         locale(), 
/*  493 */         guildLocale(), 
/*  494 */         appPermissions());
/*      */   }
/*      */   
/*      */   public ImmutableInteractionData withGuildId(long value) {
/*  498 */     Possible<Id> newValue = Possible.of(Id.of(value));
/*  499 */     return new ImmutableInteractionData(this, 
/*      */         
/*  501 */         id(), 
/*  502 */         applicationId(), this.type, 
/*      */         
/*  504 */         data(), newValue, 
/*      */         
/*  506 */         channel(), 
/*  507 */         channelId(), 
/*  508 */         member(), 
/*  509 */         user(), this.token, this.version, 
/*      */ 
/*      */         
/*  512 */         message(), 
/*  513 */         locale(), 
/*  514 */         guildLocale(), 
/*  515 */         appPermissions());
/*      */   }
/*      */   
/*      */   public ImmutableInteractionData withChannel(Possible<ChannelData> value) {
/*  519 */     Possible<ChannelData> newValue = Objects.<Possible<ChannelData>>requireNonNull(value);
/*  520 */     return new ImmutableInteractionData(this, 
/*      */         
/*  522 */         id(), 
/*  523 */         applicationId(), this.type, 
/*      */         
/*  525 */         data(), 
/*  526 */         guildId(), newValue, 
/*      */         
/*  528 */         channelId(), 
/*  529 */         member(), 
/*  530 */         user(), this.token, this.version, 
/*      */ 
/*      */         
/*  533 */         message(), 
/*  534 */         locale(), 
/*  535 */         guildLocale(), 
/*  536 */         appPermissions());
/*      */   }
/*      */   
/*      */   public ImmutableInteractionData withChannel(ChannelData value) {
/*  540 */     Possible<ChannelData> newValue = Possible.of(value);
/*  541 */     return new ImmutableInteractionData(this, 
/*      */         
/*  543 */         id(), 
/*  544 */         applicationId(), this.type, 
/*      */         
/*  546 */         data(), 
/*  547 */         guildId(), newValue, 
/*      */         
/*  549 */         channelId(), 
/*  550 */         member(), 
/*  551 */         user(), this.token, this.version, 
/*      */ 
/*      */         
/*  554 */         message(), 
/*  555 */         locale(), 
/*  556 */         guildLocale(), 
/*  557 */         appPermissions());
/*      */   }
/*      */   
/*      */   public ImmutableInteractionData withChannelId(Possible<Id> value) {
/*  561 */     Possible<Id> newValue = Objects.<Possible<Id>>requireNonNull(value);
/*  562 */     return new ImmutableInteractionData(this, 
/*      */         
/*  564 */         id(), 
/*  565 */         applicationId(), this.type, 
/*      */         
/*  567 */         data(), 
/*  568 */         guildId(), 
/*  569 */         channel(), newValue, 
/*      */         
/*  571 */         member(), 
/*  572 */         user(), this.token, this.version, 
/*      */ 
/*      */         
/*  575 */         message(), 
/*  576 */         locale(), 
/*  577 */         guildLocale(), 
/*  578 */         appPermissions());
/*      */   }
/*      */   
/*      */   public ImmutableInteractionData withChannelId(long value) {
/*  582 */     Possible<Id> newValue = Possible.of(Id.of(value));
/*  583 */     return new ImmutableInteractionData(this, 
/*      */         
/*  585 */         id(), 
/*  586 */         applicationId(), this.type, 
/*      */         
/*  588 */         data(), 
/*  589 */         guildId(), 
/*  590 */         channel(), newValue, 
/*      */         
/*  592 */         member(), 
/*  593 */         user(), this.token, this.version, 
/*      */ 
/*      */         
/*  596 */         message(), 
/*  597 */         locale(), 
/*  598 */         guildLocale(), 
/*  599 */         appPermissions());
/*      */   }
/*      */   
/*      */   public ImmutableInteractionData withMember(Possible<MemberData> value) {
/*  603 */     Possible<MemberData> newValue = Objects.<Possible<MemberData>>requireNonNull(value);
/*  604 */     return new ImmutableInteractionData(this, 
/*      */         
/*  606 */         id(), 
/*  607 */         applicationId(), this.type, 
/*      */         
/*  609 */         data(), 
/*  610 */         guildId(), 
/*  611 */         channel(), 
/*  612 */         channelId(), newValue, 
/*      */         
/*  614 */         user(), this.token, this.version, 
/*      */ 
/*      */         
/*  617 */         message(), 
/*  618 */         locale(), 
/*  619 */         guildLocale(), 
/*  620 */         appPermissions());
/*      */   }
/*      */   
/*      */   public ImmutableInteractionData withMember(MemberData value) {
/*  624 */     Possible<MemberData> newValue = Possible.of(value);
/*  625 */     return new ImmutableInteractionData(this, 
/*      */         
/*  627 */         id(), 
/*  628 */         applicationId(), this.type, 
/*      */         
/*  630 */         data(), 
/*  631 */         guildId(), 
/*  632 */         channel(), 
/*  633 */         channelId(), newValue, 
/*      */         
/*  635 */         user(), this.token, this.version, 
/*      */ 
/*      */         
/*  638 */         message(), 
/*  639 */         locale(), 
/*  640 */         guildLocale(), 
/*  641 */         appPermissions());
/*      */   }
/*      */   
/*      */   public ImmutableInteractionData withUser(Possible<UserData> value) {
/*  645 */     Possible<UserData> newValue = Objects.<Possible<UserData>>requireNonNull(value);
/*  646 */     return new ImmutableInteractionData(this, 
/*      */         
/*  648 */         id(), 
/*  649 */         applicationId(), this.type, 
/*      */         
/*  651 */         data(), 
/*  652 */         guildId(), 
/*  653 */         channel(), 
/*  654 */         channelId(), 
/*  655 */         member(), newValue, this.token, this.version, 
/*      */ 
/*      */ 
/*      */         
/*  659 */         message(), 
/*  660 */         locale(), 
/*  661 */         guildLocale(), 
/*  662 */         appPermissions());
/*      */   }
/*      */   
/*      */   public ImmutableInteractionData withUser(UserData value) {
/*  666 */     Possible<UserData> newValue = Possible.of(value);
/*  667 */     return new ImmutableInteractionData(this, 
/*      */         
/*  669 */         id(), 
/*  670 */         applicationId(), this.type, 
/*      */         
/*  672 */         data(), 
/*  673 */         guildId(), 
/*  674 */         channel(), 
/*  675 */         channelId(), 
/*  676 */         member(), newValue, this.token, this.version, 
/*      */ 
/*      */ 
/*      */         
/*  680 */         message(), 
/*  681 */         locale(), 
/*  682 */         guildLocale(), 
/*  683 */         appPermissions());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableInteractionData withToken(String value) {
/*  693 */     String newValue = Objects.<String>requireNonNull(value, "token");
/*  694 */     if (this.token.equals(newValue)) return this; 
/*  695 */     return new ImmutableInteractionData(this, 
/*      */         
/*  697 */         id(), 
/*  698 */         applicationId(), this.type, 
/*      */         
/*  700 */         data(), 
/*  701 */         guildId(), 
/*  702 */         channel(), 
/*  703 */         channelId(), 
/*  704 */         member(), 
/*  705 */         user(), newValue, this.version, 
/*      */ 
/*      */         
/*  708 */         message(), 
/*  709 */         locale(), 
/*  710 */         guildLocale(), 
/*  711 */         appPermissions());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableInteractionData withVersion(int value) {
/*  721 */     if (this.version == value) return this; 
/*  722 */     return new ImmutableInteractionData(this, 
/*      */         
/*  724 */         id(), 
/*  725 */         applicationId(), this.type, 
/*      */         
/*  727 */         data(), 
/*  728 */         guildId(), 
/*  729 */         channel(), 
/*  730 */         channelId(), 
/*  731 */         member(), 
/*  732 */         user(), this.token, value, 
/*      */ 
/*      */         
/*  735 */         message(), 
/*  736 */         locale(), 
/*  737 */         guildLocale(), 
/*  738 */         appPermissions());
/*      */   }
/*      */   
/*      */   public ImmutableInteractionData withMessage(Possible<MessageData> value) {
/*  742 */     Possible<MessageData> newValue = Objects.<Possible<MessageData>>requireNonNull(value);
/*  743 */     return new ImmutableInteractionData(this, 
/*      */         
/*  745 */         id(), 
/*  746 */         applicationId(), this.type, 
/*      */         
/*  748 */         data(), 
/*  749 */         guildId(), 
/*  750 */         channel(), 
/*  751 */         channelId(), 
/*  752 */         member(), 
/*  753 */         user(), this.token, this.version, newValue, 
/*      */ 
/*      */ 
/*      */         
/*  757 */         locale(), 
/*  758 */         guildLocale(), 
/*  759 */         appPermissions());
/*      */   }
/*      */   
/*      */   public ImmutableInteractionData withMessage(MessageData value) {
/*  763 */     Possible<MessageData> newValue = Possible.of(value);
/*  764 */     return new ImmutableInteractionData(this, 
/*      */         
/*  766 */         id(), 
/*  767 */         applicationId(), this.type, 
/*      */         
/*  769 */         data(), 
/*  770 */         guildId(), 
/*  771 */         channel(), 
/*  772 */         channelId(), 
/*  773 */         member(), 
/*  774 */         user(), this.token, this.version, newValue, 
/*      */ 
/*      */ 
/*      */         
/*  778 */         locale(), 
/*  779 */         guildLocale(), 
/*  780 */         appPermissions());
/*      */   }
/*      */   
/*      */   public ImmutableInteractionData withLocale(Possible<String> value) {
/*  784 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  785 */     return new ImmutableInteractionData(this, 
/*      */         
/*  787 */         id(), 
/*  788 */         applicationId(), this.type, 
/*      */         
/*  790 */         data(), 
/*  791 */         guildId(), 
/*  792 */         channel(), 
/*  793 */         channelId(), 
/*  794 */         member(), 
/*  795 */         user(), this.token, this.version, 
/*      */ 
/*      */         
/*  798 */         message(), newValue, 
/*      */         
/*  800 */         guildLocale(), 
/*  801 */         appPermissions());
/*      */   }
/*      */   
/*      */   public ImmutableInteractionData withLocale(String value) {
/*  805 */     Possible<String> newValue = Possible.of(value);
/*  806 */     return new ImmutableInteractionData(this, 
/*      */         
/*  808 */         id(), 
/*  809 */         applicationId(), this.type, 
/*      */         
/*  811 */         data(), 
/*  812 */         guildId(), 
/*  813 */         channel(), 
/*  814 */         channelId(), 
/*  815 */         member(), 
/*  816 */         user(), this.token, this.version, 
/*      */ 
/*      */         
/*  819 */         message(), newValue, 
/*      */         
/*  821 */         guildLocale(), 
/*  822 */         appPermissions());
/*      */   }
/*      */   
/*      */   public ImmutableInteractionData withGuildLocale(Possible<String> value) {
/*  826 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  827 */     return new ImmutableInteractionData(this, 
/*      */         
/*  829 */         id(), 
/*  830 */         applicationId(), this.type, 
/*      */         
/*  832 */         data(), 
/*  833 */         guildId(), 
/*  834 */         channel(), 
/*  835 */         channelId(), 
/*  836 */         member(), 
/*  837 */         user(), this.token, this.version, 
/*      */ 
/*      */         
/*  840 */         message(), 
/*  841 */         locale(), newValue, 
/*      */         
/*  843 */         appPermissions());
/*      */   }
/*      */   
/*      */   public ImmutableInteractionData withGuildLocale(String value) {
/*  847 */     Possible<String> newValue = Possible.of(value);
/*  848 */     return new ImmutableInteractionData(this, 
/*      */         
/*  850 */         id(), 
/*  851 */         applicationId(), this.type, 
/*      */         
/*  853 */         data(), 
/*  854 */         guildId(), 
/*  855 */         channel(), 
/*  856 */         channelId(), 
/*  857 */         member(), 
/*  858 */         user(), this.token, this.version, 
/*      */ 
/*      */         
/*  861 */         message(), 
/*  862 */         locale(), newValue, 
/*      */         
/*  864 */         appPermissions());
/*      */   }
/*      */   
/*      */   public ImmutableInteractionData withAppPermissions(Possible<String> value) {
/*  868 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  869 */     return new ImmutableInteractionData(this, 
/*      */         
/*  871 */         id(), 
/*  872 */         applicationId(), this.type, 
/*      */         
/*  874 */         data(), 
/*  875 */         guildId(), 
/*  876 */         channel(), 
/*  877 */         channelId(), 
/*  878 */         member(), 
/*  879 */         user(), this.token, this.version, 
/*      */ 
/*      */         
/*  882 */         message(), 
/*  883 */         locale(), 
/*  884 */         guildLocale(), newValue);
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableInteractionData withAppPermissions(String value) {
/*  889 */     Possible<String> newValue = Possible.of(value);
/*  890 */     return new ImmutableInteractionData(this, 
/*      */         
/*  892 */         id(), 
/*  893 */         applicationId(), this.type, 
/*      */         
/*  895 */         data(), 
/*  896 */         guildId(), 
/*  897 */         channel(), 
/*  898 */         channelId(), 
/*  899 */         member(), 
/*  900 */         user(), this.token, this.version, 
/*      */ 
/*      */         
/*  903 */         message(), 
/*  904 */         locale(), 
/*  905 */         guildLocale(), newValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object another) {
/*  915 */     if (this == another) return true; 
/*  916 */     return (another instanceof ImmutableInteractionData && 
/*  917 */       equalTo(0, (ImmutableInteractionData)another));
/*      */   }
/*      */   
/*      */   private boolean equalTo(int synthetic, ImmutableInteractionData another) {
/*  921 */     return (Objects.equals(Long.valueOf(this.id_value), Long.valueOf(another.id_value)) && 
/*  922 */       Objects.equals(Long.valueOf(this.applicationId_value), Long.valueOf(another.applicationId_value)) && this.type == another.type && 
/*      */       
/*  924 */       data().equals(another.data()) && 
/*  925 */       guildId().equals(another.guildId()) && 
/*  926 */       channel().equals(another.channel()) && 
/*  927 */       channelId().equals(another.channelId()) && 
/*  928 */       member().equals(another.member()) && 
/*  929 */       user().equals(another.user()) && this.token
/*  930 */       .equals(another.token) && this.version == another.version && 
/*      */       
/*  932 */       message().equals(another.message()) && 
/*  933 */       locale().equals(another.locale()) && 
/*  934 */       guildLocale().equals(another.guildLocale()) && 
/*  935 */       appPermissions().equals(another.appPermissions()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/*  944 */     int h = 5381;
/*  945 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.id_value));
/*  946 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.applicationId_value));
/*  947 */     h += (h << 5) + this.type;
/*  948 */     h += (h << 5) + data().hashCode();
/*  949 */     h += (h << 5) + guildId().hashCode();
/*  950 */     h += (h << 5) + channel().hashCode();
/*  951 */     h += (h << 5) + channelId().hashCode();
/*  952 */     h += (h << 5) + member().hashCode();
/*  953 */     h += (h << 5) + user().hashCode();
/*  954 */     h += (h << 5) + this.token.hashCode();
/*  955 */     h += (h << 5) + this.version;
/*  956 */     h += (h << 5) + message().hashCode();
/*  957 */     h += (h << 5) + locale().hashCode();
/*  958 */     h += (h << 5) + guildLocale().hashCode();
/*  959 */     h += (h << 5) + appPermissions().hashCode();
/*  960 */     return h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*  969 */     return "InteractionData{id=" + 
/*  970 */       Objects.toString(Long.valueOf(this.id_value)) + ", applicationId=" + 
/*  971 */       Objects.toString(Long.valueOf(this.applicationId_value)) + ", type=" + this.type + ", data=" + 
/*      */       
/*  973 */       data().toString() + ", guildId=" + 
/*  974 */       guildId().toString() + ", channel=" + 
/*  975 */       channel().toString() + ", channelId=" + 
/*  976 */       channelId().toString() + ", member=" + 
/*  977 */       member().toString() + ", user=" + 
/*  978 */       user().toString() + ", token=" + this.token + ", version=" + this.version + ", message=" + 
/*      */ 
/*      */       
/*  981 */       message().toString() + ", locale=" + 
/*  982 */       locale().toString() + ", guildLocale=" + 
/*  983 */       guildLocale().toString() + ", appPermissions=" + 
/*  984 */       appPermissions().toString() + "}";
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonDeserialize
/*      */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*      */   @Generated(from = "InteractionData", generator = "Immutables")
/*      */   static final class Json
/*      */     implements InteractionData
/*      */   {
/*      */     Id id;
/*      */     
/*      */     Id applicationId;
/*      */     
/*      */     int type;
/*      */     
/*      */     boolean typeIsSet;
/* 1002 */     Possible<ApplicationCommandInteractionData> data = Possible.absent();
/*      */ 
/*      */     
/* 1005 */     Possible<Id> guildId = Possible.absent();
/*      */ 
/*      */     
/* 1008 */     Possible<ChannelData> channel = Possible.absent();
/*      */ 
/*      */     
/* 1011 */     Possible<Id> channelId = Possible.absent();
/*      */ 
/*      */     
/* 1014 */     Possible<MemberData> member = Possible.absent();
/*      */ 
/*      */     
/* 1017 */     Possible<UserData> user = Possible.absent();
/*      */     
/*      */     String token;
/*      */     
/*      */     int version;
/*      */     boolean versionIsSet;
/* 1023 */     Possible<MessageData> message = Possible.absent();
/*      */ 
/*      */     
/* 1026 */     Possible<String> locale = Possible.absent();
/*      */ 
/*      */     
/* 1029 */     Possible<String> guildLocale = Possible.absent();
/*      */ 
/*      */     
/* 1032 */     Possible<String> appPermissions = Possible.absent();
/*      */     
/*      */     @JsonProperty("id")
/*      */     public void setId(Id id) {
/* 1036 */       this.id = id;
/*      */     }
/*      */     @JsonProperty("application_id")
/*      */     public void setApplicationId(Id applicationId) {
/* 1040 */       this.applicationId = applicationId;
/*      */     }
/*      */     @JsonProperty("type")
/*      */     public void setType(int type) {
/* 1044 */       this.type = type;
/* 1045 */       this.typeIsSet = true;
/*      */     }
/*      */     @JsonProperty("data")
/*      */     public void setData(Possible<ApplicationCommandInteractionData> data) {
/* 1049 */       this.data = data;
/*      */     }
/*      */     @JsonProperty("guild_id")
/*      */     public void setGuildId(Possible<Id> guildId) {
/* 1053 */       this.guildId = guildId;
/*      */     }
/*      */     @JsonProperty("channel")
/*      */     public void setChannel(Possible<ChannelData> channel) {
/* 1057 */       this.channel = channel;
/*      */     }
/*      */     @JsonProperty("channel_id")
/*      */     public void setChannelId(Possible<Id> channelId) {
/* 1061 */       this.channelId = channelId;
/*      */     }
/*      */     @JsonProperty("member")
/*      */     public void setMember(Possible<MemberData> member) {
/* 1065 */       this.member = member;
/*      */     }
/*      */     @JsonProperty("user")
/*      */     public void setUser(Possible<UserData> user) {
/* 1069 */       this.user = user;
/*      */     }
/*      */     @JsonProperty("token")
/*      */     public void setToken(String token) {
/* 1073 */       this.token = token;
/*      */     }
/*      */     @JsonProperty("version")
/*      */     public void setVersion(int version) {
/* 1077 */       this.version = version;
/* 1078 */       this.versionIsSet = true;
/*      */     }
/*      */     @JsonProperty("message")
/*      */     public void setMessage(Possible<MessageData> message) {
/* 1082 */       this.message = message;
/*      */     }
/*      */     @JsonProperty("locale")
/*      */     public void setLocale(Possible<String> locale) {
/* 1086 */       this.locale = locale;
/*      */     }
/*      */     @JsonProperty("guild_locale")
/*      */     public void setGuildLocale(Possible<String> guildLocale) {
/* 1090 */       this.guildLocale = guildLocale;
/*      */     }
/*      */     @JsonProperty("app_permissions")
/*      */     public void setAppPermissions(Possible<String> appPermissions) {
/* 1094 */       this.appPermissions = appPermissions;
/*      */     }
/*      */     public Id id() {
/* 1097 */       throw new UnsupportedOperationException();
/*      */     } public Id applicationId() {
/* 1099 */       throw new UnsupportedOperationException();
/*      */     } public int type() {
/* 1101 */       throw new UnsupportedOperationException();
/*      */     } public Possible<ApplicationCommandInteractionData> data() {
/* 1103 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Id> guildId() {
/* 1105 */       throw new UnsupportedOperationException();
/*      */     } public Possible<ChannelData> channel() {
/* 1107 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Id> channelId() {
/* 1109 */       throw new UnsupportedOperationException();
/*      */     } public Possible<MemberData> member() {
/* 1111 */       throw new UnsupportedOperationException();
/*      */     } public Possible<UserData> user() {
/* 1113 */       throw new UnsupportedOperationException();
/*      */     } public String token() {
/* 1115 */       throw new UnsupportedOperationException();
/*      */     } public int version() {
/* 1117 */       throw new UnsupportedOperationException();
/*      */     } public Possible<MessageData> message() {
/* 1119 */       throw new UnsupportedOperationException();
/*      */     } public Possible<String> locale() {
/* 1121 */       throw new UnsupportedOperationException();
/*      */     } public Possible<String> guildLocale() {
/* 1123 */       throw new UnsupportedOperationException();
/*      */     } public Possible<String> appPermissions() {
/* 1125 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*      */   static ImmutableInteractionData fromJson(Json json) {
/* 1136 */     Builder builder = builder();
/* 1137 */     if (json.id != null) {
/* 1138 */       builder.id(json.id);
/*      */     }
/* 1140 */     if (json.applicationId != null) {
/* 1141 */       builder.applicationId(json.applicationId);
/*      */     }
/* 1143 */     if (json.typeIsSet) {
/* 1144 */       builder.type(json.type);
/*      */     }
/* 1146 */     if (json.data != null) {
/* 1147 */       builder.data(json.data);
/*      */     }
/* 1149 */     if (json.guildId != null) {
/* 1150 */       builder.guildId(json.guildId);
/*      */     }
/* 1152 */     if (json.channel != null) {
/* 1153 */       builder.channel(json.channel);
/*      */     }
/* 1155 */     if (json.channelId != null) {
/* 1156 */       builder.channelId(json.channelId);
/*      */     }
/* 1158 */     if (json.member != null) {
/* 1159 */       builder.member(json.member);
/*      */     }
/* 1161 */     if (json.user != null) {
/* 1162 */       builder.user(json.user);
/*      */     }
/* 1164 */     if (json.token != null) {
/* 1165 */       builder.token(json.token);
/*      */     }
/* 1167 */     if (json.versionIsSet) {
/* 1168 */       builder.version(json.version);
/*      */     }
/* 1170 */     if (json.message != null) {
/* 1171 */       builder.message(json.message);
/*      */     }
/* 1173 */     if (json.locale != null) {
/* 1174 */       builder.locale(json.locale);
/*      */     }
/* 1176 */     if (json.guildLocale != null) {
/* 1177 */       builder.guildLocale(json.guildLocale);
/*      */     }
/* 1179 */     if (json.appPermissions != null) {
/* 1180 */       builder.appPermissions(json.appPermissions);
/*      */     }
/* 1182 */     return builder.build();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableInteractionData of(Id id, Id applicationId, int type, Possible<ApplicationCommandInteractionData> data, Possible<Id> guildId, Possible<ChannelData> channel, Possible<Id> channelId, Possible<MemberData> member, Possible<UserData> user, String token, int version, Possible<MessageData> message, Possible<String> locale, Possible<String> guildLocale, Possible<String> appPermissions) {
/* 1205 */     return new ImmutableInteractionData(id, applicationId, type, data, guildId, channel, channelId, member, user, token, version, message, locale, guildLocale, appPermissions);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableInteractionData copyOf(InteractionData instance) {
/* 1216 */     if (instance instanceof ImmutableInteractionData) {
/* 1217 */       return (ImmutableInteractionData)instance;
/*      */     }
/* 1219 */     return builder()
/* 1220 */       .from(instance)
/* 1221 */       .build();
/*      */   }
/*      */   
/*      */   public boolean isDataPresent() {
/* 1225 */     return !this.data_absent;
/*      */   }
/*      */   
/*      */   public ApplicationCommandInteractionData dataOrElse(ApplicationCommandInteractionData defaultValue) {
/* 1229 */     return !this.data_absent ? this.data_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isGuildIdPresent() {
/* 1233 */     return !this.guildId_absent;
/*      */   }
/*      */   
/*      */   public long guildIdOrElse(long defaultValue) {
/* 1237 */     return !this.guildId_absent ? this.guildId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isChannelPresent() {
/* 1241 */     return !this.channel_absent;
/*      */   }
/*      */   
/*      */   public ChannelData channelOrElse(ChannelData defaultValue) {
/* 1245 */     return !this.channel_absent ? this.channel_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isChannelIdPresent() {
/* 1249 */     return !this.channelId_absent;
/*      */   }
/*      */   
/*      */   public long channelIdOrElse(long defaultValue) {
/* 1253 */     return !this.channelId_absent ? this.channelId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isMemberPresent() {
/* 1257 */     return !this.member_absent;
/*      */   }
/*      */   
/*      */   public MemberData memberOrElse(MemberData defaultValue) {
/* 1261 */     return !this.member_absent ? this.member_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isUserPresent() {
/* 1265 */     return !this.user_absent;
/*      */   }
/*      */   
/*      */   public UserData userOrElse(UserData defaultValue) {
/* 1269 */     return !this.user_absent ? this.user_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isMessagePresent() {
/* 1273 */     return !this.message_absent;
/*      */   }
/*      */   
/*      */   public MessageData messageOrElse(MessageData defaultValue) {
/* 1277 */     return !this.message_absent ? this.message_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isLocalePresent() {
/* 1281 */     return !this.locale_absent;
/*      */   }
/*      */   
/*      */   public String localeOrElse(String defaultValue) {
/* 1285 */     return !this.locale_absent ? this.locale_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isGuildLocalePresent() {
/* 1289 */     return !this.guildLocale_absent;
/*      */   }
/*      */   
/*      */   public String guildLocaleOrElse(String defaultValue) {
/* 1293 */     return !this.guildLocale_absent ? this.guildLocale_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isAppPermissionsPresent() {
/* 1297 */     return !this.appPermissions_absent;
/*      */   }
/*      */   
/*      */   public String appPermissionsOrElse(String defaultValue) {
/* 1301 */     return !this.appPermissions_absent ? this.appPermissions_value : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Builder builder() {
/* 1328 */     return new Builder();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Generated(from = "InteractionData", generator = "Immutables")
/*      */   public static final class Builder
/*      */   {
/*      */     private static final long INIT_BIT_TYPE = 1L;
/*      */ 
/*      */     
/*      */     private static final long INIT_BIT_TOKEN = 2L;
/*      */     
/*      */     private static final long INIT_BIT_VERSION = 4L;
/*      */     
/* 1343 */     private long initBits = 7L;
/*      */     
/* 1345 */     private Id id_id = null;
/* 1346 */     private Id applicationId_id = null;
/* 1347 */     private Possible<ApplicationCommandInteractionData> data_possible = Possible.absent();
/* 1348 */     private Possible<Id> guildId_possible = Possible.absent();
/* 1349 */     private Possible<ChannelData> channel_possible = Possible.absent();
/* 1350 */     private Possible<Id> channelId_possible = Possible.absent();
/* 1351 */     private Possible<MemberData> member_possible = Possible.absent();
/* 1352 */     private Possible<UserData> user_possible = Possible.absent();
/* 1353 */     private Possible<MessageData> message_possible = Possible.absent();
/* 1354 */     private Possible<String> locale_possible = Possible.absent();
/* 1355 */     private Possible<String> guildLocale_possible = Possible.absent();
/* 1356 */     private Possible<String> appPermissions_possible = Possible.absent();
/*      */ 
/*      */ 
/*      */     
/*      */     private int type;
/*      */ 
/*      */ 
/*      */     
/*      */     private String token;
/*      */ 
/*      */     
/*      */     private int version;
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(InteractionData instance) {
/* 1372 */       Objects.requireNonNull(instance, "instance");
/* 1373 */       id(instance.id());
/* 1374 */       applicationId(instance.applicationId());
/* 1375 */       type(instance.type());
/* 1376 */       data(instance.data());
/* 1377 */       guildId(instance.guildId());
/* 1378 */       channel(instance.channel());
/* 1379 */       channelId(instance.channelId());
/* 1380 */       member(instance.member());
/* 1381 */       user(instance.user());
/* 1382 */       token(instance.token());
/* 1383 */       version(instance.version());
/* 1384 */       message(instance.message());
/* 1385 */       locale(instance.locale());
/* 1386 */       guildLocale(instance.guildLocale());
/* 1387 */       appPermissions(instance.appPermissions());
/* 1388 */       return this;
/*      */     }
/*      */     
/*      */     public Builder id(String value) {
/* 1392 */       this.id_id = Id.of(value);
/* 1393 */       return this;
/*      */     }
/*      */     
/*      */     public Builder id(long value) {
/* 1397 */       this.id_id = Id.of(value);
/* 1398 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("id")
/*      */     public Builder id(Id value) {
/* 1403 */       this.id_id = value;
/* 1404 */       return this;
/*      */     }
/*      */     
/*      */     public Builder applicationId(String value) {
/* 1408 */       this.applicationId_id = Id.of(value);
/* 1409 */       return this;
/*      */     }
/*      */     
/*      */     public Builder applicationId(long value) {
/* 1413 */       this.applicationId_id = Id.of(value);
/* 1414 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("application_id")
/*      */     public Builder applicationId(Id value) {
/* 1419 */       this.applicationId_id = value;
/* 1420 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("type")
/*      */     public final Builder type(int type) {
/* 1430 */       this.type = type;
/* 1431 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 1432 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("data")
/*      */     public Builder data(Possible<ApplicationCommandInteractionData> value) {
/* 1437 */       this.data_possible = value;
/* 1438 */       return this;
/*      */     }
/*      */     
/*      */     public Builder data(ApplicationCommandInteractionData value) {
/* 1442 */       this.data_possible = Possible.of(value);
/* 1443 */       return this;
/*      */     }
/*      */     
/*      */     public Builder guildId(String value) {
/* 1447 */       this.guildId_possible = Possible.of(Id.of(value));
/* 1448 */       return this;
/*      */     }
/*      */     
/*      */     public Builder guildId(long value) {
/* 1452 */       this.guildId_possible = Possible.of(Id.of(value));
/* 1453 */       return this;
/*      */     }
/*      */     
/*      */     public Builder guildId(Id value) {
/* 1457 */       this.guildId_possible = Possible.of(value);
/* 1458 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("guild_id")
/*      */     public Builder guildId(Possible<Id> value) {
/* 1463 */       this.guildId_possible = value;
/* 1464 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("channel")
/*      */     public Builder channel(Possible<ChannelData> value) {
/* 1469 */       this.channel_possible = value;
/* 1470 */       return this;
/*      */     }
/*      */     
/*      */     public Builder channel(ChannelData value) {
/* 1474 */       this.channel_possible = Possible.of(value);
/* 1475 */       return this;
/*      */     }
/*      */     
/*      */     public Builder channelId(String value) {
/* 1479 */       this.channelId_possible = Possible.of(Id.of(value));
/* 1480 */       return this;
/*      */     }
/*      */     
/*      */     public Builder channelId(long value) {
/* 1484 */       this.channelId_possible = Possible.of(Id.of(value));
/* 1485 */       return this;
/*      */     }
/*      */     
/*      */     public Builder channelId(Id value) {
/* 1489 */       this.channelId_possible = Possible.of(value);
/* 1490 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("channel_id")
/*      */     public Builder channelId(Possible<Id> value) {
/* 1495 */       this.channelId_possible = value;
/* 1496 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("member")
/*      */     public Builder member(Possible<MemberData> value) {
/* 1501 */       this.member_possible = value;
/* 1502 */       return this;
/*      */     }
/*      */     
/*      */     public Builder member(MemberData value) {
/* 1506 */       this.member_possible = Possible.of(value);
/* 1507 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("user")
/*      */     public Builder user(Possible<UserData> value) {
/* 1512 */       this.user_possible = value;
/* 1513 */       return this;
/*      */     }
/*      */     
/*      */     public Builder user(UserData value) {
/* 1517 */       this.user_possible = Possible.of(value);
/* 1518 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("token")
/*      */     public final Builder token(String token) {
/* 1528 */       this.token = Objects.<String>requireNonNull(token, "token");
/* 1529 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 1530 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("version")
/*      */     public final Builder version(int version) {
/* 1540 */       this.version = version;
/* 1541 */       this.initBits &= 0xFFFFFFFFFFFFFFFBL;
/* 1542 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("message")
/*      */     public Builder message(Possible<MessageData> value) {
/* 1547 */       this.message_possible = value;
/* 1548 */       return this;
/*      */     }
/*      */     
/*      */     public Builder message(MessageData value) {
/* 1552 */       this.message_possible = Possible.of(value);
/* 1553 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("locale")
/*      */     public Builder locale(Possible<String> value) {
/* 1558 */       this.locale_possible = value;
/* 1559 */       return this;
/*      */     }
/*      */     
/*      */     public Builder locale(String value) {
/* 1563 */       this.locale_possible = Possible.of(value);
/* 1564 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("guild_locale")
/*      */     public Builder guildLocale(Possible<String> value) {
/* 1569 */       this.guildLocale_possible = value;
/* 1570 */       return this;
/*      */     }
/*      */     
/*      */     public Builder guildLocale(String value) {
/* 1574 */       this.guildLocale_possible = Possible.of(value);
/* 1575 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("app_permissions")
/*      */     public Builder appPermissions(Possible<String> value) {
/* 1580 */       this.appPermissions_possible = value;
/* 1581 */       return this;
/*      */     }
/*      */     
/*      */     public Builder appPermissions(String value) {
/* 1585 */       this.appPermissions_possible = Possible.of(value);
/* 1586 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ImmutableInteractionData build() {
/* 1595 */       if (this.initBits != 0L) {
/* 1596 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*      */       }
/* 1598 */       return new ImmutableInteractionData(null, 
/*      */           
/* 1600 */           id_build(), 
/* 1601 */           applicationId_build(), this.type, 
/*      */           
/* 1603 */           data_build(), 
/* 1604 */           guildId_build(), 
/* 1605 */           channel_build(), 
/* 1606 */           channelId_build(), 
/* 1607 */           member_build(), 
/* 1608 */           user_build(), this.token, this.version, 
/*      */ 
/*      */           
/* 1611 */           message_build(), 
/* 1612 */           locale_build(), 
/* 1613 */           guildLocale_build(), 
/* 1614 */           appPermissions_build());
/*      */     }
/*      */     
/*      */     private String formatRequiredAttributesMessage() {
/* 1618 */       List<String> attributes = new ArrayList<>();
/* 1619 */       if ((this.initBits & 0x1L) != 0L) attributes.add("type"); 
/* 1620 */       if ((this.initBits & 0x2L) != 0L) attributes.add("token"); 
/* 1621 */       if ((this.initBits & 0x4L) != 0L) attributes.add("version"); 
/* 1622 */       return "Cannot build InteractionData, some of required attributes are not set " + attributes;
/*      */     }
/*      */     
/*      */     private Id id_build() {
/* 1626 */       return this.id_id;
/*      */     }
/*      */     
/*      */     private Id applicationId_build() {
/* 1630 */       return this.applicationId_id;
/*      */     }
/*      */     
/*      */     private Possible<ApplicationCommandInteractionData> data_build() {
/* 1634 */       return this.data_possible;
/*      */     }
/*      */     
/*      */     private Possible<Id> guildId_build() {
/* 1638 */       return this.guildId_possible;
/*      */     }
/*      */     
/*      */     private Possible<ChannelData> channel_build() {
/* 1642 */       return this.channel_possible;
/*      */     }
/*      */     
/*      */     private Possible<Id> channelId_build() {
/* 1646 */       return this.channelId_possible;
/*      */     }
/*      */     
/*      */     private Possible<MemberData> member_build() {
/* 1650 */       return this.member_possible;
/*      */     }
/*      */     
/*      */     private Possible<UserData> user_build() {
/* 1654 */       return this.user_possible;
/*      */     }
/*      */     
/*      */     private Possible<MessageData> message_build() {
/* 1658 */       return this.message_possible;
/*      */     }
/*      */     
/*      */     private Possible<String> locale_build() {
/* 1662 */       return this.locale_possible;
/*      */     }
/*      */     
/*      */     private Possible<String> guildLocale_build() {
/* 1666 */       return this.guildLocale_possible;
/*      */     }
/*      */     
/*      */     private Possible<String> appPermissions_build() {
/* 1670 */       return this.appPermissions_possible;
/*      */     }
/*      */     
/*      */     private Builder() {}
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableInteractionData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */