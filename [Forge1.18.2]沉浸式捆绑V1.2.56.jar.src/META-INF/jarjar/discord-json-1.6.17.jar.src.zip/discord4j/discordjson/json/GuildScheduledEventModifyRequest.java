/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.Id;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import java.time.Instant;
/*    */ import java.util.Optional;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ @JsonSerialize(as = ImmutableGuildScheduledEventModifyRequest.class)
/*    */ @JsonDeserialize(as = ImmutableGuildScheduledEventModifyRequest.class)
/*    */ @Immutable
/*    */ public interface GuildScheduledEventModifyRequest
/*    */ {
/*    */   static ImmutableGuildScheduledEventModifyRequest.Builder builder() {
/* 19 */     return ImmutableGuildScheduledEventModifyRequest.builder();
/*    */   }
/*    */   
/*    */   @JsonProperty("channel_id")
/*    */   Possible<Optional<Id>> channelId();
/*    */   
/*    */   @JsonProperty("entity_metadata")
/*    */   Possible<GuildScheduledEventEntityMetadataData> entityMetadata();
/*    */   
/*    */   Possible<String> name();
/*    */   
/*    */   @JsonProperty("privacy_level")
/*    */   Possible<Integer> privacyLevel();
/*    */   
/*    */   @JsonProperty("scheduled_start_time")
/*    */   Possible<Instant> scheduledStartTime();
/*    */   
/*    */   @JsonProperty("scheduled_end_time")
/*    */   Possible<Instant> scheduledEndTime();
/*    */   
/*    */   Possible<String> description();
/*    */   
/*    */   @JsonProperty("entity_type")
/*    */   Possible<Integer> entityType();
/*    */   
/*    */   Possible<Integer> status();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\GuildScheduledEventModifyRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */