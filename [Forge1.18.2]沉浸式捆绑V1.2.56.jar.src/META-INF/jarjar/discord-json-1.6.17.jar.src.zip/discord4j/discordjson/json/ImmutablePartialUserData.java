/*      */ package discord4j.discordjson.json;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*      */ import com.fasterxml.jackson.annotation.JsonCreator;
/*      */ import com.fasterxml.jackson.annotation.JsonProperty;
/*      */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*      */ import discord4j.discordjson.Id;
/*      */ import discord4j.discordjson.possible.Possible;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import java.util.Optional;
/*      */ import org.immutables.value.Generated;
/*      */ import reactor.util.annotation.Nullable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Generated(from = "PartialUserData", generator = "Immutables")
/*      */ public final class ImmutablePartialUserData
/*      */   implements PartialUserData
/*      */ {
/*      */   private final long id_value;
/*      */   private final String globalName_value;
/*      */   private final boolean globalName_absent;
/*      */   private final String username_value;
/*      */   private final boolean username_absent;
/*      */   private final String discriminator_value;
/*      */   private final boolean discriminator_absent;
/*      */   private final String avatar_value;
/*      */   private final boolean avatar_absent;
/*      */   private final String banner_value;
/*      */   private final boolean banner_absent;
/*      */   private final Integer accentColor_value;
/*      */   private final boolean accentColor_absent;
/*      */   private final Boolean bot_value;
/*      */   private final boolean bot_absent;
/*      */   private final Boolean system_value;
/*      */   private final boolean system_absent;
/*      */   private final Boolean mfaEnabled_value;
/*      */   private final boolean mfaEnabled_absent;
/*      */   private final String locale_value;
/*      */   private final boolean locale_absent;
/*      */   private final Boolean verified_value;
/*      */   private final boolean verified_absent;
/*      */   private final String email_value;
/*      */   private final boolean email_absent;
/*      */   private final Long flags_value;
/*      */   private final boolean flags_absent;
/*      */   private final Integer premiumType_value;
/*      */   private final boolean premiumType_absent;
/*      */   private final Long publicFlags_value;
/*      */   private final boolean publicFlags_absent;
/*      */   private static final byte STAGE_INITIALIZING = -1;
/*      */   private static final byte STAGE_UNINITIALIZED = 0;
/*      */   private static final byte STAGE_INITIALIZED = 1;
/*      */   
/*      */   private ImmutablePartialUserData(Id id, Possible<Optional<String>> globalName, Possible<String> username, Possible<String> discriminator, Possible<Optional<String>> avatar, Possible<Optional<String>> banner, Possible<Optional<Integer>> accentColor, Possible<Boolean> bot, Possible<Boolean> system, Possible<Boolean> mfaEnabled, Possible<String> locale, Possible<Boolean> verified, Possible<String> email, Possible<Long> flags, Possible<Integer> premiumType, Possible<Long> publicFlags) {
/*   77 */     Id id$impl = id;
/*   78 */     Possible<Optional<String>> globalName$impl = globalName;
/*   79 */     Possible<String> username$impl = username;
/*   80 */     Possible<String> discriminator$impl = discriminator;
/*   81 */     Possible<Optional<String>> avatar$impl = avatar;
/*   82 */     Possible<Optional<String>> banner$impl = banner;
/*   83 */     Possible<Optional<Integer>> accentColor$impl = accentColor;
/*   84 */     Possible<Boolean> bot$impl = bot;
/*   85 */     Possible<Boolean> system$impl = system;
/*   86 */     Possible<Boolean> mfaEnabled$impl = mfaEnabled;
/*   87 */     Possible<String> locale$impl = locale;
/*   88 */     Possible<Boolean> verified$impl = verified;
/*   89 */     Possible<String> email$impl = email;
/*   90 */     Possible<Long> flags$impl = flags;
/*   91 */     Possible<Integer> premiumType$impl = premiumType;
/*   92 */     Possible<Long> publicFlags$impl = publicFlags;
/*   93 */     this.id_value = id$impl.asLong();
/*   94 */     this.globalName_value = Possible.flatOpt(globalName$impl).orElse(null);
/*   95 */     this.globalName_absent = globalName$impl.isAbsent();
/*   96 */     this.username_value = username$impl.toOptional().orElse(null);
/*   97 */     this.username_absent = username$impl.isAbsent();
/*   98 */     this.discriminator_value = discriminator$impl.toOptional().orElse(null);
/*   99 */     this.discriminator_absent = discriminator$impl.isAbsent();
/*  100 */     this.avatar_value = Possible.flatOpt(avatar$impl).orElse(null);
/*  101 */     this.avatar_absent = avatar$impl.isAbsent();
/*  102 */     this.banner_value = Possible.flatOpt(banner$impl).orElse(null);
/*  103 */     this.banner_absent = banner$impl.isAbsent();
/*  104 */     this.accentColor_value = Possible.flatOpt(accentColor$impl).orElse(null);
/*  105 */     this.accentColor_absent = accentColor$impl.isAbsent();
/*  106 */     this.bot_value = bot$impl.toOptional().orElse(null);
/*  107 */     this.bot_absent = bot$impl.isAbsent();
/*  108 */     this.system_value = system$impl.toOptional().orElse(null);
/*  109 */     this.system_absent = system$impl.isAbsent();
/*  110 */     this.mfaEnabled_value = mfaEnabled$impl.toOptional().orElse(null);
/*  111 */     this.mfaEnabled_absent = mfaEnabled$impl.isAbsent();
/*  112 */     this.locale_value = locale$impl.toOptional().orElse(null);
/*  113 */     this.locale_absent = locale$impl.isAbsent();
/*  114 */     this.verified_value = verified$impl.toOptional().orElse(null);
/*  115 */     this.verified_absent = verified$impl.isAbsent();
/*  116 */     this.email_value = email$impl.toOptional().orElse(null);
/*  117 */     this.email_absent = email$impl.isAbsent();
/*  118 */     this.flags_value = flags$impl.toOptional().orElse(null);
/*  119 */     this.flags_absent = flags$impl.isAbsent();
/*  120 */     this.premiumType_value = premiumType$impl.toOptional().orElse(null);
/*  121 */     this.premiumType_absent = premiumType$impl.isAbsent();
/*  122 */     this.publicFlags_value = publicFlags$impl.toOptional().orElse(null);
/*  123 */     this.publicFlags_absent = publicFlags$impl.isAbsent();
/*  124 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ImmutablePartialUserData(ImmutablePartialUserData original, Id id, Possible<Optional<String>> globalName, Possible<String> username, Possible<String> discriminator, Possible<Optional<String>> avatar, Possible<Optional<String>> banner, Possible<Optional<Integer>> accentColor, Possible<Boolean> bot, Possible<Boolean> system, Possible<Boolean> mfaEnabled, Possible<String> locale, Possible<Boolean> verified, Possible<String> email, Possible<Long> flags, Possible<Integer> premiumType, Possible<Long> publicFlags) {
/*  145 */     Id id$impl = id;
/*  146 */     Possible<Optional<String>> globalName$impl = globalName;
/*  147 */     Possible<String> username$impl = username;
/*  148 */     Possible<String> discriminator$impl = discriminator;
/*  149 */     Possible<Optional<String>> avatar$impl = avatar;
/*  150 */     Possible<Optional<String>> banner$impl = banner;
/*  151 */     Possible<Optional<Integer>> accentColor$impl = accentColor;
/*  152 */     Possible<Boolean> bot$impl = bot;
/*  153 */     Possible<Boolean> system$impl = system;
/*  154 */     Possible<Boolean> mfaEnabled$impl = mfaEnabled;
/*  155 */     Possible<String> locale$impl = locale;
/*  156 */     Possible<Boolean> verified$impl = verified;
/*  157 */     Possible<String> email$impl = email;
/*  158 */     Possible<Long> flags$impl = flags;
/*  159 */     Possible<Integer> premiumType$impl = premiumType;
/*  160 */     Possible<Long> publicFlags$impl = publicFlags;
/*  161 */     this.id_value = id$impl.asLong();
/*  162 */     this.globalName_value = Possible.flatOpt(globalName$impl).orElse(null);
/*  163 */     this.globalName_absent = globalName$impl.isAbsent();
/*  164 */     this.username_value = username$impl.toOptional().orElse(null);
/*  165 */     this.username_absent = username$impl.isAbsent();
/*  166 */     this.discriminator_value = discriminator$impl.toOptional().orElse(null);
/*  167 */     this.discriminator_absent = discriminator$impl.isAbsent();
/*  168 */     this.avatar_value = Possible.flatOpt(avatar$impl).orElse(null);
/*  169 */     this.avatar_absent = avatar$impl.isAbsent();
/*  170 */     this.banner_value = Possible.flatOpt(banner$impl).orElse(null);
/*  171 */     this.banner_absent = banner$impl.isAbsent();
/*  172 */     this.accentColor_value = Possible.flatOpt(accentColor$impl).orElse(null);
/*  173 */     this.accentColor_absent = accentColor$impl.isAbsent();
/*  174 */     this.bot_value = bot$impl.toOptional().orElse(null);
/*  175 */     this.bot_absent = bot$impl.isAbsent();
/*  176 */     this.system_value = system$impl.toOptional().orElse(null);
/*  177 */     this.system_absent = system$impl.isAbsent();
/*  178 */     this.mfaEnabled_value = mfaEnabled$impl.toOptional().orElse(null);
/*  179 */     this.mfaEnabled_absent = mfaEnabled$impl.isAbsent();
/*  180 */     this.locale_value = locale$impl.toOptional().orElse(null);
/*  181 */     this.locale_absent = locale$impl.isAbsent();
/*  182 */     this.verified_value = verified$impl.toOptional().orElse(null);
/*  183 */     this.verified_absent = verified$impl.isAbsent();
/*  184 */     this.email_value = email$impl.toOptional().orElse(null);
/*  185 */     this.email_absent = email$impl.isAbsent();
/*  186 */     this.flags_value = flags$impl.toOptional().orElse(null);
/*  187 */     this.flags_absent = flags$impl.isAbsent();
/*  188 */     this.premiumType_value = premiumType$impl.toOptional().orElse(null);
/*  189 */     this.premiumType_absent = premiumType$impl.isAbsent();
/*  190 */     this.publicFlags_value = publicFlags$impl.toOptional().orElse(null);
/*  191 */     this.publicFlags_absent = publicFlags$impl.isAbsent();
/*  192 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  198 */   private volatile transient InitShim initShim = new InitShim();
/*      */   
/*      */   @Generated(from = "PartialUserData", generator = "Immutables")
/*      */   private final class InitShim {
/*      */     private String formatInitCycleMessage() {
/*  203 */       List<String> attributes = new ArrayList<>();
/*  204 */       return "Cannot build PartialUserData, attribute initializers form cycle " + attributes;
/*      */     }
/*      */ 
/*      */     
/*      */     private InitShim() {}
/*      */   }
/*      */ 
/*      */   
/*      */   @JsonProperty("id")
/*      */   public Id id() {
/*  214 */     return Id.of(this.id_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("global_name")
/*      */   public Possible<Optional<String>> globalName() {
/*  223 */     return this.globalName_absent ? Possible.absent() : 
/*  224 */       Possible.of(Optional.ofNullable(this.globalName_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("username")
/*      */   public Possible<String> username() {
/*  233 */     return this.username_absent ? Possible.absent() : Possible.of(this.username_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("discriminator")
/*      */   @Deprecated
/*      */   public Possible<String> discriminator() {
/*  244 */     return this.discriminator_absent ? Possible.absent() : Possible.of(this.discriminator_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("avatar")
/*      */   public Possible<Optional<String>> avatar() {
/*  253 */     return this.avatar_absent ? Possible.absent() : 
/*  254 */       Possible.of(Optional.ofNullable(this.avatar_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("banner")
/*      */   public Possible<Optional<String>> banner() {
/*  263 */     return this.banner_absent ? Possible.absent() : 
/*  264 */       Possible.of(Optional.ofNullable(this.banner_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("accent_color")
/*      */   public Possible<Optional<Integer>> accentColor() {
/*  273 */     return this.accentColor_absent ? Possible.absent() : 
/*  274 */       Possible.of(Optional.ofNullable(this.accentColor_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("bot")
/*      */   public Possible<Boolean> bot() {
/*  283 */     return this.bot_absent ? Possible.absent() : Possible.of(this.bot_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("system")
/*      */   public Possible<Boolean> system() {
/*  292 */     return this.system_absent ? Possible.absent() : Possible.of(this.system_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("mfa_enabled")
/*      */   public Possible<Boolean> mfaEnabled() {
/*  301 */     return this.mfaEnabled_absent ? Possible.absent() : Possible.of(this.mfaEnabled_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("locale")
/*      */   public Possible<String> locale() {
/*  310 */     return this.locale_absent ? Possible.absent() : Possible.of(this.locale_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("verified")
/*      */   public Possible<Boolean> verified() {
/*  319 */     return this.verified_absent ? Possible.absent() : Possible.of(this.verified_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("email")
/*      */   public Possible<String> email() {
/*  328 */     return this.email_absent ? Possible.absent() : Possible.of(this.email_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("flags")
/*      */   public Possible<Long> flags() {
/*  337 */     return this.flags_absent ? Possible.absent() : Possible.of(this.flags_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("premium_type")
/*      */   public Possible<Integer> premiumType() {
/*  346 */     return this.premiumType_absent ? Possible.absent() : Possible.of(this.premiumType_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("public_flags")
/*      */   public Possible<Long> publicFlags() {
/*  355 */     return this.publicFlags_absent ? Possible.absent() : Possible.of(this.publicFlags_value);
/*      */   }
/*      */   
/*      */   public ImmutablePartialUserData withId(long value) {
/*  359 */     Id newValue = Id.of(value);
/*  360 */     return new ImmutablePartialUserData(this, newValue, 
/*      */ 
/*      */         
/*  363 */         globalName(), 
/*  364 */         username(), 
/*  365 */         discriminator(), 
/*  366 */         avatar(), 
/*  367 */         banner(), 
/*  368 */         accentColor(), 
/*  369 */         bot(), 
/*  370 */         system(), 
/*  371 */         mfaEnabled(), 
/*  372 */         locale(), 
/*  373 */         verified(), 
/*  374 */         email(), 
/*  375 */         flags(), 
/*  376 */         premiumType(), 
/*  377 */         publicFlags());
/*      */   }
/*      */   
/*      */   public ImmutablePartialUserData withId(String value) {
/*  381 */     Id newValue = Id.of(value);
/*  382 */     return new ImmutablePartialUserData(this, newValue, 
/*      */ 
/*      */         
/*  385 */         globalName(), 
/*  386 */         username(), 
/*  387 */         discriminator(), 
/*  388 */         avatar(), 
/*  389 */         banner(), 
/*  390 */         accentColor(), 
/*  391 */         bot(), 
/*  392 */         system(), 
/*  393 */         mfaEnabled(), 
/*  394 */         locale(), 
/*  395 */         verified(), 
/*  396 */         email(), 
/*  397 */         flags(), 
/*  398 */         premiumType(), 
/*  399 */         publicFlags());
/*      */   }
/*      */   
/*      */   public ImmutablePartialUserData withGlobalName(Possible<Optional<String>> value) {
/*  403 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/*  404 */     return new ImmutablePartialUserData(this, 
/*      */         
/*  406 */         id(), newValue, 
/*      */         
/*  408 */         username(), 
/*  409 */         discriminator(), 
/*  410 */         avatar(), 
/*  411 */         banner(), 
/*  412 */         accentColor(), 
/*  413 */         bot(), 
/*  414 */         system(), 
/*  415 */         mfaEnabled(), 
/*  416 */         locale(), 
/*  417 */         verified(), 
/*  418 */         email(), 
/*  419 */         flags(), 
/*  420 */         premiumType(), 
/*  421 */         publicFlags());
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public ImmutablePartialUserData withGlobalName(@Nullable String value) {
/*  426 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  427 */     return new ImmutablePartialUserData(this, 
/*      */         
/*  429 */         id(), newValue, 
/*      */         
/*  431 */         username(), 
/*  432 */         discriminator(), 
/*  433 */         avatar(), 
/*  434 */         banner(), 
/*  435 */         accentColor(), 
/*  436 */         bot(), 
/*  437 */         system(), 
/*  438 */         mfaEnabled(), 
/*  439 */         locale(), 
/*  440 */         verified(), 
/*  441 */         email(), 
/*  442 */         flags(), 
/*  443 */         premiumType(), 
/*  444 */         publicFlags());
/*      */   }
/*      */   
/*      */   public ImmutablePartialUserData withGlobalNameOrNull(@Nullable String value) {
/*  448 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  449 */     return new ImmutablePartialUserData(this, 
/*      */         
/*  451 */         id(), newValue, 
/*      */         
/*  453 */         username(), 
/*  454 */         discriminator(), 
/*  455 */         avatar(), 
/*  456 */         banner(), 
/*  457 */         accentColor(), 
/*  458 */         bot(), 
/*  459 */         system(), 
/*  460 */         mfaEnabled(), 
/*  461 */         locale(), 
/*  462 */         verified(), 
/*  463 */         email(), 
/*  464 */         flags(), 
/*  465 */         premiumType(), 
/*  466 */         publicFlags());
/*      */   }
/*      */   
/*      */   public ImmutablePartialUserData withUsername(Possible<String> value) {
/*  470 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  471 */     return new ImmutablePartialUserData(this, 
/*      */         
/*  473 */         id(), 
/*  474 */         globalName(), newValue, 
/*      */         
/*  476 */         discriminator(), 
/*  477 */         avatar(), 
/*  478 */         banner(), 
/*  479 */         accentColor(), 
/*  480 */         bot(), 
/*  481 */         system(), 
/*  482 */         mfaEnabled(), 
/*  483 */         locale(), 
/*  484 */         verified(), 
/*  485 */         email(), 
/*  486 */         flags(), 
/*  487 */         premiumType(), 
/*  488 */         publicFlags());
/*      */   }
/*      */   
/*      */   public ImmutablePartialUserData withUsername(String value) {
/*  492 */     Possible<String> newValue = Possible.of(value);
/*  493 */     return new ImmutablePartialUserData(this, 
/*      */         
/*  495 */         id(), 
/*  496 */         globalName(), newValue, 
/*      */         
/*  498 */         discriminator(), 
/*  499 */         avatar(), 
/*  500 */         banner(), 
/*  501 */         accentColor(), 
/*  502 */         bot(), 
/*  503 */         system(), 
/*  504 */         mfaEnabled(), 
/*  505 */         locale(), 
/*  506 */         verified(), 
/*  507 */         email(), 
/*  508 */         flags(), 
/*  509 */         premiumType(), 
/*  510 */         publicFlags());
/*      */   }
/*      */   
/*      */   public ImmutablePartialUserData withDiscriminator(Possible<String> value) {
/*  514 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  515 */     return new ImmutablePartialUserData(this, 
/*      */         
/*  517 */         id(), 
/*  518 */         globalName(), 
/*  519 */         username(), newValue, 
/*      */         
/*  521 */         avatar(), 
/*  522 */         banner(), 
/*  523 */         accentColor(), 
/*  524 */         bot(), 
/*  525 */         system(), 
/*  526 */         mfaEnabled(), 
/*  527 */         locale(), 
/*  528 */         verified(), 
/*  529 */         email(), 
/*  530 */         flags(), 
/*  531 */         premiumType(), 
/*  532 */         publicFlags());
/*      */   }
/*      */   
/*      */   public ImmutablePartialUserData withDiscriminator(String value) {
/*  536 */     Possible<String> newValue = Possible.of(value);
/*  537 */     return new ImmutablePartialUserData(this, 
/*      */         
/*  539 */         id(), 
/*  540 */         globalName(), 
/*  541 */         username(), newValue, 
/*      */         
/*  543 */         avatar(), 
/*  544 */         banner(), 
/*  545 */         accentColor(), 
/*  546 */         bot(), 
/*  547 */         system(), 
/*  548 */         mfaEnabled(), 
/*  549 */         locale(), 
/*  550 */         verified(), 
/*  551 */         email(), 
/*  552 */         flags(), 
/*  553 */         premiumType(), 
/*  554 */         publicFlags());
/*      */   }
/*      */   
/*      */   public ImmutablePartialUserData withAvatar(Possible<Optional<String>> value) {
/*  558 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/*  559 */     return new ImmutablePartialUserData(this, 
/*      */         
/*  561 */         id(), 
/*  562 */         globalName(), 
/*  563 */         username(), 
/*  564 */         discriminator(), newValue, 
/*      */         
/*  566 */         banner(), 
/*  567 */         accentColor(), 
/*  568 */         bot(), 
/*  569 */         system(), 
/*  570 */         mfaEnabled(), 
/*  571 */         locale(), 
/*  572 */         verified(), 
/*  573 */         email(), 
/*  574 */         flags(), 
/*  575 */         premiumType(), 
/*  576 */         publicFlags());
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public ImmutablePartialUserData withAvatar(@Nullable String value) {
/*  581 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  582 */     return new ImmutablePartialUserData(this, 
/*      */         
/*  584 */         id(), 
/*  585 */         globalName(), 
/*  586 */         username(), 
/*  587 */         discriminator(), newValue, 
/*      */         
/*  589 */         banner(), 
/*  590 */         accentColor(), 
/*  591 */         bot(), 
/*  592 */         system(), 
/*  593 */         mfaEnabled(), 
/*  594 */         locale(), 
/*  595 */         verified(), 
/*  596 */         email(), 
/*  597 */         flags(), 
/*  598 */         premiumType(), 
/*  599 */         publicFlags());
/*      */   }
/*      */   
/*      */   public ImmutablePartialUserData withAvatarOrNull(@Nullable String value) {
/*  603 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  604 */     return new ImmutablePartialUserData(this, 
/*      */         
/*  606 */         id(), 
/*  607 */         globalName(), 
/*  608 */         username(), 
/*  609 */         discriminator(), newValue, 
/*      */         
/*  611 */         banner(), 
/*  612 */         accentColor(), 
/*  613 */         bot(), 
/*  614 */         system(), 
/*  615 */         mfaEnabled(), 
/*  616 */         locale(), 
/*  617 */         verified(), 
/*  618 */         email(), 
/*  619 */         flags(), 
/*  620 */         premiumType(), 
/*  621 */         publicFlags());
/*      */   }
/*      */   
/*      */   public ImmutablePartialUserData withBanner(Possible<Optional<String>> value) {
/*  625 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/*  626 */     return new ImmutablePartialUserData(this, 
/*      */         
/*  628 */         id(), 
/*  629 */         globalName(), 
/*  630 */         username(), 
/*  631 */         discriminator(), 
/*  632 */         avatar(), newValue, 
/*      */         
/*  634 */         accentColor(), 
/*  635 */         bot(), 
/*  636 */         system(), 
/*  637 */         mfaEnabled(), 
/*  638 */         locale(), 
/*  639 */         verified(), 
/*  640 */         email(), 
/*  641 */         flags(), 
/*  642 */         premiumType(), 
/*  643 */         publicFlags());
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public ImmutablePartialUserData withBanner(@Nullable String value) {
/*  648 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  649 */     return new ImmutablePartialUserData(this, 
/*      */         
/*  651 */         id(), 
/*  652 */         globalName(), 
/*  653 */         username(), 
/*  654 */         discriminator(), 
/*  655 */         avatar(), newValue, 
/*      */         
/*  657 */         accentColor(), 
/*  658 */         bot(), 
/*  659 */         system(), 
/*  660 */         mfaEnabled(), 
/*  661 */         locale(), 
/*  662 */         verified(), 
/*  663 */         email(), 
/*  664 */         flags(), 
/*  665 */         premiumType(), 
/*  666 */         publicFlags());
/*      */   }
/*      */   
/*      */   public ImmutablePartialUserData withBannerOrNull(@Nullable String value) {
/*  670 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  671 */     return new ImmutablePartialUserData(this, 
/*      */         
/*  673 */         id(), 
/*  674 */         globalName(), 
/*  675 */         username(), 
/*  676 */         discriminator(), 
/*  677 */         avatar(), newValue, 
/*      */         
/*  679 */         accentColor(), 
/*  680 */         bot(), 
/*  681 */         system(), 
/*  682 */         mfaEnabled(), 
/*  683 */         locale(), 
/*  684 */         verified(), 
/*  685 */         email(), 
/*  686 */         flags(), 
/*  687 */         premiumType(), 
/*  688 */         publicFlags());
/*      */   }
/*      */   
/*      */   public ImmutablePartialUserData withAccentColor(Possible<Optional<Integer>> value) {
/*  692 */     Possible<Optional<Integer>> newValue = Objects.<Possible<Optional<Integer>>>requireNonNull(value);
/*  693 */     return new ImmutablePartialUserData(this, 
/*      */         
/*  695 */         id(), 
/*  696 */         globalName(), 
/*  697 */         username(), 
/*  698 */         discriminator(), 
/*  699 */         avatar(), 
/*  700 */         banner(), newValue, 
/*      */         
/*  702 */         bot(), 
/*  703 */         system(), 
/*  704 */         mfaEnabled(), 
/*  705 */         locale(), 
/*  706 */         verified(), 
/*  707 */         email(), 
/*  708 */         flags(), 
/*  709 */         premiumType(), 
/*  710 */         publicFlags());
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public ImmutablePartialUserData withAccentColor(@Nullable Integer value) {
/*  715 */     Possible<Optional<Integer>> newValue = Possible.of(Optional.ofNullable(value));
/*  716 */     return new ImmutablePartialUserData(this, 
/*      */         
/*  718 */         id(), 
/*  719 */         globalName(), 
/*  720 */         username(), 
/*  721 */         discriminator(), 
/*  722 */         avatar(), 
/*  723 */         banner(), newValue, 
/*      */         
/*  725 */         bot(), 
/*  726 */         system(), 
/*  727 */         mfaEnabled(), 
/*  728 */         locale(), 
/*  729 */         verified(), 
/*  730 */         email(), 
/*  731 */         flags(), 
/*  732 */         premiumType(), 
/*  733 */         publicFlags());
/*      */   }
/*      */   
/*      */   public ImmutablePartialUserData withAccentColorOrNull(@Nullable Integer value) {
/*  737 */     Possible<Optional<Integer>> newValue = Possible.of(Optional.ofNullable(value));
/*  738 */     return new ImmutablePartialUserData(this, 
/*      */         
/*  740 */         id(), 
/*  741 */         globalName(), 
/*  742 */         username(), 
/*  743 */         discriminator(), 
/*  744 */         avatar(), 
/*  745 */         banner(), newValue, 
/*      */         
/*  747 */         bot(), 
/*  748 */         system(), 
/*  749 */         mfaEnabled(), 
/*  750 */         locale(), 
/*  751 */         verified(), 
/*  752 */         email(), 
/*  753 */         flags(), 
/*  754 */         premiumType(), 
/*  755 */         publicFlags());
/*      */   }
/*      */   
/*      */   public ImmutablePartialUserData withBot(Possible<Boolean> value) {
/*  759 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/*  760 */     return new ImmutablePartialUserData(this, 
/*      */         
/*  762 */         id(), 
/*  763 */         globalName(), 
/*  764 */         username(), 
/*  765 */         discriminator(), 
/*  766 */         avatar(), 
/*  767 */         banner(), 
/*  768 */         accentColor(), newValue, 
/*      */         
/*  770 */         system(), 
/*  771 */         mfaEnabled(), 
/*  772 */         locale(), 
/*  773 */         verified(), 
/*  774 */         email(), 
/*  775 */         flags(), 
/*  776 */         premiumType(), 
/*  777 */         publicFlags());
/*      */   }
/*      */   
/*      */   public ImmutablePartialUserData withBot(Boolean value) {
/*  781 */     Possible<Boolean> newValue = Possible.of(value);
/*  782 */     return new ImmutablePartialUserData(this, 
/*      */         
/*  784 */         id(), 
/*  785 */         globalName(), 
/*  786 */         username(), 
/*  787 */         discriminator(), 
/*  788 */         avatar(), 
/*  789 */         banner(), 
/*  790 */         accentColor(), newValue, 
/*      */         
/*  792 */         system(), 
/*  793 */         mfaEnabled(), 
/*  794 */         locale(), 
/*  795 */         verified(), 
/*  796 */         email(), 
/*  797 */         flags(), 
/*  798 */         premiumType(), 
/*  799 */         publicFlags());
/*      */   }
/*      */   
/*      */   public ImmutablePartialUserData withSystem(Possible<Boolean> value) {
/*  803 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/*  804 */     return new ImmutablePartialUserData(this, 
/*      */         
/*  806 */         id(), 
/*  807 */         globalName(), 
/*  808 */         username(), 
/*  809 */         discriminator(), 
/*  810 */         avatar(), 
/*  811 */         banner(), 
/*  812 */         accentColor(), 
/*  813 */         bot(), newValue, 
/*      */         
/*  815 */         mfaEnabled(), 
/*  816 */         locale(), 
/*  817 */         verified(), 
/*  818 */         email(), 
/*  819 */         flags(), 
/*  820 */         premiumType(), 
/*  821 */         publicFlags());
/*      */   }
/*      */   
/*      */   public ImmutablePartialUserData withSystem(Boolean value) {
/*  825 */     Possible<Boolean> newValue = Possible.of(value);
/*  826 */     return new ImmutablePartialUserData(this, 
/*      */         
/*  828 */         id(), 
/*  829 */         globalName(), 
/*  830 */         username(), 
/*  831 */         discriminator(), 
/*  832 */         avatar(), 
/*  833 */         banner(), 
/*  834 */         accentColor(), 
/*  835 */         bot(), newValue, 
/*      */         
/*  837 */         mfaEnabled(), 
/*  838 */         locale(), 
/*  839 */         verified(), 
/*  840 */         email(), 
/*  841 */         flags(), 
/*  842 */         premiumType(), 
/*  843 */         publicFlags());
/*      */   }
/*      */   
/*      */   public ImmutablePartialUserData withMfaEnabled(Possible<Boolean> value) {
/*  847 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/*  848 */     return new ImmutablePartialUserData(this, 
/*      */         
/*  850 */         id(), 
/*  851 */         globalName(), 
/*  852 */         username(), 
/*  853 */         discriminator(), 
/*  854 */         avatar(), 
/*  855 */         banner(), 
/*  856 */         accentColor(), 
/*  857 */         bot(), 
/*  858 */         system(), newValue, 
/*      */         
/*  860 */         locale(), 
/*  861 */         verified(), 
/*  862 */         email(), 
/*  863 */         flags(), 
/*  864 */         premiumType(), 
/*  865 */         publicFlags());
/*      */   }
/*      */   
/*      */   public ImmutablePartialUserData withMfaEnabled(Boolean value) {
/*  869 */     Possible<Boolean> newValue = Possible.of(value);
/*  870 */     return new ImmutablePartialUserData(this, 
/*      */         
/*  872 */         id(), 
/*  873 */         globalName(), 
/*  874 */         username(), 
/*  875 */         discriminator(), 
/*  876 */         avatar(), 
/*  877 */         banner(), 
/*  878 */         accentColor(), 
/*  879 */         bot(), 
/*  880 */         system(), newValue, 
/*      */         
/*  882 */         locale(), 
/*  883 */         verified(), 
/*  884 */         email(), 
/*  885 */         flags(), 
/*  886 */         premiumType(), 
/*  887 */         publicFlags());
/*      */   }
/*      */   
/*      */   public ImmutablePartialUserData withLocale(Possible<String> value) {
/*  891 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  892 */     return new ImmutablePartialUserData(this, 
/*      */         
/*  894 */         id(), 
/*  895 */         globalName(), 
/*  896 */         username(), 
/*  897 */         discriminator(), 
/*  898 */         avatar(), 
/*  899 */         banner(), 
/*  900 */         accentColor(), 
/*  901 */         bot(), 
/*  902 */         system(), 
/*  903 */         mfaEnabled(), newValue, 
/*      */         
/*  905 */         verified(), 
/*  906 */         email(), 
/*  907 */         flags(), 
/*  908 */         premiumType(), 
/*  909 */         publicFlags());
/*      */   }
/*      */   
/*      */   public ImmutablePartialUserData withLocale(String value) {
/*  913 */     Possible<String> newValue = Possible.of(value);
/*  914 */     return new ImmutablePartialUserData(this, 
/*      */         
/*  916 */         id(), 
/*  917 */         globalName(), 
/*  918 */         username(), 
/*  919 */         discriminator(), 
/*  920 */         avatar(), 
/*  921 */         banner(), 
/*  922 */         accentColor(), 
/*  923 */         bot(), 
/*  924 */         system(), 
/*  925 */         mfaEnabled(), newValue, 
/*      */         
/*  927 */         verified(), 
/*  928 */         email(), 
/*  929 */         flags(), 
/*  930 */         premiumType(), 
/*  931 */         publicFlags());
/*      */   }
/*      */   
/*      */   public ImmutablePartialUserData withVerified(Possible<Boolean> value) {
/*  935 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/*  936 */     return new ImmutablePartialUserData(this, 
/*      */         
/*  938 */         id(), 
/*  939 */         globalName(), 
/*  940 */         username(), 
/*  941 */         discriminator(), 
/*  942 */         avatar(), 
/*  943 */         banner(), 
/*  944 */         accentColor(), 
/*  945 */         bot(), 
/*  946 */         system(), 
/*  947 */         mfaEnabled(), 
/*  948 */         locale(), newValue, 
/*      */         
/*  950 */         email(), 
/*  951 */         flags(), 
/*  952 */         premiumType(), 
/*  953 */         publicFlags());
/*      */   }
/*      */   
/*      */   public ImmutablePartialUserData withVerified(Boolean value) {
/*  957 */     Possible<Boolean> newValue = Possible.of(value);
/*  958 */     return new ImmutablePartialUserData(this, 
/*      */         
/*  960 */         id(), 
/*  961 */         globalName(), 
/*  962 */         username(), 
/*  963 */         discriminator(), 
/*  964 */         avatar(), 
/*  965 */         banner(), 
/*  966 */         accentColor(), 
/*  967 */         bot(), 
/*  968 */         system(), 
/*  969 */         mfaEnabled(), 
/*  970 */         locale(), newValue, 
/*      */         
/*  972 */         email(), 
/*  973 */         flags(), 
/*  974 */         premiumType(), 
/*  975 */         publicFlags());
/*      */   }
/*      */   
/*      */   public ImmutablePartialUserData withEmail(Possible<String> value) {
/*  979 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  980 */     return new ImmutablePartialUserData(this, 
/*      */         
/*  982 */         id(), 
/*  983 */         globalName(), 
/*  984 */         username(), 
/*  985 */         discriminator(), 
/*  986 */         avatar(), 
/*  987 */         banner(), 
/*  988 */         accentColor(), 
/*  989 */         bot(), 
/*  990 */         system(), 
/*  991 */         mfaEnabled(), 
/*  992 */         locale(), 
/*  993 */         verified(), newValue, 
/*      */         
/*  995 */         flags(), 
/*  996 */         premiumType(), 
/*  997 */         publicFlags());
/*      */   }
/*      */   
/*      */   public ImmutablePartialUserData withEmail(String value) {
/* 1001 */     Possible<String> newValue = Possible.of(value);
/* 1002 */     return new ImmutablePartialUserData(this, 
/*      */         
/* 1004 */         id(), 
/* 1005 */         globalName(), 
/* 1006 */         username(), 
/* 1007 */         discriminator(), 
/* 1008 */         avatar(), 
/* 1009 */         banner(), 
/* 1010 */         accentColor(), 
/* 1011 */         bot(), 
/* 1012 */         system(), 
/* 1013 */         mfaEnabled(), 
/* 1014 */         locale(), 
/* 1015 */         verified(), newValue, 
/*      */         
/* 1017 */         flags(), 
/* 1018 */         premiumType(), 
/* 1019 */         publicFlags());
/*      */   }
/*      */   
/*      */   public ImmutablePartialUserData withFlags(Possible<Long> value) {
/* 1023 */     Possible<Long> newValue = Objects.<Possible<Long>>requireNonNull(value);
/* 1024 */     return new ImmutablePartialUserData(this, 
/*      */         
/* 1026 */         id(), 
/* 1027 */         globalName(), 
/* 1028 */         username(), 
/* 1029 */         discriminator(), 
/* 1030 */         avatar(), 
/* 1031 */         banner(), 
/* 1032 */         accentColor(), 
/* 1033 */         bot(), 
/* 1034 */         system(), 
/* 1035 */         mfaEnabled(), 
/* 1036 */         locale(), 
/* 1037 */         verified(), 
/* 1038 */         email(), newValue, 
/*      */         
/* 1040 */         premiumType(), 
/* 1041 */         publicFlags());
/*      */   }
/*      */   
/*      */   public ImmutablePartialUserData withFlags(Long value) {
/* 1045 */     Possible<Long> newValue = Possible.of(value);
/* 1046 */     return new ImmutablePartialUserData(this, 
/*      */         
/* 1048 */         id(), 
/* 1049 */         globalName(), 
/* 1050 */         username(), 
/* 1051 */         discriminator(), 
/* 1052 */         avatar(), 
/* 1053 */         banner(), 
/* 1054 */         accentColor(), 
/* 1055 */         bot(), 
/* 1056 */         system(), 
/* 1057 */         mfaEnabled(), 
/* 1058 */         locale(), 
/* 1059 */         verified(), 
/* 1060 */         email(), newValue, 
/*      */         
/* 1062 */         premiumType(), 
/* 1063 */         publicFlags());
/*      */   }
/*      */   
/*      */   public ImmutablePartialUserData withPremiumType(Possible<Integer> value) {
/* 1067 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 1068 */     return new ImmutablePartialUserData(this, 
/*      */         
/* 1070 */         id(), 
/* 1071 */         globalName(), 
/* 1072 */         username(), 
/* 1073 */         discriminator(), 
/* 1074 */         avatar(), 
/* 1075 */         banner(), 
/* 1076 */         accentColor(), 
/* 1077 */         bot(), 
/* 1078 */         system(), 
/* 1079 */         mfaEnabled(), 
/* 1080 */         locale(), 
/* 1081 */         verified(), 
/* 1082 */         email(), 
/* 1083 */         flags(), newValue, 
/*      */         
/* 1085 */         publicFlags());
/*      */   }
/*      */   
/*      */   public ImmutablePartialUserData withPremiumType(Integer value) {
/* 1089 */     Possible<Integer> newValue = Possible.of(value);
/* 1090 */     return new ImmutablePartialUserData(this, 
/*      */         
/* 1092 */         id(), 
/* 1093 */         globalName(), 
/* 1094 */         username(), 
/* 1095 */         discriminator(), 
/* 1096 */         avatar(), 
/* 1097 */         banner(), 
/* 1098 */         accentColor(), 
/* 1099 */         bot(), 
/* 1100 */         system(), 
/* 1101 */         mfaEnabled(), 
/* 1102 */         locale(), 
/* 1103 */         verified(), 
/* 1104 */         email(), 
/* 1105 */         flags(), newValue, 
/*      */         
/* 1107 */         publicFlags());
/*      */   }
/*      */   
/*      */   public ImmutablePartialUserData withPublicFlags(Possible<Long> value) {
/* 1111 */     Possible<Long> newValue = Objects.<Possible<Long>>requireNonNull(value);
/* 1112 */     return new ImmutablePartialUserData(this, 
/*      */         
/* 1114 */         id(), 
/* 1115 */         globalName(), 
/* 1116 */         username(), 
/* 1117 */         discriminator(), 
/* 1118 */         avatar(), 
/* 1119 */         banner(), 
/* 1120 */         accentColor(), 
/* 1121 */         bot(), 
/* 1122 */         system(), 
/* 1123 */         mfaEnabled(), 
/* 1124 */         locale(), 
/* 1125 */         verified(), 
/* 1126 */         email(), 
/* 1127 */         flags(), 
/* 1128 */         premiumType(), newValue);
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutablePartialUserData withPublicFlags(Long value) {
/* 1133 */     Possible<Long> newValue = Possible.of(value);
/* 1134 */     return new ImmutablePartialUserData(this, 
/*      */         
/* 1136 */         id(), 
/* 1137 */         globalName(), 
/* 1138 */         username(), 
/* 1139 */         discriminator(), 
/* 1140 */         avatar(), 
/* 1141 */         banner(), 
/* 1142 */         accentColor(), 
/* 1143 */         bot(), 
/* 1144 */         system(), 
/* 1145 */         mfaEnabled(), 
/* 1146 */         locale(), 
/* 1147 */         verified(), 
/* 1148 */         email(), 
/* 1149 */         flags(), 
/* 1150 */         premiumType(), newValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object another) {
/* 1160 */     if (this == another) return true; 
/* 1161 */     return (another instanceof ImmutablePartialUserData && 
/* 1162 */       equalTo(0, (ImmutablePartialUserData)another));
/*      */   }
/*      */   
/*      */   private boolean equalTo(int synthetic, ImmutablePartialUserData another) {
/* 1166 */     return (Objects.equals(Long.valueOf(this.id_value), Long.valueOf(another.id_value)) && 
/* 1167 */       globalName().equals(another.globalName()) && 
/* 1168 */       username().equals(another.username()) && 
/* 1169 */       discriminator().equals(another.discriminator()) && 
/* 1170 */       avatar().equals(another.avatar()) && 
/* 1171 */       banner().equals(another.banner()) && 
/* 1172 */       accentColor().equals(another.accentColor()) && 
/* 1173 */       bot().equals(another.bot()) && 
/* 1174 */       system().equals(another.system()) && 
/* 1175 */       mfaEnabled().equals(another.mfaEnabled()) && 
/* 1176 */       locale().equals(another.locale()) && 
/* 1177 */       verified().equals(another.verified()) && 
/* 1178 */       email().equals(another.email()) && 
/* 1179 */       flags().equals(another.flags()) && 
/* 1180 */       premiumType().equals(another.premiumType()) && 
/* 1181 */       publicFlags().equals(another.publicFlags()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/* 1190 */     int h = 5381;
/* 1191 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.id_value));
/* 1192 */     h += (h << 5) + globalName().hashCode();
/* 1193 */     h += (h << 5) + username().hashCode();
/* 1194 */     h += (h << 5) + discriminator().hashCode();
/* 1195 */     h += (h << 5) + avatar().hashCode();
/* 1196 */     h += (h << 5) + banner().hashCode();
/* 1197 */     h += (h << 5) + accentColor().hashCode();
/* 1198 */     h += (h << 5) + bot().hashCode();
/* 1199 */     h += (h << 5) + system().hashCode();
/* 1200 */     h += (h << 5) + mfaEnabled().hashCode();
/* 1201 */     h += (h << 5) + locale().hashCode();
/* 1202 */     h += (h << 5) + verified().hashCode();
/* 1203 */     h += (h << 5) + email().hashCode();
/* 1204 */     h += (h << 5) + flags().hashCode();
/* 1205 */     h += (h << 5) + premiumType().hashCode();
/* 1206 */     h += (h << 5) + publicFlags().hashCode();
/* 1207 */     return h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1216 */     return "PartialUserData{id=" + 
/* 1217 */       Objects.toString(Long.valueOf(this.id_value)) + ", globalName=" + 
/* 1218 */       globalName().toString() + ", username=" + 
/* 1219 */       username().toString() + ", discriminator=" + 
/* 1220 */       discriminator().toString() + ", avatar=" + 
/* 1221 */       avatar().toString() + ", banner=" + 
/* 1222 */       banner().toString() + ", accentColor=" + 
/* 1223 */       accentColor().toString() + ", bot=" + 
/* 1224 */       bot().toString() + ", system=" + 
/* 1225 */       system().toString() + ", mfaEnabled=" + 
/* 1226 */       mfaEnabled().toString() + ", locale=" + 
/* 1227 */       locale().toString() + ", verified=" + 
/* 1228 */       verified().toString() + ", email=" + 
/* 1229 */       email().toString() + ", flags=" + 
/* 1230 */       flags().toString() + ", premiumType=" + 
/* 1231 */       premiumType().toString() + ", publicFlags=" + 
/* 1232 */       publicFlags().toString() + "}";
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonDeserialize
/*      */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*      */   @Generated(from = "PartialUserData", generator = "Immutables")
/*      */   static final class Json
/*      */     implements PartialUserData
/*      */   {
/*      */     Id id;
/*      */ 
/*      */     
/* 1247 */     Possible<Optional<String>> globalName = Possible.absent();
/*      */ 
/*      */     
/* 1250 */     Possible<String> username = Possible.absent();
/*      */ 
/*      */     
/* 1253 */     Possible<String> discriminator = Possible.absent();
/*      */ 
/*      */     
/* 1256 */     Possible<Optional<String>> avatar = Possible.absent();
/*      */ 
/*      */     
/* 1259 */     Possible<Optional<String>> banner = Possible.absent();
/*      */ 
/*      */     
/* 1262 */     Possible<Optional<Integer>> accentColor = Possible.absent();
/*      */ 
/*      */     
/* 1265 */     Possible<Boolean> bot = Possible.absent();
/*      */ 
/*      */     
/* 1268 */     Possible<Boolean> system = Possible.absent();
/*      */ 
/*      */     
/* 1271 */     Possible<Boolean> mfaEnabled = Possible.absent();
/*      */ 
/*      */     
/* 1274 */     Possible<String> locale = Possible.absent();
/*      */ 
/*      */     
/* 1277 */     Possible<Boolean> verified = Possible.absent();
/*      */ 
/*      */     
/* 1280 */     Possible<String> email = Possible.absent();
/*      */ 
/*      */     
/* 1283 */     Possible<Long> flags = Possible.absent();
/*      */ 
/*      */     
/* 1286 */     Possible<Integer> premiumType = Possible.absent();
/*      */ 
/*      */     
/* 1289 */     Possible<Long> publicFlags = Possible.absent();
/*      */     
/*      */     @JsonProperty("id")
/*      */     public void setId(Id id) {
/* 1293 */       this.id = id;
/*      */     }
/*      */     @JsonProperty("global_name")
/*      */     public void setGlobalName(Possible<Optional<String>> globalName) {
/* 1297 */       this.globalName = globalName;
/*      */     }
/*      */     @JsonProperty("username")
/*      */     public void setUsername(Possible<String> username) {
/* 1301 */       this.username = username;
/*      */     }
/*      */     @JsonProperty("discriminator")
/*      */     public void setDiscriminator(Possible<String> discriminator) {
/* 1305 */       this.discriminator = discriminator;
/*      */     }
/*      */     @JsonProperty("avatar")
/*      */     public void setAvatar(Possible<Optional<String>> avatar) {
/* 1309 */       this.avatar = avatar;
/*      */     }
/*      */     @JsonProperty("banner")
/*      */     public void setBanner(Possible<Optional<String>> banner) {
/* 1313 */       this.banner = banner;
/*      */     }
/*      */     @JsonProperty("accent_color")
/*      */     public void setAccentColor(Possible<Optional<Integer>> accentColor) {
/* 1317 */       this.accentColor = accentColor;
/*      */     }
/*      */     @JsonProperty("bot")
/*      */     public void setBot(Possible<Boolean> bot) {
/* 1321 */       this.bot = bot;
/*      */     }
/*      */     @JsonProperty("system")
/*      */     public void setSystem(Possible<Boolean> system) {
/* 1325 */       this.system = system;
/*      */     }
/*      */     @JsonProperty("mfa_enabled")
/*      */     public void setMfaEnabled(Possible<Boolean> mfaEnabled) {
/* 1329 */       this.mfaEnabled = mfaEnabled;
/*      */     }
/*      */     @JsonProperty("locale")
/*      */     public void setLocale(Possible<String> locale) {
/* 1333 */       this.locale = locale;
/*      */     }
/*      */     @JsonProperty("verified")
/*      */     public void setVerified(Possible<Boolean> verified) {
/* 1337 */       this.verified = verified;
/*      */     }
/*      */     @JsonProperty("email")
/*      */     public void setEmail(Possible<String> email) {
/* 1341 */       this.email = email;
/*      */     }
/*      */     @JsonProperty("flags")
/*      */     public void setFlags(Possible<Long> flags) {
/* 1345 */       this.flags = flags;
/*      */     }
/*      */     @JsonProperty("premium_type")
/*      */     public void setPremiumType(Possible<Integer> premiumType) {
/* 1349 */       this.premiumType = premiumType;
/*      */     }
/*      */     @JsonProperty("public_flags")
/*      */     public void setPublicFlags(Possible<Long> publicFlags) {
/* 1353 */       this.publicFlags = publicFlags;
/*      */     }
/*      */     public Id id() {
/* 1356 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<String>> globalName() {
/* 1358 */       throw new UnsupportedOperationException();
/*      */     } public Possible<String> username() {
/* 1360 */       throw new UnsupportedOperationException();
/*      */     } public Possible<String> discriminator() {
/* 1362 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<String>> avatar() {
/* 1364 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<String>> banner() {
/* 1366 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<Integer>> accentColor() {
/* 1368 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Boolean> bot() {
/* 1370 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Boolean> system() {
/* 1372 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Boolean> mfaEnabled() {
/* 1374 */       throw new UnsupportedOperationException();
/*      */     } public Possible<String> locale() {
/* 1376 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Boolean> verified() {
/* 1378 */       throw new UnsupportedOperationException();
/*      */     } public Possible<String> email() {
/* 1380 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Long> flags() {
/* 1382 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> premiumType() {
/* 1384 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Long> publicFlags() {
/* 1386 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*      */   static ImmutablePartialUserData fromJson(Json json) {
/* 1397 */     Builder builder = builder();
/* 1398 */     if (json.id != null) {
/* 1399 */       builder.id(json.id);
/*      */     }
/* 1401 */     if (json.globalName != null) {
/* 1402 */       builder.globalName(json.globalName);
/*      */     }
/* 1404 */     if (json.username != null) {
/* 1405 */       builder.username(json.username);
/*      */     }
/* 1407 */     if (json.discriminator != null) {
/* 1408 */       builder.discriminator(json.discriminator);
/*      */     }
/* 1410 */     if (json.avatar != null) {
/* 1411 */       builder.avatar(json.avatar);
/*      */     }
/* 1413 */     if (json.banner != null) {
/* 1414 */       builder.banner(json.banner);
/*      */     }
/* 1416 */     if (json.accentColor != null) {
/* 1417 */       builder.accentColor(json.accentColor);
/*      */     }
/* 1419 */     if (json.bot != null) {
/* 1420 */       builder.bot(json.bot);
/*      */     }
/* 1422 */     if (json.system != null) {
/* 1423 */       builder.system(json.system);
/*      */     }
/* 1425 */     if (json.mfaEnabled != null) {
/* 1426 */       builder.mfaEnabled(json.mfaEnabled);
/*      */     }
/* 1428 */     if (json.locale != null) {
/* 1429 */       builder.locale(json.locale);
/*      */     }
/* 1431 */     if (json.verified != null) {
/* 1432 */       builder.verified(json.verified);
/*      */     }
/* 1434 */     if (json.email != null) {
/* 1435 */       builder.email(json.email);
/*      */     }
/* 1437 */     if (json.flags != null) {
/* 1438 */       builder.flags(json.flags);
/*      */     }
/* 1440 */     if (json.premiumType != null) {
/* 1441 */       builder.premiumType(json.premiumType);
/*      */     }
/* 1443 */     if (json.publicFlags != null) {
/* 1444 */       builder.publicFlags(json.publicFlags);
/*      */     }
/* 1446 */     return builder.build();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutablePartialUserData of(Id id, Possible<Optional<String>> globalName, Possible<String> username, Possible<String> discriminator, Possible<Optional<String>> avatar, Possible<Optional<String>> banner, Possible<Optional<Integer>> accentColor, Possible<Boolean> bot, Possible<Boolean> system, Possible<Boolean> mfaEnabled, Possible<String> locale, Possible<Boolean> verified, Possible<String> email, Possible<Long> flags, Possible<Integer> premiumType, Possible<Long> publicFlags) {
/* 1470 */     return new ImmutablePartialUserData(id, globalName, username, discriminator, avatar, banner, accentColor, bot, system, mfaEnabled, locale, verified, email, flags, premiumType, publicFlags);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutablePartialUserData copyOf(PartialUserData instance) {
/* 1481 */     if (instance instanceof ImmutablePartialUserData) {
/* 1482 */       return (ImmutablePartialUserData)instance;
/*      */     }
/* 1484 */     return builder()
/* 1485 */       .from(instance)
/* 1486 */       .build();
/*      */   }
/*      */   
/*      */   public boolean isGlobalNamePresent() {
/* 1490 */     return !this.globalName_absent;
/*      */   }
/*      */   
/*      */   public String globalNameOrElse(String defaultValue) {
/* 1494 */     return !this.globalName_absent ? this.globalName_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isUsernamePresent() {
/* 1498 */     return !this.username_absent;
/*      */   }
/*      */   
/*      */   public String usernameOrElse(String defaultValue) {
/* 1502 */     return !this.username_absent ? this.username_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isDiscriminatorPresent() {
/* 1506 */     return !this.discriminator_absent;
/*      */   }
/*      */   
/*      */   public String discriminatorOrElse(String defaultValue) {
/* 1510 */     return !this.discriminator_absent ? this.discriminator_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isAvatarPresent() {
/* 1514 */     return !this.avatar_absent;
/*      */   }
/*      */   
/*      */   public String avatarOrElse(String defaultValue) {
/* 1518 */     return !this.avatar_absent ? this.avatar_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isBannerPresent() {
/* 1522 */     return !this.banner_absent;
/*      */   }
/*      */   
/*      */   public String bannerOrElse(String defaultValue) {
/* 1526 */     return !this.banner_absent ? this.banner_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isAccentColorPresent() {
/* 1530 */     return !this.accentColor_absent;
/*      */   }
/*      */   
/*      */   public Integer accentColorOrElse(Integer defaultValue) {
/* 1534 */     return !this.accentColor_absent ? this.accentColor_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isBotPresent() {
/* 1538 */     return !this.bot_absent;
/*      */   }
/*      */   
/*      */   public Boolean botOrElse(Boolean defaultValue) {
/* 1542 */     return !this.bot_absent ? this.bot_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isSystemPresent() {
/* 1546 */     return !this.system_absent;
/*      */   }
/*      */   
/*      */   public Boolean systemOrElse(Boolean defaultValue) {
/* 1550 */     return !this.system_absent ? this.system_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isMfaEnabledPresent() {
/* 1554 */     return !this.mfaEnabled_absent;
/*      */   }
/*      */   
/*      */   public Boolean mfaEnabledOrElse(Boolean defaultValue) {
/* 1558 */     return !this.mfaEnabled_absent ? this.mfaEnabled_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isLocalePresent() {
/* 1562 */     return !this.locale_absent;
/*      */   }
/*      */   
/*      */   public String localeOrElse(String defaultValue) {
/* 1566 */     return !this.locale_absent ? this.locale_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isVerifiedPresent() {
/* 1570 */     return !this.verified_absent;
/*      */   }
/*      */   
/*      */   public Boolean verifiedOrElse(Boolean defaultValue) {
/* 1574 */     return !this.verified_absent ? this.verified_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isEmailPresent() {
/* 1578 */     return !this.email_absent;
/*      */   }
/*      */   
/*      */   public String emailOrElse(String defaultValue) {
/* 1582 */     return !this.email_absent ? this.email_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isFlagsPresent() {
/* 1586 */     return !this.flags_absent;
/*      */   }
/*      */   
/*      */   public Long flagsOrElse(Long defaultValue) {
/* 1590 */     return !this.flags_absent ? this.flags_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isPremiumTypePresent() {
/* 1594 */     return !this.premiumType_absent;
/*      */   }
/*      */   
/*      */   public Integer premiumTypeOrElse(Integer defaultValue) {
/* 1598 */     return !this.premiumType_absent ? this.premiumType_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isPublicFlagsPresent() {
/* 1602 */     return !this.publicFlags_absent;
/*      */   }
/*      */   
/*      */   public Long publicFlagsOrElse(Long defaultValue) {
/* 1606 */     return !this.publicFlags_absent ? this.publicFlags_value : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Builder builder() {
/* 1634 */     return new Builder();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Generated(from = "PartialUserData", generator = "Immutables")
/*      */   public static final class Builder
/*      */   {
/* 1646 */     private Id id_id = null;
/* 1647 */     private Possible<Optional<String>> globalName_possible = Possible.absent();
/* 1648 */     private Possible<String> username_possible = Possible.absent();
/* 1649 */     private Possible<String> discriminator_possible = Possible.absent();
/* 1650 */     private Possible<Optional<String>> avatar_possible = Possible.absent();
/* 1651 */     private Possible<Optional<String>> banner_possible = Possible.absent();
/* 1652 */     private Possible<Optional<Integer>> accentColor_possible = Possible.absent();
/* 1653 */     private Possible<Boolean> bot_possible = Possible.absent();
/* 1654 */     private Possible<Boolean> system_possible = Possible.absent();
/* 1655 */     private Possible<Boolean> mfaEnabled_possible = Possible.absent();
/* 1656 */     private Possible<String> locale_possible = Possible.absent();
/* 1657 */     private Possible<Boolean> verified_possible = Possible.absent();
/* 1658 */     private Possible<String> email_possible = Possible.absent();
/* 1659 */     private Possible<Long> flags_possible = Possible.absent();
/* 1660 */     private Possible<Integer> premiumType_possible = Possible.absent();
/* 1661 */     private Possible<Long> publicFlags_possible = Possible.absent();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(PartialUserData instance) {
/* 1674 */       Objects.requireNonNull(instance, "instance");
/* 1675 */       id(instance.id());
/* 1676 */       globalName(instance.globalName());
/* 1677 */       username(instance.username());
/* 1678 */       discriminator(instance.discriminator());
/* 1679 */       avatar(instance.avatar());
/* 1680 */       banner(instance.banner());
/* 1681 */       accentColor(instance.accentColor());
/* 1682 */       bot(instance.bot());
/* 1683 */       system(instance.system());
/* 1684 */       mfaEnabled(instance.mfaEnabled());
/* 1685 */       locale(instance.locale());
/* 1686 */       verified(instance.verified());
/* 1687 */       email(instance.email());
/* 1688 */       flags(instance.flags());
/* 1689 */       premiumType(instance.premiumType());
/* 1690 */       publicFlags(instance.publicFlags());
/* 1691 */       return this;
/*      */     }
/*      */     
/*      */     public Builder id(String value) {
/* 1695 */       this.id_id = Id.of(value);
/* 1696 */       return this;
/*      */     }
/*      */     
/*      */     public Builder id(long value) {
/* 1700 */       this.id_id = Id.of(value);
/* 1701 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("id")
/*      */     public Builder id(Id value) {
/* 1706 */       this.id_id = value;
/* 1707 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("global_name")
/*      */     public Builder globalName(Possible<Optional<String>> value) {
/* 1712 */       this.globalName_possible = value;
/* 1713 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder globalName(@Nullable String value) {
/* 1718 */       this.globalName_possible = Possible.of(Optional.ofNullable(value));
/* 1719 */       return this;
/*      */     }
/*      */     
/*      */     public Builder globalNameOrNull(@Nullable String value) {
/* 1723 */       this.globalName_possible = Possible.of(Optional.ofNullable(value));
/* 1724 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("username")
/*      */     public Builder username(Possible<String> value) {
/* 1729 */       this.username_possible = value;
/* 1730 */       return this;
/*      */     }
/*      */     
/*      */     public Builder username(String value) {
/* 1734 */       this.username_possible = Possible.of(value);
/* 1735 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("discriminator")
/*      */     public Builder discriminator(Possible<String> value) {
/* 1740 */       this.discriminator_possible = value;
/* 1741 */       return this;
/*      */     }
/*      */     
/*      */     public Builder discriminator(String value) {
/* 1745 */       this.discriminator_possible = Possible.of(value);
/* 1746 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("avatar")
/*      */     public Builder avatar(Possible<Optional<String>> value) {
/* 1751 */       this.avatar_possible = value;
/* 1752 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder avatar(@Nullable String value) {
/* 1757 */       this.avatar_possible = Possible.of(Optional.ofNullable(value));
/* 1758 */       return this;
/*      */     }
/*      */     
/*      */     public Builder avatarOrNull(@Nullable String value) {
/* 1762 */       this.avatar_possible = Possible.of(Optional.ofNullable(value));
/* 1763 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("banner")
/*      */     public Builder banner(Possible<Optional<String>> value) {
/* 1768 */       this.banner_possible = value;
/* 1769 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder banner(@Nullable String value) {
/* 1774 */       this.banner_possible = Possible.of(Optional.ofNullable(value));
/* 1775 */       return this;
/*      */     }
/*      */     
/*      */     public Builder bannerOrNull(@Nullable String value) {
/* 1779 */       this.banner_possible = Possible.of(Optional.ofNullable(value));
/* 1780 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("accent_color")
/*      */     public Builder accentColor(Possible<Optional<Integer>> value) {
/* 1785 */       this.accentColor_possible = value;
/* 1786 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder accentColor(@Nullable Integer value) {
/* 1791 */       this.accentColor_possible = Possible.of(Optional.ofNullable(value));
/* 1792 */       return this;
/*      */     }
/*      */     
/*      */     public Builder accentColorOrNull(@Nullable Integer value) {
/* 1796 */       this.accentColor_possible = Possible.of(Optional.ofNullable(value));
/* 1797 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("bot")
/*      */     public Builder bot(Possible<Boolean> value) {
/* 1802 */       this.bot_possible = value;
/* 1803 */       return this;
/*      */     }
/*      */     
/*      */     public Builder bot(Boolean value) {
/* 1807 */       this.bot_possible = Possible.of(value);
/* 1808 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("system")
/*      */     public Builder system(Possible<Boolean> value) {
/* 1813 */       this.system_possible = value;
/* 1814 */       return this;
/*      */     }
/*      */     
/*      */     public Builder system(Boolean value) {
/* 1818 */       this.system_possible = Possible.of(value);
/* 1819 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("mfa_enabled")
/*      */     public Builder mfaEnabled(Possible<Boolean> value) {
/* 1824 */       this.mfaEnabled_possible = value;
/* 1825 */       return this;
/*      */     }
/*      */     
/*      */     public Builder mfaEnabled(Boolean value) {
/* 1829 */       this.mfaEnabled_possible = Possible.of(value);
/* 1830 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("locale")
/*      */     public Builder locale(Possible<String> value) {
/* 1835 */       this.locale_possible = value;
/* 1836 */       return this;
/*      */     }
/*      */     
/*      */     public Builder locale(String value) {
/* 1840 */       this.locale_possible = Possible.of(value);
/* 1841 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("verified")
/*      */     public Builder verified(Possible<Boolean> value) {
/* 1846 */       this.verified_possible = value;
/* 1847 */       return this;
/*      */     }
/*      */     
/*      */     public Builder verified(Boolean value) {
/* 1851 */       this.verified_possible = Possible.of(value);
/* 1852 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("email")
/*      */     public Builder email(Possible<String> value) {
/* 1857 */       this.email_possible = value;
/* 1858 */       return this;
/*      */     }
/*      */     
/*      */     public Builder email(String value) {
/* 1862 */       this.email_possible = Possible.of(value);
/* 1863 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("flags")
/*      */     public Builder flags(Possible<Long> value) {
/* 1868 */       this.flags_possible = value;
/* 1869 */       return this;
/*      */     }
/*      */     
/*      */     public Builder flags(Long value) {
/* 1873 */       this.flags_possible = Possible.of(value);
/* 1874 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("premium_type")
/*      */     public Builder premiumType(Possible<Integer> value) {
/* 1879 */       this.premiumType_possible = value;
/* 1880 */       return this;
/*      */     }
/*      */     
/*      */     public Builder premiumType(Integer value) {
/* 1884 */       this.premiumType_possible = Possible.of(value);
/* 1885 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("public_flags")
/*      */     public Builder publicFlags(Possible<Long> value) {
/* 1890 */       this.publicFlags_possible = value;
/* 1891 */       return this;
/*      */     }
/*      */     
/*      */     public Builder publicFlags(Long value) {
/* 1895 */       this.publicFlags_possible = Possible.of(value);
/* 1896 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ImmutablePartialUserData build() {
/* 1905 */       return new ImmutablePartialUserData(null, 
/*      */           
/* 1907 */           id_build(), 
/* 1908 */           globalName_build(), 
/* 1909 */           username_build(), 
/* 1910 */           discriminator_build(), 
/* 1911 */           avatar_build(), 
/* 1912 */           banner_build(), 
/* 1913 */           accentColor_build(), 
/* 1914 */           bot_build(), 
/* 1915 */           system_build(), 
/* 1916 */           mfaEnabled_build(), 
/* 1917 */           locale_build(), 
/* 1918 */           verified_build(), 
/* 1919 */           email_build(), 
/* 1920 */           flags_build(), 
/* 1921 */           premiumType_build(), 
/* 1922 */           publicFlags_build());
/*      */     }
/*      */     
/*      */     private Id id_build() {
/* 1926 */       return this.id_id;
/*      */     }
/*      */     
/*      */     private Possible<Optional<String>> globalName_build() {
/* 1930 */       return this.globalName_possible;
/*      */     }
/*      */     
/*      */     private Possible<String> username_build() {
/* 1934 */       return this.username_possible;
/*      */     }
/*      */     
/*      */     private Possible<String> discriminator_build() {
/* 1938 */       return this.discriminator_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<String>> avatar_build() {
/* 1942 */       return this.avatar_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<String>> banner_build() {
/* 1946 */       return this.banner_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<Integer>> accentColor_build() {
/* 1950 */       return this.accentColor_possible;
/*      */     }
/*      */     
/*      */     private Possible<Boolean> bot_build() {
/* 1954 */       return this.bot_possible;
/*      */     }
/*      */     
/*      */     private Possible<Boolean> system_build() {
/* 1958 */       return this.system_possible;
/*      */     }
/*      */     
/*      */     private Possible<Boolean> mfaEnabled_build() {
/* 1962 */       return this.mfaEnabled_possible;
/*      */     }
/*      */     
/*      */     private Possible<String> locale_build() {
/* 1966 */       return this.locale_possible;
/*      */     }
/*      */     
/*      */     private Possible<Boolean> verified_build() {
/* 1970 */       return this.verified_possible;
/*      */     }
/*      */     
/*      */     private Possible<String> email_build() {
/* 1974 */       return this.email_possible;
/*      */     }
/*      */     
/*      */     private Possible<Long> flags_build() {
/* 1978 */       return this.flags_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> premiumType_build() {
/* 1982 */       return this.premiumType_possible;
/*      */     }
/*      */     
/*      */     private Possible<Long> publicFlags_build() {
/* 1986 */       return this.publicFlags_possible;
/*      */     }
/*      */     
/*      */     private Builder() {}
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutablePartialUserData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */