/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ @JsonSerialize(as = ImmutableSelectOptionData.class)
/*    */ @JsonDeserialize(as = ImmutableSelectOptionData.class)
/*    */ @Immutable
/*    */ public interface SelectOptionData
/*    */ {
/*    */   static ImmutableSelectOptionData.Builder builder() {
/* 15 */     return ImmutableSelectOptionData.builder();
/*    */   }
/*    */   
/*    */   String label();
/*    */   
/*    */   String value();
/*    */   
/*    */   Possible<String> description();
/*    */   
/*    */   Possible<EmojiData> emoji();
/*    */   
/*    */   @JsonProperty("default")
/*    */   Possible<Boolean> isDefault();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\SelectOptionData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */