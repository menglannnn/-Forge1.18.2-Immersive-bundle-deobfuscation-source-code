/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.Id;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "OnboardingPromptData", generator = "Immutables")
/*     */ public final class ImmutableOnboardingPromptData
/*     */   implements OnboardingPromptData
/*     */ {
/*     */   private final long id_value;
/*     */   private final int type;
/*     */   private final List<OnboardingPromptOptionData> options;
/*     */   private final String title;
/*     */   private final boolean singleSelect;
/*     */   private final boolean required;
/*     */   private final boolean inOnboarding;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private ImmutableOnboardingPromptData(Id id, int type, Iterable<? extends OnboardingPromptOptionData> options, String title, boolean singleSelect, boolean required, boolean inOnboarding) {
/*  44 */     Id id$impl = id;
/*  45 */     this.type = type;
/*  46 */     this.options = createUnmodifiableList(false, createSafeList(options, true, false));
/*  47 */     this.title = Objects.<String>requireNonNull(title, "title");
/*  48 */     this.singleSelect = singleSelect;
/*  49 */     this.required = required;
/*  50 */     this.inOnboarding = inOnboarding;
/*  51 */     this.id_value = id$impl.asLong();
/*  52 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableOnboardingPromptData(ImmutableOnboardingPromptData original, Id id, int type, List<OnboardingPromptOptionData> options, String title, boolean singleSelect, boolean required, boolean inOnboarding) {
/*  64 */     Id id$impl = id;
/*  65 */     this.type = type;
/*  66 */     this.options = options;
/*  67 */     this.title = title;
/*  68 */     this.singleSelect = singleSelect;
/*  69 */     this.required = required;
/*  70 */     this.inOnboarding = inOnboarding;
/*  71 */     this.id_value = id$impl.asLong();
/*  72 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  78 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "OnboardingPromptData", generator = "Immutables")
/*     */   private final class InitShim {
/*     */     private String formatInitCycleMessage() {
/*  83 */       List<String> attributes = new ArrayList<>();
/*  84 */       return "Cannot build OnboardingPromptData, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @JsonProperty("id")
/*     */   public Id id() {
/*  94 */     return Id.of(this.id_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("type")
/*     */   public int type() {
/* 103 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("options")
/*     */   public List<OnboardingPromptOptionData> options() {
/* 112 */     return this.options;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("title")
/*     */   public String title() {
/* 121 */     return this.title;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("single_select")
/*     */   public boolean singleSelect() {
/* 130 */     return this.singleSelect;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("required")
/*     */   public boolean required() {
/* 139 */     return this.required;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("in_onboarding")
/*     */   public boolean inOnboarding() {
/* 148 */     return this.inOnboarding;
/*     */   }
/*     */   
/*     */   public ImmutableOnboardingPromptData withId(long value) {
/* 152 */     Id newValue = Id.of(value);
/* 153 */     return new ImmutableOnboardingPromptData(this, newValue, this.type, this.options, this.title, this.singleSelect, this.required, this.inOnboarding);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImmutableOnboardingPromptData withId(String value) {
/* 165 */     Id newValue = Id.of(value);
/* 166 */     return new ImmutableOnboardingPromptData(this, newValue, this.type, this.options, this.title, this.singleSelect, this.required, this.inOnboarding);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableOnboardingPromptData withType(int value) {
/* 184 */     if (this.type == value) return this; 
/* 185 */     return new ImmutableOnboardingPromptData(this, 
/*     */         
/* 187 */         id(), value, this.options, this.title, this.singleSelect, this.required, this.inOnboarding);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableOnboardingPromptData withOptions(OnboardingPromptOptionData... elements) {
/* 202 */     List<OnboardingPromptOptionData> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 203 */     return new ImmutableOnboardingPromptData(this, 
/*     */         
/* 205 */         id(), this.type, newValue, this.title, this.singleSelect, this.required, this.inOnboarding);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableOnboardingPromptData withOptions(Iterable<? extends OnboardingPromptOptionData> elements) {
/* 221 */     if (this.options == elements) return this; 
/* 222 */     List<OnboardingPromptOptionData> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 223 */     return new ImmutableOnboardingPromptData(this, 
/*     */         
/* 225 */         id(), this.type, newValue, this.title, this.singleSelect, this.required, this.inOnboarding);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableOnboardingPromptData withTitle(String value) {
/* 241 */     String newValue = Objects.<String>requireNonNull(value, "title");
/* 242 */     if (this.title.equals(newValue)) return this; 
/* 243 */     return new ImmutableOnboardingPromptData(this, 
/*     */         
/* 245 */         id(), this.type, this.options, newValue, this.singleSelect, this.required, this.inOnboarding);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableOnboardingPromptData withSingleSelect(boolean value) {
/* 261 */     if (this.singleSelect == value) return this; 
/* 262 */     return new ImmutableOnboardingPromptData(this, id(), this.type, this.options, this.title, value, this.required, this.inOnboarding);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableOnboardingPromptData withRequired(boolean value) {
/* 272 */     if (this.required == value) return this; 
/* 273 */     return new ImmutableOnboardingPromptData(this, 
/*     */         
/* 275 */         id(), this.type, this.options, this.title, this.singleSelect, value, this.inOnboarding);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableOnboardingPromptData withInOnboarding(boolean value) {
/* 291 */     if (this.inOnboarding == value) return this; 
/* 292 */     return new ImmutableOnboardingPromptData(this, id(), this.type, this.options, this.title, this.singleSelect, this.required, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 301 */     if (this == another) return true; 
/* 302 */     return (another instanceof ImmutableOnboardingPromptData && 
/* 303 */       equalTo(0, (ImmutableOnboardingPromptData)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableOnboardingPromptData another) {
/* 307 */     return (Objects.equals(Long.valueOf(this.id_value), Long.valueOf(another.id_value)) && this.type == another.type && this.options
/*     */       
/* 309 */       .equals(another.options) && this.title
/* 310 */       .equals(another.title) && this.singleSelect == another.singleSelect && this.required == another.required && this.inOnboarding == another.inOnboarding);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 322 */     int h = 5381;
/* 323 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.id_value));
/* 324 */     h += (h << 5) + this.type;
/* 325 */     h += (h << 5) + this.options.hashCode();
/* 326 */     h += (h << 5) + this.title.hashCode();
/* 327 */     h += (h << 5) + Boolean.hashCode(this.singleSelect);
/* 328 */     h += (h << 5) + Boolean.hashCode(this.required);
/* 329 */     h += (h << 5) + Boolean.hashCode(this.inOnboarding);
/* 330 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 339 */     return "OnboardingPromptData{id=" + 
/* 340 */       Objects.toString(Long.valueOf(this.id_value)) + ", type=" + this.type + ", options=" + this.options + ", title=" + this.title + ", singleSelect=" + this.singleSelect + ", required=" + this.required + ", inOnboarding=" + this.inOnboarding + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "OnboardingPromptData", generator = "Immutables")
/*     */   static final class Json
/*     */     implements OnboardingPromptData
/*     */   {
/*     */     Id id;
/*     */ 
/*     */     
/*     */     int type;
/*     */ 
/*     */     
/*     */     boolean typeIsSet;
/*     */ 
/*     */     
/* 362 */     List<OnboardingPromptOptionData> options = Collections.emptyList(); String title;
/*     */     boolean singleSelect;
/*     */     boolean singleSelectIsSet;
/*     */     boolean required;
/*     */     boolean requiredIsSet;
/*     */     boolean inOnboarding;
/*     */     boolean inOnboardingIsSet;
/*     */     
/*     */     @JsonProperty("id")
/*     */     public void setId(Id id) {
/* 372 */       this.id = id;
/*     */     }
/*     */     @JsonProperty("type")
/*     */     public void setType(int type) {
/* 376 */       this.type = type;
/* 377 */       this.typeIsSet = true;
/*     */     }
/*     */     @JsonProperty("options")
/*     */     public void setOptions(List<OnboardingPromptOptionData> options) {
/* 381 */       this.options = options;
/*     */     }
/*     */     @JsonProperty("title")
/*     */     public void setTitle(String title) {
/* 385 */       this.title = title;
/*     */     }
/*     */     @JsonProperty("single_select")
/*     */     public void setSingleSelect(boolean singleSelect) {
/* 389 */       this.singleSelect = singleSelect;
/* 390 */       this.singleSelectIsSet = true;
/*     */     }
/*     */     @JsonProperty("required")
/*     */     public void setRequired(boolean required) {
/* 394 */       this.required = required;
/* 395 */       this.requiredIsSet = true;
/*     */     }
/*     */     @JsonProperty("in_onboarding")
/*     */     public void setInOnboarding(boolean inOnboarding) {
/* 399 */       this.inOnboarding = inOnboarding;
/* 400 */       this.inOnboardingIsSet = true;
/*     */     }
/*     */     public Id id() {
/* 403 */       throw new UnsupportedOperationException();
/*     */     } public int type() {
/* 405 */       throw new UnsupportedOperationException();
/*     */     } public List<OnboardingPromptOptionData> options() {
/* 407 */       throw new UnsupportedOperationException();
/*     */     } public String title() {
/* 409 */       throw new UnsupportedOperationException();
/*     */     } public boolean singleSelect() {
/* 411 */       throw new UnsupportedOperationException();
/*     */     } public boolean required() {
/* 413 */       throw new UnsupportedOperationException();
/*     */     } public boolean inOnboarding() {
/* 415 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableOnboardingPromptData fromJson(Json json) {
/* 426 */     Builder builder = builder();
/* 427 */     if (json.id != null) {
/* 428 */       builder.id(json.id);
/*     */     }
/* 430 */     if (json.typeIsSet) {
/* 431 */       builder.type(json.type);
/*     */     }
/* 433 */     if (json.options != null) {
/* 434 */       builder.addAllOptions(json.options);
/*     */     }
/* 436 */     if (json.title != null) {
/* 437 */       builder.title(json.title);
/*     */     }
/* 439 */     if (json.singleSelectIsSet) {
/* 440 */       builder.singleSelect(json.singleSelect);
/*     */     }
/* 442 */     if (json.requiredIsSet) {
/* 443 */       builder.required(json.required);
/*     */     }
/* 445 */     if (json.inOnboardingIsSet) {
/* 446 */       builder.inOnboarding(json.inOnboarding);
/*     */     }
/* 448 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableOnboardingPromptData of(Id id, int type, List<OnboardingPromptOptionData> options, String title, boolean singleSelect, boolean required, boolean inOnboarding) {
/* 463 */     return of(id, type, options, title, singleSelect, required, inOnboarding);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableOnboardingPromptData of(Id id, int type, Iterable<? extends OnboardingPromptOptionData> options, String title, boolean singleSelect, boolean required, boolean inOnboarding) {
/* 478 */     return new ImmutableOnboardingPromptData(id, type, options, title, singleSelect, required, inOnboarding);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableOnboardingPromptData copyOf(OnboardingPromptData instance) {
/* 489 */     if (instance instanceof ImmutableOnboardingPromptData) {
/* 490 */       return (ImmutableOnboardingPromptData)instance;
/*     */     }
/* 492 */     return builder()
/* 493 */       .from(instance)
/* 494 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 513 */     return new Builder();
/*     */   }
/*     */ 
/*     */   
/*     */   @Generated(from = "OnboardingPromptData", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_TYPE = 1L;
/*     */     
/*     */     private static final long INIT_BIT_TITLE = 2L;
/*     */     
/*     */     private static final long INIT_BIT_SINGLE_SELECT = 4L;
/*     */     
/*     */     private static final long INIT_BIT_REQUIRED = 8L;
/*     */     
/*     */     private static final long INIT_BIT_IN_ONBOARDING = 16L;
/*     */     
/* 530 */     private long initBits = 31L;
/*     */     
/* 532 */     private Id id_id = null;
/*     */     private int type;
/* 534 */     private List<OnboardingPromptOptionData> options = new ArrayList<>();
/*     */ 
/*     */ 
/*     */     
/*     */     private String title;
/*     */ 
/*     */     
/*     */     private boolean singleSelect;
/*     */ 
/*     */     
/*     */     private boolean required;
/*     */ 
/*     */     
/*     */     private boolean inOnboarding;
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(OnboardingPromptData instance) {
/* 552 */       Objects.requireNonNull(instance, "instance");
/* 553 */       id(instance.id());
/* 554 */       type(instance.type());
/* 555 */       addAllOptions(instance.options());
/* 556 */       title(instance.title());
/* 557 */       singleSelect(instance.singleSelect());
/* 558 */       required(instance.required());
/* 559 */       inOnboarding(instance.inOnboarding());
/* 560 */       return this;
/*     */     }
/*     */     
/*     */     public Builder id(String value) {
/* 564 */       this.id_id = Id.of(value);
/* 565 */       return this;
/*     */     }
/*     */     
/*     */     public Builder id(long value) {
/* 569 */       this.id_id = Id.of(value);
/* 570 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("id")
/*     */     public Builder id(Id value) {
/* 575 */       this.id_id = value;
/* 576 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("type")
/*     */     public final Builder type(int type) {
/* 586 */       this.type = type;
/* 587 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 588 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addOption(OnboardingPromptOptionData element) {
/* 597 */       this.options.add(Objects.<OnboardingPromptOptionData>requireNonNull(element, "options element"));
/* 598 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addOptions(OnboardingPromptOptionData... elements) {
/* 607 */       for (OnboardingPromptOptionData element : elements) {
/* 608 */         this.options.add(Objects.<OnboardingPromptOptionData>requireNonNull(element, "options element"));
/*     */       }
/* 610 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("options")
/*     */     public final Builder options(Iterable<? extends OnboardingPromptOptionData> elements) {
/* 621 */       this.options.clear();
/* 622 */       return addAllOptions(elements);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addAllOptions(Iterable<? extends OnboardingPromptOptionData> elements) {
/* 631 */       for (OnboardingPromptOptionData element : elements) {
/* 632 */         this.options.add(Objects.<OnboardingPromptOptionData>requireNonNull(element, "options element"));
/*     */       }
/* 634 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("title")
/*     */     public final Builder title(String title) {
/* 644 */       this.title = Objects.<String>requireNonNull(title, "title");
/* 645 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 646 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("single_select")
/*     */     public final Builder singleSelect(boolean singleSelect) {
/* 656 */       this.singleSelect = singleSelect;
/* 657 */       this.initBits &= 0xFFFFFFFFFFFFFFFBL;
/* 658 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("required")
/*     */     public final Builder required(boolean required) {
/* 668 */       this.required = required;
/* 669 */       this.initBits &= 0xFFFFFFFFFFFFFFF7L;
/* 670 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("in_onboarding")
/*     */     public final Builder inOnboarding(boolean inOnboarding) {
/* 680 */       this.inOnboarding = inOnboarding;
/* 681 */       this.initBits &= 0xFFFFFFFFFFFFFFEFL;
/* 682 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableOnboardingPromptData build() {
/* 691 */       if (this.initBits != 0L) {
/* 692 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 694 */       return new ImmutableOnboardingPromptData(null, 
/*     */           
/* 696 */           id_build(), this.type, ImmutableOnboardingPromptData
/*     */           
/* 698 */           .createUnmodifiableList(true, (List)this.options), this.title, this.singleSelect, this.required, this.inOnboarding);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 706 */       List<String> attributes = new ArrayList<>();
/* 707 */       if ((this.initBits & 0x1L) != 0L) attributes.add("type"); 
/* 708 */       if ((this.initBits & 0x2L) != 0L) attributes.add("title"); 
/* 709 */       if ((this.initBits & 0x4L) != 0L) attributes.add("singleSelect"); 
/* 710 */       if ((this.initBits & 0x8L) != 0L) attributes.add("required"); 
/* 711 */       if ((this.initBits & 0x10L) != 0L) attributes.add("inOnboarding"); 
/* 712 */       return "Cannot build OnboardingPromptData, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Id id_build() {
/* 716 */       return this.id_id;
/*     */     }
/*     */     private Builder() {} }
/*     */   
/*     */   private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
/*     */     ArrayList<T> list;
/* 722 */     if (iterable instanceof Collection) {
/* 723 */       int size = ((Collection)iterable).size();
/* 724 */       if (size == 0) return Collections.emptyList(); 
/* 725 */       list = new ArrayList<>();
/*     */     } else {
/* 727 */       list = new ArrayList<>();
/*     */     } 
/* 729 */     for (T element : iterable) {
/* 730 */       if (skipNulls && element == null)
/* 731 */         continue;  if (checkNulls) Objects.requireNonNull(element, "element"); 
/* 732 */       list.add(element);
/*     */     } 
/* 734 */     return list;
/*     */   }
/*     */   
/*     */   private static <T> List<T> createUnmodifiableList(boolean clone, List<T> list) {
/* 738 */     switch (list.size()) { case 0:
/* 739 */         return Collections.emptyList();
/* 740 */       case 1: return Collections.singletonList(list.get(0)); }
/*     */     
/* 742 */     if (clone) {
/* 743 */       return Collections.unmodifiableList(new ArrayList<>(list));
/*     */     }
/* 745 */     if (list instanceof ArrayList) {
/* 746 */       ((ArrayList)list).trimToSize();
/*     */     }
/* 748 */     return Collections.unmodifiableList(list);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableOnboardingPromptData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */