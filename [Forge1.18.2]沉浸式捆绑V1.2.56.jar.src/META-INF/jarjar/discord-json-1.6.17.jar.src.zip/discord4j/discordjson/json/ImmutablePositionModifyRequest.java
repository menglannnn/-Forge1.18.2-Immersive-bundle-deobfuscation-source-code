/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "PositionModifyRequest", generator = "Immutables")
/*     */ public final class ImmutablePositionModifyRequest
/*     */   implements PositionModifyRequest
/*     */ {
/*     */   private final String id;
/*     */   private final int position;
/*     */   private final Boolean lockPermissions_value;
/*     */   private final boolean lockPermissions_absent;
/*     */   private final String parentId_value;
/*     */   private final boolean parentId_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private ImmutablePositionModifyRequest(String id, int position, Possible<Optional<Boolean>> lockPermissions, Possible<Optional<String>> parentId) {
/*  70 */     this.initShim = new InitShim(); this.id = Objects.<String>requireNonNull(id, "id"); this.position = position; Possible<Optional<Boolean>> lockPermissions$impl = lockPermissions; Possible<Optional<String>> parentId$impl = parentId; this.lockPermissions_value = Possible.flatOpt(lockPermissions$impl).orElse(null); this.lockPermissions_absent = lockPermissions$impl.isAbsent(); this.parentId_value = Possible.flatOpt(parentId$impl).orElse(null); this.parentId_absent = parentId$impl.isAbsent(); this.initShim = null; } private ImmutablePositionModifyRequest(ImmutablePositionModifyRequest original, String id, int position, Possible<Optional<Boolean>> lockPermissions, Possible<Optional<String>> parentId) { this.initShim = new InitShim(); this.id = id; this.position = position; Possible<Optional<Boolean>> lockPermissions$impl = lockPermissions; Possible<Optional<String>> parentId$impl = parentId;
/*     */     this.lockPermissions_value = Possible.flatOpt(lockPermissions$impl).orElse(null);
/*     */     this.lockPermissions_absent = lockPermissions$impl.isAbsent();
/*     */     this.parentId_value = Possible.flatOpt(parentId$impl).orElse(null);
/*     */     this.parentId_absent = parentId$impl.isAbsent();
/*  75 */     this.initShim = null; } @Generated(from = "PositionModifyRequest", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/*  76 */       return "Cannot build PositionModifyRequest, attribute initializers form cycle " + attributes; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("id")
/*     */   public String id() {
/*  86 */     return this.id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("position")
/*     */   public int position() {
/*  95 */     return this.position;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("lock_permissions")
/*     */   public Possible<Optional<Boolean>> lockPermissions() {
/* 104 */     return this.lockPermissions_absent ? Possible.absent() : 
/* 105 */       Possible.of(Optional.ofNullable(this.lockPermissions_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("parent_id")
/*     */   public Possible<Optional<String>> parentId() {
/* 114 */     return this.parentId_absent ? Possible.absent() : 
/* 115 */       Possible.of(Optional.ofNullable(this.parentId_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutablePositionModifyRequest withId(String value) {
/* 125 */     String newValue = Objects.<String>requireNonNull(value, "id");
/* 126 */     if (this.id.equals(newValue)) return this; 
/* 127 */     return new ImmutablePositionModifyRequest(this, newValue, this.position, lockPermissions(), parentId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutablePositionModifyRequest withPosition(int value) {
/* 137 */     if (this.position == value) return this; 
/* 138 */     return new ImmutablePositionModifyRequest(this, this.id, value, lockPermissions(), parentId());
/*     */   }
/*     */   
/*     */   public ImmutablePositionModifyRequest withLockPermissions(Possible<Optional<Boolean>> value) {
/* 142 */     Possible<Optional<Boolean>> newValue = Objects.<Possible<Optional<Boolean>>>requireNonNull(value);
/* 143 */     return new ImmutablePositionModifyRequest(this, this.id, this.position, newValue, parentId());
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public ImmutablePositionModifyRequest withLockPermissions(@Nullable Boolean value) {
/* 148 */     Possible<Optional<Boolean>> newValue = Possible.of(Optional.ofNullable(value));
/* 149 */     return new ImmutablePositionModifyRequest(this, this.id, this.position, newValue, parentId());
/*     */   }
/*     */   
/*     */   public ImmutablePositionModifyRequest withLockPermissionsOrNull(@Nullable Boolean value) {
/* 153 */     Possible<Optional<Boolean>> newValue = Possible.of(Optional.ofNullable(value));
/* 154 */     return new ImmutablePositionModifyRequest(this, this.id, this.position, newValue, parentId());
/*     */   }
/*     */   
/*     */   public ImmutablePositionModifyRequest withParentId(Possible<Optional<String>> value) {
/* 158 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/* 159 */     return new ImmutablePositionModifyRequest(this, this.id, this.position, lockPermissions(), newValue);
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public ImmutablePositionModifyRequest withParentId(@Nullable String value) {
/* 164 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 165 */     return new ImmutablePositionModifyRequest(this, this.id, this.position, lockPermissions(), newValue);
/*     */   }
/*     */   
/*     */   public ImmutablePositionModifyRequest withParentIdOrNull(@Nullable String value) {
/* 169 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 170 */     return new ImmutablePositionModifyRequest(this, this.id, this.position, lockPermissions(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 179 */     if (this == another) return true; 
/* 180 */     return (another instanceof ImmutablePositionModifyRequest && 
/* 181 */       equalTo(0, (ImmutablePositionModifyRequest)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutablePositionModifyRequest another) {
/* 185 */     return (this.id.equals(another.id) && this.position == another.position && 
/*     */       
/* 187 */       lockPermissions().equals(another.lockPermissions()) && 
/* 188 */       parentId().equals(another.parentId()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 197 */     int h = 5381;
/* 198 */     h += (h << 5) + this.id.hashCode();
/* 199 */     h += (h << 5) + this.position;
/* 200 */     h += (h << 5) + lockPermissions().hashCode();
/* 201 */     h += (h << 5) + parentId().hashCode();
/* 202 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 211 */     return "PositionModifyRequest{id=" + this.id + ", position=" + this.position + ", lockPermissions=" + 
/*     */ 
/*     */       
/* 214 */       lockPermissions().toString() + ", parentId=" + 
/* 215 */       parentId().toString() + "}";
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "PositionModifyRequest", generator = "Immutables")
/*     */   static final class Json
/*     */     implements PositionModifyRequest
/*     */   {
/*     */     String id;
/*     */     
/*     */     int position;
/*     */     
/*     */     boolean positionIsSet;
/*     */     
/* 232 */     Possible<Optional<Boolean>> lockPermissions = Possible.absent();
/*     */ 
/*     */     
/* 235 */     Possible<Optional<String>> parentId = Possible.absent();
/*     */     
/*     */     @JsonProperty("id")
/*     */     public void setId(String id) {
/* 239 */       this.id = id;
/*     */     }
/*     */     @JsonProperty("position")
/*     */     public void setPosition(int position) {
/* 243 */       this.position = position;
/* 244 */       this.positionIsSet = true;
/*     */     }
/*     */     @JsonProperty("lock_permissions")
/*     */     public void setLockPermissions(Possible<Optional<Boolean>> lockPermissions) {
/* 248 */       this.lockPermissions = lockPermissions;
/*     */     }
/*     */     @JsonProperty("parent_id")
/*     */     public void setParentId(Possible<Optional<String>> parentId) {
/* 252 */       this.parentId = parentId;
/*     */     }
/*     */     public String id() {
/* 255 */       throw new UnsupportedOperationException();
/*     */     } public int position() {
/* 257 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Optional<Boolean>> lockPermissions() {
/* 259 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Optional<String>> parentId() {
/* 261 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutablePositionModifyRequest fromJson(Json json) {
/* 272 */     Builder builder = builder();
/* 273 */     if (json.id != null) {
/* 274 */       builder.id(json.id);
/*     */     }
/* 276 */     if (json.positionIsSet) {
/* 277 */       builder.position(json.position);
/*     */     }
/* 279 */     if (json.lockPermissions != null) {
/* 280 */       builder.lockPermissions(json.lockPermissions);
/*     */     }
/* 282 */     if (json.parentId != null) {
/* 283 */       builder.parentId(json.parentId);
/*     */     }
/* 285 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutablePositionModifyRequest of(String id, int position, Possible<Optional<Boolean>> lockPermissions, Possible<Optional<String>> parentId) {
/* 297 */     return new ImmutablePositionModifyRequest(id, position, lockPermissions, parentId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutablePositionModifyRequest copyOf(PositionModifyRequest instance) {
/* 308 */     if (instance instanceof ImmutablePositionModifyRequest) {
/* 309 */       return (ImmutablePositionModifyRequest)instance;
/*     */     }
/* 311 */     return builder()
/* 312 */       .from(instance)
/* 313 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isLockPermissionsPresent() {
/* 317 */     return !this.lockPermissions_absent;
/*     */   }
/*     */   
/*     */   public Boolean lockPermissionsOrElse(Boolean defaultValue) {
/* 321 */     return !this.lockPermissions_absent ? this.lockPermissions_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isParentIdPresent() {
/* 325 */     return !this.parentId_absent;
/*     */   }
/*     */   
/*     */   public String parentIdOrElse(String defaultValue) {
/* 329 */     return !this.parentId_absent ? this.parentId_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 345 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "PositionModifyRequest", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_ID = 1L;
/*     */ 
/*     */     
/*     */     private static final long INIT_BIT_POSITION = 2L;
/*     */ 
/*     */     
/* 359 */     private long initBits = 3L;
/*     */     
/* 361 */     private Possible<Optional<Boolean>> lockPermissions_possible = Possible.absent();
/* 362 */     private Possible<Optional<String>> parentId_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String id;
/*     */ 
/*     */ 
/*     */     
/*     */     private int position;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(PositionModifyRequest instance) {
/* 377 */       Objects.requireNonNull(instance, "instance");
/* 378 */       id(instance.id());
/* 379 */       position(instance.position());
/* 380 */       lockPermissions(instance.lockPermissions());
/* 381 */       parentId(instance.parentId());
/* 382 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("id")
/*     */     public final Builder id(String id) {
/* 392 */       this.id = Objects.<String>requireNonNull(id, "id");
/* 393 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 394 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("position")
/*     */     public final Builder position(int position) {
/* 404 */       this.position = position;
/* 405 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 406 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("lock_permissions")
/*     */     public Builder lockPermissions(Possible<Optional<Boolean>> value) {
/* 411 */       this.lockPermissions_possible = value;
/* 412 */       return this;
/*     */     }
/*     */     
/*     */     @Deprecated
/*     */     public Builder lockPermissions(@Nullable Boolean value) {
/* 417 */       this.lockPermissions_possible = Possible.of(Optional.ofNullable(value));
/* 418 */       return this;
/*     */     }
/*     */     
/*     */     public Builder lockPermissionsOrNull(@Nullable Boolean value) {
/* 422 */       this.lockPermissions_possible = Possible.of(Optional.ofNullable(value));
/* 423 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("parent_id")
/*     */     public Builder parentId(Possible<Optional<String>> value) {
/* 428 */       this.parentId_possible = value;
/* 429 */       return this;
/*     */     }
/*     */     
/*     */     @Deprecated
/*     */     public Builder parentId(@Nullable String value) {
/* 434 */       this.parentId_possible = Possible.of(Optional.ofNullable(value));
/* 435 */       return this;
/*     */     }
/*     */     
/*     */     public Builder parentIdOrNull(@Nullable String value) {
/* 439 */       this.parentId_possible = Possible.of(Optional.ofNullable(value));
/* 440 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutablePositionModifyRequest build() {
/* 449 */       if (this.initBits != 0L) {
/* 450 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 452 */       return new ImmutablePositionModifyRequest(null, this.id, this.position, lockPermissions_build(), parentId_build());
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 456 */       List<String> attributes = new ArrayList<>();
/* 457 */       if ((this.initBits & 0x1L) != 0L) attributes.add("id"); 
/* 458 */       if ((this.initBits & 0x2L) != 0L) attributes.add("position"); 
/* 459 */       return "Cannot build PositionModifyRequest, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Possible<Optional<Boolean>> lockPermissions_build() {
/* 463 */       return this.lockPermissions_possible;
/*     */     }
/*     */     
/*     */     private Possible<Optional<String>> parentId_build() {
/* 467 */       return this.parentId_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutablePositionModifyRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */