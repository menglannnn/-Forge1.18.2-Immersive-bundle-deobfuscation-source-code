/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import java.io.UncheckedIOException;
/*    */ import java.io.UnsupportedEncodingException;
/*    */ import java.net.URLEncoder;
/*    */ import java.nio.charset.StandardCharsets;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ @Immutable
/*    */ public abstract class AuthorizationCodeGrantRequest
/*    */ {
/*    */   public static ImmutableAuthorizationCodeGrantRequest.Builder builder() {
/* 14 */     return ImmutableAuthorizationCodeGrantRequest.builder();
/*    */   }
/*    */ 
/*    */   
/*    */   public abstract long clientId();
/*    */   
/*    */   public abstract String clientSecret();
/*    */   
/*    */   public abstract String code();
/*    */   
/*    */   public abstract String redirectUri();
/*    */   
/*    */   public String toString() {
/*    */     String redirectUri;
/*    */     try {
/* 29 */       redirectUri = URLEncoder.encode(redirectUri(), StandardCharsets.UTF_8.toString());
/* 30 */     } catch (UnsupportedEncodingException e) {
/* 31 */       throw new UncheckedIOException(e);
/*    */     } 
/* 33 */     return "client_id=" + clientId() + "&client_secret=" + 
/* 34 */       clientSecret() + "&grant_type=authorization_code&code=" + 
/*    */       
/* 36 */       code() + "&redirect_uri=" + redirectUri;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\AuthorizationCodeGrantRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */