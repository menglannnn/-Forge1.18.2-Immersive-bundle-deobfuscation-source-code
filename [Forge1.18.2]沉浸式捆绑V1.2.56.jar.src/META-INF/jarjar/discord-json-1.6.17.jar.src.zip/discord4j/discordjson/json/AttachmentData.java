/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.Id;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import java.util.Optional;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ @JsonSerialize(as = ImmutableAttachmentData.class)
/*    */ @JsonDeserialize(as = ImmutableAttachmentData.class)
/*    */ @Immutable
/*    */ public interface AttachmentData
/*    */ {
/*    */   static ImmutableAttachmentData.Builder builder() {
/* 18 */     return ImmutableAttachmentData.builder();
/*    */   }
/*    */   
/*    */   Id id();
/*    */   
/*    */   String filename();
/*    */   
/*    */   Possible<String> description();
/*    */   
/*    */   @JsonProperty("content_type")
/*    */   Possible<String> contentType();
/*    */   
/*    */   int size();
/*    */   
/*    */   String url();
/*    */   
/*    */   @JsonProperty("proxy_url")
/*    */   String proxyUrl();
/*    */   
/*    */   Possible<Optional<Integer>> height();
/*    */   
/*    */   Possible<Optional<Integer>> width();
/*    */   
/*    */   Possible<Boolean> ephemeral();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\AttachmentData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */