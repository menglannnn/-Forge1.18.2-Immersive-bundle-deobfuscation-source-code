/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.Id;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import java.util.Optional;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ @JsonSerialize(as = ImmutableIntegrationApplicationData.class)
/*    */ @JsonDeserialize(as = ImmutableIntegrationApplicationData.class)
/*    */ @Immutable
/*    */ public interface IntegrationApplicationData
/*    */ {
/*    */   static ImmutableIntegrationApplicationData.Builder builder() {
/* 17 */     return ImmutableIntegrationApplicationData.builder();
/*    */   }
/*    */   
/*    */   Id id();
/*    */   
/*    */   String name();
/*    */   
/*    */   Optional<String> icon();
/*    */   
/*    */   String description();
/*    */   
/*    */   String summary();
/*    */   
/*    */   Possible<UserData> bot();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\IntegrationApplicationData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */