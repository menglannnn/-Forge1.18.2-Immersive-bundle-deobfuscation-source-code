/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.Id;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ @JsonSerialize(as = ImmutableMessageReferenceData.class)
/*    */ @JsonDeserialize(as = ImmutableMessageReferenceData.class)
/*    */ @Immutable
/*    */ public interface MessageReferenceData
/*    */ {
/*    */   static ImmutableMessageReferenceData.Builder builder() {
/* 16 */     return ImmutableMessageReferenceData.builder();
/*    */   }
/*    */   
/*    */   @JsonProperty("message_id")
/*    */   Possible<Id> messageId();
/*    */   
/*    */   @JsonProperty("channel_id")
/*    */   Possible<Id> channelId();
/*    */   
/*    */   @JsonProperty("guild_id")
/*    */   Possible<Id> guildId();
/*    */   
/*    */   @JsonProperty("fail_if_not_exists")
/*    */   Possible<Boolean> failIfNotExists();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\MessageReferenceData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */