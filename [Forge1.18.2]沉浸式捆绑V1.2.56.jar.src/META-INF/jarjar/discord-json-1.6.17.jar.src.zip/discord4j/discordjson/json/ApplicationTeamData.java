/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.Id;
/*    */ import java.util.List;
/*    */ import java.util.Optional;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ @JsonSerialize(as = ImmutableApplicationTeamData.class)
/*    */ @JsonDeserialize(as = ImmutableApplicationTeamData.class)
/*    */ @Immutable
/*    */ public interface ApplicationTeamData
/*    */ {
/*    */   static ImmutableApplicationTeamData.Builder builder() {
/* 18 */     return ImmutableApplicationTeamData.builder();
/*    */   }
/*    */   
/*    */   Optional<String> icon();
/*    */   
/*    */   Id id();
/*    */   
/*    */   List<ApplicationTeamMemberData> members();
/*    */   
/*    */   String name();
/*    */   
/*    */   @JsonProperty("owner_user_id")
/*    */   Id ownerUserId();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ApplicationTeamData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */