/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "WebhookModifyRequest", generator = "Immutables")
/*     */ public final class ImmutableWebhookModifyRequest
/*     */   implements WebhookModifyRequest
/*     */ {
/*     */   private final String name_value;
/*     */   private final boolean name_absent;
/*     */   private final String avatar_value;
/*     */   private final boolean avatar_absent;
/*     */   private final String channelId_value;
/*     */   private final boolean channelId_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private ImmutableWebhookModifyRequest(Possible<String> name, Possible<String> avatar, Possible<String> channelId) {
/*  36 */     Possible<String> name$impl = name;
/*  37 */     Possible<String> avatar$impl = avatar;
/*  38 */     Possible<String> channelId$impl = channelId;
/*  39 */     this.name_value = name$impl.toOptional().orElse(null);
/*  40 */     this.name_absent = name$impl.isAbsent();
/*  41 */     this.avatar_value = avatar$impl.toOptional().orElse(null);
/*  42 */     this.avatar_absent = avatar$impl.isAbsent();
/*  43 */     this.channelId_value = channelId$impl.toOptional().orElse(null);
/*  44 */     this.channelId_absent = channelId$impl.isAbsent();
/*  45 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableWebhookModifyRequest(ImmutableWebhookModifyRequest original, Possible<String> name, Possible<String> avatar, Possible<String> channelId) {
/*  53 */     Possible<String> name$impl = name;
/*  54 */     Possible<String> avatar$impl = avatar;
/*  55 */     Possible<String> channelId$impl = channelId;
/*  56 */     this.name_value = name$impl.toOptional().orElse(null);
/*  57 */     this.name_absent = name$impl.isAbsent();
/*  58 */     this.avatar_value = avatar$impl.toOptional().orElse(null);
/*  59 */     this.avatar_absent = avatar$impl.isAbsent();
/*  60 */     this.channelId_value = channelId$impl.toOptional().orElse(null);
/*  61 */     this.channelId_absent = channelId$impl.isAbsent();
/*  62 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  68 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "WebhookModifyRequest", generator = "Immutables")
/*     */   private final class InitShim {
/*     */     private String formatInitCycleMessage() {
/*  73 */       List<String> attributes = new ArrayList<>();
/*  74 */       return "Cannot build WebhookModifyRequest, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @JsonProperty("name")
/*     */   public Possible<String> name() {
/*  84 */     return this.name_absent ? Possible.absent() : Possible.of(this.name_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("avatar")
/*     */   public Possible<String> avatar() {
/*  93 */     return this.avatar_absent ? Possible.absent() : Possible.of(this.avatar_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("channel_id")
/*     */   public Possible<String> channelId() {
/* 102 */     return this.channelId_absent ? Possible.absent() : Possible.of(this.channelId_value);
/*     */   }
/*     */   
/*     */   public ImmutableWebhookModifyRequest withName(Possible<String> value) {
/* 106 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 107 */     return new ImmutableWebhookModifyRequest(this, newValue, avatar(), channelId());
/*     */   }
/*     */   
/*     */   public ImmutableWebhookModifyRequest withName(String value) {
/* 111 */     Possible<String> newValue = Possible.of(value);
/* 112 */     return new ImmutableWebhookModifyRequest(this, newValue, avatar(), channelId());
/*     */   }
/*     */   
/*     */   public ImmutableWebhookModifyRequest withAvatar(Possible<String> value) {
/* 116 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 117 */     return new ImmutableWebhookModifyRequest(this, name(), newValue, channelId());
/*     */   }
/*     */   
/*     */   public ImmutableWebhookModifyRequest withAvatar(String value) {
/* 121 */     Possible<String> newValue = Possible.of(value);
/* 122 */     return new ImmutableWebhookModifyRequest(this, name(), newValue, channelId());
/*     */   }
/*     */   
/*     */   public ImmutableWebhookModifyRequest withChannelId(Possible<String> value) {
/* 126 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 127 */     return new ImmutableWebhookModifyRequest(this, name(), avatar(), newValue);
/*     */   }
/*     */   
/*     */   public ImmutableWebhookModifyRequest withChannelId(String value) {
/* 131 */     Possible<String> newValue = Possible.of(value);
/* 132 */     return new ImmutableWebhookModifyRequest(this, name(), avatar(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 141 */     if (this == another) return true; 
/* 142 */     return (another instanceof ImmutableWebhookModifyRequest && 
/* 143 */       equalTo(0, (ImmutableWebhookModifyRequest)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableWebhookModifyRequest another) {
/* 147 */     return (name().equals(another.name()) && 
/* 148 */       avatar().equals(another.avatar()) && 
/* 149 */       channelId().equals(another.channelId()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 158 */     int h = 5381;
/* 159 */     h += (h << 5) + name().hashCode();
/* 160 */     h += (h << 5) + avatar().hashCode();
/* 161 */     h += (h << 5) + channelId().hashCode();
/* 162 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 171 */     return "WebhookModifyRequest{name=" + 
/* 172 */       name().toString() + ", avatar=" + 
/* 173 */       avatar().toString() + ", channelId=" + 
/* 174 */       channelId().toString() + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "WebhookModifyRequest", generator = "Immutables")
/*     */   static final class Json
/*     */     implements WebhookModifyRequest
/*     */   {
/* 188 */     Possible<String> name = Possible.absent();
/*     */ 
/*     */     
/* 191 */     Possible<String> avatar = Possible.absent();
/*     */ 
/*     */     
/* 194 */     Possible<String> channelId = Possible.absent();
/*     */     
/*     */     @JsonProperty("name")
/*     */     public void setName(Possible<String> name) {
/* 198 */       this.name = name;
/*     */     }
/*     */     @JsonProperty("avatar")
/*     */     public void setAvatar(Possible<String> avatar) {
/* 202 */       this.avatar = avatar;
/*     */     }
/*     */     @JsonProperty("channel_id")
/*     */     public void setChannelId(Possible<String> channelId) {
/* 206 */       this.channelId = channelId;
/*     */     }
/*     */     public Possible<String> name() {
/* 209 */       throw new UnsupportedOperationException();
/*     */     } public Possible<String> avatar() {
/* 211 */       throw new UnsupportedOperationException();
/*     */     } public Possible<String> channelId() {
/* 213 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableWebhookModifyRequest fromJson(Json json) {
/* 224 */     Builder builder = builder();
/* 225 */     if (json.name != null) {
/* 226 */       builder.name(json.name);
/*     */     }
/* 228 */     if (json.avatar != null) {
/* 229 */       builder.avatar(json.avatar);
/*     */     }
/* 231 */     if (json.channelId != null) {
/* 232 */       builder.channelId(json.channelId);
/*     */     }
/* 234 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableWebhookModifyRequest of(Possible<String> name, Possible<String> avatar, Possible<String> channelId) {
/* 245 */     return new ImmutableWebhookModifyRequest(name, avatar, channelId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableWebhookModifyRequest copyOf(WebhookModifyRequest instance) {
/* 256 */     if (instance instanceof ImmutableWebhookModifyRequest) {
/* 257 */       return (ImmutableWebhookModifyRequest)instance;
/*     */     }
/* 259 */     return builder()
/* 260 */       .from(instance)
/* 261 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isNamePresent() {
/* 265 */     return !this.name_absent;
/*     */   }
/*     */   
/*     */   public String nameOrElse(String defaultValue) {
/* 269 */     return !this.name_absent ? this.name_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isAvatarPresent() {
/* 273 */     return !this.avatar_absent;
/*     */   }
/*     */   
/*     */   public String avatarOrElse(String defaultValue) {
/* 277 */     return !this.avatar_absent ? this.avatar_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isChannelIdPresent() {
/* 281 */     return !this.channelId_absent;
/*     */   }
/*     */   
/*     */   public String channelIdOrElse(String defaultValue) {
/* 285 */     return !this.channelId_absent ? this.channelId_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 300 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "WebhookModifyRequest", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/* 312 */     private Possible<String> name_possible = Possible.absent();
/* 313 */     private Possible<String> avatar_possible = Possible.absent();
/* 314 */     private Possible<String> channelId_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(WebhookModifyRequest instance) {
/* 327 */       Objects.requireNonNull(instance, "instance");
/* 328 */       name(instance.name());
/* 329 */       avatar(instance.avatar());
/* 330 */       channelId(instance.channelId());
/* 331 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("name")
/*     */     public Builder name(Possible<String> value) {
/* 336 */       this.name_possible = value;
/* 337 */       return this;
/*     */     }
/*     */     
/*     */     public Builder name(String value) {
/* 341 */       this.name_possible = Possible.of(value);
/* 342 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("avatar")
/*     */     public Builder avatar(Possible<String> value) {
/* 347 */       this.avatar_possible = value;
/* 348 */       return this;
/*     */     }
/*     */     
/*     */     public Builder avatar(String value) {
/* 352 */       this.avatar_possible = Possible.of(value);
/* 353 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("channel_id")
/*     */     public Builder channelId(Possible<String> value) {
/* 358 */       this.channelId_possible = value;
/* 359 */       return this;
/*     */     }
/*     */     
/*     */     public Builder channelId(String value) {
/* 363 */       this.channelId_possible = Possible.of(value);
/* 364 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableWebhookModifyRequest build() {
/* 373 */       return new ImmutableWebhookModifyRequest(null, name_build(), avatar_build(), channelId_build());
/*     */     }
/*     */     
/*     */     private Possible<String> name_build() {
/* 377 */       return this.name_possible;
/*     */     }
/*     */     
/*     */     private Possible<String> avatar_build() {
/* 381 */       return this.avatar_possible;
/*     */     }
/*     */     
/*     */     private Possible<String> channelId_build() {
/* 385 */       return this.channelId_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableWebhookModifyRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */