/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "TemplateCreateGuildRequest", generator = "Immutables")
/*     */ public final class ImmutableTemplateCreateGuildRequest
/*     */   implements TemplateCreateGuildRequest
/*     */ {
/*     */   private final String name;
/*     */   private final String icon_value;
/*     */   private final boolean icon_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private ImmutableTemplateCreateGuildRequest(String name, Possible<String> icon) {
/*  52 */     this.initShim = new InitShim(); this.name = Objects.<String>requireNonNull(name, "name"); Possible<String> icon$impl = icon; this.icon_value = icon$impl.toOptional().orElse(null); this.icon_absent = icon$impl.isAbsent(); this.initShim = null; } private ImmutableTemplateCreateGuildRequest(ImmutableTemplateCreateGuildRequest original, String name, Possible<String> icon) { this.initShim = new InitShim();
/*     */     this.name = name;
/*     */     Possible<String> icon$impl = icon;
/*     */     this.icon_value = icon$impl.toOptional().orElse(null);
/*     */     this.icon_absent = icon$impl.isAbsent();
/*  57 */     this.initShim = null; } @Generated(from = "TemplateCreateGuildRequest", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/*  58 */       return "Cannot build TemplateCreateGuildRequest, attribute initializers form cycle " + attributes; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("name")
/*     */   public String name() {
/*  68 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("icon")
/*     */   public Possible<String> icon() {
/*  77 */     return this.icon_absent ? Possible.absent() : Possible.of(this.icon_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableTemplateCreateGuildRequest withName(String value) {
/*  87 */     String newValue = Objects.<String>requireNonNull(value, "name");
/*  88 */     if (this.name.equals(newValue)) return this; 
/*  89 */     return new ImmutableTemplateCreateGuildRequest(this, newValue, icon());
/*     */   }
/*     */   
/*     */   public ImmutableTemplateCreateGuildRequest withIcon(Possible<String> value) {
/*  93 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  94 */     return new ImmutableTemplateCreateGuildRequest(this, this.name, newValue);
/*     */   }
/*     */   
/*     */   public ImmutableTemplateCreateGuildRequest withIcon(String value) {
/*  98 */     Possible<String> newValue = Possible.of(value);
/*  99 */     return new ImmutableTemplateCreateGuildRequest(this, this.name, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 108 */     if (this == another) return true; 
/* 109 */     return (another instanceof ImmutableTemplateCreateGuildRequest && 
/* 110 */       equalTo(0, (ImmutableTemplateCreateGuildRequest)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableTemplateCreateGuildRequest another) {
/* 114 */     return (this.name.equals(another.name) && 
/* 115 */       icon().equals(another.icon()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 124 */     int h = 5381;
/* 125 */     h += (h << 5) + this.name.hashCode();
/* 126 */     h += (h << 5) + icon().hashCode();
/* 127 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 136 */     return "TemplateCreateGuildRequest{name=" + this.name + ", icon=" + 
/*     */       
/* 138 */       icon().toString() + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "TemplateCreateGuildRequest", generator = "Immutables")
/*     */   static final class Json
/*     */     implements TemplateCreateGuildRequest
/*     */   {
/*     */     String name;
/*     */ 
/*     */     
/* 153 */     Possible<String> icon = Possible.absent();
/*     */     
/*     */     @JsonProperty("name")
/*     */     public void setName(String name) {
/* 157 */       this.name = name;
/*     */     }
/*     */     @JsonProperty("icon")
/*     */     public void setIcon(Possible<String> icon) {
/* 161 */       this.icon = icon;
/*     */     }
/*     */     public String name() {
/* 164 */       throw new UnsupportedOperationException();
/*     */     } public Possible<String> icon() {
/* 166 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableTemplateCreateGuildRequest fromJson(Json json) {
/* 177 */     Builder builder = builder();
/* 178 */     if (json.name != null) {
/* 179 */       builder.name(json.name);
/*     */     }
/* 181 */     if (json.icon != null) {
/* 182 */       builder.icon(json.icon);
/*     */     }
/* 184 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableTemplateCreateGuildRequest of(String name, Possible<String> icon) {
/* 194 */     return new ImmutableTemplateCreateGuildRequest(name, icon);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableTemplateCreateGuildRequest copyOf(TemplateCreateGuildRequest instance) {
/* 205 */     if (instance instanceof ImmutableTemplateCreateGuildRequest) {
/* 206 */       return (ImmutableTemplateCreateGuildRequest)instance;
/*     */     }
/* 208 */     return builder()
/* 209 */       .from(instance)
/* 210 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isIconPresent() {
/* 214 */     return !this.icon_absent;
/*     */   }
/*     */   
/*     */   public String iconOrElse(String defaultValue) {
/* 218 */     return !this.icon_absent ? this.icon_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 232 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "TemplateCreateGuildRequest", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_NAME = 1L;
/*     */ 
/*     */ 
/*     */     
/* 245 */     private long initBits = 1L;
/*     */     
/* 247 */     private Possible<String> icon_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String name;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(TemplateCreateGuildRequest instance) {
/* 261 */       Objects.requireNonNull(instance, "instance");
/* 262 */       name(instance.name());
/* 263 */       icon(instance.icon());
/* 264 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("name")
/*     */     public final Builder name(String name) {
/* 274 */       this.name = Objects.<String>requireNonNull(name, "name");
/* 275 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 276 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("icon")
/*     */     public Builder icon(Possible<String> value) {
/* 281 */       this.icon_possible = value;
/* 282 */       return this;
/*     */     }
/*     */     
/*     */     public Builder icon(String value) {
/* 286 */       this.icon_possible = Possible.of(value);
/* 287 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableTemplateCreateGuildRequest build() {
/* 296 */       if (this.initBits != 0L) {
/* 297 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 299 */       return new ImmutableTemplateCreateGuildRequest(null, this.name, icon_build());
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 303 */       List<String> attributes = new ArrayList<>();
/* 304 */       if ((this.initBits & 0x1L) != 0L) attributes.add("name"); 
/* 305 */       return "Cannot build TemplateCreateGuildRequest, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Possible<String> icon_build() {
/* 309 */       return this.icon_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableTemplateCreateGuildRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */