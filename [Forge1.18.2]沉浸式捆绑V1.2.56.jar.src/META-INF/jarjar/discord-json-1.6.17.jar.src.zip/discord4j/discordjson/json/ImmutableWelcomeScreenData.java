/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "WelcomeScreenData", generator = "Immutables")
/*     */ public final class ImmutableWelcomeScreenData
/*     */   implements WelcomeScreenData
/*     */ {
/*     */   private final String description;
/*     */   private final List<WelcomeScreenChannelData> welcomeChannels;
/*     */   
/*     */   private ImmutableWelcomeScreenData(Optional<String> description, Iterable<? extends WelcomeScreenChannelData> welcomeChannels) {
/*  34 */     this.description = description.orElse(null);
/*  35 */     this.welcomeChannels = createUnmodifiableList(false, createSafeList(welcomeChannels, true, false));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableWelcomeScreenData(ImmutableWelcomeScreenData original, String description, List<WelcomeScreenChannelData> welcomeChannels) {
/*  42 */     this.description = description;
/*  43 */     this.welcomeChannels = welcomeChannels;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("description")
/*     */   public Optional<String> description() {
/*  52 */     return Optional.ofNullable(this.description);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("welcome_channels")
/*     */   public List<WelcomeScreenChannelData> welcomeChannels() {
/*  61 */     return this.welcomeChannels;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableWelcomeScreenData withDescription(String value) {
/*  70 */     String newValue = Objects.<String>requireNonNull(value, "description");
/*  71 */     if (Objects.equals(this.description, newValue)) return this; 
/*  72 */     return new ImmutableWelcomeScreenData(this, newValue, this.welcomeChannels);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableWelcomeScreenData withDescription(Optional<String> optional) {
/*  82 */     String value = optional.orElse(null);
/*  83 */     if (Objects.equals(this.description, value)) return this; 
/*  84 */     return new ImmutableWelcomeScreenData(this, value, this.welcomeChannels);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableWelcomeScreenData withWelcomeChannels(WelcomeScreenChannelData... elements) {
/*  93 */     List<WelcomeScreenChannelData> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/*  94 */     return new ImmutableWelcomeScreenData(this, this.description, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableWelcomeScreenData withWelcomeChannels(Iterable<? extends WelcomeScreenChannelData> elements) {
/* 104 */     if (this.welcomeChannels == elements) return this; 
/* 105 */     List<WelcomeScreenChannelData> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 106 */     return new ImmutableWelcomeScreenData(this, this.description, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 115 */     if (this == another) return true; 
/* 116 */     return (another instanceof ImmutableWelcomeScreenData && 
/* 117 */       equalTo(0, (ImmutableWelcomeScreenData)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableWelcomeScreenData another) {
/* 121 */     return (Objects.equals(this.description, another.description) && this.welcomeChannels
/* 122 */       .equals(another.welcomeChannels));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 131 */     int h = 5381;
/* 132 */     h += (h << 5) + Objects.hashCode(this.description);
/* 133 */     h += (h << 5) + this.welcomeChannels.hashCode();
/* 134 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 143 */     StringBuilder builder = new StringBuilder("WelcomeScreenData{");
/* 144 */     if (this.description != null) {
/* 145 */       builder.append("description=").append(this.description);
/*     */     }
/* 147 */     if (builder.length() > 18) builder.append(", "); 
/* 148 */     builder.append("welcomeChannels=").append(this.welcomeChannels);
/* 149 */     return builder.append("}").toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "WelcomeScreenData", generator = "Immutables")
/*     */   static final class Json
/*     */     implements WelcomeScreenData
/*     */   {
/* 161 */     Optional<String> description = Optional.empty();
/* 162 */     List<WelcomeScreenChannelData> welcomeChannels = Collections.emptyList();
/*     */     @JsonProperty("description")
/*     */     public void setDescription(Optional<String> description) {
/* 165 */       this.description = description;
/*     */     }
/*     */     @JsonProperty("welcome_channels")
/*     */     public void setWelcomeChannels(List<WelcomeScreenChannelData> welcomeChannels) {
/* 169 */       this.welcomeChannels = welcomeChannels;
/*     */     }
/*     */     public Optional<String> description() {
/* 172 */       throw new UnsupportedOperationException();
/*     */     } public List<WelcomeScreenChannelData> welcomeChannels() {
/* 174 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableWelcomeScreenData fromJson(Json json) {
/* 185 */     Builder builder = builder();
/* 186 */     if (json.description != null) {
/* 187 */       builder.description(json.description);
/*     */     }
/* 189 */     if (json.welcomeChannels != null) {
/* 190 */       builder.addAllWelcomeChannels(json.welcomeChannels);
/*     */     }
/* 192 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableWelcomeScreenData of(Optional<String> description, List<WelcomeScreenChannelData> welcomeChannels) {
/* 202 */     return of(description, welcomeChannels);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableWelcomeScreenData of(Optional<String> description, Iterable<? extends WelcomeScreenChannelData> welcomeChannels) {
/* 212 */     return new ImmutableWelcomeScreenData(description, welcomeChannels);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableWelcomeScreenData copyOf(WelcomeScreenData instance) {
/* 223 */     if (instance instanceof ImmutableWelcomeScreenData) {
/* 224 */       return (ImmutableWelcomeScreenData)instance;
/*     */     }
/* 226 */     return builder()
/* 227 */       .from(instance)
/* 228 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 242 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "WelcomeScreenData", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private String description;
/*     */ 
/*     */ 
/*     */     
/* 255 */     private List<WelcomeScreenChannelData> welcomeChannels = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(WelcomeScreenData instance) {
/* 269 */       Objects.requireNonNull(instance, "instance");
/* 270 */       Optional<String> descriptionOptional = instance.description();
/* 271 */       if (descriptionOptional.isPresent()) {
/* 272 */         description(descriptionOptional);
/*     */       }
/* 274 */       addAllWelcomeChannels(instance.welcomeChannels());
/* 275 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder description(String description) {
/* 284 */       this.description = Objects.<String>requireNonNull(description, "description");
/* 285 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("description")
/*     */     public final Builder description(Optional<String> description) {
/* 295 */       this.description = description.orElse(null);
/* 296 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addWelcomeChannel(WelcomeScreenChannelData element) {
/* 305 */       this.welcomeChannels.add(Objects.<WelcomeScreenChannelData>requireNonNull(element, "welcomeChannels element"));
/* 306 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addWelcomeChannels(WelcomeScreenChannelData... elements) {
/* 315 */       for (WelcomeScreenChannelData element : elements) {
/* 316 */         this.welcomeChannels.add(Objects.<WelcomeScreenChannelData>requireNonNull(element, "welcomeChannels element"));
/*     */       }
/* 318 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("welcome_channels")
/*     */     public final Builder welcomeChannels(Iterable<? extends WelcomeScreenChannelData> elements) {
/* 329 */       this.welcomeChannels.clear();
/* 330 */       return addAllWelcomeChannels(elements);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addAllWelcomeChannels(Iterable<? extends WelcomeScreenChannelData> elements) {
/* 339 */       for (WelcomeScreenChannelData element : elements) {
/* 340 */         this.welcomeChannels.add(Objects.<WelcomeScreenChannelData>requireNonNull(element, "welcomeChannels element"));
/*     */       }
/* 342 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableWelcomeScreenData build() {
/* 351 */       return new ImmutableWelcomeScreenData(null, this.description, ImmutableWelcomeScreenData.createUnmodifiableList(true, (List)this.welcomeChannels));
/*     */     }
/*     */     private Builder() {} }
/*     */   
/*     */   private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
/*     */     ArrayList<T> list;
/* 357 */     if (iterable instanceof Collection) {
/* 358 */       int size = ((Collection)iterable).size();
/* 359 */       if (size == 0) return Collections.emptyList(); 
/* 360 */       list = new ArrayList<>();
/*     */     } else {
/* 362 */       list = new ArrayList<>();
/*     */     } 
/* 364 */     for (T element : iterable) {
/* 365 */       if (skipNulls && element == null)
/* 366 */         continue;  if (checkNulls) Objects.requireNonNull(element, "element"); 
/* 367 */       list.add(element);
/*     */     } 
/* 369 */     return list;
/*     */   }
/*     */   
/*     */   private static <T> List<T> createUnmodifiableList(boolean clone, List<T> list) {
/* 373 */     switch (list.size()) { case 0:
/* 374 */         return Collections.emptyList();
/* 375 */       case 1: return Collections.singletonList(list.get(0)); }
/*     */     
/* 377 */     if (clone) {
/* 378 */       return Collections.unmodifiableList(new ArrayList<>(list));
/*     */     }
/* 380 */     if (list instanceof ArrayList) {
/* 381 */       ((ArrayList)list).trimToSize();
/*     */     }
/* 383 */     return Collections.unmodifiableList(list);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableWelcomeScreenData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */