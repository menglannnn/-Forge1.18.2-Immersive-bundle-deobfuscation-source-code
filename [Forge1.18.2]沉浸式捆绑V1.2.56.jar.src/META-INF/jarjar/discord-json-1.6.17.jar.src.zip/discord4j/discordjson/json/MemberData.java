/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ @JsonSerialize(as = ImmutableMemberData.class)
/*    */ @JsonDeserialize(as = ImmutableMemberData.class)
/*    */ @Immutable
/*    */ public interface MemberData
/*    */   extends PartialMemberData {
/*    */   static ImmutableMemberData.Builder builder() {
/* 14 */     return ImmutableMemberData.builder();
/*    */   }
/*    */   
/*    */   UserData user();
/*    */   
/*    */   Possible<Boolean> pending();
/*    */   
/*    */   Possible<String> permissions();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\MemberData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */