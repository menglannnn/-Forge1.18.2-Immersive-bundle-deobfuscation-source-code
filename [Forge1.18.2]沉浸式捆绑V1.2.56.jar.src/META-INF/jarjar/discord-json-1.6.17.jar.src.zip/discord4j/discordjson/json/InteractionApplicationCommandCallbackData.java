/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import java.util.List;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ @JsonSerialize(as = ImmutableInteractionApplicationCommandCallbackData.class)
/*    */ @JsonDeserialize(as = ImmutableInteractionApplicationCommandCallbackData.class)
/*    */ @Immutable
/*    */ public interface InteractionApplicationCommandCallbackData
/*    */ {
/*    */   static ImmutableInteractionApplicationCommandCallbackData.Builder builder() {
/* 17 */     return ImmutableInteractionApplicationCommandCallbackData.builder();
/*    */   }
/*    */   
/*    */   Possible<Boolean> tts();
/*    */   
/*    */   Possible<String> content();
/*    */   
/*    */   Possible<List<EmbedData>> embeds();
/*    */   
/*    */   @JsonProperty("allowed_mentions")
/*    */   Possible<AllowedMentionsData> allowedMentions();
/*    */   
/*    */   Possible<Integer> flags();
/*    */   
/*    */   Possible<List<ComponentData>> components();
/*    */   
/*    */   Possible<List<ApplicationCommandOptionChoiceData>> choices();
/*    */   
/*    */   @JsonProperty("custom_id")
/*    */   Possible<String> customId();
/*    */   
/*    */   Possible<String> title();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\InteractionApplicationCommandCallbackData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */