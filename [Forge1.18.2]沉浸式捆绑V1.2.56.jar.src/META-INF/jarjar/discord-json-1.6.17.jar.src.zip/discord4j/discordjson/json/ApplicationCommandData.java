/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.Id;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.Optional;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ @JsonSerialize(as = ImmutableApplicationCommandData.class)
/*    */ @JsonDeserialize(as = ImmutableApplicationCommandData.class)
/*    */ @Immutable
/*    */ public interface ApplicationCommandData
/*    */ {
/*    */   static ImmutableApplicationCommandData.Builder builder() {
/* 20 */     return ImmutableApplicationCommandData.builder();
/*    */   }
/*    */   
/*    */   Id id();
/*    */   
/*    */   Id version();
/*    */   
/*    */   @JsonProperty("guild_id")
/*    */   Possible<Id> guildId();
/*    */   
/*    */   Possible<Integer> type();
/*    */   
/*    */   @JsonProperty("application_id")
/*    */   Id applicationId();
/*    */   
/*    */   String name();
/*    */   
/*    */   @JsonProperty("name_localizations")
/*    */   Possible<Optional<Map<String, String>>> nameLocalizations();
/*    */   
/*    */   String description();
/*    */   
/*    */   @JsonProperty("description_localizations")
/*    */   Possible<Optional<Map<String, String>>> descriptionLocalizations();
/*    */   
/*    */   Possible<List<ApplicationCommandOptionData>> options();
/*    */   
/*    */   @JsonProperty("dm_permission")
/*    */   Possible<Boolean> dmPermission();
/*    */   
/*    */   @JsonProperty("default_permission")
/*    */   @Deprecated
/*    */   Possible<Boolean> defaultPermission();
/*    */   
/*    */   @JsonProperty("default_member_permissions")
/*    */   Optional<String> defaultMemberPermissions();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ApplicationCommandData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */