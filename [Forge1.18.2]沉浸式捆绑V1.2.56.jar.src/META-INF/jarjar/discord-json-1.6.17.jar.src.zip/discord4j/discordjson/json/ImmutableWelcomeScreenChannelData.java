/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "WelcomeScreenChannelData", generator = "Immutables")
/*     */ public final class ImmutableWelcomeScreenChannelData
/*     */   implements WelcomeScreenChannelData
/*     */ {
/*     */   private final String channelId;
/*     */   private final String description;
/*     */   private final String emojiId;
/*     */   private final String emojiName;
/*     */   
/*     */   private ImmutableWelcomeScreenChannelData(String channelId, String description, Optional<String> emojiId, Optional<String> emojiName) {
/*  36 */     this.channelId = Objects.<String>requireNonNull(channelId, "channelId");
/*  37 */     this.description = Objects.<String>requireNonNull(description, "description");
/*  38 */     this.emojiId = emojiId.orElse(null);
/*  39 */     this.emojiName = emojiName.orElse(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableWelcomeScreenChannelData(ImmutableWelcomeScreenChannelData original, String channelId, String description, String emojiId, String emojiName) {
/*  48 */     this.channelId = channelId;
/*  49 */     this.description = description;
/*  50 */     this.emojiId = emojiId;
/*  51 */     this.emojiName = emojiName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("channel_id")
/*     */   public String channelId() {
/*  60 */     return this.channelId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("description")
/*     */   public String description() {
/*  69 */     return this.description;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("emoji_id")
/*     */   public Optional<String> emojiId() {
/*  78 */     return Optional.ofNullable(this.emojiId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("emoji_name")
/*     */   public Optional<String> emojiName() {
/*  87 */     return Optional.ofNullable(this.emojiName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableWelcomeScreenChannelData withChannelId(String value) {
/*  97 */     String newValue = Objects.<String>requireNonNull(value, "channelId");
/*  98 */     if (this.channelId.equals(newValue)) return this; 
/*  99 */     return new ImmutableWelcomeScreenChannelData(this, newValue, this.description, this.emojiId, this.emojiName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableWelcomeScreenChannelData withDescription(String value) {
/* 109 */     String newValue = Objects.<String>requireNonNull(value, "description");
/* 110 */     if (this.description.equals(newValue)) return this; 
/* 111 */     return new ImmutableWelcomeScreenChannelData(this, this.channelId, newValue, this.emojiId, this.emojiName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableWelcomeScreenChannelData withEmojiId(String value) {
/* 120 */     String newValue = Objects.<String>requireNonNull(value, "emojiId");
/* 121 */     if (Objects.equals(this.emojiId, newValue)) return this; 
/* 122 */     return new ImmutableWelcomeScreenChannelData(this, this.channelId, this.description, newValue, this.emojiName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableWelcomeScreenChannelData withEmojiId(Optional<String> optional) {
/* 132 */     String value = optional.orElse(null);
/* 133 */     if (Objects.equals(this.emojiId, value)) return this; 
/* 134 */     return new ImmutableWelcomeScreenChannelData(this, this.channelId, this.description, value, this.emojiName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableWelcomeScreenChannelData withEmojiName(String value) {
/* 143 */     String newValue = Objects.<String>requireNonNull(value, "emojiName");
/* 144 */     if (Objects.equals(this.emojiName, newValue)) return this; 
/* 145 */     return new ImmutableWelcomeScreenChannelData(this, this.channelId, this.description, this.emojiId, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableWelcomeScreenChannelData withEmojiName(Optional<String> optional) {
/* 155 */     String value = optional.orElse(null);
/* 156 */     if (Objects.equals(this.emojiName, value)) return this; 
/* 157 */     return new ImmutableWelcomeScreenChannelData(this, this.channelId, this.description, this.emojiId, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 166 */     if (this == another) return true; 
/* 167 */     return (another instanceof ImmutableWelcomeScreenChannelData && 
/* 168 */       equalTo(0, (ImmutableWelcomeScreenChannelData)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableWelcomeScreenChannelData another) {
/* 172 */     return (this.channelId.equals(another.channelId) && this.description
/* 173 */       .equals(another.description) && 
/* 174 */       Objects.equals(this.emojiId, another.emojiId) && 
/* 175 */       Objects.equals(this.emojiName, another.emojiName));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 184 */     int h = 5381;
/* 185 */     h += (h << 5) + this.channelId.hashCode();
/* 186 */     h += (h << 5) + this.description.hashCode();
/* 187 */     h += (h << 5) + Objects.hashCode(this.emojiId);
/* 188 */     h += (h << 5) + Objects.hashCode(this.emojiName);
/* 189 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 198 */     StringBuilder builder = new StringBuilder("WelcomeScreenChannelData{");
/* 199 */     builder.append("channelId=").append(this.channelId);
/* 200 */     builder.append(", ");
/* 201 */     builder.append("description=").append(this.description);
/* 202 */     if (this.emojiId != null) {
/* 203 */       builder.append(", ");
/* 204 */       builder.append("emojiId=").append(this.emojiId);
/*     */     } 
/* 206 */     if (this.emojiName != null) {
/* 207 */       builder.append(", ");
/* 208 */       builder.append("emojiName=").append(this.emojiName);
/*     */     } 
/* 210 */     return builder.append("}").toString();
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "WelcomeScreenChannelData", generator = "Immutables")
/*     */   static final class Json
/*     */     implements WelcomeScreenChannelData
/*     */   {
/*     */     String channelId;
/*     */     
/*     */     String description;
/* 224 */     Optional<String> emojiId = Optional.empty();
/* 225 */     Optional<String> emojiName = Optional.empty();
/*     */     @JsonProperty("channel_id")
/*     */     public void setChannelId(String channelId) {
/* 228 */       this.channelId = channelId;
/*     */     }
/*     */     @JsonProperty("description")
/*     */     public void setDescription(String description) {
/* 232 */       this.description = description;
/*     */     }
/*     */     @JsonProperty("emoji_id")
/*     */     public void setEmojiId(Optional<String> emojiId) {
/* 236 */       this.emojiId = emojiId;
/*     */     }
/*     */     @JsonProperty("emoji_name")
/*     */     public void setEmojiName(Optional<String> emojiName) {
/* 240 */       this.emojiName = emojiName;
/*     */     }
/*     */     public String channelId() {
/* 243 */       throw new UnsupportedOperationException();
/*     */     } public String description() {
/* 245 */       throw new UnsupportedOperationException();
/*     */     } public Optional<String> emojiId() {
/* 247 */       throw new UnsupportedOperationException();
/*     */     } public Optional<String> emojiName() {
/* 249 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableWelcomeScreenChannelData fromJson(Json json) {
/* 260 */     Builder builder = builder();
/* 261 */     if (json.channelId != null) {
/* 262 */       builder.channelId(json.channelId);
/*     */     }
/* 264 */     if (json.description != null) {
/* 265 */       builder.description(json.description);
/*     */     }
/* 267 */     if (json.emojiId != null) {
/* 268 */       builder.emojiId(json.emojiId);
/*     */     }
/* 270 */     if (json.emojiName != null) {
/* 271 */       builder.emojiName(json.emojiName);
/*     */     }
/* 273 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableWelcomeScreenChannelData of(String channelId, String description, Optional<String> emojiId, Optional<String> emojiName) {
/* 285 */     return new ImmutableWelcomeScreenChannelData(channelId, description, emojiId, emojiName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableWelcomeScreenChannelData copyOf(WelcomeScreenChannelData instance) {
/* 296 */     if (instance instanceof ImmutableWelcomeScreenChannelData) {
/* 297 */       return (ImmutableWelcomeScreenChannelData)instance;
/*     */     }
/* 299 */     return builder()
/* 300 */       .from(instance)
/* 301 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 317 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "WelcomeScreenChannelData", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_CHANNEL_ID = 1L;
/*     */ 
/*     */     
/*     */     private static final long INIT_BIT_DESCRIPTION = 2L;
/*     */ 
/*     */     
/* 331 */     private long initBits = 3L;
/*     */ 
/*     */ 
/*     */     
/*     */     private String channelId;
/*     */ 
/*     */     
/*     */     private String description;
/*     */ 
/*     */     
/*     */     private String emojiId;
/*     */ 
/*     */     
/*     */     private String emojiName;
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(WelcomeScreenChannelData instance) {
/* 349 */       Objects.requireNonNull(instance, "instance");
/* 350 */       channelId(instance.channelId());
/* 351 */       description(instance.description());
/* 352 */       Optional<String> emojiIdOptional = instance.emojiId();
/* 353 */       if (emojiIdOptional.isPresent()) {
/* 354 */         emojiId(emojiIdOptional);
/*     */       }
/* 356 */       Optional<String> emojiNameOptional = instance.emojiName();
/* 357 */       if (emojiNameOptional.isPresent()) {
/* 358 */         emojiName(emojiNameOptional);
/*     */       }
/* 360 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("channel_id")
/*     */     public final Builder channelId(String channelId) {
/* 370 */       this.channelId = Objects.<String>requireNonNull(channelId, "channelId");
/* 371 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 372 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("description")
/*     */     public final Builder description(String description) {
/* 382 */       this.description = Objects.<String>requireNonNull(description, "description");
/* 383 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 384 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder emojiId(String emojiId) {
/* 393 */       this.emojiId = Objects.<String>requireNonNull(emojiId, "emojiId");
/* 394 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("emoji_id")
/*     */     public final Builder emojiId(Optional<String> emojiId) {
/* 404 */       this.emojiId = emojiId.orElse(null);
/* 405 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder emojiName(String emojiName) {
/* 414 */       this.emojiName = Objects.<String>requireNonNull(emojiName, "emojiName");
/* 415 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("emoji_name")
/*     */     public final Builder emojiName(Optional<String> emojiName) {
/* 425 */       this.emojiName = emojiName.orElse(null);
/* 426 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableWelcomeScreenChannelData build() {
/* 435 */       if (this.initBits != 0L) {
/* 436 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 438 */       return new ImmutableWelcomeScreenChannelData(null, this.channelId, this.description, this.emojiId, this.emojiName);
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 442 */       List<String> attributes = new ArrayList<>();
/* 443 */       if ((this.initBits & 0x1L) != 0L) attributes.add("channelId"); 
/* 444 */       if ((this.initBits & 0x2L) != 0L) attributes.add("description"); 
/* 445 */       return "Cannot build WelcomeScreenChannelData, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableWelcomeScreenChannelData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */