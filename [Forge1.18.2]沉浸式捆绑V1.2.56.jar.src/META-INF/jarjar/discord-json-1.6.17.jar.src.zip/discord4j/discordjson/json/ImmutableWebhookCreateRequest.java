/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "WebhookCreateRequest", generator = "Immutables")
/*     */ public final class ImmutableWebhookCreateRequest
/*     */   implements WebhookCreateRequest
/*     */ {
/*     */   private final String name;
/*     */   private final String avatar_value;
/*     */   private final boolean avatar_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private ImmutableWebhookCreateRequest(String name, Possible<Optional<String>> avatar) {
/*  55 */     this.initShim = new InitShim(); this.name = Objects.<String>requireNonNull(name, "name"); Possible<Optional<String>> avatar$impl = avatar; this.avatar_value = Possible.flatOpt(avatar$impl).orElse(null); this.avatar_absent = avatar$impl.isAbsent(); this.initShim = null; } private ImmutableWebhookCreateRequest(ImmutableWebhookCreateRequest original, String name, Possible<Optional<String>> avatar) { this.initShim = new InitShim();
/*     */     this.name = name;
/*     */     Possible<Optional<String>> avatar$impl = avatar;
/*     */     this.avatar_value = Possible.flatOpt(avatar$impl).orElse(null);
/*     */     this.avatar_absent = avatar$impl.isAbsent();
/*  60 */     this.initShim = null; } @Generated(from = "WebhookCreateRequest", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/*  61 */       return "Cannot build WebhookCreateRequest, attribute initializers form cycle " + attributes; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("name")
/*     */   public String name() {
/*  71 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("avatar")
/*     */   public Possible<Optional<String>> avatar() {
/*  80 */     return this.avatar_absent ? Possible.absent() : 
/*  81 */       Possible.of(Optional.ofNullable(this.avatar_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableWebhookCreateRequest withName(String value) {
/*  91 */     String newValue = Objects.<String>requireNonNull(value, "name");
/*  92 */     if (this.name.equals(newValue)) return this; 
/*  93 */     return new ImmutableWebhookCreateRequest(this, newValue, avatar());
/*     */   }
/*     */   
/*     */   public ImmutableWebhookCreateRequest withAvatar(Possible<Optional<String>> value) {
/*  97 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/*  98 */     return new ImmutableWebhookCreateRequest(this, this.name, newValue);
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public ImmutableWebhookCreateRequest withAvatar(@Nullable String value) {
/* 103 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 104 */     return new ImmutableWebhookCreateRequest(this, this.name, newValue);
/*     */   }
/*     */   
/*     */   public ImmutableWebhookCreateRequest withAvatarOrNull(@Nullable String value) {
/* 108 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 109 */     return new ImmutableWebhookCreateRequest(this, this.name, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 118 */     if (this == another) return true; 
/* 119 */     return (another instanceof ImmutableWebhookCreateRequest && 
/* 120 */       equalTo(0, (ImmutableWebhookCreateRequest)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableWebhookCreateRequest another) {
/* 124 */     return (this.name.equals(another.name) && 
/* 125 */       avatar().equals(another.avatar()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 134 */     int h = 5381;
/* 135 */     h += (h << 5) + this.name.hashCode();
/* 136 */     h += (h << 5) + avatar().hashCode();
/* 137 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 146 */     return "WebhookCreateRequest{name=" + this.name + ", avatar=" + 
/*     */       
/* 148 */       avatar().toString() + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "WebhookCreateRequest", generator = "Immutables")
/*     */   static final class Json
/*     */     implements WebhookCreateRequest
/*     */   {
/*     */     String name;
/*     */ 
/*     */     
/* 163 */     Possible<Optional<String>> avatar = Possible.absent();
/*     */     
/*     */     @JsonProperty("name")
/*     */     public void setName(String name) {
/* 167 */       this.name = name;
/*     */     }
/*     */     @JsonProperty("avatar")
/*     */     public void setAvatar(Possible<Optional<String>> avatar) {
/* 171 */       this.avatar = avatar;
/*     */     }
/*     */     public String name() {
/* 174 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Optional<String>> avatar() {
/* 176 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableWebhookCreateRequest fromJson(Json json) {
/* 187 */     Builder builder = builder();
/* 188 */     if (json.name != null) {
/* 189 */       builder.name(json.name);
/*     */     }
/* 191 */     if (json.avatar != null) {
/* 192 */       builder.avatar(json.avatar);
/*     */     }
/* 194 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableWebhookCreateRequest of(String name, Possible<Optional<String>> avatar) {
/* 204 */     return new ImmutableWebhookCreateRequest(name, avatar);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableWebhookCreateRequest copyOf(WebhookCreateRequest instance) {
/* 215 */     if (instance instanceof ImmutableWebhookCreateRequest) {
/* 216 */       return (ImmutableWebhookCreateRequest)instance;
/*     */     }
/* 218 */     return builder()
/* 219 */       .from(instance)
/* 220 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isAvatarPresent() {
/* 224 */     return !this.avatar_absent;
/*     */   }
/*     */   
/*     */   public String avatarOrElse(String defaultValue) {
/* 228 */     return !this.avatar_absent ? this.avatar_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 242 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "WebhookCreateRequest", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_NAME = 1L;
/*     */ 
/*     */ 
/*     */     
/* 255 */     private long initBits = 1L;
/*     */     
/* 257 */     private Possible<Optional<String>> avatar_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String name;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(WebhookCreateRequest instance) {
/* 271 */       Objects.requireNonNull(instance, "instance");
/* 272 */       name(instance.name());
/* 273 */       avatar(instance.avatar());
/* 274 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("name")
/*     */     public final Builder name(String name) {
/* 284 */       this.name = Objects.<String>requireNonNull(name, "name");
/* 285 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 286 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("avatar")
/*     */     public Builder avatar(Possible<Optional<String>> value) {
/* 291 */       this.avatar_possible = value;
/* 292 */       return this;
/*     */     }
/*     */     
/*     */     @Deprecated
/*     */     public Builder avatar(@Nullable String value) {
/* 297 */       this.avatar_possible = Possible.of(Optional.ofNullable(value));
/* 298 */       return this;
/*     */     }
/*     */     
/*     */     public Builder avatarOrNull(@Nullable String value) {
/* 302 */       this.avatar_possible = Possible.of(Optional.ofNullable(value));
/* 303 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableWebhookCreateRequest build() {
/* 312 */       if (this.initBits != 0L) {
/* 313 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 315 */       return new ImmutableWebhookCreateRequest(null, this.name, avatar_build());
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 319 */       List<String> attributes = new ArrayList<>();
/* 320 */       if ((this.initBits & 0x1L) != 0L) attributes.add("name"); 
/* 321 */       return "Cannot build WebhookCreateRequest, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Possible<Optional<String>> avatar_build() {
/* 325 */       return this.avatar_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableWebhookCreateRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */