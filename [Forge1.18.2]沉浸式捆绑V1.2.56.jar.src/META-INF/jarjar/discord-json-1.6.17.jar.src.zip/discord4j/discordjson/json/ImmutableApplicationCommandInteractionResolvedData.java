/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "ApplicationCommandInteractionResolvedData", generator = "Immutables")
/*     */ public final class ImmutableApplicationCommandInteractionResolvedData
/*     */   implements ApplicationCommandInteractionResolvedData
/*     */ {
/*     */   private final Map<String, UserData> users_value;
/*     */   private final boolean users_absent;
/*     */   private final Map<String, ResolvedMemberData> members_value;
/*     */   private final boolean members_absent;
/*     */   private final Map<String, ResolvedChannelData> channels_value;
/*     */   private final boolean channels_absent;
/*     */   private final Map<String, RoleData> roles_value;
/*     */   private final boolean roles_absent;
/*     */   private final Map<String, MessageData> messages_value;
/*     */   private final boolean messages_absent;
/*     */   private final Map<String, AttachmentData> attachments_value;
/*     */   private final boolean attachments_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private ImmutableApplicationCommandInteractionResolvedData(Possible<Map<String, UserData>> users, Possible<Map<String, ResolvedMemberData>> members, Possible<Map<String, ResolvedChannelData>> channels, Possible<Map<String, RoleData>> roles, Possible<Map<String, MessageData>> messages, Possible<Map<String, AttachmentData>> attachments) {
/*  47 */     Possible<Map<String, UserData>> users$impl = users;
/*  48 */     Possible<Map<String, ResolvedMemberData>> members$impl = members;
/*  49 */     Possible<Map<String, ResolvedChannelData>> channels$impl = channels;
/*  50 */     Possible<Map<String, RoleData>> roles$impl = roles;
/*  51 */     Possible<Map<String, MessageData>> messages$impl = messages;
/*  52 */     Possible<Map<String, AttachmentData>> attachments$impl = attachments;
/*  53 */     this.users_value = users$impl.toOptional().orElse(null);
/*  54 */     this.users_absent = users$impl.isAbsent();
/*  55 */     this.members_value = members$impl.toOptional().orElse(null);
/*  56 */     this.members_absent = members$impl.isAbsent();
/*  57 */     this.channels_value = channels$impl.toOptional().orElse(null);
/*  58 */     this.channels_absent = channels$impl.isAbsent();
/*  59 */     this.roles_value = roles$impl.toOptional().orElse(null);
/*  60 */     this.roles_absent = roles$impl.isAbsent();
/*  61 */     this.messages_value = messages$impl.toOptional().orElse(null);
/*  62 */     this.messages_absent = messages$impl.isAbsent();
/*  63 */     this.attachments_value = attachments$impl.toOptional().orElse(null);
/*  64 */     this.attachments_absent = attachments$impl.isAbsent();
/*  65 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableApplicationCommandInteractionResolvedData(ImmutableApplicationCommandInteractionResolvedData original, Possible<Map<String, UserData>> users, Possible<Map<String, ResolvedMemberData>> members, Possible<Map<String, ResolvedChannelData>> channels, Possible<Map<String, RoleData>> roles, Possible<Map<String, MessageData>> messages, Possible<Map<String, AttachmentData>> attachments) {
/*  76 */     Possible<Map<String, UserData>> users$impl = users;
/*  77 */     Possible<Map<String, ResolvedMemberData>> members$impl = members;
/*  78 */     Possible<Map<String, ResolvedChannelData>> channels$impl = channels;
/*  79 */     Possible<Map<String, RoleData>> roles$impl = roles;
/*  80 */     Possible<Map<String, MessageData>> messages$impl = messages;
/*  81 */     Possible<Map<String, AttachmentData>> attachments$impl = attachments;
/*  82 */     this.users_value = users$impl.toOptional().orElse(null);
/*  83 */     this.users_absent = users$impl.isAbsent();
/*  84 */     this.members_value = members$impl.toOptional().orElse(null);
/*  85 */     this.members_absent = members$impl.isAbsent();
/*  86 */     this.channels_value = channels$impl.toOptional().orElse(null);
/*  87 */     this.channels_absent = channels$impl.isAbsent();
/*  88 */     this.roles_value = roles$impl.toOptional().orElse(null);
/*  89 */     this.roles_absent = roles$impl.isAbsent();
/*  90 */     this.messages_value = messages$impl.toOptional().orElse(null);
/*  91 */     this.messages_absent = messages$impl.isAbsent();
/*  92 */     this.attachments_value = attachments$impl.toOptional().orElse(null);
/*  93 */     this.attachments_absent = attachments$impl.isAbsent();
/*  94 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 100 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "ApplicationCommandInteractionResolvedData", generator = "Immutables")
/*     */   private final class InitShim {
/*     */     private String formatInitCycleMessage() {
/* 105 */       List<String> attributes = new ArrayList<>();
/* 106 */       return "Cannot build ApplicationCommandInteractionResolvedData, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @JsonProperty("users")
/*     */   public Possible<Map<String, UserData>> users() {
/* 116 */     return this.users_absent ? Possible.absent() : Possible.of(this.users_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("members")
/*     */   public Possible<Map<String, ResolvedMemberData>> members() {
/* 125 */     return this.members_absent ? Possible.absent() : Possible.of(this.members_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("channels")
/*     */   public Possible<Map<String, ResolvedChannelData>> channels() {
/* 134 */     return this.channels_absent ? Possible.absent() : Possible.of(this.channels_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("roles")
/*     */   public Possible<Map<String, RoleData>> roles() {
/* 143 */     return this.roles_absent ? Possible.absent() : Possible.of(this.roles_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("messages")
/*     */   public Possible<Map<String, MessageData>> messages() {
/* 152 */     return this.messages_absent ? Possible.absent() : Possible.of(this.messages_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("attachments")
/*     */   public Possible<Map<String, AttachmentData>> attachments() {
/* 161 */     return this.attachments_absent ? Possible.absent() : Possible.of(this.attachments_value);
/*     */   }
/*     */   
/*     */   public ImmutableApplicationCommandInteractionResolvedData withUsers(Possible<Map<String, UserData>> value) {
/* 165 */     Possible<Map<String, UserData>> newValue = Objects.<Possible<Map<String, UserData>>>requireNonNull(value);
/* 166 */     return new ImmutableApplicationCommandInteractionResolvedData(this, newValue, 
/*     */ 
/*     */         
/* 169 */         members(), 
/* 170 */         channels(), 
/* 171 */         roles(), 
/* 172 */         messages(), 
/* 173 */         attachments());
/*     */   }
/*     */   
/*     */   public ImmutableApplicationCommandInteractionResolvedData withUsers(Map<String, UserData> value) {
/* 177 */     Possible<Map<String, UserData>> newValue = Possible.of(value);
/* 178 */     return new ImmutableApplicationCommandInteractionResolvedData(this, newValue, 
/*     */ 
/*     */         
/* 181 */         members(), 
/* 182 */         channels(), 
/* 183 */         roles(), 
/* 184 */         messages(), 
/* 185 */         attachments());
/*     */   }
/*     */   
/*     */   public ImmutableApplicationCommandInteractionResolvedData withMembers(Possible<Map<String, ResolvedMemberData>> value) {
/* 189 */     Possible<Map<String, ResolvedMemberData>> newValue = Objects.<Possible<Map<String, ResolvedMemberData>>>requireNonNull(value);
/* 190 */     return new ImmutableApplicationCommandInteractionResolvedData(this, 
/*     */         
/* 192 */         users(), newValue, 
/*     */         
/* 194 */         channels(), 
/* 195 */         roles(), 
/* 196 */         messages(), 
/* 197 */         attachments());
/*     */   }
/*     */   
/*     */   public ImmutableApplicationCommandInteractionResolvedData withMembers(Map<String, ResolvedMemberData> value) {
/* 201 */     Possible<Map<String, ResolvedMemberData>> newValue = Possible.of(value);
/* 202 */     return new ImmutableApplicationCommandInteractionResolvedData(this, 
/*     */         
/* 204 */         users(), newValue, 
/*     */         
/* 206 */         channels(), 
/* 207 */         roles(), 
/* 208 */         messages(), 
/* 209 */         attachments());
/*     */   }
/*     */   
/*     */   public ImmutableApplicationCommandInteractionResolvedData withChannels(Possible<Map<String, ResolvedChannelData>> value) {
/* 213 */     Possible<Map<String, ResolvedChannelData>> newValue = Objects.<Possible<Map<String, ResolvedChannelData>>>requireNonNull(value);
/* 214 */     return new ImmutableApplicationCommandInteractionResolvedData(this, users(), members(), newValue, roles(), messages(), attachments());
/*     */   }
/*     */   
/*     */   public ImmutableApplicationCommandInteractionResolvedData withChannels(Map<String, ResolvedChannelData> value) {
/* 218 */     Possible<Map<String, ResolvedChannelData>> newValue = Possible.of(value);
/* 219 */     return new ImmutableApplicationCommandInteractionResolvedData(this, users(), members(), newValue, roles(), messages(), attachments());
/*     */   }
/*     */   
/*     */   public ImmutableApplicationCommandInteractionResolvedData withRoles(Possible<Map<String, RoleData>> value) {
/* 223 */     Possible<Map<String, RoleData>> newValue = Objects.<Possible<Map<String, RoleData>>>requireNonNull(value);
/* 224 */     return new ImmutableApplicationCommandInteractionResolvedData(this, 
/*     */         
/* 226 */         users(), 
/* 227 */         members(), 
/* 228 */         channels(), newValue, 
/*     */         
/* 230 */         messages(), 
/* 231 */         attachments());
/*     */   }
/*     */   
/*     */   public ImmutableApplicationCommandInteractionResolvedData withRoles(Map<String, RoleData> value) {
/* 235 */     Possible<Map<String, RoleData>> newValue = Possible.of(value);
/* 236 */     return new ImmutableApplicationCommandInteractionResolvedData(this, 
/*     */         
/* 238 */         users(), 
/* 239 */         members(), 
/* 240 */         channels(), newValue, 
/*     */         
/* 242 */         messages(), 
/* 243 */         attachments());
/*     */   }
/*     */   
/*     */   public ImmutableApplicationCommandInteractionResolvedData withMessages(Possible<Map<String, MessageData>> value) {
/* 247 */     Possible<Map<String, MessageData>> newValue = Objects.<Possible<Map<String, MessageData>>>requireNonNull(value);
/* 248 */     return new ImmutableApplicationCommandInteractionResolvedData(this, users(), members(), channels(), roles(), newValue, attachments());
/*     */   }
/*     */   
/*     */   public ImmutableApplicationCommandInteractionResolvedData withMessages(Map<String, MessageData> value) {
/* 252 */     Possible<Map<String, MessageData>> newValue = Possible.of(value);
/* 253 */     return new ImmutableApplicationCommandInteractionResolvedData(this, users(), members(), channels(), roles(), newValue, attachments());
/*     */   }
/*     */   
/*     */   public ImmutableApplicationCommandInteractionResolvedData withAttachments(Possible<Map<String, AttachmentData>> value) {
/* 257 */     Possible<Map<String, AttachmentData>> newValue = Objects.<Possible<Map<String, AttachmentData>>>requireNonNull(value);
/* 258 */     return new ImmutableApplicationCommandInteractionResolvedData(this, users(), members(), channels(), roles(), messages(), newValue);
/*     */   }
/*     */   
/*     */   public ImmutableApplicationCommandInteractionResolvedData withAttachments(Map<String, AttachmentData> value) {
/* 262 */     Possible<Map<String, AttachmentData>> newValue = Possible.of(value);
/* 263 */     return new ImmutableApplicationCommandInteractionResolvedData(this, users(), members(), channels(), roles(), messages(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 272 */     if (this == another) return true; 
/* 273 */     return (another instanceof ImmutableApplicationCommandInteractionResolvedData && 
/* 274 */       equalTo(0, (ImmutableApplicationCommandInteractionResolvedData)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableApplicationCommandInteractionResolvedData another) {
/* 278 */     return (users().equals(another.users()) && 
/* 279 */       members().equals(another.members()) && 
/* 280 */       channels().equals(another.channels()) && 
/* 281 */       roles().equals(another.roles()) && 
/* 282 */       messages().equals(another.messages()) && 
/* 283 */       attachments().equals(another.attachments()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 292 */     int h = 5381;
/* 293 */     h += (h << 5) + users().hashCode();
/* 294 */     h += (h << 5) + members().hashCode();
/* 295 */     h += (h << 5) + channels().hashCode();
/* 296 */     h += (h << 5) + roles().hashCode();
/* 297 */     h += (h << 5) + messages().hashCode();
/* 298 */     h += (h << 5) + attachments().hashCode();
/* 299 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 308 */     return "ApplicationCommandInteractionResolvedData{users=" + 
/* 309 */       users().toString() + ", members=" + 
/* 310 */       members().toString() + ", channels=" + 
/* 311 */       channels().toString() + ", roles=" + 
/* 312 */       roles().toString() + ", messages=" + 
/* 313 */       messages().toString() + ", attachments=" + 
/* 314 */       attachments().toString() + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "ApplicationCommandInteractionResolvedData", generator = "Immutables")
/*     */   static final class Json
/*     */     implements ApplicationCommandInteractionResolvedData
/*     */   {
/* 328 */     Possible<Map<String, UserData>> users = Possible.absent();
/*     */ 
/*     */     
/* 331 */     Possible<Map<String, ResolvedMemberData>> members = Possible.absent();
/*     */ 
/*     */     
/* 334 */     Possible<Map<String, ResolvedChannelData>> channels = Possible.absent();
/*     */ 
/*     */     
/* 337 */     Possible<Map<String, RoleData>> roles = Possible.absent();
/*     */ 
/*     */     
/* 340 */     Possible<Map<String, MessageData>> messages = Possible.absent();
/*     */ 
/*     */     
/* 343 */     Possible<Map<String, AttachmentData>> attachments = Possible.absent();
/*     */     
/*     */     @JsonProperty("users")
/*     */     public void setUsers(Possible<Map<String, UserData>> users) {
/* 347 */       this.users = users;
/*     */     }
/*     */     @JsonProperty("members")
/*     */     public void setMembers(Possible<Map<String, ResolvedMemberData>> members) {
/* 351 */       this.members = members;
/*     */     }
/*     */     @JsonProperty("channels")
/*     */     public void setChannels(Possible<Map<String, ResolvedChannelData>> channels) {
/* 355 */       this.channels = channels;
/*     */     }
/*     */     @JsonProperty("roles")
/*     */     public void setRoles(Possible<Map<String, RoleData>> roles) {
/* 359 */       this.roles = roles;
/*     */     }
/*     */     @JsonProperty("messages")
/*     */     public void setMessages(Possible<Map<String, MessageData>> messages) {
/* 363 */       this.messages = messages;
/*     */     }
/*     */     @JsonProperty("attachments")
/*     */     public void setAttachments(Possible<Map<String, AttachmentData>> attachments) {
/* 367 */       this.attachments = attachments;
/*     */     }
/*     */     public Possible<Map<String, UserData>> users() {
/* 370 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Map<String, ResolvedMemberData>> members() {
/* 372 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Map<String, ResolvedChannelData>> channels() {
/* 374 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Map<String, RoleData>> roles() {
/* 376 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Map<String, MessageData>> messages() {
/* 378 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Map<String, AttachmentData>> attachments() {
/* 380 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableApplicationCommandInteractionResolvedData fromJson(Json json) {
/* 391 */     Builder builder = builder();
/* 392 */     if (json.users != null) {
/* 393 */       builder.users(json.users);
/*     */     }
/* 395 */     if (json.members != null) {
/* 396 */       builder.members(json.members);
/*     */     }
/* 398 */     if (json.channels != null) {
/* 399 */       builder.channels(json.channels);
/*     */     }
/* 401 */     if (json.roles != null) {
/* 402 */       builder.roles(json.roles);
/*     */     }
/* 404 */     if (json.messages != null) {
/* 405 */       builder.messages(json.messages);
/*     */     }
/* 407 */     if (json.attachments != null) {
/* 408 */       builder.attachments(json.attachments);
/*     */     }
/* 410 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableApplicationCommandInteractionResolvedData of(Possible<Map<String, UserData>> users, Possible<Map<String, ResolvedMemberData>> members, Possible<Map<String, ResolvedChannelData>> channels, Possible<Map<String, RoleData>> roles, Possible<Map<String, MessageData>> messages, Possible<Map<String, AttachmentData>> attachments) {
/* 424 */     return new ImmutableApplicationCommandInteractionResolvedData(users, members, channels, roles, messages, attachments);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableApplicationCommandInteractionResolvedData copyOf(ApplicationCommandInteractionResolvedData instance) {
/* 435 */     if (instance instanceof ImmutableApplicationCommandInteractionResolvedData) {
/* 436 */       return (ImmutableApplicationCommandInteractionResolvedData)instance;
/*     */     }
/* 438 */     return builder()
/* 439 */       .from(instance)
/* 440 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isUsersPresent() {
/* 444 */     return !this.users_absent;
/*     */   }
/*     */   
/*     */   public Map<String, UserData> usersOrElse(Map<String, UserData> defaultValue) {
/* 448 */     return !this.users_absent ? this.users_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isMembersPresent() {
/* 452 */     return !this.members_absent;
/*     */   }
/*     */   
/*     */   public Map<String, ResolvedMemberData> membersOrElse(Map<String, ResolvedMemberData> defaultValue) {
/* 456 */     return !this.members_absent ? this.members_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isChannelsPresent() {
/* 460 */     return !this.channels_absent;
/*     */   }
/*     */   
/*     */   public Map<String, ResolvedChannelData> channelsOrElse(Map<String, ResolvedChannelData> defaultValue) {
/* 464 */     return !this.channels_absent ? this.channels_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isRolesPresent() {
/* 468 */     return !this.roles_absent;
/*     */   }
/*     */   
/*     */   public Map<String, RoleData> rolesOrElse(Map<String, RoleData> defaultValue) {
/* 472 */     return !this.roles_absent ? this.roles_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isMessagesPresent() {
/* 476 */     return !this.messages_absent;
/*     */   }
/*     */   
/*     */   public Map<String, MessageData> messagesOrElse(Map<String, MessageData> defaultValue) {
/* 480 */     return !this.messages_absent ? this.messages_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isAttachmentsPresent() {
/* 484 */     return !this.attachments_absent;
/*     */   }
/*     */   
/*     */   public Map<String, AttachmentData> attachmentsOrElse(Map<String, AttachmentData> defaultValue) {
/* 488 */     return !this.attachments_absent ? this.attachments_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 506 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "ApplicationCommandInteractionResolvedData", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/* 518 */     private Possible<Map<String, UserData>> users_possible = Possible.absent();
/* 519 */     private Possible<Map<String, ResolvedMemberData>> members_possible = Possible.absent();
/* 520 */     private Possible<Map<String, ResolvedChannelData>> channels_possible = Possible.absent();
/* 521 */     private Possible<Map<String, RoleData>> roles_possible = Possible.absent();
/* 522 */     private Possible<Map<String, MessageData>> messages_possible = Possible.absent();
/* 523 */     private Possible<Map<String, AttachmentData>> attachments_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(ApplicationCommandInteractionResolvedData instance) {
/* 536 */       Objects.requireNonNull(instance, "instance");
/* 537 */       users(instance.users());
/* 538 */       members(instance.members());
/* 539 */       channels(instance.channels());
/* 540 */       roles(instance.roles());
/* 541 */       messages(instance.messages());
/* 542 */       attachments(instance.attachments());
/* 543 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("users")
/*     */     public Builder users(Possible<Map<String, UserData>> value) {
/* 548 */       this.users_possible = value;
/* 549 */       return this;
/*     */     }
/*     */     
/*     */     public Builder users(Map<String, UserData> value) {
/* 553 */       this.users_possible = Possible.of(value);
/* 554 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("members")
/*     */     public Builder members(Possible<Map<String, ResolvedMemberData>> value) {
/* 559 */       this.members_possible = value;
/* 560 */       return this;
/*     */     }
/*     */     
/*     */     public Builder members(Map<String, ResolvedMemberData> value) {
/* 564 */       this.members_possible = Possible.of(value);
/* 565 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("channels")
/*     */     public Builder channels(Possible<Map<String, ResolvedChannelData>> value) {
/* 570 */       this.channels_possible = value;
/* 571 */       return this;
/*     */     }
/*     */     
/*     */     public Builder channels(Map<String, ResolvedChannelData> value) {
/* 575 */       this.channels_possible = Possible.of(value);
/* 576 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("roles")
/*     */     public Builder roles(Possible<Map<String, RoleData>> value) {
/* 581 */       this.roles_possible = value;
/* 582 */       return this;
/*     */     }
/*     */     
/*     */     public Builder roles(Map<String, RoleData> value) {
/* 586 */       this.roles_possible = Possible.of(value);
/* 587 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("messages")
/*     */     public Builder messages(Possible<Map<String, MessageData>> value) {
/* 592 */       this.messages_possible = value;
/* 593 */       return this;
/*     */     }
/*     */     
/*     */     public Builder messages(Map<String, MessageData> value) {
/* 597 */       this.messages_possible = Possible.of(value);
/* 598 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("attachments")
/*     */     public Builder attachments(Possible<Map<String, AttachmentData>> value) {
/* 603 */       this.attachments_possible = value;
/* 604 */       return this;
/*     */     }
/*     */     
/*     */     public Builder attachments(Map<String, AttachmentData> value) {
/* 608 */       this.attachments_possible = Possible.of(value);
/* 609 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableApplicationCommandInteractionResolvedData build() {
/* 618 */       return new ImmutableApplicationCommandInteractionResolvedData(null, 
/*     */           
/* 620 */           users_build(), 
/* 621 */           members_build(), 
/* 622 */           channels_build(), 
/* 623 */           roles_build(), 
/* 624 */           messages_build(), 
/* 625 */           attachments_build());
/*     */     }
/*     */     
/*     */     private Possible<Map<String, UserData>> users_build() {
/* 629 */       return this.users_possible;
/*     */     }
/*     */     
/*     */     private Possible<Map<String, ResolvedMemberData>> members_build() {
/* 633 */       return this.members_possible;
/*     */     }
/*     */     
/*     */     private Possible<Map<String, ResolvedChannelData>> channels_build() {
/* 637 */       return this.channels_possible;
/*     */     }
/*     */     
/*     */     private Possible<Map<String, RoleData>> roles_build() {
/* 641 */       return this.roles_possible;
/*     */     }
/*     */     
/*     */     private Possible<Map<String, MessageData>> messages_build() {
/* 645 */       return this.messages_possible;
/*     */     }
/*     */     
/*     */     private Possible<Map<String, AttachmentData>> attachments_build() {
/* 649 */       return this.attachments_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableApplicationCommandInteractionResolvedData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */