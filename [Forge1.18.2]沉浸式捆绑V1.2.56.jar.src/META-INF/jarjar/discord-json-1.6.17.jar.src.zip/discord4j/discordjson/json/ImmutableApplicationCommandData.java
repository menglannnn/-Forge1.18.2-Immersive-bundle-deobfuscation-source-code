/*      */ package discord4j.discordjson.json;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*      */ import com.fasterxml.jackson.annotation.JsonCreator;
/*      */ import com.fasterxml.jackson.annotation.JsonProperty;
/*      */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*      */ import discord4j.discordjson.Id;
/*      */ import discord4j.discordjson.possible.Possible;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Objects;
/*      */ import java.util.Optional;
/*      */ import java.util.stream.Collectors;
/*      */ import java.util.stream.StreamSupport;
/*      */ import org.immutables.value.Generated;
/*      */ import reactor.util.annotation.Nullable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Generated(from = "ApplicationCommandData", generator = "Immutables")
/*      */ public final class ImmutableApplicationCommandData
/*      */   implements ApplicationCommandData
/*      */ {
/*      */   private final long id_value;
/*      */   private final long version_value;
/*      */   private final long guildId_value;
/*      */   private final boolean guildId_absent;
/*      */   private final Integer type_value;
/*      */   private final boolean type_absent;
/*      */   private final long applicationId_value;
/*      */   private final String name;
/*      */   private final Map<String, String> nameLocalizations_value;
/*      */   private final boolean nameLocalizations_absent;
/*      */   private final String description;
/*      */   private final Map<String, String> descriptionLocalizations_value;
/*      */   private final boolean descriptionLocalizations_absent;
/*      */   private final List<ApplicationCommandOptionData> options_value;
/*      */   private final boolean options_absent;
/*      */   private final Boolean dmPermission_value;
/*      */   private final boolean dmPermission_absent;
/*      */   private final Boolean defaultPermission_value;
/*      */   private final boolean defaultPermission_absent;
/*      */   private final String defaultMemberPermissions;
/*      */   private static final byte STAGE_INITIALIZING = -1;
/*      */   private static final byte STAGE_UNINITIALIZED = 0;
/*      */   private static final byte STAGE_INITIALIZED = 1;
/*      */   
/*      */   private ImmutableApplicationCommandData(Id id, Id version, Possible<Id> guildId, Possible<Integer> type, Id applicationId, String name, Possible<Optional<Map<String, String>>> nameLocalizations, String description, Possible<Optional<Map<String, String>>> descriptionLocalizations, Possible<List<ApplicationCommandOptionData>> options, Possible<Boolean> dmPermission, Possible<Boolean> defaultPermission, Optional<String> defaultMemberPermissions) {
/*   68 */     Id id$impl = id;
/*   69 */     Id version$impl = version;
/*   70 */     Possible<Id> guildId$impl = guildId;
/*   71 */     Possible<Integer> type$impl = type;
/*   72 */     Id applicationId$impl = applicationId;
/*   73 */     this.name = Objects.<String>requireNonNull(name, "name");
/*   74 */     Possible<Optional<Map<String, String>>> nameLocalizations$impl = nameLocalizations;
/*   75 */     this.description = Objects.<String>requireNonNull(description, "description");
/*   76 */     Possible<Optional<Map<String, String>>> descriptionLocalizations$impl = descriptionLocalizations;
/*   77 */     Possible<List<ApplicationCommandOptionData>> options$impl = options;
/*   78 */     Possible<Boolean> dmPermission$impl = dmPermission;
/*   79 */     Possible<Boolean> defaultPermission$impl = defaultPermission;
/*   80 */     this.defaultMemberPermissions = defaultMemberPermissions.orElse(null);
/*   81 */     this.id_value = id$impl.asLong();
/*   82 */     this.version_value = version$impl.asLong();
/*   83 */     this
/*      */       
/*   85 */       .guildId_value = ((Long)guildId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*   86 */     this.guildId_absent = guildId$impl.isAbsent();
/*   87 */     this.type_value = type$impl.toOptional().orElse(null);
/*   88 */     this.type_absent = type$impl.isAbsent();
/*   89 */     this.applicationId_value = applicationId$impl.asLong();
/*   90 */     this.nameLocalizations_value = Possible.flatOpt(nameLocalizations$impl).orElse(null);
/*   91 */     this.nameLocalizations_absent = nameLocalizations$impl.isAbsent();
/*   92 */     this.descriptionLocalizations_value = Possible.flatOpt(descriptionLocalizations$impl).orElse(null);
/*   93 */     this.descriptionLocalizations_absent = descriptionLocalizations$impl.isAbsent();
/*   94 */     this.options_value = options$impl.toOptional().orElse(null);
/*   95 */     this.options_absent = options$impl.isAbsent();
/*   96 */     this.dmPermission_value = dmPermission$impl.toOptional().orElse(null);
/*   97 */     this.dmPermission_absent = dmPermission$impl.isAbsent();
/*   98 */     this.defaultPermission_value = defaultPermission$impl.toOptional().orElse(null);
/*   99 */     this.defaultPermission_absent = defaultPermission$impl.isAbsent();
/*  100 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ImmutableApplicationCommandData(ImmutableApplicationCommandData original, Id id, Id version, Possible<Id> guildId, Possible<Integer> type, Id applicationId, String name, Possible<Optional<Map<String, String>>> nameLocalizations, String description, Possible<Optional<Map<String, String>>> descriptionLocalizations, Possible<List<ApplicationCommandOptionData>> options, Possible<Boolean> dmPermission, Possible<Boolean> defaultPermission, String defaultMemberPermissions) {
/*  118 */     Id id$impl = id;
/*  119 */     Id version$impl = version;
/*  120 */     Possible<Id> guildId$impl = guildId;
/*  121 */     Possible<Integer> type$impl = type;
/*  122 */     Id applicationId$impl = applicationId;
/*  123 */     this.name = name;
/*  124 */     Possible<Optional<Map<String, String>>> nameLocalizations$impl = nameLocalizations;
/*  125 */     this.description = description;
/*  126 */     Possible<Optional<Map<String, String>>> descriptionLocalizations$impl = descriptionLocalizations;
/*  127 */     Possible<List<ApplicationCommandOptionData>> options$impl = options;
/*  128 */     Possible<Boolean> dmPermission$impl = dmPermission;
/*  129 */     Possible<Boolean> defaultPermission$impl = defaultPermission;
/*  130 */     this.defaultMemberPermissions = defaultMemberPermissions;
/*  131 */     this.id_value = id$impl.asLong();
/*  132 */     this.version_value = version$impl.asLong();
/*  133 */     this
/*      */       
/*  135 */       .guildId_value = ((Long)guildId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  136 */     this.guildId_absent = guildId$impl.isAbsent();
/*  137 */     this.type_value = type$impl.toOptional().orElse(null);
/*  138 */     this.type_absent = type$impl.isAbsent();
/*  139 */     this.applicationId_value = applicationId$impl.asLong();
/*  140 */     this.nameLocalizations_value = Possible.flatOpt(nameLocalizations$impl).orElse(null);
/*  141 */     this.nameLocalizations_absent = nameLocalizations$impl.isAbsent();
/*  142 */     this.descriptionLocalizations_value = Possible.flatOpt(descriptionLocalizations$impl).orElse(null);
/*  143 */     this.descriptionLocalizations_absent = descriptionLocalizations$impl.isAbsent();
/*  144 */     this.options_value = options$impl.toOptional().orElse(null);
/*  145 */     this.options_absent = options$impl.isAbsent();
/*  146 */     this.dmPermission_value = dmPermission$impl.toOptional().orElse(null);
/*  147 */     this.dmPermission_absent = dmPermission$impl.isAbsent();
/*  148 */     this.defaultPermission_value = defaultPermission$impl.toOptional().orElse(null);
/*  149 */     this.defaultPermission_absent = defaultPermission$impl.isAbsent();
/*  150 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  156 */   private volatile transient InitShim initShim = new InitShim();
/*      */   
/*      */   @Generated(from = "ApplicationCommandData", generator = "Immutables")
/*      */   private final class InitShim {
/*      */     private String formatInitCycleMessage() {
/*  161 */       List<String> attributes = new ArrayList<>();
/*  162 */       return "Cannot build ApplicationCommandData, attribute initializers form cycle " + attributes;
/*      */     }
/*      */ 
/*      */     
/*      */     private InitShim() {}
/*      */   }
/*      */ 
/*      */   
/*      */   @JsonProperty("id")
/*      */   public Id id() {
/*  172 */     return Id.of(this.id_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("version")
/*      */   public Id version() {
/*  181 */     return Id.of(this.version_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("guild_id")
/*      */   public Possible<Id> guildId() {
/*  190 */     return this.guildId_absent ? Possible.absent() : 
/*  191 */       Possible.of(Id.of(this.guildId_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("type")
/*      */   public Possible<Integer> type() {
/*  200 */     return this.type_absent ? Possible.absent() : Possible.of(this.type_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("application_id")
/*      */   public Id applicationId() {
/*  209 */     return Id.of(this.applicationId_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("name")
/*      */   public String name() {
/*  218 */     return this.name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("name_localizations")
/*      */   public Possible<Optional<Map<String, String>>> nameLocalizations() {
/*  227 */     return this.nameLocalizations_absent ? Possible.absent() : 
/*  228 */       Possible.of(Optional.ofNullable(this.nameLocalizations_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("description")
/*      */   public String description() {
/*  237 */     return this.description;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("description_localizations")
/*      */   public Possible<Optional<Map<String, String>>> descriptionLocalizations() {
/*  246 */     return this.descriptionLocalizations_absent ? Possible.absent() : 
/*  247 */       Possible.of(Optional.ofNullable(this.descriptionLocalizations_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("options")
/*      */   public Possible<List<ApplicationCommandOptionData>> options() {
/*  256 */     return this.options_absent ? Possible.absent() : 
/*  257 */       Possible.of(this.options_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("dm_permission")
/*      */   public Possible<Boolean> dmPermission() {
/*  266 */     return this.dmPermission_absent ? Possible.absent() : Possible.of(this.dmPermission_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("default_permission")
/*      */   @Deprecated
/*      */   public Possible<Boolean> defaultPermission() {
/*  276 */     return this.defaultPermission_absent ? Possible.absent() : Possible.of(this.defaultPermission_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("default_member_permissions")
/*      */   public Optional<String> defaultMemberPermissions() {
/*  285 */     return Optional.ofNullable(this.defaultMemberPermissions);
/*      */   }
/*      */   
/*      */   public ImmutableApplicationCommandData withId(long value) {
/*  289 */     Id newValue = Id.of(value);
/*  290 */     return new ImmutableApplicationCommandData(this, newValue, 
/*      */ 
/*      */         
/*  293 */         version(), 
/*  294 */         guildId(), 
/*  295 */         type(), 
/*  296 */         applicationId(), this.name, 
/*      */         
/*  298 */         nameLocalizations(), this.description, 
/*      */         
/*  300 */         descriptionLocalizations(), 
/*  301 */         options(), 
/*  302 */         dmPermission(), 
/*  303 */         defaultPermission(), this.defaultMemberPermissions);
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableApplicationCommandData withId(String value) {
/*  308 */     Id newValue = Id.of(value);
/*  309 */     return new ImmutableApplicationCommandData(this, newValue, 
/*      */ 
/*      */         
/*  312 */         version(), 
/*  313 */         guildId(), 
/*  314 */         type(), 
/*  315 */         applicationId(), this.name, 
/*      */         
/*  317 */         nameLocalizations(), this.description, 
/*      */         
/*  319 */         descriptionLocalizations(), 
/*  320 */         options(), 
/*  321 */         dmPermission(), 
/*  322 */         defaultPermission(), this.defaultMemberPermissions);
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableApplicationCommandData withVersion(long value) {
/*  327 */     Id newValue = Id.of(value);
/*  328 */     return new ImmutableApplicationCommandData(this, 
/*      */         
/*  330 */         id(), newValue, 
/*      */         
/*  332 */         guildId(), 
/*  333 */         type(), 
/*  334 */         applicationId(), this.name, 
/*      */         
/*  336 */         nameLocalizations(), this.description, 
/*      */         
/*  338 */         descriptionLocalizations(), 
/*  339 */         options(), 
/*  340 */         dmPermission(), 
/*  341 */         defaultPermission(), this.defaultMemberPermissions);
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableApplicationCommandData withVersion(String value) {
/*  346 */     Id newValue = Id.of(value);
/*  347 */     return new ImmutableApplicationCommandData(this, 
/*      */         
/*  349 */         id(), newValue, 
/*      */         
/*  351 */         guildId(), 
/*  352 */         type(), 
/*  353 */         applicationId(), this.name, 
/*      */         
/*  355 */         nameLocalizations(), this.description, 
/*      */         
/*  357 */         descriptionLocalizations(), 
/*  358 */         options(), 
/*  359 */         dmPermission(), 
/*  360 */         defaultPermission(), this.defaultMemberPermissions);
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableApplicationCommandData withGuildId(Possible<Id> value) {
/*  365 */     Possible<Id> newValue = Objects.<Possible<Id>>requireNonNull(value);
/*  366 */     return new ImmutableApplicationCommandData(this, 
/*      */         
/*  368 */         id(), 
/*  369 */         version(), newValue, 
/*      */         
/*  371 */         type(), 
/*  372 */         applicationId(), this.name, 
/*      */         
/*  374 */         nameLocalizations(), this.description, 
/*      */         
/*  376 */         descriptionLocalizations(), 
/*  377 */         options(), 
/*  378 */         dmPermission(), 
/*  379 */         defaultPermission(), this.defaultMemberPermissions);
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableApplicationCommandData withGuildId(long value) {
/*  384 */     Possible<Id> newValue = Possible.of(Id.of(value));
/*  385 */     return new ImmutableApplicationCommandData(this, 
/*      */         
/*  387 */         id(), 
/*  388 */         version(), newValue, 
/*      */         
/*  390 */         type(), 
/*  391 */         applicationId(), this.name, 
/*      */         
/*  393 */         nameLocalizations(), this.description, 
/*      */         
/*  395 */         descriptionLocalizations(), 
/*  396 */         options(), 
/*  397 */         dmPermission(), 
/*  398 */         defaultPermission(), this.defaultMemberPermissions);
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableApplicationCommandData withType(Possible<Integer> value) {
/*  403 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/*  404 */     return new ImmutableApplicationCommandData(this, 
/*      */         
/*  406 */         id(), 
/*  407 */         version(), 
/*  408 */         guildId(), newValue, 
/*      */         
/*  410 */         applicationId(), this.name, 
/*      */         
/*  412 */         nameLocalizations(), this.description, 
/*      */         
/*  414 */         descriptionLocalizations(), 
/*  415 */         options(), 
/*  416 */         dmPermission(), 
/*  417 */         defaultPermission(), this.defaultMemberPermissions);
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableApplicationCommandData withType(Integer value) {
/*  422 */     Possible<Integer> newValue = Possible.of(value);
/*  423 */     return new ImmutableApplicationCommandData(this, 
/*      */         
/*  425 */         id(), 
/*  426 */         version(), 
/*  427 */         guildId(), newValue, 
/*      */         
/*  429 */         applicationId(), this.name, 
/*      */         
/*  431 */         nameLocalizations(), this.description, 
/*      */         
/*  433 */         descriptionLocalizations(), 
/*  434 */         options(), 
/*  435 */         dmPermission(), 
/*  436 */         defaultPermission(), this.defaultMemberPermissions);
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableApplicationCommandData withApplicationId(long value) {
/*  441 */     Id newValue = Id.of(value);
/*  442 */     return new ImmutableApplicationCommandData(this, 
/*      */         
/*  444 */         id(), 
/*  445 */         version(), 
/*  446 */         guildId(), 
/*  447 */         type(), newValue, this.name, 
/*      */ 
/*      */         
/*  450 */         nameLocalizations(), this.description, 
/*      */         
/*  452 */         descriptionLocalizations(), 
/*  453 */         options(), 
/*  454 */         dmPermission(), 
/*  455 */         defaultPermission(), this.defaultMemberPermissions);
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableApplicationCommandData withApplicationId(String value) {
/*  460 */     Id newValue = Id.of(value);
/*  461 */     return new ImmutableApplicationCommandData(this, 
/*      */         
/*  463 */         id(), 
/*  464 */         version(), 
/*  465 */         guildId(), 
/*  466 */         type(), newValue, this.name, 
/*      */ 
/*      */         
/*  469 */         nameLocalizations(), this.description, 
/*      */         
/*  471 */         descriptionLocalizations(), 
/*  472 */         options(), 
/*  473 */         dmPermission(), 
/*  474 */         defaultPermission(), this.defaultMemberPermissions);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableApplicationCommandData withName(String value) {
/*  485 */     String newValue = Objects.<String>requireNonNull(value, "name");
/*  486 */     if (this.name.equals(newValue)) return this; 
/*  487 */     return new ImmutableApplicationCommandData(this, 
/*      */         
/*  489 */         id(), 
/*  490 */         version(), 
/*  491 */         guildId(), 
/*  492 */         type(), 
/*  493 */         applicationId(), newValue, 
/*      */         
/*  495 */         nameLocalizations(), this.description, 
/*      */         
/*  497 */         descriptionLocalizations(), 
/*  498 */         options(), 
/*  499 */         dmPermission(), 
/*  500 */         defaultPermission(), this.defaultMemberPermissions);
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableApplicationCommandData withNameLocalizations(Possible<Optional<Map<String, String>>> value) {
/*  505 */     Possible<Optional<Map<String, String>>> newValue = Objects.<Possible<Optional<Map<String, String>>>>requireNonNull(value);
/*  506 */     return new ImmutableApplicationCommandData(this, 
/*      */         
/*  508 */         id(), 
/*  509 */         version(), 
/*  510 */         guildId(), 
/*  511 */         type(), 
/*  512 */         applicationId(), this.name, newValue, this.description, 
/*      */ 
/*      */ 
/*      */         
/*  516 */         descriptionLocalizations(), 
/*  517 */         options(), 
/*  518 */         dmPermission(), 
/*  519 */         defaultPermission(), this.defaultMemberPermissions);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableApplicationCommandData withNameLocalizations(@Nullable Map<String, String> value) {
/*  525 */     Possible<Optional<Map<String, String>>> newValue = Possible.of(Optional.ofNullable(value));
/*  526 */     return new ImmutableApplicationCommandData(this, 
/*      */         
/*  528 */         id(), 
/*  529 */         version(), 
/*  530 */         guildId(), 
/*  531 */         type(), 
/*  532 */         applicationId(), this.name, newValue, this.description, 
/*      */ 
/*      */ 
/*      */         
/*  536 */         descriptionLocalizations(), 
/*  537 */         options(), 
/*  538 */         dmPermission(), 
/*  539 */         defaultPermission(), this.defaultMemberPermissions);
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableApplicationCommandData withNameLocalizationsOrNull(@Nullable Map<String, String> value) {
/*  544 */     Possible<Optional<Map<String, String>>> newValue = Possible.of(Optional.ofNullable(value));
/*  545 */     return new ImmutableApplicationCommandData(this, 
/*      */         
/*  547 */         id(), 
/*  548 */         version(), 
/*  549 */         guildId(), 
/*  550 */         type(), 
/*  551 */         applicationId(), this.name, newValue, this.description, 
/*      */ 
/*      */ 
/*      */         
/*  555 */         descriptionLocalizations(), 
/*  556 */         options(), 
/*  557 */         dmPermission(), 
/*  558 */         defaultPermission(), this.defaultMemberPermissions);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableApplicationCommandData withDescription(String value) {
/*  569 */     String newValue = Objects.<String>requireNonNull(value, "description");
/*  570 */     if (this.description.equals(newValue)) return this; 
/*  571 */     return new ImmutableApplicationCommandData(this, 
/*      */         
/*  573 */         id(), 
/*  574 */         version(), 
/*  575 */         guildId(), 
/*  576 */         type(), 
/*  577 */         applicationId(), this.name, 
/*      */         
/*  579 */         nameLocalizations(), newValue, 
/*      */         
/*  581 */         descriptionLocalizations(), 
/*  582 */         options(), 
/*  583 */         dmPermission(), 
/*  584 */         defaultPermission(), this.defaultMemberPermissions);
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableApplicationCommandData withDescriptionLocalizations(Possible<Optional<Map<String, String>>> value) {
/*  589 */     Possible<Optional<Map<String, String>>> newValue = Objects.<Possible<Optional<Map<String, String>>>>requireNonNull(value);
/*  590 */     return new ImmutableApplicationCommandData(this, 
/*      */         
/*  592 */         id(), 
/*  593 */         version(), 
/*  594 */         guildId(), 
/*  595 */         type(), 
/*  596 */         applicationId(), this.name, 
/*      */         
/*  598 */         nameLocalizations(), this.description, newValue, 
/*      */ 
/*      */         
/*  601 */         options(), 
/*  602 */         dmPermission(), 
/*  603 */         defaultPermission(), this.defaultMemberPermissions);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableApplicationCommandData withDescriptionLocalizations(@Nullable Map<String, String> value) {
/*  609 */     Possible<Optional<Map<String, String>>> newValue = Possible.of(Optional.ofNullable(value));
/*  610 */     return new ImmutableApplicationCommandData(this, 
/*      */         
/*  612 */         id(), 
/*  613 */         version(), 
/*  614 */         guildId(), 
/*  615 */         type(), 
/*  616 */         applicationId(), this.name, 
/*      */         
/*  618 */         nameLocalizations(), this.description, newValue, 
/*      */ 
/*      */         
/*  621 */         options(), 
/*  622 */         dmPermission(), 
/*  623 */         defaultPermission(), this.defaultMemberPermissions);
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableApplicationCommandData withDescriptionLocalizationsOrNull(@Nullable Map<String, String> value) {
/*  628 */     Possible<Optional<Map<String, String>>> newValue = Possible.of(Optional.ofNullable(value));
/*  629 */     return new ImmutableApplicationCommandData(this, 
/*      */         
/*  631 */         id(), 
/*  632 */         version(), 
/*  633 */         guildId(), 
/*  634 */         type(), 
/*  635 */         applicationId(), this.name, 
/*      */         
/*  637 */         nameLocalizations(), this.description, newValue, 
/*      */ 
/*      */         
/*  640 */         options(), 
/*  641 */         dmPermission(), 
/*  642 */         defaultPermission(), this.defaultMemberPermissions);
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableApplicationCommandData withOptions(Possible<List<ApplicationCommandOptionData>> possible) {
/*  647 */     Possible<List<ApplicationCommandOptionData>> newValue = Objects.<Possible<List<ApplicationCommandOptionData>>>requireNonNull(possible);
/*  648 */     return new ImmutableApplicationCommandData(this, 
/*      */         
/*  650 */         id(), 
/*  651 */         version(), 
/*  652 */         guildId(), 
/*  653 */         type(), 
/*  654 */         applicationId(), this.name, 
/*      */         
/*  656 */         nameLocalizations(), this.description, 
/*      */         
/*  658 */         descriptionLocalizations(), newValue, 
/*      */         
/*  660 */         dmPermission(), 
/*  661 */         defaultPermission(), this.defaultMemberPermissions);
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableApplicationCommandData withOptions(Iterable<ApplicationCommandOptionData> elements) {
/*  666 */     Possible<List<ApplicationCommandOptionData>> newValue = Possible.of(
/*  667 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/*  668 */     return new ImmutableApplicationCommandData(this, 
/*      */         
/*  670 */         id(), 
/*  671 */         version(), 
/*  672 */         guildId(), 
/*  673 */         type(), 
/*  674 */         applicationId(), this.name, 
/*      */         
/*  676 */         nameLocalizations(), this.description, 
/*      */         
/*  678 */         descriptionLocalizations(), newValue, 
/*      */         
/*  680 */         dmPermission(), 
/*  681 */         defaultPermission(), this.defaultMemberPermissions);
/*      */   }
/*      */ 
/*      */   
/*      */   @SafeVarargs
/*      */   public final ImmutableApplicationCommandData withOptions(ApplicationCommandOptionData... elements) {
/*  687 */     Possible<List<ApplicationCommandOptionData>> newValue = Possible.of(Arrays.asList(elements));
/*  688 */     return new ImmutableApplicationCommandData(this, 
/*      */         
/*  690 */         id(), 
/*  691 */         version(), 
/*  692 */         guildId(), 
/*  693 */         type(), 
/*  694 */         applicationId(), this.name, 
/*      */         
/*  696 */         nameLocalizations(), this.description, 
/*      */         
/*  698 */         descriptionLocalizations(), newValue, 
/*      */         
/*  700 */         dmPermission(), 
/*  701 */         defaultPermission(), this.defaultMemberPermissions);
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableApplicationCommandData withDmPermission(Possible<Boolean> value) {
/*  706 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/*  707 */     return new ImmutableApplicationCommandData(this, 
/*      */         
/*  709 */         id(), 
/*  710 */         version(), 
/*  711 */         guildId(), 
/*  712 */         type(), 
/*  713 */         applicationId(), this.name, 
/*      */         
/*  715 */         nameLocalizations(), this.description, 
/*      */         
/*  717 */         descriptionLocalizations(), 
/*  718 */         options(), newValue, 
/*      */         
/*  720 */         defaultPermission(), this.defaultMemberPermissions);
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableApplicationCommandData withDmPermission(Boolean value) {
/*  725 */     Possible<Boolean> newValue = Possible.of(value);
/*  726 */     return new ImmutableApplicationCommandData(this, 
/*      */         
/*  728 */         id(), 
/*  729 */         version(), 
/*  730 */         guildId(), 
/*  731 */         type(), 
/*  732 */         applicationId(), this.name, 
/*      */         
/*  734 */         nameLocalizations(), this.description, 
/*      */         
/*  736 */         descriptionLocalizations(), 
/*  737 */         options(), newValue, 
/*      */         
/*  739 */         defaultPermission(), this.defaultMemberPermissions);
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableApplicationCommandData withDefaultPermission(Possible<Boolean> value) {
/*  744 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/*  745 */     return new ImmutableApplicationCommandData(this, 
/*      */         
/*  747 */         id(), 
/*  748 */         version(), 
/*  749 */         guildId(), 
/*  750 */         type(), 
/*  751 */         applicationId(), this.name, 
/*      */         
/*  753 */         nameLocalizations(), this.description, 
/*      */         
/*  755 */         descriptionLocalizations(), 
/*  756 */         options(), 
/*  757 */         dmPermission(), newValue, this.defaultMemberPermissions);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableApplicationCommandData withDefaultPermission(Boolean value) {
/*  763 */     Possible<Boolean> newValue = Possible.of(value);
/*  764 */     return new ImmutableApplicationCommandData(this, 
/*      */         
/*  766 */         id(), 
/*  767 */         version(), 
/*  768 */         guildId(), 
/*  769 */         type(), 
/*  770 */         applicationId(), this.name, 
/*      */         
/*  772 */         nameLocalizations(), this.description, 
/*      */         
/*  774 */         descriptionLocalizations(), 
/*  775 */         options(), 
/*  776 */         dmPermission(), newValue, this.defaultMemberPermissions);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableApplicationCommandData withDefaultMemberPermissions(String value) {
/*  787 */     String newValue = Objects.<String>requireNonNull(value, "defaultMemberPermissions");
/*  788 */     if (Objects.equals(this.defaultMemberPermissions, newValue)) return this; 
/*  789 */     return new ImmutableApplicationCommandData(this, 
/*      */         
/*  791 */         id(), 
/*  792 */         version(), 
/*  793 */         guildId(), 
/*  794 */         type(), 
/*  795 */         applicationId(), this.name, 
/*      */         
/*  797 */         nameLocalizations(), this.description, 
/*      */         
/*  799 */         descriptionLocalizations(), 
/*  800 */         options(), 
/*  801 */         dmPermission(), 
/*  802 */         defaultPermission(), newValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableApplicationCommandData withDefaultMemberPermissions(Optional<String> optional) {
/*  813 */     String value = optional.orElse(null);
/*  814 */     if (Objects.equals(this.defaultMemberPermissions, value)) return this; 
/*  815 */     return new ImmutableApplicationCommandData(this, 
/*      */         
/*  817 */         id(), 
/*  818 */         version(), 
/*  819 */         guildId(), 
/*  820 */         type(), 
/*  821 */         applicationId(), this.name, 
/*      */         
/*  823 */         nameLocalizations(), this.description, 
/*      */         
/*  825 */         descriptionLocalizations(), 
/*  826 */         options(), 
/*  827 */         dmPermission(), 
/*  828 */         defaultPermission(), value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object another) {
/*  838 */     if (this == another) return true; 
/*  839 */     return (another instanceof ImmutableApplicationCommandData && 
/*  840 */       equalTo(0, (ImmutableApplicationCommandData)another));
/*      */   }
/*      */   
/*      */   private boolean equalTo(int synthetic, ImmutableApplicationCommandData another) {
/*  844 */     return (Objects.equals(Long.valueOf(this.id_value), Long.valueOf(another.id_value)) && 
/*  845 */       Objects.equals(Long.valueOf(this.version_value), Long.valueOf(another.version_value)) && 
/*  846 */       guildId().equals(another.guildId()) && 
/*  847 */       type().equals(another.type()) && 
/*  848 */       Objects.equals(Long.valueOf(this.applicationId_value), Long.valueOf(another.applicationId_value)) && this.name
/*  849 */       .equals(another.name) && 
/*  850 */       nameLocalizations().equals(another.nameLocalizations()) && this.description
/*  851 */       .equals(another.description) && 
/*  852 */       descriptionLocalizations().equals(another.descriptionLocalizations()) && 
/*  853 */       Objects.equals(this.options_value, another.options_value) && 
/*  854 */       dmPermission().equals(another.dmPermission()) && 
/*  855 */       defaultPermission().equals(another.defaultPermission()) && 
/*  856 */       Objects.equals(this.defaultMemberPermissions, another.defaultMemberPermissions));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/*  865 */     int h = 5381;
/*  866 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.id_value));
/*  867 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.version_value));
/*  868 */     h += (h << 5) + guildId().hashCode();
/*  869 */     h += (h << 5) + type().hashCode();
/*  870 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.applicationId_value));
/*  871 */     h += (h << 5) + this.name.hashCode();
/*  872 */     h += (h << 5) + nameLocalizations().hashCode();
/*  873 */     h += (h << 5) + this.description.hashCode();
/*  874 */     h += (h << 5) + descriptionLocalizations().hashCode();
/*  875 */     h += (h << 5) + Objects.hashCode(this.options_value);
/*  876 */     h += (h << 5) + dmPermission().hashCode();
/*  877 */     h += (h << 5) + defaultPermission().hashCode();
/*  878 */     h += (h << 5) + Objects.hashCode(this.defaultMemberPermissions);
/*  879 */     return h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*  888 */     StringBuilder builder = new StringBuilder("ApplicationCommandData{");
/*  889 */     builder.append("id=").append(Objects.toString(Long.valueOf(this.id_value)));
/*  890 */     builder.append(", ");
/*  891 */     builder.append("version=").append(Objects.toString(Long.valueOf(this.version_value)));
/*  892 */     builder.append(", ");
/*  893 */     builder.append("guildId=").append(guildId().toString());
/*  894 */     builder.append(", ");
/*  895 */     builder.append("type=").append(type().toString());
/*  896 */     builder.append(", ");
/*  897 */     builder.append("applicationId=").append(Objects.toString(Long.valueOf(this.applicationId_value)));
/*  898 */     builder.append(", ");
/*  899 */     builder.append("name=").append(this.name);
/*  900 */     builder.append(", ");
/*  901 */     builder.append("nameLocalizations=").append(nameLocalizations().toString());
/*  902 */     builder.append(", ");
/*  903 */     builder.append("description=").append(this.description);
/*  904 */     builder.append(", ");
/*  905 */     builder.append("descriptionLocalizations=").append(descriptionLocalizations().toString());
/*  906 */     builder.append(", ");
/*  907 */     builder.append("options=").append(Objects.toString(this.options_value));
/*  908 */     builder.append(", ");
/*  909 */     builder.append("dmPermission=").append(dmPermission().toString());
/*  910 */     builder.append(", ");
/*  911 */     builder.append("defaultPermission=").append(defaultPermission().toString());
/*  912 */     if (this.defaultMemberPermissions != null) {
/*  913 */       builder.append(", ");
/*  914 */       builder.append("defaultMemberPermissions=").append(this.defaultMemberPermissions);
/*      */     } 
/*  916 */     return builder.append("}").toString();
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonDeserialize
/*      */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*      */   @Generated(from = "ApplicationCommandData", generator = "Immutables")
/*      */   static final class Json
/*      */     implements ApplicationCommandData
/*      */   {
/*      */     Id id;
/*      */     
/*      */     Id version;
/*      */     
/*  931 */     Possible<Id> guildId = Possible.absent();
/*      */ 
/*      */     
/*  934 */     Possible<Integer> type = Possible.absent();
/*      */     
/*      */     Id applicationId;
/*      */     
/*      */     String name;
/*  939 */     Possible<Optional<Map<String, String>>> nameLocalizations = Possible.absent();
/*      */     
/*      */     String description;
/*      */     
/*  943 */     Possible<Optional<Map<String, String>>> descriptionLocalizations = Possible.absent();
/*      */ 
/*      */     
/*  946 */     Possible<List<ApplicationCommandOptionData>> options = Possible.absent();
/*      */ 
/*      */     
/*  949 */     Possible<Boolean> dmPermission = Possible.absent();
/*      */ 
/*      */     
/*  952 */     Possible<Boolean> defaultPermission = Possible.absent();
/*      */     
/*  954 */     Optional<String> defaultMemberPermissions = Optional.empty();
/*      */     @JsonProperty("id")
/*      */     public void setId(Id id) {
/*  957 */       this.id = id;
/*      */     }
/*      */     @JsonProperty("version")
/*      */     public void setVersion(Id version) {
/*  961 */       this.version = version;
/*      */     }
/*      */     @JsonProperty("guild_id")
/*      */     public void setGuildId(Possible<Id> guildId) {
/*  965 */       this.guildId = guildId;
/*      */     }
/*      */     @JsonProperty("type")
/*      */     public void setType(Possible<Integer> type) {
/*  969 */       this.type = type;
/*      */     }
/*      */     @JsonProperty("application_id")
/*      */     public void setApplicationId(Id applicationId) {
/*  973 */       this.applicationId = applicationId;
/*      */     }
/*      */     @JsonProperty("name")
/*      */     public void setName(String name) {
/*  977 */       this.name = name;
/*      */     }
/*      */     @JsonProperty("name_localizations")
/*      */     public void setNameLocalizations(Possible<Optional<Map<String, String>>> nameLocalizations) {
/*  981 */       this.nameLocalizations = nameLocalizations;
/*      */     }
/*      */     @JsonProperty("description")
/*      */     public void setDescription(String description) {
/*  985 */       this.description = description;
/*      */     }
/*      */     @JsonProperty("description_localizations")
/*      */     public void setDescriptionLocalizations(Possible<Optional<Map<String, String>>> descriptionLocalizations) {
/*  989 */       this.descriptionLocalizations = descriptionLocalizations;
/*      */     }
/*      */     @JsonProperty("options")
/*      */     public void setOptions(Possible<List<ApplicationCommandOptionData>> options) {
/*  993 */       this.options = options;
/*      */     }
/*      */     @JsonProperty("dm_permission")
/*      */     public void setDmPermission(Possible<Boolean> dmPermission) {
/*  997 */       this.dmPermission = dmPermission;
/*      */     }
/*      */     @JsonProperty("default_permission")
/*      */     public void setDefaultPermission(Possible<Boolean> defaultPermission) {
/* 1001 */       this.defaultPermission = defaultPermission;
/*      */     }
/*      */     @JsonProperty("default_member_permissions")
/*      */     public void setDefaultMemberPermissions(Optional<String> defaultMemberPermissions) {
/* 1005 */       this.defaultMemberPermissions = defaultMemberPermissions;
/*      */     }
/*      */     public Id id() {
/* 1008 */       throw new UnsupportedOperationException();
/*      */     } public Id version() {
/* 1010 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Id> guildId() {
/* 1012 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> type() {
/* 1014 */       throw new UnsupportedOperationException();
/*      */     } public Id applicationId() {
/* 1016 */       throw new UnsupportedOperationException();
/*      */     } public String name() {
/* 1018 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<Map<String, String>>> nameLocalizations() {
/* 1020 */       throw new UnsupportedOperationException();
/*      */     } public String description() {
/* 1022 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<Map<String, String>>> descriptionLocalizations() {
/* 1024 */       throw new UnsupportedOperationException();
/*      */     } public Possible<List<ApplicationCommandOptionData>> options() {
/* 1026 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Boolean> dmPermission() {
/* 1028 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Boolean> defaultPermission() {
/* 1030 */       throw new UnsupportedOperationException();
/*      */     } public Optional<String> defaultMemberPermissions() {
/* 1032 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*      */   static ImmutableApplicationCommandData fromJson(Json json) {
/* 1043 */     Builder builder = builder();
/* 1044 */     if (json.id != null) {
/* 1045 */       builder.id(json.id);
/*      */     }
/* 1047 */     if (json.version != null) {
/* 1048 */       builder.version(json.version);
/*      */     }
/* 1050 */     if (json.guildId != null) {
/* 1051 */       builder.guildId(json.guildId);
/*      */     }
/* 1053 */     if (json.type != null) {
/* 1054 */       builder.type(json.type);
/*      */     }
/* 1056 */     if (json.applicationId != null) {
/* 1057 */       builder.applicationId(json.applicationId);
/*      */     }
/* 1059 */     if (json.name != null) {
/* 1060 */       builder.name(json.name);
/*      */     }
/* 1062 */     if (json.nameLocalizations != null) {
/* 1063 */       builder.nameLocalizations(json.nameLocalizations);
/*      */     }
/* 1065 */     if (json.description != null) {
/* 1066 */       builder.description(json.description);
/*      */     }
/* 1068 */     if (json.descriptionLocalizations != null) {
/* 1069 */       builder.descriptionLocalizations(json.descriptionLocalizations);
/*      */     }
/* 1071 */     if (json.options != null) {
/* 1072 */       builder.options(json.options);
/*      */     }
/* 1074 */     if (json.dmPermission != null) {
/* 1075 */       builder.dmPermission(json.dmPermission);
/*      */     }
/* 1077 */     if (json.defaultPermission != null) {
/* 1078 */       builder.defaultPermission(json.defaultPermission);
/*      */     }
/* 1080 */     if (json.defaultMemberPermissions != null) {
/* 1081 */       builder.defaultMemberPermissions(json.defaultMemberPermissions);
/*      */     }
/* 1083 */     return builder.build();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableApplicationCommandData of(Id id, Id version, Possible<Id> guildId, Possible<Integer> type, Id applicationId, String name, Possible<Optional<Map<String, String>>> nameLocalizations, String description, Possible<Optional<Map<String, String>>> descriptionLocalizations, Possible<List<ApplicationCommandOptionData>> options, Possible<Boolean> dmPermission, Possible<Boolean> defaultPermission, Optional<String> defaultMemberPermissions) {
/* 1104 */     return new ImmutableApplicationCommandData(id, version, guildId, type, applicationId, name, nameLocalizations, description, descriptionLocalizations, options, dmPermission, defaultPermission, defaultMemberPermissions);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableApplicationCommandData copyOf(ApplicationCommandData instance) {
/* 1115 */     if (instance instanceof ImmutableApplicationCommandData) {
/* 1116 */       return (ImmutableApplicationCommandData)instance;
/*      */     }
/* 1118 */     return builder()
/* 1119 */       .from(instance)
/* 1120 */       .build();
/*      */   }
/*      */   
/*      */   public boolean isGuildIdPresent() {
/* 1124 */     return !this.guildId_absent;
/*      */   }
/*      */   
/*      */   public long guildIdOrElse(long defaultValue) {
/* 1128 */     return !this.guildId_absent ? this.guildId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isTypePresent() {
/* 1132 */     return !this.type_absent;
/*      */   }
/*      */   
/*      */   public Integer typeOrElse(Integer defaultValue) {
/* 1136 */     return !this.type_absent ? this.type_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isNameLocalizationsPresent() {
/* 1140 */     return !this.nameLocalizations_absent;
/*      */   }
/*      */   
/*      */   public Map<String, String> nameLocalizationsOrElse(Map<String, String> defaultValue) {
/* 1144 */     return !this.nameLocalizations_absent ? this.nameLocalizations_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isDescriptionLocalizationsPresent() {
/* 1148 */     return !this.descriptionLocalizations_absent;
/*      */   }
/*      */   
/*      */   public Map<String, String> descriptionLocalizationsOrElse(Map<String, String> defaultValue) {
/* 1152 */     return !this.descriptionLocalizations_absent ? this.descriptionLocalizations_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isOptionsPresent() {
/* 1156 */     return !this.options_absent;
/*      */   }
/*      */   
/*      */   public List<ApplicationCommandOptionData> optionsOrElse(List<ApplicationCommandOptionData> defaultValue) {
/* 1160 */     return !this.options_absent ? this.options_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isDmPermissionPresent() {
/* 1164 */     return !this.dmPermission_absent;
/*      */   }
/*      */   
/*      */   public Boolean dmPermissionOrElse(Boolean defaultValue) {
/* 1168 */     return !this.dmPermission_absent ? this.dmPermission_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isDefaultPermissionPresent() {
/* 1172 */     return !this.defaultPermission_absent;
/*      */   }
/*      */   
/*      */   public Boolean defaultPermissionOrElse(Boolean defaultValue) {
/* 1176 */     return !this.defaultPermission_absent ? this.defaultPermission_value : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Builder builder() {
/* 1201 */     return new Builder();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Generated(from = "ApplicationCommandData", generator = "Immutables")
/*      */   public static final class Builder
/*      */   {
/*      */     private static final long INIT_BIT_NAME = 1L;
/*      */ 
/*      */     
/*      */     private static final long INIT_BIT_DESCRIPTION = 2L;
/*      */ 
/*      */     
/* 1215 */     private long initBits = 3L;
/*      */     
/* 1217 */     private Id id_id = null;
/* 1218 */     private Id version_id = null;
/* 1219 */     private Possible<Id> guildId_possible = Possible.absent();
/* 1220 */     private Possible<Integer> type_possible = Possible.absent();
/* 1221 */     private Id applicationId_id = null;
/* 1222 */     private Possible<Optional<Map<String, String>>> nameLocalizations_possible = Possible.absent();
/* 1223 */     private Possible<Optional<Map<String, String>>> descriptionLocalizations_possible = Possible.absent();
/* 1224 */     private List<ApplicationCommandOptionData> options_list = null;
/* 1225 */     private Possible<Boolean> dmPermission_possible = Possible.absent();
/* 1226 */     private Possible<Boolean> defaultPermission_possible = Possible.absent();
/*      */ 
/*      */ 
/*      */     
/*      */     private String name;
/*      */ 
/*      */ 
/*      */     
/*      */     private String description;
/*      */ 
/*      */     
/*      */     private String defaultMemberPermissions;
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(ApplicationCommandData instance) {
/* 1242 */       Objects.requireNonNull(instance, "instance");
/* 1243 */       id(instance.id());
/* 1244 */       version(instance.version());
/* 1245 */       guildId(instance.guildId());
/* 1246 */       type(instance.type());
/* 1247 */       applicationId(instance.applicationId());
/* 1248 */       name(instance.name());
/* 1249 */       nameLocalizations(instance.nameLocalizations());
/* 1250 */       description(instance.description());
/* 1251 */       descriptionLocalizations(instance.descriptionLocalizations());
/* 1252 */       options(instance.options());
/* 1253 */       dmPermission(instance.dmPermission());
/* 1254 */       defaultPermission(instance.defaultPermission());
/* 1255 */       Optional<String> defaultMemberPermissionsOptional = instance.defaultMemberPermissions();
/* 1256 */       if (defaultMemberPermissionsOptional.isPresent()) {
/* 1257 */         defaultMemberPermissions(defaultMemberPermissionsOptional);
/*      */       }
/* 1259 */       return this;
/*      */     }
/*      */     
/*      */     public Builder id(String value) {
/* 1263 */       this.id_id = Id.of(value);
/* 1264 */       return this;
/*      */     }
/*      */     
/*      */     public Builder id(long value) {
/* 1268 */       this.id_id = Id.of(value);
/* 1269 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("id")
/*      */     public Builder id(Id value) {
/* 1274 */       this.id_id = value;
/* 1275 */       return this;
/*      */     }
/*      */     
/*      */     public Builder version(String value) {
/* 1279 */       this.version_id = Id.of(value);
/* 1280 */       return this;
/*      */     }
/*      */     
/*      */     public Builder version(long value) {
/* 1284 */       this.version_id = Id.of(value);
/* 1285 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("version")
/*      */     public Builder version(Id value) {
/* 1290 */       this.version_id = value;
/* 1291 */       return this;
/*      */     }
/*      */     
/*      */     public Builder guildId(String value) {
/* 1295 */       this.guildId_possible = Possible.of(Id.of(value));
/* 1296 */       return this;
/*      */     }
/*      */     
/*      */     public Builder guildId(long value) {
/* 1300 */       this.guildId_possible = Possible.of(Id.of(value));
/* 1301 */       return this;
/*      */     }
/*      */     
/*      */     public Builder guildId(Id value) {
/* 1305 */       this.guildId_possible = Possible.of(value);
/* 1306 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("guild_id")
/*      */     public Builder guildId(Possible<Id> value) {
/* 1311 */       this.guildId_possible = value;
/* 1312 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("type")
/*      */     public Builder type(Possible<Integer> value) {
/* 1317 */       this.type_possible = value;
/* 1318 */       return this;
/*      */     }
/*      */     
/*      */     public Builder type(Integer value) {
/* 1322 */       this.type_possible = Possible.of(value);
/* 1323 */       return this;
/*      */     }
/*      */     
/*      */     public Builder applicationId(String value) {
/* 1327 */       this.applicationId_id = Id.of(value);
/* 1328 */       return this;
/*      */     }
/*      */     
/*      */     public Builder applicationId(long value) {
/* 1332 */       this.applicationId_id = Id.of(value);
/* 1333 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("application_id")
/*      */     public Builder applicationId(Id value) {
/* 1338 */       this.applicationId_id = value;
/* 1339 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("name")
/*      */     public final Builder name(String name) {
/* 1349 */       this.name = Objects.<String>requireNonNull(name, "name");
/* 1350 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 1351 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("name_localizations")
/*      */     public Builder nameLocalizations(Possible<Optional<Map<String, String>>> value) {
/* 1356 */       this.nameLocalizations_possible = value;
/* 1357 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder nameLocalizations(@Nullable Map<String, String> value) {
/* 1362 */       this.nameLocalizations_possible = Possible.of(Optional.ofNullable(value));
/* 1363 */       return this;
/*      */     }
/*      */     
/*      */     public Builder nameLocalizationsOrNull(@Nullable Map<String, String> value) {
/* 1367 */       this.nameLocalizations_possible = Possible.of(Optional.ofNullable(value));
/* 1368 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("description")
/*      */     public final Builder description(String description) {
/* 1378 */       this.description = Objects.<String>requireNonNull(description, "description");
/* 1379 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 1380 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("description_localizations")
/*      */     public Builder descriptionLocalizations(Possible<Optional<Map<String, String>>> value) {
/* 1385 */       this.descriptionLocalizations_possible = value;
/* 1386 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder descriptionLocalizations(@Nullable Map<String, String> value) {
/* 1391 */       this.descriptionLocalizations_possible = Possible.of(Optional.ofNullable(value));
/* 1392 */       return this;
/*      */     }
/*      */     
/*      */     public Builder descriptionLocalizationsOrNull(@Nullable Map<String, String> value) {
/* 1396 */       this.descriptionLocalizations_possible = Possible.of(Optional.ofNullable(value));
/* 1397 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addOption(ApplicationCommandOptionData element) {
/* 1401 */       options_getOrCreate().add(element);
/* 1402 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addAllOptions(List<ApplicationCommandOptionData> elements) {
/* 1406 */       options_getOrCreate().addAll(elements);
/* 1407 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("options")
/*      */     public Builder options(Possible<List<ApplicationCommandOptionData>> elements) {
/* 1412 */       this.options_list = null;
/* 1413 */       elements.toOptional().ifPresent(e -> options_getOrCreate().addAll(e));
/* 1414 */       return this;
/*      */     }
/*      */     
/*      */     public Builder options(List<ApplicationCommandOptionData> elements) {
/* 1418 */       this.options_list = new ArrayList<>(elements);
/* 1419 */       return this;
/*      */     }
/*      */     
/*      */     public Builder options(Iterable<ApplicationCommandOptionData> elements) {
/* 1423 */       this.options_list = (List<ApplicationCommandOptionData>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 1424 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("dm_permission")
/*      */     public Builder dmPermission(Possible<Boolean> value) {
/* 1429 */       this.dmPermission_possible = value;
/* 1430 */       return this;
/*      */     }
/*      */     
/*      */     public Builder dmPermission(Boolean value) {
/* 1434 */       this.dmPermission_possible = Possible.of(value);
/* 1435 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("default_permission")
/*      */     public Builder defaultPermission(Possible<Boolean> value) {
/* 1440 */       this.defaultPermission_possible = value;
/* 1441 */       return this;
/*      */     }
/*      */     
/*      */     public Builder defaultPermission(Boolean value) {
/* 1445 */       this.defaultPermission_possible = Possible.of(value);
/* 1446 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder defaultMemberPermissions(String defaultMemberPermissions) {
/* 1455 */       this.defaultMemberPermissions = Objects.<String>requireNonNull(defaultMemberPermissions, "defaultMemberPermissions");
/* 1456 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("default_member_permissions")
/*      */     public final Builder defaultMemberPermissions(Optional<String> defaultMemberPermissions) {
/* 1466 */       this.defaultMemberPermissions = defaultMemberPermissions.orElse(null);
/* 1467 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ImmutableApplicationCommandData build() {
/* 1476 */       if (this.initBits != 0L) {
/* 1477 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*      */       }
/* 1479 */       return new ImmutableApplicationCommandData(null, 
/*      */           
/* 1481 */           id_build(), 
/* 1482 */           version_build(), 
/* 1483 */           guildId_build(), 
/* 1484 */           type_build(), 
/* 1485 */           applicationId_build(), this.name, 
/*      */           
/* 1487 */           nameLocalizations_build(), this.description, 
/*      */           
/* 1489 */           descriptionLocalizations_build(), 
/* 1490 */           options_build(), 
/* 1491 */           dmPermission_build(), 
/* 1492 */           defaultPermission_build(), this.defaultMemberPermissions);
/*      */     }
/*      */ 
/*      */     
/*      */     private String formatRequiredAttributesMessage() {
/* 1497 */       List<String> attributes = new ArrayList<>();
/* 1498 */       if ((this.initBits & 0x1L) != 0L) attributes.add("name"); 
/* 1499 */       if ((this.initBits & 0x2L) != 0L) attributes.add("description"); 
/* 1500 */       return "Cannot build ApplicationCommandData, some of required attributes are not set " + attributes;
/*      */     }
/*      */     
/*      */     private Id id_build() {
/* 1504 */       return this.id_id;
/*      */     }
/*      */     
/*      */     private Id version_build() {
/* 1508 */       return this.version_id;
/*      */     }
/*      */     
/*      */     private Possible<Id> guildId_build() {
/* 1512 */       return this.guildId_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> type_build() {
/* 1516 */       return this.type_possible;
/*      */     }
/*      */     
/*      */     private Id applicationId_build() {
/* 1520 */       return this.applicationId_id;
/*      */     }
/*      */     
/*      */     private Possible<Optional<Map<String, String>>> nameLocalizations_build() {
/* 1524 */       return this.nameLocalizations_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<Map<String, String>>> descriptionLocalizations_build() {
/* 1528 */       return this.descriptionLocalizations_possible;
/*      */     }
/*      */     
/*      */     private Possible<List<ApplicationCommandOptionData>> options_build() {
/* 1532 */       return (this.options_list == null) ? Possible.absent() : 
/* 1533 */         Possible.of(this.options_list);
/*      */     }
/*      */     
/*      */     private List<ApplicationCommandOptionData> options_getOrCreate() {
/* 1537 */       if (this.options_list == null) {
/* 1538 */         this.options_list = new ArrayList<>();
/*      */       }
/* 1540 */       return this.options_list;
/*      */     }
/*      */     
/*      */     private Possible<Boolean> dmPermission_build() {
/* 1544 */       return this.dmPermission_possible;
/*      */     }
/*      */     
/*      */     private Possible<Boolean> defaultPermission_build() {
/* 1548 */       return this.defaultPermission_possible;
/*      */     }
/*      */     
/*      */     private Builder() {}
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableApplicationCommandData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */