/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ @JsonSerialize(as = ImmutableMessageCreateRequest.class)
/*    */ @JsonDeserialize(as = ImmutableMessageCreateRequest.class)
/*    */ @Immutable
/*    */ public interface MessageCreateRequest extends MessageSendRequestBase {
/*    */   static ImmutableMessageCreateRequest.Builder builder() {
/* 13 */     return ImmutableMessageCreateRequest.builder();
/*    */   }
/*    */   
/*    */   Possible<Object> nonce();
/*    */   
/*    */   @Deprecated
/*    */   Possible<EmbedData> embed();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\MessageCreateRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */