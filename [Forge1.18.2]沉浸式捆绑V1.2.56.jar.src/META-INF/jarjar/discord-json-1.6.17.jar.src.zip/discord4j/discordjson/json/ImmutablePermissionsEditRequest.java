/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "PermissionsEditRequest", generator = "Immutables")
/*     */ public final class ImmutablePermissionsEditRequest
/*     */   implements PermissionsEditRequest
/*     */ {
/*     */   private final long allow;
/*     */   private final long deny;
/*     */   private final int type;
/*     */   
/*     */   private ImmutablePermissionsEditRequest(long allow, long deny, int type) {
/*  30 */     this.allow = allow;
/*  31 */     this.deny = deny;
/*  32 */     this.type = type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("allow")
/*     */   public long allow() {
/*  41 */     return this.allow;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("deny")
/*     */   public long deny() {
/*  50 */     return this.deny;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("type")
/*     */   public int type() {
/*  59 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutablePermissionsEditRequest withAllow(long value) {
/*  69 */     if (this.allow == value) return this; 
/*  70 */     return new ImmutablePermissionsEditRequest(value, this.deny, this.type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutablePermissionsEditRequest withDeny(long value) {
/*  80 */     if (this.deny == value) return this; 
/*  81 */     return new ImmutablePermissionsEditRequest(this.allow, value, this.type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutablePermissionsEditRequest withType(int value) {
/*  91 */     if (this.type == value) return this; 
/*  92 */     return new ImmutablePermissionsEditRequest(this.allow, this.deny, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 101 */     if (this == another) return true; 
/* 102 */     return (another instanceof ImmutablePermissionsEditRequest && 
/* 103 */       equalTo(0, (ImmutablePermissionsEditRequest)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutablePermissionsEditRequest another) {
/* 107 */     return (this.allow == another.allow && this.deny == another.deny && this.type == another.type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 118 */     int h = 5381;
/* 119 */     h += (h << 5) + Long.hashCode(this.allow);
/* 120 */     h += (h << 5) + Long.hashCode(this.deny);
/* 121 */     h += (h << 5) + this.type;
/* 122 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 131 */     return "PermissionsEditRequest{allow=" + this.allow + ", deny=" + this.deny + ", type=" + this.type + "}";
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "PermissionsEditRequest", generator = "Immutables")
/*     */   static final class Json
/*     */     implements PermissionsEditRequest
/*     */   {
/*     */     long allow;
/*     */     
/*     */     boolean allowIsSet;
/*     */     
/*     */     long deny;
/*     */     
/*     */     boolean denyIsSet;
/*     */     
/*     */     int type;
/*     */     boolean typeIsSet;
/*     */     
/*     */     @JsonProperty("allow")
/*     */     public void setAllow(long allow) {
/* 155 */       this.allow = allow;
/* 156 */       this.allowIsSet = true;
/*     */     }
/*     */     @JsonProperty("deny")
/*     */     public void setDeny(long deny) {
/* 160 */       this.deny = deny;
/* 161 */       this.denyIsSet = true;
/*     */     }
/*     */     @JsonProperty("type")
/*     */     public void setType(int type) {
/* 165 */       this.type = type;
/* 166 */       this.typeIsSet = true;
/*     */     }
/*     */     public long allow() {
/* 169 */       throw new UnsupportedOperationException();
/*     */     } public long deny() {
/* 171 */       throw new UnsupportedOperationException();
/*     */     } public int type() {
/* 173 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutablePermissionsEditRequest fromJson(Json json) {
/* 184 */     Builder builder = builder();
/* 185 */     if (json.allowIsSet) {
/* 186 */       builder.allow(json.allow);
/*     */     }
/* 188 */     if (json.denyIsSet) {
/* 189 */       builder.deny(json.deny);
/*     */     }
/* 191 */     if (json.typeIsSet) {
/* 192 */       builder.type(json.type);
/*     */     }
/* 194 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutablePermissionsEditRequest of(long allow, long deny, int type) {
/* 205 */     return new ImmutablePermissionsEditRequest(allow, deny, type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutablePermissionsEditRequest copyOf(PermissionsEditRequest instance) {
/* 216 */     if (instance instanceof ImmutablePermissionsEditRequest) {
/* 217 */       return (ImmutablePermissionsEditRequest)instance;
/*     */     }
/* 219 */     return builder()
/* 220 */       .from(instance)
/* 221 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 236 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "PermissionsEditRequest", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_ALLOW = 1L;
/*     */ 
/*     */     
/*     */     private static final long INIT_BIT_DENY = 2L;
/*     */     
/*     */     private static final long INIT_BIT_TYPE = 4L;
/*     */     
/* 251 */     private long initBits = 7L;
/*     */ 
/*     */ 
/*     */     
/*     */     private long allow;
/*     */ 
/*     */ 
/*     */     
/*     */     private long deny;
/*     */ 
/*     */ 
/*     */     
/*     */     private int type;
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(PermissionsEditRequest instance) {
/* 268 */       Objects.requireNonNull(instance, "instance");
/* 269 */       allow(instance.allow());
/* 270 */       deny(instance.deny());
/* 271 */       type(instance.type());
/* 272 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("allow")
/*     */     public final Builder allow(long allow) {
/* 282 */       this.allow = allow;
/* 283 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 284 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("deny")
/*     */     public final Builder deny(long deny) {
/* 294 */       this.deny = deny;
/* 295 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 296 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("type")
/*     */     public final Builder type(int type) {
/* 306 */       this.type = type;
/* 307 */       this.initBits &= 0xFFFFFFFFFFFFFFFBL;
/* 308 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutablePermissionsEditRequest build() {
/* 317 */       if (this.initBits != 0L) {
/* 318 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 320 */       return new ImmutablePermissionsEditRequest(this.allow, this.deny, this.type);
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 324 */       List<String> attributes = new ArrayList<>();
/* 325 */       if ((this.initBits & 0x1L) != 0L) attributes.add("allow"); 
/* 326 */       if ((this.initBits & 0x2L) != 0L) attributes.add("deny"); 
/* 327 */       if ((this.initBits & 0x4L) != 0L) attributes.add("type"); 
/* 328 */       return "Cannot build PermissionsEditRequest, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutablePermissionsEditRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */