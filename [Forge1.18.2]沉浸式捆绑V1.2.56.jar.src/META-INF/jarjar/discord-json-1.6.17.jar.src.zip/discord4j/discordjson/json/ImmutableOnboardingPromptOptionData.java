/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.Id;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.LongStream;
/*     */ import java.util.stream.StreamSupport;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "OnboardingPromptOptionData", generator = "Immutables")
/*     */ public final class ImmutableOnboardingPromptOptionData
/*     */   implements OnboardingPromptOptionData
/*     */ {
/*     */   private final long id_value;
/*     */   private final long[] channelsIds_value;
/*     */   private final long[] rolesIds_value;
/*     */   private final EmojiData emoji;
/*     */   private final String title;
/*     */   private final String description;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private ImmutableOnboardingPromptOptionData(Id id, List<Id> channelsIds, List<Id> rolesIds, EmojiData emoji, String title, Optional<String> description) {
/*  44 */     Id id$impl = id;
/*  45 */     List<Id> channelsIds$impl = channelsIds;
/*  46 */     List<Id> rolesIds$impl = rolesIds;
/*  47 */     this.emoji = Objects.<EmojiData>requireNonNull(emoji, "emoji");
/*  48 */     this.title = Objects.<String>requireNonNull(title, "title");
/*  49 */     this.description = description.orElse(null);
/*  50 */     this.id_value = id$impl.asLong();
/*  51 */     this
/*     */       
/*  53 */       .channelsIds_value = channelsIds$impl.stream().mapToLong(Id::asLong).toArray();
/*  54 */     this
/*     */       
/*  56 */       .rolesIds_value = rolesIds$impl.stream().mapToLong(Id::asLong).toArray();
/*  57 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableOnboardingPromptOptionData(ImmutableOnboardingPromptOptionData original, Id id, List<Id> channelsIds, List<Id> rolesIds, EmojiData emoji, String title, String description) {
/*  68 */     Id id$impl = id;
/*  69 */     List<Id> channelsIds$impl = channelsIds;
/*  70 */     List<Id> rolesIds$impl = rolesIds;
/*  71 */     this.emoji = emoji;
/*  72 */     this.title = title;
/*  73 */     this.description = description;
/*  74 */     this.id_value = id$impl.asLong();
/*  75 */     this
/*     */       
/*  77 */       .channelsIds_value = channelsIds$impl.stream().mapToLong(Id::asLong).toArray();
/*  78 */     this
/*     */       
/*  80 */       .rolesIds_value = rolesIds$impl.stream().mapToLong(Id::asLong).toArray();
/*  81 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  87 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "OnboardingPromptOptionData", generator = "Immutables")
/*     */   private final class InitShim {
/*     */     private String formatInitCycleMessage() {
/*  92 */       List<String> attributes = new ArrayList<>();
/*  93 */       return "Cannot build OnboardingPromptOptionData, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @JsonProperty("id")
/*     */   public Id id() {
/* 103 */     return Id.of(this.id_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("channel_ids")
/*     */   public List<Id> channelsIds() {
/* 112 */     return (List<Id>)LongStream.of(this.channelsIds_value)
/* 113 */       .mapToObj(Id::of)
/* 114 */       .collect(Collectors.toList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("role_ids")
/*     */   public List<Id> rolesIds() {
/* 123 */     return (List<Id>)LongStream.of(this.rolesIds_value)
/* 124 */       .mapToObj(Id::of)
/* 125 */       .collect(Collectors.toList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("emoji")
/*     */   public EmojiData emoji() {
/* 134 */     return this.emoji;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("title")
/*     */   public String title() {
/* 143 */     return this.title;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("description")
/*     */   public Optional<String> description() {
/* 152 */     return Optional.ofNullable(this.description);
/*     */   }
/*     */   
/*     */   public ImmutableOnboardingPromptOptionData withId(long value) {
/* 156 */     Id newValue = Id.of(value);
/* 157 */     return new ImmutableOnboardingPromptOptionData(this, newValue, channelsIds(), rolesIds(), this.emoji, this.title, this.description);
/*     */   }
/*     */   
/*     */   public ImmutableOnboardingPromptOptionData withId(String value) {
/* 161 */     Id newValue = Id.of(value);
/* 162 */     return new ImmutableOnboardingPromptOptionData(this, newValue, channelsIds(), rolesIds(), this.emoji, this.title, this.description);
/*     */   }
/*     */   
/*     */   public ImmutableOnboardingPromptOptionData withChannelsIds(List<Id> value) {
/* 166 */     List<Id> newValue = value;
/* 167 */     return new ImmutableOnboardingPromptOptionData(this, id(), newValue, rolesIds(), this.emoji, this.title, this.description);
/*     */   }
/*     */   
/*     */   public ImmutableOnboardingPromptOptionData withRolesIds(List<Id> value) {
/* 171 */     List<Id> newValue = value;
/* 172 */     return new ImmutableOnboardingPromptOptionData(this, id(), channelsIds(), newValue, this.emoji, this.title, this.description);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableOnboardingPromptOptionData withEmoji(EmojiData value) {
/* 182 */     if (this.emoji == value) return this; 
/* 183 */     EmojiData newValue = Objects.<EmojiData>requireNonNull(value, "emoji");
/* 184 */     return new ImmutableOnboardingPromptOptionData(this, id(), channelsIds(), rolesIds(), newValue, this.title, this.description);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableOnboardingPromptOptionData withTitle(String value) {
/* 194 */     String newValue = Objects.<String>requireNonNull(value, "title");
/* 195 */     if (this.title.equals(newValue)) return this; 
/* 196 */     return new ImmutableOnboardingPromptOptionData(this, id(), channelsIds(), rolesIds(), this.emoji, newValue, this.description);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableOnboardingPromptOptionData withDescription(String value) {
/* 205 */     String newValue = Objects.<String>requireNonNull(value, "description");
/* 206 */     if (Objects.equals(this.description, newValue)) return this; 
/* 207 */     return new ImmutableOnboardingPromptOptionData(this, id(), channelsIds(), rolesIds(), this.emoji, this.title, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableOnboardingPromptOptionData withDescription(Optional<String> optional) {
/* 217 */     String value = optional.orElse(null);
/* 218 */     if (Objects.equals(this.description, value)) return this; 
/* 219 */     return new ImmutableOnboardingPromptOptionData(this, id(), channelsIds(), rolesIds(), this.emoji, this.title, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 228 */     if (this == another) return true; 
/* 229 */     return (another instanceof ImmutableOnboardingPromptOptionData && 
/* 230 */       equalTo(0, (ImmutableOnboardingPromptOptionData)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableOnboardingPromptOptionData another) {
/* 234 */     return (Objects.equals(Long.valueOf(this.id_value), Long.valueOf(another.id_value)) && 
/* 235 */       Objects.equals(this.channelsIds_value, another.channelsIds_value) && 
/* 236 */       Objects.equals(this.rolesIds_value, another.rolesIds_value) && this.emoji
/* 237 */       .equals(another.emoji) && this.title
/* 238 */       .equals(another.title) && 
/* 239 */       Objects.equals(this.description, another.description));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 248 */     int h = 5381;
/* 249 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.id_value));
/* 250 */     h += (h << 5) + Objects.hashCode(this.channelsIds_value);
/* 251 */     h += (h << 5) + Objects.hashCode(this.rolesIds_value);
/* 252 */     h += (h << 5) + this.emoji.hashCode();
/* 253 */     h += (h << 5) + this.title.hashCode();
/* 254 */     h += (h << 5) + Objects.hashCode(this.description);
/* 255 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 264 */     StringBuilder builder = new StringBuilder("OnboardingPromptOptionData{");
/* 265 */     builder.append("id=").append(Objects.toString(Long.valueOf(this.id_value)));
/* 266 */     builder.append(", ");
/* 267 */     builder.append("channelsIds=").append(Objects.toString(this.channelsIds_value));
/* 268 */     builder.append(", ");
/* 269 */     builder.append("rolesIds=").append(Objects.toString(this.rolesIds_value));
/* 270 */     builder.append(", ");
/* 271 */     builder.append("emoji=").append(this.emoji);
/* 272 */     builder.append(", ");
/* 273 */     builder.append("title=").append(this.title);
/* 274 */     if (this.description != null) {
/* 275 */       builder.append(", ");
/* 276 */       builder.append("description=").append(this.description);
/*     */     } 
/* 278 */     return builder.append("}").toString();
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "OnboardingPromptOptionData", generator = "Immutables")
/*     */   static final class Json
/*     */     implements OnboardingPromptOptionData
/*     */   {
/*     */     Id id;
/*     */     
/*     */     List<Id> channelsIds;
/*     */     List<Id> rolesIds;
/*     */     EmojiData emoji;
/*     */     String title;
/* 295 */     Optional<String> description = Optional.empty();
/*     */     @JsonProperty("id")
/*     */     public void setId(Id id) {
/* 298 */       this.id = id;
/*     */     }
/*     */     @JsonProperty("channel_ids")
/*     */     public void setChannelsIds(List<Id> channelsIds) {
/* 302 */       this.channelsIds = channelsIds;
/*     */     }
/*     */     @JsonProperty("role_ids")
/*     */     public void setRolesIds(List<Id> rolesIds) {
/* 306 */       this.rolesIds = rolesIds;
/*     */     }
/*     */     @JsonProperty("emoji")
/*     */     public void setEmoji(EmojiData emoji) {
/* 310 */       this.emoji = emoji;
/*     */     }
/*     */     @JsonProperty("title")
/*     */     public void setTitle(String title) {
/* 314 */       this.title = title;
/*     */     }
/*     */     @JsonProperty("description")
/*     */     public void setDescription(Optional<String> description) {
/* 318 */       this.description = description;
/*     */     }
/*     */     public Id id() {
/* 321 */       throw new UnsupportedOperationException();
/*     */     } public List<Id> channelsIds() {
/* 323 */       throw new UnsupportedOperationException();
/*     */     } public List<Id> rolesIds() {
/* 325 */       throw new UnsupportedOperationException();
/*     */     } public EmojiData emoji() {
/* 327 */       throw new UnsupportedOperationException();
/*     */     } public String title() {
/* 329 */       throw new UnsupportedOperationException();
/*     */     } public Optional<String> description() {
/* 331 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableOnboardingPromptOptionData fromJson(Json json) {
/* 342 */     Builder builder = builder();
/* 343 */     if (json.id != null) {
/* 344 */       builder.id(json.id);
/*     */     }
/* 346 */     if (json.channelsIds != null) {
/* 347 */       builder.channelsIds(json.channelsIds);
/*     */     }
/* 349 */     if (json.rolesIds != null) {
/* 350 */       builder.rolesIds(json.rolesIds);
/*     */     }
/* 352 */     if (json.emoji != null) {
/* 353 */       builder.emoji(json.emoji);
/*     */     }
/* 355 */     if (json.title != null) {
/* 356 */       builder.title(json.title);
/*     */     }
/* 358 */     if (json.description != null) {
/* 359 */       builder.description(json.description);
/*     */     }
/* 361 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableOnboardingPromptOptionData of(Id id, List<Id> channelsIds, List<Id> rolesIds, EmojiData emoji, String title, Optional<String> description) {
/* 375 */     return new ImmutableOnboardingPromptOptionData(id, channelsIds, rolesIds, emoji, title, description);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableOnboardingPromptOptionData copyOf(OnboardingPromptOptionData instance) {
/* 386 */     if (instance instanceof ImmutableOnboardingPromptOptionData) {
/* 387 */       return (ImmutableOnboardingPromptOptionData)instance;
/*     */     }
/* 389 */     return builder()
/* 390 */       .from(instance)
/* 391 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 409 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "OnboardingPromptOptionData", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_EMOJI = 1L;
/*     */ 
/*     */     
/*     */     private static final long INIT_BIT_TITLE = 2L;
/*     */ 
/*     */     
/* 423 */     private long initBits = 3L;
/*     */     
/* 425 */     private Id id_id = null;
/* 426 */     private List<Long> channelsIds_list = null;
/* 427 */     private List<Long> rolesIds_list = null;
/*     */ 
/*     */ 
/*     */     
/*     */     private EmojiData emoji;
/*     */ 
/*     */ 
/*     */     
/*     */     private String title;
/*     */ 
/*     */     
/*     */     private String description;
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(OnboardingPromptOptionData instance) {
/* 443 */       Objects.requireNonNull(instance, "instance");
/* 444 */       id(instance.id());
/* 445 */       channelsIds(instance.channelsIds());
/* 446 */       rolesIds(instance.rolesIds());
/* 447 */       emoji(instance.emoji());
/* 448 */       title(instance.title());
/* 449 */       Optional<String> descriptionOptional = instance.description();
/* 450 */       if (descriptionOptional.isPresent()) {
/* 451 */         description(descriptionOptional);
/*     */       }
/* 453 */       return this;
/*     */     }
/*     */     
/*     */     public Builder id(String value) {
/* 457 */       this.id_id = Id.of(value);
/* 458 */       return this;
/*     */     }
/*     */     
/*     */     public Builder id(long value) {
/* 462 */       this.id_id = Id.of(value);
/* 463 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("id")
/*     */     public Builder id(Id value) {
/* 468 */       this.id_id = value;
/* 469 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addChannelsId(long element) {
/* 473 */       channelsIds_getOrCreate().add(Long.valueOf(element));
/* 474 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addChannelsId(String element) {
/* 478 */       channelsIds_getOrCreate().add(Long.valueOf(Id.of(element).asLong()));
/* 479 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addChannelsId(Id element) {
/* 483 */       channelsIds_getOrCreate().add(Long.valueOf(element.asLong()));
/* 484 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addAllChannelsIds(List<Long> elements) {
/* 488 */       channelsIds_getOrCreate().addAll(elements);
/* 489 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("channel_ids")
/*     */     public Builder channelsIds(List<Id> elements) {
/* 494 */       this.channelsIds_list = (List<Long>)elements.stream().map(Id::asLong).collect(Collectors.toList());
/* 495 */       return this;
/*     */     }
/*     */     
/*     */     public Builder channelsIds(Iterable<Id> elements) {
/* 499 */       this
/*     */         
/* 501 */         .channelsIds_list = (List<Long>)StreamSupport.stream(elements.spliterator(), false).map(Id::asLong).collect(Collectors.toList());
/* 502 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addRolesId(long element) {
/* 506 */       rolesIds_getOrCreate().add(Long.valueOf(element));
/* 507 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addRolesId(String element) {
/* 511 */       rolesIds_getOrCreate().add(Long.valueOf(Id.of(element).asLong()));
/* 512 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addRolesId(Id element) {
/* 516 */       rolesIds_getOrCreate().add(Long.valueOf(element.asLong()));
/* 517 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addAllRolesIds(List<Long> elements) {
/* 521 */       rolesIds_getOrCreate().addAll(elements);
/* 522 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("role_ids")
/*     */     public Builder rolesIds(List<Id> elements) {
/* 527 */       this.rolesIds_list = (List<Long>)elements.stream().map(Id::asLong).collect(Collectors.toList());
/* 528 */       return this;
/*     */     }
/*     */     
/*     */     public Builder rolesIds(Iterable<Id> elements) {
/* 532 */       this
/*     */         
/* 534 */         .rolesIds_list = (List<Long>)StreamSupport.stream(elements.spliterator(), false).map(Id::asLong).collect(Collectors.toList());
/* 535 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("emoji")
/*     */     public final Builder emoji(EmojiData emoji) {
/* 545 */       this.emoji = Objects.<EmojiData>requireNonNull(emoji, "emoji");
/* 546 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 547 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("title")
/*     */     public final Builder title(String title) {
/* 557 */       this.title = Objects.<String>requireNonNull(title, "title");
/* 558 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 559 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder description(String description) {
/* 568 */       this.description = Objects.<String>requireNonNull(description, "description");
/* 569 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("description")
/*     */     public final Builder description(Optional<String> description) {
/* 579 */       this.description = description.orElse(null);
/* 580 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableOnboardingPromptOptionData build() {
/* 589 */       if (this.initBits != 0L) {
/* 590 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 592 */       return new ImmutableOnboardingPromptOptionData(null, id_build(), channelsIds_build(), rolesIds_build(), this.emoji, this.title, this.description);
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 596 */       List<String> attributes = new ArrayList<>();
/* 597 */       if ((this.initBits & 0x1L) != 0L) attributes.add("emoji"); 
/* 598 */       if ((this.initBits & 0x2L) != 0L) attributes.add("title"); 
/* 599 */       return "Cannot build OnboardingPromptOptionData, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Id id_build() {
/* 603 */       return this.id_id;
/*     */     }
/*     */     
/*     */     private List<Id> channelsIds_build() {
/* 607 */       return (List<Id>)channelsIds_getOrCreate().stream().map(Id::of).collect(Collectors.toList());
/*     */     }
/*     */     
/*     */     private List<Long> channelsIds_getOrCreate() {
/* 611 */       if (this.channelsIds_list == null) {
/* 612 */         this.channelsIds_list = new ArrayList<>();
/*     */       }
/* 614 */       return this.channelsIds_list;
/*     */     }
/*     */     
/*     */     private List<Id> rolesIds_build() {
/* 618 */       return (List<Id>)rolesIds_getOrCreate().stream().map(Id::of).collect(Collectors.toList());
/*     */     }
/*     */     
/*     */     private List<Long> rolesIds_getOrCreate() {
/* 622 */       if (this.rolesIds_list == null) {
/* 623 */         this.rolesIds_list = new ArrayList<>();
/*     */       }
/* 625 */       return this.rolesIds_list;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableOnboardingPromptOptionData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */