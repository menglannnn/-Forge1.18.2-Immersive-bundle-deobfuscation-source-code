/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.StreamSupport;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "GuildEmojiModifyRequest", generator = "Immutables")
/*     */ public final class ImmutableGuildEmojiModifyRequest
/*     */   implements GuildEmojiModifyRequest
/*     */ {
/*     */   private final String name_value;
/*     */   private final boolean name_absent;
/*     */   private final List<String> roles_value;
/*     */   private final boolean roles_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private ImmutableGuildEmojiModifyRequest(Possible<String> name, Possible<List<String>> roles) {
/*  37 */     Possible<String> name$impl = name;
/*  38 */     Possible<List<String>> roles$impl = roles;
/*  39 */     this.name_value = name$impl.toOptional().orElse(null);
/*  40 */     this.name_absent = name$impl.isAbsent();
/*  41 */     this.roles_value = roles$impl.toOptional().orElse(null);
/*  42 */     this.roles_absent = roles$impl.isAbsent();
/*  43 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableGuildEmojiModifyRequest(ImmutableGuildEmojiModifyRequest original, Possible<String> name, Possible<List<String>> roles) {
/*  50 */     Possible<String> name$impl = name;
/*  51 */     Possible<List<String>> roles$impl = roles;
/*  52 */     this.name_value = name$impl.toOptional().orElse(null);
/*  53 */     this.name_absent = name$impl.isAbsent();
/*  54 */     this.roles_value = roles$impl.toOptional().orElse(null);
/*  55 */     this.roles_absent = roles$impl.isAbsent();
/*  56 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  62 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "GuildEmojiModifyRequest", generator = "Immutables")
/*     */   private final class InitShim {
/*     */     private String formatInitCycleMessage() {
/*  67 */       List<String> attributes = new ArrayList<>();
/*  68 */       return "Cannot build GuildEmojiModifyRequest, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @JsonProperty("name")
/*     */   public Possible<String> name() {
/*  78 */     return this.name_absent ? Possible.absent() : Possible.of(this.name_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("roles")
/*     */   public Possible<List<String>> roles() {
/*  87 */     return this.roles_absent ? Possible.absent() : 
/*  88 */       Possible.of(this.roles_value);
/*     */   }
/*     */   
/*     */   public ImmutableGuildEmojiModifyRequest withName(Possible<String> value) {
/*  92 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  93 */     return new ImmutableGuildEmojiModifyRequest(this, newValue, roles());
/*     */   }
/*     */   
/*     */   public ImmutableGuildEmojiModifyRequest withName(String value) {
/*  97 */     Possible<String> newValue = Possible.of(value);
/*  98 */     return new ImmutableGuildEmojiModifyRequest(this, newValue, roles());
/*     */   }
/*     */   
/*     */   public ImmutableGuildEmojiModifyRequest withRoles(Possible<List<String>> possible) {
/* 102 */     Possible<List<String>> newValue = Objects.<Possible<List<String>>>requireNonNull(possible);
/* 103 */     return new ImmutableGuildEmojiModifyRequest(this, name(), newValue);
/*     */   }
/*     */   
/*     */   public ImmutableGuildEmojiModifyRequest withRoles(Iterable<String> elements) {
/* 107 */     Possible<List<String>> newValue = Possible.of(
/* 108 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/* 109 */     return new ImmutableGuildEmojiModifyRequest(this, name(), newValue);
/*     */   }
/*     */   
/*     */   @SafeVarargs
/*     */   public final ImmutableGuildEmojiModifyRequest withRoles(String... elements) {
/* 114 */     Possible<List<String>> newValue = Possible.of(Arrays.asList(elements));
/* 115 */     return new ImmutableGuildEmojiModifyRequest(this, name(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 124 */     if (this == another) return true; 
/* 125 */     return (another instanceof ImmutableGuildEmojiModifyRequest && 
/* 126 */       equalTo(0, (ImmutableGuildEmojiModifyRequest)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableGuildEmojiModifyRequest another) {
/* 130 */     return (name().equals(another.name()) && 
/* 131 */       Objects.equals(this.roles_value, another.roles_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 140 */     int h = 5381;
/* 141 */     h += (h << 5) + name().hashCode();
/* 142 */     h += (h << 5) + Objects.hashCode(this.roles_value);
/* 143 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 152 */     return "GuildEmojiModifyRequest{name=" + 
/* 153 */       name().toString() + ", roles=" + 
/* 154 */       Objects.toString(this.roles_value) + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "GuildEmojiModifyRequest", generator = "Immutables")
/*     */   static final class Json
/*     */     implements GuildEmojiModifyRequest
/*     */   {
/* 168 */     Possible<String> name = Possible.absent();
/*     */ 
/*     */     
/* 171 */     Possible<List<String>> roles = Possible.absent();
/*     */     
/*     */     @JsonProperty("name")
/*     */     public void setName(Possible<String> name) {
/* 175 */       this.name = name;
/*     */     }
/*     */     @JsonProperty("roles")
/*     */     public void setRoles(Possible<List<String>> roles) {
/* 179 */       this.roles = roles;
/*     */     }
/*     */     public Possible<String> name() {
/* 182 */       throw new UnsupportedOperationException();
/*     */     } public Possible<List<String>> roles() {
/* 184 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableGuildEmojiModifyRequest fromJson(Json json) {
/* 195 */     Builder builder = builder();
/* 196 */     if (json.name != null) {
/* 197 */       builder.name(json.name);
/*     */     }
/* 199 */     if (json.roles != null) {
/* 200 */       builder.roles(json.roles);
/*     */     }
/* 202 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableGuildEmojiModifyRequest of(Possible<String> name, Possible<List<String>> roles) {
/* 212 */     return new ImmutableGuildEmojiModifyRequest(name, roles);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableGuildEmojiModifyRequest copyOf(GuildEmojiModifyRequest instance) {
/* 223 */     if (instance instanceof ImmutableGuildEmojiModifyRequest) {
/* 224 */       return (ImmutableGuildEmojiModifyRequest)instance;
/*     */     }
/* 226 */     return builder()
/* 227 */       .from(instance)
/* 228 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isNamePresent() {
/* 232 */     return !this.name_absent;
/*     */   }
/*     */   
/*     */   public String nameOrElse(String defaultValue) {
/* 236 */     return !this.name_absent ? this.name_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isRolesPresent() {
/* 240 */     return !this.roles_absent;
/*     */   }
/*     */   
/*     */   public List<String> rolesOrElse(List<String> defaultValue) {
/* 244 */     return !this.roles_absent ? this.roles_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 258 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "GuildEmojiModifyRequest", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/* 270 */     private Possible<String> name_possible = Possible.absent();
/* 271 */     private List<String> roles_list = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(GuildEmojiModifyRequest instance) {
/* 284 */       Objects.requireNonNull(instance, "instance");
/* 285 */       name(instance.name());
/* 286 */       roles(instance.roles());
/* 287 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("name")
/*     */     public Builder name(Possible<String> value) {
/* 292 */       this.name_possible = value;
/* 293 */       return this;
/*     */     }
/*     */     
/*     */     public Builder name(String value) {
/* 297 */       this.name_possible = Possible.of(value);
/* 298 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addRole(String element) {
/* 302 */       roles_getOrCreate().add(element);
/* 303 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addAllRoles(List<String> elements) {
/* 307 */       roles_getOrCreate().addAll(elements);
/* 308 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("roles")
/*     */     public Builder roles(Possible<List<String>> elements) {
/* 313 */       this.roles_list = null;
/* 314 */       elements.toOptional().ifPresent(e -> roles_getOrCreate().addAll(e));
/* 315 */       return this;
/*     */     }
/*     */     
/*     */     public Builder roles(List<String> elements) {
/* 319 */       this.roles_list = new ArrayList<>(elements);
/* 320 */       return this;
/*     */     }
/*     */     
/*     */     public Builder roles(Iterable<String> elements) {
/* 324 */       this.roles_list = (List<String>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 325 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableGuildEmojiModifyRequest build() {
/* 334 */       return new ImmutableGuildEmojiModifyRequest(null, name_build(), roles_build());
/*     */     }
/*     */     
/*     */     private Possible<String> name_build() {
/* 338 */       return this.name_possible;
/*     */     }
/*     */     
/*     */     private Possible<List<String>> roles_build() {
/* 342 */       return (this.roles_list == null) ? Possible.absent() : 
/* 343 */         Possible.of(this.roles_list);
/*     */     }
/*     */     
/*     */     private List<String> roles_getOrCreate() {
/* 347 */       if (this.roles_list == null) {
/* 348 */         this.roles_list = new ArrayList<>();
/*     */       }
/* 350 */       return this.roles_list;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableGuildEmojiModifyRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */