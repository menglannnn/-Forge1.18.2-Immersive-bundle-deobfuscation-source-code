/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "EmbedImageData", generator = "Immutables")
/*     */ public final class ImmutableEmbedImageData
/*     */   implements EmbedImageData
/*     */ {
/*     */   private final String url_value;
/*     */   private final boolean url_absent;
/*     */   private final String proxyUrl_value;
/*     */   private final boolean proxyUrl_absent;
/*     */   private final Integer height_value;
/*     */   private final boolean height_absent;
/*     */   private final Integer width_value;
/*     */   private final boolean width_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private ImmutableEmbedImageData(Possible<String> url, Possible<String> proxyUrl, Possible<Integer> height, Possible<Integer> width) {
/*  39 */     Possible<String> url$impl = url;
/*  40 */     Possible<String> proxyUrl$impl = proxyUrl;
/*  41 */     Possible<Integer> height$impl = height;
/*  42 */     Possible<Integer> width$impl = width;
/*  43 */     this.url_value = url$impl.toOptional().orElse(null);
/*  44 */     this.url_absent = url$impl.isAbsent();
/*  45 */     this.proxyUrl_value = proxyUrl$impl.toOptional().orElse(null);
/*  46 */     this.proxyUrl_absent = proxyUrl$impl.isAbsent();
/*  47 */     this.height_value = height$impl.toOptional().orElse(null);
/*  48 */     this.height_absent = height$impl.isAbsent();
/*  49 */     this.width_value = width$impl.toOptional().orElse(null);
/*  50 */     this.width_absent = width$impl.isAbsent();
/*  51 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableEmbedImageData(ImmutableEmbedImageData original, Possible<String> url, Possible<String> proxyUrl, Possible<Integer> height, Possible<Integer> width) {
/*  60 */     Possible<String> url$impl = url;
/*  61 */     Possible<String> proxyUrl$impl = proxyUrl;
/*  62 */     Possible<Integer> height$impl = height;
/*  63 */     Possible<Integer> width$impl = width;
/*  64 */     this.url_value = url$impl.toOptional().orElse(null);
/*  65 */     this.url_absent = url$impl.isAbsent();
/*  66 */     this.proxyUrl_value = proxyUrl$impl.toOptional().orElse(null);
/*  67 */     this.proxyUrl_absent = proxyUrl$impl.isAbsent();
/*  68 */     this.height_value = height$impl.toOptional().orElse(null);
/*  69 */     this.height_absent = height$impl.isAbsent();
/*  70 */     this.width_value = width$impl.toOptional().orElse(null);
/*  71 */     this.width_absent = width$impl.isAbsent();
/*  72 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  78 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "EmbedImageData", generator = "Immutables")
/*     */   private final class InitShim {
/*     */     private String formatInitCycleMessage() {
/*  83 */       List<String> attributes = new ArrayList<>();
/*  84 */       return "Cannot build EmbedImageData, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @JsonProperty("url")
/*     */   public Possible<String> url() {
/*  94 */     return this.url_absent ? Possible.absent() : Possible.of(this.url_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("proxy_url")
/*     */   public Possible<String> proxyUrl() {
/* 103 */     return this.proxyUrl_absent ? Possible.absent() : Possible.of(this.proxyUrl_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("height")
/*     */   public Possible<Integer> height() {
/* 112 */     return this.height_absent ? Possible.absent() : Possible.of(this.height_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("width")
/*     */   public Possible<Integer> width() {
/* 121 */     return this.width_absent ? Possible.absent() : Possible.of(this.width_value);
/*     */   }
/*     */   
/*     */   public ImmutableEmbedImageData withUrl(Possible<String> value) {
/* 125 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 126 */     return new ImmutableEmbedImageData(this, newValue, proxyUrl(), height(), width());
/*     */   }
/*     */   
/*     */   public ImmutableEmbedImageData withUrl(String value) {
/* 130 */     Possible<String> newValue = Possible.of(value);
/* 131 */     return new ImmutableEmbedImageData(this, newValue, proxyUrl(), height(), width());
/*     */   }
/*     */   
/*     */   public ImmutableEmbedImageData withProxyUrl(Possible<String> value) {
/* 135 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 136 */     return new ImmutableEmbedImageData(this, url(), newValue, height(), width());
/*     */   }
/*     */   
/*     */   public ImmutableEmbedImageData withProxyUrl(String value) {
/* 140 */     Possible<String> newValue = Possible.of(value);
/* 141 */     return new ImmutableEmbedImageData(this, url(), newValue, height(), width());
/*     */   }
/*     */   
/*     */   public ImmutableEmbedImageData withHeight(Possible<Integer> value) {
/* 145 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 146 */     return new ImmutableEmbedImageData(this, url(), proxyUrl(), newValue, width());
/*     */   }
/*     */   
/*     */   public ImmutableEmbedImageData withHeight(Integer value) {
/* 150 */     Possible<Integer> newValue = Possible.of(value);
/* 151 */     return new ImmutableEmbedImageData(this, url(), proxyUrl(), newValue, width());
/*     */   }
/*     */   
/*     */   public ImmutableEmbedImageData withWidth(Possible<Integer> value) {
/* 155 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 156 */     return new ImmutableEmbedImageData(this, url(), proxyUrl(), height(), newValue);
/*     */   }
/*     */   
/*     */   public ImmutableEmbedImageData withWidth(Integer value) {
/* 160 */     Possible<Integer> newValue = Possible.of(value);
/* 161 */     return new ImmutableEmbedImageData(this, url(), proxyUrl(), height(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 170 */     if (this == another) return true; 
/* 171 */     return (another instanceof ImmutableEmbedImageData && 
/* 172 */       equalTo(0, (ImmutableEmbedImageData)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableEmbedImageData another) {
/* 176 */     return (url().equals(another.url()) && 
/* 177 */       proxyUrl().equals(another.proxyUrl()) && 
/* 178 */       height().equals(another.height()) && 
/* 179 */       width().equals(another.width()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 188 */     int h = 5381;
/* 189 */     h += (h << 5) + url().hashCode();
/* 190 */     h += (h << 5) + proxyUrl().hashCode();
/* 191 */     h += (h << 5) + height().hashCode();
/* 192 */     h += (h << 5) + width().hashCode();
/* 193 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 202 */     return "EmbedImageData{url=" + 
/* 203 */       url().toString() + ", proxyUrl=" + 
/* 204 */       proxyUrl().toString() + ", height=" + 
/* 205 */       height().toString() + ", width=" + 
/* 206 */       width().toString() + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "EmbedImageData", generator = "Immutables")
/*     */   static final class Json
/*     */     implements EmbedImageData
/*     */   {
/* 220 */     Possible<String> url = Possible.absent();
/*     */ 
/*     */     
/* 223 */     Possible<String> proxyUrl = Possible.absent();
/*     */ 
/*     */     
/* 226 */     Possible<Integer> height = Possible.absent();
/*     */ 
/*     */     
/* 229 */     Possible<Integer> width = Possible.absent();
/*     */     
/*     */     @JsonProperty("url")
/*     */     public void setUrl(Possible<String> url) {
/* 233 */       this.url = url;
/*     */     }
/*     */     @JsonProperty("proxy_url")
/*     */     public void setProxyUrl(Possible<String> proxyUrl) {
/* 237 */       this.proxyUrl = proxyUrl;
/*     */     }
/*     */     @JsonProperty("height")
/*     */     public void setHeight(Possible<Integer> height) {
/* 241 */       this.height = height;
/*     */     }
/*     */     @JsonProperty("width")
/*     */     public void setWidth(Possible<Integer> width) {
/* 245 */       this.width = width;
/*     */     }
/*     */     public Possible<String> url() {
/* 248 */       throw new UnsupportedOperationException();
/*     */     } public Possible<String> proxyUrl() {
/* 250 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Integer> height() {
/* 252 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Integer> width() {
/* 254 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableEmbedImageData fromJson(Json json) {
/* 265 */     Builder builder = builder();
/* 266 */     if (json.url != null) {
/* 267 */       builder.url(json.url);
/*     */     }
/* 269 */     if (json.proxyUrl != null) {
/* 270 */       builder.proxyUrl(json.proxyUrl);
/*     */     }
/* 272 */     if (json.height != null) {
/* 273 */       builder.height(json.height);
/*     */     }
/* 275 */     if (json.width != null) {
/* 276 */       builder.width(json.width);
/*     */     }
/* 278 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableEmbedImageData of(Possible<String> url, Possible<String> proxyUrl, Possible<Integer> height, Possible<Integer> width) {
/* 290 */     return new ImmutableEmbedImageData(url, proxyUrl, height, width);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableEmbedImageData copyOf(EmbedImageData instance) {
/* 301 */     if (instance instanceof ImmutableEmbedImageData) {
/* 302 */       return (ImmutableEmbedImageData)instance;
/*     */     }
/* 304 */     return builder()
/* 305 */       .from(instance)
/* 306 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isUrlPresent() {
/* 310 */     return !this.url_absent;
/*     */   }
/*     */   
/*     */   public String urlOrElse(String defaultValue) {
/* 314 */     return !this.url_absent ? this.url_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isProxyUrlPresent() {
/* 318 */     return !this.proxyUrl_absent;
/*     */   }
/*     */   
/*     */   public String proxyUrlOrElse(String defaultValue) {
/* 322 */     return !this.proxyUrl_absent ? this.proxyUrl_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isHeightPresent() {
/* 326 */     return !this.height_absent;
/*     */   }
/*     */   
/*     */   public Integer heightOrElse(Integer defaultValue) {
/* 330 */     return !this.height_absent ? this.height_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isWidthPresent() {
/* 334 */     return !this.width_absent;
/*     */   }
/*     */   
/*     */   public Integer widthOrElse(Integer defaultValue) {
/* 338 */     return !this.width_absent ? this.width_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 354 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "EmbedImageData", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/* 366 */     private Possible<String> url_possible = Possible.absent();
/* 367 */     private Possible<String> proxyUrl_possible = Possible.absent();
/* 368 */     private Possible<Integer> height_possible = Possible.absent();
/* 369 */     private Possible<Integer> width_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(EmbedImageData instance) {
/* 382 */       Objects.requireNonNull(instance, "instance");
/* 383 */       url(instance.url());
/* 384 */       proxyUrl(instance.proxyUrl());
/* 385 */       height(instance.height());
/* 386 */       width(instance.width());
/* 387 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("url")
/*     */     public Builder url(Possible<String> value) {
/* 392 */       this.url_possible = value;
/* 393 */       return this;
/*     */     }
/*     */     
/*     */     public Builder url(String value) {
/* 397 */       this.url_possible = Possible.of(value);
/* 398 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("proxy_url")
/*     */     public Builder proxyUrl(Possible<String> value) {
/* 403 */       this.proxyUrl_possible = value;
/* 404 */       return this;
/*     */     }
/*     */     
/*     */     public Builder proxyUrl(String value) {
/* 408 */       this.proxyUrl_possible = Possible.of(value);
/* 409 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("height")
/*     */     public Builder height(Possible<Integer> value) {
/* 414 */       this.height_possible = value;
/* 415 */       return this;
/*     */     }
/*     */     
/*     */     public Builder height(Integer value) {
/* 419 */       this.height_possible = Possible.of(value);
/* 420 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("width")
/*     */     public Builder width(Possible<Integer> value) {
/* 425 */       this.width_possible = value;
/* 426 */       return this;
/*     */     }
/*     */     
/*     */     public Builder width(Integer value) {
/* 430 */       this.width_possible = Possible.of(value);
/* 431 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableEmbedImageData build() {
/* 440 */       return new ImmutableEmbedImageData(null, url_build(), proxyUrl_build(), height_build(), width_build());
/*     */     }
/*     */     
/*     */     private Possible<String> url_build() {
/* 444 */       return this.url_possible;
/*     */     }
/*     */     
/*     */     private Possible<String> proxyUrl_build() {
/* 448 */       return this.proxyUrl_possible;
/*     */     }
/*     */     
/*     */     private Possible<Integer> height_build() {
/* 452 */       return this.height_possible;
/*     */     }
/*     */     
/*     */     private Possible<Integer> width_build() {
/* 456 */       return this.width_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableEmbedImageData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */