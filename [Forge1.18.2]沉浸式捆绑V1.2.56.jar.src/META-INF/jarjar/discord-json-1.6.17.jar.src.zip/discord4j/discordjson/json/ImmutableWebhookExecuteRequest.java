/*      */ package discord4j.discordjson.json;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*      */ import com.fasterxml.jackson.annotation.JsonCreator;
/*      */ import com.fasterxml.jackson.annotation.JsonProperty;
/*      */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*      */ import discord4j.discordjson.possible.Possible;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import java.util.stream.Collectors;
/*      */ import java.util.stream.StreamSupport;
/*      */ import org.immutables.value.Generated;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Generated(from = "WebhookExecuteRequest", generator = "Immutables")
/*      */ public final class ImmutableWebhookExecuteRequest
/*      */   implements WebhookExecuteRequest
/*      */ {
/*      */   private final String content_value;
/*      */   private final boolean content_absent;
/*      */   private final Boolean tts_value;
/*      */   private final boolean tts_absent;
/*      */   private final AllowedMentionsData allowedMentions_value;
/*      */   private final boolean allowedMentions_absent;
/*      */   private final MessageReferenceData messageReference_value;
/*      */   private final boolean messageReference_absent;
/*      */   private final List<ComponentData> components_value;
/*      */   private final boolean components_absent;
/*      */   private final List<EmbedData> embeds_value;
/*      */   private final boolean embeds_absent;
/*      */   private final String username_value;
/*      */   private final boolean username_absent;
/*      */   private final String avatarUrl_value;
/*      */   private final boolean avatarUrl_absent;
/*      */   private static final byte STAGE_INITIALIZING = -1;
/*      */   private static final byte STAGE_UNINITIALIZED = 0;
/*      */   private static final byte STAGE_INITIALIZED = 1;
/*      */   
/*      */   private ImmutableWebhookExecuteRequest(Possible<String> content, Possible<Boolean> tts, Possible<AllowedMentionsData> allowedMentions, Possible<MessageReferenceData> messageReference, Possible<List<ComponentData>> components, Possible<List<EmbedData>> embeds, Possible<String> username, Possible<String> avatarUrl) {
/*   54 */     Possible<String> content$impl = content;
/*   55 */     Possible<Boolean> tts$impl = tts;
/*   56 */     Possible<AllowedMentionsData> allowedMentions$impl = allowedMentions;
/*   57 */     Possible<MessageReferenceData> messageReference$impl = messageReference;
/*   58 */     Possible<List<ComponentData>> components$impl = components;
/*   59 */     Possible<List<EmbedData>> embeds$impl = embeds;
/*   60 */     Possible<String> username$impl = username;
/*   61 */     Possible<String> avatarUrl$impl = avatarUrl;
/*   62 */     this.content_value = content$impl.toOptional().orElse(null);
/*   63 */     this.content_absent = content$impl.isAbsent();
/*   64 */     this.tts_value = tts$impl.toOptional().orElse(null);
/*   65 */     this.tts_absent = tts$impl.isAbsent();
/*   66 */     this.allowedMentions_value = allowedMentions$impl.toOptional().orElse(null);
/*   67 */     this.allowedMentions_absent = allowedMentions$impl.isAbsent();
/*   68 */     this.messageReference_value = messageReference$impl.toOptional().orElse(null);
/*   69 */     this.messageReference_absent = messageReference$impl.isAbsent();
/*   70 */     this.components_value = components$impl.toOptional().orElse(null);
/*   71 */     this.components_absent = components$impl.isAbsent();
/*   72 */     this.embeds_value = embeds$impl.toOptional().orElse(null);
/*   73 */     this.embeds_absent = embeds$impl.isAbsent();
/*   74 */     this.username_value = username$impl.toOptional().orElse(null);
/*   75 */     this.username_absent = username$impl.isAbsent();
/*   76 */     this.avatarUrl_value = avatarUrl$impl.toOptional().orElse(null);
/*   77 */     this.avatarUrl_absent = avatarUrl$impl.isAbsent();
/*   78 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ImmutableWebhookExecuteRequest(ImmutableWebhookExecuteRequest original, Possible<String> content, Possible<Boolean> tts, Possible<AllowedMentionsData> allowedMentions, Possible<MessageReferenceData> messageReference, Possible<List<ComponentData>> components, Possible<List<EmbedData>> embeds, Possible<String> username, Possible<String> avatarUrl) {
/*   91 */     Possible<String> content$impl = content;
/*   92 */     Possible<Boolean> tts$impl = tts;
/*   93 */     Possible<AllowedMentionsData> allowedMentions$impl = allowedMentions;
/*   94 */     Possible<MessageReferenceData> messageReference$impl = messageReference;
/*   95 */     Possible<List<ComponentData>> components$impl = components;
/*   96 */     Possible<List<EmbedData>> embeds$impl = embeds;
/*   97 */     Possible<String> username$impl = username;
/*   98 */     Possible<String> avatarUrl$impl = avatarUrl;
/*   99 */     this.content_value = content$impl.toOptional().orElse(null);
/*  100 */     this.content_absent = content$impl.isAbsent();
/*  101 */     this.tts_value = tts$impl.toOptional().orElse(null);
/*  102 */     this.tts_absent = tts$impl.isAbsent();
/*  103 */     this.allowedMentions_value = allowedMentions$impl.toOptional().orElse(null);
/*  104 */     this.allowedMentions_absent = allowedMentions$impl.isAbsent();
/*  105 */     this.messageReference_value = messageReference$impl.toOptional().orElse(null);
/*  106 */     this.messageReference_absent = messageReference$impl.isAbsent();
/*  107 */     this.components_value = components$impl.toOptional().orElse(null);
/*  108 */     this.components_absent = components$impl.isAbsent();
/*  109 */     this.embeds_value = embeds$impl.toOptional().orElse(null);
/*  110 */     this.embeds_absent = embeds$impl.isAbsent();
/*  111 */     this.username_value = username$impl.toOptional().orElse(null);
/*  112 */     this.username_absent = username$impl.isAbsent();
/*  113 */     this.avatarUrl_value = avatarUrl$impl.toOptional().orElse(null);
/*  114 */     this.avatarUrl_absent = avatarUrl$impl.isAbsent();
/*  115 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  121 */   private volatile transient InitShim initShim = new InitShim();
/*      */   
/*      */   @Generated(from = "WebhookExecuteRequest", generator = "Immutables")
/*      */   private final class InitShim {
/*      */     private String formatInitCycleMessage() {
/*  126 */       List<String> attributes = new ArrayList<>();
/*  127 */       return "Cannot build WebhookExecuteRequest, attribute initializers form cycle " + attributes;
/*      */     }
/*      */ 
/*      */     
/*      */     private InitShim() {}
/*      */   }
/*      */ 
/*      */   
/*      */   @JsonProperty("content")
/*      */   public Possible<String> content() {
/*  137 */     return this.content_absent ? Possible.absent() : Possible.of(this.content_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("tts")
/*      */   public Possible<Boolean> tts() {
/*  146 */     return this.tts_absent ? Possible.absent() : Possible.of(this.tts_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("allowed_mentions")
/*      */   public Possible<AllowedMentionsData> allowedMentions() {
/*  155 */     return this.allowedMentions_absent ? Possible.absent() : Possible.of(this.allowedMentions_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("message_reference")
/*      */   public Possible<MessageReferenceData> messageReference() {
/*  164 */     return this.messageReference_absent ? Possible.absent() : Possible.of(this.messageReference_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("components")
/*      */   public Possible<List<ComponentData>> components() {
/*  173 */     return this.components_absent ? Possible.absent() : 
/*  174 */       Possible.of(this.components_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("embeds")
/*      */   public Possible<List<EmbedData>> embeds() {
/*  183 */     return this.embeds_absent ? Possible.absent() : 
/*  184 */       Possible.of(this.embeds_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("username")
/*      */   public Possible<String> username() {
/*  193 */     return this.username_absent ? Possible.absent() : Possible.of(this.username_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("avatar_url")
/*      */   public Possible<String> avatarUrl() {
/*  202 */     return this.avatarUrl_absent ? Possible.absent() : Possible.of(this.avatarUrl_value);
/*      */   }
/*      */   
/*      */   public ImmutableWebhookExecuteRequest withContent(Possible<String> value) {
/*  206 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  207 */     return new ImmutableWebhookExecuteRequest(this, newValue, 
/*      */ 
/*      */         
/*  210 */         tts(), 
/*  211 */         allowedMentions(), 
/*  212 */         messageReference(), 
/*  213 */         components(), 
/*  214 */         embeds(), 
/*  215 */         username(), 
/*  216 */         avatarUrl());
/*      */   }
/*      */   
/*      */   public ImmutableWebhookExecuteRequest withContent(String value) {
/*  220 */     Possible<String> newValue = Possible.of(value);
/*  221 */     return new ImmutableWebhookExecuteRequest(this, newValue, 
/*      */ 
/*      */         
/*  224 */         tts(), 
/*  225 */         allowedMentions(), 
/*  226 */         messageReference(), 
/*  227 */         components(), 
/*  228 */         embeds(), 
/*  229 */         username(), 
/*  230 */         avatarUrl());
/*      */   }
/*      */   
/*      */   public ImmutableWebhookExecuteRequest withTts(Possible<Boolean> value) {
/*  234 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/*  235 */     return new ImmutableWebhookExecuteRequest(this, 
/*      */         
/*  237 */         content(), newValue, 
/*      */         
/*  239 */         allowedMentions(), 
/*  240 */         messageReference(), 
/*  241 */         components(), 
/*  242 */         embeds(), 
/*  243 */         username(), 
/*  244 */         avatarUrl());
/*      */   }
/*      */   
/*      */   public ImmutableWebhookExecuteRequest withTts(Boolean value) {
/*  248 */     Possible<Boolean> newValue = Possible.of(value);
/*  249 */     return new ImmutableWebhookExecuteRequest(this, 
/*      */         
/*  251 */         content(), newValue, 
/*      */         
/*  253 */         allowedMentions(), 
/*  254 */         messageReference(), 
/*  255 */         components(), 
/*  256 */         embeds(), 
/*  257 */         username(), 
/*  258 */         avatarUrl());
/*      */   }
/*      */   
/*      */   public ImmutableWebhookExecuteRequest withAllowedMentions(Possible<AllowedMentionsData> value) {
/*  262 */     Possible<AllowedMentionsData> newValue = Objects.<Possible<AllowedMentionsData>>requireNonNull(value);
/*  263 */     return new ImmutableWebhookExecuteRequest(this, 
/*      */         
/*  265 */         content(), 
/*  266 */         tts(), newValue, 
/*      */         
/*  268 */         messageReference(), 
/*  269 */         components(), 
/*  270 */         embeds(), 
/*  271 */         username(), 
/*  272 */         avatarUrl());
/*      */   }
/*      */   
/*      */   public ImmutableWebhookExecuteRequest withAllowedMentions(AllowedMentionsData value) {
/*  276 */     Possible<AllowedMentionsData> newValue = Possible.of(value);
/*  277 */     return new ImmutableWebhookExecuteRequest(this, 
/*      */         
/*  279 */         content(), 
/*  280 */         tts(), newValue, 
/*      */         
/*  282 */         messageReference(), 
/*  283 */         components(), 
/*  284 */         embeds(), 
/*  285 */         username(), 
/*  286 */         avatarUrl());
/*      */   }
/*      */   
/*      */   public ImmutableWebhookExecuteRequest withMessageReference(Possible<MessageReferenceData> value) {
/*  290 */     Possible<MessageReferenceData> newValue = Objects.<Possible<MessageReferenceData>>requireNonNull(value);
/*  291 */     return new ImmutableWebhookExecuteRequest(this, 
/*      */         
/*  293 */         content(), 
/*  294 */         tts(), 
/*  295 */         allowedMentions(), newValue, 
/*      */         
/*  297 */         components(), 
/*  298 */         embeds(), 
/*  299 */         username(), 
/*  300 */         avatarUrl());
/*      */   }
/*      */   
/*      */   public ImmutableWebhookExecuteRequest withMessageReference(MessageReferenceData value) {
/*  304 */     Possible<MessageReferenceData> newValue = Possible.of(value);
/*  305 */     return new ImmutableWebhookExecuteRequest(this, 
/*      */         
/*  307 */         content(), 
/*  308 */         tts(), 
/*  309 */         allowedMentions(), newValue, 
/*      */         
/*  311 */         components(), 
/*  312 */         embeds(), 
/*  313 */         username(), 
/*  314 */         avatarUrl());
/*      */   }
/*      */   
/*      */   public ImmutableWebhookExecuteRequest withComponents(Possible<List<ComponentData>> possible) {
/*  318 */     Possible<List<ComponentData>> newValue = Objects.<Possible<List<ComponentData>>>requireNonNull(possible);
/*  319 */     return new ImmutableWebhookExecuteRequest(this, 
/*      */         
/*  321 */         content(), 
/*  322 */         tts(), 
/*  323 */         allowedMentions(), 
/*  324 */         messageReference(), newValue, 
/*      */         
/*  326 */         embeds(), 
/*  327 */         username(), 
/*  328 */         avatarUrl());
/*      */   }
/*      */   
/*      */   public ImmutableWebhookExecuteRequest withComponents(Iterable<ComponentData> elements) {
/*  332 */     Possible<List<ComponentData>> newValue = Possible.of(
/*  333 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/*  334 */     return new ImmutableWebhookExecuteRequest(this, 
/*      */         
/*  336 */         content(), 
/*  337 */         tts(), 
/*  338 */         allowedMentions(), 
/*  339 */         messageReference(), newValue, 
/*      */         
/*  341 */         embeds(), 
/*  342 */         username(), 
/*  343 */         avatarUrl());
/*      */   }
/*      */   
/*      */   @SafeVarargs
/*      */   public final ImmutableWebhookExecuteRequest withComponents(ComponentData... elements) {
/*  348 */     Possible<List<ComponentData>> newValue = Possible.of(Arrays.asList(elements));
/*  349 */     return new ImmutableWebhookExecuteRequest(this, 
/*      */         
/*  351 */         content(), 
/*  352 */         tts(), 
/*  353 */         allowedMentions(), 
/*  354 */         messageReference(), newValue, 
/*      */         
/*  356 */         embeds(), 
/*  357 */         username(), 
/*  358 */         avatarUrl());
/*      */   }
/*      */   
/*      */   public ImmutableWebhookExecuteRequest withEmbeds(Possible<List<EmbedData>> possible) {
/*  362 */     Possible<List<EmbedData>> newValue = Objects.<Possible<List<EmbedData>>>requireNonNull(possible);
/*  363 */     return new ImmutableWebhookExecuteRequest(this, 
/*      */         
/*  365 */         content(), 
/*  366 */         tts(), 
/*  367 */         allowedMentions(), 
/*  368 */         messageReference(), 
/*  369 */         components(), newValue, 
/*      */         
/*  371 */         username(), 
/*  372 */         avatarUrl());
/*      */   }
/*      */   
/*      */   public ImmutableWebhookExecuteRequest withEmbeds(Iterable<EmbedData> elements) {
/*  376 */     Possible<List<EmbedData>> newValue = Possible.of(
/*  377 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/*  378 */     return new ImmutableWebhookExecuteRequest(this, 
/*      */         
/*  380 */         content(), 
/*  381 */         tts(), 
/*  382 */         allowedMentions(), 
/*  383 */         messageReference(), 
/*  384 */         components(), newValue, 
/*      */         
/*  386 */         username(), 
/*  387 */         avatarUrl());
/*      */   }
/*      */   
/*      */   @SafeVarargs
/*      */   public final ImmutableWebhookExecuteRequest withEmbeds(EmbedData... elements) {
/*  392 */     Possible<List<EmbedData>> newValue = Possible.of(Arrays.asList(elements));
/*  393 */     return new ImmutableWebhookExecuteRequest(this, 
/*      */         
/*  395 */         content(), 
/*  396 */         tts(), 
/*  397 */         allowedMentions(), 
/*  398 */         messageReference(), 
/*  399 */         components(), newValue, 
/*      */         
/*  401 */         username(), 
/*  402 */         avatarUrl());
/*      */   }
/*      */   
/*      */   public ImmutableWebhookExecuteRequest withUsername(Possible<String> value) {
/*  406 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  407 */     return new ImmutableWebhookExecuteRequest(this, 
/*      */         
/*  409 */         content(), 
/*  410 */         tts(), 
/*  411 */         allowedMentions(), 
/*  412 */         messageReference(), 
/*  413 */         components(), 
/*  414 */         embeds(), newValue, 
/*      */         
/*  416 */         avatarUrl());
/*      */   }
/*      */   
/*      */   public ImmutableWebhookExecuteRequest withUsername(String value) {
/*  420 */     Possible<String> newValue = Possible.of(value);
/*  421 */     return new ImmutableWebhookExecuteRequest(this, 
/*      */         
/*  423 */         content(), 
/*  424 */         tts(), 
/*  425 */         allowedMentions(), 
/*  426 */         messageReference(), 
/*  427 */         components(), 
/*  428 */         embeds(), newValue, 
/*      */         
/*  430 */         avatarUrl());
/*      */   }
/*      */   
/*      */   public ImmutableWebhookExecuteRequest withAvatarUrl(Possible<String> value) {
/*  434 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  435 */     return new ImmutableWebhookExecuteRequest(this, 
/*      */         
/*  437 */         content(), 
/*  438 */         tts(), 
/*  439 */         allowedMentions(), 
/*  440 */         messageReference(), 
/*  441 */         components(), 
/*  442 */         embeds(), 
/*  443 */         username(), newValue);
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableWebhookExecuteRequest withAvatarUrl(String value) {
/*  448 */     Possible<String> newValue = Possible.of(value);
/*  449 */     return new ImmutableWebhookExecuteRequest(this, 
/*      */         
/*  451 */         content(), 
/*  452 */         tts(), 
/*  453 */         allowedMentions(), 
/*  454 */         messageReference(), 
/*  455 */         components(), 
/*  456 */         embeds(), 
/*  457 */         username(), newValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object another) {
/*  467 */     if (this == another) return true; 
/*  468 */     return (another instanceof ImmutableWebhookExecuteRequest && 
/*  469 */       equalTo(0, (ImmutableWebhookExecuteRequest)another));
/*      */   }
/*      */   
/*      */   private boolean equalTo(int synthetic, ImmutableWebhookExecuteRequest another) {
/*  473 */     return (content().equals(another.content()) && 
/*  474 */       tts().equals(another.tts()) && 
/*  475 */       allowedMentions().equals(another.allowedMentions()) && 
/*  476 */       messageReference().equals(another.messageReference()) && 
/*  477 */       Objects.equals(this.components_value, another.components_value) && 
/*  478 */       Objects.equals(this.embeds_value, another.embeds_value) && 
/*  479 */       username().equals(another.username()) && 
/*  480 */       avatarUrl().equals(another.avatarUrl()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/*  489 */     int h = 5381;
/*  490 */     h += (h << 5) + content().hashCode();
/*  491 */     h += (h << 5) + tts().hashCode();
/*  492 */     h += (h << 5) + allowedMentions().hashCode();
/*  493 */     h += (h << 5) + messageReference().hashCode();
/*  494 */     h += (h << 5) + Objects.hashCode(this.components_value);
/*  495 */     h += (h << 5) + Objects.hashCode(this.embeds_value);
/*  496 */     h += (h << 5) + username().hashCode();
/*  497 */     h += (h << 5) + avatarUrl().hashCode();
/*  498 */     return h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*  507 */     return "WebhookExecuteRequest{content=" + 
/*  508 */       content().toString() + ", tts=" + 
/*  509 */       tts().toString() + ", allowedMentions=" + 
/*  510 */       allowedMentions().toString() + ", messageReference=" + 
/*  511 */       messageReference().toString() + ", components=" + 
/*  512 */       Objects.toString(this.components_value) + ", embeds=" + 
/*  513 */       Objects.toString(this.embeds_value) + ", username=" + 
/*  514 */       username().toString() + ", avatarUrl=" + 
/*  515 */       avatarUrl().toString() + "}";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonDeserialize
/*      */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*      */   @Generated(from = "WebhookExecuteRequest", generator = "Immutables")
/*      */   static final class Json
/*      */     implements WebhookExecuteRequest
/*      */   {
/*  529 */     Possible<String> content = Possible.absent();
/*      */ 
/*      */     
/*  532 */     Possible<Boolean> tts = Possible.absent();
/*      */ 
/*      */     
/*  535 */     Possible<AllowedMentionsData> allowedMentions = Possible.absent();
/*      */ 
/*      */     
/*  538 */     Possible<MessageReferenceData> messageReference = Possible.absent();
/*      */ 
/*      */     
/*  541 */     Possible<List<ComponentData>> components = Possible.absent();
/*      */ 
/*      */     
/*  544 */     Possible<List<EmbedData>> embeds = Possible.absent();
/*      */ 
/*      */     
/*  547 */     Possible<String> username = Possible.absent();
/*      */ 
/*      */     
/*  550 */     Possible<String> avatarUrl = Possible.absent();
/*      */     
/*      */     @JsonProperty("content")
/*      */     public void setContent(Possible<String> content) {
/*  554 */       this.content = content;
/*      */     }
/*      */     @JsonProperty("tts")
/*      */     public void setTts(Possible<Boolean> tts) {
/*  558 */       this.tts = tts;
/*      */     }
/*      */     @JsonProperty("allowed_mentions")
/*      */     public void setAllowedMentions(Possible<AllowedMentionsData> allowedMentions) {
/*  562 */       this.allowedMentions = allowedMentions;
/*      */     }
/*      */     @JsonProperty("message_reference")
/*      */     public void setMessageReference(Possible<MessageReferenceData> messageReference) {
/*  566 */       this.messageReference = messageReference;
/*      */     }
/*      */     @JsonProperty("components")
/*      */     public void setComponents(Possible<List<ComponentData>> components) {
/*  570 */       this.components = components;
/*      */     }
/*      */     @JsonProperty("embeds")
/*      */     public void setEmbeds(Possible<List<EmbedData>> embeds) {
/*  574 */       this.embeds = embeds;
/*      */     }
/*      */     @JsonProperty("username")
/*      */     public void setUsername(Possible<String> username) {
/*  578 */       this.username = username;
/*      */     }
/*      */     @JsonProperty("avatar_url")
/*      */     public void setAvatarUrl(Possible<String> avatarUrl) {
/*  582 */       this.avatarUrl = avatarUrl;
/*      */     }
/*      */     public Possible<String> content() {
/*  585 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Boolean> tts() {
/*  587 */       throw new UnsupportedOperationException();
/*      */     } public Possible<AllowedMentionsData> allowedMentions() {
/*  589 */       throw new UnsupportedOperationException();
/*      */     } public Possible<MessageReferenceData> messageReference() {
/*  591 */       throw new UnsupportedOperationException();
/*      */     } public Possible<List<ComponentData>> components() {
/*  593 */       throw new UnsupportedOperationException();
/*      */     } public Possible<List<EmbedData>> embeds() {
/*  595 */       throw new UnsupportedOperationException();
/*      */     } public Possible<String> username() {
/*  597 */       throw new UnsupportedOperationException();
/*      */     } public Possible<String> avatarUrl() {
/*  599 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*      */   static ImmutableWebhookExecuteRequest fromJson(Json json) {
/*  610 */     Builder builder = builder();
/*  611 */     if (json.content != null) {
/*  612 */       builder.content(json.content);
/*      */     }
/*  614 */     if (json.tts != null) {
/*  615 */       builder.tts(json.tts);
/*      */     }
/*  617 */     if (json.allowedMentions != null) {
/*  618 */       builder.allowedMentions(json.allowedMentions);
/*      */     }
/*  620 */     if (json.messageReference != null) {
/*  621 */       builder.messageReference(json.messageReference);
/*      */     }
/*  623 */     if (json.components != null) {
/*  624 */       builder.components(json.components);
/*      */     }
/*  626 */     if (json.embeds != null) {
/*  627 */       builder.embeds(json.embeds);
/*      */     }
/*  629 */     if (json.username != null) {
/*  630 */       builder.username(json.username);
/*      */     }
/*  632 */     if (json.avatarUrl != null) {
/*  633 */       builder.avatarUrl(json.avatarUrl);
/*      */     }
/*  635 */     return builder.build();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableWebhookExecuteRequest of(Possible<String> content, Possible<Boolean> tts, Possible<AllowedMentionsData> allowedMentions, Possible<MessageReferenceData> messageReference, Possible<List<ComponentData>> components, Possible<List<EmbedData>> embeds, Possible<String> username, Possible<String> avatarUrl) {
/*  651 */     return new ImmutableWebhookExecuteRequest(content, tts, allowedMentions, messageReference, components, embeds, username, avatarUrl);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableWebhookExecuteRequest copyOf(WebhookExecuteRequest instance) {
/*  662 */     if (instance instanceof ImmutableWebhookExecuteRequest) {
/*  663 */       return (ImmutableWebhookExecuteRequest)instance;
/*      */     }
/*  665 */     return builder()
/*  666 */       .from(instance)
/*  667 */       .build();
/*      */   }
/*      */   
/*      */   public boolean isContentPresent() {
/*  671 */     return !this.content_absent;
/*      */   }
/*      */   
/*      */   public String contentOrElse(String defaultValue) {
/*  675 */     return !this.content_absent ? this.content_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isTtsPresent() {
/*  679 */     return !this.tts_absent;
/*      */   }
/*      */   
/*      */   public Boolean ttsOrElse(Boolean defaultValue) {
/*  683 */     return !this.tts_absent ? this.tts_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isAllowedMentionsPresent() {
/*  687 */     return !this.allowedMentions_absent;
/*      */   }
/*      */   
/*      */   public AllowedMentionsData allowedMentionsOrElse(AllowedMentionsData defaultValue) {
/*  691 */     return !this.allowedMentions_absent ? this.allowedMentions_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isMessageReferencePresent() {
/*  695 */     return !this.messageReference_absent;
/*      */   }
/*      */   
/*      */   public MessageReferenceData messageReferenceOrElse(MessageReferenceData defaultValue) {
/*  699 */     return !this.messageReference_absent ? this.messageReference_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isComponentsPresent() {
/*  703 */     return !this.components_absent;
/*      */   }
/*      */   
/*      */   public List<ComponentData> componentsOrElse(List<ComponentData> defaultValue) {
/*  707 */     return !this.components_absent ? this.components_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isEmbedsPresent() {
/*  711 */     return !this.embeds_absent;
/*      */   }
/*      */   
/*      */   public List<EmbedData> embedsOrElse(List<EmbedData> defaultValue) {
/*  715 */     return !this.embeds_absent ? this.embeds_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isUsernamePresent() {
/*  719 */     return !this.username_absent;
/*      */   }
/*      */   
/*      */   public String usernameOrElse(String defaultValue) {
/*  723 */     return !this.username_absent ? this.username_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isAvatarUrlPresent() {
/*  727 */     return !this.avatarUrl_absent;
/*      */   }
/*      */   
/*      */   public String avatarUrlOrElse(String defaultValue) {
/*  731 */     return !this.avatarUrl_absent ? this.avatarUrl_value : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Builder builder() {
/*  751 */     return new Builder();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Generated(from = "WebhookExecuteRequest", generator = "Immutables")
/*      */   public static final class Builder
/*      */   {
/*  763 */     private Possible<String> content_possible = Possible.absent();
/*  764 */     private Possible<Boolean> tts_possible = Possible.absent();
/*  765 */     private Possible<AllowedMentionsData> allowedMentions_possible = Possible.absent();
/*  766 */     private Possible<MessageReferenceData> messageReference_possible = Possible.absent();
/*  767 */     private List<ComponentData> components_list = null;
/*  768 */     private List<EmbedData> embeds_list = null;
/*  769 */     private Possible<String> username_possible = Possible.absent();
/*  770 */     private Possible<String> avatarUrl_possible = Possible.absent();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(WebhookExecuteRequest instance) {
/*  781 */       Objects.requireNonNull(instance, "instance");
/*  782 */       from(instance);
/*  783 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(MessageSendRequestBase instance) {
/*  792 */       Objects.requireNonNull(instance, "instance");
/*  793 */       from(instance);
/*  794 */       return this;
/*      */     }
/*      */     
/*      */     private void from(Object object) {
/*  798 */       long bits = 0L;
/*  799 */       if (object instanceof WebhookExecuteRequest) {
/*  800 */         WebhookExecuteRequest instance = (WebhookExecuteRequest)object;
/*  801 */         if ((bits & 0x1L) == 0L) {
/*  802 */           messageReference(instance.messageReference());
/*  803 */           bits |= 0x1L;
/*      */         } 
/*  805 */         if ((bits & 0x2L) == 0L) {
/*  806 */           tts(instance.tts());
/*  807 */           bits |= 0x2L;
/*      */         } 
/*  809 */         if ((bits & 0x4L) == 0L) {
/*  810 */           components(instance.components());
/*  811 */           bits |= 0x4L;
/*      */         } 
/*  813 */         avatarUrl(instance.avatarUrl());
/*  814 */         if ((bits & 0x8L) == 0L) {
/*  815 */           embeds(instance.embeds());
/*  816 */           bits |= 0x8L;
/*      */         } 
/*  818 */         if ((bits & 0x10L) == 0L) {
/*  819 */           content(instance.content());
/*  820 */           bits |= 0x10L;
/*      */         } 
/*  822 */         if ((bits & 0x20L) == 0L) {
/*  823 */           allowedMentions(instance.allowedMentions());
/*  824 */           bits |= 0x20L;
/*      */         } 
/*  826 */         username(instance.username());
/*      */       } 
/*  828 */       if (object instanceof MessageSendRequestBase) {
/*  829 */         MessageSendRequestBase instance = (MessageSendRequestBase)object;
/*  830 */         if ((bits & 0x1L) == 0L) {
/*  831 */           messageReference(instance.messageReference());
/*  832 */           bits |= 0x1L;
/*      */         } 
/*  834 */         if ((bits & 0x2L) == 0L) {
/*  835 */           tts(instance.tts());
/*  836 */           bits |= 0x2L;
/*      */         } 
/*  838 */         if ((bits & 0x4L) == 0L) {
/*  839 */           components(instance.components());
/*  840 */           bits |= 0x4L;
/*      */         } 
/*  842 */         if ((bits & 0x8L) == 0L) {
/*  843 */           embeds(instance.embeds());
/*  844 */           bits |= 0x8L;
/*      */         } 
/*  846 */         if ((bits & 0x10L) == 0L) {
/*  847 */           content(instance.content());
/*  848 */           bits |= 0x10L;
/*      */         } 
/*  850 */         if ((bits & 0x20L) == 0L) {
/*  851 */           allowedMentions(instance.allowedMentions());
/*  852 */           bits |= 0x20L;
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*      */     @JsonProperty("content")
/*      */     public Builder content(Possible<String> value) {
/*  859 */       this.content_possible = value;
/*  860 */       return this;
/*      */     }
/*      */     
/*      */     public Builder content(String value) {
/*  864 */       this.content_possible = Possible.of(value);
/*  865 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("tts")
/*      */     public Builder tts(Possible<Boolean> value) {
/*  870 */       this.tts_possible = value;
/*  871 */       return this;
/*      */     }
/*      */     
/*      */     public Builder tts(Boolean value) {
/*  875 */       this.tts_possible = Possible.of(value);
/*  876 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("allowed_mentions")
/*      */     public Builder allowedMentions(Possible<AllowedMentionsData> value) {
/*  881 */       this.allowedMentions_possible = value;
/*  882 */       return this;
/*      */     }
/*      */     
/*      */     public Builder allowedMentions(AllowedMentionsData value) {
/*  886 */       this.allowedMentions_possible = Possible.of(value);
/*  887 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("message_reference")
/*      */     public Builder messageReference(Possible<MessageReferenceData> value) {
/*  892 */       this.messageReference_possible = value;
/*  893 */       return this;
/*      */     }
/*      */     
/*      */     public Builder messageReference(MessageReferenceData value) {
/*  897 */       this.messageReference_possible = Possible.of(value);
/*  898 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addComponent(ComponentData element) {
/*  902 */       components_getOrCreate().add(element);
/*  903 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addAllComponents(List<ComponentData> elements) {
/*  907 */       components_getOrCreate().addAll(elements);
/*  908 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("components")
/*      */     public Builder components(Possible<List<ComponentData>> elements) {
/*  913 */       this.components_list = null;
/*  914 */       elements.toOptional().ifPresent(e -> components_getOrCreate().addAll(e));
/*  915 */       return this;
/*      */     }
/*      */     
/*      */     public Builder components(List<ComponentData> elements) {
/*  919 */       this.components_list = new ArrayList<>(elements);
/*  920 */       return this;
/*      */     }
/*      */     
/*      */     public Builder components(Iterable<ComponentData> elements) {
/*  924 */       this.components_list = (List<ComponentData>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/*  925 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addEmbed(EmbedData element) {
/*  929 */       embeds_getOrCreate().add(element);
/*  930 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addAllEmbeds(List<EmbedData> elements) {
/*  934 */       embeds_getOrCreate().addAll(elements);
/*  935 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("embeds")
/*      */     public Builder embeds(Possible<List<EmbedData>> elements) {
/*  940 */       this.embeds_list = null;
/*  941 */       elements.toOptional().ifPresent(e -> embeds_getOrCreate().addAll(e));
/*  942 */       return this;
/*      */     }
/*      */     
/*      */     public Builder embeds(List<EmbedData> elements) {
/*  946 */       this.embeds_list = new ArrayList<>(elements);
/*  947 */       return this;
/*      */     }
/*      */     
/*      */     public Builder embeds(Iterable<EmbedData> elements) {
/*  951 */       this.embeds_list = (List<EmbedData>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/*  952 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("username")
/*      */     public Builder username(Possible<String> value) {
/*  957 */       this.username_possible = value;
/*  958 */       return this;
/*      */     }
/*      */     
/*      */     public Builder username(String value) {
/*  962 */       this.username_possible = Possible.of(value);
/*  963 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("avatar_url")
/*      */     public Builder avatarUrl(Possible<String> value) {
/*  968 */       this.avatarUrl_possible = value;
/*  969 */       return this;
/*      */     }
/*      */     
/*      */     public Builder avatarUrl(String value) {
/*  973 */       this.avatarUrl_possible = Possible.of(value);
/*  974 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ImmutableWebhookExecuteRequest build() {
/*  983 */       return new ImmutableWebhookExecuteRequest(null, 
/*      */           
/*  985 */           content_build(), 
/*  986 */           tts_build(), 
/*  987 */           allowedMentions_build(), 
/*  988 */           messageReference_build(), 
/*  989 */           components_build(), 
/*  990 */           embeds_build(), 
/*  991 */           username_build(), 
/*  992 */           avatarUrl_build());
/*      */     }
/*      */     
/*      */     private Possible<String> content_build() {
/*  996 */       return this.content_possible;
/*      */     }
/*      */     
/*      */     private Possible<Boolean> tts_build() {
/* 1000 */       return this.tts_possible;
/*      */     }
/*      */     
/*      */     private Possible<AllowedMentionsData> allowedMentions_build() {
/* 1004 */       return this.allowedMentions_possible;
/*      */     }
/*      */     
/*      */     private Possible<MessageReferenceData> messageReference_build() {
/* 1008 */       return this.messageReference_possible;
/*      */     }
/*      */     
/*      */     private Possible<List<ComponentData>> components_build() {
/* 1012 */       return (this.components_list == null) ? Possible.absent() : 
/* 1013 */         Possible.of(this.components_list);
/*      */     }
/*      */     
/*      */     private List<ComponentData> components_getOrCreate() {
/* 1017 */       if (this.components_list == null) {
/* 1018 */         this.components_list = new ArrayList<>();
/*      */       }
/* 1020 */       return this.components_list;
/*      */     }
/*      */     
/*      */     private Possible<List<EmbedData>> embeds_build() {
/* 1024 */       return (this.embeds_list == null) ? Possible.absent() : 
/* 1025 */         Possible.of(this.embeds_list);
/*      */     }
/*      */     
/*      */     private List<EmbedData> embeds_getOrCreate() {
/* 1029 */       if (this.embeds_list == null) {
/* 1030 */         this.embeds_list = new ArrayList<>();
/*      */       }
/* 1032 */       return this.embeds_list;
/*      */     }
/*      */     
/*      */     private Possible<String> username_build() {
/* 1036 */       return this.username_possible;
/*      */     }
/*      */     
/*      */     private Possible<String> avatarUrl_build() {
/* 1040 */       return this.avatarUrl_possible;
/*      */     }
/*      */     
/*      */     private Builder() {}
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableWebhookExecuteRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */