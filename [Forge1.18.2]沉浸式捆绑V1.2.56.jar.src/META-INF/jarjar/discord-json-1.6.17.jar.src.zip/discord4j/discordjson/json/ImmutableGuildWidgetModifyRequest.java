/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "GuildWidgetModifyRequest", generator = "Immutables")
/*     */ public final class ImmutableGuildWidgetModifyRequest
/*     */   implements GuildWidgetModifyRequest
/*     */ {
/*     */   private final Boolean enabled_value;
/*     */   private final boolean enabled_absent;
/*     */   private final String channelId_value;
/*     */   private final boolean channelId_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private ImmutableGuildWidgetModifyRequest(Possible<Boolean> enabled, Possible<Optional<String>> channelId) {
/*  36 */     Possible<Boolean> enabled$impl = enabled;
/*  37 */     Possible<Optional<String>> channelId$impl = channelId;
/*  38 */     this.enabled_value = enabled$impl.toOptional().orElse(null);
/*  39 */     this.enabled_absent = enabled$impl.isAbsent();
/*  40 */     this.channelId_value = Possible.flatOpt(channelId$impl).orElse(null);
/*  41 */     this.channelId_absent = channelId$impl.isAbsent();
/*  42 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableGuildWidgetModifyRequest(ImmutableGuildWidgetModifyRequest original, Possible<Boolean> enabled, Possible<Optional<String>> channelId) {
/*  49 */     Possible<Boolean> enabled$impl = enabled;
/*  50 */     Possible<Optional<String>> channelId$impl = channelId;
/*  51 */     this.enabled_value = enabled$impl.toOptional().orElse(null);
/*  52 */     this.enabled_absent = enabled$impl.isAbsent();
/*  53 */     this.channelId_value = Possible.flatOpt(channelId$impl).orElse(null);
/*  54 */     this.channelId_absent = channelId$impl.isAbsent();
/*  55 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  61 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "GuildWidgetModifyRequest", generator = "Immutables")
/*     */   private final class InitShim {
/*     */     private String formatInitCycleMessage() {
/*  66 */       List<String> attributes = new ArrayList<>();
/*  67 */       return "Cannot build GuildWidgetModifyRequest, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @JsonProperty("enabled")
/*     */   public Possible<Boolean> enabled() {
/*  77 */     return this.enabled_absent ? Possible.absent() : Possible.of(this.enabled_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("channel_id")
/*     */   public Possible<Optional<String>> channelId() {
/*  86 */     return this.channelId_absent ? Possible.absent() : 
/*  87 */       Possible.of(Optional.ofNullable(this.channelId_value));
/*     */   }
/*     */   
/*     */   public ImmutableGuildWidgetModifyRequest withEnabled(Possible<Boolean> value) {
/*  91 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/*  92 */     return new ImmutableGuildWidgetModifyRequest(this, newValue, channelId());
/*     */   }
/*     */   
/*     */   public ImmutableGuildWidgetModifyRequest withEnabled(Boolean value) {
/*  96 */     Possible<Boolean> newValue = Possible.of(value);
/*  97 */     return new ImmutableGuildWidgetModifyRequest(this, newValue, channelId());
/*     */   }
/*     */   
/*     */   public ImmutableGuildWidgetModifyRequest withChannelId(Possible<Optional<String>> value) {
/* 101 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/* 102 */     return new ImmutableGuildWidgetModifyRequest(this, enabled(), newValue);
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public ImmutableGuildWidgetModifyRequest withChannelId(@Nullable String value) {
/* 107 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 108 */     return new ImmutableGuildWidgetModifyRequest(this, enabled(), newValue);
/*     */   }
/*     */   
/*     */   public ImmutableGuildWidgetModifyRequest withChannelIdOrNull(@Nullable String value) {
/* 112 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 113 */     return new ImmutableGuildWidgetModifyRequest(this, enabled(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 122 */     if (this == another) return true; 
/* 123 */     return (another instanceof ImmutableGuildWidgetModifyRequest && 
/* 124 */       equalTo(0, (ImmutableGuildWidgetModifyRequest)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableGuildWidgetModifyRequest another) {
/* 128 */     return (enabled().equals(another.enabled()) && 
/* 129 */       channelId().equals(another.channelId()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 138 */     int h = 5381;
/* 139 */     h += (h << 5) + enabled().hashCode();
/* 140 */     h += (h << 5) + channelId().hashCode();
/* 141 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 150 */     return "GuildWidgetModifyRequest{enabled=" + 
/* 151 */       enabled().toString() + ", channelId=" + 
/* 152 */       channelId().toString() + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "GuildWidgetModifyRequest", generator = "Immutables")
/*     */   static final class Json
/*     */     implements GuildWidgetModifyRequest
/*     */   {
/* 166 */     Possible<Boolean> enabled = Possible.absent();
/*     */ 
/*     */     
/* 169 */     Possible<Optional<String>> channelId = Possible.absent();
/*     */     
/*     */     @JsonProperty("enabled")
/*     */     public void setEnabled(Possible<Boolean> enabled) {
/* 173 */       this.enabled = enabled;
/*     */     }
/*     */     @JsonProperty("channel_id")
/*     */     public void setChannelId(Possible<Optional<String>> channelId) {
/* 177 */       this.channelId = channelId;
/*     */     }
/*     */     public Possible<Boolean> enabled() {
/* 180 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Optional<String>> channelId() {
/* 182 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableGuildWidgetModifyRequest fromJson(Json json) {
/* 193 */     Builder builder = builder();
/* 194 */     if (json.enabled != null) {
/* 195 */       builder.enabled(json.enabled);
/*     */     }
/* 197 */     if (json.channelId != null) {
/* 198 */       builder.channelId(json.channelId);
/*     */     }
/* 200 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableGuildWidgetModifyRequest of(Possible<Boolean> enabled, Possible<Optional<String>> channelId) {
/* 210 */     return new ImmutableGuildWidgetModifyRequest(enabled, channelId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableGuildWidgetModifyRequest copyOf(GuildWidgetModifyRequest instance) {
/* 221 */     if (instance instanceof ImmutableGuildWidgetModifyRequest) {
/* 222 */       return (ImmutableGuildWidgetModifyRequest)instance;
/*     */     }
/* 224 */     return builder()
/* 225 */       .from(instance)
/* 226 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isEnabledPresent() {
/* 230 */     return !this.enabled_absent;
/*     */   }
/*     */   
/*     */   public Boolean enabledOrElse(Boolean defaultValue) {
/* 234 */     return !this.enabled_absent ? this.enabled_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isChannelIdPresent() {
/* 238 */     return !this.channelId_absent;
/*     */   }
/*     */   
/*     */   public String channelIdOrElse(String defaultValue) {
/* 242 */     return !this.channelId_absent ? this.channelId_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 256 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "GuildWidgetModifyRequest", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/* 268 */     private Possible<Boolean> enabled_possible = Possible.absent();
/* 269 */     private Possible<Optional<String>> channelId_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(GuildWidgetModifyRequest instance) {
/* 282 */       Objects.requireNonNull(instance, "instance");
/* 283 */       enabled(instance.enabled());
/* 284 */       channelId(instance.channelId());
/* 285 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("enabled")
/*     */     public Builder enabled(Possible<Boolean> value) {
/* 290 */       this.enabled_possible = value;
/* 291 */       return this;
/*     */     }
/*     */     
/*     */     public Builder enabled(Boolean value) {
/* 295 */       this.enabled_possible = Possible.of(value);
/* 296 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("channel_id")
/*     */     public Builder channelId(Possible<Optional<String>> value) {
/* 301 */       this.channelId_possible = value;
/* 302 */       return this;
/*     */     }
/*     */     
/*     */     @Deprecated
/*     */     public Builder channelId(@Nullable String value) {
/* 307 */       this.channelId_possible = Possible.of(Optional.ofNullable(value));
/* 308 */       return this;
/*     */     }
/*     */     
/*     */     public Builder channelIdOrNull(@Nullable String value) {
/* 312 */       this.channelId_possible = Possible.of(Optional.ofNullable(value));
/* 313 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableGuildWidgetModifyRequest build() {
/* 322 */       return new ImmutableGuildWidgetModifyRequest(null, enabled_build(), channelId_build());
/*     */     }
/*     */     
/*     */     private Possible<Boolean> enabled_build() {
/* 326 */       return this.enabled_possible;
/*     */     }
/*     */     
/*     */     private Possible<Optional<String>> channelId_build() {
/* 330 */       return this.channelId_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableGuildWidgetModifyRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */