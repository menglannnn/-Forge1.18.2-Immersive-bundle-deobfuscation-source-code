/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "RoleModifyRequest", generator = "Immutables")
/*     */ public final class ImmutableRoleModifyRequest
/*     */   implements RoleModifyRequest
/*     */ {
/*     */   private final String name_value;
/*     */   private final boolean name_absent;
/*     */   private final Long permissions_value;
/*     */   private final boolean permissions_absent;
/*     */   private final Integer color_value;
/*     */   private final boolean color_absent;
/*     */   private final Boolean hoist_value;
/*     */   private final boolean hoist_absent;
/*     */   private final Boolean mentionable_value;
/*     */   private final boolean mentionable_absent;
/*     */   private final String icon_value;
/*     */   private final boolean icon_absent;
/*     */   private final String unicodeEmoji_value;
/*     */   private final boolean unicodeEmoji_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private ImmutableRoleModifyRequest(Possible<String> name, Possible<Long> permissions, Possible<Integer> color, Possible<Boolean> hoist, Possible<Boolean> mentionable, Possible<Optional<String>> icon, Possible<Optional<String>> unicodeEmoji) {
/*  50 */     Possible<String> name$impl = name;
/*  51 */     Possible<Long> permissions$impl = permissions;
/*  52 */     Possible<Integer> color$impl = color;
/*  53 */     Possible<Boolean> hoist$impl = hoist;
/*  54 */     Possible<Boolean> mentionable$impl = mentionable;
/*  55 */     Possible<Optional<String>> icon$impl = icon;
/*  56 */     Possible<Optional<String>> unicodeEmoji$impl = unicodeEmoji;
/*  57 */     this.name_value = name$impl.toOptional().orElse(null);
/*  58 */     this.name_absent = name$impl.isAbsent();
/*  59 */     this.permissions_value = permissions$impl.toOptional().orElse(null);
/*  60 */     this.permissions_absent = permissions$impl.isAbsent();
/*  61 */     this.color_value = color$impl.toOptional().orElse(null);
/*  62 */     this.color_absent = color$impl.isAbsent();
/*  63 */     this.hoist_value = hoist$impl.toOptional().orElse(null);
/*  64 */     this.hoist_absent = hoist$impl.isAbsent();
/*  65 */     this.mentionable_value = mentionable$impl.toOptional().orElse(null);
/*  66 */     this.mentionable_absent = mentionable$impl.isAbsent();
/*  67 */     this.icon_value = Possible.flatOpt(icon$impl).orElse(null);
/*  68 */     this.icon_absent = icon$impl.isAbsent();
/*  69 */     this.unicodeEmoji_value = Possible.flatOpt(unicodeEmoji$impl).orElse(null);
/*  70 */     this.unicodeEmoji_absent = unicodeEmoji$impl.isAbsent();
/*  71 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableRoleModifyRequest(ImmutableRoleModifyRequest original, Possible<String> name, Possible<Long> permissions, Possible<Integer> color, Possible<Boolean> hoist, Possible<Boolean> mentionable, Possible<Optional<String>> icon, Possible<Optional<String>> unicodeEmoji) {
/*  83 */     Possible<String> name$impl = name;
/*  84 */     Possible<Long> permissions$impl = permissions;
/*  85 */     Possible<Integer> color$impl = color;
/*  86 */     Possible<Boolean> hoist$impl = hoist;
/*  87 */     Possible<Boolean> mentionable$impl = mentionable;
/*  88 */     Possible<Optional<String>> icon$impl = icon;
/*  89 */     Possible<Optional<String>> unicodeEmoji$impl = unicodeEmoji;
/*  90 */     this.name_value = name$impl.toOptional().orElse(null);
/*  91 */     this.name_absent = name$impl.isAbsent();
/*  92 */     this.permissions_value = permissions$impl.toOptional().orElse(null);
/*  93 */     this.permissions_absent = permissions$impl.isAbsent();
/*  94 */     this.color_value = color$impl.toOptional().orElse(null);
/*  95 */     this.color_absent = color$impl.isAbsent();
/*  96 */     this.hoist_value = hoist$impl.toOptional().orElse(null);
/*  97 */     this.hoist_absent = hoist$impl.isAbsent();
/*  98 */     this.mentionable_value = mentionable$impl.toOptional().orElse(null);
/*  99 */     this.mentionable_absent = mentionable$impl.isAbsent();
/* 100 */     this.icon_value = Possible.flatOpt(icon$impl).orElse(null);
/* 101 */     this.icon_absent = icon$impl.isAbsent();
/* 102 */     this.unicodeEmoji_value = Possible.flatOpt(unicodeEmoji$impl).orElse(null);
/* 103 */     this.unicodeEmoji_absent = unicodeEmoji$impl.isAbsent();
/* 104 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 110 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "RoleModifyRequest", generator = "Immutables")
/*     */   private final class InitShim {
/*     */     private String formatInitCycleMessage() {
/* 115 */       List<String> attributes = new ArrayList<>();
/* 116 */       return "Cannot build RoleModifyRequest, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @JsonProperty("name")
/*     */   public Possible<String> name() {
/* 126 */     return this.name_absent ? Possible.absent() : Possible.of(this.name_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("permissions")
/*     */   public Possible<Long> permissions() {
/* 135 */     return this.permissions_absent ? Possible.absent() : Possible.of(this.permissions_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("color")
/*     */   public Possible<Integer> color() {
/* 144 */     return this.color_absent ? Possible.absent() : Possible.of(this.color_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("hoist")
/*     */   public Possible<Boolean> hoist() {
/* 153 */     return this.hoist_absent ? Possible.absent() : Possible.of(this.hoist_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("mentionable")
/*     */   public Possible<Boolean> mentionable() {
/* 162 */     return this.mentionable_absent ? Possible.absent() : Possible.of(this.mentionable_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("icon")
/*     */   public Possible<Optional<String>> icon() {
/* 171 */     return this.icon_absent ? Possible.absent() : 
/* 172 */       Possible.of(Optional.ofNullable(this.icon_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("unicode_emoji")
/*     */   public Possible<Optional<String>> unicodeEmoji() {
/* 181 */     return this.unicodeEmoji_absent ? Possible.absent() : 
/* 182 */       Possible.of(Optional.ofNullable(this.unicodeEmoji_value));
/*     */   }
/*     */   
/*     */   public ImmutableRoleModifyRequest withName(Possible<String> value) {
/* 186 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 187 */     return new ImmutableRoleModifyRequest(this, newValue, 
/*     */ 
/*     */         
/* 190 */         permissions(), 
/* 191 */         color(), 
/* 192 */         hoist(), 
/* 193 */         mentionable(), 
/* 194 */         icon(), 
/* 195 */         unicodeEmoji());
/*     */   }
/*     */   
/*     */   public ImmutableRoleModifyRequest withName(String value) {
/* 199 */     Possible<String> newValue = Possible.of(value);
/* 200 */     return new ImmutableRoleModifyRequest(this, newValue, 
/*     */ 
/*     */         
/* 203 */         permissions(), 
/* 204 */         color(), 
/* 205 */         hoist(), 
/* 206 */         mentionable(), 
/* 207 */         icon(), 
/* 208 */         unicodeEmoji());
/*     */   }
/*     */   
/*     */   public ImmutableRoleModifyRequest withPermissions(Possible<Long> value) {
/* 212 */     Possible<Long> newValue = Objects.<Possible<Long>>requireNonNull(value);
/* 213 */     return new ImmutableRoleModifyRequest(this, 
/*     */         
/* 215 */         name(), newValue, 
/*     */         
/* 217 */         color(), 
/* 218 */         hoist(), 
/* 219 */         mentionable(), 
/* 220 */         icon(), 
/* 221 */         unicodeEmoji());
/*     */   }
/*     */   
/*     */   public ImmutableRoleModifyRequest withPermissions(Long value) {
/* 225 */     Possible<Long> newValue = Possible.of(value);
/* 226 */     return new ImmutableRoleModifyRequest(this, 
/*     */         
/* 228 */         name(), newValue, 
/*     */         
/* 230 */         color(), 
/* 231 */         hoist(), 
/* 232 */         mentionable(), 
/* 233 */         icon(), 
/* 234 */         unicodeEmoji());
/*     */   }
/*     */   
/*     */   public ImmutableRoleModifyRequest withColor(Possible<Integer> value) {
/* 238 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 239 */     return new ImmutableRoleModifyRequest(this, 
/*     */         
/* 241 */         name(), 
/* 242 */         permissions(), newValue, 
/*     */         
/* 244 */         hoist(), 
/* 245 */         mentionable(), 
/* 246 */         icon(), 
/* 247 */         unicodeEmoji());
/*     */   }
/*     */   
/*     */   public ImmutableRoleModifyRequest withColor(Integer value) {
/* 251 */     Possible<Integer> newValue = Possible.of(value);
/* 252 */     return new ImmutableRoleModifyRequest(this, 
/*     */         
/* 254 */         name(), 
/* 255 */         permissions(), newValue, 
/*     */         
/* 257 */         hoist(), 
/* 258 */         mentionable(), 
/* 259 */         icon(), 
/* 260 */         unicodeEmoji());
/*     */   }
/*     */   
/*     */   public ImmutableRoleModifyRequest withHoist(Possible<Boolean> value) {
/* 264 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 265 */     return new ImmutableRoleModifyRequest(this, 
/*     */         
/* 267 */         name(), 
/* 268 */         permissions(), 
/* 269 */         color(), newValue, 
/*     */         
/* 271 */         mentionable(), 
/* 272 */         icon(), 
/* 273 */         unicodeEmoji());
/*     */   }
/*     */   
/*     */   public ImmutableRoleModifyRequest withHoist(Boolean value) {
/* 277 */     Possible<Boolean> newValue = Possible.of(value);
/* 278 */     return new ImmutableRoleModifyRequest(this, 
/*     */         
/* 280 */         name(), 
/* 281 */         permissions(), 
/* 282 */         color(), newValue, 
/*     */         
/* 284 */         mentionable(), 
/* 285 */         icon(), 
/* 286 */         unicodeEmoji());
/*     */   }
/*     */   
/*     */   public ImmutableRoleModifyRequest withMentionable(Possible<Boolean> value) {
/* 290 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 291 */     return new ImmutableRoleModifyRequest(this, 
/*     */         
/* 293 */         name(), 
/* 294 */         permissions(), 
/* 295 */         color(), 
/* 296 */         hoist(), newValue, 
/*     */         
/* 298 */         icon(), 
/* 299 */         unicodeEmoji());
/*     */   }
/*     */   
/*     */   public ImmutableRoleModifyRequest withMentionable(Boolean value) {
/* 303 */     Possible<Boolean> newValue = Possible.of(value);
/* 304 */     return new ImmutableRoleModifyRequest(this, 
/*     */         
/* 306 */         name(), 
/* 307 */         permissions(), 
/* 308 */         color(), 
/* 309 */         hoist(), newValue, 
/*     */         
/* 311 */         icon(), 
/* 312 */         unicodeEmoji());
/*     */   }
/*     */   
/*     */   public ImmutableRoleModifyRequest withIcon(Possible<Optional<String>> value) {
/* 316 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/* 317 */     return new ImmutableRoleModifyRequest(this, 
/*     */         
/* 319 */         name(), 
/* 320 */         permissions(), 
/* 321 */         color(), 
/* 322 */         hoist(), 
/* 323 */         mentionable(), newValue, 
/*     */         
/* 325 */         unicodeEmoji());
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public ImmutableRoleModifyRequest withIcon(@Nullable String value) {
/* 330 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 331 */     return new ImmutableRoleModifyRequest(this, 
/*     */         
/* 333 */         name(), 
/* 334 */         permissions(), 
/* 335 */         color(), 
/* 336 */         hoist(), 
/* 337 */         mentionable(), newValue, 
/*     */         
/* 339 */         unicodeEmoji());
/*     */   }
/*     */   
/*     */   public ImmutableRoleModifyRequest withIconOrNull(@Nullable String value) {
/* 343 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 344 */     return new ImmutableRoleModifyRequest(this, 
/*     */         
/* 346 */         name(), 
/* 347 */         permissions(), 
/* 348 */         color(), 
/* 349 */         hoist(), 
/* 350 */         mentionable(), newValue, 
/*     */         
/* 352 */         unicodeEmoji());
/*     */   }
/*     */   
/*     */   public ImmutableRoleModifyRequest withUnicodeEmoji(Possible<Optional<String>> value) {
/* 356 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/* 357 */     return new ImmutableRoleModifyRequest(this, 
/*     */         
/* 359 */         name(), 
/* 360 */         permissions(), 
/* 361 */         color(), 
/* 362 */         hoist(), 
/* 363 */         mentionable(), 
/* 364 */         icon(), newValue);
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public ImmutableRoleModifyRequest withUnicodeEmoji(@Nullable String value) {
/* 370 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 371 */     return new ImmutableRoleModifyRequest(this, 
/*     */         
/* 373 */         name(), 
/* 374 */         permissions(), 
/* 375 */         color(), 
/* 376 */         hoist(), 
/* 377 */         mentionable(), 
/* 378 */         icon(), newValue);
/*     */   }
/*     */ 
/*     */   
/*     */   public ImmutableRoleModifyRequest withUnicodeEmojiOrNull(@Nullable String value) {
/* 383 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 384 */     return new ImmutableRoleModifyRequest(this, 
/*     */         
/* 386 */         name(), 
/* 387 */         permissions(), 
/* 388 */         color(), 
/* 389 */         hoist(), 
/* 390 */         mentionable(), 
/* 391 */         icon(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 401 */     if (this == another) return true; 
/* 402 */     return (another instanceof ImmutableRoleModifyRequest && 
/* 403 */       equalTo(0, (ImmutableRoleModifyRequest)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableRoleModifyRequest another) {
/* 407 */     return (name().equals(another.name()) && 
/* 408 */       permissions().equals(another.permissions()) && 
/* 409 */       color().equals(another.color()) && 
/* 410 */       hoist().equals(another.hoist()) && 
/* 411 */       mentionable().equals(another.mentionable()) && 
/* 412 */       icon().equals(another.icon()) && 
/* 413 */       unicodeEmoji().equals(another.unicodeEmoji()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 422 */     int h = 5381;
/* 423 */     h += (h << 5) + name().hashCode();
/* 424 */     h += (h << 5) + permissions().hashCode();
/* 425 */     h += (h << 5) + color().hashCode();
/* 426 */     h += (h << 5) + hoist().hashCode();
/* 427 */     h += (h << 5) + mentionable().hashCode();
/* 428 */     h += (h << 5) + icon().hashCode();
/* 429 */     h += (h << 5) + unicodeEmoji().hashCode();
/* 430 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 439 */     return "RoleModifyRequest{name=" + 
/* 440 */       name().toString() + ", permissions=" + 
/* 441 */       permissions().toString() + ", color=" + 
/* 442 */       color().toString() + ", hoist=" + 
/* 443 */       hoist().toString() + ", mentionable=" + 
/* 444 */       mentionable().toString() + ", icon=" + 
/* 445 */       icon().toString() + ", unicodeEmoji=" + 
/* 446 */       unicodeEmoji().toString() + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "RoleModifyRequest", generator = "Immutables")
/*     */   static final class Json
/*     */     implements RoleModifyRequest
/*     */   {
/* 460 */     Possible<String> name = Possible.absent();
/*     */ 
/*     */     
/* 463 */     Possible<Long> permissions = Possible.absent();
/*     */ 
/*     */     
/* 466 */     Possible<Integer> color = Possible.absent();
/*     */ 
/*     */     
/* 469 */     Possible<Boolean> hoist = Possible.absent();
/*     */ 
/*     */     
/* 472 */     Possible<Boolean> mentionable = Possible.absent();
/*     */ 
/*     */     
/* 475 */     Possible<Optional<String>> icon = Possible.absent();
/*     */ 
/*     */     
/* 478 */     Possible<Optional<String>> unicodeEmoji = Possible.absent();
/*     */     
/*     */     @JsonProperty("name")
/*     */     public void setName(Possible<String> name) {
/* 482 */       this.name = name;
/*     */     }
/*     */     @JsonProperty("permissions")
/*     */     public void setPermissions(Possible<Long> permissions) {
/* 486 */       this.permissions = permissions;
/*     */     }
/*     */     @JsonProperty("color")
/*     */     public void setColor(Possible<Integer> color) {
/* 490 */       this.color = color;
/*     */     }
/*     */     @JsonProperty("hoist")
/*     */     public void setHoist(Possible<Boolean> hoist) {
/* 494 */       this.hoist = hoist;
/*     */     }
/*     */     @JsonProperty("mentionable")
/*     */     public void setMentionable(Possible<Boolean> mentionable) {
/* 498 */       this.mentionable = mentionable;
/*     */     }
/*     */     @JsonProperty("icon")
/*     */     public void setIcon(Possible<Optional<String>> icon) {
/* 502 */       this.icon = icon;
/*     */     }
/*     */     @JsonProperty("unicode_emoji")
/*     */     public void setUnicodeEmoji(Possible<Optional<String>> unicodeEmoji) {
/* 506 */       this.unicodeEmoji = unicodeEmoji;
/*     */     }
/*     */     public Possible<String> name() {
/* 509 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Long> permissions() {
/* 511 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Integer> color() {
/* 513 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Boolean> hoist() {
/* 515 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Boolean> mentionable() {
/* 517 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Optional<String>> icon() {
/* 519 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Optional<String>> unicodeEmoji() {
/* 521 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableRoleModifyRequest fromJson(Json json) {
/* 532 */     Builder builder = builder();
/* 533 */     if (json.name != null) {
/* 534 */       builder.name(json.name);
/*     */     }
/* 536 */     if (json.permissions != null) {
/* 537 */       builder.permissions(json.permissions);
/*     */     }
/* 539 */     if (json.color != null) {
/* 540 */       builder.color(json.color);
/*     */     }
/* 542 */     if (json.hoist != null) {
/* 543 */       builder.hoist(json.hoist);
/*     */     }
/* 545 */     if (json.mentionable != null) {
/* 546 */       builder.mentionable(json.mentionable);
/*     */     }
/* 548 */     if (json.icon != null) {
/* 549 */       builder.icon(json.icon);
/*     */     }
/* 551 */     if (json.unicodeEmoji != null) {
/* 552 */       builder.unicodeEmoji(json.unicodeEmoji);
/*     */     }
/* 554 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableRoleModifyRequest of(Possible<String> name, Possible<Long> permissions, Possible<Integer> color, Possible<Boolean> hoist, Possible<Boolean> mentionable, Possible<Optional<String>> icon, Possible<Optional<String>> unicodeEmoji) {
/* 569 */     return new ImmutableRoleModifyRequest(name, permissions, color, hoist, mentionable, icon, unicodeEmoji);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableRoleModifyRequest copyOf(RoleModifyRequest instance) {
/* 580 */     if (instance instanceof ImmutableRoleModifyRequest) {
/* 581 */       return (ImmutableRoleModifyRequest)instance;
/*     */     }
/* 583 */     return builder()
/* 584 */       .from(instance)
/* 585 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isNamePresent() {
/* 589 */     return !this.name_absent;
/*     */   }
/*     */   
/*     */   public String nameOrElse(String defaultValue) {
/* 593 */     return !this.name_absent ? this.name_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isPermissionsPresent() {
/* 597 */     return !this.permissions_absent;
/*     */   }
/*     */   
/*     */   public Long permissionsOrElse(Long defaultValue) {
/* 601 */     return !this.permissions_absent ? this.permissions_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isColorPresent() {
/* 605 */     return !this.color_absent;
/*     */   }
/*     */   
/*     */   public Integer colorOrElse(Integer defaultValue) {
/* 609 */     return !this.color_absent ? this.color_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isHoistPresent() {
/* 613 */     return !this.hoist_absent;
/*     */   }
/*     */   
/*     */   public Boolean hoistOrElse(Boolean defaultValue) {
/* 617 */     return !this.hoist_absent ? this.hoist_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isMentionablePresent() {
/* 621 */     return !this.mentionable_absent;
/*     */   }
/*     */   
/*     */   public Boolean mentionableOrElse(Boolean defaultValue) {
/* 625 */     return !this.mentionable_absent ? this.mentionable_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isIconPresent() {
/* 629 */     return !this.icon_absent;
/*     */   }
/*     */   
/*     */   public String iconOrElse(String defaultValue) {
/* 633 */     return !this.icon_absent ? this.icon_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isUnicodeEmojiPresent() {
/* 637 */     return !this.unicodeEmoji_absent;
/*     */   }
/*     */   
/*     */   public String unicodeEmojiOrElse(String defaultValue) {
/* 641 */     return !this.unicodeEmoji_absent ? this.unicodeEmoji_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 660 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "RoleModifyRequest", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/* 672 */     private Possible<String> name_possible = Possible.absent();
/* 673 */     private Possible<Long> permissions_possible = Possible.absent();
/* 674 */     private Possible<Integer> color_possible = Possible.absent();
/* 675 */     private Possible<Boolean> hoist_possible = Possible.absent();
/* 676 */     private Possible<Boolean> mentionable_possible = Possible.absent();
/* 677 */     private Possible<Optional<String>> icon_possible = Possible.absent();
/* 678 */     private Possible<Optional<String>> unicodeEmoji_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(RoleModifyRequest instance) {
/* 691 */       Objects.requireNonNull(instance, "instance");
/* 692 */       name(instance.name());
/* 693 */       permissions(instance.permissions());
/* 694 */       color(instance.color());
/* 695 */       hoist(instance.hoist());
/* 696 */       mentionable(instance.mentionable());
/* 697 */       icon(instance.icon());
/* 698 */       unicodeEmoji(instance.unicodeEmoji());
/* 699 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("name")
/*     */     public Builder name(Possible<String> value) {
/* 704 */       this.name_possible = value;
/* 705 */       return this;
/*     */     }
/*     */     
/*     */     public Builder name(String value) {
/* 709 */       this.name_possible = Possible.of(value);
/* 710 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("permissions")
/*     */     public Builder permissions(Possible<Long> value) {
/* 715 */       this.permissions_possible = value;
/* 716 */       return this;
/*     */     }
/*     */     
/*     */     public Builder permissions(Long value) {
/* 720 */       this.permissions_possible = Possible.of(value);
/* 721 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("color")
/*     */     public Builder color(Possible<Integer> value) {
/* 726 */       this.color_possible = value;
/* 727 */       return this;
/*     */     }
/*     */     
/*     */     public Builder color(Integer value) {
/* 731 */       this.color_possible = Possible.of(value);
/* 732 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("hoist")
/*     */     public Builder hoist(Possible<Boolean> value) {
/* 737 */       this.hoist_possible = value;
/* 738 */       return this;
/*     */     }
/*     */     
/*     */     public Builder hoist(Boolean value) {
/* 742 */       this.hoist_possible = Possible.of(value);
/* 743 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("mentionable")
/*     */     public Builder mentionable(Possible<Boolean> value) {
/* 748 */       this.mentionable_possible = value;
/* 749 */       return this;
/*     */     }
/*     */     
/*     */     public Builder mentionable(Boolean value) {
/* 753 */       this.mentionable_possible = Possible.of(value);
/* 754 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("icon")
/*     */     public Builder icon(Possible<Optional<String>> value) {
/* 759 */       this.icon_possible = value;
/* 760 */       return this;
/*     */     }
/*     */     
/*     */     @Deprecated
/*     */     public Builder icon(@Nullable String value) {
/* 765 */       this.icon_possible = Possible.of(Optional.ofNullable(value));
/* 766 */       return this;
/*     */     }
/*     */     
/*     */     public Builder iconOrNull(@Nullable String value) {
/* 770 */       this.icon_possible = Possible.of(Optional.ofNullable(value));
/* 771 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("unicode_emoji")
/*     */     public Builder unicodeEmoji(Possible<Optional<String>> value) {
/* 776 */       this.unicodeEmoji_possible = value;
/* 777 */       return this;
/*     */     }
/*     */     
/*     */     @Deprecated
/*     */     public Builder unicodeEmoji(@Nullable String value) {
/* 782 */       this.unicodeEmoji_possible = Possible.of(Optional.ofNullable(value));
/* 783 */       return this;
/*     */     }
/*     */     
/*     */     public Builder unicodeEmojiOrNull(@Nullable String value) {
/* 787 */       this.unicodeEmoji_possible = Possible.of(Optional.ofNullable(value));
/* 788 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableRoleModifyRequest build() {
/* 797 */       return new ImmutableRoleModifyRequest(null, 
/*     */           
/* 799 */           name_build(), 
/* 800 */           permissions_build(), 
/* 801 */           color_build(), 
/* 802 */           hoist_build(), 
/* 803 */           mentionable_build(), 
/* 804 */           icon_build(), 
/* 805 */           unicodeEmoji_build());
/*     */     }
/*     */     
/*     */     private Possible<String> name_build() {
/* 809 */       return this.name_possible;
/*     */     }
/*     */     
/*     */     private Possible<Long> permissions_build() {
/* 813 */       return this.permissions_possible;
/*     */     }
/*     */     
/*     */     private Possible<Integer> color_build() {
/* 817 */       return this.color_possible;
/*     */     }
/*     */     
/*     */     private Possible<Boolean> hoist_build() {
/* 821 */       return this.hoist_possible;
/*     */     }
/*     */     
/*     */     private Possible<Boolean> mentionable_build() {
/* 825 */       return this.mentionable_possible;
/*     */     }
/*     */     
/*     */     private Possible<Optional<String>> icon_build() {
/* 829 */       return this.icon_possible;
/*     */     }
/*     */     
/*     */     private Possible<Optional<String>> unicodeEmoji_build() {
/* 833 */       return this.unicodeEmoji_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableRoleModifyRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */