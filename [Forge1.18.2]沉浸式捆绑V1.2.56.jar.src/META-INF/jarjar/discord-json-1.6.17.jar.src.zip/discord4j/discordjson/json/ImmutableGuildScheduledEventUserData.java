/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.Id;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "GuildScheduledEventUserData", generator = "Immutables")
/*     */ public final class ImmutableGuildScheduledEventUserData
/*     */   implements GuildScheduledEventUserData
/*     */ {
/*     */   private final long guildScheduledEventId_value;
/*     */   private final UserData user;
/*     */   private final PartialMemberData member_value;
/*     */   private final boolean member_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private ImmutableGuildScheduledEventUserData(Id guildScheduledEventId, UserData user, Possible<PartialMemberData> member) {
/*  36 */     Id guildScheduledEventId$impl = guildScheduledEventId;
/*  37 */     this.user = Objects.<UserData>requireNonNull(user, "user");
/*  38 */     Possible<PartialMemberData> member$impl = member;
/*  39 */     this.guildScheduledEventId_value = guildScheduledEventId$impl.asLong();
/*  40 */     this.member_value = member$impl.toOptional().orElse(null);
/*  41 */     this.member_absent = member$impl.isAbsent();
/*  42 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableGuildScheduledEventUserData(ImmutableGuildScheduledEventUserData original, Id guildScheduledEventId, UserData user, Possible<PartialMemberData> member) {
/*  50 */     Id guildScheduledEventId$impl = guildScheduledEventId;
/*  51 */     this.user = user;
/*  52 */     Possible<PartialMemberData> member$impl = member;
/*  53 */     this.guildScheduledEventId_value = guildScheduledEventId$impl.asLong();
/*  54 */     this.member_value = member$impl.toOptional().orElse(null);
/*  55 */     this.member_absent = member$impl.isAbsent();
/*  56 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  62 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "GuildScheduledEventUserData", generator = "Immutables")
/*     */   private final class InitShim {
/*     */     private String formatInitCycleMessage() {
/*  67 */       List<String> attributes = new ArrayList<>();
/*  68 */       return "Cannot build GuildScheduledEventUserData, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @JsonProperty("guild_scheduled_event_id")
/*     */   public Id guildScheduledEventId() {
/*  78 */     return Id.of(this.guildScheduledEventId_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("user")
/*     */   public UserData user() {
/*  87 */     return this.user;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("member")
/*     */   public Possible<PartialMemberData> member() {
/*  96 */     return this.member_absent ? Possible.absent() : Possible.of(this.member_value);
/*     */   }
/*     */   
/*     */   public ImmutableGuildScheduledEventUserData withGuildScheduledEventId(long value) {
/* 100 */     Id newValue = Id.of(value);
/* 101 */     return new ImmutableGuildScheduledEventUserData(this, newValue, this.user, member());
/*     */   }
/*     */   
/*     */   public ImmutableGuildScheduledEventUserData withGuildScheduledEventId(String value) {
/* 105 */     Id newValue = Id.of(value);
/* 106 */     return new ImmutableGuildScheduledEventUserData(this, newValue, this.user, member());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableGuildScheduledEventUserData withUser(UserData value) {
/* 116 */     if (this.user == value) return this; 
/* 117 */     UserData newValue = Objects.<UserData>requireNonNull(value, "user");
/* 118 */     return new ImmutableGuildScheduledEventUserData(this, guildScheduledEventId(), newValue, member());
/*     */   }
/*     */   
/*     */   public ImmutableGuildScheduledEventUserData withMember(Possible<PartialMemberData> value) {
/* 122 */     Possible<PartialMemberData> newValue = Objects.<Possible<PartialMemberData>>requireNonNull(value);
/* 123 */     return new ImmutableGuildScheduledEventUserData(this, guildScheduledEventId(), this.user, newValue);
/*     */   }
/*     */   
/*     */   public ImmutableGuildScheduledEventUserData withMember(PartialMemberData value) {
/* 127 */     Possible<PartialMemberData> newValue = Possible.of(value);
/* 128 */     return new ImmutableGuildScheduledEventUserData(this, guildScheduledEventId(), this.user, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 137 */     if (this == another) return true; 
/* 138 */     return (another instanceof ImmutableGuildScheduledEventUserData && 
/* 139 */       equalTo(0, (ImmutableGuildScheduledEventUserData)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableGuildScheduledEventUserData another) {
/* 143 */     return (Objects.equals(Long.valueOf(this.guildScheduledEventId_value), Long.valueOf(another.guildScheduledEventId_value)) && this.user
/* 144 */       .equals(another.user) && 
/* 145 */       member().equals(another.member()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 154 */     int h = 5381;
/* 155 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.guildScheduledEventId_value));
/* 156 */     h += (h << 5) + this.user.hashCode();
/* 157 */     h += (h << 5) + member().hashCode();
/* 158 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 167 */     return "GuildScheduledEventUserData{guildScheduledEventId=" + 
/* 168 */       Objects.toString(Long.valueOf(this.guildScheduledEventId_value)) + ", user=" + this.user + ", member=" + 
/*     */       
/* 170 */       member().toString() + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "GuildScheduledEventUserData", generator = "Immutables")
/*     */   static final class Json
/*     */     implements GuildScheduledEventUserData
/*     */   {
/*     */     Id guildScheduledEventId;
/*     */     
/*     */     UserData user;
/*     */     
/* 186 */     Possible<PartialMemberData> member = Possible.absent();
/*     */     
/*     */     @JsonProperty("guild_scheduled_event_id")
/*     */     public void setGuildScheduledEventId(Id guildScheduledEventId) {
/* 190 */       this.guildScheduledEventId = guildScheduledEventId;
/*     */     }
/*     */     @JsonProperty("user")
/*     */     public void setUser(UserData user) {
/* 194 */       this.user = user;
/*     */     }
/*     */     @JsonProperty("member")
/*     */     public void setMember(Possible<PartialMemberData> member) {
/* 198 */       this.member = member;
/*     */     }
/*     */     public Id guildScheduledEventId() {
/* 201 */       throw new UnsupportedOperationException();
/*     */     } public UserData user() {
/* 203 */       throw new UnsupportedOperationException();
/*     */     } public Possible<PartialMemberData> member() {
/* 205 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableGuildScheduledEventUserData fromJson(Json json) {
/* 216 */     Builder builder = builder();
/* 217 */     if (json.guildScheduledEventId != null) {
/* 218 */       builder.guildScheduledEventId(json.guildScheduledEventId);
/*     */     }
/* 220 */     if (json.user != null) {
/* 221 */       builder.user(json.user);
/*     */     }
/* 223 */     if (json.member != null) {
/* 224 */       builder.member(json.member);
/*     */     }
/* 226 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableGuildScheduledEventUserData of(Id guildScheduledEventId, UserData user, Possible<PartialMemberData> member) {
/* 237 */     return new ImmutableGuildScheduledEventUserData(guildScheduledEventId, user, member);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableGuildScheduledEventUserData copyOf(GuildScheduledEventUserData instance) {
/* 248 */     if (instance instanceof ImmutableGuildScheduledEventUserData) {
/* 249 */       return (ImmutableGuildScheduledEventUserData)instance;
/*     */     }
/* 251 */     return builder()
/* 252 */       .from(instance)
/* 253 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isMemberPresent() {
/* 257 */     return !this.member_absent;
/*     */   }
/*     */   
/*     */   public PartialMemberData memberOrElse(PartialMemberData defaultValue) {
/* 261 */     return !this.member_absent ? this.member_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 276 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "GuildScheduledEventUserData", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_USER = 1L;
/*     */ 
/*     */ 
/*     */     
/* 289 */     private long initBits = 1L;
/*     */     
/* 291 */     private Id guildScheduledEventId_id = null;
/* 292 */     private Possible<PartialMemberData> member_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private UserData user;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(GuildScheduledEventUserData instance) {
/* 306 */       Objects.requireNonNull(instance, "instance");
/* 307 */       guildScheduledEventId(instance.guildScheduledEventId());
/* 308 */       user(instance.user());
/* 309 */       member(instance.member());
/* 310 */       return this;
/*     */     }
/*     */     
/*     */     public Builder guildScheduledEventId(String value) {
/* 314 */       this.guildScheduledEventId_id = Id.of(value);
/* 315 */       return this;
/*     */     }
/*     */     
/*     */     public Builder guildScheduledEventId(long value) {
/* 319 */       this.guildScheduledEventId_id = Id.of(value);
/* 320 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("guild_scheduled_event_id")
/*     */     public Builder guildScheduledEventId(Id value) {
/* 325 */       this.guildScheduledEventId_id = value;
/* 326 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("user")
/*     */     public final Builder user(UserData user) {
/* 336 */       this.user = Objects.<UserData>requireNonNull(user, "user");
/* 337 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 338 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("member")
/*     */     public Builder member(Possible<PartialMemberData> value) {
/* 343 */       this.member_possible = value;
/* 344 */       return this;
/*     */     }
/*     */     
/*     */     public Builder member(PartialMemberData value) {
/* 348 */       this.member_possible = Possible.of(value);
/* 349 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableGuildScheduledEventUserData build() {
/* 358 */       if (this.initBits != 0L) {
/* 359 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 361 */       return new ImmutableGuildScheduledEventUserData(null, guildScheduledEventId_build(), this.user, member_build());
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 365 */       List<String> attributes = new ArrayList<>();
/* 366 */       if ((this.initBits & 0x1L) != 0L) attributes.add("user"); 
/* 367 */       return "Cannot build GuildScheduledEventUserData, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Id guildScheduledEventId_build() {
/* 371 */       return this.guildScheduledEventId_id;
/*     */     }
/*     */     
/*     */     private Possible<PartialMemberData> member_build() {
/* 375 */       return this.member_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableGuildScheduledEventUserData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */