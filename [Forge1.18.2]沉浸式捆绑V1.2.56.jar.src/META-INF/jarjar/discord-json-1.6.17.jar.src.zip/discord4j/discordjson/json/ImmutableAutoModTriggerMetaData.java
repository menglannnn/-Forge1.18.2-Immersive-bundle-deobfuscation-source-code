/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.StreamSupport;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "AutoModTriggerMetaData", generator = "Immutables")
/*     */ public final class ImmutableAutoModTriggerMetaData
/*     */   implements AutoModTriggerMetaData
/*     */ {
/*     */   private final List<String> keywordFilter_value;
/*     */   private final boolean keywordFilter_absent;
/*     */   private final List<String> regexPatterns_value;
/*     */   private final boolean regexPatterns_absent;
/*     */   private final List<Integer> presets_value;
/*     */   private final boolean presets_absent;
/*     */   private final List<String> allowList_value;
/*     */   private final boolean allowList_absent;
/*     */   private final Integer mentionTotalLimit_value;
/*     */   private final boolean mentionTotalLimit_absent;
/*     */   private final Boolean mentionRaidProtectionEnabled_value;
/*     */   private final boolean mentionRaidProtectionEnabled_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private ImmutableAutoModTriggerMetaData(Possible<List<String>> keywordFilter, Possible<List<String>> regexPatterns, Possible<List<Integer>> presets, Possible<List<String>> allowList, Possible<Integer> mentionTotalLimit, Possible<Boolean> mentionRaidProtectionEnabled) {
/*  49 */     Possible<List<String>> keywordFilter$impl = keywordFilter;
/*  50 */     Possible<List<String>> regexPatterns$impl = regexPatterns;
/*  51 */     Possible<List<Integer>> presets$impl = presets;
/*  52 */     Possible<List<String>> allowList$impl = allowList;
/*  53 */     Possible<Integer> mentionTotalLimit$impl = mentionTotalLimit;
/*  54 */     Possible<Boolean> mentionRaidProtectionEnabled$impl = mentionRaidProtectionEnabled;
/*  55 */     this.keywordFilter_value = keywordFilter$impl.toOptional().orElse(null);
/*  56 */     this.keywordFilter_absent = keywordFilter$impl.isAbsent();
/*  57 */     this.regexPatterns_value = regexPatterns$impl.toOptional().orElse(null);
/*  58 */     this.regexPatterns_absent = regexPatterns$impl.isAbsent();
/*  59 */     this.presets_value = presets$impl.toOptional().orElse(null);
/*  60 */     this.presets_absent = presets$impl.isAbsent();
/*  61 */     this.allowList_value = allowList$impl.toOptional().orElse(null);
/*  62 */     this.allowList_absent = allowList$impl.isAbsent();
/*  63 */     this.mentionTotalLimit_value = mentionTotalLimit$impl.toOptional().orElse(null);
/*  64 */     this.mentionTotalLimit_absent = mentionTotalLimit$impl.isAbsent();
/*  65 */     this.mentionRaidProtectionEnabled_value = mentionRaidProtectionEnabled$impl.toOptional().orElse(null);
/*  66 */     this.mentionRaidProtectionEnabled_absent = mentionRaidProtectionEnabled$impl.isAbsent();
/*  67 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableAutoModTriggerMetaData(ImmutableAutoModTriggerMetaData original, Possible<List<String>> keywordFilter, Possible<List<String>> regexPatterns, Possible<List<Integer>> presets, Possible<List<String>> allowList, Possible<Integer> mentionTotalLimit, Possible<Boolean> mentionRaidProtectionEnabled) {
/*  78 */     Possible<List<String>> keywordFilter$impl = keywordFilter;
/*  79 */     Possible<List<String>> regexPatterns$impl = regexPatterns;
/*  80 */     Possible<List<Integer>> presets$impl = presets;
/*  81 */     Possible<List<String>> allowList$impl = allowList;
/*  82 */     Possible<Integer> mentionTotalLimit$impl = mentionTotalLimit;
/*  83 */     Possible<Boolean> mentionRaidProtectionEnabled$impl = mentionRaidProtectionEnabled;
/*  84 */     this.keywordFilter_value = keywordFilter$impl.toOptional().orElse(null);
/*  85 */     this.keywordFilter_absent = keywordFilter$impl.isAbsent();
/*  86 */     this.regexPatterns_value = regexPatterns$impl.toOptional().orElse(null);
/*  87 */     this.regexPatterns_absent = regexPatterns$impl.isAbsent();
/*  88 */     this.presets_value = presets$impl.toOptional().orElse(null);
/*  89 */     this.presets_absent = presets$impl.isAbsent();
/*  90 */     this.allowList_value = allowList$impl.toOptional().orElse(null);
/*  91 */     this.allowList_absent = allowList$impl.isAbsent();
/*  92 */     this.mentionTotalLimit_value = mentionTotalLimit$impl.toOptional().orElse(null);
/*  93 */     this.mentionTotalLimit_absent = mentionTotalLimit$impl.isAbsent();
/*  94 */     this.mentionRaidProtectionEnabled_value = mentionRaidProtectionEnabled$impl.toOptional().orElse(null);
/*  95 */     this.mentionRaidProtectionEnabled_absent = mentionRaidProtectionEnabled$impl.isAbsent();
/*  96 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 102 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "AutoModTriggerMetaData", generator = "Immutables")
/*     */   private final class InitShim {
/*     */     private String formatInitCycleMessage() {
/* 107 */       List<String> attributes = new ArrayList<>();
/* 108 */       return "Cannot build AutoModTriggerMetaData, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @JsonProperty("keyword_filter")
/*     */   public Possible<List<String>> keywordFilter() {
/* 118 */     return this.keywordFilter_absent ? Possible.absent() : 
/* 119 */       Possible.of(this.keywordFilter_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("regex_patterns")
/*     */   public Possible<List<String>> regexPatterns() {
/* 128 */     return this.regexPatterns_absent ? Possible.absent() : 
/* 129 */       Possible.of(this.regexPatterns_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("presets")
/*     */   public Possible<List<Integer>> presets() {
/* 138 */     return this.presets_absent ? Possible.absent() : 
/* 139 */       Possible.of(this.presets_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("allow_list")
/*     */   public Possible<List<String>> allowList() {
/* 148 */     return this.allowList_absent ? Possible.absent() : 
/* 149 */       Possible.of(this.allowList_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("mention_total_limit")
/*     */   public Possible<Integer> mentionTotalLimit() {
/* 158 */     return this.mentionTotalLimit_absent ? Possible.absent() : Possible.of(this.mentionTotalLimit_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("mention_raid_protection_enabled")
/*     */   public Possible<Boolean> mentionRaidProtectionEnabled() {
/* 167 */     return this.mentionRaidProtectionEnabled_absent ? Possible.absent() : Possible.of(this.mentionRaidProtectionEnabled_value);
/*     */   }
/*     */   
/*     */   public ImmutableAutoModTriggerMetaData withKeywordFilter(Possible<List<String>> possible) {
/* 171 */     Possible<List<String>> newValue = Objects.<Possible<List<String>>>requireNonNull(possible);
/* 172 */     return new ImmutableAutoModTriggerMetaData(this, newValue, 
/*     */ 
/*     */         
/* 175 */         regexPatterns(), 
/* 176 */         presets(), 
/* 177 */         allowList(), 
/* 178 */         mentionTotalLimit(), 
/* 179 */         mentionRaidProtectionEnabled());
/*     */   }
/*     */   
/*     */   public ImmutableAutoModTriggerMetaData withKeywordFilter(Iterable<String> elements) {
/* 183 */     Possible<List<String>> newValue = Possible.of(
/* 184 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/* 185 */     return new ImmutableAutoModTriggerMetaData(this, newValue, 
/*     */ 
/*     */         
/* 188 */         regexPatterns(), 
/* 189 */         presets(), 
/* 190 */         allowList(), 
/* 191 */         mentionTotalLimit(), 
/* 192 */         mentionRaidProtectionEnabled());
/*     */   }
/*     */   
/*     */   @SafeVarargs
/*     */   public final ImmutableAutoModTriggerMetaData withKeywordFilter(String... elements) {
/* 197 */     Possible<List<String>> newValue = Possible.of(Arrays.asList(elements));
/* 198 */     return new ImmutableAutoModTriggerMetaData(this, newValue, 
/*     */ 
/*     */         
/* 201 */         regexPatterns(), 
/* 202 */         presets(), 
/* 203 */         allowList(), 
/* 204 */         mentionTotalLimit(), 
/* 205 */         mentionRaidProtectionEnabled());
/*     */   }
/*     */   
/*     */   public ImmutableAutoModTriggerMetaData withRegexPatterns(Possible<List<String>> possible) {
/* 209 */     Possible<List<String>> newValue = Objects.<Possible<List<String>>>requireNonNull(possible);
/* 210 */     return new ImmutableAutoModTriggerMetaData(this, 
/*     */         
/* 212 */         keywordFilter(), newValue, 
/*     */         
/* 214 */         presets(), 
/* 215 */         allowList(), 
/* 216 */         mentionTotalLimit(), 
/* 217 */         mentionRaidProtectionEnabled());
/*     */   }
/*     */   
/*     */   public ImmutableAutoModTriggerMetaData withRegexPatterns(Iterable<String> elements) {
/* 221 */     Possible<List<String>> newValue = Possible.of(
/* 222 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/* 223 */     return new ImmutableAutoModTriggerMetaData(this, 
/*     */         
/* 225 */         keywordFilter(), newValue, 
/*     */         
/* 227 */         presets(), 
/* 228 */         allowList(), 
/* 229 */         mentionTotalLimit(), 
/* 230 */         mentionRaidProtectionEnabled());
/*     */   }
/*     */   
/*     */   @SafeVarargs
/*     */   public final ImmutableAutoModTriggerMetaData withRegexPatterns(String... elements) {
/* 235 */     Possible<List<String>> newValue = Possible.of(Arrays.asList(elements));
/* 236 */     return new ImmutableAutoModTriggerMetaData(this, 
/*     */         
/* 238 */         keywordFilter(), newValue, 
/*     */         
/* 240 */         presets(), 
/* 241 */         allowList(), 
/* 242 */         mentionTotalLimit(), 
/* 243 */         mentionRaidProtectionEnabled());
/*     */   }
/*     */   
/*     */   public ImmutableAutoModTriggerMetaData withPresets(Possible<List<Integer>> possible) {
/* 247 */     Possible<List<Integer>> newValue = Objects.<Possible<List<Integer>>>requireNonNull(possible);
/* 248 */     return new ImmutableAutoModTriggerMetaData(this, 
/*     */         
/* 250 */         keywordFilter(), 
/* 251 */         regexPatterns(), newValue, 
/*     */         
/* 253 */         allowList(), 
/* 254 */         mentionTotalLimit(), 
/* 255 */         mentionRaidProtectionEnabled());
/*     */   }
/*     */   
/*     */   public ImmutableAutoModTriggerMetaData withPresets(Iterable<Integer> elements) {
/* 259 */     Possible<List<Integer>> newValue = Possible.of(
/* 260 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/* 261 */     return new ImmutableAutoModTriggerMetaData(this, 
/*     */         
/* 263 */         keywordFilter(), 
/* 264 */         regexPatterns(), newValue, 
/*     */         
/* 266 */         allowList(), 
/* 267 */         mentionTotalLimit(), 
/* 268 */         mentionRaidProtectionEnabled());
/*     */   }
/*     */   
/*     */   @SafeVarargs
/*     */   public final ImmutableAutoModTriggerMetaData withPresets(Integer... elements) {
/* 273 */     Possible<List<Integer>> newValue = Possible.of(Arrays.asList(elements));
/* 274 */     return new ImmutableAutoModTriggerMetaData(this, 
/*     */         
/* 276 */         keywordFilter(), 
/* 277 */         regexPatterns(), newValue, 
/*     */         
/* 279 */         allowList(), 
/* 280 */         mentionTotalLimit(), 
/* 281 */         mentionRaidProtectionEnabled());
/*     */   }
/*     */   
/*     */   public ImmutableAutoModTriggerMetaData withAllowList(Possible<List<String>> possible) {
/* 285 */     Possible<List<String>> newValue = Objects.<Possible<List<String>>>requireNonNull(possible);
/* 286 */     return new ImmutableAutoModTriggerMetaData(this, 
/*     */         
/* 288 */         keywordFilter(), 
/* 289 */         regexPatterns(), 
/* 290 */         presets(), newValue, 
/*     */         
/* 292 */         mentionTotalLimit(), 
/* 293 */         mentionRaidProtectionEnabled());
/*     */   }
/*     */   
/*     */   public ImmutableAutoModTriggerMetaData withAllowList(Iterable<String> elements) {
/* 297 */     Possible<List<String>> newValue = Possible.of(
/* 298 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/* 299 */     return new ImmutableAutoModTriggerMetaData(this, 
/*     */         
/* 301 */         keywordFilter(), 
/* 302 */         regexPatterns(), 
/* 303 */         presets(), newValue, 
/*     */         
/* 305 */         mentionTotalLimit(), 
/* 306 */         mentionRaidProtectionEnabled());
/*     */   }
/*     */   
/*     */   @SafeVarargs
/*     */   public final ImmutableAutoModTriggerMetaData withAllowList(String... elements) {
/* 311 */     Possible<List<String>> newValue = Possible.of(Arrays.asList(elements));
/* 312 */     return new ImmutableAutoModTriggerMetaData(this, 
/*     */         
/* 314 */         keywordFilter(), 
/* 315 */         regexPatterns(), 
/* 316 */         presets(), newValue, 
/*     */         
/* 318 */         mentionTotalLimit(), 
/* 319 */         mentionRaidProtectionEnabled());
/*     */   }
/*     */   
/*     */   public ImmutableAutoModTriggerMetaData withMentionTotalLimit(Possible<Integer> value) {
/* 323 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 324 */     return new ImmutableAutoModTriggerMetaData(this, 
/*     */         
/* 326 */         keywordFilter(), 
/* 327 */         regexPatterns(), 
/* 328 */         presets(), 
/* 329 */         allowList(), newValue, 
/*     */         
/* 331 */         mentionRaidProtectionEnabled());
/*     */   }
/*     */   
/*     */   public ImmutableAutoModTriggerMetaData withMentionTotalLimit(Integer value) {
/* 335 */     Possible<Integer> newValue = Possible.of(value);
/* 336 */     return new ImmutableAutoModTriggerMetaData(this, 
/*     */         
/* 338 */         keywordFilter(), 
/* 339 */         regexPatterns(), 
/* 340 */         presets(), 
/* 341 */         allowList(), newValue, 
/*     */         
/* 343 */         mentionRaidProtectionEnabled());
/*     */   }
/*     */   
/*     */   public ImmutableAutoModTriggerMetaData withMentionRaidProtectionEnabled(Possible<Boolean> value) {
/* 347 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 348 */     return new ImmutableAutoModTriggerMetaData(this, 
/*     */         
/* 350 */         keywordFilter(), 
/* 351 */         regexPatterns(), 
/* 352 */         presets(), 
/* 353 */         allowList(), 
/* 354 */         mentionTotalLimit(), newValue);
/*     */   }
/*     */ 
/*     */   
/*     */   public ImmutableAutoModTriggerMetaData withMentionRaidProtectionEnabled(Boolean value) {
/* 359 */     Possible<Boolean> newValue = Possible.of(value);
/* 360 */     return new ImmutableAutoModTriggerMetaData(this, 
/*     */         
/* 362 */         keywordFilter(), 
/* 363 */         regexPatterns(), 
/* 364 */         presets(), 
/* 365 */         allowList(), 
/* 366 */         mentionTotalLimit(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 376 */     if (this == another) return true; 
/* 377 */     return (another instanceof ImmutableAutoModTriggerMetaData && 
/* 378 */       equalTo(0, (ImmutableAutoModTriggerMetaData)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableAutoModTriggerMetaData another) {
/* 382 */     return (Objects.equals(this.keywordFilter_value, another.keywordFilter_value) && 
/* 383 */       Objects.equals(this.regexPatterns_value, another.regexPatterns_value) && 
/* 384 */       Objects.equals(this.presets_value, another.presets_value) && 
/* 385 */       Objects.equals(this.allowList_value, another.allowList_value) && 
/* 386 */       mentionTotalLimit().equals(another.mentionTotalLimit()) && 
/* 387 */       mentionRaidProtectionEnabled().equals(another.mentionRaidProtectionEnabled()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 396 */     int h = 5381;
/* 397 */     h += (h << 5) + Objects.hashCode(this.keywordFilter_value);
/* 398 */     h += (h << 5) + Objects.hashCode(this.regexPatterns_value);
/* 399 */     h += (h << 5) + Objects.hashCode(this.presets_value);
/* 400 */     h += (h << 5) + Objects.hashCode(this.allowList_value);
/* 401 */     h += (h << 5) + mentionTotalLimit().hashCode();
/* 402 */     h += (h << 5) + mentionRaidProtectionEnabled().hashCode();
/* 403 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 412 */     return "AutoModTriggerMetaData{keywordFilter=" + 
/* 413 */       Objects.toString(this.keywordFilter_value) + ", regexPatterns=" + 
/* 414 */       Objects.toString(this.regexPatterns_value) + ", presets=" + 
/* 415 */       Objects.toString(this.presets_value) + ", allowList=" + 
/* 416 */       Objects.toString(this.allowList_value) + ", mentionTotalLimit=" + 
/* 417 */       mentionTotalLimit().toString() + ", mentionRaidProtectionEnabled=" + 
/* 418 */       mentionRaidProtectionEnabled().toString() + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "AutoModTriggerMetaData", generator = "Immutables")
/*     */   static final class Json
/*     */     implements AutoModTriggerMetaData
/*     */   {
/* 432 */     Possible<List<String>> keywordFilter = Possible.absent();
/*     */ 
/*     */     
/* 435 */     Possible<List<String>> regexPatterns = Possible.absent();
/*     */ 
/*     */     
/* 438 */     Possible<List<Integer>> presets = Possible.absent();
/*     */ 
/*     */     
/* 441 */     Possible<List<String>> allowList = Possible.absent();
/*     */ 
/*     */     
/* 444 */     Possible<Integer> mentionTotalLimit = Possible.absent();
/*     */ 
/*     */     
/* 447 */     Possible<Boolean> mentionRaidProtectionEnabled = Possible.absent();
/*     */     
/*     */     @JsonProperty("keyword_filter")
/*     */     public void setKeywordFilter(Possible<List<String>> keywordFilter) {
/* 451 */       this.keywordFilter = keywordFilter;
/*     */     }
/*     */     @JsonProperty("regex_patterns")
/*     */     public void setRegexPatterns(Possible<List<String>> regexPatterns) {
/* 455 */       this.regexPatterns = regexPatterns;
/*     */     }
/*     */     @JsonProperty("presets")
/*     */     public void setPresets(Possible<List<Integer>> presets) {
/* 459 */       this.presets = presets;
/*     */     }
/*     */     @JsonProperty("allow_list")
/*     */     public void setAllowList(Possible<List<String>> allowList) {
/* 463 */       this.allowList = allowList;
/*     */     }
/*     */     @JsonProperty("mention_total_limit")
/*     */     public void setMentionTotalLimit(Possible<Integer> mentionTotalLimit) {
/* 467 */       this.mentionTotalLimit = mentionTotalLimit;
/*     */     }
/*     */     @JsonProperty("mention_raid_protection_enabled")
/*     */     public void setMentionRaidProtectionEnabled(Possible<Boolean> mentionRaidProtectionEnabled) {
/* 471 */       this.mentionRaidProtectionEnabled = mentionRaidProtectionEnabled;
/*     */     }
/*     */     public Possible<List<String>> keywordFilter() {
/* 474 */       throw new UnsupportedOperationException();
/*     */     } public Possible<List<String>> regexPatterns() {
/* 476 */       throw new UnsupportedOperationException();
/*     */     } public Possible<List<Integer>> presets() {
/* 478 */       throw new UnsupportedOperationException();
/*     */     } public Possible<List<String>> allowList() {
/* 480 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Integer> mentionTotalLimit() {
/* 482 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Boolean> mentionRaidProtectionEnabled() {
/* 484 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableAutoModTriggerMetaData fromJson(Json json) {
/* 495 */     Builder builder = builder();
/* 496 */     if (json.keywordFilter != null) {
/* 497 */       builder.keywordFilter(json.keywordFilter);
/*     */     }
/* 499 */     if (json.regexPatterns != null) {
/* 500 */       builder.regexPatterns(json.regexPatterns);
/*     */     }
/* 502 */     if (json.presets != null) {
/* 503 */       builder.presets(json.presets);
/*     */     }
/* 505 */     if (json.allowList != null) {
/* 506 */       builder.allowList(json.allowList);
/*     */     }
/* 508 */     if (json.mentionTotalLimit != null) {
/* 509 */       builder.mentionTotalLimit(json.mentionTotalLimit);
/*     */     }
/* 511 */     if (json.mentionRaidProtectionEnabled != null) {
/* 512 */       builder.mentionRaidProtectionEnabled(json.mentionRaidProtectionEnabled);
/*     */     }
/* 514 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableAutoModTriggerMetaData of(Possible<List<String>> keywordFilter, Possible<List<String>> regexPatterns, Possible<List<Integer>> presets, Possible<List<String>> allowList, Possible<Integer> mentionTotalLimit, Possible<Boolean> mentionRaidProtectionEnabled) {
/* 528 */     return new ImmutableAutoModTriggerMetaData(keywordFilter, regexPatterns, presets, allowList, mentionTotalLimit, mentionRaidProtectionEnabled);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableAutoModTriggerMetaData copyOf(AutoModTriggerMetaData instance) {
/* 539 */     if (instance instanceof ImmutableAutoModTriggerMetaData) {
/* 540 */       return (ImmutableAutoModTriggerMetaData)instance;
/*     */     }
/* 542 */     return builder()
/* 543 */       .from(instance)
/* 544 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isKeywordFilterPresent() {
/* 548 */     return !this.keywordFilter_absent;
/*     */   }
/*     */   
/*     */   public List<String> keywordFilterOrElse(List<String> defaultValue) {
/* 552 */     return !this.keywordFilter_absent ? this.keywordFilter_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isRegexPatternsPresent() {
/* 556 */     return !this.regexPatterns_absent;
/*     */   }
/*     */   
/*     */   public List<String> regexPatternsOrElse(List<String> defaultValue) {
/* 560 */     return !this.regexPatterns_absent ? this.regexPatterns_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isPresetsPresent() {
/* 564 */     return !this.presets_absent;
/*     */   }
/*     */   
/*     */   public List<Integer> presetsOrElse(List<Integer> defaultValue) {
/* 568 */     return !this.presets_absent ? this.presets_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isAllowListPresent() {
/* 572 */     return !this.allowList_absent;
/*     */   }
/*     */   
/*     */   public List<String> allowListOrElse(List<String> defaultValue) {
/* 576 */     return !this.allowList_absent ? this.allowList_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isMentionTotalLimitPresent() {
/* 580 */     return !this.mentionTotalLimit_absent;
/*     */   }
/*     */   
/*     */   public Integer mentionTotalLimitOrElse(Integer defaultValue) {
/* 584 */     return !this.mentionTotalLimit_absent ? this.mentionTotalLimit_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isMentionRaidProtectionEnabledPresent() {
/* 588 */     return !this.mentionRaidProtectionEnabled_absent;
/*     */   }
/*     */   
/*     */   public Boolean mentionRaidProtectionEnabledOrElse(Boolean defaultValue) {
/* 592 */     return !this.mentionRaidProtectionEnabled_absent ? this.mentionRaidProtectionEnabled_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 610 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "AutoModTriggerMetaData", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/* 622 */     private List<String> keywordFilter_list = null;
/* 623 */     private List<String> regexPatterns_list = null;
/* 624 */     private List<Integer> presets_list = null;
/* 625 */     private List<String> allowList_list = null;
/* 626 */     private Possible<Integer> mentionTotalLimit_possible = Possible.absent();
/* 627 */     private Possible<Boolean> mentionRaidProtectionEnabled_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(AutoModTriggerMetaData instance) {
/* 640 */       Objects.requireNonNull(instance, "instance");
/* 641 */       keywordFilter(instance.keywordFilter());
/* 642 */       regexPatterns(instance.regexPatterns());
/* 643 */       presets(instance.presets());
/* 644 */       allowList(instance.allowList());
/* 645 */       mentionTotalLimit(instance.mentionTotalLimit());
/* 646 */       mentionRaidProtectionEnabled(instance.mentionRaidProtectionEnabled());
/* 647 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addKeywordFilter(String element) {
/* 651 */       keywordFilter_getOrCreate().add(element);
/* 652 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addAllKeywordFilter(List<String> elements) {
/* 656 */       keywordFilter_getOrCreate().addAll(elements);
/* 657 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("keyword_filter")
/*     */     public Builder keywordFilter(Possible<List<String>> elements) {
/* 662 */       this.keywordFilter_list = null;
/* 663 */       elements.toOptional().ifPresent(e -> keywordFilter_getOrCreate().addAll(e));
/* 664 */       return this;
/*     */     }
/*     */     
/*     */     public Builder keywordFilter(List<String> elements) {
/* 668 */       this.keywordFilter_list = new ArrayList<>(elements);
/* 669 */       return this;
/*     */     }
/*     */     
/*     */     public Builder keywordFilter(Iterable<String> elements) {
/* 673 */       this.keywordFilter_list = (List<String>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 674 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addRegexPattern(String element) {
/* 678 */       regexPatterns_getOrCreate().add(element);
/* 679 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addAllRegexPatterns(List<String> elements) {
/* 683 */       regexPatterns_getOrCreate().addAll(elements);
/* 684 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("regex_patterns")
/*     */     public Builder regexPatterns(Possible<List<String>> elements) {
/* 689 */       this.regexPatterns_list = null;
/* 690 */       elements.toOptional().ifPresent(e -> regexPatterns_getOrCreate().addAll(e));
/* 691 */       return this;
/*     */     }
/*     */     
/*     */     public Builder regexPatterns(List<String> elements) {
/* 695 */       this.regexPatterns_list = new ArrayList<>(elements);
/* 696 */       return this;
/*     */     }
/*     */     
/*     */     public Builder regexPatterns(Iterable<String> elements) {
/* 700 */       this.regexPatterns_list = (List<String>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 701 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addPreset(Integer element) {
/* 705 */       presets_getOrCreate().add(element);
/* 706 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addAllPresets(List<Integer> elements) {
/* 710 */       presets_getOrCreate().addAll(elements);
/* 711 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("presets")
/*     */     public Builder presets(Possible<List<Integer>> elements) {
/* 716 */       this.presets_list = null;
/* 717 */       elements.toOptional().ifPresent(e -> presets_getOrCreate().addAll(e));
/* 718 */       return this;
/*     */     }
/*     */     
/*     */     public Builder presets(List<Integer> elements) {
/* 722 */       this.presets_list = new ArrayList<>(elements);
/* 723 */       return this;
/*     */     }
/*     */     
/*     */     public Builder presets(Iterable<Integer> elements) {
/* 727 */       this.presets_list = (List<Integer>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 728 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addAllowList(String element) {
/* 732 */       allowList_getOrCreate().add(element);
/* 733 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addAllAllowList(List<String> elements) {
/* 737 */       allowList_getOrCreate().addAll(elements);
/* 738 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("allow_list")
/*     */     public Builder allowList(Possible<List<String>> elements) {
/* 743 */       this.allowList_list = null;
/* 744 */       elements.toOptional().ifPresent(e -> allowList_getOrCreate().addAll(e));
/* 745 */       return this;
/*     */     }
/*     */     
/*     */     public Builder allowList(List<String> elements) {
/* 749 */       this.allowList_list = new ArrayList<>(elements);
/* 750 */       return this;
/*     */     }
/*     */     
/*     */     public Builder allowList(Iterable<String> elements) {
/* 754 */       this.allowList_list = (List<String>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 755 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("mention_total_limit")
/*     */     public Builder mentionTotalLimit(Possible<Integer> value) {
/* 760 */       this.mentionTotalLimit_possible = value;
/* 761 */       return this;
/*     */     }
/*     */     
/*     */     public Builder mentionTotalLimit(Integer value) {
/* 765 */       this.mentionTotalLimit_possible = Possible.of(value);
/* 766 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("mention_raid_protection_enabled")
/*     */     public Builder mentionRaidProtectionEnabled(Possible<Boolean> value) {
/* 771 */       this.mentionRaidProtectionEnabled_possible = value;
/* 772 */       return this;
/*     */     }
/*     */     
/*     */     public Builder mentionRaidProtectionEnabled(Boolean value) {
/* 776 */       this.mentionRaidProtectionEnabled_possible = Possible.of(value);
/* 777 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableAutoModTriggerMetaData build() {
/* 786 */       return new ImmutableAutoModTriggerMetaData(null, 
/*     */           
/* 788 */           keywordFilter_build(), 
/* 789 */           regexPatterns_build(), 
/* 790 */           presets_build(), 
/* 791 */           allowList_build(), 
/* 792 */           mentionTotalLimit_build(), 
/* 793 */           mentionRaidProtectionEnabled_build());
/*     */     }
/*     */     
/*     */     private Possible<List<String>> keywordFilter_build() {
/* 797 */       return (this.keywordFilter_list == null) ? Possible.absent() : 
/* 798 */         Possible.of(this.keywordFilter_list);
/*     */     }
/*     */     
/*     */     private List<String> keywordFilter_getOrCreate() {
/* 802 */       if (this.keywordFilter_list == null) {
/* 803 */         this.keywordFilter_list = new ArrayList<>();
/*     */       }
/* 805 */       return this.keywordFilter_list;
/*     */     }
/*     */     
/*     */     private Possible<List<String>> regexPatterns_build() {
/* 809 */       return (this.regexPatterns_list == null) ? Possible.absent() : 
/* 810 */         Possible.of(this.regexPatterns_list);
/*     */     }
/*     */     
/*     */     private List<String> regexPatterns_getOrCreate() {
/* 814 */       if (this.regexPatterns_list == null) {
/* 815 */         this.regexPatterns_list = new ArrayList<>();
/*     */       }
/* 817 */       return this.regexPatterns_list;
/*     */     }
/*     */     
/*     */     private Possible<List<Integer>> presets_build() {
/* 821 */       return (this.presets_list == null) ? Possible.absent() : 
/* 822 */         Possible.of(this.presets_list);
/*     */     }
/*     */     
/*     */     private List<Integer> presets_getOrCreate() {
/* 826 */       if (this.presets_list == null) {
/* 827 */         this.presets_list = new ArrayList<>();
/*     */       }
/* 829 */       return this.presets_list;
/*     */     }
/*     */     
/*     */     private Possible<List<String>> allowList_build() {
/* 833 */       return (this.allowList_list == null) ? Possible.absent() : 
/* 834 */         Possible.of(this.allowList_list);
/*     */     }
/*     */     
/*     */     private List<String> allowList_getOrCreate() {
/* 838 */       if (this.allowList_list == null) {
/* 839 */         this.allowList_list = new ArrayList<>();
/*     */       }
/* 841 */       return this.allowList_list;
/*     */     }
/*     */     
/*     */     private Possible<Integer> mentionTotalLimit_build() {
/* 845 */       return this.mentionTotalLimit_possible;
/*     */     }
/*     */     
/*     */     private Possible<Boolean> mentionRaidProtectionEnabled_build() {
/* 849 */       return this.mentionRaidProtectionEnabled_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableAutoModTriggerMetaData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */