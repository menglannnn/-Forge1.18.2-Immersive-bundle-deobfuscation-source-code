/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.Id;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.time.Instant;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "GuildScheduledEventCreateRequest", generator = "Immutables")
/*     */ public final class ImmutableGuildScheduledEventCreateRequest
/*     */   implements GuildScheduledEventCreateRequest
/*     */ {
/*     */   private final long channelId_value;
/*     */   private final boolean channelId_absent;
/*     */   private final GuildScheduledEventEntityMetadataData entityMetadata_value;
/*     */   private final boolean entityMetadata_absent;
/*     */   private final String name;
/*     */   private final int privacyLevel;
/*     */   private final Instant scheduledStartTime;
/*     */   private final Instant scheduledEndTime_value;
/*     */   private final boolean scheduledEndTime_absent;
/*     */   private final String description_value;
/*     */   private final boolean description_absent;
/*     */   private final int entityType;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private ImmutableGuildScheduledEventCreateRequest(Possible<Id> channelId, Possible<GuildScheduledEventEntityMetadataData> entityMetadata, String name, int privacyLevel, Instant scheduledStartTime, Possible<Instant> scheduledEndTime, Possible<String> description, int entityType) {
/*  50 */     Possible<Id> channelId$impl = channelId;
/*  51 */     Possible<GuildScheduledEventEntityMetadataData> entityMetadata$impl = entityMetadata;
/*  52 */     this.name = Objects.<String>requireNonNull(name, "name");
/*  53 */     this.privacyLevel = privacyLevel;
/*  54 */     this.scheduledStartTime = Objects.<Instant>requireNonNull(scheduledStartTime, "scheduledStartTime");
/*  55 */     Possible<Instant> scheduledEndTime$impl = scheduledEndTime;
/*  56 */     Possible<String> description$impl = description;
/*  57 */     this.entityType = entityType;
/*  58 */     this
/*     */       
/*  60 */       .channelId_value = ((Long)channelId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  61 */     this.channelId_absent = channelId$impl.isAbsent();
/*  62 */     this.entityMetadata_value = entityMetadata$impl.toOptional().orElse(null);
/*  63 */     this.entityMetadata_absent = entityMetadata$impl.isAbsent();
/*  64 */     this.scheduledEndTime_value = scheduledEndTime$impl.toOptional().orElse(null);
/*  65 */     this.scheduledEndTime_absent = scheduledEndTime$impl.isAbsent();
/*  66 */     this.description_value = description$impl.toOptional().orElse(null);
/*  67 */     this.description_absent = description$impl.isAbsent();
/*  68 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableGuildScheduledEventCreateRequest(ImmutableGuildScheduledEventCreateRequest original, Possible<Id> channelId, Possible<GuildScheduledEventEntityMetadataData> entityMetadata, String name, int privacyLevel, Instant scheduledStartTime, Possible<Instant> scheduledEndTime, Possible<String> description, int entityType) {
/*  81 */     Possible<Id> channelId$impl = channelId;
/*  82 */     Possible<GuildScheduledEventEntityMetadataData> entityMetadata$impl = entityMetadata;
/*  83 */     this.name = name;
/*  84 */     this.privacyLevel = privacyLevel;
/*  85 */     this.scheduledStartTime = scheduledStartTime;
/*  86 */     Possible<Instant> scheduledEndTime$impl = scheduledEndTime;
/*  87 */     Possible<String> description$impl = description;
/*  88 */     this.entityType = entityType;
/*  89 */     this
/*     */       
/*  91 */       .channelId_value = ((Long)channelId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  92 */     this.channelId_absent = channelId$impl.isAbsent();
/*  93 */     this.entityMetadata_value = entityMetadata$impl.toOptional().orElse(null);
/*  94 */     this.entityMetadata_absent = entityMetadata$impl.isAbsent();
/*  95 */     this.scheduledEndTime_value = scheduledEndTime$impl.toOptional().orElse(null);
/*  96 */     this.scheduledEndTime_absent = scheduledEndTime$impl.isAbsent();
/*  97 */     this.description_value = description$impl.toOptional().orElse(null);
/*  98 */     this.description_absent = description$impl.isAbsent();
/*  99 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 105 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "GuildScheduledEventCreateRequest", generator = "Immutables")
/*     */   private final class InitShim {
/*     */     private String formatInitCycleMessage() {
/* 110 */       List<String> attributes = new ArrayList<>();
/* 111 */       return "Cannot build GuildScheduledEventCreateRequest, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @JsonProperty("channel_id")
/*     */   public Possible<Id> channelId() {
/* 121 */     return this.channelId_absent ? Possible.absent() : 
/* 122 */       Possible.of(Id.of(this.channelId_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("entity_metadata")
/*     */   public Possible<GuildScheduledEventEntityMetadataData> entityMetadata() {
/* 131 */     return this.entityMetadata_absent ? Possible.absent() : Possible.of(this.entityMetadata_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("name")
/*     */   public String name() {
/* 140 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("privacy_level")
/*     */   public int privacyLevel() {
/* 149 */     return this.privacyLevel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("scheduled_start_time")
/*     */   public Instant scheduledStartTime() {
/* 158 */     return this.scheduledStartTime;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("scheduled_end_time")
/*     */   public Possible<Instant> scheduledEndTime() {
/* 167 */     return this.scheduledEndTime_absent ? Possible.absent() : Possible.of(this.scheduledEndTime_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("description")
/*     */   public Possible<String> description() {
/* 176 */     return this.description_absent ? Possible.absent() : Possible.of(this.description_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("entity_type")
/*     */   public int entityType() {
/* 185 */     return this.entityType;
/*     */   }
/*     */   
/*     */   public ImmutableGuildScheduledEventCreateRequest withChannelId(Possible<Id> value) {
/* 189 */     Possible<Id> newValue = Objects.<Possible<Id>>requireNonNull(value);
/* 190 */     return new ImmutableGuildScheduledEventCreateRequest(this, newValue, 
/*     */ 
/*     */         
/* 193 */         entityMetadata(), this.name, this.privacyLevel, this.scheduledStartTime, 
/*     */ 
/*     */ 
/*     */         
/* 197 */         scheduledEndTime(), 
/* 198 */         description(), this.entityType);
/*     */   }
/*     */ 
/*     */   
/*     */   public ImmutableGuildScheduledEventCreateRequest withChannelId(long value) {
/* 203 */     Possible<Id> newValue = Possible.of(Id.of(value));
/* 204 */     return new ImmutableGuildScheduledEventCreateRequest(this, newValue, 
/*     */ 
/*     */         
/* 207 */         entityMetadata(), this.name, this.privacyLevel, this.scheduledStartTime, 
/*     */ 
/*     */ 
/*     */         
/* 211 */         scheduledEndTime(), 
/* 212 */         description(), this.entityType);
/*     */   }
/*     */ 
/*     */   
/*     */   public ImmutableGuildScheduledEventCreateRequest withEntityMetadata(Possible<GuildScheduledEventEntityMetadataData> value) {
/* 217 */     Possible<GuildScheduledEventEntityMetadataData> newValue = Objects.<Possible<GuildScheduledEventEntityMetadataData>>requireNonNull(value);
/* 218 */     return new ImmutableGuildScheduledEventCreateRequest(this, 
/*     */         
/* 220 */         channelId(), newValue, this.name, this.privacyLevel, this.scheduledStartTime, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 225 */         scheduledEndTime(), 
/* 226 */         description(), this.entityType);
/*     */   }
/*     */ 
/*     */   
/*     */   public ImmutableGuildScheduledEventCreateRequest withEntityMetadata(GuildScheduledEventEntityMetadataData value) {
/* 231 */     Possible<GuildScheduledEventEntityMetadataData> newValue = Possible.of(value);
/* 232 */     return new ImmutableGuildScheduledEventCreateRequest(this, 
/*     */         
/* 234 */         channelId(), newValue, this.name, this.privacyLevel, this.scheduledStartTime, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 239 */         scheduledEndTime(), 
/* 240 */         description(), this.entityType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableGuildScheduledEventCreateRequest withName(String value) {
/* 251 */     String newValue = Objects.<String>requireNonNull(value, "name");
/* 252 */     if (this.name.equals(newValue)) return this; 
/* 253 */     return new ImmutableGuildScheduledEventCreateRequest(this, 
/*     */         
/* 255 */         channelId(), 
/* 256 */         entityMetadata(), newValue, this.privacyLevel, this.scheduledStartTime, 
/*     */ 
/*     */ 
/*     */         
/* 260 */         scheduledEndTime(), 
/* 261 */         description(), this.entityType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableGuildScheduledEventCreateRequest withPrivacyLevel(int value) {
/* 272 */     if (this.privacyLevel == value) return this; 
/* 273 */     return new ImmutableGuildScheduledEventCreateRequest(this, 
/*     */         
/* 275 */         channelId(), 
/* 276 */         entityMetadata(), this.name, value, this.scheduledStartTime, 
/*     */ 
/*     */ 
/*     */         
/* 280 */         scheduledEndTime(), 
/* 281 */         description(), this.entityType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableGuildScheduledEventCreateRequest withScheduledStartTime(Instant value) {
/* 292 */     if (this.scheduledStartTime == value) return this; 
/* 293 */     Instant newValue = Objects.<Instant>requireNonNull(value, "scheduledStartTime");
/* 294 */     return new ImmutableGuildScheduledEventCreateRequest(this, 
/*     */         
/* 296 */         channelId(), 
/* 297 */         entityMetadata(), this.name, this.privacyLevel, newValue, 
/*     */ 
/*     */ 
/*     */         
/* 301 */         scheduledEndTime(), 
/* 302 */         description(), this.entityType);
/*     */   }
/*     */ 
/*     */   
/*     */   public ImmutableGuildScheduledEventCreateRequest withScheduledEndTime(Possible<Instant> value) {
/* 307 */     Possible<Instant> newValue = Objects.<Possible<Instant>>requireNonNull(value);
/* 308 */     return new ImmutableGuildScheduledEventCreateRequest(this, 
/*     */         
/* 310 */         channelId(), 
/* 311 */         entityMetadata(), this.name, this.privacyLevel, this.scheduledStartTime, newValue, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 316 */         description(), this.entityType);
/*     */   }
/*     */ 
/*     */   
/*     */   public ImmutableGuildScheduledEventCreateRequest withScheduledEndTime(Instant value) {
/* 321 */     Possible<Instant> newValue = Possible.of(value);
/* 322 */     return new ImmutableGuildScheduledEventCreateRequest(this, 
/*     */         
/* 324 */         channelId(), 
/* 325 */         entityMetadata(), this.name, this.privacyLevel, this.scheduledStartTime, newValue, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 330 */         description(), this.entityType);
/*     */   }
/*     */ 
/*     */   
/*     */   public ImmutableGuildScheduledEventCreateRequest withDescription(Possible<String> value) {
/* 335 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 336 */     return new ImmutableGuildScheduledEventCreateRequest(this, 
/*     */         
/* 338 */         channelId(), 
/* 339 */         entityMetadata(), this.name, this.privacyLevel, this.scheduledStartTime, 
/*     */ 
/*     */ 
/*     */         
/* 343 */         scheduledEndTime(), newValue, this.entityType);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ImmutableGuildScheduledEventCreateRequest withDescription(String value) {
/* 349 */     Possible<String> newValue = Possible.of(value);
/* 350 */     return new ImmutableGuildScheduledEventCreateRequest(this, 
/*     */         
/* 352 */         channelId(), 
/* 353 */         entityMetadata(), this.name, this.privacyLevel, this.scheduledStartTime, 
/*     */ 
/*     */ 
/*     */         
/* 357 */         scheduledEndTime(), newValue, this.entityType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableGuildScheduledEventCreateRequest withEntityType(int value) {
/* 369 */     if (this.entityType == value) return this; 
/* 370 */     return new ImmutableGuildScheduledEventCreateRequest(this, 
/*     */         
/* 372 */         channelId(), 
/* 373 */         entityMetadata(), this.name, this.privacyLevel, this.scheduledStartTime, 
/*     */ 
/*     */ 
/*     */         
/* 377 */         scheduledEndTime(), 
/* 378 */         description(), value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 388 */     if (this == another) return true; 
/* 389 */     return (another instanceof ImmutableGuildScheduledEventCreateRequest && 
/* 390 */       equalTo(0, (ImmutableGuildScheduledEventCreateRequest)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableGuildScheduledEventCreateRequest another) {
/* 394 */     return (channelId().equals(another.channelId()) && 
/* 395 */       entityMetadata().equals(another.entityMetadata()) && this.name
/* 396 */       .equals(another.name) && this.privacyLevel == another.privacyLevel && this.scheduledStartTime
/*     */       
/* 398 */       .equals(another.scheduledStartTime) && 
/* 399 */       scheduledEndTime().equals(another.scheduledEndTime()) && 
/* 400 */       description().equals(another.description()) && this.entityType == another.entityType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 410 */     int h = 5381;
/* 411 */     h += (h << 5) + channelId().hashCode();
/* 412 */     h += (h << 5) + entityMetadata().hashCode();
/* 413 */     h += (h << 5) + this.name.hashCode();
/* 414 */     h += (h << 5) + this.privacyLevel;
/* 415 */     h += (h << 5) + this.scheduledStartTime.hashCode();
/* 416 */     h += (h << 5) + scheduledEndTime().hashCode();
/* 417 */     h += (h << 5) + description().hashCode();
/* 418 */     h += (h << 5) + this.entityType;
/* 419 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 428 */     return "GuildScheduledEventCreateRequest{channelId=" + 
/* 429 */       channelId().toString() + ", entityMetadata=" + 
/* 430 */       entityMetadata().toString() + ", name=" + this.name + ", privacyLevel=" + this.privacyLevel + ", scheduledStartTime=" + this.scheduledStartTime + ", scheduledEndTime=" + 
/*     */ 
/*     */ 
/*     */       
/* 434 */       scheduledEndTime().toString() + ", description=" + 
/* 435 */       description().toString() + ", entityType=" + this.entityType + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "GuildScheduledEventCreateRequest", generator = "Immutables")
/*     */   static final class Json
/*     */     implements GuildScheduledEventCreateRequest
/*     */   {
/* 450 */     Possible<Id> channelId = Possible.absent();
/*     */ 
/*     */     
/* 453 */     Possible<GuildScheduledEventEntityMetadataData> entityMetadata = Possible.absent();
/*     */     
/*     */     String name;
/*     */     
/*     */     int privacyLevel;
/*     */     boolean privacyLevelIsSet;
/*     */     Instant scheduledStartTime;
/* 460 */     Possible<Instant> scheduledEndTime = Possible.absent();
/*     */ 
/*     */     
/* 463 */     Possible<String> description = Possible.absent();
/*     */     int entityType;
/*     */     boolean entityTypeIsSet;
/*     */     
/*     */     @JsonProperty("channel_id")
/*     */     public void setChannelId(Possible<Id> channelId) {
/* 469 */       this.channelId = channelId;
/*     */     }
/*     */     @JsonProperty("entity_metadata")
/*     */     public void setEntityMetadata(Possible<GuildScheduledEventEntityMetadataData> entityMetadata) {
/* 473 */       this.entityMetadata = entityMetadata;
/*     */     }
/*     */     @JsonProperty("name")
/*     */     public void setName(String name) {
/* 477 */       this.name = name;
/*     */     }
/*     */     @JsonProperty("privacy_level")
/*     */     public void setPrivacyLevel(int privacyLevel) {
/* 481 */       this.privacyLevel = privacyLevel;
/* 482 */       this.privacyLevelIsSet = true;
/*     */     }
/*     */     @JsonProperty("scheduled_start_time")
/*     */     public void setScheduledStartTime(Instant scheduledStartTime) {
/* 486 */       this.scheduledStartTime = scheduledStartTime;
/*     */     }
/*     */     @JsonProperty("scheduled_end_time")
/*     */     public void setScheduledEndTime(Possible<Instant> scheduledEndTime) {
/* 490 */       this.scheduledEndTime = scheduledEndTime;
/*     */     }
/*     */     @JsonProperty("description")
/*     */     public void setDescription(Possible<String> description) {
/* 494 */       this.description = description;
/*     */     }
/*     */     @JsonProperty("entity_type")
/*     */     public void setEntityType(int entityType) {
/* 498 */       this.entityType = entityType;
/* 499 */       this.entityTypeIsSet = true;
/*     */     }
/*     */     public Possible<Id> channelId() {
/* 502 */       throw new UnsupportedOperationException();
/*     */     } public Possible<GuildScheduledEventEntityMetadataData> entityMetadata() {
/* 504 */       throw new UnsupportedOperationException();
/*     */     } public String name() {
/* 506 */       throw new UnsupportedOperationException();
/*     */     } public int privacyLevel() {
/* 508 */       throw new UnsupportedOperationException();
/*     */     } public Instant scheduledStartTime() {
/* 510 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Instant> scheduledEndTime() {
/* 512 */       throw new UnsupportedOperationException();
/*     */     } public Possible<String> description() {
/* 514 */       throw new UnsupportedOperationException();
/*     */     } public int entityType() {
/* 516 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableGuildScheduledEventCreateRequest fromJson(Json json) {
/* 527 */     Builder builder = builder();
/* 528 */     if (json.channelId != null) {
/* 529 */       builder.channelId(json.channelId);
/*     */     }
/* 531 */     if (json.entityMetadata != null) {
/* 532 */       builder.entityMetadata(json.entityMetadata);
/*     */     }
/* 534 */     if (json.name != null) {
/* 535 */       builder.name(json.name);
/*     */     }
/* 537 */     if (json.privacyLevelIsSet) {
/* 538 */       builder.privacyLevel(json.privacyLevel);
/*     */     }
/* 540 */     if (json.scheduledStartTime != null) {
/* 541 */       builder.scheduledStartTime(json.scheduledStartTime);
/*     */     }
/* 543 */     if (json.scheduledEndTime != null) {
/* 544 */       builder.scheduledEndTime(json.scheduledEndTime);
/*     */     }
/* 546 */     if (json.description != null) {
/* 547 */       builder.description(json.description);
/*     */     }
/* 549 */     if (json.entityTypeIsSet) {
/* 550 */       builder.entityType(json.entityType);
/*     */     }
/* 552 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableGuildScheduledEventCreateRequest of(Possible<Id> channelId, Possible<GuildScheduledEventEntityMetadataData> entityMetadata, String name, int privacyLevel, Instant scheduledStartTime, Possible<Instant> scheduledEndTime, Possible<String> description, int entityType) {
/* 568 */     return new ImmutableGuildScheduledEventCreateRequest(channelId, entityMetadata, name, privacyLevel, scheduledStartTime, scheduledEndTime, description, entityType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableGuildScheduledEventCreateRequest copyOf(GuildScheduledEventCreateRequest instance) {
/* 579 */     if (instance instanceof ImmutableGuildScheduledEventCreateRequest) {
/* 580 */       return (ImmutableGuildScheduledEventCreateRequest)instance;
/*     */     }
/* 582 */     return builder()
/* 583 */       .from(instance)
/* 584 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isChannelIdPresent() {
/* 588 */     return !this.channelId_absent;
/*     */   }
/*     */   
/*     */   public long channelIdOrElse(long defaultValue) {
/* 592 */     return !this.channelId_absent ? this.channelId_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isEntityMetadataPresent() {
/* 596 */     return !this.entityMetadata_absent;
/*     */   }
/*     */   
/*     */   public GuildScheduledEventEntityMetadataData entityMetadataOrElse(GuildScheduledEventEntityMetadataData defaultValue) {
/* 600 */     return !this.entityMetadata_absent ? this.entityMetadata_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isScheduledEndTimePresent() {
/* 604 */     return !this.scheduledEndTime_absent;
/*     */   }
/*     */   
/*     */   public Instant scheduledEndTimeOrElse(Instant defaultValue) {
/* 608 */     return !this.scheduledEndTime_absent ? this.scheduledEndTime_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isDescriptionPresent() {
/* 612 */     return !this.description_absent;
/*     */   }
/*     */   
/*     */   public String descriptionOrElse(String defaultValue) {
/* 616 */     return !this.description_absent ? this.description_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 636 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "GuildScheduledEventCreateRequest", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_NAME = 1L;
/*     */     
/*     */     private static final long INIT_BIT_PRIVACY_LEVEL = 2L;
/*     */     
/*     */     private static final long INIT_BIT_SCHEDULED_START_TIME = 4L;
/*     */     
/*     */     private static final long INIT_BIT_ENTITY_TYPE = 8L;
/*     */     
/* 652 */     private long initBits = 15L;
/*     */     
/* 654 */     private Possible<Id> channelId_possible = Possible.absent();
/* 655 */     private Possible<GuildScheduledEventEntityMetadataData> entityMetadata_possible = Possible.absent();
/* 656 */     private Possible<Instant> scheduledEndTime_possible = Possible.absent();
/* 657 */     private Possible<String> description_possible = Possible.absent();
/*     */ 
/*     */     
/*     */     private String name;
/*     */ 
/*     */     
/*     */     private int privacyLevel;
/*     */ 
/*     */     
/*     */     private Instant scheduledStartTime;
/*     */ 
/*     */     
/*     */     private int entityType;
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(GuildScheduledEventCreateRequest instance) {
/* 674 */       Objects.requireNonNull(instance, "instance");
/* 675 */       channelId(instance.channelId());
/* 676 */       entityMetadata(instance.entityMetadata());
/* 677 */       name(instance.name());
/* 678 */       privacyLevel(instance.privacyLevel());
/* 679 */       scheduledStartTime(instance.scheduledStartTime());
/* 680 */       scheduledEndTime(instance.scheduledEndTime());
/* 681 */       description(instance.description());
/* 682 */       entityType(instance.entityType());
/* 683 */       return this;
/*     */     }
/*     */     
/*     */     public Builder channelId(String value) {
/* 687 */       this.channelId_possible = Possible.of(Id.of(value));
/* 688 */       return this;
/*     */     }
/*     */     
/*     */     public Builder channelId(long value) {
/* 692 */       this.channelId_possible = Possible.of(Id.of(value));
/* 693 */       return this;
/*     */     }
/*     */     
/*     */     public Builder channelId(Id value) {
/* 697 */       this.channelId_possible = Possible.of(value);
/* 698 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("channel_id")
/*     */     public Builder channelId(Possible<Id> value) {
/* 703 */       this.channelId_possible = value;
/* 704 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("entity_metadata")
/*     */     public Builder entityMetadata(Possible<GuildScheduledEventEntityMetadataData> value) {
/* 709 */       this.entityMetadata_possible = value;
/* 710 */       return this;
/*     */     }
/*     */     
/*     */     public Builder entityMetadata(GuildScheduledEventEntityMetadataData value) {
/* 714 */       this.entityMetadata_possible = Possible.of(value);
/* 715 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("name")
/*     */     public final Builder name(String name) {
/* 725 */       this.name = Objects.<String>requireNonNull(name, "name");
/* 726 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 727 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("privacy_level")
/*     */     public final Builder privacyLevel(int privacyLevel) {
/* 737 */       this.privacyLevel = privacyLevel;
/* 738 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 739 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("scheduled_start_time")
/*     */     public final Builder scheduledStartTime(Instant scheduledStartTime) {
/* 749 */       this.scheduledStartTime = Objects.<Instant>requireNonNull(scheduledStartTime, "scheduledStartTime");
/* 750 */       this.initBits &= 0xFFFFFFFFFFFFFFFBL;
/* 751 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("scheduled_end_time")
/*     */     public Builder scheduledEndTime(Possible<Instant> value) {
/* 756 */       this.scheduledEndTime_possible = value;
/* 757 */       return this;
/*     */     }
/*     */     
/*     */     public Builder scheduledEndTime(Instant value) {
/* 761 */       this.scheduledEndTime_possible = Possible.of(value);
/* 762 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("description")
/*     */     public Builder description(Possible<String> value) {
/* 767 */       this.description_possible = value;
/* 768 */       return this;
/*     */     }
/*     */     
/*     */     public Builder description(String value) {
/* 772 */       this.description_possible = Possible.of(value);
/* 773 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("entity_type")
/*     */     public final Builder entityType(int entityType) {
/* 783 */       this.entityType = entityType;
/* 784 */       this.initBits &= 0xFFFFFFFFFFFFFFF7L;
/* 785 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableGuildScheduledEventCreateRequest build() {
/* 794 */       if (this.initBits != 0L) {
/* 795 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 797 */       return new ImmutableGuildScheduledEventCreateRequest(null, 
/*     */           
/* 799 */           channelId_build(), 
/* 800 */           entityMetadata_build(), this.name, this.privacyLevel, this.scheduledStartTime, 
/*     */ 
/*     */ 
/*     */           
/* 804 */           scheduledEndTime_build(), 
/* 805 */           description_build(), this.entityType);
/*     */     }
/*     */ 
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 810 */       List<String> attributes = new ArrayList<>();
/* 811 */       if ((this.initBits & 0x1L) != 0L) attributes.add("name"); 
/* 812 */       if ((this.initBits & 0x2L) != 0L) attributes.add("privacyLevel"); 
/* 813 */       if ((this.initBits & 0x4L) != 0L) attributes.add("scheduledStartTime"); 
/* 814 */       if ((this.initBits & 0x8L) != 0L) attributes.add("entityType"); 
/* 815 */       return "Cannot build GuildScheduledEventCreateRequest, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Possible<Id> channelId_build() {
/* 819 */       return this.channelId_possible;
/*     */     }
/*     */     
/*     */     private Possible<GuildScheduledEventEntityMetadataData> entityMetadata_build() {
/* 823 */       return this.entityMetadata_possible;
/*     */     }
/*     */     
/*     */     private Possible<Instant> scheduledEndTime_build() {
/* 827 */       return this.scheduledEndTime_possible;
/*     */     }
/*     */     
/*     */     private Possible<String> description_build() {
/* 831 */       return this.description_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableGuildScheduledEventCreateRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */