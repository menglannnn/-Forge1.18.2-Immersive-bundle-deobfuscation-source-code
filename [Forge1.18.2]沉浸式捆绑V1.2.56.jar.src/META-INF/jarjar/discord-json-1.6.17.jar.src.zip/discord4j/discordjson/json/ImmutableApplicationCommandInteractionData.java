/*      */ package discord4j.discordjson.json;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*      */ import com.fasterxml.jackson.annotation.JsonCreator;
/*      */ import com.fasterxml.jackson.annotation.JsonProperty;
/*      */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*      */ import discord4j.discordjson.possible.Possible;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import java.util.stream.Collectors;
/*      */ import java.util.stream.StreamSupport;
/*      */ import org.immutables.value.Generated;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Generated(from = "ApplicationCommandInteractionData", generator = "Immutables")
/*      */ public final class ImmutableApplicationCommandInteractionData
/*      */   implements ApplicationCommandInteractionData
/*      */ {
/*      */   private final String id_value;
/*      */   private final boolean id_absent;
/*      */   private final String name_value;
/*      */   private final boolean name_absent;
/*      */   private final Integer type_value;
/*      */   private final boolean type_absent;
/*      */   private final ApplicationCommandInteractionResolvedData resolved_value;
/*      */   private final boolean resolved_absent;
/*      */   private final List<ApplicationCommandInteractionOptionData> options_value;
/*      */   private final boolean options_absent;
/*      */   private final String customId_value;
/*      */   private final boolean customId_absent;
/*      */   private final Integer componentType_value;
/*      */   private final boolean componentType_absent;
/*      */   private final List<String> values_value;
/*      */   private final boolean values_absent;
/*      */   private final String targetId_value;
/*      */   private final boolean targetId_absent;
/*      */   private final List<ComponentData> components_value;
/*      */   private final boolean components_absent;
/*      */   private static final byte STAGE_INITIALIZING = -1;
/*      */   private static final byte STAGE_UNINITIALIZED = 0;
/*      */   private static final byte STAGE_INITIALIZED = 1;
/*      */   
/*      */   private ImmutableApplicationCommandInteractionData(Possible<String> id, Possible<String> name, Possible<Integer> type, Possible<ApplicationCommandInteractionResolvedData> resolved, Possible<List<ApplicationCommandInteractionOptionData>> options, Possible<String> customId, Possible<Integer> componentType, Possible<List<String>> values, Possible<String> targetId, Possible<List<ComponentData>> components) {
/*   61 */     Possible<String> id$impl = id;
/*   62 */     Possible<String> name$impl = name;
/*   63 */     Possible<Integer> type$impl = type;
/*   64 */     Possible<ApplicationCommandInteractionResolvedData> resolved$impl = resolved;
/*   65 */     Possible<List<ApplicationCommandInteractionOptionData>> options$impl = options;
/*   66 */     Possible<String> customId$impl = customId;
/*   67 */     Possible<Integer> componentType$impl = componentType;
/*   68 */     Possible<List<String>> values$impl = values;
/*   69 */     Possible<String> targetId$impl = targetId;
/*   70 */     Possible<List<ComponentData>> components$impl = components;
/*   71 */     this.id_value = id$impl.toOptional().orElse(null);
/*   72 */     this.id_absent = id$impl.isAbsent();
/*   73 */     this.name_value = name$impl.toOptional().orElse(null);
/*   74 */     this.name_absent = name$impl.isAbsent();
/*   75 */     this.type_value = type$impl.toOptional().orElse(null);
/*   76 */     this.type_absent = type$impl.isAbsent();
/*   77 */     this.resolved_value = resolved$impl.toOptional().orElse(null);
/*   78 */     this.resolved_absent = resolved$impl.isAbsent();
/*   79 */     this.options_value = options$impl.toOptional().orElse(null);
/*   80 */     this.options_absent = options$impl.isAbsent();
/*   81 */     this.customId_value = customId$impl.toOptional().orElse(null);
/*   82 */     this.customId_absent = customId$impl.isAbsent();
/*   83 */     this.componentType_value = componentType$impl.toOptional().orElse(null);
/*   84 */     this.componentType_absent = componentType$impl.isAbsent();
/*   85 */     this.values_value = values$impl.toOptional().orElse(null);
/*   86 */     this.values_absent = values$impl.isAbsent();
/*   87 */     this.targetId_value = targetId$impl.toOptional().orElse(null);
/*   88 */     this.targetId_absent = targetId$impl.isAbsent();
/*   89 */     this.components_value = components$impl.toOptional().orElse(null);
/*   90 */     this.components_absent = components$impl.isAbsent();
/*   91 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ImmutableApplicationCommandInteractionData(ImmutableApplicationCommandInteractionData original, Possible<String> id, Possible<String> name, Possible<Integer> type, Possible<ApplicationCommandInteractionResolvedData> resolved, Possible<List<ApplicationCommandInteractionOptionData>> options, Possible<String> customId, Possible<Integer> componentType, Possible<List<String>> values, Possible<String> targetId, Possible<List<ComponentData>> components) {
/*  106 */     Possible<String> id$impl = id;
/*  107 */     Possible<String> name$impl = name;
/*  108 */     Possible<Integer> type$impl = type;
/*  109 */     Possible<ApplicationCommandInteractionResolvedData> resolved$impl = resolved;
/*  110 */     Possible<List<ApplicationCommandInteractionOptionData>> options$impl = options;
/*  111 */     Possible<String> customId$impl = customId;
/*  112 */     Possible<Integer> componentType$impl = componentType;
/*  113 */     Possible<List<String>> values$impl = values;
/*  114 */     Possible<String> targetId$impl = targetId;
/*  115 */     Possible<List<ComponentData>> components$impl = components;
/*  116 */     this.id_value = id$impl.toOptional().orElse(null);
/*  117 */     this.id_absent = id$impl.isAbsent();
/*  118 */     this.name_value = name$impl.toOptional().orElse(null);
/*  119 */     this.name_absent = name$impl.isAbsent();
/*  120 */     this.type_value = type$impl.toOptional().orElse(null);
/*  121 */     this.type_absent = type$impl.isAbsent();
/*  122 */     this.resolved_value = resolved$impl.toOptional().orElse(null);
/*  123 */     this.resolved_absent = resolved$impl.isAbsent();
/*  124 */     this.options_value = options$impl.toOptional().orElse(null);
/*  125 */     this.options_absent = options$impl.isAbsent();
/*  126 */     this.customId_value = customId$impl.toOptional().orElse(null);
/*  127 */     this.customId_absent = customId$impl.isAbsent();
/*  128 */     this.componentType_value = componentType$impl.toOptional().orElse(null);
/*  129 */     this.componentType_absent = componentType$impl.isAbsent();
/*  130 */     this.values_value = values$impl.toOptional().orElse(null);
/*  131 */     this.values_absent = values$impl.isAbsent();
/*  132 */     this.targetId_value = targetId$impl.toOptional().orElse(null);
/*  133 */     this.targetId_absent = targetId$impl.isAbsent();
/*  134 */     this.components_value = components$impl.toOptional().orElse(null);
/*  135 */     this.components_absent = components$impl.isAbsent();
/*  136 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  142 */   private volatile transient InitShim initShim = new InitShim();
/*      */   
/*      */   @Generated(from = "ApplicationCommandInteractionData", generator = "Immutables")
/*      */   private final class InitShim {
/*      */     private String formatInitCycleMessage() {
/*  147 */       List<String> attributes = new ArrayList<>();
/*  148 */       return "Cannot build ApplicationCommandInteractionData, attribute initializers form cycle " + attributes;
/*      */     }
/*      */ 
/*      */     
/*      */     private InitShim() {}
/*      */   }
/*      */ 
/*      */   
/*      */   @JsonProperty("id")
/*      */   public Possible<String> id() {
/*  158 */     return this.id_absent ? Possible.absent() : Possible.of(this.id_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("name")
/*      */   public Possible<String> name() {
/*  167 */     return this.name_absent ? Possible.absent() : Possible.of(this.name_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("type")
/*      */   public Possible<Integer> type() {
/*  176 */     return this.type_absent ? Possible.absent() : Possible.of(this.type_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("resolved")
/*      */   public Possible<ApplicationCommandInteractionResolvedData> resolved() {
/*  185 */     return this.resolved_absent ? Possible.absent() : Possible.of(this.resolved_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("options")
/*      */   public Possible<List<ApplicationCommandInteractionOptionData>> options() {
/*  194 */     return this.options_absent ? Possible.absent() : 
/*  195 */       Possible.of(this.options_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("custom_id")
/*      */   public Possible<String> customId() {
/*  204 */     return this.customId_absent ? Possible.absent() : Possible.of(this.customId_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("component_type")
/*      */   public Possible<Integer> componentType() {
/*  213 */     return this.componentType_absent ? Possible.absent() : Possible.of(this.componentType_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("values")
/*      */   public Possible<List<String>> values() {
/*  222 */     return this.values_absent ? Possible.absent() : 
/*  223 */       Possible.of(this.values_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("target_id")
/*      */   public Possible<String> targetId() {
/*  232 */     return this.targetId_absent ? Possible.absent() : Possible.of(this.targetId_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("components")
/*      */   public Possible<List<ComponentData>> components() {
/*  241 */     return this.components_absent ? Possible.absent() : 
/*  242 */       Possible.of(this.components_value);
/*      */   }
/*      */   
/*      */   public ImmutableApplicationCommandInteractionData withId(Possible<String> value) {
/*  246 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  247 */     return new ImmutableApplicationCommandInteractionData(this, newValue, 
/*      */ 
/*      */         
/*  250 */         name(), 
/*  251 */         type(), 
/*  252 */         resolved(), 
/*  253 */         options(), 
/*  254 */         customId(), 
/*  255 */         componentType(), 
/*  256 */         values(), 
/*  257 */         targetId(), 
/*  258 */         components());
/*      */   }
/*      */   
/*      */   public ImmutableApplicationCommandInteractionData withId(String value) {
/*  262 */     Possible<String> newValue = Possible.of(value);
/*  263 */     return new ImmutableApplicationCommandInteractionData(this, newValue, 
/*      */ 
/*      */         
/*  266 */         name(), 
/*  267 */         type(), 
/*  268 */         resolved(), 
/*  269 */         options(), 
/*  270 */         customId(), 
/*  271 */         componentType(), 
/*  272 */         values(), 
/*  273 */         targetId(), 
/*  274 */         components());
/*      */   }
/*      */   
/*      */   public ImmutableApplicationCommandInteractionData withName(Possible<String> value) {
/*  278 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  279 */     return new ImmutableApplicationCommandInteractionData(this, 
/*      */         
/*  281 */         id(), newValue, 
/*      */         
/*  283 */         type(), 
/*  284 */         resolved(), 
/*  285 */         options(), 
/*  286 */         customId(), 
/*  287 */         componentType(), 
/*  288 */         values(), 
/*  289 */         targetId(), 
/*  290 */         components());
/*      */   }
/*      */   
/*      */   public ImmutableApplicationCommandInteractionData withName(String value) {
/*  294 */     Possible<String> newValue = Possible.of(value);
/*  295 */     return new ImmutableApplicationCommandInteractionData(this, 
/*      */         
/*  297 */         id(), newValue, 
/*      */         
/*  299 */         type(), 
/*  300 */         resolved(), 
/*  301 */         options(), 
/*  302 */         customId(), 
/*  303 */         componentType(), 
/*  304 */         values(), 
/*  305 */         targetId(), 
/*  306 */         components());
/*      */   }
/*      */   
/*      */   public ImmutableApplicationCommandInteractionData withType(Possible<Integer> value) {
/*  310 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/*  311 */     return new ImmutableApplicationCommandInteractionData(this, 
/*      */         
/*  313 */         id(), 
/*  314 */         name(), newValue, 
/*      */         
/*  316 */         resolved(), 
/*  317 */         options(), 
/*  318 */         customId(), 
/*  319 */         componentType(), 
/*  320 */         values(), 
/*  321 */         targetId(), 
/*  322 */         components());
/*      */   }
/*      */   
/*      */   public ImmutableApplicationCommandInteractionData withType(Integer value) {
/*  326 */     Possible<Integer> newValue = Possible.of(value);
/*  327 */     return new ImmutableApplicationCommandInteractionData(this, 
/*      */         
/*  329 */         id(), 
/*  330 */         name(), newValue, 
/*      */         
/*  332 */         resolved(), 
/*  333 */         options(), 
/*  334 */         customId(), 
/*  335 */         componentType(), 
/*  336 */         values(), 
/*  337 */         targetId(), 
/*  338 */         components());
/*      */   }
/*      */   
/*      */   public ImmutableApplicationCommandInteractionData withResolved(Possible<ApplicationCommandInteractionResolvedData> value) {
/*  342 */     Possible<ApplicationCommandInteractionResolvedData> newValue = Objects.<Possible<ApplicationCommandInteractionResolvedData>>requireNonNull(value);
/*  343 */     return new ImmutableApplicationCommandInteractionData(this, 
/*      */         
/*  345 */         id(), 
/*  346 */         name(), 
/*  347 */         type(), newValue, 
/*      */         
/*  349 */         options(), 
/*  350 */         customId(), 
/*  351 */         componentType(), 
/*  352 */         values(), 
/*  353 */         targetId(), 
/*  354 */         components());
/*      */   }
/*      */   
/*      */   public ImmutableApplicationCommandInteractionData withResolved(ApplicationCommandInteractionResolvedData value) {
/*  358 */     Possible<ApplicationCommandInteractionResolvedData> newValue = Possible.of(value);
/*  359 */     return new ImmutableApplicationCommandInteractionData(this, 
/*      */         
/*  361 */         id(), 
/*  362 */         name(), 
/*  363 */         type(), newValue, 
/*      */         
/*  365 */         options(), 
/*  366 */         customId(), 
/*  367 */         componentType(), 
/*  368 */         values(), 
/*  369 */         targetId(), 
/*  370 */         components());
/*      */   }
/*      */   
/*      */   public ImmutableApplicationCommandInteractionData withOptions(Possible<List<ApplicationCommandInteractionOptionData>> possible) {
/*  374 */     Possible<List<ApplicationCommandInteractionOptionData>> newValue = Objects.<Possible<List<ApplicationCommandInteractionOptionData>>>requireNonNull(possible);
/*  375 */     return new ImmutableApplicationCommandInteractionData(this, 
/*      */         
/*  377 */         id(), 
/*  378 */         name(), 
/*  379 */         type(), 
/*  380 */         resolved(), newValue, 
/*      */         
/*  382 */         customId(), 
/*  383 */         componentType(), 
/*  384 */         values(), 
/*  385 */         targetId(), 
/*  386 */         components());
/*      */   }
/*      */   
/*      */   public ImmutableApplicationCommandInteractionData withOptions(Iterable<ApplicationCommandInteractionOptionData> elements) {
/*  390 */     Possible<List<ApplicationCommandInteractionOptionData>> newValue = Possible.of(
/*  391 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/*  392 */     return new ImmutableApplicationCommandInteractionData(this, 
/*      */         
/*  394 */         id(), 
/*  395 */         name(), 
/*  396 */         type(), 
/*  397 */         resolved(), newValue, 
/*      */         
/*  399 */         customId(), 
/*  400 */         componentType(), 
/*  401 */         values(), 
/*  402 */         targetId(), 
/*  403 */         components());
/*      */   }
/*      */   
/*      */   @SafeVarargs
/*      */   public final ImmutableApplicationCommandInteractionData withOptions(ApplicationCommandInteractionOptionData... elements) {
/*  408 */     Possible<List<ApplicationCommandInteractionOptionData>> newValue = Possible.of(Arrays.asList(elements));
/*  409 */     return new ImmutableApplicationCommandInteractionData(this, 
/*      */         
/*  411 */         id(), 
/*  412 */         name(), 
/*  413 */         type(), 
/*  414 */         resolved(), newValue, 
/*      */         
/*  416 */         customId(), 
/*  417 */         componentType(), 
/*  418 */         values(), 
/*  419 */         targetId(), 
/*  420 */         components());
/*      */   }
/*      */   
/*      */   public ImmutableApplicationCommandInteractionData withCustomId(Possible<String> value) {
/*  424 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  425 */     return new ImmutableApplicationCommandInteractionData(this, 
/*      */         
/*  427 */         id(), 
/*  428 */         name(), 
/*  429 */         type(), 
/*  430 */         resolved(), 
/*  431 */         options(), newValue, 
/*      */         
/*  433 */         componentType(), 
/*  434 */         values(), 
/*  435 */         targetId(), 
/*  436 */         components());
/*      */   }
/*      */   
/*      */   public ImmutableApplicationCommandInteractionData withCustomId(String value) {
/*  440 */     Possible<String> newValue = Possible.of(value);
/*  441 */     return new ImmutableApplicationCommandInteractionData(this, 
/*      */         
/*  443 */         id(), 
/*  444 */         name(), 
/*  445 */         type(), 
/*  446 */         resolved(), 
/*  447 */         options(), newValue, 
/*      */         
/*  449 */         componentType(), 
/*  450 */         values(), 
/*  451 */         targetId(), 
/*  452 */         components());
/*      */   }
/*      */   
/*      */   public ImmutableApplicationCommandInteractionData withComponentType(Possible<Integer> value) {
/*  456 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/*  457 */     return new ImmutableApplicationCommandInteractionData(this, 
/*      */         
/*  459 */         id(), 
/*  460 */         name(), 
/*  461 */         type(), 
/*  462 */         resolved(), 
/*  463 */         options(), 
/*  464 */         customId(), newValue, 
/*      */         
/*  466 */         values(), 
/*  467 */         targetId(), 
/*  468 */         components());
/*      */   }
/*      */   
/*      */   public ImmutableApplicationCommandInteractionData withComponentType(Integer value) {
/*  472 */     Possible<Integer> newValue = Possible.of(value);
/*  473 */     return new ImmutableApplicationCommandInteractionData(this, 
/*      */         
/*  475 */         id(), 
/*  476 */         name(), 
/*  477 */         type(), 
/*  478 */         resolved(), 
/*  479 */         options(), 
/*  480 */         customId(), newValue, 
/*      */         
/*  482 */         values(), 
/*  483 */         targetId(), 
/*  484 */         components());
/*      */   }
/*      */   
/*      */   public ImmutableApplicationCommandInteractionData withValues(Possible<List<String>> possible) {
/*  488 */     Possible<List<String>> newValue = Objects.<Possible<List<String>>>requireNonNull(possible);
/*  489 */     return new ImmutableApplicationCommandInteractionData(this, 
/*      */         
/*  491 */         id(), 
/*  492 */         name(), 
/*  493 */         type(), 
/*  494 */         resolved(), 
/*  495 */         options(), 
/*  496 */         customId(), 
/*  497 */         componentType(), newValue, 
/*      */         
/*  499 */         targetId(), 
/*  500 */         components());
/*      */   }
/*      */   
/*      */   public ImmutableApplicationCommandInteractionData withValues(Iterable<String> elements) {
/*  504 */     Possible<List<String>> newValue = Possible.of(
/*  505 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/*  506 */     return new ImmutableApplicationCommandInteractionData(this, 
/*      */         
/*  508 */         id(), 
/*  509 */         name(), 
/*  510 */         type(), 
/*  511 */         resolved(), 
/*  512 */         options(), 
/*  513 */         customId(), 
/*  514 */         componentType(), newValue, 
/*      */         
/*  516 */         targetId(), 
/*  517 */         components());
/*      */   }
/*      */   
/*      */   @SafeVarargs
/*      */   public final ImmutableApplicationCommandInteractionData withValues(String... elements) {
/*  522 */     Possible<List<String>> newValue = Possible.of(Arrays.asList(elements));
/*  523 */     return new ImmutableApplicationCommandInteractionData(this, 
/*      */         
/*  525 */         id(), 
/*  526 */         name(), 
/*  527 */         type(), 
/*  528 */         resolved(), 
/*  529 */         options(), 
/*  530 */         customId(), 
/*  531 */         componentType(), newValue, 
/*      */         
/*  533 */         targetId(), 
/*  534 */         components());
/*      */   }
/*      */   
/*      */   public ImmutableApplicationCommandInteractionData withTargetId(Possible<String> value) {
/*  538 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  539 */     return new ImmutableApplicationCommandInteractionData(this, 
/*      */         
/*  541 */         id(), 
/*  542 */         name(), 
/*  543 */         type(), 
/*  544 */         resolved(), 
/*  545 */         options(), 
/*  546 */         customId(), 
/*  547 */         componentType(), 
/*  548 */         values(), newValue, 
/*      */         
/*  550 */         components());
/*      */   }
/*      */   
/*      */   public ImmutableApplicationCommandInteractionData withTargetId(String value) {
/*  554 */     Possible<String> newValue = Possible.of(value);
/*  555 */     return new ImmutableApplicationCommandInteractionData(this, 
/*      */         
/*  557 */         id(), 
/*  558 */         name(), 
/*  559 */         type(), 
/*  560 */         resolved(), 
/*  561 */         options(), 
/*  562 */         customId(), 
/*  563 */         componentType(), 
/*  564 */         values(), newValue, 
/*      */         
/*  566 */         components());
/*      */   }
/*      */   
/*      */   public ImmutableApplicationCommandInteractionData withComponents(Possible<List<ComponentData>> possible) {
/*  570 */     Possible<List<ComponentData>> newValue = Objects.<Possible<List<ComponentData>>>requireNonNull(possible);
/*  571 */     return new ImmutableApplicationCommandInteractionData(this, 
/*      */         
/*  573 */         id(), 
/*  574 */         name(), 
/*  575 */         type(), 
/*  576 */         resolved(), 
/*  577 */         options(), 
/*  578 */         customId(), 
/*  579 */         componentType(), 
/*  580 */         values(), 
/*  581 */         targetId(), newValue);
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableApplicationCommandInteractionData withComponents(Iterable<ComponentData> elements) {
/*  586 */     Possible<List<ComponentData>> newValue = Possible.of(
/*  587 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/*  588 */     return new ImmutableApplicationCommandInteractionData(this, 
/*      */         
/*  590 */         id(), 
/*  591 */         name(), 
/*  592 */         type(), 
/*  593 */         resolved(), 
/*  594 */         options(), 
/*  595 */         customId(), 
/*  596 */         componentType(), 
/*  597 */         values(), 
/*  598 */         targetId(), newValue);
/*      */   }
/*      */ 
/*      */   
/*      */   @SafeVarargs
/*      */   public final ImmutableApplicationCommandInteractionData withComponents(ComponentData... elements) {
/*  604 */     Possible<List<ComponentData>> newValue = Possible.of(Arrays.asList(elements));
/*  605 */     return new ImmutableApplicationCommandInteractionData(this, 
/*      */         
/*  607 */         id(), 
/*  608 */         name(), 
/*  609 */         type(), 
/*  610 */         resolved(), 
/*  611 */         options(), 
/*  612 */         customId(), 
/*  613 */         componentType(), 
/*  614 */         values(), 
/*  615 */         targetId(), newValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object another) {
/*  625 */     if (this == another) return true; 
/*  626 */     return (another instanceof ImmutableApplicationCommandInteractionData && 
/*  627 */       equalTo(0, (ImmutableApplicationCommandInteractionData)another));
/*      */   }
/*      */   
/*      */   private boolean equalTo(int synthetic, ImmutableApplicationCommandInteractionData another) {
/*  631 */     return (id().equals(another.id()) && 
/*  632 */       name().equals(another.name()) && 
/*  633 */       type().equals(another.type()) && 
/*  634 */       resolved().equals(another.resolved()) && 
/*  635 */       Objects.equals(this.options_value, another.options_value) && 
/*  636 */       customId().equals(another.customId()) && 
/*  637 */       componentType().equals(another.componentType()) && 
/*  638 */       Objects.equals(this.values_value, another.values_value) && 
/*  639 */       targetId().equals(another.targetId()) && 
/*  640 */       Objects.equals(this.components_value, another.components_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/*  649 */     int h = 5381;
/*  650 */     h += (h << 5) + id().hashCode();
/*  651 */     h += (h << 5) + name().hashCode();
/*  652 */     h += (h << 5) + type().hashCode();
/*  653 */     h += (h << 5) + resolved().hashCode();
/*  654 */     h += (h << 5) + Objects.hashCode(this.options_value);
/*  655 */     h += (h << 5) + customId().hashCode();
/*  656 */     h += (h << 5) + componentType().hashCode();
/*  657 */     h += (h << 5) + Objects.hashCode(this.values_value);
/*  658 */     h += (h << 5) + targetId().hashCode();
/*  659 */     h += (h << 5) + Objects.hashCode(this.components_value);
/*  660 */     return h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*  669 */     return "ApplicationCommandInteractionData{id=" + 
/*  670 */       id().toString() + ", name=" + 
/*  671 */       name().toString() + ", type=" + 
/*  672 */       type().toString() + ", resolved=" + 
/*  673 */       resolved().toString() + ", options=" + 
/*  674 */       Objects.toString(this.options_value) + ", customId=" + 
/*  675 */       customId().toString() + ", componentType=" + 
/*  676 */       componentType().toString() + ", values=" + 
/*  677 */       Objects.toString(this.values_value) + ", targetId=" + 
/*  678 */       targetId().toString() + ", components=" + 
/*  679 */       Objects.toString(this.components_value) + "}";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonDeserialize
/*      */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*      */   @Generated(from = "ApplicationCommandInteractionData", generator = "Immutables")
/*      */   static final class Json
/*      */     implements ApplicationCommandInteractionData
/*      */   {
/*  693 */     Possible<String> id = Possible.absent();
/*      */ 
/*      */     
/*  696 */     Possible<String> name = Possible.absent();
/*      */ 
/*      */     
/*  699 */     Possible<Integer> type = Possible.absent();
/*      */ 
/*      */     
/*  702 */     Possible<ApplicationCommandInteractionResolvedData> resolved = Possible.absent();
/*      */ 
/*      */     
/*  705 */     Possible<List<ApplicationCommandInteractionOptionData>> options = Possible.absent();
/*      */ 
/*      */     
/*  708 */     Possible<String> customId = Possible.absent();
/*      */ 
/*      */     
/*  711 */     Possible<Integer> componentType = Possible.absent();
/*      */ 
/*      */     
/*  714 */     Possible<List<String>> values = Possible.absent();
/*      */ 
/*      */     
/*  717 */     Possible<String> targetId = Possible.absent();
/*      */ 
/*      */     
/*  720 */     Possible<List<ComponentData>> components = Possible.absent();
/*      */     
/*      */     @JsonProperty("id")
/*      */     public void setId(Possible<String> id) {
/*  724 */       this.id = id;
/*      */     }
/*      */     @JsonProperty("name")
/*      */     public void setName(Possible<String> name) {
/*  728 */       this.name = name;
/*      */     }
/*      */     @JsonProperty("type")
/*      */     public void setType(Possible<Integer> type) {
/*  732 */       this.type = type;
/*      */     }
/*      */     @JsonProperty("resolved")
/*      */     public void setResolved(Possible<ApplicationCommandInteractionResolvedData> resolved) {
/*  736 */       this.resolved = resolved;
/*      */     }
/*      */     @JsonProperty("options")
/*      */     public void setOptions(Possible<List<ApplicationCommandInteractionOptionData>> options) {
/*  740 */       this.options = options;
/*      */     }
/*      */     @JsonProperty("custom_id")
/*      */     public void setCustomId(Possible<String> customId) {
/*  744 */       this.customId = customId;
/*      */     }
/*      */     @JsonProperty("component_type")
/*      */     public void setComponentType(Possible<Integer> componentType) {
/*  748 */       this.componentType = componentType;
/*      */     }
/*      */     @JsonProperty("values")
/*      */     public void setValues(Possible<List<String>> values) {
/*  752 */       this.values = values;
/*      */     }
/*      */     @JsonProperty("target_id")
/*      */     public void setTargetId(Possible<String> targetId) {
/*  756 */       this.targetId = targetId;
/*      */     }
/*      */     @JsonProperty("components")
/*      */     public void setComponents(Possible<List<ComponentData>> components) {
/*  760 */       this.components = components;
/*      */     }
/*      */     public Possible<String> id() {
/*  763 */       throw new UnsupportedOperationException();
/*      */     } public Possible<String> name() {
/*  765 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> type() {
/*  767 */       throw new UnsupportedOperationException();
/*      */     } public Possible<ApplicationCommandInteractionResolvedData> resolved() {
/*  769 */       throw new UnsupportedOperationException();
/*      */     } public Possible<List<ApplicationCommandInteractionOptionData>> options() {
/*  771 */       throw new UnsupportedOperationException();
/*      */     } public Possible<String> customId() {
/*  773 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> componentType() {
/*  775 */       throw new UnsupportedOperationException();
/*      */     } public Possible<List<String>> values() {
/*  777 */       throw new UnsupportedOperationException();
/*      */     } public Possible<String> targetId() {
/*  779 */       throw new UnsupportedOperationException();
/*      */     } public Possible<List<ComponentData>> components() {
/*  781 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*      */   static ImmutableApplicationCommandInteractionData fromJson(Json json) {
/*  792 */     Builder builder = builder();
/*  793 */     if (json.id != null) {
/*  794 */       builder.id(json.id);
/*      */     }
/*  796 */     if (json.name != null) {
/*  797 */       builder.name(json.name);
/*      */     }
/*  799 */     if (json.type != null) {
/*  800 */       builder.type(json.type);
/*      */     }
/*  802 */     if (json.resolved != null) {
/*  803 */       builder.resolved(json.resolved);
/*      */     }
/*  805 */     if (json.options != null) {
/*  806 */       builder.options(json.options);
/*      */     }
/*  808 */     if (json.customId != null) {
/*  809 */       builder.customId(json.customId);
/*      */     }
/*  811 */     if (json.componentType != null) {
/*  812 */       builder.componentType(json.componentType);
/*      */     }
/*  814 */     if (json.values != null) {
/*  815 */       builder.values(json.values);
/*      */     }
/*  817 */     if (json.targetId != null) {
/*  818 */       builder.targetId(json.targetId);
/*      */     }
/*  820 */     if (json.components != null) {
/*  821 */       builder.components(json.components);
/*      */     }
/*  823 */     return builder.build();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableApplicationCommandInteractionData of(Possible<String> id, Possible<String> name, Possible<Integer> type, Possible<ApplicationCommandInteractionResolvedData> resolved, Possible<List<ApplicationCommandInteractionOptionData>> options, Possible<String> customId, Possible<Integer> componentType, Possible<List<String>> values, Possible<String> targetId, Possible<List<ComponentData>> components) {
/*  841 */     return new ImmutableApplicationCommandInteractionData(id, name, type, resolved, options, customId, componentType, values, targetId, components);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableApplicationCommandInteractionData copyOf(ApplicationCommandInteractionData instance) {
/*  852 */     if (instance instanceof ImmutableApplicationCommandInteractionData) {
/*  853 */       return (ImmutableApplicationCommandInteractionData)instance;
/*      */     }
/*  855 */     return builder()
/*  856 */       .from(instance)
/*  857 */       .build();
/*      */   }
/*      */   
/*      */   public boolean isIdPresent() {
/*  861 */     return !this.id_absent;
/*      */   }
/*      */   
/*      */   public String idOrElse(String defaultValue) {
/*  865 */     return !this.id_absent ? this.id_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isNamePresent() {
/*  869 */     return !this.name_absent;
/*      */   }
/*      */   
/*      */   public String nameOrElse(String defaultValue) {
/*  873 */     return !this.name_absent ? this.name_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isTypePresent() {
/*  877 */     return !this.type_absent;
/*      */   }
/*      */   
/*      */   public Integer typeOrElse(Integer defaultValue) {
/*  881 */     return !this.type_absent ? this.type_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isResolvedPresent() {
/*  885 */     return !this.resolved_absent;
/*      */   }
/*      */   
/*      */   public ApplicationCommandInteractionResolvedData resolvedOrElse(ApplicationCommandInteractionResolvedData defaultValue) {
/*  889 */     return !this.resolved_absent ? this.resolved_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isOptionsPresent() {
/*  893 */     return !this.options_absent;
/*      */   }
/*      */   
/*      */   public List<ApplicationCommandInteractionOptionData> optionsOrElse(List<ApplicationCommandInteractionOptionData> defaultValue) {
/*  897 */     return !this.options_absent ? this.options_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isCustomIdPresent() {
/*  901 */     return !this.customId_absent;
/*      */   }
/*      */   
/*      */   public String customIdOrElse(String defaultValue) {
/*  905 */     return !this.customId_absent ? this.customId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isComponentTypePresent() {
/*  909 */     return !this.componentType_absent;
/*      */   }
/*      */   
/*      */   public Integer componentTypeOrElse(Integer defaultValue) {
/*  913 */     return !this.componentType_absent ? this.componentType_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isValuesPresent() {
/*  917 */     return !this.values_absent;
/*      */   }
/*      */   
/*      */   public List<String> valuesOrElse(List<String> defaultValue) {
/*  921 */     return !this.values_absent ? this.values_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isTargetIdPresent() {
/*  925 */     return !this.targetId_absent;
/*      */   }
/*      */   
/*      */   public String targetIdOrElse(String defaultValue) {
/*  929 */     return !this.targetId_absent ? this.targetId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isComponentsPresent() {
/*  933 */     return !this.components_absent;
/*      */   }
/*      */   
/*      */   public List<ComponentData> componentsOrElse(List<ComponentData> defaultValue) {
/*  937 */     return !this.components_absent ? this.components_value : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Builder builder() {
/*  959 */     return new Builder();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Generated(from = "ApplicationCommandInteractionData", generator = "Immutables")
/*      */   public static final class Builder
/*      */   {
/*  971 */     private Possible<String> id_possible = Possible.absent();
/*  972 */     private Possible<String> name_possible = Possible.absent();
/*  973 */     private Possible<Integer> type_possible = Possible.absent();
/*  974 */     private Possible<ApplicationCommandInteractionResolvedData> resolved_possible = Possible.absent();
/*  975 */     private List<ApplicationCommandInteractionOptionData> options_list = null;
/*  976 */     private Possible<String> customId_possible = Possible.absent();
/*  977 */     private Possible<Integer> componentType_possible = Possible.absent();
/*  978 */     private List<String> values_list = null;
/*  979 */     private Possible<String> targetId_possible = Possible.absent();
/*  980 */     private List<ComponentData> components_list = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(ApplicationCommandInteractionData instance) {
/*  993 */       Objects.requireNonNull(instance, "instance");
/*  994 */       id(instance.id());
/*  995 */       name(instance.name());
/*  996 */       type(instance.type());
/*  997 */       resolved(instance.resolved());
/*  998 */       options(instance.options());
/*  999 */       customId(instance.customId());
/* 1000 */       componentType(instance.componentType());
/* 1001 */       values(instance.values());
/* 1002 */       targetId(instance.targetId());
/* 1003 */       components(instance.components());
/* 1004 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("id")
/*      */     public Builder id(Possible<String> value) {
/* 1009 */       this.id_possible = value;
/* 1010 */       return this;
/*      */     }
/*      */     
/*      */     public Builder id(String value) {
/* 1014 */       this.id_possible = Possible.of(value);
/* 1015 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("name")
/*      */     public Builder name(Possible<String> value) {
/* 1020 */       this.name_possible = value;
/* 1021 */       return this;
/*      */     }
/*      */     
/*      */     public Builder name(String value) {
/* 1025 */       this.name_possible = Possible.of(value);
/* 1026 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("type")
/*      */     public Builder type(Possible<Integer> value) {
/* 1031 */       this.type_possible = value;
/* 1032 */       return this;
/*      */     }
/*      */     
/*      */     public Builder type(Integer value) {
/* 1036 */       this.type_possible = Possible.of(value);
/* 1037 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("resolved")
/*      */     public Builder resolved(Possible<ApplicationCommandInteractionResolvedData> value) {
/* 1042 */       this.resolved_possible = value;
/* 1043 */       return this;
/*      */     }
/*      */     
/*      */     public Builder resolved(ApplicationCommandInteractionResolvedData value) {
/* 1047 */       this.resolved_possible = Possible.of(value);
/* 1048 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addOption(ApplicationCommandInteractionOptionData element) {
/* 1052 */       options_getOrCreate().add(element);
/* 1053 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addAllOptions(List<ApplicationCommandInteractionOptionData> elements) {
/* 1057 */       options_getOrCreate().addAll(elements);
/* 1058 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("options")
/*      */     public Builder options(Possible<List<ApplicationCommandInteractionOptionData>> elements) {
/* 1063 */       this.options_list = null;
/* 1064 */       elements.toOptional().ifPresent(e -> options_getOrCreate().addAll(e));
/* 1065 */       return this;
/*      */     }
/*      */     
/*      */     public Builder options(List<ApplicationCommandInteractionOptionData> elements) {
/* 1069 */       this.options_list = new ArrayList<>(elements);
/* 1070 */       return this;
/*      */     }
/*      */     
/*      */     public Builder options(Iterable<ApplicationCommandInteractionOptionData> elements) {
/* 1074 */       this.options_list = (List<ApplicationCommandInteractionOptionData>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 1075 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("custom_id")
/*      */     public Builder customId(Possible<String> value) {
/* 1080 */       this.customId_possible = value;
/* 1081 */       return this;
/*      */     }
/*      */     
/*      */     public Builder customId(String value) {
/* 1085 */       this.customId_possible = Possible.of(value);
/* 1086 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("component_type")
/*      */     public Builder componentType(Possible<Integer> value) {
/* 1091 */       this.componentType_possible = value;
/* 1092 */       return this;
/*      */     }
/*      */     
/*      */     public Builder componentType(Integer value) {
/* 1096 */       this.componentType_possible = Possible.of(value);
/* 1097 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addValue(String element) {
/* 1101 */       values_getOrCreate().add(element);
/* 1102 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addAllValues(List<String> elements) {
/* 1106 */       values_getOrCreate().addAll(elements);
/* 1107 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("values")
/*      */     public Builder values(Possible<List<String>> elements) {
/* 1112 */       this.values_list = null;
/* 1113 */       elements.toOptional().ifPresent(e -> values_getOrCreate().addAll(e));
/* 1114 */       return this;
/*      */     }
/*      */     
/*      */     public Builder values(List<String> elements) {
/* 1118 */       this.values_list = new ArrayList<>(elements);
/* 1119 */       return this;
/*      */     }
/*      */     
/*      */     public Builder values(Iterable<String> elements) {
/* 1123 */       this.values_list = (List<String>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 1124 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("target_id")
/*      */     public Builder targetId(Possible<String> value) {
/* 1129 */       this.targetId_possible = value;
/* 1130 */       return this;
/*      */     }
/*      */     
/*      */     public Builder targetId(String value) {
/* 1134 */       this.targetId_possible = Possible.of(value);
/* 1135 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addComponent(ComponentData element) {
/* 1139 */       components_getOrCreate().add(element);
/* 1140 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addAllComponents(List<ComponentData> elements) {
/* 1144 */       components_getOrCreate().addAll(elements);
/* 1145 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("components")
/*      */     public Builder components(Possible<List<ComponentData>> elements) {
/* 1150 */       this.components_list = null;
/* 1151 */       elements.toOptional().ifPresent(e -> components_getOrCreate().addAll(e));
/* 1152 */       return this;
/*      */     }
/*      */     
/*      */     public Builder components(List<ComponentData> elements) {
/* 1156 */       this.components_list = new ArrayList<>(elements);
/* 1157 */       return this;
/*      */     }
/*      */     
/*      */     public Builder components(Iterable<ComponentData> elements) {
/* 1161 */       this.components_list = (List<ComponentData>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 1162 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ImmutableApplicationCommandInteractionData build() {
/* 1171 */       return new ImmutableApplicationCommandInteractionData(null, 
/*      */           
/* 1173 */           id_build(), 
/* 1174 */           name_build(), 
/* 1175 */           type_build(), 
/* 1176 */           resolved_build(), 
/* 1177 */           options_build(), 
/* 1178 */           customId_build(), 
/* 1179 */           componentType_build(), 
/* 1180 */           values_build(), 
/* 1181 */           targetId_build(), 
/* 1182 */           components_build());
/*      */     }
/*      */     
/*      */     private Possible<String> id_build() {
/* 1186 */       return this.id_possible;
/*      */     }
/*      */     
/*      */     private Possible<String> name_build() {
/* 1190 */       return this.name_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> type_build() {
/* 1194 */       return this.type_possible;
/*      */     }
/*      */     
/*      */     private Possible<ApplicationCommandInteractionResolvedData> resolved_build() {
/* 1198 */       return this.resolved_possible;
/*      */     }
/*      */     
/*      */     private Possible<List<ApplicationCommandInteractionOptionData>> options_build() {
/* 1202 */       return (this.options_list == null) ? Possible.absent() : 
/* 1203 */         Possible.of(this.options_list);
/*      */     }
/*      */     
/*      */     private List<ApplicationCommandInteractionOptionData> options_getOrCreate() {
/* 1207 */       if (this.options_list == null) {
/* 1208 */         this.options_list = new ArrayList<>();
/*      */       }
/* 1210 */       return this.options_list;
/*      */     }
/*      */     
/*      */     private Possible<String> customId_build() {
/* 1214 */       return this.customId_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> componentType_build() {
/* 1218 */       return this.componentType_possible;
/*      */     }
/*      */     
/*      */     private Possible<List<String>> values_build() {
/* 1222 */       return (this.values_list == null) ? Possible.absent() : 
/* 1223 */         Possible.of(this.values_list);
/*      */     }
/*      */     
/*      */     private List<String> values_getOrCreate() {
/* 1227 */       if (this.values_list == null) {
/* 1228 */         this.values_list = new ArrayList<>();
/*      */       }
/* 1230 */       return this.values_list;
/*      */     }
/*      */     
/*      */     private Possible<String> targetId_build() {
/* 1234 */       return this.targetId_possible;
/*      */     }
/*      */     
/*      */     private Possible<List<ComponentData>> components_build() {
/* 1238 */       return (this.components_list == null) ? Possible.absent() : 
/* 1239 */         Possible.of(this.components_list);
/*      */     }
/*      */     
/*      */     private List<ComponentData> components_getOrCreate() {
/* 1243 */       if (this.components_list == null) {
/* 1244 */         this.components_list = new ArrayList<>();
/*      */       }
/* 1246 */       return this.components_list;
/*      */     }
/*      */     
/*      */     private Builder() {}
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableApplicationCommandInteractionData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */