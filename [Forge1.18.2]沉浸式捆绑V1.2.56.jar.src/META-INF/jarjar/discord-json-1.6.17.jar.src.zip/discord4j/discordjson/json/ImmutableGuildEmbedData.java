/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.Id;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ @Generated(from = "GuildEmbedData", generator = "Immutables")
/*     */ public final class ImmutableGuildEmbedData
/*     */   implements GuildEmbedData
/*     */ {
/*     */   private final boolean enabled;
/*     */   private final long channelId_value;
/*     */   private final boolean channelId_present;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private ImmutableGuildEmbedData(boolean enabled, Optional<Id> channelId) {
/*  57 */     this.initShim = new InitShim(); this.enabled = enabled; Optional<Id> channelId$impl = channelId; this.channelId_value = ((Long)channelId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue(); this.channelId_present = channelId$impl.isPresent(); this.initShim = null; } private ImmutableGuildEmbedData(ImmutableGuildEmbedData original, boolean enabled, Optional<Id> channelId) { this.initShim = new InitShim();
/*     */     this.enabled = enabled;
/*     */     Optional<Id> channelId$impl = channelId;
/*     */     this.channelId_value = ((Long)channelId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*     */     this.channelId_present = channelId$impl.isPresent();
/*  62 */     this.initShim = null; } @Generated(from = "GuildEmbedData", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/*  63 */       return "Cannot build GuildEmbedData, attribute initializers form cycle " + attributes; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("enabled")
/*     */   public boolean enabled() {
/*  73 */     return this.enabled;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("channel_id")
/*     */   public Optional<Id> channelId() {
/*  82 */     return this.channelId_present ? Optional.<Id>of(Id.of(this.channelId_value)) : Optional.<Id>empty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableGuildEmbedData withEnabled(boolean value) {
/*  92 */     if (this.enabled == value) return this; 
/*  93 */     return new ImmutableGuildEmbedData(this, value, channelId());
/*     */   }
/*     */   
/*     */   public ImmutableGuildEmbedData withChannelId(Optional<Id> value) {
/*  97 */     Optional<Id> newValue = Objects.<Optional<Id>>requireNonNull(value);
/*  98 */     return new ImmutableGuildEmbedData(this, this.enabled, newValue);
/*     */   }
/*     */   
/*     */   public ImmutableGuildEmbedData withChannelId(long value) {
/* 102 */     Optional<Id> newValue = Optional.of(Id.of(value));
/* 103 */     return new ImmutableGuildEmbedData(this, this.enabled, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 112 */     if (this == another) return true; 
/* 113 */     return (another instanceof ImmutableGuildEmbedData && 
/* 114 */       equalTo(0, (ImmutableGuildEmbedData)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableGuildEmbedData another) {
/* 118 */     return (this.enabled == another.enabled && 
/* 119 */       channelId().equals(another.channelId()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 128 */     int h = 5381;
/* 129 */     h += (h << 5) + Boolean.hashCode(this.enabled);
/* 130 */     h += (h << 5) + channelId().hashCode();
/* 131 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 140 */     return "GuildEmbedData{enabled=" + this.enabled + ", channelId=" + 
/*     */       
/* 142 */       channelId().toString() + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "GuildEmbedData", generator = "Immutables")
/*     */   static final class Json
/*     */     implements GuildEmbedData
/*     */   {
/*     */     boolean enabled;
/*     */     
/*     */     boolean enabledIsSet;
/*     */     
/* 158 */     Optional<Id> channelId = Optional.empty();
/*     */     
/*     */     @JsonProperty("enabled")
/*     */     public void setEnabled(boolean enabled) {
/* 162 */       this.enabled = enabled;
/* 163 */       this.enabledIsSet = true;
/*     */     }
/*     */     @JsonProperty("channel_id")
/*     */     public void setChannelId(Optional<Id> channelId) {
/* 167 */       this.channelId = channelId;
/*     */     }
/*     */     public boolean enabled() {
/* 170 */       throw new UnsupportedOperationException();
/*     */     } public Optional<Id> channelId() {
/* 172 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableGuildEmbedData fromJson(Json json) {
/* 183 */     Builder builder = builder();
/* 184 */     if (json.enabledIsSet) {
/* 185 */       builder.enabled(json.enabled);
/*     */     }
/* 187 */     if (json.channelId != null) {
/* 188 */       builder.channelId(json.channelId);
/*     */     }
/* 190 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableGuildEmbedData of(boolean enabled, Optional<Id> channelId) {
/* 200 */     return new ImmutableGuildEmbedData(enabled, channelId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableGuildEmbedData copyOf(GuildEmbedData instance) {
/* 211 */     if (instance instanceof ImmutableGuildEmbedData) {
/* 212 */       return (ImmutableGuildEmbedData)instance;
/*     */     }
/* 214 */     return builder()
/* 215 */       .from(instance)
/* 216 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isChannelIdPresent() {
/* 220 */     return this.channelId_present;
/*     */   }
/*     */   
/*     */   public long channelIdOrElse(long defaultValue) {
/* 224 */     return this.channelId_present ? this.channelId_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 238 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "GuildEmbedData", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_ENABLED = 1L;
/*     */ 
/*     */ 
/*     */     
/* 251 */     private long initBits = 1L;
/*     */     
/* 253 */     private Optional<Id> channelId_optional = Optional.empty();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean enabled;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(GuildEmbedData instance) {
/* 267 */       Objects.requireNonNull(instance, "instance");
/* 268 */       enabled(instance.enabled());
/* 269 */       channelId(instance.channelId());
/* 270 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("enabled")
/*     */     public final Builder enabled(boolean enabled) {
/* 280 */       this.enabled = enabled;
/* 281 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 282 */       return this;
/*     */     }
/*     */     
/*     */     public Builder channelId(String value) {
/* 286 */       this.channelId_optional = Optional.of(Id.of(value));
/* 287 */       return this;
/*     */     }
/*     */     
/*     */     public Builder channelId(long value) {
/* 291 */       this.channelId_optional = Optional.of(Id.of(value));
/* 292 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("channel_id")
/*     */     public Builder channelId(Optional<Id> value) {
/* 297 */       this.channelId_optional = value;
/* 298 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableGuildEmbedData build() {
/* 307 */       if (this.initBits != 0L) {
/* 308 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 310 */       return new ImmutableGuildEmbedData(null, this.enabled, channelId_build());
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 314 */       List<String> attributes = new ArrayList<>();
/* 315 */       if ((this.initBits & 0x1L) != 0L) attributes.add("enabled"); 
/* 316 */       return "Cannot build GuildEmbedData, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Optional<Id> channelId_build() {
/* 320 */       return this.channelId_optional;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableGuildEmbedData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */