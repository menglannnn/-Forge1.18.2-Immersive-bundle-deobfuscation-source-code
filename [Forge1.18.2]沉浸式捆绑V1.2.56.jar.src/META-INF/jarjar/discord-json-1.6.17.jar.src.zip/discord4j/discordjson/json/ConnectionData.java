/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import java.util.List;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ @JsonSerialize(as = ImmutableConnectionData.class)
/*    */ @JsonDeserialize(as = ImmutableConnectionData.class)
/*    */ @Immutable
/*    */ public interface ConnectionData
/*    */ {
/*    */   static ImmutableConnectionData.Builder builder() {
/* 17 */     return ImmutableConnectionData.builder();
/*    */   }
/*    */   
/*    */   String id();
/*    */   
/*    */   String name();
/*    */   
/*    */   String type();
/*    */   
/*    */   Possible<Boolean> revoked();
/*    */   
/*    */   Possible<List<IntegrationData>> integrations();
/*    */   
/*    */   boolean verified();
/*    */   
/*    */   @JsonProperty("friend_sync")
/*    */   boolean friendSync();
/*    */   
/*    */   @JsonProperty("show_activity")
/*    */   boolean showActivity();
/*    */   
/*    */   int visibility();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ConnectionData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */