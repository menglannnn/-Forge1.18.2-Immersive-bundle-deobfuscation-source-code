/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "ApplicationCommandOptionChoiceData", generator = "Immutables")
/*     */ public final class ImmutableApplicationCommandOptionChoiceData
/*     */   implements ApplicationCommandOptionChoiceData
/*     */ {
/*     */   private final String name;
/*     */   private final Map<String, String> nameLocalizations_value;
/*     */   private final boolean nameLocalizations_absent;
/*     */   private final Object value;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private ImmutableApplicationCommandOptionChoiceData(String name, Possible<Optional<Map<String, String>>> nameLocalizations, Object value) {
/*  62 */     this.initShim = new InitShim(); this.name = Objects.<String>requireNonNull(name, "name"); Possible<Optional<Map<String, String>>> nameLocalizations$impl = nameLocalizations; this.value = Objects.requireNonNull(value, "value"); this.nameLocalizations_value = Possible.flatOpt(nameLocalizations$impl).orElse(null); this.nameLocalizations_absent = nameLocalizations$impl.isAbsent(); this.initShim = null; } private ImmutableApplicationCommandOptionChoiceData(ImmutableApplicationCommandOptionChoiceData original, String name, Possible<Optional<Map<String, String>>> nameLocalizations, Object value) { this.initShim = new InitShim(); this.name = name;
/*     */     Possible<Optional<Map<String, String>>> nameLocalizations$impl = nameLocalizations;
/*     */     this.value = value;
/*     */     this.nameLocalizations_value = Possible.flatOpt(nameLocalizations$impl).orElse(null);
/*     */     this.nameLocalizations_absent = nameLocalizations$impl.isAbsent();
/*  67 */     this.initShim = null; } @Generated(from = "ApplicationCommandOptionChoiceData", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/*  68 */       return "Cannot build ApplicationCommandOptionChoiceData, attribute initializers form cycle " + attributes; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("name")
/*     */   public String name() {
/*  78 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("name_localizations")
/*     */   public Possible<Optional<Map<String, String>>> nameLocalizations() {
/*  87 */     return this.nameLocalizations_absent ? Possible.absent() : 
/*  88 */       Possible.of(Optional.ofNullable(this.nameLocalizations_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("value")
/*     */   public Object value() {
/* 100 */     return this.value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableApplicationCommandOptionChoiceData withName(String value) {
/* 110 */     String newValue = Objects.<String>requireNonNull(value, "name");
/* 111 */     if (this.name.equals(newValue)) return this; 
/* 112 */     return new ImmutableApplicationCommandOptionChoiceData(this, newValue, nameLocalizations(), this.value);
/*     */   }
/*     */   
/*     */   public ImmutableApplicationCommandOptionChoiceData withNameLocalizations(Possible<Optional<Map<String, String>>> value) {
/* 116 */     Possible<Optional<Map<String, String>>> newValue = Objects.<Possible<Optional<Map<String, String>>>>requireNonNull(value);
/* 117 */     return new ImmutableApplicationCommandOptionChoiceData(this, this.name, newValue, this.value);
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public ImmutableApplicationCommandOptionChoiceData withNameLocalizations(@Nullable Map<String, String> value) {
/* 122 */     Possible<Optional<Map<String, String>>> newValue = Possible.of(Optional.ofNullable(value));
/* 123 */     return new ImmutableApplicationCommandOptionChoiceData(this, this.name, newValue, this.value);
/*     */   }
/*     */   
/*     */   public ImmutableApplicationCommandOptionChoiceData withNameLocalizationsOrNull(@Nullable Map<String, String> value) {
/* 127 */     Possible<Optional<Map<String, String>>> newValue = Possible.of(Optional.ofNullable(value));
/* 128 */     return new ImmutableApplicationCommandOptionChoiceData(this, this.name, newValue, this.value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableApplicationCommandOptionChoiceData withValue(Object value) {
/* 138 */     if (this.value == value) return this; 
/* 139 */     Object newValue = Objects.requireNonNull(value, "value");
/* 140 */     return new ImmutableApplicationCommandOptionChoiceData(this, this.name, nameLocalizations(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 149 */     if (this == another) return true; 
/* 150 */     return (another instanceof ImmutableApplicationCommandOptionChoiceData && 
/* 151 */       equalTo(0, (ImmutableApplicationCommandOptionChoiceData)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableApplicationCommandOptionChoiceData another) {
/* 155 */     return (this.name.equals(another.name) && 
/* 156 */       nameLocalizations().equals(another.nameLocalizations()) && this.value
/* 157 */       .equals(another.value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 166 */     int h = 5381;
/* 167 */     h += (h << 5) + this.name.hashCode();
/* 168 */     h += (h << 5) + nameLocalizations().hashCode();
/* 169 */     h += (h << 5) + this.value.hashCode();
/* 170 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 179 */     return "ApplicationCommandOptionChoiceData{name=" + this.name + ", nameLocalizations=" + 
/*     */       
/* 181 */       nameLocalizations().toString() + ", value=" + this.value + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "ApplicationCommandOptionChoiceData", generator = "Immutables")
/*     */   static final class Json
/*     */     implements ApplicationCommandOptionChoiceData
/*     */   {
/*     */     String name;
/*     */ 
/*     */     
/* 197 */     Possible<Optional<Map<String, String>>> nameLocalizations = Possible.absent();
/*     */     Object value;
/*     */     
/*     */     @JsonProperty("name")
/*     */     public void setName(String name) {
/* 202 */       this.name = name;
/*     */     }
/*     */     @JsonProperty("name_localizations")
/*     */     public void setNameLocalizations(Possible<Optional<Map<String, String>>> nameLocalizations) {
/* 206 */       this.nameLocalizations = nameLocalizations;
/*     */     }
/*     */     @JsonProperty("value")
/*     */     public void setValue(Object value) {
/* 210 */       this.value = value;
/*     */     }
/*     */     public String name() {
/* 213 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Optional<Map<String, String>>> nameLocalizations() {
/* 215 */       throw new UnsupportedOperationException();
/*     */     } public Object value() {
/* 217 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableApplicationCommandOptionChoiceData fromJson(Json json) {
/* 228 */     Builder builder = builder();
/* 229 */     if (json.name != null) {
/* 230 */       builder.name(json.name);
/*     */     }
/* 232 */     if (json.nameLocalizations != null) {
/* 233 */       builder.nameLocalizations(json.nameLocalizations);
/*     */     }
/* 235 */     if (json.value != null) {
/* 236 */       builder.value(json.value);
/*     */     }
/* 238 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableApplicationCommandOptionChoiceData of(String name, Possible<Optional<Map<String, String>>> nameLocalizations, Object value) {
/* 249 */     return new ImmutableApplicationCommandOptionChoiceData(name, nameLocalizations, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableApplicationCommandOptionChoiceData copyOf(ApplicationCommandOptionChoiceData instance) {
/* 260 */     if (instance instanceof ImmutableApplicationCommandOptionChoiceData) {
/* 261 */       return (ImmutableApplicationCommandOptionChoiceData)instance;
/*     */     }
/* 263 */     return builder()
/* 264 */       .from(instance)
/* 265 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isNameLocalizationsPresent() {
/* 269 */     return !this.nameLocalizations_absent;
/*     */   }
/*     */   
/*     */   public Map<String, String> nameLocalizationsOrElse(Map<String, String> defaultValue) {
/* 273 */     return !this.nameLocalizations_absent ? this.nameLocalizations_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 288 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "ApplicationCommandOptionChoiceData", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_NAME = 1L;
/*     */ 
/*     */     
/*     */     private static final long INIT_BIT_VALUE = 2L;
/*     */ 
/*     */     
/* 302 */     private long initBits = 3L;
/*     */     
/* 304 */     private Possible<Optional<Map<String, String>>> nameLocalizations_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String name;
/*     */ 
/*     */ 
/*     */     
/*     */     private Object value;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(ApplicationCommandOptionChoiceData instance) {
/* 319 */       Objects.requireNonNull(instance, "instance");
/* 320 */       name(instance.name());
/* 321 */       nameLocalizations(instance.nameLocalizations());
/* 322 */       value(instance.value());
/* 323 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("name")
/*     */     public final Builder name(String name) {
/* 333 */       this.name = Objects.<String>requireNonNull(name, "name");
/* 334 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 335 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("name_localizations")
/*     */     public Builder nameLocalizations(Possible<Optional<Map<String, String>>> value) {
/* 340 */       this.nameLocalizations_possible = value;
/* 341 */       return this;
/*     */     }
/*     */     
/*     */     @Deprecated
/*     */     public Builder nameLocalizations(@Nullable Map<String, String> value) {
/* 346 */       this.nameLocalizations_possible = Possible.of(Optional.ofNullable(value));
/* 347 */       return this;
/*     */     }
/*     */     
/*     */     public Builder nameLocalizationsOrNull(@Nullable Map<String, String> value) {
/* 351 */       this.nameLocalizations_possible = Possible.of(Optional.ofNullable(value));
/* 352 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("value")
/*     */     public final Builder value(Object value) {
/* 362 */       this.value = Objects.requireNonNull(value, "value");
/* 363 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 364 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableApplicationCommandOptionChoiceData build() {
/* 373 */       if (this.initBits != 0L) {
/* 374 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 376 */       return new ImmutableApplicationCommandOptionChoiceData(null, this.name, nameLocalizations_build(), this.value);
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 380 */       List<String> attributes = new ArrayList<>();
/* 381 */       if ((this.initBits & 0x1L) != 0L) attributes.add("name"); 
/* 382 */       if ((this.initBits & 0x2L) != 0L) attributes.add("value"); 
/* 383 */       return "Cannot build ApplicationCommandOptionChoiceData, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Possible<Optional<Map<String, String>>> nameLocalizations_build() {
/* 387 */       return this.nameLocalizations_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableApplicationCommandOptionChoiceData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */