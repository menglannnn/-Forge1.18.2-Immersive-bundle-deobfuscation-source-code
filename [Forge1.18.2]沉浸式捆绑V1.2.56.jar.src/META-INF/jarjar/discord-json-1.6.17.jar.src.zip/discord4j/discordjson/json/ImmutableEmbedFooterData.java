/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "EmbedFooterData", generator = "Immutables")
/*     */ public final class ImmutableEmbedFooterData
/*     */   implements EmbedFooterData
/*     */ {
/*     */   private final String text;
/*     */   private final String iconUrl_value;
/*     */   private final boolean iconUrl_absent;
/*     */   private final String proxyIconUrl_value;
/*     */   private final boolean proxyIconUrl_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private ImmutableEmbedFooterData(String text, Possible<String> iconUrl, Possible<String> proxyIconUrl) {
/*  63 */     this.initShim = new InitShim(); this.text = Objects.<String>requireNonNull(text, "text"); Possible<String> iconUrl$impl = iconUrl; Possible<String> proxyIconUrl$impl = proxyIconUrl; this.iconUrl_value = iconUrl$impl.toOptional().orElse(null); this.iconUrl_absent = iconUrl$impl.isAbsent(); this.proxyIconUrl_value = proxyIconUrl$impl.toOptional().orElse(null); this.proxyIconUrl_absent = proxyIconUrl$impl.isAbsent(); this.initShim = null; } private ImmutableEmbedFooterData(ImmutableEmbedFooterData original, String text, Possible<String> iconUrl, Possible<String> proxyIconUrl) { this.initShim = new InitShim(); this.text = text; Possible<String> iconUrl$impl = iconUrl; Possible<String> proxyIconUrl$impl = proxyIconUrl;
/*     */     this.iconUrl_value = iconUrl$impl.toOptional().orElse(null);
/*     */     this.iconUrl_absent = iconUrl$impl.isAbsent();
/*     */     this.proxyIconUrl_value = proxyIconUrl$impl.toOptional().orElse(null);
/*     */     this.proxyIconUrl_absent = proxyIconUrl$impl.isAbsent();
/*  68 */     this.initShim = null; } @Generated(from = "EmbedFooterData", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/*  69 */       return "Cannot build EmbedFooterData, attribute initializers form cycle " + attributes; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("text")
/*     */   public String text() {
/*  79 */     return this.text;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("icon_url")
/*     */   public Possible<String> iconUrl() {
/*  88 */     return this.iconUrl_absent ? Possible.absent() : Possible.of(this.iconUrl_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("proxy_icon_url")
/*     */   public Possible<String> proxyIconUrl() {
/*  97 */     return this.proxyIconUrl_absent ? Possible.absent() : Possible.of(this.proxyIconUrl_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableEmbedFooterData withText(String value) {
/* 107 */     String newValue = Objects.<String>requireNonNull(value, "text");
/* 108 */     if (this.text.equals(newValue)) return this; 
/* 109 */     return new ImmutableEmbedFooterData(this, newValue, iconUrl(), proxyIconUrl());
/*     */   }
/*     */   
/*     */   public ImmutableEmbedFooterData withIconUrl(Possible<String> value) {
/* 113 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 114 */     return new ImmutableEmbedFooterData(this, this.text, newValue, proxyIconUrl());
/*     */   }
/*     */   
/*     */   public ImmutableEmbedFooterData withIconUrl(String value) {
/* 118 */     Possible<String> newValue = Possible.of(value);
/* 119 */     return new ImmutableEmbedFooterData(this, this.text, newValue, proxyIconUrl());
/*     */   }
/*     */   
/*     */   public ImmutableEmbedFooterData withProxyIconUrl(Possible<String> value) {
/* 123 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 124 */     return new ImmutableEmbedFooterData(this, this.text, iconUrl(), newValue);
/*     */   }
/*     */   
/*     */   public ImmutableEmbedFooterData withProxyIconUrl(String value) {
/* 128 */     Possible<String> newValue = Possible.of(value);
/* 129 */     return new ImmutableEmbedFooterData(this, this.text, iconUrl(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 138 */     if (this == another) return true; 
/* 139 */     return (another instanceof ImmutableEmbedFooterData && 
/* 140 */       equalTo(0, (ImmutableEmbedFooterData)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableEmbedFooterData another) {
/* 144 */     return (this.text.equals(another.text) && 
/* 145 */       iconUrl().equals(another.iconUrl()) && 
/* 146 */       proxyIconUrl().equals(another.proxyIconUrl()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 155 */     int h = 5381;
/* 156 */     h += (h << 5) + this.text.hashCode();
/* 157 */     h += (h << 5) + iconUrl().hashCode();
/* 158 */     h += (h << 5) + proxyIconUrl().hashCode();
/* 159 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 168 */     return "EmbedFooterData{text=" + this.text + ", iconUrl=" + 
/*     */       
/* 170 */       iconUrl().toString() + ", proxyIconUrl=" + 
/* 171 */       proxyIconUrl().toString() + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "EmbedFooterData", generator = "Immutables")
/*     */   static final class Json
/*     */     implements EmbedFooterData
/*     */   {
/*     */     String text;
/*     */ 
/*     */     
/* 186 */     Possible<String> iconUrl = Possible.absent();
/*     */ 
/*     */     
/* 189 */     Possible<String> proxyIconUrl = Possible.absent();
/*     */     
/*     */     @JsonProperty("text")
/*     */     public void setText(String text) {
/* 193 */       this.text = text;
/*     */     }
/*     */     @JsonProperty("icon_url")
/*     */     public void setIconUrl(Possible<String> iconUrl) {
/* 197 */       this.iconUrl = iconUrl;
/*     */     }
/*     */     @JsonProperty("proxy_icon_url")
/*     */     public void setProxyIconUrl(Possible<String> proxyIconUrl) {
/* 201 */       this.proxyIconUrl = proxyIconUrl;
/*     */     }
/*     */     public String text() {
/* 204 */       throw new UnsupportedOperationException();
/*     */     } public Possible<String> iconUrl() {
/* 206 */       throw new UnsupportedOperationException();
/*     */     } public Possible<String> proxyIconUrl() {
/* 208 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableEmbedFooterData fromJson(Json json) {
/* 219 */     Builder builder = builder();
/* 220 */     if (json.text != null) {
/* 221 */       builder.text(json.text);
/*     */     }
/* 223 */     if (json.iconUrl != null) {
/* 224 */       builder.iconUrl(json.iconUrl);
/*     */     }
/* 226 */     if (json.proxyIconUrl != null) {
/* 227 */       builder.proxyIconUrl(json.proxyIconUrl);
/*     */     }
/* 229 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableEmbedFooterData of(String text, Possible<String> iconUrl, Possible<String> proxyIconUrl) {
/* 240 */     return new ImmutableEmbedFooterData(text, iconUrl, proxyIconUrl);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableEmbedFooterData copyOf(EmbedFooterData instance) {
/* 251 */     if (instance instanceof ImmutableEmbedFooterData) {
/* 252 */       return (ImmutableEmbedFooterData)instance;
/*     */     }
/* 254 */     return builder()
/* 255 */       .from(instance)
/* 256 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isIconUrlPresent() {
/* 260 */     return !this.iconUrl_absent;
/*     */   }
/*     */   
/*     */   public String iconUrlOrElse(String defaultValue) {
/* 264 */     return !this.iconUrl_absent ? this.iconUrl_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isProxyIconUrlPresent() {
/* 268 */     return !this.proxyIconUrl_absent;
/*     */   }
/*     */   
/*     */   public String proxyIconUrlOrElse(String defaultValue) {
/* 272 */     return !this.proxyIconUrl_absent ? this.proxyIconUrl_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 287 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "EmbedFooterData", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_TEXT = 1L;
/*     */ 
/*     */ 
/*     */     
/* 300 */     private long initBits = 1L;
/*     */     
/* 302 */     private Possible<String> iconUrl_possible = Possible.absent();
/* 303 */     private Possible<String> proxyIconUrl_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(EmbedFooterData instance) {
/* 317 */       Objects.requireNonNull(instance, "instance");
/* 318 */       text(instance.text());
/* 319 */       iconUrl(instance.iconUrl());
/* 320 */       proxyIconUrl(instance.proxyIconUrl());
/* 321 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("text")
/*     */     public final Builder text(String text) {
/* 331 */       this.text = Objects.<String>requireNonNull(text, "text");
/* 332 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 333 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("icon_url")
/*     */     public Builder iconUrl(Possible<String> value) {
/* 338 */       this.iconUrl_possible = value;
/* 339 */       return this;
/*     */     }
/*     */     
/*     */     public Builder iconUrl(String value) {
/* 343 */       this.iconUrl_possible = Possible.of(value);
/* 344 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("proxy_icon_url")
/*     */     public Builder proxyIconUrl(Possible<String> value) {
/* 349 */       this.proxyIconUrl_possible = value;
/* 350 */       return this;
/*     */     }
/*     */     
/*     */     public Builder proxyIconUrl(String value) {
/* 354 */       this.proxyIconUrl_possible = Possible.of(value);
/* 355 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableEmbedFooterData build() {
/* 364 */       if (this.initBits != 0L) {
/* 365 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 367 */       return new ImmutableEmbedFooterData(null, this.text, iconUrl_build(), proxyIconUrl_build());
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 371 */       List<String> attributes = new ArrayList<>();
/* 372 */       if ((this.initBits & 0x1L) != 0L) attributes.add("text"); 
/* 373 */       return "Cannot build EmbedFooterData, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Possible<String> iconUrl_build() {
/* 377 */       return this.iconUrl_possible;
/*     */     }
/*     */     
/*     */     private Possible<String> proxyIconUrl_build() {
/* 381 */       return this.proxyIconUrl_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableEmbedFooterData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */