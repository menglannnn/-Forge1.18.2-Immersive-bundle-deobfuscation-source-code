/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ @Immutable
/*    */ public abstract class TokenRefreshRequest
/*    */ {
/*    */   public static ImmutableTokenRefreshRequest.Builder builder() {
/*  9 */     return ImmutableTokenRefreshRequest.builder();
/*    */   }
/*    */ 
/*    */   
/*    */   public abstract long clientId();
/*    */   
/*    */   public abstract String clientSecret();
/*    */   
/*    */   public abstract String refreshToken();
/*    */   
/*    */   public String toString() {
/* 20 */     return "client_id=" + clientId() + "&client_secret=" + 
/* 21 */       clientSecret() + "&grant_type=refresh_token&refresh_token=" + 
/*    */       
/* 23 */       refreshToken();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\TokenRefreshRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */