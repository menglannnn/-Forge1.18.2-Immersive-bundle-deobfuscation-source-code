/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import java.util.List;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ @JsonSerialize(as = ImmutableAutoModTriggerMetaData.class)
/*    */ @JsonDeserialize(as = ImmutableAutoModTriggerMetaData.class)
/*    */ @Immutable
/*    */ public interface AutoModTriggerMetaData
/*    */ {
/*    */   static ImmutableAutoModTriggerMetaData.Builder builder() {
/* 16 */     return ImmutableAutoModTriggerMetaData.builder();
/*    */   }
/*    */   
/*    */   @JsonProperty("keyword_filter")
/*    */   Possible<List<String>> keywordFilter();
/*    */   
/*    */   @JsonProperty("regex_patterns")
/*    */   Possible<List<String>> regexPatterns();
/*    */   
/*    */   Possible<List<Integer>> presets();
/*    */   
/*    */   @JsonProperty("allow_list")
/*    */   Possible<List<String>> allowList();
/*    */   
/*    */   @JsonProperty("mention_total_limit")
/*    */   Possible<Integer> mentionTotalLimit();
/*    */   
/*    */   @JsonProperty("mention_raid_protection_enabled")
/*    */   Possible<Boolean> mentionRaidProtectionEnabled();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\AutoModTriggerMetaData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */