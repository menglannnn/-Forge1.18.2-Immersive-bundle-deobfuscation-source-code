/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import java.util.List;
/*    */ import java.util.Optional;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ @JsonSerialize(as = ImmutableResolvedMemberData.class)
/*    */ @JsonDeserialize(as = ImmutableResolvedMemberData.class)
/*    */ @Immutable
/*    */ public interface ResolvedMemberData
/*    */ {
/*    */   static ImmutableResolvedMemberData.Builder builder() {
/* 18 */     return ImmutableResolvedMemberData.builder();
/*    */   }
/*    */ 
/*    */   
/*    */   Possible<Optional<String>> nick();
/*    */   
/*    */   List<String> roles();
/*    */   
/*    */   @JsonProperty("joined_at")
/*    */   String joinedAt();
/*    */   
/*    */   @JsonProperty("premium_since")
/*    */   Possible<Optional<String>> premiumSince();
/*    */   
/*    */   Possible<Boolean> pending();
/*    */   
/*    */   Possible<String> permissions();
/*    */   
/*    */   @JsonProperty("communication_disabled_until")
/*    */   Possible<Optional<String>> communicationDisabledUntil();
/*    */   
/*    */   default long flags() {
/* 40 */     return 0L;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ResolvedMemberData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */