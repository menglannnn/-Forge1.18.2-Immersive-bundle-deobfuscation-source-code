/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "GuildScheduledEventEntityMetadataData", generator = "Immutables")
/*     */ public final class ImmutableGuildScheduledEventEntityMetadataData
/*     */   implements GuildScheduledEventEntityMetadataData
/*     */ {
/*     */   private final String location_value;
/*     */   private final boolean location_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private ImmutableGuildScheduledEventEntityMetadataData(Possible<String> location) {
/*  30 */     Possible<String> location$impl = location;
/*  31 */     this.location_value = location$impl.toOptional().orElse(null);
/*  32 */     this.location_absent = location$impl.isAbsent();
/*  33 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableGuildScheduledEventEntityMetadataData(ImmutableGuildScheduledEventEntityMetadataData original, Possible<String> location) {
/*  39 */     Possible<String> location$impl = location;
/*  40 */     this.location_value = location$impl.toOptional().orElse(null);
/*  41 */     this.location_absent = location$impl.isAbsent();
/*  42 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  48 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "GuildScheduledEventEntityMetadataData", generator = "Immutables")
/*     */   private final class InitShim {
/*     */     private String formatInitCycleMessage() {
/*  53 */       List<String> attributes = new ArrayList<>();
/*  54 */       return "Cannot build GuildScheduledEventEntityMetadataData, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @JsonProperty("location")
/*     */   public Possible<String> location() {
/*  64 */     return this.location_absent ? Possible.absent() : Possible.of(this.location_value);
/*     */   }
/*     */   
/*     */   public ImmutableGuildScheduledEventEntityMetadataData withLocation(Possible<String> value) {
/*  68 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  69 */     return new ImmutableGuildScheduledEventEntityMetadataData(this, newValue);
/*     */   }
/*     */   
/*     */   public ImmutableGuildScheduledEventEntityMetadataData withLocation(String value) {
/*  73 */     Possible<String> newValue = Possible.of(value);
/*  74 */     return new ImmutableGuildScheduledEventEntityMetadataData(this, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/*  83 */     if (this == another) return true; 
/*  84 */     return (another instanceof ImmutableGuildScheduledEventEntityMetadataData && 
/*  85 */       equalTo(0, (ImmutableGuildScheduledEventEntityMetadataData)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableGuildScheduledEventEntityMetadataData another) {
/*  89 */     return location().equals(another.location());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  98 */     int h = 5381;
/*  99 */     h += (h << 5) + location().hashCode();
/* 100 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 109 */     return "GuildScheduledEventEntityMetadataData{location=" + 
/* 110 */       location().toString() + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "GuildScheduledEventEntityMetadataData", generator = "Immutables")
/*     */   static final class Json
/*     */     implements GuildScheduledEventEntityMetadataData
/*     */   {
/* 124 */     Possible<String> location = Possible.absent();
/*     */     
/*     */     @JsonProperty("location")
/*     */     public void setLocation(Possible<String> location) {
/* 128 */       this.location = location;
/*     */     }
/*     */     public Possible<String> location() {
/* 131 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableGuildScheduledEventEntityMetadataData fromJson(Json json) {
/* 142 */     Builder builder = builder();
/* 143 */     if (json.location != null) {
/* 144 */       builder.location(json.location);
/*     */     }
/* 146 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableGuildScheduledEventEntityMetadataData of(Possible<String> location) {
/* 155 */     return new ImmutableGuildScheduledEventEntityMetadataData(location);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableGuildScheduledEventEntityMetadataData copyOf(GuildScheduledEventEntityMetadataData instance) {
/* 166 */     if (instance instanceof ImmutableGuildScheduledEventEntityMetadataData) {
/* 167 */       return (ImmutableGuildScheduledEventEntityMetadataData)instance;
/*     */     }
/* 169 */     return builder()
/* 170 */       .from(instance)
/* 171 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isLocationPresent() {
/* 175 */     return !this.location_absent;
/*     */   }
/*     */   
/*     */   public String locationOrElse(String defaultValue) {
/* 179 */     return !this.location_absent ? this.location_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 192 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "GuildScheduledEventEntityMetadataData", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/* 204 */     private Possible<String> location_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(GuildScheduledEventEntityMetadataData instance) {
/* 217 */       Objects.requireNonNull(instance, "instance");
/* 218 */       location(instance.location());
/* 219 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("location")
/*     */     public Builder location(Possible<String> value) {
/* 224 */       this.location_possible = value;
/* 225 */       return this;
/*     */     }
/*     */     
/*     */     public Builder location(String value) {
/* 229 */       this.location_possible = Possible.of(value);
/* 230 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableGuildScheduledEventEntityMetadataData build() {
/* 239 */       return new ImmutableGuildScheduledEventEntityMetadataData(null, location_build());
/*     */     }
/*     */     
/*     */     private Possible<String> location_build() {
/* 243 */       return this.location_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableGuildScheduledEventEntityMetadataData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */