/*      */ package discord4j.discordjson.json;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*      */ import com.fasterxml.jackson.annotation.JsonCreator;
/*      */ import com.fasterxml.jackson.annotation.JsonProperty;
/*      */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*      */ import discord4j.discordjson.possible.Possible;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import java.util.Optional;
/*      */ import org.immutables.value.Generated;
/*      */ import reactor.util.annotation.Nullable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Generated(from = "InviteData", generator = "Immutables")
/*      */ public final class ImmutableInviteData
/*      */   implements InviteData
/*      */ {
/*      */   private final String code;
/*      */   private final PartialGuildData guild_value;
/*      */   private final boolean guild_absent;
/*      */   private final ChannelData channel;
/*      */   private final UserData inviter_value;
/*      */   private final boolean inviter_absent;
/*      */   private final Integer targetType_value;
/*      */   private final boolean targetType_absent;
/*      */   private final UserData targetUser_value;
/*      */   private final boolean targetUser_absent;
/*      */   private final Integer approximatePresenceCount_value;
/*      */   private final boolean approximatePresenceCount_absent;
/*      */   private final Integer approximateMemberCount_value;
/*      */   private final boolean approximateMemberCount_absent;
/*      */   private final String expiresAt_value;
/*      */   private final boolean expiresAt_absent;
/*      */   private final GuildScheduledEventData guildScheduledEvent_value;
/*      */   private final boolean guildScheduledEvent_absent;
/*      */   private final Integer uses_value;
/*      */   private final boolean uses_absent;
/*      */   private final Integer maxUses_value;
/*      */   private final boolean maxUses_absent;
/*      */   private final Integer maxAge_value;
/*      */   private final boolean maxAge_absent;
/*      */   private final Boolean temporary_value;
/*      */   private final boolean temporary_absent;
/*      */   private final String createdAt_value;
/*      */   private final boolean createdAt_absent;
/*      */   private static final byte STAGE_INITIALIZING = -1;
/*      */   private static final byte STAGE_UNINITIALIZED = 0;
/*      */   private static final byte STAGE_INITIALIZED = 1;
/*      */   private volatile transient InitShim initShim;
/*      */   
/*      */   private ImmutableInviteData(String code, Possible<PartialGuildData> guild, ChannelData channel, Possible<UserData> inviter, Possible<Integer> targetType, Possible<UserData> targetUser, Possible<Integer> approximatePresenceCount, Possible<Integer> approximateMemberCount, Possible<Optional<String>> expiresAt, Possible<GuildScheduledEventData> guildScheduledEvent, Possible<Integer> uses, Possible<Integer> maxUses, Possible<Integer> maxAge, Possible<Boolean> temporary, Possible<String> createdAt) {
/*  180 */     this.initShim = new InitShim(); this.code = Objects.<String>requireNonNull(code, "code"); Possible<PartialGuildData> guild$impl = guild; this.channel = Objects.<ChannelData>requireNonNull(channel, "channel"); Possible<UserData> inviter$impl = inviter; Possible<Integer> targetType$impl = targetType; Possible<UserData> targetUser$impl = targetUser; Possible<Integer> approximatePresenceCount$impl = approximatePresenceCount; Possible<Integer> approximateMemberCount$impl = approximateMemberCount; Possible<Optional<String>> expiresAt$impl = expiresAt; Possible<GuildScheduledEventData> guildScheduledEvent$impl = guildScheduledEvent; Possible<Integer> uses$impl = uses; Possible<Integer> maxUses$impl = maxUses; Possible<Integer> maxAge$impl = maxAge; Possible<Boolean> temporary$impl = temporary; Possible<String> createdAt$impl = createdAt; this.guild_value = guild$impl.toOptional().orElse(null); this.guild_absent = guild$impl.isAbsent(); this.inviter_value = inviter$impl.toOptional().orElse(null); this.inviter_absent = inviter$impl.isAbsent(); this.targetType_value = targetType$impl.toOptional().orElse(null); this.targetType_absent = targetType$impl.isAbsent(); this.targetUser_value = targetUser$impl.toOptional().orElse(null); this.targetUser_absent = targetUser$impl.isAbsent(); this.approximatePresenceCount_value = approximatePresenceCount$impl.toOptional().orElse(null); this.approximatePresenceCount_absent = approximatePresenceCount$impl.isAbsent(); this.approximateMemberCount_value = approximateMemberCount$impl.toOptional().orElse(null); this.approximateMemberCount_absent = approximateMemberCount$impl.isAbsent(); this.expiresAt_value = Possible.flatOpt(expiresAt$impl).orElse(null); this.expiresAt_absent = expiresAt$impl.isAbsent(); this.guildScheduledEvent_value = guildScheduledEvent$impl.toOptional().orElse(null); this.guildScheduledEvent_absent = guildScheduledEvent$impl.isAbsent(); this.uses_value = uses$impl.toOptional().orElse(null); this.uses_absent = uses$impl.isAbsent(); this.maxUses_value = maxUses$impl.toOptional().orElse(null); this.maxUses_absent = maxUses$impl.isAbsent(); this.maxAge_value = maxAge$impl.toOptional().orElse(null); this.maxAge_absent = maxAge$impl.isAbsent(); this.temporary_value = temporary$impl.toOptional().orElse(null); this.temporary_absent = temporary$impl.isAbsent(); this.createdAt_value = createdAt$impl.toOptional().orElse(null); this.createdAt_absent = createdAt$impl.isAbsent(); this.initShim = null; } private ImmutableInviteData(ImmutableInviteData original, String code, Possible<PartialGuildData> guild, ChannelData channel, Possible<UserData> inviter, Possible<Integer> targetType, Possible<UserData> targetUser, Possible<Integer> approximatePresenceCount, Possible<Integer> approximateMemberCount, Possible<Optional<String>> expiresAt, Possible<GuildScheduledEventData> guildScheduledEvent, Possible<Integer> uses, Possible<Integer> maxUses, Possible<Integer> maxAge, Possible<Boolean> temporary, Possible<String> createdAt) { this.initShim = new InitShim(); this.code = code; Possible<PartialGuildData> guild$impl = guild; this.channel = channel; Possible<UserData> inviter$impl = inviter; Possible<Integer> targetType$impl = targetType; Possible<UserData> targetUser$impl = targetUser; Possible<Integer> approximatePresenceCount$impl = approximatePresenceCount; Possible<Integer> approximateMemberCount$impl = approximateMemberCount; Possible<Optional<String>> expiresAt$impl = expiresAt; Possible<GuildScheduledEventData> guildScheduledEvent$impl = guildScheduledEvent; Possible<Integer> uses$impl = uses; Possible<Integer> maxUses$impl = maxUses; Possible<Integer> maxAge$impl = maxAge; Possible<Boolean> temporary$impl = temporary; Possible<String> createdAt$impl = createdAt; this.guild_value = guild$impl.toOptional().orElse(null); this.guild_absent = guild$impl.isAbsent(); this.inviter_value = inviter$impl.toOptional().orElse(null); this.inviter_absent = inviter$impl.isAbsent(); this.targetType_value = targetType$impl.toOptional().orElse(null); this.targetType_absent = targetType$impl.isAbsent(); this.targetUser_value = targetUser$impl.toOptional().orElse(null); this.targetUser_absent = targetUser$impl.isAbsent(); this.approximatePresenceCount_value = approximatePresenceCount$impl.toOptional().orElse(null); this.approximatePresenceCount_absent = approximatePresenceCount$impl.isAbsent(); this.approximateMemberCount_value = approximateMemberCount$impl.toOptional().orElse(null); this.approximateMemberCount_absent = approximateMemberCount$impl.isAbsent(); this.expiresAt_value = Possible.flatOpt(expiresAt$impl).orElse(null); this.expiresAt_absent = expiresAt$impl.isAbsent(); this.guildScheduledEvent_value = guildScheduledEvent$impl.toOptional().orElse(null); this.guildScheduledEvent_absent = guildScheduledEvent$impl.isAbsent(); this.uses_value = uses$impl.toOptional().orElse(null); this.uses_absent = uses$impl.isAbsent(); this.maxUses_value = maxUses$impl.toOptional().orElse(null); this.maxUses_absent = maxUses$impl.isAbsent(); this.maxAge_value = maxAge$impl.toOptional().orElse(null); this.maxAge_absent = maxAge$impl.isAbsent();
/*      */     this.temporary_value = temporary$impl.toOptional().orElse(null);
/*      */     this.temporary_absent = temporary$impl.isAbsent();
/*      */     this.createdAt_value = createdAt$impl.toOptional().orElse(null);
/*      */     this.createdAt_absent = createdAt$impl.isAbsent();
/*  185 */     this.initShim = null; } @Generated(from = "InviteData", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/*  186 */       return "Cannot build InviteData, attribute initializers form cycle " + attributes; }
/*      */      }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("code")
/*      */   public String code() {
/*  196 */     return this.code;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("guild")
/*      */   public Possible<PartialGuildData> guild() {
/*  205 */     return this.guild_absent ? Possible.absent() : Possible.of(this.guild_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("channel")
/*      */   public ChannelData channel() {
/*  214 */     return this.channel;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("inviter")
/*      */   public Possible<UserData> inviter() {
/*  223 */     return this.inviter_absent ? Possible.absent() : Possible.of(this.inviter_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("target_type")
/*      */   public Possible<Integer> targetType() {
/*  232 */     return this.targetType_absent ? Possible.absent() : Possible.of(this.targetType_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("target_user")
/*      */   public Possible<UserData> targetUser() {
/*  241 */     return this.targetUser_absent ? Possible.absent() : Possible.of(this.targetUser_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("approximate_presence_count")
/*      */   public Possible<Integer> approximatePresenceCount() {
/*  250 */     return this.approximatePresenceCount_absent ? Possible.absent() : Possible.of(this.approximatePresenceCount_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("approximate_member_count")
/*      */   public Possible<Integer> approximateMemberCount() {
/*  259 */     return this.approximateMemberCount_absent ? Possible.absent() : Possible.of(this.approximateMemberCount_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("expires_at")
/*      */   public Possible<Optional<String>> expiresAt() {
/*  268 */     return this.expiresAt_absent ? Possible.absent() : 
/*  269 */       Possible.of(Optional.ofNullable(this.expiresAt_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("guild_scheduled_event")
/*      */   public Possible<GuildScheduledEventData> guildScheduledEvent() {
/*  278 */     return this.guildScheduledEvent_absent ? Possible.absent() : Possible.of(this.guildScheduledEvent_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("uses")
/*      */   public Possible<Integer> uses() {
/*  287 */     return this.uses_absent ? Possible.absent() : Possible.of(this.uses_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("max_uses")
/*      */   public Possible<Integer> maxUses() {
/*  296 */     return this.maxUses_absent ? Possible.absent() : Possible.of(this.maxUses_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("max_age")
/*      */   public Possible<Integer> maxAge() {
/*  305 */     return this.maxAge_absent ? Possible.absent() : Possible.of(this.maxAge_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("temporary")
/*      */   public Possible<Boolean> temporary() {
/*  314 */     return this.temporary_absent ? Possible.absent() : Possible.of(this.temporary_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("created_at")
/*      */   public Possible<String> createdAt() {
/*  323 */     return this.createdAt_absent ? Possible.absent() : Possible.of(this.createdAt_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableInviteData withCode(String value) {
/*  333 */     String newValue = Objects.<String>requireNonNull(value, "code");
/*  334 */     if (this.code.equals(newValue)) return this; 
/*  335 */     return new ImmutableInviteData(this, newValue, 
/*      */ 
/*      */         
/*  338 */         guild(), this.channel, 
/*      */         
/*  340 */         inviter(), 
/*  341 */         targetType(), 
/*  342 */         targetUser(), 
/*  343 */         approximatePresenceCount(), 
/*  344 */         approximateMemberCount(), 
/*  345 */         expiresAt(), 
/*  346 */         guildScheduledEvent(), 
/*  347 */         uses(), 
/*  348 */         maxUses(), 
/*  349 */         maxAge(), 
/*  350 */         temporary(), 
/*  351 */         createdAt());
/*      */   }
/*      */   
/*      */   public ImmutableInviteData withGuild(Possible<PartialGuildData> value) {
/*  355 */     Possible<PartialGuildData> newValue = Objects.<Possible<PartialGuildData>>requireNonNull(value);
/*  356 */     return new ImmutableInviteData(this, this.code, newValue, this.channel, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  361 */         inviter(), 
/*  362 */         targetType(), 
/*  363 */         targetUser(), 
/*  364 */         approximatePresenceCount(), 
/*  365 */         approximateMemberCount(), 
/*  366 */         expiresAt(), 
/*  367 */         guildScheduledEvent(), 
/*  368 */         uses(), 
/*  369 */         maxUses(), 
/*  370 */         maxAge(), 
/*  371 */         temporary(), 
/*  372 */         createdAt());
/*      */   }
/*      */   
/*      */   public ImmutableInviteData withGuild(PartialGuildData value) {
/*  376 */     Possible<PartialGuildData> newValue = Possible.of(value);
/*  377 */     return new ImmutableInviteData(this, this.code, newValue, this.channel, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  382 */         inviter(), 
/*  383 */         targetType(), 
/*  384 */         targetUser(), 
/*  385 */         approximatePresenceCount(), 
/*  386 */         approximateMemberCount(), 
/*  387 */         expiresAt(), 
/*  388 */         guildScheduledEvent(), 
/*  389 */         uses(), 
/*  390 */         maxUses(), 
/*  391 */         maxAge(), 
/*  392 */         temporary(), 
/*  393 */         createdAt());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableInviteData withChannel(ChannelData value) {
/*  403 */     if (this.channel == value) return this; 
/*  404 */     ChannelData newValue = Objects.<ChannelData>requireNonNull(value, "channel");
/*  405 */     return new ImmutableInviteData(this, this.code, 
/*      */ 
/*      */         
/*  408 */         guild(), newValue, 
/*      */         
/*  410 */         inviter(), 
/*  411 */         targetType(), 
/*  412 */         targetUser(), 
/*  413 */         approximatePresenceCount(), 
/*  414 */         approximateMemberCount(), 
/*  415 */         expiresAt(), 
/*  416 */         guildScheduledEvent(), 
/*  417 */         uses(), 
/*  418 */         maxUses(), 
/*  419 */         maxAge(), 
/*  420 */         temporary(), 
/*  421 */         createdAt());
/*      */   }
/*      */   
/*      */   public ImmutableInviteData withInviter(Possible<UserData> value) {
/*  425 */     Possible<UserData> newValue = Objects.<Possible<UserData>>requireNonNull(value);
/*  426 */     return new ImmutableInviteData(this, this.code, 
/*      */ 
/*      */         
/*  429 */         guild(), this.channel, newValue, 
/*      */ 
/*      */         
/*  432 */         targetType(), 
/*  433 */         targetUser(), 
/*  434 */         approximatePresenceCount(), 
/*  435 */         approximateMemberCount(), 
/*  436 */         expiresAt(), 
/*  437 */         guildScheduledEvent(), 
/*  438 */         uses(), 
/*  439 */         maxUses(), 
/*  440 */         maxAge(), 
/*  441 */         temporary(), 
/*  442 */         createdAt());
/*      */   }
/*      */   
/*      */   public ImmutableInviteData withInviter(UserData value) {
/*  446 */     Possible<UserData> newValue = Possible.of(value);
/*  447 */     return new ImmutableInviteData(this, this.code, 
/*      */ 
/*      */         
/*  450 */         guild(), this.channel, newValue, 
/*      */ 
/*      */         
/*  453 */         targetType(), 
/*  454 */         targetUser(), 
/*  455 */         approximatePresenceCount(), 
/*  456 */         approximateMemberCount(), 
/*  457 */         expiresAt(), 
/*  458 */         guildScheduledEvent(), 
/*  459 */         uses(), 
/*  460 */         maxUses(), 
/*  461 */         maxAge(), 
/*  462 */         temporary(), 
/*  463 */         createdAt());
/*      */   }
/*      */   
/*      */   public ImmutableInviteData withTargetType(Possible<Integer> value) {
/*  467 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/*  468 */     return new ImmutableInviteData(this, this.code, 
/*      */ 
/*      */         
/*  471 */         guild(), this.channel, 
/*      */         
/*  473 */         inviter(), newValue, 
/*      */         
/*  475 */         targetUser(), 
/*  476 */         approximatePresenceCount(), 
/*  477 */         approximateMemberCount(), 
/*  478 */         expiresAt(), 
/*  479 */         guildScheduledEvent(), 
/*  480 */         uses(), 
/*  481 */         maxUses(), 
/*  482 */         maxAge(), 
/*  483 */         temporary(), 
/*  484 */         createdAt());
/*      */   }
/*      */   
/*      */   public ImmutableInviteData withTargetType(Integer value) {
/*  488 */     Possible<Integer> newValue = Possible.of(value);
/*  489 */     return new ImmutableInviteData(this, this.code, 
/*      */ 
/*      */         
/*  492 */         guild(), this.channel, 
/*      */         
/*  494 */         inviter(), newValue, 
/*      */         
/*  496 */         targetUser(), 
/*  497 */         approximatePresenceCount(), 
/*  498 */         approximateMemberCount(), 
/*  499 */         expiresAt(), 
/*  500 */         guildScheduledEvent(), 
/*  501 */         uses(), 
/*  502 */         maxUses(), 
/*  503 */         maxAge(), 
/*  504 */         temporary(), 
/*  505 */         createdAt());
/*      */   }
/*      */   
/*      */   public ImmutableInviteData withTargetUser(Possible<UserData> value) {
/*  509 */     Possible<UserData> newValue = Objects.<Possible<UserData>>requireNonNull(value);
/*  510 */     return new ImmutableInviteData(this, this.code, 
/*      */ 
/*      */         
/*  513 */         guild(), this.channel, 
/*      */         
/*  515 */         inviter(), 
/*  516 */         targetType(), newValue, 
/*      */         
/*  518 */         approximatePresenceCount(), 
/*  519 */         approximateMemberCount(), 
/*  520 */         expiresAt(), 
/*  521 */         guildScheduledEvent(), 
/*  522 */         uses(), 
/*  523 */         maxUses(), 
/*  524 */         maxAge(), 
/*  525 */         temporary(), 
/*  526 */         createdAt());
/*      */   }
/*      */   
/*      */   public ImmutableInviteData withTargetUser(UserData value) {
/*  530 */     Possible<UserData> newValue = Possible.of(value);
/*  531 */     return new ImmutableInviteData(this, this.code, 
/*      */ 
/*      */         
/*  534 */         guild(), this.channel, 
/*      */         
/*  536 */         inviter(), 
/*  537 */         targetType(), newValue, 
/*      */         
/*  539 */         approximatePresenceCount(), 
/*  540 */         approximateMemberCount(), 
/*  541 */         expiresAt(), 
/*  542 */         guildScheduledEvent(), 
/*  543 */         uses(), 
/*  544 */         maxUses(), 
/*  545 */         maxAge(), 
/*  546 */         temporary(), 
/*  547 */         createdAt());
/*      */   }
/*      */   
/*      */   public ImmutableInviteData withApproximatePresenceCount(Possible<Integer> value) {
/*  551 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/*  552 */     return new ImmutableInviteData(this, this.code, 
/*      */ 
/*      */         
/*  555 */         guild(), this.channel, 
/*      */         
/*  557 */         inviter(), 
/*  558 */         targetType(), 
/*  559 */         targetUser(), newValue, 
/*      */         
/*  561 */         approximateMemberCount(), 
/*  562 */         expiresAt(), 
/*  563 */         guildScheduledEvent(), 
/*  564 */         uses(), 
/*  565 */         maxUses(), 
/*  566 */         maxAge(), 
/*  567 */         temporary(), 
/*  568 */         createdAt());
/*      */   }
/*      */   
/*      */   public ImmutableInviteData withApproximatePresenceCount(Integer value) {
/*  572 */     Possible<Integer> newValue = Possible.of(value);
/*  573 */     return new ImmutableInviteData(this, this.code, 
/*      */ 
/*      */         
/*  576 */         guild(), this.channel, 
/*      */         
/*  578 */         inviter(), 
/*  579 */         targetType(), 
/*  580 */         targetUser(), newValue, 
/*      */         
/*  582 */         approximateMemberCount(), 
/*  583 */         expiresAt(), 
/*  584 */         guildScheduledEvent(), 
/*  585 */         uses(), 
/*  586 */         maxUses(), 
/*  587 */         maxAge(), 
/*  588 */         temporary(), 
/*  589 */         createdAt());
/*      */   }
/*      */   
/*      */   public ImmutableInviteData withApproximateMemberCount(Possible<Integer> value) {
/*  593 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/*  594 */     return new ImmutableInviteData(this, this.code, 
/*      */ 
/*      */         
/*  597 */         guild(), this.channel, 
/*      */         
/*  599 */         inviter(), 
/*  600 */         targetType(), 
/*  601 */         targetUser(), 
/*  602 */         approximatePresenceCount(), newValue, 
/*      */         
/*  604 */         expiresAt(), 
/*  605 */         guildScheduledEvent(), 
/*  606 */         uses(), 
/*  607 */         maxUses(), 
/*  608 */         maxAge(), 
/*  609 */         temporary(), 
/*  610 */         createdAt());
/*      */   }
/*      */   
/*      */   public ImmutableInviteData withApproximateMemberCount(Integer value) {
/*  614 */     Possible<Integer> newValue = Possible.of(value);
/*  615 */     return new ImmutableInviteData(this, this.code, 
/*      */ 
/*      */         
/*  618 */         guild(), this.channel, 
/*      */         
/*  620 */         inviter(), 
/*  621 */         targetType(), 
/*  622 */         targetUser(), 
/*  623 */         approximatePresenceCount(), newValue, 
/*      */         
/*  625 */         expiresAt(), 
/*  626 */         guildScheduledEvent(), 
/*  627 */         uses(), 
/*  628 */         maxUses(), 
/*  629 */         maxAge(), 
/*  630 */         temporary(), 
/*  631 */         createdAt());
/*      */   }
/*      */   
/*      */   public ImmutableInviteData withExpiresAt(Possible<Optional<String>> value) {
/*  635 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/*  636 */     return new ImmutableInviteData(this, this.code, 
/*      */ 
/*      */         
/*  639 */         guild(), this.channel, 
/*      */         
/*  641 */         inviter(), 
/*  642 */         targetType(), 
/*  643 */         targetUser(), 
/*  644 */         approximatePresenceCount(), 
/*  645 */         approximateMemberCount(), newValue, 
/*      */         
/*  647 */         guildScheduledEvent(), 
/*  648 */         uses(), 
/*  649 */         maxUses(), 
/*  650 */         maxAge(), 
/*  651 */         temporary(), 
/*  652 */         createdAt());
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableInviteData withExpiresAt(@Nullable String value) {
/*  657 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  658 */     return new ImmutableInviteData(this, this.code, 
/*      */ 
/*      */         
/*  661 */         guild(), this.channel, 
/*      */         
/*  663 */         inviter(), 
/*  664 */         targetType(), 
/*  665 */         targetUser(), 
/*  666 */         approximatePresenceCount(), 
/*  667 */         approximateMemberCount(), newValue, 
/*      */         
/*  669 */         guildScheduledEvent(), 
/*  670 */         uses(), 
/*  671 */         maxUses(), 
/*  672 */         maxAge(), 
/*  673 */         temporary(), 
/*  674 */         createdAt());
/*      */   }
/*      */   
/*      */   public ImmutableInviteData withExpiresAtOrNull(@Nullable String value) {
/*  678 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  679 */     return new ImmutableInviteData(this, this.code, 
/*      */ 
/*      */         
/*  682 */         guild(), this.channel, 
/*      */         
/*  684 */         inviter(), 
/*  685 */         targetType(), 
/*  686 */         targetUser(), 
/*  687 */         approximatePresenceCount(), 
/*  688 */         approximateMemberCount(), newValue, 
/*      */         
/*  690 */         guildScheduledEvent(), 
/*  691 */         uses(), 
/*  692 */         maxUses(), 
/*  693 */         maxAge(), 
/*  694 */         temporary(), 
/*  695 */         createdAt());
/*      */   }
/*      */   
/*      */   public ImmutableInviteData withGuildScheduledEvent(Possible<GuildScheduledEventData> value) {
/*  699 */     Possible<GuildScheduledEventData> newValue = Objects.<Possible<GuildScheduledEventData>>requireNonNull(value);
/*  700 */     return new ImmutableInviteData(this, this.code, 
/*      */ 
/*      */         
/*  703 */         guild(), this.channel, 
/*      */         
/*  705 */         inviter(), 
/*  706 */         targetType(), 
/*  707 */         targetUser(), 
/*  708 */         approximatePresenceCount(), 
/*  709 */         approximateMemberCount(), 
/*  710 */         expiresAt(), newValue, 
/*      */         
/*  712 */         uses(), 
/*  713 */         maxUses(), 
/*  714 */         maxAge(), 
/*  715 */         temporary(), 
/*  716 */         createdAt());
/*      */   }
/*      */   
/*      */   public ImmutableInviteData withGuildScheduledEvent(GuildScheduledEventData value) {
/*  720 */     Possible<GuildScheduledEventData> newValue = Possible.of(value);
/*  721 */     return new ImmutableInviteData(this, this.code, 
/*      */ 
/*      */         
/*  724 */         guild(), this.channel, 
/*      */         
/*  726 */         inviter(), 
/*  727 */         targetType(), 
/*  728 */         targetUser(), 
/*  729 */         approximatePresenceCount(), 
/*  730 */         approximateMemberCount(), 
/*  731 */         expiresAt(), newValue, 
/*      */         
/*  733 */         uses(), 
/*  734 */         maxUses(), 
/*  735 */         maxAge(), 
/*  736 */         temporary(), 
/*  737 */         createdAt());
/*      */   }
/*      */   
/*      */   public ImmutableInviteData withUses(Possible<Integer> value) {
/*  741 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/*  742 */     return new ImmutableInviteData(this, this.code, 
/*      */ 
/*      */         
/*  745 */         guild(), this.channel, 
/*      */         
/*  747 */         inviter(), 
/*  748 */         targetType(), 
/*  749 */         targetUser(), 
/*  750 */         approximatePresenceCount(), 
/*  751 */         approximateMemberCount(), 
/*  752 */         expiresAt(), 
/*  753 */         guildScheduledEvent(), newValue, 
/*      */         
/*  755 */         maxUses(), 
/*  756 */         maxAge(), 
/*  757 */         temporary(), 
/*  758 */         createdAt());
/*      */   }
/*      */   
/*      */   public ImmutableInviteData withUses(Integer value) {
/*  762 */     Possible<Integer> newValue = Possible.of(value);
/*  763 */     return new ImmutableInviteData(this, this.code, 
/*      */ 
/*      */         
/*  766 */         guild(), this.channel, 
/*      */         
/*  768 */         inviter(), 
/*  769 */         targetType(), 
/*  770 */         targetUser(), 
/*  771 */         approximatePresenceCount(), 
/*  772 */         approximateMemberCount(), 
/*  773 */         expiresAt(), 
/*  774 */         guildScheduledEvent(), newValue, 
/*      */         
/*  776 */         maxUses(), 
/*  777 */         maxAge(), 
/*  778 */         temporary(), 
/*  779 */         createdAt());
/*      */   }
/*      */   
/*      */   public ImmutableInviteData withMaxUses(Possible<Integer> value) {
/*  783 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/*  784 */     return new ImmutableInviteData(this, this.code, 
/*      */ 
/*      */         
/*  787 */         guild(), this.channel, 
/*      */         
/*  789 */         inviter(), 
/*  790 */         targetType(), 
/*  791 */         targetUser(), 
/*  792 */         approximatePresenceCount(), 
/*  793 */         approximateMemberCount(), 
/*  794 */         expiresAt(), 
/*  795 */         guildScheduledEvent(), 
/*  796 */         uses(), newValue, 
/*      */         
/*  798 */         maxAge(), 
/*  799 */         temporary(), 
/*  800 */         createdAt());
/*      */   }
/*      */   
/*      */   public ImmutableInviteData withMaxUses(Integer value) {
/*  804 */     Possible<Integer> newValue = Possible.of(value);
/*  805 */     return new ImmutableInviteData(this, this.code, 
/*      */ 
/*      */         
/*  808 */         guild(), this.channel, 
/*      */         
/*  810 */         inviter(), 
/*  811 */         targetType(), 
/*  812 */         targetUser(), 
/*  813 */         approximatePresenceCount(), 
/*  814 */         approximateMemberCount(), 
/*  815 */         expiresAt(), 
/*  816 */         guildScheduledEvent(), 
/*  817 */         uses(), newValue, 
/*      */         
/*  819 */         maxAge(), 
/*  820 */         temporary(), 
/*  821 */         createdAt());
/*      */   }
/*      */   
/*      */   public ImmutableInviteData withMaxAge(Possible<Integer> value) {
/*  825 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/*  826 */     return new ImmutableInviteData(this, this.code, 
/*      */ 
/*      */         
/*  829 */         guild(), this.channel, 
/*      */         
/*  831 */         inviter(), 
/*  832 */         targetType(), 
/*  833 */         targetUser(), 
/*  834 */         approximatePresenceCount(), 
/*  835 */         approximateMemberCount(), 
/*  836 */         expiresAt(), 
/*  837 */         guildScheduledEvent(), 
/*  838 */         uses(), 
/*  839 */         maxUses(), newValue, 
/*      */         
/*  841 */         temporary(), 
/*  842 */         createdAt());
/*      */   }
/*      */   
/*      */   public ImmutableInviteData withMaxAge(Integer value) {
/*  846 */     Possible<Integer> newValue = Possible.of(value);
/*  847 */     return new ImmutableInviteData(this, this.code, 
/*      */ 
/*      */         
/*  850 */         guild(), this.channel, 
/*      */         
/*  852 */         inviter(), 
/*  853 */         targetType(), 
/*  854 */         targetUser(), 
/*  855 */         approximatePresenceCount(), 
/*  856 */         approximateMemberCount(), 
/*  857 */         expiresAt(), 
/*  858 */         guildScheduledEvent(), 
/*  859 */         uses(), 
/*  860 */         maxUses(), newValue, 
/*      */         
/*  862 */         temporary(), 
/*  863 */         createdAt());
/*      */   }
/*      */   
/*      */   public ImmutableInviteData withTemporary(Possible<Boolean> value) {
/*  867 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/*  868 */     return new ImmutableInviteData(this, this.code, 
/*      */ 
/*      */         
/*  871 */         guild(), this.channel, 
/*      */         
/*  873 */         inviter(), 
/*  874 */         targetType(), 
/*  875 */         targetUser(), 
/*  876 */         approximatePresenceCount(), 
/*  877 */         approximateMemberCount(), 
/*  878 */         expiresAt(), 
/*  879 */         guildScheduledEvent(), 
/*  880 */         uses(), 
/*  881 */         maxUses(), 
/*  882 */         maxAge(), newValue, 
/*      */         
/*  884 */         createdAt());
/*      */   }
/*      */   
/*      */   public ImmutableInviteData withTemporary(Boolean value) {
/*  888 */     Possible<Boolean> newValue = Possible.of(value);
/*  889 */     return new ImmutableInviteData(this, this.code, 
/*      */ 
/*      */         
/*  892 */         guild(), this.channel, 
/*      */         
/*  894 */         inviter(), 
/*  895 */         targetType(), 
/*  896 */         targetUser(), 
/*  897 */         approximatePresenceCount(), 
/*  898 */         approximateMemberCount(), 
/*  899 */         expiresAt(), 
/*  900 */         guildScheduledEvent(), 
/*  901 */         uses(), 
/*  902 */         maxUses(), 
/*  903 */         maxAge(), newValue, 
/*      */         
/*  905 */         createdAt());
/*      */   }
/*      */   
/*      */   public ImmutableInviteData withCreatedAt(Possible<String> value) {
/*  909 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  910 */     return new ImmutableInviteData(this, this.code, 
/*      */ 
/*      */         
/*  913 */         guild(), this.channel, 
/*      */         
/*  915 */         inviter(), 
/*  916 */         targetType(), 
/*  917 */         targetUser(), 
/*  918 */         approximatePresenceCount(), 
/*  919 */         approximateMemberCount(), 
/*  920 */         expiresAt(), 
/*  921 */         guildScheduledEvent(), 
/*  922 */         uses(), 
/*  923 */         maxUses(), 
/*  924 */         maxAge(), 
/*  925 */         temporary(), newValue);
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableInviteData withCreatedAt(String value) {
/*  930 */     Possible<String> newValue = Possible.of(value);
/*  931 */     return new ImmutableInviteData(this, this.code, 
/*      */ 
/*      */         
/*  934 */         guild(), this.channel, 
/*      */         
/*  936 */         inviter(), 
/*  937 */         targetType(), 
/*  938 */         targetUser(), 
/*  939 */         approximatePresenceCount(), 
/*  940 */         approximateMemberCount(), 
/*  941 */         expiresAt(), 
/*  942 */         guildScheduledEvent(), 
/*  943 */         uses(), 
/*  944 */         maxUses(), 
/*  945 */         maxAge(), 
/*  946 */         temporary(), newValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object another) {
/*  956 */     if (this == another) return true; 
/*  957 */     return (another instanceof ImmutableInviteData && 
/*  958 */       equalTo(0, (ImmutableInviteData)another));
/*      */   }
/*      */   
/*      */   private boolean equalTo(int synthetic, ImmutableInviteData another) {
/*  962 */     return (this.code.equals(another.code) && 
/*  963 */       guild().equals(another.guild()) && this.channel
/*  964 */       .equals(another.channel) && 
/*  965 */       inviter().equals(another.inviter()) && 
/*  966 */       targetType().equals(another.targetType()) && 
/*  967 */       targetUser().equals(another.targetUser()) && 
/*  968 */       approximatePresenceCount().equals(another.approximatePresenceCount()) && 
/*  969 */       approximateMemberCount().equals(another.approximateMemberCount()) && 
/*  970 */       expiresAt().equals(another.expiresAt()) && 
/*  971 */       guildScheduledEvent().equals(another.guildScheduledEvent()) && 
/*  972 */       uses().equals(another.uses()) && 
/*  973 */       maxUses().equals(another.maxUses()) && 
/*  974 */       maxAge().equals(another.maxAge()) && 
/*  975 */       temporary().equals(another.temporary()) && 
/*  976 */       createdAt().equals(another.createdAt()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/*  985 */     int h = 5381;
/*  986 */     h += (h << 5) + this.code.hashCode();
/*  987 */     h += (h << 5) + guild().hashCode();
/*  988 */     h += (h << 5) + this.channel.hashCode();
/*  989 */     h += (h << 5) + inviter().hashCode();
/*  990 */     h += (h << 5) + targetType().hashCode();
/*  991 */     h += (h << 5) + targetUser().hashCode();
/*  992 */     h += (h << 5) + approximatePresenceCount().hashCode();
/*  993 */     h += (h << 5) + approximateMemberCount().hashCode();
/*  994 */     h += (h << 5) + expiresAt().hashCode();
/*  995 */     h += (h << 5) + guildScheduledEvent().hashCode();
/*  996 */     h += (h << 5) + uses().hashCode();
/*  997 */     h += (h << 5) + maxUses().hashCode();
/*  998 */     h += (h << 5) + maxAge().hashCode();
/*  999 */     h += (h << 5) + temporary().hashCode();
/* 1000 */     h += (h << 5) + createdAt().hashCode();
/* 1001 */     return h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1010 */     return "InviteData{code=" + this.code + ", guild=" + 
/*      */       
/* 1012 */       guild().toString() + ", channel=" + this.channel + ", inviter=" + 
/*      */       
/* 1014 */       inviter().toString() + ", targetType=" + 
/* 1015 */       targetType().toString() + ", targetUser=" + 
/* 1016 */       targetUser().toString() + ", approximatePresenceCount=" + 
/* 1017 */       approximatePresenceCount().toString() + ", approximateMemberCount=" + 
/* 1018 */       approximateMemberCount().toString() + ", expiresAt=" + 
/* 1019 */       expiresAt().toString() + ", guildScheduledEvent=" + 
/* 1020 */       guildScheduledEvent().toString() + ", uses=" + 
/* 1021 */       uses().toString() + ", maxUses=" + 
/* 1022 */       maxUses().toString() + ", maxAge=" + 
/* 1023 */       maxAge().toString() + ", temporary=" + 
/* 1024 */       temporary().toString() + ", createdAt=" + 
/* 1025 */       createdAt().toString() + "}";
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonDeserialize
/*      */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*      */   @Generated(from = "InviteData", generator = "Immutables")
/*      */   static final class Json
/*      */     implements InviteData
/*      */   {
/*      */     String code;
/*      */ 
/*      */     
/* 1040 */     Possible<PartialGuildData> guild = Possible.absent();
/*      */     
/*      */     ChannelData channel;
/*      */     
/* 1044 */     Possible<UserData> inviter = Possible.absent();
/*      */ 
/*      */     
/* 1047 */     Possible<Integer> targetType = Possible.absent();
/*      */ 
/*      */     
/* 1050 */     Possible<UserData> targetUser = Possible.absent();
/*      */ 
/*      */     
/* 1053 */     Possible<Integer> approximatePresenceCount = Possible.absent();
/*      */ 
/*      */     
/* 1056 */     Possible<Integer> approximateMemberCount = Possible.absent();
/*      */ 
/*      */     
/* 1059 */     Possible<Optional<String>> expiresAt = Possible.absent();
/*      */ 
/*      */     
/* 1062 */     Possible<GuildScheduledEventData> guildScheduledEvent = Possible.absent();
/*      */ 
/*      */     
/* 1065 */     Possible<Integer> uses = Possible.absent();
/*      */ 
/*      */     
/* 1068 */     Possible<Integer> maxUses = Possible.absent();
/*      */ 
/*      */     
/* 1071 */     Possible<Integer> maxAge = Possible.absent();
/*      */ 
/*      */     
/* 1074 */     Possible<Boolean> temporary = Possible.absent();
/*      */ 
/*      */     
/* 1077 */     Possible<String> createdAt = Possible.absent();
/*      */     
/*      */     @JsonProperty("code")
/*      */     public void setCode(String code) {
/* 1081 */       this.code = code;
/*      */     }
/*      */     @JsonProperty("guild")
/*      */     public void setGuild(Possible<PartialGuildData> guild) {
/* 1085 */       this.guild = guild;
/*      */     }
/*      */     @JsonProperty("channel")
/*      */     public void setChannel(ChannelData channel) {
/* 1089 */       this.channel = channel;
/*      */     }
/*      */     @JsonProperty("inviter")
/*      */     public void setInviter(Possible<UserData> inviter) {
/* 1093 */       this.inviter = inviter;
/*      */     }
/*      */     @JsonProperty("target_type")
/*      */     public void setTargetType(Possible<Integer> targetType) {
/* 1097 */       this.targetType = targetType;
/*      */     }
/*      */     @JsonProperty("target_user")
/*      */     public void setTargetUser(Possible<UserData> targetUser) {
/* 1101 */       this.targetUser = targetUser;
/*      */     }
/*      */     @JsonProperty("approximate_presence_count")
/*      */     public void setApproximatePresenceCount(Possible<Integer> approximatePresenceCount) {
/* 1105 */       this.approximatePresenceCount = approximatePresenceCount;
/*      */     }
/*      */     @JsonProperty("approximate_member_count")
/*      */     public void setApproximateMemberCount(Possible<Integer> approximateMemberCount) {
/* 1109 */       this.approximateMemberCount = approximateMemberCount;
/*      */     }
/*      */     @JsonProperty("expires_at")
/*      */     public void setExpiresAt(Possible<Optional<String>> expiresAt) {
/* 1113 */       this.expiresAt = expiresAt;
/*      */     }
/*      */     @JsonProperty("guild_scheduled_event")
/*      */     public void setGuildScheduledEvent(Possible<GuildScheduledEventData> guildScheduledEvent) {
/* 1117 */       this.guildScheduledEvent = guildScheduledEvent;
/*      */     }
/*      */     @JsonProperty("uses")
/*      */     public void setUses(Possible<Integer> uses) {
/* 1121 */       this.uses = uses;
/*      */     }
/*      */     @JsonProperty("max_uses")
/*      */     public void setMaxUses(Possible<Integer> maxUses) {
/* 1125 */       this.maxUses = maxUses;
/*      */     }
/*      */     @JsonProperty("max_age")
/*      */     public void setMaxAge(Possible<Integer> maxAge) {
/* 1129 */       this.maxAge = maxAge;
/*      */     }
/*      */     @JsonProperty("temporary")
/*      */     public void setTemporary(Possible<Boolean> temporary) {
/* 1133 */       this.temporary = temporary;
/*      */     }
/*      */     @JsonProperty("created_at")
/*      */     public void setCreatedAt(Possible<String> createdAt) {
/* 1137 */       this.createdAt = createdAt;
/*      */     }
/*      */     public String code() {
/* 1140 */       throw new UnsupportedOperationException();
/*      */     } public Possible<PartialGuildData> guild() {
/* 1142 */       throw new UnsupportedOperationException();
/*      */     } public ChannelData channel() {
/* 1144 */       throw new UnsupportedOperationException();
/*      */     } public Possible<UserData> inviter() {
/* 1146 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> targetType() {
/* 1148 */       throw new UnsupportedOperationException();
/*      */     } public Possible<UserData> targetUser() {
/* 1150 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> approximatePresenceCount() {
/* 1152 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> approximateMemberCount() {
/* 1154 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<String>> expiresAt() {
/* 1156 */       throw new UnsupportedOperationException();
/*      */     } public Possible<GuildScheduledEventData> guildScheduledEvent() {
/* 1158 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> uses() {
/* 1160 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> maxUses() {
/* 1162 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> maxAge() {
/* 1164 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Boolean> temporary() {
/* 1166 */       throw new UnsupportedOperationException();
/*      */     } public Possible<String> createdAt() {
/* 1168 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*      */   static ImmutableInviteData fromJson(Json json) {
/* 1179 */     Builder builder = builder();
/* 1180 */     if (json.code != null) {
/* 1181 */       builder.code(json.code);
/*      */     }
/* 1183 */     if (json.guild != null) {
/* 1184 */       builder.guild(json.guild);
/*      */     }
/* 1186 */     if (json.channel != null) {
/* 1187 */       builder.channel(json.channel);
/*      */     }
/* 1189 */     if (json.inviter != null) {
/* 1190 */       builder.inviter(json.inviter);
/*      */     }
/* 1192 */     if (json.targetType != null) {
/* 1193 */       builder.targetType(json.targetType);
/*      */     }
/* 1195 */     if (json.targetUser != null) {
/* 1196 */       builder.targetUser(json.targetUser);
/*      */     }
/* 1198 */     if (json.approximatePresenceCount != null) {
/* 1199 */       builder.approximatePresenceCount(json.approximatePresenceCount);
/*      */     }
/* 1201 */     if (json.approximateMemberCount != null) {
/* 1202 */       builder.approximateMemberCount(json.approximateMemberCount);
/*      */     }
/* 1204 */     if (json.expiresAt != null) {
/* 1205 */       builder.expiresAt(json.expiresAt);
/*      */     }
/* 1207 */     if (json.guildScheduledEvent != null) {
/* 1208 */       builder.guildScheduledEvent(json.guildScheduledEvent);
/*      */     }
/* 1210 */     if (json.uses != null) {
/* 1211 */       builder.uses(json.uses);
/*      */     }
/* 1213 */     if (json.maxUses != null) {
/* 1214 */       builder.maxUses(json.maxUses);
/*      */     }
/* 1216 */     if (json.maxAge != null) {
/* 1217 */       builder.maxAge(json.maxAge);
/*      */     }
/* 1219 */     if (json.temporary != null) {
/* 1220 */       builder.temporary(json.temporary);
/*      */     }
/* 1222 */     if (json.createdAt != null) {
/* 1223 */       builder.createdAt(json.createdAt);
/*      */     }
/* 1225 */     return builder.build();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableInviteData of(String code, Possible<PartialGuildData> guild, ChannelData channel, Possible<UserData> inviter, Possible<Integer> targetType, Possible<UserData> targetUser, Possible<Integer> approximatePresenceCount, Possible<Integer> approximateMemberCount, Possible<Optional<String>> expiresAt, Possible<GuildScheduledEventData> guildScheduledEvent, Possible<Integer> uses, Possible<Integer> maxUses, Possible<Integer> maxAge, Possible<Boolean> temporary, Possible<String> createdAt) {
/* 1248 */     return new ImmutableInviteData(code, guild, channel, inviter, targetType, targetUser, approximatePresenceCount, approximateMemberCount, expiresAt, guildScheduledEvent, uses, maxUses, maxAge, temporary, createdAt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableInviteData copyOf(InviteData instance) {
/* 1259 */     if (instance instanceof ImmutableInviteData) {
/* 1260 */       return (ImmutableInviteData)instance;
/*      */     }
/* 1262 */     return builder()
/* 1263 */       .from(instance)
/* 1264 */       .build();
/*      */   }
/*      */   
/*      */   public boolean isGuildPresent() {
/* 1268 */     return !this.guild_absent;
/*      */   }
/*      */   
/*      */   public PartialGuildData guildOrElse(PartialGuildData defaultValue) {
/* 1272 */     return !this.guild_absent ? this.guild_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isInviterPresent() {
/* 1276 */     return !this.inviter_absent;
/*      */   }
/*      */   
/*      */   public UserData inviterOrElse(UserData defaultValue) {
/* 1280 */     return !this.inviter_absent ? this.inviter_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isTargetTypePresent() {
/* 1284 */     return !this.targetType_absent;
/*      */   }
/*      */   
/*      */   public Integer targetTypeOrElse(Integer defaultValue) {
/* 1288 */     return !this.targetType_absent ? this.targetType_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isTargetUserPresent() {
/* 1292 */     return !this.targetUser_absent;
/*      */   }
/*      */   
/*      */   public UserData targetUserOrElse(UserData defaultValue) {
/* 1296 */     return !this.targetUser_absent ? this.targetUser_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isApproximatePresenceCountPresent() {
/* 1300 */     return !this.approximatePresenceCount_absent;
/*      */   }
/*      */   
/*      */   public Integer approximatePresenceCountOrElse(Integer defaultValue) {
/* 1304 */     return !this.approximatePresenceCount_absent ? this.approximatePresenceCount_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isApproximateMemberCountPresent() {
/* 1308 */     return !this.approximateMemberCount_absent;
/*      */   }
/*      */   
/*      */   public Integer approximateMemberCountOrElse(Integer defaultValue) {
/* 1312 */     return !this.approximateMemberCount_absent ? this.approximateMemberCount_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isExpiresAtPresent() {
/* 1316 */     return !this.expiresAt_absent;
/*      */   }
/*      */   
/*      */   public String expiresAtOrElse(String defaultValue) {
/* 1320 */     return !this.expiresAt_absent ? this.expiresAt_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isGuildScheduledEventPresent() {
/* 1324 */     return !this.guildScheduledEvent_absent;
/*      */   }
/*      */   
/*      */   public GuildScheduledEventData guildScheduledEventOrElse(GuildScheduledEventData defaultValue) {
/* 1328 */     return !this.guildScheduledEvent_absent ? this.guildScheduledEvent_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isUsesPresent() {
/* 1332 */     return !this.uses_absent;
/*      */   }
/*      */   
/*      */   public Integer usesOrElse(Integer defaultValue) {
/* 1336 */     return !this.uses_absent ? this.uses_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isMaxUsesPresent() {
/* 1340 */     return !this.maxUses_absent;
/*      */   }
/*      */   
/*      */   public Integer maxUsesOrElse(Integer defaultValue) {
/* 1344 */     return !this.maxUses_absent ? this.maxUses_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isMaxAgePresent() {
/* 1348 */     return !this.maxAge_absent;
/*      */   }
/*      */   
/*      */   public Integer maxAgeOrElse(Integer defaultValue) {
/* 1352 */     return !this.maxAge_absent ? this.maxAge_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isTemporaryPresent() {
/* 1356 */     return !this.temporary_absent;
/*      */   }
/*      */   
/*      */   public Boolean temporaryOrElse(Boolean defaultValue) {
/* 1360 */     return !this.temporary_absent ? this.temporary_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isCreatedAtPresent() {
/* 1364 */     return !this.createdAt_absent;
/*      */   }
/*      */   
/*      */   public String createdAtOrElse(String defaultValue) {
/* 1368 */     return !this.createdAt_absent ? this.createdAt_value : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Builder builder() {
/* 1395 */     return new Builder();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Generated(from = "InviteData", generator = "Immutables")
/*      */   public static final class Builder
/*      */   {
/*      */     private static final long INIT_BIT_CODE = 1L;
/*      */ 
/*      */     
/*      */     private static final long INIT_BIT_CHANNEL = 2L;
/*      */ 
/*      */     
/* 1409 */     private long initBits = 3L;
/*      */     
/* 1411 */     private Possible<PartialGuildData> guild_possible = Possible.absent();
/* 1412 */     private Possible<UserData> inviter_possible = Possible.absent();
/* 1413 */     private Possible<Integer> targetType_possible = Possible.absent();
/* 1414 */     private Possible<UserData> targetUser_possible = Possible.absent();
/* 1415 */     private Possible<Integer> approximatePresenceCount_possible = Possible.absent();
/* 1416 */     private Possible<Integer> approximateMemberCount_possible = Possible.absent();
/* 1417 */     private Possible<Optional<String>> expiresAt_possible = Possible.absent();
/* 1418 */     private Possible<GuildScheduledEventData> guildScheduledEvent_possible = Possible.absent();
/* 1419 */     private Possible<Integer> uses_possible = Possible.absent();
/* 1420 */     private Possible<Integer> maxUses_possible = Possible.absent();
/* 1421 */     private Possible<Integer> maxAge_possible = Possible.absent();
/* 1422 */     private Possible<Boolean> temporary_possible = Possible.absent();
/* 1423 */     private Possible<String> createdAt_possible = Possible.absent();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private String code;
/*      */ 
/*      */ 
/*      */     
/*      */     private ChannelData channel;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(InviteData instance) {
/* 1438 */       Objects.requireNonNull(instance, "instance");
/* 1439 */       code(instance.code());
/* 1440 */       guild(instance.guild());
/* 1441 */       channel(instance.channel());
/* 1442 */       inviter(instance.inviter());
/* 1443 */       targetType(instance.targetType());
/* 1444 */       targetUser(instance.targetUser());
/* 1445 */       approximatePresenceCount(instance.approximatePresenceCount());
/* 1446 */       approximateMemberCount(instance.approximateMemberCount());
/* 1447 */       expiresAt(instance.expiresAt());
/* 1448 */       guildScheduledEvent(instance.guildScheduledEvent());
/* 1449 */       uses(instance.uses());
/* 1450 */       maxUses(instance.maxUses());
/* 1451 */       maxAge(instance.maxAge());
/* 1452 */       temporary(instance.temporary());
/* 1453 */       createdAt(instance.createdAt());
/* 1454 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("code")
/*      */     public final Builder code(String code) {
/* 1464 */       this.code = Objects.<String>requireNonNull(code, "code");
/* 1465 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 1466 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("guild")
/*      */     public Builder guild(Possible<PartialGuildData> value) {
/* 1471 */       this.guild_possible = value;
/* 1472 */       return this;
/*      */     }
/*      */     
/*      */     public Builder guild(PartialGuildData value) {
/* 1476 */       this.guild_possible = Possible.of(value);
/* 1477 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("channel")
/*      */     public final Builder channel(ChannelData channel) {
/* 1487 */       this.channel = Objects.<ChannelData>requireNonNull(channel, "channel");
/* 1488 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 1489 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("inviter")
/*      */     public Builder inviter(Possible<UserData> value) {
/* 1494 */       this.inviter_possible = value;
/* 1495 */       return this;
/*      */     }
/*      */     
/*      */     public Builder inviter(UserData value) {
/* 1499 */       this.inviter_possible = Possible.of(value);
/* 1500 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("target_type")
/*      */     public Builder targetType(Possible<Integer> value) {
/* 1505 */       this.targetType_possible = value;
/* 1506 */       return this;
/*      */     }
/*      */     
/*      */     public Builder targetType(Integer value) {
/* 1510 */       this.targetType_possible = Possible.of(value);
/* 1511 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("target_user")
/*      */     public Builder targetUser(Possible<UserData> value) {
/* 1516 */       this.targetUser_possible = value;
/* 1517 */       return this;
/*      */     }
/*      */     
/*      */     public Builder targetUser(UserData value) {
/* 1521 */       this.targetUser_possible = Possible.of(value);
/* 1522 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("approximate_presence_count")
/*      */     public Builder approximatePresenceCount(Possible<Integer> value) {
/* 1527 */       this.approximatePresenceCount_possible = value;
/* 1528 */       return this;
/*      */     }
/*      */     
/*      */     public Builder approximatePresenceCount(Integer value) {
/* 1532 */       this.approximatePresenceCount_possible = Possible.of(value);
/* 1533 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("approximate_member_count")
/*      */     public Builder approximateMemberCount(Possible<Integer> value) {
/* 1538 */       this.approximateMemberCount_possible = value;
/* 1539 */       return this;
/*      */     }
/*      */     
/*      */     public Builder approximateMemberCount(Integer value) {
/* 1543 */       this.approximateMemberCount_possible = Possible.of(value);
/* 1544 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("expires_at")
/*      */     public Builder expiresAt(Possible<Optional<String>> value) {
/* 1549 */       this.expiresAt_possible = value;
/* 1550 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder expiresAt(@Nullable String value) {
/* 1555 */       this.expiresAt_possible = Possible.of(Optional.ofNullable(value));
/* 1556 */       return this;
/*      */     }
/*      */     
/*      */     public Builder expiresAtOrNull(@Nullable String value) {
/* 1560 */       this.expiresAt_possible = Possible.of(Optional.ofNullable(value));
/* 1561 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("guild_scheduled_event")
/*      */     public Builder guildScheduledEvent(Possible<GuildScheduledEventData> value) {
/* 1566 */       this.guildScheduledEvent_possible = value;
/* 1567 */       return this;
/*      */     }
/*      */     
/*      */     public Builder guildScheduledEvent(GuildScheduledEventData value) {
/* 1571 */       this.guildScheduledEvent_possible = Possible.of(value);
/* 1572 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("uses")
/*      */     public Builder uses(Possible<Integer> value) {
/* 1577 */       this.uses_possible = value;
/* 1578 */       return this;
/*      */     }
/*      */     
/*      */     public Builder uses(Integer value) {
/* 1582 */       this.uses_possible = Possible.of(value);
/* 1583 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("max_uses")
/*      */     public Builder maxUses(Possible<Integer> value) {
/* 1588 */       this.maxUses_possible = value;
/* 1589 */       return this;
/*      */     }
/*      */     
/*      */     public Builder maxUses(Integer value) {
/* 1593 */       this.maxUses_possible = Possible.of(value);
/* 1594 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("max_age")
/*      */     public Builder maxAge(Possible<Integer> value) {
/* 1599 */       this.maxAge_possible = value;
/* 1600 */       return this;
/*      */     }
/*      */     
/*      */     public Builder maxAge(Integer value) {
/* 1604 */       this.maxAge_possible = Possible.of(value);
/* 1605 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("temporary")
/*      */     public Builder temporary(Possible<Boolean> value) {
/* 1610 */       this.temporary_possible = value;
/* 1611 */       return this;
/*      */     }
/*      */     
/*      */     public Builder temporary(Boolean value) {
/* 1615 */       this.temporary_possible = Possible.of(value);
/* 1616 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("created_at")
/*      */     public Builder createdAt(Possible<String> value) {
/* 1621 */       this.createdAt_possible = value;
/* 1622 */       return this;
/*      */     }
/*      */     
/*      */     public Builder createdAt(String value) {
/* 1626 */       this.createdAt_possible = Possible.of(value);
/* 1627 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ImmutableInviteData build() {
/* 1636 */       if (this.initBits != 0L) {
/* 1637 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*      */       }
/* 1639 */       return new ImmutableInviteData(null, this.code, 
/*      */ 
/*      */           
/* 1642 */           guild_build(), this.channel, 
/*      */           
/* 1644 */           inviter_build(), 
/* 1645 */           targetType_build(), 
/* 1646 */           targetUser_build(), 
/* 1647 */           approximatePresenceCount_build(), 
/* 1648 */           approximateMemberCount_build(), 
/* 1649 */           expiresAt_build(), 
/* 1650 */           guildScheduledEvent_build(), 
/* 1651 */           uses_build(), 
/* 1652 */           maxUses_build(), 
/* 1653 */           maxAge_build(), 
/* 1654 */           temporary_build(), 
/* 1655 */           createdAt_build());
/*      */     }
/*      */     
/*      */     private String formatRequiredAttributesMessage() {
/* 1659 */       List<String> attributes = new ArrayList<>();
/* 1660 */       if ((this.initBits & 0x1L) != 0L) attributes.add("code"); 
/* 1661 */       if ((this.initBits & 0x2L) != 0L) attributes.add("channel"); 
/* 1662 */       return "Cannot build InviteData, some of required attributes are not set " + attributes;
/*      */     }
/*      */     
/*      */     private Possible<PartialGuildData> guild_build() {
/* 1666 */       return this.guild_possible;
/*      */     }
/*      */     
/*      */     private Possible<UserData> inviter_build() {
/* 1670 */       return this.inviter_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> targetType_build() {
/* 1674 */       return this.targetType_possible;
/*      */     }
/*      */     
/*      */     private Possible<UserData> targetUser_build() {
/* 1678 */       return this.targetUser_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> approximatePresenceCount_build() {
/* 1682 */       return this.approximatePresenceCount_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> approximateMemberCount_build() {
/* 1686 */       return this.approximateMemberCount_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<String>> expiresAt_build() {
/* 1690 */       return this.expiresAt_possible;
/*      */     }
/*      */     
/*      */     private Possible<GuildScheduledEventData> guildScheduledEvent_build() {
/* 1694 */       return this.guildScheduledEvent_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> uses_build() {
/* 1698 */       return this.uses_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> maxUses_build() {
/* 1702 */       return this.maxUses_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> maxAge_build() {
/* 1706 */       return this.maxAge_possible;
/*      */     }
/*      */     
/*      */     private Possible<Boolean> temporary_build() {
/* 1710 */       return this.temporary_possible;
/*      */     }
/*      */     
/*      */     private Possible<String> createdAt_build() {
/* 1714 */       return this.createdAt_possible;
/*      */     }
/*      */     
/*      */     private Builder() {}
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableInviteData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */