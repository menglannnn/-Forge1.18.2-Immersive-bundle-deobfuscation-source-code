/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ @JsonSerialize(as = ImmutableUpdateUserVoiceStateRequest.class)
/*    */ @JsonDeserialize(as = ImmutableUpdateUserVoiceStateRequest.class)
/*    */ @Immutable
/*    */ public interface UpdateUserVoiceStateRequest
/*    */ {
/*    */   static ImmutableUpdateUserVoiceStateRequest.Builder builder() {
/* 15 */     return ImmutableUpdateUserVoiceStateRequest.builder();
/*    */   }
/*    */   
/*    */   @JsonProperty("channel_id")
/*    */   String channelId();
/*    */   
/*    */   Possible<Boolean> suppress();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\UpdateUserVoiceStateRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */