/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.Id;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "FollowedChannelData", generator = "Immutables")
/*     */ public final class ImmutableFollowedChannelData
/*     */   implements FollowedChannelData
/*     */ {
/*     */   private final long channelId_value;
/*     */   private final long webhookId_value;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private ImmutableFollowedChannelData(Id channelId, Id webhookId) {
/*  29 */     Id channelId$impl = channelId;
/*  30 */     Id webhookId$impl = webhookId;
/*  31 */     this.channelId_value = channelId$impl.asLong();
/*  32 */     this.webhookId_value = webhookId$impl.asLong();
/*  33 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableFollowedChannelData(ImmutableFollowedChannelData original, Id channelId, Id webhookId) {
/*  40 */     Id channelId$impl = channelId;
/*  41 */     Id webhookId$impl = webhookId;
/*  42 */     this.channelId_value = channelId$impl.asLong();
/*  43 */     this.webhookId_value = webhookId$impl.asLong();
/*  44 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  50 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "FollowedChannelData", generator = "Immutables")
/*     */   private final class InitShim {
/*     */     private String formatInitCycleMessage() {
/*  55 */       List<String> attributes = new ArrayList<>();
/*  56 */       return "Cannot build FollowedChannelData, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @JsonProperty("channel_id")
/*     */   public Id channelId() {
/*  66 */     return Id.of(this.channelId_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("webhook_id")
/*     */   public Id webhookId() {
/*  75 */     return Id.of(this.webhookId_value);
/*     */   }
/*     */   
/*     */   public ImmutableFollowedChannelData withChannelId(long value) {
/*  79 */     Id newValue = Id.of(value);
/*  80 */     return new ImmutableFollowedChannelData(this, newValue, webhookId());
/*     */   }
/*     */   
/*     */   public ImmutableFollowedChannelData withChannelId(String value) {
/*  84 */     Id newValue = Id.of(value);
/*  85 */     return new ImmutableFollowedChannelData(this, newValue, webhookId());
/*     */   }
/*     */   
/*     */   public ImmutableFollowedChannelData withWebhookId(long value) {
/*  89 */     Id newValue = Id.of(value);
/*  90 */     return new ImmutableFollowedChannelData(this, channelId(), newValue);
/*     */   }
/*     */   
/*     */   public ImmutableFollowedChannelData withWebhookId(String value) {
/*  94 */     Id newValue = Id.of(value);
/*  95 */     return new ImmutableFollowedChannelData(this, channelId(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 104 */     if (this == another) return true; 
/* 105 */     return (another instanceof ImmutableFollowedChannelData && 
/* 106 */       equalTo(0, (ImmutableFollowedChannelData)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableFollowedChannelData another) {
/* 110 */     return (Objects.equals(Long.valueOf(this.channelId_value), Long.valueOf(another.channelId_value)) && 
/* 111 */       Objects.equals(Long.valueOf(this.webhookId_value), Long.valueOf(another.webhookId_value)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 120 */     int h = 5381;
/* 121 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.channelId_value));
/* 122 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.webhookId_value));
/* 123 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 132 */     return "FollowedChannelData{channelId=" + 
/* 133 */       Objects.toString(Long.valueOf(this.channelId_value)) + ", webhookId=" + 
/* 134 */       Objects.toString(Long.valueOf(this.webhookId_value)) + "}";
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "FollowedChannelData", generator = "Immutables")
/*     */   static final class Json
/*     */     implements FollowedChannelData
/*     */   {
/*     */     Id channelId;
/*     */     
/*     */     Id webhookId;
/*     */     
/*     */     @JsonProperty("channel_id")
/*     */     public void setChannelId(Id channelId) {
/* 151 */       this.channelId = channelId;
/*     */     }
/*     */     @JsonProperty("webhook_id")
/*     */     public void setWebhookId(Id webhookId) {
/* 155 */       this.webhookId = webhookId;
/*     */     }
/*     */     public Id channelId() {
/* 158 */       throw new UnsupportedOperationException();
/*     */     } public Id webhookId() {
/* 160 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableFollowedChannelData fromJson(Json json) {
/* 171 */     Builder builder = builder();
/* 172 */     if (json.channelId != null) {
/* 173 */       builder.channelId(json.channelId);
/*     */     }
/* 175 */     if (json.webhookId != null) {
/* 176 */       builder.webhookId(json.webhookId);
/*     */     }
/* 178 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableFollowedChannelData of(Id channelId, Id webhookId) {
/* 188 */     return new ImmutableFollowedChannelData(channelId, webhookId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableFollowedChannelData copyOf(FollowedChannelData instance) {
/* 199 */     if (instance instanceof ImmutableFollowedChannelData) {
/* 200 */       return (ImmutableFollowedChannelData)instance;
/*     */     }
/* 202 */     return builder()
/* 203 */       .from(instance)
/* 204 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 218 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "FollowedChannelData", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/* 230 */     private Id channelId_id = null;
/* 231 */     private Id webhookId_id = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(FollowedChannelData instance) {
/* 244 */       Objects.requireNonNull(instance, "instance");
/* 245 */       channelId(instance.channelId());
/* 246 */       webhookId(instance.webhookId());
/* 247 */       return this;
/*     */     }
/*     */     
/*     */     public Builder channelId(String value) {
/* 251 */       this.channelId_id = Id.of(value);
/* 252 */       return this;
/*     */     }
/*     */     
/*     */     public Builder channelId(long value) {
/* 256 */       this.channelId_id = Id.of(value);
/* 257 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("channel_id")
/*     */     public Builder channelId(Id value) {
/* 262 */       this.channelId_id = value;
/* 263 */       return this;
/*     */     }
/*     */     
/*     */     public Builder webhookId(String value) {
/* 267 */       this.webhookId_id = Id.of(value);
/* 268 */       return this;
/*     */     }
/*     */     
/*     */     public Builder webhookId(long value) {
/* 272 */       this.webhookId_id = Id.of(value);
/* 273 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("webhook_id")
/*     */     public Builder webhookId(Id value) {
/* 278 */       this.webhookId_id = value;
/* 279 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableFollowedChannelData build() {
/* 288 */       return new ImmutableFollowedChannelData(null, channelId_build(), webhookId_build());
/*     */     }
/*     */     
/*     */     private Id channelId_build() {
/* 292 */       return this.channelId_id;
/*     */     }
/*     */     
/*     */     private Id webhookId_build() {
/* 296 */       return this.webhookId_id;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableFollowedChannelData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */