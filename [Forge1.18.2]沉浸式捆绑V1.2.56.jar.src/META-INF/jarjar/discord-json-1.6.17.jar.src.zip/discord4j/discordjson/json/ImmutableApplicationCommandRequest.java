/*      */ package discord4j.discordjson.json;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*      */ import com.fasterxml.jackson.annotation.JsonCreator;
/*      */ import com.fasterxml.jackson.annotation.JsonProperty;
/*      */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*      */ import discord4j.discordjson.possible.Possible;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Objects;
/*      */ import java.util.Optional;
/*      */ import java.util.stream.Collectors;
/*      */ import java.util.stream.StreamSupport;
/*      */ import org.immutables.value.Generated;
/*      */ import reactor.util.annotation.Nullable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Generated(from = "ApplicationCommandRequest", generator = "Immutables")
/*      */ public final class ImmutableApplicationCommandRequest
/*      */   implements ApplicationCommandRequest
/*      */ {
/*      */   private final String name;
/*      */   private final Map<String, String> nameLocalizations_value;
/*      */   private final boolean nameLocalizations_absent;
/*      */   private final String description_value;
/*      */   private final boolean description_absent;
/*      */   private final Map<String, String> descriptionLocalizations_value;
/*      */   private final boolean descriptionLocalizations_absent;
/*      */   private final List<ApplicationCommandOptionData> options_value;
/*      */   private final boolean options_absent;
/*      */   private final Boolean dmPermission_value;
/*      */   private final boolean dmPermission_absent;
/*      */   private final Boolean defaultPermission_value;
/*      */   private final boolean defaultPermission_absent;
/*      */   private final String defaultMemberPermissions;
/*      */   private final Integer type_value;
/*      */   private final boolean type_absent;
/*      */   private static final byte STAGE_INITIALIZING = -1;
/*      */   private static final byte STAGE_UNINITIALIZED = 0;
/*      */   private static final byte STAGE_INITIALIZED = 1;
/*      */   private volatile transient InitShim initShim;
/*      */   
/*      */   private ImmutableApplicationCommandRequest(String name, Possible<Optional<Map<String, String>>> nameLocalizations, Possible<String> description, Possible<Optional<Map<String, String>>> descriptionLocalizations, Possible<List<ApplicationCommandOptionData>> options, Possible<Boolean> dmPermission, Possible<Boolean> defaultPermission, Optional<String> defaultMemberPermissions, Possible<Integer> type) {
/*  125 */     this.initShim = new InitShim(); this.name = Objects.<String>requireNonNull(name, "name"); Possible<Optional<Map<String, String>>> nameLocalizations$impl = nameLocalizations; Possible<String> description$impl = description; Possible<Optional<Map<String, String>>> descriptionLocalizations$impl = descriptionLocalizations; Possible<List<ApplicationCommandOptionData>> options$impl = options; Possible<Boolean> dmPermission$impl = dmPermission; Possible<Boolean> defaultPermission$impl = defaultPermission; this.defaultMemberPermissions = defaultMemberPermissions.orElse(null); Possible<Integer> type$impl = type; this.nameLocalizations_value = Possible.flatOpt(nameLocalizations$impl).orElse(null); this.nameLocalizations_absent = nameLocalizations$impl.isAbsent(); this.description_value = description$impl.toOptional().orElse(null); this.description_absent = description$impl.isAbsent(); this.descriptionLocalizations_value = Possible.flatOpt(descriptionLocalizations$impl).orElse(null); this.descriptionLocalizations_absent = descriptionLocalizations$impl.isAbsent(); this.options_value = options$impl.toOptional().orElse(null); this.options_absent = options$impl.isAbsent(); this.dmPermission_value = dmPermission$impl.toOptional().orElse(null); this.dmPermission_absent = dmPermission$impl.isAbsent(); this.defaultPermission_value = defaultPermission$impl.toOptional().orElse(null); this.defaultPermission_absent = defaultPermission$impl.isAbsent(); this.type_value = type$impl.toOptional().orElse(null); this.type_absent = type$impl.isAbsent(); this.initShim = null; } private ImmutableApplicationCommandRequest(ImmutableApplicationCommandRequest original, String name, Possible<Optional<Map<String, String>>> nameLocalizations, Possible<String> description, Possible<Optional<Map<String, String>>> descriptionLocalizations, Possible<List<ApplicationCommandOptionData>> options, Possible<Boolean> dmPermission, Possible<Boolean> defaultPermission, String defaultMemberPermissions, Possible<Integer> type) { this.initShim = new InitShim(); this.name = name; Possible<Optional<Map<String, String>>> nameLocalizations$impl = nameLocalizations; Possible<String> description$impl = description; Possible<Optional<Map<String, String>>> descriptionLocalizations$impl = descriptionLocalizations; Possible<List<ApplicationCommandOptionData>> options$impl = options; Possible<Boolean> dmPermission$impl = dmPermission; Possible<Boolean> defaultPermission$impl = defaultPermission; this.defaultMemberPermissions = defaultMemberPermissions; Possible<Integer> type$impl = type; this.nameLocalizations_value = Possible.flatOpt(nameLocalizations$impl).orElse(null); this.nameLocalizations_absent = nameLocalizations$impl.isAbsent(); this.description_value = description$impl.toOptional().orElse(null); this.description_absent = description$impl.isAbsent(); this.descriptionLocalizations_value = Possible.flatOpt(descriptionLocalizations$impl).orElse(null); this.descriptionLocalizations_absent = descriptionLocalizations$impl.isAbsent(); this.options_value = options$impl.toOptional().orElse(null); this.options_absent = options$impl.isAbsent(); this.dmPermission_value = dmPermission$impl.toOptional().orElse(null); this.dmPermission_absent = dmPermission$impl.isAbsent();
/*      */     this.defaultPermission_value = defaultPermission$impl.toOptional().orElse(null);
/*      */     this.defaultPermission_absent = defaultPermission$impl.isAbsent();
/*      */     this.type_value = type$impl.toOptional().orElse(null);
/*      */     this.type_absent = type$impl.isAbsent();
/*  130 */     this.initShim = null; } @Generated(from = "ApplicationCommandRequest", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/*  131 */       return "Cannot build ApplicationCommandRequest, attribute initializers form cycle " + attributes; }
/*      */      }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("name")
/*      */   public String name() {
/*  142 */     return this.name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("name_localizations")
/*      */   public Possible<Optional<Map<String, String>>> nameLocalizations() {
/*  151 */     return this.nameLocalizations_absent ? Possible.absent() : 
/*  152 */       Possible.of(Optional.ofNullable(this.nameLocalizations_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("description")
/*      */   public Possible<String> description() {
/*  161 */     return this.description_absent ? Possible.absent() : Possible.of(this.description_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("description_localizations")
/*      */   public Possible<Optional<Map<String, String>>> descriptionLocalizations() {
/*  170 */     return this.descriptionLocalizations_absent ? Possible.absent() : 
/*  171 */       Possible.of(Optional.ofNullable(this.descriptionLocalizations_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("options")
/*      */   public Possible<List<ApplicationCommandOptionData>> options() {
/*  180 */     return this.options_absent ? Possible.absent() : 
/*  181 */       Possible.of(this.options_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("dm_permission")
/*      */   public Possible<Boolean> dmPermission() {
/*  190 */     return this.dmPermission_absent ? Possible.absent() : Possible.of(this.dmPermission_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("default_permission")
/*      */   public Possible<Boolean> defaultPermission() {
/*  199 */     return this.defaultPermission_absent ? Possible.absent() : Possible.of(this.defaultPermission_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("default_member_permissions")
/*      */   public Optional<String> defaultMemberPermissions() {
/*  208 */     return Optional.ofNullable(this.defaultMemberPermissions);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("type")
/*      */   public Possible<Integer> type() {
/*  217 */     return this.type_absent ? Possible.absent() : Possible.of(this.type_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableApplicationCommandRequest withName(String value) {
/*  227 */     String newValue = Objects.<String>requireNonNull(value, "name");
/*  228 */     if (this.name.equals(newValue)) return this; 
/*  229 */     return new ImmutableApplicationCommandRequest(this, newValue, 
/*      */ 
/*      */         
/*  232 */         nameLocalizations(), 
/*  233 */         description(), 
/*  234 */         descriptionLocalizations(), 
/*  235 */         options(), 
/*  236 */         dmPermission(), 
/*  237 */         defaultPermission(), this.defaultMemberPermissions, 
/*      */         
/*  239 */         type());
/*      */   }
/*      */   
/*      */   public ImmutableApplicationCommandRequest withNameLocalizations(Possible<Optional<Map<String, String>>> value) {
/*  243 */     Possible<Optional<Map<String, String>>> newValue = Objects.<Possible<Optional<Map<String, String>>>>requireNonNull(value);
/*  244 */     return new ImmutableApplicationCommandRequest(this, this.name, newValue, 
/*      */ 
/*      */ 
/*      */         
/*  248 */         description(), 
/*  249 */         descriptionLocalizations(), 
/*  250 */         options(), 
/*  251 */         dmPermission(), 
/*  252 */         defaultPermission(), this.defaultMemberPermissions, 
/*      */         
/*  254 */         type());
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableApplicationCommandRequest withNameLocalizations(@Nullable Map<String, String> value) {
/*  259 */     Possible<Optional<Map<String, String>>> newValue = Possible.of(Optional.ofNullable(value));
/*  260 */     return new ImmutableApplicationCommandRequest(this, this.name, newValue, 
/*      */ 
/*      */ 
/*      */         
/*  264 */         description(), 
/*  265 */         descriptionLocalizations(), 
/*  266 */         options(), 
/*  267 */         dmPermission(), 
/*  268 */         defaultPermission(), this.defaultMemberPermissions, 
/*      */         
/*  270 */         type());
/*      */   }
/*      */   
/*      */   public ImmutableApplicationCommandRequest withNameLocalizationsOrNull(@Nullable Map<String, String> value) {
/*  274 */     Possible<Optional<Map<String, String>>> newValue = Possible.of(Optional.ofNullable(value));
/*  275 */     return new ImmutableApplicationCommandRequest(this, this.name, newValue, 
/*      */ 
/*      */ 
/*      */         
/*  279 */         description(), 
/*  280 */         descriptionLocalizations(), 
/*  281 */         options(), 
/*  282 */         dmPermission(), 
/*  283 */         defaultPermission(), this.defaultMemberPermissions, 
/*      */         
/*  285 */         type());
/*      */   }
/*      */   
/*      */   public ImmutableApplicationCommandRequest withDescription(Possible<String> value) {
/*  289 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  290 */     return new ImmutableApplicationCommandRequest(this, this.name, 
/*      */ 
/*      */         
/*  293 */         nameLocalizations(), newValue, 
/*      */         
/*  295 */         descriptionLocalizations(), 
/*  296 */         options(), 
/*  297 */         dmPermission(), 
/*  298 */         defaultPermission(), this.defaultMemberPermissions, 
/*      */         
/*  300 */         type());
/*      */   }
/*      */   
/*      */   public ImmutableApplicationCommandRequest withDescription(String value) {
/*  304 */     Possible<String> newValue = Possible.of(value);
/*  305 */     return new ImmutableApplicationCommandRequest(this, this.name, 
/*      */ 
/*      */         
/*  308 */         nameLocalizations(), newValue, 
/*      */         
/*  310 */         descriptionLocalizations(), 
/*  311 */         options(), 
/*  312 */         dmPermission(), 
/*  313 */         defaultPermission(), this.defaultMemberPermissions, 
/*      */         
/*  315 */         type());
/*      */   }
/*      */   
/*      */   public ImmutableApplicationCommandRequest withDescriptionLocalizations(Possible<Optional<Map<String, String>>> value) {
/*  319 */     Possible<Optional<Map<String, String>>> newValue = Objects.<Possible<Optional<Map<String, String>>>>requireNonNull(value);
/*  320 */     return new ImmutableApplicationCommandRequest(this, this.name, 
/*      */ 
/*      */         
/*  323 */         nameLocalizations(), 
/*  324 */         description(), newValue, 
/*      */         
/*  326 */         options(), 
/*  327 */         dmPermission(), 
/*  328 */         defaultPermission(), this.defaultMemberPermissions, 
/*      */         
/*  330 */         type());
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableApplicationCommandRequest withDescriptionLocalizations(@Nullable Map<String, String> value) {
/*  335 */     Possible<Optional<Map<String, String>>> newValue = Possible.of(Optional.ofNullable(value));
/*  336 */     return new ImmutableApplicationCommandRequest(this, this.name, 
/*      */ 
/*      */         
/*  339 */         nameLocalizations(), 
/*  340 */         description(), newValue, 
/*      */         
/*  342 */         options(), 
/*  343 */         dmPermission(), 
/*  344 */         defaultPermission(), this.defaultMemberPermissions, 
/*      */         
/*  346 */         type());
/*      */   }
/*      */   
/*      */   public ImmutableApplicationCommandRequest withDescriptionLocalizationsOrNull(@Nullable Map<String, String> value) {
/*  350 */     Possible<Optional<Map<String, String>>> newValue = Possible.of(Optional.ofNullable(value));
/*  351 */     return new ImmutableApplicationCommandRequest(this, this.name, 
/*      */ 
/*      */         
/*  354 */         nameLocalizations(), 
/*  355 */         description(), newValue, 
/*      */         
/*  357 */         options(), 
/*  358 */         dmPermission(), 
/*  359 */         defaultPermission(), this.defaultMemberPermissions, 
/*      */         
/*  361 */         type());
/*      */   }
/*      */   
/*      */   public ImmutableApplicationCommandRequest withOptions(Possible<List<ApplicationCommandOptionData>> possible) {
/*  365 */     Possible<List<ApplicationCommandOptionData>> newValue = Objects.<Possible<List<ApplicationCommandOptionData>>>requireNonNull(possible);
/*  366 */     return new ImmutableApplicationCommandRequest(this, this.name, 
/*      */ 
/*      */         
/*  369 */         nameLocalizations(), 
/*  370 */         description(), 
/*  371 */         descriptionLocalizations(), newValue, 
/*      */         
/*  373 */         dmPermission(), 
/*  374 */         defaultPermission(), this.defaultMemberPermissions, 
/*      */         
/*  376 */         type());
/*      */   }
/*      */   
/*      */   public ImmutableApplicationCommandRequest withOptions(Iterable<ApplicationCommandOptionData> elements) {
/*  380 */     Possible<List<ApplicationCommandOptionData>> newValue = Possible.of(
/*  381 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/*  382 */     return new ImmutableApplicationCommandRequest(this, this.name, 
/*      */ 
/*      */         
/*  385 */         nameLocalizations(), 
/*  386 */         description(), 
/*  387 */         descriptionLocalizations(), newValue, 
/*      */         
/*  389 */         dmPermission(), 
/*  390 */         defaultPermission(), this.defaultMemberPermissions, 
/*      */         
/*  392 */         type());
/*      */   }
/*      */   
/*      */   @SafeVarargs
/*      */   public final ImmutableApplicationCommandRequest withOptions(ApplicationCommandOptionData... elements) {
/*  397 */     Possible<List<ApplicationCommandOptionData>> newValue = Possible.of(Arrays.asList(elements));
/*  398 */     return new ImmutableApplicationCommandRequest(this, this.name, 
/*      */ 
/*      */         
/*  401 */         nameLocalizations(), 
/*  402 */         description(), 
/*  403 */         descriptionLocalizations(), newValue, 
/*      */         
/*  405 */         dmPermission(), 
/*  406 */         defaultPermission(), this.defaultMemberPermissions, 
/*      */         
/*  408 */         type());
/*      */   }
/*      */   
/*      */   public ImmutableApplicationCommandRequest withDmPermission(Possible<Boolean> value) {
/*  412 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/*  413 */     return new ImmutableApplicationCommandRequest(this, this.name, 
/*      */ 
/*      */         
/*  416 */         nameLocalizations(), 
/*  417 */         description(), 
/*  418 */         descriptionLocalizations(), 
/*  419 */         options(), newValue, 
/*      */         
/*  421 */         defaultPermission(), this.defaultMemberPermissions, 
/*      */         
/*  423 */         type());
/*      */   }
/*      */   
/*      */   public ImmutableApplicationCommandRequest withDmPermission(Boolean value) {
/*  427 */     Possible<Boolean> newValue = Possible.of(value);
/*  428 */     return new ImmutableApplicationCommandRequest(this, this.name, 
/*      */ 
/*      */         
/*  431 */         nameLocalizations(), 
/*  432 */         description(), 
/*  433 */         descriptionLocalizations(), 
/*  434 */         options(), newValue, 
/*      */         
/*  436 */         defaultPermission(), this.defaultMemberPermissions, 
/*      */         
/*  438 */         type());
/*      */   }
/*      */   
/*      */   public ImmutableApplicationCommandRequest withDefaultPermission(Possible<Boolean> value) {
/*  442 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/*  443 */     return new ImmutableApplicationCommandRequest(this, this.name, 
/*      */ 
/*      */         
/*  446 */         nameLocalizations(), 
/*  447 */         description(), 
/*  448 */         descriptionLocalizations(), 
/*  449 */         options(), 
/*  450 */         dmPermission(), newValue, this.defaultMemberPermissions, 
/*      */ 
/*      */         
/*  453 */         type());
/*      */   }
/*      */   
/*      */   public ImmutableApplicationCommandRequest withDefaultPermission(Boolean value) {
/*  457 */     Possible<Boolean> newValue = Possible.of(value);
/*  458 */     return new ImmutableApplicationCommandRequest(this, this.name, 
/*      */ 
/*      */         
/*  461 */         nameLocalizations(), 
/*  462 */         description(), 
/*  463 */         descriptionLocalizations(), 
/*  464 */         options(), 
/*  465 */         dmPermission(), newValue, this.defaultMemberPermissions, 
/*      */ 
/*      */         
/*  468 */         type());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableApplicationCommandRequest withDefaultMemberPermissions(String value) {
/*  477 */     String newValue = Objects.<String>requireNonNull(value, "defaultMemberPermissions");
/*  478 */     if (Objects.equals(this.defaultMemberPermissions, newValue)) return this; 
/*  479 */     return new ImmutableApplicationCommandRequest(this, this.name, 
/*      */ 
/*      */         
/*  482 */         nameLocalizations(), 
/*  483 */         description(), 
/*  484 */         descriptionLocalizations(), 
/*  485 */         options(), 
/*  486 */         dmPermission(), 
/*  487 */         defaultPermission(), newValue, 
/*      */         
/*  489 */         type());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableApplicationCommandRequest withDefaultMemberPermissions(Optional<String> optional) {
/*  499 */     String value = optional.orElse(null);
/*  500 */     if (Objects.equals(this.defaultMemberPermissions, value)) return this; 
/*  501 */     return new ImmutableApplicationCommandRequest(this, this.name, 
/*      */ 
/*      */         
/*  504 */         nameLocalizations(), 
/*  505 */         description(), 
/*  506 */         descriptionLocalizations(), 
/*  507 */         options(), 
/*  508 */         dmPermission(), 
/*  509 */         defaultPermission(), value, 
/*      */         
/*  511 */         type());
/*      */   }
/*      */   
/*      */   public ImmutableApplicationCommandRequest withType(Possible<Integer> value) {
/*  515 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/*  516 */     return new ImmutableApplicationCommandRequest(this, this.name, 
/*      */ 
/*      */         
/*  519 */         nameLocalizations(), 
/*  520 */         description(), 
/*  521 */         descriptionLocalizations(), 
/*  522 */         options(), 
/*  523 */         dmPermission(), 
/*  524 */         defaultPermission(), this.defaultMemberPermissions, newValue);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableApplicationCommandRequest withType(Integer value) {
/*  530 */     Possible<Integer> newValue = Possible.of(value);
/*  531 */     return new ImmutableApplicationCommandRequest(this, this.name, 
/*      */ 
/*      */         
/*  534 */         nameLocalizations(), 
/*  535 */         description(), 
/*  536 */         descriptionLocalizations(), 
/*  537 */         options(), 
/*  538 */         dmPermission(), 
/*  539 */         defaultPermission(), this.defaultMemberPermissions, newValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object another) {
/*  550 */     if (this == another) return true; 
/*  551 */     return (another instanceof ImmutableApplicationCommandRequest && 
/*  552 */       equalTo(0, (ImmutableApplicationCommandRequest)another));
/*      */   }
/*      */   
/*      */   private boolean equalTo(int synthetic, ImmutableApplicationCommandRequest another) {
/*  556 */     return (this.name.equals(another.name) && 
/*  557 */       nameLocalizations().equals(another.nameLocalizations()) && 
/*  558 */       description().equals(another.description()) && 
/*  559 */       descriptionLocalizations().equals(another.descriptionLocalizations()) && 
/*  560 */       Objects.equals(this.options_value, another.options_value) && 
/*  561 */       dmPermission().equals(another.dmPermission()) && 
/*  562 */       defaultPermission().equals(another.defaultPermission()) && 
/*  563 */       Objects.equals(this.defaultMemberPermissions, another.defaultMemberPermissions) && 
/*  564 */       type().equals(another.type()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/*  573 */     int h = 5381;
/*  574 */     h += (h << 5) + this.name.hashCode();
/*  575 */     h += (h << 5) + nameLocalizations().hashCode();
/*  576 */     h += (h << 5) + description().hashCode();
/*  577 */     h += (h << 5) + descriptionLocalizations().hashCode();
/*  578 */     h += (h << 5) + Objects.hashCode(this.options_value);
/*  579 */     h += (h << 5) + dmPermission().hashCode();
/*  580 */     h += (h << 5) + defaultPermission().hashCode();
/*  581 */     h += (h << 5) + Objects.hashCode(this.defaultMemberPermissions);
/*  582 */     h += (h << 5) + type().hashCode();
/*  583 */     return h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*  592 */     StringBuilder builder = new StringBuilder("ApplicationCommandRequest{");
/*  593 */     builder.append("name=").append(this.name);
/*  594 */     builder.append(", ");
/*  595 */     builder.append("nameLocalizations=").append(nameLocalizations().toString());
/*  596 */     builder.append(", ");
/*  597 */     builder.append("description=").append(description().toString());
/*  598 */     builder.append(", ");
/*  599 */     builder.append("descriptionLocalizations=").append(descriptionLocalizations().toString());
/*  600 */     builder.append(", ");
/*  601 */     builder.append("options=").append(Objects.toString(this.options_value));
/*  602 */     builder.append(", ");
/*  603 */     builder.append("dmPermission=").append(dmPermission().toString());
/*  604 */     builder.append(", ");
/*  605 */     builder.append("defaultPermission=").append(defaultPermission().toString());
/*  606 */     if (this.defaultMemberPermissions != null) {
/*  607 */       builder.append(", ");
/*  608 */       builder.append("defaultMemberPermissions=").append(this.defaultMemberPermissions);
/*      */     } 
/*  610 */     builder.append(", ");
/*  611 */     builder.append("type=").append(type().toString());
/*  612 */     return builder.append("}").toString();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonDeserialize
/*      */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*      */   @Generated(from = "ApplicationCommandRequest", generator = "Immutables")
/*      */   static final class Json
/*      */     implements ApplicationCommandRequest
/*      */   {
/*      */     String name;
/*      */     
/*  626 */     Possible<Optional<Map<String, String>>> nameLocalizations = Possible.absent();
/*      */ 
/*      */     
/*  629 */     Possible<String> description = Possible.absent();
/*      */ 
/*      */     
/*  632 */     Possible<Optional<Map<String, String>>> descriptionLocalizations = Possible.absent();
/*      */ 
/*      */     
/*  635 */     Possible<List<ApplicationCommandOptionData>> options = Possible.absent();
/*      */ 
/*      */     
/*  638 */     Possible<Boolean> dmPermission = Possible.absent();
/*      */ 
/*      */     
/*  641 */     Possible<Boolean> defaultPermission = Possible.absent();
/*      */     
/*  643 */     Optional<String> defaultMemberPermissions = Optional.empty();
/*      */     
/*  645 */     Possible<Integer> type = Possible.absent();
/*      */     
/*      */     @JsonProperty("name")
/*      */     public void setName(String name) {
/*  649 */       this.name = name;
/*      */     }
/*      */     @JsonProperty("name_localizations")
/*      */     public void setNameLocalizations(Possible<Optional<Map<String, String>>> nameLocalizations) {
/*  653 */       this.nameLocalizations = nameLocalizations;
/*      */     }
/*      */     @JsonProperty("description")
/*      */     public void setDescription(Possible<String> description) {
/*  657 */       this.description = description;
/*      */     }
/*      */     @JsonProperty("description_localizations")
/*      */     public void setDescriptionLocalizations(Possible<Optional<Map<String, String>>> descriptionLocalizations) {
/*  661 */       this.descriptionLocalizations = descriptionLocalizations;
/*      */     }
/*      */     @JsonProperty("options")
/*      */     public void setOptions(Possible<List<ApplicationCommandOptionData>> options) {
/*  665 */       this.options = options;
/*      */     }
/*      */     @JsonProperty("dm_permission")
/*      */     public void setDmPermission(Possible<Boolean> dmPermission) {
/*  669 */       this.dmPermission = dmPermission;
/*      */     }
/*      */     @JsonProperty("default_permission")
/*      */     public void setDefaultPermission(Possible<Boolean> defaultPermission) {
/*  673 */       this.defaultPermission = defaultPermission;
/*      */     }
/*      */     @JsonProperty("default_member_permissions")
/*      */     public void setDefaultMemberPermissions(Optional<String> defaultMemberPermissions) {
/*  677 */       this.defaultMemberPermissions = defaultMemberPermissions;
/*      */     }
/*      */     @JsonProperty("type")
/*      */     public void setType(Possible<Integer> type) {
/*  681 */       this.type = type;
/*      */     }
/*      */     public String name() {
/*  684 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<Map<String, String>>> nameLocalizations() {
/*  686 */       throw new UnsupportedOperationException();
/*      */     } public Possible<String> description() {
/*  688 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<Map<String, String>>> descriptionLocalizations() {
/*  690 */       throw new UnsupportedOperationException();
/*      */     } public Possible<List<ApplicationCommandOptionData>> options() {
/*  692 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Boolean> dmPermission() {
/*  694 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Boolean> defaultPermission() {
/*  696 */       throw new UnsupportedOperationException();
/*      */     } public Optional<String> defaultMemberPermissions() {
/*  698 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> type() {
/*  700 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*      */   static ImmutableApplicationCommandRequest fromJson(Json json) {
/*  711 */     Builder builder = builder();
/*  712 */     if (json.name != null) {
/*  713 */       builder.name(json.name);
/*      */     }
/*  715 */     if (json.nameLocalizations != null) {
/*  716 */       builder.nameLocalizations(json.nameLocalizations);
/*      */     }
/*  718 */     if (json.description != null) {
/*  719 */       builder.description(json.description);
/*      */     }
/*  721 */     if (json.descriptionLocalizations != null) {
/*  722 */       builder.descriptionLocalizations(json.descriptionLocalizations);
/*      */     }
/*  724 */     if (json.options != null) {
/*  725 */       builder.options(json.options);
/*      */     }
/*  727 */     if (json.dmPermission != null) {
/*  728 */       builder.dmPermission(json.dmPermission);
/*      */     }
/*  730 */     if (json.defaultPermission != null) {
/*  731 */       builder.defaultPermission(json.defaultPermission);
/*      */     }
/*  733 */     if (json.defaultMemberPermissions != null) {
/*  734 */       builder.defaultMemberPermissions(json.defaultMemberPermissions);
/*      */     }
/*  736 */     if (json.type != null) {
/*  737 */       builder.type(json.type);
/*      */     }
/*  739 */     return builder.build();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableApplicationCommandRequest of(String name, Possible<Optional<Map<String, String>>> nameLocalizations, Possible<String> description, Possible<Optional<Map<String, String>>> descriptionLocalizations, Possible<List<ApplicationCommandOptionData>> options, Possible<Boolean> dmPermission, Possible<Boolean> defaultPermission, Optional<String> defaultMemberPermissions, Possible<Integer> type) {
/*  756 */     return new ImmutableApplicationCommandRequest(name, nameLocalizations, description, descriptionLocalizations, options, dmPermission, defaultPermission, defaultMemberPermissions, type);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableApplicationCommandRequest copyOf(ApplicationCommandRequest instance) {
/*  767 */     if (instance instanceof ImmutableApplicationCommandRequest) {
/*  768 */       return (ImmutableApplicationCommandRequest)instance;
/*      */     }
/*  770 */     return builder()
/*  771 */       .from(instance)
/*  772 */       .build();
/*      */   }
/*      */   
/*      */   public boolean isNameLocalizationsPresent() {
/*  776 */     return !this.nameLocalizations_absent;
/*      */   }
/*      */   
/*      */   public Map<String, String> nameLocalizationsOrElse(Map<String, String> defaultValue) {
/*  780 */     return !this.nameLocalizations_absent ? this.nameLocalizations_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isDescriptionPresent() {
/*  784 */     return !this.description_absent;
/*      */   }
/*      */   
/*      */   public String descriptionOrElse(String defaultValue) {
/*  788 */     return !this.description_absent ? this.description_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isDescriptionLocalizationsPresent() {
/*  792 */     return !this.descriptionLocalizations_absent;
/*      */   }
/*      */   
/*      */   public Map<String, String> descriptionLocalizationsOrElse(Map<String, String> defaultValue) {
/*  796 */     return !this.descriptionLocalizations_absent ? this.descriptionLocalizations_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isOptionsPresent() {
/*  800 */     return !this.options_absent;
/*      */   }
/*      */   
/*      */   public List<ApplicationCommandOptionData> optionsOrElse(List<ApplicationCommandOptionData> defaultValue) {
/*  804 */     return !this.options_absent ? this.options_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isDmPermissionPresent() {
/*  808 */     return !this.dmPermission_absent;
/*      */   }
/*      */   
/*      */   public Boolean dmPermissionOrElse(Boolean defaultValue) {
/*  812 */     return !this.dmPermission_absent ? this.dmPermission_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isDefaultPermissionPresent() {
/*  816 */     return !this.defaultPermission_absent;
/*      */   }
/*      */   
/*      */   public Boolean defaultPermissionOrElse(Boolean defaultValue) {
/*  820 */     return !this.defaultPermission_absent ? this.defaultPermission_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isTypePresent() {
/*  824 */     return !this.type_absent;
/*      */   }
/*      */   
/*      */   public Integer typeOrElse(Integer defaultValue) {
/*  828 */     return !this.type_absent ? this.type_value : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Builder builder() {
/*  849 */     return new Builder();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Generated(from = "ApplicationCommandRequest", generator = "Immutables")
/*      */   public static final class Builder
/*      */   {
/*      */     private static final long INIT_BIT_NAME = 1L;
/*      */ 
/*      */ 
/*      */     
/*  862 */     private long initBits = 1L;
/*      */     
/*  864 */     private Possible<Optional<Map<String, String>>> nameLocalizations_possible = Possible.absent();
/*  865 */     private Possible<String> description_possible = Possible.absent();
/*  866 */     private Possible<Optional<Map<String, String>>> descriptionLocalizations_possible = Possible.absent();
/*  867 */     private List<ApplicationCommandOptionData> options_list = null;
/*  868 */     private Possible<Boolean> dmPermission_possible = Possible.absent();
/*  869 */     private Possible<Boolean> defaultPermission_possible = Possible.absent();
/*  870 */     private Possible<Integer> type_possible = Possible.absent();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private String name;
/*      */ 
/*      */ 
/*      */     
/*      */     private String defaultMemberPermissions;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(ApplicationCommandRequest instance) {
/*  885 */       Objects.requireNonNull(instance, "instance");
/*  886 */       name(instance.name());
/*  887 */       nameLocalizations(instance.nameLocalizations());
/*  888 */       description(instance.description());
/*  889 */       descriptionLocalizations(instance.descriptionLocalizations());
/*  890 */       options(instance.options());
/*  891 */       dmPermission(instance.dmPermission());
/*  892 */       defaultPermission(instance.defaultPermission());
/*  893 */       Optional<String> defaultMemberPermissionsOptional = instance.defaultMemberPermissions();
/*  894 */       if (defaultMemberPermissionsOptional.isPresent()) {
/*  895 */         defaultMemberPermissions(defaultMemberPermissionsOptional);
/*      */       }
/*  897 */       type(instance.type());
/*  898 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("name")
/*      */     public final Builder name(String name) {
/*  908 */       this.name = Objects.<String>requireNonNull(name, "name");
/*  909 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/*  910 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("name_localizations")
/*      */     public Builder nameLocalizations(Possible<Optional<Map<String, String>>> value) {
/*  915 */       this.nameLocalizations_possible = value;
/*  916 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder nameLocalizations(@Nullable Map<String, String> value) {
/*  921 */       this.nameLocalizations_possible = Possible.of(Optional.ofNullable(value));
/*  922 */       return this;
/*      */     }
/*      */     
/*      */     public Builder nameLocalizationsOrNull(@Nullable Map<String, String> value) {
/*  926 */       this.nameLocalizations_possible = Possible.of(Optional.ofNullable(value));
/*  927 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("description")
/*      */     public Builder description(Possible<String> value) {
/*  932 */       this.description_possible = value;
/*  933 */       return this;
/*      */     }
/*      */     
/*      */     public Builder description(String value) {
/*  937 */       this.description_possible = Possible.of(value);
/*  938 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("description_localizations")
/*      */     public Builder descriptionLocalizations(Possible<Optional<Map<String, String>>> value) {
/*  943 */       this.descriptionLocalizations_possible = value;
/*  944 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder descriptionLocalizations(@Nullable Map<String, String> value) {
/*  949 */       this.descriptionLocalizations_possible = Possible.of(Optional.ofNullable(value));
/*  950 */       return this;
/*      */     }
/*      */     
/*      */     public Builder descriptionLocalizationsOrNull(@Nullable Map<String, String> value) {
/*  954 */       this.descriptionLocalizations_possible = Possible.of(Optional.ofNullable(value));
/*  955 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addOption(ApplicationCommandOptionData element) {
/*  959 */       options_getOrCreate().add(element);
/*  960 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addAllOptions(List<ApplicationCommandOptionData> elements) {
/*  964 */       options_getOrCreate().addAll(elements);
/*  965 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("options")
/*      */     public Builder options(Possible<List<ApplicationCommandOptionData>> elements) {
/*  970 */       this.options_list = null;
/*  971 */       elements.toOptional().ifPresent(e -> options_getOrCreate().addAll(e));
/*  972 */       return this;
/*      */     }
/*      */     
/*      */     public Builder options(List<ApplicationCommandOptionData> elements) {
/*  976 */       this.options_list = new ArrayList<>(elements);
/*  977 */       return this;
/*      */     }
/*      */     
/*      */     public Builder options(Iterable<ApplicationCommandOptionData> elements) {
/*  981 */       this.options_list = (List<ApplicationCommandOptionData>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/*  982 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("dm_permission")
/*      */     public Builder dmPermission(Possible<Boolean> value) {
/*  987 */       this.dmPermission_possible = value;
/*  988 */       return this;
/*      */     }
/*      */     
/*      */     public Builder dmPermission(Boolean value) {
/*  992 */       this.dmPermission_possible = Possible.of(value);
/*  993 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("default_permission")
/*      */     public Builder defaultPermission(Possible<Boolean> value) {
/*  998 */       this.defaultPermission_possible = value;
/*  999 */       return this;
/*      */     }
/*      */     
/*      */     public Builder defaultPermission(Boolean value) {
/* 1003 */       this.defaultPermission_possible = Possible.of(value);
/* 1004 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder defaultMemberPermissions(String defaultMemberPermissions) {
/* 1013 */       this.defaultMemberPermissions = Objects.<String>requireNonNull(defaultMemberPermissions, "defaultMemberPermissions");
/* 1014 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("default_member_permissions")
/*      */     public final Builder defaultMemberPermissions(Optional<String> defaultMemberPermissions) {
/* 1024 */       this.defaultMemberPermissions = defaultMemberPermissions.orElse(null);
/* 1025 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("type")
/*      */     public Builder type(Possible<Integer> value) {
/* 1030 */       this.type_possible = value;
/* 1031 */       return this;
/*      */     }
/*      */     
/*      */     public Builder type(Integer value) {
/* 1035 */       this.type_possible = Possible.of(value);
/* 1036 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ImmutableApplicationCommandRequest build() {
/* 1045 */       if (this.initBits != 0L) {
/* 1046 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*      */       }
/* 1048 */       return new ImmutableApplicationCommandRequest(null, this.name, 
/*      */ 
/*      */           
/* 1051 */           nameLocalizations_build(), 
/* 1052 */           description_build(), 
/* 1053 */           descriptionLocalizations_build(), 
/* 1054 */           options_build(), 
/* 1055 */           dmPermission_build(), 
/* 1056 */           defaultPermission_build(), this.defaultMemberPermissions, 
/*      */           
/* 1058 */           type_build());
/*      */     }
/*      */     
/*      */     private String formatRequiredAttributesMessage() {
/* 1062 */       List<String> attributes = new ArrayList<>();
/* 1063 */       if ((this.initBits & 0x1L) != 0L) attributes.add("name"); 
/* 1064 */       return "Cannot build ApplicationCommandRequest, some of required attributes are not set " + attributes;
/*      */     }
/*      */     
/*      */     private Possible<Optional<Map<String, String>>> nameLocalizations_build() {
/* 1068 */       return this.nameLocalizations_possible;
/*      */     }
/*      */     
/*      */     private Possible<String> description_build() {
/* 1072 */       return this.description_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<Map<String, String>>> descriptionLocalizations_build() {
/* 1076 */       return this.descriptionLocalizations_possible;
/*      */     }
/*      */     
/*      */     private Possible<List<ApplicationCommandOptionData>> options_build() {
/* 1080 */       return (this.options_list == null) ? Possible.absent() : 
/* 1081 */         Possible.of(this.options_list);
/*      */     }
/*      */     
/*      */     private List<ApplicationCommandOptionData> options_getOrCreate() {
/* 1085 */       if (this.options_list == null) {
/* 1086 */         this.options_list = new ArrayList<>();
/*      */       }
/* 1088 */       return this.options_list;
/*      */     }
/*      */     
/*      */     private Possible<Boolean> dmPermission_build() {
/* 1092 */       return this.dmPermission_possible;
/*      */     }
/*      */     
/*      */     private Possible<Boolean> defaultPermission_build() {
/* 1096 */       return this.defaultPermission_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> type_build() {
/* 1100 */       return this.type_possible;
/*      */     }
/*      */     
/*      */     private Builder() {}
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableApplicationCommandRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */