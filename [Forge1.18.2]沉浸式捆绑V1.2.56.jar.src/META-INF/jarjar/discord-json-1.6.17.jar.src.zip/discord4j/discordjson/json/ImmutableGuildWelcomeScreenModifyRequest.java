/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.StreamSupport;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "GuildWelcomeScreenModifyRequest", generator = "Immutables")
/*     */ public final class ImmutableGuildWelcomeScreenModifyRequest
/*     */   implements GuildWelcomeScreenModifyRequest
/*     */ {
/*     */   private final Boolean enabled_value;
/*     */   private final boolean enabled_absent;
/*     */   private final List<WelcomeScreenChannelData> welcomeChannels_value;
/*     */   private final boolean welcomeChannels_absent;
/*     */   private final String description_value;
/*     */   private final boolean description_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private ImmutableGuildWelcomeScreenModifyRequest(Possible<Optional<Boolean>> enabled, Possible<Optional<List<WelcomeScreenChannelData>>> welcomeChannels, Possible<Optional<String>> description) {
/*  39 */     Possible<Optional<Boolean>> enabled$impl = enabled;
/*  40 */     Possible<Optional<List<WelcomeScreenChannelData>>> welcomeChannels$impl = welcomeChannels;
/*  41 */     Possible<Optional<String>> description$impl = description;
/*  42 */     this.enabled_value = Possible.flatOpt(enabled$impl).orElse(null);
/*  43 */     this.enabled_absent = enabled$impl.isAbsent();
/*  44 */     this.welcomeChannels_value = Possible.flatOpt(welcomeChannels$impl).orElse(null);
/*  45 */     this.welcomeChannels_absent = welcomeChannels$impl.isAbsent();
/*  46 */     this.description_value = Possible.flatOpt(description$impl).orElse(null);
/*  47 */     this.description_absent = description$impl.isAbsent();
/*  48 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableGuildWelcomeScreenModifyRequest(ImmutableGuildWelcomeScreenModifyRequest original, Possible<Optional<Boolean>> enabled, Possible<Optional<List<WelcomeScreenChannelData>>> welcomeChannels, Possible<Optional<String>> description) {
/*  56 */     Possible<Optional<Boolean>> enabled$impl = enabled;
/*  57 */     Possible<Optional<List<WelcomeScreenChannelData>>> welcomeChannels$impl = welcomeChannels;
/*  58 */     Possible<Optional<String>> description$impl = description;
/*  59 */     this.enabled_value = Possible.flatOpt(enabled$impl).orElse(null);
/*  60 */     this.enabled_absent = enabled$impl.isAbsent();
/*  61 */     this.welcomeChannels_value = Possible.flatOpt(welcomeChannels$impl).orElse(null);
/*  62 */     this.welcomeChannels_absent = welcomeChannels$impl.isAbsent();
/*  63 */     this.description_value = Possible.flatOpt(description$impl).orElse(null);
/*  64 */     this.description_absent = description$impl.isAbsent();
/*  65 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  71 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "GuildWelcomeScreenModifyRequest", generator = "Immutables")
/*     */   private final class InitShim {
/*     */     private String formatInitCycleMessage() {
/*  76 */       List<String> attributes = new ArrayList<>();
/*  77 */       return "Cannot build GuildWelcomeScreenModifyRequest, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @JsonProperty("enabled")
/*     */   public Possible<Optional<Boolean>> enabled() {
/*  87 */     return this.enabled_absent ? Possible.absent() : 
/*  88 */       Possible.of(Optional.ofNullable(this.enabled_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("welcome_channels")
/*     */   public Possible<Optional<List<WelcomeScreenChannelData>>> welcomeChannels() {
/*  97 */     return this.welcomeChannels_absent ? Possible.absent() : 
/*  98 */       Possible.of(Optional.ofNullable(this.welcomeChannels_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("description")
/*     */   public Possible<Optional<String>> description() {
/* 107 */     return this.description_absent ? Possible.absent() : 
/* 108 */       Possible.of(Optional.ofNullable(this.description_value));
/*     */   }
/*     */   
/*     */   public ImmutableGuildWelcomeScreenModifyRequest withEnabled(Possible<Optional<Boolean>> value) {
/* 112 */     Possible<Optional<Boolean>> newValue = Objects.<Possible<Optional<Boolean>>>requireNonNull(value);
/* 113 */     return new ImmutableGuildWelcomeScreenModifyRequest(this, newValue, welcomeChannels(), description());
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public ImmutableGuildWelcomeScreenModifyRequest withEnabled(@Nullable Boolean value) {
/* 118 */     Possible<Optional<Boolean>> newValue = Possible.of(Optional.ofNullable(value));
/* 119 */     return new ImmutableGuildWelcomeScreenModifyRequest(this, newValue, welcomeChannels(), description());
/*     */   }
/*     */   
/*     */   public ImmutableGuildWelcomeScreenModifyRequest withEnabledOrNull(@Nullable Boolean value) {
/* 123 */     Possible<Optional<Boolean>> newValue = Possible.of(Optional.ofNullable(value));
/* 124 */     return new ImmutableGuildWelcomeScreenModifyRequest(this, newValue, welcomeChannels(), description());
/*     */   }
/*     */   
/*     */   public ImmutableGuildWelcomeScreenModifyRequest withWelcomeChannels(Possible<Optional<List<WelcomeScreenChannelData>>> possible) {
/* 128 */     Possible<Optional<List<WelcomeScreenChannelData>>> newValue = Objects.<Possible<Optional<List<WelcomeScreenChannelData>>>>requireNonNull(possible);
/* 129 */     return new ImmutableGuildWelcomeScreenModifyRequest(this, enabled(), newValue, description());
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public ImmutableGuildWelcomeScreenModifyRequest withWelcomeChannels(@Nullable Iterable<WelcomeScreenChannelData> elements) {
/* 134 */     Possible<Optional<List<WelcomeScreenChannelData>>> newValue = Possible.of(Optional.<Iterable<WelcomeScreenChannelData>>ofNullable(elements)
/* 135 */         .map(els -> (List)StreamSupport.stream(els.spliterator(), false).collect(Collectors.toList())));
/* 136 */     return new ImmutableGuildWelcomeScreenModifyRequest(this, enabled(), newValue, description());
/*     */   }
/*     */   
/*     */   public ImmutableGuildWelcomeScreenModifyRequest withWelcomeChannelsOrNull(@Nullable Iterable<WelcomeScreenChannelData> elements) {
/* 140 */     Possible<Optional<List<WelcomeScreenChannelData>>> newValue = Possible.of(Optional.<Iterable<WelcomeScreenChannelData>>ofNullable(elements)
/* 141 */         .map(els -> (List)StreamSupport.stream(els.spliterator(), false).collect(Collectors.toList())));
/* 142 */     return new ImmutableGuildWelcomeScreenModifyRequest(this, enabled(), newValue, description());
/*     */   }
/*     */   
/*     */   @SafeVarargs
/*     */   public final ImmutableGuildWelcomeScreenModifyRequest withWelcomeChannels(WelcomeScreenChannelData... elements) {
/* 147 */     Possible<Optional<List<WelcomeScreenChannelData>>> newValue = Possible.of(Optional.of(Arrays.asList(elements)));
/* 148 */     return new ImmutableGuildWelcomeScreenModifyRequest(this, enabled(), newValue, description());
/*     */   }
/*     */   
/*     */   public ImmutableGuildWelcomeScreenModifyRequest withDescription(Possible<Optional<String>> value) {
/* 152 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/* 153 */     return new ImmutableGuildWelcomeScreenModifyRequest(this, enabled(), welcomeChannels(), newValue);
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public ImmutableGuildWelcomeScreenModifyRequest withDescription(@Nullable String value) {
/* 158 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 159 */     return new ImmutableGuildWelcomeScreenModifyRequest(this, enabled(), welcomeChannels(), newValue);
/*     */   }
/*     */   
/*     */   public ImmutableGuildWelcomeScreenModifyRequest withDescriptionOrNull(@Nullable String value) {
/* 163 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 164 */     return new ImmutableGuildWelcomeScreenModifyRequest(this, enabled(), welcomeChannels(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 173 */     if (this == another) return true; 
/* 174 */     return (another instanceof ImmutableGuildWelcomeScreenModifyRequest && 
/* 175 */       equalTo(0, (ImmutableGuildWelcomeScreenModifyRequest)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableGuildWelcomeScreenModifyRequest another) {
/* 179 */     return (enabled().equals(another.enabled()) && 
/* 180 */       Objects.equals(this.welcomeChannels_value, another.welcomeChannels_value) && 
/* 181 */       description().equals(another.description()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 190 */     int h = 5381;
/* 191 */     h += (h << 5) + enabled().hashCode();
/* 192 */     h += (h << 5) + Objects.hashCode(this.welcomeChannels_value);
/* 193 */     h += (h << 5) + description().hashCode();
/* 194 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 203 */     return "GuildWelcomeScreenModifyRequest{enabled=" + 
/* 204 */       enabled().toString() + ", welcomeChannels=" + 
/* 205 */       Objects.toString(this.welcomeChannels_value) + ", description=" + 
/* 206 */       description().toString() + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "GuildWelcomeScreenModifyRequest", generator = "Immutables")
/*     */   static final class Json
/*     */     implements GuildWelcomeScreenModifyRequest
/*     */   {
/* 220 */     Possible<Optional<Boolean>> enabled = Possible.absent();
/*     */ 
/*     */     
/* 223 */     Possible<Optional<List<WelcomeScreenChannelData>>> welcomeChannels = Possible.absent();
/*     */ 
/*     */     
/* 226 */     Possible<Optional<String>> description = Possible.absent();
/*     */     
/*     */     @JsonProperty("enabled")
/*     */     public void setEnabled(Possible<Optional<Boolean>> enabled) {
/* 230 */       this.enabled = enabled;
/*     */     }
/*     */     @JsonProperty("welcome_channels")
/*     */     public void setWelcomeChannels(Possible<Optional<List<WelcomeScreenChannelData>>> welcomeChannels) {
/* 234 */       this.welcomeChannels = welcomeChannels;
/*     */     }
/*     */     @JsonProperty("description")
/*     */     public void setDescription(Possible<Optional<String>> description) {
/* 238 */       this.description = description;
/*     */     }
/*     */     public Possible<Optional<Boolean>> enabled() {
/* 241 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Optional<List<WelcomeScreenChannelData>>> welcomeChannels() {
/* 243 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Optional<String>> description() {
/* 245 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableGuildWelcomeScreenModifyRequest fromJson(Json json) {
/* 256 */     Builder builder = builder();
/* 257 */     if (json.enabled != null) {
/* 258 */       builder.enabled(json.enabled);
/*     */     }
/* 260 */     if (json.welcomeChannels != null) {
/* 261 */       builder.welcomeChannels(json.welcomeChannels);
/*     */     }
/* 263 */     if (json.description != null) {
/* 264 */       builder.description(json.description);
/*     */     }
/* 266 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableGuildWelcomeScreenModifyRequest of(Possible<Optional<Boolean>> enabled, Possible<Optional<List<WelcomeScreenChannelData>>> welcomeChannels, Possible<Optional<String>> description) {
/* 277 */     return new ImmutableGuildWelcomeScreenModifyRequest(enabled, welcomeChannels, description);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableGuildWelcomeScreenModifyRequest copyOf(GuildWelcomeScreenModifyRequest instance) {
/* 288 */     if (instance instanceof ImmutableGuildWelcomeScreenModifyRequest) {
/* 289 */       return (ImmutableGuildWelcomeScreenModifyRequest)instance;
/*     */     }
/* 291 */     return builder()
/* 292 */       .from(instance)
/* 293 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isEnabledPresent() {
/* 297 */     return !this.enabled_absent;
/*     */   }
/*     */   
/*     */   public Boolean enabledOrElse(Boolean defaultValue) {
/* 301 */     return !this.enabled_absent ? this.enabled_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isWelcomeChannelsPresent() {
/* 305 */     return !this.welcomeChannels_absent;
/*     */   }
/*     */   
/*     */   public List<WelcomeScreenChannelData> welcomeChannelsOrElse(List<WelcomeScreenChannelData> defaultValue) {
/* 309 */     return !this.welcomeChannels_absent ? this.welcomeChannels_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isDescriptionPresent() {
/* 313 */     return !this.description_absent;
/*     */   }
/*     */   
/*     */   public String descriptionOrElse(String defaultValue) {
/* 317 */     return !this.description_absent ? this.description_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 332 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "GuildWelcomeScreenModifyRequest", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/* 344 */     private Possible<Optional<Boolean>> enabled_possible = Possible.absent();
/* 345 */     private List<WelcomeScreenChannelData> welcomeChannels_list = null;
/*     */     private boolean welcomeChannels_explicitNull;
/* 347 */     private Possible<Optional<String>> description_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(GuildWelcomeScreenModifyRequest instance) {
/* 360 */       Objects.requireNonNull(instance, "instance");
/* 361 */       enabled(instance.enabled());
/* 362 */       welcomeChannels(instance.welcomeChannels());
/* 363 */       description(instance.description());
/* 364 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("enabled")
/*     */     public Builder enabled(Possible<Optional<Boolean>> value) {
/* 369 */       this.enabled_possible = value;
/* 370 */       return this;
/*     */     }
/*     */     
/*     */     @Deprecated
/*     */     public Builder enabled(@Nullable Boolean value) {
/* 375 */       this.enabled_possible = Possible.of(Optional.ofNullable(value));
/* 376 */       return this;
/*     */     }
/*     */     
/*     */     public Builder enabledOrNull(@Nullable Boolean value) {
/* 380 */       this.enabled_possible = Possible.of(Optional.ofNullable(value));
/* 381 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addWelcomeChannel(WelcomeScreenChannelData element) {
/* 385 */       welcomeChannels_getOrCreate().add(element);
/* 386 */       this.welcomeChannels_explicitNull = false;
/* 387 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addAllWelcomeChannels(List<WelcomeScreenChannelData> elements) {
/* 391 */       welcomeChannels_getOrCreate().addAll(elements);
/* 392 */       this.welcomeChannels_explicitNull = false;
/* 393 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("welcome_channels")
/*     */     public Builder welcomeChannels(Possible<Optional<List<WelcomeScreenChannelData>>> elements) {
/* 398 */       this.welcomeChannels_list = null;
/* 399 */       this.welcomeChannels_explicitNull = false;
/* 400 */       elements.toOptional().ifPresent(e -> {
/*     */             if (e.isPresent()) {
/*     */               welcomeChannels_getOrCreate().addAll(e.get());
/*     */             } else {
/*     */               this.welcomeChannels_explicitNull = true;
/*     */             } 
/*     */           });
/* 407 */       return this;
/*     */     }
/*     */     
/*     */     public Builder welcomeChannels(List<WelcomeScreenChannelData> elements) {
/* 411 */       this.welcomeChannels_list = new ArrayList<>(elements);
/* 412 */       this.welcomeChannels_explicitNull = false;
/* 413 */       return this;
/*     */     }
/*     */     
/*     */     @Deprecated
/*     */     public Builder welcomeChannels(@Nullable Iterable<WelcomeScreenChannelData> elements) {
/* 418 */       if (elements == null) {
/* 419 */         this.welcomeChannels_list = null;
/* 420 */         this.welcomeChannels_explicitNull = true;
/*     */       } else {
/* 422 */         this.welcomeChannels_list = (List<WelcomeScreenChannelData>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 423 */         this.welcomeChannels_explicitNull = false;
/*     */       } 
/* 425 */       return this;
/*     */     }
/*     */     
/*     */     public Builder welcomeChannelsOrNull(@Nullable Iterable<WelcomeScreenChannelData> elements) {
/* 429 */       if (elements == null) {
/* 430 */         this.welcomeChannels_list = null;
/* 431 */         this.welcomeChannels_explicitNull = true;
/*     */       } else {
/* 433 */         this.welcomeChannels_list = (List<WelcomeScreenChannelData>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 434 */         this.welcomeChannels_explicitNull = false;
/*     */       } 
/* 436 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("description")
/*     */     public Builder description(Possible<Optional<String>> value) {
/* 441 */       this.description_possible = value;
/* 442 */       return this;
/*     */     }
/*     */     
/*     */     @Deprecated
/*     */     public Builder description(@Nullable String value) {
/* 447 */       this.description_possible = Possible.of(Optional.ofNullable(value));
/* 448 */       return this;
/*     */     }
/*     */     
/*     */     public Builder descriptionOrNull(@Nullable String value) {
/* 452 */       this.description_possible = Possible.of(Optional.ofNullable(value));
/* 453 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableGuildWelcomeScreenModifyRequest build() {
/* 462 */       return new ImmutableGuildWelcomeScreenModifyRequest(null, enabled_build(), welcomeChannels_build(), description_build());
/*     */     }
/*     */     
/*     */     private Possible<Optional<Boolean>> enabled_build() {
/* 466 */       return this.enabled_possible;
/*     */     }
/*     */     
/*     */     private Possible<Optional<List<WelcomeScreenChannelData>>> welcomeChannels_build() {
/* 470 */       return (this.welcomeChannels_list == null && !this.welcomeChannels_explicitNull) ? Possible.absent() : 
/* 471 */         Possible.of(Optional.ofNullable(this.welcomeChannels_list));
/*     */     }
/*     */     
/*     */     private List<WelcomeScreenChannelData> welcomeChannels_getOrCreate() {
/* 475 */       if (this.welcomeChannels_list == null) {
/* 476 */         this.welcomeChannels_list = new ArrayList<>();
/*     */       }
/* 478 */       return this.welcomeChannels_list;
/*     */     }
/*     */     
/*     */     private Possible<Optional<String>> description_build() {
/* 482 */       return this.description_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableGuildWelcomeScreenModifyRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */