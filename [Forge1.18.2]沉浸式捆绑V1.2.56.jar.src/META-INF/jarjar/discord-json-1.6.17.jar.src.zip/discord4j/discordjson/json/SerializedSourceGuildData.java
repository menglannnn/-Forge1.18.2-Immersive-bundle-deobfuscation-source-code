/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.Id;
/*    */ import java.util.List;
/*    */ import java.util.Optional;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ @JsonSerialize(as = ImmutableSerializedSourceGuildData.class)
/*    */ @JsonDeserialize(as = ImmutableSerializedSourceGuildData.class)
/*    */ @Immutable
/*    */ public interface SerializedSourceGuildData
/*    */ {
/*    */   static ImmutableSerializedSourceGuildData.Builder builder() {
/* 18 */     return ImmutableSerializedSourceGuildData.builder();
/*    */   }
/*    */   
/*    */   String name();
/*    */   
/*    */   Optional<String> description();
/*    */   
/*    */   String region();
/*    */   
/*    */   @JsonProperty("verification_level")
/*    */   int verificationLevel();
/*    */   
/*    */   @JsonProperty("default_message_notifications")
/*    */   int defaultMessageNotifications();
/*    */   
/*    */   @JsonProperty("explicit_content_filter")
/*    */   int explicitContentFilter();
/*    */   
/*    */   @JsonProperty("preferred_locale")
/*    */   String preferredLocale();
/*    */   
/*    */   @JsonProperty("afk_timeout")
/*    */   int afkTimeout();
/*    */   
/*    */   List<RoleTemplateData> roles();
/*    */   
/*    */   List<ChannelData> channels();
/*    */   
/*    */   @JsonProperty("afk_channel_id")
/*    */   Optional<Id> afkChannelId();
/*    */   
/*    */   @JsonProperty("system_channel_id")
/*    */   Optional<Id> systemChannelId();
/*    */   
/*    */   @JsonProperty("system_channel_flags")
/*    */   int systemChannelFlags();
/*    */   
/*    */   @JsonProperty("icon_hash")
/*    */   Optional<String> iconHash();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\SerializedSourceGuildData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */