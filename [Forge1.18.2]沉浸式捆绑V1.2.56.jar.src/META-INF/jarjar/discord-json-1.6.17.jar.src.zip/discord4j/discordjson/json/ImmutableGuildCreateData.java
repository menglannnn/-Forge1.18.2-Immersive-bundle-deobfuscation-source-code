/*      */ package discord4j.discordjson.json;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*      */ import com.fasterxml.jackson.annotation.JsonCreator;
/*      */ import com.fasterxml.jackson.annotation.JsonProperty;
/*      */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*      */ import discord4j.discordjson.Id;
/*      */ import discord4j.discordjson.possible.Possible;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import java.util.Optional;
/*      */ import java.util.OptionalInt;
/*      */ import java.util.stream.Collectors;
/*      */ import java.util.stream.StreamSupport;
/*      */ import org.immutables.value.Generated;
/*      */ import reactor.util.annotation.Nullable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Generated(from = "GuildCreateData", generator = "Immutables")
/*      */ public final class ImmutableGuildCreateData
/*      */   implements GuildCreateData
/*      */ {
/*      */   private final long id_value;
/*      */   private final String name;
/*      */   private final String icon;
/*      */   private final String splash;
/*      */   private final String discoverySplash;
/*      */   private final Boolean owner_value;
/*      */   private final boolean owner_absent;
/*      */   private final Long permissions_value;
/*      */   private final boolean permissions_absent;
/*      */   private final long afkChannelId_value;
/*      */   private final boolean afkChannelId_present;
/*      */   private final Boolean embedEnabled_value;
/*      */   private final boolean embedEnabled_absent;
/*      */   private final long embedChannelId_value;
/*      */   private final boolean embedChannelId_absent;
/*      */   private final boolean embedChannelId_isNull;
/*      */   private final List<String> features;
/*      */   private final long applicationId_value;
/*      */   private final boolean applicationId_present;
/*      */   private final Boolean widgetEnabled_value;
/*      */   private final boolean widgetEnabled_absent;
/*      */   private final long widgetChannelId_value;
/*      */   private final boolean widgetChannelId_absent;
/*      */   private final boolean widgetChannelId_isNull;
/*      */   private final long systemChannelId_value;
/*      */   private final boolean systemChannelId_present;
/*      */   private final Integer systemChannelFlags;
/*      */   private final long rulesChannelId_value;
/*      */   private final boolean rulesChannelId_present;
/*      */   private final Integer maxPresences_value;
/*      */   private final boolean maxPresences_absent;
/*      */   private final Integer maxMembers_value;
/*      */   private final boolean maxMembers_absent;
/*      */   private final String vanityUrlCode;
/*      */   private final String description;
/*      */   private final String banner;
/*      */   private final Integer premiumSubscriptionCount_value;
/*      */   private final boolean premiumSubscriptionCount_absent;
/*      */   private final long publicUpdatesChannelId_value;
/*      */   private final boolean publicUpdatesChannelId_present;
/*      */   private final Integer maxVideoChannelUsers_value;
/*      */   private final boolean maxVideoChannelUsers_absent;
/*      */   private final Integer approximateMemberCount_value;
/*      */   private final boolean approximateMemberCount_absent;
/*      */   private final Integer approximatePresenceCount_value;
/*      */   private final boolean approximatePresenceCount_absent;
/*      */   private final WelcomeScreenData welcomeScreen_value;
/*      */   private final boolean welcomeScreen_absent;
/*      */   private final Boolean nsfw_value;
/*      */   private final boolean nsfw_absent;
/*      */   private final long safetyAlertsChannelId_value;
/*      */   private final boolean safetyAlertsChannelId_present;
/*      */   private final int verificationLevel;
/*      */   private final int nsfwLevel;
/*      */   private final long ownerId_value;
/*      */   private final String region_value;
/*      */   private final boolean region_absent;
/*      */   private final int afkTimeout;
/*      */   private final int defaultMessageNotifications;
/*      */   private final int explicitContentFilter;
/*      */   private final int mfaLevel;
/*      */   private final int premiumTier;
/*      */   private final String preferredLocale;
/*      */   private final String joinedAt;
/*      */   private final boolean large;
/*      */   private final Boolean unavailable_value;
/*      */   private final boolean unavailable_absent;
/*      */   private final int memberCount;
/*      */   private final List<RoleData> roles;
/*      */   private final List<EmojiData> emojis;
/*      */   private final List<StickerData> stickers_value;
/*      */   private final boolean stickers_absent;
/*      */   private final List<VoiceStateData> voiceStates;
/*      */   private final List<MemberData> members;
/*      */   private final List<ChannelData> channels;
/*      */   private final List<PresenceData> presences;
/*      */   private static final byte STAGE_INITIALIZING = -1;
/*      */   private static final byte STAGE_UNINITIALIZED = 0;
/*      */   private static final byte STAGE_INITIALIZED = 1;
/*      */   
/*      */   private ImmutableGuildCreateData(Id id, String name, Optional<String> icon, Optional<String> splash, Optional<String> discoverySplash, Possible<Boolean> owner, Possible<Long> permissions, Optional<Id> afkChannelId, Possible<Boolean> embedEnabled, Possible<Optional<Id>> embedChannelId, Iterable<String> features, Optional<Id> applicationId, Possible<Boolean> widgetEnabled, Possible<Optional<Id>> widgetChannelId, Optional<Id> systemChannelId, OptionalInt systemChannelFlags, Optional<Id> rulesChannelId, Possible<Optional<Integer>> maxPresences, Possible<Integer> maxMembers, Optional<String> vanityUrlCode, Optional<String> description, Optional<String> banner, Possible<Integer> premiumSubscriptionCount, Optional<Id> publicUpdatesChannelId, Possible<Integer> maxVideoChannelUsers, Possible<Integer> approximateMemberCount, Possible<Integer> approximatePresenceCount, Possible<WelcomeScreenData> welcomeScreen, Possible<Boolean> nsfw, Optional<Id> safetyAlertsChannelId, int verificationLevel, int nsfwLevel, Id ownerId, Possible<Optional<String>> region, int afkTimeout, int defaultMessageNotifications, int explicitContentFilter, int mfaLevel, int premiumTier, String preferredLocale, String joinedAt, boolean large, Possible<Boolean> unavailable, int memberCount, Iterable<? extends RoleData> roles, Iterable<? extends EmojiData> emojis, Possible<List<StickerData>> stickers, Iterable<? extends VoiceStateData> voiceStates, Iterable<? extends MemberData> members, Iterable<? extends ChannelData> channels, Iterable<? extends PresenceData> presences) {
/*  163 */     Id id$impl = id;
/*  164 */     this.name = Objects.<String>requireNonNull(name, "name");
/*  165 */     this.icon = icon.orElse(null);
/*  166 */     this.splash = splash.orElse(null);
/*  167 */     this.discoverySplash = discoverySplash.orElse(null);
/*  168 */     Possible<Boolean> owner$impl = owner;
/*  169 */     Possible<Long> permissions$impl = permissions;
/*  170 */     Optional<Id> afkChannelId$impl = afkChannelId;
/*  171 */     Possible<Boolean> embedEnabled$impl = embedEnabled;
/*  172 */     Possible<Optional<Id>> embedChannelId$impl = embedChannelId;
/*  173 */     this.features = createUnmodifiableList(false, createSafeList(features, true, false));
/*  174 */     Optional<Id> applicationId$impl = applicationId;
/*  175 */     Possible<Boolean> widgetEnabled$impl = widgetEnabled;
/*  176 */     Possible<Optional<Id>> widgetChannelId$impl = widgetChannelId;
/*  177 */     Optional<Id> systemChannelId$impl = systemChannelId;
/*  178 */     this.systemChannelFlags = systemChannelFlags.isPresent() ? Integer.valueOf(systemChannelFlags.getAsInt()) : null;
/*  179 */     Optional<Id> rulesChannelId$impl = rulesChannelId;
/*  180 */     Possible<Optional<Integer>> maxPresences$impl = maxPresences;
/*  181 */     Possible<Integer> maxMembers$impl = maxMembers;
/*  182 */     this.vanityUrlCode = vanityUrlCode.orElse(null);
/*  183 */     this.description = description.orElse(null);
/*  184 */     this.banner = banner.orElse(null);
/*  185 */     Possible<Integer> premiumSubscriptionCount$impl = premiumSubscriptionCount;
/*  186 */     Optional<Id> publicUpdatesChannelId$impl = publicUpdatesChannelId;
/*  187 */     Possible<Integer> maxVideoChannelUsers$impl = maxVideoChannelUsers;
/*  188 */     Possible<Integer> approximateMemberCount$impl = approximateMemberCount;
/*  189 */     Possible<Integer> approximatePresenceCount$impl = approximatePresenceCount;
/*  190 */     Possible<WelcomeScreenData> welcomeScreen$impl = welcomeScreen;
/*  191 */     Possible<Boolean> nsfw$impl = nsfw;
/*  192 */     Optional<Id> safetyAlertsChannelId$impl = safetyAlertsChannelId;
/*  193 */     this.verificationLevel = verificationLevel;
/*  194 */     this.nsfwLevel = nsfwLevel;
/*  195 */     Id ownerId$impl = ownerId;
/*  196 */     Possible<Optional<String>> region$impl = region;
/*  197 */     this.afkTimeout = afkTimeout;
/*  198 */     this.defaultMessageNotifications = defaultMessageNotifications;
/*  199 */     this.explicitContentFilter = explicitContentFilter;
/*  200 */     this.mfaLevel = mfaLevel;
/*  201 */     this.premiumTier = premiumTier;
/*  202 */     this.preferredLocale = Objects.<String>requireNonNull(preferredLocale, "preferredLocale");
/*  203 */     this.joinedAt = Objects.<String>requireNonNull(joinedAt, "joinedAt");
/*  204 */     this.large = large;
/*  205 */     Possible<Boolean> unavailable$impl = unavailable;
/*  206 */     this.memberCount = memberCount;
/*  207 */     this.roles = createUnmodifiableList(false, createSafeList(roles, true, false));
/*  208 */     this.emojis = createUnmodifiableList(false, createSafeList(emojis, true, false));
/*  209 */     Possible<List<StickerData>> stickers$impl = stickers;
/*  210 */     this.voiceStates = createUnmodifiableList(false, createSafeList(voiceStates, true, false));
/*  211 */     this.members = createUnmodifiableList(false, createSafeList(members, true, false));
/*  212 */     this.channels = createUnmodifiableList(false, createSafeList(channels, true, false));
/*  213 */     this.presences = createUnmodifiableList(false, createSafeList(presences, true, false));
/*  214 */     this.id_value = id$impl.asLong();
/*  215 */     this.owner_value = owner$impl.toOptional().orElse(null);
/*  216 */     this.owner_absent = owner$impl.isAbsent();
/*  217 */     this.permissions_value = permissions$impl.toOptional().orElse(null);
/*  218 */     this.permissions_absent = permissions$impl.isAbsent();
/*  219 */     this
/*      */       
/*  221 */       .afkChannelId_value = ((Long)afkChannelId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  222 */     this.afkChannelId_present = afkChannelId$impl.isPresent();
/*  223 */     this.embedEnabled_value = embedEnabled$impl.toOptional().orElse(null);
/*  224 */     this.embedEnabled_absent = embedEnabled$impl.isAbsent();
/*  225 */     this
/*      */       
/*  227 */       .embedChannelId_value = ((Long)Possible.flatOpt(embedChannelId$impl).map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  228 */     this.embedChannelId_absent = embedChannelId$impl.isAbsent();
/*  229 */     this.embedChannelId_isNull = (!embedChannelId$impl.isAbsent() && !((Optional)embedChannelId$impl.get()).isPresent());
/*  230 */     this
/*      */       
/*  232 */       .applicationId_value = ((Long)applicationId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  233 */     this.applicationId_present = applicationId$impl.isPresent();
/*  234 */     this.widgetEnabled_value = widgetEnabled$impl.toOptional().orElse(null);
/*  235 */     this.widgetEnabled_absent = widgetEnabled$impl.isAbsent();
/*  236 */     this
/*      */       
/*  238 */       .widgetChannelId_value = ((Long)Possible.flatOpt(widgetChannelId$impl).map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  239 */     this.widgetChannelId_absent = widgetChannelId$impl.isAbsent();
/*  240 */     this.widgetChannelId_isNull = (!widgetChannelId$impl.isAbsent() && !((Optional)widgetChannelId$impl.get()).isPresent());
/*  241 */     this
/*      */       
/*  243 */       .systemChannelId_value = ((Long)systemChannelId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  244 */     this.systemChannelId_present = systemChannelId$impl.isPresent();
/*  245 */     this
/*      */       
/*  247 */       .rulesChannelId_value = ((Long)rulesChannelId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  248 */     this.rulesChannelId_present = rulesChannelId$impl.isPresent();
/*  249 */     this.maxPresences_value = Possible.flatOpt(maxPresences$impl).orElse(null);
/*  250 */     this.maxPresences_absent = maxPresences$impl.isAbsent();
/*  251 */     this.maxMembers_value = maxMembers$impl.toOptional().orElse(null);
/*  252 */     this.maxMembers_absent = maxMembers$impl.isAbsent();
/*  253 */     this.premiumSubscriptionCount_value = premiumSubscriptionCount$impl.toOptional().orElse(null);
/*  254 */     this.premiumSubscriptionCount_absent = premiumSubscriptionCount$impl.isAbsent();
/*  255 */     this
/*      */       
/*  257 */       .publicUpdatesChannelId_value = ((Long)publicUpdatesChannelId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  258 */     this.publicUpdatesChannelId_present = publicUpdatesChannelId$impl.isPresent();
/*  259 */     this.maxVideoChannelUsers_value = maxVideoChannelUsers$impl.toOptional().orElse(null);
/*  260 */     this.maxVideoChannelUsers_absent = maxVideoChannelUsers$impl.isAbsent();
/*  261 */     this.approximateMemberCount_value = approximateMemberCount$impl.toOptional().orElse(null);
/*  262 */     this.approximateMemberCount_absent = approximateMemberCount$impl.isAbsent();
/*  263 */     this.approximatePresenceCount_value = approximatePresenceCount$impl.toOptional().orElse(null);
/*  264 */     this.approximatePresenceCount_absent = approximatePresenceCount$impl.isAbsent();
/*  265 */     this.welcomeScreen_value = welcomeScreen$impl.toOptional().orElse(null);
/*  266 */     this.welcomeScreen_absent = welcomeScreen$impl.isAbsent();
/*  267 */     this.nsfw_value = nsfw$impl.toOptional().orElse(null);
/*  268 */     this.nsfw_absent = nsfw$impl.isAbsent();
/*  269 */     this
/*      */       
/*  271 */       .safetyAlertsChannelId_value = ((Long)safetyAlertsChannelId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  272 */     this.safetyAlertsChannelId_present = safetyAlertsChannelId$impl.isPresent();
/*  273 */     this.ownerId_value = ownerId$impl.asLong();
/*  274 */     this.region_value = Possible.flatOpt(region$impl).orElse(null);
/*  275 */     this.region_absent = region$impl.isAbsent();
/*  276 */     this.unavailable_value = unavailable$impl.toOptional().orElse(null);
/*  277 */     this.unavailable_absent = unavailable$impl.isAbsent();
/*  278 */     this.stickers_value = stickers$impl.toOptional().orElse(null);
/*  279 */     this.stickers_absent = stickers$impl.isAbsent();
/*  280 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ImmutableGuildCreateData(ImmutableGuildCreateData original, Id id, String name, String icon, String splash, String discoverySplash, Possible<Boolean> owner, Possible<Long> permissions, Optional<Id> afkChannelId, Possible<Boolean> embedEnabled, Possible<Optional<Id>> embedChannelId, List<String> features, Optional<Id> applicationId, Possible<Boolean> widgetEnabled, Possible<Optional<Id>> widgetChannelId, Optional<Id> systemChannelId, Integer systemChannelFlags, Optional<Id> rulesChannelId, Possible<Optional<Integer>> maxPresences, Possible<Integer> maxMembers, String vanityUrlCode, String description, String banner, Possible<Integer> premiumSubscriptionCount, Optional<Id> publicUpdatesChannelId, Possible<Integer> maxVideoChannelUsers, Possible<Integer> approximateMemberCount, Possible<Integer> approximatePresenceCount, Possible<WelcomeScreenData> welcomeScreen, Possible<Boolean> nsfw, Optional<Id> safetyAlertsChannelId, int verificationLevel, int nsfwLevel, Id ownerId, Possible<Optional<String>> region, int afkTimeout, int defaultMessageNotifications, int explicitContentFilter, int mfaLevel, int premiumTier, String preferredLocale, String joinedAt, boolean large, Possible<Boolean> unavailable, int memberCount, List<RoleData> roles, List<EmojiData> emojis, Possible<List<StickerData>> stickers, List<VoiceStateData> voiceStates, List<MemberData> members, List<ChannelData> channels, List<PresenceData> presences) {
/*  336 */     Id id$impl = id;
/*  337 */     this.name = name;
/*  338 */     this.icon = icon;
/*  339 */     this.splash = splash;
/*  340 */     this.discoverySplash = discoverySplash;
/*  341 */     Possible<Boolean> owner$impl = owner;
/*  342 */     Possible<Long> permissions$impl = permissions;
/*  343 */     Optional<Id> afkChannelId$impl = afkChannelId;
/*  344 */     Possible<Boolean> embedEnabled$impl = embedEnabled;
/*  345 */     Possible<Optional<Id>> embedChannelId$impl = embedChannelId;
/*  346 */     this.features = features;
/*  347 */     Optional<Id> applicationId$impl = applicationId;
/*  348 */     Possible<Boolean> widgetEnabled$impl = widgetEnabled;
/*  349 */     Possible<Optional<Id>> widgetChannelId$impl = widgetChannelId;
/*  350 */     Optional<Id> systemChannelId$impl = systemChannelId;
/*  351 */     this.systemChannelFlags = systemChannelFlags;
/*  352 */     Optional<Id> rulesChannelId$impl = rulesChannelId;
/*  353 */     Possible<Optional<Integer>> maxPresences$impl = maxPresences;
/*  354 */     Possible<Integer> maxMembers$impl = maxMembers;
/*  355 */     this.vanityUrlCode = vanityUrlCode;
/*  356 */     this.description = description;
/*  357 */     this.banner = banner;
/*  358 */     Possible<Integer> premiumSubscriptionCount$impl = premiumSubscriptionCount;
/*  359 */     Optional<Id> publicUpdatesChannelId$impl = publicUpdatesChannelId;
/*  360 */     Possible<Integer> maxVideoChannelUsers$impl = maxVideoChannelUsers;
/*  361 */     Possible<Integer> approximateMemberCount$impl = approximateMemberCount;
/*  362 */     Possible<Integer> approximatePresenceCount$impl = approximatePresenceCount;
/*  363 */     Possible<WelcomeScreenData> welcomeScreen$impl = welcomeScreen;
/*  364 */     Possible<Boolean> nsfw$impl = nsfw;
/*  365 */     Optional<Id> safetyAlertsChannelId$impl = safetyAlertsChannelId;
/*  366 */     this.verificationLevel = verificationLevel;
/*  367 */     this.nsfwLevel = nsfwLevel;
/*  368 */     Id ownerId$impl = ownerId;
/*  369 */     Possible<Optional<String>> region$impl = region;
/*  370 */     this.afkTimeout = afkTimeout;
/*  371 */     this.defaultMessageNotifications = defaultMessageNotifications;
/*  372 */     this.explicitContentFilter = explicitContentFilter;
/*  373 */     this.mfaLevel = mfaLevel;
/*  374 */     this.premiumTier = premiumTier;
/*  375 */     this.preferredLocale = preferredLocale;
/*  376 */     this.joinedAt = joinedAt;
/*  377 */     this.large = large;
/*  378 */     Possible<Boolean> unavailable$impl = unavailable;
/*  379 */     this.memberCount = memberCount;
/*  380 */     this.roles = roles;
/*  381 */     this.emojis = emojis;
/*  382 */     Possible<List<StickerData>> stickers$impl = stickers;
/*  383 */     this.voiceStates = voiceStates;
/*  384 */     this.members = members;
/*  385 */     this.channels = channels;
/*  386 */     this.presences = presences;
/*  387 */     this.id_value = id$impl.asLong();
/*  388 */     this.owner_value = owner$impl.toOptional().orElse(null);
/*  389 */     this.owner_absent = owner$impl.isAbsent();
/*  390 */     this.permissions_value = permissions$impl.toOptional().orElse(null);
/*  391 */     this.permissions_absent = permissions$impl.isAbsent();
/*  392 */     this
/*      */       
/*  394 */       .afkChannelId_value = ((Long)afkChannelId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  395 */     this.afkChannelId_present = afkChannelId$impl.isPresent();
/*  396 */     this.embedEnabled_value = embedEnabled$impl.toOptional().orElse(null);
/*  397 */     this.embedEnabled_absent = embedEnabled$impl.isAbsent();
/*  398 */     this
/*      */       
/*  400 */       .embedChannelId_value = ((Long)Possible.flatOpt(embedChannelId$impl).map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  401 */     this.embedChannelId_absent = embedChannelId$impl.isAbsent();
/*  402 */     this.embedChannelId_isNull = (!embedChannelId$impl.isAbsent() && !((Optional)embedChannelId$impl.get()).isPresent());
/*  403 */     this
/*      */       
/*  405 */       .applicationId_value = ((Long)applicationId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  406 */     this.applicationId_present = applicationId$impl.isPresent();
/*  407 */     this.widgetEnabled_value = widgetEnabled$impl.toOptional().orElse(null);
/*  408 */     this.widgetEnabled_absent = widgetEnabled$impl.isAbsent();
/*  409 */     this
/*      */       
/*  411 */       .widgetChannelId_value = ((Long)Possible.flatOpt(widgetChannelId$impl).map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  412 */     this.widgetChannelId_absent = widgetChannelId$impl.isAbsent();
/*  413 */     this.widgetChannelId_isNull = (!widgetChannelId$impl.isAbsent() && !((Optional)widgetChannelId$impl.get()).isPresent());
/*  414 */     this
/*      */       
/*  416 */       .systemChannelId_value = ((Long)systemChannelId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  417 */     this.systemChannelId_present = systemChannelId$impl.isPresent();
/*  418 */     this
/*      */       
/*  420 */       .rulesChannelId_value = ((Long)rulesChannelId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  421 */     this.rulesChannelId_present = rulesChannelId$impl.isPresent();
/*  422 */     this.maxPresences_value = Possible.flatOpt(maxPresences$impl).orElse(null);
/*  423 */     this.maxPresences_absent = maxPresences$impl.isAbsent();
/*  424 */     this.maxMembers_value = maxMembers$impl.toOptional().orElse(null);
/*  425 */     this.maxMembers_absent = maxMembers$impl.isAbsent();
/*  426 */     this.premiumSubscriptionCount_value = premiumSubscriptionCount$impl.toOptional().orElse(null);
/*  427 */     this.premiumSubscriptionCount_absent = premiumSubscriptionCount$impl.isAbsent();
/*  428 */     this
/*      */       
/*  430 */       .publicUpdatesChannelId_value = ((Long)publicUpdatesChannelId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  431 */     this.publicUpdatesChannelId_present = publicUpdatesChannelId$impl.isPresent();
/*  432 */     this.maxVideoChannelUsers_value = maxVideoChannelUsers$impl.toOptional().orElse(null);
/*  433 */     this.maxVideoChannelUsers_absent = maxVideoChannelUsers$impl.isAbsent();
/*  434 */     this.approximateMemberCount_value = approximateMemberCount$impl.toOptional().orElse(null);
/*  435 */     this.approximateMemberCount_absent = approximateMemberCount$impl.isAbsent();
/*  436 */     this.approximatePresenceCount_value = approximatePresenceCount$impl.toOptional().orElse(null);
/*  437 */     this.approximatePresenceCount_absent = approximatePresenceCount$impl.isAbsent();
/*  438 */     this.welcomeScreen_value = welcomeScreen$impl.toOptional().orElse(null);
/*  439 */     this.welcomeScreen_absent = welcomeScreen$impl.isAbsent();
/*  440 */     this.nsfw_value = nsfw$impl.toOptional().orElse(null);
/*  441 */     this.nsfw_absent = nsfw$impl.isAbsent();
/*  442 */     this
/*      */       
/*  444 */       .safetyAlertsChannelId_value = ((Long)safetyAlertsChannelId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  445 */     this.safetyAlertsChannelId_present = safetyAlertsChannelId$impl.isPresent();
/*  446 */     this.ownerId_value = ownerId$impl.asLong();
/*  447 */     this.region_value = Possible.flatOpt(region$impl).orElse(null);
/*  448 */     this.region_absent = region$impl.isAbsent();
/*  449 */     this.unavailable_value = unavailable$impl.toOptional().orElse(null);
/*  450 */     this.unavailable_absent = unavailable$impl.isAbsent();
/*  451 */     this.stickers_value = stickers$impl.toOptional().orElse(null);
/*  452 */     this.stickers_absent = stickers$impl.isAbsent();
/*  453 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  459 */   private volatile transient InitShim initShim = new InitShim();
/*      */   
/*      */   @Generated(from = "GuildCreateData", generator = "Immutables")
/*      */   private final class InitShim {
/*      */     private String formatInitCycleMessage() {
/*  464 */       List<String> attributes = new ArrayList<>();
/*  465 */       return "Cannot build GuildCreateData, attribute initializers form cycle " + attributes;
/*      */     }
/*      */ 
/*      */     
/*      */     private InitShim() {}
/*      */   }
/*      */ 
/*      */   
/*      */   @JsonProperty("id")
/*      */   public Id id() {
/*  475 */     return Id.of(this.id_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("name")
/*      */   public String name() {
/*  484 */     return this.name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("icon")
/*      */   public Optional<String> icon() {
/*  493 */     return Optional.ofNullable(this.icon);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("splash")
/*      */   public Optional<String> splash() {
/*  502 */     return Optional.ofNullable(this.splash);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("discovery_splash")
/*      */   public Optional<String> discoverySplash() {
/*  511 */     return Optional.ofNullable(this.discoverySplash);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("owner")
/*      */   public Possible<Boolean> owner() {
/*  520 */     return this.owner_absent ? Possible.absent() : Possible.of(this.owner_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("permissions")
/*      */   public Possible<Long> permissions() {
/*  529 */     return this.permissions_absent ? Possible.absent() : Possible.of(this.permissions_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("afk_channel_id")
/*      */   public Optional<Id> afkChannelId() {
/*  538 */     return this.afkChannelId_present ? Optional.<Id>of(Id.of(this.afkChannelId_value)) : Optional.<Id>empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("embed_enabled")
/*      */   @Deprecated
/*      */   public Possible<Boolean> embedEnabled() {
/*  548 */     return this.embedEnabled_absent ? Possible.absent() : Possible.of(this.embedEnabled_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("embed_channel_id")
/*      */   @Deprecated
/*      */   public Possible<Optional<Id>> embedChannelId() {
/*  558 */     if (this.embedChannelId_absent)
/*  559 */       return Possible.absent(); 
/*  560 */     if (this.embedChannelId_isNull) {
/*  561 */       return Possible.of(Optional.empty());
/*      */     }
/*  563 */     return Possible.of(Optional.of(Id.of(this.embedChannelId_value)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("features")
/*      */   public List<String> features() {
/*  573 */     return this.features;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("application_id")
/*      */   public Optional<Id> applicationId() {
/*  582 */     return this.applicationId_present ? Optional.<Id>of(Id.of(this.applicationId_value)) : Optional.<Id>empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("widget_enabled")
/*      */   public Possible<Boolean> widgetEnabled() {
/*  591 */     return this.widgetEnabled_absent ? Possible.absent() : Possible.of(this.widgetEnabled_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("widget_channel_id")
/*      */   public Possible<Optional<Id>> widgetChannelId() {
/*  600 */     if (this.widgetChannelId_absent)
/*  601 */       return Possible.absent(); 
/*  602 */     if (this.widgetChannelId_isNull) {
/*  603 */       return Possible.of(Optional.empty());
/*      */     }
/*  605 */     return Possible.of(Optional.of(Id.of(this.widgetChannelId_value)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("system_channel_id")
/*      */   public Optional<Id> systemChannelId() {
/*  615 */     return this.systemChannelId_present ? Optional.<Id>of(Id.of(this.systemChannelId_value)) : Optional.<Id>empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("system_channel_flags")
/*      */   public OptionalInt systemChannelFlags() {
/*  624 */     return (this.systemChannelFlags != null) ? 
/*  625 */       OptionalInt.of(this.systemChannelFlags.intValue()) : 
/*  626 */       OptionalInt.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("rules_channel_id")
/*      */   public Optional<Id> rulesChannelId() {
/*  635 */     return this.rulesChannelId_present ? Optional.<Id>of(Id.of(this.rulesChannelId_value)) : Optional.<Id>empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("max_presences")
/*      */   public Possible<Optional<Integer>> maxPresences() {
/*  644 */     return this.maxPresences_absent ? Possible.absent() : 
/*  645 */       Possible.of(Optional.ofNullable(this.maxPresences_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("max_members")
/*      */   public Possible<Integer> maxMembers() {
/*  654 */     return this.maxMembers_absent ? Possible.absent() : Possible.of(this.maxMembers_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("vanity_url_code")
/*      */   public Optional<String> vanityUrlCode() {
/*  663 */     return Optional.ofNullable(this.vanityUrlCode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("description")
/*      */   public Optional<String> description() {
/*  672 */     return Optional.ofNullable(this.description);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("banner")
/*      */   public Optional<String> banner() {
/*  681 */     return Optional.ofNullable(this.banner);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("premium_subscription_count")
/*      */   public Possible<Integer> premiumSubscriptionCount() {
/*  690 */     return this.premiumSubscriptionCount_absent ? Possible.absent() : Possible.of(this.premiumSubscriptionCount_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("public_updates_channel_id")
/*      */   public Optional<Id> publicUpdatesChannelId() {
/*  699 */     return this.publicUpdatesChannelId_present ? Optional.<Id>of(Id.of(this.publicUpdatesChannelId_value)) : Optional.<Id>empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("max_video_channel_users")
/*      */   public Possible<Integer> maxVideoChannelUsers() {
/*  708 */     return this.maxVideoChannelUsers_absent ? Possible.absent() : Possible.of(this.maxVideoChannelUsers_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("approximate_member_count")
/*      */   public Possible<Integer> approximateMemberCount() {
/*  717 */     return this.approximateMemberCount_absent ? Possible.absent() : Possible.of(this.approximateMemberCount_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("approximate_presence_count")
/*      */   public Possible<Integer> approximatePresenceCount() {
/*  726 */     return this.approximatePresenceCount_absent ? Possible.absent() : Possible.of(this.approximatePresenceCount_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("welcome_screen")
/*      */   public Possible<WelcomeScreenData> welcomeScreen() {
/*  735 */     return this.welcomeScreen_absent ? Possible.absent() : Possible.of(this.welcomeScreen_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("nsfw")
/*      */   @Deprecated
/*      */   public Possible<Boolean> nsfw() {
/*  745 */     return this.nsfw_absent ? Possible.absent() : Possible.of(this.nsfw_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("safety_alerts_channel_id")
/*      */   public Optional<Id> safetyAlertsChannelId() {
/*  754 */     return this.safetyAlertsChannelId_present ? Optional.<Id>of(Id.of(this.safetyAlertsChannelId_value)) : Optional.<Id>empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("verification_level")
/*      */   public int verificationLevel() {
/*  763 */     return this.verificationLevel;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("nsfw_level")
/*      */   public int nsfwLevel() {
/*  772 */     return this.nsfwLevel;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("owner_id")
/*      */   public Id ownerId() {
/*  781 */     return Id.of(this.ownerId_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("region")
/*      */   public Possible<Optional<String>> region() {
/*  790 */     return this.region_absent ? Possible.absent() : 
/*  791 */       Possible.of(Optional.ofNullable(this.region_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("afk_timeout")
/*      */   public int afkTimeout() {
/*  800 */     return this.afkTimeout;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("default_message_notifications")
/*      */   public int defaultMessageNotifications() {
/*  809 */     return this.defaultMessageNotifications;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("explicit_content_filter")
/*      */   public int explicitContentFilter() {
/*  818 */     return this.explicitContentFilter;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("mfa_level")
/*      */   public int mfaLevel() {
/*  827 */     return this.mfaLevel;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("premium_tier")
/*      */   public int premiumTier() {
/*  836 */     return this.premiumTier;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("preferred_locale")
/*      */   public String preferredLocale() {
/*  845 */     return this.preferredLocale;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("joined_at")
/*      */   public String joinedAt() {
/*  854 */     return this.joinedAt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("large")
/*      */   public boolean large() {
/*  863 */     return this.large;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("unavailable")
/*      */   public Possible<Boolean> unavailable() {
/*  872 */     return this.unavailable_absent ? Possible.absent() : Possible.of(this.unavailable_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("member_count")
/*      */   public int memberCount() {
/*  881 */     return this.memberCount;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("roles")
/*      */   public List<RoleData> roles() {
/*  890 */     return this.roles;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("emojis")
/*      */   public List<EmojiData> emojis() {
/*  899 */     return this.emojis;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("stickers")
/*      */   public Possible<List<StickerData>> stickers() {
/*  908 */     return this.stickers_absent ? Possible.absent() : 
/*  909 */       Possible.of(this.stickers_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("voice_states")
/*      */   public List<VoiceStateData> voiceStates() {
/*  918 */     return this.voiceStates;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("members")
/*      */   public List<MemberData> members() {
/*  927 */     return this.members;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("channels")
/*      */   public List<ChannelData> channels() {
/*  936 */     return this.channels;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("presences")
/*      */   public List<PresenceData> presences() {
/*  945 */     return this.presences;
/*      */   }
/*      */   
/*      */   public ImmutableGuildCreateData withId(long value) {
/*  949 */     Id newValue = Id.of(value);
/*  950 */     return new ImmutableGuildCreateData(this, newValue, this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  957 */         owner(), 
/*  958 */         permissions(), 
/*  959 */         afkChannelId(), 
/*  960 */         embedEnabled(), 
/*  961 */         embedChannelId(), this.features, 
/*      */         
/*  963 */         applicationId(), 
/*  964 */         widgetEnabled(), 
/*  965 */         widgetChannelId(), 
/*  966 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/*  968 */         rulesChannelId(), 
/*  969 */         maxPresences(), 
/*  970 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/*  974 */         premiumSubscriptionCount(), 
/*  975 */         publicUpdatesChannelId(), 
/*  976 */         maxVideoChannelUsers(), 
/*  977 */         approximateMemberCount(), 
/*  978 */         approximatePresenceCount(), 
/*  979 */         welcomeScreen(), 
/*  980 */         nsfw(), 
/*  981 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/*  984 */         ownerId(), 
/*  985 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  994 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/*  998 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableGuildCreateData withId(String value) {
/* 1006 */     Id newValue = Id.of(value);
/* 1007 */     return new ImmutableGuildCreateData(this, newValue, this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1014 */         owner(), 
/* 1015 */         permissions(), 
/* 1016 */         afkChannelId(), 
/* 1017 */         embedEnabled(), 
/* 1018 */         embedChannelId(), this.features, 
/*      */         
/* 1020 */         applicationId(), 
/* 1021 */         widgetEnabled(), 
/* 1022 */         widgetChannelId(), 
/* 1023 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1025 */         rulesChannelId(), 
/* 1026 */         maxPresences(), 
/* 1027 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1031 */         premiumSubscriptionCount(), 
/* 1032 */         publicUpdatesChannelId(), 
/* 1033 */         maxVideoChannelUsers(), 
/* 1034 */         approximateMemberCount(), 
/* 1035 */         approximatePresenceCount(), 
/* 1036 */         welcomeScreen(), 
/* 1037 */         nsfw(), 
/* 1038 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 1041 */         ownerId(), 
/* 1042 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1051 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 1055 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildCreateData withName(String value) {
/* 1069 */     String newValue = Objects.<String>requireNonNull(value, "name");
/* 1070 */     if (this.name.equals(newValue)) return this; 
/* 1071 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 1073 */         id(), newValue, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1078 */         owner(), 
/* 1079 */         permissions(), 
/* 1080 */         afkChannelId(), 
/* 1081 */         embedEnabled(), 
/* 1082 */         embedChannelId(), this.features, 
/*      */         
/* 1084 */         applicationId(), 
/* 1085 */         widgetEnabled(), 
/* 1086 */         widgetChannelId(), 
/* 1087 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1089 */         rulesChannelId(), 
/* 1090 */         maxPresences(), 
/* 1091 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1095 */         premiumSubscriptionCount(), 
/* 1096 */         publicUpdatesChannelId(), 
/* 1097 */         maxVideoChannelUsers(), 
/* 1098 */         approximateMemberCount(), 
/* 1099 */         approximatePresenceCount(), 
/* 1100 */         welcomeScreen(), 
/* 1101 */         nsfw(), 
/* 1102 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 1105 */         ownerId(), 
/* 1106 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1115 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 1119 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildCreateData withIcon(String value) {
/* 1132 */     String newValue = Objects.<String>requireNonNull(value, "icon");
/* 1133 */     if (Objects.equals(this.icon, newValue)) return this; 
/* 1134 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 1136 */         id(), this.name, newValue, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1141 */         owner(), 
/* 1142 */         permissions(), 
/* 1143 */         afkChannelId(), 
/* 1144 */         embedEnabled(), 
/* 1145 */         embedChannelId(), this.features, 
/*      */         
/* 1147 */         applicationId(), 
/* 1148 */         widgetEnabled(), 
/* 1149 */         widgetChannelId(), 
/* 1150 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1152 */         rulesChannelId(), 
/* 1153 */         maxPresences(), 
/* 1154 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1158 */         premiumSubscriptionCount(), 
/* 1159 */         publicUpdatesChannelId(), 
/* 1160 */         maxVideoChannelUsers(), 
/* 1161 */         approximateMemberCount(), 
/* 1162 */         approximatePresenceCount(), 
/* 1163 */         welcomeScreen(), 
/* 1164 */         nsfw(), 
/* 1165 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 1168 */         ownerId(), 
/* 1169 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1178 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 1182 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildCreateData withIcon(Optional<String> optional) {
/* 1196 */     String value = optional.orElse(null);
/* 1197 */     if (Objects.equals(this.icon, value)) return this; 
/* 1198 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 1200 */         id(), this.name, value, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1205 */         owner(), 
/* 1206 */         permissions(), 
/* 1207 */         afkChannelId(), 
/* 1208 */         embedEnabled(), 
/* 1209 */         embedChannelId(), this.features, 
/*      */         
/* 1211 */         applicationId(), 
/* 1212 */         widgetEnabled(), 
/* 1213 */         widgetChannelId(), 
/* 1214 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1216 */         rulesChannelId(), 
/* 1217 */         maxPresences(), 
/* 1218 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1222 */         premiumSubscriptionCount(), 
/* 1223 */         publicUpdatesChannelId(), 
/* 1224 */         maxVideoChannelUsers(), 
/* 1225 */         approximateMemberCount(), 
/* 1226 */         approximatePresenceCount(), 
/* 1227 */         welcomeScreen(), 
/* 1228 */         nsfw(), 
/* 1229 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 1232 */         ownerId(), 
/* 1233 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1242 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 1246 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildCreateData withSplash(String value) {
/* 1259 */     String newValue = Objects.<String>requireNonNull(value, "splash");
/* 1260 */     if (Objects.equals(this.splash, newValue)) return this; 
/* 1261 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 1263 */         id(), this.name, this.icon, newValue, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1268 */         owner(), 
/* 1269 */         permissions(), 
/* 1270 */         afkChannelId(), 
/* 1271 */         embedEnabled(), 
/* 1272 */         embedChannelId(), this.features, 
/*      */         
/* 1274 */         applicationId(), 
/* 1275 */         widgetEnabled(), 
/* 1276 */         widgetChannelId(), 
/* 1277 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1279 */         rulesChannelId(), 
/* 1280 */         maxPresences(), 
/* 1281 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1285 */         premiumSubscriptionCount(), 
/* 1286 */         publicUpdatesChannelId(), 
/* 1287 */         maxVideoChannelUsers(), 
/* 1288 */         approximateMemberCount(), 
/* 1289 */         approximatePresenceCount(), 
/* 1290 */         welcomeScreen(), 
/* 1291 */         nsfw(), 
/* 1292 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 1295 */         ownerId(), 
/* 1296 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1305 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 1309 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildCreateData withSplash(Optional<String> optional) {
/* 1323 */     String value = optional.orElse(null);
/* 1324 */     if (Objects.equals(this.splash, value)) return this; 
/* 1325 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 1327 */         id(), this.name, this.icon, value, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1332 */         owner(), 
/* 1333 */         permissions(), 
/* 1334 */         afkChannelId(), 
/* 1335 */         embedEnabled(), 
/* 1336 */         embedChannelId(), this.features, 
/*      */         
/* 1338 */         applicationId(), 
/* 1339 */         widgetEnabled(), 
/* 1340 */         widgetChannelId(), 
/* 1341 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1343 */         rulesChannelId(), 
/* 1344 */         maxPresences(), 
/* 1345 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1349 */         premiumSubscriptionCount(), 
/* 1350 */         publicUpdatesChannelId(), 
/* 1351 */         maxVideoChannelUsers(), 
/* 1352 */         approximateMemberCount(), 
/* 1353 */         approximatePresenceCount(), 
/* 1354 */         welcomeScreen(), 
/* 1355 */         nsfw(), 
/* 1356 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 1359 */         ownerId(), 
/* 1360 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1369 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 1373 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildCreateData withDiscoverySplash(String value) {
/* 1386 */     String newValue = Objects.<String>requireNonNull(value, "discoverySplash");
/* 1387 */     if (Objects.equals(this.discoverySplash, newValue)) return this; 
/* 1388 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 1390 */         id(), this.name, this.icon, this.splash, newValue, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1395 */         owner(), 
/* 1396 */         permissions(), 
/* 1397 */         afkChannelId(), 
/* 1398 */         embedEnabled(), 
/* 1399 */         embedChannelId(), this.features, 
/*      */         
/* 1401 */         applicationId(), 
/* 1402 */         widgetEnabled(), 
/* 1403 */         widgetChannelId(), 
/* 1404 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1406 */         rulesChannelId(), 
/* 1407 */         maxPresences(), 
/* 1408 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1412 */         premiumSubscriptionCount(), 
/* 1413 */         publicUpdatesChannelId(), 
/* 1414 */         maxVideoChannelUsers(), 
/* 1415 */         approximateMemberCount(), 
/* 1416 */         approximatePresenceCount(), 
/* 1417 */         welcomeScreen(), 
/* 1418 */         nsfw(), 
/* 1419 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 1422 */         ownerId(), 
/* 1423 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1432 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 1436 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildCreateData withDiscoverySplash(Optional<String> optional) {
/* 1450 */     String value = optional.orElse(null);
/* 1451 */     if (Objects.equals(this.discoverySplash, value)) return this; 
/* 1452 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 1454 */         id(), this.name, this.icon, this.splash, value, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1459 */         owner(), 
/* 1460 */         permissions(), 
/* 1461 */         afkChannelId(), 
/* 1462 */         embedEnabled(), 
/* 1463 */         embedChannelId(), this.features, 
/*      */         
/* 1465 */         applicationId(), 
/* 1466 */         widgetEnabled(), 
/* 1467 */         widgetChannelId(), 
/* 1468 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1470 */         rulesChannelId(), 
/* 1471 */         maxPresences(), 
/* 1472 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1476 */         premiumSubscriptionCount(), 
/* 1477 */         publicUpdatesChannelId(), 
/* 1478 */         maxVideoChannelUsers(), 
/* 1479 */         approximateMemberCount(), 
/* 1480 */         approximatePresenceCount(), 
/* 1481 */         welcomeScreen(), 
/* 1482 */         nsfw(), 
/* 1483 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 1486 */         ownerId(), 
/* 1487 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1496 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 1500 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableGuildCreateData withOwner(Possible<Boolean> value) {
/* 1508 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 1509 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 1511 */         id(), this.name, this.icon, this.splash, this.discoverySplash, newValue, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1517 */         permissions(), 
/* 1518 */         afkChannelId(), 
/* 1519 */         embedEnabled(), 
/* 1520 */         embedChannelId(), this.features, 
/*      */         
/* 1522 */         applicationId(), 
/* 1523 */         widgetEnabled(), 
/* 1524 */         widgetChannelId(), 
/* 1525 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1527 */         rulesChannelId(), 
/* 1528 */         maxPresences(), 
/* 1529 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1533 */         premiumSubscriptionCount(), 
/* 1534 */         publicUpdatesChannelId(), 
/* 1535 */         maxVideoChannelUsers(), 
/* 1536 */         approximateMemberCount(), 
/* 1537 */         approximatePresenceCount(), 
/* 1538 */         welcomeScreen(), 
/* 1539 */         nsfw(), 
/* 1540 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 1543 */         ownerId(), 
/* 1544 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1553 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 1557 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableGuildCreateData withOwner(Boolean value) {
/* 1565 */     Possible<Boolean> newValue = Possible.of(value);
/* 1566 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 1568 */         id(), this.name, this.icon, this.splash, this.discoverySplash, newValue, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1574 */         permissions(), 
/* 1575 */         afkChannelId(), 
/* 1576 */         embedEnabled(), 
/* 1577 */         embedChannelId(), this.features, 
/*      */         
/* 1579 */         applicationId(), 
/* 1580 */         widgetEnabled(), 
/* 1581 */         widgetChannelId(), 
/* 1582 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1584 */         rulesChannelId(), 
/* 1585 */         maxPresences(), 
/* 1586 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1590 */         premiumSubscriptionCount(), 
/* 1591 */         publicUpdatesChannelId(), 
/* 1592 */         maxVideoChannelUsers(), 
/* 1593 */         approximateMemberCount(), 
/* 1594 */         approximatePresenceCount(), 
/* 1595 */         welcomeScreen(), 
/* 1596 */         nsfw(), 
/* 1597 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 1600 */         ownerId(), 
/* 1601 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1610 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 1614 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableGuildCreateData withPermissions(Possible<Long> value) {
/* 1622 */     Possible<Long> newValue = Objects.<Possible<Long>>requireNonNull(value);
/* 1623 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 1625 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1630 */         owner(), newValue, 
/*      */         
/* 1632 */         afkChannelId(), 
/* 1633 */         embedEnabled(), 
/* 1634 */         embedChannelId(), this.features, 
/*      */         
/* 1636 */         applicationId(), 
/* 1637 */         widgetEnabled(), 
/* 1638 */         widgetChannelId(), 
/* 1639 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1641 */         rulesChannelId(), 
/* 1642 */         maxPresences(), 
/* 1643 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1647 */         premiumSubscriptionCount(), 
/* 1648 */         publicUpdatesChannelId(), 
/* 1649 */         maxVideoChannelUsers(), 
/* 1650 */         approximateMemberCount(), 
/* 1651 */         approximatePresenceCount(), 
/* 1652 */         welcomeScreen(), 
/* 1653 */         nsfw(), 
/* 1654 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 1657 */         ownerId(), 
/* 1658 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1667 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 1671 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableGuildCreateData withPermissions(Long value) {
/* 1679 */     Possible<Long> newValue = Possible.of(value);
/* 1680 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 1682 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1687 */         owner(), newValue, 
/*      */         
/* 1689 */         afkChannelId(), 
/* 1690 */         embedEnabled(), 
/* 1691 */         embedChannelId(), this.features, 
/*      */         
/* 1693 */         applicationId(), 
/* 1694 */         widgetEnabled(), 
/* 1695 */         widgetChannelId(), 
/* 1696 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1698 */         rulesChannelId(), 
/* 1699 */         maxPresences(), 
/* 1700 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1704 */         premiumSubscriptionCount(), 
/* 1705 */         publicUpdatesChannelId(), 
/* 1706 */         maxVideoChannelUsers(), 
/* 1707 */         approximateMemberCount(), 
/* 1708 */         approximatePresenceCount(), 
/* 1709 */         welcomeScreen(), 
/* 1710 */         nsfw(), 
/* 1711 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 1714 */         ownerId(), 
/* 1715 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1724 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 1728 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableGuildCreateData withAfkChannelId(Optional<Id> value) {
/* 1736 */     Optional<Id> newValue = Objects.<Optional<Id>>requireNonNull(value);
/* 1737 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 1739 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1744 */         owner(), 
/* 1745 */         permissions(), newValue, 
/*      */         
/* 1747 */         embedEnabled(), 
/* 1748 */         embedChannelId(), this.features, 
/*      */         
/* 1750 */         applicationId(), 
/* 1751 */         widgetEnabled(), 
/* 1752 */         widgetChannelId(), 
/* 1753 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1755 */         rulesChannelId(), 
/* 1756 */         maxPresences(), 
/* 1757 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1761 */         premiumSubscriptionCount(), 
/* 1762 */         publicUpdatesChannelId(), 
/* 1763 */         maxVideoChannelUsers(), 
/* 1764 */         approximateMemberCount(), 
/* 1765 */         approximatePresenceCount(), 
/* 1766 */         welcomeScreen(), 
/* 1767 */         nsfw(), 
/* 1768 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 1771 */         ownerId(), 
/* 1772 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1781 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 1785 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableGuildCreateData withAfkChannelId(long value) {
/* 1793 */     Optional<Id> newValue = Optional.of(Id.of(value));
/* 1794 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 1796 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1801 */         owner(), 
/* 1802 */         permissions(), newValue, 
/*      */         
/* 1804 */         embedEnabled(), 
/* 1805 */         embedChannelId(), this.features, 
/*      */         
/* 1807 */         applicationId(), 
/* 1808 */         widgetEnabled(), 
/* 1809 */         widgetChannelId(), 
/* 1810 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1812 */         rulesChannelId(), 
/* 1813 */         maxPresences(), 
/* 1814 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1818 */         premiumSubscriptionCount(), 
/* 1819 */         publicUpdatesChannelId(), 
/* 1820 */         maxVideoChannelUsers(), 
/* 1821 */         approximateMemberCount(), 
/* 1822 */         approximatePresenceCount(), 
/* 1823 */         welcomeScreen(), 
/* 1824 */         nsfw(), 
/* 1825 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 1828 */         ownerId(), 
/* 1829 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1838 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 1842 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableGuildCreateData withEmbedEnabled(Possible<Boolean> value) {
/* 1850 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 1851 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 1853 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1858 */         owner(), 
/* 1859 */         permissions(), 
/* 1860 */         afkChannelId(), newValue, 
/*      */         
/* 1862 */         embedChannelId(), this.features, 
/*      */         
/* 1864 */         applicationId(), 
/* 1865 */         widgetEnabled(), 
/* 1866 */         widgetChannelId(), 
/* 1867 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1869 */         rulesChannelId(), 
/* 1870 */         maxPresences(), 
/* 1871 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1875 */         premiumSubscriptionCount(), 
/* 1876 */         publicUpdatesChannelId(), 
/* 1877 */         maxVideoChannelUsers(), 
/* 1878 */         approximateMemberCount(), 
/* 1879 */         approximatePresenceCount(), 
/* 1880 */         welcomeScreen(), 
/* 1881 */         nsfw(), 
/* 1882 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 1885 */         ownerId(), 
/* 1886 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1895 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 1899 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableGuildCreateData withEmbedEnabled(Boolean value) {
/* 1907 */     Possible<Boolean> newValue = Possible.of(value);
/* 1908 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 1910 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1915 */         owner(), 
/* 1916 */         permissions(), 
/* 1917 */         afkChannelId(), newValue, 
/*      */         
/* 1919 */         embedChannelId(), this.features, 
/*      */         
/* 1921 */         applicationId(), 
/* 1922 */         widgetEnabled(), 
/* 1923 */         widgetChannelId(), 
/* 1924 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1926 */         rulesChannelId(), 
/* 1927 */         maxPresences(), 
/* 1928 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1932 */         premiumSubscriptionCount(), 
/* 1933 */         publicUpdatesChannelId(), 
/* 1934 */         maxVideoChannelUsers(), 
/* 1935 */         approximateMemberCount(), 
/* 1936 */         approximatePresenceCount(), 
/* 1937 */         welcomeScreen(), 
/* 1938 */         nsfw(), 
/* 1939 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 1942 */         ownerId(), 
/* 1943 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1952 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 1956 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableGuildCreateData withEmbedChannelId(Possible<Optional<Id>> value) {
/* 1964 */     Possible<Optional<Id>> newValue = Objects.<Possible<Optional<Id>>>requireNonNull(value);
/* 1965 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 1967 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1972 */         owner(), 
/* 1973 */         permissions(), 
/* 1974 */         afkChannelId(), 
/* 1975 */         embedEnabled(), newValue, this.features, 
/*      */ 
/*      */         
/* 1978 */         applicationId(), 
/* 1979 */         widgetEnabled(), 
/* 1980 */         widgetChannelId(), 
/* 1981 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1983 */         rulesChannelId(), 
/* 1984 */         maxPresences(), 
/* 1985 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1989 */         premiumSubscriptionCount(), 
/* 1990 */         publicUpdatesChannelId(), 
/* 1991 */         maxVideoChannelUsers(), 
/* 1992 */         approximateMemberCount(), 
/* 1993 */         approximatePresenceCount(), 
/* 1994 */         welcomeScreen(), 
/* 1995 */         nsfw(), 
/* 1996 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 1999 */         ownerId(), 
/* 2000 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2009 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 2013 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableGuildCreateData withEmbedChannelId(@Nullable Long value) {
/* 2023 */     Possible<Optional<Id>> newValue = (value == null) ? Possible.of(Optional.empty()) : Possible.of(Optional.of(Id.of(value.longValue())));
/* 2024 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 2026 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2031 */         owner(), 
/* 2032 */         permissions(), 
/* 2033 */         afkChannelId(), 
/* 2034 */         embedEnabled(), newValue, this.features, 
/*      */ 
/*      */         
/* 2037 */         applicationId(), 
/* 2038 */         widgetEnabled(), 
/* 2039 */         widgetChannelId(), 
/* 2040 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2042 */         rulesChannelId(), 
/* 2043 */         maxPresences(), 
/* 2044 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2048 */         premiumSubscriptionCount(), 
/* 2049 */         publicUpdatesChannelId(), 
/* 2050 */         maxVideoChannelUsers(), 
/* 2051 */         approximateMemberCount(), 
/* 2052 */         approximatePresenceCount(), 
/* 2053 */         welcomeScreen(), 
/* 2054 */         nsfw(), 
/* 2055 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 2058 */         ownerId(), 
/* 2059 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2068 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 2072 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableGuildCreateData withEmbedChannelIdOrNull(@Nullable Long value) {
/* 2081 */     Possible<Optional<Id>> newValue = (value == null) ? Possible.of(Optional.empty()) : Possible.of(Optional.of(Id.of(value.longValue())));
/* 2082 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 2084 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2089 */         owner(), 
/* 2090 */         permissions(), 
/* 2091 */         afkChannelId(), 
/* 2092 */         embedEnabled(), newValue, this.features, 
/*      */ 
/*      */         
/* 2095 */         applicationId(), 
/* 2096 */         widgetEnabled(), 
/* 2097 */         widgetChannelId(), 
/* 2098 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2100 */         rulesChannelId(), 
/* 2101 */         maxPresences(), 
/* 2102 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2106 */         premiumSubscriptionCount(), 
/* 2107 */         publicUpdatesChannelId(), 
/* 2108 */         maxVideoChannelUsers(), 
/* 2109 */         approximateMemberCount(), 
/* 2110 */         approximatePresenceCount(), 
/* 2111 */         welcomeScreen(), 
/* 2112 */         nsfw(), 
/* 2113 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 2116 */         ownerId(), 
/* 2117 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2126 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 2130 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildCreateData withFeatures(String... elements) {
/* 2143 */     List<String> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 2144 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 2146 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2151 */         owner(), 
/* 2152 */         permissions(), 
/* 2153 */         afkChannelId(), 
/* 2154 */         embedEnabled(), 
/* 2155 */         embedChannelId(), newValue, 
/*      */         
/* 2157 */         applicationId(), 
/* 2158 */         widgetEnabled(), 
/* 2159 */         widgetChannelId(), 
/* 2160 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2162 */         rulesChannelId(), 
/* 2163 */         maxPresences(), 
/* 2164 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2168 */         premiumSubscriptionCount(), 
/* 2169 */         publicUpdatesChannelId(), 
/* 2170 */         maxVideoChannelUsers(), 
/* 2171 */         approximateMemberCount(), 
/* 2172 */         approximatePresenceCount(), 
/* 2173 */         welcomeScreen(), 
/* 2174 */         nsfw(), 
/* 2175 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 2178 */         ownerId(), 
/* 2179 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2188 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 2192 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildCreateData withFeatures(Iterable<String> elements) {
/* 2206 */     if (this.features == elements) return this; 
/* 2207 */     List<String> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 2208 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 2210 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2215 */         owner(), 
/* 2216 */         permissions(), 
/* 2217 */         afkChannelId(), 
/* 2218 */         embedEnabled(), 
/* 2219 */         embedChannelId(), newValue, 
/*      */         
/* 2221 */         applicationId(), 
/* 2222 */         widgetEnabled(), 
/* 2223 */         widgetChannelId(), 
/* 2224 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2226 */         rulesChannelId(), 
/* 2227 */         maxPresences(), 
/* 2228 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2232 */         premiumSubscriptionCount(), 
/* 2233 */         publicUpdatesChannelId(), 
/* 2234 */         maxVideoChannelUsers(), 
/* 2235 */         approximateMemberCount(), 
/* 2236 */         approximatePresenceCount(), 
/* 2237 */         welcomeScreen(), 
/* 2238 */         nsfw(), 
/* 2239 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 2242 */         ownerId(), 
/* 2243 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2252 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 2256 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableGuildCreateData withApplicationId(Optional<Id> value) {
/* 2264 */     Optional<Id> newValue = Objects.<Optional<Id>>requireNonNull(value);
/* 2265 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 2267 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2272 */         owner(), 
/* 2273 */         permissions(), 
/* 2274 */         afkChannelId(), 
/* 2275 */         embedEnabled(), 
/* 2276 */         embedChannelId(), this.features, newValue, 
/*      */ 
/*      */         
/* 2279 */         widgetEnabled(), 
/* 2280 */         widgetChannelId(), 
/* 2281 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2283 */         rulesChannelId(), 
/* 2284 */         maxPresences(), 
/* 2285 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2289 */         premiumSubscriptionCount(), 
/* 2290 */         publicUpdatesChannelId(), 
/* 2291 */         maxVideoChannelUsers(), 
/* 2292 */         approximateMemberCount(), 
/* 2293 */         approximatePresenceCount(), 
/* 2294 */         welcomeScreen(), 
/* 2295 */         nsfw(), 
/* 2296 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 2299 */         ownerId(), 
/* 2300 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2309 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 2313 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableGuildCreateData withApplicationId(long value) {
/* 2321 */     Optional<Id> newValue = Optional.of(Id.of(value));
/* 2322 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 2324 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2329 */         owner(), 
/* 2330 */         permissions(), 
/* 2331 */         afkChannelId(), 
/* 2332 */         embedEnabled(), 
/* 2333 */         embedChannelId(), this.features, newValue, 
/*      */ 
/*      */         
/* 2336 */         widgetEnabled(), 
/* 2337 */         widgetChannelId(), 
/* 2338 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2340 */         rulesChannelId(), 
/* 2341 */         maxPresences(), 
/* 2342 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2346 */         premiumSubscriptionCount(), 
/* 2347 */         publicUpdatesChannelId(), 
/* 2348 */         maxVideoChannelUsers(), 
/* 2349 */         approximateMemberCount(), 
/* 2350 */         approximatePresenceCount(), 
/* 2351 */         welcomeScreen(), 
/* 2352 */         nsfw(), 
/* 2353 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 2356 */         ownerId(), 
/* 2357 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2366 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 2370 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableGuildCreateData withWidgetEnabled(Possible<Boolean> value) {
/* 2378 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 2379 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 2381 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2386 */         owner(), 
/* 2387 */         permissions(), 
/* 2388 */         afkChannelId(), 
/* 2389 */         embedEnabled(), 
/* 2390 */         embedChannelId(), this.features, 
/*      */         
/* 2392 */         applicationId(), newValue, 
/*      */         
/* 2394 */         widgetChannelId(), 
/* 2395 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2397 */         rulesChannelId(), 
/* 2398 */         maxPresences(), 
/* 2399 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2403 */         premiumSubscriptionCount(), 
/* 2404 */         publicUpdatesChannelId(), 
/* 2405 */         maxVideoChannelUsers(), 
/* 2406 */         approximateMemberCount(), 
/* 2407 */         approximatePresenceCount(), 
/* 2408 */         welcomeScreen(), 
/* 2409 */         nsfw(), 
/* 2410 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 2413 */         ownerId(), 
/* 2414 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2423 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 2427 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableGuildCreateData withWidgetEnabled(Boolean value) {
/* 2435 */     Possible<Boolean> newValue = Possible.of(value);
/* 2436 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 2438 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2443 */         owner(), 
/* 2444 */         permissions(), 
/* 2445 */         afkChannelId(), 
/* 2446 */         embedEnabled(), 
/* 2447 */         embedChannelId(), this.features, 
/*      */         
/* 2449 */         applicationId(), newValue, 
/*      */         
/* 2451 */         widgetChannelId(), 
/* 2452 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2454 */         rulesChannelId(), 
/* 2455 */         maxPresences(), 
/* 2456 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2460 */         premiumSubscriptionCount(), 
/* 2461 */         publicUpdatesChannelId(), 
/* 2462 */         maxVideoChannelUsers(), 
/* 2463 */         approximateMemberCount(), 
/* 2464 */         approximatePresenceCount(), 
/* 2465 */         welcomeScreen(), 
/* 2466 */         nsfw(), 
/* 2467 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 2470 */         ownerId(), 
/* 2471 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2480 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 2484 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableGuildCreateData withWidgetChannelId(Possible<Optional<Id>> value) {
/* 2492 */     Possible<Optional<Id>> newValue = Objects.<Possible<Optional<Id>>>requireNonNull(value);
/* 2493 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 2495 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2500 */         owner(), 
/* 2501 */         permissions(), 
/* 2502 */         afkChannelId(), 
/* 2503 */         embedEnabled(), 
/* 2504 */         embedChannelId(), this.features, 
/*      */         
/* 2506 */         applicationId(), 
/* 2507 */         widgetEnabled(), newValue, 
/*      */         
/* 2509 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2511 */         rulesChannelId(), 
/* 2512 */         maxPresences(), 
/* 2513 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2517 */         premiumSubscriptionCount(), 
/* 2518 */         publicUpdatesChannelId(), 
/* 2519 */         maxVideoChannelUsers(), 
/* 2520 */         approximateMemberCount(), 
/* 2521 */         approximatePresenceCount(), 
/* 2522 */         welcomeScreen(), 
/* 2523 */         nsfw(), 
/* 2524 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 2527 */         ownerId(), 
/* 2528 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2537 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 2541 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableGuildCreateData withWidgetChannelId(@Nullable Long value) {
/* 2551 */     Possible<Optional<Id>> newValue = (value == null) ? Possible.of(Optional.empty()) : Possible.of(Optional.of(Id.of(value.longValue())));
/* 2552 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 2554 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2559 */         owner(), 
/* 2560 */         permissions(), 
/* 2561 */         afkChannelId(), 
/* 2562 */         embedEnabled(), 
/* 2563 */         embedChannelId(), this.features, 
/*      */         
/* 2565 */         applicationId(), 
/* 2566 */         widgetEnabled(), newValue, 
/*      */         
/* 2568 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2570 */         rulesChannelId(), 
/* 2571 */         maxPresences(), 
/* 2572 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2576 */         premiumSubscriptionCount(), 
/* 2577 */         publicUpdatesChannelId(), 
/* 2578 */         maxVideoChannelUsers(), 
/* 2579 */         approximateMemberCount(), 
/* 2580 */         approximatePresenceCount(), 
/* 2581 */         welcomeScreen(), 
/* 2582 */         nsfw(), 
/* 2583 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 2586 */         ownerId(), 
/* 2587 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2596 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 2600 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableGuildCreateData withWidgetChannelIdOrNull(@Nullable Long value) {
/* 2609 */     Possible<Optional<Id>> newValue = (value == null) ? Possible.of(Optional.empty()) : Possible.of(Optional.of(Id.of(value.longValue())));
/* 2610 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 2612 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2617 */         owner(), 
/* 2618 */         permissions(), 
/* 2619 */         afkChannelId(), 
/* 2620 */         embedEnabled(), 
/* 2621 */         embedChannelId(), this.features, 
/*      */         
/* 2623 */         applicationId(), 
/* 2624 */         widgetEnabled(), newValue, 
/*      */         
/* 2626 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2628 */         rulesChannelId(), 
/* 2629 */         maxPresences(), 
/* 2630 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2634 */         premiumSubscriptionCount(), 
/* 2635 */         publicUpdatesChannelId(), 
/* 2636 */         maxVideoChannelUsers(), 
/* 2637 */         approximateMemberCount(), 
/* 2638 */         approximatePresenceCount(), 
/* 2639 */         welcomeScreen(), 
/* 2640 */         nsfw(), 
/* 2641 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 2644 */         ownerId(), 
/* 2645 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2654 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 2658 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableGuildCreateData withSystemChannelId(Optional<Id> value) {
/* 2666 */     Optional<Id> newValue = Objects.<Optional<Id>>requireNonNull(value);
/* 2667 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 2669 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2674 */         owner(), 
/* 2675 */         permissions(), 
/* 2676 */         afkChannelId(), 
/* 2677 */         embedEnabled(), 
/* 2678 */         embedChannelId(), this.features, 
/*      */         
/* 2680 */         applicationId(), 
/* 2681 */         widgetEnabled(), 
/* 2682 */         widgetChannelId(), newValue, this.systemChannelFlags, 
/*      */ 
/*      */         
/* 2685 */         rulesChannelId(), 
/* 2686 */         maxPresences(), 
/* 2687 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2691 */         premiumSubscriptionCount(), 
/* 2692 */         publicUpdatesChannelId(), 
/* 2693 */         maxVideoChannelUsers(), 
/* 2694 */         approximateMemberCount(), 
/* 2695 */         approximatePresenceCount(), 
/* 2696 */         welcomeScreen(), 
/* 2697 */         nsfw(), 
/* 2698 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 2701 */         ownerId(), 
/* 2702 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2711 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 2715 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableGuildCreateData withSystemChannelId(long value) {
/* 2723 */     Optional<Id> newValue = Optional.of(Id.of(value));
/* 2724 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 2726 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2731 */         owner(), 
/* 2732 */         permissions(), 
/* 2733 */         afkChannelId(), 
/* 2734 */         embedEnabled(), 
/* 2735 */         embedChannelId(), this.features, 
/*      */         
/* 2737 */         applicationId(), 
/* 2738 */         widgetEnabled(), 
/* 2739 */         widgetChannelId(), newValue, this.systemChannelFlags, 
/*      */ 
/*      */         
/* 2742 */         rulesChannelId(), 
/* 2743 */         maxPresences(), 
/* 2744 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2748 */         premiumSubscriptionCount(), 
/* 2749 */         publicUpdatesChannelId(), 
/* 2750 */         maxVideoChannelUsers(), 
/* 2751 */         approximateMemberCount(), 
/* 2752 */         approximatePresenceCount(), 
/* 2753 */         welcomeScreen(), 
/* 2754 */         nsfw(), 
/* 2755 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 2758 */         ownerId(), 
/* 2759 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2768 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 2772 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildCreateData withSystemChannelFlags(int value) {
/* 2785 */     Integer newValue = Integer.valueOf(value);
/* 2786 */     if (Objects.equals(this.systemChannelFlags, newValue)) return this; 
/* 2787 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 2789 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2794 */         owner(), 
/* 2795 */         permissions(), 
/* 2796 */         afkChannelId(), 
/* 2797 */         embedEnabled(), 
/* 2798 */         embedChannelId(), this.features, 
/*      */         
/* 2800 */         applicationId(), 
/* 2801 */         widgetEnabled(), 
/* 2802 */         widgetChannelId(), 
/* 2803 */         systemChannelId(), newValue, 
/*      */         
/* 2805 */         rulesChannelId(), 
/* 2806 */         maxPresences(), 
/* 2807 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2811 */         premiumSubscriptionCount(), 
/* 2812 */         publicUpdatesChannelId(), 
/* 2813 */         maxVideoChannelUsers(), 
/* 2814 */         approximateMemberCount(), 
/* 2815 */         approximatePresenceCount(), 
/* 2816 */         welcomeScreen(), 
/* 2817 */         nsfw(), 
/* 2818 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 2821 */         ownerId(), 
/* 2822 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2831 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 2835 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildCreateData withSystemChannelFlags(OptionalInt optional) {
/* 2849 */     Integer value = optional.isPresent() ? Integer.valueOf(optional.getAsInt()) : null;
/* 2850 */     if (Objects.equals(this.systemChannelFlags, value)) return this; 
/* 2851 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 2853 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2858 */         owner(), 
/* 2859 */         permissions(), 
/* 2860 */         afkChannelId(), 
/* 2861 */         embedEnabled(), 
/* 2862 */         embedChannelId(), this.features, 
/*      */         
/* 2864 */         applicationId(), 
/* 2865 */         widgetEnabled(), 
/* 2866 */         widgetChannelId(), 
/* 2867 */         systemChannelId(), value, 
/*      */         
/* 2869 */         rulesChannelId(), 
/* 2870 */         maxPresences(), 
/* 2871 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2875 */         premiumSubscriptionCount(), 
/* 2876 */         publicUpdatesChannelId(), 
/* 2877 */         maxVideoChannelUsers(), 
/* 2878 */         approximateMemberCount(), 
/* 2879 */         approximatePresenceCount(), 
/* 2880 */         welcomeScreen(), 
/* 2881 */         nsfw(), 
/* 2882 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 2885 */         ownerId(), 
/* 2886 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2895 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 2899 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableGuildCreateData withRulesChannelId(Optional<Id> value) {
/* 2907 */     Optional<Id> newValue = Objects.<Optional<Id>>requireNonNull(value);
/* 2908 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 2910 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2915 */         owner(), 
/* 2916 */         permissions(), 
/* 2917 */         afkChannelId(), 
/* 2918 */         embedEnabled(), 
/* 2919 */         embedChannelId(), this.features, 
/*      */         
/* 2921 */         applicationId(), 
/* 2922 */         widgetEnabled(), 
/* 2923 */         widgetChannelId(), 
/* 2924 */         systemChannelId(), this.systemChannelFlags, newValue, 
/*      */ 
/*      */         
/* 2927 */         maxPresences(), 
/* 2928 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2932 */         premiumSubscriptionCount(), 
/* 2933 */         publicUpdatesChannelId(), 
/* 2934 */         maxVideoChannelUsers(), 
/* 2935 */         approximateMemberCount(), 
/* 2936 */         approximatePresenceCount(), 
/* 2937 */         welcomeScreen(), 
/* 2938 */         nsfw(), 
/* 2939 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 2942 */         ownerId(), 
/* 2943 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2952 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 2956 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableGuildCreateData withRulesChannelId(long value) {
/* 2964 */     Optional<Id> newValue = Optional.of(Id.of(value));
/* 2965 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 2967 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2972 */         owner(), 
/* 2973 */         permissions(), 
/* 2974 */         afkChannelId(), 
/* 2975 */         embedEnabled(), 
/* 2976 */         embedChannelId(), this.features, 
/*      */         
/* 2978 */         applicationId(), 
/* 2979 */         widgetEnabled(), 
/* 2980 */         widgetChannelId(), 
/* 2981 */         systemChannelId(), this.systemChannelFlags, newValue, 
/*      */ 
/*      */         
/* 2984 */         maxPresences(), 
/* 2985 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2989 */         premiumSubscriptionCount(), 
/* 2990 */         publicUpdatesChannelId(), 
/* 2991 */         maxVideoChannelUsers(), 
/* 2992 */         approximateMemberCount(), 
/* 2993 */         approximatePresenceCount(), 
/* 2994 */         welcomeScreen(), 
/* 2995 */         nsfw(), 
/* 2996 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 2999 */         ownerId(), 
/* 3000 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3009 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 3013 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableGuildCreateData withMaxPresences(Possible<Optional<Integer>> value) {
/* 3021 */     Possible<Optional<Integer>> newValue = Objects.<Possible<Optional<Integer>>>requireNonNull(value);
/* 3022 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 3024 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3029 */         owner(), 
/* 3030 */         permissions(), 
/* 3031 */         afkChannelId(), 
/* 3032 */         embedEnabled(), 
/* 3033 */         embedChannelId(), this.features, 
/*      */         
/* 3035 */         applicationId(), 
/* 3036 */         widgetEnabled(), 
/* 3037 */         widgetChannelId(), 
/* 3038 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 3040 */         rulesChannelId(), newValue, 
/*      */         
/* 3042 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 3046 */         premiumSubscriptionCount(), 
/* 3047 */         publicUpdatesChannelId(), 
/* 3048 */         maxVideoChannelUsers(), 
/* 3049 */         approximateMemberCount(), 
/* 3050 */         approximatePresenceCount(), 
/* 3051 */         welcomeScreen(), 
/* 3052 */         nsfw(), 
/* 3053 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 3056 */         ownerId(), 
/* 3057 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3066 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 3070 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableGuildCreateData withMaxPresences(@Nullable Integer value) {
/* 3079 */     Possible<Optional<Integer>> newValue = Possible.of(Optional.ofNullable(value));
/* 3080 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 3082 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3087 */         owner(), 
/* 3088 */         permissions(), 
/* 3089 */         afkChannelId(), 
/* 3090 */         embedEnabled(), 
/* 3091 */         embedChannelId(), this.features, 
/*      */         
/* 3093 */         applicationId(), 
/* 3094 */         widgetEnabled(), 
/* 3095 */         widgetChannelId(), 
/* 3096 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 3098 */         rulesChannelId(), newValue, 
/*      */         
/* 3100 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 3104 */         premiumSubscriptionCount(), 
/* 3105 */         publicUpdatesChannelId(), 
/* 3106 */         maxVideoChannelUsers(), 
/* 3107 */         approximateMemberCount(), 
/* 3108 */         approximatePresenceCount(), 
/* 3109 */         welcomeScreen(), 
/* 3110 */         nsfw(), 
/* 3111 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 3114 */         ownerId(), 
/* 3115 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3124 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 3128 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableGuildCreateData withMaxPresencesOrNull(@Nullable Integer value) {
/* 3136 */     Possible<Optional<Integer>> newValue = Possible.of(Optional.ofNullable(value));
/* 3137 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 3139 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3144 */         owner(), 
/* 3145 */         permissions(), 
/* 3146 */         afkChannelId(), 
/* 3147 */         embedEnabled(), 
/* 3148 */         embedChannelId(), this.features, 
/*      */         
/* 3150 */         applicationId(), 
/* 3151 */         widgetEnabled(), 
/* 3152 */         widgetChannelId(), 
/* 3153 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 3155 */         rulesChannelId(), newValue, 
/*      */         
/* 3157 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 3161 */         premiumSubscriptionCount(), 
/* 3162 */         publicUpdatesChannelId(), 
/* 3163 */         maxVideoChannelUsers(), 
/* 3164 */         approximateMemberCount(), 
/* 3165 */         approximatePresenceCount(), 
/* 3166 */         welcomeScreen(), 
/* 3167 */         nsfw(), 
/* 3168 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 3171 */         ownerId(), 
/* 3172 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3181 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 3185 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableGuildCreateData withMaxMembers(Possible<Integer> value) {
/* 3193 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 3194 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 3196 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3201 */         owner(), 
/* 3202 */         permissions(), 
/* 3203 */         afkChannelId(), 
/* 3204 */         embedEnabled(), 
/* 3205 */         embedChannelId(), this.features, 
/*      */         
/* 3207 */         applicationId(), 
/* 3208 */         widgetEnabled(), 
/* 3209 */         widgetChannelId(), 
/* 3210 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 3212 */         rulesChannelId(), 
/* 3213 */         maxPresences(), newValue, this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3218 */         premiumSubscriptionCount(), 
/* 3219 */         publicUpdatesChannelId(), 
/* 3220 */         maxVideoChannelUsers(), 
/* 3221 */         approximateMemberCount(), 
/* 3222 */         approximatePresenceCount(), 
/* 3223 */         welcomeScreen(), 
/* 3224 */         nsfw(), 
/* 3225 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 3228 */         ownerId(), 
/* 3229 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3238 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 3242 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableGuildCreateData withMaxMembers(Integer value) {
/* 3250 */     Possible<Integer> newValue = Possible.of(value);
/* 3251 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 3253 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3258 */         owner(), 
/* 3259 */         permissions(), 
/* 3260 */         afkChannelId(), 
/* 3261 */         embedEnabled(), 
/* 3262 */         embedChannelId(), this.features, 
/*      */         
/* 3264 */         applicationId(), 
/* 3265 */         widgetEnabled(), 
/* 3266 */         widgetChannelId(), 
/* 3267 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 3269 */         rulesChannelId(), 
/* 3270 */         maxPresences(), newValue, this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3275 */         premiumSubscriptionCount(), 
/* 3276 */         publicUpdatesChannelId(), 
/* 3277 */         maxVideoChannelUsers(), 
/* 3278 */         approximateMemberCount(), 
/* 3279 */         approximatePresenceCount(), 
/* 3280 */         welcomeScreen(), 
/* 3281 */         nsfw(), 
/* 3282 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 3285 */         ownerId(), 
/* 3286 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3295 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 3299 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildCreateData withVanityUrlCode(String value) {
/* 3312 */     String newValue = Objects.<String>requireNonNull(value, "vanityUrlCode");
/* 3313 */     if (Objects.equals(this.vanityUrlCode, newValue)) return this; 
/* 3314 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 3316 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3321 */         owner(), 
/* 3322 */         permissions(), 
/* 3323 */         afkChannelId(), 
/* 3324 */         embedEnabled(), 
/* 3325 */         embedChannelId(), this.features, 
/*      */         
/* 3327 */         applicationId(), 
/* 3328 */         widgetEnabled(), 
/* 3329 */         widgetChannelId(), 
/* 3330 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 3332 */         rulesChannelId(), 
/* 3333 */         maxPresences(), 
/* 3334 */         maxMembers(), newValue, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 3338 */         premiumSubscriptionCount(), 
/* 3339 */         publicUpdatesChannelId(), 
/* 3340 */         maxVideoChannelUsers(), 
/* 3341 */         approximateMemberCount(), 
/* 3342 */         approximatePresenceCount(), 
/* 3343 */         welcomeScreen(), 
/* 3344 */         nsfw(), 
/* 3345 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 3348 */         ownerId(), 
/* 3349 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3358 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 3362 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildCreateData withVanityUrlCode(Optional<String> optional) {
/* 3376 */     String value = optional.orElse(null);
/* 3377 */     if (Objects.equals(this.vanityUrlCode, value)) return this; 
/* 3378 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 3380 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3385 */         owner(), 
/* 3386 */         permissions(), 
/* 3387 */         afkChannelId(), 
/* 3388 */         embedEnabled(), 
/* 3389 */         embedChannelId(), this.features, 
/*      */         
/* 3391 */         applicationId(), 
/* 3392 */         widgetEnabled(), 
/* 3393 */         widgetChannelId(), 
/* 3394 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 3396 */         rulesChannelId(), 
/* 3397 */         maxPresences(), 
/* 3398 */         maxMembers(), value, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 3402 */         premiumSubscriptionCount(), 
/* 3403 */         publicUpdatesChannelId(), 
/* 3404 */         maxVideoChannelUsers(), 
/* 3405 */         approximateMemberCount(), 
/* 3406 */         approximatePresenceCount(), 
/* 3407 */         welcomeScreen(), 
/* 3408 */         nsfw(), 
/* 3409 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 3412 */         ownerId(), 
/* 3413 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3422 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 3426 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildCreateData withDescription(String value) {
/* 3439 */     String newValue = Objects.<String>requireNonNull(value, "description");
/* 3440 */     if (Objects.equals(this.description, newValue)) return this; 
/* 3441 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 3443 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3448 */         owner(), 
/* 3449 */         permissions(), 
/* 3450 */         afkChannelId(), 
/* 3451 */         embedEnabled(), 
/* 3452 */         embedChannelId(), this.features, 
/*      */         
/* 3454 */         applicationId(), 
/* 3455 */         widgetEnabled(), 
/* 3456 */         widgetChannelId(), 
/* 3457 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 3459 */         rulesChannelId(), 
/* 3460 */         maxPresences(), 
/* 3461 */         maxMembers(), this.vanityUrlCode, newValue, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 3465 */         premiumSubscriptionCount(), 
/* 3466 */         publicUpdatesChannelId(), 
/* 3467 */         maxVideoChannelUsers(), 
/* 3468 */         approximateMemberCount(), 
/* 3469 */         approximatePresenceCount(), 
/* 3470 */         welcomeScreen(), 
/* 3471 */         nsfw(), 
/* 3472 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 3475 */         ownerId(), 
/* 3476 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3485 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 3489 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildCreateData withDescription(Optional<String> optional) {
/* 3503 */     String value = optional.orElse(null);
/* 3504 */     if (Objects.equals(this.description, value)) return this; 
/* 3505 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 3507 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3512 */         owner(), 
/* 3513 */         permissions(), 
/* 3514 */         afkChannelId(), 
/* 3515 */         embedEnabled(), 
/* 3516 */         embedChannelId(), this.features, 
/*      */         
/* 3518 */         applicationId(), 
/* 3519 */         widgetEnabled(), 
/* 3520 */         widgetChannelId(), 
/* 3521 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 3523 */         rulesChannelId(), 
/* 3524 */         maxPresences(), 
/* 3525 */         maxMembers(), this.vanityUrlCode, value, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 3529 */         premiumSubscriptionCount(), 
/* 3530 */         publicUpdatesChannelId(), 
/* 3531 */         maxVideoChannelUsers(), 
/* 3532 */         approximateMemberCount(), 
/* 3533 */         approximatePresenceCount(), 
/* 3534 */         welcomeScreen(), 
/* 3535 */         nsfw(), 
/* 3536 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 3539 */         ownerId(), 
/* 3540 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3549 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 3553 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildCreateData withBanner(String value) {
/* 3566 */     String newValue = Objects.<String>requireNonNull(value, "banner");
/* 3567 */     if (Objects.equals(this.banner, newValue)) return this; 
/* 3568 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 3570 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3575 */         owner(), 
/* 3576 */         permissions(), 
/* 3577 */         afkChannelId(), 
/* 3578 */         embedEnabled(), 
/* 3579 */         embedChannelId(), this.features, 
/*      */         
/* 3581 */         applicationId(), 
/* 3582 */         widgetEnabled(), 
/* 3583 */         widgetChannelId(), 
/* 3584 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 3586 */         rulesChannelId(), 
/* 3587 */         maxPresences(), 
/* 3588 */         maxMembers(), this.vanityUrlCode, this.description, newValue, 
/*      */ 
/*      */ 
/*      */         
/* 3592 */         premiumSubscriptionCount(), 
/* 3593 */         publicUpdatesChannelId(), 
/* 3594 */         maxVideoChannelUsers(), 
/* 3595 */         approximateMemberCount(), 
/* 3596 */         approximatePresenceCount(), 
/* 3597 */         welcomeScreen(), 
/* 3598 */         nsfw(), 
/* 3599 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 3602 */         ownerId(), 
/* 3603 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3612 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 3616 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildCreateData withBanner(Optional<String> optional) {
/* 3630 */     String value = optional.orElse(null);
/* 3631 */     if (Objects.equals(this.banner, value)) return this; 
/* 3632 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 3634 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3639 */         owner(), 
/* 3640 */         permissions(), 
/* 3641 */         afkChannelId(), 
/* 3642 */         embedEnabled(), 
/* 3643 */         embedChannelId(), this.features, 
/*      */         
/* 3645 */         applicationId(), 
/* 3646 */         widgetEnabled(), 
/* 3647 */         widgetChannelId(), 
/* 3648 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 3650 */         rulesChannelId(), 
/* 3651 */         maxPresences(), 
/* 3652 */         maxMembers(), this.vanityUrlCode, this.description, value, 
/*      */ 
/*      */ 
/*      */         
/* 3656 */         premiumSubscriptionCount(), 
/* 3657 */         publicUpdatesChannelId(), 
/* 3658 */         maxVideoChannelUsers(), 
/* 3659 */         approximateMemberCount(), 
/* 3660 */         approximatePresenceCount(), 
/* 3661 */         welcomeScreen(), 
/* 3662 */         nsfw(), 
/* 3663 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 3666 */         ownerId(), 
/* 3667 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3676 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 3680 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableGuildCreateData withPremiumSubscriptionCount(Possible<Integer> value) {
/* 3688 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 3689 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 3691 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3696 */         owner(), 
/* 3697 */         permissions(), 
/* 3698 */         afkChannelId(), 
/* 3699 */         embedEnabled(), 
/* 3700 */         embedChannelId(), this.features, 
/*      */         
/* 3702 */         applicationId(), 
/* 3703 */         widgetEnabled(), 
/* 3704 */         widgetChannelId(), 
/* 3705 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 3707 */         rulesChannelId(), 
/* 3708 */         maxPresences(), 
/* 3709 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, newValue, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3714 */         publicUpdatesChannelId(), 
/* 3715 */         maxVideoChannelUsers(), 
/* 3716 */         approximateMemberCount(), 
/* 3717 */         approximatePresenceCount(), 
/* 3718 */         welcomeScreen(), 
/* 3719 */         nsfw(), 
/* 3720 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 3723 */         ownerId(), 
/* 3724 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3733 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 3737 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableGuildCreateData withPremiumSubscriptionCount(Integer value) {
/* 3745 */     Possible<Integer> newValue = Possible.of(value);
/* 3746 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 3748 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3753 */         owner(), 
/* 3754 */         permissions(), 
/* 3755 */         afkChannelId(), 
/* 3756 */         embedEnabled(), 
/* 3757 */         embedChannelId(), this.features, 
/*      */         
/* 3759 */         applicationId(), 
/* 3760 */         widgetEnabled(), 
/* 3761 */         widgetChannelId(), 
/* 3762 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 3764 */         rulesChannelId(), 
/* 3765 */         maxPresences(), 
/* 3766 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, newValue, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3771 */         publicUpdatesChannelId(), 
/* 3772 */         maxVideoChannelUsers(), 
/* 3773 */         approximateMemberCount(), 
/* 3774 */         approximatePresenceCount(), 
/* 3775 */         welcomeScreen(), 
/* 3776 */         nsfw(), 
/* 3777 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 3780 */         ownerId(), 
/* 3781 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3790 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 3794 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableGuildCreateData withPublicUpdatesChannelId(Optional<Id> value) {
/* 3802 */     Optional<Id> newValue = Objects.<Optional<Id>>requireNonNull(value);
/* 3803 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 3805 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3810 */         owner(), 
/* 3811 */         permissions(), 
/* 3812 */         afkChannelId(), 
/* 3813 */         embedEnabled(), 
/* 3814 */         embedChannelId(), this.features, 
/*      */         
/* 3816 */         applicationId(), 
/* 3817 */         widgetEnabled(), 
/* 3818 */         widgetChannelId(), 
/* 3819 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 3821 */         rulesChannelId(), 
/* 3822 */         maxPresences(), 
/* 3823 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 3827 */         premiumSubscriptionCount(), newValue, 
/*      */         
/* 3829 */         maxVideoChannelUsers(), 
/* 3830 */         approximateMemberCount(), 
/* 3831 */         approximatePresenceCount(), 
/* 3832 */         welcomeScreen(), 
/* 3833 */         nsfw(), 
/* 3834 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 3837 */         ownerId(), 
/* 3838 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3847 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 3851 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableGuildCreateData withPublicUpdatesChannelId(long value) {
/* 3859 */     Optional<Id> newValue = Optional.of(Id.of(value));
/* 3860 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 3862 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3867 */         owner(), 
/* 3868 */         permissions(), 
/* 3869 */         afkChannelId(), 
/* 3870 */         embedEnabled(), 
/* 3871 */         embedChannelId(), this.features, 
/*      */         
/* 3873 */         applicationId(), 
/* 3874 */         widgetEnabled(), 
/* 3875 */         widgetChannelId(), 
/* 3876 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 3878 */         rulesChannelId(), 
/* 3879 */         maxPresences(), 
/* 3880 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 3884 */         premiumSubscriptionCount(), newValue, 
/*      */         
/* 3886 */         maxVideoChannelUsers(), 
/* 3887 */         approximateMemberCount(), 
/* 3888 */         approximatePresenceCount(), 
/* 3889 */         welcomeScreen(), 
/* 3890 */         nsfw(), 
/* 3891 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 3894 */         ownerId(), 
/* 3895 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3904 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 3908 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableGuildCreateData withMaxVideoChannelUsers(Possible<Integer> value) {
/* 3916 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 3917 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 3919 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3924 */         owner(), 
/* 3925 */         permissions(), 
/* 3926 */         afkChannelId(), 
/* 3927 */         embedEnabled(), 
/* 3928 */         embedChannelId(), this.features, 
/*      */         
/* 3930 */         applicationId(), 
/* 3931 */         widgetEnabled(), 
/* 3932 */         widgetChannelId(), 
/* 3933 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 3935 */         rulesChannelId(), 
/* 3936 */         maxPresences(), 
/* 3937 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 3941 */         premiumSubscriptionCount(), 
/* 3942 */         publicUpdatesChannelId(), newValue, 
/*      */         
/* 3944 */         approximateMemberCount(), 
/* 3945 */         approximatePresenceCount(), 
/* 3946 */         welcomeScreen(), 
/* 3947 */         nsfw(), 
/* 3948 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 3951 */         ownerId(), 
/* 3952 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3961 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 3965 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableGuildCreateData withMaxVideoChannelUsers(Integer value) {
/* 3973 */     Possible<Integer> newValue = Possible.of(value);
/* 3974 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 3976 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3981 */         owner(), 
/* 3982 */         permissions(), 
/* 3983 */         afkChannelId(), 
/* 3984 */         embedEnabled(), 
/* 3985 */         embedChannelId(), this.features, 
/*      */         
/* 3987 */         applicationId(), 
/* 3988 */         widgetEnabled(), 
/* 3989 */         widgetChannelId(), 
/* 3990 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 3992 */         rulesChannelId(), 
/* 3993 */         maxPresences(), 
/* 3994 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 3998 */         premiumSubscriptionCount(), 
/* 3999 */         publicUpdatesChannelId(), newValue, 
/*      */         
/* 4001 */         approximateMemberCount(), 
/* 4002 */         approximatePresenceCount(), 
/* 4003 */         welcomeScreen(), 
/* 4004 */         nsfw(), 
/* 4005 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 4008 */         ownerId(), 
/* 4009 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4018 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 4022 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableGuildCreateData withApproximateMemberCount(Possible<Integer> value) {
/* 4030 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 4031 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 4033 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4038 */         owner(), 
/* 4039 */         permissions(), 
/* 4040 */         afkChannelId(), 
/* 4041 */         embedEnabled(), 
/* 4042 */         embedChannelId(), this.features, 
/*      */         
/* 4044 */         applicationId(), 
/* 4045 */         widgetEnabled(), 
/* 4046 */         widgetChannelId(), 
/* 4047 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 4049 */         rulesChannelId(), 
/* 4050 */         maxPresences(), 
/* 4051 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 4055 */         premiumSubscriptionCount(), 
/* 4056 */         publicUpdatesChannelId(), 
/* 4057 */         maxVideoChannelUsers(), newValue, 
/*      */         
/* 4059 */         approximatePresenceCount(), 
/* 4060 */         welcomeScreen(), 
/* 4061 */         nsfw(), 
/* 4062 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 4065 */         ownerId(), 
/* 4066 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4075 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 4079 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableGuildCreateData withApproximateMemberCount(Integer value) {
/* 4087 */     Possible<Integer> newValue = Possible.of(value);
/* 4088 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 4090 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4095 */         owner(), 
/* 4096 */         permissions(), 
/* 4097 */         afkChannelId(), 
/* 4098 */         embedEnabled(), 
/* 4099 */         embedChannelId(), this.features, 
/*      */         
/* 4101 */         applicationId(), 
/* 4102 */         widgetEnabled(), 
/* 4103 */         widgetChannelId(), 
/* 4104 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 4106 */         rulesChannelId(), 
/* 4107 */         maxPresences(), 
/* 4108 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 4112 */         premiumSubscriptionCount(), 
/* 4113 */         publicUpdatesChannelId(), 
/* 4114 */         maxVideoChannelUsers(), newValue, 
/*      */         
/* 4116 */         approximatePresenceCount(), 
/* 4117 */         welcomeScreen(), 
/* 4118 */         nsfw(), 
/* 4119 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 4122 */         ownerId(), 
/* 4123 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4132 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 4136 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableGuildCreateData withApproximatePresenceCount(Possible<Integer> value) {
/* 4144 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 4145 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 4147 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4152 */         owner(), 
/* 4153 */         permissions(), 
/* 4154 */         afkChannelId(), 
/* 4155 */         embedEnabled(), 
/* 4156 */         embedChannelId(), this.features, 
/*      */         
/* 4158 */         applicationId(), 
/* 4159 */         widgetEnabled(), 
/* 4160 */         widgetChannelId(), 
/* 4161 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 4163 */         rulesChannelId(), 
/* 4164 */         maxPresences(), 
/* 4165 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 4169 */         premiumSubscriptionCount(), 
/* 4170 */         publicUpdatesChannelId(), 
/* 4171 */         maxVideoChannelUsers(), 
/* 4172 */         approximateMemberCount(), newValue, 
/*      */         
/* 4174 */         welcomeScreen(), 
/* 4175 */         nsfw(), 
/* 4176 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 4179 */         ownerId(), 
/* 4180 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4189 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 4193 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableGuildCreateData withApproximatePresenceCount(Integer value) {
/* 4201 */     Possible<Integer> newValue = Possible.of(value);
/* 4202 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 4204 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4209 */         owner(), 
/* 4210 */         permissions(), 
/* 4211 */         afkChannelId(), 
/* 4212 */         embedEnabled(), 
/* 4213 */         embedChannelId(), this.features, 
/*      */         
/* 4215 */         applicationId(), 
/* 4216 */         widgetEnabled(), 
/* 4217 */         widgetChannelId(), 
/* 4218 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 4220 */         rulesChannelId(), 
/* 4221 */         maxPresences(), 
/* 4222 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 4226 */         premiumSubscriptionCount(), 
/* 4227 */         publicUpdatesChannelId(), 
/* 4228 */         maxVideoChannelUsers(), 
/* 4229 */         approximateMemberCount(), newValue, 
/*      */         
/* 4231 */         welcomeScreen(), 
/* 4232 */         nsfw(), 
/* 4233 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 4236 */         ownerId(), 
/* 4237 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4246 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 4250 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableGuildCreateData withWelcomeScreen(Possible<WelcomeScreenData> value) {
/* 4258 */     Possible<WelcomeScreenData> newValue = Objects.<Possible<WelcomeScreenData>>requireNonNull(value);
/* 4259 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 4261 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4266 */         owner(), 
/* 4267 */         permissions(), 
/* 4268 */         afkChannelId(), 
/* 4269 */         embedEnabled(), 
/* 4270 */         embedChannelId(), this.features, 
/*      */         
/* 4272 */         applicationId(), 
/* 4273 */         widgetEnabled(), 
/* 4274 */         widgetChannelId(), 
/* 4275 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 4277 */         rulesChannelId(), 
/* 4278 */         maxPresences(), 
/* 4279 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 4283 */         premiumSubscriptionCount(), 
/* 4284 */         publicUpdatesChannelId(), 
/* 4285 */         maxVideoChannelUsers(), 
/* 4286 */         approximateMemberCount(), 
/* 4287 */         approximatePresenceCount(), newValue, 
/*      */         
/* 4289 */         nsfw(), 
/* 4290 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 4293 */         ownerId(), 
/* 4294 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4303 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 4307 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableGuildCreateData withWelcomeScreen(WelcomeScreenData value) {
/* 4315 */     Possible<WelcomeScreenData> newValue = Possible.of(value);
/* 4316 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 4318 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4323 */         owner(), 
/* 4324 */         permissions(), 
/* 4325 */         afkChannelId(), 
/* 4326 */         embedEnabled(), 
/* 4327 */         embedChannelId(), this.features, 
/*      */         
/* 4329 */         applicationId(), 
/* 4330 */         widgetEnabled(), 
/* 4331 */         widgetChannelId(), 
/* 4332 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 4334 */         rulesChannelId(), 
/* 4335 */         maxPresences(), 
/* 4336 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 4340 */         premiumSubscriptionCount(), 
/* 4341 */         publicUpdatesChannelId(), 
/* 4342 */         maxVideoChannelUsers(), 
/* 4343 */         approximateMemberCount(), 
/* 4344 */         approximatePresenceCount(), newValue, 
/*      */         
/* 4346 */         nsfw(), 
/* 4347 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 4350 */         ownerId(), 
/* 4351 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4360 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 4364 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableGuildCreateData withNsfw(Possible<Boolean> value) {
/* 4372 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 4373 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 4375 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4380 */         owner(), 
/* 4381 */         permissions(), 
/* 4382 */         afkChannelId(), 
/* 4383 */         embedEnabled(), 
/* 4384 */         embedChannelId(), this.features, 
/*      */         
/* 4386 */         applicationId(), 
/* 4387 */         widgetEnabled(), 
/* 4388 */         widgetChannelId(), 
/* 4389 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 4391 */         rulesChannelId(), 
/* 4392 */         maxPresences(), 
/* 4393 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 4397 */         premiumSubscriptionCount(), 
/* 4398 */         publicUpdatesChannelId(), 
/* 4399 */         maxVideoChannelUsers(), 
/* 4400 */         approximateMemberCount(), 
/* 4401 */         approximatePresenceCount(), 
/* 4402 */         welcomeScreen(), newValue, 
/*      */         
/* 4404 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 4407 */         ownerId(), 
/* 4408 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4417 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 4421 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableGuildCreateData withNsfw(Boolean value) {
/* 4429 */     Possible<Boolean> newValue = Possible.of(value);
/* 4430 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 4432 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4437 */         owner(), 
/* 4438 */         permissions(), 
/* 4439 */         afkChannelId(), 
/* 4440 */         embedEnabled(), 
/* 4441 */         embedChannelId(), this.features, 
/*      */         
/* 4443 */         applicationId(), 
/* 4444 */         widgetEnabled(), 
/* 4445 */         widgetChannelId(), 
/* 4446 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 4448 */         rulesChannelId(), 
/* 4449 */         maxPresences(), 
/* 4450 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 4454 */         premiumSubscriptionCount(), 
/* 4455 */         publicUpdatesChannelId(), 
/* 4456 */         maxVideoChannelUsers(), 
/* 4457 */         approximateMemberCount(), 
/* 4458 */         approximatePresenceCount(), 
/* 4459 */         welcomeScreen(), newValue, 
/*      */         
/* 4461 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 4464 */         ownerId(), 
/* 4465 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4474 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 4478 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableGuildCreateData withSafetyAlertsChannelId(Optional<Id> value) {
/* 4486 */     Optional<Id> newValue = Objects.<Optional<Id>>requireNonNull(value);
/* 4487 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 4489 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4494 */         owner(), 
/* 4495 */         permissions(), 
/* 4496 */         afkChannelId(), 
/* 4497 */         embedEnabled(), 
/* 4498 */         embedChannelId(), this.features, 
/*      */         
/* 4500 */         applicationId(), 
/* 4501 */         widgetEnabled(), 
/* 4502 */         widgetChannelId(), 
/* 4503 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 4505 */         rulesChannelId(), 
/* 4506 */         maxPresences(), 
/* 4507 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 4511 */         premiumSubscriptionCount(), 
/* 4512 */         publicUpdatesChannelId(), 
/* 4513 */         maxVideoChannelUsers(), 
/* 4514 */         approximateMemberCount(), 
/* 4515 */         approximatePresenceCount(), 
/* 4516 */         welcomeScreen(), 
/* 4517 */         nsfw(), newValue, this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */ 
/*      */         
/* 4521 */         ownerId(), 
/* 4522 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4531 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 4535 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableGuildCreateData withSafetyAlertsChannelId(long value) {
/* 4543 */     Optional<Id> newValue = Optional.of(Id.of(value));
/* 4544 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 4546 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4551 */         owner(), 
/* 4552 */         permissions(), 
/* 4553 */         afkChannelId(), 
/* 4554 */         embedEnabled(), 
/* 4555 */         embedChannelId(), this.features, 
/*      */         
/* 4557 */         applicationId(), 
/* 4558 */         widgetEnabled(), 
/* 4559 */         widgetChannelId(), 
/* 4560 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 4562 */         rulesChannelId(), 
/* 4563 */         maxPresences(), 
/* 4564 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 4568 */         premiumSubscriptionCount(), 
/* 4569 */         publicUpdatesChannelId(), 
/* 4570 */         maxVideoChannelUsers(), 
/* 4571 */         approximateMemberCount(), 
/* 4572 */         approximatePresenceCount(), 
/* 4573 */         welcomeScreen(), 
/* 4574 */         nsfw(), newValue, this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */ 
/*      */         
/* 4578 */         ownerId(), 
/* 4579 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4588 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 4592 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildCreateData withVerificationLevel(int value) {
/* 4606 */     if (this.verificationLevel == value) return this; 
/* 4607 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 4609 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4614 */         owner(), 
/* 4615 */         permissions(), 
/* 4616 */         afkChannelId(), 
/* 4617 */         embedEnabled(), 
/* 4618 */         embedChannelId(), this.features, 
/*      */         
/* 4620 */         applicationId(), 
/* 4621 */         widgetEnabled(), 
/* 4622 */         widgetChannelId(), 
/* 4623 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 4625 */         rulesChannelId(), 
/* 4626 */         maxPresences(), 
/* 4627 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 4631 */         premiumSubscriptionCount(), 
/* 4632 */         publicUpdatesChannelId(), 
/* 4633 */         maxVideoChannelUsers(), 
/* 4634 */         approximateMemberCount(), 
/* 4635 */         approximatePresenceCount(), 
/* 4636 */         welcomeScreen(), 
/* 4637 */         nsfw(), 
/* 4638 */         safetyAlertsChannelId(), value, this.nsfwLevel, 
/*      */ 
/*      */         
/* 4641 */         ownerId(), 
/* 4642 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4651 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 4655 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildCreateData withNsfwLevel(int value) {
/* 4669 */     if (this.nsfwLevel == value) return this; 
/* 4670 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 4672 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4677 */         owner(), 
/* 4678 */         permissions(), 
/* 4679 */         afkChannelId(), 
/* 4680 */         embedEnabled(), 
/* 4681 */         embedChannelId(), this.features, 
/*      */         
/* 4683 */         applicationId(), 
/* 4684 */         widgetEnabled(), 
/* 4685 */         widgetChannelId(), 
/* 4686 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 4688 */         rulesChannelId(), 
/* 4689 */         maxPresences(), 
/* 4690 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 4694 */         premiumSubscriptionCount(), 
/* 4695 */         publicUpdatesChannelId(), 
/* 4696 */         maxVideoChannelUsers(), 
/* 4697 */         approximateMemberCount(), 
/* 4698 */         approximatePresenceCount(), 
/* 4699 */         welcomeScreen(), 
/* 4700 */         nsfw(), 
/* 4701 */         safetyAlertsChannelId(), this.verificationLevel, value, 
/*      */ 
/*      */         
/* 4704 */         ownerId(), 
/* 4705 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4714 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 4718 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableGuildCreateData withOwnerId(long value) {
/* 4726 */     Id newValue = Id.of(value);
/* 4727 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 4729 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4734 */         owner(), 
/* 4735 */         permissions(), 
/* 4736 */         afkChannelId(), 
/* 4737 */         embedEnabled(), 
/* 4738 */         embedChannelId(), this.features, 
/*      */         
/* 4740 */         applicationId(), 
/* 4741 */         widgetEnabled(), 
/* 4742 */         widgetChannelId(), 
/* 4743 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 4745 */         rulesChannelId(), 
/* 4746 */         maxPresences(), 
/* 4747 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 4751 */         premiumSubscriptionCount(), 
/* 4752 */         publicUpdatesChannelId(), 
/* 4753 */         maxVideoChannelUsers(), 
/* 4754 */         approximateMemberCount(), 
/* 4755 */         approximatePresenceCount(), 
/* 4756 */         welcomeScreen(), 
/* 4757 */         nsfw(), 
/* 4758 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, newValue, 
/*      */ 
/*      */ 
/*      */         
/* 4762 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4771 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 4775 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableGuildCreateData withOwnerId(String value) {
/* 4783 */     Id newValue = Id.of(value);
/* 4784 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 4786 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4791 */         owner(), 
/* 4792 */         permissions(), 
/* 4793 */         afkChannelId(), 
/* 4794 */         embedEnabled(), 
/* 4795 */         embedChannelId(), this.features, 
/*      */         
/* 4797 */         applicationId(), 
/* 4798 */         widgetEnabled(), 
/* 4799 */         widgetChannelId(), 
/* 4800 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 4802 */         rulesChannelId(), 
/* 4803 */         maxPresences(), 
/* 4804 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 4808 */         premiumSubscriptionCount(), 
/* 4809 */         publicUpdatesChannelId(), 
/* 4810 */         maxVideoChannelUsers(), 
/* 4811 */         approximateMemberCount(), 
/* 4812 */         approximatePresenceCount(), 
/* 4813 */         welcomeScreen(), 
/* 4814 */         nsfw(), 
/* 4815 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, newValue, 
/*      */ 
/*      */ 
/*      */         
/* 4819 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4828 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 4832 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableGuildCreateData withRegion(Possible<Optional<String>> value) {
/* 4840 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/* 4841 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 4843 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4848 */         owner(), 
/* 4849 */         permissions(), 
/* 4850 */         afkChannelId(), 
/* 4851 */         embedEnabled(), 
/* 4852 */         embedChannelId(), this.features, 
/*      */         
/* 4854 */         applicationId(), 
/* 4855 */         widgetEnabled(), 
/* 4856 */         widgetChannelId(), 
/* 4857 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 4859 */         rulesChannelId(), 
/* 4860 */         maxPresences(), 
/* 4861 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 4865 */         premiumSubscriptionCount(), 
/* 4866 */         publicUpdatesChannelId(), 
/* 4867 */         maxVideoChannelUsers(), 
/* 4868 */         approximateMemberCount(), 
/* 4869 */         approximatePresenceCount(), 
/* 4870 */         welcomeScreen(), 
/* 4871 */         nsfw(), 
/* 4872 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 4875 */         ownerId(), newValue, this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4885 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 4889 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableGuildCreateData withRegion(@Nullable String value) {
/* 4898 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 4899 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 4901 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4906 */         owner(), 
/* 4907 */         permissions(), 
/* 4908 */         afkChannelId(), 
/* 4909 */         embedEnabled(), 
/* 4910 */         embedChannelId(), this.features, 
/*      */         
/* 4912 */         applicationId(), 
/* 4913 */         widgetEnabled(), 
/* 4914 */         widgetChannelId(), 
/* 4915 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 4917 */         rulesChannelId(), 
/* 4918 */         maxPresences(), 
/* 4919 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 4923 */         premiumSubscriptionCount(), 
/* 4924 */         publicUpdatesChannelId(), 
/* 4925 */         maxVideoChannelUsers(), 
/* 4926 */         approximateMemberCount(), 
/* 4927 */         approximatePresenceCount(), 
/* 4928 */         welcomeScreen(), 
/* 4929 */         nsfw(), 
/* 4930 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 4933 */         ownerId(), newValue, this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4943 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 4947 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableGuildCreateData withRegionOrNull(@Nullable String value) {
/* 4955 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 4956 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 4958 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4963 */         owner(), 
/* 4964 */         permissions(), 
/* 4965 */         afkChannelId(), 
/* 4966 */         embedEnabled(), 
/* 4967 */         embedChannelId(), this.features, 
/*      */         
/* 4969 */         applicationId(), 
/* 4970 */         widgetEnabled(), 
/* 4971 */         widgetChannelId(), 
/* 4972 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 4974 */         rulesChannelId(), 
/* 4975 */         maxPresences(), 
/* 4976 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 4980 */         premiumSubscriptionCount(), 
/* 4981 */         publicUpdatesChannelId(), 
/* 4982 */         maxVideoChannelUsers(), 
/* 4983 */         approximateMemberCount(), 
/* 4984 */         approximatePresenceCount(), 
/* 4985 */         welcomeScreen(), 
/* 4986 */         nsfw(), 
/* 4987 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 4990 */         ownerId(), newValue, this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5000 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 5004 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildCreateData withAfkTimeout(int value) {
/* 5018 */     if (this.afkTimeout == value) return this; 
/* 5019 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 5021 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5026 */         owner(), 
/* 5027 */         permissions(), 
/* 5028 */         afkChannelId(), 
/* 5029 */         embedEnabled(), 
/* 5030 */         embedChannelId(), this.features, 
/*      */         
/* 5032 */         applicationId(), 
/* 5033 */         widgetEnabled(), 
/* 5034 */         widgetChannelId(), 
/* 5035 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 5037 */         rulesChannelId(), 
/* 5038 */         maxPresences(), 
/* 5039 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 5043 */         premiumSubscriptionCount(), 
/* 5044 */         publicUpdatesChannelId(), 
/* 5045 */         maxVideoChannelUsers(), 
/* 5046 */         approximateMemberCount(), 
/* 5047 */         approximatePresenceCount(), 
/* 5048 */         welcomeScreen(), 
/* 5049 */         nsfw(), 
/* 5050 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 5053 */         ownerId(), 
/* 5054 */         region(), value, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5063 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 5067 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildCreateData withDefaultMessageNotifications(int value) {
/* 5081 */     if (this.defaultMessageNotifications == value) return this; 
/* 5082 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 5084 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5089 */         owner(), 
/* 5090 */         permissions(), 
/* 5091 */         afkChannelId(), 
/* 5092 */         embedEnabled(), 
/* 5093 */         embedChannelId(), this.features, 
/*      */         
/* 5095 */         applicationId(), 
/* 5096 */         widgetEnabled(), 
/* 5097 */         widgetChannelId(), 
/* 5098 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 5100 */         rulesChannelId(), 
/* 5101 */         maxPresences(), 
/* 5102 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 5106 */         premiumSubscriptionCount(), 
/* 5107 */         publicUpdatesChannelId(), 
/* 5108 */         maxVideoChannelUsers(), 
/* 5109 */         approximateMemberCount(), 
/* 5110 */         approximatePresenceCount(), 
/* 5111 */         welcomeScreen(), 
/* 5112 */         nsfw(), 
/* 5113 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 5116 */         ownerId(), 
/* 5117 */         region(), this.afkTimeout, value, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5126 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 5130 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildCreateData withExplicitContentFilter(int value) {
/* 5144 */     if (this.explicitContentFilter == value) return this; 
/* 5145 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 5147 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5152 */         owner(), 
/* 5153 */         permissions(), 
/* 5154 */         afkChannelId(), 
/* 5155 */         embedEnabled(), 
/* 5156 */         embedChannelId(), this.features, 
/*      */         
/* 5158 */         applicationId(), 
/* 5159 */         widgetEnabled(), 
/* 5160 */         widgetChannelId(), 
/* 5161 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 5163 */         rulesChannelId(), 
/* 5164 */         maxPresences(), 
/* 5165 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 5169 */         premiumSubscriptionCount(), 
/* 5170 */         publicUpdatesChannelId(), 
/* 5171 */         maxVideoChannelUsers(), 
/* 5172 */         approximateMemberCount(), 
/* 5173 */         approximatePresenceCount(), 
/* 5174 */         welcomeScreen(), 
/* 5175 */         nsfw(), 
/* 5176 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 5179 */         ownerId(), 
/* 5180 */         region(), this.afkTimeout, this.defaultMessageNotifications, value, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5189 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 5193 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildCreateData withMfaLevel(int value) {
/* 5207 */     if (this.mfaLevel == value) return this; 
/* 5208 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 5210 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5215 */         owner(), 
/* 5216 */         permissions(), 
/* 5217 */         afkChannelId(), 
/* 5218 */         embedEnabled(), 
/* 5219 */         embedChannelId(), this.features, 
/*      */         
/* 5221 */         applicationId(), 
/* 5222 */         widgetEnabled(), 
/* 5223 */         widgetChannelId(), 
/* 5224 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 5226 */         rulesChannelId(), 
/* 5227 */         maxPresences(), 
/* 5228 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 5232 */         premiumSubscriptionCount(), 
/* 5233 */         publicUpdatesChannelId(), 
/* 5234 */         maxVideoChannelUsers(), 
/* 5235 */         approximateMemberCount(), 
/* 5236 */         approximatePresenceCount(), 
/* 5237 */         welcomeScreen(), 
/* 5238 */         nsfw(), 
/* 5239 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 5242 */         ownerId(), 
/* 5243 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, value, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5252 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 5256 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildCreateData withPremiumTier(int value) {
/* 5270 */     if (this.premiumTier == value) return this; 
/* 5271 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 5273 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5278 */         owner(), 
/* 5279 */         permissions(), 
/* 5280 */         afkChannelId(), 
/* 5281 */         embedEnabled(), 
/* 5282 */         embedChannelId(), this.features, 
/*      */         
/* 5284 */         applicationId(), 
/* 5285 */         widgetEnabled(), 
/* 5286 */         widgetChannelId(), 
/* 5287 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 5289 */         rulesChannelId(), 
/* 5290 */         maxPresences(), 
/* 5291 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 5295 */         premiumSubscriptionCount(), 
/* 5296 */         publicUpdatesChannelId(), 
/* 5297 */         maxVideoChannelUsers(), 
/* 5298 */         approximateMemberCount(), 
/* 5299 */         approximatePresenceCount(), 
/* 5300 */         welcomeScreen(), 
/* 5301 */         nsfw(), 
/* 5302 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 5305 */         ownerId(), 
/* 5306 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, value, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5315 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 5319 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildCreateData withPreferredLocale(String value) {
/* 5333 */     String newValue = Objects.<String>requireNonNull(value, "preferredLocale");
/* 5334 */     if (this.preferredLocale.equals(newValue)) return this; 
/* 5335 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 5337 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5342 */         owner(), 
/* 5343 */         permissions(), 
/* 5344 */         afkChannelId(), 
/* 5345 */         embedEnabled(), 
/* 5346 */         embedChannelId(), this.features, 
/*      */         
/* 5348 */         applicationId(), 
/* 5349 */         widgetEnabled(), 
/* 5350 */         widgetChannelId(), 
/* 5351 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 5353 */         rulesChannelId(), 
/* 5354 */         maxPresences(), 
/* 5355 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 5359 */         premiumSubscriptionCount(), 
/* 5360 */         publicUpdatesChannelId(), 
/* 5361 */         maxVideoChannelUsers(), 
/* 5362 */         approximateMemberCount(), 
/* 5363 */         approximatePresenceCount(), 
/* 5364 */         welcomeScreen(), 
/* 5365 */         nsfw(), 
/* 5366 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 5369 */         ownerId(), 
/* 5370 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, newValue, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5379 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 5383 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildCreateData withJoinedAt(String value) {
/* 5397 */     String newValue = Objects.<String>requireNonNull(value, "joinedAt");
/* 5398 */     if (this.joinedAt.equals(newValue)) return this; 
/* 5399 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 5401 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5406 */         owner(), 
/* 5407 */         permissions(), 
/* 5408 */         afkChannelId(), 
/* 5409 */         embedEnabled(), 
/* 5410 */         embedChannelId(), this.features, 
/*      */         
/* 5412 */         applicationId(), 
/* 5413 */         widgetEnabled(), 
/* 5414 */         widgetChannelId(), 
/* 5415 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 5417 */         rulesChannelId(), 
/* 5418 */         maxPresences(), 
/* 5419 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 5423 */         premiumSubscriptionCount(), 
/* 5424 */         publicUpdatesChannelId(), 
/* 5425 */         maxVideoChannelUsers(), 
/* 5426 */         approximateMemberCount(), 
/* 5427 */         approximatePresenceCount(), 
/* 5428 */         welcomeScreen(), 
/* 5429 */         nsfw(), 
/* 5430 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 5433 */         ownerId(), 
/* 5434 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, newValue, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5443 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 5447 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildCreateData withLarge(boolean value) {
/* 5461 */     if (this.large == value) return this; 
/* 5462 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 5464 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5469 */         owner(), 
/* 5470 */         permissions(), 
/* 5471 */         afkChannelId(), 
/* 5472 */         embedEnabled(), 
/* 5473 */         embedChannelId(), this.features, 
/*      */         
/* 5475 */         applicationId(), 
/* 5476 */         widgetEnabled(), 
/* 5477 */         widgetChannelId(), 
/* 5478 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 5480 */         rulesChannelId(), 
/* 5481 */         maxPresences(), 
/* 5482 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 5486 */         premiumSubscriptionCount(), 
/* 5487 */         publicUpdatesChannelId(), 
/* 5488 */         maxVideoChannelUsers(), 
/* 5489 */         approximateMemberCount(), 
/* 5490 */         approximatePresenceCount(), 
/* 5491 */         welcomeScreen(), 
/* 5492 */         nsfw(), 
/* 5493 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 5496 */         ownerId(), 
/* 5497 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, value, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5506 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 5510 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableGuildCreateData withUnavailable(Possible<Boolean> value) {
/* 5518 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 5519 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 5521 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5526 */         owner(), 
/* 5527 */         permissions(), 
/* 5528 */         afkChannelId(), 
/* 5529 */         embedEnabled(), 
/* 5530 */         embedChannelId(), this.features, 
/*      */         
/* 5532 */         applicationId(), 
/* 5533 */         widgetEnabled(), 
/* 5534 */         widgetChannelId(), 
/* 5535 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 5537 */         rulesChannelId(), 
/* 5538 */         maxPresences(), 
/* 5539 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 5543 */         premiumSubscriptionCount(), 
/* 5544 */         publicUpdatesChannelId(), 
/* 5545 */         maxVideoChannelUsers(), 
/* 5546 */         approximateMemberCount(), 
/* 5547 */         approximatePresenceCount(), 
/* 5548 */         welcomeScreen(), 
/* 5549 */         nsfw(), 
/* 5550 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 5553 */         ownerId(), 
/* 5554 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, newValue, this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5567 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableGuildCreateData withUnavailable(Boolean value) {
/* 5575 */     Possible<Boolean> newValue = Possible.of(value);
/* 5576 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 5578 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5583 */         owner(), 
/* 5584 */         permissions(), 
/* 5585 */         afkChannelId(), 
/* 5586 */         embedEnabled(), 
/* 5587 */         embedChannelId(), this.features, 
/*      */         
/* 5589 */         applicationId(), 
/* 5590 */         widgetEnabled(), 
/* 5591 */         widgetChannelId(), 
/* 5592 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 5594 */         rulesChannelId(), 
/* 5595 */         maxPresences(), 
/* 5596 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 5600 */         premiumSubscriptionCount(), 
/* 5601 */         publicUpdatesChannelId(), 
/* 5602 */         maxVideoChannelUsers(), 
/* 5603 */         approximateMemberCount(), 
/* 5604 */         approximatePresenceCount(), 
/* 5605 */         welcomeScreen(), 
/* 5606 */         nsfw(), 
/* 5607 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 5610 */         ownerId(), 
/* 5611 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, newValue, this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5624 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildCreateData withMemberCount(int value) {
/* 5638 */     if (this.memberCount == value) return this; 
/* 5639 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 5641 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5646 */         owner(), 
/* 5647 */         permissions(), 
/* 5648 */         afkChannelId(), 
/* 5649 */         embedEnabled(), 
/* 5650 */         embedChannelId(), this.features, 
/*      */         
/* 5652 */         applicationId(), 
/* 5653 */         widgetEnabled(), 
/* 5654 */         widgetChannelId(), 
/* 5655 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 5657 */         rulesChannelId(), 
/* 5658 */         maxPresences(), 
/* 5659 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 5663 */         premiumSubscriptionCount(), 
/* 5664 */         publicUpdatesChannelId(), 
/* 5665 */         maxVideoChannelUsers(), 
/* 5666 */         approximateMemberCount(), 
/* 5667 */         approximatePresenceCount(), 
/* 5668 */         welcomeScreen(), 
/* 5669 */         nsfw(), 
/* 5670 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 5673 */         ownerId(), 
/* 5674 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5683 */         unavailable(), value, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 5687 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildCreateData withRoles(RoleData... elements) {
/* 5700 */     List<RoleData> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 5701 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 5703 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5708 */         owner(), 
/* 5709 */         permissions(), 
/* 5710 */         afkChannelId(), 
/* 5711 */         embedEnabled(), 
/* 5712 */         embedChannelId(), this.features, 
/*      */         
/* 5714 */         applicationId(), 
/* 5715 */         widgetEnabled(), 
/* 5716 */         widgetChannelId(), 
/* 5717 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 5719 */         rulesChannelId(), 
/* 5720 */         maxPresences(), 
/* 5721 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 5725 */         premiumSubscriptionCount(), 
/* 5726 */         publicUpdatesChannelId(), 
/* 5727 */         maxVideoChannelUsers(), 
/* 5728 */         approximateMemberCount(), 
/* 5729 */         approximatePresenceCount(), 
/* 5730 */         welcomeScreen(), 
/* 5731 */         nsfw(), 
/* 5732 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 5735 */         ownerId(), 
/* 5736 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5745 */         unavailable(), this.memberCount, newValue, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 5749 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildCreateData withRoles(Iterable<? extends RoleData> elements) {
/* 5763 */     if (this.roles == elements) return this; 
/* 5764 */     List<RoleData> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 5765 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 5767 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5772 */         owner(), 
/* 5773 */         permissions(), 
/* 5774 */         afkChannelId(), 
/* 5775 */         embedEnabled(), 
/* 5776 */         embedChannelId(), this.features, 
/*      */         
/* 5778 */         applicationId(), 
/* 5779 */         widgetEnabled(), 
/* 5780 */         widgetChannelId(), 
/* 5781 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 5783 */         rulesChannelId(), 
/* 5784 */         maxPresences(), 
/* 5785 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 5789 */         premiumSubscriptionCount(), 
/* 5790 */         publicUpdatesChannelId(), 
/* 5791 */         maxVideoChannelUsers(), 
/* 5792 */         approximateMemberCount(), 
/* 5793 */         approximatePresenceCount(), 
/* 5794 */         welcomeScreen(), 
/* 5795 */         nsfw(), 
/* 5796 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 5799 */         ownerId(), 
/* 5800 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5809 */         unavailable(), this.memberCount, newValue, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 5813 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildCreateData withEmojis(EmojiData... elements) {
/* 5826 */     List<EmojiData> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 5827 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 5829 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5834 */         owner(), 
/* 5835 */         permissions(), 
/* 5836 */         afkChannelId(), 
/* 5837 */         embedEnabled(), 
/* 5838 */         embedChannelId(), this.features, 
/*      */         
/* 5840 */         applicationId(), 
/* 5841 */         widgetEnabled(), 
/* 5842 */         widgetChannelId(), 
/* 5843 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 5845 */         rulesChannelId(), 
/* 5846 */         maxPresences(), 
/* 5847 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 5851 */         premiumSubscriptionCount(), 
/* 5852 */         publicUpdatesChannelId(), 
/* 5853 */         maxVideoChannelUsers(), 
/* 5854 */         approximateMemberCount(), 
/* 5855 */         approximatePresenceCount(), 
/* 5856 */         welcomeScreen(), 
/* 5857 */         nsfw(), 
/* 5858 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 5861 */         ownerId(), 
/* 5862 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5871 */         unavailable(), this.memberCount, this.roles, newValue, 
/*      */ 
/*      */ 
/*      */         
/* 5875 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildCreateData withEmojis(Iterable<? extends EmojiData> elements) {
/* 5889 */     if (this.emojis == elements) return this; 
/* 5890 */     List<EmojiData> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 5891 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 5893 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5898 */         owner(), 
/* 5899 */         permissions(), 
/* 5900 */         afkChannelId(), 
/* 5901 */         embedEnabled(), 
/* 5902 */         embedChannelId(), this.features, 
/*      */         
/* 5904 */         applicationId(), 
/* 5905 */         widgetEnabled(), 
/* 5906 */         widgetChannelId(), 
/* 5907 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 5909 */         rulesChannelId(), 
/* 5910 */         maxPresences(), 
/* 5911 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 5915 */         premiumSubscriptionCount(), 
/* 5916 */         publicUpdatesChannelId(), 
/* 5917 */         maxVideoChannelUsers(), 
/* 5918 */         approximateMemberCount(), 
/* 5919 */         approximatePresenceCount(), 
/* 5920 */         welcomeScreen(), 
/* 5921 */         nsfw(), 
/* 5922 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 5925 */         ownerId(), 
/* 5926 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5935 */         unavailable(), this.memberCount, this.roles, newValue, 
/*      */ 
/*      */ 
/*      */         
/* 5939 */         stickers(), this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableGuildCreateData withStickers(Possible<List<StickerData>> possible) {
/* 5947 */     Possible<List<StickerData>> newValue = Objects.<Possible<List<StickerData>>>requireNonNull(possible);
/* 5948 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 5950 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5955 */         owner(), 
/* 5956 */         permissions(), 
/* 5957 */         afkChannelId(), 
/* 5958 */         embedEnabled(), 
/* 5959 */         embedChannelId(), this.features, 
/*      */         
/* 5961 */         applicationId(), 
/* 5962 */         widgetEnabled(), 
/* 5963 */         widgetChannelId(), 
/* 5964 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 5966 */         rulesChannelId(), 
/* 5967 */         maxPresences(), 
/* 5968 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 5972 */         premiumSubscriptionCount(), 
/* 5973 */         publicUpdatesChannelId(), 
/* 5974 */         maxVideoChannelUsers(), 
/* 5975 */         approximateMemberCount(), 
/* 5976 */         approximatePresenceCount(), 
/* 5977 */         welcomeScreen(), 
/* 5978 */         nsfw(), 
/* 5979 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 5982 */         ownerId(), 
/* 5983 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5992 */         unavailable(), this.memberCount, this.roles, this.emojis, newValue, this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableGuildCreateData withStickers(Iterable<StickerData> elements) {
/* 6004 */     Possible<List<StickerData>> newValue = Possible.of(
/* 6005 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/* 6006 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 6008 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 6013 */         owner(), 
/* 6014 */         permissions(), 
/* 6015 */         afkChannelId(), 
/* 6016 */         embedEnabled(), 
/* 6017 */         embedChannelId(), this.features, 
/*      */         
/* 6019 */         applicationId(), 
/* 6020 */         widgetEnabled(), 
/* 6021 */         widgetChannelId(), 
/* 6022 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 6024 */         rulesChannelId(), 
/* 6025 */         maxPresences(), 
/* 6026 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 6030 */         premiumSubscriptionCount(), 
/* 6031 */         publicUpdatesChannelId(), 
/* 6032 */         maxVideoChannelUsers(), 
/* 6033 */         approximateMemberCount(), 
/* 6034 */         approximatePresenceCount(), 
/* 6035 */         welcomeScreen(), 
/* 6036 */         nsfw(), 
/* 6037 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 6040 */         ownerId(), 
/* 6041 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 6050 */         unavailable(), this.memberCount, this.roles, this.emojis, newValue, this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @SafeVarargs
/*      */   public final ImmutableGuildCreateData withStickers(StickerData... elements) {
/* 6063 */     Possible<List<StickerData>> newValue = Possible.of(Arrays.asList(elements));
/* 6064 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 6066 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 6071 */         owner(), 
/* 6072 */         permissions(), 
/* 6073 */         afkChannelId(), 
/* 6074 */         embedEnabled(), 
/* 6075 */         embedChannelId(), this.features, 
/*      */         
/* 6077 */         applicationId(), 
/* 6078 */         widgetEnabled(), 
/* 6079 */         widgetChannelId(), 
/* 6080 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 6082 */         rulesChannelId(), 
/* 6083 */         maxPresences(), 
/* 6084 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 6088 */         premiumSubscriptionCount(), 
/* 6089 */         publicUpdatesChannelId(), 
/* 6090 */         maxVideoChannelUsers(), 
/* 6091 */         approximateMemberCount(), 
/* 6092 */         approximatePresenceCount(), 
/* 6093 */         welcomeScreen(), 
/* 6094 */         nsfw(), 
/* 6095 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 6098 */         ownerId(), 
/* 6099 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 6108 */         unavailable(), this.memberCount, this.roles, this.emojis, newValue, this.voiceStates, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildCreateData withVoiceStates(VoiceStateData... elements) {
/* 6125 */     List<VoiceStateData> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 6126 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 6128 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 6133 */         owner(), 
/* 6134 */         permissions(), 
/* 6135 */         afkChannelId(), 
/* 6136 */         embedEnabled(), 
/* 6137 */         embedChannelId(), this.features, 
/*      */         
/* 6139 */         applicationId(), 
/* 6140 */         widgetEnabled(), 
/* 6141 */         widgetChannelId(), 
/* 6142 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 6144 */         rulesChannelId(), 
/* 6145 */         maxPresences(), 
/* 6146 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 6150 */         premiumSubscriptionCount(), 
/* 6151 */         publicUpdatesChannelId(), 
/* 6152 */         maxVideoChannelUsers(), 
/* 6153 */         approximateMemberCount(), 
/* 6154 */         approximatePresenceCount(), 
/* 6155 */         welcomeScreen(), 
/* 6156 */         nsfw(), 
/* 6157 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 6160 */         ownerId(), 
/* 6161 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 6170 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 6174 */         stickers(), newValue, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildCreateData withVoiceStates(Iterable<? extends VoiceStateData> elements) {
/* 6188 */     if (this.voiceStates == elements) return this; 
/* 6189 */     List<VoiceStateData> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 6190 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 6192 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 6197 */         owner(), 
/* 6198 */         permissions(), 
/* 6199 */         afkChannelId(), 
/* 6200 */         embedEnabled(), 
/* 6201 */         embedChannelId(), this.features, 
/*      */         
/* 6203 */         applicationId(), 
/* 6204 */         widgetEnabled(), 
/* 6205 */         widgetChannelId(), 
/* 6206 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 6208 */         rulesChannelId(), 
/* 6209 */         maxPresences(), 
/* 6210 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 6214 */         premiumSubscriptionCount(), 
/* 6215 */         publicUpdatesChannelId(), 
/* 6216 */         maxVideoChannelUsers(), 
/* 6217 */         approximateMemberCount(), 
/* 6218 */         approximatePresenceCount(), 
/* 6219 */         welcomeScreen(), 
/* 6220 */         nsfw(), 
/* 6221 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 6224 */         ownerId(), 
/* 6225 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 6234 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 6238 */         stickers(), newValue, this.members, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildCreateData withMembers(MemberData... elements) {
/* 6251 */     List<MemberData> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 6252 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 6254 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 6259 */         owner(), 
/* 6260 */         permissions(), 
/* 6261 */         afkChannelId(), 
/* 6262 */         embedEnabled(), 
/* 6263 */         embedChannelId(), this.features, 
/*      */         
/* 6265 */         applicationId(), 
/* 6266 */         widgetEnabled(), 
/* 6267 */         widgetChannelId(), 
/* 6268 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 6270 */         rulesChannelId(), 
/* 6271 */         maxPresences(), 
/* 6272 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 6276 */         premiumSubscriptionCount(), 
/* 6277 */         publicUpdatesChannelId(), 
/* 6278 */         maxVideoChannelUsers(), 
/* 6279 */         approximateMemberCount(), 
/* 6280 */         approximatePresenceCount(), 
/* 6281 */         welcomeScreen(), 
/* 6282 */         nsfw(), 
/* 6283 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 6286 */         ownerId(), 
/* 6287 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 6296 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 6300 */         stickers(), this.voiceStates, newValue, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildCreateData withMembers(Iterable<? extends MemberData> elements) {
/* 6314 */     if (this.members == elements) return this; 
/* 6315 */     List<MemberData> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 6316 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 6318 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 6323 */         owner(), 
/* 6324 */         permissions(), 
/* 6325 */         afkChannelId(), 
/* 6326 */         embedEnabled(), 
/* 6327 */         embedChannelId(), this.features, 
/*      */         
/* 6329 */         applicationId(), 
/* 6330 */         widgetEnabled(), 
/* 6331 */         widgetChannelId(), 
/* 6332 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 6334 */         rulesChannelId(), 
/* 6335 */         maxPresences(), 
/* 6336 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 6340 */         premiumSubscriptionCount(), 
/* 6341 */         publicUpdatesChannelId(), 
/* 6342 */         maxVideoChannelUsers(), 
/* 6343 */         approximateMemberCount(), 
/* 6344 */         approximatePresenceCount(), 
/* 6345 */         welcomeScreen(), 
/* 6346 */         nsfw(), 
/* 6347 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 6350 */         ownerId(), 
/* 6351 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 6360 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 6364 */         stickers(), this.voiceStates, newValue, this.channels, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildCreateData withChannels(ChannelData... elements) {
/* 6377 */     List<ChannelData> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 6378 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 6380 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 6385 */         owner(), 
/* 6386 */         permissions(), 
/* 6387 */         afkChannelId(), 
/* 6388 */         embedEnabled(), 
/* 6389 */         embedChannelId(), this.features, 
/*      */         
/* 6391 */         applicationId(), 
/* 6392 */         widgetEnabled(), 
/* 6393 */         widgetChannelId(), 
/* 6394 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 6396 */         rulesChannelId(), 
/* 6397 */         maxPresences(), 
/* 6398 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 6402 */         premiumSubscriptionCount(), 
/* 6403 */         publicUpdatesChannelId(), 
/* 6404 */         maxVideoChannelUsers(), 
/* 6405 */         approximateMemberCount(), 
/* 6406 */         approximatePresenceCount(), 
/* 6407 */         welcomeScreen(), 
/* 6408 */         nsfw(), 
/* 6409 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 6412 */         ownerId(), 
/* 6413 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 6422 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 6426 */         stickers(), this.voiceStates, this.members, newValue, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildCreateData withChannels(Iterable<? extends ChannelData> elements) {
/* 6440 */     if (this.channels == elements) return this; 
/* 6441 */     List<ChannelData> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 6442 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 6444 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 6449 */         owner(), 
/* 6450 */         permissions(), 
/* 6451 */         afkChannelId(), 
/* 6452 */         embedEnabled(), 
/* 6453 */         embedChannelId(), this.features, 
/*      */         
/* 6455 */         applicationId(), 
/* 6456 */         widgetEnabled(), 
/* 6457 */         widgetChannelId(), 
/* 6458 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 6460 */         rulesChannelId(), 
/* 6461 */         maxPresences(), 
/* 6462 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 6466 */         premiumSubscriptionCount(), 
/* 6467 */         publicUpdatesChannelId(), 
/* 6468 */         maxVideoChannelUsers(), 
/* 6469 */         approximateMemberCount(), 
/* 6470 */         approximatePresenceCount(), 
/* 6471 */         welcomeScreen(), 
/* 6472 */         nsfw(), 
/* 6473 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 6476 */         ownerId(), 
/* 6477 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 6486 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 6490 */         stickers(), this.voiceStates, this.members, newValue, this.presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildCreateData withPresences(PresenceData... elements) {
/* 6503 */     List<PresenceData> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 6504 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 6506 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 6511 */         owner(), 
/* 6512 */         permissions(), 
/* 6513 */         afkChannelId(), 
/* 6514 */         embedEnabled(), 
/* 6515 */         embedChannelId(), this.features, 
/*      */         
/* 6517 */         applicationId(), 
/* 6518 */         widgetEnabled(), 
/* 6519 */         widgetChannelId(), 
/* 6520 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 6522 */         rulesChannelId(), 
/* 6523 */         maxPresences(), 
/* 6524 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 6528 */         premiumSubscriptionCount(), 
/* 6529 */         publicUpdatesChannelId(), 
/* 6530 */         maxVideoChannelUsers(), 
/* 6531 */         approximateMemberCount(), 
/* 6532 */         approximatePresenceCount(), 
/* 6533 */         welcomeScreen(), 
/* 6534 */         nsfw(), 
/* 6535 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 6538 */         ownerId(), 
/* 6539 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 6548 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 6552 */         stickers(), this.voiceStates, this.members, this.channels, newValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildCreateData withPresences(Iterable<? extends PresenceData> elements) {
/* 6566 */     if (this.presences == elements) return this; 
/* 6567 */     List<PresenceData> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 6568 */     return new ImmutableGuildCreateData(this, 
/*      */         
/* 6570 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 6575 */         owner(), 
/* 6576 */         permissions(), 
/* 6577 */         afkChannelId(), 
/* 6578 */         embedEnabled(), 
/* 6579 */         embedChannelId(), this.features, 
/*      */         
/* 6581 */         applicationId(), 
/* 6582 */         widgetEnabled(), 
/* 6583 */         widgetChannelId(), 
/* 6584 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 6586 */         rulesChannelId(), 
/* 6587 */         maxPresences(), 
/* 6588 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 6592 */         premiumSubscriptionCount(), 
/* 6593 */         publicUpdatesChannelId(), 
/* 6594 */         maxVideoChannelUsers(), 
/* 6595 */         approximateMemberCount(), 
/* 6596 */         approximatePresenceCount(), 
/* 6597 */         welcomeScreen(), 
/* 6598 */         nsfw(), 
/* 6599 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 6602 */         ownerId(), 
/* 6603 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 6612 */         unavailable(), this.memberCount, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */         
/* 6616 */         stickers(), this.voiceStates, this.members, this.channels, newValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object another) {
/* 6629 */     if (this == another) return true; 
/* 6630 */     return (another instanceof ImmutableGuildCreateData && 
/* 6631 */       equalTo(0, (ImmutableGuildCreateData)another));
/*      */   }
/*      */   
/*      */   private boolean equalTo(int synthetic, ImmutableGuildCreateData another) {
/* 6635 */     return (Objects.equals(Long.valueOf(this.id_value), Long.valueOf(another.id_value)) && this.name
/* 6636 */       .equals(another.name) && 
/* 6637 */       Objects.equals(this.icon, another.icon) && 
/* 6638 */       Objects.equals(this.splash, another.splash) && 
/* 6639 */       Objects.equals(this.discoverySplash, another.discoverySplash) && 
/* 6640 */       owner().equals(another.owner()) && 
/* 6641 */       permissions().equals(another.permissions()) && 
/* 6642 */       afkChannelId().equals(another.afkChannelId()) && 
/* 6643 */       embedEnabled().equals(another.embedEnabled()) && 
/* 6644 */       embedChannelId().equals(another.embedChannelId()) && this.features
/* 6645 */       .equals(another.features) && 
/* 6646 */       applicationId().equals(another.applicationId()) && 
/* 6647 */       widgetEnabled().equals(another.widgetEnabled()) && 
/* 6648 */       widgetChannelId().equals(another.widgetChannelId()) && 
/* 6649 */       systemChannelId().equals(another.systemChannelId()) && 
/* 6650 */       Objects.equals(this.systemChannelFlags, another.systemChannelFlags) && 
/* 6651 */       rulesChannelId().equals(another.rulesChannelId()) && 
/* 6652 */       maxPresences().equals(another.maxPresences()) && 
/* 6653 */       maxMembers().equals(another.maxMembers()) && 
/* 6654 */       Objects.equals(this.vanityUrlCode, another.vanityUrlCode) && 
/* 6655 */       Objects.equals(this.description, another.description) && 
/* 6656 */       Objects.equals(this.banner, another.banner) && 
/* 6657 */       premiumSubscriptionCount().equals(another.premiumSubscriptionCount()) && 
/* 6658 */       publicUpdatesChannelId().equals(another.publicUpdatesChannelId()) && 
/* 6659 */       maxVideoChannelUsers().equals(another.maxVideoChannelUsers()) && 
/* 6660 */       approximateMemberCount().equals(another.approximateMemberCount()) && 
/* 6661 */       approximatePresenceCount().equals(another.approximatePresenceCount()) && 
/* 6662 */       welcomeScreen().equals(another.welcomeScreen()) && 
/* 6663 */       nsfw().equals(another.nsfw()) && 
/* 6664 */       safetyAlertsChannelId().equals(another.safetyAlertsChannelId()) && this.verificationLevel == another.verificationLevel && this.nsfwLevel == another.nsfwLevel && 
/*      */ 
/*      */       
/* 6667 */       Objects.equals(Long.valueOf(this.ownerId_value), Long.valueOf(another.ownerId_value)) && 
/* 6668 */       region().equals(another.region()) && this.afkTimeout == another.afkTimeout && this.defaultMessageNotifications == another.defaultMessageNotifications && this.explicitContentFilter == another.explicitContentFilter && this.mfaLevel == another.mfaLevel && this.premiumTier == another.premiumTier && this.preferredLocale
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 6674 */       .equals(another.preferredLocale) && this.joinedAt
/* 6675 */       .equals(another.joinedAt) && this.large == another.large && 
/*      */       
/* 6677 */       unavailable().equals(another.unavailable()) && this.memberCount == another.memberCount && this.roles
/*      */       
/* 6679 */       .equals(another.roles) && this.emojis
/* 6680 */       .equals(another.emojis) && 
/* 6681 */       Objects.equals(this.stickers_value, another.stickers_value) && this.voiceStates
/* 6682 */       .equals(another.voiceStates) && this.members
/* 6683 */       .equals(another.members) && this.channels
/* 6684 */       .equals(another.channels) && this.presences
/* 6685 */       .equals(another.presences));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/* 6694 */     int h = 5381;
/* 6695 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.id_value));
/* 6696 */     h += (h << 5) + this.name.hashCode();
/* 6697 */     h += (h << 5) + Objects.hashCode(this.icon);
/* 6698 */     h += (h << 5) + Objects.hashCode(this.splash);
/* 6699 */     h += (h << 5) + Objects.hashCode(this.discoverySplash);
/* 6700 */     h += (h << 5) + owner().hashCode();
/* 6701 */     h += (h << 5) + permissions().hashCode();
/* 6702 */     h += (h << 5) + afkChannelId().hashCode();
/* 6703 */     h += (h << 5) + embedEnabled().hashCode();
/* 6704 */     h += (h << 5) + embedChannelId().hashCode();
/* 6705 */     h += (h << 5) + this.features.hashCode();
/* 6706 */     h += (h << 5) + applicationId().hashCode();
/* 6707 */     h += (h << 5) + widgetEnabled().hashCode();
/* 6708 */     h += (h << 5) + widgetChannelId().hashCode();
/* 6709 */     h += (h << 5) + systemChannelId().hashCode();
/* 6710 */     h += (h << 5) + Objects.hashCode(this.systemChannelFlags);
/* 6711 */     h += (h << 5) + rulesChannelId().hashCode();
/* 6712 */     h += (h << 5) + maxPresences().hashCode();
/* 6713 */     h += (h << 5) + maxMembers().hashCode();
/* 6714 */     h += (h << 5) + Objects.hashCode(this.vanityUrlCode);
/* 6715 */     h += (h << 5) + Objects.hashCode(this.description);
/* 6716 */     h += (h << 5) + Objects.hashCode(this.banner);
/* 6717 */     h += (h << 5) + premiumSubscriptionCount().hashCode();
/* 6718 */     h += (h << 5) + publicUpdatesChannelId().hashCode();
/* 6719 */     h += (h << 5) + maxVideoChannelUsers().hashCode();
/* 6720 */     h += (h << 5) + approximateMemberCount().hashCode();
/* 6721 */     h += (h << 5) + approximatePresenceCount().hashCode();
/* 6722 */     h += (h << 5) + welcomeScreen().hashCode();
/* 6723 */     h += (h << 5) + nsfw().hashCode();
/* 6724 */     h += (h << 5) + safetyAlertsChannelId().hashCode();
/* 6725 */     h += (h << 5) + this.verificationLevel;
/* 6726 */     h += (h << 5) + this.nsfwLevel;
/* 6727 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.ownerId_value));
/* 6728 */     h += (h << 5) + region().hashCode();
/* 6729 */     h += (h << 5) + this.afkTimeout;
/* 6730 */     h += (h << 5) + this.defaultMessageNotifications;
/* 6731 */     h += (h << 5) + this.explicitContentFilter;
/* 6732 */     h += (h << 5) + this.mfaLevel;
/* 6733 */     h += (h << 5) + this.premiumTier;
/* 6734 */     h += (h << 5) + this.preferredLocale.hashCode();
/* 6735 */     h += (h << 5) + this.joinedAt.hashCode();
/* 6736 */     h += (h << 5) + Boolean.hashCode(this.large);
/* 6737 */     h += (h << 5) + unavailable().hashCode();
/* 6738 */     h += (h << 5) + this.memberCount;
/* 6739 */     h += (h << 5) + this.roles.hashCode();
/* 6740 */     h += (h << 5) + this.emojis.hashCode();
/* 6741 */     h += (h << 5) + Objects.hashCode(this.stickers_value);
/* 6742 */     h += (h << 5) + this.voiceStates.hashCode();
/* 6743 */     h += (h << 5) + this.members.hashCode();
/* 6744 */     h += (h << 5) + this.channels.hashCode();
/* 6745 */     h += (h << 5) + this.presences.hashCode();
/* 6746 */     return h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/* 6755 */     StringBuilder builder = new StringBuilder("GuildCreateData{");
/* 6756 */     builder.append("id=").append(Objects.toString(Long.valueOf(this.id_value)));
/* 6757 */     builder.append(", ");
/* 6758 */     builder.append("name=").append(this.name);
/* 6759 */     if (this.icon != null) {
/* 6760 */       builder.append(", ");
/* 6761 */       builder.append("icon=").append(this.icon);
/*      */     } 
/* 6763 */     if (this.splash != null) {
/* 6764 */       builder.append(", ");
/* 6765 */       builder.append("splash=").append(this.splash);
/*      */     } 
/* 6767 */     if (this.discoverySplash != null) {
/* 6768 */       builder.append(", ");
/* 6769 */       builder.append("discoverySplash=").append(this.discoverySplash);
/*      */     } 
/* 6771 */     builder.append(", ");
/* 6772 */     builder.append("owner=").append(owner().toString());
/* 6773 */     builder.append(", ");
/* 6774 */     builder.append("permissions=").append(permissions().toString());
/* 6775 */     builder.append(", ");
/* 6776 */     builder.append("afkChannelId=").append(afkChannelId().toString());
/* 6777 */     builder.append(", ");
/* 6778 */     builder.append("embedEnabled=").append(embedEnabled().toString());
/* 6779 */     builder.append(", ");
/* 6780 */     builder.append("embedChannelId=").append(embedChannelId().toString());
/* 6781 */     builder.append(", ");
/* 6782 */     builder.append("features=").append(this.features);
/* 6783 */     builder.append(", ");
/* 6784 */     builder.append("applicationId=").append(applicationId().toString());
/* 6785 */     builder.append(", ");
/* 6786 */     builder.append("widgetEnabled=").append(widgetEnabled().toString());
/* 6787 */     builder.append(", ");
/* 6788 */     builder.append("widgetChannelId=").append(widgetChannelId().toString());
/* 6789 */     builder.append(", ");
/* 6790 */     builder.append("systemChannelId=").append(systemChannelId().toString());
/* 6791 */     if (this.systemChannelFlags != null) {
/* 6792 */       builder.append(", ");
/* 6793 */       builder.append("systemChannelFlags=").append(this.systemChannelFlags);
/*      */     } 
/* 6795 */     builder.append(", ");
/* 6796 */     builder.append("rulesChannelId=").append(rulesChannelId().toString());
/* 6797 */     builder.append(", ");
/* 6798 */     builder.append("maxPresences=").append(maxPresences().toString());
/* 6799 */     builder.append(", ");
/* 6800 */     builder.append("maxMembers=").append(maxMembers().toString());
/* 6801 */     if (this.vanityUrlCode != null) {
/* 6802 */       builder.append(", ");
/* 6803 */       builder.append("vanityUrlCode=").append(this.vanityUrlCode);
/*      */     } 
/* 6805 */     if (this.description != null) {
/* 6806 */       builder.append(", ");
/* 6807 */       builder.append("description=").append(this.description);
/*      */     } 
/* 6809 */     if (this.banner != null) {
/* 6810 */       builder.append(", ");
/* 6811 */       builder.append("banner=").append(this.banner);
/*      */     } 
/* 6813 */     builder.append(", ");
/* 6814 */     builder.append("premiumSubscriptionCount=").append(premiumSubscriptionCount().toString());
/* 6815 */     builder.append(", ");
/* 6816 */     builder.append("publicUpdatesChannelId=").append(publicUpdatesChannelId().toString());
/* 6817 */     builder.append(", ");
/* 6818 */     builder.append("maxVideoChannelUsers=").append(maxVideoChannelUsers().toString());
/* 6819 */     builder.append(", ");
/* 6820 */     builder.append("approximateMemberCount=").append(approximateMemberCount().toString());
/* 6821 */     builder.append(", ");
/* 6822 */     builder.append("approximatePresenceCount=").append(approximatePresenceCount().toString());
/* 6823 */     builder.append(", ");
/* 6824 */     builder.append("welcomeScreen=").append(welcomeScreen().toString());
/* 6825 */     builder.append(", ");
/* 6826 */     builder.append("nsfw=").append(nsfw().toString());
/* 6827 */     builder.append(", ");
/* 6828 */     builder.append("safetyAlertsChannelId=").append(safetyAlertsChannelId().toString());
/* 6829 */     builder.append(", ");
/* 6830 */     builder.append("verificationLevel=").append(this.verificationLevel);
/* 6831 */     builder.append(", ");
/* 6832 */     builder.append("nsfwLevel=").append(this.nsfwLevel);
/* 6833 */     builder.append(", ");
/* 6834 */     builder.append("ownerId=").append(Objects.toString(Long.valueOf(this.ownerId_value)));
/* 6835 */     builder.append(", ");
/* 6836 */     builder.append("region=").append(region().toString());
/* 6837 */     builder.append(", ");
/* 6838 */     builder.append("afkTimeout=").append(this.afkTimeout);
/* 6839 */     builder.append(", ");
/* 6840 */     builder.append("defaultMessageNotifications=").append(this.defaultMessageNotifications);
/* 6841 */     builder.append(", ");
/* 6842 */     builder.append("explicitContentFilter=").append(this.explicitContentFilter);
/* 6843 */     builder.append(", ");
/* 6844 */     builder.append("mfaLevel=").append(this.mfaLevel);
/* 6845 */     builder.append(", ");
/* 6846 */     builder.append("premiumTier=").append(this.premiumTier);
/* 6847 */     builder.append(", ");
/* 6848 */     builder.append("preferredLocale=").append(this.preferredLocale);
/* 6849 */     builder.append(", ");
/* 6850 */     builder.append("joinedAt=").append(this.joinedAt);
/* 6851 */     builder.append(", ");
/* 6852 */     builder.append("large=").append(this.large);
/* 6853 */     builder.append(", ");
/* 6854 */     builder.append("unavailable=").append(unavailable().toString());
/* 6855 */     builder.append(", ");
/* 6856 */     builder.append("memberCount=").append(this.memberCount);
/* 6857 */     builder.append(", ");
/* 6858 */     builder.append("roles=").append(this.roles);
/* 6859 */     builder.append(", ");
/* 6860 */     builder.append("emojis=").append(this.emojis);
/* 6861 */     builder.append(", ");
/* 6862 */     builder.append("stickers=").append(Objects.toString(this.stickers_value));
/* 6863 */     builder.append(", ");
/* 6864 */     builder.append("voiceStates=").append(this.voiceStates);
/* 6865 */     builder.append(", ");
/* 6866 */     builder.append("members=").append(this.members);
/* 6867 */     builder.append(", ");
/* 6868 */     builder.append("channels=").append(this.channels);
/* 6869 */     builder.append(", ");
/* 6870 */     builder.append("presences=").append(this.presences);
/* 6871 */     return builder.append("}").toString();
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonDeserialize
/*      */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*      */   @Generated(from = "GuildCreateData", generator = "Immutables")
/*      */   static final class Json
/*      */     implements GuildCreateData
/*      */   {
/*      */     Id id;
/*      */     
/*      */     String name;
/* 6885 */     Optional<String> icon = Optional.empty();
/* 6886 */     Optional<String> splash = Optional.empty();
/* 6887 */     Optional<String> discoverySplash = Optional.empty();
/*      */     
/* 6889 */     Possible<Boolean> owner = Possible.absent();
/*      */ 
/*      */     
/* 6892 */     Possible<Long> permissions = Possible.absent();
/*      */ 
/*      */     
/* 6895 */     Optional<Id> afkChannelId = Optional.empty();
/*      */ 
/*      */     
/* 6898 */     Possible<Boolean> embedEnabled = Possible.absent();
/*      */ 
/*      */     
/* 6901 */     Possible<Optional<Id>> embedChannelId = Possible.absent();
/*      */     
/* 6903 */     List<String> features = Collections.emptyList();
/*      */     
/* 6905 */     Optional<Id> applicationId = Optional.empty();
/*      */ 
/*      */     
/* 6908 */     Possible<Boolean> widgetEnabled = Possible.absent();
/*      */ 
/*      */     
/* 6911 */     Possible<Optional<Id>> widgetChannelId = Possible.absent();
/*      */ 
/*      */     
/* 6914 */     Optional<Id> systemChannelId = Optional.empty();
/*      */     
/* 6916 */     OptionalInt systemChannelFlags = OptionalInt.empty();
/*      */     
/* 6918 */     Optional<Id> rulesChannelId = Optional.empty();
/*      */ 
/*      */     
/* 6921 */     Possible<Optional<Integer>> maxPresences = Possible.absent();
/*      */ 
/*      */     
/* 6924 */     Possible<Integer> maxMembers = Possible.absent();
/*      */     
/* 6926 */     Optional<String> vanityUrlCode = Optional.empty();
/* 6927 */     Optional<String> description = Optional.empty();
/* 6928 */     Optional<String> banner = Optional.empty();
/*      */     
/* 6930 */     Possible<Integer> premiumSubscriptionCount = Possible.absent();
/*      */ 
/*      */     
/* 6933 */     Optional<Id> publicUpdatesChannelId = Optional.empty();
/*      */ 
/*      */     
/* 6936 */     Possible<Integer> maxVideoChannelUsers = Possible.absent();
/*      */ 
/*      */     
/* 6939 */     Possible<Integer> approximateMemberCount = Possible.absent();
/*      */ 
/*      */     
/* 6942 */     Possible<Integer> approximatePresenceCount = Possible.absent();
/*      */ 
/*      */     
/* 6945 */     Possible<WelcomeScreenData> welcomeScreen = Possible.absent();
/*      */ 
/*      */     
/* 6948 */     Possible<Boolean> nsfw = Possible.absent();
/*      */ 
/*      */     
/* 6951 */     Optional<Id> safetyAlertsChannelId = Optional.empty();
/*      */     
/*      */     int verificationLevel;
/*      */     
/*      */     boolean verificationLevelIsSet;
/*      */     int nsfwLevel;
/*      */     boolean nsfwLevelIsSet;
/*      */     Id ownerId;
/* 6959 */     Possible<Optional<String>> region = Possible.absent();
/*      */     
/*      */     int afkTimeout;
/*      */     
/*      */     boolean afkTimeoutIsSet;
/*      */     int defaultMessageNotifications;
/*      */     boolean defaultMessageNotificationsIsSet;
/*      */     int explicitContentFilter;
/*      */     boolean explicitContentFilterIsSet;
/*      */     int mfaLevel;
/*      */     boolean mfaLevelIsSet;
/*      */     int premiumTier;
/*      */     boolean premiumTierIsSet;
/*      */     String preferredLocale;
/*      */     String joinedAt;
/*      */     boolean large;
/*      */     boolean largeIsSet;
/* 6976 */     Possible<Boolean> unavailable = Possible.absent();
/*      */     
/*      */     int memberCount;
/*      */     boolean memberCountIsSet;
/* 6980 */     List<RoleData> roles = Collections.emptyList();
/* 6981 */     List<EmojiData> emojis = Collections.emptyList();
/*      */     
/* 6983 */     Possible<List<StickerData>> stickers = Possible.absent();
/*      */     
/* 6985 */     List<VoiceStateData> voiceStates = Collections.emptyList();
/* 6986 */     List<MemberData> members = Collections.emptyList();
/* 6987 */     List<ChannelData> channels = Collections.emptyList();
/* 6988 */     List<PresenceData> presences = Collections.emptyList();
/*      */     @JsonProperty("id")
/*      */     public void setId(Id id) {
/* 6991 */       this.id = id;
/*      */     }
/*      */     @JsonProperty("name")
/*      */     public void setName(String name) {
/* 6995 */       this.name = name;
/*      */     }
/*      */     @JsonProperty("icon")
/*      */     public void setIcon(Optional<String> icon) {
/* 6999 */       this.icon = icon;
/*      */     }
/*      */     @JsonProperty("splash")
/*      */     public void setSplash(Optional<String> splash) {
/* 7003 */       this.splash = splash;
/*      */     }
/*      */     @JsonProperty("discovery_splash")
/*      */     public void setDiscoverySplash(Optional<String> discoverySplash) {
/* 7007 */       this.discoverySplash = discoverySplash;
/*      */     }
/*      */     @JsonProperty("owner")
/*      */     public void setOwner(Possible<Boolean> owner) {
/* 7011 */       this.owner = owner;
/*      */     }
/*      */     @JsonProperty("permissions")
/*      */     public void setPermissions(Possible<Long> permissions) {
/* 7015 */       this.permissions = permissions;
/*      */     }
/*      */     @JsonProperty("afk_channel_id")
/*      */     public void setAfkChannelId(Optional<Id> afkChannelId) {
/* 7019 */       this.afkChannelId = afkChannelId;
/*      */     }
/*      */     @JsonProperty("embed_enabled")
/*      */     public void setEmbedEnabled(Possible<Boolean> embedEnabled) {
/* 7023 */       this.embedEnabled = embedEnabled;
/*      */     }
/*      */     @JsonProperty("embed_channel_id")
/*      */     public void setEmbedChannelId(Possible<Optional<Id>> embedChannelId) {
/* 7027 */       this.embedChannelId = embedChannelId;
/*      */     }
/*      */     @JsonProperty("features")
/*      */     public void setFeatures(List<String> features) {
/* 7031 */       this.features = features;
/*      */     }
/*      */     @JsonProperty("application_id")
/*      */     public void setApplicationId(Optional<Id> applicationId) {
/* 7035 */       this.applicationId = applicationId;
/*      */     }
/*      */     @JsonProperty("widget_enabled")
/*      */     public void setWidgetEnabled(Possible<Boolean> widgetEnabled) {
/* 7039 */       this.widgetEnabled = widgetEnabled;
/*      */     }
/*      */     @JsonProperty("widget_channel_id")
/*      */     public void setWidgetChannelId(Possible<Optional<Id>> widgetChannelId) {
/* 7043 */       this.widgetChannelId = widgetChannelId;
/*      */     }
/*      */     @JsonProperty("system_channel_id")
/*      */     public void setSystemChannelId(Optional<Id> systemChannelId) {
/* 7047 */       this.systemChannelId = systemChannelId;
/*      */     }
/*      */     @JsonProperty("system_channel_flags")
/*      */     public void setSystemChannelFlags(OptionalInt systemChannelFlags) {
/* 7051 */       this.systemChannelFlags = systemChannelFlags;
/*      */     }
/*      */     @JsonProperty("rules_channel_id")
/*      */     public void setRulesChannelId(Optional<Id> rulesChannelId) {
/* 7055 */       this.rulesChannelId = rulesChannelId;
/*      */     }
/*      */     @JsonProperty("max_presences")
/*      */     public void setMaxPresences(Possible<Optional<Integer>> maxPresences) {
/* 7059 */       this.maxPresences = maxPresences;
/*      */     }
/*      */     @JsonProperty("max_members")
/*      */     public void setMaxMembers(Possible<Integer> maxMembers) {
/* 7063 */       this.maxMembers = maxMembers;
/*      */     }
/*      */     @JsonProperty("vanity_url_code")
/*      */     public void setVanityUrlCode(Optional<String> vanityUrlCode) {
/* 7067 */       this.vanityUrlCode = vanityUrlCode;
/*      */     }
/*      */     @JsonProperty("description")
/*      */     public void setDescription(Optional<String> description) {
/* 7071 */       this.description = description;
/*      */     }
/*      */     @JsonProperty("banner")
/*      */     public void setBanner(Optional<String> banner) {
/* 7075 */       this.banner = banner;
/*      */     }
/*      */     @JsonProperty("premium_subscription_count")
/*      */     public void setPremiumSubscriptionCount(Possible<Integer> premiumSubscriptionCount) {
/* 7079 */       this.premiumSubscriptionCount = premiumSubscriptionCount;
/*      */     }
/*      */     @JsonProperty("public_updates_channel_id")
/*      */     public void setPublicUpdatesChannelId(Optional<Id> publicUpdatesChannelId) {
/* 7083 */       this.publicUpdatesChannelId = publicUpdatesChannelId;
/*      */     }
/*      */     @JsonProperty("max_video_channel_users")
/*      */     public void setMaxVideoChannelUsers(Possible<Integer> maxVideoChannelUsers) {
/* 7087 */       this.maxVideoChannelUsers = maxVideoChannelUsers;
/*      */     }
/*      */     @JsonProperty("approximate_member_count")
/*      */     public void setApproximateMemberCount(Possible<Integer> approximateMemberCount) {
/* 7091 */       this.approximateMemberCount = approximateMemberCount;
/*      */     }
/*      */     @JsonProperty("approximate_presence_count")
/*      */     public void setApproximatePresenceCount(Possible<Integer> approximatePresenceCount) {
/* 7095 */       this.approximatePresenceCount = approximatePresenceCount;
/*      */     }
/*      */     @JsonProperty("welcome_screen")
/*      */     public void setWelcomeScreen(Possible<WelcomeScreenData> welcomeScreen) {
/* 7099 */       this.welcomeScreen = welcomeScreen;
/*      */     }
/*      */     @JsonProperty("nsfw")
/*      */     public void setNsfw(Possible<Boolean> nsfw) {
/* 7103 */       this.nsfw = nsfw;
/*      */     }
/*      */     @JsonProperty("safety_alerts_channel_id")
/*      */     public void setSafetyAlertsChannelId(Optional<Id> safetyAlertsChannelId) {
/* 7107 */       this.safetyAlertsChannelId = safetyAlertsChannelId;
/*      */     }
/*      */     @JsonProperty("verification_level")
/*      */     public void setVerificationLevel(int verificationLevel) {
/* 7111 */       this.verificationLevel = verificationLevel;
/* 7112 */       this.verificationLevelIsSet = true;
/*      */     }
/*      */     @JsonProperty("nsfw_level")
/*      */     public void setNsfwLevel(int nsfwLevel) {
/* 7116 */       this.nsfwLevel = nsfwLevel;
/* 7117 */       this.nsfwLevelIsSet = true;
/*      */     }
/*      */     @JsonProperty("owner_id")
/*      */     public void setOwnerId(Id ownerId) {
/* 7121 */       this.ownerId = ownerId;
/*      */     }
/*      */     @JsonProperty("region")
/*      */     public void setRegion(Possible<Optional<String>> region) {
/* 7125 */       this.region = region;
/*      */     }
/*      */     @JsonProperty("afk_timeout")
/*      */     public void setAfkTimeout(int afkTimeout) {
/* 7129 */       this.afkTimeout = afkTimeout;
/* 7130 */       this.afkTimeoutIsSet = true;
/*      */     }
/*      */     @JsonProperty("default_message_notifications")
/*      */     public void setDefaultMessageNotifications(int defaultMessageNotifications) {
/* 7134 */       this.defaultMessageNotifications = defaultMessageNotifications;
/* 7135 */       this.defaultMessageNotificationsIsSet = true;
/*      */     }
/*      */     @JsonProperty("explicit_content_filter")
/*      */     public void setExplicitContentFilter(int explicitContentFilter) {
/* 7139 */       this.explicitContentFilter = explicitContentFilter;
/* 7140 */       this.explicitContentFilterIsSet = true;
/*      */     }
/*      */     @JsonProperty("mfa_level")
/*      */     public void setMfaLevel(int mfaLevel) {
/* 7144 */       this.mfaLevel = mfaLevel;
/* 7145 */       this.mfaLevelIsSet = true;
/*      */     }
/*      */     @JsonProperty("premium_tier")
/*      */     public void setPremiumTier(int premiumTier) {
/* 7149 */       this.premiumTier = premiumTier;
/* 7150 */       this.premiumTierIsSet = true;
/*      */     }
/*      */     @JsonProperty("preferred_locale")
/*      */     public void setPreferredLocale(String preferredLocale) {
/* 7154 */       this.preferredLocale = preferredLocale;
/*      */     }
/*      */     @JsonProperty("joined_at")
/*      */     public void setJoinedAt(String joinedAt) {
/* 7158 */       this.joinedAt = joinedAt;
/*      */     }
/*      */     @JsonProperty("large")
/*      */     public void setLarge(boolean large) {
/* 7162 */       this.large = large;
/* 7163 */       this.largeIsSet = true;
/*      */     }
/*      */     @JsonProperty("unavailable")
/*      */     public void setUnavailable(Possible<Boolean> unavailable) {
/* 7167 */       this.unavailable = unavailable;
/*      */     }
/*      */     @JsonProperty("member_count")
/*      */     public void setMemberCount(int memberCount) {
/* 7171 */       this.memberCount = memberCount;
/* 7172 */       this.memberCountIsSet = true;
/*      */     }
/*      */     @JsonProperty("roles")
/*      */     public void setRoles(List<RoleData> roles) {
/* 7176 */       this.roles = roles;
/*      */     }
/*      */     @JsonProperty("emojis")
/*      */     public void setEmojis(List<EmojiData> emojis) {
/* 7180 */       this.emojis = emojis;
/*      */     }
/*      */     @JsonProperty("stickers")
/*      */     public void setStickers(Possible<List<StickerData>> stickers) {
/* 7184 */       this.stickers = stickers;
/*      */     }
/*      */     @JsonProperty("voice_states")
/*      */     public void setVoiceStates(List<VoiceStateData> voiceStates) {
/* 7188 */       this.voiceStates = voiceStates;
/*      */     }
/*      */     @JsonProperty("members")
/*      */     public void setMembers(List<MemberData> members) {
/* 7192 */       this.members = members;
/*      */     }
/*      */     @JsonProperty("channels")
/*      */     public void setChannels(List<ChannelData> channels) {
/* 7196 */       this.channels = channels;
/*      */     }
/*      */     @JsonProperty("presences")
/*      */     public void setPresences(List<PresenceData> presences) {
/* 7200 */       this.presences = presences;
/*      */     }
/*      */     public Id id() {
/* 7203 */       throw new UnsupportedOperationException();
/*      */     } public String name() {
/* 7205 */       throw new UnsupportedOperationException();
/*      */     } public Optional<String> icon() {
/* 7207 */       throw new UnsupportedOperationException();
/*      */     } public Optional<String> splash() {
/* 7209 */       throw new UnsupportedOperationException();
/*      */     } public Optional<String> discoverySplash() {
/* 7211 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Boolean> owner() {
/* 7213 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Long> permissions() {
/* 7215 */       throw new UnsupportedOperationException();
/*      */     } public Optional<Id> afkChannelId() {
/* 7217 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Boolean> embedEnabled() {
/* 7219 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<Id>> embedChannelId() {
/* 7221 */       throw new UnsupportedOperationException();
/*      */     } public List<String> features() {
/* 7223 */       throw new UnsupportedOperationException();
/*      */     } public Optional<Id> applicationId() {
/* 7225 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Boolean> widgetEnabled() {
/* 7227 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<Id>> widgetChannelId() {
/* 7229 */       throw new UnsupportedOperationException();
/*      */     } public Optional<Id> systemChannelId() {
/* 7231 */       throw new UnsupportedOperationException();
/*      */     } public OptionalInt systemChannelFlags() {
/* 7233 */       throw new UnsupportedOperationException();
/*      */     } public Optional<Id> rulesChannelId() {
/* 7235 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<Integer>> maxPresences() {
/* 7237 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> maxMembers() {
/* 7239 */       throw new UnsupportedOperationException();
/*      */     } public Optional<String> vanityUrlCode() {
/* 7241 */       throw new UnsupportedOperationException();
/*      */     } public Optional<String> description() {
/* 7243 */       throw new UnsupportedOperationException();
/*      */     } public Optional<String> banner() {
/* 7245 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> premiumSubscriptionCount() {
/* 7247 */       throw new UnsupportedOperationException();
/*      */     } public Optional<Id> publicUpdatesChannelId() {
/* 7249 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> maxVideoChannelUsers() {
/* 7251 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> approximateMemberCount() {
/* 7253 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> approximatePresenceCount() {
/* 7255 */       throw new UnsupportedOperationException();
/*      */     } public Possible<WelcomeScreenData> welcomeScreen() {
/* 7257 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Boolean> nsfw() {
/* 7259 */       throw new UnsupportedOperationException();
/*      */     } public Optional<Id> safetyAlertsChannelId() {
/* 7261 */       throw new UnsupportedOperationException();
/*      */     } public int verificationLevel() {
/* 7263 */       throw new UnsupportedOperationException();
/*      */     } public int nsfwLevel() {
/* 7265 */       throw new UnsupportedOperationException();
/*      */     } public Id ownerId() {
/* 7267 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<String>> region() {
/* 7269 */       throw new UnsupportedOperationException();
/*      */     } public int afkTimeout() {
/* 7271 */       throw new UnsupportedOperationException();
/*      */     } public int defaultMessageNotifications() {
/* 7273 */       throw new UnsupportedOperationException();
/*      */     } public int explicitContentFilter() {
/* 7275 */       throw new UnsupportedOperationException();
/*      */     } public int mfaLevel() {
/* 7277 */       throw new UnsupportedOperationException();
/*      */     } public int premiumTier() {
/* 7279 */       throw new UnsupportedOperationException();
/*      */     } public String preferredLocale() {
/* 7281 */       throw new UnsupportedOperationException();
/*      */     } public String joinedAt() {
/* 7283 */       throw new UnsupportedOperationException();
/*      */     } public boolean large() {
/* 7285 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Boolean> unavailable() {
/* 7287 */       throw new UnsupportedOperationException();
/*      */     } public int memberCount() {
/* 7289 */       throw new UnsupportedOperationException();
/*      */     } public List<RoleData> roles() {
/* 7291 */       throw new UnsupportedOperationException();
/*      */     } public List<EmojiData> emojis() {
/* 7293 */       throw new UnsupportedOperationException();
/*      */     } public Possible<List<StickerData>> stickers() {
/* 7295 */       throw new UnsupportedOperationException();
/*      */     } public List<VoiceStateData> voiceStates() {
/* 7297 */       throw new UnsupportedOperationException();
/*      */     } public List<MemberData> members() {
/* 7299 */       throw new UnsupportedOperationException();
/*      */     } public List<ChannelData> channels() {
/* 7301 */       throw new UnsupportedOperationException();
/*      */     } public List<PresenceData> presences() {
/* 7303 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*      */   static ImmutableGuildCreateData fromJson(Json json) {
/* 7314 */     Builder builder = builder();
/* 7315 */     if (json.id != null) {
/* 7316 */       builder.id(json.id);
/*      */     }
/* 7318 */     if (json.name != null) {
/* 7319 */       builder.name(json.name);
/*      */     }
/* 7321 */     if (json.icon != null) {
/* 7322 */       builder.icon(json.icon);
/*      */     }
/* 7324 */     if (json.splash != null) {
/* 7325 */       builder.splash(json.splash);
/*      */     }
/* 7327 */     if (json.discoverySplash != null) {
/* 7328 */       builder.discoverySplash(json.discoverySplash);
/*      */     }
/* 7330 */     if (json.owner != null) {
/* 7331 */       builder.owner(json.owner);
/*      */     }
/* 7333 */     if (json.permissions != null) {
/* 7334 */       builder.permissions(json.permissions);
/*      */     }
/* 7336 */     if (json.afkChannelId != null) {
/* 7337 */       builder.afkChannelId(json.afkChannelId);
/*      */     }
/* 7339 */     if (json.embedEnabled != null) {
/* 7340 */       builder.embedEnabled(json.embedEnabled);
/*      */     }
/* 7342 */     if (json.embedChannelId != null) {
/* 7343 */       builder.embedChannelId(json.embedChannelId);
/*      */     }
/* 7345 */     if (json.features != null) {
/* 7346 */       builder.addAllFeatures(json.features);
/*      */     }
/* 7348 */     if (json.applicationId != null) {
/* 7349 */       builder.applicationId(json.applicationId);
/*      */     }
/* 7351 */     if (json.widgetEnabled != null) {
/* 7352 */       builder.widgetEnabled(json.widgetEnabled);
/*      */     }
/* 7354 */     if (json.widgetChannelId != null) {
/* 7355 */       builder.widgetChannelId(json.widgetChannelId);
/*      */     }
/* 7357 */     if (json.systemChannelId != null) {
/* 7358 */       builder.systemChannelId(json.systemChannelId);
/*      */     }
/* 7360 */     if (json.systemChannelFlags != null) {
/* 7361 */       builder.systemChannelFlags(json.systemChannelFlags);
/*      */     }
/* 7363 */     if (json.rulesChannelId != null) {
/* 7364 */       builder.rulesChannelId(json.rulesChannelId);
/*      */     }
/* 7366 */     if (json.maxPresences != null) {
/* 7367 */       builder.maxPresences(json.maxPresences);
/*      */     }
/* 7369 */     if (json.maxMembers != null) {
/* 7370 */       builder.maxMembers(json.maxMembers);
/*      */     }
/* 7372 */     if (json.vanityUrlCode != null) {
/* 7373 */       builder.vanityUrlCode(json.vanityUrlCode);
/*      */     }
/* 7375 */     if (json.description != null) {
/* 7376 */       builder.description(json.description);
/*      */     }
/* 7378 */     if (json.banner != null) {
/* 7379 */       builder.banner(json.banner);
/*      */     }
/* 7381 */     if (json.premiumSubscriptionCount != null) {
/* 7382 */       builder.premiumSubscriptionCount(json.premiumSubscriptionCount);
/*      */     }
/* 7384 */     if (json.publicUpdatesChannelId != null) {
/* 7385 */       builder.publicUpdatesChannelId(json.publicUpdatesChannelId);
/*      */     }
/* 7387 */     if (json.maxVideoChannelUsers != null) {
/* 7388 */       builder.maxVideoChannelUsers(json.maxVideoChannelUsers);
/*      */     }
/* 7390 */     if (json.approximateMemberCount != null) {
/* 7391 */       builder.approximateMemberCount(json.approximateMemberCount);
/*      */     }
/* 7393 */     if (json.approximatePresenceCount != null) {
/* 7394 */       builder.approximatePresenceCount(json.approximatePresenceCount);
/*      */     }
/* 7396 */     if (json.welcomeScreen != null) {
/* 7397 */       builder.welcomeScreen(json.welcomeScreen);
/*      */     }
/* 7399 */     if (json.nsfw != null) {
/* 7400 */       builder.nsfw(json.nsfw);
/*      */     }
/* 7402 */     if (json.safetyAlertsChannelId != null) {
/* 7403 */       builder.safetyAlertsChannelId(json.safetyAlertsChannelId);
/*      */     }
/* 7405 */     if (json.verificationLevelIsSet) {
/* 7406 */       builder.verificationLevel(json.verificationLevel);
/*      */     }
/* 7408 */     if (json.nsfwLevelIsSet) {
/* 7409 */       builder.nsfwLevel(json.nsfwLevel);
/*      */     }
/* 7411 */     if (json.ownerId != null) {
/* 7412 */       builder.ownerId(json.ownerId);
/*      */     }
/* 7414 */     if (json.region != null) {
/* 7415 */       builder.region(json.region);
/*      */     }
/* 7417 */     if (json.afkTimeoutIsSet) {
/* 7418 */       builder.afkTimeout(json.afkTimeout);
/*      */     }
/* 7420 */     if (json.defaultMessageNotificationsIsSet) {
/* 7421 */       builder.defaultMessageNotifications(json.defaultMessageNotifications);
/*      */     }
/* 7423 */     if (json.explicitContentFilterIsSet) {
/* 7424 */       builder.explicitContentFilter(json.explicitContentFilter);
/*      */     }
/* 7426 */     if (json.mfaLevelIsSet) {
/* 7427 */       builder.mfaLevel(json.mfaLevel);
/*      */     }
/* 7429 */     if (json.premiumTierIsSet) {
/* 7430 */       builder.premiumTier(json.premiumTier);
/*      */     }
/* 7432 */     if (json.preferredLocale != null) {
/* 7433 */       builder.preferredLocale(json.preferredLocale);
/*      */     }
/* 7435 */     if (json.joinedAt != null) {
/* 7436 */       builder.joinedAt(json.joinedAt);
/*      */     }
/* 7438 */     if (json.largeIsSet) {
/* 7439 */       builder.large(json.large);
/*      */     }
/* 7441 */     if (json.unavailable != null) {
/* 7442 */       builder.unavailable(json.unavailable);
/*      */     }
/* 7444 */     if (json.memberCountIsSet) {
/* 7445 */       builder.memberCount(json.memberCount);
/*      */     }
/* 7447 */     if (json.roles != null) {
/* 7448 */       builder.addAllRoles(json.roles);
/*      */     }
/* 7450 */     if (json.emojis != null) {
/* 7451 */       builder.addAllEmojis(json.emojis);
/*      */     }
/* 7453 */     if (json.stickers != null) {
/* 7454 */       builder.stickers(json.stickers);
/*      */     }
/* 7456 */     if (json.voiceStates != null) {
/* 7457 */       builder.addAllVoiceStates(json.voiceStates);
/*      */     }
/* 7459 */     if (json.members != null) {
/* 7460 */       builder.addAllMembers(json.members);
/*      */     }
/* 7462 */     if (json.channels != null) {
/* 7463 */       builder.addAllChannels(json.channels);
/*      */     }
/* 7465 */     if (json.presences != null) {
/* 7466 */       builder.addAllPresences(json.presences);
/*      */     }
/* 7468 */     return builder.build();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableGuildCreateData of(Id id, String name, Optional<String> icon, Optional<String> splash, Optional<String> discoverySplash, Possible<Boolean> owner, Possible<Long> permissions, Optional<Id> afkChannelId, Possible<Boolean> embedEnabled, Possible<Optional<Id>> embedChannelId, List<String> features, Optional<Id> applicationId, Possible<Boolean> widgetEnabled, Possible<Optional<Id>> widgetChannelId, Optional<Id> systemChannelId, OptionalInt systemChannelFlags, Optional<Id> rulesChannelId, Possible<Optional<Integer>> maxPresences, Possible<Integer> maxMembers, Optional<String> vanityUrlCode, Optional<String> description, Optional<String> banner, Possible<Integer> premiumSubscriptionCount, Optional<Id> publicUpdatesChannelId, Possible<Integer> maxVideoChannelUsers, Possible<Integer> approximateMemberCount, Possible<Integer> approximatePresenceCount, Possible<WelcomeScreenData> welcomeScreen, Possible<Boolean> nsfw, Optional<Id> safetyAlertsChannelId, int verificationLevel, int nsfwLevel, Id ownerId, Possible<Optional<String>> region, int afkTimeout, int defaultMessageNotifications, int explicitContentFilter, int mfaLevel, int premiumTier, String preferredLocale, String joinedAt, boolean large, Possible<Boolean> unavailable, int memberCount, List<RoleData> roles, List<EmojiData> emojis, Possible<List<StickerData>> stickers, List<VoiceStateData> voiceStates, List<MemberData> members, List<ChannelData> channels, List<PresenceData> presences) {
/* 7527 */     return of(id, name, icon, splash, discoverySplash, owner, permissions, afkChannelId, embedEnabled, embedChannelId, features, applicationId, widgetEnabled, widgetChannelId, systemChannelId, systemChannelFlags, rulesChannelId, maxPresences, maxMembers, vanityUrlCode, description, banner, premiumSubscriptionCount, publicUpdatesChannelId, maxVideoChannelUsers, approximateMemberCount, approximatePresenceCount, welcomeScreen, nsfw, safetyAlertsChannelId, verificationLevel, nsfwLevel, ownerId, region, afkTimeout, defaultMessageNotifications, explicitContentFilter, mfaLevel, premiumTier, preferredLocale, joinedAt, large, unavailable, memberCount, roles, emojis, stickers, voiceStates, members, channels, presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableGuildCreateData of(Id id, String name, Optional<String> icon, Optional<String> splash, Optional<String> discoverySplash, Possible<Boolean> owner, Possible<Long> permissions, Optional<Id> afkChannelId, Possible<Boolean> embedEnabled, Possible<Optional<Id>> embedChannelId, Iterable<String> features, Optional<Id> applicationId, Possible<Boolean> widgetEnabled, Possible<Optional<Id>> widgetChannelId, Optional<Id> systemChannelId, OptionalInt systemChannelFlags, Optional<Id> rulesChannelId, Possible<Optional<Integer>> maxPresences, Possible<Integer> maxMembers, Optional<String> vanityUrlCode, Optional<String> description, Optional<String> banner, Possible<Integer> premiumSubscriptionCount, Optional<Id> publicUpdatesChannelId, Possible<Integer> maxVideoChannelUsers, Possible<Integer> approximateMemberCount, Possible<Integer> approximatePresenceCount, Possible<WelcomeScreenData> welcomeScreen, Possible<Boolean> nsfw, Optional<Id> safetyAlertsChannelId, int verificationLevel, int nsfwLevel, Id ownerId, Possible<Optional<String>> region, int afkTimeout, int defaultMessageNotifications, int explicitContentFilter, int mfaLevel, int premiumTier, String preferredLocale, String joinedAt, boolean large, Possible<Boolean> unavailable, int memberCount, Iterable<? extends RoleData> roles, Iterable<? extends EmojiData> emojis, Possible<List<StickerData>> stickers, Iterable<? extends VoiceStateData> voiceStates, Iterable<? extends MemberData> members, Iterable<? extends ChannelData> channels, Iterable<? extends PresenceData> presences) {
/* 7586 */     return new ImmutableGuildCreateData(id, name, icon, splash, discoverySplash, owner, permissions, afkChannelId, embedEnabled, embedChannelId, features, applicationId, widgetEnabled, widgetChannelId, systemChannelId, systemChannelFlags, rulesChannelId, maxPresences, maxMembers, vanityUrlCode, description, banner, premiumSubscriptionCount, publicUpdatesChannelId, maxVideoChannelUsers, approximateMemberCount, approximatePresenceCount, welcomeScreen, nsfw, safetyAlertsChannelId, verificationLevel, nsfwLevel, ownerId, region, afkTimeout, defaultMessageNotifications, explicitContentFilter, mfaLevel, premiumTier, preferredLocale, joinedAt, large, unavailable, memberCount, roles, emojis, stickers, voiceStates, members, channels, presences);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableGuildCreateData copyOf(GuildCreateData instance) {
/* 7597 */     if (instance instanceof ImmutableGuildCreateData) {
/* 7598 */       return (ImmutableGuildCreateData)instance;
/*      */     }
/* 7600 */     return builder()
/* 7601 */       .from(instance)
/* 7602 */       .build();
/*      */   }
/*      */   
/*      */   public boolean isOwnerPresent() {
/* 7606 */     return !this.owner_absent;
/*      */   }
/*      */   
/*      */   public Boolean ownerOrElse(Boolean defaultValue) {
/* 7610 */     return !this.owner_absent ? this.owner_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isPermissionsPresent() {
/* 7614 */     return !this.permissions_absent;
/*      */   }
/*      */   
/*      */   public Long permissionsOrElse(Long defaultValue) {
/* 7618 */     return !this.permissions_absent ? this.permissions_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isAfkChannelIdPresent() {
/* 7622 */     return this.afkChannelId_present;
/*      */   }
/*      */   
/*      */   public long afkChannelIdOrElse(long defaultValue) {
/* 7626 */     return this.afkChannelId_present ? this.afkChannelId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isEmbedEnabledPresent() {
/* 7630 */     return !this.embedEnabled_absent;
/*      */   }
/*      */   
/*      */   public Boolean embedEnabledOrElse(Boolean defaultValue) {
/* 7634 */     return !this.embedEnabled_absent ? this.embedEnabled_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isEmbedChannelIdPresent() {
/* 7638 */     return !this.embedChannelId_absent;
/*      */   }
/*      */   
/*      */   public long embedChannelIdOrElse(long defaultValue) {
/* 7642 */     return !this.embedChannelId_absent ? this.embedChannelId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isApplicationIdPresent() {
/* 7646 */     return this.applicationId_present;
/*      */   }
/*      */   
/*      */   public long applicationIdOrElse(long defaultValue) {
/* 7650 */     return this.applicationId_present ? this.applicationId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isWidgetEnabledPresent() {
/* 7654 */     return !this.widgetEnabled_absent;
/*      */   }
/*      */   
/*      */   public Boolean widgetEnabledOrElse(Boolean defaultValue) {
/* 7658 */     return !this.widgetEnabled_absent ? this.widgetEnabled_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isWidgetChannelIdPresent() {
/* 7662 */     return !this.widgetChannelId_absent;
/*      */   }
/*      */   
/*      */   public long widgetChannelIdOrElse(long defaultValue) {
/* 7666 */     return !this.widgetChannelId_absent ? this.widgetChannelId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isSystemChannelIdPresent() {
/* 7670 */     return this.systemChannelId_present;
/*      */   }
/*      */   
/*      */   public long systemChannelIdOrElse(long defaultValue) {
/* 7674 */     return this.systemChannelId_present ? this.systemChannelId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isRulesChannelIdPresent() {
/* 7678 */     return this.rulesChannelId_present;
/*      */   }
/*      */   
/*      */   public long rulesChannelIdOrElse(long defaultValue) {
/* 7682 */     return this.rulesChannelId_present ? this.rulesChannelId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isMaxPresencesPresent() {
/* 7686 */     return !this.maxPresences_absent;
/*      */   }
/*      */   
/*      */   public Integer maxPresencesOrElse(Integer defaultValue) {
/* 7690 */     return !this.maxPresences_absent ? this.maxPresences_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isMaxMembersPresent() {
/* 7694 */     return !this.maxMembers_absent;
/*      */   }
/*      */   
/*      */   public Integer maxMembersOrElse(Integer defaultValue) {
/* 7698 */     return !this.maxMembers_absent ? this.maxMembers_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isPremiumSubscriptionCountPresent() {
/* 7702 */     return !this.premiumSubscriptionCount_absent;
/*      */   }
/*      */   
/*      */   public Integer premiumSubscriptionCountOrElse(Integer defaultValue) {
/* 7706 */     return !this.premiumSubscriptionCount_absent ? this.premiumSubscriptionCount_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isPublicUpdatesChannelIdPresent() {
/* 7710 */     return this.publicUpdatesChannelId_present;
/*      */   }
/*      */   
/*      */   public long publicUpdatesChannelIdOrElse(long defaultValue) {
/* 7714 */     return this.publicUpdatesChannelId_present ? this.publicUpdatesChannelId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isMaxVideoChannelUsersPresent() {
/* 7718 */     return !this.maxVideoChannelUsers_absent;
/*      */   }
/*      */   
/*      */   public Integer maxVideoChannelUsersOrElse(Integer defaultValue) {
/* 7722 */     return !this.maxVideoChannelUsers_absent ? this.maxVideoChannelUsers_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isApproximateMemberCountPresent() {
/* 7726 */     return !this.approximateMemberCount_absent;
/*      */   }
/*      */   
/*      */   public Integer approximateMemberCountOrElse(Integer defaultValue) {
/* 7730 */     return !this.approximateMemberCount_absent ? this.approximateMemberCount_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isApproximatePresenceCountPresent() {
/* 7734 */     return !this.approximatePresenceCount_absent;
/*      */   }
/*      */   
/*      */   public Integer approximatePresenceCountOrElse(Integer defaultValue) {
/* 7738 */     return !this.approximatePresenceCount_absent ? this.approximatePresenceCount_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isWelcomeScreenPresent() {
/* 7742 */     return !this.welcomeScreen_absent;
/*      */   }
/*      */   
/*      */   public WelcomeScreenData welcomeScreenOrElse(WelcomeScreenData defaultValue) {
/* 7746 */     return !this.welcomeScreen_absent ? this.welcomeScreen_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isNsfwPresent() {
/* 7750 */     return !this.nsfw_absent;
/*      */   }
/*      */   
/*      */   public Boolean nsfwOrElse(Boolean defaultValue) {
/* 7754 */     return !this.nsfw_absent ? this.nsfw_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isSafetyAlertsChannelIdPresent() {
/* 7758 */     return this.safetyAlertsChannelId_present;
/*      */   }
/*      */   
/*      */   public long safetyAlertsChannelIdOrElse(long defaultValue) {
/* 7762 */     return this.safetyAlertsChannelId_present ? this.safetyAlertsChannelId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isRegionPresent() {
/* 7766 */     return !this.region_absent;
/*      */   }
/*      */   
/*      */   public String regionOrElse(String defaultValue) {
/* 7770 */     return !this.region_absent ? this.region_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isUnavailablePresent() {
/* 7774 */     return !this.unavailable_absent;
/*      */   }
/*      */   
/*      */   public Boolean unavailableOrElse(Boolean defaultValue) {
/* 7778 */     return !this.unavailable_absent ? this.unavailable_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isStickersPresent() {
/* 7782 */     return !this.stickers_absent;
/*      */   }
/*      */   
/*      */   public List<StickerData> stickersOrElse(List<StickerData> defaultValue) {
/* 7786 */     return !this.stickers_absent ? this.stickers_value : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Builder builder() {
/* 7849 */     return new Builder();
/*      */   }
/*      */ 
/*      */   
/*      */   @Generated(from = "GuildCreateData", generator = "Immutables")
/*      */   public static final class Builder
/*      */   {
/*      */     private static final long INIT_BIT_NAME = 1L;
/*      */     
/*      */     private static final long INIT_BIT_VERIFICATION_LEVEL = 2L;
/*      */     
/*      */     private static final long INIT_BIT_NSFW_LEVEL = 4L;
/*      */     
/*      */     private static final long INIT_BIT_AFK_TIMEOUT = 8L;
/*      */     
/*      */     private static final long INIT_BIT_DEFAULT_MESSAGE_NOTIFICATIONS = 16L;
/*      */     
/*      */     private static final long INIT_BIT_EXPLICIT_CONTENT_FILTER = 32L;
/*      */     private static final long INIT_BIT_MFA_LEVEL = 64L;
/*      */     private static final long INIT_BIT_PREMIUM_TIER = 128L;
/*      */     private static final long INIT_BIT_PREFERRED_LOCALE = 256L;
/*      */     private static final long INIT_BIT_JOINED_AT = 512L;
/*      */     private static final long INIT_BIT_LARGE = 1024L;
/*      */     private static final long INIT_BIT_MEMBER_COUNT = 2048L;
/* 7873 */     private long initBits = 4095L;
/*      */     
/* 7875 */     private Id id_id = null;
/* 7876 */     private Possible<Boolean> owner_possible = Possible.absent();
/* 7877 */     private Possible<Long> permissions_possible = Possible.absent();
/* 7878 */     private Optional<Id> afkChannelId_optional = Optional.empty();
/* 7879 */     private Possible<Boolean> embedEnabled_possible = Possible.absent();
/* 7880 */     private Possible<Optional<Id>> embedChannelId_possible = Possible.absent();
/* 7881 */     private Optional<Id> applicationId_optional = Optional.empty();
/* 7882 */     private Possible<Boolean> widgetEnabled_possible = Possible.absent();
/* 7883 */     private Possible<Optional<Id>> widgetChannelId_possible = Possible.absent();
/* 7884 */     private Optional<Id> systemChannelId_optional = Optional.empty();
/* 7885 */     private Optional<Id> rulesChannelId_optional = Optional.empty();
/* 7886 */     private Possible<Optional<Integer>> maxPresences_possible = Possible.absent();
/* 7887 */     private Possible<Integer> maxMembers_possible = Possible.absent();
/* 7888 */     private Possible<Integer> premiumSubscriptionCount_possible = Possible.absent();
/* 7889 */     private Optional<Id> publicUpdatesChannelId_optional = Optional.empty();
/* 7890 */     private Possible<Integer> maxVideoChannelUsers_possible = Possible.absent();
/* 7891 */     private Possible<Integer> approximateMemberCount_possible = Possible.absent();
/* 7892 */     private Possible<Integer> approximatePresenceCount_possible = Possible.absent();
/* 7893 */     private Possible<WelcomeScreenData> welcomeScreen_possible = Possible.absent();
/* 7894 */     private Possible<Boolean> nsfw_possible = Possible.absent();
/* 7895 */     private Optional<Id> safetyAlertsChannelId_optional = Optional.empty();
/* 7896 */     private Id ownerId_id = null;
/* 7897 */     private Possible<Optional<String>> region_possible = Possible.absent();
/* 7898 */     private Possible<Boolean> unavailable_possible = Possible.absent();
/* 7899 */     private List<StickerData> stickers_list = null;
/*      */     private String name;
/*      */     private String icon;
/*      */     private String splash;
/*      */     private String discoverySplash;
/* 7904 */     private List<String> features = new ArrayList<>();
/*      */     private Integer systemChannelFlags;
/*      */     private String vanityUrlCode;
/*      */     private String description;
/*      */     private String banner;
/*      */     private int verificationLevel;
/*      */     private int nsfwLevel;
/*      */     private int afkTimeout;
/*      */     private int defaultMessageNotifications;
/*      */     private int explicitContentFilter;
/*      */     private int mfaLevel;
/*      */     private int premiumTier;
/*      */     private String preferredLocale;
/*      */     private String joinedAt;
/*      */     private boolean large;
/*      */     private int memberCount;
/* 7920 */     private List<RoleData> roles = new ArrayList<>();
/* 7921 */     private List<EmojiData> emojis = new ArrayList<>();
/* 7922 */     private List<VoiceStateData> voiceStates = new ArrayList<>();
/* 7923 */     private List<MemberData> members = new ArrayList<>();
/* 7924 */     private List<ChannelData> channels = new ArrayList<>();
/* 7925 */     private List<PresenceData> presences = new ArrayList<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(GuildFields instance) {
/* 7936 */       Objects.requireNonNull(instance, "instance");
/* 7937 */       from(instance);
/* 7938 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(GuildUpdateFields instance) {
/* 7947 */       Objects.requireNonNull(instance, "instance");
/* 7948 */       from(instance);
/* 7949 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(GuildCreateFields instance) {
/* 7958 */       Objects.requireNonNull(instance, "instance");
/* 7959 */       from(instance);
/* 7960 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(GuildNsfwLevelField instance) {
/* 7969 */       Objects.requireNonNull(instance, "instance");
/* 7970 */       from(instance);
/* 7971 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(GuildVerificationLevelField instance) {
/* 7980 */       Objects.requireNonNull(instance, "instance");
/* 7981 */       from(instance);
/* 7982 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(GuildCreateData instance) {
/* 7991 */       Objects.requireNonNull(instance, "instance");
/* 7992 */       from(instance);
/* 7993 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(GuildRolesEmojisStickersFields instance) {
/* 8002 */       Objects.requireNonNull(instance, "instance");
/* 8003 */       from(instance);
/* 8004 */       return this;
/*      */     }
/*      */     
/*      */     private void from(Object object) {
/* 8008 */       long bits = 0L;
/* 8009 */       if (object instanceof GuildFields) {
/* 8010 */         GuildFields instance = (GuildFields)object;
/* 8011 */         if ((bits & 0x2000000L) == 0L) {
/* 8012 */           Optional<String> vanityUrlCodeOptional = instance.vanityUrlCode();
/* 8013 */           if (vanityUrlCodeOptional.isPresent()) {
/* 8014 */             vanityUrlCode(vanityUrlCodeOptional);
/*      */           }
/* 8016 */           bits |= 0x2000000L;
/*      */         } 
/* 8018 */         if ((bits & 0x8000000L) == 0L) {
/* 8019 */           Optional<String> iconOptional = instance.icon();
/* 8020 */           if (iconOptional.isPresent()) {
/* 8021 */             icon(iconOptional);
/*      */           }
/* 8023 */           bits |= 0x8000000L;
/*      */         } 
/* 8025 */         if ((bits & 0x10000000L) == 0L) {
/* 8026 */           Optional<String> descriptionOptional = instance.description();
/* 8027 */           if (descriptionOptional.isPresent()) {
/* 8028 */             description(descriptionOptional);
/*      */           }
/* 8030 */           bits |= 0x10000000L;
/*      */         } 
/* 8032 */         if ((bits & 0x10L) == 0L) {
/* 8033 */           afkChannelId(instance.afkChannelId());
/* 8034 */           bits |= 0x10L;
/*      */         } 
/* 8036 */         if ((bits & 0x40L) == 0L) {
/* 8037 */           addAllFeatures(instance.features());
/* 8038 */           bits |= 0x40L;
/*      */         } 
/* 8040 */         if ((bits & 0x80L) == 0L) {
/* 8041 */           maxMembers(instance.maxMembers());
/* 8042 */           bits |= 0x80L;
/*      */         } 
/* 8044 */         if ((bits & 0x100L) == 0L) {
/* 8045 */           permissions(instance.permissions());
/* 8046 */           bits |= 0x100L;
/*      */         } 
/* 8048 */         if ((bits & 0x200L) == 0L) {
/* 8049 */           publicUpdatesChannelId(instance.publicUpdatesChannelId());
/* 8050 */           bits |= 0x200L;
/*      */         } 
/* 8052 */         if ((bits & 0x800L) == 0L) {
/* 8053 */           id(instance.id());
/* 8054 */           bits |= 0x800L;
/*      */         } 
/* 8056 */         if ((bits & 0x20000000L) == 0L) {
/* 8057 */           safetyAlertsChannelId(instance.safetyAlertsChannelId());
/* 8058 */           bits |= 0x20000000L;
/*      */         } 
/* 8060 */         if ((bits & 0x40000000L) == 0L) {
/* 8061 */           systemChannelId(instance.systemChannelId());
/* 8062 */           bits |= 0x40000000L;
/*      */         } 
/* 8064 */         if ((bits & 0x100000000L) == 0L) {
/* 8065 */           owner(instance.owner());
/* 8066 */           bits |= 0x100000000L;
/*      */         } 
/* 8068 */         if ((bits & 0x1000L) == 0L) {
/* 8069 */           approximateMemberCount(instance.approximateMemberCount());
/* 8070 */           bits |= 0x1000L;
/*      */         } 
/* 8072 */         if ((bits & 0x400000000L) == 0L) {
/* 8073 */           Optional<String> discoverySplashOptional = instance.discoverySplash();
/* 8074 */           if (discoverySplashOptional.isPresent()) {
/* 8075 */             discoverySplash(discoverySplashOptional);
/*      */           }
/* 8077 */           bits |= 0x400000000L;
/*      */         } 
/* 8079 */         if ((bits & 0x1000000000L) == 0L) {
/* 8080 */           maxPresences(instance.maxPresences());
/* 8081 */           bits |= 0x1000000000L;
/*      */         } 
/* 8083 */         if ((bits & 0x2000000000L) == 0L) {
/* 8084 */           welcomeScreen(instance.welcomeScreen());
/* 8085 */           bits |= 0x2000000000L;
/*      */         } 
/* 8087 */         if ((bits & 0x4000L) == 0L) {
/* 8088 */           rulesChannelId(instance.rulesChannelId());
/* 8089 */           bits |= 0x4000L;
/*      */         } 
/* 8091 */         if ((bits & 0x4000000000L) == 0L) {
/* 8092 */           nsfw(instance.nsfw());
/* 8093 */           bits |= 0x4000000000L;
/*      */         } 
/* 8095 */         if ((bits & 0x10000L) == 0L) {
/* 8096 */           widgetChannelId(instance.widgetChannelId());
/* 8097 */           bits |= 0x10000L;
/*      */         } 
/* 8099 */         if ((bits & 0x10000000000L) == 0L) {
/* 8100 */           Optional<String> bannerOptional = instance.banner();
/* 8101 */           if (bannerOptional.isPresent()) {
/* 8102 */             banner(bannerOptional);
/*      */           }
/* 8104 */           bits |= 0x10000000000L;
/*      */         } 
/* 8106 */         if ((bits & 0x20000L) == 0L) {
/* 8107 */           widgetEnabled(instance.widgetEnabled());
/* 8108 */           bits |= 0x20000L;
/*      */         } 
/* 8110 */         if ((bits & 0x20000000000L) == 0L) {
/* 8111 */           embedChannelId(instance.embedChannelId());
/* 8112 */           bits |= 0x20000000000L;
/*      */         } 
/* 8114 */         if ((bits & 0x40000L) == 0L) {
/* 8115 */           OptionalInt systemChannelFlagsOptional = instance.systemChannelFlags();
/* 8116 */           if (systemChannelFlagsOptional.isPresent()) {
/* 8117 */             systemChannelFlags(systemChannelFlagsOptional);
/*      */           }
/* 8119 */           bits |= 0x40000L;
/*      */         } 
/* 8121 */         if ((bits & 0x40000000000L) == 0L) {
/* 8122 */           maxVideoChannelUsers(instance.maxVideoChannelUsers());
/* 8123 */           bits |= 0x40000000000L;
/*      */         } 
/* 8125 */         if ((bits & 0x80000L) == 0L) {
/* 8126 */           name(instance.name());
/* 8127 */           bits |= 0x80000L;
/*      */         } 
/* 8129 */         if ((bits & 0x100000L) == 0L) {
/* 8130 */           premiumSubscriptionCount(instance.premiumSubscriptionCount());
/* 8131 */           bits |= 0x100000L;
/*      */         } 
/* 8133 */         if ((bits & 0x100000000000L) == 0L) {
/* 8134 */           embedEnabled(instance.embedEnabled());
/* 8135 */           bits |= 0x100000000000L;
/*      */         } 
/* 8137 */         if ((bits & 0x200000L) == 0L) {
/* 8138 */           approximatePresenceCount(instance.approximatePresenceCount());
/* 8139 */           bits |= 0x200000L;
/*      */         } 
/* 8141 */         if ((bits & 0x400000L) == 0L) {
/* 8142 */           applicationId(instance.applicationId());
/* 8143 */           bits |= 0x400000L;
/*      */         } 
/* 8145 */         if ((bits & 0x400000000000L) == 0L) {
/* 8146 */           Optional<String> splashOptional = instance.splash();
/* 8147 */           if (splashOptional.isPresent()) {
/* 8148 */             splash(splashOptional);
/*      */           }
/* 8150 */           bits |= 0x400000000000L;
/*      */         } 
/*      */       } 
/* 8153 */       if (object instanceof GuildUpdateFields) {
/* 8154 */         GuildUpdateFields instance = (GuildUpdateFields)object;
/* 8155 */         if ((bits & 0x1000000L) == 0L) {
/* 8156 */           explicitContentFilter(instance.explicitContentFilter());
/* 8157 */           bits |= 0x1000000L;
/*      */         } 
/* 8159 */         if ((bits & 0x2000000L) == 0L) {
/* 8160 */           Optional<String> vanityUrlCodeOptional = instance.vanityUrlCode();
/* 8161 */           if (vanityUrlCodeOptional.isPresent()) {
/* 8162 */             vanityUrlCode(vanityUrlCodeOptional);
/*      */           }
/* 8164 */           bits |= 0x2000000L;
/*      */         } 
/* 8166 */         if ((bits & 0x2L) == 0L) {
/* 8167 */           afkTimeout(instance.afkTimeout());
/* 8168 */           bits |= 0x2L;
/*      */         } 
/* 8170 */         if ((bits & 0x4L) == 0L) {
/* 8171 */           premiumTier(instance.premiumTier());
/* 8172 */           bits |= 0x4L;
/*      */         } 
/* 8174 */         if ((bits & 0x8L) == 0L) {
/* 8175 */           verificationLevel(instance.verificationLevel());
/* 8176 */           bits |= 0x8L;
/*      */         } 
/* 8178 */         if ((bits & 0x8000000L) == 0L) {
/* 8179 */           Optional<String> iconOptional = instance.icon();
/* 8180 */           if (iconOptional.isPresent()) {
/* 8181 */             icon(iconOptional);
/*      */           }
/* 8183 */           bits |= 0x8000000L;
/*      */         } 
/* 8185 */         if ((bits & 0x10000000L) == 0L) {
/* 8186 */           Optional<String> descriptionOptional = instance.description();
/* 8187 */           if (descriptionOptional.isPresent()) {
/* 8188 */             description(descriptionOptional);
/*      */           }
/* 8190 */           bits |= 0x10000000L;
/*      */         } 
/* 8192 */         if ((bits & 0x10L) == 0L) {
/* 8193 */           afkChannelId(instance.afkChannelId());
/* 8194 */           bits |= 0x10L;
/*      */         } 
/* 8196 */         if ((bits & 0x20L) == 0L) {
/* 8197 */           ownerId(instance.ownerId());
/* 8198 */           bits |= 0x20L;
/*      */         } 
/* 8200 */         if ((bits & 0x40L) == 0L) {
/* 8201 */           addAllFeatures(instance.features());
/* 8202 */           bits |= 0x40L;
/*      */         } 
/* 8204 */         if ((bits & 0x80L) == 0L) {
/* 8205 */           maxMembers(instance.maxMembers());
/* 8206 */           bits |= 0x80L;
/*      */         } 
/* 8208 */         if ((bits & 0x100L) == 0L) {
/* 8209 */           permissions(instance.permissions());
/* 8210 */           bits |= 0x100L;
/*      */         } 
/* 8212 */         if ((bits & 0x200L) == 0L) {
/* 8213 */           publicUpdatesChannelId(instance.publicUpdatesChannelId());
/* 8214 */           bits |= 0x200L;
/*      */         } 
/* 8216 */         if ((bits & 0x800L) == 0L) {
/* 8217 */           id(instance.id());
/* 8218 */           bits |= 0x800L;
/*      */         } 
/* 8220 */         if ((bits & 0x20000000L) == 0L) {
/* 8221 */           safetyAlertsChannelId(instance.safetyAlertsChannelId());
/* 8222 */           bits |= 0x20000000L;
/*      */         } 
/* 8224 */         if ((bits & 0x40000000L) == 0L) {
/* 8225 */           systemChannelId(instance.systemChannelId());
/* 8226 */           bits |= 0x40000000L;
/*      */         } 
/* 8228 */         if ((bits & 0x80000000L) == 0L) {
/* 8229 */           preferredLocale(instance.preferredLocale());
/* 8230 */           bits |= 0x80000000L;
/*      */         } 
/* 8232 */         if ((bits & 0x100000000L) == 0L) {
/* 8233 */           owner(instance.owner());
/* 8234 */           bits |= 0x100000000L;
/*      */         } 
/* 8236 */         if ((bits & 0x1000L) == 0L) {
/* 8237 */           approximateMemberCount(instance.approximateMemberCount());
/* 8238 */           bits |= 0x1000L;
/*      */         } 
/* 8240 */         if ((bits & 0x400000000L) == 0L) {
/* 8241 */           Optional<String> discoverySplashOptional = instance.discoverySplash();
/* 8242 */           if (discoverySplashOptional.isPresent()) {
/* 8243 */             discoverySplash(discoverySplashOptional);
/*      */           }
/* 8245 */           bits |= 0x400000000L;
/*      */         } 
/* 8247 */         if ((bits & 0x800000000L) == 0L) {
/* 8248 */           defaultMessageNotifications(instance.defaultMessageNotifications());
/* 8249 */           bits |= 0x800000000L;
/*      */         } 
/* 8251 */         if ((bits & 0x1000000000L) == 0L) {
/* 8252 */           maxPresences(instance.maxPresences());
/* 8253 */           bits |= 0x1000000000L;
/*      */         } 
/* 8255 */         if ((bits & 0x2000000000L) == 0L) {
/* 8256 */           welcomeScreen(instance.welcomeScreen());
/* 8257 */           bits |= 0x2000000000L;
/*      */         } 
/* 8259 */         if ((bits & 0x4000L) == 0L) {
/* 8260 */           rulesChannelId(instance.rulesChannelId());
/* 8261 */           bits |= 0x4000L;
/*      */         } 
/* 8263 */         if ((bits & 0x4000000000L) == 0L) {
/* 8264 */           nsfw(instance.nsfw());
/* 8265 */           bits |= 0x4000000000L;
/*      */         } 
/* 8267 */         if ((bits & 0x10000L) == 0L) {
/* 8268 */           widgetChannelId(instance.widgetChannelId());
/* 8269 */           bits |= 0x10000L;
/*      */         } 
/* 8271 */         if ((bits & 0x10000000000L) == 0L) {
/* 8272 */           Optional<String> bannerOptional = instance.banner();
/* 8273 */           if (bannerOptional.isPresent()) {
/* 8274 */             banner(bannerOptional);
/*      */           }
/* 8276 */           bits |= 0x10000000000L;
/*      */         } 
/* 8278 */         if ((bits & 0x20000L) == 0L) {
/* 8279 */           widgetEnabled(instance.widgetEnabled());
/* 8280 */           bits |= 0x20000L;
/*      */         } 
/* 8282 */         if ((bits & 0x20000000000L) == 0L) {
/* 8283 */           embedChannelId(instance.embedChannelId());
/* 8284 */           bits |= 0x20000000000L;
/*      */         } 
/* 8286 */         if ((bits & 0x40000L) == 0L) {
/* 8287 */           OptionalInt systemChannelFlagsOptional = instance.systemChannelFlags();
/* 8288 */           if (systemChannelFlagsOptional.isPresent()) {
/* 8289 */             systemChannelFlags(systemChannelFlagsOptional);
/*      */           }
/* 8291 */           bits |= 0x40000L;
/*      */         } 
/* 8293 */         if ((bits & 0x40000000000L) == 0L) {
/* 8294 */           maxVideoChannelUsers(instance.maxVideoChannelUsers());
/* 8295 */           bits |= 0x40000000000L;
/*      */         } 
/* 8297 */         if ((bits & 0x80000000000L) == 0L) {
/* 8298 */           nsfwLevel(instance.nsfwLevel());
/* 8299 */           bits |= 0x80000000000L;
/*      */         } 
/* 8301 */         if ((bits & 0x80000L) == 0L) {
/* 8302 */           name(instance.name());
/* 8303 */           bits |= 0x80000L;
/*      */         } 
/* 8305 */         if ((bits & 0x100000L) == 0L) {
/* 8306 */           premiumSubscriptionCount(instance.premiumSubscriptionCount());
/* 8307 */           bits |= 0x100000L;
/*      */         } 
/* 8309 */         if ((bits & 0x100000000000L) == 0L) {
/* 8310 */           embedEnabled(instance.embedEnabled());
/* 8311 */           bits |= 0x100000000000L;
/*      */         } 
/* 8313 */         if ((bits & 0x200000L) == 0L) {
/* 8314 */           approximatePresenceCount(instance.approximatePresenceCount());
/* 8315 */           bits |= 0x200000L;
/*      */         } 
/* 8317 */         if ((bits & 0x400000L) == 0L) {
/* 8318 */           applicationId(instance.applicationId());
/* 8319 */           bits |= 0x400000L;
/*      */         } 
/* 8321 */         if ((bits & 0x800000L) == 0L) {
/* 8322 */           region(instance.region());
/* 8323 */           bits |= 0x800000L;
/*      */         } 
/* 8325 */         if ((bits & 0x200000000000L) == 0L) {
/* 8326 */           mfaLevel(instance.mfaLevel());
/* 8327 */           bits |= 0x200000000000L;
/*      */         } 
/* 8329 */         if ((bits & 0x400000000000L) == 0L) {
/* 8330 */           Optional<String> splashOptional = instance.splash();
/* 8331 */           if (splashOptional.isPresent()) {
/* 8332 */             splash(splashOptional);
/*      */           }
/* 8334 */           bits |= 0x400000000000L;
/*      */         } 
/*      */       } 
/* 8337 */       if (object instanceof GuildCreateFields) {
/* 8338 */         GuildCreateFields instance = (GuildCreateFields)object;
/* 8339 */         if ((bits & 0x1000000L) == 0L) {
/* 8340 */           explicitContentFilter(instance.explicitContentFilter());
/* 8341 */           bits |= 0x1000000L;
/*      */         } 
/* 8343 */         if ((bits & 0x2000000L) == 0L) {
/* 8344 */           Optional<String> vanityUrlCodeOptional = instance.vanityUrlCode();
/* 8345 */           if (vanityUrlCodeOptional.isPresent()) {
/* 8346 */             vanityUrlCode(vanityUrlCodeOptional);
/*      */           }
/* 8348 */           bits |= 0x2000000L;
/*      */         } 
/* 8350 */         if ((bits & 0x1L) == 0L) {
/* 8351 */           unavailable(instance.unavailable());
/* 8352 */           bits |= 0x1L;
/*      */         } 
/* 8354 */         if ((bits & 0x2L) == 0L) {
/* 8355 */           afkTimeout(instance.afkTimeout());
/* 8356 */           bits |= 0x2L;
/*      */         } 
/* 8358 */         if ((bits & 0x4L) == 0L) {
/* 8359 */           premiumTier(instance.premiumTier());
/* 8360 */           bits |= 0x4L;
/*      */         } 
/* 8362 */         if ((bits & 0x8L) == 0L) {
/* 8363 */           verificationLevel(instance.verificationLevel());
/* 8364 */           bits |= 0x8L;
/*      */         } 
/* 8366 */         if ((bits & 0x8000000L) == 0L) {
/* 8367 */           Optional<String> iconOptional = instance.icon();
/* 8368 */           if (iconOptional.isPresent()) {
/* 8369 */             icon(iconOptional);
/*      */           }
/* 8371 */           bits |= 0x8000000L;
/*      */         } 
/* 8373 */         if ((bits & 0x10000000L) == 0L) {
/* 8374 */           Optional<String> descriptionOptional = instance.description();
/* 8375 */           if (descriptionOptional.isPresent()) {
/* 8376 */             description(descriptionOptional);
/*      */           }
/* 8378 */           bits |= 0x10000000L;
/*      */         } 
/* 8380 */         if ((bits & 0x10L) == 0L) {
/* 8381 */           afkChannelId(instance.afkChannelId());
/* 8382 */           bits |= 0x10L;
/*      */         } 
/* 8384 */         if ((bits & 0x20L) == 0L) {
/* 8385 */           ownerId(instance.ownerId());
/* 8386 */           bits |= 0x20L;
/*      */         } 
/* 8388 */         if ((bits & 0x40L) == 0L) {
/* 8389 */           addAllFeatures(instance.features());
/* 8390 */           bits |= 0x40L;
/*      */         } 
/* 8392 */         if ((bits & 0x80L) == 0L) {
/* 8393 */           maxMembers(instance.maxMembers());
/* 8394 */           bits |= 0x80L;
/*      */         } 
/* 8396 */         if ((bits & 0x100L) == 0L) {
/* 8397 */           permissions(instance.permissions());
/* 8398 */           bits |= 0x100L;
/*      */         } 
/* 8400 */         if ((bits & 0x200L) == 0L) {
/* 8401 */           publicUpdatesChannelId(instance.publicUpdatesChannelId());
/* 8402 */           bits |= 0x200L;
/*      */         } 
/* 8404 */         if ((bits & 0x800L) == 0L) {
/* 8405 */           id(instance.id());
/* 8406 */           bits |= 0x800L;
/*      */         } 
/* 8408 */         if ((bits & 0x20000000L) == 0L) {
/* 8409 */           safetyAlertsChannelId(instance.safetyAlertsChannelId());
/* 8410 */           bits |= 0x20000000L;
/*      */         } 
/* 8412 */         if ((bits & 0x40000000L) == 0L) {
/* 8413 */           systemChannelId(instance.systemChannelId());
/* 8414 */           bits |= 0x40000000L;
/*      */         } 
/* 8416 */         if ((bits & 0x80000000L) == 0L) {
/* 8417 */           preferredLocale(instance.preferredLocale());
/* 8418 */           bits |= 0x80000000L;
/*      */         } 
/* 8420 */         if ((bits & 0x100000000L) == 0L) {
/* 8421 */           owner(instance.owner());
/* 8422 */           bits |= 0x100000000L;
/*      */         } 
/* 8424 */         if ((bits & 0x1000L) == 0L) {
/* 8425 */           approximateMemberCount(instance.approximateMemberCount());
/* 8426 */           bits |= 0x1000L;
/*      */         } 
/* 8428 */         if ((bits & 0x400000000L) == 0L) {
/* 8429 */           Optional<String> discoverySplashOptional = instance.discoverySplash();
/* 8430 */           if (discoverySplashOptional.isPresent()) {
/* 8431 */             discoverySplash(discoverySplashOptional);
/*      */           }
/* 8433 */           bits |= 0x400000000L;
/*      */         } 
/* 8435 */         if ((bits & 0x800000000L) == 0L) {
/* 8436 */           defaultMessageNotifications(instance.defaultMessageNotifications());
/* 8437 */           bits |= 0x800000000L;
/*      */         } 
/* 8439 */         if ((bits & 0x1000000000L) == 0L) {
/* 8440 */           maxPresences(instance.maxPresences());
/* 8441 */           bits |= 0x1000000000L;
/*      */         } 
/* 8443 */         if ((bits & 0x2000000000L) == 0L) {
/* 8444 */           welcomeScreen(instance.welcomeScreen());
/* 8445 */           bits |= 0x2000000000L;
/*      */         } 
/* 8447 */         if ((bits & 0x2000L) == 0L) {
/* 8448 */           large(instance.large());
/* 8449 */           bits |= 0x2000L;
/*      */         } 
/* 8451 */         if ((bits & 0x4000L) == 0L) {
/* 8452 */           rulesChannelId(instance.rulesChannelId());
/* 8453 */           bits |= 0x4000L;
/*      */         } 
/* 8455 */         if ((bits & 0x4000000000L) == 0L) {
/* 8456 */           nsfw(instance.nsfw());
/* 8457 */           bits |= 0x4000000000L;
/*      */         } 
/* 8459 */         if ((bits & 0x8000L) == 0L) {
/* 8460 */           joinedAt(instance.joinedAt());
/* 8461 */           bits |= 0x8000L;
/*      */         } 
/* 8463 */         if ((bits & 0x8000000000L) == 0L) {
/* 8464 */           memberCount(instance.memberCount());
/* 8465 */           bits |= 0x8000000000L;
/*      */         } 
/* 8467 */         if ((bits & 0x10000L) == 0L) {
/* 8468 */           widgetChannelId(instance.widgetChannelId());
/* 8469 */           bits |= 0x10000L;
/*      */         } 
/* 8471 */         if ((bits & 0x10000000000L) == 0L) {
/* 8472 */           Optional<String> bannerOptional = instance.banner();
/* 8473 */           if (bannerOptional.isPresent()) {
/* 8474 */             banner(bannerOptional);
/*      */           }
/* 8476 */           bits |= 0x10000000000L;
/*      */         } 
/* 8478 */         if ((bits & 0x20000L) == 0L) {
/* 8479 */           widgetEnabled(instance.widgetEnabled());
/* 8480 */           bits |= 0x20000L;
/*      */         } 
/* 8482 */         if ((bits & 0x20000000000L) == 0L) {
/* 8483 */           embedChannelId(instance.embedChannelId());
/* 8484 */           bits |= 0x20000000000L;
/*      */         } 
/* 8486 */         if ((bits & 0x40000L) == 0L) {
/* 8487 */           OptionalInt systemChannelFlagsOptional = instance.systemChannelFlags();
/* 8488 */           if (systemChannelFlagsOptional.isPresent()) {
/* 8489 */             systemChannelFlags(systemChannelFlagsOptional);
/*      */           }
/* 8491 */           bits |= 0x40000L;
/*      */         } 
/* 8493 */         if ((bits & 0x40000000000L) == 0L) {
/* 8494 */           maxVideoChannelUsers(instance.maxVideoChannelUsers());
/* 8495 */           bits |= 0x40000000000L;
/*      */         } 
/* 8497 */         if ((bits & 0x80000000000L) == 0L) {
/* 8498 */           nsfwLevel(instance.nsfwLevel());
/* 8499 */           bits |= 0x80000000000L;
/*      */         } 
/* 8501 */         if ((bits & 0x80000L) == 0L) {
/* 8502 */           name(instance.name());
/* 8503 */           bits |= 0x80000L;
/*      */         } 
/* 8505 */         if ((bits & 0x100000L) == 0L) {
/* 8506 */           premiumSubscriptionCount(instance.premiumSubscriptionCount());
/* 8507 */           bits |= 0x100000L;
/*      */         } 
/* 8509 */         if ((bits & 0x100000000000L) == 0L) {
/* 8510 */           embedEnabled(instance.embedEnabled());
/* 8511 */           bits |= 0x100000000000L;
/*      */         } 
/* 8513 */         if ((bits & 0x200000L) == 0L) {
/* 8514 */           approximatePresenceCount(instance.approximatePresenceCount());
/* 8515 */           bits |= 0x200000L;
/*      */         } 
/* 8517 */         if ((bits & 0x400000L) == 0L) {
/* 8518 */           applicationId(instance.applicationId());
/* 8519 */           bits |= 0x400000L;
/*      */         } 
/* 8521 */         if ((bits & 0x800000L) == 0L) {
/* 8522 */           region(instance.region());
/* 8523 */           bits |= 0x800000L;
/*      */         } 
/* 8525 */         if ((bits & 0x200000000000L) == 0L) {
/* 8526 */           mfaLevel(instance.mfaLevel());
/* 8527 */           bits |= 0x200000000000L;
/*      */         } 
/* 8529 */         if ((bits & 0x400000000000L) == 0L) {
/* 8530 */           Optional<String> splashOptional = instance.splash();
/* 8531 */           if (splashOptional.isPresent()) {
/* 8532 */             splash(splashOptional);
/*      */           }
/* 8534 */           bits |= 0x400000000000L;
/*      */         } 
/*      */       } 
/* 8537 */       if (object instanceof GuildNsfwLevelField) {
/* 8538 */         GuildNsfwLevelField instance = (GuildNsfwLevelField)object;
/* 8539 */         if ((bits & 0x80000000000L) == 0L) {
/* 8540 */           nsfwLevel(instance.nsfwLevel());
/* 8541 */           bits |= 0x80000000000L;
/*      */         } 
/*      */       } 
/* 8544 */       if (object instanceof GuildVerificationLevelField) {
/* 8545 */         GuildVerificationLevelField instance = (GuildVerificationLevelField)object;
/* 8546 */         if ((bits & 0x8L) == 0L) {
/* 8547 */           verificationLevel(instance.verificationLevel());
/* 8548 */           bits |= 0x8L;
/*      */         } 
/*      */       } 
/* 8551 */       if (object instanceof GuildCreateData) {
/* 8552 */         GuildCreateData instance = (GuildCreateData)object;
/* 8553 */         if ((bits & 0x1L) == 0L) {
/* 8554 */           unavailable(instance.unavailable());
/* 8555 */           bits |= 0x1L;
/*      */         } 
/* 8557 */         if ((bits & 0x2L) == 0L) {
/* 8558 */           afkTimeout(instance.afkTimeout());
/* 8559 */           bits |= 0x2L;
/*      */         } 
/* 8561 */         if ((bits & 0x4L) == 0L) {
/* 8562 */           premiumTier(instance.premiumTier());
/* 8563 */           bits |= 0x4L;
/*      */         } 
/* 8565 */         if ((bits & 0x8L) == 0L) {
/* 8566 */           verificationLevel(instance.verificationLevel());
/* 8567 */           bits |= 0x8L;
/*      */         } 
/* 8569 */         if ((bits & 0x10L) == 0L) {
/* 8570 */           afkChannelId(instance.afkChannelId());
/* 8571 */           bits |= 0x10L;
/*      */         } 
/* 8573 */         if ((bits & 0x20L) == 0L) {
/* 8574 */           ownerId(instance.ownerId());
/* 8575 */           bits |= 0x20L;
/*      */         } 
/* 8577 */         if ((bits & 0x40L) == 0L) {
/* 8578 */           addAllFeatures(instance.features());
/* 8579 */           bits |= 0x40L;
/*      */         } 
/* 8581 */         if ((bits & 0x80L) == 0L) {
/* 8582 */           maxMembers(instance.maxMembers());
/* 8583 */           bits |= 0x80L;
/*      */         } 
/* 8585 */         if ((bits & 0x100L) == 0L) {
/* 8586 */           permissions(instance.permissions());
/* 8587 */           bits |= 0x100L;
/*      */         } 
/* 8589 */         addAllMembers(instance.members());
/* 8590 */         if ((bits & 0x200L) == 0L) {
/* 8591 */           publicUpdatesChannelId(instance.publicUpdatesChannelId());
/* 8592 */           bits |= 0x200L;
/*      */         } 
/* 8594 */         if ((bits & 0x400L) == 0L) {
/* 8595 */           stickers(instance.stickers());
/* 8596 */           bits |= 0x400L;
/*      */         } 
/* 8598 */         if ((bits & 0x800L) == 0L) {
/* 8599 */           id(instance.id());
/* 8600 */           bits |= 0x800L;
/*      */         } 
/* 8602 */         if ((bits & 0x1000L) == 0L) {
/* 8603 */           approximateMemberCount(instance.approximateMemberCount());
/* 8604 */           bits |= 0x1000L;
/*      */         } 
/* 8606 */         if ((bits & 0x2000L) == 0L) {
/* 8607 */           large(instance.large());
/* 8608 */           bits |= 0x2000L;
/*      */         } 
/* 8610 */         addAllVoiceStates(instance.voiceStates());
/* 8611 */         if ((bits & 0x4000L) == 0L) {
/* 8612 */           rulesChannelId(instance.rulesChannelId());
/* 8613 */           bits |= 0x4000L;
/*      */         } 
/* 8615 */         if ((bits & 0x8000L) == 0L) {
/* 8616 */           joinedAt(instance.joinedAt());
/* 8617 */           bits |= 0x8000L;
/*      */         } 
/* 8619 */         if ((bits & 0x10000L) == 0L) {
/* 8620 */           widgetChannelId(instance.widgetChannelId());
/* 8621 */           bits |= 0x10000L;
/*      */         } 
/* 8623 */         if ((bits & 0x20000L) == 0L) {
/* 8624 */           widgetEnabled(instance.widgetEnabled());
/* 8625 */           bits |= 0x20000L;
/*      */         } 
/* 8627 */         if ((bits & 0x40000L) == 0L) {
/* 8628 */           OptionalInt systemChannelFlagsOptional = instance.systemChannelFlags();
/* 8629 */           if (systemChannelFlagsOptional.isPresent()) {
/* 8630 */             systemChannelFlags(systemChannelFlagsOptional);
/*      */           }
/* 8632 */           bits |= 0x40000L;
/*      */         } 
/* 8634 */         addAllChannels(instance.channels());
/* 8635 */         if ((bits & 0x80000L) == 0L) {
/* 8636 */           name(instance.name());
/* 8637 */           bits |= 0x80000L;
/*      */         } 
/* 8639 */         if ((bits & 0x100000L) == 0L) {
/* 8640 */           premiumSubscriptionCount(instance.premiumSubscriptionCount());
/* 8641 */           bits |= 0x100000L;
/*      */         } 
/* 8643 */         if ((bits & 0x200000L) == 0L) {
/* 8644 */           approximatePresenceCount(instance.approximatePresenceCount());
/* 8645 */           bits |= 0x200000L;
/*      */         } 
/* 8647 */         if ((bits & 0x400000L) == 0L) {
/* 8648 */           applicationId(instance.applicationId());
/* 8649 */           bits |= 0x400000L;
/*      */         } 
/* 8651 */         if ((bits & 0x800000L) == 0L) {
/* 8652 */           region(instance.region());
/* 8653 */           bits |= 0x800000L;
/*      */         } 
/* 8655 */         if ((bits & 0x1000000L) == 0L) {
/* 8656 */           explicitContentFilter(instance.explicitContentFilter());
/* 8657 */           bits |= 0x1000000L;
/*      */         } 
/* 8659 */         if ((bits & 0x2000000L) == 0L) {
/* 8660 */           Optional<String> vanityUrlCodeOptional = instance.vanityUrlCode();
/* 8661 */           if (vanityUrlCodeOptional.isPresent()) {
/* 8662 */             vanityUrlCode(vanityUrlCodeOptional);
/*      */           }
/* 8664 */           bits |= 0x2000000L;
/*      */         } 
/* 8666 */         if ((bits & 0x4000000L) == 0L) {
/* 8667 */           addAllRoles(instance.roles());
/* 8668 */           bits |= 0x4000000L;
/*      */         } 
/* 8670 */         if ((bits & 0x8000000L) == 0L) {
/* 8671 */           Optional<String> iconOptional = instance.icon();
/* 8672 */           if (iconOptional.isPresent()) {
/* 8673 */             icon(iconOptional);
/*      */           }
/* 8675 */           bits |= 0x8000000L;
/*      */         } 
/* 8677 */         if ((bits & 0x10000000L) == 0L) {
/* 8678 */           Optional<String> descriptionOptional = instance.description();
/* 8679 */           if (descriptionOptional.isPresent()) {
/* 8680 */             description(descriptionOptional);
/*      */           }
/* 8682 */           bits |= 0x10000000L;
/*      */         } 
/* 8684 */         addAllPresences(instance.presences());
/* 8685 */         if ((bits & 0x20000000L) == 0L) {
/* 8686 */           safetyAlertsChannelId(instance.safetyAlertsChannelId());
/* 8687 */           bits |= 0x20000000L;
/*      */         } 
/* 8689 */         if ((bits & 0x40000000L) == 0L) {
/* 8690 */           systemChannelId(instance.systemChannelId());
/* 8691 */           bits |= 0x40000000L;
/*      */         } 
/* 8693 */         if ((bits & 0x80000000L) == 0L) {
/* 8694 */           preferredLocale(instance.preferredLocale());
/* 8695 */           bits |= 0x80000000L;
/*      */         } 
/* 8697 */         if ((bits & 0x100000000L) == 0L) {
/* 8698 */           owner(instance.owner());
/* 8699 */           bits |= 0x100000000L;
/*      */         } 
/* 8701 */         if ((bits & 0x200000000L) == 0L) {
/* 8702 */           addAllEmojis(instance.emojis());
/* 8703 */           bits |= 0x200000000L;
/*      */         } 
/* 8705 */         if ((bits & 0x400000000L) == 0L) {
/* 8706 */           Optional<String> discoverySplashOptional = instance.discoverySplash();
/* 8707 */           if (discoverySplashOptional.isPresent()) {
/* 8708 */             discoverySplash(discoverySplashOptional);
/*      */           }
/* 8710 */           bits |= 0x400000000L;
/*      */         } 
/* 8712 */         if ((bits & 0x800000000L) == 0L) {
/* 8713 */           defaultMessageNotifications(instance.defaultMessageNotifications());
/* 8714 */           bits |= 0x800000000L;
/*      */         } 
/* 8716 */         if ((bits & 0x1000000000L) == 0L) {
/* 8717 */           maxPresences(instance.maxPresences());
/* 8718 */           bits |= 0x1000000000L;
/*      */         } 
/* 8720 */         if ((bits & 0x2000000000L) == 0L) {
/* 8721 */           welcomeScreen(instance.welcomeScreen());
/* 8722 */           bits |= 0x2000000000L;
/*      */         } 
/* 8724 */         if ((bits & 0x4000000000L) == 0L) {
/* 8725 */           nsfw(instance.nsfw());
/* 8726 */           bits |= 0x4000000000L;
/*      */         } 
/* 8728 */         if ((bits & 0x8000000000L) == 0L) {
/* 8729 */           memberCount(instance.memberCount());
/* 8730 */           bits |= 0x8000000000L;
/*      */         } 
/* 8732 */         if ((bits & 0x10000000000L) == 0L) {
/* 8733 */           Optional<String> bannerOptional = instance.banner();
/* 8734 */           if (bannerOptional.isPresent()) {
/* 8735 */             banner(bannerOptional);
/*      */           }
/* 8737 */           bits |= 0x10000000000L;
/*      */         } 
/* 8739 */         if ((bits & 0x20000000000L) == 0L) {
/* 8740 */           embedChannelId(instance.embedChannelId());
/* 8741 */           bits |= 0x20000000000L;
/*      */         } 
/* 8743 */         if ((bits & 0x40000000000L) == 0L) {
/* 8744 */           maxVideoChannelUsers(instance.maxVideoChannelUsers());
/* 8745 */           bits |= 0x40000000000L;
/*      */         } 
/* 8747 */         if ((bits & 0x80000000000L) == 0L) {
/* 8748 */           nsfwLevel(instance.nsfwLevel());
/* 8749 */           bits |= 0x80000000000L;
/*      */         } 
/* 8751 */         if ((bits & 0x100000000000L) == 0L) {
/* 8752 */           embedEnabled(instance.embedEnabled());
/* 8753 */           bits |= 0x100000000000L;
/*      */         } 
/* 8755 */         if ((bits & 0x200000000000L) == 0L) {
/* 8756 */           mfaLevel(instance.mfaLevel());
/* 8757 */           bits |= 0x200000000000L;
/*      */         } 
/* 8759 */         if ((bits & 0x400000000000L) == 0L) {
/* 8760 */           Optional<String> splashOptional = instance.splash();
/* 8761 */           if (splashOptional.isPresent()) {
/* 8762 */             splash(splashOptional);
/*      */           }
/* 8764 */           bits |= 0x400000000000L;
/*      */         } 
/*      */       } 
/* 8767 */       if (object instanceof GuildRolesEmojisStickersFields) {
/* 8768 */         GuildRolesEmojisStickersFields instance = (GuildRolesEmojisStickersFields)object;
/* 8769 */         if ((bits & 0x200000000L) == 0L) {
/* 8770 */           addAllEmojis(instance.emojis());
/* 8771 */           bits |= 0x200000000L;
/*      */         } 
/* 8773 */         if ((bits & 0x400L) == 0L) {
/* 8774 */           stickers(instance.stickers());
/* 8775 */           bits |= 0x400L;
/*      */         } 
/* 8777 */         if ((bits & 0x4000000L) == 0L) {
/* 8778 */           addAllRoles(instance.roles());
/* 8779 */           bits |= 0x4000000L;
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*      */     public Builder id(String value) {
/* 8785 */       this.id_id = Id.of(value);
/* 8786 */       return this;
/*      */     }
/*      */     
/*      */     public Builder id(long value) {
/* 8790 */       this.id_id = Id.of(value);
/* 8791 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("id")
/*      */     public Builder id(Id value) {
/* 8796 */       this.id_id = value;
/* 8797 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("name")
/*      */     public final Builder name(String name) {
/* 8807 */       this.name = Objects.<String>requireNonNull(name, "name");
/* 8808 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 8809 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder icon(String icon) {
/* 8818 */       this.icon = Objects.<String>requireNonNull(icon, "icon");
/* 8819 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("icon")
/*      */     public final Builder icon(Optional<String> icon) {
/* 8829 */       this.icon = icon.orElse(null);
/* 8830 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder splash(String splash) {
/* 8839 */       this.splash = Objects.<String>requireNonNull(splash, "splash");
/* 8840 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("splash")
/*      */     public final Builder splash(Optional<String> splash) {
/* 8850 */       this.splash = splash.orElse(null);
/* 8851 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder discoverySplash(String discoverySplash) {
/* 8860 */       this.discoverySplash = Objects.<String>requireNonNull(discoverySplash, "discoverySplash");
/* 8861 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("discovery_splash")
/*      */     public final Builder discoverySplash(Optional<String> discoverySplash) {
/* 8871 */       this.discoverySplash = discoverySplash.orElse(null);
/* 8872 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("owner")
/*      */     public Builder owner(Possible<Boolean> value) {
/* 8877 */       this.owner_possible = value;
/* 8878 */       return this;
/*      */     }
/*      */     
/*      */     public Builder owner(Boolean value) {
/* 8882 */       this.owner_possible = Possible.of(value);
/* 8883 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("permissions")
/*      */     public Builder permissions(Possible<Long> value) {
/* 8888 */       this.permissions_possible = value;
/* 8889 */       return this;
/*      */     }
/*      */     
/*      */     public Builder permissions(Long value) {
/* 8893 */       this.permissions_possible = Possible.of(value);
/* 8894 */       return this;
/*      */     }
/*      */     
/*      */     public Builder afkChannelId(String value) {
/* 8898 */       this.afkChannelId_optional = Optional.of(Id.of(value));
/* 8899 */       return this;
/*      */     }
/*      */     
/*      */     public Builder afkChannelId(long value) {
/* 8903 */       this.afkChannelId_optional = Optional.of(Id.of(value));
/* 8904 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("afk_channel_id")
/*      */     public Builder afkChannelId(Optional<Id> value) {
/* 8909 */       this.afkChannelId_optional = value;
/* 8910 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("embed_enabled")
/*      */     public Builder embedEnabled(Possible<Boolean> value) {
/* 8915 */       this.embedEnabled_possible = value;
/* 8916 */       return this;
/*      */     }
/*      */     
/*      */     public Builder embedEnabled(Boolean value) {
/* 8920 */       this.embedEnabled_possible = Possible.of(value);
/* 8921 */       return this;
/*      */     }
/*      */     
/*      */     public Builder embedChannelId(String value) {
/* 8925 */       this.embedChannelId_possible = Possible.of(Optional.of(Id.of(value)));
/* 8926 */       return this;
/*      */     }
/*      */     
/*      */     public Builder embedChannelId(long value) {
/* 8930 */       this.embedChannelId_possible = Possible.of(Optional.of(Id.of(value)));
/* 8931 */       return this;
/*      */     }
/*      */     
/*      */     public Builder embedChannelId(Id value) {
/* 8935 */       this.embedChannelId_possible = Possible.of(Optional.of(value));
/* 8936 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("embed_channel_id")
/*      */     public Builder embedChannelId(Possible<Optional<Id>> value) {
/* 8941 */       this.embedChannelId_possible = value;
/* 8942 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addFeature(String element) {
/* 8951 */       this.features.add(Objects.<String>requireNonNull(element, "features element"));
/* 8952 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addFeatures(String... elements) {
/* 8961 */       for (String element : elements) {
/* 8962 */         this.features.add(Objects.<String>requireNonNull(element, "features element"));
/*      */       }
/* 8964 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("features")
/*      */     public final Builder features(Iterable<String> elements) {
/* 8975 */       this.features.clear();
/* 8976 */       return addAllFeatures(elements);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addAllFeatures(Iterable<String> elements) {
/* 8985 */       for (String element : elements) {
/* 8986 */         this.features.add(Objects.<String>requireNonNull(element, "features element"));
/*      */       }
/* 8988 */       return this;
/*      */     }
/*      */     
/*      */     public Builder applicationId(String value) {
/* 8992 */       this.applicationId_optional = Optional.of(Id.of(value));
/* 8993 */       return this;
/*      */     }
/*      */     
/*      */     public Builder applicationId(long value) {
/* 8997 */       this.applicationId_optional = Optional.of(Id.of(value));
/* 8998 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("application_id")
/*      */     public Builder applicationId(Optional<Id> value) {
/* 9003 */       this.applicationId_optional = value;
/* 9004 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("widget_enabled")
/*      */     public Builder widgetEnabled(Possible<Boolean> value) {
/* 9009 */       this.widgetEnabled_possible = value;
/* 9010 */       return this;
/*      */     }
/*      */     
/*      */     public Builder widgetEnabled(Boolean value) {
/* 9014 */       this.widgetEnabled_possible = Possible.of(value);
/* 9015 */       return this;
/*      */     }
/*      */     
/*      */     public Builder widgetChannelId(String value) {
/* 9019 */       this.widgetChannelId_possible = Possible.of(Optional.of(Id.of(value)));
/* 9020 */       return this;
/*      */     }
/*      */     
/*      */     public Builder widgetChannelId(long value) {
/* 9024 */       this.widgetChannelId_possible = Possible.of(Optional.of(Id.of(value)));
/* 9025 */       return this;
/*      */     }
/*      */     
/*      */     public Builder widgetChannelId(Id value) {
/* 9029 */       this.widgetChannelId_possible = Possible.of(Optional.of(value));
/* 9030 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("widget_channel_id")
/*      */     public Builder widgetChannelId(Possible<Optional<Id>> value) {
/* 9035 */       this.widgetChannelId_possible = value;
/* 9036 */       return this;
/*      */     }
/*      */     
/*      */     public Builder systemChannelId(String value) {
/* 9040 */       this.systemChannelId_optional = Optional.of(Id.of(value));
/* 9041 */       return this;
/*      */     }
/*      */     
/*      */     public Builder systemChannelId(long value) {
/* 9045 */       this.systemChannelId_optional = Optional.of(Id.of(value));
/* 9046 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("system_channel_id")
/*      */     public Builder systemChannelId(Optional<Id> value) {
/* 9051 */       this.systemChannelId_optional = value;
/* 9052 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder systemChannelFlags(int systemChannelFlags) {
/* 9061 */       this.systemChannelFlags = Integer.valueOf(systemChannelFlags);
/* 9062 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("system_channel_flags")
/*      */     public final Builder systemChannelFlags(OptionalInt systemChannelFlags) {
/* 9072 */       this.systemChannelFlags = systemChannelFlags.isPresent() ? Integer.valueOf(systemChannelFlags.getAsInt()) : null;
/* 9073 */       return this;
/*      */     }
/*      */     
/*      */     public Builder rulesChannelId(String value) {
/* 9077 */       this.rulesChannelId_optional = Optional.of(Id.of(value));
/* 9078 */       return this;
/*      */     }
/*      */     
/*      */     public Builder rulesChannelId(long value) {
/* 9082 */       this.rulesChannelId_optional = Optional.of(Id.of(value));
/* 9083 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("rules_channel_id")
/*      */     public Builder rulesChannelId(Optional<Id> value) {
/* 9088 */       this.rulesChannelId_optional = value;
/* 9089 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("max_presences")
/*      */     public Builder maxPresences(Possible<Optional<Integer>> value) {
/* 9094 */       this.maxPresences_possible = value;
/* 9095 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder maxPresences(@Nullable Integer value) {
/* 9100 */       this.maxPresences_possible = Possible.of(Optional.ofNullable(value));
/* 9101 */       return this;
/*      */     }
/*      */     
/*      */     public Builder maxPresencesOrNull(@Nullable Integer value) {
/* 9105 */       this.maxPresences_possible = Possible.of(Optional.ofNullable(value));
/* 9106 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("max_members")
/*      */     public Builder maxMembers(Possible<Integer> value) {
/* 9111 */       this.maxMembers_possible = value;
/* 9112 */       return this;
/*      */     }
/*      */     
/*      */     public Builder maxMembers(Integer value) {
/* 9116 */       this.maxMembers_possible = Possible.of(value);
/* 9117 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder vanityUrlCode(String vanityUrlCode) {
/* 9126 */       this.vanityUrlCode = Objects.<String>requireNonNull(vanityUrlCode, "vanityUrlCode");
/* 9127 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("vanity_url_code")
/*      */     public final Builder vanityUrlCode(Optional<String> vanityUrlCode) {
/* 9137 */       this.vanityUrlCode = vanityUrlCode.orElse(null);
/* 9138 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder description(String description) {
/* 9147 */       this.description = Objects.<String>requireNonNull(description, "description");
/* 9148 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("description")
/*      */     public final Builder description(Optional<String> description) {
/* 9158 */       this.description = description.orElse(null);
/* 9159 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder banner(String banner) {
/* 9168 */       this.banner = Objects.<String>requireNonNull(banner, "banner");
/* 9169 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("banner")
/*      */     public final Builder banner(Optional<String> banner) {
/* 9179 */       this.banner = banner.orElse(null);
/* 9180 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("premium_subscription_count")
/*      */     public Builder premiumSubscriptionCount(Possible<Integer> value) {
/* 9185 */       this.premiumSubscriptionCount_possible = value;
/* 9186 */       return this;
/*      */     }
/*      */     
/*      */     public Builder premiumSubscriptionCount(Integer value) {
/* 9190 */       this.premiumSubscriptionCount_possible = Possible.of(value);
/* 9191 */       return this;
/*      */     }
/*      */     
/*      */     public Builder publicUpdatesChannelId(String value) {
/* 9195 */       this.publicUpdatesChannelId_optional = Optional.of(Id.of(value));
/* 9196 */       return this;
/*      */     }
/*      */     
/*      */     public Builder publicUpdatesChannelId(long value) {
/* 9200 */       this.publicUpdatesChannelId_optional = Optional.of(Id.of(value));
/* 9201 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("public_updates_channel_id")
/*      */     public Builder publicUpdatesChannelId(Optional<Id> value) {
/* 9206 */       this.publicUpdatesChannelId_optional = value;
/* 9207 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("max_video_channel_users")
/*      */     public Builder maxVideoChannelUsers(Possible<Integer> value) {
/* 9212 */       this.maxVideoChannelUsers_possible = value;
/* 9213 */       return this;
/*      */     }
/*      */     
/*      */     public Builder maxVideoChannelUsers(Integer value) {
/* 9217 */       this.maxVideoChannelUsers_possible = Possible.of(value);
/* 9218 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("approximate_member_count")
/*      */     public Builder approximateMemberCount(Possible<Integer> value) {
/* 9223 */       this.approximateMemberCount_possible = value;
/* 9224 */       return this;
/*      */     }
/*      */     
/*      */     public Builder approximateMemberCount(Integer value) {
/* 9228 */       this.approximateMemberCount_possible = Possible.of(value);
/* 9229 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("approximate_presence_count")
/*      */     public Builder approximatePresenceCount(Possible<Integer> value) {
/* 9234 */       this.approximatePresenceCount_possible = value;
/* 9235 */       return this;
/*      */     }
/*      */     
/*      */     public Builder approximatePresenceCount(Integer value) {
/* 9239 */       this.approximatePresenceCount_possible = Possible.of(value);
/* 9240 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("welcome_screen")
/*      */     public Builder welcomeScreen(Possible<WelcomeScreenData> value) {
/* 9245 */       this.welcomeScreen_possible = value;
/* 9246 */       return this;
/*      */     }
/*      */     
/*      */     public Builder welcomeScreen(WelcomeScreenData value) {
/* 9250 */       this.welcomeScreen_possible = Possible.of(value);
/* 9251 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("nsfw")
/*      */     public Builder nsfw(Possible<Boolean> value) {
/* 9256 */       this.nsfw_possible = value;
/* 9257 */       return this;
/*      */     }
/*      */     
/*      */     public Builder nsfw(Boolean value) {
/* 9261 */       this.nsfw_possible = Possible.of(value);
/* 9262 */       return this;
/*      */     }
/*      */     
/*      */     public Builder safetyAlertsChannelId(String value) {
/* 9266 */       this.safetyAlertsChannelId_optional = Optional.of(Id.of(value));
/* 9267 */       return this;
/*      */     }
/*      */     
/*      */     public Builder safetyAlertsChannelId(long value) {
/* 9271 */       this.safetyAlertsChannelId_optional = Optional.of(Id.of(value));
/* 9272 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("safety_alerts_channel_id")
/*      */     public Builder safetyAlertsChannelId(Optional<Id> value) {
/* 9277 */       this.safetyAlertsChannelId_optional = value;
/* 9278 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("verification_level")
/*      */     public final Builder verificationLevel(int verificationLevel) {
/* 9288 */       this.verificationLevel = verificationLevel;
/* 9289 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 9290 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("nsfw_level")
/*      */     public final Builder nsfwLevel(int nsfwLevel) {
/* 9300 */       this.nsfwLevel = nsfwLevel;
/* 9301 */       this.initBits &= 0xFFFFFFFFFFFFFFFBL;
/* 9302 */       return this;
/*      */     }
/*      */     
/*      */     public Builder ownerId(String value) {
/* 9306 */       this.ownerId_id = Id.of(value);
/* 9307 */       return this;
/*      */     }
/*      */     
/*      */     public Builder ownerId(long value) {
/* 9311 */       this.ownerId_id = Id.of(value);
/* 9312 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("owner_id")
/*      */     public Builder ownerId(Id value) {
/* 9317 */       this.ownerId_id = value;
/* 9318 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("region")
/*      */     public Builder region(Possible<Optional<String>> value) {
/* 9323 */       this.region_possible = value;
/* 9324 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder region(@Nullable String value) {
/* 9329 */       this.region_possible = Possible.of(Optional.ofNullable(value));
/* 9330 */       return this;
/*      */     }
/*      */     
/*      */     public Builder regionOrNull(@Nullable String value) {
/* 9334 */       this.region_possible = Possible.of(Optional.ofNullable(value));
/* 9335 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("afk_timeout")
/*      */     public final Builder afkTimeout(int afkTimeout) {
/* 9345 */       this.afkTimeout = afkTimeout;
/* 9346 */       this.initBits &= 0xFFFFFFFFFFFFFFF7L;
/* 9347 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("default_message_notifications")
/*      */     public final Builder defaultMessageNotifications(int defaultMessageNotifications) {
/* 9357 */       this.defaultMessageNotifications = defaultMessageNotifications;
/* 9358 */       this.initBits &= 0xFFFFFFFFFFFFFFEFL;
/* 9359 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("explicit_content_filter")
/*      */     public final Builder explicitContentFilter(int explicitContentFilter) {
/* 9369 */       this.explicitContentFilter = explicitContentFilter;
/* 9370 */       this.initBits &= 0xFFFFFFFFFFFFFFDFL;
/* 9371 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("mfa_level")
/*      */     public final Builder mfaLevel(int mfaLevel) {
/* 9381 */       this.mfaLevel = mfaLevel;
/* 9382 */       this.initBits &= 0xFFFFFFFFFFFFFFBFL;
/* 9383 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("premium_tier")
/*      */     public final Builder premiumTier(int premiumTier) {
/* 9393 */       this.premiumTier = premiumTier;
/* 9394 */       this.initBits &= 0xFFFFFFFFFFFFFF7FL;
/* 9395 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("preferred_locale")
/*      */     public final Builder preferredLocale(String preferredLocale) {
/* 9405 */       this.preferredLocale = Objects.<String>requireNonNull(preferredLocale, "preferredLocale");
/* 9406 */       this.initBits &= 0xFFFFFFFFFFFFFEFFL;
/* 9407 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("joined_at")
/*      */     public final Builder joinedAt(String joinedAt) {
/* 9417 */       this.joinedAt = Objects.<String>requireNonNull(joinedAt, "joinedAt");
/* 9418 */       this.initBits &= 0xFFFFFFFFFFFFFDFFL;
/* 9419 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("large")
/*      */     public final Builder large(boolean large) {
/* 9429 */       this.large = large;
/* 9430 */       this.initBits &= 0xFFFFFFFFFFFFFBFFL;
/* 9431 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("unavailable")
/*      */     public Builder unavailable(Possible<Boolean> value) {
/* 9436 */       this.unavailable_possible = value;
/* 9437 */       return this;
/*      */     }
/*      */     
/*      */     public Builder unavailable(Boolean value) {
/* 9441 */       this.unavailable_possible = Possible.of(value);
/* 9442 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("member_count")
/*      */     public final Builder memberCount(int memberCount) {
/* 9452 */       this.memberCount = memberCount;
/* 9453 */       this.initBits &= 0xFFFFFFFFFFFFF7FFL;
/* 9454 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addRole(RoleData element) {
/* 9463 */       this.roles.add(Objects.<RoleData>requireNonNull(element, "roles element"));
/* 9464 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addRoles(RoleData... elements) {
/* 9473 */       for (RoleData element : elements) {
/* 9474 */         this.roles.add(Objects.<RoleData>requireNonNull(element, "roles element"));
/*      */       }
/* 9476 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("roles")
/*      */     public final Builder roles(Iterable<? extends RoleData> elements) {
/* 9487 */       this.roles.clear();
/* 9488 */       return addAllRoles(elements);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addAllRoles(Iterable<? extends RoleData> elements) {
/* 9497 */       for (RoleData element : elements) {
/* 9498 */         this.roles.add(Objects.<RoleData>requireNonNull(element, "roles element"));
/*      */       }
/* 9500 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addEmoji(EmojiData element) {
/* 9509 */       this.emojis.add(Objects.<EmojiData>requireNonNull(element, "emojis element"));
/* 9510 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addEmojis(EmojiData... elements) {
/* 9519 */       for (EmojiData element : elements) {
/* 9520 */         this.emojis.add(Objects.<EmojiData>requireNonNull(element, "emojis element"));
/*      */       }
/* 9522 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("emojis")
/*      */     public final Builder emojis(Iterable<? extends EmojiData> elements) {
/* 9533 */       this.emojis.clear();
/* 9534 */       return addAllEmojis(elements);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addAllEmojis(Iterable<? extends EmojiData> elements) {
/* 9543 */       for (EmojiData element : elements) {
/* 9544 */         this.emojis.add(Objects.<EmojiData>requireNonNull(element, "emojis element"));
/*      */       }
/* 9546 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addSticker(StickerData element) {
/* 9550 */       stickers_getOrCreate().add(element);
/* 9551 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addAllStickers(List<StickerData> elements) {
/* 9555 */       stickers_getOrCreate().addAll(elements);
/* 9556 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("stickers")
/*      */     public Builder stickers(Possible<List<StickerData>> elements) {
/* 9561 */       this.stickers_list = null;
/* 9562 */       elements.toOptional().ifPresent(e -> stickers_getOrCreate().addAll(e));
/* 9563 */       return this;
/*      */     }
/*      */     
/*      */     public Builder stickers(List<StickerData> elements) {
/* 9567 */       this.stickers_list = new ArrayList<>(elements);
/* 9568 */       return this;
/*      */     }
/*      */     
/*      */     public Builder stickers(Iterable<StickerData> elements) {
/* 9572 */       this.stickers_list = (List<StickerData>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 9573 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addVoiceState(VoiceStateData element) {
/* 9582 */       this.voiceStates.add(Objects.<VoiceStateData>requireNonNull(element, "voiceStates element"));
/* 9583 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addVoiceStates(VoiceStateData... elements) {
/* 9592 */       for (VoiceStateData element : elements) {
/* 9593 */         this.voiceStates.add(Objects.<VoiceStateData>requireNonNull(element, "voiceStates element"));
/*      */       }
/* 9595 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("voice_states")
/*      */     public final Builder voiceStates(Iterable<? extends VoiceStateData> elements) {
/* 9606 */       this.voiceStates.clear();
/* 9607 */       return addAllVoiceStates(elements);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addAllVoiceStates(Iterable<? extends VoiceStateData> elements) {
/* 9616 */       for (VoiceStateData element : elements) {
/* 9617 */         this.voiceStates.add(Objects.<VoiceStateData>requireNonNull(element, "voiceStates element"));
/*      */       }
/* 9619 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addMember(MemberData element) {
/* 9628 */       this.members.add(Objects.<MemberData>requireNonNull(element, "members element"));
/* 9629 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addMembers(MemberData... elements) {
/* 9638 */       for (MemberData element : elements) {
/* 9639 */         this.members.add(Objects.<MemberData>requireNonNull(element, "members element"));
/*      */       }
/* 9641 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("members")
/*      */     public final Builder members(Iterable<? extends MemberData> elements) {
/* 9652 */       this.members.clear();
/* 9653 */       return addAllMembers(elements);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addAllMembers(Iterable<? extends MemberData> elements) {
/* 9662 */       for (MemberData element : elements) {
/* 9663 */         this.members.add(Objects.<MemberData>requireNonNull(element, "members element"));
/*      */       }
/* 9665 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addChannel(ChannelData element) {
/* 9674 */       this.channels.add(Objects.<ChannelData>requireNonNull(element, "channels element"));
/* 9675 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addChannels(ChannelData... elements) {
/* 9684 */       for (ChannelData element : elements) {
/* 9685 */         this.channels.add(Objects.<ChannelData>requireNonNull(element, "channels element"));
/*      */       }
/* 9687 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("channels")
/*      */     public final Builder channels(Iterable<? extends ChannelData> elements) {
/* 9698 */       this.channels.clear();
/* 9699 */       return addAllChannels(elements);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addAllChannels(Iterable<? extends ChannelData> elements) {
/* 9708 */       for (ChannelData element : elements) {
/* 9709 */         this.channels.add(Objects.<ChannelData>requireNonNull(element, "channels element"));
/*      */       }
/* 9711 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addPresence(PresenceData element) {
/* 9720 */       this.presences.add(Objects.<PresenceData>requireNonNull(element, "presences element"));
/* 9721 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addPresences(PresenceData... elements) {
/* 9730 */       for (PresenceData element : elements) {
/* 9731 */         this.presences.add(Objects.<PresenceData>requireNonNull(element, "presences element"));
/*      */       }
/* 9733 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("presences")
/*      */     public final Builder presences(Iterable<? extends PresenceData> elements) {
/* 9744 */       this.presences.clear();
/* 9745 */       return addAllPresences(elements);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addAllPresences(Iterable<? extends PresenceData> elements) {
/* 9754 */       for (PresenceData element : elements) {
/* 9755 */         this.presences.add(Objects.<PresenceData>requireNonNull(element, "presences element"));
/*      */       }
/* 9757 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ImmutableGuildCreateData build() {
/* 9766 */       if (this.initBits != 0L) {
/* 9767 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*      */       }
/* 9769 */       return new ImmutableGuildCreateData(null, 
/*      */           
/* 9771 */           id_build(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 9776 */           owner_build(), 
/* 9777 */           permissions_build(), 
/* 9778 */           afkChannelId_build(), 
/* 9779 */           embedEnabled_build(), 
/* 9780 */           embedChannelId_build(), ImmutableGuildCreateData
/* 9781 */           .createUnmodifiableList(true, (List)this.features), 
/* 9782 */           applicationId_build(), 
/* 9783 */           widgetEnabled_build(), 
/* 9784 */           widgetChannelId_build(), 
/* 9785 */           systemChannelId_build(), this.systemChannelFlags, 
/*      */           
/* 9787 */           rulesChannelId_build(), 
/* 9788 */           maxPresences_build(), 
/* 9789 */           maxMembers_build(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */           
/* 9793 */           premiumSubscriptionCount_build(), 
/* 9794 */           publicUpdatesChannelId_build(), 
/* 9795 */           maxVideoChannelUsers_build(), 
/* 9796 */           approximateMemberCount_build(), 
/* 9797 */           approximatePresenceCount_build(), 
/* 9798 */           welcomeScreen_build(), 
/* 9799 */           nsfw_build(), 
/* 9800 */           safetyAlertsChannelId_build(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */           
/* 9803 */           ownerId_build(), 
/* 9804 */           region_build(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 9813 */           unavailable_build(), this.memberCount, ImmutableGuildCreateData
/*      */           
/* 9815 */           .createUnmodifiableList(true, (List)this.roles), ImmutableGuildCreateData
/* 9816 */           .createUnmodifiableList(true, (List)this.emojis), 
/* 9817 */           stickers_build(), ImmutableGuildCreateData
/* 9818 */           .createUnmodifiableList(true, (List)this.voiceStates), ImmutableGuildCreateData
/* 9819 */           .createUnmodifiableList(true, (List)this.members), ImmutableGuildCreateData
/* 9820 */           .createUnmodifiableList(true, (List)this.channels), ImmutableGuildCreateData
/* 9821 */           .createUnmodifiableList(true, (List)this.presences));
/*      */     }
/*      */     
/*      */     private String formatRequiredAttributesMessage() {
/* 9825 */       List<String> attributes = new ArrayList<>();
/* 9826 */       if ((this.initBits & 0x1L) != 0L) attributes.add("name"); 
/* 9827 */       if ((this.initBits & 0x2L) != 0L) attributes.add("verificationLevel"); 
/* 9828 */       if ((this.initBits & 0x4L) != 0L) attributes.add("nsfwLevel"); 
/* 9829 */       if ((this.initBits & 0x8L) != 0L) attributes.add("afkTimeout"); 
/* 9830 */       if ((this.initBits & 0x10L) != 0L) attributes.add("defaultMessageNotifications"); 
/* 9831 */       if ((this.initBits & 0x20L) != 0L) attributes.add("explicitContentFilter"); 
/* 9832 */       if ((this.initBits & 0x40L) != 0L) attributes.add("mfaLevel"); 
/* 9833 */       if ((this.initBits & 0x80L) != 0L) attributes.add("premiumTier"); 
/* 9834 */       if ((this.initBits & 0x100L) != 0L) attributes.add("preferredLocale"); 
/* 9835 */       if ((this.initBits & 0x200L) != 0L) attributes.add("joinedAt"); 
/* 9836 */       if ((this.initBits & 0x400L) != 0L) attributes.add("large"); 
/* 9837 */       if ((this.initBits & 0x800L) != 0L) attributes.add("memberCount"); 
/* 9838 */       return "Cannot build GuildCreateData, some of required attributes are not set " + attributes;
/*      */     }
/*      */     
/*      */     private Id id_build() {
/* 9842 */       return this.id_id;
/*      */     }
/*      */     
/*      */     private Possible<Boolean> owner_build() {
/* 9846 */       return this.owner_possible;
/*      */     }
/*      */     
/*      */     private Possible<Long> permissions_build() {
/* 9850 */       return this.permissions_possible;
/*      */     }
/*      */     
/*      */     private Optional<Id> afkChannelId_build() {
/* 9854 */       return this.afkChannelId_optional;
/*      */     }
/*      */     
/*      */     private Possible<Boolean> embedEnabled_build() {
/* 9858 */       return this.embedEnabled_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<Id>> embedChannelId_build() {
/* 9862 */       return this.embedChannelId_possible;
/*      */     }
/*      */     
/*      */     private Optional<Id> applicationId_build() {
/* 9866 */       return this.applicationId_optional;
/*      */     }
/*      */     
/*      */     private Possible<Boolean> widgetEnabled_build() {
/* 9870 */       return this.widgetEnabled_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<Id>> widgetChannelId_build() {
/* 9874 */       return this.widgetChannelId_possible;
/*      */     }
/*      */     
/*      */     private Optional<Id> systemChannelId_build() {
/* 9878 */       return this.systemChannelId_optional;
/*      */     }
/*      */     
/*      */     private Optional<Id> rulesChannelId_build() {
/* 9882 */       return this.rulesChannelId_optional;
/*      */     }
/*      */     
/*      */     private Possible<Optional<Integer>> maxPresences_build() {
/* 9886 */       return this.maxPresences_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> maxMembers_build() {
/* 9890 */       return this.maxMembers_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> premiumSubscriptionCount_build() {
/* 9894 */       return this.premiumSubscriptionCount_possible;
/*      */     }
/*      */     
/*      */     private Optional<Id> publicUpdatesChannelId_build() {
/* 9898 */       return this.publicUpdatesChannelId_optional;
/*      */     }
/*      */     
/*      */     private Possible<Integer> maxVideoChannelUsers_build() {
/* 9902 */       return this.maxVideoChannelUsers_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> approximateMemberCount_build() {
/* 9906 */       return this.approximateMemberCount_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> approximatePresenceCount_build() {
/* 9910 */       return this.approximatePresenceCount_possible;
/*      */     }
/*      */     
/*      */     private Possible<WelcomeScreenData> welcomeScreen_build() {
/* 9914 */       return this.welcomeScreen_possible;
/*      */     }
/*      */     
/*      */     private Possible<Boolean> nsfw_build() {
/* 9918 */       return this.nsfw_possible;
/*      */     }
/*      */     
/*      */     private Optional<Id> safetyAlertsChannelId_build() {
/* 9922 */       return this.safetyAlertsChannelId_optional;
/*      */     }
/*      */     
/*      */     private Id ownerId_build() {
/* 9926 */       return this.ownerId_id;
/*      */     }
/*      */     
/*      */     private Possible<Optional<String>> region_build() {
/* 9930 */       return this.region_possible;
/*      */     }
/*      */     
/*      */     private Possible<Boolean> unavailable_build() {
/* 9934 */       return this.unavailable_possible;
/*      */     }
/*      */     
/*      */     private Possible<List<StickerData>> stickers_build() {
/* 9938 */       return (this.stickers_list == null) ? Possible.absent() : 
/* 9939 */         Possible.of(this.stickers_list);
/*      */     }
/*      */     
/*      */     private List<StickerData> stickers_getOrCreate() {
/* 9943 */       if (this.stickers_list == null) {
/* 9944 */         this.stickers_list = new ArrayList<>();
/*      */       }
/* 9946 */       return this.stickers_list;
/*      */     }
/*      */     private Builder() {} }
/*      */   
/*      */   private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
/*      */     ArrayList<T> list;
/* 9952 */     if (iterable instanceof Collection) {
/* 9953 */       int size = ((Collection)iterable).size();
/* 9954 */       if (size == 0) return Collections.emptyList(); 
/* 9955 */       list = new ArrayList<>();
/*      */     } else {
/* 9957 */       list = new ArrayList<>();
/*      */     } 
/* 9959 */     for (T element : iterable) {
/* 9960 */       if (skipNulls && element == null)
/* 9961 */         continue;  if (checkNulls) Objects.requireNonNull(element, "element"); 
/* 9962 */       list.add(element);
/*      */     } 
/* 9964 */     return list;
/*      */   }
/*      */   
/*      */   private static <T> List<T> createUnmodifiableList(boolean clone, List<T> list) {
/* 9968 */     switch (list.size()) { case 0:
/* 9969 */         return Collections.emptyList();
/* 9970 */       case 1: return Collections.singletonList(list.get(0)); }
/*      */     
/* 9972 */     if (clone) {
/* 9973 */       return Collections.unmodifiableList(new ArrayList<>(list));
/*      */     }
/* 9975 */     if (list instanceof ArrayList) {
/* 9976 */       ((ArrayList)list).trimToSize();
/*      */     }
/* 9978 */     return Collections.unmodifiableList(list);
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableGuildCreateData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */