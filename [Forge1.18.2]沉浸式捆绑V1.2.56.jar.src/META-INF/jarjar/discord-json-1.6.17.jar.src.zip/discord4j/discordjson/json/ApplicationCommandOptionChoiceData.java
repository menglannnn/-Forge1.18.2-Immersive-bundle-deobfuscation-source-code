/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import java.util.Map;
/*    */ import java.util.Optional;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ @JsonSerialize(as = ImmutableApplicationCommandOptionChoiceData.class)
/*    */ @JsonDeserialize(as = ImmutableApplicationCommandOptionChoiceData.class)
/*    */ @Immutable
/*    */ public interface ApplicationCommandOptionChoiceData
/*    */ {
/*    */   static ImmutableApplicationCommandOptionChoiceData.Builder builder() {
/* 18 */     return ImmutableApplicationCommandOptionChoiceData.builder();
/*    */   }
/*    */   
/*    */   String name();
/*    */   
/*    */   @JsonProperty("name_localizations")
/*    */   Possible<Optional<Map<String, String>>> nameLocalizations();
/*    */   
/*    */   Object value();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ApplicationCommandOptionChoiceData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */