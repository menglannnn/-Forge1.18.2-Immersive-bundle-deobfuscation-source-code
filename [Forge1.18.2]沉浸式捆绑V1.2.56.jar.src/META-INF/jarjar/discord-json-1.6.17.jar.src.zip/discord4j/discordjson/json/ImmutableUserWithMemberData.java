/*      */ package discord4j.discordjson.json;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*      */ import com.fasterxml.jackson.annotation.JsonCreator;
/*      */ import com.fasterxml.jackson.annotation.JsonProperty;
/*      */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*      */ import discord4j.discordjson.Id;
/*      */ import discord4j.discordjson.possible.Possible;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import java.util.Optional;
/*      */ import org.immutables.value.Generated;
/*      */ import reactor.util.annotation.Nullable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Generated(from = "UserWithMemberData", generator = "Immutables")
/*      */ public final class ImmutableUserWithMemberData
/*      */   implements UserWithMemberData
/*      */ {
/*      */   private final long id_value;
/*      */   private final String globalName;
/*      */   private final String username;
/*      */   private final String discriminator;
/*      */   private final String avatar;
/*      */   private final String banner_value;
/*      */   private final boolean banner_absent;
/*      */   private final Integer accentColor_value;
/*      */   private final boolean accentColor_absent;
/*      */   private final Boolean bot_value;
/*      */   private final boolean bot_absent;
/*      */   private final Boolean system_value;
/*      */   private final boolean system_absent;
/*      */   private final Boolean mfaEnabled_value;
/*      */   private final boolean mfaEnabled_absent;
/*      */   private final String locale_value;
/*      */   private final boolean locale_absent;
/*      */   private final Boolean verified_value;
/*      */   private final boolean verified_absent;
/*      */   private final String email_value;
/*      */   private final boolean email_absent;
/*      */   private final Long flags_value;
/*      */   private final boolean flags_absent;
/*      */   private final Integer premiumType_value;
/*      */   private final boolean premiumType_absent;
/*      */   private final Long publicFlags_value;
/*      */   private final boolean publicFlags_absent;
/*      */   private final PartialMemberData member_value;
/*      */   private final boolean member_absent;
/*      */   private static final byte STAGE_INITIALIZING = -1;
/*      */   private static final byte STAGE_UNINITIALIZED = 0;
/*      */   private static final byte STAGE_INITIALIZED = 1;
/*      */   
/*      */   private ImmutableUserWithMemberData(Id id, Optional<String> globalName, String username, String discriminator, Optional<String> avatar, Possible<Optional<String>> banner, Possible<Optional<Integer>> accentColor, Possible<Boolean> bot, Possible<Boolean> system, Possible<Boolean> mfaEnabled, Possible<String> locale, Possible<Boolean> verified, Possible<Optional<String>> email, Possible<Long> flags, Possible<Integer> premiumType, Possible<Long> publicFlags, Possible<PartialMemberData> member) {
/*   76 */     Id id$impl = id;
/*   77 */     this.globalName = globalName.orElse(null);
/*   78 */     this.username = Objects.<String>requireNonNull(username, "username");
/*   79 */     this.discriminator = Objects.<String>requireNonNull(discriminator, "discriminator");
/*   80 */     this.avatar = avatar.orElse(null);
/*   81 */     Possible<Optional<String>> banner$impl = banner;
/*   82 */     Possible<Optional<Integer>> accentColor$impl = accentColor;
/*   83 */     Possible<Boolean> bot$impl = bot;
/*   84 */     Possible<Boolean> system$impl = system;
/*   85 */     Possible<Boolean> mfaEnabled$impl = mfaEnabled;
/*   86 */     Possible<String> locale$impl = locale;
/*   87 */     Possible<Boolean> verified$impl = verified;
/*   88 */     Possible<Optional<String>> email$impl = email;
/*   89 */     Possible<Long> flags$impl = flags;
/*   90 */     Possible<Integer> premiumType$impl = premiumType;
/*   91 */     Possible<Long> publicFlags$impl = publicFlags;
/*   92 */     Possible<PartialMemberData> member$impl = member;
/*   93 */     this.id_value = id$impl.asLong();
/*   94 */     this.banner_value = Possible.flatOpt(banner$impl).orElse(null);
/*   95 */     this.banner_absent = banner$impl.isAbsent();
/*   96 */     this.accentColor_value = Possible.flatOpt(accentColor$impl).orElse(null);
/*   97 */     this.accentColor_absent = accentColor$impl.isAbsent();
/*   98 */     this.bot_value = bot$impl.toOptional().orElse(null);
/*   99 */     this.bot_absent = bot$impl.isAbsent();
/*  100 */     this.system_value = system$impl.toOptional().orElse(null);
/*  101 */     this.system_absent = system$impl.isAbsent();
/*  102 */     this.mfaEnabled_value = mfaEnabled$impl.toOptional().orElse(null);
/*  103 */     this.mfaEnabled_absent = mfaEnabled$impl.isAbsent();
/*  104 */     this.locale_value = locale$impl.toOptional().orElse(null);
/*  105 */     this.locale_absent = locale$impl.isAbsent();
/*  106 */     this.verified_value = verified$impl.toOptional().orElse(null);
/*  107 */     this.verified_absent = verified$impl.isAbsent();
/*  108 */     this.email_value = Possible.flatOpt(email$impl).orElse(null);
/*  109 */     this.email_absent = email$impl.isAbsent();
/*  110 */     this.flags_value = flags$impl.toOptional().orElse(null);
/*  111 */     this.flags_absent = flags$impl.isAbsent();
/*  112 */     this.premiumType_value = premiumType$impl.toOptional().orElse(null);
/*  113 */     this.premiumType_absent = premiumType$impl.isAbsent();
/*  114 */     this.publicFlags_value = publicFlags$impl.toOptional().orElse(null);
/*  115 */     this.publicFlags_absent = publicFlags$impl.isAbsent();
/*  116 */     this.member_value = member$impl.toOptional().orElse(null);
/*  117 */     this.member_absent = member$impl.isAbsent();
/*  118 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ImmutableUserWithMemberData(ImmutableUserWithMemberData original, Id id, String globalName, String username, String discriminator, String avatar, Possible<Optional<String>> banner, Possible<Optional<Integer>> accentColor, Possible<Boolean> bot, Possible<Boolean> system, Possible<Boolean> mfaEnabled, Possible<String> locale, Possible<Boolean> verified, Possible<Optional<String>> email, Possible<Long> flags, Possible<Integer> premiumType, Possible<Long> publicFlags, Possible<PartialMemberData> member) {
/*  140 */     Id id$impl = id;
/*  141 */     this.globalName = globalName;
/*  142 */     this.username = username;
/*  143 */     this.discriminator = discriminator;
/*  144 */     this.avatar = avatar;
/*  145 */     Possible<Optional<String>> banner$impl = banner;
/*  146 */     Possible<Optional<Integer>> accentColor$impl = accentColor;
/*  147 */     Possible<Boolean> bot$impl = bot;
/*  148 */     Possible<Boolean> system$impl = system;
/*  149 */     Possible<Boolean> mfaEnabled$impl = mfaEnabled;
/*  150 */     Possible<String> locale$impl = locale;
/*  151 */     Possible<Boolean> verified$impl = verified;
/*  152 */     Possible<Optional<String>> email$impl = email;
/*  153 */     Possible<Long> flags$impl = flags;
/*  154 */     Possible<Integer> premiumType$impl = premiumType;
/*  155 */     Possible<Long> publicFlags$impl = publicFlags;
/*  156 */     Possible<PartialMemberData> member$impl = member;
/*  157 */     this.id_value = id$impl.asLong();
/*  158 */     this.banner_value = Possible.flatOpt(banner$impl).orElse(null);
/*  159 */     this.banner_absent = banner$impl.isAbsent();
/*  160 */     this.accentColor_value = Possible.flatOpt(accentColor$impl).orElse(null);
/*  161 */     this.accentColor_absent = accentColor$impl.isAbsent();
/*  162 */     this.bot_value = bot$impl.toOptional().orElse(null);
/*  163 */     this.bot_absent = bot$impl.isAbsent();
/*  164 */     this.system_value = system$impl.toOptional().orElse(null);
/*  165 */     this.system_absent = system$impl.isAbsent();
/*  166 */     this.mfaEnabled_value = mfaEnabled$impl.toOptional().orElse(null);
/*  167 */     this.mfaEnabled_absent = mfaEnabled$impl.isAbsent();
/*  168 */     this.locale_value = locale$impl.toOptional().orElse(null);
/*  169 */     this.locale_absent = locale$impl.isAbsent();
/*  170 */     this.verified_value = verified$impl.toOptional().orElse(null);
/*  171 */     this.verified_absent = verified$impl.isAbsent();
/*  172 */     this.email_value = Possible.flatOpt(email$impl).orElse(null);
/*  173 */     this.email_absent = email$impl.isAbsent();
/*  174 */     this.flags_value = flags$impl.toOptional().orElse(null);
/*  175 */     this.flags_absent = flags$impl.isAbsent();
/*  176 */     this.premiumType_value = premiumType$impl.toOptional().orElse(null);
/*  177 */     this.premiumType_absent = premiumType$impl.isAbsent();
/*  178 */     this.publicFlags_value = publicFlags$impl.toOptional().orElse(null);
/*  179 */     this.publicFlags_absent = publicFlags$impl.isAbsent();
/*  180 */     this.member_value = member$impl.toOptional().orElse(null);
/*  181 */     this.member_absent = member$impl.isAbsent();
/*  182 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  188 */   private volatile transient InitShim initShim = new InitShim();
/*      */   
/*      */   @Generated(from = "UserWithMemberData", generator = "Immutables")
/*      */   private final class InitShim {
/*      */     private String formatInitCycleMessage() {
/*  193 */       List<String> attributes = new ArrayList<>();
/*  194 */       return "Cannot build UserWithMemberData, attribute initializers form cycle " + attributes;
/*      */     }
/*      */ 
/*      */     
/*      */     private InitShim() {}
/*      */   }
/*      */ 
/*      */   
/*      */   @JsonProperty("id")
/*      */   public Id id() {
/*  204 */     return Id.of(this.id_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("global_name")
/*      */   public Optional<String> globalName() {
/*  213 */     return Optional.ofNullable(this.globalName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("username")
/*      */   public String username() {
/*  222 */     return this.username;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("discriminator")
/*      */   @Deprecated
/*      */   public String discriminator() {
/*  233 */     return this.discriminator;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("avatar")
/*      */   public Optional<String> avatar() {
/*  242 */     return Optional.ofNullable(this.avatar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("banner")
/*      */   public Possible<Optional<String>> banner() {
/*  251 */     return this.banner_absent ? Possible.absent() : 
/*  252 */       Possible.of(Optional.ofNullable(this.banner_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("accent_color")
/*      */   public Possible<Optional<Integer>> accentColor() {
/*  261 */     return this.accentColor_absent ? Possible.absent() : 
/*  262 */       Possible.of(Optional.ofNullable(this.accentColor_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("bot")
/*      */   public Possible<Boolean> bot() {
/*  271 */     return this.bot_absent ? Possible.absent() : Possible.of(this.bot_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("system")
/*      */   public Possible<Boolean> system() {
/*  280 */     return this.system_absent ? Possible.absent() : Possible.of(this.system_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("mfa_enabled")
/*      */   public Possible<Boolean> mfaEnabled() {
/*  289 */     return this.mfaEnabled_absent ? Possible.absent() : Possible.of(this.mfaEnabled_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("locale")
/*      */   public Possible<String> locale() {
/*  298 */     return this.locale_absent ? Possible.absent() : Possible.of(this.locale_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("verified")
/*      */   public Possible<Boolean> verified() {
/*  307 */     return this.verified_absent ? Possible.absent() : Possible.of(this.verified_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("email")
/*      */   public Possible<Optional<String>> email() {
/*  316 */     return this.email_absent ? Possible.absent() : 
/*  317 */       Possible.of(Optional.ofNullable(this.email_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("flags")
/*      */   public Possible<Long> flags() {
/*  326 */     return this.flags_absent ? Possible.absent() : Possible.of(this.flags_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("premium_type")
/*      */   public Possible<Integer> premiumType() {
/*  335 */     return this.premiumType_absent ? Possible.absent() : Possible.of(this.premiumType_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("public_flags")
/*      */   public Possible<Long> publicFlags() {
/*  344 */     return this.publicFlags_absent ? Possible.absent() : Possible.of(this.publicFlags_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("member")
/*      */   public Possible<PartialMemberData> member() {
/*  353 */     return this.member_absent ? Possible.absent() : Possible.of(this.member_value);
/*      */   }
/*      */   
/*      */   public ImmutableUserWithMemberData withId(long value) {
/*  357 */     Id newValue = Id.of(value);
/*  358 */     return new ImmutableUserWithMemberData(this, newValue, this.globalName, this.username, this.discriminator, this.avatar, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  365 */         banner(), 
/*  366 */         accentColor(), 
/*  367 */         bot(), 
/*  368 */         system(), 
/*  369 */         mfaEnabled(), 
/*  370 */         locale(), 
/*  371 */         verified(), 
/*  372 */         email(), 
/*  373 */         flags(), 
/*  374 */         premiumType(), 
/*  375 */         publicFlags(), 
/*  376 */         member());
/*      */   }
/*      */   
/*      */   public ImmutableUserWithMemberData withId(String value) {
/*  380 */     Id newValue = Id.of(value);
/*  381 */     return new ImmutableUserWithMemberData(this, newValue, this.globalName, this.username, this.discriminator, this.avatar, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  388 */         banner(), 
/*  389 */         accentColor(), 
/*  390 */         bot(), 
/*  391 */         system(), 
/*  392 */         mfaEnabled(), 
/*  393 */         locale(), 
/*  394 */         verified(), 
/*  395 */         email(), 
/*  396 */         flags(), 
/*  397 */         premiumType(), 
/*  398 */         publicFlags(), 
/*  399 */         member());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableUserWithMemberData withGlobalName(String value) {
/*  408 */     String newValue = Objects.<String>requireNonNull(value, "globalName");
/*  409 */     if (Objects.equals(this.globalName, newValue)) return this; 
/*  410 */     return new ImmutableUserWithMemberData(this, 
/*      */         
/*  412 */         id(), newValue, this.username, this.discriminator, this.avatar, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  417 */         banner(), 
/*  418 */         accentColor(), 
/*  419 */         bot(), 
/*  420 */         system(), 
/*  421 */         mfaEnabled(), 
/*  422 */         locale(), 
/*  423 */         verified(), 
/*  424 */         email(), 
/*  425 */         flags(), 
/*  426 */         premiumType(), 
/*  427 */         publicFlags(), 
/*  428 */         member());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableUserWithMemberData withGlobalName(Optional<String> optional) {
/*  438 */     String value = optional.orElse(null);
/*  439 */     if (Objects.equals(this.globalName, value)) return this; 
/*  440 */     return new ImmutableUserWithMemberData(this, 
/*      */         
/*  442 */         id(), value, this.username, this.discriminator, this.avatar, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  447 */         banner(), 
/*  448 */         accentColor(), 
/*  449 */         bot(), 
/*  450 */         system(), 
/*  451 */         mfaEnabled(), 
/*  452 */         locale(), 
/*  453 */         verified(), 
/*  454 */         email(), 
/*  455 */         flags(), 
/*  456 */         premiumType(), 
/*  457 */         publicFlags(), 
/*  458 */         member());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableUserWithMemberData withUsername(String value) {
/*  468 */     String newValue = Objects.<String>requireNonNull(value, "username");
/*  469 */     if (this.username.equals(newValue)) return this; 
/*  470 */     return new ImmutableUserWithMemberData(this, 
/*      */         
/*  472 */         id(), this.globalName, newValue, this.discriminator, this.avatar, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  477 */         banner(), 
/*  478 */         accentColor(), 
/*  479 */         bot(), 
/*  480 */         system(), 
/*  481 */         mfaEnabled(), 
/*  482 */         locale(), 
/*  483 */         verified(), 
/*  484 */         email(), 
/*  485 */         flags(), 
/*  486 */         premiumType(), 
/*  487 */         publicFlags(), 
/*  488 */         member());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public final ImmutableUserWithMemberData withDiscriminator(String value) {
/*  499 */     String newValue = Objects.<String>requireNonNull(value, "discriminator");
/*  500 */     if (this.discriminator.equals(newValue)) return this; 
/*  501 */     return new ImmutableUserWithMemberData(this, 
/*      */         
/*  503 */         id(), this.globalName, this.username, newValue, this.avatar, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  508 */         banner(), 
/*  509 */         accentColor(), 
/*  510 */         bot(), 
/*  511 */         system(), 
/*  512 */         mfaEnabled(), 
/*  513 */         locale(), 
/*  514 */         verified(), 
/*  515 */         email(), 
/*  516 */         flags(), 
/*  517 */         premiumType(), 
/*  518 */         publicFlags(), 
/*  519 */         member());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableUserWithMemberData withAvatar(String value) {
/*  528 */     String newValue = Objects.<String>requireNonNull(value, "avatar");
/*  529 */     if (Objects.equals(this.avatar, newValue)) return this; 
/*  530 */     return new ImmutableUserWithMemberData(this, 
/*      */         
/*  532 */         id(), this.globalName, this.username, this.discriminator, newValue, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  537 */         banner(), 
/*  538 */         accentColor(), 
/*  539 */         bot(), 
/*  540 */         system(), 
/*  541 */         mfaEnabled(), 
/*  542 */         locale(), 
/*  543 */         verified(), 
/*  544 */         email(), 
/*  545 */         flags(), 
/*  546 */         premiumType(), 
/*  547 */         publicFlags(), 
/*  548 */         member());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableUserWithMemberData withAvatar(Optional<String> optional) {
/*  558 */     String value = optional.orElse(null);
/*  559 */     if (Objects.equals(this.avatar, value)) return this; 
/*  560 */     return new ImmutableUserWithMemberData(this, 
/*      */         
/*  562 */         id(), this.globalName, this.username, this.discriminator, value, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  567 */         banner(), 
/*  568 */         accentColor(), 
/*  569 */         bot(), 
/*  570 */         system(), 
/*  571 */         mfaEnabled(), 
/*  572 */         locale(), 
/*  573 */         verified(), 
/*  574 */         email(), 
/*  575 */         flags(), 
/*  576 */         premiumType(), 
/*  577 */         publicFlags(), 
/*  578 */         member());
/*      */   }
/*      */   
/*      */   public ImmutableUserWithMemberData withBanner(Possible<Optional<String>> value) {
/*  582 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/*  583 */     return new ImmutableUserWithMemberData(this, 
/*      */         
/*  585 */         id(), this.globalName, this.username, this.discriminator, this.avatar, newValue, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  591 */         accentColor(), 
/*  592 */         bot(), 
/*  593 */         system(), 
/*  594 */         mfaEnabled(), 
/*  595 */         locale(), 
/*  596 */         verified(), 
/*  597 */         email(), 
/*  598 */         flags(), 
/*  599 */         premiumType(), 
/*  600 */         publicFlags(), 
/*  601 */         member());
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableUserWithMemberData withBanner(@Nullable String value) {
/*  606 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  607 */     return new ImmutableUserWithMemberData(this, 
/*      */         
/*  609 */         id(), this.globalName, this.username, this.discriminator, this.avatar, newValue, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  615 */         accentColor(), 
/*  616 */         bot(), 
/*  617 */         system(), 
/*  618 */         mfaEnabled(), 
/*  619 */         locale(), 
/*  620 */         verified(), 
/*  621 */         email(), 
/*  622 */         flags(), 
/*  623 */         premiumType(), 
/*  624 */         publicFlags(), 
/*  625 */         member());
/*      */   }
/*      */   
/*      */   public ImmutableUserWithMemberData withBannerOrNull(@Nullable String value) {
/*  629 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  630 */     return new ImmutableUserWithMemberData(this, 
/*      */         
/*  632 */         id(), this.globalName, this.username, this.discriminator, this.avatar, newValue, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  638 */         accentColor(), 
/*  639 */         bot(), 
/*  640 */         system(), 
/*  641 */         mfaEnabled(), 
/*  642 */         locale(), 
/*  643 */         verified(), 
/*  644 */         email(), 
/*  645 */         flags(), 
/*  646 */         premiumType(), 
/*  647 */         publicFlags(), 
/*  648 */         member());
/*      */   }
/*      */   
/*      */   public ImmutableUserWithMemberData withAccentColor(Possible<Optional<Integer>> value) {
/*  652 */     Possible<Optional<Integer>> newValue = Objects.<Possible<Optional<Integer>>>requireNonNull(value);
/*  653 */     return new ImmutableUserWithMemberData(this, 
/*      */         
/*  655 */         id(), this.globalName, this.username, this.discriminator, this.avatar, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  660 */         banner(), newValue, 
/*      */         
/*  662 */         bot(), 
/*  663 */         system(), 
/*  664 */         mfaEnabled(), 
/*  665 */         locale(), 
/*  666 */         verified(), 
/*  667 */         email(), 
/*  668 */         flags(), 
/*  669 */         premiumType(), 
/*  670 */         publicFlags(), 
/*  671 */         member());
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableUserWithMemberData withAccentColor(@Nullable Integer value) {
/*  676 */     Possible<Optional<Integer>> newValue = Possible.of(Optional.ofNullable(value));
/*  677 */     return new ImmutableUserWithMemberData(this, 
/*      */         
/*  679 */         id(), this.globalName, this.username, this.discriminator, this.avatar, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  684 */         banner(), newValue, 
/*      */         
/*  686 */         bot(), 
/*  687 */         system(), 
/*  688 */         mfaEnabled(), 
/*  689 */         locale(), 
/*  690 */         verified(), 
/*  691 */         email(), 
/*  692 */         flags(), 
/*  693 */         premiumType(), 
/*  694 */         publicFlags(), 
/*  695 */         member());
/*      */   }
/*      */   
/*      */   public ImmutableUserWithMemberData withAccentColorOrNull(@Nullable Integer value) {
/*  699 */     Possible<Optional<Integer>> newValue = Possible.of(Optional.ofNullable(value));
/*  700 */     return new ImmutableUserWithMemberData(this, 
/*      */         
/*  702 */         id(), this.globalName, this.username, this.discriminator, this.avatar, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  707 */         banner(), newValue, 
/*      */         
/*  709 */         bot(), 
/*  710 */         system(), 
/*  711 */         mfaEnabled(), 
/*  712 */         locale(), 
/*  713 */         verified(), 
/*  714 */         email(), 
/*  715 */         flags(), 
/*  716 */         premiumType(), 
/*  717 */         publicFlags(), 
/*  718 */         member());
/*      */   }
/*      */   
/*      */   public ImmutableUserWithMemberData withBot(Possible<Boolean> value) {
/*  722 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/*  723 */     return new ImmutableUserWithMemberData(this, 
/*      */         
/*  725 */         id(), this.globalName, this.username, this.discriminator, this.avatar, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  730 */         banner(), 
/*  731 */         accentColor(), newValue, 
/*      */         
/*  733 */         system(), 
/*  734 */         mfaEnabled(), 
/*  735 */         locale(), 
/*  736 */         verified(), 
/*  737 */         email(), 
/*  738 */         flags(), 
/*  739 */         premiumType(), 
/*  740 */         publicFlags(), 
/*  741 */         member());
/*      */   }
/*      */   
/*      */   public ImmutableUserWithMemberData withBot(Boolean value) {
/*  745 */     Possible<Boolean> newValue = Possible.of(value);
/*  746 */     return new ImmutableUserWithMemberData(this, 
/*      */         
/*  748 */         id(), this.globalName, this.username, this.discriminator, this.avatar, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  753 */         banner(), 
/*  754 */         accentColor(), newValue, 
/*      */         
/*  756 */         system(), 
/*  757 */         mfaEnabled(), 
/*  758 */         locale(), 
/*  759 */         verified(), 
/*  760 */         email(), 
/*  761 */         flags(), 
/*  762 */         premiumType(), 
/*  763 */         publicFlags(), 
/*  764 */         member());
/*      */   }
/*      */   
/*      */   public ImmutableUserWithMemberData withSystem(Possible<Boolean> value) {
/*  768 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/*  769 */     return new ImmutableUserWithMemberData(this, 
/*      */         
/*  771 */         id(), this.globalName, this.username, this.discriminator, this.avatar, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  776 */         banner(), 
/*  777 */         accentColor(), 
/*  778 */         bot(), newValue, 
/*      */         
/*  780 */         mfaEnabled(), 
/*  781 */         locale(), 
/*  782 */         verified(), 
/*  783 */         email(), 
/*  784 */         flags(), 
/*  785 */         premiumType(), 
/*  786 */         publicFlags(), 
/*  787 */         member());
/*      */   }
/*      */   
/*      */   public ImmutableUserWithMemberData withSystem(Boolean value) {
/*  791 */     Possible<Boolean> newValue = Possible.of(value);
/*  792 */     return new ImmutableUserWithMemberData(this, 
/*      */         
/*  794 */         id(), this.globalName, this.username, this.discriminator, this.avatar, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  799 */         banner(), 
/*  800 */         accentColor(), 
/*  801 */         bot(), newValue, 
/*      */         
/*  803 */         mfaEnabled(), 
/*  804 */         locale(), 
/*  805 */         verified(), 
/*  806 */         email(), 
/*  807 */         flags(), 
/*  808 */         premiumType(), 
/*  809 */         publicFlags(), 
/*  810 */         member());
/*      */   }
/*      */   
/*      */   public ImmutableUserWithMemberData withMfaEnabled(Possible<Boolean> value) {
/*  814 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/*  815 */     return new ImmutableUserWithMemberData(this, 
/*      */         
/*  817 */         id(), this.globalName, this.username, this.discriminator, this.avatar, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  822 */         banner(), 
/*  823 */         accentColor(), 
/*  824 */         bot(), 
/*  825 */         system(), newValue, 
/*      */         
/*  827 */         locale(), 
/*  828 */         verified(), 
/*  829 */         email(), 
/*  830 */         flags(), 
/*  831 */         premiumType(), 
/*  832 */         publicFlags(), 
/*  833 */         member());
/*      */   }
/*      */   
/*      */   public ImmutableUserWithMemberData withMfaEnabled(Boolean value) {
/*  837 */     Possible<Boolean> newValue = Possible.of(value);
/*  838 */     return new ImmutableUserWithMemberData(this, 
/*      */         
/*  840 */         id(), this.globalName, this.username, this.discriminator, this.avatar, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  845 */         banner(), 
/*  846 */         accentColor(), 
/*  847 */         bot(), 
/*  848 */         system(), newValue, 
/*      */         
/*  850 */         locale(), 
/*  851 */         verified(), 
/*  852 */         email(), 
/*  853 */         flags(), 
/*  854 */         premiumType(), 
/*  855 */         publicFlags(), 
/*  856 */         member());
/*      */   }
/*      */   
/*      */   public ImmutableUserWithMemberData withLocale(Possible<String> value) {
/*  860 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  861 */     return new ImmutableUserWithMemberData(this, 
/*      */         
/*  863 */         id(), this.globalName, this.username, this.discriminator, this.avatar, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  868 */         banner(), 
/*  869 */         accentColor(), 
/*  870 */         bot(), 
/*  871 */         system(), 
/*  872 */         mfaEnabled(), newValue, 
/*      */         
/*  874 */         verified(), 
/*  875 */         email(), 
/*  876 */         flags(), 
/*  877 */         premiumType(), 
/*  878 */         publicFlags(), 
/*  879 */         member());
/*      */   }
/*      */   
/*      */   public ImmutableUserWithMemberData withLocale(String value) {
/*  883 */     Possible<String> newValue = Possible.of(value);
/*  884 */     return new ImmutableUserWithMemberData(this, 
/*      */         
/*  886 */         id(), this.globalName, this.username, this.discriminator, this.avatar, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  891 */         banner(), 
/*  892 */         accentColor(), 
/*  893 */         bot(), 
/*  894 */         system(), 
/*  895 */         mfaEnabled(), newValue, 
/*      */         
/*  897 */         verified(), 
/*  898 */         email(), 
/*  899 */         flags(), 
/*  900 */         premiumType(), 
/*  901 */         publicFlags(), 
/*  902 */         member());
/*      */   }
/*      */   
/*      */   public ImmutableUserWithMemberData withVerified(Possible<Boolean> value) {
/*  906 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/*  907 */     return new ImmutableUserWithMemberData(this, 
/*      */         
/*  909 */         id(), this.globalName, this.username, this.discriminator, this.avatar, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  914 */         banner(), 
/*  915 */         accentColor(), 
/*  916 */         bot(), 
/*  917 */         system(), 
/*  918 */         mfaEnabled(), 
/*  919 */         locale(), newValue, 
/*      */         
/*  921 */         email(), 
/*  922 */         flags(), 
/*  923 */         premiumType(), 
/*  924 */         publicFlags(), 
/*  925 */         member());
/*      */   }
/*      */   
/*      */   public ImmutableUserWithMemberData withVerified(Boolean value) {
/*  929 */     Possible<Boolean> newValue = Possible.of(value);
/*  930 */     return new ImmutableUserWithMemberData(this, 
/*      */         
/*  932 */         id(), this.globalName, this.username, this.discriminator, this.avatar, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  937 */         banner(), 
/*  938 */         accentColor(), 
/*  939 */         bot(), 
/*  940 */         system(), 
/*  941 */         mfaEnabled(), 
/*  942 */         locale(), newValue, 
/*      */         
/*  944 */         email(), 
/*  945 */         flags(), 
/*  946 */         premiumType(), 
/*  947 */         publicFlags(), 
/*  948 */         member());
/*      */   }
/*      */   
/*      */   public ImmutableUserWithMemberData withEmail(Possible<Optional<String>> value) {
/*  952 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/*  953 */     return new ImmutableUserWithMemberData(this, 
/*      */         
/*  955 */         id(), this.globalName, this.username, this.discriminator, this.avatar, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  960 */         banner(), 
/*  961 */         accentColor(), 
/*  962 */         bot(), 
/*  963 */         system(), 
/*  964 */         mfaEnabled(), 
/*  965 */         locale(), 
/*  966 */         verified(), newValue, 
/*      */         
/*  968 */         flags(), 
/*  969 */         premiumType(), 
/*  970 */         publicFlags(), 
/*  971 */         member());
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableUserWithMemberData withEmail(@Nullable String value) {
/*  976 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  977 */     return new ImmutableUserWithMemberData(this, 
/*      */         
/*  979 */         id(), this.globalName, this.username, this.discriminator, this.avatar, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  984 */         banner(), 
/*  985 */         accentColor(), 
/*  986 */         bot(), 
/*  987 */         system(), 
/*  988 */         mfaEnabled(), 
/*  989 */         locale(), 
/*  990 */         verified(), newValue, 
/*      */         
/*  992 */         flags(), 
/*  993 */         premiumType(), 
/*  994 */         publicFlags(), 
/*  995 */         member());
/*      */   }
/*      */   
/*      */   public ImmutableUserWithMemberData withEmailOrNull(@Nullable String value) {
/*  999 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 1000 */     return new ImmutableUserWithMemberData(this, 
/*      */         
/* 1002 */         id(), this.globalName, this.username, this.discriminator, this.avatar, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1007 */         banner(), 
/* 1008 */         accentColor(), 
/* 1009 */         bot(), 
/* 1010 */         system(), 
/* 1011 */         mfaEnabled(), 
/* 1012 */         locale(), 
/* 1013 */         verified(), newValue, 
/*      */         
/* 1015 */         flags(), 
/* 1016 */         premiumType(), 
/* 1017 */         publicFlags(), 
/* 1018 */         member());
/*      */   }
/*      */   
/*      */   public ImmutableUserWithMemberData withFlags(Possible<Long> value) {
/* 1022 */     Possible<Long> newValue = Objects.<Possible<Long>>requireNonNull(value);
/* 1023 */     return new ImmutableUserWithMemberData(this, 
/*      */         
/* 1025 */         id(), this.globalName, this.username, this.discriminator, this.avatar, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1030 */         banner(), 
/* 1031 */         accentColor(), 
/* 1032 */         bot(), 
/* 1033 */         system(), 
/* 1034 */         mfaEnabled(), 
/* 1035 */         locale(), 
/* 1036 */         verified(), 
/* 1037 */         email(), newValue, 
/*      */         
/* 1039 */         premiumType(), 
/* 1040 */         publicFlags(), 
/* 1041 */         member());
/*      */   }
/*      */   
/*      */   public ImmutableUserWithMemberData withFlags(Long value) {
/* 1045 */     Possible<Long> newValue = Possible.of(value);
/* 1046 */     return new ImmutableUserWithMemberData(this, 
/*      */         
/* 1048 */         id(), this.globalName, this.username, this.discriminator, this.avatar, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1053 */         banner(), 
/* 1054 */         accentColor(), 
/* 1055 */         bot(), 
/* 1056 */         system(), 
/* 1057 */         mfaEnabled(), 
/* 1058 */         locale(), 
/* 1059 */         verified(), 
/* 1060 */         email(), newValue, 
/*      */         
/* 1062 */         premiumType(), 
/* 1063 */         publicFlags(), 
/* 1064 */         member());
/*      */   }
/*      */   
/*      */   public ImmutableUserWithMemberData withPremiumType(Possible<Integer> value) {
/* 1068 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 1069 */     return new ImmutableUserWithMemberData(this, 
/*      */         
/* 1071 */         id(), this.globalName, this.username, this.discriminator, this.avatar, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1076 */         banner(), 
/* 1077 */         accentColor(), 
/* 1078 */         bot(), 
/* 1079 */         system(), 
/* 1080 */         mfaEnabled(), 
/* 1081 */         locale(), 
/* 1082 */         verified(), 
/* 1083 */         email(), 
/* 1084 */         flags(), newValue, 
/*      */         
/* 1086 */         publicFlags(), 
/* 1087 */         member());
/*      */   }
/*      */   
/*      */   public ImmutableUserWithMemberData withPremiumType(Integer value) {
/* 1091 */     Possible<Integer> newValue = Possible.of(value);
/* 1092 */     return new ImmutableUserWithMemberData(this, 
/*      */         
/* 1094 */         id(), this.globalName, this.username, this.discriminator, this.avatar, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1099 */         banner(), 
/* 1100 */         accentColor(), 
/* 1101 */         bot(), 
/* 1102 */         system(), 
/* 1103 */         mfaEnabled(), 
/* 1104 */         locale(), 
/* 1105 */         verified(), 
/* 1106 */         email(), 
/* 1107 */         flags(), newValue, 
/*      */         
/* 1109 */         publicFlags(), 
/* 1110 */         member());
/*      */   }
/*      */   
/*      */   public ImmutableUserWithMemberData withPublicFlags(Possible<Long> value) {
/* 1114 */     Possible<Long> newValue = Objects.<Possible<Long>>requireNonNull(value);
/* 1115 */     return new ImmutableUserWithMemberData(this, 
/*      */         
/* 1117 */         id(), this.globalName, this.username, this.discriminator, this.avatar, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1122 */         banner(), 
/* 1123 */         accentColor(), 
/* 1124 */         bot(), 
/* 1125 */         system(), 
/* 1126 */         mfaEnabled(), 
/* 1127 */         locale(), 
/* 1128 */         verified(), 
/* 1129 */         email(), 
/* 1130 */         flags(), 
/* 1131 */         premiumType(), newValue, 
/*      */         
/* 1133 */         member());
/*      */   }
/*      */   
/*      */   public ImmutableUserWithMemberData withPublicFlags(Long value) {
/* 1137 */     Possible<Long> newValue = Possible.of(value);
/* 1138 */     return new ImmutableUserWithMemberData(this, 
/*      */         
/* 1140 */         id(), this.globalName, this.username, this.discriminator, this.avatar, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1145 */         banner(), 
/* 1146 */         accentColor(), 
/* 1147 */         bot(), 
/* 1148 */         system(), 
/* 1149 */         mfaEnabled(), 
/* 1150 */         locale(), 
/* 1151 */         verified(), 
/* 1152 */         email(), 
/* 1153 */         flags(), 
/* 1154 */         premiumType(), newValue, 
/*      */         
/* 1156 */         member());
/*      */   }
/*      */   
/*      */   public ImmutableUserWithMemberData withMember(Possible<PartialMemberData> value) {
/* 1160 */     Possible<PartialMemberData> newValue = Objects.<Possible<PartialMemberData>>requireNonNull(value);
/* 1161 */     return new ImmutableUserWithMemberData(this, 
/*      */         
/* 1163 */         id(), this.globalName, this.username, this.discriminator, this.avatar, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1168 */         banner(), 
/* 1169 */         accentColor(), 
/* 1170 */         bot(), 
/* 1171 */         system(), 
/* 1172 */         mfaEnabled(), 
/* 1173 */         locale(), 
/* 1174 */         verified(), 
/* 1175 */         email(), 
/* 1176 */         flags(), 
/* 1177 */         premiumType(), 
/* 1178 */         publicFlags(), newValue);
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableUserWithMemberData withMember(PartialMemberData value) {
/* 1183 */     Possible<PartialMemberData> newValue = Possible.of(value);
/* 1184 */     return new ImmutableUserWithMemberData(this, 
/*      */         
/* 1186 */         id(), this.globalName, this.username, this.discriminator, this.avatar, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1191 */         banner(), 
/* 1192 */         accentColor(), 
/* 1193 */         bot(), 
/* 1194 */         system(), 
/* 1195 */         mfaEnabled(), 
/* 1196 */         locale(), 
/* 1197 */         verified(), 
/* 1198 */         email(), 
/* 1199 */         flags(), 
/* 1200 */         premiumType(), 
/* 1201 */         publicFlags(), newValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object another) {
/* 1211 */     if (this == another) return true; 
/* 1212 */     return (another instanceof ImmutableUserWithMemberData && 
/* 1213 */       equalTo(0, (ImmutableUserWithMemberData)another));
/*      */   }
/*      */   
/*      */   private boolean equalTo(int synthetic, ImmutableUserWithMemberData another) {
/* 1217 */     return (Objects.equals(Long.valueOf(this.id_value), Long.valueOf(another.id_value)) && 
/* 1218 */       Objects.equals(this.globalName, another.globalName) && this.username
/* 1219 */       .equals(another.username) && this.discriminator
/* 1220 */       .equals(another.discriminator) && 
/* 1221 */       Objects.equals(this.avatar, another.avatar) && 
/* 1222 */       banner().equals(another.banner()) && 
/* 1223 */       accentColor().equals(another.accentColor()) && 
/* 1224 */       bot().equals(another.bot()) && 
/* 1225 */       system().equals(another.system()) && 
/* 1226 */       mfaEnabled().equals(another.mfaEnabled()) && 
/* 1227 */       locale().equals(another.locale()) && 
/* 1228 */       verified().equals(another.verified()) && 
/* 1229 */       email().equals(another.email()) && 
/* 1230 */       flags().equals(another.flags()) && 
/* 1231 */       premiumType().equals(another.premiumType()) && 
/* 1232 */       publicFlags().equals(another.publicFlags()) && 
/* 1233 */       member().equals(another.member()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/* 1242 */     int h = 5381;
/* 1243 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.id_value));
/* 1244 */     h += (h << 5) + Objects.hashCode(this.globalName);
/* 1245 */     h += (h << 5) + this.username.hashCode();
/* 1246 */     h += (h << 5) + this.discriminator.hashCode();
/* 1247 */     h += (h << 5) + Objects.hashCode(this.avatar);
/* 1248 */     h += (h << 5) + banner().hashCode();
/* 1249 */     h += (h << 5) + accentColor().hashCode();
/* 1250 */     h += (h << 5) + bot().hashCode();
/* 1251 */     h += (h << 5) + system().hashCode();
/* 1252 */     h += (h << 5) + mfaEnabled().hashCode();
/* 1253 */     h += (h << 5) + locale().hashCode();
/* 1254 */     h += (h << 5) + verified().hashCode();
/* 1255 */     h += (h << 5) + email().hashCode();
/* 1256 */     h += (h << 5) + flags().hashCode();
/* 1257 */     h += (h << 5) + premiumType().hashCode();
/* 1258 */     h += (h << 5) + publicFlags().hashCode();
/* 1259 */     h += (h << 5) + member().hashCode();
/* 1260 */     return h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1269 */     StringBuilder builder = new StringBuilder("UserWithMemberData{");
/* 1270 */     builder.append("id=").append(Objects.toString(Long.valueOf(this.id_value)));
/* 1271 */     if (this.globalName != null) {
/* 1272 */       builder.append(", ");
/* 1273 */       builder.append("globalName=").append(this.globalName);
/*      */     } 
/* 1275 */     builder.append(", ");
/* 1276 */     builder.append("username=").append(this.username);
/* 1277 */     builder.append(", ");
/* 1278 */     builder.append("discriminator=").append(this.discriminator);
/* 1279 */     if (this.avatar != null) {
/* 1280 */       builder.append(", ");
/* 1281 */       builder.append("avatar=").append(this.avatar);
/*      */     } 
/* 1283 */     builder.append(", ");
/* 1284 */     builder.append("banner=").append(banner().toString());
/* 1285 */     builder.append(", ");
/* 1286 */     builder.append("accentColor=").append(accentColor().toString());
/* 1287 */     builder.append(", ");
/* 1288 */     builder.append("bot=").append(bot().toString());
/* 1289 */     builder.append(", ");
/* 1290 */     builder.append("system=").append(system().toString());
/* 1291 */     builder.append(", ");
/* 1292 */     builder.append("mfaEnabled=").append(mfaEnabled().toString());
/* 1293 */     builder.append(", ");
/* 1294 */     builder.append("locale=").append(locale().toString());
/* 1295 */     builder.append(", ");
/* 1296 */     builder.append("verified=").append(verified().toString());
/* 1297 */     builder.append(", ");
/* 1298 */     builder.append("email=").append(email().toString());
/* 1299 */     builder.append(", ");
/* 1300 */     builder.append("flags=").append(flags().toString());
/* 1301 */     builder.append(", ");
/* 1302 */     builder.append("premiumType=").append(premiumType().toString());
/* 1303 */     builder.append(", ");
/* 1304 */     builder.append("publicFlags=").append(publicFlags().toString());
/* 1305 */     builder.append(", ");
/* 1306 */     builder.append("member=").append(member().toString());
/* 1307 */     return builder.append("}").toString();
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonDeserialize
/*      */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*      */   @Generated(from = "UserWithMemberData", generator = "Immutables")
/*      */   static final class Json
/*      */     implements UserWithMemberData
/*      */   {
/*      */     Id id;
/*      */     
/* 1320 */     Optional<String> globalName = Optional.empty();
/*      */     String username;
/*      */     String discriminator;
/* 1323 */     Optional<String> avatar = Optional.empty();
/*      */     
/* 1325 */     Possible<Optional<String>> banner = Possible.absent();
/*      */ 
/*      */     
/* 1328 */     Possible<Optional<Integer>> accentColor = Possible.absent();
/*      */ 
/*      */     
/* 1331 */     Possible<Boolean> bot = Possible.absent();
/*      */ 
/*      */     
/* 1334 */     Possible<Boolean> system = Possible.absent();
/*      */ 
/*      */     
/* 1337 */     Possible<Boolean> mfaEnabled = Possible.absent();
/*      */ 
/*      */     
/* 1340 */     Possible<String> locale = Possible.absent();
/*      */ 
/*      */     
/* 1343 */     Possible<Boolean> verified = Possible.absent();
/*      */ 
/*      */     
/* 1346 */     Possible<Optional<String>> email = Possible.absent();
/*      */ 
/*      */     
/* 1349 */     Possible<Long> flags = Possible.absent();
/*      */ 
/*      */     
/* 1352 */     Possible<Integer> premiumType = Possible.absent();
/*      */ 
/*      */     
/* 1355 */     Possible<Long> publicFlags = Possible.absent();
/*      */ 
/*      */     
/* 1358 */     Possible<PartialMemberData> member = Possible.absent();
/*      */     
/*      */     @JsonProperty("id")
/*      */     public void setId(Id id) {
/* 1362 */       this.id = id;
/*      */     }
/*      */     @JsonProperty("global_name")
/*      */     public void setGlobalName(Optional<String> globalName) {
/* 1366 */       this.globalName = globalName;
/*      */     }
/*      */     @JsonProperty("username")
/*      */     public void setUsername(String username) {
/* 1370 */       this.username = username;
/*      */     }
/*      */     @JsonProperty("discriminator")
/*      */     public void setDiscriminator(String discriminator) {
/* 1374 */       this.discriminator = discriminator;
/*      */     }
/*      */     @JsonProperty("avatar")
/*      */     public void setAvatar(Optional<String> avatar) {
/* 1378 */       this.avatar = avatar;
/*      */     }
/*      */     @JsonProperty("banner")
/*      */     public void setBanner(Possible<Optional<String>> banner) {
/* 1382 */       this.banner = banner;
/*      */     }
/*      */     @JsonProperty("accent_color")
/*      */     public void setAccentColor(Possible<Optional<Integer>> accentColor) {
/* 1386 */       this.accentColor = accentColor;
/*      */     }
/*      */     @JsonProperty("bot")
/*      */     public void setBot(Possible<Boolean> bot) {
/* 1390 */       this.bot = bot;
/*      */     }
/*      */     @JsonProperty("system")
/*      */     public void setSystem(Possible<Boolean> system) {
/* 1394 */       this.system = system;
/*      */     }
/*      */     @JsonProperty("mfa_enabled")
/*      */     public void setMfaEnabled(Possible<Boolean> mfaEnabled) {
/* 1398 */       this.mfaEnabled = mfaEnabled;
/*      */     }
/*      */     @JsonProperty("locale")
/*      */     public void setLocale(Possible<String> locale) {
/* 1402 */       this.locale = locale;
/*      */     }
/*      */     @JsonProperty("verified")
/*      */     public void setVerified(Possible<Boolean> verified) {
/* 1406 */       this.verified = verified;
/*      */     }
/*      */     @JsonProperty("email")
/*      */     public void setEmail(Possible<Optional<String>> email) {
/* 1410 */       this.email = email;
/*      */     }
/*      */     @JsonProperty("flags")
/*      */     public void setFlags(Possible<Long> flags) {
/* 1414 */       this.flags = flags;
/*      */     }
/*      */     @JsonProperty("premium_type")
/*      */     public void setPremiumType(Possible<Integer> premiumType) {
/* 1418 */       this.premiumType = premiumType;
/*      */     }
/*      */     @JsonProperty("public_flags")
/*      */     public void setPublicFlags(Possible<Long> publicFlags) {
/* 1422 */       this.publicFlags = publicFlags;
/*      */     }
/*      */     @JsonProperty("member")
/*      */     public void setMember(Possible<PartialMemberData> member) {
/* 1426 */       this.member = member;
/*      */     }
/*      */     public Id id() {
/* 1429 */       throw new UnsupportedOperationException();
/*      */     } public Optional<String> globalName() {
/* 1431 */       throw new UnsupportedOperationException();
/*      */     } public String username() {
/* 1433 */       throw new UnsupportedOperationException();
/*      */     } public String discriminator() {
/* 1435 */       throw new UnsupportedOperationException();
/*      */     } public Optional<String> avatar() {
/* 1437 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<String>> banner() {
/* 1439 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<Integer>> accentColor() {
/* 1441 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Boolean> bot() {
/* 1443 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Boolean> system() {
/* 1445 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Boolean> mfaEnabled() {
/* 1447 */       throw new UnsupportedOperationException();
/*      */     } public Possible<String> locale() {
/* 1449 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Boolean> verified() {
/* 1451 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<String>> email() {
/* 1453 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Long> flags() {
/* 1455 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> premiumType() {
/* 1457 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Long> publicFlags() {
/* 1459 */       throw new UnsupportedOperationException();
/*      */     } public Possible<PartialMemberData> member() {
/* 1461 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*      */   static ImmutableUserWithMemberData fromJson(Json json) {
/* 1472 */     Builder builder = builder();
/* 1473 */     if (json.id != null) {
/* 1474 */       builder.id(json.id);
/*      */     }
/* 1476 */     if (json.globalName != null) {
/* 1477 */       builder.globalName(json.globalName);
/*      */     }
/* 1479 */     if (json.username != null) {
/* 1480 */       builder.username(json.username);
/*      */     }
/* 1482 */     if (json.discriminator != null) {
/* 1483 */       builder.discriminator(json.discriminator);
/*      */     }
/* 1485 */     if (json.avatar != null) {
/* 1486 */       builder.avatar(json.avatar);
/*      */     }
/* 1488 */     if (json.banner != null) {
/* 1489 */       builder.banner(json.banner);
/*      */     }
/* 1491 */     if (json.accentColor != null) {
/* 1492 */       builder.accentColor(json.accentColor);
/*      */     }
/* 1494 */     if (json.bot != null) {
/* 1495 */       builder.bot(json.bot);
/*      */     }
/* 1497 */     if (json.system != null) {
/* 1498 */       builder.system(json.system);
/*      */     }
/* 1500 */     if (json.mfaEnabled != null) {
/* 1501 */       builder.mfaEnabled(json.mfaEnabled);
/*      */     }
/* 1503 */     if (json.locale != null) {
/* 1504 */       builder.locale(json.locale);
/*      */     }
/* 1506 */     if (json.verified != null) {
/* 1507 */       builder.verified(json.verified);
/*      */     }
/* 1509 */     if (json.email != null) {
/* 1510 */       builder.email(json.email);
/*      */     }
/* 1512 */     if (json.flags != null) {
/* 1513 */       builder.flags(json.flags);
/*      */     }
/* 1515 */     if (json.premiumType != null) {
/* 1516 */       builder.premiumType(json.premiumType);
/*      */     }
/* 1518 */     if (json.publicFlags != null) {
/* 1519 */       builder.publicFlags(json.publicFlags);
/*      */     }
/* 1521 */     if (json.member != null) {
/* 1522 */       builder.member(json.member);
/*      */     }
/* 1524 */     return builder.build();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableUserWithMemberData of(Id id, Optional<String> globalName, String username, String discriminator, Optional<String> avatar, Possible<Optional<String>> banner, Possible<Optional<Integer>> accentColor, Possible<Boolean> bot, Possible<Boolean> system, Possible<Boolean> mfaEnabled, Possible<String> locale, Possible<Boolean> verified, Possible<Optional<String>> email, Possible<Long> flags, Possible<Integer> premiumType, Possible<Long> publicFlags, Possible<PartialMemberData> member) {
/* 1549 */     return new ImmutableUserWithMemberData(id, globalName, username, discriminator, avatar, banner, accentColor, bot, system, mfaEnabled, locale, verified, email, flags, premiumType, publicFlags, member);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableUserWithMemberData copyOf(UserWithMemberData instance) {
/* 1560 */     if (instance instanceof ImmutableUserWithMemberData) {
/* 1561 */       return (ImmutableUserWithMemberData)instance;
/*      */     }
/* 1563 */     return builder()
/* 1564 */       .from(instance)
/* 1565 */       .build();
/*      */   }
/*      */   
/*      */   public boolean isBannerPresent() {
/* 1569 */     return !this.banner_absent;
/*      */   }
/*      */   
/*      */   public String bannerOrElse(String defaultValue) {
/* 1573 */     return !this.banner_absent ? this.banner_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isAccentColorPresent() {
/* 1577 */     return !this.accentColor_absent;
/*      */   }
/*      */   
/*      */   public Integer accentColorOrElse(Integer defaultValue) {
/* 1581 */     return !this.accentColor_absent ? this.accentColor_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isBotPresent() {
/* 1585 */     return !this.bot_absent;
/*      */   }
/*      */   
/*      */   public Boolean botOrElse(Boolean defaultValue) {
/* 1589 */     return !this.bot_absent ? this.bot_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isSystemPresent() {
/* 1593 */     return !this.system_absent;
/*      */   }
/*      */   
/*      */   public Boolean systemOrElse(Boolean defaultValue) {
/* 1597 */     return !this.system_absent ? this.system_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isMfaEnabledPresent() {
/* 1601 */     return !this.mfaEnabled_absent;
/*      */   }
/*      */   
/*      */   public Boolean mfaEnabledOrElse(Boolean defaultValue) {
/* 1605 */     return !this.mfaEnabled_absent ? this.mfaEnabled_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isLocalePresent() {
/* 1609 */     return !this.locale_absent;
/*      */   }
/*      */   
/*      */   public String localeOrElse(String defaultValue) {
/* 1613 */     return !this.locale_absent ? this.locale_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isVerifiedPresent() {
/* 1617 */     return !this.verified_absent;
/*      */   }
/*      */   
/*      */   public Boolean verifiedOrElse(Boolean defaultValue) {
/* 1621 */     return !this.verified_absent ? this.verified_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isEmailPresent() {
/* 1625 */     return !this.email_absent;
/*      */   }
/*      */   
/*      */   public String emailOrElse(String defaultValue) {
/* 1629 */     return !this.email_absent ? this.email_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isFlagsPresent() {
/* 1633 */     return !this.flags_absent;
/*      */   }
/*      */   
/*      */   public Long flagsOrElse(Long defaultValue) {
/* 1637 */     return !this.flags_absent ? this.flags_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isPremiumTypePresent() {
/* 1641 */     return !this.premiumType_absent;
/*      */   }
/*      */   
/*      */   public Integer premiumTypeOrElse(Integer defaultValue) {
/* 1645 */     return !this.premiumType_absent ? this.premiumType_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isPublicFlagsPresent() {
/* 1649 */     return !this.publicFlags_absent;
/*      */   }
/*      */   
/*      */   public Long publicFlagsOrElse(Long defaultValue) {
/* 1653 */     return !this.publicFlags_absent ? this.publicFlags_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isMemberPresent() {
/* 1657 */     return !this.member_absent;
/*      */   }
/*      */   
/*      */   public PartialMemberData memberOrElse(PartialMemberData defaultValue) {
/* 1661 */     return !this.member_absent ? this.member_value : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Builder builder() {
/* 1690 */     return new Builder();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Generated(from = "UserWithMemberData", generator = "Immutables")
/*      */   public static final class Builder
/*      */   {
/*      */     private static final long INIT_BIT_USERNAME = 1L;
/*      */ 
/*      */     
/*      */     private static final long INIT_BIT_DISCRIMINATOR = 2L;
/*      */ 
/*      */     
/* 1704 */     private long initBits = 3L;
/*      */     
/* 1706 */     private Id id_id = null;
/* 1707 */     private Possible<Optional<String>> banner_possible = Possible.absent();
/* 1708 */     private Possible<Optional<Integer>> accentColor_possible = Possible.absent();
/* 1709 */     private Possible<Boolean> bot_possible = Possible.absent();
/* 1710 */     private Possible<Boolean> system_possible = Possible.absent();
/* 1711 */     private Possible<Boolean> mfaEnabled_possible = Possible.absent();
/* 1712 */     private Possible<String> locale_possible = Possible.absent();
/* 1713 */     private Possible<Boolean> verified_possible = Possible.absent();
/* 1714 */     private Possible<Optional<String>> email_possible = Possible.absent();
/* 1715 */     private Possible<Long> flags_possible = Possible.absent();
/* 1716 */     private Possible<Integer> premiumType_possible = Possible.absent();
/* 1717 */     private Possible<Long> publicFlags_possible = Possible.absent();
/* 1718 */     private Possible<PartialMemberData> member_possible = Possible.absent();
/*      */ 
/*      */     
/*      */     private String globalName;
/*      */ 
/*      */     
/*      */     private String username;
/*      */ 
/*      */     
/*      */     private String discriminator;
/*      */     
/*      */     private String avatar;
/*      */ 
/*      */     
/*      */     public final Builder from(UserWithMemberData instance) {
/* 1733 */       Objects.requireNonNull(instance, "instance");
/* 1734 */       from(instance);
/* 1735 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(UserData instance) {
/* 1744 */       Objects.requireNonNull(instance, "instance");
/* 1745 */       from(instance);
/* 1746 */       return this;
/*      */     }
/*      */     
/*      */     private void from(Object object) {
/* 1750 */       long bits = 0L;
/* 1751 */       if (object instanceof UserWithMemberData) {
/* 1752 */         UserWithMemberData instance = (UserWithMemberData)object;
/* 1753 */         if ((bits & 0x1L) == 0L) {
/* 1754 */           Optional<String> globalNameOptional = instance.globalName();
/* 1755 */           if (globalNameOptional.isPresent()) {
/* 1756 */             globalName(globalNameOptional);
/*      */           }
/* 1758 */           bits |= 0x1L;
/*      */         } 
/* 1760 */         if ((bits & 0x2L) == 0L) {
/* 1761 */           publicFlags(instance.publicFlags());
/* 1762 */           bits |= 0x2L;
/*      */         } 
/* 1764 */         if ((bits & 0x4L) == 0L) {
/* 1765 */           accentColor(instance.accentColor());
/* 1766 */           bits |= 0x4L;
/*      */         } 
/* 1768 */         if ((bits & 0x8L) == 0L) {
/* 1769 */           bot(instance.bot());
/* 1770 */           bits |= 0x8L;
/*      */         } 
/* 1772 */         if ((bits & 0x10L) == 0L) {
/* 1773 */           verified(instance.verified());
/* 1774 */           bits |= 0x10L;
/*      */         } 
/* 1776 */         if ((bits & 0x20L) == 0L) {
/* 1777 */           flags(instance.flags());
/* 1778 */           bits |= 0x20L;
/*      */         } 
/* 1780 */         if ((bits & 0x40L) == 0L) {
/* 1781 */           banner(instance.banner());
/* 1782 */           bits |= 0x40L;
/*      */         } 
/* 1784 */         if ((bits & 0x80L) == 0L) {
/* 1785 */           Optional<String> avatarOptional = instance.avatar();
/* 1786 */           if (avatarOptional.isPresent()) {
/* 1787 */             avatar(avatarOptional);
/*      */           }
/* 1789 */           bits |= 0x80L;
/*      */         } 
/* 1791 */         if ((bits & 0x100L) == 0L) {
/* 1792 */           locale(instance.locale());
/* 1793 */           bits |= 0x100L;
/*      */         } 
/* 1795 */         if ((bits & 0x200L) == 0L) {
/* 1796 */           premiumType(instance.premiumType());
/* 1797 */           bits |= 0x200L;
/*      */         } 
/* 1799 */         if ((bits & 0x400L) == 0L) {
/* 1800 */           discriminator(instance.discriminator());
/* 1801 */           bits |= 0x400L;
/*      */         } 
/* 1803 */         if ((bits & 0x800L) == 0L) {
/* 1804 */           system(instance.system());
/* 1805 */           bits |= 0x800L;
/*      */         } 
/* 1807 */         member(instance.member());
/* 1808 */         if ((bits & 0x1000L) == 0L) {
/* 1809 */           mfaEnabled(instance.mfaEnabled());
/* 1810 */           bits |= 0x1000L;
/*      */         } 
/* 1812 */         if ((bits & 0x2000L) == 0L) {
/* 1813 */           id(instance.id());
/* 1814 */           bits |= 0x2000L;
/*      */         } 
/* 1816 */         if ((bits & 0x4000L) == 0L) {
/* 1817 */           email(instance.email());
/* 1818 */           bits |= 0x4000L;
/*      */         } 
/* 1820 */         if ((bits & 0x8000L) == 0L) {
/* 1821 */           username(instance.username());
/* 1822 */           bits |= 0x8000L;
/*      */         } 
/*      */       } 
/* 1825 */       if (object instanceof UserData) {
/* 1826 */         UserData instance = (UserData)object;
/* 1827 */         if ((bits & 0x1L) == 0L) {
/* 1828 */           Optional<String> globalNameOptional = instance.globalName();
/* 1829 */           if (globalNameOptional.isPresent()) {
/* 1830 */             globalName(globalNameOptional);
/*      */           }
/* 1832 */           bits |= 0x1L;
/*      */         } 
/* 1834 */         if ((bits & 0x2L) == 0L) {
/* 1835 */           publicFlags(instance.publicFlags());
/* 1836 */           bits |= 0x2L;
/*      */         } 
/* 1838 */         if ((bits & 0x4L) == 0L) {
/* 1839 */           accentColor(instance.accentColor());
/* 1840 */           bits |= 0x4L;
/*      */         } 
/* 1842 */         if ((bits & 0x8L) == 0L) {
/* 1843 */           bot(instance.bot());
/* 1844 */           bits |= 0x8L;
/*      */         } 
/* 1846 */         if ((bits & 0x10L) == 0L) {
/* 1847 */           verified(instance.verified());
/* 1848 */           bits |= 0x10L;
/*      */         } 
/* 1850 */         if ((bits & 0x20L) == 0L) {
/* 1851 */           flags(instance.flags());
/* 1852 */           bits |= 0x20L;
/*      */         } 
/* 1854 */         if ((bits & 0x40L) == 0L) {
/* 1855 */           banner(instance.banner());
/* 1856 */           bits |= 0x40L;
/*      */         } 
/* 1858 */         if ((bits & 0x80L) == 0L) {
/* 1859 */           Optional<String> avatarOptional = instance.avatar();
/* 1860 */           if (avatarOptional.isPresent()) {
/* 1861 */             avatar(avatarOptional);
/*      */           }
/* 1863 */           bits |= 0x80L;
/*      */         } 
/* 1865 */         if ((bits & 0x100L) == 0L) {
/* 1866 */           locale(instance.locale());
/* 1867 */           bits |= 0x100L;
/*      */         } 
/* 1869 */         if ((bits & 0x200L) == 0L) {
/* 1870 */           premiumType(instance.premiumType());
/* 1871 */           bits |= 0x200L;
/*      */         } 
/* 1873 */         if ((bits & 0x400L) == 0L) {
/* 1874 */           discriminator(instance.discriminator());
/* 1875 */           bits |= 0x400L;
/*      */         } 
/* 1877 */         if ((bits & 0x800L) == 0L) {
/* 1878 */           system(instance.system());
/* 1879 */           bits |= 0x800L;
/*      */         } 
/* 1881 */         if ((bits & 0x1000L) == 0L) {
/* 1882 */           mfaEnabled(instance.mfaEnabled());
/* 1883 */           bits |= 0x1000L;
/*      */         } 
/* 1885 */         if ((bits & 0x2000L) == 0L) {
/* 1886 */           id(instance.id());
/* 1887 */           bits |= 0x2000L;
/*      */         } 
/* 1889 */         if ((bits & 0x4000L) == 0L) {
/* 1890 */           email(instance.email());
/* 1891 */           bits |= 0x4000L;
/*      */         } 
/* 1893 */         if ((bits & 0x8000L) == 0L) {
/* 1894 */           username(instance.username());
/* 1895 */           bits |= 0x8000L;
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*      */     public Builder id(String value) {
/* 1901 */       this.id_id = Id.of(value);
/* 1902 */       return this;
/*      */     }
/*      */     
/*      */     public Builder id(long value) {
/* 1906 */       this.id_id = Id.of(value);
/* 1907 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("id")
/*      */     public Builder id(Id value) {
/* 1912 */       this.id_id = value;
/* 1913 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder globalName(String globalName) {
/* 1922 */       this.globalName = Objects.<String>requireNonNull(globalName, "globalName");
/* 1923 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("global_name")
/*      */     public final Builder globalName(Optional<String> globalName) {
/* 1933 */       this.globalName = globalName.orElse(null);
/* 1934 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("username")
/*      */     public final Builder username(String username) {
/* 1944 */       this.username = Objects.<String>requireNonNull(username, "username");
/* 1945 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 1946 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("discriminator")
/*      */     @Deprecated
/*      */     public final Builder discriminator(String discriminator) {
/* 1957 */       this.discriminator = Objects.<String>requireNonNull(discriminator, "discriminator");
/* 1958 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 1959 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder avatar(String avatar) {
/* 1968 */       this.avatar = Objects.<String>requireNonNull(avatar, "avatar");
/* 1969 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("avatar")
/*      */     public final Builder avatar(Optional<String> avatar) {
/* 1979 */       this.avatar = avatar.orElse(null);
/* 1980 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("banner")
/*      */     public Builder banner(Possible<Optional<String>> value) {
/* 1985 */       this.banner_possible = value;
/* 1986 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder banner(@Nullable String value) {
/* 1991 */       this.banner_possible = Possible.of(Optional.ofNullable(value));
/* 1992 */       return this;
/*      */     }
/*      */     
/*      */     public Builder bannerOrNull(@Nullable String value) {
/* 1996 */       this.banner_possible = Possible.of(Optional.ofNullable(value));
/* 1997 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("accent_color")
/*      */     public Builder accentColor(Possible<Optional<Integer>> value) {
/* 2002 */       this.accentColor_possible = value;
/* 2003 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder accentColor(@Nullable Integer value) {
/* 2008 */       this.accentColor_possible = Possible.of(Optional.ofNullable(value));
/* 2009 */       return this;
/*      */     }
/*      */     
/*      */     public Builder accentColorOrNull(@Nullable Integer value) {
/* 2013 */       this.accentColor_possible = Possible.of(Optional.ofNullable(value));
/* 2014 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("bot")
/*      */     public Builder bot(Possible<Boolean> value) {
/* 2019 */       this.bot_possible = value;
/* 2020 */       return this;
/*      */     }
/*      */     
/*      */     public Builder bot(Boolean value) {
/* 2024 */       this.bot_possible = Possible.of(value);
/* 2025 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("system")
/*      */     public Builder system(Possible<Boolean> value) {
/* 2030 */       this.system_possible = value;
/* 2031 */       return this;
/*      */     }
/*      */     
/*      */     public Builder system(Boolean value) {
/* 2035 */       this.system_possible = Possible.of(value);
/* 2036 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("mfa_enabled")
/*      */     public Builder mfaEnabled(Possible<Boolean> value) {
/* 2041 */       this.mfaEnabled_possible = value;
/* 2042 */       return this;
/*      */     }
/*      */     
/*      */     public Builder mfaEnabled(Boolean value) {
/* 2046 */       this.mfaEnabled_possible = Possible.of(value);
/* 2047 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("locale")
/*      */     public Builder locale(Possible<String> value) {
/* 2052 */       this.locale_possible = value;
/* 2053 */       return this;
/*      */     }
/*      */     
/*      */     public Builder locale(String value) {
/* 2057 */       this.locale_possible = Possible.of(value);
/* 2058 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("verified")
/*      */     public Builder verified(Possible<Boolean> value) {
/* 2063 */       this.verified_possible = value;
/* 2064 */       return this;
/*      */     }
/*      */     
/*      */     public Builder verified(Boolean value) {
/* 2068 */       this.verified_possible = Possible.of(value);
/* 2069 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("email")
/*      */     public Builder email(Possible<Optional<String>> value) {
/* 2074 */       this.email_possible = value;
/* 2075 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder email(@Nullable String value) {
/* 2080 */       this.email_possible = Possible.of(Optional.ofNullable(value));
/* 2081 */       return this;
/*      */     }
/*      */     
/*      */     public Builder emailOrNull(@Nullable String value) {
/* 2085 */       this.email_possible = Possible.of(Optional.ofNullable(value));
/* 2086 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("flags")
/*      */     public Builder flags(Possible<Long> value) {
/* 2091 */       this.flags_possible = value;
/* 2092 */       return this;
/*      */     }
/*      */     
/*      */     public Builder flags(Long value) {
/* 2096 */       this.flags_possible = Possible.of(value);
/* 2097 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("premium_type")
/*      */     public Builder premiumType(Possible<Integer> value) {
/* 2102 */       this.premiumType_possible = value;
/* 2103 */       return this;
/*      */     }
/*      */     
/*      */     public Builder premiumType(Integer value) {
/* 2107 */       this.premiumType_possible = Possible.of(value);
/* 2108 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("public_flags")
/*      */     public Builder publicFlags(Possible<Long> value) {
/* 2113 */       this.publicFlags_possible = value;
/* 2114 */       return this;
/*      */     }
/*      */     
/*      */     public Builder publicFlags(Long value) {
/* 2118 */       this.publicFlags_possible = Possible.of(value);
/* 2119 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("member")
/*      */     public Builder member(Possible<PartialMemberData> value) {
/* 2124 */       this.member_possible = value;
/* 2125 */       return this;
/*      */     }
/*      */     
/*      */     public Builder member(PartialMemberData value) {
/* 2129 */       this.member_possible = Possible.of(value);
/* 2130 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ImmutableUserWithMemberData build() {
/* 2139 */       if (this.initBits != 0L) {
/* 2140 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*      */       }
/* 2142 */       return new ImmutableUserWithMemberData(null, 
/*      */           
/* 2144 */           id_build(), this.globalName, this.username, this.discriminator, this.avatar, 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2149 */           banner_build(), 
/* 2150 */           accentColor_build(), 
/* 2151 */           bot_build(), 
/* 2152 */           system_build(), 
/* 2153 */           mfaEnabled_build(), 
/* 2154 */           locale_build(), 
/* 2155 */           verified_build(), 
/* 2156 */           email_build(), 
/* 2157 */           flags_build(), 
/* 2158 */           premiumType_build(), 
/* 2159 */           publicFlags_build(), 
/* 2160 */           member_build());
/*      */     }
/*      */     
/*      */     private String formatRequiredAttributesMessage() {
/* 2164 */       List<String> attributes = new ArrayList<>();
/* 2165 */       if ((this.initBits & 0x1L) != 0L) attributes.add("username"); 
/* 2166 */       if ((this.initBits & 0x2L) != 0L) attributes.add("discriminator"); 
/* 2167 */       return "Cannot build UserWithMemberData, some of required attributes are not set " + attributes;
/*      */     }
/*      */     
/*      */     private Id id_build() {
/* 2171 */       return this.id_id;
/*      */     }
/*      */     
/*      */     private Possible<Optional<String>> banner_build() {
/* 2175 */       return this.banner_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<Integer>> accentColor_build() {
/* 2179 */       return this.accentColor_possible;
/*      */     }
/*      */     
/*      */     private Possible<Boolean> bot_build() {
/* 2183 */       return this.bot_possible;
/*      */     }
/*      */     
/*      */     private Possible<Boolean> system_build() {
/* 2187 */       return this.system_possible;
/*      */     }
/*      */     
/*      */     private Possible<Boolean> mfaEnabled_build() {
/* 2191 */       return this.mfaEnabled_possible;
/*      */     }
/*      */     
/*      */     private Possible<String> locale_build() {
/* 2195 */       return this.locale_possible;
/*      */     }
/*      */     
/*      */     private Possible<Boolean> verified_build() {
/* 2199 */       return this.verified_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<String>> email_build() {
/* 2203 */       return this.email_possible;
/*      */     }
/*      */     
/*      */     private Possible<Long> flags_build() {
/* 2207 */       return this.flags_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> premiumType_build() {
/* 2211 */       return this.premiumType_possible;
/*      */     }
/*      */     
/*      */     private Possible<Long> publicFlags_build() {
/* 2215 */       return this.publicFlags_possible;
/*      */     }
/*      */     
/*      */     private Possible<PartialMemberData> member_build() {
/* 2219 */       return this.member_possible;
/*      */     }
/*      */     
/*      */     private Builder() {}
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableUserWithMemberData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */