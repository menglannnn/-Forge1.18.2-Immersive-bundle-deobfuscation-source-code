/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.Id;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "RoleTagsData", generator = "Immutables")
/*     */ public final class ImmutableRoleTagsData
/*     */   implements RoleTagsData
/*     */ {
/*     */   private final long botId_value;
/*     */   private final boolean botId_absent;
/*     */   private final long integrationId_value;
/*     */   private final boolean integrationId_absent;
/*     */   private final Void premiumSubscriber_value;
/*     */   private final boolean premiumSubscriber_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private ImmutableRoleTagsData(Possible<Id> botId, Possible<Id> integrationId, Possible<Optional<Void>> premiumSubscriber) {
/*  39 */     Possible<Id> botId$impl = botId;
/*  40 */     Possible<Id> integrationId$impl = integrationId;
/*  41 */     Possible<Optional<Void>> premiumSubscriber$impl = premiumSubscriber;
/*  42 */     this
/*     */       
/*  44 */       .botId_value = ((Long)botId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  45 */     this.botId_absent = botId$impl.isAbsent();
/*  46 */     this
/*     */       
/*  48 */       .integrationId_value = ((Long)integrationId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  49 */     this.integrationId_absent = integrationId$impl.isAbsent();
/*  50 */     this.premiumSubscriber_value = Possible.flatOpt(premiumSubscriber$impl).orElse(null);
/*  51 */     this.premiumSubscriber_absent = premiumSubscriber$impl.isAbsent();
/*  52 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableRoleTagsData(ImmutableRoleTagsData original, Possible<Id> botId, Possible<Id> integrationId, Possible<Optional<Void>> premiumSubscriber) {
/*  60 */     Possible<Id> botId$impl = botId;
/*  61 */     Possible<Id> integrationId$impl = integrationId;
/*  62 */     Possible<Optional<Void>> premiumSubscriber$impl = premiumSubscriber;
/*  63 */     this
/*     */       
/*  65 */       .botId_value = ((Long)botId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  66 */     this.botId_absent = botId$impl.isAbsent();
/*  67 */     this
/*     */       
/*  69 */       .integrationId_value = ((Long)integrationId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  70 */     this.integrationId_absent = integrationId$impl.isAbsent();
/*  71 */     this.premiumSubscriber_value = Possible.flatOpt(premiumSubscriber$impl).orElse(null);
/*  72 */     this.premiumSubscriber_absent = premiumSubscriber$impl.isAbsent();
/*  73 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  79 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "RoleTagsData", generator = "Immutables")
/*     */   private final class InitShim {
/*     */     private String formatInitCycleMessage() {
/*  84 */       List<String> attributes = new ArrayList<>();
/*  85 */       return "Cannot build RoleTagsData, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @JsonProperty("bot_id")
/*     */   public Possible<Id> botId() {
/*  95 */     return this.botId_absent ? Possible.absent() : 
/*  96 */       Possible.of(Id.of(this.botId_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("integration_id")
/*     */   public Possible<Id> integrationId() {
/* 105 */     return this.integrationId_absent ? Possible.absent() : 
/* 106 */       Possible.of(Id.of(this.integrationId_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("premium_subscriber")
/*     */   public Possible<Optional<Void>> premiumSubscriber() {
/* 115 */     return this.premiumSubscriber_absent ? Possible.absent() : 
/* 116 */       Possible.of(Optional.ofNullable(this.premiumSubscriber_value));
/*     */   }
/*     */   
/*     */   public ImmutableRoleTagsData withBotId(Possible<Id> value) {
/* 120 */     Possible<Id> newValue = Objects.<Possible<Id>>requireNonNull(value);
/* 121 */     return new ImmutableRoleTagsData(this, newValue, integrationId(), premiumSubscriber());
/*     */   }
/*     */   
/*     */   public ImmutableRoleTagsData withBotId(long value) {
/* 125 */     Possible<Id> newValue = Possible.of(Id.of(value));
/* 126 */     return new ImmutableRoleTagsData(this, newValue, integrationId(), premiumSubscriber());
/*     */   }
/*     */   
/*     */   public ImmutableRoleTagsData withIntegrationId(Possible<Id> value) {
/* 130 */     Possible<Id> newValue = Objects.<Possible<Id>>requireNonNull(value);
/* 131 */     return new ImmutableRoleTagsData(this, botId(), newValue, premiumSubscriber());
/*     */   }
/*     */   
/*     */   public ImmutableRoleTagsData withIntegrationId(long value) {
/* 135 */     Possible<Id> newValue = Possible.of(Id.of(value));
/* 136 */     return new ImmutableRoleTagsData(this, botId(), newValue, premiumSubscriber());
/*     */   }
/*     */   
/*     */   public ImmutableRoleTagsData withPremiumSubscriber(Possible<Optional<Void>> value) {
/* 140 */     Possible<Optional<Void>> newValue = Objects.<Possible<Optional<Void>>>requireNonNull(value);
/* 141 */     return new ImmutableRoleTagsData(this, botId(), integrationId(), newValue);
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public ImmutableRoleTagsData withPremiumSubscriber(@Nullable Void value) {
/* 146 */     Possible<Optional<Void>> newValue = Possible.of(Optional.ofNullable(value));
/* 147 */     return new ImmutableRoleTagsData(this, botId(), integrationId(), newValue);
/*     */   }
/*     */   
/*     */   public ImmutableRoleTagsData withPremiumSubscriberOrNull(@Nullable Void value) {
/* 151 */     Possible<Optional<Void>> newValue = Possible.of(Optional.ofNullable(value));
/* 152 */     return new ImmutableRoleTagsData(this, botId(), integrationId(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 161 */     if (this == another) return true; 
/* 162 */     return (another instanceof ImmutableRoleTagsData && 
/* 163 */       equalTo(0, (ImmutableRoleTagsData)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableRoleTagsData another) {
/* 167 */     return (botId().equals(another.botId()) && 
/* 168 */       integrationId().equals(another.integrationId()) && 
/* 169 */       premiumSubscriber().equals(another.premiumSubscriber()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 178 */     int h = 5381;
/* 179 */     h += (h << 5) + botId().hashCode();
/* 180 */     h += (h << 5) + integrationId().hashCode();
/* 181 */     h += (h << 5) + premiumSubscriber().hashCode();
/* 182 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 191 */     return "RoleTagsData{botId=" + 
/* 192 */       botId().toString() + ", integrationId=" + 
/* 193 */       integrationId().toString() + ", premiumSubscriber=" + 
/* 194 */       premiumSubscriber().toString() + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "RoleTagsData", generator = "Immutables")
/*     */   static final class Json
/*     */     implements RoleTagsData
/*     */   {
/* 208 */     Possible<Id> botId = Possible.absent();
/*     */ 
/*     */     
/* 211 */     Possible<Id> integrationId = Possible.absent();
/*     */ 
/*     */     
/* 214 */     Possible<Optional<Void>> premiumSubscriber = Possible.absent();
/*     */     
/*     */     @JsonProperty("bot_id")
/*     */     public void setBotId(Possible<Id> botId) {
/* 218 */       this.botId = botId;
/*     */     }
/*     */     @JsonProperty("integration_id")
/*     */     public void setIntegrationId(Possible<Id> integrationId) {
/* 222 */       this.integrationId = integrationId;
/*     */     }
/*     */     @JsonProperty("premium_subscriber")
/*     */     public void setPremiumSubscriber(Possible<Optional<Void>> premiumSubscriber) {
/* 226 */       this.premiumSubscriber = premiumSubscriber;
/*     */     }
/*     */     public Possible<Id> botId() {
/* 229 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Id> integrationId() {
/* 231 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Optional<Void>> premiumSubscriber() {
/* 233 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableRoleTagsData fromJson(Json json) {
/* 244 */     Builder builder = builder();
/* 245 */     if (json.botId != null) {
/* 246 */       builder.botId(json.botId);
/*     */     }
/* 248 */     if (json.integrationId != null) {
/* 249 */       builder.integrationId(json.integrationId);
/*     */     }
/* 251 */     if (json.premiumSubscriber != null) {
/* 252 */       builder.premiumSubscriber(json.premiumSubscriber);
/*     */     }
/* 254 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableRoleTagsData of(Possible<Id> botId, Possible<Id> integrationId, Possible<Optional<Void>> premiumSubscriber) {
/* 265 */     return new ImmutableRoleTagsData(botId, integrationId, premiumSubscriber);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableRoleTagsData copyOf(RoleTagsData instance) {
/* 276 */     if (instance instanceof ImmutableRoleTagsData) {
/* 277 */       return (ImmutableRoleTagsData)instance;
/*     */     }
/* 279 */     return builder()
/* 280 */       .from(instance)
/* 281 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isBotIdPresent() {
/* 285 */     return !this.botId_absent;
/*     */   }
/*     */   
/*     */   public long botIdOrElse(long defaultValue) {
/* 289 */     return !this.botId_absent ? this.botId_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isIntegrationIdPresent() {
/* 293 */     return !this.integrationId_absent;
/*     */   }
/*     */   
/*     */   public long integrationIdOrElse(long defaultValue) {
/* 297 */     return !this.integrationId_absent ? this.integrationId_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isPremiumSubscriberPresent() {
/* 301 */     return !this.premiumSubscriber_absent;
/*     */   }
/*     */   
/*     */   public Void premiumSubscriberOrElse(Void defaultValue) {
/* 305 */     return !this.premiumSubscriber_absent ? this.premiumSubscriber_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 320 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "RoleTagsData", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/* 332 */     private Possible<Id> botId_possible = Possible.absent();
/* 333 */     private Possible<Id> integrationId_possible = Possible.absent();
/* 334 */     private Possible<Optional<Void>> premiumSubscriber_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(RoleTagsData instance) {
/* 347 */       Objects.requireNonNull(instance, "instance");
/* 348 */       botId(instance.botId());
/* 349 */       integrationId(instance.integrationId());
/* 350 */       premiumSubscriber(instance.premiumSubscriber());
/* 351 */       return this;
/*     */     }
/*     */     
/*     */     public Builder botId(String value) {
/* 355 */       this.botId_possible = Possible.of(Id.of(value));
/* 356 */       return this;
/*     */     }
/*     */     
/*     */     public Builder botId(long value) {
/* 360 */       this.botId_possible = Possible.of(Id.of(value));
/* 361 */       return this;
/*     */     }
/*     */     
/*     */     public Builder botId(Id value) {
/* 365 */       this.botId_possible = Possible.of(value);
/* 366 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("bot_id")
/*     */     public Builder botId(Possible<Id> value) {
/* 371 */       this.botId_possible = value;
/* 372 */       return this;
/*     */     }
/*     */     
/*     */     public Builder integrationId(String value) {
/* 376 */       this.integrationId_possible = Possible.of(Id.of(value));
/* 377 */       return this;
/*     */     }
/*     */     
/*     */     public Builder integrationId(long value) {
/* 381 */       this.integrationId_possible = Possible.of(Id.of(value));
/* 382 */       return this;
/*     */     }
/*     */     
/*     */     public Builder integrationId(Id value) {
/* 386 */       this.integrationId_possible = Possible.of(value);
/* 387 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("integration_id")
/*     */     public Builder integrationId(Possible<Id> value) {
/* 392 */       this.integrationId_possible = value;
/* 393 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("premium_subscriber")
/*     */     public Builder premiumSubscriber(Possible<Optional<Void>> value) {
/* 398 */       this.premiumSubscriber_possible = value;
/* 399 */       return this;
/*     */     }
/*     */     
/*     */     @Deprecated
/*     */     public Builder premiumSubscriber(@Nullable Void value) {
/* 404 */       this.premiumSubscriber_possible = Possible.of(Optional.ofNullable(value));
/* 405 */       return this;
/*     */     }
/*     */     
/*     */     public Builder premiumSubscriberOrNull(@Nullable Void value) {
/* 409 */       this.premiumSubscriber_possible = Possible.of(Optional.ofNullable(value));
/* 410 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableRoleTagsData build() {
/* 419 */       return new ImmutableRoleTagsData(null, botId_build(), integrationId_build(), premiumSubscriber_build());
/*     */     }
/*     */     
/*     */     private Possible<Id> botId_build() {
/* 423 */       return this.botId_possible;
/*     */     }
/*     */     
/*     */     private Possible<Id> integrationId_build() {
/* 427 */       return this.integrationId_possible;
/*     */     }
/*     */     
/*     */     private Possible<Optional<Void>> premiumSubscriber_build() {
/* 431 */       return this.premiumSubscriber_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableRoleTagsData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */