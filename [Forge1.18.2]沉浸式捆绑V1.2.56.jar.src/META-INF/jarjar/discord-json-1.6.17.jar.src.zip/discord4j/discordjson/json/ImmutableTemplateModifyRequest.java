/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "TemplateModifyRequest", generator = "Immutables")
/*     */ public final class ImmutableTemplateModifyRequest
/*     */   implements TemplateModifyRequest
/*     */ {
/*     */   private final String name_value;
/*     */   private final boolean name_absent;
/*     */   private final String description_value;
/*     */   private final boolean description_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private ImmutableTemplateModifyRequest(Possible<String> name, Possible<Optional<String>> description) {
/*  35 */     Possible<String> name$impl = name;
/*  36 */     Possible<Optional<String>> description$impl = description;
/*  37 */     this.name_value = name$impl.toOptional().orElse(null);
/*  38 */     this.name_absent = name$impl.isAbsent();
/*  39 */     this.description_value = Possible.flatOpt(description$impl).orElse(null);
/*  40 */     this.description_absent = description$impl.isAbsent();
/*  41 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableTemplateModifyRequest(ImmutableTemplateModifyRequest original, Possible<String> name, Possible<Optional<String>> description) {
/*  48 */     Possible<String> name$impl = name;
/*  49 */     Possible<Optional<String>> description$impl = description;
/*  50 */     this.name_value = name$impl.toOptional().orElse(null);
/*  51 */     this.name_absent = name$impl.isAbsent();
/*  52 */     this.description_value = Possible.flatOpt(description$impl).orElse(null);
/*  53 */     this.description_absent = description$impl.isAbsent();
/*  54 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  60 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "TemplateModifyRequest", generator = "Immutables")
/*     */   private final class InitShim {
/*     */     private String formatInitCycleMessage() {
/*  65 */       List<String> attributes = new ArrayList<>();
/*  66 */       return "Cannot build TemplateModifyRequest, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @JsonProperty("name")
/*     */   public Possible<String> name() {
/*  76 */     return this.name_absent ? Possible.absent() : Possible.of(this.name_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("description")
/*     */   public Possible<Optional<String>> description() {
/*  85 */     return this.description_absent ? Possible.absent() : 
/*  86 */       Possible.of(Optional.ofNullable(this.description_value));
/*     */   }
/*     */   
/*     */   public ImmutableTemplateModifyRequest withName(Possible<String> value) {
/*  90 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  91 */     return new ImmutableTemplateModifyRequest(this, newValue, description());
/*     */   }
/*     */   
/*     */   public ImmutableTemplateModifyRequest withName(String value) {
/*  95 */     Possible<String> newValue = Possible.of(value);
/*  96 */     return new ImmutableTemplateModifyRequest(this, newValue, description());
/*     */   }
/*     */   
/*     */   public ImmutableTemplateModifyRequest withDescription(Possible<Optional<String>> value) {
/* 100 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/* 101 */     return new ImmutableTemplateModifyRequest(this, name(), newValue);
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public ImmutableTemplateModifyRequest withDescription(@Nullable String value) {
/* 106 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 107 */     return new ImmutableTemplateModifyRequest(this, name(), newValue);
/*     */   }
/*     */   
/*     */   public ImmutableTemplateModifyRequest withDescriptionOrNull(@Nullable String value) {
/* 111 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 112 */     return new ImmutableTemplateModifyRequest(this, name(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 121 */     if (this == another) return true; 
/* 122 */     return (another instanceof ImmutableTemplateModifyRequest && 
/* 123 */       equalTo(0, (ImmutableTemplateModifyRequest)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableTemplateModifyRequest another) {
/* 127 */     return (name().equals(another.name()) && 
/* 128 */       description().equals(another.description()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 137 */     int h = 5381;
/* 138 */     h += (h << 5) + name().hashCode();
/* 139 */     h += (h << 5) + description().hashCode();
/* 140 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 149 */     return "TemplateModifyRequest{name=" + 
/* 150 */       name().toString() + ", description=" + 
/* 151 */       description().toString() + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "TemplateModifyRequest", generator = "Immutables")
/*     */   static final class Json
/*     */     implements TemplateModifyRequest
/*     */   {
/* 165 */     Possible<String> name = Possible.absent();
/*     */ 
/*     */     
/* 168 */     Possible<Optional<String>> description = Possible.absent();
/*     */     
/*     */     @JsonProperty("name")
/*     */     public void setName(Possible<String> name) {
/* 172 */       this.name = name;
/*     */     }
/*     */     @JsonProperty("description")
/*     */     public void setDescription(Possible<Optional<String>> description) {
/* 176 */       this.description = description;
/*     */     }
/*     */     public Possible<String> name() {
/* 179 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Optional<String>> description() {
/* 181 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableTemplateModifyRequest fromJson(Json json) {
/* 192 */     Builder builder = builder();
/* 193 */     if (json.name != null) {
/* 194 */       builder.name(json.name);
/*     */     }
/* 196 */     if (json.description != null) {
/* 197 */       builder.description(json.description);
/*     */     }
/* 199 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableTemplateModifyRequest of(Possible<String> name, Possible<Optional<String>> description) {
/* 209 */     return new ImmutableTemplateModifyRequest(name, description);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableTemplateModifyRequest copyOf(TemplateModifyRequest instance) {
/* 220 */     if (instance instanceof ImmutableTemplateModifyRequest) {
/* 221 */       return (ImmutableTemplateModifyRequest)instance;
/*     */     }
/* 223 */     return builder()
/* 224 */       .from(instance)
/* 225 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isNamePresent() {
/* 229 */     return !this.name_absent;
/*     */   }
/*     */   
/*     */   public String nameOrElse(String defaultValue) {
/* 233 */     return !this.name_absent ? this.name_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isDescriptionPresent() {
/* 237 */     return !this.description_absent;
/*     */   }
/*     */   
/*     */   public String descriptionOrElse(String defaultValue) {
/* 241 */     return !this.description_absent ? this.description_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 255 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "TemplateModifyRequest", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/* 267 */     private Possible<String> name_possible = Possible.absent();
/* 268 */     private Possible<Optional<String>> description_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(TemplateModifyRequest instance) {
/* 281 */       Objects.requireNonNull(instance, "instance");
/* 282 */       name(instance.name());
/* 283 */       description(instance.description());
/* 284 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("name")
/*     */     public Builder name(Possible<String> value) {
/* 289 */       this.name_possible = value;
/* 290 */       return this;
/*     */     }
/*     */     
/*     */     public Builder name(String value) {
/* 294 */       this.name_possible = Possible.of(value);
/* 295 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("description")
/*     */     public Builder description(Possible<Optional<String>> value) {
/* 300 */       this.description_possible = value;
/* 301 */       return this;
/*     */     }
/*     */     
/*     */     @Deprecated
/*     */     public Builder description(@Nullable String value) {
/* 306 */       this.description_possible = Possible.of(Optional.ofNullable(value));
/* 307 */       return this;
/*     */     }
/*     */     
/*     */     public Builder descriptionOrNull(@Nullable String value) {
/* 311 */       this.description_possible = Possible.of(Optional.ofNullable(value));
/* 312 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableTemplateModifyRequest build() {
/* 321 */       return new ImmutableTemplateModifyRequest(null, name_build(), description_build());
/*     */     }
/*     */     
/*     */     private Possible<String> name_build() {
/* 325 */       return this.name_possible;
/*     */     }
/*     */     
/*     */     private Possible<Optional<String>> description_build() {
/* 329 */       return this.description_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableTemplateModifyRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */