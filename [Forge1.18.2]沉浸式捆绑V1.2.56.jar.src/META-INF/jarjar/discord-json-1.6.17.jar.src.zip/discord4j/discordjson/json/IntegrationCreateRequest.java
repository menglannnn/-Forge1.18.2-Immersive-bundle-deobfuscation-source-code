/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ @JsonSerialize(as = ImmutableIntegrationCreateRequest.class)
/*    */ @JsonDeserialize(as = ImmutableIntegrationCreateRequest.class)
/*    */ @Immutable
/*    */ public interface IntegrationCreateRequest
/*    */ {
/*    */   static ImmutableIntegrationCreateRequest.Builder builder() {
/* 13 */     return ImmutableIntegrationCreateRequest.builder();
/*    */   }
/*    */   
/*    */   String type();
/*    */   
/*    */   String id();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\IntegrationCreateRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */