/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "AuditLogData", generator = "Immutables")
/*     */ public final class ImmutableAuditLogData
/*     */   implements AuditLogData
/*     */ {
/*     */   private final List<WebhookData> webhooks;
/*     */   private final List<UserData> users;
/*     */   private final List<AuditLogEntryData> auditLogEntries;
/*     */   private final List<IntegrationData> integrations;
/*     */   private final List<AutoModRuleData> autoModerationRules;
/*     */   
/*     */   private ImmutableAuditLogData(Iterable<? extends WebhookData> webhooks, Iterable<? extends UserData> users, Iterable<? extends AuditLogEntryData> auditLogEntries, Iterable<? extends IntegrationData> integrations, Iterable<? extends AutoModRuleData> autoModerationRules) {
/*  39 */     this.webhooks = createUnmodifiableList(false, createSafeList(webhooks, true, false));
/*  40 */     this.users = createUnmodifiableList(false, createSafeList(users, true, false));
/*  41 */     this.auditLogEntries = createUnmodifiableList(false, createSafeList(auditLogEntries, true, false));
/*  42 */     this.integrations = createUnmodifiableList(false, createSafeList(integrations, true, false));
/*  43 */     this.autoModerationRules = createUnmodifiableList(false, createSafeList(autoModerationRules, true, false));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableAuditLogData(ImmutableAuditLogData original, List<WebhookData> webhooks, List<UserData> users, List<AuditLogEntryData> auditLogEntries, List<IntegrationData> integrations, List<AutoModRuleData> autoModerationRules) {
/*  53 */     this.webhooks = webhooks;
/*  54 */     this.users = users;
/*  55 */     this.auditLogEntries = auditLogEntries;
/*  56 */     this.integrations = integrations;
/*  57 */     this.autoModerationRules = autoModerationRules;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("webhooks")
/*     */   public List<WebhookData> webhooks() {
/*  66 */     return this.webhooks;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("users")
/*     */   public List<UserData> users() {
/*  75 */     return this.users;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("audit_log_entries")
/*     */   public List<AuditLogEntryData> auditLogEntries() {
/*  84 */     return this.auditLogEntries;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("integrations")
/*     */   public List<IntegrationData> integrations() {
/*  93 */     return this.integrations;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("auto_moderation_rules")
/*     */   public List<AutoModRuleData> autoModerationRules() {
/* 102 */     return this.autoModerationRules;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableAuditLogData withWebhooks(WebhookData... elements) {
/* 111 */     List<WebhookData> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 112 */     return new ImmutableAuditLogData(this, newValue, this.users, this.auditLogEntries, this.integrations, this.autoModerationRules);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableAuditLogData withWebhooks(Iterable<? extends WebhookData> elements) {
/* 122 */     if (this.webhooks == elements) return this; 
/* 123 */     List<WebhookData> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 124 */     return new ImmutableAuditLogData(this, newValue, this.users, this.auditLogEntries, this.integrations, this.autoModerationRules);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableAuditLogData withUsers(UserData... elements) {
/* 133 */     List<UserData> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 134 */     return new ImmutableAuditLogData(this, this.webhooks, newValue, this.auditLogEntries, this.integrations, this.autoModerationRules);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableAuditLogData withUsers(Iterable<? extends UserData> elements) {
/* 150 */     if (this.users == elements) return this; 
/* 151 */     List<UserData> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 152 */     return new ImmutableAuditLogData(this, this.webhooks, newValue, this.auditLogEntries, this.integrations, this.autoModerationRules);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableAuditLogData withAuditLogEntries(AuditLogEntryData... elements) {
/* 167 */     List<AuditLogEntryData> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 168 */     return new ImmutableAuditLogData(this, this.webhooks, this.users, newValue, this.integrations, this.autoModerationRules);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableAuditLogData withAuditLogEntries(Iterable<? extends AuditLogEntryData> elements) {
/* 178 */     if (this.auditLogEntries == elements) return this; 
/* 179 */     List<AuditLogEntryData> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 180 */     return new ImmutableAuditLogData(this, this.webhooks, this.users, newValue, this.integrations, this.autoModerationRules);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableAuditLogData withIntegrations(IntegrationData... elements) {
/* 189 */     List<IntegrationData> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 190 */     return new ImmutableAuditLogData(this, this.webhooks, this.users, this.auditLogEntries, newValue, this.autoModerationRules);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableAuditLogData withIntegrations(Iterable<? extends IntegrationData> elements) {
/* 200 */     if (this.integrations == elements) return this; 
/* 201 */     List<IntegrationData> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 202 */     return new ImmutableAuditLogData(this, this.webhooks, this.users, this.auditLogEntries, newValue, this.autoModerationRules);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableAuditLogData withAutoModerationRules(AutoModRuleData... elements) {
/* 211 */     List<AutoModRuleData> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 212 */     return new ImmutableAuditLogData(this, this.webhooks, this.users, this.auditLogEntries, this.integrations, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableAuditLogData withAutoModerationRules(Iterable<? extends AutoModRuleData> elements) {
/* 222 */     if (this.autoModerationRules == elements) return this; 
/* 223 */     List<AutoModRuleData> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 224 */     return new ImmutableAuditLogData(this, this.webhooks, this.users, this.auditLogEntries, this.integrations, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 233 */     if (this == another) return true; 
/* 234 */     return (another instanceof ImmutableAuditLogData && 
/* 235 */       equalTo(0, (ImmutableAuditLogData)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableAuditLogData another) {
/* 239 */     return (this.webhooks.equals(another.webhooks) && this.users
/* 240 */       .equals(another.users) && this.auditLogEntries
/* 241 */       .equals(another.auditLogEntries) && this.integrations
/* 242 */       .equals(another.integrations) && this.autoModerationRules
/* 243 */       .equals(another.autoModerationRules));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 252 */     int h = 5381;
/* 253 */     h += (h << 5) + this.webhooks.hashCode();
/* 254 */     h += (h << 5) + this.users.hashCode();
/* 255 */     h += (h << 5) + this.auditLogEntries.hashCode();
/* 256 */     h += (h << 5) + this.integrations.hashCode();
/* 257 */     h += (h << 5) + this.autoModerationRules.hashCode();
/* 258 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 267 */     return "AuditLogData{webhooks=" + this.webhooks + ", users=" + this.users + ", auditLogEntries=" + this.auditLogEntries + ", integrations=" + this.integrations + ", autoModerationRules=" + this.autoModerationRules + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "AuditLogData", generator = "Immutables")
/*     */   static final class Json
/*     */     implements AuditLogData
/*     */   {
/* 285 */     List<WebhookData> webhooks = Collections.emptyList();
/* 286 */     List<UserData> users = Collections.emptyList();
/* 287 */     List<AuditLogEntryData> auditLogEntries = Collections.emptyList();
/* 288 */     List<IntegrationData> integrations = Collections.emptyList();
/* 289 */     List<AutoModRuleData> autoModerationRules = Collections.emptyList();
/*     */     @JsonProperty("webhooks")
/*     */     public void setWebhooks(List<WebhookData> webhooks) {
/* 292 */       this.webhooks = webhooks;
/*     */     }
/*     */     @JsonProperty("users")
/*     */     public void setUsers(List<UserData> users) {
/* 296 */       this.users = users;
/*     */     }
/*     */     @JsonProperty("audit_log_entries")
/*     */     public void setAuditLogEntries(List<AuditLogEntryData> auditLogEntries) {
/* 300 */       this.auditLogEntries = auditLogEntries;
/*     */     }
/*     */     @JsonProperty("integrations")
/*     */     public void setIntegrations(List<IntegrationData> integrations) {
/* 304 */       this.integrations = integrations;
/*     */     }
/*     */     @JsonProperty("auto_moderation_rules")
/*     */     public void setAutoModerationRules(List<AutoModRuleData> autoModerationRules) {
/* 308 */       this.autoModerationRules = autoModerationRules;
/*     */     }
/*     */     public List<WebhookData> webhooks() {
/* 311 */       throw new UnsupportedOperationException();
/*     */     } public List<UserData> users() {
/* 313 */       throw new UnsupportedOperationException();
/*     */     } public List<AuditLogEntryData> auditLogEntries() {
/* 315 */       throw new UnsupportedOperationException();
/*     */     } public List<IntegrationData> integrations() {
/* 317 */       throw new UnsupportedOperationException();
/*     */     } public List<AutoModRuleData> autoModerationRules() {
/* 319 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableAuditLogData fromJson(Json json) {
/* 330 */     Builder builder = builder();
/* 331 */     if (json.webhooks != null) {
/* 332 */       builder.addAllWebhooks(json.webhooks);
/*     */     }
/* 334 */     if (json.users != null) {
/* 335 */       builder.addAllUsers(json.users);
/*     */     }
/* 337 */     if (json.auditLogEntries != null) {
/* 338 */       builder.addAllAuditLogEntries(json.auditLogEntries);
/*     */     }
/* 340 */     if (json.integrations != null) {
/* 341 */       builder.addAllIntegrations(json.integrations);
/*     */     }
/* 343 */     if (json.autoModerationRules != null) {
/* 344 */       builder.addAllAutoModerationRules(json.autoModerationRules);
/*     */     }
/* 346 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableAuditLogData of(List<WebhookData> webhooks, List<UserData> users, List<AuditLogEntryData> auditLogEntries, List<IntegrationData> integrations, List<AutoModRuleData> autoModerationRules) {
/* 359 */     return of(webhooks, users, auditLogEntries, integrations, autoModerationRules);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableAuditLogData of(Iterable<? extends WebhookData> webhooks, Iterable<? extends UserData> users, Iterable<? extends AuditLogEntryData> auditLogEntries, Iterable<? extends IntegrationData> integrations, Iterable<? extends AutoModRuleData> autoModerationRules) {
/* 372 */     return new ImmutableAuditLogData(webhooks, users, auditLogEntries, integrations, autoModerationRules);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableAuditLogData copyOf(AuditLogData instance) {
/* 383 */     if (instance instanceof ImmutableAuditLogData) {
/* 384 */       return (ImmutableAuditLogData)instance;
/*     */     }
/* 386 */     return builder()
/* 387 */       .from(instance)
/* 388 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 405 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "AuditLogData", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/* 417 */     private List<WebhookData> webhooks = new ArrayList<>();
/* 418 */     private List<UserData> users = new ArrayList<>();
/* 419 */     private List<AuditLogEntryData> auditLogEntries = new ArrayList<>();
/* 420 */     private List<IntegrationData> integrations = new ArrayList<>();
/* 421 */     private List<AutoModRuleData> autoModerationRules = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(AuditLogData instance) {
/* 435 */       Objects.requireNonNull(instance, "instance");
/* 436 */       addAllWebhooks(instance.webhooks());
/* 437 */       addAllUsers(instance.users());
/* 438 */       addAllAuditLogEntries(instance.auditLogEntries());
/* 439 */       addAllIntegrations(instance.integrations());
/* 440 */       addAllAutoModerationRules(instance.autoModerationRules());
/* 441 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addWebhook(WebhookData element) {
/* 450 */       this.webhooks.add(Objects.<WebhookData>requireNonNull(element, "webhooks element"));
/* 451 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addWebhooks(WebhookData... elements) {
/* 460 */       for (WebhookData element : elements) {
/* 461 */         this.webhooks.add(Objects.<WebhookData>requireNonNull(element, "webhooks element"));
/*     */       }
/* 463 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("webhooks")
/*     */     public final Builder webhooks(Iterable<? extends WebhookData> elements) {
/* 474 */       this.webhooks.clear();
/* 475 */       return addAllWebhooks(elements);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addAllWebhooks(Iterable<? extends WebhookData> elements) {
/* 484 */       for (WebhookData element : elements) {
/* 485 */         this.webhooks.add(Objects.<WebhookData>requireNonNull(element, "webhooks element"));
/*     */       }
/* 487 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addUser(UserData element) {
/* 496 */       this.users.add(Objects.<UserData>requireNonNull(element, "users element"));
/* 497 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addUsers(UserData... elements) {
/* 506 */       for (UserData element : elements) {
/* 507 */         this.users.add(Objects.<UserData>requireNonNull(element, "users element"));
/*     */       }
/* 509 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("users")
/*     */     public final Builder users(Iterable<? extends UserData> elements) {
/* 520 */       this.users.clear();
/* 521 */       return addAllUsers(elements);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addAllUsers(Iterable<? extends UserData> elements) {
/* 530 */       for (UserData element : elements) {
/* 531 */         this.users.add(Objects.<UserData>requireNonNull(element, "users element"));
/*     */       }
/* 533 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addAuditLogEntry(AuditLogEntryData element) {
/* 542 */       this.auditLogEntries.add(Objects.<AuditLogEntryData>requireNonNull(element, "auditLogEntries element"));
/* 543 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addAuditLogEntries(AuditLogEntryData... elements) {
/* 552 */       for (AuditLogEntryData element : elements) {
/* 553 */         this.auditLogEntries.add(Objects.<AuditLogEntryData>requireNonNull(element, "auditLogEntries element"));
/*     */       }
/* 555 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("audit_log_entries")
/*     */     public final Builder auditLogEntries(Iterable<? extends AuditLogEntryData> elements) {
/* 566 */       this.auditLogEntries.clear();
/* 567 */       return addAllAuditLogEntries(elements);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addAllAuditLogEntries(Iterable<? extends AuditLogEntryData> elements) {
/* 576 */       for (AuditLogEntryData element : elements) {
/* 577 */         this.auditLogEntries.add(Objects.<AuditLogEntryData>requireNonNull(element, "auditLogEntries element"));
/*     */       }
/* 579 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addIntegration(IntegrationData element) {
/* 588 */       this.integrations.add(Objects.<IntegrationData>requireNonNull(element, "integrations element"));
/* 589 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addIntegrations(IntegrationData... elements) {
/* 598 */       for (IntegrationData element : elements) {
/* 599 */         this.integrations.add(Objects.<IntegrationData>requireNonNull(element, "integrations element"));
/*     */       }
/* 601 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("integrations")
/*     */     public final Builder integrations(Iterable<? extends IntegrationData> elements) {
/* 612 */       this.integrations.clear();
/* 613 */       return addAllIntegrations(elements);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addAllIntegrations(Iterable<? extends IntegrationData> elements) {
/* 622 */       for (IntegrationData element : elements) {
/* 623 */         this.integrations.add(Objects.<IntegrationData>requireNonNull(element, "integrations element"));
/*     */       }
/* 625 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addAutoModerationRule(AutoModRuleData element) {
/* 634 */       this.autoModerationRules.add(Objects.<AutoModRuleData>requireNonNull(element, "autoModerationRules element"));
/* 635 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addAutoModerationRules(AutoModRuleData... elements) {
/* 644 */       for (AutoModRuleData element : elements) {
/* 645 */         this.autoModerationRules.add(Objects.<AutoModRuleData>requireNonNull(element, "autoModerationRules element"));
/*     */       }
/* 647 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("auto_moderation_rules")
/*     */     public final Builder autoModerationRules(Iterable<? extends AutoModRuleData> elements) {
/* 658 */       this.autoModerationRules.clear();
/* 659 */       return addAllAutoModerationRules(elements);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addAllAutoModerationRules(Iterable<? extends AutoModRuleData> elements) {
/* 668 */       for (AutoModRuleData element : elements) {
/* 669 */         this.autoModerationRules.add(Objects.<AutoModRuleData>requireNonNull(element, "autoModerationRules element"));
/*     */       }
/* 671 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableAuditLogData build() {
/* 680 */       return new ImmutableAuditLogData(null, ImmutableAuditLogData
/*     */           
/* 682 */           .createUnmodifiableList(true, (List)this.webhooks), ImmutableAuditLogData
/* 683 */           .createUnmodifiableList(true, (List)this.users), ImmutableAuditLogData
/* 684 */           .createUnmodifiableList(true, (List)this.auditLogEntries), ImmutableAuditLogData
/* 685 */           .createUnmodifiableList(true, (List)this.integrations), ImmutableAuditLogData
/* 686 */           .createUnmodifiableList(true, (List)this.autoModerationRules));
/*     */     }
/*     */     private Builder() {} }
/*     */   
/*     */   private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
/*     */     ArrayList<T> list;
/* 692 */     if (iterable instanceof Collection) {
/* 693 */       int size = ((Collection)iterable).size();
/* 694 */       if (size == 0) return Collections.emptyList(); 
/* 695 */       list = new ArrayList<>();
/*     */     } else {
/* 697 */       list = new ArrayList<>();
/*     */     } 
/* 699 */     for (T element : iterable) {
/* 700 */       if (skipNulls && element == null)
/* 701 */         continue;  if (checkNulls) Objects.requireNonNull(element, "element"); 
/* 702 */       list.add(element);
/*     */     } 
/* 704 */     return list;
/*     */   }
/*     */   
/*     */   private static <T> List<T> createUnmodifiableList(boolean clone, List<T> list) {
/* 708 */     switch (list.size()) { case 0:
/* 709 */         return Collections.emptyList();
/* 710 */       case 1: return Collections.singletonList(list.get(0)); }
/*     */     
/* 712 */     if (clone) {
/* 713 */       return Collections.unmodifiableList(new ArrayList<>(list));
/*     */     }
/* 715 */     if (list instanceof ArrayList) {
/* 716 */       ((ArrayList)list).trimToSize();
/*     */     }
/* 718 */     return Collections.unmodifiableList(list);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableAuditLogData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */