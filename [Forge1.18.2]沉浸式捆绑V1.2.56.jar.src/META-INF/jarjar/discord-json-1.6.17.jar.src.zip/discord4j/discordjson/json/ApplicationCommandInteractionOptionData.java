/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import java.util.List;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ @JsonSerialize(as = ImmutableApplicationCommandInteractionOptionData.class)
/*    */ @JsonDeserialize(as = ImmutableApplicationCommandInteractionOptionData.class)
/*    */ @Immutable
/*    */ public interface ApplicationCommandInteractionOptionData
/*    */ {
/*    */   static ImmutableApplicationCommandInteractionOptionData.Builder builder() {
/* 16 */     return ImmutableApplicationCommandInteractionOptionData.builder();
/*    */   }
/*    */   
/*    */   String name();
/*    */   
/*    */   Possible<String> value();
/*    */   
/*    */   int type();
/*    */   
/*    */   Possible<List<ApplicationCommandInteractionOptionData>> options();
/*    */   
/*    */   Possible<Boolean> focused();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ApplicationCommandInteractionOptionData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */