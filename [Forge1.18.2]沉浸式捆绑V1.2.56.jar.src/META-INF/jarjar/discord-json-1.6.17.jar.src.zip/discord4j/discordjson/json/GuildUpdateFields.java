package discord4j.discordjson.json;

import com.fasterxml.jackson.annotation.JsonProperty;
import discord4j.discordjson.Id;
import discord4j.discordjson.possible.Possible;
import java.util.Optional;

public interface GuildUpdateFields extends GuildFields, GuildVerificationLevelField, GuildNsfwLevelField {
  @JsonProperty("owner_id")
  Id ownerId();
  
  Possible<Optional<String>> region();
  
  @JsonProperty("afk_timeout")
  int afkTimeout();
  
  @JsonProperty("default_message_notifications")
  int defaultMessageNotifications();
  
  @JsonProperty("explicit_content_filter")
  int explicitContentFilter();
  
  @JsonProperty("mfa_level")
  int mfaLevel();
  
  @JsonProperty("premium_tier")
  int premiumTier();
  
  @JsonProperty("preferred_locale")
  String preferredLocale();
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\GuildUpdateFields.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */