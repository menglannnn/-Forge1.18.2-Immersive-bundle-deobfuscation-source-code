/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.Id;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import java.util.List;
/*    */ import java.util.Optional;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ @JsonSerialize(as = ImmutablePartialMemberData.class)
/*    */ @JsonDeserialize(as = ImmutablePartialMemberData.class)
/*    */ @Immutable
/*    */ public interface PartialMemberData
/*    */ {
/*    */   static ImmutablePartialMemberData.Builder builder() {
/* 19 */     return ImmutablePartialMemberData.builder();
/*    */   }
/*    */ 
/*    */   
/*    */   Possible<Optional<String>> nick();
/*    */   
/*    */   Optional<String> avatar();
/*    */   
/*    */   List<Id> roles();
/*    */   
/*    */   @JsonProperty("joined_at")
/*    */   Optional<String> joinedAt();
/*    */   
/*    */   @JsonProperty("premium_since")
/*    */   Possible<Optional<String>> premiumSince();
/*    */   
/*    */   @JsonProperty("hoisted_role")
/*    */   Optional<String> hoistedRole();
/*    */   
/*    */   boolean deaf();
/*    */   
/*    */   boolean mute();
/*    */   
/*    */   @JsonProperty("communication_disabled_until")
/*    */   Possible<Optional<String>> communicationDisabledUntil();
/*    */   
/*    */   default long flags() {
/* 46 */     return 0L;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\PartialMemberData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */