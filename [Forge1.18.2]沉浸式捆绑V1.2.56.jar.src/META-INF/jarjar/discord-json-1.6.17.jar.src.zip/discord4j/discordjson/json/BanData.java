/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import java.util.Optional;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ @JsonSerialize(as = ImmutableBanData.class)
/*    */ @JsonDeserialize(as = ImmutableBanData.class)
/*    */ @Immutable
/*    */ public interface BanData
/*    */ {
/*    */   static ImmutableBanData.Builder builder() {
/* 15 */     return ImmutableBanData.builder();
/*    */   }
/*    */   
/*    */   Optional<String> reason();
/*    */   
/*    */   UserData user();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\BanData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */