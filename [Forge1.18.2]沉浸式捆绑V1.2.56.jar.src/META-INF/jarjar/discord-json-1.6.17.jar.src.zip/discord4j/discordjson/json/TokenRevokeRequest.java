/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ @Immutable
/*    */ public abstract class TokenRevokeRequest
/*    */ {
/*    */   public static ImmutableTokenRevokeRequest.Builder builder() {
/*  9 */     return ImmutableTokenRevokeRequest.builder();
/*    */   }
/*    */ 
/*    */   
/*    */   public abstract long clientId();
/*    */   
/*    */   public abstract String clientSecret();
/*    */   
/*    */   public abstract String token();
/*    */   
/*    */   public String toString() {
/* 20 */     return "token=" + token();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\TokenRevokeRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */