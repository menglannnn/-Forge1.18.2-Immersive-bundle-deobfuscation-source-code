/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.Id;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "MessageReferenceData", generator = "Immutables")
/*     */ public final class ImmutableMessageReferenceData
/*     */   implements MessageReferenceData
/*     */ {
/*     */   private final long messageId_value;
/*     */   private final boolean messageId_absent;
/*     */   private final long channelId_value;
/*     */   private final boolean channelId_absent;
/*     */   private final long guildId_value;
/*     */   private final boolean guildId_absent;
/*     */   private final Boolean failIfNotExists_value;
/*     */   private final boolean failIfNotExists_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private ImmutableMessageReferenceData(Possible<Id> messageId, Possible<Id> channelId, Possible<Id> guildId, Possible<Boolean> failIfNotExists) {
/*  40 */     Possible<Id> messageId$impl = messageId;
/*  41 */     Possible<Id> channelId$impl = channelId;
/*  42 */     Possible<Id> guildId$impl = guildId;
/*  43 */     Possible<Boolean> failIfNotExists$impl = failIfNotExists;
/*  44 */     this
/*     */       
/*  46 */       .messageId_value = ((Long)messageId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  47 */     this.messageId_absent = messageId$impl.isAbsent();
/*  48 */     this
/*     */       
/*  50 */       .channelId_value = ((Long)channelId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  51 */     this.channelId_absent = channelId$impl.isAbsent();
/*  52 */     this
/*     */       
/*  54 */       .guildId_value = ((Long)guildId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  55 */     this.guildId_absent = guildId$impl.isAbsent();
/*  56 */     this.failIfNotExists_value = failIfNotExists$impl.toOptional().orElse(null);
/*  57 */     this.failIfNotExists_absent = failIfNotExists$impl.isAbsent();
/*  58 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableMessageReferenceData(ImmutableMessageReferenceData original, Possible<Id> messageId, Possible<Id> channelId, Possible<Id> guildId, Possible<Boolean> failIfNotExists) {
/*  67 */     Possible<Id> messageId$impl = messageId;
/*  68 */     Possible<Id> channelId$impl = channelId;
/*  69 */     Possible<Id> guildId$impl = guildId;
/*  70 */     Possible<Boolean> failIfNotExists$impl = failIfNotExists;
/*  71 */     this
/*     */       
/*  73 */       .messageId_value = ((Long)messageId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  74 */     this.messageId_absent = messageId$impl.isAbsent();
/*  75 */     this
/*     */       
/*  77 */       .channelId_value = ((Long)channelId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  78 */     this.channelId_absent = channelId$impl.isAbsent();
/*  79 */     this
/*     */       
/*  81 */       .guildId_value = ((Long)guildId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  82 */     this.guildId_absent = guildId$impl.isAbsent();
/*  83 */     this.failIfNotExists_value = failIfNotExists$impl.toOptional().orElse(null);
/*  84 */     this.failIfNotExists_absent = failIfNotExists$impl.isAbsent();
/*  85 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  91 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "MessageReferenceData", generator = "Immutables")
/*     */   private final class InitShim {
/*     */     private String formatInitCycleMessage() {
/*  96 */       List<String> attributes = new ArrayList<>();
/*  97 */       return "Cannot build MessageReferenceData, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @JsonProperty("message_id")
/*     */   public Possible<Id> messageId() {
/* 107 */     return this.messageId_absent ? Possible.absent() : 
/* 108 */       Possible.of(Id.of(this.messageId_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("channel_id")
/*     */   public Possible<Id> channelId() {
/* 117 */     return this.channelId_absent ? Possible.absent() : 
/* 118 */       Possible.of(Id.of(this.channelId_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("guild_id")
/*     */   public Possible<Id> guildId() {
/* 127 */     return this.guildId_absent ? Possible.absent() : 
/* 128 */       Possible.of(Id.of(this.guildId_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("fail_if_not_exists")
/*     */   public Possible<Boolean> failIfNotExists() {
/* 137 */     return this.failIfNotExists_absent ? Possible.absent() : Possible.of(this.failIfNotExists_value);
/*     */   }
/*     */   
/*     */   public ImmutableMessageReferenceData withMessageId(Possible<Id> value) {
/* 141 */     Possible<Id> newValue = Objects.<Possible<Id>>requireNonNull(value);
/* 142 */     return new ImmutableMessageReferenceData(this, newValue, channelId(), guildId(), failIfNotExists());
/*     */   }
/*     */   
/*     */   public ImmutableMessageReferenceData withMessageId(long value) {
/* 146 */     Possible<Id> newValue = Possible.of(Id.of(value));
/* 147 */     return new ImmutableMessageReferenceData(this, newValue, channelId(), guildId(), failIfNotExists());
/*     */   }
/*     */   
/*     */   public ImmutableMessageReferenceData withChannelId(Possible<Id> value) {
/* 151 */     Possible<Id> newValue = Objects.<Possible<Id>>requireNonNull(value);
/* 152 */     return new ImmutableMessageReferenceData(this, messageId(), newValue, guildId(), failIfNotExists());
/*     */   }
/*     */   
/*     */   public ImmutableMessageReferenceData withChannelId(long value) {
/* 156 */     Possible<Id> newValue = Possible.of(Id.of(value));
/* 157 */     return new ImmutableMessageReferenceData(this, messageId(), newValue, guildId(), failIfNotExists());
/*     */   }
/*     */   
/*     */   public ImmutableMessageReferenceData withGuildId(Possible<Id> value) {
/* 161 */     Possible<Id> newValue = Objects.<Possible<Id>>requireNonNull(value);
/* 162 */     return new ImmutableMessageReferenceData(this, messageId(), channelId(), newValue, failIfNotExists());
/*     */   }
/*     */   
/*     */   public ImmutableMessageReferenceData withGuildId(long value) {
/* 166 */     Possible<Id> newValue = Possible.of(Id.of(value));
/* 167 */     return new ImmutableMessageReferenceData(this, messageId(), channelId(), newValue, failIfNotExists());
/*     */   }
/*     */   
/*     */   public ImmutableMessageReferenceData withFailIfNotExists(Possible<Boolean> value) {
/* 171 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 172 */     return new ImmutableMessageReferenceData(this, messageId(), channelId(), guildId(), newValue);
/*     */   }
/*     */   
/*     */   public ImmutableMessageReferenceData withFailIfNotExists(Boolean value) {
/* 176 */     Possible<Boolean> newValue = Possible.of(value);
/* 177 */     return new ImmutableMessageReferenceData(this, messageId(), channelId(), guildId(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 186 */     if (this == another) return true; 
/* 187 */     return (another instanceof ImmutableMessageReferenceData && 
/* 188 */       equalTo(0, (ImmutableMessageReferenceData)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableMessageReferenceData another) {
/* 192 */     return (messageId().equals(another.messageId()) && 
/* 193 */       channelId().equals(another.channelId()) && 
/* 194 */       guildId().equals(another.guildId()) && 
/* 195 */       failIfNotExists().equals(another.failIfNotExists()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 204 */     int h = 5381;
/* 205 */     h += (h << 5) + messageId().hashCode();
/* 206 */     h += (h << 5) + channelId().hashCode();
/* 207 */     h += (h << 5) + guildId().hashCode();
/* 208 */     h += (h << 5) + failIfNotExists().hashCode();
/* 209 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 218 */     return "MessageReferenceData{messageId=" + 
/* 219 */       messageId().toString() + ", channelId=" + 
/* 220 */       channelId().toString() + ", guildId=" + 
/* 221 */       guildId().toString() + ", failIfNotExists=" + 
/* 222 */       failIfNotExists().toString() + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "MessageReferenceData", generator = "Immutables")
/*     */   static final class Json
/*     */     implements MessageReferenceData
/*     */   {
/* 236 */     Possible<Id> messageId = Possible.absent();
/*     */ 
/*     */     
/* 239 */     Possible<Id> channelId = Possible.absent();
/*     */ 
/*     */     
/* 242 */     Possible<Id> guildId = Possible.absent();
/*     */ 
/*     */     
/* 245 */     Possible<Boolean> failIfNotExists = Possible.absent();
/*     */     
/*     */     @JsonProperty("message_id")
/*     */     public void setMessageId(Possible<Id> messageId) {
/* 249 */       this.messageId = messageId;
/*     */     }
/*     */     @JsonProperty("channel_id")
/*     */     public void setChannelId(Possible<Id> channelId) {
/* 253 */       this.channelId = channelId;
/*     */     }
/*     */     @JsonProperty("guild_id")
/*     */     public void setGuildId(Possible<Id> guildId) {
/* 257 */       this.guildId = guildId;
/*     */     }
/*     */     @JsonProperty("fail_if_not_exists")
/*     */     public void setFailIfNotExists(Possible<Boolean> failIfNotExists) {
/* 261 */       this.failIfNotExists = failIfNotExists;
/*     */     }
/*     */     public Possible<Id> messageId() {
/* 264 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Id> channelId() {
/* 266 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Id> guildId() {
/* 268 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Boolean> failIfNotExists() {
/* 270 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableMessageReferenceData fromJson(Json json) {
/* 281 */     Builder builder = builder();
/* 282 */     if (json.messageId != null) {
/* 283 */       builder.messageId(json.messageId);
/*     */     }
/* 285 */     if (json.channelId != null) {
/* 286 */       builder.channelId(json.channelId);
/*     */     }
/* 288 */     if (json.guildId != null) {
/* 289 */       builder.guildId(json.guildId);
/*     */     }
/* 291 */     if (json.failIfNotExists != null) {
/* 292 */       builder.failIfNotExists(json.failIfNotExists);
/*     */     }
/* 294 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableMessageReferenceData of(Possible<Id> messageId, Possible<Id> channelId, Possible<Id> guildId, Possible<Boolean> failIfNotExists) {
/* 306 */     return new ImmutableMessageReferenceData(messageId, channelId, guildId, failIfNotExists);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableMessageReferenceData copyOf(MessageReferenceData instance) {
/* 317 */     if (instance instanceof ImmutableMessageReferenceData) {
/* 318 */       return (ImmutableMessageReferenceData)instance;
/*     */     }
/* 320 */     return builder()
/* 321 */       .from(instance)
/* 322 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isMessageIdPresent() {
/* 326 */     return !this.messageId_absent;
/*     */   }
/*     */   
/*     */   public long messageIdOrElse(long defaultValue) {
/* 330 */     return !this.messageId_absent ? this.messageId_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isChannelIdPresent() {
/* 334 */     return !this.channelId_absent;
/*     */   }
/*     */   
/*     */   public long channelIdOrElse(long defaultValue) {
/* 338 */     return !this.channelId_absent ? this.channelId_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isGuildIdPresent() {
/* 342 */     return !this.guildId_absent;
/*     */   }
/*     */   
/*     */   public long guildIdOrElse(long defaultValue) {
/* 346 */     return !this.guildId_absent ? this.guildId_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isFailIfNotExistsPresent() {
/* 350 */     return !this.failIfNotExists_absent;
/*     */   }
/*     */   
/*     */   public Boolean failIfNotExistsOrElse(Boolean defaultValue) {
/* 354 */     return !this.failIfNotExists_absent ? this.failIfNotExists_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 370 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "MessageReferenceData", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/* 382 */     private Possible<Id> messageId_possible = Possible.absent();
/* 383 */     private Possible<Id> channelId_possible = Possible.absent();
/* 384 */     private Possible<Id> guildId_possible = Possible.absent();
/* 385 */     private Possible<Boolean> failIfNotExists_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(MessageReferenceData instance) {
/* 398 */       Objects.requireNonNull(instance, "instance");
/* 399 */       messageId(instance.messageId());
/* 400 */       channelId(instance.channelId());
/* 401 */       guildId(instance.guildId());
/* 402 */       failIfNotExists(instance.failIfNotExists());
/* 403 */       return this;
/*     */     }
/*     */     
/*     */     public Builder messageId(String value) {
/* 407 */       this.messageId_possible = Possible.of(Id.of(value));
/* 408 */       return this;
/*     */     }
/*     */     
/*     */     public Builder messageId(long value) {
/* 412 */       this.messageId_possible = Possible.of(Id.of(value));
/* 413 */       return this;
/*     */     }
/*     */     
/*     */     public Builder messageId(Id value) {
/* 417 */       this.messageId_possible = Possible.of(value);
/* 418 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("message_id")
/*     */     public Builder messageId(Possible<Id> value) {
/* 423 */       this.messageId_possible = value;
/* 424 */       return this;
/*     */     }
/*     */     
/*     */     public Builder channelId(String value) {
/* 428 */       this.channelId_possible = Possible.of(Id.of(value));
/* 429 */       return this;
/*     */     }
/*     */     
/*     */     public Builder channelId(long value) {
/* 433 */       this.channelId_possible = Possible.of(Id.of(value));
/* 434 */       return this;
/*     */     }
/*     */     
/*     */     public Builder channelId(Id value) {
/* 438 */       this.channelId_possible = Possible.of(value);
/* 439 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("channel_id")
/*     */     public Builder channelId(Possible<Id> value) {
/* 444 */       this.channelId_possible = value;
/* 445 */       return this;
/*     */     }
/*     */     
/*     */     public Builder guildId(String value) {
/* 449 */       this.guildId_possible = Possible.of(Id.of(value));
/* 450 */       return this;
/*     */     }
/*     */     
/*     */     public Builder guildId(long value) {
/* 454 */       this.guildId_possible = Possible.of(Id.of(value));
/* 455 */       return this;
/*     */     }
/*     */     
/*     */     public Builder guildId(Id value) {
/* 459 */       this.guildId_possible = Possible.of(value);
/* 460 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("guild_id")
/*     */     public Builder guildId(Possible<Id> value) {
/* 465 */       this.guildId_possible = value;
/* 466 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("fail_if_not_exists")
/*     */     public Builder failIfNotExists(Possible<Boolean> value) {
/* 471 */       this.failIfNotExists_possible = value;
/* 472 */       return this;
/*     */     }
/*     */     
/*     */     public Builder failIfNotExists(Boolean value) {
/* 476 */       this.failIfNotExists_possible = Possible.of(value);
/* 477 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableMessageReferenceData build() {
/* 486 */       return new ImmutableMessageReferenceData(null, messageId_build(), channelId_build(), guildId_build(), failIfNotExists_build());
/*     */     }
/*     */     
/*     */     private Possible<Id> messageId_build() {
/* 490 */       return this.messageId_possible;
/*     */     }
/*     */     
/*     */     private Possible<Id> channelId_build() {
/* 494 */       return this.channelId_possible;
/*     */     }
/*     */     
/*     */     private Possible<Id> guildId_build() {
/* 498 */       return this.guildId_possible;
/*     */     }
/*     */     
/*     */     private Possible<Boolean> failIfNotExists_build() {
/* 502 */       return this.failIfNotExists_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableMessageReferenceData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */