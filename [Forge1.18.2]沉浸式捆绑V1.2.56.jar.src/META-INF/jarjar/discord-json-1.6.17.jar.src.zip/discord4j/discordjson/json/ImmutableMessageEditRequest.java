/*      */ package discord4j.discordjson.json;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*      */ import com.fasterxml.jackson.annotation.JsonCreator;
/*      */ import com.fasterxml.jackson.annotation.JsonProperty;
/*      */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*      */ import discord4j.discordjson.possible.Possible;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import java.util.Optional;
/*      */ import java.util.stream.Collectors;
/*      */ import java.util.stream.StreamSupport;
/*      */ import org.immutables.value.Generated;
/*      */ import reactor.util.annotation.Nullable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Generated(from = "MessageEditRequest", generator = "Immutables")
/*      */ public final class ImmutableMessageEditRequest
/*      */   implements MessageEditRequest
/*      */ {
/*      */   private final String content_value;
/*      */   private final boolean content_absent;
/*      */   private final EmbedData embed_value;
/*      */   private final boolean embed_absent;
/*      */   private final List<EmbedData> embeds_value;
/*      */   private final boolean embeds_absent;
/*      */   private final Integer flags_value;
/*      */   private final boolean flags_absent;
/*      */   private final AllowedMentionsData allowedMentions_value;
/*      */   private final boolean allowedMentions_absent;
/*      */   private final List<AttachmentData> attachments_value;
/*      */   private final boolean attachments_absent;
/*      */   private final List<ComponentData> components_value;
/*      */   private final boolean components_absent;
/*      */   private static final byte STAGE_INITIALIZING = -1;
/*      */   private static final byte STAGE_UNINITIALIZED = 0;
/*      */   private static final byte STAGE_INITIALIZED = 1;
/*      */   
/*      */   private ImmutableMessageEditRequest(Possible<Optional<String>> content, Possible<Optional<EmbedData>> embed, Possible<Optional<List<EmbedData>>> embeds, Possible<Optional<Integer>> flags, Possible<Optional<AllowedMentionsData>> allowedMentions, Possible<Optional<List<AttachmentData>>> attachments, Possible<Optional<List<ComponentData>>> components) {
/*   50 */     Possible<Optional<String>> content$impl = content;
/*   51 */     Possible<Optional<EmbedData>> embed$impl = embed;
/*   52 */     Possible<Optional<List<EmbedData>>> embeds$impl = embeds;
/*   53 */     Possible<Optional<Integer>> flags$impl = flags;
/*   54 */     Possible<Optional<AllowedMentionsData>> allowedMentions$impl = allowedMentions;
/*   55 */     Possible<Optional<List<AttachmentData>>> attachments$impl = attachments;
/*   56 */     Possible<Optional<List<ComponentData>>> components$impl = components;
/*   57 */     this.content_value = Possible.flatOpt(content$impl).orElse(null);
/*   58 */     this.content_absent = content$impl.isAbsent();
/*   59 */     this.embed_value = Possible.flatOpt(embed$impl).orElse(null);
/*   60 */     this.embed_absent = embed$impl.isAbsent();
/*   61 */     this.embeds_value = Possible.flatOpt(embeds$impl).orElse(null);
/*   62 */     this.embeds_absent = embeds$impl.isAbsent();
/*   63 */     this.flags_value = Possible.flatOpt(flags$impl).orElse(null);
/*   64 */     this.flags_absent = flags$impl.isAbsent();
/*   65 */     this.allowedMentions_value = Possible.flatOpt(allowedMentions$impl).orElse(null);
/*   66 */     this.allowedMentions_absent = allowedMentions$impl.isAbsent();
/*   67 */     this.attachments_value = Possible.flatOpt(attachments$impl).orElse(null);
/*   68 */     this.attachments_absent = attachments$impl.isAbsent();
/*   69 */     this.components_value = Possible.flatOpt(components$impl).orElse(null);
/*   70 */     this.components_absent = components$impl.isAbsent();
/*   71 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ImmutableMessageEditRequest(ImmutableMessageEditRequest original, Possible<Optional<String>> content, Possible<Optional<EmbedData>> embed, Possible<Optional<List<EmbedData>>> embeds, Possible<Optional<Integer>> flags, Possible<Optional<AllowedMentionsData>> allowedMentions, Possible<Optional<List<AttachmentData>>> attachments, Possible<Optional<List<ComponentData>>> components) {
/*   83 */     Possible<Optional<String>> content$impl = content;
/*   84 */     Possible<Optional<EmbedData>> embed$impl = embed;
/*   85 */     Possible<Optional<List<EmbedData>>> embeds$impl = embeds;
/*   86 */     Possible<Optional<Integer>> flags$impl = flags;
/*   87 */     Possible<Optional<AllowedMentionsData>> allowedMentions$impl = allowedMentions;
/*   88 */     Possible<Optional<List<AttachmentData>>> attachments$impl = attachments;
/*   89 */     Possible<Optional<List<ComponentData>>> components$impl = components;
/*   90 */     this.content_value = Possible.flatOpt(content$impl).orElse(null);
/*   91 */     this.content_absent = content$impl.isAbsent();
/*   92 */     this.embed_value = Possible.flatOpt(embed$impl).orElse(null);
/*   93 */     this.embed_absent = embed$impl.isAbsent();
/*   94 */     this.embeds_value = Possible.flatOpt(embeds$impl).orElse(null);
/*   95 */     this.embeds_absent = embeds$impl.isAbsent();
/*   96 */     this.flags_value = Possible.flatOpt(flags$impl).orElse(null);
/*   97 */     this.flags_absent = flags$impl.isAbsent();
/*   98 */     this.allowedMentions_value = Possible.flatOpt(allowedMentions$impl).orElse(null);
/*   99 */     this.allowedMentions_absent = allowedMentions$impl.isAbsent();
/*  100 */     this.attachments_value = Possible.flatOpt(attachments$impl).orElse(null);
/*  101 */     this.attachments_absent = attachments$impl.isAbsent();
/*  102 */     this.components_value = Possible.flatOpt(components$impl).orElse(null);
/*  103 */     this.components_absent = components$impl.isAbsent();
/*  104 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  110 */   private volatile transient InitShim initShim = new InitShim();
/*      */   
/*      */   @Generated(from = "MessageEditRequest", generator = "Immutables")
/*      */   private final class InitShim {
/*      */     private String formatInitCycleMessage() {
/*  115 */       List<String> attributes = new ArrayList<>();
/*  116 */       return "Cannot build MessageEditRequest, attribute initializers form cycle " + attributes;
/*      */     }
/*      */ 
/*      */     
/*      */     private InitShim() {}
/*      */   }
/*      */ 
/*      */   
/*      */   @JsonProperty("content")
/*      */   public Possible<Optional<String>> content() {
/*  126 */     return this.content_absent ? Possible.absent() : 
/*  127 */       Possible.of(Optional.ofNullable(this.content_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("embed")
/*      */   @Deprecated
/*      */   public Possible<Optional<EmbedData>> embed() {
/*  137 */     return this.embed_absent ? Possible.absent() : 
/*  138 */       Possible.of(Optional.ofNullable(this.embed_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("embeds")
/*      */   public Possible<Optional<List<EmbedData>>> embeds() {
/*  147 */     return this.embeds_absent ? Possible.absent() : 
/*  148 */       Possible.of(Optional.ofNullable(this.embeds_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("flags")
/*      */   public Possible<Optional<Integer>> flags() {
/*  157 */     return this.flags_absent ? Possible.absent() : 
/*  158 */       Possible.of(Optional.ofNullable(this.flags_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("allowed_mentions")
/*      */   public Possible<Optional<AllowedMentionsData>> allowedMentions() {
/*  167 */     return this.allowedMentions_absent ? Possible.absent() : 
/*  168 */       Possible.of(Optional.ofNullable(this.allowedMentions_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("attachments")
/*      */   public Possible<Optional<List<AttachmentData>>> attachments() {
/*  177 */     return this.attachments_absent ? Possible.absent() : 
/*  178 */       Possible.of(Optional.ofNullable(this.attachments_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("components")
/*      */   public Possible<Optional<List<ComponentData>>> components() {
/*  187 */     return this.components_absent ? Possible.absent() : 
/*  188 */       Possible.of(Optional.ofNullable(this.components_value));
/*      */   }
/*      */   
/*      */   public ImmutableMessageEditRequest withContent(Possible<Optional<String>> value) {
/*  192 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/*  193 */     return new ImmutableMessageEditRequest(this, newValue, 
/*      */ 
/*      */         
/*  196 */         embed(), 
/*  197 */         embeds(), 
/*  198 */         flags(), 
/*  199 */         allowedMentions(), 
/*  200 */         attachments(), 
/*  201 */         components());
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableMessageEditRequest withContent(@Nullable String value) {
/*  206 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  207 */     return new ImmutableMessageEditRequest(this, newValue, 
/*      */ 
/*      */         
/*  210 */         embed(), 
/*  211 */         embeds(), 
/*  212 */         flags(), 
/*  213 */         allowedMentions(), 
/*  214 */         attachments(), 
/*  215 */         components());
/*      */   }
/*      */   
/*      */   public ImmutableMessageEditRequest withContentOrNull(@Nullable String value) {
/*  219 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  220 */     return new ImmutableMessageEditRequest(this, newValue, 
/*      */ 
/*      */         
/*  223 */         embed(), 
/*  224 */         embeds(), 
/*  225 */         flags(), 
/*  226 */         allowedMentions(), 
/*  227 */         attachments(), 
/*  228 */         components());
/*      */   }
/*      */   
/*      */   public ImmutableMessageEditRequest withEmbed(Possible<Optional<EmbedData>> value) {
/*  232 */     Possible<Optional<EmbedData>> newValue = Objects.<Possible<Optional<EmbedData>>>requireNonNull(value);
/*  233 */     return new ImmutableMessageEditRequest(this, 
/*      */         
/*  235 */         content(), newValue, 
/*      */         
/*  237 */         embeds(), 
/*  238 */         flags(), 
/*  239 */         allowedMentions(), 
/*  240 */         attachments(), 
/*  241 */         components());
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableMessageEditRequest withEmbed(@Nullable EmbedData value) {
/*  246 */     Possible<Optional<EmbedData>> newValue = Possible.of(Optional.ofNullable(value));
/*  247 */     return new ImmutableMessageEditRequest(this, 
/*      */         
/*  249 */         content(), newValue, 
/*      */         
/*  251 */         embeds(), 
/*  252 */         flags(), 
/*  253 */         allowedMentions(), 
/*  254 */         attachments(), 
/*  255 */         components());
/*      */   }
/*      */   
/*      */   public ImmutableMessageEditRequest withEmbedOrNull(@Nullable EmbedData value) {
/*  259 */     Possible<Optional<EmbedData>> newValue = Possible.of(Optional.ofNullable(value));
/*  260 */     return new ImmutableMessageEditRequest(this, 
/*      */         
/*  262 */         content(), newValue, 
/*      */         
/*  264 */         embeds(), 
/*  265 */         flags(), 
/*  266 */         allowedMentions(), 
/*  267 */         attachments(), 
/*  268 */         components());
/*      */   }
/*      */   
/*      */   public ImmutableMessageEditRequest withEmbeds(Possible<Optional<List<EmbedData>>> possible) {
/*  272 */     Possible<Optional<List<EmbedData>>> newValue = Objects.<Possible<Optional<List<EmbedData>>>>requireNonNull(possible);
/*  273 */     return new ImmutableMessageEditRequest(this, 
/*      */         
/*  275 */         content(), 
/*  276 */         embed(), newValue, 
/*      */         
/*  278 */         flags(), 
/*  279 */         allowedMentions(), 
/*  280 */         attachments(), 
/*  281 */         components());
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableMessageEditRequest withEmbeds(@Nullable Iterable<EmbedData> elements) {
/*  286 */     Possible<Optional<List<EmbedData>>> newValue = Possible.of(Optional.<Iterable<EmbedData>>ofNullable(elements)
/*  287 */         .map(els -> (List)StreamSupport.stream(els.spliterator(), false).collect(Collectors.toList())));
/*  288 */     return new ImmutableMessageEditRequest(this, 
/*      */         
/*  290 */         content(), 
/*  291 */         embed(), newValue, 
/*      */         
/*  293 */         flags(), 
/*  294 */         allowedMentions(), 
/*  295 */         attachments(), 
/*  296 */         components());
/*      */   }
/*      */   
/*      */   public ImmutableMessageEditRequest withEmbedsOrNull(@Nullable Iterable<EmbedData> elements) {
/*  300 */     Possible<Optional<List<EmbedData>>> newValue = Possible.of(Optional.<Iterable<EmbedData>>ofNullable(elements)
/*  301 */         .map(els -> (List)StreamSupport.stream(els.spliterator(), false).collect(Collectors.toList())));
/*  302 */     return new ImmutableMessageEditRequest(this, 
/*      */         
/*  304 */         content(), 
/*  305 */         embed(), newValue, 
/*      */         
/*  307 */         flags(), 
/*  308 */         allowedMentions(), 
/*  309 */         attachments(), 
/*  310 */         components());
/*      */   }
/*      */   
/*      */   @SafeVarargs
/*      */   public final ImmutableMessageEditRequest withEmbeds(EmbedData... elements) {
/*  315 */     Possible<Optional<List<EmbedData>>> newValue = Possible.of(Optional.of(Arrays.asList(elements)));
/*  316 */     return new ImmutableMessageEditRequest(this, 
/*      */         
/*  318 */         content(), 
/*  319 */         embed(), newValue, 
/*      */         
/*  321 */         flags(), 
/*  322 */         allowedMentions(), 
/*  323 */         attachments(), 
/*  324 */         components());
/*      */   }
/*      */   
/*      */   public ImmutableMessageEditRequest withFlags(Possible<Optional<Integer>> value) {
/*  328 */     Possible<Optional<Integer>> newValue = Objects.<Possible<Optional<Integer>>>requireNonNull(value);
/*  329 */     return new ImmutableMessageEditRequest(this, 
/*      */         
/*  331 */         content(), 
/*  332 */         embed(), 
/*  333 */         embeds(), newValue, 
/*      */         
/*  335 */         allowedMentions(), 
/*  336 */         attachments(), 
/*  337 */         components());
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableMessageEditRequest withFlags(@Nullable Integer value) {
/*  342 */     Possible<Optional<Integer>> newValue = Possible.of(Optional.ofNullable(value));
/*  343 */     return new ImmutableMessageEditRequest(this, 
/*      */         
/*  345 */         content(), 
/*  346 */         embed(), 
/*  347 */         embeds(), newValue, 
/*      */         
/*  349 */         allowedMentions(), 
/*  350 */         attachments(), 
/*  351 */         components());
/*      */   }
/*      */   
/*      */   public ImmutableMessageEditRequest withFlagsOrNull(@Nullable Integer value) {
/*  355 */     Possible<Optional<Integer>> newValue = Possible.of(Optional.ofNullable(value));
/*  356 */     return new ImmutableMessageEditRequest(this, 
/*      */         
/*  358 */         content(), 
/*  359 */         embed(), 
/*  360 */         embeds(), newValue, 
/*      */         
/*  362 */         allowedMentions(), 
/*  363 */         attachments(), 
/*  364 */         components());
/*      */   }
/*      */   
/*      */   public ImmutableMessageEditRequest withAllowedMentions(Possible<Optional<AllowedMentionsData>> value) {
/*  368 */     Possible<Optional<AllowedMentionsData>> newValue = Objects.<Possible<Optional<AllowedMentionsData>>>requireNonNull(value);
/*  369 */     return new ImmutableMessageEditRequest(this, 
/*      */         
/*  371 */         content(), 
/*  372 */         embed(), 
/*  373 */         embeds(), 
/*  374 */         flags(), newValue, 
/*      */         
/*  376 */         attachments(), 
/*  377 */         components());
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableMessageEditRequest withAllowedMentions(@Nullable AllowedMentionsData value) {
/*  382 */     Possible<Optional<AllowedMentionsData>> newValue = Possible.of(Optional.ofNullable(value));
/*  383 */     return new ImmutableMessageEditRequest(this, 
/*      */         
/*  385 */         content(), 
/*  386 */         embed(), 
/*  387 */         embeds(), 
/*  388 */         flags(), newValue, 
/*      */         
/*  390 */         attachments(), 
/*  391 */         components());
/*      */   }
/*      */   
/*      */   public ImmutableMessageEditRequest withAllowedMentionsOrNull(@Nullable AllowedMentionsData value) {
/*  395 */     Possible<Optional<AllowedMentionsData>> newValue = Possible.of(Optional.ofNullable(value));
/*  396 */     return new ImmutableMessageEditRequest(this, 
/*      */         
/*  398 */         content(), 
/*  399 */         embed(), 
/*  400 */         embeds(), 
/*  401 */         flags(), newValue, 
/*      */         
/*  403 */         attachments(), 
/*  404 */         components());
/*      */   }
/*      */   
/*      */   public ImmutableMessageEditRequest withAttachments(Possible<Optional<List<AttachmentData>>> possible) {
/*  408 */     Possible<Optional<List<AttachmentData>>> newValue = Objects.<Possible<Optional<List<AttachmentData>>>>requireNonNull(possible);
/*  409 */     return new ImmutableMessageEditRequest(this, 
/*      */         
/*  411 */         content(), 
/*  412 */         embed(), 
/*  413 */         embeds(), 
/*  414 */         flags(), 
/*  415 */         allowedMentions(), newValue, 
/*      */         
/*  417 */         components());
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableMessageEditRequest withAttachments(@Nullable Iterable<AttachmentData> elements) {
/*  422 */     Possible<Optional<List<AttachmentData>>> newValue = Possible.of(Optional.<Iterable<AttachmentData>>ofNullable(elements)
/*  423 */         .map(els -> (List)StreamSupport.stream(els.spliterator(), false).collect(Collectors.toList())));
/*  424 */     return new ImmutableMessageEditRequest(this, 
/*      */         
/*  426 */         content(), 
/*  427 */         embed(), 
/*  428 */         embeds(), 
/*  429 */         flags(), 
/*  430 */         allowedMentions(), newValue, 
/*      */         
/*  432 */         components());
/*      */   }
/*      */   
/*      */   public ImmutableMessageEditRequest withAttachmentsOrNull(@Nullable Iterable<AttachmentData> elements) {
/*  436 */     Possible<Optional<List<AttachmentData>>> newValue = Possible.of(Optional.<Iterable<AttachmentData>>ofNullable(elements)
/*  437 */         .map(els -> (List)StreamSupport.stream(els.spliterator(), false).collect(Collectors.toList())));
/*  438 */     return new ImmutableMessageEditRequest(this, 
/*      */         
/*  440 */         content(), 
/*  441 */         embed(), 
/*  442 */         embeds(), 
/*  443 */         flags(), 
/*  444 */         allowedMentions(), newValue, 
/*      */         
/*  446 */         components());
/*      */   }
/*      */   
/*      */   @SafeVarargs
/*      */   public final ImmutableMessageEditRequest withAttachments(AttachmentData... elements) {
/*  451 */     Possible<Optional<List<AttachmentData>>> newValue = Possible.of(Optional.of(Arrays.asList(elements)));
/*  452 */     return new ImmutableMessageEditRequest(this, 
/*      */         
/*  454 */         content(), 
/*  455 */         embed(), 
/*  456 */         embeds(), 
/*  457 */         flags(), 
/*  458 */         allowedMentions(), newValue, 
/*      */         
/*  460 */         components());
/*      */   }
/*      */   
/*      */   public ImmutableMessageEditRequest withComponents(Possible<Optional<List<ComponentData>>> possible) {
/*  464 */     Possible<Optional<List<ComponentData>>> newValue = Objects.<Possible<Optional<List<ComponentData>>>>requireNonNull(possible);
/*  465 */     return new ImmutableMessageEditRequest(this, 
/*      */         
/*  467 */         content(), 
/*  468 */         embed(), 
/*  469 */         embeds(), 
/*  470 */         flags(), 
/*  471 */         allowedMentions(), 
/*  472 */         attachments(), newValue);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableMessageEditRequest withComponents(@Nullable Iterable<ComponentData> elements) {
/*  478 */     Possible<Optional<List<ComponentData>>> newValue = Possible.of(Optional.<Iterable<ComponentData>>ofNullable(elements)
/*  479 */         .map(els -> (List)StreamSupport.stream(els.spliterator(), false).collect(Collectors.toList())));
/*  480 */     return new ImmutableMessageEditRequest(this, 
/*      */         
/*  482 */         content(), 
/*  483 */         embed(), 
/*  484 */         embeds(), 
/*  485 */         flags(), 
/*  486 */         allowedMentions(), 
/*  487 */         attachments(), newValue);
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableMessageEditRequest withComponentsOrNull(@Nullable Iterable<ComponentData> elements) {
/*  492 */     Possible<Optional<List<ComponentData>>> newValue = Possible.of(Optional.<Iterable<ComponentData>>ofNullable(elements)
/*  493 */         .map(els -> (List)StreamSupport.stream(els.spliterator(), false).collect(Collectors.toList())));
/*  494 */     return new ImmutableMessageEditRequest(this, 
/*      */         
/*  496 */         content(), 
/*  497 */         embed(), 
/*  498 */         embeds(), 
/*  499 */         flags(), 
/*  500 */         allowedMentions(), 
/*  501 */         attachments(), newValue);
/*      */   }
/*      */ 
/*      */   
/*      */   @SafeVarargs
/*      */   public final ImmutableMessageEditRequest withComponents(ComponentData... elements) {
/*  507 */     Possible<Optional<List<ComponentData>>> newValue = Possible.of(Optional.of(Arrays.asList(elements)));
/*  508 */     return new ImmutableMessageEditRequest(this, 
/*      */         
/*  510 */         content(), 
/*  511 */         embed(), 
/*  512 */         embeds(), 
/*  513 */         flags(), 
/*  514 */         allowedMentions(), 
/*  515 */         attachments(), newValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object another) {
/*  525 */     if (this == another) return true; 
/*  526 */     return (another instanceof ImmutableMessageEditRequest && 
/*  527 */       equalTo(0, (ImmutableMessageEditRequest)another));
/*      */   }
/*      */   
/*      */   private boolean equalTo(int synthetic, ImmutableMessageEditRequest another) {
/*  531 */     return (content().equals(another.content()) && 
/*  532 */       embed().equals(another.embed()) && 
/*  533 */       Objects.equals(this.embeds_value, another.embeds_value) && 
/*  534 */       flags().equals(another.flags()) && 
/*  535 */       allowedMentions().equals(another.allowedMentions()) && 
/*  536 */       Objects.equals(this.attachments_value, another.attachments_value) && 
/*  537 */       Objects.equals(this.components_value, another.components_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/*  546 */     int h = 5381;
/*  547 */     h += (h << 5) + content().hashCode();
/*  548 */     h += (h << 5) + embed().hashCode();
/*  549 */     h += (h << 5) + Objects.hashCode(this.embeds_value);
/*  550 */     h += (h << 5) + flags().hashCode();
/*  551 */     h += (h << 5) + allowedMentions().hashCode();
/*  552 */     h += (h << 5) + Objects.hashCode(this.attachments_value);
/*  553 */     h += (h << 5) + Objects.hashCode(this.components_value);
/*  554 */     return h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*  563 */     return "MessageEditRequest{content=" + 
/*  564 */       content().toString() + ", embed=" + 
/*  565 */       embed().toString() + ", embeds=" + 
/*  566 */       Objects.toString(this.embeds_value) + ", flags=" + 
/*  567 */       flags().toString() + ", allowedMentions=" + 
/*  568 */       allowedMentions().toString() + ", attachments=" + 
/*  569 */       Objects.toString(this.attachments_value) + ", components=" + 
/*  570 */       Objects.toString(this.components_value) + "}";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonDeserialize
/*      */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*      */   @Generated(from = "MessageEditRequest", generator = "Immutables")
/*      */   static final class Json
/*      */     implements MessageEditRequest
/*      */   {
/*  584 */     Possible<Optional<String>> content = Possible.absent();
/*      */ 
/*      */     
/*  587 */     Possible<Optional<EmbedData>> embed = Possible.absent();
/*      */ 
/*      */     
/*  590 */     Possible<Optional<List<EmbedData>>> embeds = Possible.absent();
/*      */ 
/*      */     
/*  593 */     Possible<Optional<Integer>> flags = Possible.absent();
/*      */ 
/*      */     
/*  596 */     Possible<Optional<AllowedMentionsData>> allowedMentions = Possible.absent();
/*      */ 
/*      */     
/*  599 */     Possible<Optional<List<AttachmentData>>> attachments = Possible.absent();
/*      */ 
/*      */     
/*  602 */     Possible<Optional<List<ComponentData>>> components = Possible.absent();
/*      */     
/*      */     @JsonProperty("content")
/*      */     public void setContent(Possible<Optional<String>> content) {
/*  606 */       this.content = content;
/*      */     }
/*      */     @JsonProperty("embed")
/*      */     public void setEmbed(Possible<Optional<EmbedData>> embed) {
/*  610 */       this.embed = embed;
/*      */     }
/*      */     @JsonProperty("embeds")
/*      */     public void setEmbeds(Possible<Optional<List<EmbedData>>> embeds) {
/*  614 */       this.embeds = embeds;
/*      */     }
/*      */     @JsonProperty("flags")
/*      */     public void setFlags(Possible<Optional<Integer>> flags) {
/*  618 */       this.flags = flags;
/*      */     }
/*      */     @JsonProperty("allowed_mentions")
/*      */     public void setAllowedMentions(Possible<Optional<AllowedMentionsData>> allowedMentions) {
/*  622 */       this.allowedMentions = allowedMentions;
/*      */     }
/*      */     @JsonProperty("attachments")
/*      */     public void setAttachments(Possible<Optional<List<AttachmentData>>> attachments) {
/*  626 */       this.attachments = attachments;
/*      */     }
/*      */     @JsonProperty("components")
/*      */     public void setComponents(Possible<Optional<List<ComponentData>>> components) {
/*  630 */       this.components = components;
/*      */     }
/*      */     public Possible<Optional<String>> content() {
/*  633 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<EmbedData>> embed() {
/*  635 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<List<EmbedData>>> embeds() {
/*  637 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<Integer>> flags() {
/*  639 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<AllowedMentionsData>> allowedMentions() {
/*  641 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<List<AttachmentData>>> attachments() {
/*  643 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<List<ComponentData>>> components() {
/*  645 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*      */   static ImmutableMessageEditRequest fromJson(Json json) {
/*  656 */     Builder builder = builder();
/*  657 */     if (json.content != null) {
/*  658 */       builder.content(json.content);
/*      */     }
/*  660 */     if (json.embed != null) {
/*  661 */       builder.embed(json.embed);
/*      */     }
/*  663 */     if (json.embeds != null) {
/*  664 */       builder.embeds(json.embeds);
/*      */     }
/*  666 */     if (json.flags != null) {
/*  667 */       builder.flags(json.flags);
/*      */     }
/*  669 */     if (json.allowedMentions != null) {
/*  670 */       builder.allowedMentions(json.allowedMentions);
/*      */     }
/*  672 */     if (json.attachments != null) {
/*  673 */       builder.attachments(json.attachments);
/*      */     }
/*  675 */     if (json.components != null) {
/*  676 */       builder.components(json.components);
/*      */     }
/*  678 */     return builder.build();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableMessageEditRequest of(Possible<Optional<String>> content, Possible<Optional<EmbedData>> embed, Possible<Optional<List<EmbedData>>> embeds, Possible<Optional<Integer>> flags, Possible<Optional<AllowedMentionsData>> allowedMentions, Possible<Optional<List<AttachmentData>>> attachments, Possible<Optional<List<ComponentData>>> components) {
/*  693 */     return new ImmutableMessageEditRequest(content, embed, embeds, flags, allowedMentions, attachments, components);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableMessageEditRequest copyOf(MessageEditRequest instance) {
/*  704 */     if (instance instanceof ImmutableMessageEditRequest) {
/*  705 */       return (ImmutableMessageEditRequest)instance;
/*      */     }
/*  707 */     return builder()
/*  708 */       .from(instance)
/*  709 */       .build();
/*      */   }
/*      */   
/*      */   public boolean isContentPresent() {
/*  713 */     return !this.content_absent;
/*      */   }
/*      */   
/*      */   public String contentOrElse(String defaultValue) {
/*  717 */     return !this.content_absent ? this.content_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isEmbedPresent() {
/*  721 */     return !this.embed_absent;
/*      */   }
/*      */   
/*      */   public EmbedData embedOrElse(EmbedData defaultValue) {
/*  725 */     return !this.embed_absent ? this.embed_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isEmbedsPresent() {
/*  729 */     return !this.embeds_absent;
/*      */   }
/*      */   
/*      */   public List<EmbedData> embedsOrElse(List<EmbedData> defaultValue) {
/*  733 */     return !this.embeds_absent ? this.embeds_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isFlagsPresent() {
/*  737 */     return !this.flags_absent;
/*      */   }
/*      */   
/*      */   public Integer flagsOrElse(Integer defaultValue) {
/*  741 */     return !this.flags_absent ? this.flags_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isAllowedMentionsPresent() {
/*  745 */     return !this.allowedMentions_absent;
/*      */   }
/*      */   
/*      */   public AllowedMentionsData allowedMentionsOrElse(AllowedMentionsData defaultValue) {
/*  749 */     return !this.allowedMentions_absent ? this.allowedMentions_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isAttachmentsPresent() {
/*  753 */     return !this.attachments_absent;
/*      */   }
/*      */   
/*      */   public List<AttachmentData> attachmentsOrElse(List<AttachmentData> defaultValue) {
/*  757 */     return !this.attachments_absent ? this.attachments_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isComponentsPresent() {
/*  761 */     return !this.components_absent;
/*      */   }
/*      */   
/*      */   public List<ComponentData> componentsOrElse(List<ComponentData> defaultValue) {
/*  765 */     return !this.components_absent ? this.components_value : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Builder builder() {
/*  784 */     return new Builder();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Generated(from = "MessageEditRequest", generator = "Immutables")
/*      */   public static final class Builder
/*      */   {
/*  796 */     private Possible<Optional<String>> content_possible = Possible.absent();
/*  797 */     private Possible<Optional<EmbedData>> embed_possible = Possible.absent();
/*  798 */     private List<EmbedData> embeds_list = null;
/*      */     private boolean embeds_explicitNull;
/*  800 */     private Possible<Optional<Integer>> flags_possible = Possible.absent();
/*  801 */     private Possible<Optional<AllowedMentionsData>> allowedMentions_possible = Possible.absent();
/*  802 */     private List<AttachmentData> attachments_list = null;
/*      */     private boolean attachments_explicitNull;
/*  804 */     private List<ComponentData> components_list = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean components_explicitNull;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(MessageEditRequest instance) {
/*  818 */       Objects.requireNonNull(instance, "instance");
/*  819 */       content(instance.content());
/*  820 */       embed(instance.embed());
/*  821 */       embeds(instance.embeds());
/*  822 */       flags(instance.flags());
/*  823 */       allowedMentions(instance.allowedMentions());
/*  824 */       attachments(instance.attachments());
/*  825 */       components(instance.components());
/*  826 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("content")
/*      */     public Builder content(Possible<Optional<String>> value) {
/*  831 */       this.content_possible = value;
/*  832 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder content(@Nullable String value) {
/*  837 */       this.content_possible = Possible.of(Optional.ofNullable(value));
/*  838 */       return this;
/*      */     }
/*      */     
/*      */     public Builder contentOrNull(@Nullable String value) {
/*  842 */       this.content_possible = Possible.of(Optional.ofNullable(value));
/*  843 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("embed")
/*      */     public Builder embed(Possible<Optional<EmbedData>> value) {
/*  848 */       this.embed_possible = value;
/*  849 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder embed(@Nullable EmbedData value) {
/*  854 */       this.embed_possible = Possible.of(Optional.ofNullable(value));
/*  855 */       return this;
/*      */     }
/*      */     
/*      */     public Builder embedOrNull(@Nullable EmbedData value) {
/*  859 */       this.embed_possible = Possible.of(Optional.ofNullable(value));
/*  860 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addEmbed(EmbedData element) {
/*  864 */       embeds_getOrCreate().add(element);
/*  865 */       this.embeds_explicitNull = false;
/*  866 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addAllEmbeds(List<EmbedData> elements) {
/*  870 */       embeds_getOrCreate().addAll(elements);
/*  871 */       this.embeds_explicitNull = false;
/*  872 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("embeds")
/*      */     public Builder embeds(Possible<Optional<List<EmbedData>>> elements) {
/*  877 */       this.embeds_list = null;
/*  878 */       this.embeds_explicitNull = false;
/*  879 */       elements.toOptional().ifPresent(e -> {
/*      */             if (e.isPresent()) {
/*      */               embeds_getOrCreate().addAll(e.get());
/*      */             } else {
/*      */               this.embeds_explicitNull = true;
/*      */             } 
/*      */           });
/*  886 */       return this;
/*      */     }
/*      */     
/*      */     public Builder embeds(List<EmbedData> elements) {
/*  890 */       this.embeds_list = new ArrayList<>(elements);
/*  891 */       this.embeds_explicitNull = false;
/*  892 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder embeds(@Nullable Iterable<EmbedData> elements) {
/*  897 */       if (elements == null) {
/*  898 */         this.embeds_list = null;
/*  899 */         this.embeds_explicitNull = true;
/*      */       } else {
/*  901 */         this.embeds_list = (List<EmbedData>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/*  902 */         this.embeds_explicitNull = false;
/*      */       } 
/*  904 */       return this;
/*      */     }
/*      */     
/*      */     public Builder embedsOrNull(@Nullable Iterable<EmbedData> elements) {
/*  908 */       if (elements == null) {
/*  909 */         this.embeds_list = null;
/*  910 */         this.embeds_explicitNull = true;
/*      */       } else {
/*  912 */         this.embeds_list = (List<EmbedData>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/*  913 */         this.embeds_explicitNull = false;
/*      */       } 
/*  915 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("flags")
/*      */     public Builder flags(Possible<Optional<Integer>> value) {
/*  920 */       this.flags_possible = value;
/*  921 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder flags(@Nullable Integer value) {
/*  926 */       this.flags_possible = Possible.of(Optional.ofNullable(value));
/*  927 */       return this;
/*      */     }
/*      */     
/*      */     public Builder flagsOrNull(@Nullable Integer value) {
/*  931 */       this.flags_possible = Possible.of(Optional.ofNullable(value));
/*  932 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("allowed_mentions")
/*      */     public Builder allowedMentions(Possible<Optional<AllowedMentionsData>> value) {
/*  937 */       this.allowedMentions_possible = value;
/*  938 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder allowedMentions(@Nullable AllowedMentionsData value) {
/*  943 */       this.allowedMentions_possible = Possible.of(Optional.ofNullable(value));
/*  944 */       return this;
/*      */     }
/*      */     
/*      */     public Builder allowedMentionsOrNull(@Nullable AllowedMentionsData value) {
/*  948 */       this.allowedMentions_possible = Possible.of(Optional.ofNullable(value));
/*  949 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addAttachment(AttachmentData element) {
/*  953 */       attachments_getOrCreate().add(element);
/*  954 */       this.attachments_explicitNull = false;
/*  955 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addAllAttachments(List<AttachmentData> elements) {
/*  959 */       attachments_getOrCreate().addAll(elements);
/*  960 */       this.attachments_explicitNull = false;
/*  961 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("attachments")
/*      */     public Builder attachments(Possible<Optional<List<AttachmentData>>> elements) {
/*  966 */       this.attachments_list = null;
/*  967 */       this.attachments_explicitNull = false;
/*  968 */       elements.toOptional().ifPresent(e -> {
/*      */             if (e.isPresent()) {
/*      */               attachments_getOrCreate().addAll(e.get());
/*      */             } else {
/*      */               this.attachments_explicitNull = true;
/*      */             } 
/*      */           });
/*  975 */       return this;
/*      */     }
/*      */     
/*      */     public Builder attachments(List<AttachmentData> elements) {
/*  979 */       this.attachments_list = new ArrayList<>(elements);
/*  980 */       this.attachments_explicitNull = false;
/*  981 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder attachments(@Nullable Iterable<AttachmentData> elements) {
/*  986 */       if (elements == null) {
/*  987 */         this.attachments_list = null;
/*  988 */         this.attachments_explicitNull = true;
/*      */       } else {
/*  990 */         this.attachments_list = (List<AttachmentData>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/*  991 */         this.attachments_explicitNull = false;
/*      */       } 
/*  993 */       return this;
/*      */     }
/*      */     
/*      */     public Builder attachmentsOrNull(@Nullable Iterable<AttachmentData> elements) {
/*  997 */       if (elements == null) {
/*  998 */         this.attachments_list = null;
/*  999 */         this.attachments_explicitNull = true;
/*      */       } else {
/* 1001 */         this.attachments_list = (List<AttachmentData>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 1002 */         this.attachments_explicitNull = false;
/*      */       } 
/* 1004 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addComponent(ComponentData element) {
/* 1008 */       components_getOrCreate().add(element);
/* 1009 */       this.components_explicitNull = false;
/* 1010 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addAllComponents(List<ComponentData> elements) {
/* 1014 */       components_getOrCreate().addAll(elements);
/* 1015 */       this.components_explicitNull = false;
/* 1016 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("components")
/*      */     public Builder components(Possible<Optional<List<ComponentData>>> elements) {
/* 1021 */       this.components_list = null;
/* 1022 */       this.components_explicitNull = false;
/* 1023 */       elements.toOptional().ifPresent(e -> {
/*      */             if (e.isPresent()) {
/*      */               components_getOrCreate().addAll(e.get());
/*      */             } else {
/*      */               this.components_explicitNull = true;
/*      */             } 
/*      */           });
/* 1030 */       return this;
/*      */     }
/*      */     
/*      */     public Builder components(List<ComponentData> elements) {
/* 1034 */       this.components_list = new ArrayList<>(elements);
/* 1035 */       this.components_explicitNull = false;
/* 1036 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder components(@Nullable Iterable<ComponentData> elements) {
/* 1041 */       if (elements == null) {
/* 1042 */         this.components_list = null;
/* 1043 */         this.components_explicitNull = true;
/*      */       } else {
/* 1045 */         this.components_list = (List<ComponentData>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 1046 */         this.components_explicitNull = false;
/*      */       } 
/* 1048 */       return this;
/*      */     }
/*      */     
/*      */     public Builder componentsOrNull(@Nullable Iterable<ComponentData> elements) {
/* 1052 */       if (elements == null) {
/* 1053 */         this.components_list = null;
/* 1054 */         this.components_explicitNull = true;
/*      */       } else {
/* 1056 */         this.components_list = (List<ComponentData>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 1057 */         this.components_explicitNull = false;
/*      */       } 
/* 1059 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ImmutableMessageEditRequest build() {
/* 1068 */       return new ImmutableMessageEditRequest(null, 
/*      */           
/* 1070 */           content_build(), 
/* 1071 */           embed_build(), 
/* 1072 */           embeds_build(), 
/* 1073 */           flags_build(), 
/* 1074 */           allowedMentions_build(), 
/* 1075 */           attachments_build(), 
/* 1076 */           components_build());
/*      */     }
/*      */     
/*      */     private Possible<Optional<String>> content_build() {
/* 1080 */       return this.content_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<EmbedData>> embed_build() {
/* 1084 */       return this.embed_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<List<EmbedData>>> embeds_build() {
/* 1088 */       return (this.embeds_list == null && !this.embeds_explicitNull) ? Possible.absent() : 
/* 1089 */         Possible.of(Optional.ofNullable(this.embeds_list));
/*      */     }
/*      */     
/*      */     private List<EmbedData> embeds_getOrCreate() {
/* 1093 */       if (this.embeds_list == null) {
/* 1094 */         this.embeds_list = new ArrayList<>();
/*      */       }
/* 1096 */       return this.embeds_list;
/*      */     }
/*      */     
/*      */     private Possible<Optional<Integer>> flags_build() {
/* 1100 */       return this.flags_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<AllowedMentionsData>> allowedMentions_build() {
/* 1104 */       return this.allowedMentions_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<List<AttachmentData>>> attachments_build() {
/* 1108 */       return (this.attachments_list == null && !this.attachments_explicitNull) ? Possible.absent() : 
/* 1109 */         Possible.of(Optional.ofNullable(this.attachments_list));
/*      */     }
/*      */     
/*      */     private List<AttachmentData> attachments_getOrCreate() {
/* 1113 */       if (this.attachments_list == null) {
/* 1114 */         this.attachments_list = new ArrayList<>();
/*      */       }
/* 1116 */       return this.attachments_list;
/*      */     }
/*      */     
/*      */     private Possible<Optional<List<ComponentData>>> components_build() {
/* 1120 */       return (this.components_list == null && !this.components_explicitNull) ? Possible.absent() : 
/* 1121 */         Possible.of(Optional.ofNullable(this.components_list));
/*      */     }
/*      */     
/*      */     private List<ComponentData> components_getOrCreate() {
/* 1125 */       if (this.components_list == null) {
/* 1126 */         this.components_list = new ArrayList<>();
/*      */       }
/* 1128 */       return this.components_list;
/*      */     }
/*      */     
/*      */     private Builder() {}
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableMessageEditRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */