/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.Id;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import java.util.Optional;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ @JsonSerialize(as = ImmutableMessageApplicationData.class)
/*    */ @JsonDeserialize(as = ImmutableMessageApplicationData.class)
/*    */ @Immutable
/*    */ public interface MessageApplicationData
/*    */ {
/*    */   static ImmutableMessageApplicationData.Builder builder() {
/* 18 */     return ImmutableMessageApplicationData.builder();
/*    */   }
/*    */   
/*    */   Id id();
/*    */   
/*    */   @JsonProperty("cover_image")
/*    */   Possible<String> coverImage();
/*    */   
/*    */   String description();
/*    */   
/*    */   Optional<String> icon();
/*    */   
/*    */   String name();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\MessageApplicationData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */