/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.Id;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ @JsonSerialize(as = ImmutableGuildScheduledEventUserData.class)
/*    */ @JsonDeserialize(as = ImmutableGuildScheduledEventUserData.class)
/*    */ @Immutable
/*    */ public interface GuildScheduledEventUserData
/*    */ {
/*    */   static ImmutableGuildScheduledEventUserData.Builder builder() {
/* 16 */     return ImmutableGuildScheduledEventUserData.builder();
/*    */   }
/*    */   
/*    */   @JsonProperty("guild_scheduled_event_id")
/*    */   Id guildScheduledEventId();
/*    */   
/*    */   UserData user();
/*    */   
/*    */   Possible<PartialMemberData> member();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\GuildScheduledEventUserData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */