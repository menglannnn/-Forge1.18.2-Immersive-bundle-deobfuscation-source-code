/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.Id;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.StreamSupport;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "StickerPackData", generator = "Immutables")
/*     */ public final class ImmutableStickerPackData
/*     */   implements StickerPackData
/*     */ {
/*     */   private final long id_value;
/*     */   private final List<StickerData> stickers_value;
/*     */   private final boolean stickers_absent;
/*     */   private final String name;
/*     */   private final String description;
/*     */   private final long skuId_value;
/*     */   private final long coverStickerId_value;
/*     */   private final boolean coverStickerId_absent;
/*     */   private final long bannerAssetId_value;
/*     */   private final boolean bannerAssetId_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private ImmutableStickerPackData(Id id, Possible<List<StickerData>> stickers, String name, String description, Id skuId, Possible<Id> coverStickerId, Possible<Id> bannerAssetId) {
/*  48 */     Id id$impl = id;
/*  49 */     Possible<List<StickerData>> stickers$impl = stickers;
/*  50 */     this.name = Objects.<String>requireNonNull(name, "name");
/*  51 */     this.description = Objects.<String>requireNonNull(description, "description");
/*  52 */     Id skuId$impl = skuId;
/*  53 */     Possible<Id> coverStickerId$impl = coverStickerId;
/*  54 */     Possible<Id> bannerAssetId$impl = bannerAssetId;
/*  55 */     this.id_value = id$impl.asLong();
/*  56 */     this.stickers_value = stickers$impl.toOptional().orElse(null);
/*  57 */     this.stickers_absent = stickers$impl.isAbsent();
/*  58 */     this.skuId_value = skuId$impl.asLong();
/*  59 */     this
/*     */       
/*  61 */       .coverStickerId_value = ((Long)coverStickerId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  62 */     this.coverStickerId_absent = coverStickerId$impl.isAbsent();
/*  63 */     this
/*     */       
/*  65 */       .bannerAssetId_value = ((Long)bannerAssetId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  66 */     this.bannerAssetId_absent = bannerAssetId$impl.isAbsent();
/*  67 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableStickerPackData(ImmutableStickerPackData original, Id id, Possible<List<StickerData>> stickers, String name, String description, Id skuId, Possible<Id> coverStickerId, Possible<Id> bannerAssetId) {
/*  79 */     Id id$impl = id;
/*  80 */     Possible<List<StickerData>> stickers$impl = stickers;
/*  81 */     this.name = name;
/*  82 */     this.description = description;
/*  83 */     Id skuId$impl = skuId;
/*  84 */     Possible<Id> coverStickerId$impl = coverStickerId;
/*  85 */     Possible<Id> bannerAssetId$impl = bannerAssetId;
/*  86 */     this.id_value = id$impl.asLong();
/*  87 */     this.stickers_value = stickers$impl.toOptional().orElse(null);
/*  88 */     this.stickers_absent = stickers$impl.isAbsent();
/*  89 */     this.skuId_value = skuId$impl.asLong();
/*  90 */     this
/*     */       
/*  92 */       .coverStickerId_value = ((Long)coverStickerId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  93 */     this.coverStickerId_absent = coverStickerId$impl.isAbsent();
/*  94 */     this
/*     */       
/*  96 */       .bannerAssetId_value = ((Long)bannerAssetId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  97 */     this.bannerAssetId_absent = bannerAssetId$impl.isAbsent();
/*  98 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 104 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "StickerPackData", generator = "Immutables")
/*     */   private final class InitShim {
/*     */     private String formatInitCycleMessage() {
/* 109 */       List<String> attributes = new ArrayList<>();
/* 110 */       return "Cannot build StickerPackData, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @JsonProperty("id")
/*     */   public Id id() {
/* 120 */     return Id.of(this.id_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("stickers")
/*     */   public Possible<List<StickerData>> stickers() {
/* 129 */     return this.stickers_absent ? Possible.absent() : 
/* 130 */       Possible.of(this.stickers_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("name")
/*     */   public String name() {
/* 139 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("description")
/*     */   public String description() {
/* 148 */     return this.description;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("sku_id")
/*     */   public Id skuId() {
/* 157 */     return Id.of(this.skuId_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("cover_sticker_id")
/*     */   public Possible<Id> coverStickerId() {
/* 166 */     return this.coverStickerId_absent ? Possible.absent() : 
/* 167 */       Possible.of(Id.of(this.coverStickerId_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("banner_asset_id")
/*     */   public Possible<Id> bannerAssetId() {
/* 176 */     return this.bannerAssetId_absent ? Possible.absent() : 
/* 177 */       Possible.of(Id.of(this.bannerAssetId_value));
/*     */   }
/*     */   
/*     */   public ImmutableStickerPackData withId(long value) {
/* 181 */     Id newValue = Id.of(value);
/* 182 */     return new ImmutableStickerPackData(this, newValue, 
/*     */ 
/*     */         
/* 185 */         stickers(), this.name, this.description, 
/*     */ 
/*     */         
/* 188 */         skuId(), 
/* 189 */         coverStickerId(), 
/* 190 */         bannerAssetId());
/*     */   }
/*     */   
/*     */   public ImmutableStickerPackData withId(String value) {
/* 194 */     Id newValue = Id.of(value);
/* 195 */     return new ImmutableStickerPackData(this, newValue, 
/*     */ 
/*     */         
/* 198 */         stickers(), this.name, this.description, 
/*     */ 
/*     */         
/* 201 */         skuId(), 
/* 202 */         coverStickerId(), 
/* 203 */         bannerAssetId());
/*     */   }
/*     */   
/*     */   public ImmutableStickerPackData withStickers(Possible<List<StickerData>> possible) {
/* 207 */     Possible<List<StickerData>> newValue = Objects.<Possible<List<StickerData>>>requireNonNull(possible);
/* 208 */     return new ImmutableStickerPackData(this, 
/*     */         
/* 210 */         id(), newValue, this.name, this.description, 
/*     */ 
/*     */ 
/*     */         
/* 214 */         skuId(), 
/* 215 */         coverStickerId(), 
/* 216 */         bannerAssetId());
/*     */   }
/*     */   
/*     */   public ImmutableStickerPackData withStickers(Iterable<StickerData> elements) {
/* 220 */     Possible<List<StickerData>> newValue = Possible.of(
/* 221 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/* 222 */     return new ImmutableStickerPackData(this, 
/*     */         
/* 224 */         id(), newValue, this.name, this.description, 
/*     */ 
/*     */ 
/*     */         
/* 228 */         skuId(), 
/* 229 */         coverStickerId(), 
/* 230 */         bannerAssetId());
/*     */   }
/*     */   
/*     */   @SafeVarargs
/*     */   public final ImmutableStickerPackData withStickers(StickerData... elements) {
/* 235 */     Possible<List<StickerData>> newValue = Possible.of(Arrays.asList(elements));
/* 236 */     return new ImmutableStickerPackData(this, 
/*     */         
/* 238 */         id(), newValue, this.name, this.description, 
/*     */ 
/*     */ 
/*     */         
/* 242 */         skuId(), 
/* 243 */         coverStickerId(), 
/* 244 */         bannerAssetId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableStickerPackData withName(String value) {
/* 254 */     String newValue = Objects.<String>requireNonNull(value, "name");
/* 255 */     if (this.name.equals(newValue)) return this; 
/* 256 */     return new ImmutableStickerPackData(this, 
/*     */         
/* 258 */         id(), 
/* 259 */         stickers(), newValue, this.description, 
/*     */ 
/*     */         
/* 262 */         skuId(), 
/* 263 */         coverStickerId(), 
/* 264 */         bannerAssetId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableStickerPackData withDescription(String value) {
/* 274 */     String newValue = Objects.<String>requireNonNull(value, "description");
/* 275 */     if (this.description.equals(newValue)) return this; 
/* 276 */     return new ImmutableStickerPackData(this, 
/*     */         
/* 278 */         id(), 
/* 279 */         stickers(), this.name, newValue, 
/*     */ 
/*     */         
/* 282 */         skuId(), 
/* 283 */         coverStickerId(), 
/* 284 */         bannerAssetId());
/*     */   }
/*     */   
/*     */   public ImmutableStickerPackData withSkuId(long value) {
/* 288 */     Id newValue = Id.of(value);
/* 289 */     return new ImmutableStickerPackData(this, 
/*     */         
/* 291 */         id(), 
/* 292 */         stickers(), this.name, this.description, newValue, 
/*     */ 
/*     */ 
/*     */         
/* 296 */         coverStickerId(), 
/* 297 */         bannerAssetId());
/*     */   }
/*     */   
/*     */   public ImmutableStickerPackData withSkuId(String value) {
/* 301 */     Id newValue = Id.of(value);
/* 302 */     return new ImmutableStickerPackData(this, 
/*     */         
/* 304 */         id(), 
/* 305 */         stickers(), this.name, this.description, newValue, 
/*     */ 
/*     */ 
/*     */         
/* 309 */         coverStickerId(), 
/* 310 */         bannerAssetId());
/*     */   }
/*     */   
/*     */   public ImmutableStickerPackData withCoverStickerId(Possible<Id> value) {
/* 314 */     Possible<Id> newValue = Objects.<Possible<Id>>requireNonNull(value);
/* 315 */     return new ImmutableStickerPackData(this, 
/*     */         
/* 317 */         id(), 
/* 318 */         stickers(), this.name, this.description, 
/*     */ 
/*     */         
/* 321 */         skuId(), newValue, 
/*     */         
/* 323 */         bannerAssetId());
/*     */   }
/*     */   
/*     */   public ImmutableStickerPackData withCoverStickerId(long value) {
/* 327 */     Possible<Id> newValue = Possible.of(Id.of(value));
/* 328 */     return new ImmutableStickerPackData(this, 
/*     */         
/* 330 */         id(), 
/* 331 */         stickers(), this.name, this.description, 
/*     */ 
/*     */         
/* 334 */         skuId(), newValue, 
/*     */         
/* 336 */         bannerAssetId());
/*     */   }
/*     */   
/*     */   public ImmutableStickerPackData withBannerAssetId(Possible<Id> value) {
/* 340 */     Possible<Id> newValue = Objects.<Possible<Id>>requireNonNull(value);
/* 341 */     return new ImmutableStickerPackData(this, 
/*     */         
/* 343 */         id(), 
/* 344 */         stickers(), this.name, this.description, 
/*     */ 
/*     */         
/* 347 */         skuId(), 
/* 348 */         coverStickerId(), newValue);
/*     */   }
/*     */ 
/*     */   
/*     */   public ImmutableStickerPackData withBannerAssetId(long value) {
/* 353 */     Possible<Id> newValue = Possible.of(Id.of(value));
/* 354 */     return new ImmutableStickerPackData(this, 
/*     */         
/* 356 */         id(), 
/* 357 */         stickers(), this.name, this.description, 
/*     */ 
/*     */         
/* 360 */         skuId(), 
/* 361 */         coverStickerId(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 371 */     if (this == another) return true; 
/* 372 */     return (another instanceof ImmutableStickerPackData && 
/* 373 */       equalTo(0, (ImmutableStickerPackData)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableStickerPackData another) {
/* 377 */     return (Objects.equals(Long.valueOf(this.id_value), Long.valueOf(another.id_value)) && 
/* 378 */       Objects.equals(this.stickers_value, another.stickers_value) && this.name
/* 379 */       .equals(another.name) && this.description
/* 380 */       .equals(another.description) && 
/* 381 */       Objects.equals(Long.valueOf(this.skuId_value), Long.valueOf(another.skuId_value)) && 
/* 382 */       coverStickerId().equals(another.coverStickerId()) && 
/* 383 */       bannerAssetId().equals(another.bannerAssetId()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 392 */     int h = 5381;
/* 393 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.id_value));
/* 394 */     h += (h << 5) + Objects.hashCode(this.stickers_value);
/* 395 */     h += (h << 5) + this.name.hashCode();
/* 396 */     h += (h << 5) + this.description.hashCode();
/* 397 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.skuId_value));
/* 398 */     h += (h << 5) + coverStickerId().hashCode();
/* 399 */     h += (h << 5) + bannerAssetId().hashCode();
/* 400 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 409 */     return "StickerPackData{id=" + 
/* 410 */       Objects.toString(Long.valueOf(this.id_value)) + ", stickers=" + 
/* 411 */       Objects.toString(this.stickers_value) + ", name=" + this.name + ", description=" + this.description + ", skuId=" + 
/*     */ 
/*     */       
/* 414 */       Objects.toString(Long.valueOf(this.skuId_value)) + ", coverStickerId=" + 
/* 415 */       coverStickerId().toString() + ", bannerAssetId=" + 
/* 416 */       bannerAssetId().toString() + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "StickerPackData", generator = "Immutables")
/*     */   static final class Json
/*     */     implements StickerPackData
/*     */   {
/*     */     Id id;
/*     */ 
/*     */     
/* 431 */     Possible<List<StickerData>> stickers = Possible.absent();
/*     */     
/*     */     String name;
/*     */     
/*     */     String description;
/*     */     Id skuId;
/* 437 */     Possible<Id> coverStickerId = Possible.absent();
/*     */ 
/*     */     
/* 440 */     Possible<Id> bannerAssetId = Possible.absent();
/*     */     
/*     */     @JsonProperty("id")
/*     */     public void setId(Id id) {
/* 444 */       this.id = id;
/*     */     }
/*     */     @JsonProperty("stickers")
/*     */     public void setStickers(Possible<List<StickerData>> stickers) {
/* 448 */       this.stickers = stickers;
/*     */     }
/*     */     @JsonProperty("name")
/*     */     public void setName(String name) {
/* 452 */       this.name = name;
/*     */     }
/*     */     @JsonProperty("description")
/*     */     public void setDescription(String description) {
/* 456 */       this.description = description;
/*     */     }
/*     */     @JsonProperty("sku_id")
/*     */     public void setSkuId(Id skuId) {
/* 460 */       this.skuId = skuId;
/*     */     }
/*     */     @JsonProperty("cover_sticker_id")
/*     */     public void setCoverStickerId(Possible<Id> coverStickerId) {
/* 464 */       this.coverStickerId = coverStickerId;
/*     */     }
/*     */     @JsonProperty("banner_asset_id")
/*     */     public void setBannerAssetId(Possible<Id> bannerAssetId) {
/* 468 */       this.bannerAssetId = bannerAssetId;
/*     */     }
/*     */     public Id id() {
/* 471 */       throw new UnsupportedOperationException();
/*     */     } public Possible<List<StickerData>> stickers() {
/* 473 */       throw new UnsupportedOperationException();
/*     */     } public String name() {
/* 475 */       throw new UnsupportedOperationException();
/*     */     } public String description() {
/* 477 */       throw new UnsupportedOperationException();
/*     */     } public Id skuId() {
/* 479 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Id> coverStickerId() {
/* 481 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Id> bannerAssetId() {
/* 483 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableStickerPackData fromJson(Json json) {
/* 494 */     Builder builder = builder();
/* 495 */     if (json.id != null) {
/* 496 */       builder.id(json.id);
/*     */     }
/* 498 */     if (json.stickers != null) {
/* 499 */       builder.stickers(json.stickers);
/*     */     }
/* 501 */     if (json.name != null) {
/* 502 */       builder.name(json.name);
/*     */     }
/* 504 */     if (json.description != null) {
/* 505 */       builder.description(json.description);
/*     */     }
/* 507 */     if (json.skuId != null) {
/* 508 */       builder.skuId(json.skuId);
/*     */     }
/* 510 */     if (json.coverStickerId != null) {
/* 511 */       builder.coverStickerId(json.coverStickerId);
/*     */     }
/* 513 */     if (json.bannerAssetId != null) {
/* 514 */       builder.bannerAssetId(json.bannerAssetId);
/*     */     }
/* 516 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableStickerPackData of(Id id, Possible<List<StickerData>> stickers, String name, String description, Id skuId, Possible<Id> coverStickerId, Possible<Id> bannerAssetId) {
/* 531 */     return new ImmutableStickerPackData(id, stickers, name, description, skuId, coverStickerId, bannerAssetId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableStickerPackData copyOf(StickerPackData instance) {
/* 542 */     if (instance instanceof ImmutableStickerPackData) {
/* 543 */       return (ImmutableStickerPackData)instance;
/*     */     }
/* 545 */     return builder()
/* 546 */       .from(instance)
/* 547 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isStickersPresent() {
/* 551 */     return !this.stickers_absent;
/*     */   }
/*     */   
/*     */   public List<StickerData> stickersOrElse(List<StickerData> defaultValue) {
/* 555 */     return !this.stickers_absent ? this.stickers_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isCoverStickerIdPresent() {
/* 559 */     return !this.coverStickerId_absent;
/*     */   }
/*     */   
/*     */   public long coverStickerIdOrElse(long defaultValue) {
/* 563 */     return !this.coverStickerId_absent ? this.coverStickerId_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isBannerAssetIdPresent() {
/* 567 */     return !this.bannerAssetId_absent;
/*     */   }
/*     */   
/*     */   public long bannerAssetIdOrElse(long defaultValue) {
/* 571 */     return !this.bannerAssetId_absent ? this.bannerAssetId_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 590 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "StickerPackData", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_NAME = 1L;
/*     */ 
/*     */     
/*     */     private static final long INIT_BIT_DESCRIPTION = 2L;
/*     */ 
/*     */     
/* 604 */     private long initBits = 3L;
/*     */     
/* 606 */     private Id id_id = null;
/* 607 */     private List<StickerData> stickers_list = null;
/* 608 */     private Id skuId_id = null;
/* 609 */     private Possible<Id> coverStickerId_possible = Possible.absent();
/* 610 */     private Possible<Id> bannerAssetId_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String name;
/*     */ 
/*     */ 
/*     */     
/*     */     private String description;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(StickerPackData instance) {
/* 625 */       Objects.requireNonNull(instance, "instance");
/* 626 */       id(instance.id());
/* 627 */       stickers(instance.stickers());
/* 628 */       name(instance.name());
/* 629 */       description(instance.description());
/* 630 */       skuId(instance.skuId());
/* 631 */       coverStickerId(instance.coverStickerId());
/* 632 */       bannerAssetId(instance.bannerAssetId());
/* 633 */       return this;
/*     */     }
/*     */     
/*     */     public Builder id(String value) {
/* 637 */       this.id_id = Id.of(value);
/* 638 */       return this;
/*     */     }
/*     */     
/*     */     public Builder id(long value) {
/* 642 */       this.id_id = Id.of(value);
/* 643 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("id")
/*     */     public Builder id(Id value) {
/* 648 */       this.id_id = value;
/* 649 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addSticker(StickerData element) {
/* 653 */       stickers_getOrCreate().add(element);
/* 654 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addAllStickers(List<StickerData> elements) {
/* 658 */       stickers_getOrCreate().addAll(elements);
/* 659 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("stickers")
/*     */     public Builder stickers(Possible<List<StickerData>> elements) {
/* 664 */       this.stickers_list = null;
/* 665 */       elements.toOptional().ifPresent(e -> stickers_getOrCreate().addAll(e));
/* 666 */       return this;
/*     */     }
/*     */     
/*     */     public Builder stickers(List<StickerData> elements) {
/* 670 */       this.stickers_list = new ArrayList<>(elements);
/* 671 */       return this;
/*     */     }
/*     */     
/*     */     public Builder stickers(Iterable<StickerData> elements) {
/* 675 */       this.stickers_list = (List<StickerData>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 676 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("name")
/*     */     public final Builder name(String name) {
/* 686 */       this.name = Objects.<String>requireNonNull(name, "name");
/* 687 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 688 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("description")
/*     */     public final Builder description(String description) {
/* 698 */       this.description = Objects.<String>requireNonNull(description, "description");
/* 699 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 700 */       return this;
/*     */     }
/*     */     
/*     */     public Builder skuId(String value) {
/* 704 */       this.skuId_id = Id.of(value);
/* 705 */       return this;
/*     */     }
/*     */     
/*     */     public Builder skuId(long value) {
/* 709 */       this.skuId_id = Id.of(value);
/* 710 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("sku_id")
/*     */     public Builder skuId(Id value) {
/* 715 */       this.skuId_id = value;
/* 716 */       return this;
/*     */     }
/*     */     
/*     */     public Builder coverStickerId(String value) {
/* 720 */       this.coverStickerId_possible = Possible.of(Id.of(value));
/* 721 */       return this;
/*     */     }
/*     */     
/*     */     public Builder coverStickerId(long value) {
/* 725 */       this.coverStickerId_possible = Possible.of(Id.of(value));
/* 726 */       return this;
/*     */     }
/*     */     
/*     */     public Builder coverStickerId(Id value) {
/* 730 */       this.coverStickerId_possible = Possible.of(value);
/* 731 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("cover_sticker_id")
/*     */     public Builder coverStickerId(Possible<Id> value) {
/* 736 */       this.coverStickerId_possible = value;
/* 737 */       return this;
/*     */     }
/*     */     
/*     */     public Builder bannerAssetId(String value) {
/* 741 */       this.bannerAssetId_possible = Possible.of(Id.of(value));
/* 742 */       return this;
/*     */     }
/*     */     
/*     */     public Builder bannerAssetId(long value) {
/* 746 */       this.bannerAssetId_possible = Possible.of(Id.of(value));
/* 747 */       return this;
/*     */     }
/*     */     
/*     */     public Builder bannerAssetId(Id value) {
/* 751 */       this.bannerAssetId_possible = Possible.of(value);
/* 752 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("banner_asset_id")
/*     */     public Builder bannerAssetId(Possible<Id> value) {
/* 757 */       this.bannerAssetId_possible = value;
/* 758 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableStickerPackData build() {
/* 767 */       if (this.initBits != 0L) {
/* 768 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 770 */       return new ImmutableStickerPackData(null, 
/*     */           
/* 772 */           id_build(), 
/* 773 */           stickers_build(), this.name, this.description, 
/*     */ 
/*     */           
/* 776 */           skuId_build(), 
/* 777 */           coverStickerId_build(), 
/* 778 */           bannerAssetId_build());
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 782 */       List<String> attributes = new ArrayList<>();
/* 783 */       if ((this.initBits & 0x1L) != 0L) attributes.add("name"); 
/* 784 */       if ((this.initBits & 0x2L) != 0L) attributes.add("description"); 
/* 785 */       return "Cannot build StickerPackData, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Id id_build() {
/* 789 */       return this.id_id;
/*     */     }
/*     */     
/*     */     private Possible<List<StickerData>> stickers_build() {
/* 793 */       return (this.stickers_list == null) ? Possible.absent() : 
/* 794 */         Possible.of(this.stickers_list);
/*     */     }
/*     */     
/*     */     private List<StickerData> stickers_getOrCreate() {
/* 798 */       if (this.stickers_list == null) {
/* 799 */         this.stickers_list = new ArrayList<>();
/*     */       }
/* 801 */       return this.stickers_list;
/*     */     }
/*     */     
/*     */     private Id skuId_build() {
/* 805 */       return this.skuId_id;
/*     */     }
/*     */     
/*     */     private Possible<Id> coverStickerId_build() {
/* 809 */       return this.coverStickerId_possible;
/*     */     }
/*     */     
/*     */     private Possible<Id> bannerAssetId_build() {
/* 813 */       return this.bannerAssetId_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableStickerPackData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */