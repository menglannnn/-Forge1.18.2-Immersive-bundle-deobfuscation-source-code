/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.Id;
/*    */ import java.util.List;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ @JsonSerialize(as = ImmutableOnboardingData.class)
/*    */ @JsonDeserialize(as = ImmutableOnboardingData.class)
/*    */ @Immutable
/*    */ public interface OnboardingData
/*    */ {
/*    */   static ImmutableOnboardingData.Builder builder() {
/* 16 */     return ImmutableOnboardingData.builder();
/*    */   }
/*    */   
/*    */   @JsonProperty("guild_id")
/*    */   Id guildId();
/*    */   
/*    */   List<OnboardingPromptData> prompts();
/*    */   
/*    */   @JsonProperty("default_channel_ids")
/*    */   List<Id> defaultChannelIds();
/*    */   
/*    */   boolean enabled();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\OnboardingData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */