/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.Id;
/*    */ import java.util.Optional;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ @JsonSerialize(as = ImmutableGuildWidgetData.class)
/*    */ @JsonDeserialize(as = ImmutableGuildWidgetData.class)
/*    */ @Immutable
/*    */ public interface GuildWidgetData
/*    */ {
/*    */   static ImmutableGuildWidgetData.Builder builder() {
/* 17 */     return ImmutableGuildWidgetData.builder();
/*    */   }
/*    */   
/*    */   boolean enabled();
/*    */   
/*    */   @JsonProperty("channel_id")
/*    */   Optional<Id> channelId();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\GuildWidgetData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */