/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.StreamSupport;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "ActivityPartyData", generator = "Immutables")
/*     */ public final class ImmutableActivityPartyData
/*     */   implements ActivityPartyData
/*     */ {
/*     */   private final String id_value;
/*     */   private final boolean id_absent;
/*     */   private final List<Long> size_value;
/*     */   private final boolean size_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private ImmutableActivityPartyData(Possible<String> id, Possible<List<Long>> size) {
/*  36 */     Possible<String> id$impl = id;
/*  37 */     Possible<List<Long>> size$impl = size;
/*  38 */     this.id_value = id$impl.toOptional().orElse(null);
/*  39 */     this.id_absent = id$impl.isAbsent();
/*  40 */     this.size_value = size$impl.toOptional().orElse(null);
/*  41 */     this.size_absent = size$impl.isAbsent();
/*  42 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableActivityPartyData(ImmutableActivityPartyData original, Possible<String> id, Possible<List<Long>> size) {
/*  49 */     Possible<String> id$impl = id;
/*  50 */     Possible<List<Long>> size$impl = size;
/*  51 */     this.id_value = id$impl.toOptional().orElse(null);
/*  52 */     this.id_absent = id$impl.isAbsent();
/*  53 */     this.size_value = size$impl.toOptional().orElse(null);
/*  54 */     this.size_absent = size$impl.isAbsent();
/*  55 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  61 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "ActivityPartyData", generator = "Immutables")
/*     */   private final class InitShim {
/*     */     private String formatInitCycleMessage() {
/*  66 */       List<String> attributes = new ArrayList<>();
/*  67 */       return "Cannot build ActivityPartyData, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @JsonProperty("id")
/*     */   public Possible<String> id() {
/*  77 */     return this.id_absent ? Possible.absent() : Possible.of(this.id_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("size")
/*     */   public Possible<List<Long>> size() {
/*  86 */     return this.size_absent ? Possible.absent() : 
/*  87 */       Possible.of(this.size_value);
/*     */   }
/*     */   
/*     */   public ImmutableActivityPartyData withId(Possible<String> value) {
/*  91 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  92 */     return new ImmutableActivityPartyData(this, newValue, size());
/*     */   }
/*     */   
/*     */   public ImmutableActivityPartyData withId(String value) {
/*  96 */     Possible<String> newValue = Possible.of(value);
/*  97 */     return new ImmutableActivityPartyData(this, newValue, size());
/*     */   }
/*     */   
/*     */   public ImmutableActivityPartyData withSize(Possible<List<Long>> possible) {
/* 101 */     Possible<List<Long>> newValue = Objects.<Possible<List<Long>>>requireNonNull(possible);
/* 102 */     return new ImmutableActivityPartyData(this, id(), newValue);
/*     */   }
/*     */   
/*     */   public ImmutableActivityPartyData withSize(Iterable<Long> elements) {
/* 106 */     Possible<List<Long>> newValue = Possible.of(
/* 107 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/* 108 */     return new ImmutableActivityPartyData(this, id(), newValue);
/*     */   }
/*     */   
/*     */   @SafeVarargs
/*     */   public final ImmutableActivityPartyData withSize(Long... elements) {
/* 113 */     Possible<List<Long>> newValue = Possible.of(Arrays.asList(elements));
/* 114 */     return new ImmutableActivityPartyData(this, id(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 123 */     if (this == another) return true; 
/* 124 */     return (another instanceof ImmutableActivityPartyData && 
/* 125 */       equalTo(0, (ImmutableActivityPartyData)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableActivityPartyData another) {
/* 129 */     return (id().equals(another.id()) && 
/* 130 */       Objects.equals(this.size_value, another.size_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 139 */     int h = 5381;
/* 140 */     h += (h << 5) + id().hashCode();
/* 141 */     h += (h << 5) + Objects.hashCode(this.size_value);
/* 142 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 151 */     return "ActivityPartyData{id=" + 
/* 152 */       id().toString() + ", size=" + 
/* 153 */       Objects.toString(this.size_value) + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "ActivityPartyData", generator = "Immutables")
/*     */   static final class Json
/*     */     implements ActivityPartyData
/*     */   {
/* 167 */     Possible<String> id = Possible.absent();
/*     */ 
/*     */     
/* 170 */     Possible<List<Long>> size = Possible.absent();
/*     */     
/*     */     @JsonProperty("id")
/*     */     public void setId(Possible<String> id) {
/* 174 */       this.id = id;
/*     */     }
/*     */     @JsonProperty("size")
/*     */     public void setSize(Possible<List<Long>> size) {
/* 178 */       this.size = size;
/*     */     }
/*     */     public Possible<String> id() {
/* 181 */       throw new UnsupportedOperationException();
/*     */     } public Possible<List<Long>> size() {
/* 183 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableActivityPartyData fromJson(Json json) {
/* 194 */     Builder builder = builder();
/* 195 */     if (json.id != null) {
/* 196 */       builder.id(json.id);
/*     */     }
/* 198 */     if (json.size != null) {
/* 199 */       builder.size(json.size);
/*     */     }
/* 201 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableActivityPartyData of(Possible<String> id, Possible<List<Long>> size) {
/* 211 */     return new ImmutableActivityPartyData(id, size);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableActivityPartyData copyOf(ActivityPartyData instance) {
/* 222 */     if (instance instanceof ImmutableActivityPartyData) {
/* 223 */       return (ImmutableActivityPartyData)instance;
/*     */     }
/* 225 */     return builder()
/* 226 */       .from(instance)
/* 227 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isIdPresent() {
/* 231 */     return !this.id_absent;
/*     */   }
/*     */   
/*     */   public String idOrElse(String defaultValue) {
/* 235 */     return !this.id_absent ? this.id_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isSizePresent() {
/* 239 */     return !this.size_absent;
/*     */   }
/*     */   
/*     */   public List<Long> sizeOrElse(List<Long> defaultValue) {
/* 243 */     return !this.size_absent ? this.size_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 257 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "ActivityPartyData", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/* 269 */     private Possible<String> id_possible = Possible.absent();
/* 270 */     private List<Long> size_list = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(ActivityPartyData instance) {
/* 283 */       Objects.requireNonNull(instance, "instance");
/* 284 */       id(instance.id());
/* 285 */       size(instance.size());
/* 286 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("id")
/*     */     public Builder id(Possible<String> value) {
/* 291 */       this.id_possible = value;
/* 292 */       return this;
/*     */     }
/*     */     
/*     */     public Builder id(String value) {
/* 296 */       this.id_possible = Possible.of(value);
/* 297 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addSize(Long element) {
/* 301 */       size_getOrCreate().add(element);
/* 302 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addAllSize(List<Long> elements) {
/* 306 */       size_getOrCreate().addAll(elements);
/* 307 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("size")
/*     */     public Builder size(Possible<List<Long>> elements) {
/* 312 */       this.size_list = null;
/* 313 */       elements.toOptional().ifPresent(e -> size_getOrCreate().addAll(e));
/* 314 */       return this;
/*     */     }
/*     */     
/*     */     public Builder size(List<Long> elements) {
/* 318 */       this.size_list = new ArrayList<>(elements);
/* 319 */       return this;
/*     */     }
/*     */     
/*     */     public Builder size(Iterable<Long> elements) {
/* 323 */       this.size_list = (List<Long>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 324 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableActivityPartyData build() {
/* 333 */       return new ImmutableActivityPartyData(null, id_build(), size_build());
/*     */     }
/*     */     
/*     */     private Possible<String> id_build() {
/* 337 */       return this.id_possible;
/*     */     }
/*     */     
/*     */     private Possible<List<Long>> size_build() {
/* 341 */       return (this.size_list == null) ? Possible.absent() : 
/* 342 */         Possible.of(this.size_list);
/*     */     }
/*     */     
/*     */     private List<Long> size_getOrCreate() {
/* 346 */       if (this.size_list == null) {
/* 347 */         this.size_list = new ArrayList<>();
/*     */       }
/* 349 */       return this.size_list;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableActivityPartyData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */