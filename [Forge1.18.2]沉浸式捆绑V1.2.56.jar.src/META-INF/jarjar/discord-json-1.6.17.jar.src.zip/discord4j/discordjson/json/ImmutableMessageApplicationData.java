/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.Id;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "MessageApplicationData", generator = "Immutables")
/*     */ public final class ImmutableMessageApplicationData
/*     */   implements MessageApplicationData
/*     */ {
/*     */   private final long id_value;
/*     */   private final String coverImage_value;
/*     */   private final boolean coverImage_absent;
/*     */   private final String description;
/*     */   private final String icon;
/*     */   private final String name;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private ImmutableMessageApplicationData(Id id, Possible<String> coverImage, String description, Optional<String> icon, String name) {
/*  41 */     Id id$impl = id;
/*  42 */     Possible<String> coverImage$impl = coverImage;
/*  43 */     this.description = Objects.<String>requireNonNull(description, "description");
/*  44 */     this.icon = icon.orElse(null);
/*  45 */     this.name = Objects.<String>requireNonNull(name, "name");
/*  46 */     this.id_value = id$impl.asLong();
/*  47 */     this.coverImage_value = coverImage$impl.toOptional().orElse(null);
/*  48 */     this.coverImage_absent = coverImage$impl.isAbsent();
/*  49 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableMessageApplicationData(ImmutableMessageApplicationData original, Id id, Possible<String> coverImage, String description, String icon, String name) {
/*  59 */     Id id$impl = id;
/*  60 */     Possible<String> coverImage$impl = coverImage;
/*  61 */     this.description = description;
/*  62 */     this.icon = icon;
/*  63 */     this.name = name;
/*  64 */     this.id_value = id$impl.asLong();
/*  65 */     this.coverImage_value = coverImage$impl.toOptional().orElse(null);
/*  66 */     this.coverImage_absent = coverImage$impl.isAbsent();
/*  67 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  73 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "MessageApplicationData", generator = "Immutables")
/*     */   private final class InitShim {
/*     */     private String formatInitCycleMessage() {
/*  78 */       List<String> attributes = new ArrayList<>();
/*  79 */       return "Cannot build MessageApplicationData, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @JsonProperty("id")
/*     */   public Id id() {
/*  89 */     return Id.of(this.id_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("cover_image")
/*     */   public Possible<String> coverImage() {
/*  98 */     return this.coverImage_absent ? Possible.absent() : Possible.of(this.coverImage_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("description")
/*     */   public String description() {
/* 107 */     return this.description;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("icon")
/*     */   public Optional<String> icon() {
/* 116 */     return Optional.ofNullable(this.icon);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("name")
/*     */   public String name() {
/* 125 */     return this.name;
/*     */   }
/*     */   
/*     */   public ImmutableMessageApplicationData withId(long value) {
/* 129 */     Id newValue = Id.of(value);
/* 130 */     return new ImmutableMessageApplicationData(this, newValue, coverImage(), this.description, this.icon, this.name);
/*     */   }
/*     */   
/*     */   public ImmutableMessageApplicationData withId(String value) {
/* 134 */     Id newValue = Id.of(value);
/* 135 */     return new ImmutableMessageApplicationData(this, newValue, coverImage(), this.description, this.icon, this.name);
/*     */   }
/*     */   
/*     */   public ImmutableMessageApplicationData withCoverImage(Possible<String> value) {
/* 139 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 140 */     return new ImmutableMessageApplicationData(this, id(), newValue, this.description, this.icon, this.name);
/*     */   }
/*     */   
/*     */   public ImmutableMessageApplicationData withCoverImage(String value) {
/* 144 */     Possible<String> newValue = Possible.of(value);
/* 145 */     return new ImmutableMessageApplicationData(this, id(), newValue, this.description, this.icon, this.name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableMessageApplicationData withDescription(String value) {
/* 155 */     String newValue = Objects.<String>requireNonNull(value, "description");
/* 156 */     if (this.description.equals(newValue)) return this; 
/* 157 */     return new ImmutableMessageApplicationData(this, id(), coverImage(), newValue, this.icon, this.name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableMessageApplicationData withIcon(String value) {
/* 166 */     String newValue = Objects.<String>requireNonNull(value, "icon");
/* 167 */     if (Objects.equals(this.icon, newValue)) return this; 
/* 168 */     return new ImmutableMessageApplicationData(this, id(), coverImage(), this.description, newValue, this.name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableMessageApplicationData withIcon(Optional<String> optional) {
/* 178 */     String value = optional.orElse(null);
/* 179 */     if (Objects.equals(this.icon, value)) return this; 
/* 180 */     return new ImmutableMessageApplicationData(this, id(), coverImage(), this.description, value, this.name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableMessageApplicationData withName(String value) {
/* 190 */     String newValue = Objects.<String>requireNonNull(value, "name");
/* 191 */     if (this.name.equals(newValue)) return this; 
/* 192 */     return new ImmutableMessageApplicationData(this, id(), coverImage(), this.description, this.icon, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 201 */     if (this == another) return true; 
/* 202 */     return (another instanceof ImmutableMessageApplicationData && 
/* 203 */       equalTo(0, (ImmutableMessageApplicationData)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableMessageApplicationData another) {
/* 207 */     return (Objects.equals(Long.valueOf(this.id_value), Long.valueOf(another.id_value)) && 
/* 208 */       coverImage().equals(another.coverImage()) && this.description
/* 209 */       .equals(another.description) && 
/* 210 */       Objects.equals(this.icon, another.icon) && this.name
/* 211 */       .equals(another.name));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 220 */     int h = 5381;
/* 221 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.id_value));
/* 222 */     h += (h << 5) + coverImage().hashCode();
/* 223 */     h += (h << 5) + this.description.hashCode();
/* 224 */     h += (h << 5) + Objects.hashCode(this.icon);
/* 225 */     h += (h << 5) + this.name.hashCode();
/* 226 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 235 */     StringBuilder builder = new StringBuilder("MessageApplicationData{");
/* 236 */     builder.append("id=").append(Objects.toString(Long.valueOf(this.id_value)));
/* 237 */     builder.append(", ");
/* 238 */     builder.append("coverImage=").append(coverImage().toString());
/* 239 */     builder.append(", ");
/* 240 */     builder.append("description=").append(this.description);
/* 241 */     if (this.icon != null) {
/* 242 */       builder.append(", ");
/* 243 */       builder.append("icon=").append(this.icon);
/*     */     } 
/* 245 */     builder.append(", ");
/* 246 */     builder.append("name=").append(this.name);
/* 247 */     return builder.append("}").toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "MessageApplicationData", generator = "Immutables")
/*     */   static final class Json
/*     */     implements MessageApplicationData
/*     */   {
/*     */     Id id;
/*     */     
/* 261 */     Possible<String> coverImage = Possible.absent();
/*     */     
/*     */     String description;
/* 264 */     Optional<String> icon = Optional.empty(); String name;
/*     */     
/*     */     @JsonProperty("id")
/*     */     public void setId(Id id) {
/* 268 */       this.id = id;
/*     */     }
/*     */     @JsonProperty("cover_image")
/*     */     public void setCoverImage(Possible<String> coverImage) {
/* 272 */       this.coverImage = coverImage;
/*     */     }
/*     */     @JsonProperty("description")
/*     */     public void setDescription(String description) {
/* 276 */       this.description = description;
/*     */     }
/*     */     @JsonProperty("icon")
/*     */     public void setIcon(Optional<String> icon) {
/* 280 */       this.icon = icon;
/*     */     }
/*     */     @JsonProperty("name")
/*     */     public void setName(String name) {
/* 284 */       this.name = name;
/*     */     }
/*     */     public Id id() {
/* 287 */       throw new UnsupportedOperationException();
/*     */     } public Possible<String> coverImage() {
/* 289 */       throw new UnsupportedOperationException();
/*     */     } public String description() {
/* 291 */       throw new UnsupportedOperationException();
/*     */     } public Optional<String> icon() {
/* 293 */       throw new UnsupportedOperationException();
/*     */     } public String name() {
/* 295 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableMessageApplicationData fromJson(Json json) {
/* 306 */     Builder builder = builder();
/* 307 */     if (json.id != null) {
/* 308 */       builder.id(json.id);
/*     */     }
/* 310 */     if (json.coverImage != null) {
/* 311 */       builder.coverImage(json.coverImage);
/*     */     }
/* 313 */     if (json.description != null) {
/* 314 */       builder.description(json.description);
/*     */     }
/* 316 */     if (json.icon != null) {
/* 317 */       builder.icon(json.icon);
/*     */     }
/* 319 */     if (json.name != null) {
/* 320 */       builder.name(json.name);
/*     */     }
/* 322 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableMessageApplicationData of(Id id, Possible<String> coverImage, String description, Optional<String> icon, String name) {
/* 335 */     return new ImmutableMessageApplicationData(id, coverImage, description, icon, name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableMessageApplicationData copyOf(MessageApplicationData instance) {
/* 346 */     if (instance instanceof ImmutableMessageApplicationData) {
/* 347 */       return (ImmutableMessageApplicationData)instance;
/*     */     }
/* 349 */     return builder()
/* 350 */       .from(instance)
/* 351 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isCoverImagePresent() {
/* 355 */     return !this.coverImage_absent;
/*     */   }
/*     */   
/*     */   public String coverImageOrElse(String defaultValue) {
/* 359 */     return !this.coverImage_absent ? this.coverImage_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 376 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "MessageApplicationData", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_DESCRIPTION = 1L;
/*     */ 
/*     */     
/*     */     private static final long INIT_BIT_NAME = 2L;
/*     */ 
/*     */     
/* 390 */     private long initBits = 3L;
/*     */     
/* 392 */     private Id id_id = null;
/* 393 */     private Possible<String> coverImage_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */     
/*     */     private String description;
/*     */ 
/*     */ 
/*     */     
/*     */     private String icon;
/*     */ 
/*     */     
/*     */     private String name;
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(MessageApplicationData instance) {
/* 409 */       Objects.requireNonNull(instance, "instance");
/* 410 */       id(instance.id());
/* 411 */       coverImage(instance.coverImage());
/* 412 */       description(instance.description());
/* 413 */       Optional<String> iconOptional = instance.icon();
/* 414 */       if (iconOptional.isPresent()) {
/* 415 */         icon(iconOptional);
/*     */       }
/* 417 */       name(instance.name());
/* 418 */       return this;
/*     */     }
/*     */     
/*     */     public Builder id(String value) {
/* 422 */       this.id_id = Id.of(value);
/* 423 */       return this;
/*     */     }
/*     */     
/*     */     public Builder id(long value) {
/* 427 */       this.id_id = Id.of(value);
/* 428 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("id")
/*     */     public Builder id(Id value) {
/* 433 */       this.id_id = value;
/* 434 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("cover_image")
/*     */     public Builder coverImage(Possible<String> value) {
/* 439 */       this.coverImage_possible = value;
/* 440 */       return this;
/*     */     }
/*     */     
/*     */     public Builder coverImage(String value) {
/* 444 */       this.coverImage_possible = Possible.of(value);
/* 445 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("description")
/*     */     public final Builder description(String description) {
/* 455 */       this.description = Objects.<String>requireNonNull(description, "description");
/* 456 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 457 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder icon(String icon) {
/* 466 */       this.icon = Objects.<String>requireNonNull(icon, "icon");
/* 467 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("icon")
/*     */     public final Builder icon(Optional<String> icon) {
/* 477 */       this.icon = icon.orElse(null);
/* 478 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("name")
/*     */     public final Builder name(String name) {
/* 488 */       this.name = Objects.<String>requireNonNull(name, "name");
/* 489 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 490 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableMessageApplicationData build() {
/* 499 */       if (this.initBits != 0L) {
/* 500 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 502 */       return new ImmutableMessageApplicationData(null, id_build(), coverImage_build(), this.description, this.icon, this.name);
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 506 */       List<String> attributes = new ArrayList<>();
/* 507 */       if ((this.initBits & 0x1L) != 0L) attributes.add("description"); 
/* 508 */       if ((this.initBits & 0x2L) != 0L) attributes.add("name"); 
/* 509 */       return "Cannot build MessageApplicationData, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Id id_build() {
/* 513 */       return this.id_id;
/*     */     }
/*     */     
/*     */     private Possible<String> coverImage_build() {
/* 517 */       return this.coverImage_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableMessageApplicationData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */