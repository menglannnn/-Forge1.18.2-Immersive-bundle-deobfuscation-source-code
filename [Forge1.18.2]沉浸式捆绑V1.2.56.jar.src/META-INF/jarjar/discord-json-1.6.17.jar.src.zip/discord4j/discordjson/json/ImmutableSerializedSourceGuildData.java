/*      */ package discord4j.discordjson.json;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*      */ import com.fasterxml.jackson.annotation.JsonCreator;
/*      */ import com.fasterxml.jackson.annotation.JsonProperty;
/*      */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*      */ import discord4j.discordjson.Id;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import java.util.Optional;
/*      */ import org.immutables.value.Generated;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Generated(from = "SerializedSourceGuildData", generator = "Immutables")
/*      */ public final class ImmutableSerializedSourceGuildData
/*      */   implements SerializedSourceGuildData
/*      */ {
/*      */   private final String name;
/*      */   private final String description;
/*      */   private final String region;
/*      */   private final int verificationLevel;
/*      */   private final int defaultMessageNotifications;
/*      */   private final int explicitContentFilter;
/*      */   private final String preferredLocale;
/*      */   private final int afkTimeout;
/*      */   private final List<RoleTemplateData> roles;
/*      */   private final List<ChannelData> channels;
/*      */   private final long afkChannelId_value;
/*      */   private final boolean afkChannelId_present;
/*      */   private final long systemChannelId_value;
/*      */   private final boolean systemChannelId_present;
/*      */   private final int systemChannelFlags;
/*      */   private final String iconHash;
/*      */   private static final byte STAGE_INITIALIZING = -1;
/*      */   private static final byte STAGE_UNINITIALIZED = 0;
/*      */   private static final byte STAGE_INITIALIZED = 1;
/*      */   private volatile transient InitShim initShim;
/*      */   
/*      */   private ImmutableSerializedSourceGuildData(String name, Optional<String> description, String region, int verificationLevel, int defaultMessageNotifications, int explicitContentFilter, String preferredLocale, int afkTimeout, Iterable<? extends RoleTemplateData> roles, Iterable<? extends ChannelData> channels, Optional<Id> afkChannelId, Optional<Id> systemChannelId, int systemChannelFlags, Optional<String> iconHash) {
/*  131 */     this.initShim = new InitShim(); this.name = Objects.<String>requireNonNull(name, "name"); this.description = description.orElse(null); this.region = Objects.<String>requireNonNull(region, "region"); this.verificationLevel = verificationLevel; this.defaultMessageNotifications = defaultMessageNotifications; this.explicitContentFilter = explicitContentFilter; this.preferredLocale = Objects.<String>requireNonNull(preferredLocale, "preferredLocale"); this.afkTimeout = afkTimeout; this.roles = createUnmodifiableList(false, createSafeList(roles, true, false)); this.channels = createUnmodifiableList(false, createSafeList(channels, true, false)); Optional<Id> afkChannelId$impl = afkChannelId; Optional<Id> systemChannelId$impl = systemChannelId; this.systemChannelFlags = systemChannelFlags; this.iconHash = iconHash.orElse(null); this.afkChannelId_value = ((Long)afkChannelId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue(); this.afkChannelId_present = afkChannelId$impl.isPresent(); this.systemChannelId_value = ((Long)systemChannelId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue(); this.systemChannelId_present = systemChannelId$impl.isPresent(); this.initShim = null; } private ImmutableSerializedSourceGuildData(ImmutableSerializedSourceGuildData original, String name, String description, String region, int verificationLevel, int defaultMessageNotifications, int explicitContentFilter, String preferredLocale, int afkTimeout, List<RoleTemplateData> roles, List<ChannelData> channels, Optional<Id> afkChannelId, Optional<Id> systemChannelId, int systemChannelFlags, String iconHash) { this.initShim = new InitShim(); this.name = name; this.description = description; this.region = region; this.verificationLevel = verificationLevel; this.defaultMessageNotifications = defaultMessageNotifications; this.explicitContentFilter = explicitContentFilter; this.preferredLocale = preferredLocale; this.afkTimeout = afkTimeout; this.roles = roles; this.channels = channels; Optional<Id> afkChannelId$impl = afkChannelId; Optional<Id> systemChannelId$impl = systemChannelId; this.systemChannelFlags = systemChannelFlags; this.iconHash = iconHash;
/*      */     this.afkChannelId_value = ((Long)afkChannelId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*      */     this.afkChannelId_present = afkChannelId$impl.isPresent();
/*      */     this.systemChannelId_value = ((Long)systemChannelId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*      */     this.systemChannelId_present = systemChannelId$impl.isPresent();
/*  136 */     this.initShim = null; } @Generated(from = "SerializedSourceGuildData", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/*  137 */       return "Cannot build SerializedSourceGuildData, attribute initializers form cycle " + attributes; }
/*      */      }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("name")
/*      */   public String name() {
/*  147 */     return this.name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("description")
/*      */   public Optional<String> description() {
/*  156 */     return Optional.ofNullable(this.description);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("region")
/*      */   public String region() {
/*  165 */     return this.region;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("verification_level")
/*      */   public int verificationLevel() {
/*  174 */     return this.verificationLevel;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("default_message_notifications")
/*      */   public int defaultMessageNotifications() {
/*  183 */     return this.defaultMessageNotifications;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("explicit_content_filter")
/*      */   public int explicitContentFilter() {
/*  192 */     return this.explicitContentFilter;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("preferred_locale")
/*      */   public String preferredLocale() {
/*  201 */     return this.preferredLocale;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("afk_timeout")
/*      */   public int afkTimeout() {
/*  210 */     return this.afkTimeout;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("roles")
/*      */   public List<RoleTemplateData> roles() {
/*  219 */     return this.roles;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("channels")
/*      */   public List<ChannelData> channels() {
/*  228 */     return this.channels;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("afk_channel_id")
/*      */   public Optional<Id> afkChannelId() {
/*  237 */     return this.afkChannelId_present ? Optional.<Id>of(Id.of(this.afkChannelId_value)) : Optional.<Id>empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("system_channel_id")
/*      */   public Optional<Id> systemChannelId() {
/*  246 */     return this.systemChannelId_present ? Optional.<Id>of(Id.of(this.systemChannelId_value)) : Optional.<Id>empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("system_channel_flags")
/*      */   public int systemChannelFlags() {
/*  255 */     return this.systemChannelFlags;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("icon_hash")
/*      */   public Optional<String> iconHash() {
/*  264 */     return Optional.ofNullable(this.iconHash);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableSerializedSourceGuildData withName(String value) {
/*  274 */     String newValue = Objects.<String>requireNonNull(value, "name");
/*  275 */     if (this.name.equals(newValue)) return this; 
/*  276 */     return new ImmutableSerializedSourceGuildData(this, newValue, this.description, this.region, this.verificationLevel, this.defaultMessageNotifications, this.explicitContentFilter, this.preferredLocale, this.afkTimeout, this.roles, this.channels, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  288 */         afkChannelId(), 
/*  289 */         systemChannelId(), this.systemChannelFlags, this.iconHash);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableSerializedSourceGuildData withDescription(String value) {
/*  300 */     String newValue = Objects.<String>requireNonNull(value, "description");
/*  301 */     if (Objects.equals(this.description, newValue)) return this; 
/*  302 */     return new ImmutableSerializedSourceGuildData(this, this.name, newValue, this.region, this.verificationLevel, this.defaultMessageNotifications, this.explicitContentFilter, this.preferredLocale, this.afkTimeout, this.roles, this.channels, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  314 */         afkChannelId(), 
/*  315 */         systemChannelId(), this.systemChannelFlags, this.iconHash);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableSerializedSourceGuildData withDescription(Optional<String> optional) {
/*  327 */     String value = optional.orElse(null);
/*  328 */     if (Objects.equals(this.description, value)) return this; 
/*  329 */     return new ImmutableSerializedSourceGuildData(this, this.name, value, this.region, this.verificationLevel, this.defaultMessageNotifications, this.explicitContentFilter, this.preferredLocale, this.afkTimeout, this.roles, this.channels, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  341 */         afkChannelId(), 
/*  342 */         systemChannelId(), this.systemChannelFlags, this.iconHash);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableSerializedSourceGuildData withRegion(String value) {
/*  354 */     String newValue = Objects.<String>requireNonNull(value, "region");
/*  355 */     if (this.region.equals(newValue)) return this; 
/*  356 */     return new ImmutableSerializedSourceGuildData(this, this.name, this.description, newValue, this.verificationLevel, this.defaultMessageNotifications, this.explicitContentFilter, this.preferredLocale, this.afkTimeout, this.roles, this.channels, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  368 */         afkChannelId(), 
/*  369 */         systemChannelId(), this.systemChannelFlags, this.iconHash);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableSerializedSourceGuildData withVerificationLevel(int value) {
/*  381 */     if (this.verificationLevel == value) return this; 
/*  382 */     return new ImmutableSerializedSourceGuildData(this, this.name, this.description, this.region, value, this.defaultMessageNotifications, this.explicitContentFilter, this.preferredLocale, this.afkTimeout, this.roles, this.channels, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  394 */         afkChannelId(), 
/*  395 */         systemChannelId(), this.systemChannelFlags, this.iconHash);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableSerializedSourceGuildData withDefaultMessageNotifications(int value) {
/*  407 */     if (this.defaultMessageNotifications == value) return this; 
/*  408 */     return new ImmutableSerializedSourceGuildData(this, this.name, this.description, this.region, this.verificationLevel, value, this.explicitContentFilter, this.preferredLocale, this.afkTimeout, this.roles, this.channels, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  420 */         afkChannelId(), 
/*  421 */         systemChannelId(), this.systemChannelFlags, this.iconHash);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableSerializedSourceGuildData withExplicitContentFilter(int value) {
/*  433 */     if (this.explicitContentFilter == value) return this; 
/*  434 */     return new ImmutableSerializedSourceGuildData(this, this.name, this.description, this.region, this.verificationLevel, this.defaultMessageNotifications, value, this.preferredLocale, this.afkTimeout, this.roles, this.channels, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  446 */         afkChannelId(), 
/*  447 */         systemChannelId(), this.systemChannelFlags, this.iconHash);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableSerializedSourceGuildData withPreferredLocale(String value) {
/*  459 */     String newValue = Objects.<String>requireNonNull(value, "preferredLocale");
/*  460 */     if (this.preferredLocale.equals(newValue)) return this; 
/*  461 */     return new ImmutableSerializedSourceGuildData(this, this.name, this.description, this.region, this.verificationLevel, this.defaultMessageNotifications, this.explicitContentFilter, newValue, this.afkTimeout, this.roles, this.channels, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  473 */         afkChannelId(), 
/*  474 */         systemChannelId(), this.systemChannelFlags, this.iconHash);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableSerializedSourceGuildData withAfkTimeout(int value) {
/*  486 */     if (this.afkTimeout == value) return this; 
/*  487 */     return new ImmutableSerializedSourceGuildData(this, this.name, this.description, this.region, this.verificationLevel, this.defaultMessageNotifications, this.explicitContentFilter, this.preferredLocale, value, this.roles, this.channels, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  499 */         afkChannelId(), 
/*  500 */         systemChannelId(), this.systemChannelFlags, this.iconHash);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableSerializedSourceGuildData withRoles(RoleTemplateData... elements) {
/*  511 */     List<RoleTemplateData> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/*  512 */     return new ImmutableSerializedSourceGuildData(this, this.name, this.description, this.region, this.verificationLevel, this.defaultMessageNotifications, this.explicitContentFilter, this.preferredLocale, this.afkTimeout, newValue, this.channels, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  524 */         afkChannelId(), 
/*  525 */         systemChannelId(), this.systemChannelFlags, this.iconHash);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableSerializedSourceGuildData withRoles(Iterable<? extends RoleTemplateData> elements) {
/*  537 */     if (this.roles == elements) return this; 
/*  538 */     List<RoleTemplateData> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/*  539 */     return new ImmutableSerializedSourceGuildData(this, this.name, this.description, this.region, this.verificationLevel, this.defaultMessageNotifications, this.explicitContentFilter, this.preferredLocale, this.afkTimeout, newValue, this.channels, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  551 */         afkChannelId(), 
/*  552 */         systemChannelId(), this.systemChannelFlags, this.iconHash);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableSerializedSourceGuildData withChannels(ChannelData... elements) {
/*  563 */     List<ChannelData> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/*  564 */     return new ImmutableSerializedSourceGuildData(this, this.name, this.description, this.region, this.verificationLevel, this.defaultMessageNotifications, this.explicitContentFilter, this.preferredLocale, this.afkTimeout, this.roles, newValue, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  576 */         afkChannelId(), 
/*  577 */         systemChannelId(), this.systemChannelFlags, this.iconHash);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableSerializedSourceGuildData withChannels(Iterable<? extends ChannelData> elements) {
/*  589 */     if (this.channels == elements) return this; 
/*  590 */     List<ChannelData> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/*  591 */     return new ImmutableSerializedSourceGuildData(this, this.name, this.description, this.region, this.verificationLevel, this.defaultMessageNotifications, this.explicitContentFilter, this.preferredLocale, this.afkTimeout, this.roles, newValue, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  603 */         afkChannelId(), 
/*  604 */         systemChannelId(), this.systemChannelFlags, this.iconHash);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableSerializedSourceGuildData withAfkChannelId(Optional<Id> value) {
/*  610 */     Optional<Id> newValue = Objects.<Optional<Id>>requireNonNull(value);
/*  611 */     return new ImmutableSerializedSourceGuildData(this, this.name, this.description, this.region, this.verificationLevel, this.defaultMessageNotifications, this.explicitContentFilter, this.preferredLocale, this.afkTimeout, this.roles, this.channels, newValue, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  624 */         systemChannelId(), this.systemChannelFlags, this.iconHash);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableSerializedSourceGuildData withAfkChannelId(long value) {
/*  630 */     Optional<Id> newValue = Optional.of(Id.of(value));
/*  631 */     return new ImmutableSerializedSourceGuildData(this, this.name, this.description, this.region, this.verificationLevel, this.defaultMessageNotifications, this.explicitContentFilter, this.preferredLocale, this.afkTimeout, this.roles, this.channels, newValue, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  644 */         systemChannelId(), this.systemChannelFlags, this.iconHash);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableSerializedSourceGuildData withSystemChannelId(Optional<Id> value) {
/*  650 */     Optional<Id> newValue = Objects.<Optional<Id>>requireNonNull(value);
/*  651 */     return new ImmutableSerializedSourceGuildData(this, this.name, this.description, this.region, this.verificationLevel, this.defaultMessageNotifications, this.explicitContentFilter, this.preferredLocale, this.afkTimeout, this.roles, this.channels, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  663 */         afkChannelId(), newValue, this.systemChannelFlags, this.iconHash);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableSerializedSourceGuildData withSystemChannelId(long value) {
/*  670 */     Optional<Id> newValue = Optional.of(Id.of(value));
/*  671 */     return new ImmutableSerializedSourceGuildData(this, this.name, this.description, this.region, this.verificationLevel, this.defaultMessageNotifications, this.explicitContentFilter, this.preferredLocale, this.afkTimeout, this.roles, this.channels, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  683 */         afkChannelId(), newValue, this.systemChannelFlags, this.iconHash);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableSerializedSourceGuildData withSystemChannelFlags(int value) {
/*  696 */     if (this.systemChannelFlags == value) return this; 
/*  697 */     return new ImmutableSerializedSourceGuildData(this, this.name, this.description, this.region, this.verificationLevel, this.defaultMessageNotifications, this.explicitContentFilter, this.preferredLocale, this.afkTimeout, this.roles, this.channels, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  709 */         afkChannelId(), 
/*  710 */         systemChannelId(), value, this.iconHash);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableSerializedSourceGuildData withIconHash(String value) {
/*  721 */     String newValue = Objects.<String>requireNonNull(value, "iconHash");
/*  722 */     if (Objects.equals(this.iconHash, newValue)) return this; 
/*  723 */     return new ImmutableSerializedSourceGuildData(this, this.name, this.description, this.region, this.verificationLevel, this.defaultMessageNotifications, this.explicitContentFilter, this.preferredLocale, this.afkTimeout, this.roles, this.channels, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  735 */         afkChannelId(), 
/*  736 */         systemChannelId(), this.systemChannelFlags, newValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableSerializedSourceGuildData withIconHash(Optional<String> optional) {
/*  748 */     String value = optional.orElse(null);
/*  749 */     if (Objects.equals(this.iconHash, value)) return this; 
/*  750 */     return new ImmutableSerializedSourceGuildData(this, this.name, this.description, this.region, this.verificationLevel, this.defaultMessageNotifications, this.explicitContentFilter, this.preferredLocale, this.afkTimeout, this.roles, this.channels, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  762 */         afkChannelId(), 
/*  763 */         systemChannelId(), this.systemChannelFlags, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object another) {
/*  774 */     if (this == another) return true; 
/*  775 */     return (another instanceof ImmutableSerializedSourceGuildData && 
/*  776 */       equalTo(0, (ImmutableSerializedSourceGuildData)another));
/*      */   }
/*      */   
/*      */   private boolean equalTo(int synthetic, ImmutableSerializedSourceGuildData another) {
/*  780 */     return (this.name.equals(another.name) && 
/*  781 */       Objects.equals(this.description, another.description) && this.region
/*  782 */       .equals(another.region) && this.verificationLevel == another.verificationLevel && this.defaultMessageNotifications == another.defaultMessageNotifications && this.explicitContentFilter == another.explicitContentFilter && this.preferredLocale
/*      */ 
/*      */ 
/*      */       
/*  786 */       .equals(another.preferredLocale) && this.afkTimeout == another.afkTimeout && this.roles
/*      */       
/*  788 */       .equals(another.roles) && this.channels
/*  789 */       .equals(another.channels) && 
/*  790 */       afkChannelId().equals(another.afkChannelId()) && 
/*  791 */       systemChannelId().equals(another.systemChannelId()) && this.systemChannelFlags == another.systemChannelFlags && 
/*      */       
/*  793 */       Objects.equals(this.iconHash, another.iconHash));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/*  802 */     int h = 5381;
/*  803 */     h += (h << 5) + this.name.hashCode();
/*  804 */     h += (h << 5) + Objects.hashCode(this.description);
/*  805 */     h += (h << 5) + this.region.hashCode();
/*  806 */     h += (h << 5) + this.verificationLevel;
/*  807 */     h += (h << 5) + this.defaultMessageNotifications;
/*  808 */     h += (h << 5) + this.explicitContentFilter;
/*  809 */     h += (h << 5) + this.preferredLocale.hashCode();
/*  810 */     h += (h << 5) + this.afkTimeout;
/*  811 */     h += (h << 5) + this.roles.hashCode();
/*  812 */     h += (h << 5) + this.channels.hashCode();
/*  813 */     h += (h << 5) + afkChannelId().hashCode();
/*  814 */     h += (h << 5) + systemChannelId().hashCode();
/*  815 */     h += (h << 5) + this.systemChannelFlags;
/*  816 */     h += (h << 5) + Objects.hashCode(this.iconHash);
/*  817 */     return h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*  826 */     StringBuilder builder = new StringBuilder("SerializedSourceGuildData{");
/*  827 */     builder.append("name=").append(this.name);
/*  828 */     if (this.description != null) {
/*  829 */       builder.append(", ");
/*  830 */       builder.append("description=").append(this.description);
/*      */     } 
/*  832 */     builder.append(", ");
/*  833 */     builder.append("region=").append(this.region);
/*  834 */     builder.append(", ");
/*  835 */     builder.append("verificationLevel=").append(this.verificationLevel);
/*  836 */     builder.append(", ");
/*  837 */     builder.append("defaultMessageNotifications=").append(this.defaultMessageNotifications);
/*  838 */     builder.append(", ");
/*  839 */     builder.append("explicitContentFilter=").append(this.explicitContentFilter);
/*  840 */     builder.append(", ");
/*  841 */     builder.append("preferredLocale=").append(this.preferredLocale);
/*  842 */     builder.append(", ");
/*  843 */     builder.append("afkTimeout=").append(this.afkTimeout);
/*  844 */     builder.append(", ");
/*  845 */     builder.append("roles=").append(this.roles);
/*  846 */     builder.append(", ");
/*  847 */     builder.append("channels=").append(this.channels);
/*  848 */     builder.append(", ");
/*  849 */     builder.append("afkChannelId=").append(afkChannelId().toString());
/*  850 */     builder.append(", ");
/*  851 */     builder.append("systemChannelId=").append(systemChannelId().toString());
/*  852 */     builder.append(", ");
/*  853 */     builder.append("systemChannelFlags=").append(this.systemChannelFlags);
/*  854 */     if (this.iconHash != null) {
/*  855 */       builder.append(", ");
/*  856 */       builder.append("iconHash=").append(this.iconHash);
/*      */     } 
/*  858 */     return builder.append("}").toString();
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonDeserialize
/*      */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*      */   @Generated(from = "SerializedSourceGuildData", generator = "Immutables")
/*      */   static final class Json
/*      */     implements SerializedSourceGuildData
/*      */   {
/*      */     String name;
/*      */     
/*  871 */     Optional<String> description = Optional.empty();
/*      */     String region;
/*      */     int verificationLevel;
/*      */     boolean verificationLevelIsSet;
/*      */     int defaultMessageNotifications;
/*      */     boolean defaultMessageNotificationsIsSet;
/*      */     int explicitContentFilter;
/*      */     boolean explicitContentFilterIsSet;
/*      */     String preferredLocale;
/*      */     int afkTimeout;
/*      */     boolean afkTimeoutIsSet;
/*  882 */     List<RoleTemplateData> roles = Collections.emptyList();
/*  883 */     List<ChannelData> channels = Collections.emptyList();
/*      */     
/*  885 */     Optional<Id> afkChannelId = Optional.empty();
/*      */ 
/*      */     
/*  888 */     Optional<Id> systemChannelId = Optional.empty();
/*      */     
/*      */     int systemChannelFlags;
/*      */     boolean systemChannelFlagsIsSet;
/*  892 */     Optional<String> iconHash = Optional.empty();
/*      */     @JsonProperty("name")
/*      */     public void setName(String name) {
/*  895 */       this.name = name;
/*      */     }
/*      */     @JsonProperty("description")
/*      */     public void setDescription(Optional<String> description) {
/*  899 */       this.description = description;
/*      */     }
/*      */     @JsonProperty("region")
/*      */     public void setRegion(String region) {
/*  903 */       this.region = region;
/*      */     }
/*      */     @JsonProperty("verification_level")
/*      */     public void setVerificationLevel(int verificationLevel) {
/*  907 */       this.verificationLevel = verificationLevel;
/*  908 */       this.verificationLevelIsSet = true;
/*      */     }
/*      */     @JsonProperty("default_message_notifications")
/*      */     public void setDefaultMessageNotifications(int defaultMessageNotifications) {
/*  912 */       this.defaultMessageNotifications = defaultMessageNotifications;
/*  913 */       this.defaultMessageNotificationsIsSet = true;
/*      */     }
/*      */     @JsonProperty("explicit_content_filter")
/*      */     public void setExplicitContentFilter(int explicitContentFilter) {
/*  917 */       this.explicitContentFilter = explicitContentFilter;
/*  918 */       this.explicitContentFilterIsSet = true;
/*      */     }
/*      */     @JsonProperty("preferred_locale")
/*      */     public void setPreferredLocale(String preferredLocale) {
/*  922 */       this.preferredLocale = preferredLocale;
/*      */     }
/*      */     @JsonProperty("afk_timeout")
/*      */     public void setAfkTimeout(int afkTimeout) {
/*  926 */       this.afkTimeout = afkTimeout;
/*  927 */       this.afkTimeoutIsSet = true;
/*      */     }
/*      */     @JsonProperty("roles")
/*      */     public void setRoles(List<RoleTemplateData> roles) {
/*  931 */       this.roles = roles;
/*      */     }
/*      */     @JsonProperty("channels")
/*      */     public void setChannels(List<ChannelData> channels) {
/*  935 */       this.channels = channels;
/*      */     }
/*      */     @JsonProperty("afk_channel_id")
/*      */     public void setAfkChannelId(Optional<Id> afkChannelId) {
/*  939 */       this.afkChannelId = afkChannelId;
/*      */     }
/*      */     @JsonProperty("system_channel_id")
/*      */     public void setSystemChannelId(Optional<Id> systemChannelId) {
/*  943 */       this.systemChannelId = systemChannelId;
/*      */     }
/*      */     @JsonProperty("system_channel_flags")
/*      */     public void setSystemChannelFlags(int systemChannelFlags) {
/*  947 */       this.systemChannelFlags = systemChannelFlags;
/*  948 */       this.systemChannelFlagsIsSet = true;
/*      */     }
/*      */     @JsonProperty("icon_hash")
/*      */     public void setIconHash(Optional<String> iconHash) {
/*  952 */       this.iconHash = iconHash;
/*      */     }
/*      */     public String name() {
/*  955 */       throw new UnsupportedOperationException();
/*      */     } public Optional<String> description() {
/*  957 */       throw new UnsupportedOperationException();
/*      */     } public String region() {
/*  959 */       throw new UnsupportedOperationException();
/*      */     } public int verificationLevel() {
/*  961 */       throw new UnsupportedOperationException();
/*      */     } public int defaultMessageNotifications() {
/*  963 */       throw new UnsupportedOperationException();
/*      */     } public int explicitContentFilter() {
/*  965 */       throw new UnsupportedOperationException();
/*      */     } public String preferredLocale() {
/*  967 */       throw new UnsupportedOperationException();
/*      */     } public int afkTimeout() {
/*  969 */       throw new UnsupportedOperationException();
/*      */     } public List<RoleTemplateData> roles() {
/*  971 */       throw new UnsupportedOperationException();
/*      */     } public List<ChannelData> channels() {
/*  973 */       throw new UnsupportedOperationException();
/*      */     } public Optional<Id> afkChannelId() {
/*  975 */       throw new UnsupportedOperationException();
/*      */     } public Optional<Id> systemChannelId() {
/*  977 */       throw new UnsupportedOperationException();
/*      */     } public int systemChannelFlags() {
/*  979 */       throw new UnsupportedOperationException();
/*      */     } public Optional<String> iconHash() {
/*  981 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*      */   static ImmutableSerializedSourceGuildData fromJson(Json json) {
/*  992 */     Builder builder = builder();
/*  993 */     if (json.name != null) {
/*  994 */       builder.name(json.name);
/*      */     }
/*  996 */     if (json.description != null) {
/*  997 */       builder.description(json.description);
/*      */     }
/*  999 */     if (json.region != null) {
/* 1000 */       builder.region(json.region);
/*      */     }
/* 1002 */     if (json.verificationLevelIsSet) {
/* 1003 */       builder.verificationLevel(json.verificationLevel);
/*      */     }
/* 1005 */     if (json.defaultMessageNotificationsIsSet) {
/* 1006 */       builder.defaultMessageNotifications(json.defaultMessageNotifications);
/*      */     }
/* 1008 */     if (json.explicitContentFilterIsSet) {
/* 1009 */       builder.explicitContentFilter(json.explicitContentFilter);
/*      */     }
/* 1011 */     if (json.preferredLocale != null) {
/* 1012 */       builder.preferredLocale(json.preferredLocale);
/*      */     }
/* 1014 */     if (json.afkTimeoutIsSet) {
/* 1015 */       builder.afkTimeout(json.afkTimeout);
/*      */     }
/* 1017 */     if (json.roles != null) {
/* 1018 */       builder.addAllRoles(json.roles);
/*      */     }
/* 1020 */     if (json.channels != null) {
/* 1021 */       builder.addAllChannels(json.channels);
/*      */     }
/* 1023 */     if (json.afkChannelId != null) {
/* 1024 */       builder.afkChannelId(json.afkChannelId);
/*      */     }
/* 1026 */     if (json.systemChannelId != null) {
/* 1027 */       builder.systemChannelId(json.systemChannelId);
/*      */     }
/* 1029 */     if (json.systemChannelFlagsIsSet) {
/* 1030 */       builder.systemChannelFlags(json.systemChannelFlags);
/*      */     }
/* 1032 */     if (json.iconHash != null) {
/* 1033 */       builder.iconHash(json.iconHash);
/*      */     }
/* 1035 */     return builder.build();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableSerializedSourceGuildData of(String name, Optional<String> description, String region, int verificationLevel, int defaultMessageNotifications, int explicitContentFilter, String preferredLocale, int afkTimeout, List<RoleTemplateData> roles, List<ChannelData> channels, Optional<Id> afkChannelId, Optional<Id> systemChannelId, int systemChannelFlags, Optional<String> iconHash) {
/* 1057 */     return of(name, description, region, verificationLevel, defaultMessageNotifications, explicitContentFilter, preferredLocale, afkTimeout, roles, channels, afkChannelId, systemChannelId, systemChannelFlags, iconHash);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableSerializedSourceGuildData of(String name, Optional<String> description, String region, int verificationLevel, int defaultMessageNotifications, int explicitContentFilter, String preferredLocale, int afkTimeout, Iterable<? extends RoleTemplateData> roles, Iterable<? extends ChannelData> channels, Optional<Id> afkChannelId, Optional<Id> systemChannelId, int systemChannelFlags, Optional<String> iconHash) {
/* 1079 */     return new ImmutableSerializedSourceGuildData(name, description, region, verificationLevel, defaultMessageNotifications, explicitContentFilter, preferredLocale, afkTimeout, roles, channels, afkChannelId, systemChannelId, systemChannelFlags, iconHash);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableSerializedSourceGuildData copyOf(SerializedSourceGuildData instance) {
/* 1090 */     if (instance instanceof ImmutableSerializedSourceGuildData) {
/* 1091 */       return (ImmutableSerializedSourceGuildData)instance;
/*      */     }
/* 1093 */     return builder()
/* 1094 */       .from(instance)
/* 1095 */       .build();
/*      */   }
/*      */   
/*      */   public boolean isAfkChannelIdPresent() {
/* 1099 */     return this.afkChannelId_present;
/*      */   }
/*      */   
/*      */   public long afkChannelIdOrElse(long defaultValue) {
/* 1103 */     return this.afkChannelId_present ? this.afkChannelId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isSystemChannelIdPresent() {
/* 1107 */     return this.systemChannelId_present;
/*      */   }
/*      */   
/*      */   public long systemChannelIdOrElse(long defaultValue) {
/* 1111 */     return this.systemChannelId_present ? this.systemChannelId_value : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Builder builder() {
/* 1137 */     return new Builder();
/*      */   }
/*      */ 
/*      */   
/*      */   @Generated(from = "SerializedSourceGuildData", generator = "Immutables")
/*      */   public static final class Builder
/*      */   {
/*      */     private static final long INIT_BIT_NAME = 1L;
/*      */     
/*      */     private static final long INIT_BIT_REGION = 2L;
/*      */     
/*      */     private static final long INIT_BIT_VERIFICATION_LEVEL = 4L;
/*      */     
/*      */     private static final long INIT_BIT_DEFAULT_MESSAGE_NOTIFICATIONS = 8L;
/*      */     
/*      */     private static final long INIT_BIT_EXPLICIT_CONTENT_FILTER = 16L;
/*      */     
/*      */     private static final long INIT_BIT_PREFERRED_LOCALE = 32L;
/*      */     private static final long INIT_BIT_AFK_TIMEOUT = 64L;
/*      */     private static final long INIT_BIT_SYSTEM_CHANNEL_FLAGS = 128L;
/* 1157 */     private long initBits = 255L;
/*      */     
/* 1159 */     private Optional<Id> afkChannelId_optional = Optional.empty();
/* 1160 */     private Optional<Id> systemChannelId_optional = Optional.empty();
/*      */     private String name;
/*      */     private String description;
/*      */     private String region;
/*      */     private int verificationLevel;
/*      */     private int defaultMessageNotifications;
/*      */     private int explicitContentFilter;
/*      */     private String preferredLocale;
/*      */     private int afkTimeout;
/* 1169 */     private List<RoleTemplateData> roles = new ArrayList<>();
/* 1170 */     private List<ChannelData> channels = new ArrayList<>();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private int systemChannelFlags;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private String iconHash;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(SerializedSourceGuildData instance) {
/* 1186 */       Objects.requireNonNull(instance, "instance");
/* 1187 */       name(instance.name());
/* 1188 */       Optional<String> descriptionOptional = instance.description();
/* 1189 */       if (descriptionOptional.isPresent()) {
/* 1190 */         description(descriptionOptional);
/*      */       }
/* 1192 */       region(instance.region());
/* 1193 */       verificationLevel(instance.verificationLevel());
/* 1194 */       defaultMessageNotifications(instance.defaultMessageNotifications());
/* 1195 */       explicitContentFilter(instance.explicitContentFilter());
/* 1196 */       preferredLocale(instance.preferredLocale());
/* 1197 */       afkTimeout(instance.afkTimeout());
/* 1198 */       addAllRoles(instance.roles());
/* 1199 */       addAllChannels(instance.channels());
/* 1200 */       afkChannelId(instance.afkChannelId());
/* 1201 */       systemChannelId(instance.systemChannelId());
/* 1202 */       systemChannelFlags(instance.systemChannelFlags());
/* 1203 */       Optional<String> iconHashOptional = instance.iconHash();
/* 1204 */       if (iconHashOptional.isPresent()) {
/* 1205 */         iconHash(iconHashOptional);
/*      */       }
/* 1207 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("name")
/*      */     public final Builder name(String name) {
/* 1217 */       this.name = Objects.<String>requireNonNull(name, "name");
/* 1218 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 1219 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder description(String description) {
/* 1228 */       this.description = Objects.<String>requireNonNull(description, "description");
/* 1229 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("description")
/*      */     public final Builder description(Optional<String> description) {
/* 1239 */       this.description = description.orElse(null);
/* 1240 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("region")
/*      */     public final Builder region(String region) {
/* 1250 */       this.region = Objects.<String>requireNonNull(region, "region");
/* 1251 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 1252 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("verification_level")
/*      */     public final Builder verificationLevel(int verificationLevel) {
/* 1262 */       this.verificationLevel = verificationLevel;
/* 1263 */       this.initBits &= 0xFFFFFFFFFFFFFFFBL;
/* 1264 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("default_message_notifications")
/*      */     public final Builder defaultMessageNotifications(int defaultMessageNotifications) {
/* 1274 */       this.defaultMessageNotifications = defaultMessageNotifications;
/* 1275 */       this.initBits &= 0xFFFFFFFFFFFFFFF7L;
/* 1276 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("explicit_content_filter")
/*      */     public final Builder explicitContentFilter(int explicitContentFilter) {
/* 1286 */       this.explicitContentFilter = explicitContentFilter;
/* 1287 */       this.initBits &= 0xFFFFFFFFFFFFFFEFL;
/* 1288 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("preferred_locale")
/*      */     public final Builder preferredLocale(String preferredLocale) {
/* 1298 */       this.preferredLocale = Objects.<String>requireNonNull(preferredLocale, "preferredLocale");
/* 1299 */       this.initBits &= 0xFFFFFFFFFFFFFFDFL;
/* 1300 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("afk_timeout")
/*      */     public final Builder afkTimeout(int afkTimeout) {
/* 1310 */       this.afkTimeout = afkTimeout;
/* 1311 */       this.initBits &= 0xFFFFFFFFFFFFFFBFL;
/* 1312 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addRole(RoleTemplateData element) {
/* 1321 */       this.roles.add(Objects.<RoleTemplateData>requireNonNull(element, "roles element"));
/* 1322 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addRoles(RoleTemplateData... elements) {
/* 1331 */       for (RoleTemplateData element : elements) {
/* 1332 */         this.roles.add(Objects.<RoleTemplateData>requireNonNull(element, "roles element"));
/*      */       }
/* 1334 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("roles")
/*      */     public final Builder roles(Iterable<? extends RoleTemplateData> elements) {
/* 1345 */       this.roles.clear();
/* 1346 */       return addAllRoles(elements);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addAllRoles(Iterable<? extends RoleTemplateData> elements) {
/* 1355 */       for (RoleTemplateData element : elements) {
/* 1356 */         this.roles.add(Objects.<RoleTemplateData>requireNonNull(element, "roles element"));
/*      */       }
/* 1358 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addChannel(ChannelData element) {
/* 1367 */       this.channels.add(Objects.<ChannelData>requireNonNull(element, "channels element"));
/* 1368 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addChannels(ChannelData... elements) {
/* 1377 */       for (ChannelData element : elements) {
/* 1378 */         this.channels.add(Objects.<ChannelData>requireNonNull(element, "channels element"));
/*      */       }
/* 1380 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("channels")
/*      */     public final Builder channels(Iterable<? extends ChannelData> elements) {
/* 1391 */       this.channels.clear();
/* 1392 */       return addAllChannels(elements);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addAllChannels(Iterable<? extends ChannelData> elements) {
/* 1401 */       for (ChannelData element : elements) {
/* 1402 */         this.channels.add(Objects.<ChannelData>requireNonNull(element, "channels element"));
/*      */       }
/* 1404 */       return this;
/*      */     }
/*      */     
/*      */     public Builder afkChannelId(String value) {
/* 1408 */       this.afkChannelId_optional = Optional.of(Id.of(value));
/* 1409 */       return this;
/*      */     }
/*      */     
/*      */     public Builder afkChannelId(long value) {
/* 1413 */       this.afkChannelId_optional = Optional.of(Id.of(value));
/* 1414 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("afk_channel_id")
/*      */     public Builder afkChannelId(Optional<Id> value) {
/* 1419 */       this.afkChannelId_optional = value;
/* 1420 */       return this;
/*      */     }
/*      */     
/*      */     public Builder systemChannelId(String value) {
/* 1424 */       this.systemChannelId_optional = Optional.of(Id.of(value));
/* 1425 */       return this;
/*      */     }
/*      */     
/*      */     public Builder systemChannelId(long value) {
/* 1429 */       this.systemChannelId_optional = Optional.of(Id.of(value));
/* 1430 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("system_channel_id")
/*      */     public Builder systemChannelId(Optional<Id> value) {
/* 1435 */       this.systemChannelId_optional = value;
/* 1436 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("system_channel_flags")
/*      */     public final Builder systemChannelFlags(int systemChannelFlags) {
/* 1446 */       this.systemChannelFlags = systemChannelFlags;
/* 1447 */       this.initBits &= 0xFFFFFFFFFFFFFF7FL;
/* 1448 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder iconHash(String iconHash) {
/* 1457 */       this.iconHash = Objects.<String>requireNonNull(iconHash, "iconHash");
/* 1458 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("icon_hash")
/*      */     public final Builder iconHash(Optional<String> iconHash) {
/* 1468 */       this.iconHash = iconHash.orElse(null);
/* 1469 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ImmutableSerializedSourceGuildData build() {
/* 1478 */       if (this.initBits != 0L) {
/* 1479 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*      */       }
/* 1481 */       return new ImmutableSerializedSourceGuildData(null, this.name, this.description, this.region, this.verificationLevel, this.defaultMessageNotifications, this.explicitContentFilter, this.preferredLocale, this.afkTimeout, ImmutableSerializedSourceGuildData
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1491 */           .createUnmodifiableList(true, (List)this.roles), ImmutableSerializedSourceGuildData
/* 1492 */           .createUnmodifiableList(true, (List)this.channels), 
/* 1493 */           afkChannelId_build(), 
/* 1494 */           systemChannelId_build(), this.systemChannelFlags, this.iconHash);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private String formatRequiredAttributesMessage() {
/* 1500 */       List<String> attributes = new ArrayList<>();
/* 1501 */       if ((this.initBits & 0x1L) != 0L) attributes.add("name"); 
/* 1502 */       if ((this.initBits & 0x2L) != 0L) attributes.add("region"); 
/* 1503 */       if ((this.initBits & 0x4L) != 0L) attributes.add("verificationLevel"); 
/* 1504 */       if ((this.initBits & 0x8L) != 0L) attributes.add("defaultMessageNotifications"); 
/* 1505 */       if ((this.initBits & 0x10L) != 0L) attributes.add("explicitContentFilter"); 
/* 1506 */       if ((this.initBits & 0x20L) != 0L) attributes.add("preferredLocale"); 
/* 1507 */       if ((this.initBits & 0x40L) != 0L) attributes.add("afkTimeout"); 
/* 1508 */       if ((this.initBits & 0x80L) != 0L) attributes.add("systemChannelFlags"); 
/* 1509 */       return "Cannot build SerializedSourceGuildData, some of required attributes are not set " + attributes;
/*      */     }
/*      */     
/*      */     private Optional<Id> afkChannelId_build() {
/* 1513 */       return this.afkChannelId_optional;
/*      */     }
/*      */     
/*      */     private Optional<Id> systemChannelId_build() {
/* 1517 */       return this.systemChannelId_optional;
/*      */     }
/*      */     private Builder() {} }
/*      */   
/*      */   private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
/*      */     ArrayList<T> list;
/* 1523 */     if (iterable instanceof Collection) {
/* 1524 */       int size = ((Collection)iterable).size();
/* 1525 */       if (size == 0) return Collections.emptyList(); 
/* 1526 */       list = new ArrayList<>();
/*      */     } else {
/* 1528 */       list = new ArrayList<>();
/*      */     } 
/* 1530 */     for (T element : iterable) {
/* 1531 */       if (skipNulls && element == null)
/* 1532 */         continue;  if (checkNulls) Objects.requireNonNull(element, "element"); 
/* 1533 */       list.add(element);
/*      */     } 
/* 1535 */     return list;
/*      */   }
/*      */   
/*      */   private static <T> List<T> createUnmodifiableList(boolean clone, List<T> list) {
/* 1539 */     switch (list.size()) { case 0:
/* 1540 */         return Collections.emptyList();
/* 1541 */       case 1: return Collections.singletonList(list.get(0)); }
/*      */     
/* 1543 */     if (clone) {
/* 1544 */       return Collections.unmodifiableList(new ArrayList<>(list));
/*      */     }
/* 1546 */     if (list instanceof ArrayList) {
/* 1547 */       ((ArrayList)list).trimToSize();
/*      */     }
/* 1549 */     return Collections.unmodifiableList(list);
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableSerializedSourceGuildData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */