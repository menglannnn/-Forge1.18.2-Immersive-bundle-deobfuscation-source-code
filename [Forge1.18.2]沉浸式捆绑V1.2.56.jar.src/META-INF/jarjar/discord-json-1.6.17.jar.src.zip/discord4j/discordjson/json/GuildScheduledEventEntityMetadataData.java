/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ @JsonSerialize(as = ImmutableGuildScheduledEventEntityMetadataData.class)
/*    */ @JsonDeserialize(as = ImmutableGuildScheduledEventEntityMetadataData.class)
/*    */ @Immutable
/*    */ public interface GuildScheduledEventEntityMetadataData
/*    */ {
/*    */   static ImmutableGuildScheduledEventEntityMetadataData.Builder builder() {
/* 14 */     return ImmutableGuildScheduledEventEntityMetadataData.builder();
/*    */   }
/*    */   
/*    */   Possible<String> location();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\GuildScheduledEventEntityMetadataData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */