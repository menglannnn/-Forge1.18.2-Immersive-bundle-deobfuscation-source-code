/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "IntegrationCreateRequest", generator = "Immutables")
/*     */ public final class ImmutableIntegrationCreateRequest
/*     */   implements IntegrationCreateRequest
/*     */ {
/*     */   private final String type;
/*     */   private final String id;
/*     */   
/*     */   private ImmutableIntegrationCreateRequest(String type, String id) {
/*  29 */     this.type = Objects.<String>requireNonNull(type, "type");
/*  30 */     this.id = Objects.<String>requireNonNull(id, "id");
/*     */   }
/*     */   
/*     */   private ImmutableIntegrationCreateRequest(ImmutableIntegrationCreateRequest original, String type, String id) {
/*  34 */     this.type = type;
/*  35 */     this.id = id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("type")
/*     */   public String type() {
/*  44 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("id")
/*     */   public String id() {
/*  53 */     return this.id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableIntegrationCreateRequest withType(String value) {
/*  63 */     String newValue = Objects.<String>requireNonNull(value, "type");
/*  64 */     if (this.type.equals(newValue)) return this; 
/*  65 */     return new ImmutableIntegrationCreateRequest(this, newValue, this.id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableIntegrationCreateRequest withId(String value) {
/*  75 */     String newValue = Objects.<String>requireNonNull(value, "id");
/*  76 */     if (this.id.equals(newValue)) return this; 
/*  77 */     return new ImmutableIntegrationCreateRequest(this, this.type, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/*  86 */     if (this == another) return true; 
/*  87 */     return (another instanceof ImmutableIntegrationCreateRequest && 
/*  88 */       equalTo(0, (ImmutableIntegrationCreateRequest)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableIntegrationCreateRequest another) {
/*  92 */     return (this.type.equals(another.type) && this.id
/*  93 */       .equals(another.id));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 102 */     int h = 5381;
/* 103 */     h += (h << 5) + this.type.hashCode();
/* 104 */     h += (h << 5) + this.id.hashCode();
/* 105 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 114 */     return "IntegrationCreateRequest{type=" + this.type + ", id=" + this.id + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "IntegrationCreateRequest", generator = "Immutables")
/*     */   static final class Json
/*     */     implements IntegrationCreateRequest
/*     */   {
/*     */     String type;
/*     */     
/*     */     String id;
/*     */ 
/*     */     
/*     */     @JsonProperty("type")
/*     */     public void setType(String type) {
/* 133 */       this.type = type;
/*     */     }
/*     */     @JsonProperty("id")
/*     */     public void setId(String id) {
/* 137 */       this.id = id;
/*     */     }
/*     */     public String type() {
/* 140 */       throw new UnsupportedOperationException();
/*     */     } public String id() {
/* 142 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableIntegrationCreateRequest fromJson(Json json) {
/* 153 */     Builder builder = builder();
/* 154 */     if (json.type != null) {
/* 155 */       builder.type(json.type);
/*     */     }
/* 157 */     if (json.id != null) {
/* 158 */       builder.id(json.id);
/*     */     }
/* 160 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableIntegrationCreateRequest of(String type, String id) {
/* 170 */     return new ImmutableIntegrationCreateRequest(type, id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableIntegrationCreateRequest copyOf(IntegrationCreateRequest instance) {
/* 181 */     if (instance instanceof ImmutableIntegrationCreateRequest) {
/* 182 */       return (ImmutableIntegrationCreateRequest)instance;
/*     */     }
/* 184 */     return builder()
/* 185 */       .from(instance)
/* 186 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 200 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "IntegrationCreateRequest", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_TYPE = 1L;
/*     */ 
/*     */     
/*     */     private static final long INIT_BIT_ID = 2L;
/*     */ 
/*     */     
/* 214 */     private long initBits = 3L;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String type;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String id;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(IntegrationCreateRequest instance) {
/* 230 */       Objects.requireNonNull(instance, "instance");
/* 231 */       type(instance.type());
/* 232 */       id(instance.id());
/* 233 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("type")
/*     */     public final Builder type(String type) {
/* 243 */       this.type = Objects.<String>requireNonNull(type, "type");
/* 244 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 245 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("id")
/*     */     public final Builder id(String id) {
/* 255 */       this.id = Objects.<String>requireNonNull(id, "id");
/* 256 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 257 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableIntegrationCreateRequest build() {
/* 266 */       if (this.initBits != 0L) {
/* 267 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 269 */       return new ImmutableIntegrationCreateRequest(null, this.type, this.id);
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 273 */       List<String> attributes = new ArrayList<>();
/* 274 */       if ((this.initBits & 0x1L) != 0L) attributes.add("type"); 
/* 275 */       if ((this.initBits & 0x2L) != 0L) attributes.add("id"); 
/* 276 */       return "Cannot build IntegrationCreateRequest, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableIntegrationCreateRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */