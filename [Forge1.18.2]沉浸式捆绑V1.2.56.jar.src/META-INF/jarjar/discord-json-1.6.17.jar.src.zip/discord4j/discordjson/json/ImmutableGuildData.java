/*      */ package discord4j.discordjson.json;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*      */ import com.fasterxml.jackson.annotation.JsonCreator;
/*      */ import com.fasterxml.jackson.annotation.JsonProperty;
/*      */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*      */ import discord4j.discordjson.Id;
/*      */ import discord4j.discordjson.possible.Possible;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import java.util.Optional;
/*      */ import java.util.OptionalInt;
/*      */ import java.util.stream.Collectors;
/*      */ import java.util.stream.LongStream;
/*      */ import java.util.stream.StreamSupport;
/*      */ import org.immutables.value.Generated;
/*      */ import reactor.util.annotation.Nullable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Generated(from = "GuildData", generator = "Immutables")
/*      */ public final class ImmutableGuildData
/*      */   implements GuildData
/*      */ {
/*      */   private final long id_value;
/*      */   private final String name;
/*      */   private final String icon;
/*      */   private final String splash;
/*      */   private final String discoverySplash;
/*      */   private final Boolean owner_value;
/*      */   private final boolean owner_absent;
/*      */   private final Long permissions_value;
/*      */   private final boolean permissions_absent;
/*      */   private final long afkChannelId_value;
/*      */   private final boolean afkChannelId_present;
/*      */   private final Boolean embedEnabled_value;
/*      */   private final boolean embedEnabled_absent;
/*      */   private final long embedChannelId_value;
/*      */   private final boolean embedChannelId_absent;
/*      */   private final boolean embedChannelId_isNull;
/*      */   private final List<String> features;
/*      */   private final long applicationId_value;
/*      */   private final boolean applicationId_present;
/*      */   private final Boolean widgetEnabled_value;
/*      */   private final boolean widgetEnabled_absent;
/*      */   private final long widgetChannelId_value;
/*      */   private final boolean widgetChannelId_absent;
/*      */   private final boolean widgetChannelId_isNull;
/*      */   private final long systemChannelId_value;
/*      */   private final boolean systemChannelId_present;
/*      */   private final Integer systemChannelFlags;
/*      */   private final long rulesChannelId_value;
/*      */   private final boolean rulesChannelId_present;
/*      */   private final Integer maxPresences_value;
/*      */   private final boolean maxPresences_absent;
/*      */   private final Integer maxMembers_value;
/*      */   private final boolean maxMembers_absent;
/*      */   private final String vanityUrlCode;
/*      */   private final String description;
/*      */   private final String banner;
/*      */   private final Integer premiumSubscriptionCount_value;
/*      */   private final boolean premiumSubscriptionCount_absent;
/*      */   private final long publicUpdatesChannelId_value;
/*      */   private final boolean publicUpdatesChannelId_present;
/*      */   private final Integer maxVideoChannelUsers_value;
/*      */   private final boolean maxVideoChannelUsers_absent;
/*      */   private final Integer approximateMemberCount_value;
/*      */   private final boolean approximateMemberCount_absent;
/*      */   private final Integer approximatePresenceCount_value;
/*      */   private final boolean approximatePresenceCount_absent;
/*      */   private final WelcomeScreenData welcomeScreen_value;
/*      */   private final boolean welcomeScreen_absent;
/*      */   private final Boolean nsfw_value;
/*      */   private final boolean nsfw_absent;
/*      */   private final long safetyAlertsChannelId_value;
/*      */   private final boolean safetyAlertsChannelId_present;
/*      */   private final int verificationLevel;
/*      */   private final int nsfwLevel;
/*      */   private final long ownerId_value;
/*      */   private final String region_value;
/*      */   private final boolean region_absent;
/*      */   private final int afkTimeout;
/*      */   private final int defaultMessageNotifications;
/*      */   private final int explicitContentFilter;
/*      */   private final int mfaLevel;
/*      */   private final int premiumTier;
/*      */   private final String preferredLocale;
/*      */   private final String joinedAt;
/*      */   private final boolean large;
/*      */   private final Boolean unavailable_value;
/*      */   private final boolean unavailable_absent;
/*      */   private final int memberCount;
/*      */   private final long[] roles_value;
/*      */   private final long[] emojis_value;
/*      */   private final List<Id> stickers_value;
/*      */   private final boolean stickers_absent;
/*      */   private final long[] members_value;
/*      */   private final long[] channels_value;
/*      */   private static final byte STAGE_INITIALIZING = -1;
/*      */   private static final byte STAGE_UNINITIALIZED = 0;
/*      */   private static final byte STAGE_INITIALIZED = 1;
/*      */   
/*      */   private ImmutableGuildData(Id id, String name, Optional<String> icon, Optional<String> splash, Optional<String> discoverySplash, Possible<Boolean> owner, Possible<Long> permissions, Optional<Id> afkChannelId, Possible<Boolean> embedEnabled, Possible<Optional<Id>> embedChannelId, Iterable<String> features, Optional<Id> applicationId, Possible<Boolean> widgetEnabled, Possible<Optional<Id>> widgetChannelId, Optional<Id> systemChannelId, OptionalInt systemChannelFlags, Optional<Id> rulesChannelId, Possible<Optional<Integer>> maxPresences, Possible<Integer> maxMembers, Optional<String> vanityUrlCode, Optional<String> description, Optional<String> banner, Possible<Integer> premiumSubscriptionCount, Optional<Id> publicUpdatesChannelId, Possible<Integer> maxVideoChannelUsers, Possible<Integer> approximateMemberCount, Possible<Integer> approximatePresenceCount, Possible<WelcomeScreenData> welcomeScreen, Possible<Boolean> nsfw, Optional<Id> safetyAlertsChannelId, int verificationLevel, int nsfwLevel, Id ownerId, Possible<Optional<String>> region, int afkTimeout, int defaultMessageNotifications, int explicitContentFilter, int mfaLevel, int premiumTier, String preferredLocale, String joinedAt, boolean large, Possible<Boolean> unavailable, int memberCount, List<Id> roles, List<Id> emojis, Possible<List<Id>> stickers, List<Id> members, List<Id> channels) {
/*  160 */     Id id$impl = id;
/*  161 */     this.name = Objects.<String>requireNonNull(name, "name");
/*  162 */     this.icon = icon.orElse(null);
/*  163 */     this.splash = splash.orElse(null);
/*  164 */     this.discoverySplash = discoverySplash.orElse(null);
/*  165 */     Possible<Boolean> owner$impl = owner;
/*  166 */     Possible<Long> permissions$impl = permissions;
/*  167 */     Optional<Id> afkChannelId$impl = afkChannelId;
/*  168 */     Possible<Boolean> embedEnabled$impl = embedEnabled;
/*  169 */     Possible<Optional<Id>> embedChannelId$impl = embedChannelId;
/*  170 */     this.features = createUnmodifiableList(false, createSafeList(features, true, false));
/*  171 */     Optional<Id> applicationId$impl = applicationId;
/*  172 */     Possible<Boolean> widgetEnabled$impl = widgetEnabled;
/*  173 */     Possible<Optional<Id>> widgetChannelId$impl = widgetChannelId;
/*  174 */     Optional<Id> systemChannelId$impl = systemChannelId;
/*  175 */     this.systemChannelFlags = systemChannelFlags.isPresent() ? Integer.valueOf(systemChannelFlags.getAsInt()) : null;
/*  176 */     Optional<Id> rulesChannelId$impl = rulesChannelId;
/*  177 */     Possible<Optional<Integer>> maxPresences$impl = maxPresences;
/*  178 */     Possible<Integer> maxMembers$impl = maxMembers;
/*  179 */     this.vanityUrlCode = vanityUrlCode.orElse(null);
/*  180 */     this.description = description.orElse(null);
/*  181 */     this.banner = banner.orElse(null);
/*  182 */     Possible<Integer> premiumSubscriptionCount$impl = premiumSubscriptionCount;
/*  183 */     Optional<Id> publicUpdatesChannelId$impl = publicUpdatesChannelId;
/*  184 */     Possible<Integer> maxVideoChannelUsers$impl = maxVideoChannelUsers;
/*  185 */     Possible<Integer> approximateMemberCount$impl = approximateMemberCount;
/*  186 */     Possible<Integer> approximatePresenceCount$impl = approximatePresenceCount;
/*  187 */     Possible<WelcomeScreenData> welcomeScreen$impl = welcomeScreen;
/*  188 */     Possible<Boolean> nsfw$impl = nsfw;
/*  189 */     Optional<Id> safetyAlertsChannelId$impl = safetyAlertsChannelId;
/*  190 */     this.verificationLevel = verificationLevel;
/*  191 */     this.nsfwLevel = nsfwLevel;
/*  192 */     Id ownerId$impl = ownerId;
/*  193 */     Possible<Optional<String>> region$impl = region;
/*  194 */     this.afkTimeout = afkTimeout;
/*  195 */     this.defaultMessageNotifications = defaultMessageNotifications;
/*  196 */     this.explicitContentFilter = explicitContentFilter;
/*  197 */     this.mfaLevel = mfaLevel;
/*  198 */     this.premiumTier = premiumTier;
/*  199 */     this.preferredLocale = Objects.<String>requireNonNull(preferredLocale, "preferredLocale");
/*  200 */     this.joinedAt = Objects.<String>requireNonNull(joinedAt, "joinedAt");
/*  201 */     this.large = large;
/*  202 */     Possible<Boolean> unavailable$impl = unavailable;
/*  203 */     this.memberCount = memberCount;
/*  204 */     List<Id> roles$impl = roles;
/*  205 */     List<Id> emojis$impl = emojis;
/*  206 */     Possible<List<Id>> stickers$impl = stickers;
/*  207 */     List<Id> members$impl = members;
/*  208 */     List<Id> channels$impl = channels;
/*  209 */     this.id_value = id$impl.asLong();
/*  210 */     this.owner_value = owner$impl.toOptional().orElse(null);
/*  211 */     this.owner_absent = owner$impl.isAbsent();
/*  212 */     this.permissions_value = permissions$impl.toOptional().orElse(null);
/*  213 */     this.permissions_absent = permissions$impl.isAbsent();
/*  214 */     this
/*      */       
/*  216 */       .afkChannelId_value = ((Long)afkChannelId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  217 */     this.afkChannelId_present = afkChannelId$impl.isPresent();
/*  218 */     this.embedEnabled_value = embedEnabled$impl.toOptional().orElse(null);
/*  219 */     this.embedEnabled_absent = embedEnabled$impl.isAbsent();
/*  220 */     this
/*      */       
/*  222 */       .embedChannelId_value = ((Long)Possible.flatOpt(embedChannelId$impl).map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  223 */     this.embedChannelId_absent = embedChannelId$impl.isAbsent();
/*  224 */     this.embedChannelId_isNull = (!embedChannelId$impl.isAbsent() && !((Optional)embedChannelId$impl.get()).isPresent());
/*  225 */     this
/*      */       
/*  227 */       .applicationId_value = ((Long)applicationId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  228 */     this.applicationId_present = applicationId$impl.isPresent();
/*  229 */     this.widgetEnabled_value = widgetEnabled$impl.toOptional().orElse(null);
/*  230 */     this.widgetEnabled_absent = widgetEnabled$impl.isAbsent();
/*  231 */     this
/*      */       
/*  233 */       .widgetChannelId_value = ((Long)Possible.flatOpt(widgetChannelId$impl).map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  234 */     this.widgetChannelId_absent = widgetChannelId$impl.isAbsent();
/*  235 */     this.widgetChannelId_isNull = (!widgetChannelId$impl.isAbsent() && !((Optional)widgetChannelId$impl.get()).isPresent());
/*  236 */     this
/*      */       
/*  238 */       .systemChannelId_value = ((Long)systemChannelId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  239 */     this.systemChannelId_present = systemChannelId$impl.isPresent();
/*  240 */     this
/*      */       
/*  242 */       .rulesChannelId_value = ((Long)rulesChannelId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  243 */     this.rulesChannelId_present = rulesChannelId$impl.isPresent();
/*  244 */     this.maxPresences_value = Possible.flatOpt(maxPresences$impl).orElse(null);
/*  245 */     this.maxPresences_absent = maxPresences$impl.isAbsent();
/*  246 */     this.maxMembers_value = maxMembers$impl.toOptional().orElse(null);
/*  247 */     this.maxMembers_absent = maxMembers$impl.isAbsent();
/*  248 */     this.premiumSubscriptionCount_value = premiumSubscriptionCount$impl.toOptional().orElse(null);
/*  249 */     this.premiumSubscriptionCount_absent = premiumSubscriptionCount$impl.isAbsent();
/*  250 */     this
/*      */       
/*  252 */       .publicUpdatesChannelId_value = ((Long)publicUpdatesChannelId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  253 */     this.publicUpdatesChannelId_present = publicUpdatesChannelId$impl.isPresent();
/*  254 */     this.maxVideoChannelUsers_value = maxVideoChannelUsers$impl.toOptional().orElse(null);
/*  255 */     this.maxVideoChannelUsers_absent = maxVideoChannelUsers$impl.isAbsent();
/*  256 */     this.approximateMemberCount_value = approximateMemberCount$impl.toOptional().orElse(null);
/*  257 */     this.approximateMemberCount_absent = approximateMemberCount$impl.isAbsent();
/*  258 */     this.approximatePresenceCount_value = approximatePresenceCount$impl.toOptional().orElse(null);
/*  259 */     this.approximatePresenceCount_absent = approximatePresenceCount$impl.isAbsent();
/*  260 */     this.welcomeScreen_value = welcomeScreen$impl.toOptional().orElse(null);
/*  261 */     this.welcomeScreen_absent = welcomeScreen$impl.isAbsent();
/*  262 */     this.nsfw_value = nsfw$impl.toOptional().orElse(null);
/*  263 */     this.nsfw_absent = nsfw$impl.isAbsent();
/*  264 */     this
/*      */       
/*  266 */       .safetyAlertsChannelId_value = ((Long)safetyAlertsChannelId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  267 */     this.safetyAlertsChannelId_present = safetyAlertsChannelId$impl.isPresent();
/*  268 */     this.ownerId_value = ownerId$impl.asLong();
/*  269 */     this.region_value = Possible.flatOpt(region$impl).orElse(null);
/*  270 */     this.region_absent = region$impl.isAbsent();
/*  271 */     this.unavailable_value = unavailable$impl.toOptional().orElse(null);
/*  272 */     this.unavailable_absent = unavailable$impl.isAbsent();
/*  273 */     this
/*      */       
/*  275 */       .roles_value = roles$impl.stream().mapToLong(Id::asLong).toArray();
/*  276 */     this
/*      */       
/*  278 */       .emojis_value = emojis$impl.stream().mapToLong(Id::asLong).toArray();
/*  279 */     this.stickers_value = stickers$impl.toOptional().orElse(null);
/*  280 */     this.stickers_absent = stickers$impl.isAbsent();
/*  281 */     this
/*      */       
/*  283 */       .members_value = members$impl.stream().mapToLong(Id::asLong).toArray();
/*  284 */     this
/*      */       
/*  286 */       .channels_value = channels$impl.stream().mapToLong(Id::asLong).toArray();
/*  287 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ImmutableGuildData(ImmutableGuildData original, Id id, String name, String icon, String splash, String discoverySplash, Possible<Boolean> owner, Possible<Long> permissions, Optional<Id> afkChannelId, Possible<Boolean> embedEnabled, Possible<Optional<Id>> embedChannelId, List<String> features, Optional<Id> applicationId, Possible<Boolean> widgetEnabled, Possible<Optional<Id>> widgetChannelId, Optional<Id> systemChannelId, Integer systemChannelFlags, Optional<Id> rulesChannelId, Possible<Optional<Integer>> maxPresences, Possible<Integer> maxMembers, String vanityUrlCode, String description, String banner, Possible<Integer> premiumSubscriptionCount, Optional<Id> publicUpdatesChannelId, Possible<Integer> maxVideoChannelUsers, Possible<Integer> approximateMemberCount, Possible<Integer> approximatePresenceCount, Possible<WelcomeScreenData> welcomeScreen, Possible<Boolean> nsfw, Optional<Id> safetyAlertsChannelId, int verificationLevel, int nsfwLevel, Id ownerId, Possible<Optional<String>> region, int afkTimeout, int defaultMessageNotifications, int explicitContentFilter, int mfaLevel, int premiumTier, String preferredLocale, String joinedAt, boolean large, Possible<Boolean> unavailable, int memberCount, List<Id> roles, List<Id> emojis, Possible<List<Id>> stickers, List<Id> members, List<Id> channels) {
/*  341 */     Id id$impl = id;
/*  342 */     this.name = name;
/*  343 */     this.icon = icon;
/*  344 */     this.splash = splash;
/*  345 */     this.discoverySplash = discoverySplash;
/*  346 */     Possible<Boolean> owner$impl = owner;
/*  347 */     Possible<Long> permissions$impl = permissions;
/*  348 */     Optional<Id> afkChannelId$impl = afkChannelId;
/*  349 */     Possible<Boolean> embedEnabled$impl = embedEnabled;
/*  350 */     Possible<Optional<Id>> embedChannelId$impl = embedChannelId;
/*  351 */     this.features = features;
/*  352 */     Optional<Id> applicationId$impl = applicationId;
/*  353 */     Possible<Boolean> widgetEnabled$impl = widgetEnabled;
/*  354 */     Possible<Optional<Id>> widgetChannelId$impl = widgetChannelId;
/*  355 */     Optional<Id> systemChannelId$impl = systemChannelId;
/*  356 */     this.systemChannelFlags = systemChannelFlags;
/*  357 */     Optional<Id> rulesChannelId$impl = rulesChannelId;
/*  358 */     Possible<Optional<Integer>> maxPresences$impl = maxPresences;
/*  359 */     Possible<Integer> maxMembers$impl = maxMembers;
/*  360 */     this.vanityUrlCode = vanityUrlCode;
/*  361 */     this.description = description;
/*  362 */     this.banner = banner;
/*  363 */     Possible<Integer> premiumSubscriptionCount$impl = premiumSubscriptionCount;
/*  364 */     Optional<Id> publicUpdatesChannelId$impl = publicUpdatesChannelId;
/*  365 */     Possible<Integer> maxVideoChannelUsers$impl = maxVideoChannelUsers;
/*  366 */     Possible<Integer> approximateMemberCount$impl = approximateMemberCount;
/*  367 */     Possible<Integer> approximatePresenceCount$impl = approximatePresenceCount;
/*  368 */     Possible<WelcomeScreenData> welcomeScreen$impl = welcomeScreen;
/*  369 */     Possible<Boolean> nsfw$impl = nsfw;
/*  370 */     Optional<Id> safetyAlertsChannelId$impl = safetyAlertsChannelId;
/*  371 */     this.verificationLevel = verificationLevel;
/*  372 */     this.nsfwLevel = nsfwLevel;
/*  373 */     Id ownerId$impl = ownerId;
/*  374 */     Possible<Optional<String>> region$impl = region;
/*  375 */     this.afkTimeout = afkTimeout;
/*  376 */     this.defaultMessageNotifications = defaultMessageNotifications;
/*  377 */     this.explicitContentFilter = explicitContentFilter;
/*  378 */     this.mfaLevel = mfaLevel;
/*  379 */     this.premiumTier = premiumTier;
/*  380 */     this.preferredLocale = preferredLocale;
/*  381 */     this.joinedAt = joinedAt;
/*  382 */     this.large = large;
/*  383 */     Possible<Boolean> unavailable$impl = unavailable;
/*  384 */     this.memberCount = memberCount;
/*  385 */     List<Id> roles$impl = roles;
/*  386 */     List<Id> emojis$impl = emojis;
/*  387 */     Possible<List<Id>> stickers$impl = stickers;
/*  388 */     List<Id> members$impl = members;
/*  389 */     List<Id> channels$impl = channels;
/*  390 */     this.id_value = id$impl.asLong();
/*  391 */     this.owner_value = owner$impl.toOptional().orElse(null);
/*  392 */     this.owner_absent = owner$impl.isAbsent();
/*  393 */     this.permissions_value = permissions$impl.toOptional().orElse(null);
/*  394 */     this.permissions_absent = permissions$impl.isAbsent();
/*  395 */     this
/*      */       
/*  397 */       .afkChannelId_value = ((Long)afkChannelId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  398 */     this.afkChannelId_present = afkChannelId$impl.isPresent();
/*  399 */     this.embedEnabled_value = embedEnabled$impl.toOptional().orElse(null);
/*  400 */     this.embedEnabled_absent = embedEnabled$impl.isAbsent();
/*  401 */     this
/*      */       
/*  403 */       .embedChannelId_value = ((Long)Possible.flatOpt(embedChannelId$impl).map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  404 */     this.embedChannelId_absent = embedChannelId$impl.isAbsent();
/*  405 */     this.embedChannelId_isNull = (!embedChannelId$impl.isAbsent() && !((Optional)embedChannelId$impl.get()).isPresent());
/*  406 */     this
/*      */       
/*  408 */       .applicationId_value = ((Long)applicationId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  409 */     this.applicationId_present = applicationId$impl.isPresent();
/*  410 */     this.widgetEnabled_value = widgetEnabled$impl.toOptional().orElse(null);
/*  411 */     this.widgetEnabled_absent = widgetEnabled$impl.isAbsent();
/*  412 */     this
/*      */       
/*  414 */       .widgetChannelId_value = ((Long)Possible.flatOpt(widgetChannelId$impl).map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  415 */     this.widgetChannelId_absent = widgetChannelId$impl.isAbsent();
/*  416 */     this.widgetChannelId_isNull = (!widgetChannelId$impl.isAbsent() && !((Optional)widgetChannelId$impl.get()).isPresent());
/*  417 */     this
/*      */       
/*  419 */       .systemChannelId_value = ((Long)systemChannelId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  420 */     this.systemChannelId_present = systemChannelId$impl.isPresent();
/*  421 */     this
/*      */       
/*  423 */       .rulesChannelId_value = ((Long)rulesChannelId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  424 */     this.rulesChannelId_present = rulesChannelId$impl.isPresent();
/*  425 */     this.maxPresences_value = Possible.flatOpt(maxPresences$impl).orElse(null);
/*  426 */     this.maxPresences_absent = maxPresences$impl.isAbsent();
/*  427 */     this.maxMembers_value = maxMembers$impl.toOptional().orElse(null);
/*  428 */     this.maxMembers_absent = maxMembers$impl.isAbsent();
/*  429 */     this.premiumSubscriptionCount_value = premiumSubscriptionCount$impl.toOptional().orElse(null);
/*  430 */     this.premiumSubscriptionCount_absent = premiumSubscriptionCount$impl.isAbsent();
/*  431 */     this
/*      */       
/*  433 */       .publicUpdatesChannelId_value = ((Long)publicUpdatesChannelId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  434 */     this.publicUpdatesChannelId_present = publicUpdatesChannelId$impl.isPresent();
/*  435 */     this.maxVideoChannelUsers_value = maxVideoChannelUsers$impl.toOptional().orElse(null);
/*  436 */     this.maxVideoChannelUsers_absent = maxVideoChannelUsers$impl.isAbsent();
/*  437 */     this.approximateMemberCount_value = approximateMemberCount$impl.toOptional().orElse(null);
/*  438 */     this.approximateMemberCount_absent = approximateMemberCount$impl.isAbsent();
/*  439 */     this.approximatePresenceCount_value = approximatePresenceCount$impl.toOptional().orElse(null);
/*  440 */     this.approximatePresenceCount_absent = approximatePresenceCount$impl.isAbsent();
/*  441 */     this.welcomeScreen_value = welcomeScreen$impl.toOptional().orElse(null);
/*  442 */     this.welcomeScreen_absent = welcomeScreen$impl.isAbsent();
/*  443 */     this.nsfw_value = nsfw$impl.toOptional().orElse(null);
/*  444 */     this.nsfw_absent = nsfw$impl.isAbsent();
/*  445 */     this
/*      */       
/*  447 */       .safetyAlertsChannelId_value = ((Long)safetyAlertsChannelId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  448 */     this.safetyAlertsChannelId_present = safetyAlertsChannelId$impl.isPresent();
/*  449 */     this.ownerId_value = ownerId$impl.asLong();
/*  450 */     this.region_value = Possible.flatOpt(region$impl).orElse(null);
/*  451 */     this.region_absent = region$impl.isAbsent();
/*  452 */     this.unavailable_value = unavailable$impl.toOptional().orElse(null);
/*  453 */     this.unavailable_absent = unavailable$impl.isAbsent();
/*  454 */     this
/*      */       
/*  456 */       .roles_value = roles$impl.stream().mapToLong(Id::asLong).toArray();
/*  457 */     this
/*      */       
/*  459 */       .emojis_value = emojis$impl.stream().mapToLong(Id::asLong).toArray();
/*  460 */     this.stickers_value = stickers$impl.toOptional().orElse(null);
/*  461 */     this.stickers_absent = stickers$impl.isAbsent();
/*  462 */     this
/*      */       
/*  464 */       .members_value = members$impl.stream().mapToLong(Id::asLong).toArray();
/*  465 */     this
/*      */       
/*  467 */       .channels_value = channels$impl.stream().mapToLong(Id::asLong).toArray();
/*  468 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  474 */   private volatile transient InitShim initShim = new InitShim();
/*      */   
/*      */   @Generated(from = "GuildData", generator = "Immutables")
/*      */   private final class InitShim {
/*      */     private String formatInitCycleMessage() {
/*  479 */       List<String> attributes = new ArrayList<>();
/*  480 */       return "Cannot build GuildData, attribute initializers form cycle " + attributes;
/*      */     }
/*      */ 
/*      */     
/*      */     private InitShim() {}
/*      */   }
/*      */ 
/*      */   
/*      */   @JsonProperty("id")
/*      */   public Id id() {
/*  490 */     return Id.of(this.id_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("name")
/*      */   public String name() {
/*  499 */     return this.name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("icon")
/*      */   public Optional<String> icon() {
/*  508 */     return Optional.ofNullable(this.icon);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("splash")
/*      */   public Optional<String> splash() {
/*  517 */     return Optional.ofNullable(this.splash);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("discovery_splash")
/*      */   public Optional<String> discoverySplash() {
/*  526 */     return Optional.ofNullable(this.discoverySplash);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("owner")
/*      */   public Possible<Boolean> owner() {
/*  535 */     return this.owner_absent ? Possible.absent() : Possible.of(this.owner_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("permissions")
/*      */   public Possible<Long> permissions() {
/*  544 */     return this.permissions_absent ? Possible.absent() : Possible.of(this.permissions_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("afk_channel_id")
/*      */   public Optional<Id> afkChannelId() {
/*  553 */     return this.afkChannelId_present ? Optional.<Id>of(Id.of(this.afkChannelId_value)) : Optional.<Id>empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("embed_enabled")
/*      */   @Deprecated
/*      */   public Possible<Boolean> embedEnabled() {
/*  563 */     return this.embedEnabled_absent ? Possible.absent() : Possible.of(this.embedEnabled_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("embed_channel_id")
/*      */   @Deprecated
/*      */   public Possible<Optional<Id>> embedChannelId() {
/*  573 */     if (this.embedChannelId_absent)
/*  574 */       return Possible.absent(); 
/*  575 */     if (this.embedChannelId_isNull) {
/*  576 */       return Possible.of(Optional.empty());
/*      */     }
/*  578 */     return Possible.of(Optional.of(Id.of(this.embedChannelId_value)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("features")
/*      */   public List<String> features() {
/*  588 */     return this.features;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("application_id")
/*      */   public Optional<Id> applicationId() {
/*  597 */     return this.applicationId_present ? Optional.<Id>of(Id.of(this.applicationId_value)) : Optional.<Id>empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("widget_enabled")
/*      */   public Possible<Boolean> widgetEnabled() {
/*  606 */     return this.widgetEnabled_absent ? Possible.absent() : Possible.of(this.widgetEnabled_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("widget_channel_id")
/*      */   public Possible<Optional<Id>> widgetChannelId() {
/*  615 */     if (this.widgetChannelId_absent)
/*  616 */       return Possible.absent(); 
/*  617 */     if (this.widgetChannelId_isNull) {
/*  618 */       return Possible.of(Optional.empty());
/*      */     }
/*  620 */     return Possible.of(Optional.of(Id.of(this.widgetChannelId_value)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("system_channel_id")
/*      */   public Optional<Id> systemChannelId() {
/*  630 */     return this.systemChannelId_present ? Optional.<Id>of(Id.of(this.systemChannelId_value)) : Optional.<Id>empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("system_channel_flags")
/*      */   public OptionalInt systemChannelFlags() {
/*  639 */     return (this.systemChannelFlags != null) ? 
/*  640 */       OptionalInt.of(this.systemChannelFlags.intValue()) : 
/*  641 */       OptionalInt.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("rules_channel_id")
/*      */   public Optional<Id> rulesChannelId() {
/*  650 */     return this.rulesChannelId_present ? Optional.<Id>of(Id.of(this.rulesChannelId_value)) : Optional.<Id>empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("max_presences")
/*      */   public Possible<Optional<Integer>> maxPresences() {
/*  659 */     return this.maxPresences_absent ? Possible.absent() : 
/*  660 */       Possible.of(Optional.ofNullable(this.maxPresences_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("max_members")
/*      */   public Possible<Integer> maxMembers() {
/*  669 */     return this.maxMembers_absent ? Possible.absent() : Possible.of(this.maxMembers_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("vanity_url_code")
/*      */   public Optional<String> vanityUrlCode() {
/*  678 */     return Optional.ofNullable(this.vanityUrlCode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("description")
/*      */   public Optional<String> description() {
/*  687 */     return Optional.ofNullable(this.description);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("banner")
/*      */   public Optional<String> banner() {
/*  696 */     return Optional.ofNullable(this.banner);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("premium_subscription_count")
/*      */   public Possible<Integer> premiumSubscriptionCount() {
/*  705 */     return this.premiumSubscriptionCount_absent ? Possible.absent() : Possible.of(this.premiumSubscriptionCount_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("public_updates_channel_id")
/*      */   public Optional<Id> publicUpdatesChannelId() {
/*  714 */     return this.publicUpdatesChannelId_present ? Optional.<Id>of(Id.of(this.publicUpdatesChannelId_value)) : Optional.<Id>empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("max_video_channel_users")
/*      */   public Possible<Integer> maxVideoChannelUsers() {
/*  723 */     return this.maxVideoChannelUsers_absent ? Possible.absent() : Possible.of(this.maxVideoChannelUsers_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("approximate_member_count")
/*      */   public Possible<Integer> approximateMemberCount() {
/*  732 */     return this.approximateMemberCount_absent ? Possible.absent() : Possible.of(this.approximateMemberCount_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("approximate_presence_count")
/*      */   public Possible<Integer> approximatePresenceCount() {
/*  741 */     return this.approximatePresenceCount_absent ? Possible.absent() : Possible.of(this.approximatePresenceCount_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("welcome_screen")
/*      */   public Possible<WelcomeScreenData> welcomeScreen() {
/*  750 */     return this.welcomeScreen_absent ? Possible.absent() : Possible.of(this.welcomeScreen_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("nsfw")
/*      */   @Deprecated
/*      */   public Possible<Boolean> nsfw() {
/*  760 */     return this.nsfw_absent ? Possible.absent() : Possible.of(this.nsfw_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("safety_alerts_channel_id")
/*      */   public Optional<Id> safetyAlertsChannelId() {
/*  769 */     return this.safetyAlertsChannelId_present ? Optional.<Id>of(Id.of(this.safetyAlertsChannelId_value)) : Optional.<Id>empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("verification_level")
/*      */   public int verificationLevel() {
/*  778 */     return this.verificationLevel;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("nsfw_level")
/*      */   public int nsfwLevel() {
/*  787 */     return this.nsfwLevel;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("owner_id")
/*      */   public Id ownerId() {
/*  796 */     return Id.of(this.ownerId_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("region")
/*      */   public Possible<Optional<String>> region() {
/*  805 */     return this.region_absent ? Possible.absent() : 
/*  806 */       Possible.of(Optional.ofNullable(this.region_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("afk_timeout")
/*      */   public int afkTimeout() {
/*  815 */     return this.afkTimeout;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("default_message_notifications")
/*      */   public int defaultMessageNotifications() {
/*  824 */     return this.defaultMessageNotifications;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("explicit_content_filter")
/*      */   public int explicitContentFilter() {
/*  833 */     return this.explicitContentFilter;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("mfa_level")
/*      */   public int mfaLevel() {
/*  842 */     return this.mfaLevel;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("premium_tier")
/*      */   public int premiumTier() {
/*  851 */     return this.premiumTier;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("preferred_locale")
/*      */   public String preferredLocale() {
/*  860 */     return this.preferredLocale;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("joined_at")
/*      */   public String joinedAt() {
/*  869 */     return this.joinedAt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("large")
/*      */   public boolean large() {
/*  878 */     return this.large;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("unavailable")
/*      */   public Possible<Boolean> unavailable() {
/*  887 */     return this.unavailable_absent ? Possible.absent() : Possible.of(this.unavailable_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("member_count")
/*      */   public int memberCount() {
/*  896 */     return this.memberCount;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("roles")
/*      */   public List<Id> roles() {
/*  905 */     return (List<Id>)LongStream.of(this.roles_value)
/*  906 */       .mapToObj(Id::of)
/*  907 */       .collect(Collectors.toList());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("emojis")
/*      */   public List<Id> emojis() {
/*  916 */     return (List<Id>)LongStream.of(this.emojis_value)
/*  917 */       .mapToObj(Id::of)
/*  918 */       .collect(Collectors.toList());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("stickers")
/*      */   public Possible<List<Id>> stickers() {
/*  927 */     return this.stickers_absent ? Possible.absent() : 
/*  928 */       Possible.of(this.stickers_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("members")
/*      */   public List<Id> members() {
/*  937 */     return (List<Id>)LongStream.of(this.members_value)
/*  938 */       .mapToObj(Id::of)
/*  939 */       .collect(Collectors.toList());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("channels")
/*      */   public List<Id> channels() {
/*  948 */     return (List<Id>)LongStream.of(this.channels_value)
/*  949 */       .mapToObj(Id::of)
/*  950 */       .collect(Collectors.toList());
/*      */   }
/*      */   
/*      */   public ImmutableGuildData withId(long value) {
/*  954 */     Id newValue = Id.of(value);
/*  955 */     return new ImmutableGuildData(this, newValue, this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  962 */         owner(), 
/*  963 */         permissions(), 
/*  964 */         afkChannelId(), 
/*  965 */         embedEnabled(), 
/*  966 */         embedChannelId(), this.features, 
/*      */         
/*  968 */         applicationId(), 
/*  969 */         widgetEnabled(), 
/*  970 */         widgetChannelId(), 
/*  971 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/*  973 */         rulesChannelId(), 
/*  974 */         maxPresences(), 
/*  975 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/*  979 */         premiumSubscriptionCount(), 
/*  980 */         publicUpdatesChannelId(), 
/*  981 */         maxVideoChannelUsers(), 
/*  982 */         approximateMemberCount(), 
/*  983 */         approximatePresenceCount(), 
/*  984 */         welcomeScreen(), 
/*  985 */         nsfw(), 
/*  986 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/*  989 */         ownerId(), 
/*  990 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  999 */         unavailable(), this.memberCount, 
/*      */         
/* 1001 */         roles(), 
/* 1002 */         emojis(), 
/* 1003 */         stickers(), 
/* 1004 */         members(), 
/* 1005 */         channels());
/*      */   }
/*      */   
/*      */   public ImmutableGuildData withId(String value) {
/* 1009 */     Id newValue = Id.of(value);
/* 1010 */     return new ImmutableGuildData(this, newValue, this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1017 */         owner(), 
/* 1018 */         permissions(), 
/* 1019 */         afkChannelId(), 
/* 1020 */         embedEnabled(), 
/* 1021 */         embedChannelId(), this.features, 
/*      */         
/* 1023 */         applicationId(), 
/* 1024 */         widgetEnabled(), 
/* 1025 */         widgetChannelId(), 
/* 1026 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1028 */         rulesChannelId(), 
/* 1029 */         maxPresences(), 
/* 1030 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1034 */         premiumSubscriptionCount(), 
/* 1035 */         publicUpdatesChannelId(), 
/* 1036 */         maxVideoChannelUsers(), 
/* 1037 */         approximateMemberCount(), 
/* 1038 */         approximatePresenceCount(), 
/* 1039 */         welcomeScreen(), 
/* 1040 */         nsfw(), 
/* 1041 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 1044 */         ownerId(), 
/* 1045 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1054 */         unavailable(), this.memberCount, 
/*      */         
/* 1056 */         roles(), 
/* 1057 */         emojis(), 
/* 1058 */         stickers(), 
/* 1059 */         members(), 
/* 1060 */         channels());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildData withName(String value) {
/* 1070 */     String newValue = Objects.<String>requireNonNull(value, "name");
/* 1071 */     if (this.name.equals(newValue)) return this; 
/* 1072 */     return new ImmutableGuildData(this, 
/*      */         
/* 1074 */         id(), newValue, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1079 */         owner(), 
/* 1080 */         permissions(), 
/* 1081 */         afkChannelId(), 
/* 1082 */         embedEnabled(), 
/* 1083 */         embedChannelId(), this.features, 
/*      */         
/* 1085 */         applicationId(), 
/* 1086 */         widgetEnabled(), 
/* 1087 */         widgetChannelId(), 
/* 1088 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1090 */         rulesChannelId(), 
/* 1091 */         maxPresences(), 
/* 1092 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1096 */         premiumSubscriptionCount(), 
/* 1097 */         publicUpdatesChannelId(), 
/* 1098 */         maxVideoChannelUsers(), 
/* 1099 */         approximateMemberCount(), 
/* 1100 */         approximatePresenceCount(), 
/* 1101 */         welcomeScreen(), 
/* 1102 */         nsfw(), 
/* 1103 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 1106 */         ownerId(), 
/* 1107 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1116 */         unavailable(), this.memberCount, 
/*      */         
/* 1118 */         roles(), 
/* 1119 */         emojis(), 
/* 1120 */         stickers(), 
/* 1121 */         members(), 
/* 1122 */         channels());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildData withIcon(String value) {
/* 1131 */     String newValue = Objects.<String>requireNonNull(value, "icon");
/* 1132 */     if (Objects.equals(this.icon, newValue)) return this; 
/* 1133 */     return new ImmutableGuildData(this, 
/*      */         
/* 1135 */         id(), this.name, newValue, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1140 */         owner(), 
/* 1141 */         permissions(), 
/* 1142 */         afkChannelId(), 
/* 1143 */         embedEnabled(), 
/* 1144 */         embedChannelId(), this.features, 
/*      */         
/* 1146 */         applicationId(), 
/* 1147 */         widgetEnabled(), 
/* 1148 */         widgetChannelId(), 
/* 1149 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1151 */         rulesChannelId(), 
/* 1152 */         maxPresences(), 
/* 1153 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1157 */         premiumSubscriptionCount(), 
/* 1158 */         publicUpdatesChannelId(), 
/* 1159 */         maxVideoChannelUsers(), 
/* 1160 */         approximateMemberCount(), 
/* 1161 */         approximatePresenceCount(), 
/* 1162 */         welcomeScreen(), 
/* 1163 */         nsfw(), 
/* 1164 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 1167 */         ownerId(), 
/* 1168 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1177 */         unavailable(), this.memberCount, 
/*      */         
/* 1179 */         roles(), 
/* 1180 */         emojis(), 
/* 1181 */         stickers(), 
/* 1182 */         members(), 
/* 1183 */         channels());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildData withIcon(Optional<String> optional) {
/* 1193 */     String value = optional.orElse(null);
/* 1194 */     if (Objects.equals(this.icon, value)) return this; 
/* 1195 */     return new ImmutableGuildData(this, 
/*      */         
/* 1197 */         id(), this.name, value, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1202 */         owner(), 
/* 1203 */         permissions(), 
/* 1204 */         afkChannelId(), 
/* 1205 */         embedEnabled(), 
/* 1206 */         embedChannelId(), this.features, 
/*      */         
/* 1208 */         applicationId(), 
/* 1209 */         widgetEnabled(), 
/* 1210 */         widgetChannelId(), 
/* 1211 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1213 */         rulesChannelId(), 
/* 1214 */         maxPresences(), 
/* 1215 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1219 */         premiumSubscriptionCount(), 
/* 1220 */         publicUpdatesChannelId(), 
/* 1221 */         maxVideoChannelUsers(), 
/* 1222 */         approximateMemberCount(), 
/* 1223 */         approximatePresenceCount(), 
/* 1224 */         welcomeScreen(), 
/* 1225 */         nsfw(), 
/* 1226 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 1229 */         ownerId(), 
/* 1230 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1239 */         unavailable(), this.memberCount, 
/*      */         
/* 1241 */         roles(), 
/* 1242 */         emojis(), 
/* 1243 */         stickers(), 
/* 1244 */         members(), 
/* 1245 */         channels());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildData withSplash(String value) {
/* 1254 */     String newValue = Objects.<String>requireNonNull(value, "splash");
/* 1255 */     if (Objects.equals(this.splash, newValue)) return this; 
/* 1256 */     return new ImmutableGuildData(this, 
/*      */         
/* 1258 */         id(), this.name, this.icon, newValue, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1263 */         owner(), 
/* 1264 */         permissions(), 
/* 1265 */         afkChannelId(), 
/* 1266 */         embedEnabled(), 
/* 1267 */         embedChannelId(), this.features, 
/*      */         
/* 1269 */         applicationId(), 
/* 1270 */         widgetEnabled(), 
/* 1271 */         widgetChannelId(), 
/* 1272 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1274 */         rulesChannelId(), 
/* 1275 */         maxPresences(), 
/* 1276 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1280 */         premiumSubscriptionCount(), 
/* 1281 */         publicUpdatesChannelId(), 
/* 1282 */         maxVideoChannelUsers(), 
/* 1283 */         approximateMemberCount(), 
/* 1284 */         approximatePresenceCount(), 
/* 1285 */         welcomeScreen(), 
/* 1286 */         nsfw(), 
/* 1287 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 1290 */         ownerId(), 
/* 1291 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1300 */         unavailable(), this.memberCount, 
/*      */         
/* 1302 */         roles(), 
/* 1303 */         emojis(), 
/* 1304 */         stickers(), 
/* 1305 */         members(), 
/* 1306 */         channels());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildData withSplash(Optional<String> optional) {
/* 1316 */     String value = optional.orElse(null);
/* 1317 */     if (Objects.equals(this.splash, value)) return this; 
/* 1318 */     return new ImmutableGuildData(this, 
/*      */         
/* 1320 */         id(), this.name, this.icon, value, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1325 */         owner(), 
/* 1326 */         permissions(), 
/* 1327 */         afkChannelId(), 
/* 1328 */         embedEnabled(), 
/* 1329 */         embedChannelId(), this.features, 
/*      */         
/* 1331 */         applicationId(), 
/* 1332 */         widgetEnabled(), 
/* 1333 */         widgetChannelId(), 
/* 1334 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1336 */         rulesChannelId(), 
/* 1337 */         maxPresences(), 
/* 1338 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1342 */         premiumSubscriptionCount(), 
/* 1343 */         publicUpdatesChannelId(), 
/* 1344 */         maxVideoChannelUsers(), 
/* 1345 */         approximateMemberCount(), 
/* 1346 */         approximatePresenceCount(), 
/* 1347 */         welcomeScreen(), 
/* 1348 */         nsfw(), 
/* 1349 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 1352 */         ownerId(), 
/* 1353 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1362 */         unavailable(), this.memberCount, 
/*      */         
/* 1364 */         roles(), 
/* 1365 */         emojis(), 
/* 1366 */         stickers(), 
/* 1367 */         members(), 
/* 1368 */         channels());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildData withDiscoverySplash(String value) {
/* 1377 */     String newValue = Objects.<String>requireNonNull(value, "discoverySplash");
/* 1378 */     if (Objects.equals(this.discoverySplash, newValue)) return this; 
/* 1379 */     return new ImmutableGuildData(this, 
/*      */         
/* 1381 */         id(), this.name, this.icon, this.splash, newValue, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1386 */         owner(), 
/* 1387 */         permissions(), 
/* 1388 */         afkChannelId(), 
/* 1389 */         embedEnabled(), 
/* 1390 */         embedChannelId(), this.features, 
/*      */         
/* 1392 */         applicationId(), 
/* 1393 */         widgetEnabled(), 
/* 1394 */         widgetChannelId(), 
/* 1395 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1397 */         rulesChannelId(), 
/* 1398 */         maxPresences(), 
/* 1399 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1403 */         premiumSubscriptionCount(), 
/* 1404 */         publicUpdatesChannelId(), 
/* 1405 */         maxVideoChannelUsers(), 
/* 1406 */         approximateMemberCount(), 
/* 1407 */         approximatePresenceCount(), 
/* 1408 */         welcomeScreen(), 
/* 1409 */         nsfw(), 
/* 1410 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 1413 */         ownerId(), 
/* 1414 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1423 */         unavailable(), this.memberCount, 
/*      */         
/* 1425 */         roles(), 
/* 1426 */         emojis(), 
/* 1427 */         stickers(), 
/* 1428 */         members(), 
/* 1429 */         channels());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildData withDiscoverySplash(Optional<String> optional) {
/* 1439 */     String value = optional.orElse(null);
/* 1440 */     if (Objects.equals(this.discoverySplash, value)) return this; 
/* 1441 */     return new ImmutableGuildData(this, 
/*      */         
/* 1443 */         id(), this.name, this.icon, this.splash, value, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1448 */         owner(), 
/* 1449 */         permissions(), 
/* 1450 */         afkChannelId(), 
/* 1451 */         embedEnabled(), 
/* 1452 */         embedChannelId(), this.features, 
/*      */         
/* 1454 */         applicationId(), 
/* 1455 */         widgetEnabled(), 
/* 1456 */         widgetChannelId(), 
/* 1457 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1459 */         rulesChannelId(), 
/* 1460 */         maxPresences(), 
/* 1461 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1465 */         premiumSubscriptionCount(), 
/* 1466 */         publicUpdatesChannelId(), 
/* 1467 */         maxVideoChannelUsers(), 
/* 1468 */         approximateMemberCount(), 
/* 1469 */         approximatePresenceCount(), 
/* 1470 */         welcomeScreen(), 
/* 1471 */         nsfw(), 
/* 1472 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 1475 */         ownerId(), 
/* 1476 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1485 */         unavailable(), this.memberCount, 
/*      */         
/* 1487 */         roles(), 
/* 1488 */         emojis(), 
/* 1489 */         stickers(), 
/* 1490 */         members(), 
/* 1491 */         channels());
/*      */   }
/*      */   
/*      */   public ImmutableGuildData withOwner(Possible<Boolean> value) {
/* 1495 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 1496 */     return new ImmutableGuildData(this, 
/*      */         
/* 1498 */         id(), this.name, this.icon, this.splash, this.discoverySplash, newValue, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1504 */         permissions(), 
/* 1505 */         afkChannelId(), 
/* 1506 */         embedEnabled(), 
/* 1507 */         embedChannelId(), this.features, 
/*      */         
/* 1509 */         applicationId(), 
/* 1510 */         widgetEnabled(), 
/* 1511 */         widgetChannelId(), 
/* 1512 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1514 */         rulesChannelId(), 
/* 1515 */         maxPresences(), 
/* 1516 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1520 */         premiumSubscriptionCount(), 
/* 1521 */         publicUpdatesChannelId(), 
/* 1522 */         maxVideoChannelUsers(), 
/* 1523 */         approximateMemberCount(), 
/* 1524 */         approximatePresenceCount(), 
/* 1525 */         welcomeScreen(), 
/* 1526 */         nsfw(), 
/* 1527 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 1530 */         ownerId(), 
/* 1531 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1540 */         unavailable(), this.memberCount, 
/*      */         
/* 1542 */         roles(), 
/* 1543 */         emojis(), 
/* 1544 */         stickers(), 
/* 1545 */         members(), 
/* 1546 */         channels());
/*      */   }
/*      */   
/*      */   public ImmutableGuildData withOwner(Boolean value) {
/* 1550 */     Possible<Boolean> newValue = Possible.of(value);
/* 1551 */     return new ImmutableGuildData(this, 
/*      */         
/* 1553 */         id(), this.name, this.icon, this.splash, this.discoverySplash, newValue, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1559 */         permissions(), 
/* 1560 */         afkChannelId(), 
/* 1561 */         embedEnabled(), 
/* 1562 */         embedChannelId(), this.features, 
/*      */         
/* 1564 */         applicationId(), 
/* 1565 */         widgetEnabled(), 
/* 1566 */         widgetChannelId(), 
/* 1567 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1569 */         rulesChannelId(), 
/* 1570 */         maxPresences(), 
/* 1571 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1575 */         premiumSubscriptionCount(), 
/* 1576 */         publicUpdatesChannelId(), 
/* 1577 */         maxVideoChannelUsers(), 
/* 1578 */         approximateMemberCount(), 
/* 1579 */         approximatePresenceCount(), 
/* 1580 */         welcomeScreen(), 
/* 1581 */         nsfw(), 
/* 1582 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 1585 */         ownerId(), 
/* 1586 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1595 */         unavailable(), this.memberCount, 
/*      */         
/* 1597 */         roles(), 
/* 1598 */         emojis(), 
/* 1599 */         stickers(), 
/* 1600 */         members(), 
/* 1601 */         channels());
/*      */   }
/*      */   
/*      */   public ImmutableGuildData withPermissions(Possible<Long> value) {
/* 1605 */     Possible<Long> newValue = Objects.<Possible<Long>>requireNonNull(value);
/* 1606 */     return new ImmutableGuildData(this, 
/*      */         
/* 1608 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1613 */         owner(), newValue, 
/*      */         
/* 1615 */         afkChannelId(), 
/* 1616 */         embedEnabled(), 
/* 1617 */         embedChannelId(), this.features, 
/*      */         
/* 1619 */         applicationId(), 
/* 1620 */         widgetEnabled(), 
/* 1621 */         widgetChannelId(), 
/* 1622 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1624 */         rulesChannelId(), 
/* 1625 */         maxPresences(), 
/* 1626 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1630 */         premiumSubscriptionCount(), 
/* 1631 */         publicUpdatesChannelId(), 
/* 1632 */         maxVideoChannelUsers(), 
/* 1633 */         approximateMemberCount(), 
/* 1634 */         approximatePresenceCount(), 
/* 1635 */         welcomeScreen(), 
/* 1636 */         nsfw(), 
/* 1637 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 1640 */         ownerId(), 
/* 1641 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1650 */         unavailable(), this.memberCount, 
/*      */         
/* 1652 */         roles(), 
/* 1653 */         emojis(), 
/* 1654 */         stickers(), 
/* 1655 */         members(), 
/* 1656 */         channels());
/*      */   }
/*      */   
/*      */   public ImmutableGuildData withPermissions(Long value) {
/* 1660 */     Possible<Long> newValue = Possible.of(value);
/* 1661 */     return new ImmutableGuildData(this, 
/*      */         
/* 1663 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1668 */         owner(), newValue, 
/*      */         
/* 1670 */         afkChannelId(), 
/* 1671 */         embedEnabled(), 
/* 1672 */         embedChannelId(), this.features, 
/*      */         
/* 1674 */         applicationId(), 
/* 1675 */         widgetEnabled(), 
/* 1676 */         widgetChannelId(), 
/* 1677 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1679 */         rulesChannelId(), 
/* 1680 */         maxPresences(), 
/* 1681 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1685 */         premiumSubscriptionCount(), 
/* 1686 */         publicUpdatesChannelId(), 
/* 1687 */         maxVideoChannelUsers(), 
/* 1688 */         approximateMemberCount(), 
/* 1689 */         approximatePresenceCount(), 
/* 1690 */         welcomeScreen(), 
/* 1691 */         nsfw(), 
/* 1692 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 1695 */         ownerId(), 
/* 1696 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1705 */         unavailable(), this.memberCount, 
/*      */         
/* 1707 */         roles(), 
/* 1708 */         emojis(), 
/* 1709 */         stickers(), 
/* 1710 */         members(), 
/* 1711 */         channels());
/*      */   }
/*      */   
/*      */   public ImmutableGuildData withAfkChannelId(Optional<Id> value) {
/* 1715 */     Optional<Id> newValue = Objects.<Optional<Id>>requireNonNull(value);
/* 1716 */     return new ImmutableGuildData(this, 
/*      */         
/* 1718 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1723 */         owner(), 
/* 1724 */         permissions(), newValue, 
/*      */         
/* 1726 */         embedEnabled(), 
/* 1727 */         embedChannelId(), this.features, 
/*      */         
/* 1729 */         applicationId(), 
/* 1730 */         widgetEnabled(), 
/* 1731 */         widgetChannelId(), 
/* 1732 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1734 */         rulesChannelId(), 
/* 1735 */         maxPresences(), 
/* 1736 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1740 */         premiumSubscriptionCount(), 
/* 1741 */         publicUpdatesChannelId(), 
/* 1742 */         maxVideoChannelUsers(), 
/* 1743 */         approximateMemberCount(), 
/* 1744 */         approximatePresenceCount(), 
/* 1745 */         welcomeScreen(), 
/* 1746 */         nsfw(), 
/* 1747 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 1750 */         ownerId(), 
/* 1751 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1760 */         unavailable(), this.memberCount, 
/*      */         
/* 1762 */         roles(), 
/* 1763 */         emojis(), 
/* 1764 */         stickers(), 
/* 1765 */         members(), 
/* 1766 */         channels());
/*      */   }
/*      */   
/*      */   public ImmutableGuildData withAfkChannelId(long value) {
/* 1770 */     Optional<Id> newValue = Optional.of(Id.of(value));
/* 1771 */     return new ImmutableGuildData(this, 
/*      */         
/* 1773 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1778 */         owner(), 
/* 1779 */         permissions(), newValue, 
/*      */         
/* 1781 */         embedEnabled(), 
/* 1782 */         embedChannelId(), this.features, 
/*      */         
/* 1784 */         applicationId(), 
/* 1785 */         widgetEnabled(), 
/* 1786 */         widgetChannelId(), 
/* 1787 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1789 */         rulesChannelId(), 
/* 1790 */         maxPresences(), 
/* 1791 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1795 */         premiumSubscriptionCount(), 
/* 1796 */         publicUpdatesChannelId(), 
/* 1797 */         maxVideoChannelUsers(), 
/* 1798 */         approximateMemberCount(), 
/* 1799 */         approximatePresenceCount(), 
/* 1800 */         welcomeScreen(), 
/* 1801 */         nsfw(), 
/* 1802 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 1805 */         ownerId(), 
/* 1806 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1815 */         unavailable(), this.memberCount, 
/*      */         
/* 1817 */         roles(), 
/* 1818 */         emojis(), 
/* 1819 */         stickers(), 
/* 1820 */         members(), 
/* 1821 */         channels());
/*      */   }
/*      */   
/*      */   public ImmutableGuildData withEmbedEnabled(Possible<Boolean> value) {
/* 1825 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 1826 */     return new ImmutableGuildData(this, 
/*      */         
/* 1828 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1833 */         owner(), 
/* 1834 */         permissions(), 
/* 1835 */         afkChannelId(), newValue, 
/*      */         
/* 1837 */         embedChannelId(), this.features, 
/*      */         
/* 1839 */         applicationId(), 
/* 1840 */         widgetEnabled(), 
/* 1841 */         widgetChannelId(), 
/* 1842 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1844 */         rulesChannelId(), 
/* 1845 */         maxPresences(), 
/* 1846 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1850 */         premiumSubscriptionCount(), 
/* 1851 */         publicUpdatesChannelId(), 
/* 1852 */         maxVideoChannelUsers(), 
/* 1853 */         approximateMemberCount(), 
/* 1854 */         approximatePresenceCount(), 
/* 1855 */         welcomeScreen(), 
/* 1856 */         nsfw(), 
/* 1857 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 1860 */         ownerId(), 
/* 1861 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1870 */         unavailable(), this.memberCount, 
/*      */         
/* 1872 */         roles(), 
/* 1873 */         emojis(), 
/* 1874 */         stickers(), 
/* 1875 */         members(), 
/* 1876 */         channels());
/*      */   }
/*      */   
/*      */   public ImmutableGuildData withEmbedEnabled(Boolean value) {
/* 1880 */     Possible<Boolean> newValue = Possible.of(value);
/* 1881 */     return new ImmutableGuildData(this, 
/*      */         
/* 1883 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1888 */         owner(), 
/* 1889 */         permissions(), 
/* 1890 */         afkChannelId(), newValue, 
/*      */         
/* 1892 */         embedChannelId(), this.features, 
/*      */         
/* 1894 */         applicationId(), 
/* 1895 */         widgetEnabled(), 
/* 1896 */         widgetChannelId(), 
/* 1897 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1899 */         rulesChannelId(), 
/* 1900 */         maxPresences(), 
/* 1901 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1905 */         premiumSubscriptionCount(), 
/* 1906 */         publicUpdatesChannelId(), 
/* 1907 */         maxVideoChannelUsers(), 
/* 1908 */         approximateMemberCount(), 
/* 1909 */         approximatePresenceCount(), 
/* 1910 */         welcomeScreen(), 
/* 1911 */         nsfw(), 
/* 1912 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 1915 */         ownerId(), 
/* 1916 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1925 */         unavailable(), this.memberCount, 
/*      */         
/* 1927 */         roles(), 
/* 1928 */         emojis(), 
/* 1929 */         stickers(), 
/* 1930 */         members(), 
/* 1931 */         channels());
/*      */   }
/*      */   
/*      */   public ImmutableGuildData withEmbedChannelId(Possible<Optional<Id>> value) {
/* 1935 */     Possible<Optional<Id>> newValue = Objects.<Possible<Optional<Id>>>requireNonNull(value);
/* 1936 */     return new ImmutableGuildData(this, 
/*      */         
/* 1938 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1943 */         owner(), 
/* 1944 */         permissions(), 
/* 1945 */         afkChannelId(), 
/* 1946 */         embedEnabled(), newValue, this.features, 
/*      */ 
/*      */         
/* 1949 */         applicationId(), 
/* 1950 */         widgetEnabled(), 
/* 1951 */         widgetChannelId(), 
/* 1952 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1954 */         rulesChannelId(), 
/* 1955 */         maxPresences(), 
/* 1956 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1960 */         premiumSubscriptionCount(), 
/* 1961 */         publicUpdatesChannelId(), 
/* 1962 */         maxVideoChannelUsers(), 
/* 1963 */         approximateMemberCount(), 
/* 1964 */         approximatePresenceCount(), 
/* 1965 */         welcomeScreen(), 
/* 1966 */         nsfw(), 
/* 1967 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 1970 */         ownerId(), 
/* 1971 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1980 */         unavailable(), this.memberCount, 
/*      */         
/* 1982 */         roles(), 
/* 1983 */         emojis(), 
/* 1984 */         stickers(), 
/* 1985 */         members(), 
/* 1986 */         channels());
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableGuildData withEmbedChannelId(@Nullable Long value) {
/* 1992 */     Possible<Optional<Id>> newValue = (value == null) ? Possible.of(Optional.empty()) : Possible.of(Optional.of(Id.of(value.longValue())));
/* 1993 */     return new ImmutableGuildData(this, 
/*      */         
/* 1995 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2000 */         owner(), 
/* 2001 */         permissions(), 
/* 2002 */         afkChannelId(), 
/* 2003 */         embedEnabled(), newValue, this.features, 
/*      */ 
/*      */         
/* 2006 */         applicationId(), 
/* 2007 */         widgetEnabled(), 
/* 2008 */         widgetChannelId(), 
/* 2009 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2011 */         rulesChannelId(), 
/* 2012 */         maxPresences(), 
/* 2013 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2017 */         premiumSubscriptionCount(), 
/* 2018 */         publicUpdatesChannelId(), 
/* 2019 */         maxVideoChannelUsers(), 
/* 2020 */         approximateMemberCount(), 
/* 2021 */         approximatePresenceCount(), 
/* 2022 */         welcomeScreen(), 
/* 2023 */         nsfw(), 
/* 2024 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 2027 */         ownerId(), 
/* 2028 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2037 */         unavailable(), this.memberCount, 
/*      */         
/* 2039 */         roles(), 
/* 2040 */         emojis(), 
/* 2041 */         stickers(), 
/* 2042 */         members(), 
/* 2043 */         channels());
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableGuildData withEmbedChannelIdOrNull(@Nullable Long value) {
/* 2048 */     Possible<Optional<Id>> newValue = (value == null) ? Possible.of(Optional.empty()) : Possible.of(Optional.of(Id.of(value.longValue())));
/* 2049 */     return new ImmutableGuildData(this, 
/*      */         
/* 2051 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2056 */         owner(), 
/* 2057 */         permissions(), 
/* 2058 */         afkChannelId(), 
/* 2059 */         embedEnabled(), newValue, this.features, 
/*      */ 
/*      */         
/* 2062 */         applicationId(), 
/* 2063 */         widgetEnabled(), 
/* 2064 */         widgetChannelId(), 
/* 2065 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2067 */         rulesChannelId(), 
/* 2068 */         maxPresences(), 
/* 2069 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2073 */         premiumSubscriptionCount(), 
/* 2074 */         publicUpdatesChannelId(), 
/* 2075 */         maxVideoChannelUsers(), 
/* 2076 */         approximateMemberCount(), 
/* 2077 */         approximatePresenceCount(), 
/* 2078 */         welcomeScreen(), 
/* 2079 */         nsfw(), 
/* 2080 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 2083 */         ownerId(), 
/* 2084 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2093 */         unavailable(), this.memberCount, 
/*      */         
/* 2095 */         roles(), 
/* 2096 */         emojis(), 
/* 2097 */         stickers(), 
/* 2098 */         members(), 
/* 2099 */         channels());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildData withFeatures(String... elements) {
/* 2108 */     List<String> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 2109 */     return new ImmutableGuildData(this, 
/*      */         
/* 2111 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2116 */         owner(), 
/* 2117 */         permissions(), 
/* 2118 */         afkChannelId(), 
/* 2119 */         embedEnabled(), 
/* 2120 */         embedChannelId(), newValue, 
/*      */         
/* 2122 */         applicationId(), 
/* 2123 */         widgetEnabled(), 
/* 2124 */         widgetChannelId(), 
/* 2125 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2127 */         rulesChannelId(), 
/* 2128 */         maxPresences(), 
/* 2129 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2133 */         premiumSubscriptionCount(), 
/* 2134 */         publicUpdatesChannelId(), 
/* 2135 */         maxVideoChannelUsers(), 
/* 2136 */         approximateMemberCount(), 
/* 2137 */         approximatePresenceCount(), 
/* 2138 */         welcomeScreen(), 
/* 2139 */         nsfw(), 
/* 2140 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 2143 */         ownerId(), 
/* 2144 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2153 */         unavailable(), this.memberCount, 
/*      */         
/* 2155 */         roles(), 
/* 2156 */         emojis(), 
/* 2157 */         stickers(), 
/* 2158 */         members(), 
/* 2159 */         channels());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildData withFeatures(Iterable<String> elements) {
/* 2169 */     if (this.features == elements) return this; 
/* 2170 */     List<String> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 2171 */     return new ImmutableGuildData(this, 
/*      */         
/* 2173 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2178 */         owner(), 
/* 2179 */         permissions(), 
/* 2180 */         afkChannelId(), 
/* 2181 */         embedEnabled(), 
/* 2182 */         embedChannelId(), newValue, 
/*      */         
/* 2184 */         applicationId(), 
/* 2185 */         widgetEnabled(), 
/* 2186 */         widgetChannelId(), 
/* 2187 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2189 */         rulesChannelId(), 
/* 2190 */         maxPresences(), 
/* 2191 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2195 */         premiumSubscriptionCount(), 
/* 2196 */         publicUpdatesChannelId(), 
/* 2197 */         maxVideoChannelUsers(), 
/* 2198 */         approximateMemberCount(), 
/* 2199 */         approximatePresenceCount(), 
/* 2200 */         welcomeScreen(), 
/* 2201 */         nsfw(), 
/* 2202 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 2205 */         ownerId(), 
/* 2206 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2215 */         unavailable(), this.memberCount, 
/*      */         
/* 2217 */         roles(), 
/* 2218 */         emojis(), 
/* 2219 */         stickers(), 
/* 2220 */         members(), 
/* 2221 */         channels());
/*      */   }
/*      */   
/*      */   public ImmutableGuildData withApplicationId(Optional<Id> value) {
/* 2225 */     Optional<Id> newValue = Objects.<Optional<Id>>requireNonNull(value);
/* 2226 */     return new ImmutableGuildData(this, 
/*      */         
/* 2228 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2233 */         owner(), 
/* 2234 */         permissions(), 
/* 2235 */         afkChannelId(), 
/* 2236 */         embedEnabled(), 
/* 2237 */         embedChannelId(), this.features, newValue, 
/*      */ 
/*      */         
/* 2240 */         widgetEnabled(), 
/* 2241 */         widgetChannelId(), 
/* 2242 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2244 */         rulesChannelId(), 
/* 2245 */         maxPresences(), 
/* 2246 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2250 */         premiumSubscriptionCount(), 
/* 2251 */         publicUpdatesChannelId(), 
/* 2252 */         maxVideoChannelUsers(), 
/* 2253 */         approximateMemberCount(), 
/* 2254 */         approximatePresenceCount(), 
/* 2255 */         welcomeScreen(), 
/* 2256 */         nsfw(), 
/* 2257 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 2260 */         ownerId(), 
/* 2261 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2270 */         unavailable(), this.memberCount, 
/*      */         
/* 2272 */         roles(), 
/* 2273 */         emojis(), 
/* 2274 */         stickers(), 
/* 2275 */         members(), 
/* 2276 */         channels());
/*      */   }
/*      */   
/*      */   public ImmutableGuildData withApplicationId(long value) {
/* 2280 */     Optional<Id> newValue = Optional.of(Id.of(value));
/* 2281 */     return new ImmutableGuildData(this, 
/*      */         
/* 2283 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2288 */         owner(), 
/* 2289 */         permissions(), 
/* 2290 */         afkChannelId(), 
/* 2291 */         embedEnabled(), 
/* 2292 */         embedChannelId(), this.features, newValue, 
/*      */ 
/*      */         
/* 2295 */         widgetEnabled(), 
/* 2296 */         widgetChannelId(), 
/* 2297 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2299 */         rulesChannelId(), 
/* 2300 */         maxPresences(), 
/* 2301 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2305 */         premiumSubscriptionCount(), 
/* 2306 */         publicUpdatesChannelId(), 
/* 2307 */         maxVideoChannelUsers(), 
/* 2308 */         approximateMemberCount(), 
/* 2309 */         approximatePresenceCount(), 
/* 2310 */         welcomeScreen(), 
/* 2311 */         nsfw(), 
/* 2312 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 2315 */         ownerId(), 
/* 2316 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2325 */         unavailable(), this.memberCount, 
/*      */         
/* 2327 */         roles(), 
/* 2328 */         emojis(), 
/* 2329 */         stickers(), 
/* 2330 */         members(), 
/* 2331 */         channels());
/*      */   }
/*      */   
/*      */   public ImmutableGuildData withWidgetEnabled(Possible<Boolean> value) {
/* 2335 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 2336 */     return new ImmutableGuildData(this, 
/*      */         
/* 2338 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2343 */         owner(), 
/* 2344 */         permissions(), 
/* 2345 */         afkChannelId(), 
/* 2346 */         embedEnabled(), 
/* 2347 */         embedChannelId(), this.features, 
/*      */         
/* 2349 */         applicationId(), newValue, 
/*      */         
/* 2351 */         widgetChannelId(), 
/* 2352 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2354 */         rulesChannelId(), 
/* 2355 */         maxPresences(), 
/* 2356 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2360 */         premiumSubscriptionCount(), 
/* 2361 */         publicUpdatesChannelId(), 
/* 2362 */         maxVideoChannelUsers(), 
/* 2363 */         approximateMemberCount(), 
/* 2364 */         approximatePresenceCount(), 
/* 2365 */         welcomeScreen(), 
/* 2366 */         nsfw(), 
/* 2367 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 2370 */         ownerId(), 
/* 2371 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2380 */         unavailable(), this.memberCount, 
/*      */         
/* 2382 */         roles(), 
/* 2383 */         emojis(), 
/* 2384 */         stickers(), 
/* 2385 */         members(), 
/* 2386 */         channels());
/*      */   }
/*      */   
/*      */   public ImmutableGuildData withWidgetEnabled(Boolean value) {
/* 2390 */     Possible<Boolean> newValue = Possible.of(value);
/* 2391 */     return new ImmutableGuildData(this, 
/*      */         
/* 2393 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2398 */         owner(), 
/* 2399 */         permissions(), 
/* 2400 */         afkChannelId(), 
/* 2401 */         embedEnabled(), 
/* 2402 */         embedChannelId(), this.features, 
/*      */         
/* 2404 */         applicationId(), newValue, 
/*      */         
/* 2406 */         widgetChannelId(), 
/* 2407 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2409 */         rulesChannelId(), 
/* 2410 */         maxPresences(), 
/* 2411 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2415 */         premiumSubscriptionCount(), 
/* 2416 */         publicUpdatesChannelId(), 
/* 2417 */         maxVideoChannelUsers(), 
/* 2418 */         approximateMemberCount(), 
/* 2419 */         approximatePresenceCount(), 
/* 2420 */         welcomeScreen(), 
/* 2421 */         nsfw(), 
/* 2422 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 2425 */         ownerId(), 
/* 2426 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2435 */         unavailable(), this.memberCount, 
/*      */         
/* 2437 */         roles(), 
/* 2438 */         emojis(), 
/* 2439 */         stickers(), 
/* 2440 */         members(), 
/* 2441 */         channels());
/*      */   }
/*      */   
/*      */   public ImmutableGuildData withWidgetChannelId(Possible<Optional<Id>> value) {
/* 2445 */     Possible<Optional<Id>> newValue = Objects.<Possible<Optional<Id>>>requireNonNull(value);
/* 2446 */     return new ImmutableGuildData(this, 
/*      */         
/* 2448 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2453 */         owner(), 
/* 2454 */         permissions(), 
/* 2455 */         afkChannelId(), 
/* 2456 */         embedEnabled(), 
/* 2457 */         embedChannelId(), this.features, 
/*      */         
/* 2459 */         applicationId(), 
/* 2460 */         widgetEnabled(), newValue, 
/*      */         
/* 2462 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2464 */         rulesChannelId(), 
/* 2465 */         maxPresences(), 
/* 2466 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2470 */         premiumSubscriptionCount(), 
/* 2471 */         publicUpdatesChannelId(), 
/* 2472 */         maxVideoChannelUsers(), 
/* 2473 */         approximateMemberCount(), 
/* 2474 */         approximatePresenceCount(), 
/* 2475 */         welcomeScreen(), 
/* 2476 */         nsfw(), 
/* 2477 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 2480 */         ownerId(), 
/* 2481 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2490 */         unavailable(), this.memberCount, 
/*      */         
/* 2492 */         roles(), 
/* 2493 */         emojis(), 
/* 2494 */         stickers(), 
/* 2495 */         members(), 
/* 2496 */         channels());
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableGuildData withWidgetChannelId(@Nullable Long value) {
/* 2502 */     Possible<Optional<Id>> newValue = (value == null) ? Possible.of(Optional.empty()) : Possible.of(Optional.of(Id.of(value.longValue())));
/* 2503 */     return new ImmutableGuildData(this, 
/*      */         
/* 2505 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2510 */         owner(), 
/* 2511 */         permissions(), 
/* 2512 */         afkChannelId(), 
/* 2513 */         embedEnabled(), 
/* 2514 */         embedChannelId(), this.features, 
/*      */         
/* 2516 */         applicationId(), 
/* 2517 */         widgetEnabled(), newValue, 
/*      */         
/* 2519 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2521 */         rulesChannelId(), 
/* 2522 */         maxPresences(), 
/* 2523 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2527 */         premiumSubscriptionCount(), 
/* 2528 */         publicUpdatesChannelId(), 
/* 2529 */         maxVideoChannelUsers(), 
/* 2530 */         approximateMemberCount(), 
/* 2531 */         approximatePresenceCount(), 
/* 2532 */         welcomeScreen(), 
/* 2533 */         nsfw(), 
/* 2534 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 2537 */         ownerId(), 
/* 2538 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2547 */         unavailable(), this.memberCount, 
/*      */         
/* 2549 */         roles(), 
/* 2550 */         emojis(), 
/* 2551 */         stickers(), 
/* 2552 */         members(), 
/* 2553 */         channels());
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableGuildData withWidgetChannelIdOrNull(@Nullable Long value) {
/* 2558 */     Possible<Optional<Id>> newValue = (value == null) ? Possible.of(Optional.empty()) : Possible.of(Optional.of(Id.of(value.longValue())));
/* 2559 */     return new ImmutableGuildData(this, 
/*      */         
/* 2561 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2566 */         owner(), 
/* 2567 */         permissions(), 
/* 2568 */         afkChannelId(), 
/* 2569 */         embedEnabled(), 
/* 2570 */         embedChannelId(), this.features, 
/*      */         
/* 2572 */         applicationId(), 
/* 2573 */         widgetEnabled(), newValue, 
/*      */         
/* 2575 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2577 */         rulesChannelId(), 
/* 2578 */         maxPresences(), 
/* 2579 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2583 */         premiumSubscriptionCount(), 
/* 2584 */         publicUpdatesChannelId(), 
/* 2585 */         maxVideoChannelUsers(), 
/* 2586 */         approximateMemberCount(), 
/* 2587 */         approximatePresenceCount(), 
/* 2588 */         welcomeScreen(), 
/* 2589 */         nsfw(), 
/* 2590 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 2593 */         ownerId(), 
/* 2594 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2603 */         unavailable(), this.memberCount, 
/*      */         
/* 2605 */         roles(), 
/* 2606 */         emojis(), 
/* 2607 */         stickers(), 
/* 2608 */         members(), 
/* 2609 */         channels());
/*      */   }
/*      */   
/*      */   public ImmutableGuildData withSystemChannelId(Optional<Id> value) {
/* 2613 */     Optional<Id> newValue = Objects.<Optional<Id>>requireNonNull(value);
/* 2614 */     return new ImmutableGuildData(this, 
/*      */         
/* 2616 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2621 */         owner(), 
/* 2622 */         permissions(), 
/* 2623 */         afkChannelId(), 
/* 2624 */         embedEnabled(), 
/* 2625 */         embedChannelId(), this.features, 
/*      */         
/* 2627 */         applicationId(), 
/* 2628 */         widgetEnabled(), 
/* 2629 */         widgetChannelId(), newValue, this.systemChannelFlags, 
/*      */ 
/*      */         
/* 2632 */         rulesChannelId(), 
/* 2633 */         maxPresences(), 
/* 2634 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2638 */         premiumSubscriptionCount(), 
/* 2639 */         publicUpdatesChannelId(), 
/* 2640 */         maxVideoChannelUsers(), 
/* 2641 */         approximateMemberCount(), 
/* 2642 */         approximatePresenceCount(), 
/* 2643 */         welcomeScreen(), 
/* 2644 */         nsfw(), 
/* 2645 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 2648 */         ownerId(), 
/* 2649 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2658 */         unavailable(), this.memberCount, 
/*      */         
/* 2660 */         roles(), 
/* 2661 */         emojis(), 
/* 2662 */         stickers(), 
/* 2663 */         members(), 
/* 2664 */         channels());
/*      */   }
/*      */   
/*      */   public ImmutableGuildData withSystemChannelId(long value) {
/* 2668 */     Optional<Id> newValue = Optional.of(Id.of(value));
/* 2669 */     return new ImmutableGuildData(this, 
/*      */         
/* 2671 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2676 */         owner(), 
/* 2677 */         permissions(), 
/* 2678 */         afkChannelId(), 
/* 2679 */         embedEnabled(), 
/* 2680 */         embedChannelId(), this.features, 
/*      */         
/* 2682 */         applicationId(), 
/* 2683 */         widgetEnabled(), 
/* 2684 */         widgetChannelId(), newValue, this.systemChannelFlags, 
/*      */ 
/*      */         
/* 2687 */         rulesChannelId(), 
/* 2688 */         maxPresences(), 
/* 2689 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2693 */         premiumSubscriptionCount(), 
/* 2694 */         publicUpdatesChannelId(), 
/* 2695 */         maxVideoChannelUsers(), 
/* 2696 */         approximateMemberCount(), 
/* 2697 */         approximatePresenceCount(), 
/* 2698 */         welcomeScreen(), 
/* 2699 */         nsfw(), 
/* 2700 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 2703 */         ownerId(), 
/* 2704 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2713 */         unavailable(), this.memberCount, 
/*      */         
/* 2715 */         roles(), 
/* 2716 */         emojis(), 
/* 2717 */         stickers(), 
/* 2718 */         members(), 
/* 2719 */         channels());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildData withSystemChannelFlags(int value) {
/* 2728 */     Integer newValue = Integer.valueOf(value);
/* 2729 */     if (Objects.equals(this.systemChannelFlags, newValue)) return this; 
/* 2730 */     return new ImmutableGuildData(this, 
/*      */         
/* 2732 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2737 */         owner(), 
/* 2738 */         permissions(), 
/* 2739 */         afkChannelId(), 
/* 2740 */         embedEnabled(), 
/* 2741 */         embedChannelId(), this.features, 
/*      */         
/* 2743 */         applicationId(), 
/* 2744 */         widgetEnabled(), 
/* 2745 */         widgetChannelId(), 
/* 2746 */         systemChannelId(), newValue, 
/*      */         
/* 2748 */         rulesChannelId(), 
/* 2749 */         maxPresences(), 
/* 2750 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2754 */         premiumSubscriptionCount(), 
/* 2755 */         publicUpdatesChannelId(), 
/* 2756 */         maxVideoChannelUsers(), 
/* 2757 */         approximateMemberCount(), 
/* 2758 */         approximatePresenceCount(), 
/* 2759 */         welcomeScreen(), 
/* 2760 */         nsfw(), 
/* 2761 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 2764 */         ownerId(), 
/* 2765 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2774 */         unavailable(), this.memberCount, 
/*      */         
/* 2776 */         roles(), 
/* 2777 */         emojis(), 
/* 2778 */         stickers(), 
/* 2779 */         members(), 
/* 2780 */         channels());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildData withSystemChannelFlags(OptionalInt optional) {
/* 2790 */     Integer value = optional.isPresent() ? Integer.valueOf(optional.getAsInt()) : null;
/* 2791 */     if (Objects.equals(this.systemChannelFlags, value)) return this; 
/* 2792 */     return new ImmutableGuildData(this, 
/*      */         
/* 2794 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2799 */         owner(), 
/* 2800 */         permissions(), 
/* 2801 */         afkChannelId(), 
/* 2802 */         embedEnabled(), 
/* 2803 */         embedChannelId(), this.features, 
/*      */         
/* 2805 */         applicationId(), 
/* 2806 */         widgetEnabled(), 
/* 2807 */         widgetChannelId(), 
/* 2808 */         systemChannelId(), value, 
/*      */         
/* 2810 */         rulesChannelId(), 
/* 2811 */         maxPresences(), 
/* 2812 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2816 */         premiumSubscriptionCount(), 
/* 2817 */         publicUpdatesChannelId(), 
/* 2818 */         maxVideoChannelUsers(), 
/* 2819 */         approximateMemberCount(), 
/* 2820 */         approximatePresenceCount(), 
/* 2821 */         welcomeScreen(), 
/* 2822 */         nsfw(), 
/* 2823 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 2826 */         ownerId(), 
/* 2827 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2836 */         unavailable(), this.memberCount, 
/*      */         
/* 2838 */         roles(), 
/* 2839 */         emojis(), 
/* 2840 */         stickers(), 
/* 2841 */         members(), 
/* 2842 */         channels());
/*      */   }
/*      */   
/*      */   public ImmutableGuildData withRulesChannelId(Optional<Id> value) {
/* 2846 */     Optional<Id> newValue = Objects.<Optional<Id>>requireNonNull(value);
/* 2847 */     return new ImmutableGuildData(this, 
/*      */         
/* 2849 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2854 */         owner(), 
/* 2855 */         permissions(), 
/* 2856 */         afkChannelId(), 
/* 2857 */         embedEnabled(), 
/* 2858 */         embedChannelId(), this.features, 
/*      */         
/* 2860 */         applicationId(), 
/* 2861 */         widgetEnabled(), 
/* 2862 */         widgetChannelId(), 
/* 2863 */         systemChannelId(), this.systemChannelFlags, newValue, 
/*      */ 
/*      */         
/* 2866 */         maxPresences(), 
/* 2867 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2871 */         premiumSubscriptionCount(), 
/* 2872 */         publicUpdatesChannelId(), 
/* 2873 */         maxVideoChannelUsers(), 
/* 2874 */         approximateMemberCount(), 
/* 2875 */         approximatePresenceCount(), 
/* 2876 */         welcomeScreen(), 
/* 2877 */         nsfw(), 
/* 2878 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 2881 */         ownerId(), 
/* 2882 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2891 */         unavailable(), this.memberCount, 
/*      */         
/* 2893 */         roles(), 
/* 2894 */         emojis(), 
/* 2895 */         stickers(), 
/* 2896 */         members(), 
/* 2897 */         channels());
/*      */   }
/*      */   
/*      */   public ImmutableGuildData withRulesChannelId(long value) {
/* 2901 */     Optional<Id> newValue = Optional.of(Id.of(value));
/* 2902 */     return new ImmutableGuildData(this, 
/*      */         
/* 2904 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2909 */         owner(), 
/* 2910 */         permissions(), 
/* 2911 */         afkChannelId(), 
/* 2912 */         embedEnabled(), 
/* 2913 */         embedChannelId(), this.features, 
/*      */         
/* 2915 */         applicationId(), 
/* 2916 */         widgetEnabled(), 
/* 2917 */         widgetChannelId(), 
/* 2918 */         systemChannelId(), this.systemChannelFlags, newValue, 
/*      */ 
/*      */         
/* 2921 */         maxPresences(), 
/* 2922 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2926 */         premiumSubscriptionCount(), 
/* 2927 */         publicUpdatesChannelId(), 
/* 2928 */         maxVideoChannelUsers(), 
/* 2929 */         approximateMemberCount(), 
/* 2930 */         approximatePresenceCount(), 
/* 2931 */         welcomeScreen(), 
/* 2932 */         nsfw(), 
/* 2933 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 2936 */         ownerId(), 
/* 2937 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2946 */         unavailable(), this.memberCount, 
/*      */         
/* 2948 */         roles(), 
/* 2949 */         emojis(), 
/* 2950 */         stickers(), 
/* 2951 */         members(), 
/* 2952 */         channels());
/*      */   }
/*      */   
/*      */   public ImmutableGuildData withMaxPresences(Possible<Optional<Integer>> value) {
/* 2956 */     Possible<Optional<Integer>> newValue = Objects.<Possible<Optional<Integer>>>requireNonNull(value);
/* 2957 */     return new ImmutableGuildData(this, 
/*      */         
/* 2959 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2964 */         owner(), 
/* 2965 */         permissions(), 
/* 2966 */         afkChannelId(), 
/* 2967 */         embedEnabled(), 
/* 2968 */         embedChannelId(), this.features, 
/*      */         
/* 2970 */         applicationId(), 
/* 2971 */         widgetEnabled(), 
/* 2972 */         widgetChannelId(), 
/* 2973 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2975 */         rulesChannelId(), newValue, 
/*      */         
/* 2977 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2981 */         premiumSubscriptionCount(), 
/* 2982 */         publicUpdatesChannelId(), 
/* 2983 */         maxVideoChannelUsers(), 
/* 2984 */         approximateMemberCount(), 
/* 2985 */         approximatePresenceCount(), 
/* 2986 */         welcomeScreen(), 
/* 2987 */         nsfw(), 
/* 2988 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 2991 */         ownerId(), 
/* 2992 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3001 */         unavailable(), this.memberCount, 
/*      */         
/* 3003 */         roles(), 
/* 3004 */         emojis(), 
/* 3005 */         stickers(), 
/* 3006 */         members(), 
/* 3007 */         channels());
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableGuildData withMaxPresences(@Nullable Integer value) {
/* 3012 */     Possible<Optional<Integer>> newValue = Possible.of(Optional.ofNullable(value));
/* 3013 */     return new ImmutableGuildData(this, 
/*      */         
/* 3015 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3020 */         owner(), 
/* 3021 */         permissions(), 
/* 3022 */         afkChannelId(), 
/* 3023 */         embedEnabled(), 
/* 3024 */         embedChannelId(), this.features, 
/*      */         
/* 3026 */         applicationId(), 
/* 3027 */         widgetEnabled(), 
/* 3028 */         widgetChannelId(), 
/* 3029 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 3031 */         rulesChannelId(), newValue, 
/*      */         
/* 3033 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 3037 */         premiumSubscriptionCount(), 
/* 3038 */         publicUpdatesChannelId(), 
/* 3039 */         maxVideoChannelUsers(), 
/* 3040 */         approximateMemberCount(), 
/* 3041 */         approximatePresenceCount(), 
/* 3042 */         welcomeScreen(), 
/* 3043 */         nsfw(), 
/* 3044 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 3047 */         ownerId(), 
/* 3048 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3057 */         unavailable(), this.memberCount, 
/*      */         
/* 3059 */         roles(), 
/* 3060 */         emojis(), 
/* 3061 */         stickers(), 
/* 3062 */         members(), 
/* 3063 */         channels());
/*      */   }
/*      */   
/*      */   public ImmutableGuildData withMaxPresencesOrNull(@Nullable Integer value) {
/* 3067 */     Possible<Optional<Integer>> newValue = Possible.of(Optional.ofNullable(value));
/* 3068 */     return new ImmutableGuildData(this, 
/*      */         
/* 3070 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3075 */         owner(), 
/* 3076 */         permissions(), 
/* 3077 */         afkChannelId(), 
/* 3078 */         embedEnabled(), 
/* 3079 */         embedChannelId(), this.features, 
/*      */         
/* 3081 */         applicationId(), 
/* 3082 */         widgetEnabled(), 
/* 3083 */         widgetChannelId(), 
/* 3084 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 3086 */         rulesChannelId(), newValue, 
/*      */         
/* 3088 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 3092 */         premiumSubscriptionCount(), 
/* 3093 */         publicUpdatesChannelId(), 
/* 3094 */         maxVideoChannelUsers(), 
/* 3095 */         approximateMemberCount(), 
/* 3096 */         approximatePresenceCount(), 
/* 3097 */         welcomeScreen(), 
/* 3098 */         nsfw(), 
/* 3099 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 3102 */         ownerId(), 
/* 3103 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3112 */         unavailable(), this.memberCount, 
/*      */         
/* 3114 */         roles(), 
/* 3115 */         emojis(), 
/* 3116 */         stickers(), 
/* 3117 */         members(), 
/* 3118 */         channels());
/*      */   }
/*      */   
/*      */   public ImmutableGuildData withMaxMembers(Possible<Integer> value) {
/* 3122 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 3123 */     return new ImmutableGuildData(this, 
/*      */         
/* 3125 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3130 */         owner(), 
/* 3131 */         permissions(), 
/* 3132 */         afkChannelId(), 
/* 3133 */         embedEnabled(), 
/* 3134 */         embedChannelId(), this.features, 
/*      */         
/* 3136 */         applicationId(), 
/* 3137 */         widgetEnabled(), 
/* 3138 */         widgetChannelId(), 
/* 3139 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 3141 */         rulesChannelId(), 
/* 3142 */         maxPresences(), newValue, this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3147 */         premiumSubscriptionCount(), 
/* 3148 */         publicUpdatesChannelId(), 
/* 3149 */         maxVideoChannelUsers(), 
/* 3150 */         approximateMemberCount(), 
/* 3151 */         approximatePresenceCount(), 
/* 3152 */         welcomeScreen(), 
/* 3153 */         nsfw(), 
/* 3154 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 3157 */         ownerId(), 
/* 3158 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3167 */         unavailable(), this.memberCount, 
/*      */         
/* 3169 */         roles(), 
/* 3170 */         emojis(), 
/* 3171 */         stickers(), 
/* 3172 */         members(), 
/* 3173 */         channels());
/*      */   }
/*      */   
/*      */   public ImmutableGuildData withMaxMembers(Integer value) {
/* 3177 */     Possible<Integer> newValue = Possible.of(value);
/* 3178 */     return new ImmutableGuildData(this, 
/*      */         
/* 3180 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3185 */         owner(), 
/* 3186 */         permissions(), 
/* 3187 */         afkChannelId(), 
/* 3188 */         embedEnabled(), 
/* 3189 */         embedChannelId(), this.features, 
/*      */         
/* 3191 */         applicationId(), 
/* 3192 */         widgetEnabled(), 
/* 3193 */         widgetChannelId(), 
/* 3194 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 3196 */         rulesChannelId(), 
/* 3197 */         maxPresences(), newValue, this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3202 */         premiumSubscriptionCount(), 
/* 3203 */         publicUpdatesChannelId(), 
/* 3204 */         maxVideoChannelUsers(), 
/* 3205 */         approximateMemberCount(), 
/* 3206 */         approximatePresenceCount(), 
/* 3207 */         welcomeScreen(), 
/* 3208 */         nsfw(), 
/* 3209 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 3212 */         ownerId(), 
/* 3213 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3222 */         unavailable(), this.memberCount, 
/*      */         
/* 3224 */         roles(), 
/* 3225 */         emojis(), 
/* 3226 */         stickers(), 
/* 3227 */         members(), 
/* 3228 */         channels());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildData withVanityUrlCode(String value) {
/* 3237 */     String newValue = Objects.<String>requireNonNull(value, "vanityUrlCode");
/* 3238 */     if (Objects.equals(this.vanityUrlCode, newValue)) return this; 
/* 3239 */     return new ImmutableGuildData(this, 
/*      */         
/* 3241 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3246 */         owner(), 
/* 3247 */         permissions(), 
/* 3248 */         afkChannelId(), 
/* 3249 */         embedEnabled(), 
/* 3250 */         embedChannelId(), this.features, 
/*      */         
/* 3252 */         applicationId(), 
/* 3253 */         widgetEnabled(), 
/* 3254 */         widgetChannelId(), 
/* 3255 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 3257 */         rulesChannelId(), 
/* 3258 */         maxPresences(), 
/* 3259 */         maxMembers(), newValue, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 3263 */         premiumSubscriptionCount(), 
/* 3264 */         publicUpdatesChannelId(), 
/* 3265 */         maxVideoChannelUsers(), 
/* 3266 */         approximateMemberCount(), 
/* 3267 */         approximatePresenceCount(), 
/* 3268 */         welcomeScreen(), 
/* 3269 */         nsfw(), 
/* 3270 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 3273 */         ownerId(), 
/* 3274 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3283 */         unavailable(), this.memberCount, 
/*      */         
/* 3285 */         roles(), 
/* 3286 */         emojis(), 
/* 3287 */         stickers(), 
/* 3288 */         members(), 
/* 3289 */         channels());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildData withVanityUrlCode(Optional<String> optional) {
/* 3299 */     String value = optional.orElse(null);
/* 3300 */     if (Objects.equals(this.vanityUrlCode, value)) return this; 
/* 3301 */     return new ImmutableGuildData(this, 
/*      */         
/* 3303 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3308 */         owner(), 
/* 3309 */         permissions(), 
/* 3310 */         afkChannelId(), 
/* 3311 */         embedEnabled(), 
/* 3312 */         embedChannelId(), this.features, 
/*      */         
/* 3314 */         applicationId(), 
/* 3315 */         widgetEnabled(), 
/* 3316 */         widgetChannelId(), 
/* 3317 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 3319 */         rulesChannelId(), 
/* 3320 */         maxPresences(), 
/* 3321 */         maxMembers(), value, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 3325 */         premiumSubscriptionCount(), 
/* 3326 */         publicUpdatesChannelId(), 
/* 3327 */         maxVideoChannelUsers(), 
/* 3328 */         approximateMemberCount(), 
/* 3329 */         approximatePresenceCount(), 
/* 3330 */         welcomeScreen(), 
/* 3331 */         nsfw(), 
/* 3332 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 3335 */         ownerId(), 
/* 3336 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3345 */         unavailable(), this.memberCount, 
/*      */         
/* 3347 */         roles(), 
/* 3348 */         emojis(), 
/* 3349 */         stickers(), 
/* 3350 */         members(), 
/* 3351 */         channels());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildData withDescription(String value) {
/* 3360 */     String newValue = Objects.<String>requireNonNull(value, "description");
/* 3361 */     if (Objects.equals(this.description, newValue)) return this; 
/* 3362 */     return new ImmutableGuildData(this, 
/*      */         
/* 3364 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3369 */         owner(), 
/* 3370 */         permissions(), 
/* 3371 */         afkChannelId(), 
/* 3372 */         embedEnabled(), 
/* 3373 */         embedChannelId(), this.features, 
/*      */         
/* 3375 */         applicationId(), 
/* 3376 */         widgetEnabled(), 
/* 3377 */         widgetChannelId(), 
/* 3378 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 3380 */         rulesChannelId(), 
/* 3381 */         maxPresences(), 
/* 3382 */         maxMembers(), this.vanityUrlCode, newValue, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 3386 */         premiumSubscriptionCount(), 
/* 3387 */         publicUpdatesChannelId(), 
/* 3388 */         maxVideoChannelUsers(), 
/* 3389 */         approximateMemberCount(), 
/* 3390 */         approximatePresenceCount(), 
/* 3391 */         welcomeScreen(), 
/* 3392 */         nsfw(), 
/* 3393 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 3396 */         ownerId(), 
/* 3397 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3406 */         unavailable(), this.memberCount, 
/*      */         
/* 3408 */         roles(), 
/* 3409 */         emojis(), 
/* 3410 */         stickers(), 
/* 3411 */         members(), 
/* 3412 */         channels());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildData withDescription(Optional<String> optional) {
/* 3422 */     String value = optional.orElse(null);
/* 3423 */     if (Objects.equals(this.description, value)) return this; 
/* 3424 */     return new ImmutableGuildData(this, 
/*      */         
/* 3426 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3431 */         owner(), 
/* 3432 */         permissions(), 
/* 3433 */         afkChannelId(), 
/* 3434 */         embedEnabled(), 
/* 3435 */         embedChannelId(), this.features, 
/*      */         
/* 3437 */         applicationId(), 
/* 3438 */         widgetEnabled(), 
/* 3439 */         widgetChannelId(), 
/* 3440 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 3442 */         rulesChannelId(), 
/* 3443 */         maxPresences(), 
/* 3444 */         maxMembers(), this.vanityUrlCode, value, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 3448 */         premiumSubscriptionCount(), 
/* 3449 */         publicUpdatesChannelId(), 
/* 3450 */         maxVideoChannelUsers(), 
/* 3451 */         approximateMemberCount(), 
/* 3452 */         approximatePresenceCount(), 
/* 3453 */         welcomeScreen(), 
/* 3454 */         nsfw(), 
/* 3455 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 3458 */         ownerId(), 
/* 3459 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3468 */         unavailable(), this.memberCount, 
/*      */         
/* 3470 */         roles(), 
/* 3471 */         emojis(), 
/* 3472 */         stickers(), 
/* 3473 */         members(), 
/* 3474 */         channels());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildData withBanner(String value) {
/* 3483 */     String newValue = Objects.<String>requireNonNull(value, "banner");
/* 3484 */     if (Objects.equals(this.banner, newValue)) return this; 
/* 3485 */     return new ImmutableGuildData(this, 
/*      */         
/* 3487 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3492 */         owner(), 
/* 3493 */         permissions(), 
/* 3494 */         afkChannelId(), 
/* 3495 */         embedEnabled(), 
/* 3496 */         embedChannelId(), this.features, 
/*      */         
/* 3498 */         applicationId(), 
/* 3499 */         widgetEnabled(), 
/* 3500 */         widgetChannelId(), 
/* 3501 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 3503 */         rulesChannelId(), 
/* 3504 */         maxPresences(), 
/* 3505 */         maxMembers(), this.vanityUrlCode, this.description, newValue, 
/*      */ 
/*      */ 
/*      */         
/* 3509 */         premiumSubscriptionCount(), 
/* 3510 */         publicUpdatesChannelId(), 
/* 3511 */         maxVideoChannelUsers(), 
/* 3512 */         approximateMemberCount(), 
/* 3513 */         approximatePresenceCount(), 
/* 3514 */         welcomeScreen(), 
/* 3515 */         nsfw(), 
/* 3516 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 3519 */         ownerId(), 
/* 3520 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3529 */         unavailable(), this.memberCount, 
/*      */         
/* 3531 */         roles(), 
/* 3532 */         emojis(), 
/* 3533 */         stickers(), 
/* 3534 */         members(), 
/* 3535 */         channels());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildData withBanner(Optional<String> optional) {
/* 3545 */     String value = optional.orElse(null);
/* 3546 */     if (Objects.equals(this.banner, value)) return this; 
/* 3547 */     return new ImmutableGuildData(this, 
/*      */         
/* 3549 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3554 */         owner(), 
/* 3555 */         permissions(), 
/* 3556 */         afkChannelId(), 
/* 3557 */         embedEnabled(), 
/* 3558 */         embedChannelId(), this.features, 
/*      */         
/* 3560 */         applicationId(), 
/* 3561 */         widgetEnabled(), 
/* 3562 */         widgetChannelId(), 
/* 3563 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 3565 */         rulesChannelId(), 
/* 3566 */         maxPresences(), 
/* 3567 */         maxMembers(), this.vanityUrlCode, this.description, value, 
/*      */ 
/*      */ 
/*      */         
/* 3571 */         premiumSubscriptionCount(), 
/* 3572 */         publicUpdatesChannelId(), 
/* 3573 */         maxVideoChannelUsers(), 
/* 3574 */         approximateMemberCount(), 
/* 3575 */         approximatePresenceCount(), 
/* 3576 */         welcomeScreen(), 
/* 3577 */         nsfw(), 
/* 3578 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 3581 */         ownerId(), 
/* 3582 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3591 */         unavailable(), this.memberCount, 
/*      */         
/* 3593 */         roles(), 
/* 3594 */         emojis(), 
/* 3595 */         stickers(), 
/* 3596 */         members(), 
/* 3597 */         channels());
/*      */   }
/*      */   
/*      */   public ImmutableGuildData withPremiumSubscriptionCount(Possible<Integer> value) {
/* 3601 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 3602 */     return new ImmutableGuildData(this, 
/*      */         
/* 3604 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3609 */         owner(), 
/* 3610 */         permissions(), 
/* 3611 */         afkChannelId(), 
/* 3612 */         embedEnabled(), 
/* 3613 */         embedChannelId(), this.features, 
/*      */         
/* 3615 */         applicationId(), 
/* 3616 */         widgetEnabled(), 
/* 3617 */         widgetChannelId(), 
/* 3618 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 3620 */         rulesChannelId(), 
/* 3621 */         maxPresences(), 
/* 3622 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, newValue, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3627 */         publicUpdatesChannelId(), 
/* 3628 */         maxVideoChannelUsers(), 
/* 3629 */         approximateMemberCount(), 
/* 3630 */         approximatePresenceCount(), 
/* 3631 */         welcomeScreen(), 
/* 3632 */         nsfw(), 
/* 3633 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 3636 */         ownerId(), 
/* 3637 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3646 */         unavailable(), this.memberCount, 
/*      */         
/* 3648 */         roles(), 
/* 3649 */         emojis(), 
/* 3650 */         stickers(), 
/* 3651 */         members(), 
/* 3652 */         channels());
/*      */   }
/*      */   
/*      */   public ImmutableGuildData withPremiumSubscriptionCount(Integer value) {
/* 3656 */     Possible<Integer> newValue = Possible.of(value);
/* 3657 */     return new ImmutableGuildData(this, 
/*      */         
/* 3659 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3664 */         owner(), 
/* 3665 */         permissions(), 
/* 3666 */         afkChannelId(), 
/* 3667 */         embedEnabled(), 
/* 3668 */         embedChannelId(), this.features, 
/*      */         
/* 3670 */         applicationId(), 
/* 3671 */         widgetEnabled(), 
/* 3672 */         widgetChannelId(), 
/* 3673 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 3675 */         rulesChannelId(), 
/* 3676 */         maxPresences(), 
/* 3677 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, newValue, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3682 */         publicUpdatesChannelId(), 
/* 3683 */         maxVideoChannelUsers(), 
/* 3684 */         approximateMemberCount(), 
/* 3685 */         approximatePresenceCount(), 
/* 3686 */         welcomeScreen(), 
/* 3687 */         nsfw(), 
/* 3688 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 3691 */         ownerId(), 
/* 3692 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3701 */         unavailable(), this.memberCount, 
/*      */         
/* 3703 */         roles(), 
/* 3704 */         emojis(), 
/* 3705 */         stickers(), 
/* 3706 */         members(), 
/* 3707 */         channels());
/*      */   }
/*      */   
/*      */   public ImmutableGuildData withPublicUpdatesChannelId(Optional<Id> value) {
/* 3711 */     Optional<Id> newValue = Objects.<Optional<Id>>requireNonNull(value);
/* 3712 */     return new ImmutableGuildData(this, 
/*      */         
/* 3714 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3719 */         owner(), 
/* 3720 */         permissions(), 
/* 3721 */         afkChannelId(), 
/* 3722 */         embedEnabled(), 
/* 3723 */         embedChannelId(), this.features, 
/*      */         
/* 3725 */         applicationId(), 
/* 3726 */         widgetEnabled(), 
/* 3727 */         widgetChannelId(), 
/* 3728 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 3730 */         rulesChannelId(), 
/* 3731 */         maxPresences(), 
/* 3732 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 3736 */         premiumSubscriptionCount(), newValue, 
/*      */         
/* 3738 */         maxVideoChannelUsers(), 
/* 3739 */         approximateMemberCount(), 
/* 3740 */         approximatePresenceCount(), 
/* 3741 */         welcomeScreen(), 
/* 3742 */         nsfw(), 
/* 3743 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 3746 */         ownerId(), 
/* 3747 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3756 */         unavailable(), this.memberCount, 
/*      */         
/* 3758 */         roles(), 
/* 3759 */         emojis(), 
/* 3760 */         stickers(), 
/* 3761 */         members(), 
/* 3762 */         channels());
/*      */   }
/*      */   
/*      */   public ImmutableGuildData withPublicUpdatesChannelId(long value) {
/* 3766 */     Optional<Id> newValue = Optional.of(Id.of(value));
/* 3767 */     return new ImmutableGuildData(this, 
/*      */         
/* 3769 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3774 */         owner(), 
/* 3775 */         permissions(), 
/* 3776 */         afkChannelId(), 
/* 3777 */         embedEnabled(), 
/* 3778 */         embedChannelId(), this.features, 
/*      */         
/* 3780 */         applicationId(), 
/* 3781 */         widgetEnabled(), 
/* 3782 */         widgetChannelId(), 
/* 3783 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 3785 */         rulesChannelId(), 
/* 3786 */         maxPresences(), 
/* 3787 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 3791 */         premiumSubscriptionCount(), newValue, 
/*      */         
/* 3793 */         maxVideoChannelUsers(), 
/* 3794 */         approximateMemberCount(), 
/* 3795 */         approximatePresenceCount(), 
/* 3796 */         welcomeScreen(), 
/* 3797 */         nsfw(), 
/* 3798 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 3801 */         ownerId(), 
/* 3802 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3811 */         unavailable(), this.memberCount, 
/*      */         
/* 3813 */         roles(), 
/* 3814 */         emojis(), 
/* 3815 */         stickers(), 
/* 3816 */         members(), 
/* 3817 */         channels());
/*      */   }
/*      */   
/*      */   public ImmutableGuildData withMaxVideoChannelUsers(Possible<Integer> value) {
/* 3821 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 3822 */     return new ImmutableGuildData(this, 
/*      */         
/* 3824 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3829 */         owner(), 
/* 3830 */         permissions(), 
/* 3831 */         afkChannelId(), 
/* 3832 */         embedEnabled(), 
/* 3833 */         embedChannelId(), this.features, 
/*      */         
/* 3835 */         applicationId(), 
/* 3836 */         widgetEnabled(), 
/* 3837 */         widgetChannelId(), 
/* 3838 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 3840 */         rulesChannelId(), 
/* 3841 */         maxPresences(), 
/* 3842 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 3846 */         premiumSubscriptionCount(), 
/* 3847 */         publicUpdatesChannelId(), newValue, 
/*      */         
/* 3849 */         approximateMemberCount(), 
/* 3850 */         approximatePresenceCount(), 
/* 3851 */         welcomeScreen(), 
/* 3852 */         nsfw(), 
/* 3853 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 3856 */         ownerId(), 
/* 3857 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3866 */         unavailable(), this.memberCount, 
/*      */         
/* 3868 */         roles(), 
/* 3869 */         emojis(), 
/* 3870 */         stickers(), 
/* 3871 */         members(), 
/* 3872 */         channels());
/*      */   }
/*      */   
/*      */   public ImmutableGuildData withMaxVideoChannelUsers(Integer value) {
/* 3876 */     Possible<Integer> newValue = Possible.of(value);
/* 3877 */     return new ImmutableGuildData(this, 
/*      */         
/* 3879 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3884 */         owner(), 
/* 3885 */         permissions(), 
/* 3886 */         afkChannelId(), 
/* 3887 */         embedEnabled(), 
/* 3888 */         embedChannelId(), this.features, 
/*      */         
/* 3890 */         applicationId(), 
/* 3891 */         widgetEnabled(), 
/* 3892 */         widgetChannelId(), 
/* 3893 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 3895 */         rulesChannelId(), 
/* 3896 */         maxPresences(), 
/* 3897 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 3901 */         premiumSubscriptionCount(), 
/* 3902 */         publicUpdatesChannelId(), newValue, 
/*      */         
/* 3904 */         approximateMemberCount(), 
/* 3905 */         approximatePresenceCount(), 
/* 3906 */         welcomeScreen(), 
/* 3907 */         nsfw(), 
/* 3908 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 3911 */         ownerId(), 
/* 3912 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3921 */         unavailable(), this.memberCount, 
/*      */         
/* 3923 */         roles(), 
/* 3924 */         emojis(), 
/* 3925 */         stickers(), 
/* 3926 */         members(), 
/* 3927 */         channels());
/*      */   }
/*      */   
/*      */   public ImmutableGuildData withApproximateMemberCount(Possible<Integer> value) {
/* 3931 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 3932 */     return new ImmutableGuildData(this, 
/*      */         
/* 3934 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3939 */         owner(), 
/* 3940 */         permissions(), 
/* 3941 */         afkChannelId(), 
/* 3942 */         embedEnabled(), 
/* 3943 */         embedChannelId(), this.features, 
/*      */         
/* 3945 */         applicationId(), 
/* 3946 */         widgetEnabled(), 
/* 3947 */         widgetChannelId(), 
/* 3948 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 3950 */         rulesChannelId(), 
/* 3951 */         maxPresences(), 
/* 3952 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 3956 */         premiumSubscriptionCount(), 
/* 3957 */         publicUpdatesChannelId(), 
/* 3958 */         maxVideoChannelUsers(), newValue, 
/*      */         
/* 3960 */         approximatePresenceCount(), 
/* 3961 */         welcomeScreen(), 
/* 3962 */         nsfw(), 
/* 3963 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 3966 */         ownerId(), 
/* 3967 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3976 */         unavailable(), this.memberCount, 
/*      */         
/* 3978 */         roles(), 
/* 3979 */         emojis(), 
/* 3980 */         stickers(), 
/* 3981 */         members(), 
/* 3982 */         channels());
/*      */   }
/*      */   
/*      */   public ImmutableGuildData withApproximateMemberCount(Integer value) {
/* 3986 */     Possible<Integer> newValue = Possible.of(value);
/* 3987 */     return new ImmutableGuildData(this, 
/*      */         
/* 3989 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3994 */         owner(), 
/* 3995 */         permissions(), 
/* 3996 */         afkChannelId(), 
/* 3997 */         embedEnabled(), 
/* 3998 */         embedChannelId(), this.features, 
/*      */         
/* 4000 */         applicationId(), 
/* 4001 */         widgetEnabled(), 
/* 4002 */         widgetChannelId(), 
/* 4003 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 4005 */         rulesChannelId(), 
/* 4006 */         maxPresences(), 
/* 4007 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 4011 */         premiumSubscriptionCount(), 
/* 4012 */         publicUpdatesChannelId(), 
/* 4013 */         maxVideoChannelUsers(), newValue, 
/*      */         
/* 4015 */         approximatePresenceCount(), 
/* 4016 */         welcomeScreen(), 
/* 4017 */         nsfw(), 
/* 4018 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 4021 */         ownerId(), 
/* 4022 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4031 */         unavailable(), this.memberCount, 
/*      */         
/* 4033 */         roles(), 
/* 4034 */         emojis(), 
/* 4035 */         stickers(), 
/* 4036 */         members(), 
/* 4037 */         channels());
/*      */   }
/*      */   
/*      */   public ImmutableGuildData withApproximatePresenceCount(Possible<Integer> value) {
/* 4041 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 4042 */     return new ImmutableGuildData(this, 
/*      */         
/* 4044 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4049 */         owner(), 
/* 4050 */         permissions(), 
/* 4051 */         afkChannelId(), 
/* 4052 */         embedEnabled(), 
/* 4053 */         embedChannelId(), this.features, 
/*      */         
/* 4055 */         applicationId(), 
/* 4056 */         widgetEnabled(), 
/* 4057 */         widgetChannelId(), 
/* 4058 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 4060 */         rulesChannelId(), 
/* 4061 */         maxPresences(), 
/* 4062 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 4066 */         premiumSubscriptionCount(), 
/* 4067 */         publicUpdatesChannelId(), 
/* 4068 */         maxVideoChannelUsers(), 
/* 4069 */         approximateMemberCount(), newValue, 
/*      */         
/* 4071 */         welcomeScreen(), 
/* 4072 */         nsfw(), 
/* 4073 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 4076 */         ownerId(), 
/* 4077 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4086 */         unavailable(), this.memberCount, 
/*      */         
/* 4088 */         roles(), 
/* 4089 */         emojis(), 
/* 4090 */         stickers(), 
/* 4091 */         members(), 
/* 4092 */         channels());
/*      */   }
/*      */   
/*      */   public ImmutableGuildData withApproximatePresenceCount(Integer value) {
/* 4096 */     Possible<Integer> newValue = Possible.of(value);
/* 4097 */     return new ImmutableGuildData(this, 
/*      */         
/* 4099 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4104 */         owner(), 
/* 4105 */         permissions(), 
/* 4106 */         afkChannelId(), 
/* 4107 */         embedEnabled(), 
/* 4108 */         embedChannelId(), this.features, 
/*      */         
/* 4110 */         applicationId(), 
/* 4111 */         widgetEnabled(), 
/* 4112 */         widgetChannelId(), 
/* 4113 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 4115 */         rulesChannelId(), 
/* 4116 */         maxPresences(), 
/* 4117 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 4121 */         premiumSubscriptionCount(), 
/* 4122 */         publicUpdatesChannelId(), 
/* 4123 */         maxVideoChannelUsers(), 
/* 4124 */         approximateMemberCount(), newValue, 
/*      */         
/* 4126 */         welcomeScreen(), 
/* 4127 */         nsfw(), 
/* 4128 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 4131 */         ownerId(), 
/* 4132 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4141 */         unavailable(), this.memberCount, 
/*      */         
/* 4143 */         roles(), 
/* 4144 */         emojis(), 
/* 4145 */         stickers(), 
/* 4146 */         members(), 
/* 4147 */         channels());
/*      */   }
/*      */   
/*      */   public ImmutableGuildData withWelcomeScreen(Possible<WelcomeScreenData> value) {
/* 4151 */     Possible<WelcomeScreenData> newValue = Objects.<Possible<WelcomeScreenData>>requireNonNull(value);
/* 4152 */     return new ImmutableGuildData(this, 
/*      */         
/* 4154 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4159 */         owner(), 
/* 4160 */         permissions(), 
/* 4161 */         afkChannelId(), 
/* 4162 */         embedEnabled(), 
/* 4163 */         embedChannelId(), this.features, 
/*      */         
/* 4165 */         applicationId(), 
/* 4166 */         widgetEnabled(), 
/* 4167 */         widgetChannelId(), 
/* 4168 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 4170 */         rulesChannelId(), 
/* 4171 */         maxPresences(), 
/* 4172 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 4176 */         premiumSubscriptionCount(), 
/* 4177 */         publicUpdatesChannelId(), 
/* 4178 */         maxVideoChannelUsers(), 
/* 4179 */         approximateMemberCount(), 
/* 4180 */         approximatePresenceCount(), newValue, 
/*      */         
/* 4182 */         nsfw(), 
/* 4183 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 4186 */         ownerId(), 
/* 4187 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4196 */         unavailable(), this.memberCount, 
/*      */         
/* 4198 */         roles(), 
/* 4199 */         emojis(), 
/* 4200 */         stickers(), 
/* 4201 */         members(), 
/* 4202 */         channels());
/*      */   }
/*      */   
/*      */   public ImmutableGuildData withWelcomeScreen(WelcomeScreenData value) {
/* 4206 */     Possible<WelcomeScreenData> newValue = Possible.of(value);
/* 4207 */     return new ImmutableGuildData(this, 
/*      */         
/* 4209 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4214 */         owner(), 
/* 4215 */         permissions(), 
/* 4216 */         afkChannelId(), 
/* 4217 */         embedEnabled(), 
/* 4218 */         embedChannelId(), this.features, 
/*      */         
/* 4220 */         applicationId(), 
/* 4221 */         widgetEnabled(), 
/* 4222 */         widgetChannelId(), 
/* 4223 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 4225 */         rulesChannelId(), 
/* 4226 */         maxPresences(), 
/* 4227 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 4231 */         premiumSubscriptionCount(), 
/* 4232 */         publicUpdatesChannelId(), 
/* 4233 */         maxVideoChannelUsers(), 
/* 4234 */         approximateMemberCount(), 
/* 4235 */         approximatePresenceCount(), newValue, 
/*      */         
/* 4237 */         nsfw(), 
/* 4238 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 4241 */         ownerId(), 
/* 4242 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4251 */         unavailable(), this.memberCount, 
/*      */         
/* 4253 */         roles(), 
/* 4254 */         emojis(), 
/* 4255 */         stickers(), 
/* 4256 */         members(), 
/* 4257 */         channels());
/*      */   }
/*      */   
/*      */   public ImmutableGuildData withNsfw(Possible<Boolean> value) {
/* 4261 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 4262 */     return new ImmutableGuildData(this, 
/*      */         
/* 4264 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4269 */         owner(), 
/* 4270 */         permissions(), 
/* 4271 */         afkChannelId(), 
/* 4272 */         embedEnabled(), 
/* 4273 */         embedChannelId(), this.features, 
/*      */         
/* 4275 */         applicationId(), 
/* 4276 */         widgetEnabled(), 
/* 4277 */         widgetChannelId(), 
/* 4278 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 4280 */         rulesChannelId(), 
/* 4281 */         maxPresences(), 
/* 4282 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 4286 */         premiumSubscriptionCount(), 
/* 4287 */         publicUpdatesChannelId(), 
/* 4288 */         maxVideoChannelUsers(), 
/* 4289 */         approximateMemberCount(), 
/* 4290 */         approximatePresenceCount(), 
/* 4291 */         welcomeScreen(), newValue, 
/*      */         
/* 4293 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 4296 */         ownerId(), 
/* 4297 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4306 */         unavailable(), this.memberCount, 
/*      */         
/* 4308 */         roles(), 
/* 4309 */         emojis(), 
/* 4310 */         stickers(), 
/* 4311 */         members(), 
/* 4312 */         channels());
/*      */   }
/*      */   
/*      */   public ImmutableGuildData withNsfw(Boolean value) {
/* 4316 */     Possible<Boolean> newValue = Possible.of(value);
/* 4317 */     return new ImmutableGuildData(this, 
/*      */         
/* 4319 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4324 */         owner(), 
/* 4325 */         permissions(), 
/* 4326 */         afkChannelId(), 
/* 4327 */         embedEnabled(), 
/* 4328 */         embedChannelId(), this.features, 
/*      */         
/* 4330 */         applicationId(), 
/* 4331 */         widgetEnabled(), 
/* 4332 */         widgetChannelId(), 
/* 4333 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 4335 */         rulesChannelId(), 
/* 4336 */         maxPresences(), 
/* 4337 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 4341 */         premiumSubscriptionCount(), 
/* 4342 */         publicUpdatesChannelId(), 
/* 4343 */         maxVideoChannelUsers(), 
/* 4344 */         approximateMemberCount(), 
/* 4345 */         approximatePresenceCount(), 
/* 4346 */         welcomeScreen(), newValue, 
/*      */         
/* 4348 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 4351 */         ownerId(), 
/* 4352 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4361 */         unavailable(), this.memberCount, 
/*      */         
/* 4363 */         roles(), 
/* 4364 */         emojis(), 
/* 4365 */         stickers(), 
/* 4366 */         members(), 
/* 4367 */         channels());
/*      */   }
/*      */   
/*      */   public ImmutableGuildData withSafetyAlertsChannelId(Optional<Id> value) {
/* 4371 */     Optional<Id> newValue = Objects.<Optional<Id>>requireNonNull(value);
/* 4372 */     return new ImmutableGuildData(this, 
/*      */         
/* 4374 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4379 */         owner(), 
/* 4380 */         permissions(), 
/* 4381 */         afkChannelId(), 
/* 4382 */         embedEnabled(), 
/* 4383 */         embedChannelId(), this.features, 
/*      */         
/* 4385 */         applicationId(), 
/* 4386 */         widgetEnabled(), 
/* 4387 */         widgetChannelId(), 
/* 4388 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 4390 */         rulesChannelId(), 
/* 4391 */         maxPresences(), 
/* 4392 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 4396 */         premiumSubscriptionCount(), 
/* 4397 */         publicUpdatesChannelId(), 
/* 4398 */         maxVideoChannelUsers(), 
/* 4399 */         approximateMemberCount(), 
/* 4400 */         approximatePresenceCount(), 
/* 4401 */         welcomeScreen(), 
/* 4402 */         nsfw(), newValue, this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */ 
/*      */         
/* 4406 */         ownerId(), 
/* 4407 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4416 */         unavailable(), this.memberCount, 
/*      */         
/* 4418 */         roles(), 
/* 4419 */         emojis(), 
/* 4420 */         stickers(), 
/* 4421 */         members(), 
/* 4422 */         channels());
/*      */   }
/*      */   
/*      */   public ImmutableGuildData withSafetyAlertsChannelId(long value) {
/* 4426 */     Optional<Id> newValue = Optional.of(Id.of(value));
/* 4427 */     return new ImmutableGuildData(this, 
/*      */         
/* 4429 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4434 */         owner(), 
/* 4435 */         permissions(), 
/* 4436 */         afkChannelId(), 
/* 4437 */         embedEnabled(), 
/* 4438 */         embedChannelId(), this.features, 
/*      */         
/* 4440 */         applicationId(), 
/* 4441 */         widgetEnabled(), 
/* 4442 */         widgetChannelId(), 
/* 4443 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 4445 */         rulesChannelId(), 
/* 4446 */         maxPresences(), 
/* 4447 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 4451 */         premiumSubscriptionCount(), 
/* 4452 */         publicUpdatesChannelId(), 
/* 4453 */         maxVideoChannelUsers(), 
/* 4454 */         approximateMemberCount(), 
/* 4455 */         approximatePresenceCount(), 
/* 4456 */         welcomeScreen(), 
/* 4457 */         nsfw(), newValue, this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */ 
/*      */         
/* 4461 */         ownerId(), 
/* 4462 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4471 */         unavailable(), this.memberCount, 
/*      */         
/* 4473 */         roles(), 
/* 4474 */         emojis(), 
/* 4475 */         stickers(), 
/* 4476 */         members(), 
/* 4477 */         channels());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildData withVerificationLevel(int value) {
/* 4487 */     if (this.verificationLevel == value) return this; 
/* 4488 */     return new ImmutableGuildData(this, 
/*      */         
/* 4490 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4495 */         owner(), 
/* 4496 */         permissions(), 
/* 4497 */         afkChannelId(), 
/* 4498 */         embedEnabled(), 
/* 4499 */         embedChannelId(), this.features, 
/*      */         
/* 4501 */         applicationId(), 
/* 4502 */         widgetEnabled(), 
/* 4503 */         widgetChannelId(), 
/* 4504 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 4506 */         rulesChannelId(), 
/* 4507 */         maxPresences(), 
/* 4508 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 4512 */         premiumSubscriptionCount(), 
/* 4513 */         publicUpdatesChannelId(), 
/* 4514 */         maxVideoChannelUsers(), 
/* 4515 */         approximateMemberCount(), 
/* 4516 */         approximatePresenceCount(), 
/* 4517 */         welcomeScreen(), 
/* 4518 */         nsfw(), 
/* 4519 */         safetyAlertsChannelId(), value, this.nsfwLevel, 
/*      */ 
/*      */         
/* 4522 */         ownerId(), 
/* 4523 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4532 */         unavailable(), this.memberCount, 
/*      */         
/* 4534 */         roles(), 
/* 4535 */         emojis(), 
/* 4536 */         stickers(), 
/* 4537 */         members(), 
/* 4538 */         channels());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildData withNsfwLevel(int value) {
/* 4548 */     if (this.nsfwLevel == value) return this; 
/* 4549 */     return new ImmutableGuildData(this, 
/*      */         
/* 4551 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4556 */         owner(), 
/* 4557 */         permissions(), 
/* 4558 */         afkChannelId(), 
/* 4559 */         embedEnabled(), 
/* 4560 */         embedChannelId(), this.features, 
/*      */         
/* 4562 */         applicationId(), 
/* 4563 */         widgetEnabled(), 
/* 4564 */         widgetChannelId(), 
/* 4565 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 4567 */         rulesChannelId(), 
/* 4568 */         maxPresences(), 
/* 4569 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 4573 */         premiumSubscriptionCount(), 
/* 4574 */         publicUpdatesChannelId(), 
/* 4575 */         maxVideoChannelUsers(), 
/* 4576 */         approximateMemberCount(), 
/* 4577 */         approximatePresenceCount(), 
/* 4578 */         welcomeScreen(), 
/* 4579 */         nsfw(), 
/* 4580 */         safetyAlertsChannelId(), this.verificationLevel, value, 
/*      */ 
/*      */         
/* 4583 */         ownerId(), 
/* 4584 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4593 */         unavailable(), this.memberCount, 
/*      */         
/* 4595 */         roles(), 
/* 4596 */         emojis(), 
/* 4597 */         stickers(), 
/* 4598 */         members(), 
/* 4599 */         channels());
/*      */   }
/*      */   
/*      */   public ImmutableGuildData withOwnerId(long value) {
/* 4603 */     Id newValue = Id.of(value);
/* 4604 */     return new ImmutableGuildData(this, 
/*      */         
/* 4606 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4611 */         owner(), 
/* 4612 */         permissions(), 
/* 4613 */         afkChannelId(), 
/* 4614 */         embedEnabled(), 
/* 4615 */         embedChannelId(), this.features, 
/*      */         
/* 4617 */         applicationId(), 
/* 4618 */         widgetEnabled(), 
/* 4619 */         widgetChannelId(), 
/* 4620 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 4622 */         rulesChannelId(), 
/* 4623 */         maxPresences(), 
/* 4624 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 4628 */         premiumSubscriptionCount(), 
/* 4629 */         publicUpdatesChannelId(), 
/* 4630 */         maxVideoChannelUsers(), 
/* 4631 */         approximateMemberCount(), 
/* 4632 */         approximatePresenceCount(), 
/* 4633 */         welcomeScreen(), 
/* 4634 */         nsfw(), 
/* 4635 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, newValue, 
/*      */ 
/*      */ 
/*      */         
/* 4639 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4648 */         unavailable(), this.memberCount, 
/*      */         
/* 4650 */         roles(), 
/* 4651 */         emojis(), 
/* 4652 */         stickers(), 
/* 4653 */         members(), 
/* 4654 */         channels());
/*      */   }
/*      */   
/*      */   public ImmutableGuildData withOwnerId(String value) {
/* 4658 */     Id newValue = Id.of(value);
/* 4659 */     return new ImmutableGuildData(this, 
/*      */         
/* 4661 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4666 */         owner(), 
/* 4667 */         permissions(), 
/* 4668 */         afkChannelId(), 
/* 4669 */         embedEnabled(), 
/* 4670 */         embedChannelId(), this.features, 
/*      */         
/* 4672 */         applicationId(), 
/* 4673 */         widgetEnabled(), 
/* 4674 */         widgetChannelId(), 
/* 4675 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 4677 */         rulesChannelId(), 
/* 4678 */         maxPresences(), 
/* 4679 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 4683 */         premiumSubscriptionCount(), 
/* 4684 */         publicUpdatesChannelId(), 
/* 4685 */         maxVideoChannelUsers(), 
/* 4686 */         approximateMemberCount(), 
/* 4687 */         approximatePresenceCount(), 
/* 4688 */         welcomeScreen(), 
/* 4689 */         nsfw(), 
/* 4690 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, newValue, 
/*      */ 
/*      */ 
/*      */         
/* 4694 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4703 */         unavailable(), this.memberCount, 
/*      */         
/* 4705 */         roles(), 
/* 4706 */         emojis(), 
/* 4707 */         stickers(), 
/* 4708 */         members(), 
/* 4709 */         channels());
/*      */   }
/*      */   
/*      */   public ImmutableGuildData withRegion(Possible<Optional<String>> value) {
/* 4713 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/* 4714 */     return new ImmutableGuildData(this, 
/*      */         
/* 4716 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4721 */         owner(), 
/* 4722 */         permissions(), 
/* 4723 */         afkChannelId(), 
/* 4724 */         embedEnabled(), 
/* 4725 */         embedChannelId(), this.features, 
/*      */         
/* 4727 */         applicationId(), 
/* 4728 */         widgetEnabled(), 
/* 4729 */         widgetChannelId(), 
/* 4730 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 4732 */         rulesChannelId(), 
/* 4733 */         maxPresences(), 
/* 4734 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 4738 */         premiumSubscriptionCount(), 
/* 4739 */         publicUpdatesChannelId(), 
/* 4740 */         maxVideoChannelUsers(), 
/* 4741 */         approximateMemberCount(), 
/* 4742 */         approximatePresenceCount(), 
/* 4743 */         welcomeScreen(), 
/* 4744 */         nsfw(), 
/* 4745 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 4748 */         ownerId(), newValue, this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4758 */         unavailable(), this.memberCount, 
/*      */         
/* 4760 */         roles(), 
/* 4761 */         emojis(), 
/* 4762 */         stickers(), 
/* 4763 */         members(), 
/* 4764 */         channels());
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableGuildData withRegion(@Nullable String value) {
/* 4769 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 4770 */     return new ImmutableGuildData(this, 
/*      */         
/* 4772 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4777 */         owner(), 
/* 4778 */         permissions(), 
/* 4779 */         afkChannelId(), 
/* 4780 */         embedEnabled(), 
/* 4781 */         embedChannelId(), this.features, 
/*      */         
/* 4783 */         applicationId(), 
/* 4784 */         widgetEnabled(), 
/* 4785 */         widgetChannelId(), 
/* 4786 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 4788 */         rulesChannelId(), 
/* 4789 */         maxPresences(), 
/* 4790 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 4794 */         premiumSubscriptionCount(), 
/* 4795 */         publicUpdatesChannelId(), 
/* 4796 */         maxVideoChannelUsers(), 
/* 4797 */         approximateMemberCount(), 
/* 4798 */         approximatePresenceCount(), 
/* 4799 */         welcomeScreen(), 
/* 4800 */         nsfw(), 
/* 4801 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 4804 */         ownerId(), newValue, this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4814 */         unavailable(), this.memberCount, 
/*      */         
/* 4816 */         roles(), 
/* 4817 */         emojis(), 
/* 4818 */         stickers(), 
/* 4819 */         members(), 
/* 4820 */         channels());
/*      */   }
/*      */   
/*      */   public ImmutableGuildData withRegionOrNull(@Nullable String value) {
/* 4824 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 4825 */     return new ImmutableGuildData(this, 
/*      */         
/* 4827 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4832 */         owner(), 
/* 4833 */         permissions(), 
/* 4834 */         afkChannelId(), 
/* 4835 */         embedEnabled(), 
/* 4836 */         embedChannelId(), this.features, 
/*      */         
/* 4838 */         applicationId(), 
/* 4839 */         widgetEnabled(), 
/* 4840 */         widgetChannelId(), 
/* 4841 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 4843 */         rulesChannelId(), 
/* 4844 */         maxPresences(), 
/* 4845 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 4849 */         premiumSubscriptionCount(), 
/* 4850 */         publicUpdatesChannelId(), 
/* 4851 */         maxVideoChannelUsers(), 
/* 4852 */         approximateMemberCount(), 
/* 4853 */         approximatePresenceCount(), 
/* 4854 */         welcomeScreen(), 
/* 4855 */         nsfw(), 
/* 4856 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 4859 */         ownerId(), newValue, this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4869 */         unavailable(), this.memberCount, 
/*      */         
/* 4871 */         roles(), 
/* 4872 */         emojis(), 
/* 4873 */         stickers(), 
/* 4874 */         members(), 
/* 4875 */         channels());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildData withAfkTimeout(int value) {
/* 4885 */     if (this.afkTimeout == value) return this; 
/* 4886 */     return new ImmutableGuildData(this, 
/*      */         
/* 4888 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4893 */         owner(), 
/* 4894 */         permissions(), 
/* 4895 */         afkChannelId(), 
/* 4896 */         embedEnabled(), 
/* 4897 */         embedChannelId(), this.features, 
/*      */         
/* 4899 */         applicationId(), 
/* 4900 */         widgetEnabled(), 
/* 4901 */         widgetChannelId(), 
/* 4902 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 4904 */         rulesChannelId(), 
/* 4905 */         maxPresences(), 
/* 4906 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 4910 */         premiumSubscriptionCount(), 
/* 4911 */         publicUpdatesChannelId(), 
/* 4912 */         maxVideoChannelUsers(), 
/* 4913 */         approximateMemberCount(), 
/* 4914 */         approximatePresenceCount(), 
/* 4915 */         welcomeScreen(), 
/* 4916 */         nsfw(), 
/* 4917 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 4920 */         ownerId(), 
/* 4921 */         region(), value, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4930 */         unavailable(), this.memberCount, 
/*      */         
/* 4932 */         roles(), 
/* 4933 */         emojis(), 
/* 4934 */         stickers(), 
/* 4935 */         members(), 
/* 4936 */         channels());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildData withDefaultMessageNotifications(int value) {
/* 4946 */     if (this.defaultMessageNotifications == value) return this; 
/* 4947 */     return new ImmutableGuildData(this, 
/*      */         
/* 4949 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4954 */         owner(), 
/* 4955 */         permissions(), 
/* 4956 */         afkChannelId(), 
/* 4957 */         embedEnabled(), 
/* 4958 */         embedChannelId(), this.features, 
/*      */         
/* 4960 */         applicationId(), 
/* 4961 */         widgetEnabled(), 
/* 4962 */         widgetChannelId(), 
/* 4963 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 4965 */         rulesChannelId(), 
/* 4966 */         maxPresences(), 
/* 4967 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 4971 */         premiumSubscriptionCount(), 
/* 4972 */         publicUpdatesChannelId(), 
/* 4973 */         maxVideoChannelUsers(), 
/* 4974 */         approximateMemberCount(), 
/* 4975 */         approximatePresenceCount(), 
/* 4976 */         welcomeScreen(), 
/* 4977 */         nsfw(), 
/* 4978 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 4981 */         ownerId(), 
/* 4982 */         region(), this.afkTimeout, value, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4991 */         unavailable(), this.memberCount, 
/*      */         
/* 4993 */         roles(), 
/* 4994 */         emojis(), 
/* 4995 */         stickers(), 
/* 4996 */         members(), 
/* 4997 */         channels());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildData withExplicitContentFilter(int value) {
/* 5007 */     if (this.explicitContentFilter == value) return this; 
/* 5008 */     return new ImmutableGuildData(this, 
/*      */         
/* 5010 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5015 */         owner(), 
/* 5016 */         permissions(), 
/* 5017 */         afkChannelId(), 
/* 5018 */         embedEnabled(), 
/* 5019 */         embedChannelId(), this.features, 
/*      */         
/* 5021 */         applicationId(), 
/* 5022 */         widgetEnabled(), 
/* 5023 */         widgetChannelId(), 
/* 5024 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 5026 */         rulesChannelId(), 
/* 5027 */         maxPresences(), 
/* 5028 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 5032 */         premiumSubscriptionCount(), 
/* 5033 */         publicUpdatesChannelId(), 
/* 5034 */         maxVideoChannelUsers(), 
/* 5035 */         approximateMemberCount(), 
/* 5036 */         approximatePresenceCount(), 
/* 5037 */         welcomeScreen(), 
/* 5038 */         nsfw(), 
/* 5039 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 5042 */         ownerId(), 
/* 5043 */         region(), this.afkTimeout, this.defaultMessageNotifications, value, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5052 */         unavailable(), this.memberCount, 
/*      */         
/* 5054 */         roles(), 
/* 5055 */         emojis(), 
/* 5056 */         stickers(), 
/* 5057 */         members(), 
/* 5058 */         channels());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildData withMfaLevel(int value) {
/* 5068 */     if (this.mfaLevel == value) return this; 
/* 5069 */     return new ImmutableGuildData(this, 
/*      */         
/* 5071 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5076 */         owner(), 
/* 5077 */         permissions(), 
/* 5078 */         afkChannelId(), 
/* 5079 */         embedEnabled(), 
/* 5080 */         embedChannelId(), this.features, 
/*      */         
/* 5082 */         applicationId(), 
/* 5083 */         widgetEnabled(), 
/* 5084 */         widgetChannelId(), 
/* 5085 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 5087 */         rulesChannelId(), 
/* 5088 */         maxPresences(), 
/* 5089 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 5093 */         premiumSubscriptionCount(), 
/* 5094 */         publicUpdatesChannelId(), 
/* 5095 */         maxVideoChannelUsers(), 
/* 5096 */         approximateMemberCount(), 
/* 5097 */         approximatePresenceCount(), 
/* 5098 */         welcomeScreen(), 
/* 5099 */         nsfw(), 
/* 5100 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 5103 */         ownerId(), 
/* 5104 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, value, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5113 */         unavailable(), this.memberCount, 
/*      */         
/* 5115 */         roles(), 
/* 5116 */         emojis(), 
/* 5117 */         stickers(), 
/* 5118 */         members(), 
/* 5119 */         channels());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildData withPremiumTier(int value) {
/* 5129 */     if (this.premiumTier == value) return this; 
/* 5130 */     return new ImmutableGuildData(this, 
/*      */         
/* 5132 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5137 */         owner(), 
/* 5138 */         permissions(), 
/* 5139 */         afkChannelId(), 
/* 5140 */         embedEnabled(), 
/* 5141 */         embedChannelId(), this.features, 
/*      */         
/* 5143 */         applicationId(), 
/* 5144 */         widgetEnabled(), 
/* 5145 */         widgetChannelId(), 
/* 5146 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 5148 */         rulesChannelId(), 
/* 5149 */         maxPresences(), 
/* 5150 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 5154 */         premiumSubscriptionCount(), 
/* 5155 */         publicUpdatesChannelId(), 
/* 5156 */         maxVideoChannelUsers(), 
/* 5157 */         approximateMemberCount(), 
/* 5158 */         approximatePresenceCount(), 
/* 5159 */         welcomeScreen(), 
/* 5160 */         nsfw(), 
/* 5161 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 5164 */         ownerId(), 
/* 5165 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, value, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5174 */         unavailable(), this.memberCount, 
/*      */         
/* 5176 */         roles(), 
/* 5177 */         emojis(), 
/* 5178 */         stickers(), 
/* 5179 */         members(), 
/* 5180 */         channels());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildData withPreferredLocale(String value) {
/* 5190 */     String newValue = Objects.<String>requireNonNull(value, "preferredLocale");
/* 5191 */     if (this.preferredLocale.equals(newValue)) return this; 
/* 5192 */     return new ImmutableGuildData(this, 
/*      */         
/* 5194 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5199 */         owner(), 
/* 5200 */         permissions(), 
/* 5201 */         afkChannelId(), 
/* 5202 */         embedEnabled(), 
/* 5203 */         embedChannelId(), this.features, 
/*      */         
/* 5205 */         applicationId(), 
/* 5206 */         widgetEnabled(), 
/* 5207 */         widgetChannelId(), 
/* 5208 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 5210 */         rulesChannelId(), 
/* 5211 */         maxPresences(), 
/* 5212 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 5216 */         premiumSubscriptionCount(), 
/* 5217 */         publicUpdatesChannelId(), 
/* 5218 */         maxVideoChannelUsers(), 
/* 5219 */         approximateMemberCount(), 
/* 5220 */         approximatePresenceCount(), 
/* 5221 */         welcomeScreen(), 
/* 5222 */         nsfw(), 
/* 5223 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 5226 */         ownerId(), 
/* 5227 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, newValue, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5236 */         unavailable(), this.memberCount, 
/*      */         
/* 5238 */         roles(), 
/* 5239 */         emojis(), 
/* 5240 */         stickers(), 
/* 5241 */         members(), 
/* 5242 */         channels());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildData withJoinedAt(String value) {
/* 5252 */     String newValue = Objects.<String>requireNonNull(value, "joinedAt");
/* 5253 */     if (this.joinedAt.equals(newValue)) return this; 
/* 5254 */     return new ImmutableGuildData(this, 
/*      */         
/* 5256 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5261 */         owner(), 
/* 5262 */         permissions(), 
/* 5263 */         afkChannelId(), 
/* 5264 */         embedEnabled(), 
/* 5265 */         embedChannelId(), this.features, 
/*      */         
/* 5267 */         applicationId(), 
/* 5268 */         widgetEnabled(), 
/* 5269 */         widgetChannelId(), 
/* 5270 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 5272 */         rulesChannelId(), 
/* 5273 */         maxPresences(), 
/* 5274 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 5278 */         premiumSubscriptionCount(), 
/* 5279 */         publicUpdatesChannelId(), 
/* 5280 */         maxVideoChannelUsers(), 
/* 5281 */         approximateMemberCount(), 
/* 5282 */         approximatePresenceCount(), 
/* 5283 */         welcomeScreen(), 
/* 5284 */         nsfw(), 
/* 5285 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 5288 */         ownerId(), 
/* 5289 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, newValue, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5298 */         unavailable(), this.memberCount, 
/*      */         
/* 5300 */         roles(), 
/* 5301 */         emojis(), 
/* 5302 */         stickers(), 
/* 5303 */         members(), 
/* 5304 */         channels());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildData withLarge(boolean value) {
/* 5314 */     if (this.large == value) return this; 
/* 5315 */     return new ImmutableGuildData(this, 
/*      */         
/* 5317 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5322 */         owner(), 
/* 5323 */         permissions(), 
/* 5324 */         afkChannelId(), 
/* 5325 */         embedEnabled(), 
/* 5326 */         embedChannelId(), this.features, 
/*      */         
/* 5328 */         applicationId(), 
/* 5329 */         widgetEnabled(), 
/* 5330 */         widgetChannelId(), 
/* 5331 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 5333 */         rulesChannelId(), 
/* 5334 */         maxPresences(), 
/* 5335 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 5339 */         premiumSubscriptionCount(), 
/* 5340 */         publicUpdatesChannelId(), 
/* 5341 */         maxVideoChannelUsers(), 
/* 5342 */         approximateMemberCount(), 
/* 5343 */         approximatePresenceCount(), 
/* 5344 */         welcomeScreen(), 
/* 5345 */         nsfw(), 
/* 5346 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 5349 */         ownerId(), 
/* 5350 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, value, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5359 */         unavailable(), this.memberCount, 
/*      */         
/* 5361 */         roles(), 
/* 5362 */         emojis(), 
/* 5363 */         stickers(), 
/* 5364 */         members(), 
/* 5365 */         channels());
/*      */   }
/*      */   
/*      */   public ImmutableGuildData withUnavailable(Possible<Boolean> value) {
/* 5369 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 5370 */     return new ImmutableGuildData(this, 
/*      */         
/* 5372 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5377 */         owner(), 
/* 5378 */         permissions(), 
/* 5379 */         afkChannelId(), 
/* 5380 */         embedEnabled(), 
/* 5381 */         embedChannelId(), this.features, 
/*      */         
/* 5383 */         applicationId(), 
/* 5384 */         widgetEnabled(), 
/* 5385 */         widgetChannelId(), 
/* 5386 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 5388 */         rulesChannelId(), 
/* 5389 */         maxPresences(), 
/* 5390 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 5394 */         premiumSubscriptionCount(), 
/* 5395 */         publicUpdatesChannelId(), 
/* 5396 */         maxVideoChannelUsers(), 
/* 5397 */         approximateMemberCount(), 
/* 5398 */         approximatePresenceCount(), 
/* 5399 */         welcomeScreen(), 
/* 5400 */         nsfw(), 
/* 5401 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 5404 */         ownerId(), 
/* 5405 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, newValue, this.memberCount, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5416 */         roles(), 
/* 5417 */         emojis(), 
/* 5418 */         stickers(), 
/* 5419 */         members(), 
/* 5420 */         channels());
/*      */   }
/*      */   
/*      */   public ImmutableGuildData withUnavailable(Boolean value) {
/* 5424 */     Possible<Boolean> newValue = Possible.of(value);
/* 5425 */     return new ImmutableGuildData(this, 
/*      */         
/* 5427 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5432 */         owner(), 
/* 5433 */         permissions(), 
/* 5434 */         afkChannelId(), 
/* 5435 */         embedEnabled(), 
/* 5436 */         embedChannelId(), this.features, 
/*      */         
/* 5438 */         applicationId(), 
/* 5439 */         widgetEnabled(), 
/* 5440 */         widgetChannelId(), 
/* 5441 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 5443 */         rulesChannelId(), 
/* 5444 */         maxPresences(), 
/* 5445 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 5449 */         premiumSubscriptionCount(), 
/* 5450 */         publicUpdatesChannelId(), 
/* 5451 */         maxVideoChannelUsers(), 
/* 5452 */         approximateMemberCount(), 
/* 5453 */         approximatePresenceCount(), 
/* 5454 */         welcomeScreen(), 
/* 5455 */         nsfw(), 
/* 5456 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 5459 */         ownerId(), 
/* 5460 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, newValue, this.memberCount, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5471 */         roles(), 
/* 5472 */         emojis(), 
/* 5473 */         stickers(), 
/* 5474 */         members(), 
/* 5475 */         channels());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildData withMemberCount(int value) {
/* 5485 */     if (this.memberCount == value) return this; 
/* 5486 */     return new ImmutableGuildData(this, 
/*      */         
/* 5488 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5493 */         owner(), 
/* 5494 */         permissions(), 
/* 5495 */         afkChannelId(), 
/* 5496 */         embedEnabled(), 
/* 5497 */         embedChannelId(), this.features, 
/*      */         
/* 5499 */         applicationId(), 
/* 5500 */         widgetEnabled(), 
/* 5501 */         widgetChannelId(), 
/* 5502 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 5504 */         rulesChannelId(), 
/* 5505 */         maxPresences(), 
/* 5506 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 5510 */         premiumSubscriptionCount(), 
/* 5511 */         publicUpdatesChannelId(), 
/* 5512 */         maxVideoChannelUsers(), 
/* 5513 */         approximateMemberCount(), 
/* 5514 */         approximatePresenceCount(), 
/* 5515 */         welcomeScreen(), 
/* 5516 */         nsfw(), 
/* 5517 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 5520 */         ownerId(), 
/* 5521 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5530 */         unavailable(), value, 
/*      */         
/* 5532 */         roles(), 
/* 5533 */         emojis(), 
/* 5534 */         stickers(), 
/* 5535 */         members(), 
/* 5536 */         channels());
/*      */   }
/*      */   
/*      */   public ImmutableGuildData withRoles(List<Id> value) {
/* 5540 */     List<Id> newValue = value;
/* 5541 */     return new ImmutableGuildData(this, 
/*      */         
/* 5543 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5548 */         owner(), 
/* 5549 */         permissions(), 
/* 5550 */         afkChannelId(), 
/* 5551 */         embedEnabled(), 
/* 5552 */         embedChannelId(), this.features, 
/*      */         
/* 5554 */         applicationId(), 
/* 5555 */         widgetEnabled(), 
/* 5556 */         widgetChannelId(), 
/* 5557 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 5559 */         rulesChannelId(), 
/* 5560 */         maxPresences(), 
/* 5561 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 5565 */         premiumSubscriptionCount(), 
/* 5566 */         publicUpdatesChannelId(), 
/* 5567 */         maxVideoChannelUsers(), 
/* 5568 */         approximateMemberCount(), 
/* 5569 */         approximatePresenceCount(), 
/* 5570 */         welcomeScreen(), 
/* 5571 */         nsfw(), 
/* 5572 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 5575 */         ownerId(), 
/* 5576 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5585 */         unavailable(), this.memberCount, newValue, 
/*      */ 
/*      */         
/* 5588 */         emojis(), 
/* 5589 */         stickers(), 
/* 5590 */         members(), 
/* 5591 */         channels());
/*      */   }
/*      */   
/*      */   public ImmutableGuildData withEmojis(List<Id> value) {
/* 5595 */     List<Id> newValue = value;
/* 5596 */     return new ImmutableGuildData(this, 
/*      */         
/* 5598 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5603 */         owner(), 
/* 5604 */         permissions(), 
/* 5605 */         afkChannelId(), 
/* 5606 */         embedEnabled(), 
/* 5607 */         embedChannelId(), this.features, 
/*      */         
/* 5609 */         applicationId(), 
/* 5610 */         widgetEnabled(), 
/* 5611 */         widgetChannelId(), 
/* 5612 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 5614 */         rulesChannelId(), 
/* 5615 */         maxPresences(), 
/* 5616 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 5620 */         premiumSubscriptionCount(), 
/* 5621 */         publicUpdatesChannelId(), 
/* 5622 */         maxVideoChannelUsers(), 
/* 5623 */         approximateMemberCount(), 
/* 5624 */         approximatePresenceCount(), 
/* 5625 */         welcomeScreen(), 
/* 5626 */         nsfw(), 
/* 5627 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 5630 */         ownerId(), 
/* 5631 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5640 */         unavailable(), this.memberCount, 
/*      */         
/* 5642 */         roles(), newValue, 
/*      */         
/* 5644 */         stickers(), 
/* 5645 */         members(), 
/* 5646 */         channels());
/*      */   }
/*      */   
/*      */   public ImmutableGuildData withStickers(Possible<List<Id>> possible) {
/* 5650 */     Possible<List<Id>> newValue = Objects.<Possible<List<Id>>>requireNonNull(possible);
/* 5651 */     return new ImmutableGuildData(this, 
/*      */         
/* 5653 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5658 */         owner(), 
/* 5659 */         permissions(), 
/* 5660 */         afkChannelId(), 
/* 5661 */         embedEnabled(), 
/* 5662 */         embedChannelId(), this.features, 
/*      */         
/* 5664 */         applicationId(), 
/* 5665 */         widgetEnabled(), 
/* 5666 */         widgetChannelId(), 
/* 5667 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 5669 */         rulesChannelId(), 
/* 5670 */         maxPresences(), 
/* 5671 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 5675 */         premiumSubscriptionCount(), 
/* 5676 */         publicUpdatesChannelId(), 
/* 5677 */         maxVideoChannelUsers(), 
/* 5678 */         approximateMemberCount(), 
/* 5679 */         approximatePresenceCount(), 
/* 5680 */         welcomeScreen(), 
/* 5681 */         nsfw(), 
/* 5682 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 5685 */         ownerId(), 
/* 5686 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5695 */         unavailable(), this.memberCount, 
/*      */         
/* 5697 */         roles(), 
/* 5698 */         emojis(), newValue, 
/*      */         
/* 5700 */         members(), 
/* 5701 */         channels());
/*      */   }
/*      */   
/*      */   public ImmutableGuildData withStickers(Iterable<Id> elements) {
/* 5705 */     Possible<List<Id>> newValue = Possible.of(
/* 5706 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/* 5707 */     return new ImmutableGuildData(this, 
/*      */         
/* 5709 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5714 */         owner(), 
/* 5715 */         permissions(), 
/* 5716 */         afkChannelId(), 
/* 5717 */         embedEnabled(), 
/* 5718 */         embedChannelId(), this.features, 
/*      */         
/* 5720 */         applicationId(), 
/* 5721 */         widgetEnabled(), 
/* 5722 */         widgetChannelId(), 
/* 5723 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 5725 */         rulesChannelId(), 
/* 5726 */         maxPresences(), 
/* 5727 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 5731 */         premiumSubscriptionCount(), 
/* 5732 */         publicUpdatesChannelId(), 
/* 5733 */         maxVideoChannelUsers(), 
/* 5734 */         approximateMemberCount(), 
/* 5735 */         approximatePresenceCount(), 
/* 5736 */         welcomeScreen(), 
/* 5737 */         nsfw(), 
/* 5738 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 5741 */         ownerId(), 
/* 5742 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5751 */         unavailable(), this.memberCount, 
/*      */         
/* 5753 */         roles(), 
/* 5754 */         emojis(), newValue, 
/*      */         
/* 5756 */         members(), 
/* 5757 */         channels());
/*      */   }
/*      */   
/*      */   @SafeVarargs
/*      */   public final ImmutableGuildData withStickers(Id... elements) {
/* 5762 */     Possible<List<Id>> newValue = Possible.of(Arrays.asList(elements));
/* 5763 */     return new ImmutableGuildData(this, 
/*      */         
/* 5765 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5770 */         owner(), 
/* 5771 */         permissions(), 
/* 5772 */         afkChannelId(), 
/* 5773 */         embedEnabled(), 
/* 5774 */         embedChannelId(), this.features, 
/*      */         
/* 5776 */         applicationId(), 
/* 5777 */         widgetEnabled(), 
/* 5778 */         widgetChannelId(), 
/* 5779 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 5781 */         rulesChannelId(), 
/* 5782 */         maxPresences(), 
/* 5783 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 5787 */         premiumSubscriptionCount(), 
/* 5788 */         publicUpdatesChannelId(), 
/* 5789 */         maxVideoChannelUsers(), 
/* 5790 */         approximateMemberCount(), 
/* 5791 */         approximatePresenceCount(), 
/* 5792 */         welcomeScreen(), 
/* 5793 */         nsfw(), 
/* 5794 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 5797 */         ownerId(), 
/* 5798 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5807 */         unavailable(), this.memberCount, 
/*      */         
/* 5809 */         roles(), 
/* 5810 */         emojis(), newValue, 
/*      */         
/* 5812 */         members(), 
/* 5813 */         channels());
/*      */   }
/*      */   
/*      */   public ImmutableGuildData withMembers(List<Id> value) {
/* 5817 */     List<Id> newValue = value;
/* 5818 */     return new ImmutableGuildData(this, 
/*      */         
/* 5820 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5825 */         owner(), 
/* 5826 */         permissions(), 
/* 5827 */         afkChannelId(), 
/* 5828 */         embedEnabled(), 
/* 5829 */         embedChannelId(), this.features, 
/*      */         
/* 5831 */         applicationId(), 
/* 5832 */         widgetEnabled(), 
/* 5833 */         widgetChannelId(), 
/* 5834 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 5836 */         rulesChannelId(), 
/* 5837 */         maxPresences(), 
/* 5838 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 5842 */         premiumSubscriptionCount(), 
/* 5843 */         publicUpdatesChannelId(), 
/* 5844 */         maxVideoChannelUsers(), 
/* 5845 */         approximateMemberCount(), 
/* 5846 */         approximatePresenceCount(), 
/* 5847 */         welcomeScreen(), 
/* 5848 */         nsfw(), 
/* 5849 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 5852 */         ownerId(), 
/* 5853 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5862 */         unavailable(), this.memberCount, 
/*      */         
/* 5864 */         roles(), 
/* 5865 */         emojis(), 
/* 5866 */         stickers(), newValue, 
/*      */         
/* 5868 */         channels());
/*      */   }
/*      */   
/*      */   public ImmutableGuildData withChannels(List<Id> value) {
/* 5872 */     List<Id> newValue = value;
/* 5873 */     return new ImmutableGuildData(this, 
/*      */         
/* 5875 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5880 */         owner(), 
/* 5881 */         permissions(), 
/* 5882 */         afkChannelId(), 
/* 5883 */         embedEnabled(), 
/* 5884 */         embedChannelId(), this.features, 
/*      */         
/* 5886 */         applicationId(), 
/* 5887 */         widgetEnabled(), 
/* 5888 */         widgetChannelId(), 
/* 5889 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 5891 */         rulesChannelId(), 
/* 5892 */         maxPresences(), 
/* 5893 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 5897 */         premiumSubscriptionCount(), 
/* 5898 */         publicUpdatesChannelId(), 
/* 5899 */         maxVideoChannelUsers(), 
/* 5900 */         approximateMemberCount(), 
/* 5901 */         approximatePresenceCount(), 
/* 5902 */         welcomeScreen(), 
/* 5903 */         nsfw(), 
/* 5904 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 5907 */         ownerId(), 
/* 5908 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5917 */         unavailable(), this.memberCount, 
/*      */         
/* 5919 */         roles(), 
/* 5920 */         emojis(), 
/* 5921 */         stickers(), 
/* 5922 */         members(), newValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object another) {
/* 5932 */     if (this == another) return true; 
/* 5933 */     return (another instanceof ImmutableGuildData && 
/* 5934 */       equalTo(0, (ImmutableGuildData)another));
/*      */   }
/*      */   
/*      */   private boolean equalTo(int synthetic, ImmutableGuildData another) {
/* 5938 */     return (Objects.equals(Long.valueOf(this.id_value), Long.valueOf(another.id_value)) && this.name
/* 5939 */       .equals(another.name) && 
/* 5940 */       Objects.equals(this.icon, another.icon) && 
/* 5941 */       Objects.equals(this.splash, another.splash) && 
/* 5942 */       Objects.equals(this.discoverySplash, another.discoverySplash) && 
/* 5943 */       owner().equals(another.owner()) && 
/* 5944 */       permissions().equals(another.permissions()) && 
/* 5945 */       afkChannelId().equals(another.afkChannelId()) && 
/* 5946 */       embedEnabled().equals(another.embedEnabled()) && 
/* 5947 */       embedChannelId().equals(another.embedChannelId()) && this.features
/* 5948 */       .equals(another.features) && 
/* 5949 */       applicationId().equals(another.applicationId()) && 
/* 5950 */       widgetEnabled().equals(another.widgetEnabled()) && 
/* 5951 */       widgetChannelId().equals(another.widgetChannelId()) && 
/* 5952 */       systemChannelId().equals(another.systemChannelId()) && 
/* 5953 */       Objects.equals(this.systemChannelFlags, another.systemChannelFlags) && 
/* 5954 */       rulesChannelId().equals(another.rulesChannelId()) && 
/* 5955 */       maxPresences().equals(another.maxPresences()) && 
/* 5956 */       maxMembers().equals(another.maxMembers()) && 
/* 5957 */       Objects.equals(this.vanityUrlCode, another.vanityUrlCode) && 
/* 5958 */       Objects.equals(this.description, another.description) && 
/* 5959 */       Objects.equals(this.banner, another.banner) && 
/* 5960 */       premiumSubscriptionCount().equals(another.premiumSubscriptionCount()) && 
/* 5961 */       publicUpdatesChannelId().equals(another.publicUpdatesChannelId()) && 
/* 5962 */       maxVideoChannelUsers().equals(another.maxVideoChannelUsers()) && 
/* 5963 */       approximateMemberCount().equals(another.approximateMemberCount()) && 
/* 5964 */       approximatePresenceCount().equals(another.approximatePresenceCount()) && 
/* 5965 */       welcomeScreen().equals(another.welcomeScreen()) && 
/* 5966 */       nsfw().equals(another.nsfw()) && 
/* 5967 */       safetyAlertsChannelId().equals(another.safetyAlertsChannelId()) && this.verificationLevel == another.verificationLevel && this.nsfwLevel == another.nsfwLevel && 
/*      */ 
/*      */       
/* 5970 */       Objects.equals(Long.valueOf(this.ownerId_value), Long.valueOf(another.ownerId_value)) && 
/* 5971 */       region().equals(another.region()) && this.afkTimeout == another.afkTimeout && this.defaultMessageNotifications == another.defaultMessageNotifications && this.explicitContentFilter == another.explicitContentFilter && this.mfaLevel == another.mfaLevel && this.premiumTier == another.premiumTier && this.preferredLocale
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 5977 */       .equals(another.preferredLocale) && this.joinedAt
/* 5978 */       .equals(another.joinedAt) && this.large == another.large && 
/*      */       
/* 5980 */       unavailable().equals(another.unavailable()) && this.memberCount == another.memberCount && 
/*      */       
/* 5982 */       Objects.equals(this.roles_value, another.roles_value) && 
/* 5983 */       Objects.equals(this.emojis_value, another.emojis_value) && 
/* 5984 */       Objects.equals(this.stickers_value, another.stickers_value) && 
/* 5985 */       Objects.equals(this.members_value, another.members_value) && 
/* 5986 */       Objects.equals(this.channels_value, another.channels_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/* 5995 */     int h = 5381;
/* 5996 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.id_value));
/* 5997 */     h += (h << 5) + this.name.hashCode();
/* 5998 */     h += (h << 5) + Objects.hashCode(this.icon);
/* 5999 */     h += (h << 5) + Objects.hashCode(this.splash);
/* 6000 */     h += (h << 5) + Objects.hashCode(this.discoverySplash);
/* 6001 */     h += (h << 5) + owner().hashCode();
/* 6002 */     h += (h << 5) + permissions().hashCode();
/* 6003 */     h += (h << 5) + afkChannelId().hashCode();
/* 6004 */     h += (h << 5) + embedEnabled().hashCode();
/* 6005 */     h += (h << 5) + embedChannelId().hashCode();
/* 6006 */     h += (h << 5) + this.features.hashCode();
/* 6007 */     h += (h << 5) + applicationId().hashCode();
/* 6008 */     h += (h << 5) + widgetEnabled().hashCode();
/* 6009 */     h += (h << 5) + widgetChannelId().hashCode();
/* 6010 */     h += (h << 5) + systemChannelId().hashCode();
/* 6011 */     h += (h << 5) + Objects.hashCode(this.systemChannelFlags);
/* 6012 */     h += (h << 5) + rulesChannelId().hashCode();
/* 6013 */     h += (h << 5) + maxPresences().hashCode();
/* 6014 */     h += (h << 5) + maxMembers().hashCode();
/* 6015 */     h += (h << 5) + Objects.hashCode(this.vanityUrlCode);
/* 6016 */     h += (h << 5) + Objects.hashCode(this.description);
/* 6017 */     h += (h << 5) + Objects.hashCode(this.banner);
/* 6018 */     h += (h << 5) + premiumSubscriptionCount().hashCode();
/* 6019 */     h += (h << 5) + publicUpdatesChannelId().hashCode();
/* 6020 */     h += (h << 5) + maxVideoChannelUsers().hashCode();
/* 6021 */     h += (h << 5) + approximateMemberCount().hashCode();
/* 6022 */     h += (h << 5) + approximatePresenceCount().hashCode();
/* 6023 */     h += (h << 5) + welcomeScreen().hashCode();
/* 6024 */     h += (h << 5) + nsfw().hashCode();
/* 6025 */     h += (h << 5) + safetyAlertsChannelId().hashCode();
/* 6026 */     h += (h << 5) + this.verificationLevel;
/* 6027 */     h += (h << 5) + this.nsfwLevel;
/* 6028 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.ownerId_value));
/* 6029 */     h += (h << 5) + region().hashCode();
/* 6030 */     h += (h << 5) + this.afkTimeout;
/* 6031 */     h += (h << 5) + this.defaultMessageNotifications;
/* 6032 */     h += (h << 5) + this.explicitContentFilter;
/* 6033 */     h += (h << 5) + this.mfaLevel;
/* 6034 */     h += (h << 5) + this.premiumTier;
/* 6035 */     h += (h << 5) + this.preferredLocale.hashCode();
/* 6036 */     h += (h << 5) + this.joinedAt.hashCode();
/* 6037 */     h += (h << 5) + Boolean.hashCode(this.large);
/* 6038 */     h += (h << 5) + unavailable().hashCode();
/* 6039 */     h += (h << 5) + this.memberCount;
/* 6040 */     h += (h << 5) + Objects.hashCode(this.roles_value);
/* 6041 */     h += (h << 5) + Objects.hashCode(this.emojis_value);
/* 6042 */     h += (h << 5) + Objects.hashCode(this.stickers_value);
/* 6043 */     h += (h << 5) + Objects.hashCode(this.members_value);
/* 6044 */     h += (h << 5) + Objects.hashCode(this.channels_value);
/* 6045 */     return h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/* 6054 */     StringBuilder builder = new StringBuilder("GuildData{");
/* 6055 */     builder.append("id=").append(Objects.toString(Long.valueOf(this.id_value)));
/* 6056 */     builder.append(", ");
/* 6057 */     builder.append("name=").append(this.name);
/* 6058 */     if (this.icon != null) {
/* 6059 */       builder.append(", ");
/* 6060 */       builder.append("icon=").append(this.icon);
/*      */     } 
/* 6062 */     if (this.splash != null) {
/* 6063 */       builder.append(", ");
/* 6064 */       builder.append("splash=").append(this.splash);
/*      */     } 
/* 6066 */     if (this.discoverySplash != null) {
/* 6067 */       builder.append(", ");
/* 6068 */       builder.append("discoverySplash=").append(this.discoverySplash);
/*      */     } 
/* 6070 */     builder.append(", ");
/* 6071 */     builder.append("owner=").append(owner().toString());
/* 6072 */     builder.append(", ");
/* 6073 */     builder.append("permissions=").append(permissions().toString());
/* 6074 */     builder.append(", ");
/* 6075 */     builder.append("afkChannelId=").append(afkChannelId().toString());
/* 6076 */     builder.append(", ");
/* 6077 */     builder.append("embedEnabled=").append(embedEnabled().toString());
/* 6078 */     builder.append(", ");
/* 6079 */     builder.append("embedChannelId=").append(embedChannelId().toString());
/* 6080 */     builder.append(", ");
/* 6081 */     builder.append("features=").append(this.features);
/* 6082 */     builder.append(", ");
/* 6083 */     builder.append("applicationId=").append(applicationId().toString());
/* 6084 */     builder.append(", ");
/* 6085 */     builder.append("widgetEnabled=").append(widgetEnabled().toString());
/* 6086 */     builder.append(", ");
/* 6087 */     builder.append("widgetChannelId=").append(widgetChannelId().toString());
/* 6088 */     builder.append(", ");
/* 6089 */     builder.append("systemChannelId=").append(systemChannelId().toString());
/* 6090 */     if (this.systemChannelFlags != null) {
/* 6091 */       builder.append(", ");
/* 6092 */       builder.append("systemChannelFlags=").append(this.systemChannelFlags);
/*      */     } 
/* 6094 */     builder.append(", ");
/* 6095 */     builder.append("rulesChannelId=").append(rulesChannelId().toString());
/* 6096 */     builder.append(", ");
/* 6097 */     builder.append("maxPresences=").append(maxPresences().toString());
/* 6098 */     builder.append(", ");
/* 6099 */     builder.append("maxMembers=").append(maxMembers().toString());
/* 6100 */     if (this.vanityUrlCode != null) {
/* 6101 */       builder.append(", ");
/* 6102 */       builder.append("vanityUrlCode=").append(this.vanityUrlCode);
/*      */     } 
/* 6104 */     if (this.description != null) {
/* 6105 */       builder.append(", ");
/* 6106 */       builder.append("description=").append(this.description);
/*      */     } 
/* 6108 */     if (this.banner != null) {
/* 6109 */       builder.append(", ");
/* 6110 */       builder.append("banner=").append(this.banner);
/*      */     } 
/* 6112 */     builder.append(", ");
/* 6113 */     builder.append("premiumSubscriptionCount=").append(premiumSubscriptionCount().toString());
/* 6114 */     builder.append(", ");
/* 6115 */     builder.append("publicUpdatesChannelId=").append(publicUpdatesChannelId().toString());
/* 6116 */     builder.append(", ");
/* 6117 */     builder.append("maxVideoChannelUsers=").append(maxVideoChannelUsers().toString());
/* 6118 */     builder.append(", ");
/* 6119 */     builder.append("approximateMemberCount=").append(approximateMemberCount().toString());
/* 6120 */     builder.append(", ");
/* 6121 */     builder.append("approximatePresenceCount=").append(approximatePresenceCount().toString());
/* 6122 */     builder.append(", ");
/* 6123 */     builder.append("welcomeScreen=").append(welcomeScreen().toString());
/* 6124 */     builder.append(", ");
/* 6125 */     builder.append("nsfw=").append(nsfw().toString());
/* 6126 */     builder.append(", ");
/* 6127 */     builder.append("safetyAlertsChannelId=").append(safetyAlertsChannelId().toString());
/* 6128 */     builder.append(", ");
/* 6129 */     builder.append("verificationLevel=").append(this.verificationLevel);
/* 6130 */     builder.append(", ");
/* 6131 */     builder.append("nsfwLevel=").append(this.nsfwLevel);
/* 6132 */     builder.append(", ");
/* 6133 */     builder.append("ownerId=").append(Objects.toString(Long.valueOf(this.ownerId_value)));
/* 6134 */     builder.append(", ");
/* 6135 */     builder.append("region=").append(region().toString());
/* 6136 */     builder.append(", ");
/* 6137 */     builder.append("afkTimeout=").append(this.afkTimeout);
/* 6138 */     builder.append(", ");
/* 6139 */     builder.append("defaultMessageNotifications=").append(this.defaultMessageNotifications);
/* 6140 */     builder.append(", ");
/* 6141 */     builder.append("explicitContentFilter=").append(this.explicitContentFilter);
/* 6142 */     builder.append(", ");
/* 6143 */     builder.append("mfaLevel=").append(this.mfaLevel);
/* 6144 */     builder.append(", ");
/* 6145 */     builder.append("premiumTier=").append(this.premiumTier);
/* 6146 */     builder.append(", ");
/* 6147 */     builder.append("preferredLocale=").append(this.preferredLocale);
/* 6148 */     builder.append(", ");
/* 6149 */     builder.append("joinedAt=").append(this.joinedAt);
/* 6150 */     builder.append(", ");
/* 6151 */     builder.append("large=").append(this.large);
/* 6152 */     builder.append(", ");
/* 6153 */     builder.append("unavailable=").append(unavailable().toString());
/* 6154 */     builder.append(", ");
/* 6155 */     builder.append("memberCount=").append(this.memberCount);
/* 6156 */     builder.append(", ");
/* 6157 */     builder.append("roles=").append(Objects.toString(this.roles_value));
/* 6158 */     builder.append(", ");
/* 6159 */     builder.append("emojis=").append(Objects.toString(this.emojis_value));
/* 6160 */     builder.append(", ");
/* 6161 */     builder.append("stickers=").append(Objects.toString(this.stickers_value));
/* 6162 */     builder.append(", ");
/* 6163 */     builder.append("members=").append(Objects.toString(this.members_value));
/* 6164 */     builder.append(", ");
/* 6165 */     builder.append("channels=").append(Objects.toString(this.channels_value));
/* 6166 */     return builder.append("}").toString();
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonDeserialize
/*      */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*      */   @Generated(from = "GuildData", generator = "Immutables")
/*      */   static final class Json
/*      */     implements GuildData
/*      */   {
/*      */     Id id;
/*      */     
/*      */     String name;
/* 6180 */     Optional<String> icon = Optional.empty();
/* 6181 */     Optional<String> splash = Optional.empty();
/* 6182 */     Optional<String> discoverySplash = Optional.empty();
/*      */     
/* 6184 */     Possible<Boolean> owner = Possible.absent();
/*      */ 
/*      */     
/* 6187 */     Possible<Long> permissions = Possible.absent();
/*      */ 
/*      */     
/* 6190 */     Optional<Id> afkChannelId = Optional.empty();
/*      */ 
/*      */     
/* 6193 */     Possible<Boolean> embedEnabled = Possible.absent();
/*      */ 
/*      */     
/* 6196 */     Possible<Optional<Id>> embedChannelId = Possible.absent();
/*      */     
/* 6198 */     List<String> features = Collections.emptyList();
/*      */     
/* 6200 */     Optional<Id> applicationId = Optional.empty();
/*      */ 
/*      */     
/* 6203 */     Possible<Boolean> widgetEnabled = Possible.absent();
/*      */ 
/*      */     
/* 6206 */     Possible<Optional<Id>> widgetChannelId = Possible.absent();
/*      */ 
/*      */     
/* 6209 */     Optional<Id> systemChannelId = Optional.empty();
/*      */     
/* 6211 */     OptionalInt systemChannelFlags = OptionalInt.empty();
/*      */     
/* 6213 */     Optional<Id> rulesChannelId = Optional.empty();
/*      */ 
/*      */     
/* 6216 */     Possible<Optional<Integer>> maxPresences = Possible.absent();
/*      */ 
/*      */     
/* 6219 */     Possible<Integer> maxMembers = Possible.absent();
/*      */     
/* 6221 */     Optional<String> vanityUrlCode = Optional.empty();
/* 6222 */     Optional<String> description = Optional.empty();
/* 6223 */     Optional<String> banner = Optional.empty();
/*      */     
/* 6225 */     Possible<Integer> premiumSubscriptionCount = Possible.absent();
/*      */ 
/*      */     
/* 6228 */     Optional<Id> publicUpdatesChannelId = Optional.empty();
/*      */ 
/*      */     
/* 6231 */     Possible<Integer> maxVideoChannelUsers = Possible.absent();
/*      */ 
/*      */     
/* 6234 */     Possible<Integer> approximateMemberCount = Possible.absent();
/*      */ 
/*      */     
/* 6237 */     Possible<Integer> approximatePresenceCount = Possible.absent();
/*      */ 
/*      */     
/* 6240 */     Possible<WelcomeScreenData> welcomeScreen = Possible.absent();
/*      */ 
/*      */     
/* 6243 */     Possible<Boolean> nsfw = Possible.absent();
/*      */ 
/*      */     
/* 6246 */     Optional<Id> safetyAlertsChannelId = Optional.empty();
/*      */     
/*      */     int verificationLevel;
/*      */     
/*      */     boolean verificationLevelIsSet;
/*      */     int nsfwLevel;
/*      */     boolean nsfwLevelIsSet;
/*      */     Id ownerId;
/* 6254 */     Possible<Optional<String>> region = Possible.absent();
/*      */     
/*      */     int afkTimeout;
/*      */     
/*      */     boolean afkTimeoutIsSet;
/*      */     int defaultMessageNotifications;
/*      */     boolean defaultMessageNotificationsIsSet;
/*      */     int explicitContentFilter;
/*      */     boolean explicitContentFilterIsSet;
/*      */     int mfaLevel;
/*      */     boolean mfaLevelIsSet;
/*      */     int premiumTier;
/*      */     boolean premiumTierIsSet;
/*      */     String preferredLocale;
/*      */     String joinedAt;
/*      */     boolean large;
/*      */     boolean largeIsSet;
/* 6271 */     Possible<Boolean> unavailable = Possible.absent();
/*      */     
/*      */     int memberCount;
/*      */     
/*      */     boolean memberCountIsSet;
/*      */     List<Id> roles;
/*      */     List<Id> emojis;
/* 6278 */     Possible<List<Id>> stickers = Possible.absent();
/*      */     List<Id> members;
/*      */     List<Id> channels;
/*      */     
/*      */     @JsonProperty("id")
/*      */     public void setId(Id id) {
/* 6284 */       this.id = id;
/*      */     }
/*      */     @JsonProperty("name")
/*      */     public void setName(String name) {
/* 6288 */       this.name = name;
/*      */     }
/*      */     @JsonProperty("icon")
/*      */     public void setIcon(Optional<String> icon) {
/* 6292 */       this.icon = icon;
/*      */     }
/*      */     @JsonProperty("splash")
/*      */     public void setSplash(Optional<String> splash) {
/* 6296 */       this.splash = splash;
/*      */     }
/*      */     @JsonProperty("discovery_splash")
/*      */     public void setDiscoverySplash(Optional<String> discoverySplash) {
/* 6300 */       this.discoverySplash = discoverySplash;
/*      */     }
/*      */     @JsonProperty("owner")
/*      */     public void setOwner(Possible<Boolean> owner) {
/* 6304 */       this.owner = owner;
/*      */     }
/*      */     @JsonProperty("permissions")
/*      */     public void setPermissions(Possible<Long> permissions) {
/* 6308 */       this.permissions = permissions;
/*      */     }
/*      */     @JsonProperty("afk_channel_id")
/*      */     public void setAfkChannelId(Optional<Id> afkChannelId) {
/* 6312 */       this.afkChannelId = afkChannelId;
/*      */     }
/*      */     @JsonProperty("embed_enabled")
/*      */     public void setEmbedEnabled(Possible<Boolean> embedEnabled) {
/* 6316 */       this.embedEnabled = embedEnabled;
/*      */     }
/*      */     @JsonProperty("embed_channel_id")
/*      */     public void setEmbedChannelId(Possible<Optional<Id>> embedChannelId) {
/* 6320 */       this.embedChannelId = embedChannelId;
/*      */     }
/*      */     @JsonProperty("features")
/*      */     public void setFeatures(List<String> features) {
/* 6324 */       this.features = features;
/*      */     }
/*      */     @JsonProperty("application_id")
/*      */     public void setApplicationId(Optional<Id> applicationId) {
/* 6328 */       this.applicationId = applicationId;
/*      */     }
/*      */     @JsonProperty("widget_enabled")
/*      */     public void setWidgetEnabled(Possible<Boolean> widgetEnabled) {
/* 6332 */       this.widgetEnabled = widgetEnabled;
/*      */     }
/*      */     @JsonProperty("widget_channel_id")
/*      */     public void setWidgetChannelId(Possible<Optional<Id>> widgetChannelId) {
/* 6336 */       this.widgetChannelId = widgetChannelId;
/*      */     }
/*      */     @JsonProperty("system_channel_id")
/*      */     public void setSystemChannelId(Optional<Id> systemChannelId) {
/* 6340 */       this.systemChannelId = systemChannelId;
/*      */     }
/*      */     @JsonProperty("system_channel_flags")
/*      */     public void setSystemChannelFlags(OptionalInt systemChannelFlags) {
/* 6344 */       this.systemChannelFlags = systemChannelFlags;
/*      */     }
/*      */     @JsonProperty("rules_channel_id")
/*      */     public void setRulesChannelId(Optional<Id> rulesChannelId) {
/* 6348 */       this.rulesChannelId = rulesChannelId;
/*      */     }
/*      */     @JsonProperty("max_presences")
/*      */     public void setMaxPresences(Possible<Optional<Integer>> maxPresences) {
/* 6352 */       this.maxPresences = maxPresences;
/*      */     }
/*      */     @JsonProperty("max_members")
/*      */     public void setMaxMembers(Possible<Integer> maxMembers) {
/* 6356 */       this.maxMembers = maxMembers;
/*      */     }
/*      */     @JsonProperty("vanity_url_code")
/*      */     public void setVanityUrlCode(Optional<String> vanityUrlCode) {
/* 6360 */       this.vanityUrlCode = vanityUrlCode;
/*      */     }
/*      */     @JsonProperty("description")
/*      */     public void setDescription(Optional<String> description) {
/* 6364 */       this.description = description;
/*      */     }
/*      */     @JsonProperty("banner")
/*      */     public void setBanner(Optional<String> banner) {
/* 6368 */       this.banner = banner;
/*      */     }
/*      */     @JsonProperty("premium_subscription_count")
/*      */     public void setPremiumSubscriptionCount(Possible<Integer> premiumSubscriptionCount) {
/* 6372 */       this.premiumSubscriptionCount = premiumSubscriptionCount;
/*      */     }
/*      */     @JsonProperty("public_updates_channel_id")
/*      */     public void setPublicUpdatesChannelId(Optional<Id> publicUpdatesChannelId) {
/* 6376 */       this.publicUpdatesChannelId = publicUpdatesChannelId;
/*      */     }
/*      */     @JsonProperty("max_video_channel_users")
/*      */     public void setMaxVideoChannelUsers(Possible<Integer> maxVideoChannelUsers) {
/* 6380 */       this.maxVideoChannelUsers = maxVideoChannelUsers;
/*      */     }
/*      */     @JsonProperty("approximate_member_count")
/*      */     public void setApproximateMemberCount(Possible<Integer> approximateMemberCount) {
/* 6384 */       this.approximateMemberCount = approximateMemberCount;
/*      */     }
/*      */     @JsonProperty("approximate_presence_count")
/*      */     public void setApproximatePresenceCount(Possible<Integer> approximatePresenceCount) {
/* 6388 */       this.approximatePresenceCount = approximatePresenceCount;
/*      */     }
/*      */     @JsonProperty("welcome_screen")
/*      */     public void setWelcomeScreen(Possible<WelcomeScreenData> welcomeScreen) {
/* 6392 */       this.welcomeScreen = welcomeScreen;
/*      */     }
/*      */     @JsonProperty("nsfw")
/*      */     public void setNsfw(Possible<Boolean> nsfw) {
/* 6396 */       this.nsfw = nsfw;
/*      */     }
/*      */     @JsonProperty("safety_alerts_channel_id")
/*      */     public void setSafetyAlertsChannelId(Optional<Id> safetyAlertsChannelId) {
/* 6400 */       this.safetyAlertsChannelId = safetyAlertsChannelId;
/*      */     }
/*      */     @JsonProperty("verification_level")
/*      */     public void setVerificationLevel(int verificationLevel) {
/* 6404 */       this.verificationLevel = verificationLevel;
/* 6405 */       this.verificationLevelIsSet = true;
/*      */     }
/*      */     @JsonProperty("nsfw_level")
/*      */     public void setNsfwLevel(int nsfwLevel) {
/* 6409 */       this.nsfwLevel = nsfwLevel;
/* 6410 */       this.nsfwLevelIsSet = true;
/*      */     }
/*      */     @JsonProperty("owner_id")
/*      */     public void setOwnerId(Id ownerId) {
/* 6414 */       this.ownerId = ownerId;
/*      */     }
/*      */     @JsonProperty("region")
/*      */     public void setRegion(Possible<Optional<String>> region) {
/* 6418 */       this.region = region;
/*      */     }
/*      */     @JsonProperty("afk_timeout")
/*      */     public void setAfkTimeout(int afkTimeout) {
/* 6422 */       this.afkTimeout = afkTimeout;
/* 6423 */       this.afkTimeoutIsSet = true;
/*      */     }
/*      */     @JsonProperty("default_message_notifications")
/*      */     public void setDefaultMessageNotifications(int defaultMessageNotifications) {
/* 6427 */       this.defaultMessageNotifications = defaultMessageNotifications;
/* 6428 */       this.defaultMessageNotificationsIsSet = true;
/*      */     }
/*      */     @JsonProperty("explicit_content_filter")
/*      */     public void setExplicitContentFilter(int explicitContentFilter) {
/* 6432 */       this.explicitContentFilter = explicitContentFilter;
/* 6433 */       this.explicitContentFilterIsSet = true;
/*      */     }
/*      */     @JsonProperty("mfa_level")
/*      */     public void setMfaLevel(int mfaLevel) {
/* 6437 */       this.mfaLevel = mfaLevel;
/* 6438 */       this.mfaLevelIsSet = true;
/*      */     }
/*      */     @JsonProperty("premium_tier")
/*      */     public void setPremiumTier(int premiumTier) {
/* 6442 */       this.premiumTier = premiumTier;
/* 6443 */       this.premiumTierIsSet = true;
/*      */     }
/*      */     @JsonProperty("preferred_locale")
/*      */     public void setPreferredLocale(String preferredLocale) {
/* 6447 */       this.preferredLocale = preferredLocale;
/*      */     }
/*      */     @JsonProperty("joined_at")
/*      */     public void setJoinedAt(String joinedAt) {
/* 6451 */       this.joinedAt = joinedAt;
/*      */     }
/*      */     @JsonProperty("large")
/*      */     public void setLarge(boolean large) {
/* 6455 */       this.large = large;
/* 6456 */       this.largeIsSet = true;
/*      */     }
/*      */     @JsonProperty("unavailable")
/*      */     public void setUnavailable(Possible<Boolean> unavailable) {
/* 6460 */       this.unavailable = unavailable;
/*      */     }
/*      */     @JsonProperty("member_count")
/*      */     public void setMemberCount(int memberCount) {
/* 6464 */       this.memberCount = memberCount;
/* 6465 */       this.memberCountIsSet = true;
/*      */     }
/*      */     @JsonProperty("roles")
/*      */     public void setRoles(List<Id> roles) {
/* 6469 */       this.roles = roles;
/*      */     }
/*      */     @JsonProperty("emojis")
/*      */     public void setEmojis(List<Id> emojis) {
/* 6473 */       this.emojis = emojis;
/*      */     }
/*      */     @JsonProperty("stickers")
/*      */     public void setStickers(Possible<List<Id>> stickers) {
/* 6477 */       this.stickers = stickers;
/*      */     }
/*      */     @JsonProperty("members")
/*      */     public void setMembers(List<Id> members) {
/* 6481 */       this.members = members;
/*      */     }
/*      */     @JsonProperty("channels")
/*      */     public void setChannels(List<Id> channels) {
/* 6485 */       this.channels = channels;
/*      */     }
/*      */     public Id id() {
/* 6488 */       throw new UnsupportedOperationException();
/*      */     } public String name() {
/* 6490 */       throw new UnsupportedOperationException();
/*      */     } public Optional<String> icon() {
/* 6492 */       throw new UnsupportedOperationException();
/*      */     } public Optional<String> splash() {
/* 6494 */       throw new UnsupportedOperationException();
/*      */     } public Optional<String> discoverySplash() {
/* 6496 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Boolean> owner() {
/* 6498 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Long> permissions() {
/* 6500 */       throw new UnsupportedOperationException();
/*      */     } public Optional<Id> afkChannelId() {
/* 6502 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Boolean> embedEnabled() {
/* 6504 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<Id>> embedChannelId() {
/* 6506 */       throw new UnsupportedOperationException();
/*      */     } public List<String> features() {
/* 6508 */       throw new UnsupportedOperationException();
/*      */     } public Optional<Id> applicationId() {
/* 6510 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Boolean> widgetEnabled() {
/* 6512 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<Id>> widgetChannelId() {
/* 6514 */       throw new UnsupportedOperationException();
/*      */     } public Optional<Id> systemChannelId() {
/* 6516 */       throw new UnsupportedOperationException();
/*      */     } public OptionalInt systemChannelFlags() {
/* 6518 */       throw new UnsupportedOperationException();
/*      */     } public Optional<Id> rulesChannelId() {
/* 6520 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<Integer>> maxPresences() {
/* 6522 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> maxMembers() {
/* 6524 */       throw new UnsupportedOperationException();
/*      */     } public Optional<String> vanityUrlCode() {
/* 6526 */       throw new UnsupportedOperationException();
/*      */     } public Optional<String> description() {
/* 6528 */       throw new UnsupportedOperationException();
/*      */     } public Optional<String> banner() {
/* 6530 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> premiumSubscriptionCount() {
/* 6532 */       throw new UnsupportedOperationException();
/*      */     } public Optional<Id> publicUpdatesChannelId() {
/* 6534 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> maxVideoChannelUsers() {
/* 6536 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> approximateMemberCount() {
/* 6538 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> approximatePresenceCount() {
/* 6540 */       throw new UnsupportedOperationException();
/*      */     } public Possible<WelcomeScreenData> welcomeScreen() {
/* 6542 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Boolean> nsfw() {
/* 6544 */       throw new UnsupportedOperationException();
/*      */     } public Optional<Id> safetyAlertsChannelId() {
/* 6546 */       throw new UnsupportedOperationException();
/*      */     } public int verificationLevel() {
/* 6548 */       throw new UnsupportedOperationException();
/*      */     } public int nsfwLevel() {
/* 6550 */       throw new UnsupportedOperationException();
/*      */     } public Id ownerId() {
/* 6552 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<String>> region() {
/* 6554 */       throw new UnsupportedOperationException();
/*      */     } public int afkTimeout() {
/* 6556 */       throw new UnsupportedOperationException();
/*      */     } public int defaultMessageNotifications() {
/* 6558 */       throw new UnsupportedOperationException();
/*      */     } public int explicitContentFilter() {
/* 6560 */       throw new UnsupportedOperationException();
/*      */     } public int mfaLevel() {
/* 6562 */       throw new UnsupportedOperationException();
/*      */     } public int premiumTier() {
/* 6564 */       throw new UnsupportedOperationException();
/*      */     } public String preferredLocale() {
/* 6566 */       throw new UnsupportedOperationException();
/*      */     } public String joinedAt() {
/* 6568 */       throw new UnsupportedOperationException();
/*      */     } public boolean large() {
/* 6570 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Boolean> unavailable() {
/* 6572 */       throw new UnsupportedOperationException();
/*      */     } public int memberCount() {
/* 6574 */       throw new UnsupportedOperationException();
/*      */     } public List<Id> roles() {
/* 6576 */       throw new UnsupportedOperationException();
/*      */     } public List<Id> emojis() {
/* 6578 */       throw new UnsupportedOperationException();
/*      */     } public Possible<List<Id>> stickers() {
/* 6580 */       throw new UnsupportedOperationException();
/*      */     } public List<Id> members() {
/* 6582 */       throw new UnsupportedOperationException();
/*      */     } public List<Id> channels() {
/* 6584 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*      */   static ImmutableGuildData fromJson(Json json) {
/* 6595 */     Builder builder = builder();
/* 6596 */     if (json.id != null) {
/* 6597 */       builder.id(json.id);
/*      */     }
/* 6599 */     if (json.name != null) {
/* 6600 */       builder.name(json.name);
/*      */     }
/* 6602 */     if (json.icon != null) {
/* 6603 */       builder.icon(json.icon);
/*      */     }
/* 6605 */     if (json.splash != null) {
/* 6606 */       builder.splash(json.splash);
/*      */     }
/* 6608 */     if (json.discoverySplash != null) {
/* 6609 */       builder.discoverySplash(json.discoverySplash);
/*      */     }
/* 6611 */     if (json.owner != null) {
/* 6612 */       builder.owner(json.owner);
/*      */     }
/* 6614 */     if (json.permissions != null) {
/* 6615 */       builder.permissions(json.permissions);
/*      */     }
/* 6617 */     if (json.afkChannelId != null) {
/* 6618 */       builder.afkChannelId(json.afkChannelId);
/*      */     }
/* 6620 */     if (json.embedEnabled != null) {
/* 6621 */       builder.embedEnabled(json.embedEnabled);
/*      */     }
/* 6623 */     if (json.embedChannelId != null) {
/* 6624 */       builder.embedChannelId(json.embedChannelId);
/*      */     }
/* 6626 */     if (json.features != null) {
/* 6627 */       builder.addAllFeatures(json.features);
/*      */     }
/* 6629 */     if (json.applicationId != null) {
/* 6630 */       builder.applicationId(json.applicationId);
/*      */     }
/* 6632 */     if (json.widgetEnabled != null) {
/* 6633 */       builder.widgetEnabled(json.widgetEnabled);
/*      */     }
/* 6635 */     if (json.widgetChannelId != null) {
/* 6636 */       builder.widgetChannelId(json.widgetChannelId);
/*      */     }
/* 6638 */     if (json.systemChannelId != null) {
/* 6639 */       builder.systemChannelId(json.systemChannelId);
/*      */     }
/* 6641 */     if (json.systemChannelFlags != null) {
/* 6642 */       builder.systemChannelFlags(json.systemChannelFlags);
/*      */     }
/* 6644 */     if (json.rulesChannelId != null) {
/* 6645 */       builder.rulesChannelId(json.rulesChannelId);
/*      */     }
/* 6647 */     if (json.maxPresences != null) {
/* 6648 */       builder.maxPresences(json.maxPresences);
/*      */     }
/* 6650 */     if (json.maxMembers != null) {
/* 6651 */       builder.maxMembers(json.maxMembers);
/*      */     }
/* 6653 */     if (json.vanityUrlCode != null) {
/* 6654 */       builder.vanityUrlCode(json.vanityUrlCode);
/*      */     }
/* 6656 */     if (json.description != null) {
/* 6657 */       builder.description(json.description);
/*      */     }
/* 6659 */     if (json.banner != null) {
/* 6660 */       builder.banner(json.banner);
/*      */     }
/* 6662 */     if (json.premiumSubscriptionCount != null) {
/* 6663 */       builder.premiumSubscriptionCount(json.premiumSubscriptionCount);
/*      */     }
/* 6665 */     if (json.publicUpdatesChannelId != null) {
/* 6666 */       builder.publicUpdatesChannelId(json.publicUpdatesChannelId);
/*      */     }
/* 6668 */     if (json.maxVideoChannelUsers != null) {
/* 6669 */       builder.maxVideoChannelUsers(json.maxVideoChannelUsers);
/*      */     }
/* 6671 */     if (json.approximateMemberCount != null) {
/* 6672 */       builder.approximateMemberCount(json.approximateMemberCount);
/*      */     }
/* 6674 */     if (json.approximatePresenceCount != null) {
/* 6675 */       builder.approximatePresenceCount(json.approximatePresenceCount);
/*      */     }
/* 6677 */     if (json.welcomeScreen != null) {
/* 6678 */       builder.welcomeScreen(json.welcomeScreen);
/*      */     }
/* 6680 */     if (json.nsfw != null) {
/* 6681 */       builder.nsfw(json.nsfw);
/*      */     }
/* 6683 */     if (json.safetyAlertsChannelId != null) {
/* 6684 */       builder.safetyAlertsChannelId(json.safetyAlertsChannelId);
/*      */     }
/* 6686 */     if (json.verificationLevelIsSet) {
/* 6687 */       builder.verificationLevel(json.verificationLevel);
/*      */     }
/* 6689 */     if (json.nsfwLevelIsSet) {
/* 6690 */       builder.nsfwLevel(json.nsfwLevel);
/*      */     }
/* 6692 */     if (json.ownerId != null) {
/* 6693 */       builder.ownerId(json.ownerId);
/*      */     }
/* 6695 */     if (json.region != null) {
/* 6696 */       builder.region(json.region);
/*      */     }
/* 6698 */     if (json.afkTimeoutIsSet) {
/* 6699 */       builder.afkTimeout(json.afkTimeout);
/*      */     }
/* 6701 */     if (json.defaultMessageNotificationsIsSet) {
/* 6702 */       builder.defaultMessageNotifications(json.defaultMessageNotifications);
/*      */     }
/* 6704 */     if (json.explicitContentFilterIsSet) {
/* 6705 */       builder.explicitContentFilter(json.explicitContentFilter);
/*      */     }
/* 6707 */     if (json.mfaLevelIsSet) {
/* 6708 */       builder.mfaLevel(json.mfaLevel);
/*      */     }
/* 6710 */     if (json.premiumTierIsSet) {
/* 6711 */       builder.premiumTier(json.premiumTier);
/*      */     }
/* 6713 */     if (json.preferredLocale != null) {
/* 6714 */       builder.preferredLocale(json.preferredLocale);
/*      */     }
/* 6716 */     if (json.joinedAt != null) {
/* 6717 */       builder.joinedAt(json.joinedAt);
/*      */     }
/* 6719 */     if (json.largeIsSet) {
/* 6720 */       builder.large(json.large);
/*      */     }
/* 6722 */     if (json.unavailable != null) {
/* 6723 */       builder.unavailable(json.unavailable);
/*      */     }
/* 6725 */     if (json.memberCountIsSet) {
/* 6726 */       builder.memberCount(json.memberCount);
/*      */     }
/* 6728 */     if (json.roles != null) {
/* 6729 */       builder.roles(json.roles);
/*      */     }
/* 6731 */     if (json.emojis != null) {
/* 6732 */       builder.emojis(json.emojis);
/*      */     }
/* 6734 */     if (json.stickers != null) {
/* 6735 */       builder.stickers(json.stickers);
/*      */     }
/* 6737 */     if (json.members != null) {
/* 6738 */       builder.members(json.members);
/*      */     }
/* 6740 */     if (json.channels != null) {
/* 6741 */       builder.channels(json.channels);
/*      */     }
/* 6743 */     return builder.build();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableGuildData of(Id id, String name, Optional<String> icon, Optional<String> splash, Optional<String> discoverySplash, Possible<Boolean> owner, Possible<Long> permissions, Optional<Id> afkChannelId, Possible<Boolean> embedEnabled, Possible<Optional<Id>> embedChannelId, List<String> features, Optional<Id> applicationId, Possible<Boolean> widgetEnabled, Possible<Optional<Id>> widgetChannelId, Optional<Id> systemChannelId, OptionalInt systemChannelFlags, Optional<Id> rulesChannelId, Possible<Optional<Integer>> maxPresences, Possible<Integer> maxMembers, Optional<String> vanityUrlCode, Optional<String> description, Optional<String> banner, Possible<Integer> premiumSubscriptionCount, Optional<Id> publicUpdatesChannelId, Possible<Integer> maxVideoChannelUsers, Possible<Integer> approximateMemberCount, Possible<Integer> approximatePresenceCount, Possible<WelcomeScreenData> welcomeScreen, Possible<Boolean> nsfw, Optional<Id> safetyAlertsChannelId, int verificationLevel, int nsfwLevel, Id ownerId, Possible<Optional<String>> region, int afkTimeout, int defaultMessageNotifications, int explicitContentFilter, int mfaLevel, int premiumTier, String preferredLocale, String joinedAt, boolean large, Possible<Boolean> unavailable, int memberCount, List<Id> roles, List<Id> emojis, Possible<List<Id>> stickers, List<Id> members, List<Id> channels) {
/* 6800 */     return of(id, name, icon, splash, discoverySplash, owner, permissions, afkChannelId, embedEnabled, embedChannelId, features, applicationId, widgetEnabled, widgetChannelId, systemChannelId, systemChannelFlags, rulesChannelId, maxPresences, maxMembers, vanityUrlCode, description, banner, premiumSubscriptionCount, publicUpdatesChannelId, maxVideoChannelUsers, approximateMemberCount, approximatePresenceCount, welcomeScreen, nsfw, safetyAlertsChannelId, verificationLevel, nsfwLevel, ownerId, region, afkTimeout, defaultMessageNotifications, explicitContentFilter, mfaLevel, premiumTier, preferredLocale, joinedAt, large, unavailable, memberCount, roles, emojis, stickers, members, channels);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableGuildData of(Id id, String name, Optional<String> icon, Optional<String> splash, Optional<String> discoverySplash, Possible<Boolean> owner, Possible<Long> permissions, Optional<Id> afkChannelId, Possible<Boolean> embedEnabled, Possible<Optional<Id>> embedChannelId, Iterable<String> features, Optional<Id> applicationId, Possible<Boolean> widgetEnabled, Possible<Optional<Id>> widgetChannelId, Optional<Id> systemChannelId, OptionalInt systemChannelFlags, Optional<Id> rulesChannelId, Possible<Optional<Integer>> maxPresences, Possible<Integer> maxMembers, Optional<String> vanityUrlCode, Optional<String> description, Optional<String> banner, Possible<Integer> premiumSubscriptionCount, Optional<Id> publicUpdatesChannelId, Possible<Integer> maxVideoChannelUsers, Possible<Integer> approximateMemberCount, Possible<Integer> approximatePresenceCount, Possible<WelcomeScreenData> welcomeScreen, Possible<Boolean> nsfw, Optional<Id> safetyAlertsChannelId, int verificationLevel, int nsfwLevel, Id ownerId, Possible<Optional<String>> region, int afkTimeout, int defaultMessageNotifications, int explicitContentFilter, int mfaLevel, int premiumTier, String preferredLocale, String joinedAt, boolean large, Possible<Boolean> unavailable, int memberCount, List<Id> roles, List<Id> emojis, Possible<List<Id>> stickers, List<Id> members, List<Id> channels) {
/* 6857 */     return new ImmutableGuildData(id, name, icon, splash, discoverySplash, owner, permissions, afkChannelId, embedEnabled, embedChannelId, features, applicationId, widgetEnabled, widgetChannelId, systemChannelId, systemChannelFlags, rulesChannelId, maxPresences, maxMembers, vanityUrlCode, description, banner, premiumSubscriptionCount, publicUpdatesChannelId, maxVideoChannelUsers, approximateMemberCount, approximatePresenceCount, welcomeScreen, nsfw, safetyAlertsChannelId, verificationLevel, nsfwLevel, ownerId, region, afkTimeout, defaultMessageNotifications, explicitContentFilter, mfaLevel, premiumTier, preferredLocale, joinedAt, large, unavailable, memberCount, roles, emojis, stickers, members, channels);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableGuildData copyOf(GuildData instance) {
/* 6868 */     if (instance instanceof ImmutableGuildData) {
/* 6869 */       return (ImmutableGuildData)instance;
/*      */     }
/* 6871 */     return builder()
/* 6872 */       .from(instance)
/* 6873 */       .build();
/*      */   }
/*      */   
/*      */   public boolean isOwnerPresent() {
/* 6877 */     return !this.owner_absent;
/*      */   }
/*      */   
/*      */   public Boolean ownerOrElse(Boolean defaultValue) {
/* 6881 */     return !this.owner_absent ? this.owner_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isPermissionsPresent() {
/* 6885 */     return !this.permissions_absent;
/*      */   }
/*      */   
/*      */   public Long permissionsOrElse(Long defaultValue) {
/* 6889 */     return !this.permissions_absent ? this.permissions_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isAfkChannelIdPresent() {
/* 6893 */     return this.afkChannelId_present;
/*      */   }
/*      */   
/*      */   public long afkChannelIdOrElse(long defaultValue) {
/* 6897 */     return this.afkChannelId_present ? this.afkChannelId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isEmbedEnabledPresent() {
/* 6901 */     return !this.embedEnabled_absent;
/*      */   }
/*      */   
/*      */   public Boolean embedEnabledOrElse(Boolean defaultValue) {
/* 6905 */     return !this.embedEnabled_absent ? this.embedEnabled_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isEmbedChannelIdPresent() {
/* 6909 */     return !this.embedChannelId_absent;
/*      */   }
/*      */   
/*      */   public long embedChannelIdOrElse(long defaultValue) {
/* 6913 */     return !this.embedChannelId_absent ? this.embedChannelId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isApplicationIdPresent() {
/* 6917 */     return this.applicationId_present;
/*      */   }
/*      */   
/*      */   public long applicationIdOrElse(long defaultValue) {
/* 6921 */     return this.applicationId_present ? this.applicationId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isWidgetEnabledPresent() {
/* 6925 */     return !this.widgetEnabled_absent;
/*      */   }
/*      */   
/*      */   public Boolean widgetEnabledOrElse(Boolean defaultValue) {
/* 6929 */     return !this.widgetEnabled_absent ? this.widgetEnabled_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isWidgetChannelIdPresent() {
/* 6933 */     return !this.widgetChannelId_absent;
/*      */   }
/*      */   
/*      */   public long widgetChannelIdOrElse(long defaultValue) {
/* 6937 */     return !this.widgetChannelId_absent ? this.widgetChannelId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isSystemChannelIdPresent() {
/* 6941 */     return this.systemChannelId_present;
/*      */   }
/*      */   
/*      */   public long systemChannelIdOrElse(long defaultValue) {
/* 6945 */     return this.systemChannelId_present ? this.systemChannelId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isRulesChannelIdPresent() {
/* 6949 */     return this.rulesChannelId_present;
/*      */   }
/*      */   
/*      */   public long rulesChannelIdOrElse(long defaultValue) {
/* 6953 */     return this.rulesChannelId_present ? this.rulesChannelId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isMaxPresencesPresent() {
/* 6957 */     return !this.maxPresences_absent;
/*      */   }
/*      */   
/*      */   public Integer maxPresencesOrElse(Integer defaultValue) {
/* 6961 */     return !this.maxPresences_absent ? this.maxPresences_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isMaxMembersPresent() {
/* 6965 */     return !this.maxMembers_absent;
/*      */   }
/*      */   
/*      */   public Integer maxMembersOrElse(Integer defaultValue) {
/* 6969 */     return !this.maxMembers_absent ? this.maxMembers_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isPremiumSubscriptionCountPresent() {
/* 6973 */     return !this.premiumSubscriptionCount_absent;
/*      */   }
/*      */   
/*      */   public Integer premiumSubscriptionCountOrElse(Integer defaultValue) {
/* 6977 */     return !this.premiumSubscriptionCount_absent ? this.premiumSubscriptionCount_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isPublicUpdatesChannelIdPresent() {
/* 6981 */     return this.publicUpdatesChannelId_present;
/*      */   }
/*      */   
/*      */   public long publicUpdatesChannelIdOrElse(long defaultValue) {
/* 6985 */     return this.publicUpdatesChannelId_present ? this.publicUpdatesChannelId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isMaxVideoChannelUsersPresent() {
/* 6989 */     return !this.maxVideoChannelUsers_absent;
/*      */   }
/*      */   
/*      */   public Integer maxVideoChannelUsersOrElse(Integer defaultValue) {
/* 6993 */     return !this.maxVideoChannelUsers_absent ? this.maxVideoChannelUsers_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isApproximateMemberCountPresent() {
/* 6997 */     return !this.approximateMemberCount_absent;
/*      */   }
/*      */   
/*      */   public Integer approximateMemberCountOrElse(Integer defaultValue) {
/* 7001 */     return !this.approximateMemberCount_absent ? this.approximateMemberCount_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isApproximatePresenceCountPresent() {
/* 7005 */     return !this.approximatePresenceCount_absent;
/*      */   }
/*      */   
/*      */   public Integer approximatePresenceCountOrElse(Integer defaultValue) {
/* 7009 */     return !this.approximatePresenceCount_absent ? this.approximatePresenceCount_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isWelcomeScreenPresent() {
/* 7013 */     return !this.welcomeScreen_absent;
/*      */   }
/*      */   
/*      */   public WelcomeScreenData welcomeScreenOrElse(WelcomeScreenData defaultValue) {
/* 7017 */     return !this.welcomeScreen_absent ? this.welcomeScreen_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isNsfwPresent() {
/* 7021 */     return !this.nsfw_absent;
/*      */   }
/*      */   
/*      */   public Boolean nsfwOrElse(Boolean defaultValue) {
/* 7025 */     return !this.nsfw_absent ? this.nsfw_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isSafetyAlertsChannelIdPresent() {
/* 7029 */     return this.safetyAlertsChannelId_present;
/*      */   }
/*      */   
/*      */   public long safetyAlertsChannelIdOrElse(long defaultValue) {
/* 7033 */     return this.safetyAlertsChannelId_present ? this.safetyAlertsChannelId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isRegionPresent() {
/* 7037 */     return !this.region_absent;
/*      */   }
/*      */   
/*      */   public String regionOrElse(String defaultValue) {
/* 7041 */     return !this.region_absent ? this.region_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isUnavailablePresent() {
/* 7045 */     return !this.unavailable_absent;
/*      */   }
/*      */   
/*      */   public Boolean unavailableOrElse(Boolean defaultValue) {
/* 7049 */     return !this.unavailable_absent ? this.unavailable_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isStickersPresent() {
/* 7053 */     return !this.stickers_absent;
/*      */   }
/*      */   
/*      */   public List<Id> stickersOrElse(List<Id> defaultValue) {
/* 7057 */     return !this.stickers_absent ? this.stickers_value : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Builder builder() {
/* 7118 */     return new Builder();
/*      */   }
/*      */ 
/*      */   
/*      */   @Generated(from = "GuildData", generator = "Immutables")
/*      */   public static final class Builder
/*      */   {
/*      */     private static final long INIT_BIT_NAME = 1L;
/*      */     
/*      */     private static final long INIT_BIT_VERIFICATION_LEVEL = 2L;
/*      */     
/*      */     private static final long INIT_BIT_NSFW_LEVEL = 4L;
/*      */     
/*      */     private static final long INIT_BIT_AFK_TIMEOUT = 8L;
/*      */     
/*      */     private static final long INIT_BIT_DEFAULT_MESSAGE_NOTIFICATIONS = 16L;
/*      */     
/*      */     private static final long INIT_BIT_EXPLICIT_CONTENT_FILTER = 32L;
/*      */     private static final long INIT_BIT_MFA_LEVEL = 64L;
/*      */     private static final long INIT_BIT_PREMIUM_TIER = 128L;
/*      */     private static final long INIT_BIT_PREFERRED_LOCALE = 256L;
/*      */     private static final long INIT_BIT_JOINED_AT = 512L;
/*      */     private static final long INIT_BIT_LARGE = 1024L;
/*      */     private static final long INIT_BIT_MEMBER_COUNT = 2048L;
/* 7142 */     private long initBits = 4095L;
/*      */     
/* 7144 */     private Id id_id = null;
/* 7145 */     private Possible<Boolean> owner_possible = Possible.absent();
/* 7146 */     private Possible<Long> permissions_possible = Possible.absent();
/* 7147 */     private Optional<Id> afkChannelId_optional = Optional.empty();
/* 7148 */     private Possible<Boolean> embedEnabled_possible = Possible.absent();
/* 7149 */     private Possible<Optional<Id>> embedChannelId_possible = Possible.absent();
/* 7150 */     private Optional<Id> applicationId_optional = Optional.empty();
/* 7151 */     private Possible<Boolean> widgetEnabled_possible = Possible.absent();
/* 7152 */     private Possible<Optional<Id>> widgetChannelId_possible = Possible.absent();
/* 7153 */     private Optional<Id> systemChannelId_optional = Optional.empty();
/* 7154 */     private Optional<Id> rulesChannelId_optional = Optional.empty();
/* 7155 */     private Possible<Optional<Integer>> maxPresences_possible = Possible.absent();
/* 7156 */     private Possible<Integer> maxMembers_possible = Possible.absent();
/* 7157 */     private Possible<Integer> premiumSubscriptionCount_possible = Possible.absent();
/* 7158 */     private Optional<Id> publicUpdatesChannelId_optional = Optional.empty();
/* 7159 */     private Possible<Integer> maxVideoChannelUsers_possible = Possible.absent();
/* 7160 */     private Possible<Integer> approximateMemberCount_possible = Possible.absent();
/* 7161 */     private Possible<Integer> approximatePresenceCount_possible = Possible.absent();
/* 7162 */     private Possible<WelcomeScreenData> welcomeScreen_possible = Possible.absent();
/* 7163 */     private Possible<Boolean> nsfw_possible = Possible.absent();
/* 7164 */     private Optional<Id> safetyAlertsChannelId_optional = Optional.empty();
/* 7165 */     private Id ownerId_id = null;
/* 7166 */     private Possible<Optional<String>> region_possible = Possible.absent();
/* 7167 */     private Possible<Boolean> unavailable_possible = Possible.absent();
/* 7168 */     private List<Long> roles_list = null;
/* 7169 */     private List<Long> emojis_list = null;
/* 7170 */     private List<Id> stickers_list = null;
/* 7171 */     private List<Long> members_list = null;
/* 7172 */     private List<Long> channels_list = null;
/*      */     private String name;
/*      */     private String icon;
/*      */     private String splash;
/*      */     private String discoverySplash;
/* 7177 */     private List<String> features = new ArrayList<>();
/*      */     
/*      */     private Integer systemChannelFlags;
/*      */     
/*      */     private String vanityUrlCode;
/*      */     
/*      */     private String description;
/*      */     
/*      */     private String banner;
/*      */     
/*      */     private int verificationLevel;
/*      */     
/*      */     private int nsfwLevel;
/*      */     
/*      */     private int afkTimeout;
/*      */     
/*      */     private int defaultMessageNotifications;
/*      */     private int explicitContentFilter;
/*      */     private int mfaLevel;
/*      */     private int premiumTier;
/*      */     private String preferredLocale;
/*      */     private String joinedAt;
/*      */     private boolean large;
/*      */     private int memberCount;
/*      */     
/*      */     public final Builder from(GuildFields instance) {
/* 7203 */       Objects.requireNonNull(instance, "instance");
/* 7204 */       from(instance);
/* 7205 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(GuildUpdateFields instance) {
/* 7214 */       Objects.requireNonNull(instance, "instance");
/* 7215 */       from(instance);
/* 7216 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(GuildCreateFields instance) {
/* 7225 */       Objects.requireNonNull(instance, "instance");
/* 7226 */       from(instance);
/* 7227 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(GuildNsfwLevelField instance) {
/* 7236 */       Objects.requireNonNull(instance, "instance");
/* 7237 */       from(instance);
/* 7238 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(GuildVerificationLevelField instance) {
/* 7247 */       Objects.requireNonNull(instance, "instance");
/* 7248 */       from(instance);
/* 7249 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(GuildData instance) {
/* 7258 */       Objects.requireNonNull(instance, "instance");
/* 7259 */       from(instance);
/* 7260 */       return this;
/*      */     }
/*      */     
/*      */     private void from(Object object) {
/* 7264 */       long bits = 0L;
/* 7265 */       if (object instanceof GuildFields) {
/* 7266 */         GuildFields instance = (GuildFields)object;
/* 7267 */         if ((bits & 0x1000000L) == 0L) {
/* 7268 */           Optional<String> vanityUrlCodeOptional = instance.vanityUrlCode();
/* 7269 */           if (vanityUrlCodeOptional.isPresent()) {
/* 7270 */             vanityUrlCode(vanityUrlCodeOptional);
/*      */           }
/* 7272 */           bits |= 0x1000000L;
/*      */         } 
/* 7274 */         if ((bits & 0x2000000L) == 0L) {
/* 7275 */           Optional<String> iconOptional = instance.icon();
/* 7276 */           if (iconOptional.isPresent()) {
/* 7277 */             icon(iconOptional);
/*      */           }
/* 7279 */           bits |= 0x2000000L;
/*      */         } 
/* 7281 */         if ((bits & 0x4000000L) == 0L) {
/* 7282 */           Optional<String> descriptionOptional = instance.description();
/* 7283 */           if (descriptionOptional.isPresent()) {
/* 7284 */             description(descriptionOptional);
/*      */           }
/* 7286 */           bits |= 0x4000000L;
/*      */         } 
/* 7288 */         if ((bits & 0x10L) == 0L) {
/* 7289 */           afkChannelId(instance.afkChannelId());
/* 7290 */           bits |= 0x10L;
/*      */         } 
/* 7292 */         if ((bits & 0x40L) == 0L) {
/* 7293 */           addAllFeatures(instance.features());
/* 7294 */           bits |= 0x40L;
/*      */         } 
/* 7296 */         if ((bits & 0x80L) == 0L) {
/* 7297 */           maxMembers(instance.maxMembers());
/* 7298 */           bits |= 0x80L;
/*      */         } 
/* 7300 */         if ((bits & 0x100L) == 0L) {
/* 7301 */           permissions(instance.permissions());
/* 7302 */           bits |= 0x100L;
/*      */         } 
/* 7304 */         if ((bits & 0x200L) == 0L) {
/* 7305 */           publicUpdatesChannelId(instance.publicUpdatesChannelId());
/* 7306 */           bits |= 0x200L;
/*      */         } 
/* 7308 */         if ((bits & 0x400L) == 0L) {
/* 7309 */           id(instance.id());
/* 7310 */           bits |= 0x400L;
/*      */         } 
/* 7312 */         if ((bits & 0x8000000L) == 0L) {
/* 7313 */           safetyAlertsChannelId(instance.safetyAlertsChannelId());
/* 7314 */           bits |= 0x8000000L;
/*      */         } 
/* 7316 */         if ((bits & 0x10000000L) == 0L) {
/* 7317 */           systemChannelId(instance.systemChannelId());
/* 7318 */           bits |= 0x10000000L;
/*      */         } 
/* 7320 */         if ((bits & 0x40000000L) == 0L) {
/* 7321 */           owner(instance.owner());
/* 7322 */           bits |= 0x40000000L;
/*      */         } 
/* 7324 */         if ((bits & 0x800L) == 0L) {
/* 7325 */           approximateMemberCount(instance.approximateMemberCount());
/* 7326 */           bits |= 0x800L;
/*      */         } 
/* 7328 */         if ((bits & 0x80000000L) == 0L) {
/* 7329 */           Optional<String> discoverySplashOptional = instance.discoverySplash();
/* 7330 */           if (discoverySplashOptional.isPresent()) {
/* 7331 */             discoverySplash(discoverySplashOptional);
/*      */           }
/* 7333 */           bits |= 0x80000000L;
/*      */         } 
/* 7335 */         if ((bits & 0x200000000L) == 0L) {
/* 7336 */           maxPresences(instance.maxPresences());
/* 7337 */           bits |= 0x200000000L;
/*      */         } 
/* 7339 */         if ((bits & 0x400000000L) == 0L) {
/* 7340 */           welcomeScreen(instance.welcomeScreen());
/* 7341 */           bits |= 0x400000000L;
/*      */         } 
/* 7343 */         if ((bits & 0x2000L) == 0L) {
/* 7344 */           rulesChannelId(instance.rulesChannelId());
/* 7345 */           bits |= 0x2000L;
/*      */         } 
/* 7347 */         if ((bits & 0x800000000L) == 0L) {
/* 7348 */           nsfw(instance.nsfw());
/* 7349 */           bits |= 0x800000000L;
/*      */         } 
/* 7351 */         if ((bits & 0x8000L) == 0L) {
/* 7352 */           widgetChannelId(instance.widgetChannelId());
/* 7353 */           bits |= 0x8000L;
/*      */         } 
/* 7355 */         if ((bits & 0x2000000000L) == 0L) {
/* 7356 */           Optional<String> bannerOptional = instance.banner();
/* 7357 */           if (bannerOptional.isPresent()) {
/* 7358 */             banner(bannerOptional);
/*      */           }
/* 7360 */           bits |= 0x2000000000L;
/*      */         } 
/* 7362 */         if ((bits & 0x10000L) == 0L) {
/* 7363 */           widgetEnabled(instance.widgetEnabled());
/* 7364 */           bits |= 0x10000L;
/*      */         } 
/* 7366 */         if ((bits & 0x4000000000L) == 0L) {
/* 7367 */           embedChannelId(instance.embedChannelId());
/* 7368 */           bits |= 0x4000000000L;
/*      */         } 
/* 7370 */         if ((bits & 0x20000L) == 0L) {
/* 7371 */           OptionalInt systemChannelFlagsOptional = instance.systemChannelFlags();
/* 7372 */           if (systemChannelFlagsOptional.isPresent()) {
/* 7373 */             systemChannelFlags(systemChannelFlagsOptional);
/*      */           }
/* 7375 */           bits |= 0x20000L;
/*      */         } 
/* 7377 */         if ((bits & 0x8000000000L) == 0L) {
/* 7378 */           maxVideoChannelUsers(instance.maxVideoChannelUsers());
/* 7379 */           bits |= 0x8000000000L;
/*      */         } 
/* 7381 */         if ((bits & 0x40000L) == 0L) {
/* 7382 */           name(instance.name());
/* 7383 */           bits |= 0x40000L;
/*      */         } 
/* 7385 */         if ((bits & 0x80000L) == 0L) {
/* 7386 */           premiumSubscriptionCount(instance.premiumSubscriptionCount());
/* 7387 */           bits |= 0x80000L;
/*      */         } 
/* 7389 */         if ((bits & 0x20000000000L) == 0L) {
/* 7390 */           embedEnabled(instance.embedEnabled());
/* 7391 */           bits |= 0x20000000000L;
/*      */         } 
/* 7393 */         if ((bits & 0x100000L) == 0L) {
/* 7394 */           approximatePresenceCount(instance.approximatePresenceCount());
/* 7395 */           bits |= 0x100000L;
/*      */         } 
/* 7397 */         if ((bits & 0x200000L) == 0L) {
/* 7398 */           applicationId(instance.applicationId());
/* 7399 */           bits |= 0x200000L;
/*      */         } 
/* 7401 */         if ((bits & 0x80000000000L) == 0L) {
/* 7402 */           Optional<String> splashOptional = instance.splash();
/* 7403 */           if (splashOptional.isPresent()) {
/* 7404 */             splash(splashOptional);
/*      */           }
/* 7406 */           bits |= 0x80000000000L;
/*      */         } 
/*      */       } 
/* 7409 */       if (object instanceof GuildUpdateFields) {
/* 7410 */         GuildUpdateFields instance = (GuildUpdateFields)object;
/* 7411 */         if ((bits & 0x800000L) == 0L) {
/* 7412 */           explicitContentFilter(instance.explicitContentFilter());
/* 7413 */           bits |= 0x800000L;
/*      */         } 
/* 7415 */         if ((bits & 0x1000000L) == 0L) {
/* 7416 */           Optional<String> vanityUrlCodeOptional = instance.vanityUrlCode();
/* 7417 */           if (vanityUrlCodeOptional.isPresent()) {
/* 7418 */             vanityUrlCode(vanityUrlCodeOptional);
/*      */           }
/* 7420 */           bits |= 0x1000000L;
/*      */         } 
/* 7422 */         if ((bits & 0x2L) == 0L) {
/* 7423 */           afkTimeout(instance.afkTimeout());
/* 7424 */           bits |= 0x2L;
/*      */         } 
/* 7426 */         if ((bits & 0x4L) == 0L) {
/* 7427 */           premiumTier(instance.premiumTier());
/* 7428 */           bits |= 0x4L;
/*      */         } 
/* 7430 */         if ((bits & 0x8L) == 0L) {
/* 7431 */           verificationLevel(instance.verificationLevel());
/* 7432 */           bits |= 0x8L;
/*      */         } 
/* 7434 */         if ((bits & 0x2000000L) == 0L) {
/* 7435 */           Optional<String> iconOptional = instance.icon();
/* 7436 */           if (iconOptional.isPresent()) {
/* 7437 */             icon(iconOptional);
/*      */           }
/* 7439 */           bits |= 0x2000000L;
/*      */         } 
/* 7441 */         if ((bits & 0x4000000L) == 0L) {
/* 7442 */           Optional<String> descriptionOptional = instance.description();
/* 7443 */           if (descriptionOptional.isPresent()) {
/* 7444 */             description(descriptionOptional);
/*      */           }
/* 7446 */           bits |= 0x4000000L;
/*      */         } 
/* 7448 */         if ((bits & 0x10L) == 0L) {
/* 7449 */           afkChannelId(instance.afkChannelId());
/* 7450 */           bits |= 0x10L;
/*      */         } 
/* 7452 */         if ((bits & 0x20L) == 0L) {
/* 7453 */           ownerId(instance.ownerId());
/* 7454 */           bits |= 0x20L;
/*      */         } 
/* 7456 */         if ((bits & 0x40L) == 0L) {
/* 7457 */           addAllFeatures(instance.features());
/* 7458 */           bits |= 0x40L;
/*      */         } 
/* 7460 */         if ((bits & 0x80L) == 0L) {
/* 7461 */           maxMembers(instance.maxMembers());
/* 7462 */           bits |= 0x80L;
/*      */         } 
/* 7464 */         if ((bits & 0x100L) == 0L) {
/* 7465 */           permissions(instance.permissions());
/* 7466 */           bits |= 0x100L;
/*      */         } 
/* 7468 */         if ((bits & 0x200L) == 0L) {
/* 7469 */           publicUpdatesChannelId(instance.publicUpdatesChannelId());
/* 7470 */           bits |= 0x200L;
/*      */         } 
/* 7472 */         if ((bits & 0x400L) == 0L) {
/* 7473 */           id(instance.id());
/* 7474 */           bits |= 0x400L;
/*      */         } 
/* 7476 */         if ((bits & 0x8000000L) == 0L) {
/* 7477 */           safetyAlertsChannelId(instance.safetyAlertsChannelId());
/* 7478 */           bits |= 0x8000000L;
/*      */         } 
/* 7480 */         if ((bits & 0x10000000L) == 0L) {
/* 7481 */           systemChannelId(instance.systemChannelId());
/* 7482 */           bits |= 0x10000000L;
/*      */         } 
/* 7484 */         if ((bits & 0x20000000L) == 0L) {
/* 7485 */           preferredLocale(instance.preferredLocale());
/* 7486 */           bits |= 0x20000000L;
/*      */         } 
/* 7488 */         if ((bits & 0x40000000L) == 0L) {
/* 7489 */           owner(instance.owner());
/* 7490 */           bits |= 0x40000000L;
/*      */         } 
/* 7492 */         if ((bits & 0x800L) == 0L) {
/* 7493 */           approximateMemberCount(instance.approximateMemberCount());
/* 7494 */           bits |= 0x800L;
/*      */         } 
/* 7496 */         if ((bits & 0x80000000L) == 0L) {
/* 7497 */           Optional<String> discoverySplashOptional = instance.discoverySplash();
/* 7498 */           if (discoverySplashOptional.isPresent()) {
/* 7499 */             discoverySplash(discoverySplashOptional);
/*      */           }
/* 7501 */           bits |= 0x80000000L;
/*      */         } 
/* 7503 */         if ((bits & 0x100000000L) == 0L) {
/* 7504 */           defaultMessageNotifications(instance.defaultMessageNotifications());
/* 7505 */           bits |= 0x100000000L;
/*      */         } 
/* 7507 */         if ((bits & 0x200000000L) == 0L) {
/* 7508 */           maxPresences(instance.maxPresences());
/* 7509 */           bits |= 0x200000000L;
/*      */         } 
/* 7511 */         if ((bits & 0x400000000L) == 0L) {
/* 7512 */           welcomeScreen(instance.welcomeScreen());
/* 7513 */           bits |= 0x400000000L;
/*      */         } 
/* 7515 */         if ((bits & 0x2000L) == 0L) {
/* 7516 */           rulesChannelId(instance.rulesChannelId());
/* 7517 */           bits |= 0x2000L;
/*      */         } 
/* 7519 */         if ((bits & 0x800000000L) == 0L) {
/* 7520 */           nsfw(instance.nsfw());
/* 7521 */           bits |= 0x800000000L;
/*      */         } 
/* 7523 */         if ((bits & 0x8000L) == 0L) {
/* 7524 */           widgetChannelId(instance.widgetChannelId());
/* 7525 */           bits |= 0x8000L;
/*      */         } 
/* 7527 */         if ((bits & 0x2000000000L) == 0L) {
/* 7528 */           Optional<String> bannerOptional = instance.banner();
/* 7529 */           if (bannerOptional.isPresent()) {
/* 7530 */             banner(bannerOptional);
/*      */           }
/* 7532 */           bits |= 0x2000000000L;
/*      */         } 
/* 7534 */         if ((bits & 0x10000L) == 0L) {
/* 7535 */           widgetEnabled(instance.widgetEnabled());
/* 7536 */           bits |= 0x10000L;
/*      */         } 
/* 7538 */         if ((bits & 0x4000000000L) == 0L) {
/* 7539 */           embedChannelId(instance.embedChannelId());
/* 7540 */           bits |= 0x4000000000L;
/*      */         } 
/* 7542 */         if ((bits & 0x20000L) == 0L) {
/* 7543 */           OptionalInt systemChannelFlagsOptional = instance.systemChannelFlags();
/* 7544 */           if (systemChannelFlagsOptional.isPresent()) {
/* 7545 */             systemChannelFlags(systemChannelFlagsOptional);
/*      */           }
/* 7547 */           bits |= 0x20000L;
/*      */         } 
/* 7549 */         if ((bits & 0x8000000000L) == 0L) {
/* 7550 */           maxVideoChannelUsers(instance.maxVideoChannelUsers());
/* 7551 */           bits |= 0x8000000000L;
/*      */         } 
/* 7553 */         if ((bits & 0x10000000000L) == 0L) {
/* 7554 */           nsfwLevel(instance.nsfwLevel());
/* 7555 */           bits |= 0x10000000000L;
/*      */         } 
/* 7557 */         if ((bits & 0x40000L) == 0L) {
/* 7558 */           name(instance.name());
/* 7559 */           bits |= 0x40000L;
/*      */         } 
/* 7561 */         if ((bits & 0x80000L) == 0L) {
/* 7562 */           premiumSubscriptionCount(instance.premiumSubscriptionCount());
/* 7563 */           bits |= 0x80000L;
/*      */         } 
/* 7565 */         if ((bits & 0x20000000000L) == 0L) {
/* 7566 */           embedEnabled(instance.embedEnabled());
/* 7567 */           bits |= 0x20000000000L;
/*      */         } 
/* 7569 */         if ((bits & 0x100000L) == 0L) {
/* 7570 */           approximatePresenceCount(instance.approximatePresenceCount());
/* 7571 */           bits |= 0x100000L;
/*      */         } 
/* 7573 */         if ((bits & 0x200000L) == 0L) {
/* 7574 */           applicationId(instance.applicationId());
/* 7575 */           bits |= 0x200000L;
/*      */         } 
/* 7577 */         if ((bits & 0x400000L) == 0L) {
/* 7578 */           region(instance.region());
/* 7579 */           bits |= 0x400000L;
/*      */         } 
/* 7581 */         if ((bits & 0x40000000000L) == 0L) {
/* 7582 */           mfaLevel(instance.mfaLevel());
/* 7583 */           bits |= 0x40000000000L;
/*      */         } 
/* 7585 */         if ((bits & 0x80000000000L) == 0L) {
/* 7586 */           Optional<String> splashOptional = instance.splash();
/* 7587 */           if (splashOptional.isPresent()) {
/* 7588 */             splash(splashOptional);
/*      */           }
/* 7590 */           bits |= 0x80000000000L;
/*      */         } 
/*      */       } 
/* 7593 */       if (object instanceof GuildCreateFields) {
/* 7594 */         GuildCreateFields instance = (GuildCreateFields)object;
/* 7595 */         if ((bits & 0x800000L) == 0L) {
/* 7596 */           explicitContentFilter(instance.explicitContentFilter());
/* 7597 */           bits |= 0x800000L;
/*      */         } 
/* 7599 */         if ((bits & 0x1000000L) == 0L) {
/* 7600 */           Optional<String> vanityUrlCodeOptional = instance.vanityUrlCode();
/* 7601 */           if (vanityUrlCodeOptional.isPresent()) {
/* 7602 */             vanityUrlCode(vanityUrlCodeOptional);
/*      */           }
/* 7604 */           bits |= 0x1000000L;
/*      */         } 
/* 7606 */         if ((bits & 0x1L) == 0L) {
/* 7607 */           unavailable(instance.unavailable());
/* 7608 */           bits |= 0x1L;
/*      */         } 
/* 7610 */         if ((bits & 0x2L) == 0L) {
/* 7611 */           afkTimeout(instance.afkTimeout());
/* 7612 */           bits |= 0x2L;
/*      */         } 
/* 7614 */         if ((bits & 0x4L) == 0L) {
/* 7615 */           premiumTier(instance.premiumTier());
/* 7616 */           bits |= 0x4L;
/*      */         } 
/* 7618 */         if ((bits & 0x8L) == 0L) {
/* 7619 */           verificationLevel(instance.verificationLevel());
/* 7620 */           bits |= 0x8L;
/*      */         } 
/* 7622 */         if ((bits & 0x2000000L) == 0L) {
/* 7623 */           Optional<String> iconOptional = instance.icon();
/* 7624 */           if (iconOptional.isPresent()) {
/* 7625 */             icon(iconOptional);
/*      */           }
/* 7627 */           bits |= 0x2000000L;
/*      */         } 
/* 7629 */         if ((bits & 0x4000000L) == 0L) {
/* 7630 */           Optional<String> descriptionOptional = instance.description();
/* 7631 */           if (descriptionOptional.isPresent()) {
/* 7632 */             description(descriptionOptional);
/*      */           }
/* 7634 */           bits |= 0x4000000L;
/*      */         } 
/* 7636 */         if ((bits & 0x10L) == 0L) {
/* 7637 */           afkChannelId(instance.afkChannelId());
/* 7638 */           bits |= 0x10L;
/*      */         } 
/* 7640 */         if ((bits & 0x20L) == 0L) {
/* 7641 */           ownerId(instance.ownerId());
/* 7642 */           bits |= 0x20L;
/*      */         } 
/* 7644 */         if ((bits & 0x40L) == 0L) {
/* 7645 */           addAllFeatures(instance.features());
/* 7646 */           bits |= 0x40L;
/*      */         } 
/* 7648 */         if ((bits & 0x80L) == 0L) {
/* 7649 */           maxMembers(instance.maxMembers());
/* 7650 */           bits |= 0x80L;
/*      */         } 
/* 7652 */         if ((bits & 0x100L) == 0L) {
/* 7653 */           permissions(instance.permissions());
/* 7654 */           bits |= 0x100L;
/*      */         } 
/* 7656 */         if ((bits & 0x200L) == 0L) {
/* 7657 */           publicUpdatesChannelId(instance.publicUpdatesChannelId());
/* 7658 */           bits |= 0x200L;
/*      */         } 
/* 7660 */         if ((bits & 0x400L) == 0L) {
/* 7661 */           id(instance.id());
/* 7662 */           bits |= 0x400L;
/*      */         } 
/* 7664 */         if ((bits & 0x8000000L) == 0L) {
/* 7665 */           safetyAlertsChannelId(instance.safetyAlertsChannelId());
/* 7666 */           bits |= 0x8000000L;
/*      */         } 
/* 7668 */         if ((bits & 0x10000000L) == 0L) {
/* 7669 */           systemChannelId(instance.systemChannelId());
/* 7670 */           bits |= 0x10000000L;
/*      */         } 
/* 7672 */         if ((bits & 0x20000000L) == 0L) {
/* 7673 */           preferredLocale(instance.preferredLocale());
/* 7674 */           bits |= 0x20000000L;
/*      */         } 
/* 7676 */         if ((bits & 0x40000000L) == 0L) {
/* 7677 */           owner(instance.owner());
/* 7678 */           bits |= 0x40000000L;
/*      */         } 
/* 7680 */         if ((bits & 0x800L) == 0L) {
/* 7681 */           approximateMemberCount(instance.approximateMemberCount());
/* 7682 */           bits |= 0x800L;
/*      */         } 
/* 7684 */         if ((bits & 0x80000000L) == 0L) {
/* 7685 */           Optional<String> discoverySplashOptional = instance.discoverySplash();
/* 7686 */           if (discoverySplashOptional.isPresent()) {
/* 7687 */             discoverySplash(discoverySplashOptional);
/*      */           }
/* 7689 */           bits |= 0x80000000L;
/*      */         } 
/* 7691 */         if ((bits & 0x100000000L) == 0L) {
/* 7692 */           defaultMessageNotifications(instance.defaultMessageNotifications());
/* 7693 */           bits |= 0x100000000L;
/*      */         } 
/* 7695 */         if ((bits & 0x200000000L) == 0L) {
/* 7696 */           maxPresences(instance.maxPresences());
/* 7697 */           bits |= 0x200000000L;
/*      */         } 
/* 7699 */         if ((bits & 0x400000000L) == 0L) {
/* 7700 */           welcomeScreen(instance.welcomeScreen());
/* 7701 */           bits |= 0x400000000L;
/*      */         } 
/* 7703 */         if ((bits & 0x1000L) == 0L) {
/* 7704 */           large(instance.large());
/* 7705 */           bits |= 0x1000L;
/*      */         } 
/* 7707 */         if ((bits & 0x2000L) == 0L) {
/* 7708 */           rulesChannelId(instance.rulesChannelId());
/* 7709 */           bits |= 0x2000L;
/*      */         } 
/* 7711 */         if ((bits & 0x800000000L) == 0L) {
/* 7712 */           nsfw(instance.nsfw());
/* 7713 */           bits |= 0x800000000L;
/*      */         } 
/* 7715 */         if ((bits & 0x4000L) == 0L) {
/* 7716 */           joinedAt(instance.joinedAt());
/* 7717 */           bits |= 0x4000L;
/*      */         } 
/* 7719 */         if ((bits & 0x1000000000L) == 0L) {
/* 7720 */           memberCount(instance.memberCount());
/* 7721 */           bits |= 0x1000000000L;
/*      */         } 
/* 7723 */         if ((bits & 0x8000L) == 0L) {
/* 7724 */           widgetChannelId(instance.widgetChannelId());
/* 7725 */           bits |= 0x8000L;
/*      */         } 
/* 7727 */         if ((bits & 0x2000000000L) == 0L) {
/* 7728 */           Optional<String> bannerOptional = instance.banner();
/* 7729 */           if (bannerOptional.isPresent()) {
/* 7730 */             banner(bannerOptional);
/*      */           }
/* 7732 */           bits |= 0x2000000000L;
/*      */         } 
/* 7734 */         if ((bits & 0x10000L) == 0L) {
/* 7735 */           widgetEnabled(instance.widgetEnabled());
/* 7736 */           bits |= 0x10000L;
/*      */         } 
/* 7738 */         if ((bits & 0x4000000000L) == 0L) {
/* 7739 */           embedChannelId(instance.embedChannelId());
/* 7740 */           bits |= 0x4000000000L;
/*      */         } 
/* 7742 */         if ((bits & 0x20000L) == 0L) {
/* 7743 */           OptionalInt systemChannelFlagsOptional = instance.systemChannelFlags();
/* 7744 */           if (systemChannelFlagsOptional.isPresent()) {
/* 7745 */             systemChannelFlags(systemChannelFlagsOptional);
/*      */           }
/* 7747 */           bits |= 0x20000L;
/*      */         } 
/* 7749 */         if ((bits & 0x8000000000L) == 0L) {
/* 7750 */           maxVideoChannelUsers(instance.maxVideoChannelUsers());
/* 7751 */           bits |= 0x8000000000L;
/*      */         } 
/* 7753 */         if ((bits & 0x10000000000L) == 0L) {
/* 7754 */           nsfwLevel(instance.nsfwLevel());
/* 7755 */           bits |= 0x10000000000L;
/*      */         } 
/* 7757 */         if ((bits & 0x40000L) == 0L) {
/* 7758 */           name(instance.name());
/* 7759 */           bits |= 0x40000L;
/*      */         } 
/* 7761 */         if ((bits & 0x80000L) == 0L) {
/* 7762 */           premiumSubscriptionCount(instance.premiumSubscriptionCount());
/* 7763 */           bits |= 0x80000L;
/*      */         } 
/* 7765 */         if ((bits & 0x20000000000L) == 0L) {
/* 7766 */           embedEnabled(instance.embedEnabled());
/* 7767 */           bits |= 0x20000000000L;
/*      */         } 
/* 7769 */         if ((bits & 0x100000L) == 0L) {
/* 7770 */           approximatePresenceCount(instance.approximatePresenceCount());
/* 7771 */           bits |= 0x100000L;
/*      */         } 
/* 7773 */         if ((bits & 0x200000L) == 0L) {
/* 7774 */           applicationId(instance.applicationId());
/* 7775 */           bits |= 0x200000L;
/*      */         } 
/* 7777 */         if ((bits & 0x400000L) == 0L) {
/* 7778 */           region(instance.region());
/* 7779 */           bits |= 0x400000L;
/*      */         } 
/* 7781 */         if ((bits & 0x40000000000L) == 0L) {
/* 7782 */           mfaLevel(instance.mfaLevel());
/* 7783 */           bits |= 0x40000000000L;
/*      */         } 
/* 7785 */         if ((bits & 0x80000000000L) == 0L) {
/* 7786 */           Optional<String> splashOptional = instance.splash();
/* 7787 */           if (splashOptional.isPresent()) {
/* 7788 */             splash(splashOptional);
/*      */           }
/* 7790 */           bits |= 0x80000000000L;
/*      */         } 
/*      */       } 
/* 7793 */       if (object instanceof GuildNsfwLevelField) {
/* 7794 */         GuildNsfwLevelField instance = (GuildNsfwLevelField)object;
/* 7795 */         if ((bits & 0x10000000000L) == 0L) {
/* 7796 */           nsfwLevel(instance.nsfwLevel());
/* 7797 */           bits |= 0x10000000000L;
/*      */         } 
/*      */       } 
/* 7800 */       if (object instanceof GuildVerificationLevelField) {
/* 7801 */         GuildVerificationLevelField instance = (GuildVerificationLevelField)object;
/* 7802 */         if ((bits & 0x8L) == 0L) {
/* 7803 */           verificationLevel(instance.verificationLevel());
/* 7804 */           bits |= 0x8L;
/*      */         } 
/*      */       } 
/* 7807 */       if (object instanceof GuildData) {
/* 7808 */         GuildData instance = (GuildData)object;
/* 7809 */         if ((bits & 0x1L) == 0L) {
/* 7810 */           unavailable(instance.unavailable());
/* 7811 */           bits |= 0x1L;
/*      */         } 
/* 7813 */         if ((bits & 0x2L) == 0L) {
/* 7814 */           afkTimeout(instance.afkTimeout());
/* 7815 */           bits |= 0x2L;
/*      */         } 
/* 7817 */         if ((bits & 0x4L) == 0L) {
/* 7818 */           premiumTier(instance.premiumTier());
/* 7819 */           bits |= 0x4L;
/*      */         } 
/* 7821 */         if ((bits & 0x8L) == 0L) {
/* 7822 */           verificationLevel(instance.verificationLevel());
/* 7823 */           bits |= 0x8L;
/*      */         } 
/* 7825 */         if ((bits & 0x10L) == 0L) {
/* 7826 */           afkChannelId(instance.afkChannelId());
/* 7827 */           bits |= 0x10L;
/*      */         } 
/* 7829 */         if ((bits & 0x20L) == 0L) {
/* 7830 */           ownerId(instance.ownerId());
/* 7831 */           bits |= 0x20L;
/*      */         } 
/* 7833 */         if ((bits & 0x40L) == 0L) {
/* 7834 */           addAllFeatures(instance.features());
/* 7835 */           bits |= 0x40L;
/*      */         } 
/* 7837 */         if ((bits & 0x80L) == 0L) {
/* 7838 */           maxMembers(instance.maxMembers());
/* 7839 */           bits |= 0x80L;
/*      */         } 
/* 7841 */         if ((bits & 0x100L) == 0L) {
/* 7842 */           permissions(instance.permissions());
/* 7843 */           bits |= 0x100L;
/*      */         } 
/* 7845 */         members(instance.members());
/* 7846 */         if ((bits & 0x200L) == 0L) {
/* 7847 */           publicUpdatesChannelId(instance.publicUpdatesChannelId());
/* 7848 */           bits |= 0x200L;
/*      */         } 
/* 7850 */         stickers(instance.stickers());
/* 7851 */         if ((bits & 0x400L) == 0L) {
/* 7852 */           id(instance.id());
/* 7853 */           bits |= 0x400L;
/*      */         } 
/* 7855 */         if ((bits & 0x800L) == 0L) {
/* 7856 */           approximateMemberCount(instance.approximateMemberCount());
/* 7857 */           bits |= 0x800L;
/*      */         } 
/* 7859 */         if ((bits & 0x1000L) == 0L) {
/* 7860 */           large(instance.large());
/* 7861 */           bits |= 0x1000L;
/*      */         } 
/* 7863 */         if ((bits & 0x2000L) == 0L) {
/* 7864 */           rulesChannelId(instance.rulesChannelId());
/* 7865 */           bits |= 0x2000L;
/*      */         } 
/* 7867 */         if ((bits & 0x4000L) == 0L) {
/* 7868 */           joinedAt(instance.joinedAt());
/* 7869 */           bits |= 0x4000L;
/*      */         } 
/* 7871 */         if ((bits & 0x8000L) == 0L) {
/* 7872 */           widgetChannelId(instance.widgetChannelId());
/* 7873 */           bits |= 0x8000L;
/*      */         } 
/* 7875 */         if ((bits & 0x10000L) == 0L) {
/* 7876 */           widgetEnabled(instance.widgetEnabled());
/* 7877 */           bits |= 0x10000L;
/*      */         } 
/* 7879 */         if ((bits & 0x20000L) == 0L) {
/* 7880 */           OptionalInt systemChannelFlagsOptional = instance.systemChannelFlags();
/* 7881 */           if (systemChannelFlagsOptional.isPresent()) {
/* 7882 */             systemChannelFlags(systemChannelFlagsOptional);
/*      */           }
/* 7884 */           bits |= 0x20000L;
/*      */         } 
/* 7886 */         channels(instance.channels());
/* 7887 */         if ((bits & 0x40000L) == 0L) {
/* 7888 */           name(instance.name());
/* 7889 */           bits |= 0x40000L;
/*      */         } 
/* 7891 */         if ((bits & 0x80000L) == 0L) {
/* 7892 */           premiumSubscriptionCount(instance.premiumSubscriptionCount());
/* 7893 */           bits |= 0x80000L;
/*      */         } 
/* 7895 */         if ((bits & 0x100000L) == 0L) {
/* 7896 */           approximatePresenceCount(instance.approximatePresenceCount());
/* 7897 */           bits |= 0x100000L;
/*      */         } 
/* 7899 */         if ((bits & 0x200000L) == 0L) {
/* 7900 */           applicationId(instance.applicationId());
/* 7901 */           bits |= 0x200000L;
/*      */         } 
/* 7903 */         if ((bits & 0x400000L) == 0L) {
/* 7904 */           region(instance.region());
/* 7905 */           bits |= 0x400000L;
/*      */         } 
/* 7907 */         if ((bits & 0x800000L) == 0L) {
/* 7908 */           explicitContentFilter(instance.explicitContentFilter());
/* 7909 */           bits |= 0x800000L;
/*      */         } 
/* 7911 */         if ((bits & 0x1000000L) == 0L) {
/* 7912 */           Optional<String> vanityUrlCodeOptional = instance.vanityUrlCode();
/* 7913 */           if (vanityUrlCodeOptional.isPresent()) {
/* 7914 */             vanityUrlCode(vanityUrlCodeOptional);
/*      */           }
/* 7916 */           bits |= 0x1000000L;
/*      */         } 
/* 7918 */         roles(instance.roles());
/* 7919 */         if ((bits & 0x2000000L) == 0L) {
/* 7920 */           Optional<String> iconOptional = instance.icon();
/* 7921 */           if (iconOptional.isPresent()) {
/* 7922 */             icon(iconOptional);
/*      */           }
/* 7924 */           bits |= 0x2000000L;
/*      */         } 
/* 7926 */         if ((bits & 0x4000000L) == 0L) {
/* 7927 */           Optional<String> descriptionOptional = instance.description();
/* 7928 */           if (descriptionOptional.isPresent()) {
/* 7929 */             description(descriptionOptional);
/*      */           }
/* 7931 */           bits |= 0x4000000L;
/*      */         } 
/* 7933 */         if ((bits & 0x8000000L) == 0L) {
/* 7934 */           safetyAlertsChannelId(instance.safetyAlertsChannelId());
/* 7935 */           bits |= 0x8000000L;
/*      */         } 
/* 7937 */         if ((bits & 0x10000000L) == 0L) {
/* 7938 */           systemChannelId(instance.systemChannelId());
/* 7939 */           bits |= 0x10000000L;
/*      */         } 
/* 7941 */         if ((bits & 0x20000000L) == 0L) {
/* 7942 */           preferredLocale(instance.preferredLocale());
/* 7943 */           bits |= 0x20000000L;
/*      */         } 
/* 7945 */         if ((bits & 0x40000000L) == 0L) {
/* 7946 */           owner(instance.owner());
/* 7947 */           bits |= 0x40000000L;
/*      */         } 
/* 7949 */         emojis(instance.emojis());
/* 7950 */         if ((bits & 0x80000000L) == 0L) {
/* 7951 */           Optional<String> discoverySplashOptional = instance.discoverySplash();
/* 7952 */           if (discoverySplashOptional.isPresent()) {
/* 7953 */             discoverySplash(discoverySplashOptional);
/*      */           }
/* 7955 */           bits |= 0x80000000L;
/*      */         } 
/* 7957 */         if ((bits & 0x100000000L) == 0L) {
/* 7958 */           defaultMessageNotifications(instance.defaultMessageNotifications());
/* 7959 */           bits |= 0x100000000L;
/*      */         } 
/* 7961 */         if ((bits & 0x200000000L) == 0L) {
/* 7962 */           maxPresences(instance.maxPresences());
/* 7963 */           bits |= 0x200000000L;
/*      */         } 
/* 7965 */         if ((bits & 0x400000000L) == 0L) {
/* 7966 */           welcomeScreen(instance.welcomeScreen());
/* 7967 */           bits |= 0x400000000L;
/*      */         } 
/* 7969 */         if ((bits & 0x800000000L) == 0L) {
/* 7970 */           nsfw(instance.nsfw());
/* 7971 */           bits |= 0x800000000L;
/*      */         } 
/* 7973 */         if ((bits & 0x1000000000L) == 0L) {
/* 7974 */           memberCount(instance.memberCount());
/* 7975 */           bits |= 0x1000000000L;
/*      */         } 
/* 7977 */         if ((bits & 0x2000000000L) == 0L) {
/* 7978 */           Optional<String> bannerOptional = instance.banner();
/* 7979 */           if (bannerOptional.isPresent()) {
/* 7980 */             banner(bannerOptional);
/*      */           }
/* 7982 */           bits |= 0x2000000000L;
/*      */         } 
/* 7984 */         if ((bits & 0x4000000000L) == 0L) {
/* 7985 */           embedChannelId(instance.embedChannelId());
/* 7986 */           bits |= 0x4000000000L;
/*      */         } 
/* 7988 */         if ((bits & 0x8000000000L) == 0L) {
/* 7989 */           maxVideoChannelUsers(instance.maxVideoChannelUsers());
/* 7990 */           bits |= 0x8000000000L;
/*      */         } 
/* 7992 */         if ((bits & 0x10000000000L) == 0L) {
/* 7993 */           nsfwLevel(instance.nsfwLevel());
/* 7994 */           bits |= 0x10000000000L;
/*      */         } 
/* 7996 */         if ((bits & 0x20000000000L) == 0L) {
/* 7997 */           embedEnabled(instance.embedEnabled());
/* 7998 */           bits |= 0x20000000000L;
/*      */         } 
/* 8000 */         if ((bits & 0x40000000000L) == 0L) {
/* 8001 */           mfaLevel(instance.mfaLevel());
/* 8002 */           bits |= 0x40000000000L;
/*      */         } 
/* 8004 */         if ((bits & 0x80000000000L) == 0L) {
/* 8005 */           Optional<String> splashOptional = instance.splash();
/* 8006 */           if (splashOptional.isPresent()) {
/* 8007 */             splash(splashOptional);
/*      */           }
/* 8009 */           bits |= 0x80000000000L;
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*      */     public Builder id(String value) {
/* 8015 */       this.id_id = Id.of(value);
/* 8016 */       return this;
/*      */     }
/*      */     
/*      */     public Builder id(long value) {
/* 8020 */       this.id_id = Id.of(value);
/* 8021 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("id")
/*      */     public Builder id(Id value) {
/* 8026 */       this.id_id = value;
/* 8027 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("name")
/*      */     public final Builder name(String name) {
/* 8037 */       this.name = Objects.<String>requireNonNull(name, "name");
/* 8038 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 8039 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder icon(String icon) {
/* 8048 */       this.icon = Objects.<String>requireNonNull(icon, "icon");
/* 8049 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("icon")
/*      */     public final Builder icon(Optional<String> icon) {
/* 8059 */       this.icon = icon.orElse(null);
/* 8060 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder splash(String splash) {
/* 8069 */       this.splash = Objects.<String>requireNonNull(splash, "splash");
/* 8070 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("splash")
/*      */     public final Builder splash(Optional<String> splash) {
/* 8080 */       this.splash = splash.orElse(null);
/* 8081 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder discoverySplash(String discoverySplash) {
/* 8090 */       this.discoverySplash = Objects.<String>requireNonNull(discoverySplash, "discoverySplash");
/* 8091 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("discovery_splash")
/*      */     public final Builder discoverySplash(Optional<String> discoverySplash) {
/* 8101 */       this.discoverySplash = discoverySplash.orElse(null);
/* 8102 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("owner")
/*      */     public Builder owner(Possible<Boolean> value) {
/* 8107 */       this.owner_possible = value;
/* 8108 */       return this;
/*      */     }
/*      */     
/*      */     public Builder owner(Boolean value) {
/* 8112 */       this.owner_possible = Possible.of(value);
/* 8113 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("permissions")
/*      */     public Builder permissions(Possible<Long> value) {
/* 8118 */       this.permissions_possible = value;
/* 8119 */       return this;
/*      */     }
/*      */     
/*      */     public Builder permissions(Long value) {
/* 8123 */       this.permissions_possible = Possible.of(value);
/* 8124 */       return this;
/*      */     }
/*      */     
/*      */     public Builder afkChannelId(String value) {
/* 8128 */       this.afkChannelId_optional = Optional.of(Id.of(value));
/* 8129 */       return this;
/*      */     }
/*      */     
/*      */     public Builder afkChannelId(long value) {
/* 8133 */       this.afkChannelId_optional = Optional.of(Id.of(value));
/* 8134 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("afk_channel_id")
/*      */     public Builder afkChannelId(Optional<Id> value) {
/* 8139 */       this.afkChannelId_optional = value;
/* 8140 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("embed_enabled")
/*      */     public Builder embedEnabled(Possible<Boolean> value) {
/* 8145 */       this.embedEnabled_possible = value;
/* 8146 */       return this;
/*      */     }
/*      */     
/*      */     public Builder embedEnabled(Boolean value) {
/* 8150 */       this.embedEnabled_possible = Possible.of(value);
/* 8151 */       return this;
/*      */     }
/*      */     
/*      */     public Builder embedChannelId(String value) {
/* 8155 */       this.embedChannelId_possible = Possible.of(Optional.of(Id.of(value)));
/* 8156 */       return this;
/*      */     }
/*      */     
/*      */     public Builder embedChannelId(long value) {
/* 8160 */       this.embedChannelId_possible = Possible.of(Optional.of(Id.of(value)));
/* 8161 */       return this;
/*      */     }
/*      */     
/*      */     public Builder embedChannelId(Id value) {
/* 8165 */       this.embedChannelId_possible = Possible.of(Optional.of(value));
/* 8166 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("embed_channel_id")
/*      */     public Builder embedChannelId(Possible<Optional<Id>> value) {
/* 8171 */       this.embedChannelId_possible = value;
/* 8172 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addFeature(String element) {
/* 8181 */       this.features.add(Objects.<String>requireNonNull(element, "features element"));
/* 8182 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addFeatures(String... elements) {
/* 8191 */       for (String element : elements) {
/* 8192 */         this.features.add(Objects.<String>requireNonNull(element, "features element"));
/*      */       }
/* 8194 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("features")
/*      */     public final Builder features(Iterable<String> elements) {
/* 8205 */       this.features.clear();
/* 8206 */       return addAllFeatures(elements);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addAllFeatures(Iterable<String> elements) {
/* 8215 */       for (String element : elements) {
/* 8216 */         this.features.add(Objects.<String>requireNonNull(element, "features element"));
/*      */       }
/* 8218 */       return this;
/*      */     }
/*      */     
/*      */     public Builder applicationId(String value) {
/* 8222 */       this.applicationId_optional = Optional.of(Id.of(value));
/* 8223 */       return this;
/*      */     }
/*      */     
/*      */     public Builder applicationId(long value) {
/* 8227 */       this.applicationId_optional = Optional.of(Id.of(value));
/* 8228 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("application_id")
/*      */     public Builder applicationId(Optional<Id> value) {
/* 8233 */       this.applicationId_optional = value;
/* 8234 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("widget_enabled")
/*      */     public Builder widgetEnabled(Possible<Boolean> value) {
/* 8239 */       this.widgetEnabled_possible = value;
/* 8240 */       return this;
/*      */     }
/*      */     
/*      */     public Builder widgetEnabled(Boolean value) {
/* 8244 */       this.widgetEnabled_possible = Possible.of(value);
/* 8245 */       return this;
/*      */     }
/*      */     
/*      */     public Builder widgetChannelId(String value) {
/* 8249 */       this.widgetChannelId_possible = Possible.of(Optional.of(Id.of(value)));
/* 8250 */       return this;
/*      */     }
/*      */     
/*      */     public Builder widgetChannelId(long value) {
/* 8254 */       this.widgetChannelId_possible = Possible.of(Optional.of(Id.of(value)));
/* 8255 */       return this;
/*      */     }
/*      */     
/*      */     public Builder widgetChannelId(Id value) {
/* 8259 */       this.widgetChannelId_possible = Possible.of(Optional.of(value));
/* 8260 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("widget_channel_id")
/*      */     public Builder widgetChannelId(Possible<Optional<Id>> value) {
/* 8265 */       this.widgetChannelId_possible = value;
/* 8266 */       return this;
/*      */     }
/*      */     
/*      */     public Builder systemChannelId(String value) {
/* 8270 */       this.systemChannelId_optional = Optional.of(Id.of(value));
/* 8271 */       return this;
/*      */     }
/*      */     
/*      */     public Builder systemChannelId(long value) {
/* 8275 */       this.systemChannelId_optional = Optional.of(Id.of(value));
/* 8276 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("system_channel_id")
/*      */     public Builder systemChannelId(Optional<Id> value) {
/* 8281 */       this.systemChannelId_optional = value;
/* 8282 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder systemChannelFlags(int systemChannelFlags) {
/* 8291 */       this.systemChannelFlags = Integer.valueOf(systemChannelFlags);
/* 8292 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("system_channel_flags")
/*      */     public final Builder systemChannelFlags(OptionalInt systemChannelFlags) {
/* 8302 */       this.systemChannelFlags = systemChannelFlags.isPresent() ? Integer.valueOf(systemChannelFlags.getAsInt()) : null;
/* 8303 */       return this;
/*      */     }
/*      */     
/*      */     public Builder rulesChannelId(String value) {
/* 8307 */       this.rulesChannelId_optional = Optional.of(Id.of(value));
/* 8308 */       return this;
/*      */     }
/*      */     
/*      */     public Builder rulesChannelId(long value) {
/* 8312 */       this.rulesChannelId_optional = Optional.of(Id.of(value));
/* 8313 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("rules_channel_id")
/*      */     public Builder rulesChannelId(Optional<Id> value) {
/* 8318 */       this.rulesChannelId_optional = value;
/* 8319 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("max_presences")
/*      */     public Builder maxPresences(Possible<Optional<Integer>> value) {
/* 8324 */       this.maxPresences_possible = value;
/* 8325 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder maxPresences(@Nullable Integer value) {
/* 8330 */       this.maxPresences_possible = Possible.of(Optional.ofNullable(value));
/* 8331 */       return this;
/*      */     }
/*      */     
/*      */     public Builder maxPresencesOrNull(@Nullable Integer value) {
/* 8335 */       this.maxPresences_possible = Possible.of(Optional.ofNullable(value));
/* 8336 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("max_members")
/*      */     public Builder maxMembers(Possible<Integer> value) {
/* 8341 */       this.maxMembers_possible = value;
/* 8342 */       return this;
/*      */     }
/*      */     
/*      */     public Builder maxMembers(Integer value) {
/* 8346 */       this.maxMembers_possible = Possible.of(value);
/* 8347 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder vanityUrlCode(String vanityUrlCode) {
/* 8356 */       this.vanityUrlCode = Objects.<String>requireNonNull(vanityUrlCode, "vanityUrlCode");
/* 8357 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("vanity_url_code")
/*      */     public final Builder vanityUrlCode(Optional<String> vanityUrlCode) {
/* 8367 */       this.vanityUrlCode = vanityUrlCode.orElse(null);
/* 8368 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder description(String description) {
/* 8377 */       this.description = Objects.<String>requireNonNull(description, "description");
/* 8378 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("description")
/*      */     public final Builder description(Optional<String> description) {
/* 8388 */       this.description = description.orElse(null);
/* 8389 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder banner(String banner) {
/* 8398 */       this.banner = Objects.<String>requireNonNull(banner, "banner");
/* 8399 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("banner")
/*      */     public final Builder banner(Optional<String> banner) {
/* 8409 */       this.banner = banner.orElse(null);
/* 8410 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("premium_subscription_count")
/*      */     public Builder premiumSubscriptionCount(Possible<Integer> value) {
/* 8415 */       this.premiumSubscriptionCount_possible = value;
/* 8416 */       return this;
/*      */     }
/*      */     
/*      */     public Builder premiumSubscriptionCount(Integer value) {
/* 8420 */       this.premiumSubscriptionCount_possible = Possible.of(value);
/* 8421 */       return this;
/*      */     }
/*      */     
/*      */     public Builder publicUpdatesChannelId(String value) {
/* 8425 */       this.publicUpdatesChannelId_optional = Optional.of(Id.of(value));
/* 8426 */       return this;
/*      */     }
/*      */     
/*      */     public Builder publicUpdatesChannelId(long value) {
/* 8430 */       this.publicUpdatesChannelId_optional = Optional.of(Id.of(value));
/* 8431 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("public_updates_channel_id")
/*      */     public Builder publicUpdatesChannelId(Optional<Id> value) {
/* 8436 */       this.publicUpdatesChannelId_optional = value;
/* 8437 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("max_video_channel_users")
/*      */     public Builder maxVideoChannelUsers(Possible<Integer> value) {
/* 8442 */       this.maxVideoChannelUsers_possible = value;
/* 8443 */       return this;
/*      */     }
/*      */     
/*      */     public Builder maxVideoChannelUsers(Integer value) {
/* 8447 */       this.maxVideoChannelUsers_possible = Possible.of(value);
/* 8448 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("approximate_member_count")
/*      */     public Builder approximateMemberCount(Possible<Integer> value) {
/* 8453 */       this.approximateMemberCount_possible = value;
/* 8454 */       return this;
/*      */     }
/*      */     
/*      */     public Builder approximateMemberCount(Integer value) {
/* 8458 */       this.approximateMemberCount_possible = Possible.of(value);
/* 8459 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("approximate_presence_count")
/*      */     public Builder approximatePresenceCount(Possible<Integer> value) {
/* 8464 */       this.approximatePresenceCount_possible = value;
/* 8465 */       return this;
/*      */     }
/*      */     
/*      */     public Builder approximatePresenceCount(Integer value) {
/* 8469 */       this.approximatePresenceCount_possible = Possible.of(value);
/* 8470 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("welcome_screen")
/*      */     public Builder welcomeScreen(Possible<WelcomeScreenData> value) {
/* 8475 */       this.welcomeScreen_possible = value;
/* 8476 */       return this;
/*      */     }
/*      */     
/*      */     public Builder welcomeScreen(WelcomeScreenData value) {
/* 8480 */       this.welcomeScreen_possible = Possible.of(value);
/* 8481 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("nsfw")
/*      */     public Builder nsfw(Possible<Boolean> value) {
/* 8486 */       this.nsfw_possible = value;
/* 8487 */       return this;
/*      */     }
/*      */     
/*      */     public Builder nsfw(Boolean value) {
/* 8491 */       this.nsfw_possible = Possible.of(value);
/* 8492 */       return this;
/*      */     }
/*      */     
/*      */     public Builder safetyAlertsChannelId(String value) {
/* 8496 */       this.safetyAlertsChannelId_optional = Optional.of(Id.of(value));
/* 8497 */       return this;
/*      */     }
/*      */     
/*      */     public Builder safetyAlertsChannelId(long value) {
/* 8501 */       this.safetyAlertsChannelId_optional = Optional.of(Id.of(value));
/* 8502 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("safety_alerts_channel_id")
/*      */     public Builder safetyAlertsChannelId(Optional<Id> value) {
/* 8507 */       this.safetyAlertsChannelId_optional = value;
/* 8508 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("verification_level")
/*      */     public final Builder verificationLevel(int verificationLevel) {
/* 8518 */       this.verificationLevel = verificationLevel;
/* 8519 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 8520 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("nsfw_level")
/*      */     public final Builder nsfwLevel(int nsfwLevel) {
/* 8530 */       this.nsfwLevel = nsfwLevel;
/* 8531 */       this.initBits &= 0xFFFFFFFFFFFFFFFBL;
/* 8532 */       return this;
/*      */     }
/*      */     
/*      */     public Builder ownerId(String value) {
/* 8536 */       this.ownerId_id = Id.of(value);
/* 8537 */       return this;
/*      */     }
/*      */     
/*      */     public Builder ownerId(long value) {
/* 8541 */       this.ownerId_id = Id.of(value);
/* 8542 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("owner_id")
/*      */     public Builder ownerId(Id value) {
/* 8547 */       this.ownerId_id = value;
/* 8548 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("region")
/*      */     public Builder region(Possible<Optional<String>> value) {
/* 8553 */       this.region_possible = value;
/* 8554 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder region(@Nullable String value) {
/* 8559 */       this.region_possible = Possible.of(Optional.ofNullable(value));
/* 8560 */       return this;
/*      */     }
/*      */     
/*      */     public Builder regionOrNull(@Nullable String value) {
/* 8564 */       this.region_possible = Possible.of(Optional.ofNullable(value));
/* 8565 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("afk_timeout")
/*      */     public final Builder afkTimeout(int afkTimeout) {
/* 8575 */       this.afkTimeout = afkTimeout;
/* 8576 */       this.initBits &= 0xFFFFFFFFFFFFFFF7L;
/* 8577 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("default_message_notifications")
/*      */     public final Builder defaultMessageNotifications(int defaultMessageNotifications) {
/* 8587 */       this.defaultMessageNotifications = defaultMessageNotifications;
/* 8588 */       this.initBits &= 0xFFFFFFFFFFFFFFEFL;
/* 8589 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("explicit_content_filter")
/*      */     public final Builder explicitContentFilter(int explicitContentFilter) {
/* 8599 */       this.explicitContentFilter = explicitContentFilter;
/* 8600 */       this.initBits &= 0xFFFFFFFFFFFFFFDFL;
/* 8601 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("mfa_level")
/*      */     public final Builder mfaLevel(int mfaLevel) {
/* 8611 */       this.mfaLevel = mfaLevel;
/* 8612 */       this.initBits &= 0xFFFFFFFFFFFFFFBFL;
/* 8613 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("premium_tier")
/*      */     public final Builder premiumTier(int premiumTier) {
/* 8623 */       this.premiumTier = premiumTier;
/* 8624 */       this.initBits &= 0xFFFFFFFFFFFFFF7FL;
/* 8625 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("preferred_locale")
/*      */     public final Builder preferredLocale(String preferredLocale) {
/* 8635 */       this.preferredLocale = Objects.<String>requireNonNull(preferredLocale, "preferredLocale");
/* 8636 */       this.initBits &= 0xFFFFFFFFFFFFFEFFL;
/* 8637 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("joined_at")
/*      */     public final Builder joinedAt(String joinedAt) {
/* 8647 */       this.joinedAt = Objects.<String>requireNonNull(joinedAt, "joinedAt");
/* 8648 */       this.initBits &= 0xFFFFFFFFFFFFFDFFL;
/* 8649 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("large")
/*      */     public final Builder large(boolean large) {
/* 8659 */       this.large = large;
/* 8660 */       this.initBits &= 0xFFFFFFFFFFFFFBFFL;
/* 8661 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("unavailable")
/*      */     public Builder unavailable(Possible<Boolean> value) {
/* 8666 */       this.unavailable_possible = value;
/* 8667 */       return this;
/*      */     }
/*      */     
/*      */     public Builder unavailable(Boolean value) {
/* 8671 */       this.unavailable_possible = Possible.of(value);
/* 8672 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("member_count")
/*      */     public final Builder memberCount(int memberCount) {
/* 8682 */       this.memberCount = memberCount;
/* 8683 */       this.initBits &= 0xFFFFFFFFFFFFF7FFL;
/* 8684 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addRole(long element) {
/* 8688 */       roles_getOrCreate().add(Long.valueOf(element));
/* 8689 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addRole(String element) {
/* 8693 */       roles_getOrCreate().add(Long.valueOf(Id.of(element).asLong()));
/* 8694 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addRole(Id element) {
/* 8698 */       roles_getOrCreate().add(Long.valueOf(element.asLong()));
/* 8699 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addAllRoles(List<Long> elements) {
/* 8703 */       roles_getOrCreate().addAll(elements);
/* 8704 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("roles")
/*      */     public Builder roles(List<Id> elements) {
/* 8709 */       this.roles_list = (List<Long>)elements.stream().map(Id::asLong).collect(Collectors.toList());
/* 8710 */       return this;
/*      */     }
/*      */     
/*      */     public Builder roles(Iterable<Id> elements) {
/* 8714 */       this
/*      */         
/* 8716 */         .roles_list = (List<Long>)StreamSupport.stream(elements.spliterator(), false).map(Id::asLong).collect(Collectors.toList());
/* 8717 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addEmoji(long element) {
/* 8721 */       emojis_getOrCreate().add(Long.valueOf(element));
/* 8722 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addEmoji(String element) {
/* 8726 */       emojis_getOrCreate().add(Long.valueOf(Id.of(element).asLong()));
/* 8727 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addEmoji(Id element) {
/* 8731 */       emojis_getOrCreate().add(Long.valueOf(element.asLong()));
/* 8732 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addAllEmojis(List<Long> elements) {
/* 8736 */       emojis_getOrCreate().addAll(elements);
/* 8737 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("emojis")
/*      */     public Builder emojis(List<Id> elements) {
/* 8742 */       this.emojis_list = (List<Long>)elements.stream().map(Id::asLong).collect(Collectors.toList());
/* 8743 */       return this;
/*      */     }
/*      */     
/*      */     public Builder emojis(Iterable<Id> elements) {
/* 8747 */       this
/*      */         
/* 8749 */         .emojis_list = (List<Long>)StreamSupport.stream(elements.spliterator(), false).map(Id::asLong).collect(Collectors.toList());
/* 8750 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addSticker(Id element) {
/* 8754 */       stickers_getOrCreate().add(element);
/* 8755 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addAllStickers(List<Id> elements) {
/* 8759 */       stickers_getOrCreate().addAll(elements);
/* 8760 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("stickers")
/*      */     public Builder stickers(Possible<List<Id>> elements) {
/* 8765 */       this.stickers_list = null;
/* 8766 */       elements.toOptional().ifPresent(e -> stickers_getOrCreate().addAll(e));
/* 8767 */       return this;
/*      */     }
/*      */     
/*      */     public Builder stickers(List<Id> elements) {
/* 8771 */       this.stickers_list = new ArrayList<>(elements);
/* 8772 */       return this;
/*      */     }
/*      */     
/*      */     public Builder stickers(Iterable<Id> elements) {
/* 8776 */       this.stickers_list = (List<Id>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 8777 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addMember(long element) {
/* 8781 */       members_getOrCreate().add(Long.valueOf(element));
/* 8782 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addMember(String element) {
/* 8786 */       members_getOrCreate().add(Long.valueOf(Id.of(element).asLong()));
/* 8787 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addMember(Id element) {
/* 8791 */       members_getOrCreate().add(Long.valueOf(element.asLong()));
/* 8792 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addAllMembers(List<Long> elements) {
/* 8796 */       members_getOrCreate().addAll(elements);
/* 8797 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("members")
/*      */     public Builder members(List<Id> elements) {
/* 8802 */       this.members_list = (List<Long>)elements.stream().map(Id::asLong).collect(Collectors.toList());
/* 8803 */       return this;
/*      */     }
/*      */     
/*      */     public Builder members(Iterable<Id> elements) {
/* 8807 */       this
/*      */         
/* 8809 */         .members_list = (List<Long>)StreamSupport.stream(elements.spliterator(), false).map(Id::asLong).collect(Collectors.toList());
/* 8810 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addChannel(long element) {
/* 8814 */       channels_getOrCreate().add(Long.valueOf(element));
/* 8815 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addChannel(String element) {
/* 8819 */       channels_getOrCreate().add(Long.valueOf(Id.of(element).asLong()));
/* 8820 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addChannel(Id element) {
/* 8824 */       channels_getOrCreate().add(Long.valueOf(element.asLong()));
/* 8825 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addAllChannels(List<Long> elements) {
/* 8829 */       channels_getOrCreate().addAll(elements);
/* 8830 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("channels")
/*      */     public Builder channels(List<Id> elements) {
/* 8835 */       this.channels_list = (List<Long>)elements.stream().map(Id::asLong).collect(Collectors.toList());
/* 8836 */       return this;
/*      */     }
/*      */     
/*      */     public Builder channels(Iterable<Id> elements) {
/* 8840 */       this
/*      */         
/* 8842 */         .channels_list = (List<Long>)StreamSupport.stream(elements.spliterator(), false).map(Id::asLong).collect(Collectors.toList());
/* 8843 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ImmutableGuildData build() {
/* 8852 */       if (this.initBits != 0L) {
/* 8853 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*      */       }
/* 8855 */       return new ImmutableGuildData(null, 
/*      */           
/* 8857 */           id_build(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 8862 */           owner_build(), 
/* 8863 */           permissions_build(), 
/* 8864 */           afkChannelId_build(), 
/* 8865 */           embedEnabled_build(), 
/* 8866 */           embedChannelId_build(), ImmutableGuildData
/* 8867 */           .createUnmodifiableList(true, (List)this.features), 
/* 8868 */           applicationId_build(), 
/* 8869 */           widgetEnabled_build(), 
/* 8870 */           widgetChannelId_build(), 
/* 8871 */           systemChannelId_build(), this.systemChannelFlags, 
/*      */           
/* 8873 */           rulesChannelId_build(), 
/* 8874 */           maxPresences_build(), 
/* 8875 */           maxMembers_build(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */           
/* 8879 */           premiumSubscriptionCount_build(), 
/* 8880 */           publicUpdatesChannelId_build(), 
/* 8881 */           maxVideoChannelUsers_build(), 
/* 8882 */           approximateMemberCount_build(), 
/* 8883 */           approximatePresenceCount_build(), 
/* 8884 */           welcomeScreen_build(), 
/* 8885 */           nsfw_build(), 
/* 8886 */           safetyAlertsChannelId_build(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */           
/* 8889 */           ownerId_build(), 
/* 8890 */           region_build(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.joinedAt, this.large, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 8899 */           unavailable_build(), this.memberCount, 
/*      */           
/* 8901 */           roles_build(), 
/* 8902 */           emojis_build(), 
/* 8903 */           stickers_build(), 
/* 8904 */           members_build(), 
/* 8905 */           channels_build());
/*      */     }
/*      */     
/*      */     private String formatRequiredAttributesMessage() {
/* 8909 */       List<String> attributes = new ArrayList<>();
/* 8910 */       if ((this.initBits & 0x1L) != 0L) attributes.add("name"); 
/* 8911 */       if ((this.initBits & 0x2L) != 0L) attributes.add("verificationLevel"); 
/* 8912 */       if ((this.initBits & 0x4L) != 0L) attributes.add("nsfwLevel"); 
/* 8913 */       if ((this.initBits & 0x8L) != 0L) attributes.add("afkTimeout"); 
/* 8914 */       if ((this.initBits & 0x10L) != 0L) attributes.add("defaultMessageNotifications"); 
/* 8915 */       if ((this.initBits & 0x20L) != 0L) attributes.add("explicitContentFilter"); 
/* 8916 */       if ((this.initBits & 0x40L) != 0L) attributes.add("mfaLevel"); 
/* 8917 */       if ((this.initBits & 0x80L) != 0L) attributes.add("premiumTier"); 
/* 8918 */       if ((this.initBits & 0x100L) != 0L) attributes.add("preferredLocale"); 
/* 8919 */       if ((this.initBits & 0x200L) != 0L) attributes.add("joinedAt"); 
/* 8920 */       if ((this.initBits & 0x400L) != 0L) attributes.add("large"); 
/* 8921 */       if ((this.initBits & 0x800L) != 0L) attributes.add("memberCount"); 
/* 8922 */       return "Cannot build GuildData, some of required attributes are not set " + attributes;
/*      */     }
/*      */     
/*      */     private Id id_build() {
/* 8926 */       return this.id_id;
/*      */     }
/*      */     
/*      */     private Possible<Boolean> owner_build() {
/* 8930 */       return this.owner_possible;
/*      */     }
/*      */     
/*      */     private Possible<Long> permissions_build() {
/* 8934 */       return this.permissions_possible;
/*      */     }
/*      */     
/*      */     private Optional<Id> afkChannelId_build() {
/* 8938 */       return this.afkChannelId_optional;
/*      */     }
/*      */     
/*      */     private Possible<Boolean> embedEnabled_build() {
/* 8942 */       return this.embedEnabled_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<Id>> embedChannelId_build() {
/* 8946 */       return this.embedChannelId_possible;
/*      */     }
/*      */     
/*      */     private Optional<Id> applicationId_build() {
/* 8950 */       return this.applicationId_optional;
/*      */     }
/*      */     
/*      */     private Possible<Boolean> widgetEnabled_build() {
/* 8954 */       return this.widgetEnabled_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<Id>> widgetChannelId_build() {
/* 8958 */       return this.widgetChannelId_possible;
/*      */     }
/*      */     
/*      */     private Optional<Id> systemChannelId_build() {
/* 8962 */       return this.systemChannelId_optional;
/*      */     }
/*      */     
/*      */     private Optional<Id> rulesChannelId_build() {
/* 8966 */       return this.rulesChannelId_optional;
/*      */     }
/*      */     
/*      */     private Possible<Optional<Integer>> maxPresences_build() {
/* 8970 */       return this.maxPresences_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> maxMembers_build() {
/* 8974 */       return this.maxMembers_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> premiumSubscriptionCount_build() {
/* 8978 */       return this.premiumSubscriptionCount_possible;
/*      */     }
/*      */     
/*      */     private Optional<Id> publicUpdatesChannelId_build() {
/* 8982 */       return this.publicUpdatesChannelId_optional;
/*      */     }
/*      */     
/*      */     private Possible<Integer> maxVideoChannelUsers_build() {
/* 8986 */       return this.maxVideoChannelUsers_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> approximateMemberCount_build() {
/* 8990 */       return this.approximateMemberCount_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> approximatePresenceCount_build() {
/* 8994 */       return this.approximatePresenceCount_possible;
/*      */     }
/*      */     
/*      */     private Possible<WelcomeScreenData> welcomeScreen_build() {
/* 8998 */       return this.welcomeScreen_possible;
/*      */     }
/*      */     
/*      */     private Possible<Boolean> nsfw_build() {
/* 9002 */       return this.nsfw_possible;
/*      */     }
/*      */     
/*      */     private Optional<Id> safetyAlertsChannelId_build() {
/* 9006 */       return this.safetyAlertsChannelId_optional;
/*      */     }
/*      */     
/*      */     private Id ownerId_build() {
/* 9010 */       return this.ownerId_id;
/*      */     }
/*      */     
/*      */     private Possible<Optional<String>> region_build() {
/* 9014 */       return this.region_possible;
/*      */     }
/*      */     
/*      */     private Possible<Boolean> unavailable_build() {
/* 9018 */       return this.unavailable_possible;
/*      */     }
/*      */     
/*      */     private List<Id> roles_build() {
/* 9022 */       return (List<Id>)roles_getOrCreate().stream().map(Id::of).collect(Collectors.toList());
/*      */     }
/*      */     
/*      */     private List<Long> roles_getOrCreate() {
/* 9026 */       if (this.roles_list == null) {
/* 9027 */         this.roles_list = new ArrayList<>();
/*      */       }
/* 9029 */       return this.roles_list;
/*      */     }
/*      */     
/*      */     private List<Id> emojis_build() {
/* 9033 */       return (List<Id>)emojis_getOrCreate().stream().map(Id::of).collect(Collectors.toList());
/*      */     }
/*      */     
/*      */     private List<Long> emojis_getOrCreate() {
/* 9037 */       if (this.emojis_list == null) {
/* 9038 */         this.emojis_list = new ArrayList<>();
/*      */       }
/* 9040 */       return this.emojis_list;
/*      */     }
/*      */     
/*      */     private Possible<List<Id>> stickers_build() {
/* 9044 */       return (this.stickers_list == null) ? Possible.absent() : 
/* 9045 */         Possible.of(this.stickers_list);
/*      */     }
/*      */     
/*      */     private List<Id> stickers_getOrCreate() {
/* 9049 */       if (this.stickers_list == null) {
/* 9050 */         this.stickers_list = new ArrayList<>();
/*      */       }
/* 9052 */       return this.stickers_list;
/*      */     }
/*      */     
/*      */     private List<Id> members_build() {
/* 9056 */       return (List<Id>)members_getOrCreate().stream().map(Id::of).collect(Collectors.toList());
/*      */     }
/*      */     
/*      */     private List<Long> members_getOrCreate() {
/* 9060 */       if (this.members_list == null) {
/* 9061 */         this.members_list = new ArrayList<>();
/*      */       }
/* 9063 */       return this.members_list;
/*      */     }
/*      */     
/*      */     private List<Id> channels_build() {
/* 9067 */       return (List<Id>)channels_getOrCreate().stream().map(Id::of).collect(Collectors.toList());
/*      */     }
/*      */     
/*      */     private List<Long> channels_getOrCreate() {
/* 9071 */       if (this.channels_list == null) {
/* 9072 */         this.channels_list = new ArrayList<>();
/*      */       }
/* 9074 */       return this.channels_list;
/*      */     }
/*      */     private Builder() {} }
/*      */   
/*      */   private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
/*      */     ArrayList<T> list;
/* 9080 */     if (iterable instanceof Collection) {
/* 9081 */       int size = ((Collection)iterable).size();
/* 9082 */       if (size == 0) return Collections.emptyList(); 
/* 9083 */       list = new ArrayList<>();
/*      */     } else {
/* 9085 */       list = new ArrayList<>();
/*      */     } 
/* 9087 */     for (T element : iterable) {
/* 9088 */       if (skipNulls && element == null)
/* 9089 */         continue;  if (checkNulls) Objects.requireNonNull(element, "element"); 
/* 9090 */       list.add(element);
/*      */     } 
/* 9092 */     return list;
/*      */   }
/*      */   
/*      */   private static <T> List<T> createUnmodifiableList(boolean clone, List<T> list) {
/* 9096 */     switch (list.size()) { case 0:
/* 9097 */         return Collections.emptyList();
/* 9098 */       case 1: return Collections.singletonList(list.get(0)); }
/*      */     
/* 9100 */     if (clone) {
/* 9101 */       return Collections.unmodifiableList(new ArrayList<>(list));
/*      */     }
/* 9103 */     if (list instanceof ArrayList) {
/* 9104 */       ((ArrayList)list).trimToSize();
/*      */     }
/* 9106 */     return Collections.unmodifiableList(list);
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableGuildData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */