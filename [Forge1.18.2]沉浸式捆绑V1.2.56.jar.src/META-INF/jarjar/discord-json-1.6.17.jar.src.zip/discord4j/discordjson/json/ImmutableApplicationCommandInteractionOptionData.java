/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.StreamSupport;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "ApplicationCommandInteractionOptionData", generator = "Immutables")
/*     */ public final class ImmutableApplicationCommandInteractionOptionData
/*     */   implements ApplicationCommandInteractionOptionData
/*     */ {
/*     */   private final String name;
/*     */   private final String value_value;
/*     */   private final boolean value_absent;
/*     */   private final int type;
/*     */   private final List<ApplicationCommandInteractionOptionData> options_value;
/*     */   private final boolean options_absent;
/*     */   private final Boolean focused_value;
/*     */   private final boolean focused_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private ImmutableApplicationCommandInteractionOptionData(String name, Possible<String> value, int type, Possible<List<ApplicationCommandInteractionOptionData>> options, Possible<Boolean> focused) {
/*  82 */     this.initShim = new InitShim(); this.name = Objects.<String>requireNonNull(name, "name"); Possible<String> value$impl = value; this.type = type; Possible<List<ApplicationCommandInteractionOptionData>> options$impl = options; Possible<Boolean> focused$impl = focused; this.value_value = value$impl.toOptional().orElse(null); this.value_absent = value$impl.isAbsent(); this.options_value = options$impl.toOptional().orElse(null); this.options_absent = options$impl.isAbsent(); this.focused_value = focused$impl.toOptional().orElse(null); this.focused_absent = focused$impl.isAbsent(); this.initShim = null; } private ImmutableApplicationCommandInteractionOptionData(ImmutableApplicationCommandInteractionOptionData original, String name, Possible<String> value, int type, Possible<List<ApplicationCommandInteractionOptionData>> options, Possible<Boolean> focused) { this.initShim = new InitShim(); this.name = name; Possible<String> value$impl = value; this.type = type; Possible<List<ApplicationCommandInteractionOptionData>> options$impl = options; Possible<Boolean> focused$impl = focused; this.value_value = value$impl.toOptional().orElse(null); this.value_absent = value$impl.isAbsent();
/*     */     this.options_value = options$impl.toOptional().orElse(null);
/*     */     this.options_absent = options$impl.isAbsent();
/*     */     this.focused_value = focused$impl.toOptional().orElse(null);
/*     */     this.focused_absent = focused$impl.isAbsent();
/*  87 */     this.initShim = null; } @Generated(from = "ApplicationCommandInteractionOptionData", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/*  88 */       return "Cannot build ApplicationCommandInteractionOptionData, attribute initializers form cycle " + attributes; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("name")
/*     */   public String name() {
/*  98 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("value")
/*     */   public Possible<String> value() {
/* 107 */     return this.value_absent ? Possible.absent() : Possible.of(this.value_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("type")
/*     */   public int type() {
/* 116 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("options")
/*     */   public Possible<List<ApplicationCommandInteractionOptionData>> options() {
/* 125 */     return this.options_absent ? Possible.absent() : 
/* 126 */       Possible.of(this.options_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("focused")
/*     */   public Possible<Boolean> focused() {
/* 135 */     return this.focused_absent ? Possible.absent() : Possible.of(this.focused_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableApplicationCommandInteractionOptionData withName(String value) {
/* 145 */     String newValue = Objects.<String>requireNonNull(value, "name");
/* 146 */     if (this.name.equals(newValue)) return this; 
/* 147 */     return new ImmutableApplicationCommandInteractionOptionData(this, newValue, value(), this.type, options(), focused());
/*     */   }
/*     */   
/*     */   public ImmutableApplicationCommandInteractionOptionData withValue(Possible<String> value) {
/* 151 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 152 */     return new ImmutableApplicationCommandInteractionOptionData(this, this.name, newValue, this.type, options(), focused());
/*     */   }
/*     */   
/*     */   public ImmutableApplicationCommandInteractionOptionData withValue(String value) {
/* 156 */     Possible<String> newValue = Possible.of(value);
/* 157 */     return new ImmutableApplicationCommandInteractionOptionData(this, this.name, newValue, this.type, options(), focused());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableApplicationCommandInteractionOptionData withType(int value) {
/* 167 */     if (this.type == value) return this; 
/* 168 */     return new ImmutableApplicationCommandInteractionOptionData(this, this.name, value(), value, options(), focused());
/*     */   }
/*     */   
/*     */   public ImmutableApplicationCommandInteractionOptionData withOptions(Possible<List<ApplicationCommandInteractionOptionData>> possible) {
/* 172 */     Possible<List<ApplicationCommandInteractionOptionData>> newValue = Objects.<Possible<List<ApplicationCommandInteractionOptionData>>>requireNonNull(possible);
/* 173 */     return new ImmutableApplicationCommandInteractionOptionData(this, this.name, value(), this.type, newValue, focused());
/*     */   }
/*     */   
/*     */   public ImmutableApplicationCommandInteractionOptionData withOptions(Iterable<ApplicationCommandInteractionOptionData> elements) {
/* 177 */     Possible<List<ApplicationCommandInteractionOptionData>> newValue = Possible.of(
/* 178 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/* 179 */     return new ImmutableApplicationCommandInteractionOptionData(this, this.name, value(), this.type, newValue, focused());
/*     */   }
/*     */   
/*     */   @SafeVarargs
/*     */   public final ImmutableApplicationCommandInteractionOptionData withOptions(ApplicationCommandInteractionOptionData... elements) {
/* 184 */     Possible<List<ApplicationCommandInteractionOptionData>> newValue = Possible.of(Arrays.asList(elements));
/* 185 */     return new ImmutableApplicationCommandInteractionOptionData(this, this.name, value(), this.type, newValue, focused());
/*     */   }
/*     */   
/*     */   public ImmutableApplicationCommandInteractionOptionData withFocused(Possible<Boolean> value) {
/* 189 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 190 */     return new ImmutableApplicationCommandInteractionOptionData(this, this.name, value(), this.type, options(), newValue);
/*     */   }
/*     */   
/*     */   public ImmutableApplicationCommandInteractionOptionData withFocused(Boolean value) {
/* 194 */     Possible<Boolean> newValue = Possible.of(value);
/* 195 */     return new ImmutableApplicationCommandInteractionOptionData(this, this.name, value(), this.type, options(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 204 */     if (this == another) return true; 
/* 205 */     return (another instanceof ImmutableApplicationCommandInteractionOptionData && 
/* 206 */       equalTo(0, (ImmutableApplicationCommandInteractionOptionData)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableApplicationCommandInteractionOptionData another) {
/* 210 */     return (this.name.equals(another.name) && 
/* 211 */       value().equals(another.value()) && this.type == another.type && 
/*     */       
/* 213 */       Objects.equals(this.options_value, another.options_value) && 
/* 214 */       focused().equals(another.focused()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 223 */     int h = 5381;
/* 224 */     h += (h << 5) + this.name.hashCode();
/* 225 */     h += (h << 5) + value().hashCode();
/* 226 */     h += (h << 5) + this.type;
/* 227 */     h += (h << 5) + Objects.hashCode(this.options_value);
/* 228 */     h += (h << 5) + focused().hashCode();
/* 229 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 238 */     return "ApplicationCommandInteractionOptionData{name=" + this.name + ", value=" + 
/*     */       
/* 240 */       value().toString() + ", type=" + this.type + ", options=" + 
/*     */       
/* 242 */       Objects.toString(this.options_value) + ", focused=" + 
/* 243 */       focused().toString() + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "ApplicationCommandInteractionOptionData", generator = "Immutables")
/*     */   static final class Json
/*     */     implements ApplicationCommandInteractionOptionData
/*     */   {
/*     */     String name;
/*     */ 
/*     */     
/* 258 */     Possible<String> value = Possible.absent();
/*     */     
/*     */     int type;
/*     */     
/*     */     boolean typeIsSet;
/* 263 */     Possible<List<ApplicationCommandInteractionOptionData>> options = Possible.absent();
/*     */ 
/*     */     
/* 266 */     Possible<Boolean> focused = Possible.absent();
/*     */     
/*     */     @JsonProperty("name")
/*     */     public void setName(String name) {
/* 270 */       this.name = name;
/*     */     }
/*     */     @JsonProperty("value")
/*     */     public void setValue(Possible<String> value) {
/* 274 */       this.value = value;
/*     */     }
/*     */     @JsonProperty("type")
/*     */     public void setType(int type) {
/* 278 */       this.type = type;
/* 279 */       this.typeIsSet = true;
/*     */     }
/*     */     @JsonProperty("options")
/*     */     public void setOptions(Possible<List<ApplicationCommandInteractionOptionData>> options) {
/* 283 */       this.options = options;
/*     */     }
/*     */     @JsonProperty("focused")
/*     */     public void setFocused(Possible<Boolean> focused) {
/* 287 */       this.focused = focused;
/*     */     }
/*     */     public String name() {
/* 290 */       throw new UnsupportedOperationException();
/*     */     } public Possible<String> value() {
/* 292 */       throw new UnsupportedOperationException();
/*     */     } public int type() {
/* 294 */       throw new UnsupportedOperationException();
/*     */     } public Possible<List<ApplicationCommandInteractionOptionData>> options() {
/* 296 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Boolean> focused() {
/* 298 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableApplicationCommandInteractionOptionData fromJson(Json json) {
/* 309 */     Builder builder = builder();
/* 310 */     if (json.name != null) {
/* 311 */       builder.name(json.name);
/*     */     }
/* 313 */     if (json.value != null) {
/* 314 */       builder.value(json.value);
/*     */     }
/* 316 */     if (json.typeIsSet) {
/* 317 */       builder.type(json.type);
/*     */     }
/* 319 */     if (json.options != null) {
/* 320 */       builder.options(json.options);
/*     */     }
/* 322 */     if (json.focused != null) {
/* 323 */       builder.focused(json.focused);
/*     */     }
/* 325 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableApplicationCommandInteractionOptionData of(String name, Possible<String> value, int type, Possible<List<ApplicationCommandInteractionOptionData>> options, Possible<Boolean> focused) {
/* 338 */     return new ImmutableApplicationCommandInteractionOptionData(name, value, type, options, focused);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableApplicationCommandInteractionOptionData copyOf(ApplicationCommandInteractionOptionData instance) {
/* 349 */     if (instance instanceof ImmutableApplicationCommandInteractionOptionData) {
/* 350 */       return (ImmutableApplicationCommandInteractionOptionData)instance;
/*     */     }
/* 352 */     return builder()
/* 353 */       .from(instance)
/* 354 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isValuePresent() {
/* 358 */     return !this.value_absent;
/*     */   }
/*     */   
/*     */   public String valueOrElse(String defaultValue) {
/* 362 */     return !this.value_absent ? this.value_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isOptionsPresent() {
/* 366 */     return !this.options_absent;
/*     */   }
/*     */   
/*     */   public List<ApplicationCommandInteractionOptionData> optionsOrElse(List<ApplicationCommandInteractionOptionData> defaultValue) {
/* 370 */     return !this.options_absent ? this.options_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isFocusedPresent() {
/* 374 */     return !this.focused_absent;
/*     */   }
/*     */   
/*     */   public Boolean focusedOrElse(Boolean defaultValue) {
/* 378 */     return !this.focused_absent ? this.focused_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 395 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "ApplicationCommandInteractionOptionData", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_NAME = 1L;
/*     */ 
/*     */     
/*     */     private static final long INIT_BIT_TYPE = 2L;
/*     */ 
/*     */     
/* 409 */     private long initBits = 3L;
/*     */     
/* 411 */     private Possible<String> value_possible = Possible.absent();
/* 412 */     private List<ApplicationCommandInteractionOptionData> options_list = null;
/* 413 */     private Possible<Boolean> focused_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String name;
/*     */ 
/*     */ 
/*     */     
/*     */     private int type;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(ApplicationCommandInteractionOptionData instance) {
/* 428 */       Objects.requireNonNull(instance, "instance");
/* 429 */       name(instance.name());
/* 430 */       value(instance.value());
/* 431 */       type(instance.type());
/* 432 */       options(instance.options());
/* 433 */       focused(instance.focused());
/* 434 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("name")
/*     */     public final Builder name(String name) {
/* 444 */       this.name = Objects.<String>requireNonNull(name, "name");
/* 445 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 446 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("value")
/*     */     public Builder value(Possible<String> value) {
/* 451 */       this.value_possible = value;
/* 452 */       return this;
/*     */     }
/*     */     
/*     */     public Builder value(String value) {
/* 456 */       this.value_possible = Possible.of(value);
/* 457 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("type")
/*     */     public final Builder type(int type) {
/* 467 */       this.type = type;
/* 468 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 469 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addOption(ApplicationCommandInteractionOptionData element) {
/* 473 */       options_getOrCreate().add(element);
/* 474 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addAllOptions(List<ApplicationCommandInteractionOptionData> elements) {
/* 478 */       options_getOrCreate().addAll(elements);
/* 479 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("options")
/*     */     public Builder options(Possible<List<ApplicationCommandInteractionOptionData>> elements) {
/* 484 */       this.options_list = null;
/* 485 */       elements.toOptional().ifPresent(e -> options_getOrCreate().addAll(e));
/* 486 */       return this;
/*     */     }
/*     */     
/*     */     public Builder options(List<ApplicationCommandInteractionOptionData> elements) {
/* 490 */       this.options_list = new ArrayList<>(elements);
/* 491 */       return this;
/*     */     }
/*     */     
/*     */     public Builder options(Iterable<ApplicationCommandInteractionOptionData> elements) {
/* 495 */       this.options_list = (List<ApplicationCommandInteractionOptionData>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 496 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("focused")
/*     */     public Builder focused(Possible<Boolean> value) {
/* 501 */       this.focused_possible = value;
/* 502 */       return this;
/*     */     }
/*     */     
/*     */     public Builder focused(Boolean value) {
/* 506 */       this.focused_possible = Possible.of(value);
/* 507 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableApplicationCommandInteractionOptionData build() {
/* 516 */       if (this.initBits != 0L) {
/* 517 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 519 */       return new ImmutableApplicationCommandInteractionOptionData(null, this.name, value_build(), this.type, options_build(), focused_build());
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 523 */       List<String> attributes = new ArrayList<>();
/* 524 */       if ((this.initBits & 0x1L) != 0L) attributes.add("name"); 
/* 525 */       if ((this.initBits & 0x2L) != 0L) attributes.add("type"); 
/* 526 */       return "Cannot build ApplicationCommandInteractionOptionData, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Possible<String> value_build() {
/* 530 */       return this.value_possible;
/*     */     }
/*     */     
/*     */     private Possible<List<ApplicationCommandInteractionOptionData>> options_build() {
/* 534 */       return (this.options_list == null) ? Possible.absent() : 
/* 535 */         Possible.of(this.options_list);
/*     */     }
/*     */     
/*     */     private List<ApplicationCommandInteractionOptionData> options_getOrCreate() {
/* 539 */       if (this.options_list == null) {
/* 540 */         this.options_list = new ArrayList<>();
/*     */       }
/* 542 */       return this.options_list;
/*     */     }
/*     */     
/*     */     private Possible<Boolean> focused_build() {
/* 546 */       return this.focused_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableApplicationCommandInteractionOptionData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */