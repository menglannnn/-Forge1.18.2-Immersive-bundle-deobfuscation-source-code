package discord4j.discordjson.json;

import com.fasterxml.jackson.annotation.JsonProperty;
import discord4j.discordjson.possible.Possible;
import java.util.List;

public interface MessageSendRequestBase {
  Possible<String> content();
  
  Possible<Boolean> tts();
  
  @JsonProperty("allowed_mentions")
  Possible<AllowedMentionsData> allowedMentions();
  
  @JsonProperty("message_reference")
  Possible<MessageReferenceData> messageReference();
  
  Possible<List<ComponentData>> components();
  
  Possible<List<EmbedData>> embeds();
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\MessageSendRequestBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */