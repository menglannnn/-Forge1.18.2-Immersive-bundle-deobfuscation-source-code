/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "PruneData", generator = "Immutables")
/*     */ public final class ImmutablePruneData
/*     */   implements PruneData
/*     */ {
/*     */   private final Integer pruned;
/*     */   
/*     */   private ImmutablePruneData(Optional<Integer> pruned) {
/*  26 */     this.pruned = pruned.orElse(null);
/*     */   }
/*     */   
/*     */   private ImmutablePruneData(ImmutablePruneData original, Integer pruned) {
/*  30 */     this.pruned = pruned;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("pruned")
/*     */   public Optional<Integer> pruned() {
/*  39 */     return Optional.ofNullable(this.pruned);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutablePruneData withPruned(int value) {
/*  48 */     Integer newValue = Integer.valueOf(value);
/*  49 */     if (Objects.equals(this.pruned, newValue)) return this; 
/*  50 */     return new ImmutablePruneData(this, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutablePruneData withPruned(Optional<Integer> optional) {
/*  60 */     Integer value = optional.orElse(null);
/*  61 */     if (Objects.equals(this.pruned, value)) return this; 
/*  62 */     return new ImmutablePruneData(this, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/*  71 */     if (this == another) return true; 
/*  72 */     return (another instanceof ImmutablePruneData && 
/*  73 */       equalTo(0, (ImmutablePruneData)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutablePruneData another) {
/*  77 */     return Objects.equals(this.pruned, another.pruned);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  86 */     int h = 5381;
/*  87 */     h += (h << 5) + Objects.hashCode(this.pruned);
/*  88 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  97 */     StringBuilder builder = new StringBuilder("PruneData{");
/*  98 */     if (this.pruned != null) {
/*  99 */       builder.append("pruned=").append(this.pruned);
/*     */     }
/* 101 */     return builder.append("}").toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "PruneData", generator = "Immutables")
/*     */   static final class Json
/*     */     implements PruneData
/*     */   {
/* 113 */     Optional<Integer> pruned = Optional.empty();
/*     */     @JsonProperty("pruned")
/*     */     public void setPruned(Optional<Integer> pruned) {
/* 116 */       this.pruned = pruned;
/*     */     }
/*     */     public Optional<Integer> pruned() {
/* 119 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutablePruneData fromJson(Json json) {
/* 130 */     Builder builder = builder();
/* 131 */     if (json.pruned != null) {
/* 132 */       builder.pruned(json.pruned);
/*     */     }
/* 134 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutablePruneData of(Optional<Integer> pruned) {
/* 143 */     return new ImmutablePruneData(pruned);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutablePruneData copyOf(PruneData instance) {
/* 154 */     if (instance instanceof ImmutablePruneData) {
/* 155 */       return (ImmutablePruneData)instance;
/*     */     }
/* 157 */     return builder()
/* 158 */       .from(instance)
/* 159 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 172 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "PruneData", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private Integer pruned;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Builder() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(PruneData instance) {
/* 197 */       Objects.requireNonNull(instance, "instance");
/* 198 */       Optional<Integer> prunedOptional = instance.pruned();
/* 199 */       if (prunedOptional.isPresent()) {
/* 200 */         pruned(prunedOptional);
/*     */       }
/* 202 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder pruned(int pruned) {
/* 211 */       this.pruned = Integer.valueOf(pruned);
/* 212 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("pruned")
/*     */     public final Builder pruned(Optional<Integer> pruned) {
/* 222 */       this.pruned = pruned.orElse(null);
/* 223 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutablePruneData build() {
/* 232 */       return new ImmutablePruneData(null, this.pruned);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutablePruneData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */