/*      */ package discord4j.discordjson.json;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*      */ import com.fasterxml.jackson.annotation.JsonCreator;
/*      */ import com.fasterxml.jackson.annotation.JsonProperty;
/*      */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*      */ import discord4j.discordjson.possible.Possible;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import java.util.Optional;
/*      */ import java.util.stream.Collectors;
/*      */ import java.util.stream.StreamSupport;
/*      */ import org.immutables.value.Generated;
/*      */ import reactor.util.annotation.Nullable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Generated(from = "GuildModifyRequest", generator = "Immutables")
/*      */ public final class ImmutableGuildModifyRequest
/*      */   implements GuildModifyRequest
/*      */ {
/*      */   private final String name_value;
/*      */   private final boolean name_absent;
/*      */   private final String region_value;
/*      */   private final boolean region_absent;
/*      */   private final Integer verificationLevel_value;
/*      */   private final boolean verificationLevel_absent;
/*      */   private final Integer defaultMessageNotifications_value;
/*      */   private final boolean defaultMessageNotifications_absent;
/*      */   private final Integer explicitContentFilter_value;
/*      */   private final boolean explicitContentFilter_absent;
/*      */   private final String afkChannelId_value;
/*      */   private final boolean afkChannelId_absent;
/*      */   private final Integer afkTimeout_value;
/*      */   private final boolean afkTimeout_absent;
/*      */   private final String icon_value;
/*      */   private final boolean icon_absent;
/*      */   private final String ownerId_value;
/*      */   private final boolean ownerId_absent;
/*      */   private final String splash_value;
/*      */   private final boolean splash_absent;
/*      */   private final String discoverySplash_value;
/*      */   private final boolean discoverySplash_absent;
/*      */   private final String banner_value;
/*      */   private final boolean banner_absent;
/*      */   private final String systemChannelId_value;
/*      */   private final boolean systemChannelId_absent;
/*      */   private final Integer systemChannelFlags_value;
/*      */   private final boolean systemChannelFlags_absent;
/*      */   private final String rulesChannelId_value;
/*      */   private final boolean rulesChannelId_absent;
/*      */   private final String publicUpdatesChannelId_value;
/*      */   private final boolean publicUpdatesChannelId_absent;
/*      */   private final String preferredLocale_value;
/*      */   private final boolean preferredLocale_absent;
/*      */   private final List<String> features_value;
/*      */   private final boolean features_absent;
/*      */   private final String description_value;
/*      */   private final boolean description_absent;
/*      */   private final String safetyAlertsChannelId_value;
/*      */   private final boolean safetyAlertsChannelId_absent;
/*      */   private static final byte STAGE_INITIALIZING = -1;
/*      */   private static final byte STAGE_UNINITIALIZED = 0;
/*      */   private static final byte STAGE_INITIALIZED = 1;
/*      */   
/*      */   private ImmutableGuildModifyRequest(Possible<String> name, Possible<Optional<String>> region, Possible<Optional<Integer>> verificationLevel, Possible<Optional<Integer>> defaultMessageNotifications, Possible<Optional<Integer>> explicitContentFilter, Possible<Optional<String>> afkChannelId, Possible<Integer> afkTimeout, Possible<Optional<String>> icon, Possible<String> ownerId, Possible<Optional<String>> splash, Possible<Optional<String>> discoverySplash, Possible<Optional<String>> banner, Possible<Optional<String>> systemChannelId, Possible<Integer> systemChannelFlags, Possible<Optional<String>> rulesChannelId, Possible<Optional<String>> publicUpdatesChannelId, Possible<Optional<String>> preferredLocale, Possible<List<String>> features, Possible<Optional<String>> description, Possible<Optional<String>> safetyAlertsChannelId) {
/*   92 */     Possible<String> name$impl = name;
/*   93 */     Possible<Optional<String>> region$impl = region;
/*   94 */     Possible<Optional<Integer>> verificationLevel$impl = verificationLevel;
/*   95 */     Possible<Optional<Integer>> defaultMessageNotifications$impl = defaultMessageNotifications;
/*   96 */     Possible<Optional<Integer>> explicitContentFilter$impl = explicitContentFilter;
/*   97 */     Possible<Optional<String>> afkChannelId$impl = afkChannelId;
/*   98 */     Possible<Integer> afkTimeout$impl = afkTimeout;
/*   99 */     Possible<Optional<String>> icon$impl = icon;
/*  100 */     Possible<String> ownerId$impl = ownerId;
/*  101 */     Possible<Optional<String>> splash$impl = splash;
/*  102 */     Possible<Optional<String>> discoverySplash$impl = discoverySplash;
/*  103 */     Possible<Optional<String>> banner$impl = banner;
/*  104 */     Possible<Optional<String>> systemChannelId$impl = systemChannelId;
/*  105 */     Possible<Integer> systemChannelFlags$impl = systemChannelFlags;
/*  106 */     Possible<Optional<String>> rulesChannelId$impl = rulesChannelId;
/*  107 */     Possible<Optional<String>> publicUpdatesChannelId$impl = publicUpdatesChannelId;
/*  108 */     Possible<Optional<String>> preferredLocale$impl = preferredLocale;
/*  109 */     Possible<List<String>> features$impl = features;
/*  110 */     Possible<Optional<String>> description$impl = description;
/*  111 */     Possible<Optional<String>> safetyAlertsChannelId$impl = safetyAlertsChannelId;
/*  112 */     this.name_value = name$impl.toOptional().orElse(null);
/*  113 */     this.name_absent = name$impl.isAbsent();
/*  114 */     this.region_value = Possible.flatOpt(region$impl).orElse(null);
/*  115 */     this.region_absent = region$impl.isAbsent();
/*  116 */     this.verificationLevel_value = Possible.flatOpt(verificationLevel$impl).orElse(null);
/*  117 */     this.verificationLevel_absent = verificationLevel$impl.isAbsent();
/*  118 */     this.defaultMessageNotifications_value = Possible.flatOpt(defaultMessageNotifications$impl).orElse(null);
/*  119 */     this.defaultMessageNotifications_absent = defaultMessageNotifications$impl.isAbsent();
/*  120 */     this.explicitContentFilter_value = Possible.flatOpt(explicitContentFilter$impl).orElse(null);
/*  121 */     this.explicitContentFilter_absent = explicitContentFilter$impl.isAbsent();
/*  122 */     this.afkChannelId_value = Possible.flatOpt(afkChannelId$impl).orElse(null);
/*  123 */     this.afkChannelId_absent = afkChannelId$impl.isAbsent();
/*  124 */     this.afkTimeout_value = afkTimeout$impl.toOptional().orElse(null);
/*  125 */     this.afkTimeout_absent = afkTimeout$impl.isAbsent();
/*  126 */     this.icon_value = Possible.flatOpt(icon$impl).orElse(null);
/*  127 */     this.icon_absent = icon$impl.isAbsent();
/*  128 */     this.ownerId_value = ownerId$impl.toOptional().orElse(null);
/*  129 */     this.ownerId_absent = ownerId$impl.isAbsent();
/*  130 */     this.splash_value = Possible.flatOpt(splash$impl).orElse(null);
/*  131 */     this.splash_absent = splash$impl.isAbsent();
/*  132 */     this.discoverySplash_value = Possible.flatOpt(discoverySplash$impl).orElse(null);
/*  133 */     this.discoverySplash_absent = discoverySplash$impl.isAbsent();
/*  134 */     this.banner_value = Possible.flatOpt(banner$impl).orElse(null);
/*  135 */     this.banner_absent = banner$impl.isAbsent();
/*  136 */     this.systemChannelId_value = Possible.flatOpt(systemChannelId$impl).orElse(null);
/*  137 */     this.systemChannelId_absent = systemChannelId$impl.isAbsent();
/*  138 */     this.systemChannelFlags_value = systemChannelFlags$impl.toOptional().orElse(null);
/*  139 */     this.systemChannelFlags_absent = systemChannelFlags$impl.isAbsent();
/*  140 */     this.rulesChannelId_value = Possible.flatOpt(rulesChannelId$impl).orElse(null);
/*  141 */     this.rulesChannelId_absent = rulesChannelId$impl.isAbsent();
/*  142 */     this.publicUpdatesChannelId_value = Possible.flatOpt(publicUpdatesChannelId$impl).orElse(null);
/*  143 */     this.publicUpdatesChannelId_absent = publicUpdatesChannelId$impl.isAbsent();
/*  144 */     this.preferredLocale_value = Possible.flatOpt(preferredLocale$impl).orElse(null);
/*  145 */     this.preferredLocale_absent = preferredLocale$impl.isAbsent();
/*  146 */     this.features_value = features$impl.toOptional().orElse(null);
/*  147 */     this.features_absent = features$impl.isAbsent();
/*  148 */     this.description_value = Possible.flatOpt(description$impl).orElse(null);
/*  149 */     this.description_absent = description$impl.isAbsent();
/*  150 */     this.safetyAlertsChannelId_value = Possible.flatOpt(safetyAlertsChannelId$impl).orElse(null);
/*  151 */     this.safetyAlertsChannelId_absent = safetyAlertsChannelId$impl.isAbsent();
/*  152 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ImmutableGuildModifyRequest(ImmutableGuildModifyRequest original, Possible<String> name, Possible<Optional<String>> region, Possible<Optional<Integer>> verificationLevel, Possible<Optional<Integer>> defaultMessageNotifications, Possible<Optional<Integer>> explicitContentFilter, Possible<Optional<String>> afkChannelId, Possible<Integer> afkTimeout, Possible<Optional<String>> icon, Possible<String> ownerId, Possible<Optional<String>> splash, Possible<Optional<String>> discoverySplash, Possible<Optional<String>> banner, Possible<Optional<String>> systemChannelId, Possible<Integer> systemChannelFlags, Possible<Optional<String>> rulesChannelId, Possible<Optional<String>> publicUpdatesChannelId, Possible<Optional<String>> preferredLocale, Possible<List<String>> features, Possible<Optional<String>> description, Possible<Optional<String>> safetyAlertsChannelId) {
/*  177 */     Possible<String> name$impl = name;
/*  178 */     Possible<Optional<String>> region$impl = region;
/*  179 */     Possible<Optional<Integer>> verificationLevel$impl = verificationLevel;
/*  180 */     Possible<Optional<Integer>> defaultMessageNotifications$impl = defaultMessageNotifications;
/*  181 */     Possible<Optional<Integer>> explicitContentFilter$impl = explicitContentFilter;
/*  182 */     Possible<Optional<String>> afkChannelId$impl = afkChannelId;
/*  183 */     Possible<Integer> afkTimeout$impl = afkTimeout;
/*  184 */     Possible<Optional<String>> icon$impl = icon;
/*  185 */     Possible<String> ownerId$impl = ownerId;
/*  186 */     Possible<Optional<String>> splash$impl = splash;
/*  187 */     Possible<Optional<String>> discoverySplash$impl = discoverySplash;
/*  188 */     Possible<Optional<String>> banner$impl = banner;
/*  189 */     Possible<Optional<String>> systemChannelId$impl = systemChannelId;
/*  190 */     Possible<Integer> systemChannelFlags$impl = systemChannelFlags;
/*  191 */     Possible<Optional<String>> rulesChannelId$impl = rulesChannelId;
/*  192 */     Possible<Optional<String>> publicUpdatesChannelId$impl = publicUpdatesChannelId;
/*  193 */     Possible<Optional<String>> preferredLocale$impl = preferredLocale;
/*  194 */     Possible<List<String>> features$impl = features;
/*  195 */     Possible<Optional<String>> description$impl = description;
/*  196 */     Possible<Optional<String>> safetyAlertsChannelId$impl = safetyAlertsChannelId;
/*  197 */     this.name_value = name$impl.toOptional().orElse(null);
/*  198 */     this.name_absent = name$impl.isAbsent();
/*  199 */     this.region_value = Possible.flatOpt(region$impl).orElse(null);
/*  200 */     this.region_absent = region$impl.isAbsent();
/*  201 */     this.verificationLevel_value = Possible.flatOpt(verificationLevel$impl).orElse(null);
/*  202 */     this.verificationLevel_absent = verificationLevel$impl.isAbsent();
/*  203 */     this.defaultMessageNotifications_value = Possible.flatOpt(defaultMessageNotifications$impl).orElse(null);
/*  204 */     this.defaultMessageNotifications_absent = defaultMessageNotifications$impl.isAbsent();
/*  205 */     this.explicitContentFilter_value = Possible.flatOpt(explicitContentFilter$impl).orElse(null);
/*  206 */     this.explicitContentFilter_absent = explicitContentFilter$impl.isAbsent();
/*  207 */     this.afkChannelId_value = Possible.flatOpt(afkChannelId$impl).orElse(null);
/*  208 */     this.afkChannelId_absent = afkChannelId$impl.isAbsent();
/*  209 */     this.afkTimeout_value = afkTimeout$impl.toOptional().orElse(null);
/*  210 */     this.afkTimeout_absent = afkTimeout$impl.isAbsent();
/*  211 */     this.icon_value = Possible.flatOpt(icon$impl).orElse(null);
/*  212 */     this.icon_absent = icon$impl.isAbsent();
/*  213 */     this.ownerId_value = ownerId$impl.toOptional().orElse(null);
/*  214 */     this.ownerId_absent = ownerId$impl.isAbsent();
/*  215 */     this.splash_value = Possible.flatOpt(splash$impl).orElse(null);
/*  216 */     this.splash_absent = splash$impl.isAbsent();
/*  217 */     this.discoverySplash_value = Possible.flatOpt(discoverySplash$impl).orElse(null);
/*  218 */     this.discoverySplash_absent = discoverySplash$impl.isAbsent();
/*  219 */     this.banner_value = Possible.flatOpt(banner$impl).orElse(null);
/*  220 */     this.banner_absent = banner$impl.isAbsent();
/*  221 */     this.systemChannelId_value = Possible.flatOpt(systemChannelId$impl).orElse(null);
/*  222 */     this.systemChannelId_absent = systemChannelId$impl.isAbsent();
/*  223 */     this.systemChannelFlags_value = systemChannelFlags$impl.toOptional().orElse(null);
/*  224 */     this.systemChannelFlags_absent = systemChannelFlags$impl.isAbsent();
/*  225 */     this.rulesChannelId_value = Possible.flatOpt(rulesChannelId$impl).orElse(null);
/*  226 */     this.rulesChannelId_absent = rulesChannelId$impl.isAbsent();
/*  227 */     this.publicUpdatesChannelId_value = Possible.flatOpt(publicUpdatesChannelId$impl).orElse(null);
/*  228 */     this.publicUpdatesChannelId_absent = publicUpdatesChannelId$impl.isAbsent();
/*  229 */     this.preferredLocale_value = Possible.flatOpt(preferredLocale$impl).orElse(null);
/*  230 */     this.preferredLocale_absent = preferredLocale$impl.isAbsent();
/*  231 */     this.features_value = features$impl.toOptional().orElse(null);
/*  232 */     this.features_absent = features$impl.isAbsent();
/*  233 */     this.description_value = Possible.flatOpt(description$impl).orElse(null);
/*  234 */     this.description_absent = description$impl.isAbsent();
/*  235 */     this.safetyAlertsChannelId_value = Possible.flatOpt(safetyAlertsChannelId$impl).orElse(null);
/*  236 */     this.safetyAlertsChannelId_absent = safetyAlertsChannelId$impl.isAbsent();
/*  237 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  243 */   private volatile transient InitShim initShim = new InitShim();
/*      */   
/*      */   @Generated(from = "GuildModifyRequest", generator = "Immutables")
/*      */   private final class InitShim {
/*      */     private String formatInitCycleMessage() {
/*  248 */       List<String> attributes = new ArrayList<>();
/*  249 */       return "Cannot build GuildModifyRequest, attribute initializers form cycle " + attributes;
/*      */     }
/*      */ 
/*      */     
/*      */     private InitShim() {}
/*      */   }
/*      */ 
/*      */   
/*      */   @JsonProperty("name")
/*      */   public Possible<String> name() {
/*  259 */     return this.name_absent ? Possible.absent() : Possible.of(this.name_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("region")
/*      */   public Possible<Optional<String>> region() {
/*  268 */     return this.region_absent ? Possible.absent() : 
/*  269 */       Possible.of(Optional.ofNullable(this.region_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("verification_level")
/*      */   public Possible<Optional<Integer>> verificationLevel() {
/*  278 */     return this.verificationLevel_absent ? Possible.absent() : 
/*  279 */       Possible.of(Optional.ofNullable(this.verificationLevel_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("default_message_notifications")
/*      */   public Possible<Optional<Integer>> defaultMessageNotifications() {
/*  288 */     return this.defaultMessageNotifications_absent ? Possible.absent() : 
/*  289 */       Possible.of(Optional.ofNullable(this.defaultMessageNotifications_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("explicit_content_filter")
/*      */   public Possible<Optional<Integer>> explicitContentFilter() {
/*  298 */     return this.explicitContentFilter_absent ? Possible.absent() : 
/*  299 */       Possible.of(Optional.ofNullable(this.explicitContentFilter_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("afk_channel_id")
/*      */   public Possible<Optional<String>> afkChannelId() {
/*  308 */     return this.afkChannelId_absent ? Possible.absent() : 
/*  309 */       Possible.of(Optional.ofNullable(this.afkChannelId_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("afk_timeout")
/*      */   public Possible<Integer> afkTimeout() {
/*  318 */     return this.afkTimeout_absent ? Possible.absent() : Possible.of(this.afkTimeout_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("icon")
/*      */   public Possible<Optional<String>> icon() {
/*  327 */     return this.icon_absent ? Possible.absent() : 
/*  328 */       Possible.of(Optional.ofNullable(this.icon_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("owner_id")
/*      */   public Possible<String> ownerId() {
/*  337 */     return this.ownerId_absent ? Possible.absent() : Possible.of(this.ownerId_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("splash")
/*      */   public Possible<Optional<String>> splash() {
/*  346 */     return this.splash_absent ? Possible.absent() : 
/*  347 */       Possible.of(Optional.ofNullable(this.splash_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("discovery_splash")
/*      */   public Possible<Optional<String>> discoverySplash() {
/*  356 */     return this.discoverySplash_absent ? Possible.absent() : 
/*  357 */       Possible.of(Optional.ofNullable(this.discoverySplash_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("banner")
/*      */   public Possible<Optional<String>> banner() {
/*  366 */     return this.banner_absent ? Possible.absent() : 
/*  367 */       Possible.of(Optional.ofNullable(this.banner_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("system_channel_id")
/*      */   public Possible<Optional<String>> systemChannelId() {
/*  376 */     return this.systemChannelId_absent ? Possible.absent() : 
/*  377 */       Possible.of(Optional.ofNullable(this.systemChannelId_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("system_channel_flags")
/*      */   public Possible<Integer> systemChannelFlags() {
/*  386 */     return this.systemChannelFlags_absent ? Possible.absent() : Possible.of(this.systemChannelFlags_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("rules_channel_id")
/*      */   public Possible<Optional<String>> rulesChannelId() {
/*  395 */     return this.rulesChannelId_absent ? Possible.absent() : 
/*  396 */       Possible.of(Optional.ofNullable(this.rulesChannelId_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("public_updates_channel_id")
/*      */   public Possible<Optional<String>> publicUpdatesChannelId() {
/*  405 */     return this.publicUpdatesChannelId_absent ? Possible.absent() : 
/*  406 */       Possible.of(Optional.ofNullable(this.publicUpdatesChannelId_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("preferred_locale")
/*      */   public Possible<Optional<String>> preferredLocale() {
/*  415 */     return this.preferredLocale_absent ? Possible.absent() : 
/*  416 */       Possible.of(Optional.ofNullable(this.preferredLocale_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("features")
/*      */   public Possible<List<String>> features() {
/*  425 */     return this.features_absent ? Possible.absent() : 
/*  426 */       Possible.of(this.features_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("description")
/*      */   public Possible<Optional<String>> description() {
/*  435 */     return this.description_absent ? Possible.absent() : 
/*  436 */       Possible.of(Optional.ofNullable(this.description_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("safety_alerts_channel_id")
/*      */   public Possible<Optional<String>> safetyAlertsChannelId() {
/*  445 */     return this.safetyAlertsChannelId_absent ? Possible.absent() : 
/*  446 */       Possible.of(Optional.ofNullable(this.safetyAlertsChannelId_value));
/*      */   }
/*      */   
/*      */   public ImmutableGuildModifyRequest withName(Possible<String> value) {
/*  450 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  451 */     return new ImmutableGuildModifyRequest(this, newValue, 
/*      */ 
/*      */         
/*  454 */         region(), 
/*  455 */         verificationLevel(), 
/*  456 */         defaultMessageNotifications(), 
/*  457 */         explicitContentFilter(), 
/*  458 */         afkChannelId(), 
/*  459 */         afkTimeout(), 
/*  460 */         icon(), 
/*  461 */         ownerId(), 
/*  462 */         splash(), 
/*  463 */         discoverySplash(), 
/*  464 */         banner(), 
/*  465 */         systemChannelId(), 
/*  466 */         systemChannelFlags(), 
/*  467 */         rulesChannelId(), 
/*  468 */         publicUpdatesChannelId(), 
/*  469 */         preferredLocale(), 
/*  470 */         features(), 
/*  471 */         description(), 
/*  472 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableGuildModifyRequest withName(String value) {
/*  476 */     Possible<String> newValue = Possible.of(value);
/*  477 */     return new ImmutableGuildModifyRequest(this, newValue, 
/*      */ 
/*      */         
/*  480 */         region(), 
/*  481 */         verificationLevel(), 
/*  482 */         defaultMessageNotifications(), 
/*  483 */         explicitContentFilter(), 
/*  484 */         afkChannelId(), 
/*  485 */         afkTimeout(), 
/*  486 */         icon(), 
/*  487 */         ownerId(), 
/*  488 */         splash(), 
/*  489 */         discoverySplash(), 
/*  490 */         banner(), 
/*  491 */         systemChannelId(), 
/*  492 */         systemChannelFlags(), 
/*  493 */         rulesChannelId(), 
/*  494 */         publicUpdatesChannelId(), 
/*  495 */         preferredLocale(), 
/*  496 */         features(), 
/*  497 */         description(), 
/*  498 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableGuildModifyRequest withRegion(Possible<Optional<String>> value) {
/*  502 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/*  503 */     return new ImmutableGuildModifyRequest(this, 
/*      */         
/*  505 */         name(), newValue, 
/*      */         
/*  507 */         verificationLevel(), 
/*  508 */         defaultMessageNotifications(), 
/*  509 */         explicitContentFilter(), 
/*  510 */         afkChannelId(), 
/*  511 */         afkTimeout(), 
/*  512 */         icon(), 
/*  513 */         ownerId(), 
/*  514 */         splash(), 
/*  515 */         discoverySplash(), 
/*  516 */         banner(), 
/*  517 */         systemChannelId(), 
/*  518 */         systemChannelFlags(), 
/*  519 */         rulesChannelId(), 
/*  520 */         publicUpdatesChannelId(), 
/*  521 */         preferredLocale(), 
/*  522 */         features(), 
/*  523 */         description(), 
/*  524 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableGuildModifyRequest withRegion(@Nullable String value) {
/*  529 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  530 */     return new ImmutableGuildModifyRequest(this, 
/*      */         
/*  532 */         name(), newValue, 
/*      */         
/*  534 */         verificationLevel(), 
/*  535 */         defaultMessageNotifications(), 
/*  536 */         explicitContentFilter(), 
/*  537 */         afkChannelId(), 
/*  538 */         afkTimeout(), 
/*  539 */         icon(), 
/*  540 */         ownerId(), 
/*  541 */         splash(), 
/*  542 */         discoverySplash(), 
/*  543 */         banner(), 
/*  544 */         systemChannelId(), 
/*  545 */         systemChannelFlags(), 
/*  546 */         rulesChannelId(), 
/*  547 */         publicUpdatesChannelId(), 
/*  548 */         preferredLocale(), 
/*  549 */         features(), 
/*  550 */         description(), 
/*  551 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableGuildModifyRequest withRegionOrNull(@Nullable String value) {
/*  555 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  556 */     return new ImmutableGuildModifyRequest(this, 
/*      */         
/*  558 */         name(), newValue, 
/*      */         
/*  560 */         verificationLevel(), 
/*  561 */         defaultMessageNotifications(), 
/*  562 */         explicitContentFilter(), 
/*  563 */         afkChannelId(), 
/*  564 */         afkTimeout(), 
/*  565 */         icon(), 
/*  566 */         ownerId(), 
/*  567 */         splash(), 
/*  568 */         discoverySplash(), 
/*  569 */         banner(), 
/*  570 */         systemChannelId(), 
/*  571 */         systemChannelFlags(), 
/*  572 */         rulesChannelId(), 
/*  573 */         publicUpdatesChannelId(), 
/*  574 */         preferredLocale(), 
/*  575 */         features(), 
/*  576 */         description(), 
/*  577 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableGuildModifyRequest withVerificationLevel(Possible<Optional<Integer>> value) {
/*  581 */     Possible<Optional<Integer>> newValue = Objects.<Possible<Optional<Integer>>>requireNonNull(value);
/*  582 */     return new ImmutableGuildModifyRequest(this, 
/*      */         
/*  584 */         name(), 
/*  585 */         region(), newValue, 
/*      */         
/*  587 */         defaultMessageNotifications(), 
/*  588 */         explicitContentFilter(), 
/*  589 */         afkChannelId(), 
/*  590 */         afkTimeout(), 
/*  591 */         icon(), 
/*  592 */         ownerId(), 
/*  593 */         splash(), 
/*  594 */         discoverySplash(), 
/*  595 */         banner(), 
/*  596 */         systemChannelId(), 
/*  597 */         systemChannelFlags(), 
/*  598 */         rulesChannelId(), 
/*  599 */         publicUpdatesChannelId(), 
/*  600 */         preferredLocale(), 
/*  601 */         features(), 
/*  602 */         description(), 
/*  603 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableGuildModifyRequest withVerificationLevel(@Nullable Integer value) {
/*  608 */     Possible<Optional<Integer>> newValue = Possible.of(Optional.ofNullable(value));
/*  609 */     return new ImmutableGuildModifyRequest(this, 
/*      */         
/*  611 */         name(), 
/*  612 */         region(), newValue, 
/*      */         
/*  614 */         defaultMessageNotifications(), 
/*  615 */         explicitContentFilter(), 
/*  616 */         afkChannelId(), 
/*  617 */         afkTimeout(), 
/*  618 */         icon(), 
/*  619 */         ownerId(), 
/*  620 */         splash(), 
/*  621 */         discoverySplash(), 
/*  622 */         banner(), 
/*  623 */         systemChannelId(), 
/*  624 */         systemChannelFlags(), 
/*  625 */         rulesChannelId(), 
/*  626 */         publicUpdatesChannelId(), 
/*  627 */         preferredLocale(), 
/*  628 */         features(), 
/*  629 */         description(), 
/*  630 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableGuildModifyRequest withVerificationLevelOrNull(@Nullable Integer value) {
/*  634 */     Possible<Optional<Integer>> newValue = Possible.of(Optional.ofNullable(value));
/*  635 */     return new ImmutableGuildModifyRequest(this, 
/*      */         
/*  637 */         name(), 
/*  638 */         region(), newValue, 
/*      */         
/*  640 */         defaultMessageNotifications(), 
/*  641 */         explicitContentFilter(), 
/*  642 */         afkChannelId(), 
/*  643 */         afkTimeout(), 
/*  644 */         icon(), 
/*  645 */         ownerId(), 
/*  646 */         splash(), 
/*  647 */         discoverySplash(), 
/*  648 */         banner(), 
/*  649 */         systemChannelId(), 
/*  650 */         systemChannelFlags(), 
/*  651 */         rulesChannelId(), 
/*  652 */         publicUpdatesChannelId(), 
/*  653 */         preferredLocale(), 
/*  654 */         features(), 
/*  655 */         description(), 
/*  656 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableGuildModifyRequest withDefaultMessageNotifications(Possible<Optional<Integer>> value) {
/*  660 */     Possible<Optional<Integer>> newValue = Objects.<Possible<Optional<Integer>>>requireNonNull(value);
/*  661 */     return new ImmutableGuildModifyRequest(this, 
/*      */         
/*  663 */         name(), 
/*  664 */         region(), 
/*  665 */         verificationLevel(), newValue, 
/*      */         
/*  667 */         explicitContentFilter(), 
/*  668 */         afkChannelId(), 
/*  669 */         afkTimeout(), 
/*  670 */         icon(), 
/*  671 */         ownerId(), 
/*  672 */         splash(), 
/*  673 */         discoverySplash(), 
/*  674 */         banner(), 
/*  675 */         systemChannelId(), 
/*  676 */         systemChannelFlags(), 
/*  677 */         rulesChannelId(), 
/*  678 */         publicUpdatesChannelId(), 
/*  679 */         preferredLocale(), 
/*  680 */         features(), 
/*  681 */         description(), 
/*  682 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableGuildModifyRequest withDefaultMessageNotifications(@Nullable Integer value) {
/*  687 */     Possible<Optional<Integer>> newValue = Possible.of(Optional.ofNullable(value));
/*  688 */     return new ImmutableGuildModifyRequest(this, 
/*      */         
/*  690 */         name(), 
/*  691 */         region(), 
/*  692 */         verificationLevel(), newValue, 
/*      */         
/*  694 */         explicitContentFilter(), 
/*  695 */         afkChannelId(), 
/*  696 */         afkTimeout(), 
/*  697 */         icon(), 
/*  698 */         ownerId(), 
/*  699 */         splash(), 
/*  700 */         discoverySplash(), 
/*  701 */         banner(), 
/*  702 */         systemChannelId(), 
/*  703 */         systemChannelFlags(), 
/*  704 */         rulesChannelId(), 
/*  705 */         publicUpdatesChannelId(), 
/*  706 */         preferredLocale(), 
/*  707 */         features(), 
/*  708 */         description(), 
/*  709 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableGuildModifyRequest withDefaultMessageNotificationsOrNull(@Nullable Integer value) {
/*  713 */     Possible<Optional<Integer>> newValue = Possible.of(Optional.ofNullable(value));
/*  714 */     return new ImmutableGuildModifyRequest(this, 
/*      */         
/*  716 */         name(), 
/*  717 */         region(), 
/*  718 */         verificationLevel(), newValue, 
/*      */         
/*  720 */         explicitContentFilter(), 
/*  721 */         afkChannelId(), 
/*  722 */         afkTimeout(), 
/*  723 */         icon(), 
/*  724 */         ownerId(), 
/*  725 */         splash(), 
/*  726 */         discoverySplash(), 
/*  727 */         banner(), 
/*  728 */         systemChannelId(), 
/*  729 */         systemChannelFlags(), 
/*  730 */         rulesChannelId(), 
/*  731 */         publicUpdatesChannelId(), 
/*  732 */         preferredLocale(), 
/*  733 */         features(), 
/*  734 */         description(), 
/*  735 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableGuildModifyRequest withExplicitContentFilter(Possible<Optional<Integer>> value) {
/*  739 */     Possible<Optional<Integer>> newValue = Objects.<Possible<Optional<Integer>>>requireNonNull(value);
/*  740 */     return new ImmutableGuildModifyRequest(this, 
/*      */         
/*  742 */         name(), 
/*  743 */         region(), 
/*  744 */         verificationLevel(), 
/*  745 */         defaultMessageNotifications(), newValue, 
/*      */         
/*  747 */         afkChannelId(), 
/*  748 */         afkTimeout(), 
/*  749 */         icon(), 
/*  750 */         ownerId(), 
/*  751 */         splash(), 
/*  752 */         discoverySplash(), 
/*  753 */         banner(), 
/*  754 */         systemChannelId(), 
/*  755 */         systemChannelFlags(), 
/*  756 */         rulesChannelId(), 
/*  757 */         publicUpdatesChannelId(), 
/*  758 */         preferredLocale(), 
/*  759 */         features(), 
/*  760 */         description(), 
/*  761 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableGuildModifyRequest withExplicitContentFilter(@Nullable Integer value) {
/*  766 */     Possible<Optional<Integer>> newValue = Possible.of(Optional.ofNullable(value));
/*  767 */     return new ImmutableGuildModifyRequest(this, 
/*      */         
/*  769 */         name(), 
/*  770 */         region(), 
/*  771 */         verificationLevel(), 
/*  772 */         defaultMessageNotifications(), newValue, 
/*      */         
/*  774 */         afkChannelId(), 
/*  775 */         afkTimeout(), 
/*  776 */         icon(), 
/*  777 */         ownerId(), 
/*  778 */         splash(), 
/*  779 */         discoverySplash(), 
/*  780 */         banner(), 
/*  781 */         systemChannelId(), 
/*  782 */         systemChannelFlags(), 
/*  783 */         rulesChannelId(), 
/*  784 */         publicUpdatesChannelId(), 
/*  785 */         preferredLocale(), 
/*  786 */         features(), 
/*  787 */         description(), 
/*  788 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableGuildModifyRequest withExplicitContentFilterOrNull(@Nullable Integer value) {
/*  792 */     Possible<Optional<Integer>> newValue = Possible.of(Optional.ofNullable(value));
/*  793 */     return new ImmutableGuildModifyRequest(this, 
/*      */         
/*  795 */         name(), 
/*  796 */         region(), 
/*  797 */         verificationLevel(), 
/*  798 */         defaultMessageNotifications(), newValue, 
/*      */         
/*  800 */         afkChannelId(), 
/*  801 */         afkTimeout(), 
/*  802 */         icon(), 
/*  803 */         ownerId(), 
/*  804 */         splash(), 
/*  805 */         discoverySplash(), 
/*  806 */         banner(), 
/*  807 */         systemChannelId(), 
/*  808 */         systemChannelFlags(), 
/*  809 */         rulesChannelId(), 
/*  810 */         publicUpdatesChannelId(), 
/*  811 */         preferredLocale(), 
/*  812 */         features(), 
/*  813 */         description(), 
/*  814 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableGuildModifyRequest withAfkChannelId(Possible<Optional<String>> value) {
/*  818 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/*  819 */     return new ImmutableGuildModifyRequest(this, 
/*      */         
/*  821 */         name(), 
/*  822 */         region(), 
/*  823 */         verificationLevel(), 
/*  824 */         defaultMessageNotifications(), 
/*  825 */         explicitContentFilter(), newValue, 
/*      */         
/*  827 */         afkTimeout(), 
/*  828 */         icon(), 
/*  829 */         ownerId(), 
/*  830 */         splash(), 
/*  831 */         discoverySplash(), 
/*  832 */         banner(), 
/*  833 */         systemChannelId(), 
/*  834 */         systemChannelFlags(), 
/*  835 */         rulesChannelId(), 
/*  836 */         publicUpdatesChannelId(), 
/*  837 */         preferredLocale(), 
/*  838 */         features(), 
/*  839 */         description(), 
/*  840 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableGuildModifyRequest withAfkChannelId(@Nullable String value) {
/*  845 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  846 */     return new ImmutableGuildModifyRequest(this, 
/*      */         
/*  848 */         name(), 
/*  849 */         region(), 
/*  850 */         verificationLevel(), 
/*  851 */         defaultMessageNotifications(), 
/*  852 */         explicitContentFilter(), newValue, 
/*      */         
/*  854 */         afkTimeout(), 
/*  855 */         icon(), 
/*  856 */         ownerId(), 
/*  857 */         splash(), 
/*  858 */         discoverySplash(), 
/*  859 */         banner(), 
/*  860 */         systemChannelId(), 
/*  861 */         systemChannelFlags(), 
/*  862 */         rulesChannelId(), 
/*  863 */         publicUpdatesChannelId(), 
/*  864 */         preferredLocale(), 
/*  865 */         features(), 
/*  866 */         description(), 
/*  867 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableGuildModifyRequest withAfkChannelIdOrNull(@Nullable String value) {
/*  871 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  872 */     return new ImmutableGuildModifyRequest(this, 
/*      */         
/*  874 */         name(), 
/*  875 */         region(), 
/*  876 */         verificationLevel(), 
/*  877 */         defaultMessageNotifications(), 
/*  878 */         explicitContentFilter(), newValue, 
/*      */         
/*  880 */         afkTimeout(), 
/*  881 */         icon(), 
/*  882 */         ownerId(), 
/*  883 */         splash(), 
/*  884 */         discoverySplash(), 
/*  885 */         banner(), 
/*  886 */         systemChannelId(), 
/*  887 */         systemChannelFlags(), 
/*  888 */         rulesChannelId(), 
/*  889 */         publicUpdatesChannelId(), 
/*  890 */         preferredLocale(), 
/*  891 */         features(), 
/*  892 */         description(), 
/*  893 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableGuildModifyRequest withAfkTimeout(Possible<Integer> value) {
/*  897 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/*  898 */     return new ImmutableGuildModifyRequest(this, 
/*      */         
/*  900 */         name(), 
/*  901 */         region(), 
/*  902 */         verificationLevel(), 
/*  903 */         defaultMessageNotifications(), 
/*  904 */         explicitContentFilter(), 
/*  905 */         afkChannelId(), newValue, 
/*      */         
/*  907 */         icon(), 
/*  908 */         ownerId(), 
/*  909 */         splash(), 
/*  910 */         discoverySplash(), 
/*  911 */         banner(), 
/*  912 */         systemChannelId(), 
/*  913 */         systemChannelFlags(), 
/*  914 */         rulesChannelId(), 
/*  915 */         publicUpdatesChannelId(), 
/*  916 */         preferredLocale(), 
/*  917 */         features(), 
/*  918 */         description(), 
/*  919 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableGuildModifyRequest withAfkTimeout(Integer value) {
/*  923 */     Possible<Integer> newValue = Possible.of(value);
/*  924 */     return new ImmutableGuildModifyRequest(this, 
/*      */         
/*  926 */         name(), 
/*  927 */         region(), 
/*  928 */         verificationLevel(), 
/*  929 */         defaultMessageNotifications(), 
/*  930 */         explicitContentFilter(), 
/*  931 */         afkChannelId(), newValue, 
/*      */         
/*  933 */         icon(), 
/*  934 */         ownerId(), 
/*  935 */         splash(), 
/*  936 */         discoverySplash(), 
/*  937 */         banner(), 
/*  938 */         systemChannelId(), 
/*  939 */         systemChannelFlags(), 
/*  940 */         rulesChannelId(), 
/*  941 */         publicUpdatesChannelId(), 
/*  942 */         preferredLocale(), 
/*  943 */         features(), 
/*  944 */         description(), 
/*  945 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableGuildModifyRequest withIcon(Possible<Optional<String>> value) {
/*  949 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/*  950 */     return new ImmutableGuildModifyRequest(this, 
/*      */         
/*  952 */         name(), 
/*  953 */         region(), 
/*  954 */         verificationLevel(), 
/*  955 */         defaultMessageNotifications(), 
/*  956 */         explicitContentFilter(), 
/*  957 */         afkChannelId(), 
/*  958 */         afkTimeout(), newValue, 
/*      */         
/*  960 */         ownerId(), 
/*  961 */         splash(), 
/*  962 */         discoverySplash(), 
/*  963 */         banner(), 
/*  964 */         systemChannelId(), 
/*  965 */         systemChannelFlags(), 
/*  966 */         rulesChannelId(), 
/*  967 */         publicUpdatesChannelId(), 
/*  968 */         preferredLocale(), 
/*  969 */         features(), 
/*  970 */         description(), 
/*  971 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableGuildModifyRequest withIcon(@Nullable String value) {
/*  976 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  977 */     return new ImmutableGuildModifyRequest(this, 
/*      */         
/*  979 */         name(), 
/*  980 */         region(), 
/*  981 */         verificationLevel(), 
/*  982 */         defaultMessageNotifications(), 
/*  983 */         explicitContentFilter(), 
/*  984 */         afkChannelId(), 
/*  985 */         afkTimeout(), newValue, 
/*      */         
/*  987 */         ownerId(), 
/*  988 */         splash(), 
/*  989 */         discoverySplash(), 
/*  990 */         banner(), 
/*  991 */         systemChannelId(), 
/*  992 */         systemChannelFlags(), 
/*  993 */         rulesChannelId(), 
/*  994 */         publicUpdatesChannelId(), 
/*  995 */         preferredLocale(), 
/*  996 */         features(), 
/*  997 */         description(), 
/*  998 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableGuildModifyRequest withIconOrNull(@Nullable String value) {
/* 1002 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 1003 */     return new ImmutableGuildModifyRequest(this, 
/*      */         
/* 1005 */         name(), 
/* 1006 */         region(), 
/* 1007 */         verificationLevel(), 
/* 1008 */         defaultMessageNotifications(), 
/* 1009 */         explicitContentFilter(), 
/* 1010 */         afkChannelId(), 
/* 1011 */         afkTimeout(), newValue, 
/*      */         
/* 1013 */         ownerId(), 
/* 1014 */         splash(), 
/* 1015 */         discoverySplash(), 
/* 1016 */         banner(), 
/* 1017 */         systemChannelId(), 
/* 1018 */         systemChannelFlags(), 
/* 1019 */         rulesChannelId(), 
/* 1020 */         publicUpdatesChannelId(), 
/* 1021 */         preferredLocale(), 
/* 1022 */         features(), 
/* 1023 */         description(), 
/* 1024 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableGuildModifyRequest withOwnerId(Possible<String> value) {
/* 1028 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 1029 */     return new ImmutableGuildModifyRequest(this, 
/*      */         
/* 1031 */         name(), 
/* 1032 */         region(), 
/* 1033 */         verificationLevel(), 
/* 1034 */         defaultMessageNotifications(), 
/* 1035 */         explicitContentFilter(), 
/* 1036 */         afkChannelId(), 
/* 1037 */         afkTimeout(), 
/* 1038 */         icon(), newValue, 
/*      */         
/* 1040 */         splash(), 
/* 1041 */         discoverySplash(), 
/* 1042 */         banner(), 
/* 1043 */         systemChannelId(), 
/* 1044 */         systemChannelFlags(), 
/* 1045 */         rulesChannelId(), 
/* 1046 */         publicUpdatesChannelId(), 
/* 1047 */         preferredLocale(), 
/* 1048 */         features(), 
/* 1049 */         description(), 
/* 1050 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableGuildModifyRequest withOwnerId(String value) {
/* 1054 */     Possible<String> newValue = Possible.of(value);
/* 1055 */     return new ImmutableGuildModifyRequest(this, 
/*      */         
/* 1057 */         name(), 
/* 1058 */         region(), 
/* 1059 */         verificationLevel(), 
/* 1060 */         defaultMessageNotifications(), 
/* 1061 */         explicitContentFilter(), 
/* 1062 */         afkChannelId(), 
/* 1063 */         afkTimeout(), 
/* 1064 */         icon(), newValue, 
/*      */         
/* 1066 */         splash(), 
/* 1067 */         discoverySplash(), 
/* 1068 */         banner(), 
/* 1069 */         systemChannelId(), 
/* 1070 */         systemChannelFlags(), 
/* 1071 */         rulesChannelId(), 
/* 1072 */         publicUpdatesChannelId(), 
/* 1073 */         preferredLocale(), 
/* 1074 */         features(), 
/* 1075 */         description(), 
/* 1076 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableGuildModifyRequest withSplash(Possible<Optional<String>> value) {
/* 1080 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/* 1081 */     return new ImmutableGuildModifyRequest(this, 
/*      */         
/* 1083 */         name(), 
/* 1084 */         region(), 
/* 1085 */         verificationLevel(), 
/* 1086 */         defaultMessageNotifications(), 
/* 1087 */         explicitContentFilter(), 
/* 1088 */         afkChannelId(), 
/* 1089 */         afkTimeout(), 
/* 1090 */         icon(), 
/* 1091 */         ownerId(), newValue, 
/*      */         
/* 1093 */         discoverySplash(), 
/* 1094 */         banner(), 
/* 1095 */         systemChannelId(), 
/* 1096 */         systemChannelFlags(), 
/* 1097 */         rulesChannelId(), 
/* 1098 */         publicUpdatesChannelId(), 
/* 1099 */         preferredLocale(), 
/* 1100 */         features(), 
/* 1101 */         description(), 
/* 1102 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableGuildModifyRequest withSplash(@Nullable String value) {
/* 1107 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 1108 */     return new ImmutableGuildModifyRequest(this, 
/*      */         
/* 1110 */         name(), 
/* 1111 */         region(), 
/* 1112 */         verificationLevel(), 
/* 1113 */         defaultMessageNotifications(), 
/* 1114 */         explicitContentFilter(), 
/* 1115 */         afkChannelId(), 
/* 1116 */         afkTimeout(), 
/* 1117 */         icon(), 
/* 1118 */         ownerId(), newValue, 
/*      */         
/* 1120 */         discoverySplash(), 
/* 1121 */         banner(), 
/* 1122 */         systemChannelId(), 
/* 1123 */         systemChannelFlags(), 
/* 1124 */         rulesChannelId(), 
/* 1125 */         publicUpdatesChannelId(), 
/* 1126 */         preferredLocale(), 
/* 1127 */         features(), 
/* 1128 */         description(), 
/* 1129 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableGuildModifyRequest withSplashOrNull(@Nullable String value) {
/* 1133 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 1134 */     return new ImmutableGuildModifyRequest(this, 
/*      */         
/* 1136 */         name(), 
/* 1137 */         region(), 
/* 1138 */         verificationLevel(), 
/* 1139 */         defaultMessageNotifications(), 
/* 1140 */         explicitContentFilter(), 
/* 1141 */         afkChannelId(), 
/* 1142 */         afkTimeout(), 
/* 1143 */         icon(), 
/* 1144 */         ownerId(), newValue, 
/*      */         
/* 1146 */         discoverySplash(), 
/* 1147 */         banner(), 
/* 1148 */         systemChannelId(), 
/* 1149 */         systemChannelFlags(), 
/* 1150 */         rulesChannelId(), 
/* 1151 */         publicUpdatesChannelId(), 
/* 1152 */         preferredLocale(), 
/* 1153 */         features(), 
/* 1154 */         description(), 
/* 1155 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableGuildModifyRequest withDiscoverySplash(Possible<Optional<String>> value) {
/* 1159 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/* 1160 */     return new ImmutableGuildModifyRequest(this, 
/*      */         
/* 1162 */         name(), 
/* 1163 */         region(), 
/* 1164 */         verificationLevel(), 
/* 1165 */         defaultMessageNotifications(), 
/* 1166 */         explicitContentFilter(), 
/* 1167 */         afkChannelId(), 
/* 1168 */         afkTimeout(), 
/* 1169 */         icon(), 
/* 1170 */         ownerId(), 
/* 1171 */         splash(), newValue, 
/*      */         
/* 1173 */         banner(), 
/* 1174 */         systemChannelId(), 
/* 1175 */         systemChannelFlags(), 
/* 1176 */         rulesChannelId(), 
/* 1177 */         publicUpdatesChannelId(), 
/* 1178 */         preferredLocale(), 
/* 1179 */         features(), 
/* 1180 */         description(), 
/* 1181 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableGuildModifyRequest withDiscoverySplash(@Nullable String value) {
/* 1186 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 1187 */     return new ImmutableGuildModifyRequest(this, 
/*      */         
/* 1189 */         name(), 
/* 1190 */         region(), 
/* 1191 */         verificationLevel(), 
/* 1192 */         defaultMessageNotifications(), 
/* 1193 */         explicitContentFilter(), 
/* 1194 */         afkChannelId(), 
/* 1195 */         afkTimeout(), 
/* 1196 */         icon(), 
/* 1197 */         ownerId(), 
/* 1198 */         splash(), newValue, 
/*      */         
/* 1200 */         banner(), 
/* 1201 */         systemChannelId(), 
/* 1202 */         systemChannelFlags(), 
/* 1203 */         rulesChannelId(), 
/* 1204 */         publicUpdatesChannelId(), 
/* 1205 */         preferredLocale(), 
/* 1206 */         features(), 
/* 1207 */         description(), 
/* 1208 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableGuildModifyRequest withDiscoverySplashOrNull(@Nullable String value) {
/* 1212 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 1213 */     return new ImmutableGuildModifyRequest(this, 
/*      */         
/* 1215 */         name(), 
/* 1216 */         region(), 
/* 1217 */         verificationLevel(), 
/* 1218 */         defaultMessageNotifications(), 
/* 1219 */         explicitContentFilter(), 
/* 1220 */         afkChannelId(), 
/* 1221 */         afkTimeout(), 
/* 1222 */         icon(), 
/* 1223 */         ownerId(), 
/* 1224 */         splash(), newValue, 
/*      */         
/* 1226 */         banner(), 
/* 1227 */         systemChannelId(), 
/* 1228 */         systemChannelFlags(), 
/* 1229 */         rulesChannelId(), 
/* 1230 */         publicUpdatesChannelId(), 
/* 1231 */         preferredLocale(), 
/* 1232 */         features(), 
/* 1233 */         description(), 
/* 1234 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableGuildModifyRequest withBanner(Possible<Optional<String>> value) {
/* 1238 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/* 1239 */     return new ImmutableGuildModifyRequest(this, 
/*      */         
/* 1241 */         name(), 
/* 1242 */         region(), 
/* 1243 */         verificationLevel(), 
/* 1244 */         defaultMessageNotifications(), 
/* 1245 */         explicitContentFilter(), 
/* 1246 */         afkChannelId(), 
/* 1247 */         afkTimeout(), 
/* 1248 */         icon(), 
/* 1249 */         ownerId(), 
/* 1250 */         splash(), 
/* 1251 */         discoverySplash(), newValue, 
/*      */         
/* 1253 */         systemChannelId(), 
/* 1254 */         systemChannelFlags(), 
/* 1255 */         rulesChannelId(), 
/* 1256 */         publicUpdatesChannelId(), 
/* 1257 */         preferredLocale(), 
/* 1258 */         features(), 
/* 1259 */         description(), 
/* 1260 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableGuildModifyRequest withBanner(@Nullable String value) {
/* 1265 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 1266 */     return new ImmutableGuildModifyRequest(this, 
/*      */         
/* 1268 */         name(), 
/* 1269 */         region(), 
/* 1270 */         verificationLevel(), 
/* 1271 */         defaultMessageNotifications(), 
/* 1272 */         explicitContentFilter(), 
/* 1273 */         afkChannelId(), 
/* 1274 */         afkTimeout(), 
/* 1275 */         icon(), 
/* 1276 */         ownerId(), 
/* 1277 */         splash(), 
/* 1278 */         discoverySplash(), newValue, 
/*      */         
/* 1280 */         systemChannelId(), 
/* 1281 */         systemChannelFlags(), 
/* 1282 */         rulesChannelId(), 
/* 1283 */         publicUpdatesChannelId(), 
/* 1284 */         preferredLocale(), 
/* 1285 */         features(), 
/* 1286 */         description(), 
/* 1287 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableGuildModifyRequest withBannerOrNull(@Nullable String value) {
/* 1291 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 1292 */     return new ImmutableGuildModifyRequest(this, 
/*      */         
/* 1294 */         name(), 
/* 1295 */         region(), 
/* 1296 */         verificationLevel(), 
/* 1297 */         defaultMessageNotifications(), 
/* 1298 */         explicitContentFilter(), 
/* 1299 */         afkChannelId(), 
/* 1300 */         afkTimeout(), 
/* 1301 */         icon(), 
/* 1302 */         ownerId(), 
/* 1303 */         splash(), 
/* 1304 */         discoverySplash(), newValue, 
/*      */         
/* 1306 */         systemChannelId(), 
/* 1307 */         systemChannelFlags(), 
/* 1308 */         rulesChannelId(), 
/* 1309 */         publicUpdatesChannelId(), 
/* 1310 */         preferredLocale(), 
/* 1311 */         features(), 
/* 1312 */         description(), 
/* 1313 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableGuildModifyRequest withSystemChannelId(Possible<Optional<String>> value) {
/* 1317 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/* 1318 */     return new ImmutableGuildModifyRequest(this, 
/*      */         
/* 1320 */         name(), 
/* 1321 */         region(), 
/* 1322 */         verificationLevel(), 
/* 1323 */         defaultMessageNotifications(), 
/* 1324 */         explicitContentFilter(), 
/* 1325 */         afkChannelId(), 
/* 1326 */         afkTimeout(), 
/* 1327 */         icon(), 
/* 1328 */         ownerId(), 
/* 1329 */         splash(), 
/* 1330 */         discoverySplash(), 
/* 1331 */         banner(), newValue, 
/*      */         
/* 1333 */         systemChannelFlags(), 
/* 1334 */         rulesChannelId(), 
/* 1335 */         publicUpdatesChannelId(), 
/* 1336 */         preferredLocale(), 
/* 1337 */         features(), 
/* 1338 */         description(), 
/* 1339 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableGuildModifyRequest withSystemChannelId(@Nullable String value) {
/* 1344 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 1345 */     return new ImmutableGuildModifyRequest(this, 
/*      */         
/* 1347 */         name(), 
/* 1348 */         region(), 
/* 1349 */         verificationLevel(), 
/* 1350 */         defaultMessageNotifications(), 
/* 1351 */         explicitContentFilter(), 
/* 1352 */         afkChannelId(), 
/* 1353 */         afkTimeout(), 
/* 1354 */         icon(), 
/* 1355 */         ownerId(), 
/* 1356 */         splash(), 
/* 1357 */         discoverySplash(), 
/* 1358 */         banner(), newValue, 
/*      */         
/* 1360 */         systemChannelFlags(), 
/* 1361 */         rulesChannelId(), 
/* 1362 */         publicUpdatesChannelId(), 
/* 1363 */         preferredLocale(), 
/* 1364 */         features(), 
/* 1365 */         description(), 
/* 1366 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableGuildModifyRequest withSystemChannelIdOrNull(@Nullable String value) {
/* 1370 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 1371 */     return new ImmutableGuildModifyRequest(this, 
/*      */         
/* 1373 */         name(), 
/* 1374 */         region(), 
/* 1375 */         verificationLevel(), 
/* 1376 */         defaultMessageNotifications(), 
/* 1377 */         explicitContentFilter(), 
/* 1378 */         afkChannelId(), 
/* 1379 */         afkTimeout(), 
/* 1380 */         icon(), 
/* 1381 */         ownerId(), 
/* 1382 */         splash(), 
/* 1383 */         discoverySplash(), 
/* 1384 */         banner(), newValue, 
/*      */         
/* 1386 */         systemChannelFlags(), 
/* 1387 */         rulesChannelId(), 
/* 1388 */         publicUpdatesChannelId(), 
/* 1389 */         preferredLocale(), 
/* 1390 */         features(), 
/* 1391 */         description(), 
/* 1392 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableGuildModifyRequest withSystemChannelFlags(Possible<Integer> value) {
/* 1396 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 1397 */     return new ImmutableGuildModifyRequest(this, 
/*      */         
/* 1399 */         name(), 
/* 1400 */         region(), 
/* 1401 */         verificationLevel(), 
/* 1402 */         defaultMessageNotifications(), 
/* 1403 */         explicitContentFilter(), 
/* 1404 */         afkChannelId(), 
/* 1405 */         afkTimeout(), 
/* 1406 */         icon(), 
/* 1407 */         ownerId(), 
/* 1408 */         splash(), 
/* 1409 */         discoverySplash(), 
/* 1410 */         banner(), 
/* 1411 */         systemChannelId(), newValue, 
/*      */         
/* 1413 */         rulesChannelId(), 
/* 1414 */         publicUpdatesChannelId(), 
/* 1415 */         preferredLocale(), 
/* 1416 */         features(), 
/* 1417 */         description(), 
/* 1418 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableGuildModifyRequest withSystemChannelFlags(Integer value) {
/* 1422 */     Possible<Integer> newValue = Possible.of(value);
/* 1423 */     return new ImmutableGuildModifyRequest(this, 
/*      */         
/* 1425 */         name(), 
/* 1426 */         region(), 
/* 1427 */         verificationLevel(), 
/* 1428 */         defaultMessageNotifications(), 
/* 1429 */         explicitContentFilter(), 
/* 1430 */         afkChannelId(), 
/* 1431 */         afkTimeout(), 
/* 1432 */         icon(), 
/* 1433 */         ownerId(), 
/* 1434 */         splash(), 
/* 1435 */         discoverySplash(), 
/* 1436 */         banner(), 
/* 1437 */         systemChannelId(), newValue, 
/*      */         
/* 1439 */         rulesChannelId(), 
/* 1440 */         publicUpdatesChannelId(), 
/* 1441 */         preferredLocale(), 
/* 1442 */         features(), 
/* 1443 */         description(), 
/* 1444 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableGuildModifyRequest withRulesChannelId(Possible<Optional<String>> value) {
/* 1448 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/* 1449 */     return new ImmutableGuildModifyRequest(this, 
/*      */         
/* 1451 */         name(), 
/* 1452 */         region(), 
/* 1453 */         verificationLevel(), 
/* 1454 */         defaultMessageNotifications(), 
/* 1455 */         explicitContentFilter(), 
/* 1456 */         afkChannelId(), 
/* 1457 */         afkTimeout(), 
/* 1458 */         icon(), 
/* 1459 */         ownerId(), 
/* 1460 */         splash(), 
/* 1461 */         discoverySplash(), 
/* 1462 */         banner(), 
/* 1463 */         systemChannelId(), 
/* 1464 */         systemChannelFlags(), newValue, 
/*      */         
/* 1466 */         publicUpdatesChannelId(), 
/* 1467 */         preferredLocale(), 
/* 1468 */         features(), 
/* 1469 */         description(), 
/* 1470 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableGuildModifyRequest withRulesChannelId(@Nullable String value) {
/* 1475 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 1476 */     return new ImmutableGuildModifyRequest(this, 
/*      */         
/* 1478 */         name(), 
/* 1479 */         region(), 
/* 1480 */         verificationLevel(), 
/* 1481 */         defaultMessageNotifications(), 
/* 1482 */         explicitContentFilter(), 
/* 1483 */         afkChannelId(), 
/* 1484 */         afkTimeout(), 
/* 1485 */         icon(), 
/* 1486 */         ownerId(), 
/* 1487 */         splash(), 
/* 1488 */         discoverySplash(), 
/* 1489 */         banner(), 
/* 1490 */         systemChannelId(), 
/* 1491 */         systemChannelFlags(), newValue, 
/*      */         
/* 1493 */         publicUpdatesChannelId(), 
/* 1494 */         preferredLocale(), 
/* 1495 */         features(), 
/* 1496 */         description(), 
/* 1497 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableGuildModifyRequest withRulesChannelIdOrNull(@Nullable String value) {
/* 1501 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 1502 */     return new ImmutableGuildModifyRequest(this, 
/*      */         
/* 1504 */         name(), 
/* 1505 */         region(), 
/* 1506 */         verificationLevel(), 
/* 1507 */         defaultMessageNotifications(), 
/* 1508 */         explicitContentFilter(), 
/* 1509 */         afkChannelId(), 
/* 1510 */         afkTimeout(), 
/* 1511 */         icon(), 
/* 1512 */         ownerId(), 
/* 1513 */         splash(), 
/* 1514 */         discoverySplash(), 
/* 1515 */         banner(), 
/* 1516 */         systemChannelId(), 
/* 1517 */         systemChannelFlags(), newValue, 
/*      */         
/* 1519 */         publicUpdatesChannelId(), 
/* 1520 */         preferredLocale(), 
/* 1521 */         features(), 
/* 1522 */         description(), 
/* 1523 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableGuildModifyRequest withPublicUpdatesChannelId(Possible<Optional<String>> value) {
/* 1527 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/* 1528 */     return new ImmutableGuildModifyRequest(this, 
/*      */         
/* 1530 */         name(), 
/* 1531 */         region(), 
/* 1532 */         verificationLevel(), 
/* 1533 */         defaultMessageNotifications(), 
/* 1534 */         explicitContentFilter(), 
/* 1535 */         afkChannelId(), 
/* 1536 */         afkTimeout(), 
/* 1537 */         icon(), 
/* 1538 */         ownerId(), 
/* 1539 */         splash(), 
/* 1540 */         discoverySplash(), 
/* 1541 */         banner(), 
/* 1542 */         systemChannelId(), 
/* 1543 */         systemChannelFlags(), 
/* 1544 */         rulesChannelId(), newValue, 
/*      */         
/* 1546 */         preferredLocale(), 
/* 1547 */         features(), 
/* 1548 */         description(), 
/* 1549 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableGuildModifyRequest withPublicUpdatesChannelId(@Nullable String value) {
/* 1554 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 1555 */     return new ImmutableGuildModifyRequest(this, 
/*      */         
/* 1557 */         name(), 
/* 1558 */         region(), 
/* 1559 */         verificationLevel(), 
/* 1560 */         defaultMessageNotifications(), 
/* 1561 */         explicitContentFilter(), 
/* 1562 */         afkChannelId(), 
/* 1563 */         afkTimeout(), 
/* 1564 */         icon(), 
/* 1565 */         ownerId(), 
/* 1566 */         splash(), 
/* 1567 */         discoverySplash(), 
/* 1568 */         banner(), 
/* 1569 */         systemChannelId(), 
/* 1570 */         systemChannelFlags(), 
/* 1571 */         rulesChannelId(), newValue, 
/*      */         
/* 1573 */         preferredLocale(), 
/* 1574 */         features(), 
/* 1575 */         description(), 
/* 1576 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableGuildModifyRequest withPublicUpdatesChannelIdOrNull(@Nullable String value) {
/* 1580 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 1581 */     return new ImmutableGuildModifyRequest(this, 
/*      */         
/* 1583 */         name(), 
/* 1584 */         region(), 
/* 1585 */         verificationLevel(), 
/* 1586 */         defaultMessageNotifications(), 
/* 1587 */         explicitContentFilter(), 
/* 1588 */         afkChannelId(), 
/* 1589 */         afkTimeout(), 
/* 1590 */         icon(), 
/* 1591 */         ownerId(), 
/* 1592 */         splash(), 
/* 1593 */         discoverySplash(), 
/* 1594 */         banner(), 
/* 1595 */         systemChannelId(), 
/* 1596 */         systemChannelFlags(), 
/* 1597 */         rulesChannelId(), newValue, 
/*      */         
/* 1599 */         preferredLocale(), 
/* 1600 */         features(), 
/* 1601 */         description(), 
/* 1602 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableGuildModifyRequest withPreferredLocale(Possible<Optional<String>> value) {
/* 1606 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/* 1607 */     return new ImmutableGuildModifyRequest(this, 
/*      */         
/* 1609 */         name(), 
/* 1610 */         region(), 
/* 1611 */         verificationLevel(), 
/* 1612 */         defaultMessageNotifications(), 
/* 1613 */         explicitContentFilter(), 
/* 1614 */         afkChannelId(), 
/* 1615 */         afkTimeout(), 
/* 1616 */         icon(), 
/* 1617 */         ownerId(), 
/* 1618 */         splash(), 
/* 1619 */         discoverySplash(), 
/* 1620 */         banner(), 
/* 1621 */         systemChannelId(), 
/* 1622 */         systemChannelFlags(), 
/* 1623 */         rulesChannelId(), 
/* 1624 */         publicUpdatesChannelId(), newValue, 
/*      */         
/* 1626 */         features(), 
/* 1627 */         description(), 
/* 1628 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableGuildModifyRequest withPreferredLocale(@Nullable String value) {
/* 1633 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 1634 */     return new ImmutableGuildModifyRequest(this, 
/*      */         
/* 1636 */         name(), 
/* 1637 */         region(), 
/* 1638 */         verificationLevel(), 
/* 1639 */         defaultMessageNotifications(), 
/* 1640 */         explicitContentFilter(), 
/* 1641 */         afkChannelId(), 
/* 1642 */         afkTimeout(), 
/* 1643 */         icon(), 
/* 1644 */         ownerId(), 
/* 1645 */         splash(), 
/* 1646 */         discoverySplash(), 
/* 1647 */         banner(), 
/* 1648 */         systemChannelId(), 
/* 1649 */         systemChannelFlags(), 
/* 1650 */         rulesChannelId(), 
/* 1651 */         publicUpdatesChannelId(), newValue, 
/*      */         
/* 1653 */         features(), 
/* 1654 */         description(), 
/* 1655 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableGuildModifyRequest withPreferredLocaleOrNull(@Nullable String value) {
/* 1659 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 1660 */     return new ImmutableGuildModifyRequest(this, 
/*      */         
/* 1662 */         name(), 
/* 1663 */         region(), 
/* 1664 */         verificationLevel(), 
/* 1665 */         defaultMessageNotifications(), 
/* 1666 */         explicitContentFilter(), 
/* 1667 */         afkChannelId(), 
/* 1668 */         afkTimeout(), 
/* 1669 */         icon(), 
/* 1670 */         ownerId(), 
/* 1671 */         splash(), 
/* 1672 */         discoverySplash(), 
/* 1673 */         banner(), 
/* 1674 */         systemChannelId(), 
/* 1675 */         systemChannelFlags(), 
/* 1676 */         rulesChannelId(), 
/* 1677 */         publicUpdatesChannelId(), newValue, 
/*      */         
/* 1679 */         features(), 
/* 1680 */         description(), 
/* 1681 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableGuildModifyRequest withFeatures(Possible<List<String>> possible) {
/* 1685 */     Possible<List<String>> newValue = Objects.<Possible<List<String>>>requireNonNull(possible);
/* 1686 */     return new ImmutableGuildModifyRequest(this, 
/*      */         
/* 1688 */         name(), 
/* 1689 */         region(), 
/* 1690 */         verificationLevel(), 
/* 1691 */         defaultMessageNotifications(), 
/* 1692 */         explicitContentFilter(), 
/* 1693 */         afkChannelId(), 
/* 1694 */         afkTimeout(), 
/* 1695 */         icon(), 
/* 1696 */         ownerId(), 
/* 1697 */         splash(), 
/* 1698 */         discoverySplash(), 
/* 1699 */         banner(), 
/* 1700 */         systemChannelId(), 
/* 1701 */         systemChannelFlags(), 
/* 1702 */         rulesChannelId(), 
/* 1703 */         publicUpdatesChannelId(), 
/* 1704 */         preferredLocale(), newValue, 
/*      */         
/* 1706 */         description(), 
/* 1707 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableGuildModifyRequest withFeatures(Iterable<String> elements) {
/* 1711 */     Possible<List<String>> newValue = Possible.of(
/* 1712 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/* 1713 */     return new ImmutableGuildModifyRequest(this, 
/*      */         
/* 1715 */         name(), 
/* 1716 */         region(), 
/* 1717 */         verificationLevel(), 
/* 1718 */         defaultMessageNotifications(), 
/* 1719 */         explicitContentFilter(), 
/* 1720 */         afkChannelId(), 
/* 1721 */         afkTimeout(), 
/* 1722 */         icon(), 
/* 1723 */         ownerId(), 
/* 1724 */         splash(), 
/* 1725 */         discoverySplash(), 
/* 1726 */         banner(), 
/* 1727 */         systemChannelId(), 
/* 1728 */         systemChannelFlags(), 
/* 1729 */         rulesChannelId(), 
/* 1730 */         publicUpdatesChannelId(), 
/* 1731 */         preferredLocale(), newValue, 
/*      */         
/* 1733 */         description(), 
/* 1734 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   @SafeVarargs
/*      */   public final ImmutableGuildModifyRequest withFeatures(String... elements) {
/* 1739 */     Possible<List<String>> newValue = Possible.of(Arrays.asList(elements));
/* 1740 */     return new ImmutableGuildModifyRequest(this, 
/*      */         
/* 1742 */         name(), 
/* 1743 */         region(), 
/* 1744 */         verificationLevel(), 
/* 1745 */         defaultMessageNotifications(), 
/* 1746 */         explicitContentFilter(), 
/* 1747 */         afkChannelId(), 
/* 1748 */         afkTimeout(), 
/* 1749 */         icon(), 
/* 1750 */         ownerId(), 
/* 1751 */         splash(), 
/* 1752 */         discoverySplash(), 
/* 1753 */         banner(), 
/* 1754 */         systemChannelId(), 
/* 1755 */         systemChannelFlags(), 
/* 1756 */         rulesChannelId(), 
/* 1757 */         publicUpdatesChannelId(), 
/* 1758 */         preferredLocale(), newValue, 
/*      */         
/* 1760 */         description(), 
/* 1761 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableGuildModifyRequest withDescription(Possible<Optional<String>> value) {
/* 1765 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/* 1766 */     return new ImmutableGuildModifyRequest(this, 
/*      */         
/* 1768 */         name(), 
/* 1769 */         region(), 
/* 1770 */         verificationLevel(), 
/* 1771 */         defaultMessageNotifications(), 
/* 1772 */         explicitContentFilter(), 
/* 1773 */         afkChannelId(), 
/* 1774 */         afkTimeout(), 
/* 1775 */         icon(), 
/* 1776 */         ownerId(), 
/* 1777 */         splash(), 
/* 1778 */         discoverySplash(), 
/* 1779 */         banner(), 
/* 1780 */         systemChannelId(), 
/* 1781 */         systemChannelFlags(), 
/* 1782 */         rulesChannelId(), 
/* 1783 */         publicUpdatesChannelId(), 
/* 1784 */         preferredLocale(), 
/* 1785 */         features(), newValue, 
/*      */         
/* 1787 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableGuildModifyRequest withDescription(@Nullable String value) {
/* 1792 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 1793 */     return new ImmutableGuildModifyRequest(this, 
/*      */         
/* 1795 */         name(), 
/* 1796 */         region(), 
/* 1797 */         verificationLevel(), 
/* 1798 */         defaultMessageNotifications(), 
/* 1799 */         explicitContentFilter(), 
/* 1800 */         afkChannelId(), 
/* 1801 */         afkTimeout(), 
/* 1802 */         icon(), 
/* 1803 */         ownerId(), 
/* 1804 */         splash(), 
/* 1805 */         discoverySplash(), 
/* 1806 */         banner(), 
/* 1807 */         systemChannelId(), 
/* 1808 */         systemChannelFlags(), 
/* 1809 */         rulesChannelId(), 
/* 1810 */         publicUpdatesChannelId(), 
/* 1811 */         preferredLocale(), 
/* 1812 */         features(), newValue, 
/*      */         
/* 1814 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableGuildModifyRequest withDescriptionOrNull(@Nullable String value) {
/* 1818 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 1819 */     return new ImmutableGuildModifyRequest(this, 
/*      */         
/* 1821 */         name(), 
/* 1822 */         region(), 
/* 1823 */         verificationLevel(), 
/* 1824 */         defaultMessageNotifications(), 
/* 1825 */         explicitContentFilter(), 
/* 1826 */         afkChannelId(), 
/* 1827 */         afkTimeout(), 
/* 1828 */         icon(), 
/* 1829 */         ownerId(), 
/* 1830 */         splash(), 
/* 1831 */         discoverySplash(), 
/* 1832 */         banner(), 
/* 1833 */         systemChannelId(), 
/* 1834 */         systemChannelFlags(), 
/* 1835 */         rulesChannelId(), 
/* 1836 */         publicUpdatesChannelId(), 
/* 1837 */         preferredLocale(), 
/* 1838 */         features(), newValue, 
/*      */         
/* 1840 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableGuildModifyRequest withSafetyAlertsChannelId(Possible<Optional<String>> value) {
/* 1844 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/* 1845 */     return new ImmutableGuildModifyRequest(this, 
/*      */         
/* 1847 */         name(), 
/* 1848 */         region(), 
/* 1849 */         verificationLevel(), 
/* 1850 */         defaultMessageNotifications(), 
/* 1851 */         explicitContentFilter(), 
/* 1852 */         afkChannelId(), 
/* 1853 */         afkTimeout(), 
/* 1854 */         icon(), 
/* 1855 */         ownerId(), 
/* 1856 */         splash(), 
/* 1857 */         discoverySplash(), 
/* 1858 */         banner(), 
/* 1859 */         systemChannelId(), 
/* 1860 */         systemChannelFlags(), 
/* 1861 */         rulesChannelId(), 
/* 1862 */         publicUpdatesChannelId(), 
/* 1863 */         preferredLocale(), 
/* 1864 */         features(), 
/* 1865 */         description(), newValue);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableGuildModifyRequest withSafetyAlertsChannelId(@Nullable String value) {
/* 1871 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 1872 */     return new ImmutableGuildModifyRequest(this, 
/*      */         
/* 1874 */         name(), 
/* 1875 */         region(), 
/* 1876 */         verificationLevel(), 
/* 1877 */         defaultMessageNotifications(), 
/* 1878 */         explicitContentFilter(), 
/* 1879 */         afkChannelId(), 
/* 1880 */         afkTimeout(), 
/* 1881 */         icon(), 
/* 1882 */         ownerId(), 
/* 1883 */         splash(), 
/* 1884 */         discoverySplash(), 
/* 1885 */         banner(), 
/* 1886 */         systemChannelId(), 
/* 1887 */         systemChannelFlags(), 
/* 1888 */         rulesChannelId(), 
/* 1889 */         publicUpdatesChannelId(), 
/* 1890 */         preferredLocale(), 
/* 1891 */         features(), 
/* 1892 */         description(), newValue);
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableGuildModifyRequest withSafetyAlertsChannelIdOrNull(@Nullable String value) {
/* 1897 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 1898 */     return new ImmutableGuildModifyRequest(this, 
/*      */         
/* 1900 */         name(), 
/* 1901 */         region(), 
/* 1902 */         verificationLevel(), 
/* 1903 */         defaultMessageNotifications(), 
/* 1904 */         explicitContentFilter(), 
/* 1905 */         afkChannelId(), 
/* 1906 */         afkTimeout(), 
/* 1907 */         icon(), 
/* 1908 */         ownerId(), 
/* 1909 */         splash(), 
/* 1910 */         discoverySplash(), 
/* 1911 */         banner(), 
/* 1912 */         systemChannelId(), 
/* 1913 */         systemChannelFlags(), 
/* 1914 */         rulesChannelId(), 
/* 1915 */         publicUpdatesChannelId(), 
/* 1916 */         preferredLocale(), 
/* 1917 */         features(), 
/* 1918 */         description(), newValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object another) {
/* 1928 */     if (this == another) return true; 
/* 1929 */     return (another instanceof ImmutableGuildModifyRequest && 
/* 1930 */       equalTo(0, (ImmutableGuildModifyRequest)another));
/*      */   }
/*      */   
/*      */   private boolean equalTo(int synthetic, ImmutableGuildModifyRequest another) {
/* 1934 */     return (name().equals(another.name()) && 
/* 1935 */       region().equals(another.region()) && 
/* 1936 */       verificationLevel().equals(another.verificationLevel()) && 
/* 1937 */       defaultMessageNotifications().equals(another.defaultMessageNotifications()) && 
/* 1938 */       explicitContentFilter().equals(another.explicitContentFilter()) && 
/* 1939 */       afkChannelId().equals(another.afkChannelId()) && 
/* 1940 */       afkTimeout().equals(another.afkTimeout()) && 
/* 1941 */       icon().equals(another.icon()) && 
/* 1942 */       ownerId().equals(another.ownerId()) && 
/* 1943 */       splash().equals(another.splash()) && 
/* 1944 */       discoverySplash().equals(another.discoverySplash()) && 
/* 1945 */       banner().equals(another.banner()) && 
/* 1946 */       systemChannelId().equals(another.systemChannelId()) && 
/* 1947 */       systemChannelFlags().equals(another.systemChannelFlags()) && 
/* 1948 */       rulesChannelId().equals(another.rulesChannelId()) && 
/* 1949 */       publicUpdatesChannelId().equals(another.publicUpdatesChannelId()) && 
/* 1950 */       preferredLocale().equals(another.preferredLocale()) && 
/* 1951 */       Objects.equals(this.features_value, another.features_value) && 
/* 1952 */       description().equals(another.description()) && 
/* 1953 */       safetyAlertsChannelId().equals(another.safetyAlertsChannelId()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/* 1962 */     int h = 5381;
/* 1963 */     h += (h << 5) + name().hashCode();
/* 1964 */     h += (h << 5) + region().hashCode();
/* 1965 */     h += (h << 5) + verificationLevel().hashCode();
/* 1966 */     h += (h << 5) + defaultMessageNotifications().hashCode();
/* 1967 */     h += (h << 5) + explicitContentFilter().hashCode();
/* 1968 */     h += (h << 5) + afkChannelId().hashCode();
/* 1969 */     h += (h << 5) + afkTimeout().hashCode();
/* 1970 */     h += (h << 5) + icon().hashCode();
/* 1971 */     h += (h << 5) + ownerId().hashCode();
/* 1972 */     h += (h << 5) + splash().hashCode();
/* 1973 */     h += (h << 5) + discoverySplash().hashCode();
/* 1974 */     h += (h << 5) + banner().hashCode();
/* 1975 */     h += (h << 5) + systemChannelId().hashCode();
/* 1976 */     h += (h << 5) + systemChannelFlags().hashCode();
/* 1977 */     h += (h << 5) + rulesChannelId().hashCode();
/* 1978 */     h += (h << 5) + publicUpdatesChannelId().hashCode();
/* 1979 */     h += (h << 5) + preferredLocale().hashCode();
/* 1980 */     h += (h << 5) + Objects.hashCode(this.features_value);
/* 1981 */     h += (h << 5) + description().hashCode();
/* 1982 */     h += (h << 5) + safetyAlertsChannelId().hashCode();
/* 1983 */     return h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1992 */     return "GuildModifyRequest{name=" + 
/* 1993 */       name().toString() + ", region=" + 
/* 1994 */       region().toString() + ", verificationLevel=" + 
/* 1995 */       verificationLevel().toString() + ", defaultMessageNotifications=" + 
/* 1996 */       defaultMessageNotifications().toString() + ", explicitContentFilter=" + 
/* 1997 */       explicitContentFilter().toString() + ", afkChannelId=" + 
/* 1998 */       afkChannelId().toString() + ", afkTimeout=" + 
/* 1999 */       afkTimeout().toString() + ", icon=" + 
/* 2000 */       icon().toString() + ", ownerId=" + 
/* 2001 */       ownerId().toString() + ", splash=" + 
/* 2002 */       splash().toString() + ", discoverySplash=" + 
/* 2003 */       discoverySplash().toString() + ", banner=" + 
/* 2004 */       banner().toString() + ", systemChannelId=" + 
/* 2005 */       systemChannelId().toString() + ", systemChannelFlags=" + 
/* 2006 */       systemChannelFlags().toString() + ", rulesChannelId=" + 
/* 2007 */       rulesChannelId().toString() + ", publicUpdatesChannelId=" + 
/* 2008 */       publicUpdatesChannelId().toString() + ", preferredLocale=" + 
/* 2009 */       preferredLocale().toString() + ", features=" + 
/* 2010 */       Objects.toString(this.features_value) + ", description=" + 
/* 2011 */       description().toString() + ", safetyAlertsChannelId=" + 
/* 2012 */       safetyAlertsChannelId().toString() + "}";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonDeserialize
/*      */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*      */   @Generated(from = "GuildModifyRequest", generator = "Immutables")
/*      */   static final class Json
/*      */     implements GuildModifyRequest
/*      */   {
/* 2026 */     Possible<String> name = Possible.absent();
/*      */ 
/*      */     
/* 2029 */     Possible<Optional<String>> region = Possible.absent();
/*      */ 
/*      */     
/* 2032 */     Possible<Optional<Integer>> verificationLevel = Possible.absent();
/*      */ 
/*      */     
/* 2035 */     Possible<Optional<Integer>> defaultMessageNotifications = Possible.absent();
/*      */ 
/*      */     
/* 2038 */     Possible<Optional<Integer>> explicitContentFilter = Possible.absent();
/*      */ 
/*      */     
/* 2041 */     Possible<Optional<String>> afkChannelId = Possible.absent();
/*      */ 
/*      */     
/* 2044 */     Possible<Integer> afkTimeout = Possible.absent();
/*      */ 
/*      */     
/* 2047 */     Possible<Optional<String>> icon = Possible.absent();
/*      */ 
/*      */     
/* 2050 */     Possible<String> ownerId = Possible.absent();
/*      */ 
/*      */     
/* 2053 */     Possible<Optional<String>> splash = Possible.absent();
/*      */ 
/*      */     
/* 2056 */     Possible<Optional<String>> discoverySplash = Possible.absent();
/*      */ 
/*      */     
/* 2059 */     Possible<Optional<String>> banner = Possible.absent();
/*      */ 
/*      */     
/* 2062 */     Possible<Optional<String>> systemChannelId = Possible.absent();
/*      */ 
/*      */     
/* 2065 */     Possible<Integer> systemChannelFlags = Possible.absent();
/*      */ 
/*      */     
/* 2068 */     Possible<Optional<String>> rulesChannelId = Possible.absent();
/*      */ 
/*      */     
/* 2071 */     Possible<Optional<String>> publicUpdatesChannelId = Possible.absent();
/*      */ 
/*      */     
/* 2074 */     Possible<Optional<String>> preferredLocale = Possible.absent();
/*      */ 
/*      */     
/* 2077 */     Possible<List<String>> features = Possible.absent();
/*      */ 
/*      */     
/* 2080 */     Possible<Optional<String>> description = Possible.absent();
/*      */ 
/*      */     
/* 2083 */     Possible<Optional<String>> safetyAlertsChannelId = Possible.absent();
/*      */     
/*      */     @JsonProperty("name")
/*      */     public void setName(Possible<String> name) {
/* 2087 */       this.name = name;
/*      */     }
/*      */     @JsonProperty("region")
/*      */     public void setRegion(Possible<Optional<String>> region) {
/* 2091 */       this.region = region;
/*      */     }
/*      */     @JsonProperty("verification_level")
/*      */     public void setVerificationLevel(Possible<Optional<Integer>> verificationLevel) {
/* 2095 */       this.verificationLevel = verificationLevel;
/*      */     }
/*      */     @JsonProperty("default_message_notifications")
/*      */     public void setDefaultMessageNotifications(Possible<Optional<Integer>> defaultMessageNotifications) {
/* 2099 */       this.defaultMessageNotifications = defaultMessageNotifications;
/*      */     }
/*      */     @JsonProperty("explicit_content_filter")
/*      */     public void setExplicitContentFilter(Possible<Optional<Integer>> explicitContentFilter) {
/* 2103 */       this.explicitContentFilter = explicitContentFilter;
/*      */     }
/*      */     @JsonProperty("afk_channel_id")
/*      */     public void setAfkChannelId(Possible<Optional<String>> afkChannelId) {
/* 2107 */       this.afkChannelId = afkChannelId;
/*      */     }
/*      */     @JsonProperty("afk_timeout")
/*      */     public void setAfkTimeout(Possible<Integer> afkTimeout) {
/* 2111 */       this.afkTimeout = afkTimeout;
/*      */     }
/*      */     @JsonProperty("icon")
/*      */     public void setIcon(Possible<Optional<String>> icon) {
/* 2115 */       this.icon = icon;
/*      */     }
/*      */     @JsonProperty("owner_id")
/*      */     public void setOwnerId(Possible<String> ownerId) {
/* 2119 */       this.ownerId = ownerId;
/*      */     }
/*      */     @JsonProperty("splash")
/*      */     public void setSplash(Possible<Optional<String>> splash) {
/* 2123 */       this.splash = splash;
/*      */     }
/*      */     @JsonProperty("discovery_splash")
/*      */     public void setDiscoverySplash(Possible<Optional<String>> discoverySplash) {
/* 2127 */       this.discoverySplash = discoverySplash;
/*      */     }
/*      */     @JsonProperty("banner")
/*      */     public void setBanner(Possible<Optional<String>> banner) {
/* 2131 */       this.banner = banner;
/*      */     }
/*      */     @JsonProperty("system_channel_id")
/*      */     public void setSystemChannelId(Possible<Optional<String>> systemChannelId) {
/* 2135 */       this.systemChannelId = systemChannelId;
/*      */     }
/*      */     @JsonProperty("system_channel_flags")
/*      */     public void setSystemChannelFlags(Possible<Integer> systemChannelFlags) {
/* 2139 */       this.systemChannelFlags = systemChannelFlags;
/*      */     }
/*      */     @JsonProperty("rules_channel_id")
/*      */     public void setRulesChannelId(Possible<Optional<String>> rulesChannelId) {
/* 2143 */       this.rulesChannelId = rulesChannelId;
/*      */     }
/*      */     @JsonProperty("public_updates_channel_id")
/*      */     public void setPublicUpdatesChannelId(Possible<Optional<String>> publicUpdatesChannelId) {
/* 2147 */       this.publicUpdatesChannelId = publicUpdatesChannelId;
/*      */     }
/*      */     @JsonProperty("preferred_locale")
/*      */     public void setPreferredLocale(Possible<Optional<String>> preferredLocale) {
/* 2151 */       this.preferredLocale = preferredLocale;
/*      */     }
/*      */     @JsonProperty("features")
/*      */     public void setFeatures(Possible<List<String>> features) {
/* 2155 */       this.features = features;
/*      */     }
/*      */     @JsonProperty("description")
/*      */     public void setDescription(Possible<Optional<String>> description) {
/* 2159 */       this.description = description;
/*      */     }
/*      */     @JsonProperty("safety_alerts_channel_id")
/*      */     public void setSafetyAlertsChannelId(Possible<Optional<String>> safetyAlertsChannelId) {
/* 2163 */       this.safetyAlertsChannelId = safetyAlertsChannelId;
/*      */     }
/*      */     public Possible<String> name() {
/* 2166 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<String>> region() {
/* 2168 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<Integer>> verificationLevel() {
/* 2170 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<Integer>> defaultMessageNotifications() {
/* 2172 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<Integer>> explicitContentFilter() {
/* 2174 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<String>> afkChannelId() {
/* 2176 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> afkTimeout() {
/* 2178 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<String>> icon() {
/* 2180 */       throw new UnsupportedOperationException();
/*      */     } public Possible<String> ownerId() {
/* 2182 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<String>> splash() {
/* 2184 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<String>> discoverySplash() {
/* 2186 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<String>> banner() {
/* 2188 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<String>> systemChannelId() {
/* 2190 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> systemChannelFlags() {
/* 2192 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<String>> rulesChannelId() {
/* 2194 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<String>> publicUpdatesChannelId() {
/* 2196 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<String>> preferredLocale() {
/* 2198 */       throw new UnsupportedOperationException();
/*      */     } public Possible<List<String>> features() {
/* 2200 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<String>> description() {
/* 2202 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<String>> safetyAlertsChannelId() {
/* 2204 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*      */   static ImmutableGuildModifyRequest fromJson(Json json) {
/* 2215 */     Builder builder = builder();
/* 2216 */     if (json.name != null) {
/* 2217 */       builder.name(json.name);
/*      */     }
/* 2219 */     if (json.region != null) {
/* 2220 */       builder.region(json.region);
/*      */     }
/* 2222 */     if (json.verificationLevel != null) {
/* 2223 */       builder.verificationLevel(json.verificationLevel);
/*      */     }
/* 2225 */     if (json.defaultMessageNotifications != null) {
/* 2226 */       builder.defaultMessageNotifications(json.defaultMessageNotifications);
/*      */     }
/* 2228 */     if (json.explicitContentFilter != null) {
/* 2229 */       builder.explicitContentFilter(json.explicitContentFilter);
/*      */     }
/* 2231 */     if (json.afkChannelId != null) {
/* 2232 */       builder.afkChannelId(json.afkChannelId);
/*      */     }
/* 2234 */     if (json.afkTimeout != null) {
/* 2235 */       builder.afkTimeout(json.afkTimeout);
/*      */     }
/* 2237 */     if (json.icon != null) {
/* 2238 */       builder.icon(json.icon);
/*      */     }
/* 2240 */     if (json.ownerId != null) {
/* 2241 */       builder.ownerId(json.ownerId);
/*      */     }
/* 2243 */     if (json.splash != null) {
/* 2244 */       builder.splash(json.splash);
/*      */     }
/* 2246 */     if (json.discoverySplash != null) {
/* 2247 */       builder.discoverySplash(json.discoverySplash);
/*      */     }
/* 2249 */     if (json.banner != null) {
/* 2250 */       builder.banner(json.banner);
/*      */     }
/* 2252 */     if (json.systemChannelId != null) {
/* 2253 */       builder.systemChannelId(json.systemChannelId);
/*      */     }
/* 2255 */     if (json.systemChannelFlags != null) {
/* 2256 */       builder.systemChannelFlags(json.systemChannelFlags);
/*      */     }
/* 2258 */     if (json.rulesChannelId != null) {
/* 2259 */       builder.rulesChannelId(json.rulesChannelId);
/*      */     }
/* 2261 */     if (json.publicUpdatesChannelId != null) {
/* 2262 */       builder.publicUpdatesChannelId(json.publicUpdatesChannelId);
/*      */     }
/* 2264 */     if (json.preferredLocale != null) {
/* 2265 */       builder.preferredLocale(json.preferredLocale);
/*      */     }
/* 2267 */     if (json.features != null) {
/* 2268 */       builder.features(json.features);
/*      */     }
/* 2270 */     if (json.description != null) {
/* 2271 */       builder.description(json.description);
/*      */     }
/* 2273 */     if (json.safetyAlertsChannelId != null) {
/* 2274 */       builder.safetyAlertsChannelId(json.safetyAlertsChannelId);
/*      */     }
/* 2276 */     return builder.build();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableGuildModifyRequest of(Possible<String> name, Possible<Optional<String>> region, Possible<Optional<Integer>> verificationLevel, Possible<Optional<Integer>> defaultMessageNotifications, Possible<Optional<Integer>> explicitContentFilter, Possible<Optional<String>> afkChannelId, Possible<Integer> afkTimeout, Possible<Optional<String>> icon, Possible<String> ownerId, Possible<Optional<String>> splash, Possible<Optional<String>> discoverySplash, Possible<Optional<String>> banner, Possible<Optional<String>> systemChannelId, Possible<Integer> systemChannelFlags, Possible<Optional<String>> rulesChannelId, Possible<Optional<String>> publicUpdatesChannelId, Possible<Optional<String>> preferredLocale, Possible<List<String>> features, Possible<Optional<String>> description, Possible<Optional<String>> safetyAlertsChannelId) {
/* 2304 */     return new ImmutableGuildModifyRequest(name, region, verificationLevel, defaultMessageNotifications, explicitContentFilter, afkChannelId, afkTimeout, icon, ownerId, splash, discoverySplash, banner, systemChannelId, systemChannelFlags, rulesChannelId, publicUpdatesChannelId, preferredLocale, features, description, safetyAlertsChannelId);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableGuildModifyRequest copyOf(GuildModifyRequest instance) {
/* 2315 */     if (instance instanceof ImmutableGuildModifyRequest) {
/* 2316 */       return (ImmutableGuildModifyRequest)instance;
/*      */     }
/* 2318 */     return builder()
/* 2319 */       .from(instance)
/* 2320 */       .build();
/*      */   }
/*      */   
/*      */   public boolean isNamePresent() {
/* 2324 */     return !this.name_absent;
/*      */   }
/*      */   
/*      */   public String nameOrElse(String defaultValue) {
/* 2328 */     return !this.name_absent ? this.name_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isRegionPresent() {
/* 2332 */     return !this.region_absent;
/*      */   }
/*      */   
/*      */   public String regionOrElse(String defaultValue) {
/* 2336 */     return !this.region_absent ? this.region_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isVerificationLevelPresent() {
/* 2340 */     return !this.verificationLevel_absent;
/*      */   }
/*      */   
/*      */   public Integer verificationLevelOrElse(Integer defaultValue) {
/* 2344 */     return !this.verificationLevel_absent ? this.verificationLevel_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isDefaultMessageNotificationsPresent() {
/* 2348 */     return !this.defaultMessageNotifications_absent;
/*      */   }
/*      */   
/*      */   public Integer defaultMessageNotificationsOrElse(Integer defaultValue) {
/* 2352 */     return !this.defaultMessageNotifications_absent ? this.defaultMessageNotifications_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isExplicitContentFilterPresent() {
/* 2356 */     return !this.explicitContentFilter_absent;
/*      */   }
/*      */   
/*      */   public Integer explicitContentFilterOrElse(Integer defaultValue) {
/* 2360 */     return !this.explicitContentFilter_absent ? this.explicitContentFilter_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isAfkChannelIdPresent() {
/* 2364 */     return !this.afkChannelId_absent;
/*      */   }
/*      */   
/*      */   public String afkChannelIdOrElse(String defaultValue) {
/* 2368 */     return !this.afkChannelId_absent ? this.afkChannelId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isAfkTimeoutPresent() {
/* 2372 */     return !this.afkTimeout_absent;
/*      */   }
/*      */   
/*      */   public Integer afkTimeoutOrElse(Integer defaultValue) {
/* 2376 */     return !this.afkTimeout_absent ? this.afkTimeout_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isIconPresent() {
/* 2380 */     return !this.icon_absent;
/*      */   }
/*      */   
/*      */   public String iconOrElse(String defaultValue) {
/* 2384 */     return !this.icon_absent ? this.icon_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isOwnerIdPresent() {
/* 2388 */     return !this.ownerId_absent;
/*      */   }
/*      */   
/*      */   public String ownerIdOrElse(String defaultValue) {
/* 2392 */     return !this.ownerId_absent ? this.ownerId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isSplashPresent() {
/* 2396 */     return !this.splash_absent;
/*      */   }
/*      */   
/*      */   public String splashOrElse(String defaultValue) {
/* 2400 */     return !this.splash_absent ? this.splash_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isDiscoverySplashPresent() {
/* 2404 */     return !this.discoverySplash_absent;
/*      */   }
/*      */   
/*      */   public String discoverySplashOrElse(String defaultValue) {
/* 2408 */     return !this.discoverySplash_absent ? this.discoverySplash_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isBannerPresent() {
/* 2412 */     return !this.banner_absent;
/*      */   }
/*      */   
/*      */   public String bannerOrElse(String defaultValue) {
/* 2416 */     return !this.banner_absent ? this.banner_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isSystemChannelIdPresent() {
/* 2420 */     return !this.systemChannelId_absent;
/*      */   }
/*      */   
/*      */   public String systemChannelIdOrElse(String defaultValue) {
/* 2424 */     return !this.systemChannelId_absent ? this.systemChannelId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isSystemChannelFlagsPresent() {
/* 2428 */     return !this.systemChannelFlags_absent;
/*      */   }
/*      */   
/*      */   public Integer systemChannelFlagsOrElse(Integer defaultValue) {
/* 2432 */     return !this.systemChannelFlags_absent ? this.systemChannelFlags_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isRulesChannelIdPresent() {
/* 2436 */     return !this.rulesChannelId_absent;
/*      */   }
/*      */   
/*      */   public String rulesChannelIdOrElse(String defaultValue) {
/* 2440 */     return !this.rulesChannelId_absent ? this.rulesChannelId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isPublicUpdatesChannelIdPresent() {
/* 2444 */     return !this.publicUpdatesChannelId_absent;
/*      */   }
/*      */   
/*      */   public String publicUpdatesChannelIdOrElse(String defaultValue) {
/* 2448 */     return !this.publicUpdatesChannelId_absent ? this.publicUpdatesChannelId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isPreferredLocalePresent() {
/* 2452 */     return !this.preferredLocale_absent;
/*      */   }
/*      */   
/*      */   public String preferredLocaleOrElse(String defaultValue) {
/* 2456 */     return !this.preferredLocale_absent ? this.preferredLocale_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isFeaturesPresent() {
/* 2460 */     return !this.features_absent;
/*      */   }
/*      */   
/*      */   public List<String> featuresOrElse(List<String> defaultValue) {
/* 2464 */     return !this.features_absent ? this.features_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isDescriptionPresent() {
/* 2468 */     return !this.description_absent;
/*      */   }
/*      */   
/*      */   public String descriptionOrElse(String defaultValue) {
/* 2472 */     return !this.description_absent ? this.description_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isSafetyAlertsChannelIdPresent() {
/* 2476 */     return !this.safetyAlertsChannelId_absent;
/*      */   }
/*      */   
/*      */   public String safetyAlertsChannelIdOrElse(String defaultValue) {
/* 2480 */     return !this.safetyAlertsChannelId_absent ? this.safetyAlertsChannelId_value : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Builder builder() {
/* 2512 */     return new Builder();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Generated(from = "GuildModifyRequest", generator = "Immutables")
/*      */   public static final class Builder
/*      */   {
/* 2524 */     private Possible<String> name_possible = Possible.absent();
/* 2525 */     private Possible<Optional<String>> region_possible = Possible.absent();
/* 2526 */     private Possible<Optional<Integer>> verificationLevel_possible = Possible.absent();
/* 2527 */     private Possible<Optional<Integer>> defaultMessageNotifications_possible = Possible.absent();
/* 2528 */     private Possible<Optional<Integer>> explicitContentFilter_possible = Possible.absent();
/* 2529 */     private Possible<Optional<String>> afkChannelId_possible = Possible.absent();
/* 2530 */     private Possible<Integer> afkTimeout_possible = Possible.absent();
/* 2531 */     private Possible<Optional<String>> icon_possible = Possible.absent();
/* 2532 */     private Possible<String> ownerId_possible = Possible.absent();
/* 2533 */     private Possible<Optional<String>> splash_possible = Possible.absent();
/* 2534 */     private Possible<Optional<String>> discoverySplash_possible = Possible.absent();
/* 2535 */     private Possible<Optional<String>> banner_possible = Possible.absent();
/* 2536 */     private Possible<Optional<String>> systemChannelId_possible = Possible.absent();
/* 2537 */     private Possible<Integer> systemChannelFlags_possible = Possible.absent();
/* 2538 */     private Possible<Optional<String>> rulesChannelId_possible = Possible.absent();
/* 2539 */     private Possible<Optional<String>> publicUpdatesChannelId_possible = Possible.absent();
/* 2540 */     private Possible<Optional<String>> preferredLocale_possible = Possible.absent();
/* 2541 */     private List<String> features_list = null;
/* 2542 */     private Possible<Optional<String>> description_possible = Possible.absent();
/* 2543 */     private Possible<Optional<String>> safetyAlertsChannelId_possible = Possible.absent();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(GuildModifyRequest instance) {
/* 2556 */       Objects.requireNonNull(instance, "instance");
/* 2557 */       name(instance.name());
/* 2558 */       region(instance.region());
/* 2559 */       verificationLevel(instance.verificationLevel());
/* 2560 */       defaultMessageNotifications(instance.defaultMessageNotifications());
/* 2561 */       explicitContentFilter(instance.explicitContentFilter());
/* 2562 */       afkChannelId(instance.afkChannelId());
/* 2563 */       afkTimeout(instance.afkTimeout());
/* 2564 */       icon(instance.icon());
/* 2565 */       ownerId(instance.ownerId());
/* 2566 */       splash(instance.splash());
/* 2567 */       discoverySplash(instance.discoverySplash());
/* 2568 */       banner(instance.banner());
/* 2569 */       systemChannelId(instance.systemChannelId());
/* 2570 */       systemChannelFlags(instance.systemChannelFlags());
/* 2571 */       rulesChannelId(instance.rulesChannelId());
/* 2572 */       publicUpdatesChannelId(instance.publicUpdatesChannelId());
/* 2573 */       preferredLocale(instance.preferredLocale());
/* 2574 */       features(instance.features());
/* 2575 */       description(instance.description());
/* 2576 */       safetyAlertsChannelId(instance.safetyAlertsChannelId());
/* 2577 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("name")
/*      */     public Builder name(Possible<String> value) {
/* 2582 */       this.name_possible = value;
/* 2583 */       return this;
/*      */     }
/*      */     
/*      */     public Builder name(String value) {
/* 2587 */       this.name_possible = Possible.of(value);
/* 2588 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("region")
/*      */     public Builder region(Possible<Optional<String>> value) {
/* 2593 */       this.region_possible = value;
/* 2594 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder region(@Nullable String value) {
/* 2599 */       this.region_possible = Possible.of(Optional.ofNullable(value));
/* 2600 */       return this;
/*      */     }
/*      */     
/*      */     public Builder regionOrNull(@Nullable String value) {
/* 2604 */       this.region_possible = Possible.of(Optional.ofNullable(value));
/* 2605 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("verification_level")
/*      */     public Builder verificationLevel(Possible<Optional<Integer>> value) {
/* 2610 */       this.verificationLevel_possible = value;
/* 2611 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder verificationLevel(@Nullable Integer value) {
/* 2616 */       this.verificationLevel_possible = Possible.of(Optional.ofNullable(value));
/* 2617 */       return this;
/*      */     }
/*      */     
/*      */     public Builder verificationLevelOrNull(@Nullable Integer value) {
/* 2621 */       this.verificationLevel_possible = Possible.of(Optional.ofNullable(value));
/* 2622 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("default_message_notifications")
/*      */     public Builder defaultMessageNotifications(Possible<Optional<Integer>> value) {
/* 2627 */       this.defaultMessageNotifications_possible = value;
/* 2628 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder defaultMessageNotifications(@Nullable Integer value) {
/* 2633 */       this.defaultMessageNotifications_possible = Possible.of(Optional.ofNullable(value));
/* 2634 */       return this;
/*      */     }
/*      */     
/*      */     public Builder defaultMessageNotificationsOrNull(@Nullable Integer value) {
/* 2638 */       this.defaultMessageNotifications_possible = Possible.of(Optional.ofNullable(value));
/* 2639 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("explicit_content_filter")
/*      */     public Builder explicitContentFilter(Possible<Optional<Integer>> value) {
/* 2644 */       this.explicitContentFilter_possible = value;
/* 2645 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder explicitContentFilter(@Nullable Integer value) {
/* 2650 */       this.explicitContentFilter_possible = Possible.of(Optional.ofNullable(value));
/* 2651 */       return this;
/*      */     }
/*      */     
/*      */     public Builder explicitContentFilterOrNull(@Nullable Integer value) {
/* 2655 */       this.explicitContentFilter_possible = Possible.of(Optional.ofNullable(value));
/* 2656 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("afk_channel_id")
/*      */     public Builder afkChannelId(Possible<Optional<String>> value) {
/* 2661 */       this.afkChannelId_possible = value;
/* 2662 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder afkChannelId(@Nullable String value) {
/* 2667 */       this.afkChannelId_possible = Possible.of(Optional.ofNullable(value));
/* 2668 */       return this;
/*      */     }
/*      */     
/*      */     public Builder afkChannelIdOrNull(@Nullable String value) {
/* 2672 */       this.afkChannelId_possible = Possible.of(Optional.ofNullable(value));
/* 2673 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("afk_timeout")
/*      */     public Builder afkTimeout(Possible<Integer> value) {
/* 2678 */       this.afkTimeout_possible = value;
/* 2679 */       return this;
/*      */     }
/*      */     
/*      */     public Builder afkTimeout(Integer value) {
/* 2683 */       this.afkTimeout_possible = Possible.of(value);
/* 2684 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("icon")
/*      */     public Builder icon(Possible<Optional<String>> value) {
/* 2689 */       this.icon_possible = value;
/* 2690 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder icon(@Nullable String value) {
/* 2695 */       this.icon_possible = Possible.of(Optional.ofNullable(value));
/* 2696 */       return this;
/*      */     }
/*      */     
/*      */     public Builder iconOrNull(@Nullable String value) {
/* 2700 */       this.icon_possible = Possible.of(Optional.ofNullable(value));
/* 2701 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("owner_id")
/*      */     public Builder ownerId(Possible<String> value) {
/* 2706 */       this.ownerId_possible = value;
/* 2707 */       return this;
/*      */     }
/*      */     
/*      */     public Builder ownerId(String value) {
/* 2711 */       this.ownerId_possible = Possible.of(value);
/* 2712 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("splash")
/*      */     public Builder splash(Possible<Optional<String>> value) {
/* 2717 */       this.splash_possible = value;
/* 2718 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder splash(@Nullable String value) {
/* 2723 */       this.splash_possible = Possible.of(Optional.ofNullable(value));
/* 2724 */       return this;
/*      */     }
/*      */     
/*      */     public Builder splashOrNull(@Nullable String value) {
/* 2728 */       this.splash_possible = Possible.of(Optional.ofNullable(value));
/* 2729 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("discovery_splash")
/*      */     public Builder discoverySplash(Possible<Optional<String>> value) {
/* 2734 */       this.discoverySplash_possible = value;
/* 2735 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder discoverySplash(@Nullable String value) {
/* 2740 */       this.discoverySplash_possible = Possible.of(Optional.ofNullable(value));
/* 2741 */       return this;
/*      */     }
/*      */     
/*      */     public Builder discoverySplashOrNull(@Nullable String value) {
/* 2745 */       this.discoverySplash_possible = Possible.of(Optional.ofNullable(value));
/* 2746 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("banner")
/*      */     public Builder banner(Possible<Optional<String>> value) {
/* 2751 */       this.banner_possible = value;
/* 2752 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder banner(@Nullable String value) {
/* 2757 */       this.banner_possible = Possible.of(Optional.ofNullable(value));
/* 2758 */       return this;
/*      */     }
/*      */     
/*      */     public Builder bannerOrNull(@Nullable String value) {
/* 2762 */       this.banner_possible = Possible.of(Optional.ofNullable(value));
/* 2763 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("system_channel_id")
/*      */     public Builder systemChannelId(Possible<Optional<String>> value) {
/* 2768 */       this.systemChannelId_possible = value;
/* 2769 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder systemChannelId(@Nullable String value) {
/* 2774 */       this.systemChannelId_possible = Possible.of(Optional.ofNullable(value));
/* 2775 */       return this;
/*      */     }
/*      */     
/*      */     public Builder systemChannelIdOrNull(@Nullable String value) {
/* 2779 */       this.systemChannelId_possible = Possible.of(Optional.ofNullable(value));
/* 2780 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("system_channel_flags")
/*      */     public Builder systemChannelFlags(Possible<Integer> value) {
/* 2785 */       this.systemChannelFlags_possible = value;
/* 2786 */       return this;
/*      */     }
/*      */     
/*      */     public Builder systemChannelFlags(Integer value) {
/* 2790 */       this.systemChannelFlags_possible = Possible.of(value);
/* 2791 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("rules_channel_id")
/*      */     public Builder rulesChannelId(Possible<Optional<String>> value) {
/* 2796 */       this.rulesChannelId_possible = value;
/* 2797 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder rulesChannelId(@Nullable String value) {
/* 2802 */       this.rulesChannelId_possible = Possible.of(Optional.ofNullable(value));
/* 2803 */       return this;
/*      */     }
/*      */     
/*      */     public Builder rulesChannelIdOrNull(@Nullable String value) {
/* 2807 */       this.rulesChannelId_possible = Possible.of(Optional.ofNullable(value));
/* 2808 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("public_updates_channel_id")
/*      */     public Builder publicUpdatesChannelId(Possible<Optional<String>> value) {
/* 2813 */       this.publicUpdatesChannelId_possible = value;
/* 2814 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder publicUpdatesChannelId(@Nullable String value) {
/* 2819 */       this.publicUpdatesChannelId_possible = Possible.of(Optional.ofNullable(value));
/* 2820 */       return this;
/*      */     }
/*      */     
/*      */     public Builder publicUpdatesChannelIdOrNull(@Nullable String value) {
/* 2824 */       this.publicUpdatesChannelId_possible = Possible.of(Optional.ofNullable(value));
/* 2825 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("preferred_locale")
/*      */     public Builder preferredLocale(Possible<Optional<String>> value) {
/* 2830 */       this.preferredLocale_possible = value;
/* 2831 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder preferredLocale(@Nullable String value) {
/* 2836 */       this.preferredLocale_possible = Possible.of(Optional.ofNullable(value));
/* 2837 */       return this;
/*      */     }
/*      */     
/*      */     public Builder preferredLocaleOrNull(@Nullable String value) {
/* 2841 */       this.preferredLocale_possible = Possible.of(Optional.ofNullable(value));
/* 2842 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addFeature(String element) {
/* 2846 */       features_getOrCreate().add(element);
/* 2847 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addAllFeatures(List<String> elements) {
/* 2851 */       features_getOrCreate().addAll(elements);
/* 2852 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("features")
/*      */     public Builder features(Possible<List<String>> elements) {
/* 2857 */       this.features_list = null;
/* 2858 */       elements.toOptional().ifPresent(e -> features_getOrCreate().addAll(e));
/* 2859 */       return this;
/*      */     }
/*      */     
/*      */     public Builder features(List<String> elements) {
/* 2863 */       this.features_list = new ArrayList<>(elements);
/* 2864 */       return this;
/*      */     }
/*      */     
/*      */     public Builder features(Iterable<String> elements) {
/* 2868 */       this.features_list = (List<String>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 2869 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("description")
/*      */     public Builder description(Possible<Optional<String>> value) {
/* 2874 */       this.description_possible = value;
/* 2875 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder description(@Nullable String value) {
/* 2880 */       this.description_possible = Possible.of(Optional.ofNullable(value));
/* 2881 */       return this;
/*      */     }
/*      */     
/*      */     public Builder descriptionOrNull(@Nullable String value) {
/* 2885 */       this.description_possible = Possible.of(Optional.ofNullable(value));
/* 2886 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("safety_alerts_channel_id")
/*      */     public Builder safetyAlertsChannelId(Possible<Optional<String>> value) {
/* 2891 */       this.safetyAlertsChannelId_possible = value;
/* 2892 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder safetyAlertsChannelId(@Nullable String value) {
/* 2897 */       this.safetyAlertsChannelId_possible = Possible.of(Optional.ofNullable(value));
/* 2898 */       return this;
/*      */     }
/*      */     
/*      */     public Builder safetyAlertsChannelIdOrNull(@Nullable String value) {
/* 2902 */       this.safetyAlertsChannelId_possible = Possible.of(Optional.ofNullable(value));
/* 2903 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ImmutableGuildModifyRequest build() {
/* 2912 */       return new ImmutableGuildModifyRequest(null, 
/*      */           
/* 2914 */           name_build(), 
/* 2915 */           region_build(), 
/* 2916 */           verificationLevel_build(), 
/* 2917 */           defaultMessageNotifications_build(), 
/* 2918 */           explicitContentFilter_build(), 
/* 2919 */           afkChannelId_build(), 
/* 2920 */           afkTimeout_build(), 
/* 2921 */           icon_build(), 
/* 2922 */           ownerId_build(), 
/* 2923 */           splash_build(), 
/* 2924 */           discoverySplash_build(), 
/* 2925 */           banner_build(), 
/* 2926 */           systemChannelId_build(), 
/* 2927 */           systemChannelFlags_build(), 
/* 2928 */           rulesChannelId_build(), 
/* 2929 */           publicUpdatesChannelId_build(), 
/* 2930 */           preferredLocale_build(), 
/* 2931 */           features_build(), 
/* 2932 */           description_build(), 
/* 2933 */           safetyAlertsChannelId_build());
/*      */     }
/*      */     
/*      */     private Possible<String> name_build() {
/* 2937 */       return this.name_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<String>> region_build() {
/* 2941 */       return this.region_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<Integer>> verificationLevel_build() {
/* 2945 */       return this.verificationLevel_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<Integer>> defaultMessageNotifications_build() {
/* 2949 */       return this.defaultMessageNotifications_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<Integer>> explicitContentFilter_build() {
/* 2953 */       return this.explicitContentFilter_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<String>> afkChannelId_build() {
/* 2957 */       return this.afkChannelId_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> afkTimeout_build() {
/* 2961 */       return this.afkTimeout_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<String>> icon_build() {
/* 2965 */       return this.icon_possible;
/*      */     }
/*      */     
/*      */     private Possible<String> ownerId_build() {
/* 2969 */       return this.ownerId_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<String>> splash_build() {
/* 2973 */       return this.splash_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<String>> discoverySplash_build() {
/* 2977 */       return this.discoverySplash_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<String>> banner_build() {
/* 2981 */       return this.banner_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<String>> systemChannelId_build() {
/* 2985 */       return this.systemChannelId_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> systemChannelFlags_build() {
/* 2989 */       return this.systemChannelFlags_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<String>> rulesChannelId_build() {
/* 2993 */       return this.rulesChannelId_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<String>> publicUpdatesChannelId_build() {
/* 2997 */       return this.publicUpdatesChannelId_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<String>> preferredLocale_build() {
/* 3001 */       return this.preferredLocale_possible;
/*      */     }
/*      */     
/*      */     private Possible<List<String>> features_build() {
/* 3005 */       return (this.features_list == null) ? Possible.absent() : 
/* 3006 */         Possible.of(this.features_list);
/*      */     }
/*      */     
/*      */     private List<String> features_getOrCreate() {
/* 3010 */       if (this.features_list == null) {
/* 3011 */         this.features_list = new ArrayList<>();
/*      */       }
/* 3013 */       return this.features_list;
/*      */     }
/*      */     
/*      */     private Possible<Optional<String>> description_build() {
/* 3017 */       return this.description_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<String>> safetyAlertsChannelId_build() {
/* 3021 */       return this.safetyAlertsChannelId_possible;
/*      */     }
/*      */     
/*      */     private Builder() {}
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableGuildModifyRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */