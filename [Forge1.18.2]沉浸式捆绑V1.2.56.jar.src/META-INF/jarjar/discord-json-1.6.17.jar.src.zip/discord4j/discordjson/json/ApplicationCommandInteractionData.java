/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import java.util.List;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ @JsonSerialize(as = ImmutableApplicationCommandInteractionData.class)
/*    */ @JsonDeserialize(as = ImmutableApplicationCommandInteractionData.class)
/*    */ @Immutable
/*    */ public interface ApplicationCommandInteractionData
/*    */ {
/*    */   static ImmutableApplicationCommandInteractionData.Builder builder() {
/* 17 */     return ImmutableApplicationCommandInteractionData.builder();
/*    */   }
/*    */   
/*    */   Possible<String> id();
/*    */   
/*    */   Possible<String> name();
/*    */   
/*    */   Possible<Integer> type();
/*    */   
/*    */   Possible<ApplicationCommandInteractionResolvedData> resolved();
/*    */   
/*    */   Possible<List<ApplicationCommandInteractionOptionData>> options();
/*    */   
/*    */   @JsonProperty("custom_id")
/*    */   Possible<String> customId();
/*    */   
/*    */   @JsonProperty("component_type")
/*    */   Possible<Integer> componentType();
/*    */   
/*    */   Possible<List<String>> values();
/*    */   
/*    */   @JsonProperty("target_id")
/*    */   Possible<String> targetId();
/*    */   
/*    */   Possible<List<ComponentData>> components();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ApplicationCommandInteractionData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */