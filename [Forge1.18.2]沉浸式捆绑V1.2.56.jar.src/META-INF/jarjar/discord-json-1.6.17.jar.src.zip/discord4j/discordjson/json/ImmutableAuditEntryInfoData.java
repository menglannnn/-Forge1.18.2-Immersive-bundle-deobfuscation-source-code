/*      */ package discord4j.discordjson.json;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*      */ import com.fasterxml.jackson.annotation.JsonCreator;
/*      */ import com.fasterxml.jackson.annotation.JsonProperty;
/*      */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*      */ import discord4j.discordjson.Id;
/*      */ import discord4j.discordjson.possible.Possible;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import org.immutables.value.Generated;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Generated(from = "AuditEntryInfoData", generator = "Immutables")
/*      */ public final class ImmutableAuditEntryInfoData
/*      */   implements AuditEntryInfoData
/*      */ {
/*      */   private final String deleteMemberDays_value;
/*      */   private final boolean deleteMemberDays_absent;
/*      */   private final String membersRemoved_value;
/*      */   private final boolean membersRemoved_absent;
/*      */   private final long channelId_value;
/*      */   private final boolean channelId_absent;
/*      */   private final long messageId_value;
/*      */   private final boolean messageId_absent;
/*      */   private final long applicationId_value;
/*      */   private final boolean applicationId_absent;
/*      */   private final String count_value;
/*      */   private final boolean count_absent;
/*      */   private final long id_value;
/*      */   private final boolean id_absent;
/*      */   private final String type_value;
/*      */   private final boolean type_absent;
/*      */   private final String roleName_value;
/*      */   private final boolean roleName_absent;
/*      */   private final String autoModerationRuleName_value;
/*      */   private final boolean autoModerationRuleName_absent;
/*      */   private final String autoModerationRuleTriggerType_value;
/*      */   private final boolean autoModerationRuleTriggerType_absent;
/*      */   private static final byte STAGE_INITIALIZING = -1;
/*      */   private static final byte STAGE_UNINITIALIZED = 0;
/*      */   private static final byte STAGE_INITIALIZED = 1;
/*      */   
/*      */   private ImmutableAuditEntryInfoData(Possible<String> deleteMemberDays, Possible<String> membersRemoved, Possible<Id> channelId, Possible<Id> messageId, Possible<Id> applicationId, Possible<String> count, Possible<Id> id, Possible<String> type, Possible<String> roleName, Possible<String> autoModerationRuleName, Possible<String> autoModerationRuleTriggerType) {
/*   61 */     Possible<String> deleteMemberDays$impl = deleteMemberDays;
/*   62 */     Possible<String> membersRemoved$impl = membersRemoved;
/*   63 */     Possible<Id> channelId$impl = channelId;
/*   64 */     Possible<Id> messageId$impl = messageId;
/*   65 */     Possible<Id> applicationId$impl = applicationId;
/*   66 */     Possible<String> count$impl = count;
/*   67 */     Possible<Id> id$impl = id;
/*   68 */     Possible<String> type$impl = type;
/*   69 */     Possible<String> roleName$impl = roleName;
/*   70 */     Possible<String> autoModerationRuleName$impl = autoModerationRuleName;
/*   71 */     Possible<String> autoModerationRuleTriggerType$impl = autoModerationRuleTriggerType;
/*   72 */     this.deleteMemberDays_value = deleteMemberDays$impl.toOptional().orElse(null);
/*   73 */     this.deleteMemberDays_absent = deleteMemberDays$impl.isAbsent();
/*   74 */     this.membersRemoved_value = membersRemoved$impl.toOptional().orElse(null);
/*   75 */     this.membersRemoved_absent = membersRemoved$impl.isAbsent();
/*   76 */     this
/*      */       
/*   78 */       .channelId_value = ((Long)channelId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*   79 */     this.channelId_absent = channelId$impl.isAbsent();
/*   80 */     this
/*      */       
/*   82 */       .messageId_value = ((Long)messageId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*   83 */     this.messageId_absent = messageId$impl.isAbsent();
/*   84 */     this
/*      */       
/*   86 */       .applicationId_value = ((Long)applicationId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*   87 */     this.applicationId_absent = applicationId$impl.isAbsent();
/*   88 */     this.count_value = count$impl.toOptional().orElse(null);
/*   89 */     this.count_absent = count$impl.isAbsent();
/*   90 */     this
/*      */       
/*   92 */       .id_value = ((Long)id$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*   93 */     this.id_absent = id$impl.isAbsent();
/*   94 */     this.type_value = type$impl.toOptional().orElse(null);
/*   95 */     this.type_absent = type$impl.isAbsent();
/*   96 */     this.roleName_value = roleName$impl.toOptional().orElse(null);
/*   97 */     this.roleName_absent = roleName$impl.isAbsent();
/*   98 */     this.autoModerationRuleName_value = autoModerationRuleName$impl.toOptional().orElse(null);
/*   99 */     this.autoModerationRuleName_absent = autoModerationRuleName$impl.isAbsent();
/*  100 */     this.autoModerationRuleTriggerType_value = autoModerationRuleTriggerType$impl.toOptional().orElse(null);
/*  101 */     this.autoModerationRuleTriggerType_absent = autoModerationRuleTriggerType$impl.isAbsent();
/*  102 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ImmutableAuditEntryInfoData(ImmutableAuditEntryInfoData original, Possible<String> deleteMemberDays, Possible<String> membersRemoved, Possible<Id> channelId, Possible<Id> messageId, Possible<Id> applicationId, Possible<String> count, Possible<Id> id, Possible<String> type, Possible<String> roleName, Possible<String> autoModerationRuleName, Possible<String> autoModerationRuleTriggerType) {
/*  118 */     Possible<String> deleteMemberDays$impl = deleteMemberDays;
/*  119 */     Possible<String> membersRemoved$impl = membersRemoved;
/*  120 */     Possible<Id> channelId$impl = channelId;
/*  121 */     Possible<Id> messageId$impl = messageId;
/*  122 */     Possible<Id> applicationId$impl = applicationId;
/*  123 */     Possible<String> count$impl = count;
/*  124 */     Possible<Id> id$impl = id;
/*  125 */     Possible<String> type$impl = type;
/*  126 */     Possible<String> roleName$impl = roleName;
/*  127 */     Possible<String> autoModerationRuleName$impl = autoModerationRuleName;
/*  128 */     Possible<String> autoModerationRuleTriggerType$impl = autoModerationRuleTriggerType;
/*  129 */     this.deleteMemberDays_value = deleteMemberDays$impl.toOptional().orElse(null);
/*  130 */     this.deleteMemberDays_absent = deleteMemberDays$impl.isAbsent();
/*  131 */     this.membersRemoved_value = membersRemoved$impl.toOptional().orElse(null);
/*  132 */     this.membersRemoved_absent = membersRemoved$impl.isAbsent();
/*  133 */     this
/*      */       
/*  135 */       .channelId_value = ((Long)channelId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  136 */     this.channelId_absent = channelId$impl.isAbsent();
/*  137 */     this
/*      */       
/*  139 */       .messageId_value = ((Long)messageId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  140 */     this.messageId_absent = messageId$impl.isAbsent();
/*  141 */     this
/*      */       
/*  143 */       .applicationId_value = ((Long)applicationId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  144 */     this.applicationId_absent = applicationId$impl.isAbsent();
/*  145 */     this.count_value = count$impl.toOptional().orElse(null);
/*  146 */     this.count_absent = count$impl.isAbsent();
/*  147 */     this
/*      */       
/*  149 */       .id_value = ((Long)id$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  150 */     this.id_absent = id$impl.isAbsent();
/*  151 */     this.type_value = type$impl.toOptional().orElse(null);
/*  152 */     this.type_absent = type$impl.isAbsent();
/*  153 */     this.roleName_value = roleName$impl.toOptional().orElse(null);
/*  154 */     this.roleName_absent = roleName$impl.isAbsent();
/*  155 */     this.autoModerationRuleName_value = autoModerationRuleName$impl.toOptional().orElse(null);
/*  156 */     this.autoModerationRuleName_absent = autoModerationRuleName$impl.isAbsent();
/*  157 */     this.autoModerationRuleTriggerType_value = autoModerationRuleTriggerType$impl.toOptional().orElse(null);
/*  158 */     this.autoModerationRuleTriggerType_absent = autoModerationRuleTriggerType$impl.isAbsent();
/*  159 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  165 */   private volatile transient InitShim initShim = new InitShim();
/*      */   
/*      */   @Generated(from = "AuditEntryInfoData", generator = "Immutables")
/*      */   private final class InitShim {
/*      */     private String formatInitCycleMessage() {
/*  170 */       List<String> attributes = new ArrayList<>();
/*  171 */       return "Cannot build AuditEntryInfoData, attribute initializers form cycle " + attributes;
/*      */     }
/*      */ 
/*      */     
/*      */     private InitShim() {}
/*      */   }
/*      */ 
/*      */   
/*      */   @JsonProperty("delete_member_days")
/*      */   public Possible<String> deleteMemberDays() {
/*  181 */     return this.deleteMemberDays_absent ? Possible.absent() : Possible.of(this.deleteMemberDays_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("members_removed")
/*      */   public Possible<String> membersRemoved() {
/*  190 */     return this.membersRemoved_absent ? Possible.absent() : Possible.of(this.membersRemoved_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("channel_id")
/*      */   public Possible<Id> channelId() {
/*  199 */     return this.channelId_absent ? Possible.absent() : 
/*  200 */       Possible.of(Id.of(this.channelId_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("message_id")
/*      */   public Possible<Id> messageId() {
/*  209 */     return this.messageId_absent ? Possible.absent() : 
/*  210 */       Possible.of(Id.of(this.messageId_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("application_id")
/*      */   public Possible<Id> applicationId() {
/*  219 */     return this.applicationId_absent ? Possible.absent() : 
/*  220 */       Possible.of(Id.of(this.applicationId_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("count")
/*      */   public Possible<String> count() {
/*  229 */     return this.count_absent ? Possible.absent() : Possible.of(this.count_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("id")
/*      */   public Possible<Id> id() {
/*  238 */     return this.id_absent ? Possible.absent() : 
/*  239 */       Possible.of(Id.of(this.id_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("type")
/*      */   public Possible<String> type() {
/*  248 */     return this.type_absent ? Possible.absent() : Possible.of(this.type_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("role_name")
/*      */   public Possible<String> roleName() {
/*  257 */     return this.roleName_absent ? Possible.absent() : Possible.of(this.roleName_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("auto_moderation_rule_name")
/*      */   public Possible<String> autoModerationRuleName() {
/*  266 */     return this.autoModerationRuleName_absent ? Possible.absent() : Possible.of(this.autoModerationRuleName_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("auto_moderation_rule_trigger_type")
/*      */   public Possible<String> autoModerationRuleTriggerType() {
/*  275 */     return this.autoModerationRuleTriggerType_absent ? Possible.absent() : Possible.of(this.autoModerationRuleTriggerType_value);
/*      */   }
/*      */   
/*      */   public ImmutableAuditEntryInfoData withDeleteMemberDays(Possible<String> value) {
/*  279 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  280 */     return new ImmutableAuditEntryInfoData(this, newValue, 
/*      */ 
/*      */         
/*  283 */         membersRemoved(), 
/*  284 */         channelId(), 
/*  285 */         messageId(), 
/*  286 */         applicationId(), 
/*  287 */         count(), 
/*  288 */         id(), 
/*  289 */         type(), 
/*  290 */         roleName(), 
/*  291 */         autoModerationRuleName(), 
/*  292 */         autoModerationRuleTriggerType());
/*      */   }
/*      */   
/*      */   public ImmutableAuditEntryInfoData withDeleteMemberDays(String value) {
/*  296 */     Possible<String> newValue = Possible.of(value);
/*  297 */     return new ImmutableAuditEntryInfoData(this, newValue, 
/*      */ 
/*      */         
/*  300 */         membersRemoved(), 
/*  301 */         channelId(), 
/*  302 */         messageId(), 
/*  303 */         applicationId(), 
/*  304 */         count(), 
/*  305 */         id(), 
/*  306 */         type(), 
/*  307 */         roleName(), 
/*  308 */         autoModerationRuleName(), 
/*  309 */         autoModerationRuleTriggerType());
/*      */   }
/*      */   
/*      */   public ImmutableAuditEntryInfoData withMembersRemoved(Possible<String> value) {
/*  313 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  314 */     return new ImmutableAuditEntryInfoData(this, 
/*      */         
/*  316 */         deleteMemberDays(), newValue, 
/*      */         
/*  318 */         channelId(), 
/*  319 */         messageId(), 
/*  320 */         applicationId(), 
/*  321 */         count(), 
/*  322 */         id(), 
/*  323 */         type(), 
/*  324 */         roleName(), 
/*  325 */         autoModerationRuleName(), 
/*  326 */         autoModerationRuleTriggerType());
/*      */   }
/*      */   
/*      */   public ImmutableAuditEntryInfoData withMembersRemoved(String value) {
/*  330 */     Possible<String> newValue = Possible.of(value);
/*  331 */     return new ImmutableAuditEntryInfoData(this, 
/*      */         
/*  333 */         deleteMemberDays(), newValue, 
/*      */         
/*  335 */         channelId(), 
/*  336 */         messageId(), 
/*  337 */         applicationId(), 
/*  338 */         count(), 
/*  339 */         id(), 
/*  340 */         type(), 
/*  341 */         roleName(), 
/*  342 */         autoModerationRuleName(), 
/*  343 */         autoModerationRuleTriggerType());
/*      */   }
/*      */   
/*      */   public ImmutableAuditEntryInfoData withChannelId(Possible<Id> value) {
/*  347 */     Possible<Id> newValue = Objects.<Possible<Id>>requireNonNull(value);
/*  348 */     return new ImmutableAuditEntryInfoData(this, 
/*      */         
/*  350 */         deleteMemberDays(), 
/*  351 */         membersRemoved(), newValue, 
/*      */         
/*  353 */         messageId(), 
/*  354 */         applicationId(), 
/*  355 */         count(), 
/*  356 */         id(), 
/*  357 */         type(), 
/*  358 */         roleName(), 
/*  359 */         autoModerationRuleName(), 
/*  360 */         autoModerationRuleTriggerType());
/*      */   }
/*      */   
/*      */   public ImmutableAuditEntryInfoData withChannelId(long value) {
/*  364 */     Possible<Id> newValue = Possible.of(Id.of(value));
/*  365 */     return new ImmutableAuditEntryInfoData(this, 
/*      */         
/*  367 */         deleteMemberDays(), 
/*  368 */         membersRemoved(), newValue, 
/*      */         
/*  370 */         messageId(), 
/*  371 */         applicationId(), 
/*  372 */         count(), 
/*  373 */         id(), 
/*  374 */         type(), 
/*  375 */         roleName(), 
/*  376 */         autoModerationRuleName(), 
/*  377 */         autoModerationRuleTriggerType());
/*      */   }
/*      */   
/*      */   public ImmutableAuditEntryInfoData withMessageId(Possible<Id> value) {
/*  381 */     Possible<Id> newValue = Objects.<Possible<Id>>requireNonNull(value);
/*  382 */     return new ImmutableAuditEntryInfoData(this, 
/*      */         
/*  384 */         deleteMemberDays(), 
/*  385 */         membersRemoved(), 
/*  386 */         channelId(), newValue, 
/*      */         
/*  388 */         applicationId(), 
/*  389 */         count(), 
/*  390 */         id(), 
/*  391 */         type(), 
/*  392 */         roleName(), 
/*  393 */         autoModerationRuleName(), 
/*  394 */         autoModerationRuleTriggerType());
/*      */   }
/*      */   
/*      */   public ImmutableAuditEntryInfoData withMessageId(long value) {
/*  398 */     Possible<Id> newValue = Possible.of(Id.of(value));
/*  399 */     return new ImmutableAuditEntryInfoData(this, 
/*      */         
/*  401 */         deleteMemberDays(), 
/*  402 */         membersRemoved(), 
/*  403 */         channelId(), newValue, 
/*      */         
/*  405 */         applicationId(), 
/*  406 */         count(), 
/*  407 */         id(), 
/*  408 */         type(), 
/*  409 */         roleName(), 
/*  410 */         autoModerationRuleName(), 
/*  411 */         autoModerationRuleTriggerType());
/*      */   }
/*      */   
/*      */   public ImmutableAuditEntryInfoData withApplicationId(Possible<Id> value) {
/*  415 */     Possible<Id> newValue = Objects.<Possible<Id>>requireNonNull(value);
/*  416 */     return new ImmutableAuditEntryInfoData(this, 
/*      */         
/*  418 */         deleteMemberDays(), 
/*  419 */         membersRemoved(), 
/*  420 */         channelId(), 
/*  421 */         messageId(), newValue, 
/*      */         
/*  423 */         count(), 
/*  424 */         id(), 
/*  425 */         type(), 
/*  426 */         roleName(), 
/*  427 */         autoModerationRuleName(), 
/*  428 */         autoModerationRuleTriggerType());
/*      */   }
/*      */   
/*      */   public ImmutableAuditEntryInfoData withApplicationId(long value) {
/*  432 */     Possible<Id> newValue = Possible.of(Id.of(value));
/*  433 */     return new ImmutableAuditEntryInfoData(this, 
/*      */         
/*  435 */         deleteMemberDays(), 
/*  436 */         membersRemoved(), 
/*  437 */         channelId(), 
/*  438 */         messageId(), newValue, 
/*      */         
/*  440 */         count(), 
/*  441 */         id(), 
/*  442 */         type(), 
/*  443 */         roleName(), 
/*  444 */         autoModerationRuleName(), 
/*  445 */         autoModerationRuleTriggerType());
/*      */   }
/*      */   
/*      */   public ImmutableAuditEntryInfoData withCount(Possible<String> value) {
/*  449 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  450 */     return new ImmutableAuditEntryInfoData(this, 
/*      */         
/*  452 */         deleteMemberDays(), 
/*  453 */         membersRemoved(), 
/*  454 */         channelId(), 
/*  455 */         messageId(), 
/*  456 */         applicationId(), newValue, 
/*      */         
/*  458 */         id(), 
/*  459 */         type(), 
/*  460 */         roleName(), 
/*  461 */         autoModerationRuleName(), 
/*  462 */         autoModerationRuleTriggerType());
/*      */   }
/*      */   
/*      */   public ImmutableAuditEntryInfoData withCount(String value) {
/*  466 */     Possible<String> newValue = Possible.of(value);
/*  467 */     return new ImmutableAuditEntryInfoData(this, 
/*      */         
/*  469 */         deleteMemberDays(), 
/*  470 */         membersRemoved(), 
/*  471 */         channelId(), 
/*  472 */         messageId(), 
/*  473 */         applicationId(), newValue, 
/*      */         
/*  475 */         id(), 
/*  476 */         type(), 
/*  477 */         roleName(), 
/*  478 */         autoModerationRuleName(), 
/*  479 */         autoModerationRuleTriggerType());
/*      */   }
/*      */   
/*      */   public ImmutableAuditEntryInfoData withId(Possible<Id> value) {
/*  483 */     Possible<Id> newValue = Objects.<Possible<Id>>requireNonNull(value);
/*  484 */     return new ImmutableAuditEntryInfoData(this, 
/*      */         
/*  486 */         deleteMemberDays(), 
/*  487 */         membersRemoved(), 
/*  488 */         channelId(), 
/*  489 */         messageId(), 
/*  490 */         applicationId(), 
/*  491 */         count(), newValue, 
/*      */         
/*  493 */         type(), 
/*  494 */         roleName(), 
/*  495 */         autoModerationRuleName(), 
/*  496 */         autoModerationRuleTriggerType());
/*      */   }
/*      */   
/*      */   public ImmutableAuditEntryInfoData withId(long value) {
/*  500 */     Possible<Id> newValue = Possible.of(Id.of(value));
/*  501 */     return new ImmutableAuditEntryInfoData(this, 
/*      */         
/*  503 */         deleteMemberDays(), 
/*  504 */         membersRemoved(), 
/*  505 */         channelId(), 
/*  506 */         messageId(), 
/*  507 */         applicationId(), 
/*  508 */         count(), newValue, 
/*      */         
/*  510 */         type(), 
/*  511 */         roleName(), 
/*  512 */         autoModerationRuleName(), 
/*  513 */         autoModerationRuleTriggerType());
/*      */   }
/*      */   
/*      */   public ImmutableAuditEntryInfoData withType(Possible<String> value) {
/*  517 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  518 */     return new ImmutableAuditEntryInfoData(this, 
/*      */         
/*  520 */         deleteMemberDays(), 
/*  521 */         membersRemoved(), 
/*  522 */         channelId(), 
/*  523 */         messageId(), 
/*  524 */         applicationId(), 
/*  525 */         count(), 
/*  526 */         id(), newValue, 
/*      */         
/*  528 */         roleName(), 
/*  529 */         autoModerationRuleName(), 
/*  530 */         autoModerationRuleTriggerType());
/*      */   }
/*      */   
/*      */   public ImmutableAuditEntryInfoData withType(String value) {
/*  534 */     Possible<String> newValue = Possible.of(value);
/*  535 */     return new ImmutableAuditEntryInfoData(this, 
/*      */         
/*  537 */         deleteMemberDays(), 
/*  538 */         membersRemoved(), 
/*  539 */         channelId(), 
/*  540 */         messageId(), 
/*  541 */         applicationId(), 
/*  542 */         count(), 
/*  543 */         id(), newValue, 
/*      */         
/*  545 */         roleName(), 
/*  546 */         autoModerationRuleName(), 
/*  547 */         autoModerationRuleTriggerType());
/*      */   }
/*      */   
/*      */   public ImmutableAuditEntryInfoData withRoleName(Possible<String> value) {
/*  551 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  552 */     return new ImmutableAuditEntryInfoData(this, 
/*      */         
/*  554 */         deleteMemberDays(), 
/*  555 */         membersRemoved(), 
/*  556 */         channelId(), 
/*  557 */         messageId(), 
/*  558 */         applicationId(), 
/*  559 */         count(), 
/*  560 */         id(), 
/*  561 */         type(), newValue, 
/*      */         
/*  563 */         autoModerationRuleName(), 
/*  564 */         autoModerationRuleTriggerType());
/*      */   }
/*      */   
/*      */   public ImmutableAuditEntryInfoData withRoleName(String value) {
/*  568 */     Possible<String> newValue = Possible.of(value);
/*  569 */     return new ImmutableAuditEntryInfoData(this, 
/*      */         
/*  571 */         deleteMemberDays(), 
/*  572 */         membersRemoved(), 
/*  573 */         channelId(), 
/*  574 */         messageId(), 
/*  575 */         applicationId(), 
/*  576 */         count(), 
/*  577 */         id(), 
/*  578 */         type(), newValue, 
/*      */         
/*  580 */         autoModerationRuleName(), 
/*  581 */         autoModerationRuleTriggerType());
/*      */   }
/*      */   
/*      */   public ImmutableAuditEntryInfoData withAutoModerationRuleName(Possible<String> value) {
/*  585 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  586 */     return new ImmutableAuditEntryInfoData(this, 
/*      */         
/*  588 */         deleteMemberDays(), 
/*  589 */         membersRemoved(), 
/*  590 */         channelId(), 
/*  591 */         messageId(), 
/*  592 */         applicationId(), 
/*  593 */         count(), 
/*  594 */         id(), 
/*  595 */         type(), 
/*  596 */         roleName(), newValue, 
/*      */         
/*  598 */         autoModerationRuleTriggerType());
/*      */   }
/*      */   
/*      */   public ImmutableAuditEntryInfoData withAutoModerationRuleName(String value) {
/*  602 */     Possible<String> newValue = Possible.of(value);
/*  603 */     return new ImmutableAuditEntryInfoData(this, 
/*      */         
/*  605 */         deleteMemberDays(), 
/*  606 */         membersRemoved(), 
/*  607 */         channelId(), 
/*  608 */         messageId(), 
/*  609 */         applicationId(), 
/*  610 */         count(), 
/*  611 */         id(), 
/*  612 */         type(), 
/*  613 */         roleName(), newValue, 
/*      */         
/*  615 */         autoModerationRuleTriggerType());
/*      */   }
/*      */   
/*      */   public ImmutableAuditEntryInfoData withAutoModerationRuleTriggerType(Possible<String> value) {
/*  619 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  620 */     return new ImmutableAuditEntryInfoData(this, 
/*      */         
/*  622 */         deleteMemberDays(), 
/*  623 */         membersRemoved(), 
/*  624 */         channelId(), 
/*  625 */         messageId(), 
/*  626 */         applicationId(), 
/*  627 */         count(), 
/*  628 */         id(), 
/*  629 */         type(), 
/*  630 */         roleName(), 
/*  631 */         autoModerationRuleName(), newValue);
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableAuditEntryInfoData withAutoModerationRuleTriggerType(String value) {
/*  636 */     Possible<String> newValue = Possible.of(value);
/*  637 */     return new ImmutableAuditEntryInfoData(this, 
/*      */         
/*  639 */         deleteMemberDays(), 
/*  640 */         membersRemoved(), 
/*  641 */         channelId(), 
/*  642 */         messageId(), 
/*  643 */         applicationId(), 
/*  644 */         count(), 
/*  645 */         id(), 
/*  646 */         type(), 
/*  647 */         roleName(), 
/*  648 */         autoModerationRuleName(), newValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object another) {
/*  658 */     if (this == another) return true; 
/*  659 */     return (another instanceof ImmutableAuditEntryInfoData && 
/*  660 */       equalTo(0, (ImmutableAuditEntryInfoData)another));
/*      */   }
/*      */   
/*      */   private boolean equalTo(int synthetic, ImmutableAuditEntryInfoData another) {
/*  664 */     return (deleteMemberDays().equals(another.deleteMemberDays()) && 
/*  665 */       membersRemoved().equals(another.membersRemoved()) && 
/*  666 */       channelId().equals(another.channelId()) && 
/*  667 */       messageId().equals(another.messageId()) && 
/*  668 */       applicationId().equals(another.applicationId()) && 
/*  669 */       count().equals(another.count()) && 
/*  670 */       id().equals(another.id()) && 
/*  671 */       type().equals(another.type()) && 
/*  672 */       roleName().equals(another.roleName()) && 
/*  673 */       autoModerationRuleName().equals(another.autoModerationRuleName()) && 
/*  674 */       autoModerationRuleTriggerType().equals(another.autoModerationRuleTriggerType()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/*  683 */     int h = 5381;
/*  684 */     h += (h << 5) + deleteMemberDays().hashCode();
/*  685 */     h += (h << 5) + membersRemoved().hashCode();
/*  686 */     h += (h << 5) + channelId().hashCode();
/*  687 */     h += (h << 5) + messageId().hashCode();
/*  688 */     h += (h << 5) + applicationId().hashCode();
/*  689 */     h += (h << 5) + count().hashCode();
/*  690 */     h += (h << 5) + id().hashCode();
/*  691 */     h += (h << 5) + type().hashCode();
/*  692 */     h += (h << 5) + roleName().hashCode();
/*  693 */     h += (h << 5) + autoModerationRuleName().hashCode();
/*  694 */     h += (h << 5) + autoModerationRuleTriggerType().hashCode();
/*  695 */     return h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*  704 */     return "AuditEntryInfoData{deleteMemberDays=" + 
/*  705 */       deleteMemberDays().toString() + ", membersRemoved=" + 
/*  706 */       membersRemoved().toString() + ", channelId=" + 
/*  707 */       channelId().toString() + ", messageId=" + 
/*  708 */       messageId().toString() + ", applicationId=" + 
/*  709 */       applicationId().toString() + ", count=" + 
/*  710 */       count().toString() + ", id=" + 
/*  711 */       id().toString() + ", type=" + 
/*  712 */       type().toString() + ", roleName=" + 
/*  713 */       roleName().toString() + ", autoModerationRuleName=" + 
/*  714 */       autoModerationRuleName().toString() + ", autoModerationRuleTriggerType=" + 
/*  715 */       autoModerationRuleTriggerType().toString() + "}";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonDeserialize
/*      */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*      */   @Generated(from = "AuditEntryInfoData", generator = "Immutables")
/*      */   static final class Json
/*      */     implements AuditEntryInfoData
/*      */   {
/*  729 */     Possible<String> deleteMemberDays = Possible.absent();
/*      */ 
/*      */     
/*  732 */     Possible<String> membersRemoved = Possible.absent();
/*      */ 
/*      */     
/*  735 */     Possible<Id> channelId = Possible.absent();
/*      */ 
/*      */     
/*  738 */     Possible<Id> messageId = Possible.absent();
/*      */ 
/*      */     
/*  741 */     Possible<Id> applicationId = Possible.absent();
/*      */ 
/*      */     
/*  744 */     Possible<String> count = Possible.absent();
/*      */ 
/*      */     
/*  747 */     Possible<Id> id = Possible.absent();
/*      */ 
/*      */     
/*  750 */     Possible<String> type = Possible.absent();
/*      */ 
/*      */     
/*  753 */     Possible<String> roleName = Possible.absent();
/*      */ 
/*      */     
/*  756 */     Possible<String> autoModerationRuleName = Possible.absent();
/*      */ 
/*      */     
/*  759 */     Possible<String> autoModerationRuleTriggerType = Possible.absent();
/*      */     
/*      */     @JsonProperty("delete_member_days")
/*      */     public void setDeleteMemberDays(Possible<String> deleteMemberDays) {
/*  763 */       this.deleteMemberDays = deleteMemberDays;
/*      */     }
/*      */     @JsonProperty("members_removed")
/*      */     public void setMembersRemoved(Possible<String> membersRemoved) {
/*  767 */       this.membersRemoved = membersRemoved;
/*      */     }
/*      */     @JsonProperty("channel_id")
/*      */     public void setChannelId(Possible<Id> channelId) {
/*  771 */       this.channelId = channelId;
/*      */     }
/*      */     @JsonProperty("message_id")
/*      */     public void setMessageId(Possible<Id> messageId) {
/*  775 */       this.messageId = messageId;
/*      */     }
/*      */     @JsonProperty("application_id")
/*      */     public void setApplicationId(Possible<Id> applicationId) {
/*  779 */       this.applicationId = applicationId;
/*      */     }
/*      */     @JsonProperty("count")
/*      */     public void setCount(Possible<String> count) {
/*  783 */       this.count = count;
/*      */     }
/*      */     @JsonProperty("id")
/*      */     public void setId(Possible<Id> id) {
/*  787 */       this.id = id;
/*      */     }
/*      */     @JsonProperty("type")
/*      */     public void setType(Possible<String> type) {
/*  791 */       this.type = type;
/*      */     }
/*      */     @JsonProperty("role_name")
/*      */     public void setRoleName(Possible<String> roleName) {
/*  795 */       this.roleName = roleName;
/*      */     }
/*      */     @JsonProperty("auto_moderation_rule_name")
/*      */     public void setAutoModerationRuleName(Possible<String> autoModerationRuleName) {
/*  799 */       this.autoModerationRuleName = autoModerationRuleName;
/*      */     }
/*      */     @JsonProperty("auto_moderation_rule_trigger_type")
/*      */     public void setAutoModerationRuleTriggerType(Possible<String> autoModerationRuleTriggerType) {
/*  803 */       this.autoModerationRuleTriggerType = autoModerationRuleTriggerType;
/*      */     }
/*      */     public Possible<String> deleteMemberDays() {
/*  806 */       throw new UnsupportedOperationException();
/*      */     } public Possible<String> membersRemoved() {
/*  808 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Id> channelId() {
/*  810 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Id> messageId() {
/*  812 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Id> applicationId() {
/*  814 */       throw new UnsupportedOperationException();
/*      */     } public Possible<String> count() {
/*  816 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Id> id() {
/*  818 */       throw new UnsupportedOperationException();
/*      */     } public Possible<String> type() {
/*  820 */       throw new UnsupportedOperationException();
/*      */     } public Possible<String> roleName() {
/*  822 */       throw new UnsupportedOperationException();
/*      */     } public Possible<String> autoModerationRuleName() {
/*  824 */       throw new UnsupportedOperationException();
/*      */     } public Possible<String> autoModerationRuleTriggerType() {
/*  826 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*      */   static ImmutableAuditEntryInfoData fromJson(Json json) {
/*  837 */     Builder builder = builder();
/*  838 */     if (json.deleteMemberDays != null) {
/*  839 */       builder.deleteMemberDays(json.deleteMemberDays);
/*      */     }
/*  841 */     if (json.membersRemoved != null) {
/*  842 */       builder.membersRemoved(json.membersRemoved);
/*      */     }
/*  844 */     if (json.channelId != null) {
/*  845 */       builder.channelId(json.channelId);
/*      */     }
/*  847 */     if (json.messageId != null) {
/*  848 */       builder.messageId(json.messageId);
/*      */     }
/*  850 */     if (json.applicationId != null) {
/*  851 */       builder.applicationId(json.applicationId);
/*      */     }
/*  853 */     if (json.count != null) {
/*  854 */       builder.count(json.count);
/*      */     }
/*  856 */     if (json.id != null) {
/*  857 */       builder.id(json.id);
/*      */     }
/*  859 */     if (json.type != null) {
/*  860 */       builder.type(json.type);
/*      */     }
/*  862 */     if (json.roleName != null) {
/*  863 */       builder.roleName(json.roleName);
/*      */     }
/*  865 */     if (json.autoModerationRuleName != null) {
/*  866 */       builder.autoModerationRuleName(json.autoModerationRuleName);
/*      */     }
/*  868 */     if (json.autoModerationRuleTriggerType != null) {
/*  869 */       builder.autoModerationRuleTriggerType(json.autoModerationRuleTriggerType);
/*      */     }
/*  871 */     return builder.build();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableAuditEntryInfoData of(Possible<String> deleteMemberDays, Possible<String> membersRemoved, Possible<Id> channelId, Possible<Id> messageId, Possible<Id> applicationId, Possible<String> count, Possible<Id> id, Possible<String> type, Possible<String> roleName, Possible<String> autoModerationRuleName, Possible<String> autoModerationRuleTriggerType) {
/*  890 */     return new ImmutableAuditEntryInfoData(deleteMemberDays, membersRemoved, channelId, messageId, applicationId, count, id, type, roleName, autoModerationRuleName, autoModerationRuleTriggerType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableAuditEntryInfoData copyOf(AuditEntryInfoData instance) {
/*  901 */     if (instance instanceof ImmutableAuditEntryInfoData) {
/*  902 */       return (ImmutableAuditEntryInfoData)instance;
/*      */     }
/*  904 */     return builder()
/*  905 */       .from(instance)
/*  906 */       .build();
/*      */   }
/*      */   
/*      */   public boolean isDeleteMemberDaysPresent() {
/*  910 */     return !this.deleteMemberDays_absent;
/*      */   }
/*      */   
/*      */   public String deleteMemberDaysOrElse(String defaultValue) {
/*  914 */     return !this.deleteMemberDays_absent ? this.deleteMemberDays_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isMembersRemovedPresent() {
/*  918 */     return !this.membersRemoved_absent;
/*      */   }
/*      */   
/*      */   public String membersRemovedOrElse(String defaultValue) {
/*  922 */     return !this.membersRemoved_absent ? this.membersRemoved_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isChannelIdPresent() {
/*  926 */     return !this.channelId_absent;
/*      */   }
/*      */   
/*      */   public long channelIdOrElse(long defaultValue) {
/*  930 */     return !this.channelId_absent ? this.channelId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isMessageIdPresent() {
/*  934 */     return !this.messageId_absent;
/*      */   }
/*      */   
/*      */   public long messageIdOrElse(long defaultValue) {
/*  938 */     return !this.messageId_absent ? this.messageId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isApplicationIdPresent() {
/*  942 */     return !this.applicationId_absent;
/*      */   }
/*      */   
/*      */   public long applicationIdOrElse(long defaultValue) {
/*  946 */     return !this.applicationId_absent ? this.applicationId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isCountPresent() {
/*  950 */     return !this.count_absent;
/*      */   }
/*      */   
/*      */   public String countOrElse(String defaultValue) {
/*  954 */     return !this.count_absent ? this.count_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isIdPresent() {
/*  958 */     return !this.id_absent;
/*      */   }
/*      */   
/*      */   public long idOrElse(long defaultValue) {
/*  962 */     return !this.id_absent ? this.id_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isTypePresent() {
/*  966 */     return !this.type_absent;
/*      */   }
/*      */   
/*      */   public String typeOrElse(String defaultValue) {
/*  970 */     return !this.type_absent ? this.type_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isRoleNamePresent() {
/*  974 */     return !this.roleName_absent;
/*      */   }
/*      */   
/*      */   public String roleNameOrElse(String defaultValue) {
/*  978 */     return !this.roleName_absent ? this.roleName_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isAutoModerationRuleNamePresent() {
/*  982 */     return !this.autoModerationRuleName_absent;
/*      */   }
/*      */   
/*      */   public String autoModerationRuleNameOrElse(String defaultValue) {
/*  986 */     return !this.autoModerationRuleName_absent ? this.autoModerationRuleName_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isAutoModerationRuleTriggerTypePresent() {
/*  990 */     return !this.autoModerationRuleTriggerType_absent;
/*      */   }
/*      */   
/*      */   public String autoModerationRuleTriggerTypeOrElse(String defaultValue) {
/*  994 */     return !this.autoModerationRuleTriggerType_absent ? this.autoModerationRuleTriggerType_value : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Builder builder() {
/* 1017 */     return new Builder();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Generated(from = "AuditEntryInfoData", generator = "Immutables")
/*      */   public static final class Builder
/*      */   {
/* 1029 */     private Possible<String> deleteMemberDays_possible = Possible.absent();
/* 1030 */     private Possible<String> membersRemoved_possible = Possible.absent();
/* 1031 */     private Possible<Id> channelId_possible = Possible.absent();
/* 1032 */     private Possible<Id> messageId_possible = Possible.absent();
/* 1033 */     private Possible<Id> applicationId_possible = Possible.absent();
/* 1034 */     private Possible<String> count_possible = Possible.absent();
/* 1035 */     private Possible<Id> id_possible = Possible.absent();
/* 1036 */     private Possible<String> type_possible = Possible.absent();
/* 1037 */     private Possible<String> roleName_possible = Possible.absent();
/* 1038 */     private Possible<String> autoModerationRuleName_possible = Possible.absent();
/* 1039 */     private Possible<String> autoModerationRuleTriggerType_possible = Possible.absent();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(AuditEntryInfoData instance) {
/* 1052 */       Objects.requireNonNull(instance, "instance");
/* 1053 */       deleteMemberDays(instance.deleteMemberDays());
/* 1054 */       membersRemoved(instance.membersRemoved());
/* 1055 */       channelId(instance.channelId());
/* 1056 */       messageId(instance.messageId());
/* 1057 */       applicationId(instance.applicationId());
/* 1058 */       count(instance.count());
/* 1059 */       id(instance.id());
/* 1060 */       type(instance.type());
/* 1061 */       roleName(instance.roleName());
/* 1062 */       autoModerationRuleName(instance.autoModerationRuleName());
/* 1063 */       autoModerationRuleTriggerType(instance.autoModerationRuleTriggerType());
/* 1064 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("delete_member_days")
/*      */     public Builder deleteMemberDays(Possible<String> value) {
/* 1069 */       this.deleteMemberDays_possible = value;
/* 1070 */       return this;
/*      */     }
/*      */     
/*      */     public Builder deleteMemberDays(String value) {
/* 1074 */       this.deleteMemberDays_possible = Possible.of(value);
/* 1075 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("members_removed")
/*      */     public Builder membersRemoved(Possible<String> value) {
/* 1080 */       this.membersRemoved_possible = value;
/* 1081 */       return this;
/*      */     }
/*      */     
/*      */     public Builder membersRemoved(String value) {
/* 1085 */       this.membersRemoved_possible = Possible.of(value);
/* 1086 */       return this;
/*      */     }
/*      */     
/*      */     public Builder channelId(String value) {
/* 1090 */       this.channelId_possible = Possible.of(Id.of(value));
/* 1091 */       return this;
/*      */     }
/*      */     
/*      */     public Builder channelId(long value) {
/* 1095 */       this.channelId_possible = Possible.of(Id.of(value));
/* 1096 */       return this;
/*      */     }
/*      */     
/*      */     public Builder channelId(Id value) {
/* 1100 */       this.channelId_possible = Possible.of(value);
/* 1101 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("channel_id")
/*      */     public Builder channelId(Possible<Id> value) {
/* 1106 */       this.channelId_possible = value;
/* 1107 */       return this;
/*      */     }
/*      */     
/*      */     public Builder messageId(String value) {
/* 1111 */       this.messageId_possible = Possible.of(Id.of(value));
/* 1112 */       return this;
/*      */     }
/*      */     
/*      */     public Builder messageId(long value) {
/* 1116 */       this.messageId_possible = Possible.of(Id.of(value));
/* 1117 */       return this;
/*      */     }
/*      */     
/*      */     public Builder messageId(Id value) {
/* 1121 */       this.messageId_possible = Possible.of(value);
/* 1122 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("message_id")
/*      */     public Builder messageId(Possible<Id> value) {
/* 1127 */       this.messageId_possible = value;
/* 1128 */       return this;
/*      */     }
/*      */     
/*      */     public Builder applicationId(String value) {
/* 1132 */       this.applicationId_possible = Possible.of(Id.of(value));
/* 1133 */       return this;
/*      */     }
/*      */     
/*      */     public Builder applicationId(long value) {
/* 1137 */       this.applicationId_possible = Possible.of(Id.of(value));
/* 1138 */       return this;
/*      */     }
/*      */     
/*      */     public Builder applicationId(Id value) {
/* 1142 */       this.applicationId_possible = Possible.of(value);
/* 1143 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("application_id")
/*      */     public Builder applicationId(Possible<Id> value) {
/* 1148 */       this.applicationId_possible = value;
/* 1149 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("count")
/*      */     public Builder count(Possible<String> value) {
/* 1154 */       this.count_possible = value;
/* 1155 */       return this;
/*      */     }
/*      */     
/*      */     public Builder count(String value) {
/* 1159 */       this.count_possible = Possible.of(value);
/* 1160 */       return this;
/*      */     }
/*      */     
/*      */     public Builder id(String value) {
/* 1164 */       this.id_possible = Possible.of(Id.of(value));
/* 1165 */       return this;
/*      */     }
/*      */     
/*      */     public Builder id(long value) {
/* 1169 */       this.id_possible = Possible.of(Id.of(value));
/* 1170 */       return this;
/*      */     }
/*      */     
/*      */     public Builder id(Id value) {
/* 1174 */       this.id_possible = Possible.of(value);
/* 1175 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("id")
/*      */     public Builder id(Possible<Id> value) {
/* 1180 */       this.id_possible = value;
/* 1181 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("type")
/*      */     public Builder type(Possible<String> value) {
/* 1186 */       this.type_possible = value;
/* 1187 */       return this;
/*      */     }
/*      */     
/*      */     public Builder type(String value) {
/* 1191 */       this.type_possible = Possible.of(value);
/* 1192 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("role_name")
/*      */     public Builder roleName(Possible<String> value) {
/* 1197 */       this.roleName_possible = value;
/* 1198 */       return this;
/*      */     }
/*      */     
/*      */     public Builder roleName(String value) {
/* 1202 */       this.roleName_possible = Possible.of(value);
/* 1203 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("auto_moderation_rule_name")
/*      */     public Builder autoModerationRuleName(Possible<String> value) {
/* 1208 */       this.autoModerationRuleName_possible = value;
/* 1209 */       return this;
/*      */     }
/*      */     
/*      */     public Builder autoModerationRuleName(String value) {
/* 1213 */       this.autoModerationRuleName_possible = Possible.of(value);
/* 1214 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("auto_moderation_rule_trigger_type")
/*      */     public Builder autoModerationRuleTriggerType(Possible<String> value) {
/* 1219 */       this.autoModerationRuleTriggerType_possible = value;
/* 1220 */       return this;
/*      */     }
/*      */     
/*      */     public Builder autoModerationRuleTriggerType(String value) {
/* 1224 */       this.autoModerationRuleTriggerType_possible = Possible.of(value);
/* 1225 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ImmutableAuditEntryInfoData build() {
/* 1234 */       return new ImmutableAuditEntryInfoData(null, 
/*      */           
/* 1236 */           deleteMemberDays_build(), 
/* 1237 */           membersRemoved_build(), 
/* 1238 */           channelId_build(), 
/* 1239 */           messageId_build(), 
/* 1240 */           applicationId_build(), 
/* 1241 */           count_build(), 
/* 1242 */           id_build(), 
/* 1243 */           type_build(), 
/* 1244 */           roleName_build(), 
/* 1245 */           autoModerationRuleName_build(), 
/* 1246 */           autoModerationRuleTriggerType_build());
/*      */     }
/*      */     
/*      */     private Possible<String> deleteMemberDays_build() {
/* 1250 */       return this.deleteMemberDays_possible;
/*      */     }
/*      */     
/*      */     private Possible<String> membersRemoved_build() {
/* 1254 */       return this.membersRemoved_possible;
/*      */     }
/*      */     
/*      */     private Possible<Id> channelId_build() {
/* 1258 */       return this.channelId_possible;
/*      */     }
/*      */     
/*      */     private Possible<Id> messageId_build() {
/* 1262 */       return this.messageId_possible;
/*      */     }
/*      */     
/*      */     private Possible<Id> applicationId_build() {
/* 1266 */       return this.applicationId_possible;
/*      */     }
/*      */     
/*      */     private Possible<String> count_build() {
/* 1270 */       return this.count_possible;
/*      */     }
/*      */     
/*      */     private Possible<Id> id_build() {
/* 1274 */       return this.id_possible;
/*      */     }
/*      */     
/*      */     private Possible<String> type_build() {
/* 1278 */       return this.type_possible;
/*      */     }
/*      */     
/*      */     private Possible<String> roleName_build() {
/* 1282 */       return this.roleName_possible;
/*      */     }
/*      */     
/*      */     private Possible<String> autoModerationRuleName_build() {
/* 1286 */       return this.autoModerationRuleName_possible;
/*      */     }
/*      */     
/*      */     private Possible<String> autoModerationRuleTriggerType_build() {
/* 1290 */       return this.autoModerationRuleTriggerType_possible;
/*      */     }
/*      */     
/*      */     private Builder() {}
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableAuditEntryInfoData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */