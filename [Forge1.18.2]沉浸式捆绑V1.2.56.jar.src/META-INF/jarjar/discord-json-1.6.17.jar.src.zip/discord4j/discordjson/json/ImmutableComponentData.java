/*      */ package discord4j.discordjson.json;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*      */ import com.fasterxml.jackson.annotation.JsonCreator;
/*      */ import com.fasterxml.jackson.annotation.JsonProperty;
/*      */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*      */ import discord4j.discordjson.possible.Possible;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import java.util.stream.Collectors;
/*      */ import java.util.stream.StreamSupport;
/*      */ import org.immutables.value.Generated;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Generated(from = "ComponentData", generator = "Immutables")
/*      */ public final class ImmutableComponentData
/*      */   implements ComponentData
/*      */ {
/*      */   private final int type;
/*      */   private final List<ComponentData> components_value;
/*      */   private final boolean components_absent;
/*      */   private final Integer style_value;
/*      */   private final boolean style_absent;
/*      */   private final String label_value;
/*      */   private final boolean label_absent;
/*      */   private final EmojiData emoji_value;
/*      */   private final boolean emoji_absent;
/*      */   private final String customId_value;
/*      */   private final boolean customId_absent;
/*      */   private final String url_value;
/*      */   private final boolean url_absent;
/*      */   private final Boolean disabled_value;
/*      */   private final boolean disabled_absent;
/*      */   private final String placeholder_value;
/*      */   private final boolean placeholder_absent;
/*      */   private final Integer minValues_value;
/*      */   private final boolean minValues_absent;
/*      */   private final Integer maxValues_value;
/*      */   private final boolean maxValues_absent;
/*      */   private final Integer minLength_value;
/*      */   private final boolean minLength_absent;
/*      */   private final Integer maxLength_value;
/*      */   private final boolean maxLength_absent;
/*      */   private final Boolean required_value;
/*      */   private final boolean required_absent;
/*      */   private final String value_value;
/*      */   private final boolean value_absent;
/*      */   private final List<String> values_value;
/*      */   private final boolean values_absent;
/*      */   private final List<SelectOptionData> options_value;
/*      */   private final boolean options_absent;
/*      */   private final List<Integer> channelTypes_value;
/*      */   private final boolean channelTypes_absent;
/*      */   private static final byte STAGE_INITIALIZING = -1;
/*      */   private static final byte STAGE_UNINITIALIZED = 0;
/*      */   private static final byte STAGE_INITIALIZED = 1;
/*      */   private volatile transient InitShim initShim;
/*      */   
/*      */   private ImmutableComponentData(int type, Possible<List<ComponentData>> components, Possible<Integer> style, Possible<String> label, Possible<EmojiData> emoji, Possible<String> customId, Possible<String> url, Possible<Boolean> disabled, Possible<String> placeholder, Possible<Integer> minValues, Possible<Integer> maxValues, Possible<Integer> minLength, Possible<Integer> maxLength, Possible<Boolean> required, Possible<String> value, Possible<List<String>> values, Possible<List<SelectOptionData>> options, Possible<List<Integer>> channelTypes) {
/*  216 */     this.initShim = new InitShim(); this.type = type; Possible<List<ComponentData>> components$impl = components; Possible<Integer> style$impl = style; Possible<String> label$impl = label; Possible<EmojiData> emoji$impl = emoji; Possible<String> customId$impl = customId; Possible<String> url$impl = url; Possible<Boolean> disabled$impl = disabled; Possible<String> placeholder$impl = placeholder; Possible<Integer> minValues$impl = minValues; Possible<Integer> maxValues$impl = maxValues; Possible<Integer> minLength$impl = minLength; Possible<Integer> maxLength$impl = maxLength; Possible<Boolean> required$impl = required; Possible<String> value$impl = value; Possible<List<String>> values$impl = values; Possible<List<SelectOptionData>> options$impl = options; Possible<List<Integer>> channelTypes$impl = channelTypes; this.components_value = components$impl.toOptional().orElse(null); this.components_absent = components$impl.isAbsent(); this.style_value = style$impl.toOptional().orElse(null); this.style_absent = style$impl.isAbsent(); this.label_value = label$impl.toOptional().orElse(null); this.label_absent = label$impl.isAbsent(); this.emoji_value = emoji$impl.toOptional().orElse(null); this.emoji_absent = emoji$impl.isAbsent(); this.customId_value = customId$impl.toOptional().orElse(null); this.customId_absent = customId$impl.isAbsent(); this.url_value = url$impl.toOptional().orElse(null); this.url_absent = url$impl.isAbsent(); this.disabled_value = disabled$impl.toOptional().orElse(null); this.disabled_absent = disabled$impl.isAbsent(); this.placeholder_value = placeholder$impl.toOptional().orElse(null); this.placeholder_absent = placeholder$impl.isAbsent(); this.minValues_value = minValues$impl.toOptional().orElse(null); this.minValues_absent = minValues$impl.isAbsent(); this.maxValues_value = maxValues$impl.toOptional().orElse(null); this.maxValues_absent = maxValues$impl.isAbsent(); this.minLength_value = minLength$impl.toOptional().orElse(null); this.minLength_absent = minLength$impl.isAbsent(); this.maxLength_value = maxLength$impl.toOptional().orElse(null); this.maxLength_absent = maxLength$impl.isAbsent(); this.required_value = required$impl.toOptional().orElse(null); this.required_absent = required$impl.isAbsent(); this.value_value = value$impl.toOptional().orElse(null); this.value_absent = value$impl.isAbsent(); this.values_value = values$impl.toOptional().orElse(null); this.values_absent = values$impl.isAbsent(); this.options_value = options$impl.toOptional().orElse(null); this.options_absent = options$impl.isAbsent(); this.channelTypes_value = channelTypes$impl.toOptional().orElse(null); this.channelTypes_absent = channelTypes$impl.isAbsent(); this.initShim = null; } private ImmutableComponentData(ImmutableComponentData original, int type, Possible<List<ComponentData>> components, Possible<Integer> style, Possible<String> label, Possible<EmojiData> emoji, Possible<String> customId, Possible<String> url, Possible<Boolean> disabled, Possible<String> placeholder, Possible<Integer> minValues, Possible<Integer> maxValues, Possible<Integer> minLength, Possible<Integer> maxLength, Possible<Boolean> required, Possible<String> value, Possible<List<String>> values, Possible<List<SelectOptionData>> options, Possible<List<Integer>> channelTypes) { this.initShim = new InitShim(); this.type = type; Possible<List<ComponentData>> components$impl = components; Possible<Integer> style$impl = style; Possible<String> label$impl = label; Possible<EmojiData> emoji$impl = emoji; Possible<String> customId$impl = customId; Possible<String> url$impl = url; Possible<Boolean> disabled$impl = disabled; Possible<String> placeholder$impl = placeholder; Possible<Integer> minValues$impl = minValues; Possible<Integer> maxValues$impl = maxValues; Possible<Integer> minLength$impl = minLength; Possible<Integer> maxLength$impl = maxLength; Possible<Boolean> required$impl = required; Possible<String> value$impl = value; Possible<List<String>> values$impl = values; Possible<List<SelectOptionData>> options$impl = options; Possible<List<Integer>> channelTypes$impl = channelTypes; this.components_value = components$impl.toOptional().orElse(null); this.components_absent = components$impl.isAbsent(); this.style_value = style$impl.toOptional().orElse(null); this.style_absent = style$impl.isAbsent(); this.label_value = label$impl.toOptional().orElse(null); this.label_absent = label$impl.isAbsent(); this.emoji_value = emoji$impl.toOptional().orElse(null); this.emoji_absent = emoji$impl.isAbsent(); this.customId_value = customId$impl.toOptional().orElse(null); this.customId_absent = customId$impl.isAbsent(); this.url_value = url$impl.toOptional().orElse(null); this.url_absent = url$impl.isAbsent(); this.disabled_value = disabled$impl.toOptional().orElse(null); this.disabled_absent = disabled$impl.isAbsent(); this.placeholder_value = placeholder$impl.toOptional().orElse(null); this.placeholder_absent = placeholder$impl.isAbsent(); this.minValues_value = minValues$impl.toOptional().orElse(null); this.minValues_absent = minValues$impl.isAbsent(); this.maxValues_value = maxValues$impl.toOptional().orElse(null); this.maxValues_absent = maxValues$impl.isAbsent(); this.minLength_value = minLength$impl.toOptional().orElse(null); this.minLength_absent = minLength$impl.isAbsent(); this.maxLength_value = maxLength$impl.toOptional().orElse(null); this.maxLength_absent = maxLength$impl.isAbsent(); this.required_value = required$impl.toOptional().orElse(null); this.required_absent = required$impl.isAbsent(); this.value_value = value$impl.toOptional().orElse(null); this.value_absent = value$impl.isAbsent(); this.values_value = values$impl.toOptional().orElse(null); this.values_absent = values$impl.isAbsent();
/*      */     this.options_value = options$impl.toOptional().orElse(null);
/*      */     this.options_absent = options$impl.isAbsent();
/*      */     this.channelTypes_value = channelTypes$impl.toOptional().orElse(null);
/*      */     this.channelTypes_absent = channelTypes$impl.isAbsent();
/*  221 */     this.initShim = null; } @Generated(from = "ComponentData", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/*  222 */       return "Cannot build ComponentData, attribute initializers form cycle " + attributes; }
/*      */      }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("type")
/*      */   public int type() {
/*  232 */     return this.type;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("components")
/*      */   public Possible<List<ComponentData>> components() {
/*  241 */     return this.components_absent ? Possible.absent() : 
/*  242 */       Possible.of(this.components_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("style")
/*      */   public Possible<Integer> style() {
/*  251 */     return this.style_absent ? Possible.absent() : Possible.of(this.style_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("label")
/*      */   public Possible<String> label() {
/*  260 */     return this.label_absent ? Possible.absent() : Possible.of(this.label_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("emoji")
/*      */   public Possible<EmojiData> emoji() {
/*  269 */     return this.emoji_absent ? Possible.absent() : Possible.of(this.emoji_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("custom_id")
/*      */   public Possible<String> customId() {
/*  278 */     return this.customId_absent ? Possible.absent() : Possible.of(this.customId_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("url")
/*      */   public Possible<String> url() {
/*  287 */     return this.url_absent ? Possible.absent() : Possible.of(this.url_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("disabled")
/*      */   public Possible<Boolean> disabled() {
/*  296 */     return this.disabled_absent ? Possible.absent() : Possible.of(this.disabled_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("placeholder")
/*      */   public Possible<String> placeholder() {
/*  305 */     return this.placeholder_absent ? Possible.absent() : Possible.of(this.placeholder_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("min_values")
/*      */   public Possible<Integer> minValues() {
/*  314 */     return this.minValues_absent ? Possible.absent() : Possible.of(this.minValues_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("max_values")
/*      */   public Possible<Integer> maxValues() {
/*  323 */     return this.maxValues_absent ? Possible.absent() : Possible.of(this.maxValues_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("min_length")
/*      */   public Possible<Integer> minLength() {
/*  332 */     return this.minLength_absent ? Possible.absent() : Possible.of(this.minLength_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("max_length")
/*      */   public Possible<Integer> maxLength() {
/*  341 */     return this.maxLength_absent ? Possible.absent() : Possible.of(this.maxLength_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("required")
/*      */   public Possible<Boolean> required() {
/*  350 */     return this.required_absent ? Possible.absent() : Possible.of(this.required_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("value")
/*      */   public Possible<String> value() {
/*  359 */     return this.value_absent ? Possible.absent() : Possible.of(this.value_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("values")
/*      */   public Possible<List<String>> values() {
/*  368 */     return this.values_absent ? Possible.absent() : 
/*  369 */       Possible.of(this.values_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("options")
/*      */   public Possible<List<SelectOptionData>> options() {
/*  378 */     return this.options_absent ? Possible.absent() : 
/*  379 */       Possible.of(this.options_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("channel_types")
/*      */   public Possible<List<Integer>> channelTypes() {
/*  388 */     return this.channelTypes_absent ? Possible.absent() : 
/*  389 */       Possible.of(this.channelTypes_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableComponentData withType(int value) {
/*  399 */     if (this.type == value) return this; 
/*  400 */     return new ImmutableComponentData(this, value, 
/*      */ 
/*      */         
/*  403 */         components(), 
/*  404 */         style(), 
/*  405 */         label(), 
/*  406 */         emoji(), 
/*  407 */         customId(), 
/*  408 */         url(), 
/*  409 */         disabled(), 
/*  410 */         placeholder(), 
/*  411 */         minValues(), 
/*  412 */         maxValues(), 
/*  413 */         minLength(), 
/*  414 */         maxLength(), 
/*  415 */         required(), 
/*  416 */         value(), 
/*  417 */         values(), 
/*  418 */         options(), 
/*  419 */         channelTypes());
/*      */   }
/*      */   
/*      */   public ImmutableComponentData withComponents(Possible<List<ComponentData>> possible) {
/*  423 */     Possible<List<ComponentData>> newValue = Objects.<Possible<List<ComponentData>>>requireNonNull(possible);
/*  424 */     return new ImmutableComponentData(this, this.type, newValue, 
/*      */ 
/*      */ 
/*      */         
/*  428 */         style(), 
/*  429 */         label(), 
/*  430 */         emoji(), 
/*  431 */         customId(), 
/*  432 */         url(), 
/*  433 */         disabled(), 
/*  434 */         placeholder(), 
/*  435 */         minValues(), 
/*  436 */         maxValues(), 
/*  437 */         minLength(), 
/*  438 */         maxLength(), 
/*  439 */         required(), 
/*  440 */         value(), 
/*  441 */         values(), 
/*  442 */         options(), 
/*  443 */         channelTypes());
/*      */   }
/*      */   
/*      */   public ImmutableComponentData withComponents(Iterable<ComponentData> elements) {
/*  447 */     Possible<List<ComponentData>> newValue = Possible.of(
/*  448 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/*  449 */     return new ImmutableComponentData(this, this.type, newValue, 
/*      */ 
/*      */ 
/*      */         
/*  453 */         style(), 
/*  454 */         label(), 
/*  455 */         emoji(), 
/*  456 */         customId(), 
/*  457 */         url(), 
/*  458 */         disabled(), 
/*  459 */         placeholder(), 
/*  460 */         minValues(), 
/*  461 */         maxValues(), 
/*  462 */         minLength(), 
/*  463 */         maxLength(), 
/*  464 */         required(), 
/*  465 */         value(), 
/*  466 */         values(), 
/*  467 */         options(), 
/*  468 */         channelTypes());
/*      */   }
/*      */   
/*      */   @SafeVarargs
/*      */   public final ImmutableComponentData withComponents(ComponentData... elements) {
/*  473 */     Possible<List<ComponentData>> newValue = Possible.of(Arrays.asList(elements));
/*  474 */     return new ImmutableComponentData(this, this.type, newValue, 
/*      */ 
/*      */ 
/*      */         
/*  478 */         style(), 
/*  479 */         label(), 
/*  480 */         emoji(), 
/*  481 */         customId(), 
/*  482 */         url(), 
/*  483 */         disabled(), 
/*  484 */         placeholder(), 
/*  485 */         minValues(), 
/*  486 */         maxValues(), 
/*  487 */         minLength(), 
/*  488 */         maxLength(), 
/*  489 */         required(), 
/*  490 */         value(), 
/*  491 */         values(), 
/*  492 */         options(), 
/*  493 */         channelTypes());
/*      */   }
/*      */   
/*      */   public ImmutableComponentData withStyle(Possible<Integer> value) {
/*  497 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/*  498 */     return new ImmutableComponentData(this, this.type, 
/*      */ 
/*      */         
/*  501 */         components(), newValue, 
/*      */         
/*  503 */         label(), 
/*  504 */         emoji(), 
/*  505 */         customId(), 
/*  506 */         url(), 
/*  507 */         disabled(), 
/*  508 */         placeholder(), 
/*  509 */         minValues(), 
/*  510 */         maxValues(), 
/*  511 */         minLength(), 
/*  512 */         maxLength(), 
/*  513 */         required(), 
/*  514 */         value(), 
/*  515 */         values(), 
/*  516 */         options(), 
/*  517 */         channelTypes());
/*      */   }
/*      */   
/*      */   public ImmutableComponentData withStyle(Integer value) {
/*  521 */     Possible<Integer> newValue = Possible.of(value);
/*  522 */     return new ImmutableComponentData(this, this.type, 
/*      */ 
/*      */         
/*  525 */         components(), newValue, 
/*      */         
/*  527 */         label(), 
/*  528 */         emoji(), 
/*  529 */         customId(), 
/*  530 */         url(), 
/*  531 */         disabled(), 
/*  532 */         placeholder(), 
/*  533 */         minValues(), 
/*  534 */         maxValues(), 
/*  535 */         minLength(), 
/*  536 */         maxLength(), 
/*  537 */         required(), 
/*  538 */         value(), 
/*  539 */         values(), 
/*  540 */         options(), 
/*  541 */         channelTypes());
/*      */   }
/*      */   
/*      */   public ImmutableComponentData withLabel(Possible<String> value) {
/*  545 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  546 */     return new ImmutableComponentData(this, this.type, 
/*      */ 
/*      */         
/*  549 */         components(), 
/*  550 */         style(), newValue, 
/*      */         
/*  552 */         emoji(), 
/*  553 */         customId(), 
/*  554 */         url(), 
/*  555 */         disabled(), 
/*  556 */         placeholder(), 
/*  557 */         minValues(), 
/*  558 */         maxValues(), 
/*  559 */         minLength(), 
/*  560 */         maxLength(), 
/*  561 */         required(), 
/*  562 */         value(), 
/*  563 */         values(), 
/*  564 */         options(), 
/*  565 */         channelTypes());
/*      */   }
/*      */   
/*      */   public ImmutableComponentData withLabel(String value) {
/*  569 */     Possible<String> newValue = Possible.of(value);
/*  570 */     return new ImmutableComponentData(this, this.type, 
/*      */ 
/*      */         
/*  573 */         components(), 
/*  574 */         style(), newValue, 
/*      */         
/*  576 */         emoji(), 
/*  577 */         customId(), 
/*  578 */         url(), 
/*  579 */         disabled(), 
/*  580 */         placeholder(), 
/*  581 */         minValues(), 
/*  582 */         maxValues(), 
/*  583 */         minLength(), 
/*  584 */         maxLength(), 
/*  585 */         required(), 
/*  586 */         value(), 
/*  587 */         values(), 
/*  588 */         options(), 
/*  589 */         channelTypes());
/*      */   }
/*      */   
/*      */   public ImmutableComponentData withEmoji(Possible<EmojiData> value) {
/*  593 */     Possible<EmojiData> newValue = Objects.<Possible<EmojiData>>requireNonNull(value);
/*  594 */     return new ImmutableComponentData(this, this.type, 
/*      */ 
/*      */         
/*  597 */         components(), 
/*  598 */         style(), 
/*  599 */         label(), newValue, 
/*      */         
/*  601 */         customId(), 
/*  602 */         url(), 
/*  603 */         disabled(), 
/*  604 */         placeholder(), 
/*  605 */         minValues(), 
/*  606 */         maxValues(), 
/*  607 */         minLength(), 
/*  608 */         maxLength(), 
/*  609 */         required(), 
/*  610 */         value(), 
/*  611 */         values(), 
/*  612 */         options(), 
/*  613 */         channelTypes());
/*      */   }
/*      */   
/*      */   public ImmutableComponentData withEmoji(EmojiData value) {
/*  617 */     Possible<EmojiData> newValue = Possible.of(value);
/*  618 */     return new ImmutableComponentData(this, this.type, 
/*      */ 
/*      */         
/*  621 */         components(), 
/*  622 */         style(), 
/*  623 */         label(), newValue, 
/*      */         
/*  625 */         customId(), 
/*  626 */         url(), 
/*  627 */         disabled(), 
/*  628 */         placeholder(), 
/*  629 */         minValues(), 
/*  630 */         maxValues(), 
/*  631 */         minLength(), 
/*  632 */         maxLength(), 
/*  633 */         required(), 
/*  634 */         value(), 
/*  635 */         values(), 
/*  636 */         options(), 
/*  637 */         channelTypes());
/*      */   }
/*      */   
/*      */   public ImmutableComponentData withCustomId(Possible<String> value) {
/*  641 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  642 */     return new ImmutableComponentData(this, this.type, 
/*      */ 
/*      */         
/*  645 */         components(), 
/*  646 */         style(), 
/*  647 */         label(), 
/*  648 */         emoji(), newValue, 
/*      */         
/*  650 */         url(), 
/*  651 */         disabled(), 
/*  652 */         placeholder(), 
/*  653 */         minValues(), 
/*  654 */         maxValues(), 
/*  655 */         minLength(), 
/*  656 */         maxLength(), 
/*  657 */         required(), 
/*  658 */         value(), 
/*  659 */         values(), 
/*  660 */         options(), 
/*  661 */         channelTypes());
/*      */   }
/*      */   
/*      */   public ImmutableComponentData withCustomId(String value) {
/*  665 */     Possible<String> newValue = Possible.of(value);
/*  666 */     return new ImmutableComponentData(this, this.type, 
/*      */ 
/*      */         
/*  669 */         components(), 
/*  670 */         style(), 
/*  671 */         label(), 
/*  672 */         emoji(), newValue, 
/*      */         
/*  674 */         url(), 
/*  675 */         disabled(), 
/*  676 */         placeholder(), 
/*  677 */         minValues(), 
/*  678 */         maxValues(), 
/*  679 */         minLength(), 
/*  680 */         maxLength(), 
/*  681 */         required(), 
/*  682 */         value(), 
/*  683 */         values(), 
/*  684 */         options(), 
/*  685 */         channelTypes());
/*      */   }
/*      */   
/*      */   public ImmutableComponentData withUrl(Possible<String> value) {
/*  689 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  690 */     return new ImmutableComponentData(this, this.type, 
/*      */ 
/*      */         
/*  693 */         components(), 
/*  694 */         style(), 
/*  695 */         label(), 
/*  696 */         emoji(), 
/*  697 */         customId(), newValue, 
/*      */         
/*  699 */         disabled(), 
/*  700 */         placeholder(), 
/*  701 */         minValues(), 
/*  702 */         maxValues(), 
/*  703 */         minLength(), 
/*  704 */         maxLength(), 
/*  705 */         required(), 
/*  706 */         value(), 
/*  707 */         values(), 
/*  708 */         options(), 
/*  709 */         channelTypes());
/*      */   }
/*      */   
/*      */   public ImmutableComponentData withUrl(String value) {
/*  713 */     Possible<String> newValue = Possible.of(value);
/*  714 */     return new ImmutableComponentData(this, this.type, 
/*      */ 
/*      */         
/*  717 */         components(), 
/*  718 */         style(), 
/*  719 */         label(), 
/*  720 */         emoji(), 
/*  721 */         customId(), newValue, 
/*      */         
/*  723 */         disabled(), 
/*  724 */         placeholder(), 
/*  725 */         minValues(), 
/*  726 */         maxValues(), 
/*  727 */         minLength(), 
/*  728 */         maxLength(), 
/*  729 */         required(), 
/*  730 */         value(), 
/*  731 */         values(), 
/*  732 */         options(), 
/*  733 */         channelTypes());
/*      */   }
/*      */   
/*      */   public ImmutableComponentData withDisabled(Possible<Boolean> value) {
/*  737 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/*  738 */     return new ImmutableComponentData(this, this.type, 
/*      */ 
/*      */         
/*  741 */         components(), 
/*  742 */         style(), 
/*  743 */         label(), 
/*  744 */         emoji(), 
/*  745 */         customId(), 
/*  746 */         url(), newValue, 
/*      */         
/*  748 */         placeholder(), 
/*  749 */         minValues(), 
/*  750 */         maxValues(), 
/*  751 */         minLength(), 
/*  752 */         maxLength(), 
/*  753 */         required(), 
/*  754 */         value(), 
/*  755 */         values(), 
/*  756 */         options(), 
/*  757 */         channelTypes());
/*      */   }
/*      */   
/*      */   public ImmutableComponentData withDisabled(Boolean value) {
/*  761 */     Possible<Boolean> newValue = Possible.of(value);
/*  762 */     return new ImmutableComponentData(this, this.type, 
/*      */ 
/*      */         
/*  765 */         components(), 
/*  766 */         style(), 
/*  767 */         label(), 
/*  768 */         emoji(), 
/*  769 */         customId(), 
/*  770 */         url(), newValue, 
/*      */         
/*  772 */         placeholder(), 
/*  773 */         minValues(), 
/*  774 */         maxValues(), 
/*  775 */         minLength(), 
/*  776 */         maxLength(), 
/*  777 */         required(), 
/*  778 */         value(), 
/*  779 */         values(), 
/*  780 */         options(), 
/*  781 */         channelTypes());
/*      */   }
/*      */   
/*      */   public ImmutableComponentData withPlaceholder(Possible<String> value) {
/*  785 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  786 */     return new ImmutableComponentData(this, this.type, 
/*      */ 
/*      */         
/*  789 */         components(), 
/*  790 */         style(), 
/*  791 */         label(), 
/*  792 */         emoji(), 
/*  793 */         customId(), 
/*  794 */         url(), 
/*  795 */         disabled(), newValue, 
/*      */         
/*  797 */         minValues(), 
/*  798 */         maxValues(), 
/*  799 */         minLength(), 
/*  800 */         maxLength(), 
/*  801 */         required(), 
/*  802 */         value(), 
/*  803 */         values(), 
/*  804 */         options(), 
/*  805 */         channelTypes());
/*      */   }
/*      */   
/*      */   public ImmutableComponentData withPlaceholder(String value) {
/*  809 */     Possible<String> newValue = Possible.of(value);
/*  810 */     return new ImmutableComponentData(this, this.type, 
/*      */ 
/*      */         
/*  813 */         components(), 
/*  814 */         style(), 
/*  815 */         label(), 
/*  816 */         emoji(), 
/*  817 */         customId(), 
/*  818 */         url(), 
/*  819 */         disabled(), newValue, 
/*      */         
/*  821 */         minValues(), 
/*  822 */         maxValues(), 
/*  823 */         minLength(), 
/*  824 */         maxLength(), 
/*  825 */         required(), 
/*  826 */         value(), 
/*  827 */         values(), 
/*  828 */         options(), 
/*  829 */         channelTypes());
/*      */   }
/*      */   
/*      */   public ImmutableComponentData withMinValues(Possible<Integer> value) {
/*  833 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/*  834 */     return new ImmutableComponentData(this, this.type, 
/*      */ 
/*      */         
/*  837 */         components(), 
/*  838 */         style(), 
/*  839 */         label(), 
/*  840 */         emoji(), 
/*  841 */         customId(), 
/*  842 */         url(), 
/*  843 */         disabled(), 
/*  844 */         placeholder(), newValue, 
/*      */         
/*  846 */         maxValues(), 
/*  847 */         minLength(), 
/*  848 */         maxLength(), 
/*  849 */         required(), 
/*  850 */         value(), 
/*  851 */         values(), 
/*  852 */         options(), 
/*  853 */         channelTypes());
/*      */   }
/*      */   
/*      */   public ImmutableComponentData withMinValues(Integer value) {
/*  857 */     Possible<Integer> newValue = Possible.of(value);
/*  858 */     return new ImmutableComponentData(this, this.type, 
/*      */ 
/*      */         
/*  861 */         components(), 
/*  862 */         style(), 
/*  863 */         label(), 
/*  864 */         emoji(), 
/*  865 */         customId(), 
/*  866 */         url(), 
/*  867 */         disabled(), 
/*  868 */         placeholder(), newValue, 
/*      */         
/*  870 */         maxValues(), 
/*  871 */         minLength(), 
/*  872 */         maxLength(), 
/*  873 */         required(), 
/*  874 */         value(), 
/*  875 */         values(), 
/*  876 */         options(), 
/*  877 */         channelTypes());
/*      */   }
/*      */   
/*      */   public ImmutableComponentData withMaxValues(Possible<Integer> value) {
/*  881 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/*  882 */     return new ImmutableComponentData(this, this.type, 
/*      */ 
/*      */         
/*  885 */         components(), 
/*  886 */         style(), 
/*  887 */         label(), 
/*  888 */         emoji(), 
/*  889 */         customId(), 
/*  890 */         url(), 
/*  891 */         disabled(), 
/*  892 */         placeholder(), 
/*  893 */         minValues(), newValue, 
/*      */         
/*  895 */         minLength(), 
/*  896 */         maxLength(), 
/*  897 */         required(), 
/*  898 */         value(), 
/*  899 */         values(), 
/*  900 */         options(), 
/*  901 */         channelTypes());
/*      */   }
/*      */   
/*      */   public ImmutableComponentData withMaxValues(Integer value) {
/*  905 */     Possible<Integer> newValue = Possible.of(value);
/*  906 */     return new ImmutableComponentData(this, this.type, 
/*      */ 
/*      */         
/*  909 */         components(), 
/*  910 */         style(), 
/*  911 */         label(), 
/*  912 */         emoji(), 
/*  913 */         customId(), 
/*  914 */         url(), 
/*  915 */         disabled(), 
/*  916 */         placeholder(), 
/*  917 */         minValues(), newValue, 
/*      */         
/*  919 */         minLength(), 
/*  920 */         maxLength(), 
/*  921 */         required(), 
/*  922 */         value(), 
/*  923 */         values(), 
/*  924 */         options(), 
/*  925 */         channelTypes());
/*      */   }
/*      */   
/*      */   public ImmutableComponentData withMinLength(Possible<Integer> value) {
/*  929 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/*  930 */     return new ImmutableComponentData(this, this.type, 
/*      */ 
/*      */         
/*  933 */         components(), 
/*  934 */         style(), 
/*  935 */         label(), 
/*  936 */         emoji(), 
/*  937 */         customId(), 
/*  938 */         url(), 
/*  939 */         disabled(), 
/*  940 */         placeholder(), 
/*  941 */         minValues(), 
/*  942 */         maxValues(), newValue, 
/*      */         
/*  944 */         maxLength(), 
/*  945 */         required(), 
/*  946 */         value(), 
/*  947 */         values(), 
/*  948 */         options(), 
/*  949 */         channelTypes());
/*      */   }
/*      */   
/*      */   public ImmutableComponentData withMinLength(Integer value) {
/*  953 */     Possible<Integer> newValue = Possible.of(value);
/*  954 */     return new ImmutableComponentData(this, this.type, 
/*      */ 
/*      */         
/*  957 */         components(), 
/*  958 */         style(), 
/*  959 */         label(), 
/*  960 */         emoji(), 
/*  961 */         customId(), 
/*  962 */         url(), 
/*  963 */         disabled(), 
/*  964 */         placeholder(), 
/*  965 */         minValues(), 
/*  966 */         maxValues(), newValue, 
/*      */         
/*  968 */         maxLength(), 
/*  969 */         required(), 
/*  970 */         value(), 
/*  971 */         values(), 
/*  972 */         options(), 
/*  973 */         channelTypes());
/*      */   }
/*      */   
/*      */   public ImmutableComponentData withMaxLength(Possible<Integer> value) {
/*  977 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/*  978 */     return new ImmutableComponentData(this, this.type, 
/*      */ 
/*      */         
/*  981 */         components(), 
/*  982 */         style(), 
/*  983 */         label(), 
/*  984 */         emoji(), 
/*  985 */         customId(), 
/*  986 */         url(), 
/*  987 */         disabled(), 
/*  988 */         placeholder(), 
/*  989 */         minValues(), 
/*  990 */         maxValues(), 
/*  991 */         minLength(), newValue, 
/*      */         
/*  993 */         required(), 
/*  994 */         value(), 
/*  995 */         values(), 
/*  996 */         options(), 
/*  997 */         channelTypes());
/*      */   }
/*      */   
/*      */   public ImmutableComponentData withMaxLength(Integer value) {
/* 1001 */     Possible<Integer> newValue = Possible.of(value);
/* 1002 */     return new ImmutableComponentData(this, this.type, 
/*      */ 
/*      */         
/* 1005 */         components(), 
/* 1006 */         style(), 
/* 1007 */         label(), 
/* 1008 */         emoji(), 
/* 1009 */         customId(), 
/* 1010 */         url(), 
/* 1011 */         disabled(), 
/* 1012 */         placeholder(), 
/* 1013 */         minValues(), 
/* 1014 */         maxValues(), 
/* 1015 */         minLength(), newValue, 
/*      */         
/* 1017 */         required(), 
/* 1018 */         value(), 
/* 1019 */         values(), 
/* 1020 */         options(), 
/* 1021 */         channelTypes());
/*      */   }
/*      */   
/*      */   public ImmutableComponentData withRequired(Possible<Boolean> value) {
/* 1025 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 1026 */     return new ImmutableComponentData(this, this.type, 
/*      */ 
/*      */         
/* 1029 */         components(), 
/* 1030 */         style(), 
/* 1031 */         label(), 
/* 1032 */         emoji(), 
/* 1033 */         customId(), 
/* 1034 */         url(), 
/* 1035 */         disabled(), 
/* 1036 */         placeholder(), 
/* 1037 */         minValues(), 
/* 1038 */         maxValues(), 
/* 1039 */         minLength(), 
/* 1040 */         maxLength(), newValue, 
/*      */         
/* 1042 */         value(), 
/* 1043 */         values(), 
/* 1044 */         options(), 
/* 1045 */         channelTypes());
/*      */   }
/*      */   
/*      */   public ImmutableComponentData withRequired(Boolean value) {
/* 1049 */     Possible<Boolean> newValue = Possible.of(value);
/* 1050 */     return new ImmutableComponentData(this, this.type, 
/*      */ 
/*      */         
/* 1053 */         components(), 
/* 1054 */         style(), 
/* 1055 */         label(), 
/* 1056 */         emoji(), 
/* 1057 */         customId(), 
/* 1058 */         url(), 
/* 1059 */         disabled(), 
/* 1060 */         placeholder(), 
/* 1061 */         minValues(), 
/* 1062 */         maxValues(), 
/* 1063 */         minLength(), 
/* 1064 */         maxLength(), newValue, 
/*      */         
/* 1066 */         value(), 
/* 1067 */         values(), 
/* 1068 */         options(), 
/* 1069 */         channelTypes());
/*      */   }
/*      */   
/*      */   public ImmutableComponentData withValue(Possible<String> value) {
/* 1073 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 1074 */     return new ImmutableComponentData(this, this.type, 
/*      */ 
/*      */         
/* 1077 */         components(), 
/* 1078 */         style(), 
/* 1079 */         label(), 
/* 1080 */         emoji(), 
/* 1081 */         customId(), 
/* 1082 */         url(), 
/* 1083 */         disabled(), 
/* 1084 */         placeholder(), 
/* 1085 */         minValues(), 
/* 1086 */         maxValues(), 
/* 1087 */         minLength(), 
/* 1088 */         maxLength(), 
/* 1089 */         required(), newValue, 
/*      */         
/* 1091 */         values(), 
/* 1092 */         options(), 
/* 1093 */         channelTypes());
/*      */   }
/*      */   
/*      */   public ImmutableComponentData withValue(String value) {
/* 1097 */     Possible<String> newValue = Possible.of(value);
/* 1098 */     return new ImmutableComponentData(this, this.type, 
/*      */ 
/*      */         
/* 1101 */         components(), 
/* 1102 */         style(), 
/* 1103 */         label(), 
/* 1104 */         emoji(), 
/* 1105 */         customId(), 
/* 1106 */         url(), 
/* 1107 */         disabled(), 
/* 1108 */         placeholder(), 
/* 1109 */         minValues(), 
/* 1110 */         maxValues(), 
/* 1111 */         minLength(), 
/* 1112 */         maxLength(), 
/* 1113 */         required(), newValue, 
/*      */         
/* 1115 */         values(), 
/* 1116 */         options(), 
/* 1117 */         channelTypes());
/*      */   }
/*      */   
/*      */   public ImmutableComponentData withValues(Possible<List<String>> possible) {
/* 1121 */     Possible<List<String>> newValue = Objects.<Possible<List<String>>>requireNonNull(possible);
/* 1122 */     return new ImmutableComponentData(this, this.type, 
/*      */ 
/*      */         
/* 1125 */         components(), 
/* 1126 */         style(), 
/* 1127 */         label(), 
/* 1128 */         emoji(), 
/* 1129 */         customId(), 
/* 1130 */         url(), 
/* 1131 */         disabled(), 
/* 1132 */         placeholder(), 
/* 1133 */         minValues(), 
/* 1134 */         maxValues(), 
/* 1135 */         minLength(), 
/* 1136 */         maxLength(), 
/* 1137 */         required(), 
/* 1138 */         value(), newValue, 
/*      */         
/* 1140 */         options(), 
/* 1141 */         channelTypes());
/*      */   }
/*      */   
/*      */   public ImmutableComponentData withValues(Iterable<String> elements) {
/* 1145 */     Possible<List<String>> newValue = Possible.of(
/* 1146 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/* 1147 */     return new ImmutableComponentData(this, this.type, 
/*      */ 
/*      */         
/* 1150 */         components(), 
/* 1151 */         style(), 
/* 1152 */         label(), 
/* 1153 */         emoji(), 
/* 1154 */         customId(), 
/* 1155 */         url(), 
/* 1156 */         disabled(), 
/* 1157 */         placeholder(), 
/* 1158 */         minValues(), 
/* 1159 */         maxValues(), 
/* 1160 */         minLength(), 
/* 1161 */         maxLength(), 
/* 1162 */         required(), 
/* 1163 */         value(), newValue, 
/*      */         
/* 1165 */         options(), 
/* 1166 */         channelTypes());
/*      */   }
/*      */   
/*      */   @SafeVarargs
/*      */   public final ImmutableComponentData withValues(String... elements) {
/* 1171 */     Possible<List<String>> newValue = Possible.of(Arrays.asList(elements));
/* 1172 */     return new ImmutableComponentData(this, this.type, 
/*      */ 
/*      */         
/* 1175 */         components(), 
/* 1176 */         style(), 
/* 1177 */         label(), 
/* 1178 */         emoji(), 
/* 1179 */         customId(), 
/* 1180 */         url(), 
/* 1181 */         disabled(), 
/* 1182 */         placeholder(), 
/* 1183 */         minValues(), 
/* 1184 */         maxValues(), 
/* 1185 */         minLength(), 
/* 1186 */         maxLength(), 
/* 1187 */         required(), 
/* 1188 */         value(), newValue, 
/*      */         
/* 1190 */         options(), 
/* 1191 */         channelTypes());
/*      */   }
/*      */   
/*      */   public ImmutableComponentData withOptions(Possible<List<SelectOptionData>> possible) {
/* 1195 */     Possible<List<SelectOptionData>> newValue = Objects.<Possible<List<SelectOptionData>>>requireNonNull(possible);
/* 1196 */     return new ImmutableComponentData(this, this.type, 
/*      */ 
/*      */         
/* 1199 */         components(), 
/* 1200 */         style(), 
/* 1201 */         label(), 
/* 1202 */         emoji(), 
/* 1203 */         customId(), 
/* 1204 */         url(), 
/* 1205 */         disabled(), 
/* 1206 */         placeholder(), 
/* 1207 */         minValues(), 
/* 1208 */         maxValues(), 
/* 1209 */         minLength(), 
/* 1210 */         maxLength(), 
/* 1211 */         required(), 
/* 1212 */         value(), 
/* 1213 */         values(), newValue, 
/*      */         
/* 1215 */         channelTypes());
/*      */   }
/*      */   
/*      */   public ImmutableComponentData withOptions(Iterable<SelectOptionData> elements) {
/* 1219 */     Possible<List<SelectOptionData>> newValue = Possible.of(
/* 1220 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/* 1221 */     return new ImmutableComponentData(this, this.type, 
/*      */ 
/*      */         
/* 1224 */         components(), 
/* 1225 */         style(), 
/* 1226 */         label(), 
/* 1227 */         emoji(), 
/* 1228 */         customId(), 
/* 1229 */         url(), 
/* 1230 */         disabled(), 
/* 1231 */         placeholder(), 
/* 1232 */         minValues(), 
/* 1233 */         maxValues(), 
/* 1234 */         minLength(), 
/* 1235 */         maxLength(), 
/* 1236 */         required(), 
/* 1237 */         value(), 
/* 1238 */         values(), newValue, 
/*      */         
/* 1240 */         channelTypes());
/*      */   }
/*      */   
/*      */   @SafeVarargs
/*      */   public final ImmutableComponentData withOptions(SelectOptionData... elements) {
/* 1245 */     Possible<List<SelectOptionData>> newValue = Possible.of(Arrays.asList(elements));
/* 1246 */     return new ImmutableComponentData(this, this.type, 
/*      */ 
/*      */         
/* 1249 */         components(), 
/* 1250 */         style(), 
/* 1251 */         label(), 
/* 1252 */         emoji(), 
/* 1253 */         customId(), 
/* 1254 */         url(), 
/* 1255 */         disabled(), 
/* 1256 */         placeholder(), 
/* 1257 */         minValues(), 
/* 1258 */         maxValues(), 
/* 1259 */         minLength(), 
/* 1260 */         maxLength(), 
/* 1261 */         required(), 
/* 1262 */         value(), 
/* 1263 */         values(), newValue, 
/*      */         
/* 1265 */         channelTypes());
/*      */   }
/*      */   
/*      */   public ImmutableComponentData withChannelTypes(Possible<List<Integer>> possible) {
/* 1269 */     Possible<List<Integer>> newValue = Objects.<Possible<List<Integer>>>requireNonNull(possible);
/* 1270 */     return new ImmutableComponentData(this, this.type, 
/*      */ 
/*      */         
/* 1273 */         components(), 
/* 1274 */         style(), 
/* 1275 */         label(), 
/* 1276 */         emoji(), 
/* 1277 */         customId(), 
/* 1278 */         url(), 
/* 1279 */         disabled(), 
/* 1280 */         placeholder(), 
/* 1281 */         minValues(), 
/* 1282 */         maxValues(), 
/* 1283 */         minLength(), 
/* 1284 */         maxLength(), 
/* 1285 */         required(), 
/* 1286 */         value(), 
/* 1287 */         values(), 
/* 1288 */         options(), newValue);
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableComponentData withChannelTypes(Iterable<Integer> elements) {
/* 1293 */     Possible<List<Integer>> newValue = Possible.of(
/* 1294 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/* 1295 */     return new ImmutableComponentData(this, this.type, 
/*      */ 
/*      */         
/* 1298 */         components(), 
/* 1299 */         style(), 
/* 1300 */         label(), 
/* 1301 */         emoji(), 
/* 1302 */         customId(), 
/* 1303 */         url(), 
/* 1304 */         disabled(), 
/* 1305 */         placeholder(), 
/* 1306 */         minValues(), 
/* 1307 */         maxValues(), 
/* 1308 */         minLength(), 
/* 1309 */         maxLength(), 
/* 1310 */         required(), 
/* 1311 */         value(), 
/* 1312 */         values(), 
/* 1313 */         options(), newValue);
/*      */   }
/*      */ 
/*      */   
/*      */   @SafeVarargs
/*      */   public final ImmutableComponentData withChannelTypes(Integer... elements) {
/* 1319 */     Possible<List<Integer>> newValue = Possible.of(Arrays.asList(elements));
/* 1320 */     return new ImmutableComponentData(this, this.type, 
/*      */ 
/*      */         
/* 1323 */         components(), 
/* 1324 */         style(), 
/* 1325 */         label(), 
/* 1326 */         emoji(), 
/* 1327 */         customId(), 
/* 1328 */         url(), 
/* 1329 */         disabled(), 
/* 1330 */         placeholder(), 
/* 1331 */         minValues(), 
/* 1332 */         maxValues(), 
/* 1333 */         minLength(), 
/* 1334 */         maxLength(), 
/* 1335 */         required(), 
/* 1336 */         value(), 
/* 1337 */         values(), 
/* 1338 */         options(), newValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object another) {
/* 1348 */     if (this == another) return true; 
/* 1349 */     return (another instanceof ImmutableComponentData && 
/* 1350 */       equalTo(0, (ImmutableComponentData)another));
/*      */   }
/*      */   
/*      */   private boolean equalTo(int synthetic, ImmutableComponentData another) {
/* 1354 */     return (this.type == another.type && 
/* 1355 */       Objects.equals(this.components_value, another.components_value) && 
/* 1356 */       style().equals(another.style()) && 
/* 1357 */       label().equals(another.label()) && 
/* 1358 */       emoji().equals(another.emoji()) && 
/* 1359 */       customId().equals(another.customId()) && 
/* 1360 */       url().equals(another.url()) && 
/* 1361 */       disabled().equals(another.disabled()) && 
/* 1362 */       placeholder().equals(another.placeholder()) && 
/* 1363 */       minValues().equals(another.minValues()) && 
/* 1364 */       maxValues().equals(another.maxValues()) && 
/* 1365 */       minLength().equals(another.minLength()) && 
/* 1366 */       maxLength().equals(another.maxLength()) && 
/* 1367 */       required().equals(another.required()) && 
/* 1368 */       value().equals(another.value()) && 
/* 1369 */       Objects.equals(this.values_value, another.values_value) && 
/* 1370 */       Objects.equals(this.options_value, another.options_value) && 
/* 1371 */       Objects.equals(this.channelTypes_value, another.channelTypes_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/* 1380 */     int h = 5381;
/* 1381 */     h += (h << 5) + this.type;
/* 1382 */     h += (h << 5) + Objects.hashCode(this.components_value);
/* 1383 */     h += (h << 5) + style().hashCode();
/* 1384 */     h += (h << 5) + label().hashCode();
/* 1385 */     h += (h << 5) + emoji().hashCode();
/* 1386 */     h += (h << 5) + customId().hashCode();
/* 1387 */     h += (h << 5) + url().hashCode();
/* 1388 */     h += (h << 5) + disabled().hashCode();
/* 1389 */     h += (h << 5) + placeholder().hashCode();
/* 1390 */     h += (h << 5) + minValues().hashCode();
/* 1391 */     h += (h << 5) + maxValues().hashCode();
/* 1392 */     h += (h << 5) + minLength().hashCode();
/* 1393 */     h += (h << 5) + maxLength().hashCode();
/* 1394 */     h += (h << 5) + required().hashCode();
/* 1395 */     h += (h << 5) + value().hashCode();
/* 1396 */     h += (h << 5) + Objects.hashCode(this.values_value);
/* 1397 */     h += (h << 5) + Objects.hashCode(this.options_value);
/* 1398 */     h += (h << 5) + Objects.hashCode(this.channelTypes_value);
/* 1399 */     return h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1408 */     return "ComponentData{type=" + this.type + ", components=" + 
/*      */       
/* 1410 */       Objects.toString(this.components_value) + ", style=" + 
/* 1411 */       style().toString() + ", label=" + 
/* 1412 */       label().toString() + ", emoji=" + 
/* 1413 */       emoji().toString() + ", customId=" + 
/* 1414 */       customId().toString() + ", url=" + 
/* 1415 */       url().toString() + ", disabled=" + 
/* 1416 */       disabled().toString() + ", placeholder=" + 
/* 1417 */       placeholder().toString() + ", minValues=" + 
/* 1418 */       minValues().toString() + ", maxValues=" + 
/* 1419 */       maxValues().toString() + ", minLength=" + 
/* 1420 */       minLength().toString() + ", maxLength=" + 
/* 1421 */       maxLength().toString() + ", required=" + 
/* 1422 */       required().toString() + ", value=" + 
/* 1423 */       value().toString() + ", values=" + 
/* 1424 */       Objects.toString(this.values_value) + ", options=" + 
/* 1425 */       Objects.toString(this.options_value) + ", channelTypes=" + 
/* 1426 */       Objects.toString(this.channelTypes_value) + "}";
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonDeserialize
/*      */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*      */   @Generated(from = "ComponentData", generator = "Immutables")
/*      */   static final class Json
/*      */     implements ComponentData
/*      */   {
/*      */     int type;
/*      */     
/*      */     boolean typeIsSet;
/*      */     
/* 1442 */     Possible<List<ComponentData>> components = Possible.absent();
/*      */ 
/*      */     
/* 1445 */     Possible<Integer> style = Possible.absent();
/*      */ 
/*      */     
/* 1448 */     Possible<String> label = Possible.absent();
/*      */ 
/*      */     
/* 1451 */     Possible<EmojiData> emoji = Possible.absent();
/*      */ 
/*      */     
/* 1454 */     Possible<String> customId = Possible.absent();
/*      */ 
/*      */     
/* 1457 */     Possible<String> url = Possible.absent();
/*      */ 
/*      */     
/* 1460 */     Possible<Boolean> disabled = Possible.absent();
/*      */ 
/*      */     
/* 1463 */     Possible<String> placeholder = Possible.absent();
/*      */ 
/*      */     
/* 1466 */     Possible<Integer> minValues = Possible.absent();
/*      */ 
/*      */     
/* 1469 */     Possible<Integer> maxValues = Possible.absent();
/*      */ 
/*      */     
/* 1472 */     Possible<Integer> minLength = Possible.absent();
/*      */ 
/*      */     
/* 1475 */     Possible<Integer> maxLength = Possible.absent();
/*      */ 
/*      */     
/* 1478 */     Possible<Boolean> required = Possible.absent();
/*      */ 
/*      */     
/* 1481 */     Possible<String> value = Possible.absent();
/*      */ 
/*      */     
/* 1484 */     Possible<List<String>> values = Possible.absent();
/*      */ 
/*      */     
/* 1487 */     Possible<List<SelectOptionData>> options = Possible.absent();
/*      */ 
/*      */     
/* 1490 */     Possible<List<Integer>> channelTypes = Possible.absent();
/*      */     
/*      */     @JsonProperty("type")
/*      */     public void setType(int type) {
/* 1494 */       this.type = type;
/* 1495 */       this.typeIsSet = true;
/*      */     }
/*      */     @JsonProperty("components")
/*      */     public void setComponents(Possible<List<ComponentData>> components) {
/* 1499 */       this.components = components;
/*      */     }
/*      */     @JsonProperty("style")
/*      */     public void setStyle(Possible<Integer> style) {
/* 1503 */       this.style = style;
/*      */     }
/*      */     @JsonProperty("label")
/*      */     public void setLabel(Possible<String> label) {
/* 1507 */       this.label = label;
/*      */     }
/*      */     @JsonProperty("emoji")
/*      */     public void setEmoji(Possible<EmojiData> emoji) {
/* 1511 */       this.emoji = emoji;
/*      */     }
/*      */     @JsonProperty("custom_id")
/*      */     public void setCustomId(Possible<String> customId) {
/* 1515 */       this.customId = customId;
/*      */     }
/*      */     @JsonProperty("url")
/*      */     public void setUrl(Possible<String> url) {
/* 1519 */       this.url = url;
/*      */     }
/*      */     @JsonProperty("disabled")
/*      */     public void setDisabled(Possible<Boolean> disabled) {
/* 1523 */       this.disabled = disabled;
/*      */     }
/*      */     @JsonProperty("placeholder")
/*      */     public void setPlaceholder(Possible<String> placeholder) {
/* 1527 */       this.placeholder = placeholder;
/*      */     }
/*      */     @JsonProperty("min_values")
/*      */     public void setMinValues(Possible<Integer> minValues) {
/* 1531 */       this.minValues = minValues;
/*      */     }
/*      */     @JsonProperty("max_values")
/*      */     public void setMaxValues(Possible<Integer> maxValues) {
/* 1535 */       this.maxValues = maxValues;
/*      */     }
/*      */     @JsonProperty("min_length")
/*      */     public void setMinLength(Possible<Integer> minLength) {
/* 1539 */       this.minLength = minLength;
/*      */     }
/*      */     @JsonProperty("max_length")
/*      */     public void setMaxLength(Possible<Integer> maxLength) {
/* 1543 */       this.maxLength = maxLength;
/*      */     }
/*      */     @JsonProperty("required")
/*      */     public void setRequired(Possible<Boolean> required) {
/* 1547 */       this.required = required;
/*      */     }
/*      */     @JsonProperty("value")
/*      */     public void setValue(Possible<String> value) {
/* 1551 */       this.value = value;
/*      */     }
/*      */     @JsonProperty("values")
/*      */     public void setValues(Possible<List<String>> values) {
/* 1555 */       this.values = values;
/*      */     }
/*      */     @JsonProperty("options")
/*      */     public void setOptions(Possible<List<SelectOptionData>> options) {
/* 1559 */       this.options = options;
/*      */     }
/*      */     @JsonProperty("channel_types")
/*      */     public void setChannelTypes(Possible<List<Integer>> channelTypes) {
/* 1563 */       this.channelTypes = channelTypes;
/*      */     }
/*      */     public int type() {
/* 1566 */       throw new UnsupportedOperationException();
/*      */     } public Possible<List<ComponentData>> components() {
/* 1568 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> style() {
/* 1570 */       throw new UnsupportedOperationException();
/*      */     } public Possible<String> label() {
/* 1572 */       throw new UnsupportedOperationException();
/*      */     } public Possible<EmojiData> emoji() {
/* 1574 */       throw new UnsupportedOperationException();
/*      */     } public Possible<String> customId() {
/* 1576 */       throw new UnsupportedOperationException();
/*      */     } public Possible<String> url() {
/* 1578 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Boolean> disabled() {
/* 1580 */       throw new UnsupportedOperationException();
/*      */     } public Possible<String> placeholder() {
/* 1582 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> minValues() {
/* 1584 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> maxValues() {
/* 1586 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> minLength() {
/* 1588 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> maxLength() {
/* 1590 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Boolean> required() {
/* 1592 */       throw new UnsupportedOperationException();
/*      */     } public Possible<String> value() {
/* 1594 */       throw new UnsupportedOperationException();
/*      */     } public Possible<List<String>> values() {
/* 1596 */       throw new UnsupportedOperationException();
/*      */     } public Possible<List<SelectOptionData>> options() {
/* 1598 */       throw new UnsupportedOperationException();
/*      */     } public Possible<List<Integer>> channelTypes() {
/* 1600 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*      */   static ImmutableComponentData fromJson(Json json) {
/* 1611 */     Builder builder = builder();
/* 1612 */     if (json.typeIsSet) {
/* 1613 */       builder.type(json.type);
/*      */     }
/* 1615 */     if (json.components != null) {
/* 1616 */       builder.components(json.components);
/*      */     }
/* 1618 */     if (json.style != null) {
/* 1619 */       builder.style(json.style);
/*      */     }
/* 1621 */     if (json.label != null) {
/* 1622 */       builder.label(json.label);
/*      */     }
/* 1624 */     if (json.emoji != null) {
/* 1625 */       builder.emoji(json.emoji);
/*      */     }
/* 1627 */     if (json.customId != null) {
/* 1628 */       builder.customId(json.customId);
/*      */     }
/* 1630 */     if (json.url != null) {
/* 1631 */       builder.url(json.url);
/*      */     }
/* 1633 */     if (json.disabled != null) {
/* 1634 */       builder.disabled(json.disabled);
/*      */     }
/* 1636 */     if (json.placeholder != null) {
/* 1637 */       builder.placeholder(json.placeholder);
/*      */     }
/* 1639 */     if (json.minValues != null) {
/* 1640 */       builder.minValues(json.minValues);
/*      */     }
/* 1642 */     if (json.maxValues != null) {
/* 1643 */       builder.maxValues(json.maxValues);
/*      */     }
/* 1645 */     if (json.minLength != null) {
/* 1646 */       builder.minLength(json.minLength);
/*      */     }
/* 1648 */     if (json.maxLength != null) {
/* 1649 */       builder.maxLength(json.maxLength);
/*      */     }
/* 1651 */     if (json.required != null) {
/* 1652 */       builder.required(json.required);
/*      */     }
/* 1654 */     if (json.value != null) {
/* 1655 */       builder.value(json.value);
/*      */     }
/* 1657 */     if (json.values != null) {
/* 1658 */       builder.values(json.values);
/*      */     }
/* 1660 */     if (json.options != null) {
/* 1661 */       builder.options(json.options);
/*      */     }
/* 1663 */     if (json.channelTypes != null) {
/* 1664 */       builder.channelTypes(json.channelTypes);
/*      */     }
/* 1666 */     return builder.build();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableComponentData of(int type, Possible<List<ComponentData>> components, Possible<Integer> style, Possible<String> label, Possible<EmojiData> emoji, Possible<String> customId, Possible<String> url, Possible<Boolean> disabled, Possible<String> placeholder, Possible<Integer> minValues, Possible<Integer> maxValues, Possible<Integer> minLength, Possible<Integer> maxLength, Possible<Boolean> required, Possible<String> value, Possible<List<String>> values, Possible<List<SelectOptionData>> options, Possible<List<Integer>> channelTypes) {
/* 1692 */     return new ImmutableComponentData(type, components, style, label, emoji, customId, url, disabled, placeholder, minValues, maxValues, minLength, maxLength, required, value, values, options, channelTypes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableComponentData copyOf(ComponentData instance) {
/* 1703 */     if (instance instanceof ImmutableComponentData) {
/* 1704 */       return (ImmutableComponentData)instance;
/*      */     }
/* 1706 */     return builder()
/* 1707 */       .from(instance)
/* 1708 */       .build();
/*      */   }
/*      */   
/*      */   public boolean isComponentsPresent() {
/* 1712 */     return !this.components_absent;
/*      */   }
/*      */   
/*      */   public List<ComponentData> componentsOrElse(List<ComponentData> defaultValue) {
/* 1716 */     return !this.components_absent ? this.components_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isStylePresent() {
/* 1720 */     return !this.style_absent;
/*      */   }
/*      */   
/*      */   public Integer styleOrElse(Integer defaultValue) {
/* 1724 */     return !this.style_absent ? this.style_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isLabelPresent() {
/* 1728 */     return !this.label_absent;
/*      */   }
/*      */   
/*      */   public String labelOrElse(String defaultValue) {
/* 1732 */     return !this.label_absent ? this.label_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isEmojiPresent() {
/* 1736 */     return !this.emoji_absent;
/*      */   }
/*      */   
/*      */   public EmojiData emojiOrElse(EmojiData defaultValue) {
/* 1740 */     return !this.emoji_absent ? this.emoji_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isCustomIdPresent() {
/* 1744 */     return !this.customId_absent;
/*      */   }
/*      */   
/*      */   public String customIdOrElse(String defaultValue) {
/* 1748 */     return !this.customId_absent ? this.customId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isUrlPresent() {
/* 1752 */     return !this.url_absent;
/*      */   }
/*      */   
/*      */   public String urlOrElse(String defaultValue) {
/* 1756 */     return !this.url_absent ? this.url_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isDisabledPresent() {
/* 1760 */     return !this.disabled_absent;
/*      */   }
/*      */   
/*      */   public Boolean disabledOrElse(Boolean defaultValue) {
/* 1764 */     return !this.disabled_absent ? this.disabled_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isPlaceholderPresent() {
/* 1768 */     return !this.placeholder_absent;
/*      */   }
/*      */   
/*      */   public String placeholderOrElse(String defaultValue) {
/* 1772 */     return !this.placeholder_absent ? this.placeholder_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isMinValuesPresent() {
/* 1776 */     return !this.minValues_absent;
/*      */   }
/*      */   
/*      */   public Integer minValuesOrElse(Integer defaultValue) {
/* 1780 */     return !this.minValues_absent ? this.minValues_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isMaxValuesPresent() {
/* 1784 */     return !this.maxValues_absent;
/*      */   }
/*      */   
/*      */   public Integer maxValuesOrElse(Integer defaultValue) {
/* 1788 */     return !this.maxValues_absent ? this.maxValues_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isMinLengthPresent() {
/* 1792 */     return !this.minLength_absent;
/*      */   }
/*      */   
/*      */   public Integer minLengthOrElse(Integer defaultValue) {
/* 1796 */     return !this.minLength_absent ? this.minLength_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isMaxLengthPresent() {
/* 1800 */     return !this.maxLength_absent;
/*      */   }
/*      */   
/*      */   public Integer maxLengthOrElse(Integer defaultValue) {
/* 1804 */     return !this.maxLength_absent ? this.maxLength_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isRequiredPresent() {
/* 1808 */     return !this.required_absent;
/*      */   }
/*      */   
/*      */   public Boolean requiredOrElse(Boolean defaultValue) {
/* 1812 */     return !this.required_absent ? this.required_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isValuePresent() {
/* 1816 */     return !this.value_absent;
/*      */   }
/*      */   
/*      */   public String valueOrElse(String defaultValue) {
/* 1820 */     return !this.value_absent ? this.value_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isValuesPresent() {
/* 1824 */     return !this.values_absent;
/*      */   }
/*      */   
/*      */   public List<String> valuesOrElse(List<String> defaultValue) {
/* 1828 */     return !this.values_absent ? this.values_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isOptionsPresent() {
/* 1832 */     return !this.options_absent;
/*      */   }
/*      */   
/*      */   public List<SelectOptionData> optionsOrElse(List<SelectOptionData> defaultValue) {
/* 1836 */     return !this.options_absent ? this.options_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isChannelTypesPresent() {
/* 1840 */     return !this.channelTypes_absent;
/*      */   }
/*      */   
/*      */   public List<Integer> channelTypesOrElse(List<Integer> defaultValue) {
/* 1844 */     return !this.channelTypes_absent ? this.channelTypes_value : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Builder builder() {
/* 1874 */     return new Builder();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Generated(from = "ComponentData", generator = "Immutables")
/*      */   public static final class Builder
/*      */   {
/*      */     private static final long INIT_BIT_TYPE = 1L;
/*      */ 
/*      */ 
/*      */     
/* 1887 */     private long initBits = 1L;
/*      */     
/* 1889 */     private List<ComponentData> components_list = null;
/* 1890 */     private Possible<Integer> style_possible = Possible.absent();
/* 1891 */     private Possible<String> label_possible = Possible.absent();
/* 1892 */     private Possible<EmojiData> emoji_possible = Possible.absent();
/* 1893 */     private Possible<String> customId_possible = Possible.absent();
/* 1894 */     private Possible<String> url_possible = Possible.absent();
/* 1895 */     private Possible<Boolean> disabled_possible = Possible.absent();
/* 1896 */     private Possible<String> placeholder_possible = Possible.absent();
/* 1897 */     private Possible<Integer> minValues_possible = Possible.absent();
/* 1898 */     private Possible<Integer> maxValues_possible = Possible.absent();
/* 1899 */     private Possible<Integer> minLength_possible = Possible.absent();
/* 1900 */     private Possible<Integer> maxLength_possible = Possible.absent();
/* 1901 */     private Possible<Boolean> required_possible = Possible.absent();
/* 1902 */     private Possible<String> value_possible = Possible.absent();
/* 1903 */     private List<String> values_list = null;
/* 1904 */     private List<SelectOptionData> options_list = null;
/* 1905 */     private List<Integer> channelTypes_list = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private int type;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(ComponentData instance) {
/* 1919 */       Objects.requireNonNull(instance, "instance");
/* 1920 */       type(instance.type());
/* 1921 */       components(instance.components());
/* 1922 */       style(instance.style());
/* 1923 */       label(instance.label());
/* 1924 */       emoji(instance.emoji());
/* 1925 */       customId(instance.customId());
/* 1926 */       url(instance.url());
/* 1927 */       disabled(instance.disabled());
/* 1928 */       placeholder(instance.placeholder());
/* 1929 */       minValues(instance.minValues());
/* 1930 */       maxValues(instance.maxValues());
/* 1931 */       minLength(instance.minLength());
/* 1932 */       maxLength(instance.maxLength());
/* 1933 */       required(instance.required());
/* 1934 */       value(instance.value());
/* 1935 */       values(instance.values());
/* 1936 */       options(instance.options());
/* 1937 */       channelTypes(instance.channelTypes());
/* 1938 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("type")
/*      */     public final Builder type(int type) {
/* 1948 */       this.type = type;
/* 1949 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 1950 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addComponent(ComponentData element) {
/* 1954 */       components_getOrCreate().add(element);
/* 1955 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addAllComponents(List<ComponentData> elements) {
/* 1959 */       components_getOrCreate().addAll(elements);
/* 1960 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("components")
/*      */     public Builder components(Possible<List<ComponentData>> elements) {
/* 1965 */       this.components_list = null;
/* 1966 */       elements.toOptional().ifPresent(e -> components_getOrCreate().addAll(e));
/* 1967 */       return this;
/*      */     }
/*      */     
/*      */     public Builder components(List<ComponentData> elements) {
/* 1971 */       this.components_list = new ArrayList<>(elements);
/* 1972 */       return this;
/*      */     }
/*      */     
/*      */     public Builder components(Iterable<ComponentData> elements) {
/* 1976 */       this.components_list = (List<ComponentData>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 1977 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("style")
/*      */     public Builder style(Possible<Integer> value) {
/* 1982 */       this.style_possible = value;
/* 1983 */       return this;
/*      */     }
/*      */     
/*      */     public Builder style(Integer value) {
/* 1987 */       this.style_possible = Possible.of(value);
/* 1988 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("label")
/*      */     public Builder label(Possible<String> value) {
/* 1993 */       this.label_possible = value;
/* 1994 */       return this;
/*      */     }
/*      */     
/*      */     public Builder label(String value) {
/* 1998 */       this.label_possible = Possible.of(value);
/* 1999 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("emoji")
/*      */     public Builder emoji(Possible<EmojiData> value) {
/* 2004 */       this.emoji_possible = value;
/* 2005 */       return this;
/*      */     }
/*      */     
/*      */     public Builder emoji(EmojiData value) {
/* 2009 */       this.emoji_possible = Possible.of(value);
/* 2010 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("custom_id")
/*      */     public Builder customId(Possible<String> value) {
/* 2015 */       this.customId_possible = value;
/* 2016 */       return this;
/*      */     }
/*      */     
/*      */     public Builder customId(String value) {
/* 2020 */       this.customId_possible = Possible.of(value);
/* 2021 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("url")
/*      */     public Builder url(Possible<String> value) {
/* 2026 */       this.url_possible = value;
/* 2027 */       return this;
/*      */     }
/*      */     
/*      */     public Builder url(String value) {
/* 2031 */       this.url_possible = Possible.of(value);
/* 2032 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("disabled")
/*      */     public Builder disabled(Possible<Boolean> value) {
/* 2037 */       this.disabled_possible = value;
/* 2038 */       return this;
/*      */     }
/*      */     
/*      */     public Builder disabled(Boolean value) {
/* 2042 */       this.disabled_possible = Possible.of(value);
/* 2043 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("placeholder")
/*      */     public Builder placeholder(Possible<String> value) {
/* 2048 */       this.placeholder_possible = value;
/* 2049 */       return this;
/*      */     }
/*      */     
/*      */     public Builder placeholder(String value) {
/* 2053 */       this.placeholder_possible = Possible.of(value);
/* 2054 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("min_values")
/*      */     public Builder minValues(Possible<Integer> value) {
/* 2059 */       this.minValues_possible = value;
/* 2060 */       return this;
/*      */     }
/*      */     
/*      */     public Builder minValues(Integer value) {
/* 2064 */       this.minValues_possible = Possible.of(value);
/* 2065 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("max_values")
/*      */     public Builder maxValues(Possible<Integer> value) {
/* 2070 */       this.maxValues_possible = value;
/* 2071 */       return this;
/*      */     }
/*      */     
/*      */     public Builder maxValues(Integer value) {
/* 2075 */       this.maxValues_possible = Possible.of(value);
/* 2076 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("min_length")
/*      */     public Builder minLength(Possible<Integer> value) {
/* 2081 */       this.minLength_possible = value;
/* 2082 */       return this;
/*      */     }
/*      */     
/*      */     public Builder minLength(Integer value) {
/* 2086 */       this.minLength_possible = Possible.of(value);
/* 2087 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("max_length")
/*      */     public Builder maxLength(Possible<Integer> value) {
/* 2092 */       this.maxLength_possible = value;
/* 2093 */       return this;
/*      */     }
/*      */     
/*      */     public Builder maxLength(Integer value) {
/* 2097 */       this.maxLength_possible = Possible.of(value);
/* 2098 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("required")
/*      */     public Builder required(Possible<Boolean> value) {
/* 2103 */       this.required_possible = value;
/* 2104 */       return this;
/*      */     }
/*      */     
/*      */     public Builder required(Boolean value) {
/* 2108 */       this.required_possible = Possible.of(value);
/* 2109 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("value")
/*      */     public Builder value(Possible<String> value) {
/* 2114 */       this.value_possible = value;
/* 2115 */       return this;
/*      */     }
/*      */     
/*      */     public Builder value(String value) {
/* 2119 */       this.value_possible = Possible.of(value);
/* 2120 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addValue(String element) {
/* 2124 */       values_getOrCreate().add(element);
/* 2125 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addAllValues(List<String> elements) {
/* 2129 */       values_getOrCreate().addAll(elements);
/* 2130 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("values")
/*      */     public Builder values(Possible<List<String>> elements) {
/* 2135 */       this.values_list = null;
/* 2136 */       elements.toOptional().ifPresent(e -> values_getOrCreate().addAll(e));
/* 2137 */       return this;
/*      */     }
/*      */     
/*      */     public Builder values(List<String> elements) {
/* 2141 */       this.values_list = new ArrayList<>(elements);
/* 2142 */       return this;
/*      */     }
/*      */     
/*      */     public Builder values(Iterable<String> elements) {
/* 2146 */       this.values_list = (List<String>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 2147 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addOption(SelectOptionData element) {
/* 2151 */       options_getOrCreate().add(element);
/* 2152 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addAllOptions(List<SelectOptionData> elements) {
/* 2156 */       options_getOrCreate().addAll(elements);
/* 2157 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("options")
/*      */     public Builder options(Possible<List<SelectOptionData>> elements) {
/* 2162 */       this.options_list = null;
/* 2163 */       elements.toOptional().ifPresent(e -> options_getOrCreate().addAll(e));
/* 2164 */       return this;
/*      */     }
/*      */     
/*      */     public Builder options(List<SelectOptionData> elements) {
/* 2168 */       this.options_list = new ArrayList<>(elements);
/* 2169 */       return this;
/*      */     }
/*      */     
/*      */     public Builder options(Iterable<SelectOptionData> elements) {
/* 2173 */       this.options_list = (List<SelectOptionData>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 2174 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addChannelType(Integer element) {
/* 2178 */       channelTypes_getOrCreate().add(element);
/* 2179 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addAllChannelTypes(List<Integer> elements) {
/* 2183 */       channelTypes_getOrCreate().addAll(elements);
/* 2184 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("channel_types")
/*      */     public Builder channelTypes(Possible<List<Integer>> elements) {
/* 2189 */       this.channelTypes_list = null;
/* 2190 */       elements.toOptional().ifPresent(e -> channelTypes_getOrCreate().addAll(e));
/* 2191 */       return this;
/*      */     }
/*      */     
/*      */     public Builder channelTypes(List<Integer> elements) {
/* 2195 */       this.channelTypes_list = new ArrayList<>(elements);
/* 2196 */       return this;
/*      */     }
/*      */     
/*      */     public Builder channelTypes(Iterable<Integer> elements) {
/* 2200 */       this.channelTypes_list = (List<Integer>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 2201 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ImmutableComponentData build() {
/* 2210 */       if (this.initBits != 0L) {
/* 2211 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*      */       }
/* 2213 */       return new ImmutableComponentData(null, this.type, 
/*      */ 
/*      */           
/* 2216 */           components_build(), 
/* 2217 */           style_build(), 
/* 2218 */           label_build(), 
/* 2219 */           emoji_build(), 
/* 2220 */           customId_build(), 
/* 2221 */           url_build(), 
/* 2222 */           disabled_build(), 
/* 2223 */           placeholder_build(), 
/* 2224 */           minValues_build(), 
/* 2225 */           maxValues_build(), 
/* 2226 */           minLength_build(), 
/* 2227 */           maxLength_build(), 
/* 2228 */           required_build(), 
/* 2229 */           value_build(), 
/* 2230 */           values_build(), 
/* 2231 */           options_build(), 
/* 2232 */           channelTypes_build());
/*      */     }
/*      */     
/*      */     private String formatRequiredAttributesMessage() {
/* 2236 */       List<String> attributes = new ArrayList<>();
/* 2237 */       if ((this.initBits & 0x1L) != 0L) attributes.add("type"); 
/* 2238 */       return "Cannot build ComponentData, some of required attributes are not set " + attributes;
/*      */     }
/*      */     
/*      */     private Possible<List<ComponentData>> components_build() {
/* 2242 */       return (this.components_list == null) ? Possible.absent() : 
/* 2243 */         Possible.of(this.components_list);
/*      */     }
/*      */     
/*      */     private List<ComponentData> components_getOrCreate() {
/* 2247 */       if (this.components_list == null) {
/* 2248 */         this.components_list = new ArrayList<>();
/*      */       }
/* 2250 */       return this.components_list;
/*      */     }
/*      */     
/*      */     private Possible<Integer> style_build() {
/* 2254 */       return this.style_possible;
/*      */     }
/*      */     
/*      */     private Possible<String> label_build() {
/* 2258 */       return this.label_possible;
/*      */     }
/*      */     
/*      */     private Possible<EmojiData> emoji_build() {
/* 2262 */       return this.emoji_possible;
/*      */     }
/*      */     
/*      */     private Possible<String> customId_build() {
/* 2266 */       return this.customId_possible;
/*      */     }
/*      */     
/*      */     private Possible<String> url_build() {
/* 2270 */       return this.url_possible;
/*      */     }
/*      */     
/*      */     private Possible<Boolean> disabled_build() {
/* 2274 */       return this.disabled_possible;
/*      */     }
/*      */     
/*      */     private Possible<String> placeholder_build() {
/* 2278 */       return this.placeholder_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> minValues_build() {
/* 2282 */       return this.minValues_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> maxValues_build() {
/* 2286 */       return this.maxValues_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> minLength_build() {
/* 2290 */       return this.minLength_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> maxLength_build() {
/* 2294 */       return this.maxLength_possible;
/*      */     }
/*      */     
/*      */     private Possible<Boolean> required_build() {
/* 2298 */       return this.required_possible;
/*      */     }
/*      */     
/*      */     private Possible<String> value_build() {
/* 2302 */       return this.value_possible;
/*      */     }
/*      */     
/*      */     private Possible<List<String>> values_build() {
/* 2306 */       return (this.values_list == null) ? Possible.absent() : 
/* 2307 */         Possible.of(this.values_list);
/*      */     }
/*      */     
/*      */     private List<String> values_getOrCreate() {
/* 2311 */       if (this.values_list == null) {
/* 2312 */         this.values_list = new ArrayList<>();
/*      */       }
/* 2314 */       return this.values_list;
/*      */     }
/*      */     
/*      */     private Possible<List<SelectOptionData>> options_build() {
/* 2318 */       return (this.options_list == null) ? Possible.absent() : 
/* 2319 */         Possible.of(this.options_list);
/*      */     }
/*      */     
/*      */     private List<SelectOptionData> options_getOrCreate() {
/* 2323 */       if (this.options_list == null) {
/* 2324 */         this.options_list = new ArrayList<>();
/*      */       }
/* 2326 */       return this.options_list;
/*      */     }
/*      */     
/*      */     private Possible<List<Integer>> channelTypes_build() {
/* 2330 */       return (this.channelTypes_list == null) ? Possible.absent() : 
/* 2331 */         Possible.of(this.channelTypes_list);
/*      */     }
/*      */     
/*      */     private List<Integer> channelTypes_getOrCreate() {
/* 2335 */       if (this.channelTypes_list == null) {
/* 2336 */         this.channelTypes_list = new ArrayList<>();
/*      */       }
/* 2338 */       return this.channelTypes_list;
/*      */     }
/*      */     
/*      */     private Builder() {}
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableComponentData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */