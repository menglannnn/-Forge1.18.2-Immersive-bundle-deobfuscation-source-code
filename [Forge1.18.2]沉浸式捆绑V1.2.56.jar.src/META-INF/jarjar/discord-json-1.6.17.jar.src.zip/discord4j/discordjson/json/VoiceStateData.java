/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.Id;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import java.util.Optional;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ @JsonSerialize(as = ImmutableVoiceStateData.class)
/*    */ @JsonDeserialize(as = ImmutableVoiceStateData.class)
/*    */ @Immutable
/*    */ public interface VoiceStateData
/*    */ {
/*    */   static ImmutableVoiceStateData.Builder builder() {
/* 18 */     return ImmutableVoiceStateData.builder();
/*    */   }
/*    */   
/*    */   @JsonProperty("guild_id")
/*    */   Possible<Id> guildId();
/*    */   
/*    */   @JsonProperty("channel_id")
/*    */   Optional<Id> channelId();
/*    */   
/*    */   @JsonProperty("user_id")
/*    */   Id userId();
/*    */   
/*    */   Possible<MemberData> member();
/*    */   
/*    */   @JsonProperty("session_id")
/*    */   String sessionId();
/*    */   
/*    */   boolean deaf();
/*    */   
/*    */   boolean mute();
/*    */   
/*    */   @JsonProperty("self_deaf")
/*    */   boolean selfDeaf();
/*    */   
/*    */   @JsonProperty("self_mute")
/*    */   boolean selfMute();
/*    */   
/*    */   @JsonProperty("self_stream")
/*    */   Possible<Boolean> selfStream();
/*    */   
/*    */   @JsonProperty("self_video")
/*    */   boolean selfVideo();
/*    */   
/*    */   boolean suppress();
/*    */   
/*    */   @JsonProperty("request_to_speak_timestamp")
/*    */   Optional<String> requestToSpeakTimestamp();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\VoiceStateData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */