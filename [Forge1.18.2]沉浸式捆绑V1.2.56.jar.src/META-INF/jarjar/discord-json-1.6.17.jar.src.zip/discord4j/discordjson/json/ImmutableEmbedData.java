/*      */ package discord4j.discordjson.json;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*      */ import com.fasterxml.jackson.annotation.JsonCreator;
/*      */ import com.fasterxml.jackson.annotation.JsonProperty;
/*      */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*      */ import discord4j.discordjson.possible.Possible;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import java.util.stream.Collectors;
/*      */ import java.util.stream.StreamSupport;
/*      */ import org.immutables.value.Generated;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Generated(from = "EmbedData", generator = "Immutables")
/*      */ public final class ImmutableEmbedData
/*      */   implements EmbedData
/*      */ {
/*      */   private final String title_value;
/*      */   private final boolean title_absent;
/*      */   private final String type_value;
/*      */   private final boolean type_absent;
/*      */   private final String description_value;
/*      */   private final boolean description_absent;
/*      */   private final String url_value;
/*      */   private final boolean url_absent;
/*      */   private final String timestamp_value;
/*      */   private final boolean timestamp_absent;
/*      */   private final Integer color_value;
/*      */   private final boolean color_absent;
/*      */   private final EmbedFooterData footer_value;
/*      */   private final boolean footer_absent;
/*      */   private final EmbedImageData image_value;
/*      */   private final boolean image_absent;
/*      */   private final EmbedThumbnailData thumbnail_value;
/*      */   private final boolean thumbnail_absent;
/*      */   private final EmbedVideoData video_value;
/*      */   private final boolean video_absent;
/*      */   private final EmbedProviderData provider_value;
/*      */   private final boolean provider_absent;
/*      */   private final EmbedAuthorData author_value;
/*      */   private final boolean author_absent;
/*      */   private final List<EmbedFieldData> fields_value;
/*      */   private final boolean fields_absent;
/*      */   private static final byte STAGE_INITIALIZING = -1;
/*      */   private static final byte STAGE_UNINITIALIZED = 0;
/*      */   private static final byte STAGE_INITIALIZED = 1;
/*      */   
/*      */   private ImmutableEmbedData(Possible<String> title, Possible<String> type, Possible<String> description, Possible<String> url, Possible<String> timestamp, Possible<Integer> color, Possible<EmbedFooterData> footer, Possible<EmbedImageData> image, Possible<EmbedThumbnailData> thumbnail, Possible<EmbedVideoData> video, Possible<EmbedProviderData> provider, Possible<EmbedAuthorData> author, Possible<List<EmbedFieldData>> fields) {
/*   69 */     Possible<String> title$impl = title;
/*   70 */     Possible<String> type$impl = type;
/*   71 */     Possible<String> description$impl = description;
/*   72 */     Possible<String> url$impl = url;
/*   73 */     Possible<String> timestamp$impl = timestamp;
/*   74 */     Possible<Integer> color$impl = color;
/*   75 */     Possible<EmbedFooterData> footer$impl = footer;
/*   76 */     Possible<EmbedImageData> image$impl = image;
/*   77 */     Possible<EmbedThumbnailData> thumbnail$impl = thumbnail;
/*   78 */     Possible<EmbedVideoData> video$impl = video;
/*   79 */     Possible<EmbedProviderData> provider$impl = provider;
/*   80 */     Possible<EmbedAuthorData> author$impl = author;
/*   81 */     Possible<List<EmbedFieldData>> fields$impl = fields;
/*   82 */     this.title_value = title$impl.toOptional().orElse(null);
/*   83 */     this.title_absent = title$impl.isAbsent();
/*   84 */     this.type_value = type$impl.toOptional().orElse(null);
/*   85 */     this.type_absent = type$impl.isAbsent();
/*   86 */     this.description_value = description$impl.toOptional().orElse(null);
/*   87 */     this.description_absent = description$impl.isAbsent();
/*   88 */     this.url_value = url$impl.toOptional().orElse(null);
/*   89 */     this.url_absent = url$impl.isAbsent();
/*   90 */     this.timestamp_value = timestamp$impl.toOptional().orElse(null);
/*   91 */     this.timestamp_absent = timestamp$impl.isAbsent();
/*   92 */     this.color_value = color$impl.toOptional().orElse(null);
/*   93 */     this.color_absent = color$impl.isAbsent();
/*   94 */     this.footer_value = footer$impl.toOptional().orElse(null);
/*   95 */     this.footer_absent = footer$impl.isAbsent();
/*   96 */     this.image_value = image$impl.toOptional().orElse(null);
/*   97 */     this.image_absent = image$impl.isAbsent();
/*   98 */     this.thumbnail_value = thumbnail$impl.toOptional().orElse(null);
/*   99 */     this.thumbnail_absent = thumbnail$impl.isAbsent();
/*  100 */     this.video_value = video$impl.toOptional().orElse(null);
/*  101 */     this.video_absent = video$impl.isAbsent();
/*  102 */     this.provider_value = provider$impl.toOptional().orElse(null);
/*  103 */     this.provider_absent = provider$impl.isAbsent();
/*  104 */     this.author_value = author$impl.toOptional().orElse(null);
/*  105 */     this.author_absent = author$impl.isAbsent();
/*  106 */     this.fields_value = fields$impl.toOptional().orElse(null);
/*  107 */     this.fields_absent = fields$impl.isAbsent();
/*  108 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ImmutableEmbedData(ImmutableEmbedData original, Possible<String> title, Possible<String> type, Possible<String> description, Possible<String> url, Possible<String> timestamp, Possible<Integer> color, Possible<EmbedFooterData> footer, Possible<EmbedImageData> image, Possible<EmbedThumbnailData> thumbnail, Possible<EmbedVideoData> video, Possible<EmbedProviderData> provider, Possible<EmbedAuthorData> author, Possible<List<EmbedFieldData>> fields) {
/*  126 */     Possible<String> title$impl = title;
/*  127 */     Possible<String> type$impl = type;
/*  128 */     Possible<String> description$impl = description;
/*  129 */     Possible<String> url$impl = url;
/*  130 */     Possible<String> timestamp$impl = timestamp;
/*  131 */     Possible<Integer> color$impl = color;
/*  132 */     Possible<EmbedFooterData> footer$impl = footer;
/*  133 */     Possible<EmbedImageData> image$impl = image;
/*  134 */     Possible<EmbedThumbnailData> thumbnail$impl = thumbnail;
/*  135 */     Possible<EmbedVideoData> video$impl = video;
/*  136 */     Possible<EmbedProviderData> provider$impl = provider;
/*  137 */     Possible<EmbedAuthorData> author$impl = author;
/*  138 */     Possible<List<EmbedFieldData>> fields$impl = fields;
/*  139 */     this.title_value = title$impl.toOptional().orElse(null);
/*  140 */     this.title_absent = title$impl.isAbsent();
/*  141 */     this.type_value = type$impl.toOptional().orElse(null);
/*  142 */     this.type_absent = type$impl.isAbsent();
/*  143 */     this.description_value = description$impl.toOptional().orElse(null);
/*  144 */     this.description_absent = description$impl.isAbsent();
/*  145 */     this.url_value = url$impl.toOptional().orElse(null);
/*  146 */     this.url_absent = url$impl.isAbsent();
/*  147 */     this.timestamp_value = timestamp$impl.toOptional().orElse(null);
/*  148 */     this.timestamp_absent = timestamp$impl.isAbsent();
/*  149 */     this.color_value = color$impl.toOptional().orElse(null);
/*  150 */     this.color_absent = color$impl.isAbsent();
/*  151 */     this.footer_value = footer$impl.toOptional().orElse(null);
/*  152 */     this.footer_absent = footer$impl.isAbsent();
/*  153 */     this.image_value = image$impl.toOptional().orElse(null);
/*  154 */     this.image_absent = image$impl.isAbsent();
/*  155 */     this.thumbnail_value = thumbnail$impl.toOptional().orElse(null);
/*  156 */     this.thumbnail_absent = thumbnail$impl.isAbsent();
/*  157 */     this.video_value = video$impl.toOptional().orElse(null);
/*  158 */     this.video_absent = video$impl.isAbsent();
/*  159 */     this.provider_value = provider$impl.toOptional().orElse(null);
/*  160 */     this.provider_absent = provider$impl.isAbsent();
/*  161 */     this.author_value = author$impl.toOptional().orElse(null);
/*  162 */     this.author_absent = author$impl.isAbsent();
/*  163 */     this.fields_value = fields$impl.toOptional().orElse(null);
/*  164 */     this.fields_absent = fields$impl.isAbsent();
/*  165 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  171 */   private volatile transient InitShim initShim = new InitShim();
/*      */   
/*      */   @Generated(from = "EmbedData", generator = "Immutables")
/*      */   private final class InitShim {
/*      */     private String formatInitCycleMessage() {
/*  176 */       List<String> attributes = new ArrayList<>();
/*  177 */       return "Cannot build EmbedData, attribute initializers form cycle " + attributes;
/*      */     }
/*      */ 
/*      */     
/*      */     private InitShim() {}
/*      */   }
/*      */ 
/*      */   
/*      */   @JsonProperty("title")
/*      */   public Possible<String> title() {
/*  187 */     return this.title_absent ? Possible.absent() : Possible.of(this.title_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("type")
/*      */   public Possible<String> type() {
/*  196 */     return this.type_absent ? Possible.absent() : Possible.of(this.type_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("description")
/*      */   public Possible<String> description() {
/*  205 */     return this.description_absent ? Possible.absent() : Possible.of(this.description_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("url")
/*      */   public Possible<String> url() {
/*  214 */     return this.url_absent ? Possible.absent() : Possible.of(this.url_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("timestamp")
/*      */   public Possible<String> timestamp() {
/*  223 */     return this.timestamp_absent ? Possible.absent() : Possible.of(this.timestamp_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("color")
/*      */   public Possible<Integer> color() {
/*  232 */     return this.color_absent ? Possible.absent() : Possible.of(this.color_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("footer")
/*      */   public Possible<EmbedFooterData> footer() {
/*  241 */     return this.footer_absent ? Possible.absent() : Possible.of(this.footer_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("image")
/*      */   public Possible<EmbedImageData> image() {
/*  250 */     return this.image_absent ? Possible.absent() : Possible.of(this.image_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("thumbnail")
/*      */   public Possible<EmbedThumbnailData> thumbnail() {
/*  259 */     return this.thumbnail_absent ? Possible.absent() : Possible.of(this.thumbnail_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("video")
/*      */   public Possible<EmbedVideoData> video() {
/*  268 */     return this.video_absent ? Possible.absent() : Possible.of(this.video_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("provider")
/*      */   public Possible<EmbedProviderData> provider() {
/*  277 */     return this.provider_absent ? Possible.absent() : Possible.of(this.provider_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("author")
/*      */   public Possible<EmbedAuthorData> author() {
/*  286 */     return this.author_absent ? Possible.absent() : Possible.of(this.author_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("fields")
/*      */   public Possible<List<EmbedFieldData>> fields() {
/*  295 */     return this.fields_absent ? Possible.absent() : 
/*  296 */       Possible.of(this.fields_value);
/*      */   }
/*      */   
/*      */   public ImmutableEmbedData withTitle(Possible<String> value) {
/*  300 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  301 */     return new ImmutableEmbedData(this, newValue, 
/*      */ 
/*      */         
/*  304 */         type(), 
/*  305 */         description(), 
/*  306 */         url(), 
/*  307 */         timestamp(), 
/*  308 */         color(), 
/*  309 */         footer(), 
/*  310 */         image(), 
/*  311 */         thumbnail(), 
/*  312 */         video(), 
/*  313 */         provider(), 
/*  314 */         author(), 
/*  315 */         fields());
/*      */   }
/*      */   
/*      */   public ImmutableEmbedData withTitle(String value) {
/*  319 */     Possible<String> newValue = Possible.of(value);
/*  320 */     return new ImmutableEmbedData(this, newValue, 
/*      */ 
/*      */         
/*  323 */         type(), 
/*  324 */         description(), 
/*  325 */         url(), 
/*  326 */         timestamp(), 
/*  327 */         color(), 
/*  328 */         footer(), 
/*  329 */         image(), 
/*  330 */         thumbnail(), 
/*  331 */         video(), 
/*  332 */         provider(), 
/*  333 */         author(), 
/*  334 */         fields());
/*      */   }
/*      */   
/*      */   public ImmutableEmbedData withType(Possible<String> value) {
/*  338 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  339 */     return new ImmutableEmbedData(this, 
/*      */         
/*  341 */         title(), newValue, 
/*      */         
/*  343 */         description(), 
/*  344 */         url(), 
/*  345 */         timestamp(), 
/*  346 */         color(), 
/*  347 */         footer(), 
/*  348 */         image(), 
/*  349 */         thumbnail(), 
/*  350 */         video(), 
/*  351 */         provider(), 
/*  352 */         author(), 
/*  353 */         fields());
/*      */   }
/*      */   
/*      */   public ImmutableEmbedData withType(String value) {
/*  357 */     Possible<String> newValue = Possible.of(value);
/*  358 */     return new ImmutableEmbedData(this, 
/*      */         
/*  360 */         title(), newValue, 
/*      */         
/*  362 */         description(), 
/*  363 */         url(), 
/*  364 */         timestamp(), 
/*  365 */         color(), 
/*  366 */         footer(), 
/*  367 */         image(), 
/*  368 */         thumbnail(), 
/*  369 */         video(), 
/*  370 */         provider(), 
/*  371 */         author(), 
/*  372 */         fields());
/*      */   }
/*      */   
/*      */   public ImmutableEmbedData withDescription(Possible<String> value) {
/*  376 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  377 */     return new ImmutableEmbedData(this, 
/*      */         
/*  379 */         title(), 
/*  380 */         type(), newValue, 
/*      */         
/*  382 */         url(), 
/*  383 */         timestamp(), 
/*  384 */         color(), 
/*  385 */         footer(), 
/*  386 */         image(), 
/*  387 */         thumbnail(), 
/*  388 */         video(), 
/*  389 */         provider(), 
/*  390 */         author(), 
/*  391 */         fields());
/*      */   }
/*      */   
/*      */   public ImmutableEmbedData withDescription(String value) {
/*  395 */     Possible<String> newValue = Possible.of(value);
/*  396 */     return new ImmutableEmbedData(this, 
/*      */         
/*  398 */         title(), 
/*  399 */         type(), newValue, 
/*      */         
/*  401 */         url(), 
/*  402 */         timestamp(), 
/*  403 */         color(), 
/*  404 */         footer(), 
/*  405 */         image(), 
/*  406 */         thumbnail(), 
/*  407 */         video(), 
/*  408 */         provider(), 
/*  409 */         author(), 
/*  410 */         fields());
/*      */   }
/*      */   
/*      */   public ImmutableEmbedData withUrl(Possible<String> value) {
/*  414 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  415 */     return new ImmutableEmbedData(this, 
/*      */         
/*  417 */         title(), 
/*  418 */         type(), 
/*  419 */         description(), newValue, 
/*      */         
/*  421 */         timestamp(), 
/*  422 */         color(), 
/*  423 */         footer(), 
/*  424 */         image(), 
/*  425 */         thumbnail(), 
/*  426 */         video(), 
/*  427 */         provider(), 
/*  428 */         author(), 
/*  429 */         fields());
/*      */   }
/*      */   
/*      */   public ImmutableEmbedData withUrl(String value) {
/*  433 */     Possible<String> newValue = Possible.of(value);
/*  434 */     return new ImmutableEmbedData(this, 
/*      */         
/*  436 */         title(), 
/*  437 */         type(), 
/*  438 */         description(), newValue, 
/*      */         
/*  440 */         timestamp(), 
/*  441 */         color(), 
/*  442 */         footer(), 
/*  443 */         image(), 
/*  444 */         thumbnail(), 
/*  445 */         video(), 
/*  446 */         provider(), 
/*  447 */         author(), 
/*  448 */         fields());
/*      */   }
/*      */   
/*      */   public ImmutableEmbedData withTimestamp(Possible<String> value) {
/*  452 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  453 */     return new ImmutableEmbedData(this, 
/*      */         
/*  455 */         title(), 
/*  456 */         type(), 
/*  457 */         description(), 
/*  458 */         url(), newValue, 
/*      */         
/*  460 */         color(), 
/*  461 */         footer(), 
/*  462 */         image(), 
/*  463 */         thumbnail(), 
/*  464 */         video(), 
/*  465 */         provider(), 
/*  466 */         author(), 
/*  467 */         fields());
/*      */   }
/*      */   
/*      */   public ImmutableEmbedData withTimestamp(String value) {
/*  471 */     Possible<String> newValue = Possible.of(value);
/*  472 */     return new ImmutableEmbedData(this, 
/*      */         
/*  474 */         title(), 
/*  475 */         type(), 
/*  476 */         description(), 
/*  477 */         url(), newValue, 
/*      */         
/*  479 */         color(), 
/*  480 */         footer(), 
/*  481 */         image(), 
/*  482 */         thumbnail(), 
/*  483 */         video(), 
/*  484 */         provider(), 
/*  485 */         author(), 
/*  486 */         fields());
/*      */   }
/*      */   
/*      */   public ImmutableEmbedData withColor(Possible<Integer> value) {
/*  490 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/*  491 */     return new ImmutableEmbedData(this, 
/*      */         
/*  493 */         title(), 
/*  494 */         type(), 
/*  495 */         description(), 
/*  496 */         url(), 
/*  497 */         timestamp(), newValue, 
/*      */         
/*  499 */         footer(), 
/*  500 */         image(), 
/*  501 */         thumbnail(), 
/*  502 */         video(), 
/*  503 */         provider(), 
/*  504 */         author(), 
/*  505 */         fields());
/*      */   }
/*      */   
/*      */   public ImmutableEmbedData withColor(Integer value) {
/*  509 */     Possible<Integer> newValue = Possible.of(value);
/*  510 */     return new ImmutableEmbedData(this, 
/*      */         
/*  512 */         title(), 
/*  513 */         type(), 
/*  514 */         description(), 
/*  515 */         url(), 
/*  516 */         timestamp(), newValue, 
/*      */         
/*  518 */         footer(), 
/*  519 */         image(), 
/*  520 */         thumbnail(), 
/*  521 */         video(), 
/*  522 */         provider(), 
/*  523 */         author(), 
/*  524 */         fields());
/*      */   }
/*      */   
/*      */   public ImmutableEmbedData withFooter(Possible<EmbedFooterData> value) {
/*  528 */     Possible<EmbedFooterData> newValue = Objects.<Possible<EmbedFooterData>>requireNonNull(value);
/*  529 */     return new ImmutableEmbedData(this, 
/*      */         
/*  531 */         title(), 
/*  532 */         type(), 
/*  533 */         description(), 
/*  534 */         url(), 
/*  535 */         timestamp(), 
/*  536 */         color(), newValue, 
/*      */         
/*  538 */         image(), 
/*  539 */         thumbnail(), 
/*  540 */         video(), 
/*  541 */         provider(), 
/*  542 */         author(), 
/*  543 */         fields());
/*      */   }
/*      */   
/*      */   public ImmutableEmbedData withFooter(EmbedFooterData value) {
/*  547 */     Possible<EmbedFooterData> newValue = Possible.of(value);
/*  548 */     return new ImmutableEmbedData(this, 
/*      */         
/*  550 */         title(), 
/*  551 */         type(), 
/*  552 */         description(), 
/*  553 */         url(), 
/*  554 */         timestamp(), 
/*  555 */         color(), newValue, 
/*      */         
/*  557 */         image(), 
/*  558 */         thumbnail(), 
/*  559 */         video(), 
/*  560 */         provider(), 
/*  561 */         author(), 
/*  562 */         fields());
/*      */   }
/*      */   
/*      */   public ImmutableEmbedData withImage(Possible<EmbedImageData> value) {
/*  566 */     Possible<EmbedImageData> newValue = Objects.<Possible<EmbedImageData>>requireNonNull(value);
/*  567 */     return new ImmutableEmbedData(this, 
/*      */         
/*  569 */         title(), 
/*  570 */         type(), 
/*  571 */         description(), 
/*  572 */         url(), 
/*  573 */         timestamp(), 
/*  574 */         color(), 
/*  575 */         footer(), newValue, 
/*      */         
/*  577 */         thumbnail(), 
/*  578 */         video(), 
/*  579 */         provider(), 
/*  580 */         author(), 
/*  581 */         fields());
/*      */   }
/*      */   
/*      */   public ImmutableEmbedData withImage(EmbedImageData value) {
/*  585 */     Possible<EmbedImageData> newValue = Possible.of(value);
/*  586 */     return new ImmutableEmbedData(this, 
/*      */         
/*  588 */         title(), 
/*  589 */         type(), 
/*  590 */         description(), 
/*  591 */         url(), 
/*  592 */         timestamp(), 
/*  593 */         color(), 
/*  594 */         footer(), newValue, 
/*      */         
/*  596 */         thumbnail(), 
/*  597 */         video(), 
/*  598 */         provider(), 
/*  599 */         author(), 
/*  600 */         fields());
/*      */   }
/*      */   
/*      */   public ImmutableEmbedData withThumbnail(Possible<EmbedThumbnailData> value) {
/*  604 */     Possible<EmbedThumbnailData> newValue = Objects.<Possible<EmbedThumbnailData>>requireNonNull(value);
/*  605 */     return new ImmutableEmbedData(this, 
/*      */         
/*  607 */         title(), 
/*  608 */         type(), 
/*  609 */         description(), 
/*  610 */         url(), 
/*  611 */         timestamp(), 
/*  612 */         color(), 
/*  613 */         footer(), 
/*  614 */         image(), newValue, 
/*      */         
/*  616 */         video(), 
/*  617 */         provider(), 
/*  618 */         author(), 
/*  619 */         fields());
/*      */   }
/*      */   
/*      */   public ImmutableEmbedData withThumbnail(EmbedThumbnailData value) {
/*  623 */     Possible<EmbedThumbnailData> newValue = Possible.of(value);
/*  624 */     return new ImmutableEmbedData(this, 
/*      */         
/*  626 */         title(), 
/*  627 */         type(), 
/*  628 */         description(), 
/*  629 */         url(), 
/*  630 */         timestamp(), 
/*  631 */         color(), 
/*  632 */         footer(), 
/*  633 */         image(), newValue, 
/*      */         
/*  635 */         video(), 
/*  636 */         provider(), 
/*  637 */         author(), 
/*  638 */         fields());
/*      */   }
/*      */   
/*      */   public ImmutableEmbedData withVideo(Possible<EmbedVideoData> value) {
/*  642 */     Possible<EmbedVideoData> newValue = Objects.<Possible<EmbedVideoData>>requireNonNull(value);
/*  643 */     return new ImmutableEmbedData(this, 
/*      */         
/*  645 */         title(), 
/*  646 */         type(), 
/*  647 */         description(), 
/*  648 */         url(), 
/*  649 */         timestamp(), 
/*  650 */         color(), 
/*  651 */         footer(), 
/*  652 */         image(), 
/*  653 */         thumbnail(), newValue, 
/*      */         
/*  655 */         provider(), 
/*  656 */         author(), 
/*  657 */         fields());
/*      */   }
/*      */   
/*      */   public ImmutableEmbedData withVideo(EmbedVideoData value) {
/*  661 */     Possible<EmbedVideoData> newValue = Possible.of(value);
/*  662 */     return new ImmutableEmbedData(this, 
/*      */         
/*  664 */         title(), 
/*  665 */         type(), 
/*  666 */         description(), 
/*  667 */         url(), 
/*  668 */         timestamp(), 
/*  669 */         color(), 
/*  670 */         footer(), 
/*  671 */         image(), 
/*  672 */         thumbnail(), newValue, 
/*      */         
/*  674 */         provider(), 
/*  675 */         author(), 
/*  676 */         fields());
/*      */   }
/*      */   
/*      */   public ImmutableEmbedData withProvider(Possible<EmbedProviderData> value) {
/*  680 */     Possible<EmbedProviderData> newValue = Objects.<Possible<EmbedProviderData>>requireNonNull(value);
/*  681 */     return new ImmutableEmbedData(this, 
/*      */         
/*  683 */         title(), 
/*  684 */         type(), 
/*  685 */         description(), 
/*  686 */         url(), 
/*  687 */         timestamp(), 
/*  688 */         color(), 
/*  689 */         footer(), 
/*  690 */         image(), 
/*  691 */         thumbnail(), 
/*  692 */         video(), newValue, 
/*      */         
/*  694 */         author(), 
/*  695 */         fields());
/*      */   }
/*      */   
/*      */   public ImmutableEmbedData withProvider(EmbedProviderData value) {
/*  699 */     Possible<EmbedProviderData> newValue = Possible.of(value);
/*  700 */     return new ImmutableEmbedData(this, 
/*      */         
/*  702 */         title(), 
/*  703 */         type(), 
/*  704 */         description(), 
/*  705 */         url(), 
/*  706 */         timestamp(), 
/*  707 */         color(), 
/*  708 */         footer(), 
/*  709 */         image(), 
/*  710 */         thumbnail(), 
/*  711 */         video(), newValue, 
/*      */         
/*  713 */         author(), 
/*  714 */         fields());
/*      */   }
/*      */   
/*      */   public ImmutableEmbedData withAuthor(Possible<EmbedAuthorData> value) {
/*  718 */     Possible<EmbedAuthorData> newValue = Objects.<Possible<EmbedAuthorData>>requireNonNull(value);
/*  719 */     return new ImmutableEmbedData(this, 
/*      */         
/*  721 */         title(), 
/*  722 */         type(), 
/*  723 */         description(), 
/*  724 */         url(), 
/*  725 */         timestamp(), 
/*  726 */         color(), 
/*  727 */         footer(), 
/*  728 */         image(), 
/*  729 */         thumbnail(), 
/*  730 */         video(), 
/*  731 */         provider(), newValue, 
/*      */         
/*  733 */         fields());
/*      */   }
/*      */   
/*      */   public ImmutableEmbedData withAuthor(EmbedAuthorData value) {
/*  737 */     Possible<EmbedAuthorData> newValue = Possible.of(value);
/*  738 */     return new ImmutableEmbedData(this, 
/*      */         
/*  740 */         title(), 
/*  741 */         type(), 
/*  742 */         description(), 
/*  743 */         url(), 
/*  744 */         timestamp(), 
/*  745 */         color(), 
/*  746 */         footer(), 
/*  747 */         image(), 
/*  748 */         thumbnail(), 
/*  749 */         video(), 
/*  750 */         provider(), newValue, 
/*      */         
/*  752 */         fields());
/*      */   }
/*      */   
/*      */   public ImmutableEmbedData withFields(Possible<List<EmbedFieldData>> possible) {
/*  756 */     Possible<List<EmbedFieldData>> newValue = Objects.<Possible<List<EmbedFieldData>>>requireNonNull(possible);
/*  757 */     return new ImmutableEmbedData(this, 
/*      */         
/*  759 */         title(), 
/*  760 */         type(), 
/*  761 */         description(), 
/*  762 */         url(), 
/*  763 */         timestamp(), 
/*  764 */         color(), 
/*  765 */         footer(), 
/*  766 */         image(), 
/*  767 */         thumbnail(), 
/*  768 */         video(), 
/*  769 */         provider(), 
/*  770 */         author(), newValue);
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableEmbedData withFields(Iterable<EmbedFieldData> elements) {
/*  775 */     Possible<List<EmbedFieldData>> newValue = Possible.of(
/*  776 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/*  777 */     return new ImmutableEmbedData(this, 
/*      */         
/*  779 */         title(), 
/*  780 */         type(), 
/*  781 */         description(), 
/*  782 */         url(), 
/*  783 */         timestamp(), 
/*  784 */         color(), 
/*  785 */         footer(), 
/*  786 */         image(), 
/*  787 */         thumbnail(), 
/*  788 */         video(), 
/*  789 */         provider(), 
/*  790 */         author(), newValue);
/*      */   }
/*      */ 
/*      */   
/*      */   @SafeVarargs
/*      */   public final ImmutableEmbedData withFields(EmbedFieldData... elements) {
/*  796 */     Possible<List<EmbedFieldData>> newValue = Possible.of(Arrays.asList(elements));
/*  797 */     return new ImmutableEmbedData(this, 
/*      */         
/*  799 */         title(), 
/*  800 */         type(), 
/*  801 */         description(), 
/*  802 */         url(), 
/*  803 */         timestamp(), 
/*  804 */         color(), 
/*  805 */         footer(), 
/*  806 */         image(), 
/*  807 */         thumbnail(), 
/*  808 */         video(), 
/*  809 */         provider(), 
/*  810 */         author(), newValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object another) {
/*  820 */     if (this == another) return true; 
/*  821 */     return (another instanceof ImmutableEmbedData && 
/*  822 */       equalTo(0, (ImmutableEmbedData)another));
/*      */   }
/*      */   
/*      */   private boolean equalTo(int synthetic, ImmutableEmbedData another) {
/*  826 */     return (title().equals(another.title()) && 
/*  827 */       type().equals(another.type()) && 
/*  828 */       description().equals(another.description()) && 
/*  829 */       url().equals(another.url()) && 
/*  830 */       timestamp().equals(another.timestamp()) && 
/*  831 */       color().equals(another.color()) && 
/*  832 */       footer().equals(another.footer()) && 
/*  833 */       image().equals(another.image()) && 
/*  834 */       thumbnail().equals(another.thumbnail()) && 
/*  835 */       video().equals(another.video()) && 
/*  836 */       provider().equals(another.provider()) && 
/*  837 */       author().equals(another.author()) && 
/*  838 */       Objects.equals(this.fields_value, another.fields_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/*  847 */     int h = 5381;
/*  848 */     h += (h << 5) + title().hashCode();
/*  849 */     h += (h << 5) + type().hashCode();
/*  850 */     h += (h << 5) + description().hashCode();
/*  851 */     h += (h << 5) + url().hashCode();
/*  852 */     h += (h << 5) + timestamp().hashCode();
/*  853 */     h += (h << 5) + color().hashCode();
/*  854 */     h += (h << 5) + footer().hashCode();
/*  855 */     h += (h << 5) + image().hashCode();
/*  856 */     h += (h << 5) + thumbnail().hashCode();
/*  857 */     h += (h << 5) + video().hashCode();
/*  858 */     h += (h << 5) + provider().hashCode();
/*  859 */     h += (h << 5) + author().hashCode();
/*  860 */     h += (h << 5) + Objects.hashCode(this.fields_value);
/*  861 */     return h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*  870 */     return "EmbedData{title=" + 
/*  871 */       title().toString() + ", type=" + 
/*  872 */       type().toString() + ", description=" + 
/*  873 */       description().toString() + ", url=" + 
/*  874 */       url().toString() + ", timestamp=" + 
/*  875 */       timestamp().toString() + ", color=" + 
/*  876 */       color().toString() + ", footer=" + 
/*  877 */       footer().toString() + ", image=" + 
/*  878 */       image().toString() + ", thumbnail=" + 
/*  879 */       thumbnail().toString() + ", video=" + 
/*  880 */       video().toString() + ", provider=" + 
/*  881 */       provider().toString() + ", author=" + 
/*  882 */       author().toString() + ", fields=" + 
/*  883 */       Objects.toString(this.fields_value) + "}";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonDeserialize
/*      */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*      */   @Generated(from = "EmbedData", generator = "Immutables")
/*      */   static final class Json
/*      */     implements EmbedData
/*      */   {
/*  897 */     Possible<String> title = Possible.absent();
/*      */ 
/*      */     
/*  900 */     Possible<String> type = Possible.absent();
/*      */ 
/*      */     
/*  903 */     Possible<String> description = Possible.absent();
/*      */ 
/*      */     
/*  906 */     Possible<String> url = Possible.absent();
/*      */ 
/*      */     
/*  909 */     Possible<String> timestamp = Possible.absent();
/*      */ 
/*      */     
/*  912 */     Possible<Integer> color = Possible.absent();
/*      */ 
/*      */     
/*  915 */     Possible<EmbedFooterData> footer = Possible.absent();
/*      */ 
/*      */     
/*  918 */     Possible<EmbedImageData> image = Possible.absent();
/*      */ 
/*      */     
/*  921 */     Possible<EmbedThumbnailData> thumbnail = Possible.absent();
/*      */ 
/*      */     
/*  924 */     Possible<EmbedVideoData> video = Possible.absent();
/*      */ 
/*      */     
/*  927 */     Possible<EmbedProviderData> provider = Possible.absent();
/*      */ 
/*      */     
/*  930 */     Possible<EmbedAuthorData> author = Possible.absent();
/*      */ 
/*      */     
/*  933 */     Possible<List<EmbedFieldData>> fields = Possible.absent();
/*      */     
/*      */     @JsonProperty("title")
/*      */     public void setTitle(Possible<String> title) {
/*  937 */       this.title = title;
/*      */     }
/*      */     @JsonProperty("type")
/*      */     public void setType(Possible<String> type) {
/*  941 */       this.type = type;
/*      */     }
/*      */     @JsonProperty("description")
/*      */     public void setDescription(Possible<String> description) {
/*  945 */       this.description = description;
/*      */     }
/*      */     @JsonProperty("url")
/*      */     public void setUrl(Possible<String> url) {
/*  949 */       this.url = url;
/*      */     }
/*      */     @JsonProperty("timestamp")
/*      */     public void setTimestamp(Possible<String> timestamp) {
/*  953 */       this.timestamp = timestamp;
/*      */     }
/*      */     @JsonProperty("color")
/*      */     public void setColor(Possible<Integer> color) {
/*  957 */       this.color = color;
/*      */     }
/*      */     @JsonProperty("footer")
/*      */     public void setFooter(Possible<EmbedFooterData> footer) {
/*  961 */       this.footer = footer;
/*      */     }
/*      */     @JsonProperty("image")
/*      */     public void setImage(Possible<EmbedImageData> image) {
/*  965 */       this.image = image;
/*      */     }
/*      */     @JsonProperty("thumbnail")
/*      */     public void setThumbnail(Possible<EmbedThumbnailData> thumbnail) {
/*  969 */       this.thumbnail = thumbnail;
/*      */     }
/*      */     @JsonProperty("video")
/*      */     public void setVideo(Possible<EmbedVideoData> video) {
/*  973 */       this.video = video;
/*      */     }
/*      */     @JsonProperty("provider")
/*      */     public void setProvider(Possible<EmbedProviderData> provider) {
/*  977 */       this.provider = provider;
/*      */     }
/*      */     @JsonProperty("author")
/*      */     public void setAuthor(Possible<EmbedAuthorData> author) {
/*  981 */       this.author = author;
/*      */     }
/*      */     @JsonProperty("fields")
/*      */     public void setFields(Possible<List<EmbedFieldData>> fields) {
/*  985 */       this.fields = fields;
/*      */     }
/*      */     public Possible<String> title() {
/*  988 */       throw new UnsupportedOperationException();
/*      */     } public Possible<String> type() {
/*  990 */       throw new UnsupportedOperationException();
/*      */     } public Possible<String> description() {
/*  992 */       throw new UnsupportedOperationException();
/*      */     } public Possible<String> url() {
/*  994 */       throw new UnsupportedOperationException();
/*      */     } public Possible<String> timestamp() {
/*  996 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> color() {
/*  998 */       throw new UnsupportedOperationException();
/*      */     } public Possible<EmbedFooterData> footer() {
/* 1000 */       throw new UnsupportedOperationException();
/*      */     } public Possible<EmbedImageData> image() {
/* 1002 */       throw new UnsupportedOperationException();
/*      */     } public Possible<EmbedThumbnailData> thumbnail() {
/* 1004 */       throw new UnsupportedOperationException();
/*      */     } public Possible<EmbedVideoData> video() {
/* 1006 */       throw new UnsupportedOperationException();
/*      */     } public Possible<EmbedProviderData> provider() {
/* 1008 */       throw new UnsupportedOperationException();
/*      */     } public Possible<EmbedAuthorData> author() {
/* 1010 */       throw new UnsupportedOperationException();
/*      */     } public Possible<List<EmbedFieldData>> fields() {
/* 1012 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*      */   static ImmutableEmbedData fromJson(Json json) {
/* 1023 */     Builder builder = builder();
/* 1024 */     if (json.title != null) {
/* 1025 */       builder.title(json.title);
/*      */     }
/* 1027 */     if (json.type != null) {
/* 1028 */       builder.type(json.type);
/*      */     }
/* 1030 */     if (json.description != null) {
/* 1031 */       builder.description(json.description);
/*      */     }
/* 1033 */     if (json.url != null) {
/* 1034 */       builder.url(json.url);
/*      */     }
/* 1036 */     if (json.timestamp != null) {
/* 1037 */       builder.timestamp(json.timestamp);
/*      */     }
/* 1039 */     if (json.color != null) {
/* 1040 */       builder.color(json.color);
/*      */     }
/* 1042 */     if (json.footer != null) {
/* 1043 */       builder.footer(json.footer);
/*      */     }
/* 1045 */     if (json.image != null) {
/* 1046 */       builder.image(json.image);
/*      */     }
/* 1048 */     if (json.thumbnail != null) {
/* 1049 */       builder.thumbnail(json.thumbnail);
/*      */     }
/* 1051 */     if (json.video != null) {
/* 1052 */       builder.video(json.video);
/*      */     }
/* 1054 */     if (json.provider != null) {
/* 1055 */       builder.provider(json.provider);
/*      */     }
/* 1057 */     if (json.author != null) {
/* 1058 */       builder.author(json.author);
/*      */     }
/* 1060 */     if (json.fields != null) {
/* 1061 */       builder.fields(json.fields);
/*      */     }
/* 1063 */     return builder.build();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableEmbedData of(Possible<String> title, Possible<String> type, Possible<String> description, Possible<String> url, Possible<String> timestamp, Possible<Integer> color, Possible<EmbedFooterData> footer, Possible<EmbedImageData> image, Possible<EmbedThumbnailData> thumbnail, Possible<EmbedVideoData> video, Possible<EmbedProviderData> provider, Possible<EmbedAuthorData> author, Possible<List<EmbedFieldData>> fields) {
/* 1084 */     return new ImmutableEmbedData(title, type, description, url, timestamp, color, footer, image, thumbnail, video, provider, author, fields);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableEmbedData copyOf(EmbedData instance) {
/* 1095 */     if (instance instanceof ImmutableEmbedData) {
/* 1096 */       return (ImmutableEmbedData)instance;
/*      */     }
/* 1098 */     return builder()
/* 1099 */       .from(instance)
/* 1100 */       .build();
/*      */   }
/*      */   
/*      */   public boolean isTitlePresent() {
/* 1104 */     return !this.title_absent;
/*      */   }
/*      */   
/*      */   public String titleOrElse(String defaultValue) {
/* 1108 */     return !this.title_absent ? this.title_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isTypePresent() {
/* 1112 */     return !this.type_absent;
/*      */   }
/*      */   
/*      */   public String typeOrElse(String defaultValue) {
/* 1116 */     return !this.type_absent ? this.type_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isDescriptionPresent() {
/* 1120 */     return !this.description_absent;
/*      */   }
/*      */   
/*      */   public String descriptionOrElse(String defaultValue) {
/* 1124 */     return !this.description_absent ? this.description_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isUrlPresent() {
/* 1128 */     return !this.url_absent;
/*      */   }
/*      */   
/*      */   public String urlOrElse(String defaultValue) {
/* 1132 */     return !this.url_absent ? this.url_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isTimestampPresent() {
/* 1136 */     return !this.timestamp_absent;
/*      */   }
/*      */   
/*      */   public String timestampOrElse(String defaultValue) {
/* 1140 */     return !this.timestamp_absent ? this.timestamp_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isColorPresent() {
/* 1144 */     return !this.color_absent;
/*      */   }
/*      */   
/*      */   public Integer colorOrElse(Integer defaultValue) {
/* 1148 */     return !this.color_absent ? this.color_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isFooterPresent() {
/* 1152 */     return !this.footer_absent;
/*      */   }
/*      */   
/*      */   public EmbedFooterData footerOrElse(EmbedFooterData defaultValue) {
/* 1156 */     return !this.footer_absent ? this.footer_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isImagePresent() {
/* 1160 */     return !this.image_absent;
/*      */   }
/*      */   
/*      */   public EmbedImageData imageOrElse(EmbedImageData defaultValue) {
/* 1164 */     return !this.image_absent ? this.image_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isThumbnailPresent() {
/* 1168 */     return !this.thumbnail_absent;
/*      */   }
/*      */   
/*      */   public EmbedThumbnailData thumbnailOrElse(EmbedThumbnailData defaultValue) {
/* 1172 */     return !this.thumbnail_absent ? this.thumbnail_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isVideoPresent() {
/* 1176 */     return !this.video_absent;
/*      */   }
/*      */   
/*      */   public EmbedVideoData videoOrElse(EmbedVideoData defaultValue) {
/* 1180 */     return !this.video_absent ? this.video_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isProviderPresent() {
/* 1184 */     return !this.provider_absent;
/*      */   }
/*      */   
/*      */   public EmbedProviderData providerOrElse(EmbedProviderData defaultValue) {
/* 1188 */     return !this.provider_absent ? this.provider_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isAuthorPresent() {
/* 1192 */     return !this.author_absent;
/*      */   }
/*      */   
/*      */   public EmbedAuthorData authorOrElse(EmbedAuthorData defaultValue) {
/* 1196 */     return !this.author_absent ? this.author_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isFieldsPresent() {
/* 1200 */     return !this.fields_absent;
/*      */   }
/*      */   
/*      */   public List<EmbedFieldData> fieldsOrElse(List<EmbedFieldData> defaultValue) {
/* 1204 */     return !this.fields_absent ? this.fields_value : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Builder builder() {
/* 1229 */     return new Builder();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Generated(from = "EmbedData", generator = "Immutables")
/*      */   public static final class Builder
/*      */   {
/* 1241 */     private Possible<String> title_possible = Possible.absent();
/* 1242 */     private Possible<String> type_possible = Possible.absent();
/* 1243 */     private Possible<String> description_possible = Possible.absent();
/* 1244 */     private Possible<String> url_possible = Possible.absent();
/* 1245 */     private Possible<String> timestamp_possible = Possible.absent();
/* 1246 */     private Possible<Integer> color_possible = Possible.absent();
/* 1247 */     private Possible<EmbedFooterData> footer_possible = Possible.absent();
/* 1248 */     private Possible<EmbedImageData> image_possible = Possible.absent();
/* 1249 */     private Possible<EmbedThumbnailData> thumbnail_possible = Possible.absent();
/* 1250 */     private Possible<EmbedVideoData> video_possible = Possible.absent();
/* 1251 */     private Possible<EmbedProviderData> provider_possible = Possible.absent();
/* 1252 */     private Possible<EmbedAuthorData> author_possible = Possible.absent();
/* 1253 */     private List<EmbedFieldData> fields_list = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(EmbedData instance) {
/* 1266 */       Objects.requireNonNull(instance, "instance");
/* 1267 */       title(instance.title());
/* 1268 */       type(instance.type());
/* 1269 */       description(instance.description());
/* 1270 */       url(instance.url());
/* 1271 */       timestamp(instance.timestamp());
/* 1272 */       color(instance.color());
/* 1273 */       footer(instance.footer());
/* 1274 */       image(instance.image());
/* 1275 */       thumbnail(instance.thumbnail());
/* 1276 */       video(instance.video());
/* 1277 */       provider(instance.provider());
/* 1278 */       author(instance.author());
/* 1279 */       fields(instance.fields());
/* 1280 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("title")
/*      */     public Builder title(Possible<String> value) {
/* 1285 */       this.title_possible = value;
/* 1286 */       return this;
/*      */     }
/*      */     
/*      */     public Builder title(String value) {
/* 1290 */       this.title_possible = Possible.of(value);
/* 1291 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("type")
/*      */     public Builder type(Possible<String> value) {
/* 1296 */       this.type_possible = value;
/* 1297 */       return this;
/*      */     }
/*      */     
/*      */     public Builder type(String value) {
/* 1301 */       this.type_possible = Possible.of(value);
/* 1302 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("description")
/*      */     public Builder description(Possible<String> value) {
/* 1307 */       this.description_possible = value;
/* 1308 */       return this;
/*      */     }
/*      */     
/*      */     public Builder description(String value) {
/* 1312 */       this.description_possible = Possible.of(value);
/* 1313 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("url")
/*      */     public Builder url(Possible<String> value) {
/* 1318 */       this.url_possible = value;
/* 1319 */       return this;
/*      */     }
/*      */     
/*      */     public Builder url(String value) {
/* 1323 */       this.url_possible = Possible.of(value);
/* 1324 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("timestamp")
/*      */     public Builder timestamp(Possible<String> value) {
/* 1329 */       this.timestamp_possible = value;
/* 1330 */       return this;
/*      */     }
/*      */     
/*      */     public Builder timestamp(String value) {
/* 1334 */       this.timestamp_possible = Possible.of(value);
/* 1335 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("color")
/*      */     public Builder color(Possible<Integer> value) {
/* 1340 */       this.color_possible = value;
/* 1341 */       return this;
/*      */     }
/*      */     
/*      */     public Builder color(Integer value) {
/* 1345 */       this.color_possible = Possible.of(value);
/* 1346 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("footer")
/*      */     public Builder footer(Possible<EmbedFooterData> value) {
/* 1351 */       this.footer_possible = value;
/* 1352 */       return this;
/*      */     }
/*      */     
/*      */     public Builder footer(EmbedFooterData value) {
/* 1356 */       this.footer_possible = Possible.of(value);
/* 1357 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("image")
/*      */     public Builder image(Possible<EmbedImageData> value) {
/* 1362 */       this.image_possible = value;
/* 1363 */       return this;
/*      */     }
/*      */     
/*      */     public Builder image(EmbedImageData value) {
/* 1367 */       this.image_possible = Possible.of(value);
/* 1368 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("thumbnail")
/*      */     public Builder thumbnail(Possible<EmbedThumbnailData> value) {
/* 1373 */       this.thumbnail_possible = value;
/* 1374 */       return this;
/*      */     }
/*      */     
/*      */     public Builder thumbnail(EmbedThumbnailData value) {
/* 1378 */       this.thumbnail_possible = Possible.of(value);
/* 1379 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("video")
/*      */     public Builder video(Possible<EmbedVideoData> value) {
/* 1384 */       this.video_possible = value;
/* 1385 */       return this;
/*      */     }
/*      */     
/*      */     public Builder video(EmbedVideoData value) {
/* 1389 */       this.video_possible = Possible.of(value);
/* 1390 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("provider")
/*      */     public Builder provider(Possible<EmbedProviderData> value) {
/* 1395 */       this.provider_possible = value;
/* 1396 */       return this;
/*      */     }
/*      */     
/*      */     public Builder provider(EmbedProviderData value) {
/* 1400 */       this.provider_possible = Possible.of(value);
/* 1401 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("author")
/*      */     public Builder author(Possible<EmbedAuthorData> value) {
/* 1406 */       this.author_possible = value;
/* 1407 */       return this;
/*      */     }
/*      */     
/*      */     public Builder author(EmbedAuthorData value) {
/* 1411 */       this.author_possible = Possible.of(value);
/* 1412 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addField(EmbedFieldData element) {
/* 1416 */       fields_getOrCreate().add(element);
/* 1417 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addAllFields(List<EmbedFieldData> elements) {
/* 1421 */       fields_getOrCreate().addAll(elements);
/* 1422 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("fields")
/*      */     public Builder fields(Possible<List<EmbedFieldData>> elements) {
/* 1427 */       this.fields_list = null;
/* 1428 */       elements.toOptional().ifPresent(e -> fields_getOrCreate().addAll(e));
/* 1429 */       return this;
/*      */     }
/*      */     
/*      */     public Builder fields(List<EmbedFieldData> elements) {
/* 1433 */       this.fields_list = new ArrayList<>(elements);
/* 1434 */       return this;
/*      */     }
/*      */     
/*      */     public Builder fields(Iterable<EmbedFieldData> elements) {
/* 1438 */       this.fields_list = (List<EmbedFieldData>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 1439 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ImmutableEmbedData build() {
/* 1448 */       return new ImmutableEmbedData(null, 
/*      */           
/* 1450 */           title_build(), 
/* 1451 */           type_build(), 
/* 1452 */           description_build(), 
/* 1453 */           url_build(), 
/* 1454 */           timestamp_build(), 
/* 1455 */           color_build(), 
/* 1456 */           footer_build(), 
/* 1457 */           image_build(), 
/* 1458 */           thumbnail_build(), 
/* 1459 */           video_build(), 
/* 1460 */           provider_build(), 
/* 1461 */           author_build(), 
/* 1462 */           fields_build());
/*      */     }
/*      */     
/*      */     private Possible<String> title_build() {
/* 1466 */       return this.title_possible;
/*      */     }
/*      */     
/*      */     private Possible<String> type_build() {
/* 1470 */       return this.type_possible;
/*      */     }
/*      */     
/*      */     private Possible<String> description_build() {
/* 1474 */       return this.description_possible;
/*      */     }
/*      */     
/*      */     private Possible<String> url_build() {
/* 1478 */       return this.url_possible;
/*      */     }
/*      */     
/*      */     private Possible<String> timestamp_build() {
/* 1482 */       return this.timestamp_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> color_build() {
/* 1486 */       return this.color_possible;
/*      */     }
/*      */     
/*      */     private Possible<EmbedFooterData> footer_build() {
/* 1490 */       return this.footer_possible;
/*      */     }
/*      */     
/*      */     private Possible<EmbedImageData> image_build() {
/* 1494 */       return this.image_possible;
/*      */     }
/*      */     
/*      */     private Possible<EmbedThumbnailData> thumbnail_build() {
/* 1498 */       return this.thumbnail_possible;
/*      */     }
/*      */     
/*      */     private Possible<EmbedVideoData> video_build() {
/* 1502 */       return this.video_possible;
/*      */     }
/*      */     
/*      */     private Possible<EmbedProviderData> provider_build() {
/* 1506 */       return this.provider_possible;
/*      */     }
/*      */     
/*      */     private Possible<EmbedAuthorData> author_build() {
/* 1510 */       return this.author_possible;
/*      */     }
/*      */     
/*      */     private Possible<List<EmbedFieldData>> fields_build() {
/* 1514 */       return (this.fields_list == null) ? Possible.absent() : 
/* 1515 */         Possible.of(this.fields_list);
/*      */     }
/*      */     
/*      */     private List<EmbedFieldData> fields_getOrCreate() {
/* 1519 */       if (this.fields_list == null) {
/* 1520 */         this.fields_list = new ArrayList<>();
/*      */       }
/* 1522 */       return this.fields_list;
/*      */     }
/*      */     
/*      */     private Builder() {}
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableEmbedData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */