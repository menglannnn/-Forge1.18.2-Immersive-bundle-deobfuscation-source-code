/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "PartialGuildApplicationCommandPermissionsData", generator = "Immutables")
/*     */ public final class ImmutablePartialGuildApplicationCommandPermissionsData
/*     */   implements PartialGuildApplicationCommandPermissionsData
/*     */ {
/*     */   private final String id;
/*     */   private final List<ApplicationCommandPermissionsData> permissions;
/*     */   
/*     */   private ImmutablePartialGuildApplicationCommandPermissionsData(String id, Iterable<? extends ApplicationCommandPermissionsData> permissions) {
/*  34 */     this.id = Objects.<String>requireNonNull(id, "id");
/*  35 */     this.permissions = createUnmodifiableList(false, createSafeList(permissions, true, false));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutablePartialGuildApplicationCommandPermissionsData(ImmutablePartialGuildApplicationCommandPermissionsData original, String id, List<ApplicationCommandPermissionsData> permissions) {
/*  42 */     this.id = id;
/*  43 */     this.permissions = permissions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("id")
/*     */   public String id() {
/*  52 */     return this.id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("permissions")
/*     */   public List<ApplicationCommandPermissionsData> permissions() {
/*  61 */     return this.permissions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutablePartialGuildApplicationCommandPermissionsData withId(String value) {
/*  71 */     String newValue = Objects.<String>requireNonNull(value, "id");
/*  72 */     if (this.id.equals(newValue)) return this; 
/*  73 */     return new ImmutablePartialGuildApplicationCommandPermissionsData(this, newValue, this.permissions);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutablePartialGuildApplicationCommandPermissionsData withPermissions(ApplicationCommandPermissionsData... elements) {
/*  82 */     List<ApplicationCommandPermissionsData> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/*  83 */     return new ImmutablePartialGuildApplicationCommandPermissionsData(this, this.id, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutablePartialGuildApplicationCommandPermissionsData withPermissions(Iterable<? extends ApplicationCommandPermissionsData> elements) {
/*  93 */     if (this.permissions == elements) return this; 
/*  94 */     List<ApplicationCommandPermissionsData> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/*  95 */     return new ImmutablePartialGuildApplicationCommandPermissionsData(this, this.id, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 104 */     if (this == another) return true; 
/* 105 */     return (another instanceof ImmutablePartialGuildApplicationCommandPermissionsData && 
/* 106 */       equalTo(0, (ImmutablePartialGuildApplicationCommandPermissionsData)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutablePartialGuildApplicationCommandPermissionsData another) {
/* 110 */     return (this.id.equals(another.id) && this.permissions
/* 111 */       .equals(another.permissions));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 120 */     int h = 5381;
/* 121 */     h += (h << 5) + this.id.hashCode();
/* 122 */     h += (h << 5) + this.permissions.hashCode();
/* 123 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 132 */     return "PartialGuildApplicationCommandPermissionsData{id=" + this.id + ", permissions=" + this.permissions + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "PartialGuildApplicationCommandPermissionsData", generator = "Immutables")
/*     */   static final class Json
/*     */     implements PartialGuildApplicationCommandPermissionsData
/*     */   {
/*     */     String id;
/*     */ 
/*     */     
/* 148 */     List<ApplicationCommandPermissionsData> permissions = Collections.emptyList();
/*     */     @JsonProperty("id")
/*     */     public void setId(String id) {
/* 151 */       this.id = id;
/*     */     }
/*     */     @JsonProperty("permissions")
/*     */     public void setPermissions(List<ApplicationCommandPermissionsData> permissions) {
/* 155 */       this.permissions = permissions;
/*     */     }
/*     */     public String id() {
/* 158 */       throw new UnsupportedOperationException();
/*     */     } public List<ApplicationCommandPermissionsData> permissions() {
/* 160 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutablePartialGuildApplicationCommandPermissionsData fromJson(Json json) {
/* 171 */     Builder builder = builder();
/* 172 */     if (json.id != null) {
/* 173 */       builder.id(json.id);
/*     */     }
/* 175 */     if (json.permissions != null) {
/* 176 */       builder.addAllPermissions(json.permissions);
/*     */     }
/* 178 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutablePartialGuildApplicationCommandPermissionsData of(String id, List<ApplicationCommandPermissionsData> permissions) {
/* 188 */     return of(id, permissions);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutablePartialGuildApplicationCommandPermissionsData of(String id, Iterable<? extends ApplicationCommandPermissionsData> permissions) {
/* 198 */     return new ImmutablePartialGuildApplicationCommandPermissionsData(id, permissions);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutablePartialGuildApplicationCommandPermissionsData copyOf(PartialGuildApplicationCommandPermissionsData instance) {
/* 209 */     if (instance instanceof ImmutablePartialGuildApplicationCommandPermissionsData) {
/* 210 */       return (ImmutablePartialGuildApplicationCommandPermissionsData)instance;
/*     */     }
/* 212 */     return builder()
/* 213 */       .from(instance)
/* 214 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 228 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "PartialGuildApplicationCommandPermissionsData", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_ID = 1L;
/*     */ 
/*     */ 
/*     */     
/* 241 */     private long initBits = 1L;
/*     */     
/*     */     private String id;
/* 244 */     private List<ApplicationCommandPermissionsData> permissions = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(PartialGuildApplicationCommandPermissionsData instance) {
/* 258 */       Objects.requireNonNull(instance, "instance");
/* 259 */       id(instance.id());
/* 260 */       addAllPermissions(instance.permissions());
/* 261 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("id")
/*     */     public final Builder id(String id) {
/* 271 */       this.id = Objects.<String>requireNonNull(id, "id");
/* 272 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 273 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addPermission(ApplicationCommandPermissionsData element) {
/* 282 */       this.permissions.add(Objects.<ApplicationCommandPermissionsData>requireNonNull(element, "permissions element"));
/* 283 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addPermissions(ApplicationCommandPermissionsData... elements) {
/* 292 */       for (ApplicationCommandPermissionsData element : elements) {
/* 293 */         this.permissions.add(Objects.<ApplicationCommandPermissionsData>requireNonNull(element, "permissions element"));
/*     */       }
/* 295 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("permissions")
/*     */     public final Builder permissions(Iterable<? extends ApplicationCommandPermissionsData> elements) {
/* 306 */       this.permissions.clear();
/* 307 */       return addAllPermissions(elements);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addAllPermissions(Iterable<? extends ApplicationCommandPermissionsData> elements) {
/* 316 */       for (ApplicationCommandPermissionsData element : elements) {
/* 317 */         this.permissions.add(Objects.<ApplicationCommandPermissionsData>requireNonNull(element, "permissions element"));
/*     */       }
/* 319 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutablePartialGuildApplicationCommandPermissionsData build() {
/* 328 */       if (this.initBits != 0L) {
/* 329 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 331 */       return new ImmutablePartialGuildApplicationCommandPermissionsData(null, this.id, ImmutablePartialGuildApplicationCommandPermissionsData.createUnmodifiableList(true, (List)this.permissions));
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 335 */       List<String> attributes = new ArrayList<>();
/* 336 */       if ((this.initBits & 0x1L) != 0L) attributes.add("id"); 
/* 337 */       return "Cannot build PartialGuildApplicationCommandPermissionsData, some of required attributes are not set " + attributes;
/*     */     }
/*     */     private Builder() {} }
/*     */   
/*     */   private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
/*     */     ArrayList<T> list;
/* 343 */     if (iterable instanceof Collection) {
/* 344 */       int size = ((Collection)iterable).size();
/* 345 */       if (size == 0) return Collections.emptyList(); 
/* 346 */       list = new ArrayList<>();
/*     */     } else {
/* 348 */       list = new ArrayList<>();
/*     */     } 
/* 350 */     for (T element : iterable) {
/* 351 */       if (skipNulls && element == null)
/* 352 */         continue;  if (checkNulls) Objects.requireNonNull(element, "element"); 
/* 353 */       list.add(element);
/*     */     } 
/* 355 */     return list;
/*     */   }
/*     */   
/*     */   private static <T> List<T> createUnmodifiableList(boolean clone, List<T> list) {
/* 359 */     switch (list.size()) { case 0:
/* 360 */         return Collections.emptyList();
/* 361 */       case 1: return Collections.singletonList(list.get(0)); }
/*     */     
/* 363 */     if (clone) {
/* 364 */       return Collections.unmodifiableList(new ArrayList<>(list));
/*     */     }
/* 366 */     if (list instanceof ArrayList) {
/* 367 */       ((ArrayList)list).trimToSize();
/*     */     }
/* 369 */     return Collections.unmodifiableList(list);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutablePartialGuildApplicationCommandPermissionsData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */