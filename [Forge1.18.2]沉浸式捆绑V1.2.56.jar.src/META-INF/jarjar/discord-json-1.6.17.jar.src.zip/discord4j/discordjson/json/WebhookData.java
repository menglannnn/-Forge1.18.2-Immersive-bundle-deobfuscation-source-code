/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.Id;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import java.util.Optional;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ @JsonSerialize(as = ImmutableWebhookData.class)
/*    */ @JsonDeserialize(as = ImmutableWebhookData.class)
/*    */ @Immutable
/*    */ public interface WebhookData
/*    */ {
/*    */   static ImmutableWebhookData.Builder builder() {
/* 18 */     return ImmutableWebhookData.builder();
/*    */   }
/*    */   
/*    */   Id id();
/*    */   
/*    */   int type();
/*    */   
/*    */   @JsonProperty("guild_id")
/*    */   Possible<Optional<Id>> guildId();
/*    */   
/*    */   @JsonProperty("channel_id")
/*    */   Optional<Id> channelId();
/*    */   
/*    */   Possible<UserData> user();
/*    */   
/*    */   Optional<String> name();
/*    */   
/*    */   Optional<String> avatar();
/*    */   
/*    */   Possible<String> token();
/*    */   
/*    */   @JsonProperty("application_id")
/*    */   Optional<Id> applicationId();
/*    */   
/*    */   @JsonProperty("source_guild")
/*    */   Possible<WebhookPartialGuildData> sourceGuild();
/*    */   
/*    */   @JsonProperty("source_channel")
/*    */   Possible<WebhookPartialChannelData> sourceChannel();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\WebhookData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */