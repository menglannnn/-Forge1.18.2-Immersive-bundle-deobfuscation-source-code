/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.Id;
/*    */ import java.util.List;
/*    */ import java.util.Optional;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ @JsonSerialize(as = ImmutableGuildPreviewData.class)
/*    */ @JsonDeserialize(as = ImmutableGuildPreviewData.class)
/*    */ @Immutable
/*    */ public interface GuildPreviewData
/*    */ {
/*    */   static ImmutableGuildPreviewData.Builder builder() {
/* 18 */     return ImmutableGuildPreviewData.builder();
/*    */   }
/*    */   
/*    */   Id id();
/*    */   
/*    */   String name();
/*    */   
/*    */   Optional<String> icon();
/*    */   
/*    */   Optional<String> splash();
/*    */   
/*    */   @JsonProperty("discovery_splash")
/*    */   Optional<String> discoverySplash();
/*    */   
/*    */   List<EmojiData> emojis();
/*    */   
/*    */   List<String> features();
/*    */   
/*    */   @JsonProperty("approximate_member_count")
/*    */   int approximateMemberCount();
/*    */   
/*    */   @JsonProperty("approximate_presence_count")
/*    */   int approximatePresenceCount();
/*    */   
/*    */   Optional<String> description();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\GuildPreviewData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */