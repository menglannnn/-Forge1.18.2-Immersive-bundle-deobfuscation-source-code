/*     */ package io.netty.resolver;
/*     */ 
/*     */ import io.netty.util.NetUtil;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import io.netty.util.internal.PlatformDependent;
/*     */ import io.netty.util.internal.logging.InternalLogger;
/*     */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ import java.net.InetAddress;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class HostsFileEntriesProvider
/*     */ {
/*     */   public static Parser parser() {
/* 123 */     return ParserImpl.INSTANCE;
/*     */   }
/*     */   
/* 126 */   static final HostsFileEntriesProvider EMPTY = new HostsFileEntriesProvider(
/*     */       
/* 128 */       Collections.emptyMap(), 
/* 129 */       Collections.emptyMap());
/*     */   
/*     */   private final Map<String, List<InetAddress>> ipv4Entries;
/*     */   private final Map<String, List<InetAddress>> ipv6Entries;
/*     */   
/*     */   HostsFileEntriesProvider(Map<String, List<InetAddress>> ipv4Entries, Map<String, List<InetAddress>> ipv6Entries) {
/* 135 */     this.ipv4Entries = Collections.unmodifiableMap(new HashMap<String, List<InetAddress>>(ipv4Entries));
/* 136 */     this.ipv6Entries = Collections.unmodifiableMap(new HashMap<String, List<InetAddress>>(ipv6Entries));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, List<InetAddress>> ipv4Entries() {
/* 145 */     return this.ipv4Entries;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, List<InetAddress>> ipv6Entries() {
/* 154 */     return this.ipv6Entries;
/*     */   }
/*     */   
/*     */   private static final class ParserImpl
/*     */     implements Parser
/*     */   {
/*     */     private static final String WINDOWS_DEFAULT_SYSTEM_ROOT = "C:\\Windows";
/*     */     private static final String WINDOWS_HOSTS_FILE_RELATIVE_PATH = "\\system32\\drivers\\etc\\hosts";
/*     */     private static final String X_PLATFORMS_HOSTS_FILE_PATH = "/etc/hosts";
/* 163 */     private static final Pattern WHITESPACES = Pattern.compile("[ \t]+");
/*     */     
/* 165 */     private static final InternalLogger logger = InternalLoggerFactory.getInstance(HostsFileEntriesProvider.Parser.class);
/*     */     
/* 167 */     static final ParserImpl INSTANCE = new ParserImpl();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public HostsFileEntriesProvider parse() throws IOException {
/* 175 */       return parse(locateHostsFile(), new Charset[] { Charset.defaultCharset() });
/*     */     }
/*     */ 
/*     */     
/*     */     public HostsFileEntriesProvider parse(Charset... charsets) throws IOException {
/* 180 */       return parse(locateHostsFile(), charsets);
/*     */     }
/*     */ 
/*     */     
/*     */     public HostsFileEntriesProvider parse(File file, Charset... charsets) throws IOException {
/* 185 */       ObjectUtil.checkNotNull(file, "file");
/* 186 */       ObjectUtil.checkNotNull(charsets, "charsets");
/* 187 */       if (charsets.length == 0) {
/* 188 */         charsets = new Charset[] { Charset.defaultCharset() };
/*     */       }
/* 190 */       if (file.exists() && file.isFile()) {
/* 191 */         for (Charset charset : charsets) {
/* 192 */           BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(file), charset));
/*     */         }
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 204 */       return HostsFileEntriesProvider.EMPTY;
/*     */     }
/*     */ 
/*     */     
/*     */     public HostsFileEntriesProvider parse(Reader reader) throws IOException {
/* 209 */       ObjectUtil.checkNotNull(reader, "reader");
/* 210 */       BufferedReader buff = new BufferedReader(reader);
/*     */       try {
/* 212 */         Map<String, List<InetAddress>> ipv4Entries = new HashMap<String, List<InetAddress>>();
/* 213 */         Map<String, List<InetAddress>> ipv6Entries = new HashMap<String, List<InetAddress>>();
/*     */         String line;
/* 215 */         while ((line = buff.readLine()) != null) {
/*     */           
/* 217 */           int commentPosition = line.indexOf('#');
/* 218 */           if (commentPosition != -1) {
/* 219 */             line = line.substring(0, commentPosition);
/*     */           }
/*     */           
/* 222 */           line = line.trim();
/* 223 */           if (line.isEmpty()) {
/*     */             continue;
/*     */           }
/*     */ 
/*     */           
/* 228 */           List<String> lineParts = new ArrayList<String>();
/* 229 */           for (String s : WHITESPACES.split(line)) {
/* 230 */             if (!s.isEmpty()) {
/* 231 */               lineParts.add(s);
/*     */             }
/*     */           } 
/*     */ 
/*     */           
/* 236 */           if (lineParts.size() < 2) {
/*     */             continue;
/*     */           }
/*     */ 
/*     */           
/* 241 */           byte[] ipBytes = NetUtil.createByteArrayFromIpAddressString(lineParts.get(0));
/*     */           
/* 243 */           if (ipBytes == null) {
/*     */             continue;
/*     */           }
/*     */ 
/*     */ 
/*     */           
/* 249 */           for (int i = 1; i < lineParts.size(); i++) {
/* 250 */             List<InetAddress> addresses; String hostname = lineParts.get(i);
/* 251 */             String hostnameLower = hostname.toLowerCase(Locale.ENGLISH);
/* 252 */             InetAddress address = InetAddress.getByAddress(hostname, ipBytes);
/*     */             
/* 254 */             if (address instanceof java.net.Inet4Address) {
/* 255 */               addresses = ipv4Entries.get(hostnameLower);
/* 256 */               if (addresses == null) {
/* 257 */                 addresses = new ArrayList<InetAddress>();
/* 258 */                 ipv4Entries.put(hostnameLower, addresses);
/*     */               } 
/*     */             } else {
/* 261 */               addresses = ipv6Entries.get(hostnameLower);
/* 262 */               if (addresses == null) {
/* 263 */                 addresses = new ArrayList<InetAddress>();
/* 264 */                 ipv6Entries.put(hostnameLower, addresses);
/*     */               } 
/*     */             } 
/* 267 */             addresses.add(address);
/*     */           } 
/*     */         } 
/* 270 */         return (ipv4Entries.isEmpty() && ipv6Entries.isEmpty()) ? HostsFileEntriesProvider.EMPTY : new HostsFileEntriesProvider(ipv4Entries, ipv6Entries);
/*     */       } finally {
/*     */ 
/*     */         
/*     */         try {
/* 275 */           buff.close();
/* 276 */         } catch (IOException e) {
/* 277 */           logger.warn("Failed to close a reader", e);
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public HostsFileEntriesProvider parseSilently() {
/* 284 */       return parseSilently(locateHostsFile(), new Charset[] { Charset.defaultCharset() });
/*     */     }
/*     */ 
/*     */     
/*     */     public HostsFileEntriesProvider parseSilently(Charset... charsets) {
/* 289 */       return parseSilently(locateHostsFile(), charsets);
/*     */     }
/*     */ 
/*     */     
/*     */     public HostsFileEntriesProvider parseSilently(File file, Charset... charsets) {
/*     */       try {
/* 295 */         return parse(file, charsets);
/* 296 */       } catch (IOException e) {
/* 297 */         if (logger.isWarnEnabled()) {
/* 298 */           logger.warn("Failed to load and parse hosts file at " + file.getPath(), e);
/*     */         }
/* 300 */         return HostsFileEntriesProvider.EMPTY;
/*     */       } 
/*     */     }
/*     */     
/*     */     private static File locateHostsFile() {
/*     */       File hostsFile;
/* 306 */       if (PlatformDependent.isWindows()) {
/* 307 */         hostsFile = new File(System.getenv("SystemRoot") + "\\system32\\drivers\\etc\\hosts");
/* 308 */         if (!hostsFile.exists()) {
/* 309 */           hostsFile = new File("C:\\Windows\\system32\\drivers\\etc\\hosts");
/*     */         }
/*     */       } else {
/* 312 */         hostsFile = new File("/etc/hosts");
/*     */       } 
/* 314 */       return hostsFile;
/*     */     }
/*     */   }
/*     */   
/*     */   public static interface Parser {
/*     */     HostsFileEntriesProvider parse() throws IOException;
/*     */     
/*     */     HostsFileEntriesProvider parse(Charset... param1VarArgs) throws IOException;
/*     */     
/*     */     HostsFileEntriesProvider parse(File param1File, Charset... param1VarArgs) throws IOException;
/*     */     
/*     */     HostsFileEntriesProvider parse(Reader param1Reader) throws IOException;
/*     */     
/*     */     HostsFileEntriesProvider parseSilently();
/*     */     
/*     */     HostsFileEntriesProvider parseSilently(Charset... param1VarArgs);
/*     */     
/*     */     HostsFileEntriesProvider parseSilently(File param1File, Charset... param1VarArgs);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-resolver-4.1.93.Final.jar!\io\netty\resolver\HostsFileEntriesProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */