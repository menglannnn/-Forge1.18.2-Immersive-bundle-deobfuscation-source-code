/*    */ package io.netty.resolver;
/*    */ 
/*    */ import io.netty.util.concurrent.EventExecutor;
/*    */ import io.netty.util.concurrent.Promise;
/*    */ import java.net.SocketAddress;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NoopAddressResolver
/*    */   extends AbstractAddressResolver<SocketAddress>
/*    */ {
/*    */   public NoopAddressResolver(EventExecutor executor) {
/* 33 */     super(executor);
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean doIsResolved(SocketAddress address) {
/* 38 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   protected void doResolve(SocketAddress unresolvedAddress, Promise<SocketAddress> promise) throws Exception {
/* 43 */     promise.setSuccess(unresolvedAddress);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void doResolveAll(SocketAddress unresolvedAddress, Promise<List<SocketAddress>> promise) throws Exception {
/* 49 */     promise.setSuccess(Collections.singletonList(unresolvedAddress));
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-resolver-4.1.93.Final.jar!\io\netty\resolver\NoopAddressResolver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */