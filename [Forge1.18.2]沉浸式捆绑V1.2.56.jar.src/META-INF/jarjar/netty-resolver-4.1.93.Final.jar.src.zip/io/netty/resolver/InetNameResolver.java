/*    */ package io.netty.resolver;
/*    */ 
/*    */ import io.netty.util.concurrent.EventExecutor;
/*    */ import java.net.InetAddress;
/*    */ import java.net.InetSocketAddress;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class InetNameResolver
/*    */   extends SimpleNameResolver<InetAddress>
/*    */ {
/*    */   private volatile AddressResolver<InetSocketAddress> addressResolver;
/*    */   
/*    */   protected InetNameResolver(EventExecutor executor) {
/* 35 */     super(executor);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public AddressResolver<InetSocketAddress> asAddressResolver() {
/* 43 */     AddressResolver<InetSocketAddress> result = this.addressResolver;
/* 44 */     if (result == null) {
/* 45 */       synchronized (this) {
/* 46 */         result = this.addressResolver;
/* 47 */         if (result == null) {
/* 48 */           this.addressResolver = result = new InetSocketAddressResolver(executor(), this);
/*    */         }
/*    */       } 
/*    */     }
/* 52 */     return result;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-resolver-4.1.93.Final.jar!\io\netty\resolver\InetNameResolver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */