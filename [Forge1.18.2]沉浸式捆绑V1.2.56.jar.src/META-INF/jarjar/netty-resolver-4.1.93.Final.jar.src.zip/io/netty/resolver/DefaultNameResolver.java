/*    */ package io.netty.resolver;
/*    */ 
/*    */ import io.netty.util.concurrent.EventExecutor;
/*    */ import io.netty.util.concurrent.Promise;
/*    */ import io.netty.util.internal.SocketUtils;
/*    */ import java.net.InetAddress;
/*    */ import java.net.UnknownHostException;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultNameResolver
/*    */   extends InetNameResolver
/*    */ {
/*    */   public DefaultNameResolver(EventExecutor executor) {
/* 35 */     super(executor);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void doResolve(String inetHost, Promise<InetAddress> promise) throws Exception {
/*    */     try {
/* 41 */       promise.setSuccess(SocketUtils.addressByName(inetHost));
/* 42 */     } catch (UnknownHostException e) {
/* 43 */       promise.setFailure(e);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   protected void doResolveAll(String inetHost, Promise<List<InetAddress>> promise) throws Exception {
/*    */     try {
/* 50 */       promise.setSuccess(Arrays.asList(SocketUtils.allAddressesByName(inetHost)));
/* 51 */     } catch (UnknownHostException e) {
/* 52 */       promise.setFailure(e);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-resolver-4.1.93.Final.jar!\io\netty\resolver\DefaultNameResolver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */