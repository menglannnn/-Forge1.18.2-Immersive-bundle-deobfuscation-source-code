package reactor.netty.http;

import java.net.SocketAddress;
import reactor.netty.channel.ChannelMetricsRecorder;

public interface HttpMetricsRecorder extends ChannelMetricsRecorder {
  void recordDataReceived(SocketAddress paramSocketAddress, String paramString, long paramLong);
  
  void recordDataSent(SocketAddress paramSocketAddress, String paramString, long paramLong);
  
  void incrementErrorsCount(SocketAddress paramSocketAddress, String paramString);
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\HttpMetricsRecorder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */