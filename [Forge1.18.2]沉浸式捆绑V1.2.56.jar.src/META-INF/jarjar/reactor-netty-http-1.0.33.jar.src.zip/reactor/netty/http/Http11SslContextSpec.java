/*     */ package reactor.netty.http;
/*     */ 
/*     */ import io.netty.handler.ssl.CipherSuiteFilter;
/*     */ import io.netty.handler.ssl.IdentityCipherSuiteFilter;
/*     */ import io.netty.handler.ssl.OpenSsl;
/*     */ import io.netty.handler.ssl.SslContextBuilder;
/*     */ import io.netty.handler.ssl.SslProvider;
/*     */ import java.io.File;
/*     */ import java.io.InputStream;
/*     */ import java.security.PrivateKey;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.function.Consumer;
/*     */ import javax.net.ssl.KeyManager;
/*     */ import javax.net.ssl.KeyManagerFactory;
/*     */ import reactor.netty.tcp.AbstractProtocolSslContextSpec;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Http11SslContextSpec
/*     */   extends AbstractProtocolSslContextSpec<Http11SslContextSpec>
/*     */ {
/*     */   static final Consumer<SslContextBuilder> DEFAULT_CONFIGURATOR;
/*     */   
/*     */   public static Http11SslContextSpec forClient() {
/*  55 */     return new Http11SslContextSpec(SslContextBuilder.forClient());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Http11SslContextSpec forServer(File keyCertChainFile, File keyFile) {
/*  64 */     return new Http11SslContextSpec(SslContextBuilder.forServer(keyCertChainFile, keyFile));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Http11SslContextSpec forServer(File keyCertChainFile, File keyFile, String keyPassword) {
/*  73 */     return new Http11SslContextSpec(SslContextBuilder.forServer(keyCertChainFile, keyFile, keyPassword));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Http11SslContextSpec forServer(InputStream keyCertChainInputStream, InputStream keyInputStream) {
/*  82 */     return new Http11SslContextSpec(SslContextBuilder.forServer(keyCertChainInputStream, keyInputStream));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Http11SslContextSpec forServer(InputStream keyCertChainInputStream, InputStream keyInputStream, String keyPassword) {
/*  92 */     return new Http11SslContextSpec(SslContextBuilder.forServer(keyCertChainInputStream, keyInputStream, keyPassword));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Http11SslContextSpec forServer(KeyManager keyManager) {
/* 101 */     return new Http11SslContextSpec(SslContextBuilder.forServer(keyManager));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Http11SslContextSpec forServer(KeyManagerFactory keyManagerFactory) {
/* 110 */     return new Http11SslContextSpec(SslContextBuilder.forServer(keyManagerFactory));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Http11SslContextSpec forServer(PrivateKey key, Iterable<? extends X509Certificate> keyCertChain) {
/* 119 */     return new Http11SslContextSpec(SslContextBuilder.forServer(key, keyCertChain));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Http11SslContextSpec forServer(PrivateKey key, String keyPassword, Iterable<? extends X509Certificate> keyCertChain) {
/* 129 */     return new Http11SslContextSpec(SslContextBuilder.forServer(key, keyPassword, keyCertChain));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Http11SslContextSpec forServer(PrivateKey key, String keyPassword, X509Certificate... keyCertChain) {
/* 138 */     return new Http11SslContextSpec(SslContextBuilder.forServer(key, keyPassword, keyCertChain));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Http11SslContextSpec forServer(PrivateKey key, X509Certificate... keyCertChain) {
/* 147 */     return new Http11SslContextSpec(SslContextBuilder.forServer(key, keyCertChain));
/*     */   }
/*     */   
/*     */   Http11SslContextSpec(SslContextBuilder sslContextBuilder) {
/* 151 */     super(sslContextBuilder);
/*     */   }
/*     */ 
/*     */   
/*     */   public Http11SslContextSpec get() {
/* 156 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Consumer<SslContextBuilder> defaultConfiguration() {
/* 161 */     return DEFAULT_CONFIGURATOR;
/*     */   }
/*     */   static {
/* 164 */     DEFAULT_CONFIGURATOR = (sslCtxBuilder -> sslCtxBuilder.sslProvider(OpenSsl.isAvailable() ? SslProvider.OPENSSL : SslProvider.JDK).ciphers(null, (CipherSuiteFilter)IdentityCipherSuiteFilter.INSTANCE).applicationProtocolConfig(null));
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\Http11SslContextSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */