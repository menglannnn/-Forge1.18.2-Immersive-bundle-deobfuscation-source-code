/*     */ package reactor.netty.http;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.buffer.ByteBufAllocator;
/*     */ import io.netty.buffer.ByteBufHolder;
/*     */ import io.netty.buffer.Unpooled;
/*     */ import io.netty.channel.ChannelFuture;
/*     */ import io.netty.channel.ChannelHandler;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.channel.ChannelInboundHandler;
/*     */ import io.netty.handler.codec.http.HttpHeaderNames;
/*     */ import io.netty.handler.codec.http.HttpMessage;
/*     */ import io.netty.handler.codec.http.HttpUtil;
/*     */ import io.netty.handler.codec.http.LastHttpContent;
/*     */ import io.netty.util.ReferenceCountUtil;
/*     */ import io.netty.util.ReferenceCounted;
/*     */ import io.netty.util.concurrent.Future;
/*     */ import java.net.URI;
/*     */ import java.nio.file.Path;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Predicate;
/*     */ import java.util.regex.Pattern;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.netty.Connection;
/*     */ import reactor.netty.ConnectionObserver;
/*     */ import reactor.netty.FutureMono;
/*     */ import reactor.netty.NettyInbound;
/*     */ import reactor.netty.NettyOutbound;
/*     */ import reactor.netty.NettyPipeline;
/*     */ import reactor.netty.ReactorNetty;
/*     */ import reactor.netty.channel.AbortedException;
/*     */ import reactor.netty.channel.ChannelOperations;
/*     */ import reactor.netty.http.logging.HttpMessageArgProviderFactory;
/*     */ import reactor.netty.http.logging.HttpMessageLogFactory;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.Loggers;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class HttpOperations<INBOUND extends NettyInbound, OUTBOUND extends NettyOutbound>
/*     */   extends ChannelOperations<INBOUND, OUTBOUND>
/*     */   implements HttpInfos
/*     */ {
/*     */   volatile int statusAndHeadersSent;
/*     */   static final int READY = 0;
/*     */   static final int HEADERS_SENT = 1;
/*     */   static final int BODY_SENT = 2;
/*     */   final HttpMessageLogFactory httpMessageLogFactory;
/*     */   
/*     */   protected HttpOperations(HttpOperations<INBOUND, OUTBOUND> replaced) {
/*  82 */     super(replaced);
/*  83 */     this.httpMessageLogFactory = replaced.httpMessageLogFactory;
/*  84 */     this.statusAndHeadersSent = replaced.statusAndHeadersSent;
/*     */   }
/*     */   
/*     */   protected HttpOperations(Connection connection, ConnectionObserver listener, HttpMessageLogFactory httpMessageLogFactory) {
/*  88 */     super(connection, listener);
/*  89 */     this.httpMessageLogFactory = httpMessageLogFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean hasSentHeaders() {
/*  98 */     return (this.statusAndHeadersSent != 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isWebsocket() {
/* 103 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public String requestId() {
/* 108 */     return asShortText();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public NettyOutbound send(Publisher<? extends ByteBuf> source) {
/* 114 */     if (!channel().isActive()) {
/* 115 */       return then((Publisher)Mono.error((Throwable)AbortedException.beforeSend()));
/*     */     }
/* 117 */     if (source instanceof Mono) {
/* 118 */       return new PostHeadersNettyOutbound(((Mono)source)
/* 119 */           .flatMap(b -> {
/*     */               if (markSentHeaderAndBody(new Object[] { b }, )) {
/*     */                 HttpMessage msg = prepareHttpMessage(b);
/*     */ 
/*     */                 
/*     */                 try {
/*     */                   afterMarkSentHeaders();
/* 126 */                 } catch (RuntimeException e) {
/*     */                   ReferenceCountUtil.release(b);
/*     */                   
/*     */                   return Mono.error(e);
/*     */                 } 
/*     */                 
/*     */                 return FutureMono.from((Future)channel().writeAndFlush(msg));
/*     */               } 
/*     */               return FutureMono.from((Future)channel().writeAndFlush(b));
/* 135 */             }).doOnDiscard(ByteBuf.class, ReferenceCounted::release), this, null);
/*     */     }
/* 137 */     return super.send(source);
/*     */   }
/*     */ 
/*     */   
/*     */   public NettyOutbound sendObject(Object message) {
/* 142 */     if (!channel().isActive()) {
/* 143 */       ReactorNetty.safeRelease(message);
/* 144 */       return then((Publisher)Mono.error((Throwable)AbortedException.beforeSend()));
/*     */     } 
/* 146 */     if (!(message instanceof ByteBuf)) {
/* 147 */       return super.sendObject(message);
/*     */     }
/* 149 */     ByteBuf b = (ByteBuf)message;
/* 150 */     return new PostHeadersNettyOutbound(FutureMono.deferFuture(() -> {
/*     */             if (markSentHeaderAndBody(new Object[] { b }, )) {
/*     */               HttpMessage msg = prepareHttpMessage(b);
/*     */ 
/*     */               
/*     */               try {
/*     */                 afterMarkSentHeaders();
/* 157 */               } catch (RuntimeException e) {
/*     */                 b.release();
/*     */                 throw e;
/*     */               } 
/*     */               return channel().writeAndFlush(msg);
/*     */             } 
/*     */             return channel().writeAndFlush(b);
/*     */           }), this, b);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> then() {
/* 170 */     if (!channel().isActive()) {
/* 171 */       return Mono.error((Throwable)AbortedException.beforeSend());
/*     */     }
/*     */     
/* 174 */     if (hasSentHeaders()) {
/* 175 */       return Mono.empty();
/*     */     }
/*     */     
/* 178 */     return FutureMono.deferFuture(() -> {
/*     */           if (markSentHeaders(new Object[] { outboundHttpMessage() })) {
/*     */             HttpMessage msg;
/*     */ 
/*     */             
/*     */             if (HttpUtil.isContentLengthSet(outboundHttpMessage())) {
/*     */               outboundHttpMessage().headers().remove((CharSequence)HttpHeaderNames.TRANSFER_ENCODING);
/*     */ 
/*     */               
/*     */               if (HttpUtil.getContentLength(outboundHttpMessage(), 0) == 0) {
/*     */                 markSentBody();
/*     */                 
/*     */                 msg = newFullBodyMessage(Unpooled.EMPTY_BUFFER);
/*     */               } else {
/*     */                 msg = outboundHttpMessage();
/*     */               } 
/*     */             } else if (isContentAlwaysEmpty()) {
/*     */               markSentBody();
/*     */               
/*     */               msg = newFullBodyMessage(Unpooled.EMPTY_BUFFER);
/*     */             } else {
/*     */               msg = outboundHttpMessage();
/*     */             } 
/*     */             
/*     */             try {
/*     */               afterMarkSentHeaders();
/* 204 */             } catch (RuntimeException e) {
/*     */               ReferenceCountUtil.release(msg);
/*     */               throw e;
/*     */             } 
/*     */             return channel().writeAndFlush(msg).addListener(());
/*     */           } 
/*     */           return channel().newSucceededFuture();
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String asDebugLogMessage(Object o) {
/* 220 */     return (o instanceof io.netty.handler.codec.http.HttpObject) ? 
/* 221 */       this.httpMessageLogFactory.debug(HttpMessageArgProviderFactory.create(o)) : 
/* 222 */       o.toString();
/*     */   }
/*     */   
/*     */   protected HttpMessageLogFactory httpMessageLogFactory() {
/* 226 */     return this.httpMessageLogFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final NettyOutbound sendFile(Path file, long position, long count) {
/* 241 */     Objects.requireNonNull(file);
/*     */     
/* 243 */     if (hasSentHeaders()) {
/* 244 */       return super.sendFile(file, position, count);
/*     */     }
/*     */     
/* 247 */     if (!HttpUtil.isTransferEncodingChunked(outboundHttpMessage()) && !HttpUtil.isContentLengthSet(
/* 248 */         outboundHttpMessage()) && count < 2147483647L) {
/* 249 */       outboundHttpMessage().headers()
/* 250 */         .setInt((CharSequence)HttpHeaderNames.CONTENT_LENGTH, (int)count);
/*     */     }
/* 252 */     else if (!HttpUtil.isContentLengthSet(outboundHttpMessage())) {
/* 253 */       outboundHttpMessage().headers()
/* 254 */         .remove((CharSequence)HttpHeaderNames.CONTENT_LENGTH)
/* 255 */         .remove((CharSequence)HttpHeaderNames.TRANSFER_ENCODING);
/* 256 */       HttpUtil.setTransferEncodingChunked(outboundHttpMessage(), true);
/*     */     } 
/*     */     
/* 259 */     return super.sendFile(file, position, count);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 264 */     if (isWebsocket()) {
/* 265 */       return "ws{uri=" + fullPath() + ", connection=" + connection() + "}";
/*     */     }
/*     */     
/* 268 */     return method().name() + "{uri=" + fullPath() + ", connection=" + connection() + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpOperations<INBOUND, OUTBOUND> addHandler(String name, ChannelHandler handler) {
/* 274 */     super.addHandler(name, handler);
/*     */     
/* 276 */     if (channel().pipeline().context(handler) == null) {
/* 277 */       return this;
/*     */     }
/*     */     
/* 280 */     autoAddHttpExtractor((Connection)this, name, handler);
/* 281 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   static void autoAddHttpExtractor(Connection c, String name, ChannelHandler handler) {
/* 286 */     if (handler instanceof io.netty.handler.codec.ByteToMessageDecoder || handler instanceof io.netty.handler.codec.ByteToMessageCodec || handler instanceof io.netty.channel.CombinedChannelDuplexHandler) {
/*     */ 
/*     */       
/* 289 */       String extractorName = name + "$extractor";
/*     */       
/* 291 */       if (c.channel().pipeline().context(extractorName) != null) {
/*     */         return;
/*     */       }
/*     */       
/* 295 */       c.channel().pipeline().addBefore(name, extractorName, (ChannelHandler)HTTP_EXTRACTOR);
/*     */       
/* 297 */       if (c.isPersistent()) {
/* 298 */         c.onTerminate().subscribe(null, null, () -> c.removeHandler(extractorName));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final boolean markSentHeaders(Object... objectsToRelease) {
/*     */     try {
/* 311 */       if (!hasSentHeaders()) {
/* 312 */         beforeMarkSentHeaders();
/*     */       }
/*     */     }
/* 315 */     catch (RuntimeException e) {
/* 316 */       for (Object o : objectsToRelease) {
/*     */         try {
/* 318 */           ReferenceCountUtil.release(o);
/*     */         }
/* 320 */         catch (Throwable throwable) {}
/*     */       } 
/*     */ 
/*     */       
/* 324 */       throw e;
/*     */     } 
/* 326 */     return HTTP_STATE.compareAndSet(this, 0, 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final boolean markSentBody() {
/* 335 */     return HTTP_STATE.compareAndSet(this, 1, 2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final boolean markSentHeaderAndBody(Object... objectsToRelease) {
/*     */     try {
/* 345 */       if (!hasSentHeaders()) {
/* 346 */         beforeMarkSentHeaders();
/*     */       }
/*     */     }
/* 349 */     catch (RuntimeException e) {
/* 350 */       for (Object o : objectsToRelease) {
/*     */         try {
/* 352 */           ReferenceCountUtil.release(o);
/*     */         }
/* 354 */         catch (Throwable throwable) {}
/*     */       } 
/*     */ 
/*     */       
/* 358 */       throw e;
/*     */     } 
/* 360 */     return HTTP_STATE.compareAndSet(this, 0, 2);
/*     */   }
/*     */ 
/*     */   
/*     */   protected final String initShortId() {
/* 365 */     if (connection() instanceof AtomicLong) {
/* 366 */       return channel().id().asShortText() + '-' + ((AtomicLong)connection()).incrementAndGet();
/*     */     }
/* 368 */     return super.initShortId();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String resolvePath(String uri) {
/* 378 */     Objects.requireNonNull(uri, "uri");
/*     */     
/* 380 */     String tempUri = uri;
/*     */     
/* 382 */     int index = tempUri.indexOf('?');
/* 383 */     if (index > -1) {
/* 384 */       tempUri = tempUri.substring(0, index);
/*     */     }
/*     */     
/* 387 */     index = tempUri.indexOf('#');
/* 388 */     if (index > -1) {
/* 389 */       tempUri = tempUri.substring(0, index);
/*     */     }
/*     */     
/* 392 */     if (tempUri.isEmpty()) {
/* 393 */       return tempUri;
/*     */     }
/*     */     
/* 396 */     if (tempUri.charAt(0) == '/') {
/* 397 */       if (tempUri.length() == 1) {
/* 398 */         return tempUri;
/*     */       }
/* 400 */       tempUri = "http://localhost:8080" + tempUri;
/*     */     }
/* 402 */     else if (!SCHEME_PATTERN.matcher(tempUri).matches()) {
/* 403 */       tempUri = "http://" + tempUri;
/*     */     } 
/*     */     
/* 406 */     return URI.create(tempUri)
/* 407 */       .getPath();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   HttpMessage prepareHttpMessage(ByteBuf buffer) {
/*     */     HttpMessage msg;
/* 419 */     if (HttpUtil.getContentLength(outboundHttpMessage(), -1) == 0 || 
/* 420 */       isContentAlwaysEmpty()) {
/* 421 */       if (log.isDebugEnabled()) {
/* 422 */         log.debug(ReactorNetty.format(channel(), "Dropped HTTP content, since response has 1. [Content-Length: 0] or 2. there must be no content: {}"), new Object[] { buffer });
/*     */       }
/*     */       
/* 425 */       buffer.release();
/* 426 */       msg = newFullBodyMessage(Unpooled.EMPTY_BUFFER);
/*     */     } else {
/*     */       
/* 429 */       msg = newFullBodyMessage(buffer);
/*     */     } 
/*     */     
/* 432 */     return msg;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 437 */   static final AtomicIntegerFieldUpdater<HttpOperations> HTTP_STATE = AtomicIntegerFieldUpdater.newUpdater(HttpOperations.class, "statusAndHeadersSent"); static final ChannelInboundHandler HTTP_EXTRACTOR;
/*     */   
/*     */   static {
/* 440 */     HTTP_EXTRACTOR = NettyPipeline.inboundHandler((ctx, msg) -> {
/*     */           if (msg instanceof ByteBufHolder) {
/*     */             if (msg instanceof io.netty.handler.codec.http.FullHttpMessage) {
/*     */               ctx.fireChannelRead(msg);
/*     */             } else {
/*     */               ByteBuf bb = ((ByteBufHolder)msg).content();
/*     */               ctx.fireChannelRead(bb);
/*     */               if (msg instanceof LastHttpContent) {
/*     */                 ctx.fireChannelRead(LastHttpContent.EMPTY_LAST_CONTENT);
/*     */               }
/*     */             } 
/*     */           } else {
/*     */             ctx.fireChannelRead(msg);
/*     */           } 
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 461 */   static final Logger log = Loggers.getLogger(HttpOperations.class);
/*     */   
/* 463 */   static final Pattern SCHEME_PATTERN = Pattern.compile("^(https?|wss?)://.*$");
/*     */   protected abstract void beforeMarkSentHeaders();
/*     */   protected abstract void afterMarkSentHeaders();
/*     */   protected abstract boolean isContentAlwaysEmpty();
/*     */   protected abstract void onHeadersSent();
/*     */   protected abstract HttpMessage newFullBodyMessage(ByteBuf paramByteBuf);
/*     */   protected abstract HttpMessage outboundHttpMessage();
/*     */   protected static final class PostHeadersNettyOutbound implements NettyOutbound, Consumer<Throwable>, Runnable { final Mono<Void> source;
/*     */     public PostHeadersNettyOutbound(Mono<Void> source, HttpOperations<?, ?> parent, @Nullable ByteBuf msg) {
/* 472 */       this.msg = msg;
/* 473 */       if (msg != null) {
/* 474 */         this
/* 475 */           .source = source.doOnError(this).doOnCancel(this);
/*     */       } else {
/*     */         
/* 478 */         this.source = source;
/*     */       } 
/* 480 */       this.parent = parent;
/*     */     }
/*     */     final HttpOperations<?, ?> parent; final ByteBuf msg;
/*     */     
/*     */     public void run() {
/* 485 */       if (this.msg != null && this.msg.refCnt() > 0) {
/* 486 */         this.msg.release();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void accept(Throwable throwable) {
/* 492 */       if (this.msg != null && this.msg.refCnt() > 0) {
/* 493 */         this.msg.release();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public Mono<Void> then() {
/* 499 */       return this.source;
/*     */     }
/*     */ 
/*     */     
/*     */     public ByteBufAllocator alloc() {
/* 504 */       return this.parent.alloc();
/*     */     }
/*     */ 
/*     */     
/*     */     public NettyOutbound send(Publisher<? extends ByteBuf> dataStream, Predicate<ByteBuf> predicate) {
/* 509 */       return this.parent.send(dataStream, predicate);
/*     */     }
/*     */ 
/*     */     
/*     */     public NettyOutbound sendObject(Publisher<?> dataStream, Predicate<Object> predicate) {
/* 514 */       return this.parent.sendObject(dataStream, predicate);
/*     */     }
/*     */ 
/*     */     
/*     */     public NettyOutbound sendObject(Object message) {
/* 519 */       return this.parent.sendObject(message);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public <S> NettyOutbound sendUsing(Callable<? extends S> sourceInput, BiFunction<? super Connection, ? super S, ?> mappedInput, Consumer<? super S> sourceCleanup) {
/* 526 */       return this.parent.sendUsing(sourceInput, mappedInput, sourceCleanup);
/*     */     }
/*     */ 
/*     */     
/*     */     public NettyOutbound withConnection(Consumer<? super Connection> withConnection) {
/* 531 */       return (NettyOutbound)this.parent.withConnection(withConnection);
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\HttpOperations.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */