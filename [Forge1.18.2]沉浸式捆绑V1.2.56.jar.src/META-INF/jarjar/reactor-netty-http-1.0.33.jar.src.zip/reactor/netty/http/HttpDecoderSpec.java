/*     */ package reactor.netty.http;
/*     */ 
/*     */ import java.util.function.Supplier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class HttpDecoderSpec<T extends HttpDecoderSpec<T>>
/*     */   implements Supplier<T>
/*     */ {
/*     */   public static final int DEFAULT_MAX_INITIAL_LINE_LENGTH = 4096;
/*     */   public static final int DEFAULT_MAX_HEADER_SIZE = 8192;
/*     */   public static final int DEFAULT_MAX_CHUNK_SIZE = 8192;
/*     */   public static final boolean DEFAULT_VALIDATE_HEADERS = true;
/*     */   public static final int DEFAULT_INITIAL_BUFFER_SIZE = 128;
/*     */   public static final boolean DEFAULT_ALLOW_DUPLICATE_CONTENT_LENGTHS = false;
/*  35 */   protected int maxInitialLineLength = 4096;
/*  36 */   protected int maxHeaderSize = 8192;
/*  37 */   protected int maxChunkSize = 8192;
/*     */   protected boolean validateHeaders = true;
/*  39 */   protected int initialBufferSize = 128;
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean allowDuplicateContentLengths = false;
/*     */ 
/*     */   
/*     */   protected int h2cMaxContentLength;
/*     */ 
/*     */ 
/*     */   
/*     */   public T maxInitialLineLength(int value) {
/*  51 */     if (value <= 0) {
/*  52 */       throw new IllegalArgumentException("maxInitialLineLength must be strictly positive");
/*     */     }
/*  54 */     this.maxInitialLineLength = value;
/*  55 */     return get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int maxInitialLineLength() {
/*  64 */     return this.maxInitialLineLength;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T maxHeaderSize(int value) {
/*  75 */     if (value <= 0) {
/*  76 */       throw new IllegalArgumentException("maxHeaderSize must be strictly positive");
/*     */     }
/*  78 */     this.maxHeaderSize = value;
/*  79 */     return get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int maxHeaderSize() {
/*  88 */     return this.maxHeaderSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T maxChunkSize(int value) {
/*  99 */     if (value <= 0) {
/* 100 */       throw new IllegalArgumentException("maxChunkSize must be strictly positive");
/*     */     }
/* 102 */     this.maxChunkSize = value;
/* 103 */     return get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int maxChunkSize() {
/* 112 */     return this.maxChunkSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T validateHeaders(boolean validate) {
/* 123 */     this.validateHeaders = validate;
/* 124 */     return get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean validateHeaders() {
/* 133 */     return this.validateHeaders;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T initialBufferSize(int value) {
/* 144 */     if (value <= 0) {
/* 145 */       throw new IllegalArgumentException("initialBufferSize must be strictly positive");
/*     */     }
/* 147 */     this.initialBufferSize = value;
/* 148 */     return get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int initialBufferSize() {
/* 157 */     return this.initialBufferSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T allowDuplicateContentLengths(boolean allow) {
/* 173 */     this.allowDuplicateContentLengths = allow;
/* 174 */     return get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean allowDuplicateContentLengths() {
/* 184 */     return this.allowDuplicateContentLengths;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T h2cMaxContentLength(int h2cMaxContentLength) {
/* 202 */     if (h2cMaxContentLength < 0) {
/* 203 */       throw new IllegalArgumentException("h2cMaxContentLength must be non negative");
/*     */     }
/* 205 */     this.h2cMaxContentLength = h2cMaxContentLength;
/* 206 */     return get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int h2cMaxContentLength() {
/* 215 */     return this.h2cMaxContentLength;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 220 */     if (this == o) {
/* 221 */       return true;
/*     */     }
/* 223 */     if (!(o instanceof HttpDecoderSpec)) {
/* 224 */       return false;
/*     */     }
/* 226 */     HttpDecoderSpec<?> that = (HttpDecoderSpec)o;
/* 227 */     return (this.maxInitialLineLength == that.maxInitialLineLength && this.maxHeaderSize == that.maxHeaderSize && this.maxChunkSize == that.maxChunkSize && this.validateHeaders == that.validateHeaders && this.initialBufferSize == that.initialBufferSize && this.allowDuplicateContentLengths == that.allowDuplicateContentLengths && this.h2cMaxContentLength == that.h2cMaxContentLength);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 238 */     int result = 1;
/* 239 */     result = 31 * result + this.maxInitialLineLength;
/* 240 */     result = 31 * result + this.maxHeaderSize;
/* 241 */     result = 31 * result + this.maxChunkSize;
/* 242 */     result = 31 * result + Boolean.hashCode(this.validateHeaders);
/* 243 */     result = 31 * result + this.initialBufferSize;
/* 244 */     result = 31 * result + Boolean.hashCode(this.allowDuplicateContentLengths);
/* 245 */     result = 31 * result + this.h2cMaxContentLength;
/* 246 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\HttpDecoderSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */