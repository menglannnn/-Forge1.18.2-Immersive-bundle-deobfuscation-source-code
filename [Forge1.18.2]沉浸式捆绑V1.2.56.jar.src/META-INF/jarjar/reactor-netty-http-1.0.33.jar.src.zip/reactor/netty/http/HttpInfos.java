/*     */ package reactor.netty.http;
/*     */ 
/*     */ import io.netty.handler.codec.http.HttpMethod;
/*     */ import io.netty.handler.codec.http.HttpVersion;
/*     */ import io.netty.handler.codec.http.cookie.Cookie;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface HttpInfos
/*     */ {
/*     */   Map<CharSequence, Set<Cookie>> cookies();
/*     */   
/*     */   String fullPath();
/*     */   
/*     */   String requestId();
/*     */   
/*     */   boolean isKeepAlive();
/*     */   
/*     */   boolean isWebsocket();
/*     */   
/*     */   HttpMethod method();
/*     */   
/*     */   default String path() {
/*  98 */     String path = fullPath();
/*  99 */     if (!path.isEmpty()) {
/* 100 */       if (path.charAt(0) == '/') {
/* 101 */         path = path.substring(1);
/* 102 */         if (path.isEmpty()) {
/* 103 */           return path;
/*     */         }
/*     */       } 
/* 106 */       if (path.charAt(path.length() - 1) == '/') {
/* 107 */         return path.substring(0, path.length() - 1);
/*     */       }
/*     */     } 
/* 110 */     return path;
/*     */   }
/*     */   
/*     */   String uri();
/*     */   
/*     */   HttpVersion version();
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\HttpInfos.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */