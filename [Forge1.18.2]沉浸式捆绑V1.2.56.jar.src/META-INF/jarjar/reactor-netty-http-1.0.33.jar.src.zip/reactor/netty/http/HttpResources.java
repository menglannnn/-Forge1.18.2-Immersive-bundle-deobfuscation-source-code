/*     */ package reactor.netty.http;
/*     */ 
/*     */ import io.netty.resolver.AddressResolverGroup;
/*     */ import java.net.SocketAddress;
/*     */ import java.time.Duration;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.Function;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.netty.resources.ConnectionProvider;
/*     */ import reactor.netty.resources.LoopResources;
/*     */ import reactor.netty.tcp.TcpResources;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class HttpResources
/*     */   extends TcpResources
/*     */ {
/*     */   final AtomicReference<ConnectionProvider> http2ConnectionProvider;
/*     */   
/*     */   public static void disposeLoopsAndConnections() {
/*  49 */     HttpResources resources = httpResources.getAndSet(null);
/*  50 */     if (resources != null) {
/*  51 */       ConnectionProvider provider = resources.http2ConnectionProvider.get();
/*  52 */       if (provider != null) {
/*  53 */         provider.dispose();
/*     */       }
/*  55 */       resources._dispose();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Mono<Void> disposeLoopsAndConnectionsLater() {
/*  68 */     return disposeLoopsAndConnectionsLater(Duration.ofSeconds(LoopResources.DEFAULT_SHUTDOWN_QUIET_PERIOD), 
/*  69 */         Duration.ofSeconds(LoopResources.DEFAULT_SHUTDOWN_TIMEOUT));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Mono<Void> disposeLoopsAndConnectionsLater(Duration quietPeriod, Duration timeout) {
/*  87 */     Objects.requireNonNull(quietPeriod, "quietPeriod");
/*  88 */     Objects.requireNonNull(timeout, "timeout");
/*  89 */     return Mono.defer(() -> {
/*     */           HttpResources resources = httpResources.getAndSet(null);
/*     */           if (resources != null) {
/*     */             ConnectionProvider provider = resources.http2ConnectionProvider.get();
/*     */             Mono<Void> disposeProvider = Mono.empty();
/*     */             if (provider != null) {
/*     */               disposeProvider = provider.disposeLater();
/*     */             }
/*     */             return Mono.when(new Publisher[] { (Publisher)disposeProvider, (Publisher)resources._disposeLater(quietPeriod, timeout) });
/*     */           } 
/*     */           return Mono.empty();
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static HttpResources get() {
/* 109 */     return (HttpResources)getOrCreate(httpResources, null, null, ON_HTTP_NEW, "http");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static HttpResources reset() {
/* 118 */     disposeLoopsAndConnections();
/* 119 */     return (HttpResources)getOrCreate(httpResources, null, null, ON_HTTP_NEW, "http");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static HttpResources set(ConnectionProvider provider) {
/* 130 */     return (HttpResources)getOrCreate(httpResources, null, provider, ON_HTTP_NEW, "http");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static HttpResources set(LoopResources loops) {
/* 141 */     return (HttpResources)getOrCreate(httpResources, loops, null, ON_HTTP_NEW, "http");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   HttpResources(LoopResources loops, ConnectionProvider provider) {
/* 147 */     super(loops, provider);
/* 148 */     this.http2ConnectionProvider = new AtomicReference<>();
/*     */   }
/*     */ 
/*     */   
/*     */   public void disposeWhen(SocketAddress remoteAddress) {
/* 153 */     ConnectionProvider provider = this.http2ConnectionProvider.get();
/* 154 */     if (provider != null) {
/* 155 */       provider.disposeWhen(remoteAddress);
/*     */     }
/* 157 */     super.disposeWhen(remoteAddress);
/*     */   }
/*     */ 
/*     */   
/*     */   public AddressResolverGroup<?> getOrCreateDefaultResolver() {
/* 162 */     return super.getOrCreateDefaultResolver();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConnectionProvider getOrCreateHttp2ConnectionProvider(Function<ConnectionProvider, ConnectionProvider> create) {
/* 175 */     ConnectionProvider provider = this.http2ConnectionProvider.get();
/* 176 */     if (provider == null) {
/* 177 */       ConnectionProvider newProvider = create.apply(this);
/* 178 */       if (!this.http2ConnectionProvider.compareAndSet(null, newProvider)) {
/* 179 */         newProvider.dispose();
/*     */       }
/* 181 */       provider = getOrCreateHttp2ConnectionProvider(create);
/*     */     } 
/* 183 */     return provider;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 191 */   static final BiFunction<LoopResources, ConnectionProvider, HttpResources> ON_HTTP_NEW = HttpResources::new;
/* 192 */   static final AtomicReference<HttpResources> httpResources = new AtomicReference<>();
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\HttpResources.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */