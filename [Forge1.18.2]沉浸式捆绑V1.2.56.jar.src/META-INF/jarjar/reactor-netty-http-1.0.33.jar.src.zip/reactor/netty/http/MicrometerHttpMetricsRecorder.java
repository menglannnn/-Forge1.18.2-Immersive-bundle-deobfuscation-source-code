/*     */ package reactor.netty.http;
/*     */ 
/*     */ import io.micrometer.core.instrument.Counter;
/*     */ import io.micrometer.core.instrument.DistributionSummary;
/*     */ import io.micrometer.core.instrument.Meter;
/*     */ import io.micrometer.core.instrument.Timer;
/*     */ import java.net.SocketAddress;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import reactor.netty.Metrics;
/*     */ import reactor.netty.channel.MeterKey;
/*     */ import reactor.netty.channel.MicrometerChannelMetricsRecorder;
/*     */ import reactor.netty.internal.util.MapUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MicrometerHttpMetricsRecorder
/*     */   extends MicrometerChannelMetricsRecorder
/*     */   implements HttpMetricsRecorder
/*     */ {
/*     */   protected static final String DATA_RECEIVED_TIME_DESCRIPTION = "Time spent in consuming incoming data";
/*     */   protected static final String DATA_SENT_TIME_DESCRIPTION = "Time spent in sending outgoing data";
/*     */   protected static final String RESPONSE_TIME_DESCRIPTION = "Total time for the request/response";
/*  48 */   protected final ConcurrentMap<MeterKey, Timer> dataReceivedTimeCache = new ConcurrentHashMap<>();
/*     */   
/*  50 */   protected final ConcurrentMap<MeterKey, Timer> dataSentTimeCache = new ConcurrentHashMap<>();
/*     */   
/*  52 */   protected final ConcurrentMap<MeterKey, Timer> responseTimeCache = new ConcurrentHashMap<>();
/*     */   
/*  54 */   private final ConcurrentMap<MeterKey, DistributionSummary> dataReceivedCache = new ConcurrentHashMap<>();
/*     */   
/*  56 */   private final ConcurrentMap<MeterKey, DistributionSummary> dataSentCache = new ConcurrentHashMap<>();
/*     */   
/*  58 */   private final ConcurrentMap<MeterKey, Counter> errorsCache = new ConcurrentHashMap<>();
/*     */   
/*     */   protected MicrometerHttpMetricsRecorder(String name, String protocol) {
/*  61 */     super(name, protocol);
/*     */   }
/*     */ 
/*     */   
/*     */   public void recordDataReceived(SocketAddress remoteAddress, String uri, long bytes) {
/*  66 */     String address = Metrics.formatSocketAddress(remoteAddress);
/*  67 */     MeterKey meterKey = new MeterKey(uri, address, null, null);
/*  68 */     DistributionSummary dataReceived = (DistributionSummary)MapUtils.computeIfAbsent(this.dataReceivedCache, meterKey, key -> (DistributionSummary)filter((Meter)DistributionSummary.builder(name() + ".data.received").baseUnit("bytes").description("Amount of the data received, in bytes").tags(new String[] { "remote.address", address, "uri", uri }).register(Metrics.REGISTRY)));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  74 */     if (dataReceived != null) {
/*  75 */       dataReceived.record(bytes);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void recordDataSent(SocketAddress remoteAddress, String uri, long bytes) {
/*  81 */     String address = Metrics.formatSocketAddress(remoteAddress);
/*  82 */     MeterKey meterKey = new MeterKey(uri, address, null, null);
/*  83 */     DistributionSummary dataSent = (DistributionSummary)MapUtils.computeIfAbsent(this.dataSentCache, meterKey, key -> (DistributionSummary)filter((Meter)DistributionSummary.builder(name() + ".data.sent").baseUnit("bytes").description("Amount of the data sent, in bytes").tags(new String[] { "remote.address", address, "uri", uri }).register(Metrics.REGISTRY)));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  89 */     if (dataSent != null) {
/*  90 */       dataSent.record(bytes);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void incrementErrorsCount(SocketAddress remoteAddress, String uri) {
/*  96 */     String address = Metrics.formatSocketAddress(remoteAddress);
/*  97 */     MeterKey meterKey = new MeterKey(uri, address, null, null);
/*  98 */     Counter errors = (Counter)MapUtils.computeIfAbsent(this.errorsCache, meterKey, key -> (Counter)filter((Meter)Counter.builder(name() + ".errors").description("Number of errors that occurred").tags(new String[] { "remote.address", address, "uri", uri }).register(Metrics.REGISTRY)));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 103 */     if (errors != null)
/* 104 */       errors.increment(); 
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\MicrometerHttpMetricsRecorder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */