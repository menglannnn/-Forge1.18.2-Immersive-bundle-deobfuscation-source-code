/*    */ package reactor.netty.http;
/*    */ 
/*    */ import java.net.SocketAddress;
/*    */ import reactor.netty.channel.ContextAwareChannelMetricsRecorder;
/*    */ import reactor.util.context.Context;
/*    */ import reactor.util.context.ContextView;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ContextAwareHttpMetricsRecorder
/*    */   extends ContextAwareChannelMetricsRecorder
/*    */   implements HttpMetricsRecorder
/*    */ {
/*    */   public abstract void incrementErrorsCount(ContextView paramContextView, SocketAddress paramSocketAddress, String paramString);
/*    */   
/*    */   public abstract void recordDataReceived(ContextView paramContextView, SocketAddress paramSocketAddress, String paramString, long paramLong);
/*    */   
/*    */   public abstract void recordDataSent(ContextView paramContextView, SocketAddress paramSocketAddress, String paramString, long paramLong);
/*    */   
/*    */   public void recordDataReceived(SocketAddress remoteAddress, String uri, long bytes) {
/* 63 */     recordDataReceived((ContextView)Context.empty(), remoteAddress, uri, bytes);
/*    */   }
/*    */ 
/*    */   
/*    */   public void recordDataSent(SocketAddress remoteAddress, String uri, long bytes) {
/* 68 */     recordDataSent((ContextView)Context.empty(), remoteAddress, uri, bytes);
/*    */   }
/*    */ 
/*    */   
/*    */   public void incrementErrorsCount(SocketAddress remoteAddress, String uri) {
/* 73 */     incrementErrorsCount((ContextView)Context.empty(), remoteAddress, uri);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\ContextAwareHttpMetricsRecorder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */