/*    */ package reactor.netty.http.logging;
/*    */ 
/*    */ import io.netty.handler.codec.http.FullHttpRequest;
/*    */ import io.netty.handler.codec.http.FullHttpResponse;
/*    */ import io.netty.handler.codec.http.HttpContent;
/*    */ import io.netty.handler.codec.http.HttpRequest;
/*    */ import io.netty.handler.codec.http.HttpResponse;
/*    */ import io.netty.handler.codec.http.LastHttpContent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class HttpMessageArgProviderFactory
/*    */ {
/*    */   public static HttpMessageArgProvider create(Object httpObject) {
/* 40 */     if (httpObject instanceof FullHttpRequest) {
/* 41 */       return new FullHttpRequestArgProvider((FullHttpRequest)httpObject);
/*    */     }
/* 43 */     if (httpObject instanceof HttpRequest) {
/* 44 */       return new HttpRequestArgProvider((HttpRequest)httpObject);
/*    */     }
/* 46 */     if (httpObject instanceof FullHttpResponse) {
/* 47 */       return new FullHttpResponseArgProvider((FullHttpResponse)httpObject);
/*    */     }
/* 49 */     if (httpObject instanceof HttpResponse) {
/* 50 */       return new HttpResponseArgProvider((HttpResponse)httpObject);
/*    */     }
/* 52 */     if (httpObject instanceof LastHttpContent) {
/* 53 */       return new LastHttpContentArgProvider((LastHttpContent)httpObject);
/*    */     }
/* 55 */     if (httpObject instanceof HttpContent) {
/* 56 */       return new HttpContentArgProvider((HttpContent)httpObject);
/*    */     }
/*    */     
/* 59 */     throw new IllegalArgumentException("Unknown object: " + httpObject);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\logging\HttpMessageArgProviderFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */