/*    */ package reactor.netty.http.logging;
/*    */ 
/*    */ import io.netty.handler.codec.http.HttpContent;
/*    */ import io.netty.handler.codec.http.HttpHeaders;
/*    */ import io.netty.handler.codec.http.LastHttpContent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class LastHttpContentArgProvider
/*    */   extends HttpContentArgProvider
/*    */ {
/*    */   final HttpHeaders trailingHeaders;
/*    */   
/*    */   LastHttpContentArgProvider(LastHttpContent lastHttpContent) {
/* 28 */     super((HttpContent)lastHttpContent);
/* 29 */     this.trailingHeaders = lastHttpContent.trailingHeaders();
/*    */   }
/*    */ 
/*    */   
/*    */   public HttpMessageType httpMessageType() {
/* 34 */     return HttpMessageType.LAST_CONTENT;
/*    */   }
/*    */ 
/*    */   
/*    */   public HttpHeaders trailingHeaders() {
/* 39 */     return this.trailingHeaders;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\logging\LastHttpContentArgProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */