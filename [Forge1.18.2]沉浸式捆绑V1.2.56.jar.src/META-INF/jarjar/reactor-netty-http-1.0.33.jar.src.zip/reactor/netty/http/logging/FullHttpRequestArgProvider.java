/*    */ package reactor.netty.http.logging;
/*    */ 
/*    */ import io.netty.handler.codec.http.FullHttpRequest;
/*    */ import io.netty.handler.codec.http.HttpHeaders;
/*    */ import io.netty.handler.codec.http.LastHttpContent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class FullHttpRequestArgProvider
/*    */   extends LastHttpContentArgProvider
/*    */ {
/*    */   final HttpHeaders httpHeaders;
/*    */   final String method;
/*    */   final String protocol;
/*    */   final String uri;
/*    */   
/*    */   FullHttpRequestArgProvider(FullHttpRequest fullHttpRequest) {
/* 31 */     super((LastHttpContent)fullHttpRequest);
/* 32 */     this.httpHeaders = fullHttpRequest.headers();
/* 33 */     this.method = fullHttpRequest.method().name();
/* 34 */     this.protocol = fullHttpRequest.protocolVersion().text();
/* 35 */     this.uri = fullHttpRequest.uri();
/*    */   }
/*    */ 
/*    */   
/*    */   public HttpHeaders headers() {
/* 40 */     return this.httpHeaders;
/*    */   }
/*    */ 
/*    */   
/*    */   public HttpMessageType httpMessageType() {
/* 45 */     return HttpMessageType.FULL_REQUEST;
/*    */   }
/*    */ 
/*    */   
/*    */   public String method() {
/* 50 */     return this.method;
/*    */   }
/*    */ 
/*    */   
/*    */   public String protocol() {
/* 55 */     return this.protocol;
/*    */   }
/*    */ 
/*    */   
/*    */   public String uri() {
/* 60 */     return this.uri;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\logging\FullHttpRequestArgProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */