/*    */ package reactor.netty.http.logging;
/*    */ 
/*    */ import io.netty.buffer.ByteBuf;
/*    */ import io.netty.handler.codec.http.HttpContent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class HttpContentArgProvider
/*    */   extends AbstractHttpMessageArgProvider
/*    */ {
/*    */   final ByteBuf content;
/*    */   
/*    */   HttpContentArgProvider(HttpContent httpContent) {
/* 28 */     super(httpContent.decoderResult());
/* 29 */     this.content = httpContent.content();
/*    */   }
/*    */ 
/*    */   
/*    */   public ByteBuf content() {
/* 34 */     return this.content;
/*    */   }
/*    */ 
/*    */   
/*    */   public HttpMessageType httpMessageType() {
/* 39 */     return HttpMessageType.CONTENT;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\logging\HttpContentArgProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */