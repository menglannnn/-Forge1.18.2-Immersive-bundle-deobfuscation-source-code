/*     */ package reactor.netty.http.logging;
/*     */ 
/*     */ import io.netty.handler.codec.DecoderResult;
/*     */ import io.netty.handler.codec.http.HttpHeaders;
/*     */ import io.netty.util.internal.StringUtil;
/*     */ import java.util.Map;
/*     */ import java.util.function.Function;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class HttpMessageLogUtils
/*     */ {
/*     */   public static String logHttpMessage(HttpMessageArgProvider argProvider, Function<String, String> uriValueFunction, Function<DecoderResult, String> decoderResultFunction, Function<Map.Entry<String, String>, String> headerValueFunction) {
/*  47 */     switch (argProvider.httpMessageType()) {
/*     */       case REQUEST:
/*  49 */         return logRequest(argProvider, uriValueFunction, decoderResultFunction, headerValueFunction);
/*     */       case FULL_REQUEST:
/*  51 */         return logFullRequest(argProvider, uriValueFunction, decoderResultFunction, headerValueFunction);
/*     */       case RESPONSE:
/*  53 */         return logResponse(argProvider, decoderResultFunction, headerValueFunction);
/*     */       case FULL_RESPONSE:
/*  55 */         return logFullResponse(argProvider, decoderResultFunction, headerValueFunction);
/*     */       case CONTENT:
/*  57 */         return logContent(argProvider, decoderResultFunction);
/*     */       case LAST_CONTENT:
/*  59 */         return logLastContent(argProvider, decoderResultFunction, headerValueFunction);
/*     */     } 
/*  61 */     throw new IllegalArgumentException("Unknown HttpMessageType: " + argProvider.httpMessageType());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String logContent(HttpMessageArgProvider argProvider, Function<DecoderResult, String> decoderResultFunction) {
/*  68 */     StringBuilder buf = new StringBuilder(256);
/*  69 */     logContent(buf, argProvider, decoderResultFunction);
/*  70 */     removeLastNewLine(buf);
/*  71 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String logFullRequest(HttpMessageArgProvider argProvider, Function<String, String> uriValueFunction, Function<DecoderResult, String> decoderResultFunction, Function<Map.Entry<String, String>, String> headerValueFunction) {
/*  79 */     StringBuilder buf = new StringBuilder(256);
/*  80 */     logFullCommon(buf, argProvider, decoderResultFunction);
/*  81 */     logInitialLine(buf, argProvider, uriValueFunction);
/*  82 */     logHeaders(buf, argProvider.headers(), headerValueFunction);
/*  83 */     logHeaders(buf, argProvider.trailingHeaders(), headerValueFunction);
/*  84 */     removeLastNewLine(buf);
/*  85 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String logFullResponse(HttpMessageArgProvider argProvider, Function<DecoderResult, String> decoderResultFunction, Function<Map.Entry<String, String>, String> headerValueFunction) {
/*  92 */     StringBuilder buf = new StringBuilder(256);
/*  93 */     logFullCommon(buf, argProvider, decoderResultFunction);
/*  94 */     logInitialLine(buf, argProvider);
/*  95 */     logHeaders(buf, argProvider.headers(), headerValueFunction);
/*  96 */     logHeaders(buf, argProvider.trailingHeaders(), headerValueFunction);
/*  97 */     removeLastNewLine(buf);
/*  98 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String logLastContent(HttpMessageArgProvider argProvider, Function<DecoderResult, String> decoderResultFunction, Function<Map.Entry<String, String>, String> headerValueFunction) {
/* 105 */     StringBuilder buf = new StringBuilder(256);
/* 106 */     logContent(buf, argProvider, decoderResultFunction);
/* 107 */     logHeaders(buf, argProvider.trailingHeaders(), headerValueFunction);
/* 108 */     removeLastNewLine(buf);
/* 109 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String logRequest(HttpMessageArgProvider argProvider, Function<String, String> uriValueFunction, Function<DecoderResult, String> decoderResultFunction, Function<Map.Entry<String, String>, String> headerValueFunction) {
/* 117 */     StringBuilder buf = new StringBuilder(256);
/* 118 */     logCommon(buf, argProvider, decoderResultFunction);
/* 119 */     logInitialLine(buf, argProvider, uriValueFunction);
/* 120 */     logHeaders(buf, argProvider.headers(), headerValueFunction);
/* 121 */     removeLastNewLine(buf);
/* 122 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String logResponse(HttpMessageArgProvider argProvider, Function<DecoderResult, String> decoderResultFunction, Function<Map.Entry<String, String>, String> headerValueFunction) {
/* 129 */     StringBuilder buf = new StringBuilder(256);
/* 130 */     logCommon(buf, argProvider, decoderResultFunction);
/* 131 */     logInitialLine(buf, argProvider);
/* 132 */     logHeaders(buf, argProvider.headers(), headerValueFunction);
/* 133 */     removeLastNewLine(buf);
/* 134 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void logCommon(StringBuilder buf, HttpMessageArgProvider argProvider, Function<DecoderResult, String> decoderResultFunction) {
/* 141 */     buf.append(argProvider.httpMessageType());
/* 142 */     buf.append("(decodeResult: ");
/* 143 */     buf.append(decoderResultFunction.apply(argProvider.decoderResult()));
/* 144 */     buf.append(", version: ");
/* 145 */     buf.append(argProvider.protocol());
/* 146 */     buf.append(')');
/* 147 */     buf.append(StringUtil.NEWLINE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void logContent(StringBuilder buf, HttpMessageArgProvider argProvider, Function<DecoderResult, String> decoderResultFunction) {
/* 154 */     buf.append(argProvider.httpMessageType());
/* 155 */     buf.append("(decodeResult: ");
/* 156 */     buf.append(decoderResultFunction.apply(argProvider.decoderResult()));
/* 157 */     buf.append(", content: ");
/* 158 */     buf.append(argProvider.content());
/* 159 */     buf.append(')');
/* 160 */     buf.append(StringUtil.NEWLINE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void logFullCommon(StringBuilder buf, HttpMessageArgProvider argProvider, Function<DecoderResult, String> decoderResultFunction) {
/* 167 */     buf.append(argProvider.httpMessageType());
/* 168 */     buf.append("(decodeResult: ");
/* 169 */     buf.append(decoderResultFunction.apply(argProvider.decoderResult()));
/* 170 */     buf.append(", version: ");
/* 171 */     buf.append(argProvider.protocol());
/* 172 */     buf.append(", content: ");
/* 173 */     buf.append(argProvider.content());
/* 174 */     buf.append(')');
/* 175 */     buf.append(StringUtil.NEWLINE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void logHeaders(StringBuilder buf, HttpHeaders headers, Function<Map.Entry<String, String>, String> headerValueFunction) {
/* 182 */     for (Map.Entry<String, String> e : (Iterable<Map.Entry<String, String>>)headers) {
/* 183 */       buf.append(e.getKey());
/* 184 */       buf.append(": ");
/* 185 */       buf.append(headerValueFunction.apply(e));
/* 186 */       buf.append(StringUtil.NEWLINE);
/*     */     } 
/*     */   }
/*     */   
/*     */   static void logInitialLine(StringBuilder buf, HttpMessageArgProvider argProvider) {
/* 191 */     buf.append(argProvider.protocol());
/* 192 */     buf.append(' ');
/* 193 */     buf.append(argProvider.status());
/* 194 */     buf.append(StringUtil.NEWLINE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void logInitialLine(StringBuilder buf, HttpMessageArgProvider argProvider, Function<String, String> uriValueFunction) {
/* 201 */     buf.append(argProvider.method());
/* 202 */     buf.append(' ');
/* 203 */     buf.append(uriValueFunction.apply(argProvider.uri()));
/* 204 */     buf.append(' ');
/* 205 */     buf.append(argProvider.protocol());
/* 206 */     buf.append(StringUtil.NEWLINE);
/*     */   }
/*     */   
/*     */   static void removeLastNewLine(StringBuilder buf) {
/* 210 */     buf.setLength(buf.length() - StringUtil.NEWLINE.length());
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\logging\HttpMessageLogUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */