/*    */ package reactor.netty.http.logging;
/*    */ 
/*    */ import io.netty.handler.codec.http.FullHttpResponse;
/*    */ import io.netty.handler.codec.http.HttpHeaders;
/*    */ import io.netty.handler.codec.http.LastHttpContent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class FullHttpResponseArgProvider
/*    */   extends LastHttpContentArgProvider
/*    */ {
/*    */   final HttpHeaders httpHeaders;
/*    */   final String protocol;
/*    */   final String status;
/*    */   
/*    */   FullHttpResponseArgProvider(FullHttpResponse fullHttpResponse) {
/* 30 */     super((LastHttpContent)fullHttpResponse);
/* 31 */     this.httpHeaders = fullHttpResponse.headers();
/* 32 */     this.protocol = fullHttpResponse.protocolVersion().text();
/* 33 */     this.status = fullHttpResponse.status().toString();
/*    */   }
/*    */ 
/*    */   
/*    */   public HttpHeaders headers() {
/* 38 */     return this.httpHeaders;
/*    */   }
/*    */ 
/*    */   
/*    */   public HttpMessageType httpMessageType() {
/* 43 */     return HttpMessageType.FULL_RESPONSE;
/*    */   }
/*    */ 
/*    */   
/*    */   public String protocol() {
/* 48 */     return this.protocol;
/*    */   }
/*    */ 
/*    */   
/*    */   public String status() {
/* 53 */     return this.status;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\logging\FullHttpResponseArgProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */