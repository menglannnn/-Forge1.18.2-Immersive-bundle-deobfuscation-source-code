package reactor.netty.http.logging;

public interface HttpMessageLogFactory {
  String trace(HttpMessageArgProvider paramHttpMessageArgProvider);
  
  String debug(HttpMessageArgProvider paramHttpMessageArgProvider);
  
  String info(HttpMessageArgProvider paramHttpMessageArgProvider);
  
  String warn(HttpMessageArgProvider paramHttpMessageArgProvider);
  
  String error(HttpMessageArgProvider paramHttpMessageArgProvider);
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\logging\HttpMessageLogFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */