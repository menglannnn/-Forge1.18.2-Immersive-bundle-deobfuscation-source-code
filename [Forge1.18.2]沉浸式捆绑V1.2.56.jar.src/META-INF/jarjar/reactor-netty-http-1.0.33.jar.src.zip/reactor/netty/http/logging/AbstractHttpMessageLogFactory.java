/*    */ package reactor.netty.http.logging;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractHttpMessageLogFactory
/*    */   implements HttpMessageLogFactory
/*    */ {
/*    */   public String trace(HttpMessageArgProvider arg) {
/* 29 */     return common(arg);
/*    */   }
/*    */ 
/*    */   
/*    */   public String debug(HttpMessageArgProvider arg) {
/* 34 */     return common(arg);
/*    */   }
/*    */ 
/*    */   
/*    */   public String info(HttpMessageArgProvider arg) {
/* 39 */     return common(arg);
/*    */   }
/*    */ 
/*    */   
/*    */   public String warn(HttpMessageArgProvider arg) {
/* 44 */     return common(arg);
/*    */   }
/*    */ 
/*    */   
/*    */   public String error(HttpMessageArgProvider arg) {
/* 49 */     return common(arg);
/*    */   }
/*    */   
/*    */   public abstract String common(HttpMessageArgProvider paramHttpMessageArgProvider);
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\logging\AbstractHttpMessageLogFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */