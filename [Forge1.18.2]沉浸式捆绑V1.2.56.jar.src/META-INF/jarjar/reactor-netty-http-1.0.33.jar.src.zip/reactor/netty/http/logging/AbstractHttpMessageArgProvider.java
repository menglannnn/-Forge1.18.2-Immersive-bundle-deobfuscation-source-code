/*    */ package reactor.netty.http.logging;
/*    */ 
/*    */ import io.netty.handler.codec.DecoderResult;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class AbstractHttpMessageArgProvider
/*    */   implements HttpMessageArgProvider
/*    */ {
/*    */   final DecoderResult decoderResult;
/*    */   
/*    */   AbstractHttpMessageArgProvider(DecoderResult decoderResult) {
/* 25 */     this.decoderResult = decoderResult;
/*    */   }
/*    */ 
/*    */   
/*    */   public DecoderResult decoderResult() {
/* 30 */     return this.decoderResult;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\logging\AbstractHttpMessageArgProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */