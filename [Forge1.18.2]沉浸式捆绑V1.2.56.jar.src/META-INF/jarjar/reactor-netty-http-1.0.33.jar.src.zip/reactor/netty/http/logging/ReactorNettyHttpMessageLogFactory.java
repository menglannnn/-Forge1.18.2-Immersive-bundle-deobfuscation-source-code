/*    */ package reactor.netty.http.logging;
/*    */ 
/*    */ import io.netty.handler.codec.DecoderResult;
/*    */ import java.util.Map;
/*    */ import java.util.function.Function;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReactorNettyHttpMessageLogFactory
/*    */   extends AbstractHttpMessageLogFactory
/*    */ {
/* 33 */   public static final ReactorNettyHttpMessageLogFactory INSTANCE = new ReactorNettyHttpMessageLogFactory();
/*    */   static {
/* 35 */     DEFAULT_URI_VALUE_FUNCTION = (s -> {
/*    */         int index = s.indexOf('?');
/*    */         
/*    */         return (index == -1) ? s : (s.substring(0, index + 1) + "<filtered>");
/*    */       });
/* 40 */     DEFAULT_DECODER_RESULT_FUNCTION = (decoderResult -> {
/*    */         if (decoderResult.isFinished()) {
/*    */           if (decoderResult.isSuccess()) {
/*    */             return "success";
/*    */           }
/*    */           String cause = decoderResult.cause().toString();
/*    */           return (new StringBuilder(cause.length() + 17)).append("failure(").append(cause).append(')').toString();
/*    */         } 
/*    */         return "unfinished";
/*    */       });
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   static final Function<String, String> DEFAULT_URI_VALUE_FUNCTION;
/*    */ 
/*    */   
/*    */   static final Function<DecoderResult, String> DEFAULT_DECODER_RESULT_FUNCTION;
/*    */   
/*    */   static final Function<Map.Entry<String, String>, String> DEFAULT_HEADER_VALUE_FUNCTION = e -> "<filtered>";
/*    */ 
/*    */   
/*    */   public String common(HttpMessageArgProvider arg) {
/* 63 */     return HttpMessageLogUtils.logHttpMessage(arg, uriValueFunction(), decoderResultFunction(), headerValueFunction());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected Function<String, String> uriValueFunction() {
/* 72 */     return DEFAULT_URI_VALUE_FUNCTION;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected Function<DecoderResult, String> decoderResultFunction() {
/* 81 */     return DEFAULT_DECODER_RESULT_FUNCTION;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected Function<Map.Entry<String, String>, String> headerValueFunction() {
/* 90 */     return DEFAULT_HEADER_VALUE_FUNCTION;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\logging\ReactorNettyHttpMessageLogFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */