/*    */ package reactor.netty.http.websocket;
/*    */ 
/*    */ import io.netty.channel.ChannelHandler;
/*    */ import io.netty.handler.codec.http.HttpHeaders;
/*    */ import io.netty.handler.codec.http.websocketx.WebSocketCloseStatus;
/*    */ import io.netty.handler.codec.http.websocketx.WebSocketFrame;
/*    */ import io.netty.handler.codec.http.websocketx.WebSocketFrameAggregator;
/*    */ import reactor.core.publisher.Flux;
/*    */ import reactor.core.publisher.Mono;
/*    */ import reactor.netty.Connection;
/*    */ import reactor.netty.NettyInbound;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface WebsocketInbound
/*    */   extends NettyInbound
/*    */ {
/*    */   default WebsocketInbound aggregateFrames() {
/* 74 */     return aggregateFrames(65536);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default WebsocketInbound aggregateFrames(int maxContentLength) {
/* 86 */     withConnection(c -> c.addHandlerLast("reactor.left.wsFrameAggregator", (ChannelHandler)new WebSocketFrameAggregator(maxContentLength)));
/* 87 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default Flux<WebSocketFrame> receiveFrames() {
/* 96 */     return receiveObject().ofType(WebSocketFrame.class);
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   String selectedSubprotocol();
/*    */   
/*    */   HttpHeaders headers();
/*    */   
/*    */   Mono<WebSocketCloseStatus> receiveCloseStatus();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\websocket\WebsocketInbound.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */