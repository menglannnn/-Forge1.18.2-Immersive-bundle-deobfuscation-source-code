/*     */ package reactor.netty.http.websocket;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.handler.codec.http.websocketx.WebSocketFrame;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.function.Function;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.netty.NettyOutbound;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface WebsocketOutbound
/*     */   extends NettyOutbound
/*     */ {
/*     */   @Nullable
/*     */   String selectedSubprotocol();
/*     */   
/*     */   NettyOutbound send(Publisher<? extends ByteBuf> paramPublisher);
/*     */   
/*     */   Mono<Void> sendClose();
/*     */   
/*     */   Mono<Void> sendClose(int paramInt);
/*     */   
/*     */   Mono<Void> sendClose(int paramInt, @Nullable String paramString);
/*     */   
/*     */   Mono<Void> sendClose(int paramInt1, int paramInt2, @Nullable String paramString);
/*     */   
/*     */   default NettyOutbound sendString(Publisher<? extends String> dataStream, Charset charset) {
/* 111 */     return sendObject((Publisher)Flux.from(dataStream)
/* 112 */         .map(stringToWebsocketFrame));
/*     */   }
/*     */   
/* 115 */   public static final Function<? super String, ? extends WebSocketFrame> stringToWebsocketFrame = io.netty.handler.codec.http.websocketx.TextWebSocketFrame::new;
/*     */   
/* 117 */   public static final Function<? super ByteBuf, ? extends WebSocketFrame> bytebufToWebsocketFrame = io.netty.handler.codec.http.websocketx.BinaryWebSocketFrame::new;
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\websocket\WebsocketOutbound.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */