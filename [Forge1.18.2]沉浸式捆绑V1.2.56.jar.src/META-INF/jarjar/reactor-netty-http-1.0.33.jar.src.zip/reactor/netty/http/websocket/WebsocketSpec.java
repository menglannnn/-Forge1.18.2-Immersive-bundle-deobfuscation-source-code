/*     */ package reactor.netty.http.websocket;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.function.Supplier;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface WebsocketSpec
/*     */ {
/*     */   @Nullable
/*     */   String protocols();
/*     */   
/*     */   int maxFramePayloadLength();
/*     */   
/*     */   boolean handlePing();
/*     */   
/*     */   boolean compress();
/*     */   
/*     */   public static class Builder<SPEC extends Builder<SPEC>>
/*     */     implements Supplier<SPEC>
/*     */   {
/*     */     String protocols;
/*  63 */     int maxFramePayloadLength = 65536;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     boolean handlePing;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     boolean compress;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final SPEC protocols(String protocols) {
/*  79 */       this.protocols = Objects.<String>requireNonNull(protocols, "protocols");
/*  80 */       return get();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final SPEC maxFramePayloadLength(int maxFramePayloadLength) {
/*  92 */       if (maxFramePayloadLength <= 0) {
/*  93 */         throw new IllegalArgumentException("Max frame payload length value must be strictly positive");
/*     */       }
/*  95 */       this.maxFramePayloadLength = maxFramePayloadLength;
/*  96 */       return get();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final SPEC handlePing(boolean handlePing) {
/* 107 */       this.handlePing = handlePing;
/* 108 */       return get();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final SPEC compress(boolean compress) {
/* 121 */       this.compress = compress;
/* 122 */       return get();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public SPEC get() {
/* 128 */       return (SPEC)this;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\websocket\WebsocketSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */