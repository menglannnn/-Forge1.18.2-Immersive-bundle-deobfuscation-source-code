/*    */ package reactor.netty.http.websocket;
/*    */ 
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WebsocketSpecImpl
/*    */   implements WebsocketSpec
/*    */ {
/*    */   private final String protocols;
/*    */   private final int maxFramePayloadLength;
/*    */   private final boolean proxyPing;
/*    */   private final boolean compress;
/*    */   
/*    */   protected WebsocketSpecImpl(WebsocketSpec.Builder<?> builder) {
/* 35 */     this.protocols = builder.protocols;
/* 36 */     this.maxFramePayloadLength = builder.maxFramePayloadLength;
/* 37 */     this.proxyPing = builder.handlePing;
/* 38 */     this.compress = builder.compress;
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public final String protocols() {
/* 44 */     return this.protocols;
/*    */   }
/*    */ 
/*    */   
/*    */   public final int maxFramePayloadLength() {
/* 49 */     return this.maxFramePayloadLength;
/*    */   }
/*    */ 
/*    */   
/*    */   public final boolean handlePing() {
/* 54 */     return this.proxyPing;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean compress() {
/* 59 */     return this.compress;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\websocket\WebsocketSpecImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */