/*     */ package reactor.netty.http.server;
/*     */ 
/*     */ import io.netty.handler.codec.http.HttpRequest;
/*     */ import io.netty.handler.codec.http.multipart.DefaultHttpDataFactory;
/*     */ import io.netty.handler.codec.http.multipart.HttpData;
/*     */ import io.netty.handler.codec.http.multipart.HttpDataFactory;
/*     */ import io.netty.handler.codec.http.multipart.HttpPostMultipartRequestDecoder;
/*     */ import io.netty.handler.codec.http.multipart.HttpPostStandardRequestDecoder;
/*     */ import io.netty.handler.codec.http.multipart.InterfaceHttpData;
/*     */ import io.netty.handler.codec.http.multipart.InterfaceHttpPostRequestDecoder;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.Path;
/*     */ import java.nio.file.attribute.FileAttribute;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.core.scheduler.Scheduler;
/*     */ import reactor.core.scheduler.Schedulers;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class HttpServerFormDecoderProvider
/*     */ {
/*     */   final Path baseDirectory;
/*     */   final Charset charset;
/*     */   final long maxInMemorySize;
/*     */   final long maxSize;
/*     */   final Scheduler scheduler;
/*     */   final boolean streaming;
/* 123 */   private volatile Mono<Path> defaultTempDirectory = createDefaultTempDirectory();
/*     */   
/*     */   HttpServerFormDecoderProvider(Build build) {
/* 126 */     this.baseDirectory = build.baseDirectory;
/* 127 */     this.charset = build.charset;
/* 128 */     this.maxInMemorySize = !build.streaming ? build.maxInMemorySize : -1L;
/* 129 */     this.maxSize = build.maxSize;
/* 130 */     this.scheduler = build.scheduler;
/* 131 */     this.streaming = build.streaming;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Path baseDirectory() {
/* 142 */     return this.baseDirectory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Charset charset() {
/* 152 */     return this.charset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long maxInMemorySize() {
/* 162 */     return this.maxInMemorySize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long maxSize() {
/* 172 */     return this.maxSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Scheduler scheduler() {
/* 182 */     return this.scheduler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean streaming() {
/* 192 */     return this.streaming;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 197 */     if (this == o) {
/* 198 */       return true;
/*     */     }
/* 200 */     if (!(o instanceof HttpServerFormDecoderProvider)) {
/* 201 */       return false;
/*     */     }
/* 203 */     HttpServerFormDecoderProvider that = (HttpServerFormDecoderProvider)o;
/* 204 */     return (this.maxInMemorySize == that.maxInMemorySize && this.maxSize == that.maxSize && this.streaming == that.streaming && 
/*     */ 
/*     */       
/* 207 */       Objects.equals(this.baseDirectory, that.baseDirectory) && this.charset
/* 208 */       .equals(that.charset) && this.scheduler
/* 209 */       .equals(that.scheduler));
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 214 */     int result = 1;
/* 215 */     result = 31 * result + Objects.hashCode(this.baseDirectory);
/* 216 */     result = 31 * result + Objects.hashCode(this.charset);
/* 217 */     result = 31 * result + Long.hashCode(this.maxInMemorySize);
/* 218 */     result = 31 * result + Long.hashCode(this.maxSize);
/* 219 */     result = 31 * result + Objects.hashCode(this.scheduler);
/* 220 */     result = 31 * result + Boolean.hashCode(this.streaming);
/* 221 */     return result;
/*     */   }
/*     */   
/*     */   Mono<Path> createDefaultTempDirectory() {
/* 225 */     return Mono.fromCallable(() -> Files.createTempDirectory("RN_form_", (FileAttribute<?>[])new FileAttribute[0]))
/* 226 */       .cache();
/*     */   }
/*     */   
/*     */   Mono<Path> defaultTempDirectory() {
/* 230 */     return this.defaultTempDirectory
/* 231 */       .flatMap(dir -> {
/*     */           if (!Files.exists(dir, new java.nio.file.LinkOption[0])) {
/*     */             Mono<Path> newDirectory = createDefaultTempDirectory();
/*     */             
/*     */             this.defaultTempDirectory = newDirectory;
/*     */             
/*     */             return newDirectory;
/*     */           } 
/*     */           
/*     */           return Mono.just(dir);
/* 241 */         }).subscribeOn(this.scheduler);
/*     */   }
/*     */   
/*     */   Mono<ReactorNettyHttpPostRequestDecoder> newHttpPostRequestDecoder(HttpRequest request, boolean isMultipart) {
/* 245 */     if (this.maxInMemorySize > -1L) {
/*     */       Mono<Path> directoryMono;
/* 247 */       if (this.baseDirectory == null) {
/* 248 */         directoryMono = defaultTempDirectory();
/*     */       } else {
/*     */         
/* 251 */         directoryMono = Mono.just(this.baseDirectory);
/*     */       } 
/* 253 */       return directoryMono.map(directory -> createNewHttpPostRequestDecoder(request, isMultipart, directory));
/*     */     } 
/*     */     
/* 256 */     return Mono.just(createNewHttpPostRequestDecoder(request, isMultipart, null));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ReactorNettyHttpPostRequestDecoder createNewHttpPostRequestDecoder(HttpRequest request, boolean isMultipart, @Nullable Path baseDirectory) {
/* 264 */     DefaultHttpDataFactory factory = (this.maxInMemorySize > 0L) ? new DefaultHttpDataFactory(this.maxInMemorySize, this.charset) : new DefaultHttpDataFactory((this.maxInMemorySize == 0L), this.charset);
/* 265 */     factory.setMaxLimit(this.maxSize);
/* 266 */     if (baseDirectory != null) {
/* 267 */       factory.setBaseDir(baseDirectory.toFile().getAbsolutePath());
/*     */     }
/* 269 */     return isMultipart ? 
/* 270 */       new ReactorNettyHttpPostMultipartRequestDecoder((HttpDataFactory)factory, request) : 
/* 271 */       new ReactorNettyHttpPostStandardRequestDecoder((HttpDataFactory)factory, request);
/*     */   } static final String DEFAULT_TEMP_DIRECTORY_PREFIX = "RN_form_"; public static interface Builder {
/*     */     Builder baseDirectory(Path param1Path); Builder charset(Charset param1Charset); Builder maxInMemorySize(long param1Long); Builder maxSize(long param1Long); Builder scheduler(Scheduler param1Scheduler); Builder streaming(boolean param1Boolean); }
/* 274 */   static final HttpServerFormDecoderProvider DEFAULT_FORM_DECODER_SPEC = (new Build()).build();
/*     */   
/*     */   static interface ReactorNettyHttpPostRequestDecoder
/*     */     extends InterfaceHttpPostRequestDecoder
/*     */   {
/*     */     void cleanCurrentHttpData(boolean param1Boolean);
/*     */     
/*     */     List<HttpData> currentHttpData(boolean param1Boolean);
/*     */   }
/*     */   
/*     */   static final class Build
/*     */     implements Builder
/*     */   {
/* 287 */     static final Charset DEFAULT_CHARSET = StandardCharsets.UTF_8;
/*     */     static final long DEFAULT_MAX_IN_MEMORY_SIZE = 16384L;
/*     */     static final long DEFAULT_MAX_SIZE = -1L;
/* 290 */     static final Scheduler DEFAULT_SCHEDULER = Schedulers.boundedElastic();
/*     */     
/*     */     static final boolean DEFAULT_STREAMING = false;
/*     */     Path baseDirectory;
/* 294 */     Charset charset = DEFAULT_CHARSET;
/* 295 */     long maxInMemorySize = 16384L;
/* 296 */     long maxSize = -1L;
/* 297 */     Scheduler scheduler = DEFAULT_SCHEDULER;
/*     */     
/*     */     boolean streaming = false;
/*     */     
/*     */     public HttpServerFormDecoderProvider.Builder baseDirectory(Path baseDirectory) {
/* 302 */       this.baseDirectory = Objects.<Path>requireNonNull(baseDirectory, "baseDirectory");
/* 303 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public HttpServerFormDecoderProvider.Builder charset(Charset charset) {
/* 308 */       this.charset = Objects.<Charset>requireNonNull(charset, "charset");
/* 309 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public HttpServerFormDecoderProvider.Builder maxInMemorySize(long maxInMemorySize) {
/* 314 */       if (maxInMemorySize < -1L) {
/* 315 */         throw new IllegalArgumentException("Maximum in-memory size must be greater or equal to -1");
/*     */       }
/* 317 */       this.maxInMemorySize = maxInMemorySize;
/* 318 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public HttpServerFormDecoderProvider.Builder maxSize(long maxSize) {
/* 323 */       if (maxSize < -1L) {
/* 324 */         throw new IllegalArgumentException("Maximum size must be be greater or equal to -1");
/*     */       }
/* 326 */       this.maxSize = maxSize;
/* 327 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public HttpServerFormDecoderProvider.Builder scheduler(Scheduler scheduler) {
/* 332 */       this.scheduler = Objects.<Scheduler>requireNonNull(scheduler, "scheduler");
/* 333 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public HttpServerFormDecoderProvider.Builder streaming(boolean enable) {
/* 338 */       this.streaming = enable;
/* 339 */       return this;
/*     */     }
/*     */     
/*     */     HttpServerFormDecoderProvider build() {
/* 343 */       return new HttpServerFormDecoderProvider(this);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static final class ReactorNettyHttpPostMultipartRequestDecoder
/*     */     extends HttpPostMultipartRequestDecoder
/*     */     implements ReactorNettyHttpPostRequestDecoder
/*     */   {
/* 353 */     final List<HttpData> currentCompletedHttpData = new ArrayList<>();
/*     */     
/*     */     ReactorNettyHttpPostMultipartRequestDecoder(HttpDataFactory factory, HttpRequest request) {
/* 356 */       super(factory, request);
/*     */     }
/*     */ 
/*     */     
/*     */     protected void addHttpData(InterfaceHttpData data) {
/* 361 */       if (data instanceof HttpData) {
/* 362 */         this.currentCompletedHttpData.add((HttpData)data);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void cleanCurrentHttpData(boolean onlyCompleted) {
/* 368 */       for (HttpData data : this.currentCompletedHttpData) {
/* 369 */         removeHttpDataFromClean((InterfaceHttpData)data);
/* 370 */         data.release();
/*     */       } 
/* 372 */       this.currentCompletedHttpData.clear();
/*     */       
/* 374 */       if (!onlyCompleted) {
/* 375 */         InterfaceHttpData partial = currentPartialHttpData();
/* 376 */         if (partial instanceof HttpData) {
/* 377 */           ((HttpData)partial).delete();
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public List<HttpData> currentHttpData(boolean onlyCompleted) {
/* 384 */       if (!onlyCompleted) {
/* 385 */         InterfaceHttpData partial = currentPartialHttpData();
/* 386 */         if (partial instanceof HttpData) {
/* 387 */           this.currentCompletedHttpData.add(((HttpData)partial).retainedDuplicate());
/*     */         }
/*     */       } 
/*     */       
/* 391 */       return this.currentCompletedHttpData;
/*     */     }
/*     */ 
/*     */     
/*     */     public void destroy() {
/* 396 */       super.destroy();
/* 397 */       InterfaceHttpData partial = currentPartialHttpData();
/* 398 */       if (partial != null) {
/* 399 */         partial.release();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static final class ReactorNettyHttpPostStandardRequestDecoder
/*     */     extends HttpPostStandardRequestDecoder
/*     */     implements ReactorNettyHttpPostRequestDecoder
/*     */   {
/* 410 */     final List<HttpData> currentCompletedHttpData = new ArrayList<>();
/*     */     
/*     */     ReactorNettyHttpPostStandardRequestDecoder(HttpDataFactory factory, HttpRequest request) {
/* 413 */       super(factory, request);
/*     */     }
/*     */ 
/*     */     
/*     */     protected void addHttpData(InterfaceHttpData data) {
/* 418 */       if (data instanceof HttpData) {
/* 419 */         this.currentCompletedHttpData.add((HttpData)data);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void cleanCurrentHttpData(boolean onlyCompleted) {
/* 425 */       for (HttpData data : this.currentCompletedHttpData) {
/* 426 */         removeHttpDataFromClean((InterfaceHttpData)data);
/* 427 */         data.release();
/*     */       } 
/* 429 */       this.currentCompletedHttpData.clear();
/*     */       
/* 431 */       if (!onlyCompleted) {
/* 432 */         InterfaceHttpData partial = currentPartialHttpData();
/* 433 */         if (partial instanceof HttpData) {
/* 434 */           ((HttpData)partial).delete();
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public List<HttpData> currentHttpData(boolean onlyCompleted) {
/* 441 */       if (!onlyCompleted) {
/* 442 */         InterfaceHttpData partial = currentPartialHttpData();
/* 443 */         if (partial instanceof HttpData) {
/* 444 */           this.currentCompletedHttpData.add(((HttpData)partial).retainedDuplicate());
/*     */         }
/*     */       } 
/*     */       
/* 448 */       return this.currentCompletedHttpData;
/*     */     }
/*     */ 
/*     */     
/*     */     public void destroy() {
/* 453 */       super.destroy();
/* 454 */       InterfaceHttpData partial = currentPartialHttpData();
/* 455 */       if (partial != null)
/* 456 */         partial.release(); 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\server\HttpServerFormDecoderProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */