/*    */ package reactor.netty.http.server;
/*    */ 
/*    */ import io.netty.buffer.ByteBuf;
/*    */ import io.netty.channel.ChannelHandler;
/*    */ import io.netty.channel.ChannelHandlerContext;
/*    */ import io.netty.handler.codec.ByteToMessageDecoder;
/*    */ import io.netty.handler.codec.ProtocolDetectionResult;
/*    */ import io.netty.handler.codec.haproxy.HAProxyMessageDecoder;
/*    */ import io.netty.handler.codec.haproxy.HAProxyProtocolVersion;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class HAProxyMessageDetector
/*    */   extends ByteToMessageDecoder
/*    */ {
/*    */   protected void decode(ChannelHandlerContext ctx, ByteBuf in, List<Object> out) {
/* 40 */     ProtocolDetectionResult<HAProxyProtocolVersion> detectionResult = HAProxyMessageDecoder.detectProtocol(in);
/* 41 */     if (detectionResult.equals(ProtocolDetectionResult.needsMoreData())) {
/*    */       return;
/*    */     }
/* 44 */     if (detectionResult.equals(ProtocolDetectionResult.invalid())) {
/* 45 */       ctx.pipeline()
/* 46 */         .remove((ChannelHandler)this);
/*    */     } else {
/*    */       
/* 49 */       ctx.pipeline()
/* 50 */         .addAfter("reactor.left.proxyProtocolDecoder", "reactor.left.proxyProtocolReader", (ChannelHandler)new HAProxyMessageReader());
/*    */ 
/*    */       
/* 53 */       ctx.pipeline()
/* 54 */         .replace((ChannelHandler)this, "reactor.left.proxyProtocolDecoder", (ChannelHandler)new HAProxyMessageDecoder());
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\server\HAProxyMessageDetector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */