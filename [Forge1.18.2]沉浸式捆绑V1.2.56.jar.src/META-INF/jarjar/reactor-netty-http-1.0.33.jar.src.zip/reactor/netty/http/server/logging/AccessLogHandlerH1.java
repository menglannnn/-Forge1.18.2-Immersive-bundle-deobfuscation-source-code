/*    */ package reactor.netty.http.server.logging;
/*    */ 
/*    */ import io.netty.buffer.ByteBuf;
/*    */ import io.netty.buffer.ByteBufHolder;
/*    */ import io.netty.channel.ChannelHandlerContext;
/*    */ import io.netty.channel.ChannelPromise;
/*    */ import io.netty.handler.codec.http.HttpMessage;
/*    */ import io.netty.handler.codec.http.HttpResponse;
/*    */ import io.netty.handler.codec.http.HttpResponseStatus;
/*    */ import io.netty.handler.codec.http.HttpUtil;
/*    */ import io.netty.handler.codec.http.LastHttpContent;
/*    */ import io.netty.util.concurrent.Future;
/*    */ import java.util.function.Function;
/*    */ import reactor.netty.channel.ChannelOperations;
/*    */ import reactor.netty.http.server.HttpServerRequest;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class AccessLogHandlerH1
/*    */   extends BaseAccessLogHandler
/*    */ {
/*    */   AccessLogArgProviderH1 accessLogArgProvider;
/*    */   
/*    */   AccessLogHandlerH1(@Nullable Function<AccessLogArgProvider, AccessLog> accessLog) {
/* 44 */     super(accessLog);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void write(ChannelHandlerContext ctx, Object msg, ChannelPromise promise) {
/* 50 */     if (msg instanceof HttpResponse) {
/* 51 */       HttpResponse response = (HttpResponse)msg;
/* 52 */       HttpResponseStatus status = response.status();
/*    */       
/* 54 */       if (status.equals(HttpResponseStatus.CONTINUE)) {
/*    */         
/* 56 */         ctx.write(msg, promise);
/*    */         
/*    */         return;
/*    */       } 
/* 60 */       if (this.accessLogArgProvider == null) {
/* 61 */         this.accessLogArgProvider = new AccessLogArgProviderH1(ctx.channel().remoteAddress());
/*    */       }
/*    */       
/* 64 */       ChannelOperations<?, ?> ops = ChannelOperations.get(ctx.channel());
/* 65 */       if (ops instanceof HttpServerRequest) {
/* 66 */         this.accessLogArgProvider.request((HttpServerRequest)ops);
/*    */       }
/*    */       
/* 69 */       boolean chunked = HttpUtil.isTransferEncodingChunked((HttpMessage)response);
/* 70 */       this.accessLogArgProvider.response(response)
/* 71 */         .chunked(chunked);
/* 72 */       if (!chunked) {
/* 73 */         this.accessLogArgProvider.contentLength(HttpUtil.getContentLength((HttpMessage)response, -1));
/*    */       }
/*    */     } 
/* 76 */     if (msg instanceof LastHttpContent) {
/* 77 */       this.accessLogArgProvider.increaseContentLength(((LastHttpContent)msg).content().readableBytes());
/* 78 */       ctx.write(msg, promise.unvoid())
/* 79 */         .addListener(future -> {
/*    */             if (future.isSuccess()) {
/*    */               AccessLog log = this.accessLog.apply(this.accessLogArgProvider);
/*    */               if (log != null) {
/*    */                 log.log();
/*    */               }
/*    */               this.accessLogArgProvider.clear();
/*    */             } 
/*    */           });
/*    */       return;
/*    */     } 
/* 90 */     if (msg instanceof ByteBuf) {
/* 91 */       this.accessLogArgProvider.increaseContentLength(((ByteBuf)msg).readableBytes());
/*    */     }
/* 93 */     if (msg instanceof ByteBufHolder) {
/* 94 */       this.accessLogArgProvider.increaseContentLength(((ByteBufHolder)msg).content().readableBytes());
/*    */     }
/*    */     
/* 97 */     ctx.write(msg, promise);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\server\logging\AccessLogHandlerH1.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */