package reactor.netty.http.server;

import io.netty.handler.codec.http.cookie.Cookie;
import java.util.List;
import java.util.Map;
import reactor.netty.http.HttpInfos;

public interface HttpServerInfos extends HttpInfos, ConnectionInformation {
  Map<CharSequence, List<Cookie>> allCookies();
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\server\HttpServerInfos.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */