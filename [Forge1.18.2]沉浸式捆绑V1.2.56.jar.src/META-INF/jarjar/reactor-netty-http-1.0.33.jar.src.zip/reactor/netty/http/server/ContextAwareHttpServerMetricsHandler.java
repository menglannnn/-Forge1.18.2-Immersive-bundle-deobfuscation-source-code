/*    */ package reactor.netty.http.server;
/*    */ 
/*    */ import java.time.Duration;
/*    */ import java.util.function.Function;
/*    */ import reactor.util.annotation.Nullable;
/*    */ import reactor.util.context.Context;
/*    */ import reactor.util.context.ContextView;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class ContextAwareHttpServerMetricsHandler
/*    */   extends AbstractHttpServerMetricsHandler
/*    */ {
/*    */   final ContextAwareHttpServerMetricsRecorder recorder;
/*    */   
/*    */   ContextAwareHttpServerMetricsHandler(ContextAwareHttpServerMetricsRecorder recorder, @Nullable Function<String, String> uriTagValue) {
/* 34 */     super(uriTagValue);
/* 35 */     this.recorder = recorder;
/*    */   }
/*    */   
/*    */   ContextAwareHttpServerMetricsHandler(ContextAwareHttpServerMetricsHandler copy) {
/* 39 */     super(copy);
/* 40 */     this.recorder = copy.recorder;
/*    */   }
/*    */ 
/*    */   
/*    */   protected ContextAwareHttpServerMetricsRecorder recorder() {
/* 45 */     return this.recorder;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void recordException(HttpServerOperations ops, String path) {
/* 51 */     recorder().incrementErrorsCount((ContextView)ops.currentContext(), ops.remoteAddress(), path);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void recordRead(HttpServerOperations ops, String path, String method) {
/* 56 */     Context context = ops.currentContext();
/* 57 */     recorder().recordDataReceivedTime((ContextView)context, path, method, 
/* 58 */         Duration.ofNanos(System.nanoTime() - this.dataReceivedTime));
/*    */ 
/*    */     
/* 61 */     recorder().recordDataReceived((ContextView)context, ops.remoteAddress(), path, this.dataReceived);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void recordWrite(HttpServerOperations ops, String path, String method, String status) {
/* 66 */     Context context = ops.currentContext();
/* 67 */     Duration dataSentTimeDuration = Duration.ofNanos(System.nanoTime() - this.dataSentTime);
/* 68 */     recorder().recordDataSentTime((ContextView)context, path, method, status, dataSentTimeDuration);
/*    */     
/* 70 */     if (this.dataReceivedTime != 0L) {
/* 71 */       recorder().recordResponseTime((ContextView)context, path, method, status, 
/* 72 */           Duration.ofNanos(System.nanoTime() - this.dataReceivedTime));
/*    */     } else {
/*    */       
/* 75 */       recorder().recordResponseTime((ContextView)context, path, method, status, dataSentTimeDuration);
/*    */     } 
/*    */ 
/*    */     
/* 79 */     recorder().recordDataSent((ContextView)context, ops.remoteAddress(), path, this.dataSent);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\server\ContextAwareHttpServerMetricsHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */