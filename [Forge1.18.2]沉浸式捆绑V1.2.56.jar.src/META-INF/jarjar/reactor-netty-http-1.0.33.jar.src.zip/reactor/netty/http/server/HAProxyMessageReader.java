/*    */ package reactor.netty.http.server;
/*    */ 
/*    */ import io.netty.channel.Channel;
/*    */ import io.netty.channel.ChannelHandler;
/*    */ import io.netty.channel.ChannelHandlerContext;
/*    */ import io.netty.channel.ChannelInboundHandlerAdapter;
/*    */ import io.netty.handler.codec.haproxy.HAProxyMessage;
/*    */ import io.netty.util.AttributeKey;
/*    */ import java.net.InetSocketAddress;
/*    */ import java.net.SocketAddress;
/*    */ import reactor.netty.transport.AddressUtils;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class HAProxyMessageReader
/*    */   extends ChannelInboundHandlerAdapter
/*    */ {
/* 38 */   private static final AttributeKey<InetSocketAddress> REMOTE_ADDRESS_FROM_PROXY_PROTOCOL = AttributeKey.valueOf("remoteAddressFromProxyProtocol");
/*    */   
/*    */   private static final boolean isProxyProtocolAvailable;
/*    */   
/*    */   static {
/* 43 */     boolean proxyProtocolCheck = true;
/*    */     try {
/* 45 */       Class.forName("io.netty.handler.codec.haproxy.HAProxyMessageDecoder");
/*    */     }
/* 47 */     catch (ClassNotFoundException cnfe) {
/* 48 */       proxyProtocolCheck = false;
/*    */     } 
/* 50 */     isProxyProtocolAvailable = proxyProtocolCheck;
/*    */   }
/*    */   
/*    */   static boolean isProxyProtocolAvailable() {
/* 54 */     return isProxyProtocolAvailable;
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   static SocketAddress resolveRemoteAddressFromProxyProtocol(Channel channel) {
/* 59 */     if (isProxyProtocolAvailable()) {
/* 60 */       return (SocketAddress)channel.attr(REMOTE_ADDRESS_FROM_PROXY_PROTOCOL).getAndSet(null);
/*    */     }
/*    */     
/* 63 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
/* 68 */     if (msg instanceof HAProxyMessage) {
/* 69 */       HAProxyMessage proxyMessage = (HAProxyMessage)msg;
/* 70 */       if (proxyMessage.sourceAddress() != null && proxyMessage.sourcePort() != 0) {
/*    */         
/* 72 */         InetSocketAddress remoteAddress = AddressUtils.createUnresolved(proxyMessage.sourceAddress(), proxyMessage.sourcePort());
/* 73 */         ctx.channel()
/* 74 */           .attr(REMOTE_ADDRESS_FROM_PROXY_PROTOCOL)
/* 75 */           .set(remoteAddress);
/*    */       } 
/*    */       
/* 78 */       proxyMessage.release();
/*    */       
/* 80 */       ctx.channel()
/* 81 */         .pipeline()
/* 82 */         .remove((ChannelHandler)this);
/*    */       
/* 84 */       ctx.read();
/*    */     } else {
/*    */       
/* 87 */       super.channelRead(ctx, msg);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\server\HAProxyMessageReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */