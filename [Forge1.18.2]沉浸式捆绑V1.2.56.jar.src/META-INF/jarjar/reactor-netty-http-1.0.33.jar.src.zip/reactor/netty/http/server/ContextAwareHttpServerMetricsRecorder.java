/*    */ package reactor.netty.http.server;
/*    */ 
/*    */ import java.time.Duration;
/*    */ import reactor.netty.http.ContextAwareHttpMetricsRecorder;
/*    */ import reactor.util.context.Context;
/*    */ import reactor.util.context.ContextView;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ContextAwareHttpServerMetricsRecorder
/*    */   extends ContextAwareHttpMetricsRecorder
/*    */   implements HttpServerMetricsRecorder
/*    */ {
/*    */   public abstract void recordDataReceivedTime(ContextView paramContextView, String paramString1, String paramString2, Duration paramDuration);
/*    */   
/*    */   public abstract void recordDataSentTime(ContextView paramContextView, String paramString1, String paramString2, String paramString3, Duration paramDuration);
/*    */   
/*    */   public abstract void recordResponseTime(ContextView paramContextView, String paramString1, String paramString2, String paramString3, Duration paramDuration);
/*    */   
/*    */   public void recordDataReceivedTime(String uri, String method, Duration time) {
/* 66 */     recordDataReceivedTime((ContextView)Context.empty(), uri, method, time);
/*    */   }
/*    */ 
/*    */   
/*    */   public void recordDataSentTime(String uri, String method, String status, Duration time) {
/* 71 */     recordDataSentTime((ContextView)Context.empty(), uri, method, status, time);
/*    */   }
/*    */ 
/*    */   
/*    */   public void recordResponseTime(String uri, String method, String status, Duration time) {
/* 76 */     recordResponseTime((ContextView)Context.empty(), uri, method, status, time);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\server\ContextAwareHttpServerMetricsRecorder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */