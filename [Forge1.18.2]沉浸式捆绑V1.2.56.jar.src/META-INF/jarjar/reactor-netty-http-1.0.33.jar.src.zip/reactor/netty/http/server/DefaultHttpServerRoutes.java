/*     */ package reactor.netty.http.server;
/*     */ 
/*     */ import io.netty.handler.codec.http.HttpMethod;
/*     */ import java.net.URI;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.Path;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Comparator;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.CopyOnWriteArrayList;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Predicate;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class DefaultHttpServerRoutes
/*     */   implements HttpServerRoutes
/*     */ {
/*  43 */   private final CopyOnWriteArrayList<HttpRouteHandler> handlers = new CopyOnWriteArrayList<>();
/*     */ 
/*     */   
/*  46 */   private final List<HttpRouteHandler> initialOrderHandlers = new ArrayList<>();
/*     */ 
/*     */   
/*     */   private Comparator<HttpRouteHandlerMetadata> comparator;
/*     */ 
/*     */   
/*     */   public HttpServerRoutes directory(String uri, Path directory, @Nullable Function<HttpServerResponse, HttpServerResponse> interceptor) {
/*  53 */     Objects.requireNonNull(directory, "directory");
/*  54 */     return route(HttpPredicate.prefix(uri), (req, resp) -> {
/*     */           String prefix = URI.create(req.uri()).getPath().replaceFirst(uri, "");
/*     */           if (!prefix.isEmpty() && prefix.charAt(0) == '/') {
/*     */             prefix = prefix.substring(1);
/*     */           }
/*     */           Path p = directory.resolve(prefix);
/*     */           return (Publisher)(Files.isReadable(p) ? ((interceptor != null) ? ((HttpServerResponse)interceptor.apply(resp)).sendFile(p) : resp.sendFile(p)) : resp.sendNotFound());
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpServerRoutes removeIf(Predicate<? super HttpRouteHandlerMetadata> condition) {
/*  80 */     Objects.requireNonNull(condition, "condition");
/*     */     
/*  82 */     this.handlers.removeIf(condition);
/*     */     
/*  84 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpServerRoutes route(Predicate<? super HttpServerRequest> condition, BiFunction<? super HttpServerRequest, ? super HttpServerResponse, ? extends Publisher<Void>> handler) {
/*  90 */     Objects.requireNonNull(condition, "condition");
/*  91 */     Objects.requireNonNull(handler, "handler");
/*     */     
/*  93 */     if (condition instanceof HttpPredicate) {
/*  94 */       HttpPredicate predicate = (HttpPredicate)condition;
/*  95 */       HttpRouteHandler httpRouteHandler = new HttpRouteHandler(condition, handler, predicate, predicate.uri, predicate.method);
/*     */ 
/*     */       
/*  98 */       this.handlers.add(httpRouteHandler);
/*  99 */       this.initialOrderHandlers.add(httpRouteHandler);
/*     */     }
/*     */     else {
/*     */       
/* 103 */       HttpRouteHandler httpRouteHandler = new HttpRouteHandler(condition, handler, null, null, null);
/* 104 */       this.handlers.add(httpRouteHandler);
/* 105 */       this.initialOrderHandlers.add(httpRouteHandler);
/*     */     } 
/*     */     
/* 108 */     if (this.comparator != null) {
/* 109 */       this.handlers.sort(this.comparator);
/*     */     }
/*     */     
/* 112 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpServerRoutes comparator(Comparator<HttpRouteHandlerMetadata> comparator) {
/* 117 */     Objects.requireNonNull(comparator, "comparator");
/* 118 */     this.comparator = comparator;
/* 119 */     this.handlers.sort(comparator);
/* 120 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpServerRoutes noComparator() {
/* 125 */     this.handlers.clear();
/* 126 */     this.handlers.addAll(this.initialOrderHandlers);
/* 127 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Publisher<Void> apply(HttpServerRequest request, HttpServerResponse response) {
/* 133 */     Iterator<HttpRouteHandler> iterator = this.handlers.iterator();
/*     */ 
/*     */     
/*     */     try {
/* 137 */       while (iterator.hasNext()) {
/* 138 */         HttpRouteHandler cursor = iterator.next();
/* 139 */         if (cursor.test(request)) {
/* 140 */           return cursor.apply(request, response);
/*     */         }
/*     */       }
/*     */     
/* 144 */     } catch (Throwable t) {
/* 145 */       Exceptions.throwIfJvmFatal(t);
/* 146 */       return (Publisher<Void>)Mono.error(t);
/*     */     } 
/*     */     
/* 149 */     return (Publisher<Void>)response.sendNotFound();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static final class HttpRouteHandler
/*     */     implements BiFunction<HttpServerRequest, HttpServerResponse, Publisher<Void>>, Predicate<HttpServerRequest>, HttpRouteHandlerMetadata
/*     */   {
/*     */     final Predicate<? super HttpServerRequest> condition;
/*     */ 
/*     */     
/*     */     final BiFunction<? super HttpServerRequest, ? super HttpServerResponse, ? extends Publisher<Void>> handler;
/*     */     
/*     */     final Function<? super String, Map<String, String>> resolver;
/*     */     
/*     */     final String path;
/*     */     
/*     */     final HttpMethod method;
/*     */ 
/*     */     
/*     */     HttpRouteHandler(Predicate<? super HttpServerRequest> condition, BiFunction<? super HttpServerRequest, ? super HttpServerResponse, ? extends Publisher<Void>> handler, @Nullable Function<? super String, Map<String, String>> resolver, @Nullable String path, @Nullable HttpMethod method) {
/* 170 */       this.condition = Objects.<Predicate<? super HttpServerRequest>>requireNonNull(condition, "condition");
/* 171 */       this.handler = Objects.<BiFunction<? super HttpServerRequest, ? super HttpServerResponse, ? extends Publisher<Void>>>requireNonNull(handler, "handler");
/* 172 */       this.resolver = resolver;
/* 173 */       this.path = path;
/* 174 */       this.method = method;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Publisher<Void> apply(HttpServerRequest request, HttpServerResponse response) {
/* 180 */       return this.handler.apply(request.paramsResolver(this.resolver), response);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean test(HttpServerRequest o) {
/* 185 */       return this.condition.test(o);
/*     */     }
/*     */ 
/*     */     
/*     */     public String getPath() {
/* 190 */       return this.path;
/*     */     }
/*     */ 
/*     */     
/*     */     public HttpMethod getMethod() {
/* 195 */       return this.method;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\server\DefaultHttpServerRoutes.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */