/*    */ package reactor.netty.http.server.logging;
/*    */ 
/*    */ import io.netty.channel.ChannelHandler;
/*    */ import java.util.function.Function;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum AccessLogHandlerFactory
/*    */ {
/* 33 */   H1,
/*    */ 
/*    */ 
/*    */   
/* 37 */   H2;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ChannelHandler create(@Nullable Function<AccessLogArgProvider, AccessLog> accessLog) {
/* 46 */     switch (this) {
/*    */       case H2:
/* 48 */         return (ChannelHandler)new AccessLogHandlerH2(accessLog);
/*    */     } 
/*    */     
/* 51 */     return (ChannelHandler)new AccessLogHandlerH1(accessLog);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\server\logging\AccessLogHandlerFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */