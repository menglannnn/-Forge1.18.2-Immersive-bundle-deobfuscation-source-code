/*    */ package reactor.netty.http.server.logging;
/*    */ 
/*    */ import io.netty.handler.codec.http2.Http2HeadersFrame;
/*    */ import java.net.SocketAddress;
/*    */ import java.util.Objects;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class AccessLogArgProviderH2
/*    */   extends AbstractAccessLogArgProvider<AccessLogArgProviderH2>
/*    */ {
/*    */   static final String H2_PROTOCOL_NAME = "HTTP/2.0";
/*    */   Http2HeadersFrame requestHeaders;
/*    */   Http2HeadersFrame responseHeaders;
/*    */   
/*    */   AccessLogArgProviderH2(@Nullable SocketAddress remoteAddress) {
/* 35 */     super(remoteAddress);
/*    */   }
/*    */   
/*    */   AccessLogArgProviderH2 requestHeaders(Http2HeadersFrame requestHeaders) {
/* 39 */     this.requestHeaders = Objects.<Http2HeadersFrame>requireNonNull(requestHeaders, "requestHeaders");
/* 40 */     onRequest();
/* 41 */     return get();
/*    */   }
/*    */   
/*    */   AccessLogArgProviderH2 responseHeaders(Http2HeadersFrame responseHeaders) {
/* 45 */     this.responseHeaders = Objects.<Http2HeadersFrame>requireNonNull(responseHeaders, "responseHeaders");
/* 46 */     return get();
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public CharSequence status() {
/* 52 */     return (this.responseHeaders == null) ? null : this.responseHeaders.headers().status();
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public CharSequence requestHeader(CharSequence name) {
/* 58 */     Objects.requireNonNull(name, "name");
/* 59 */     return (this.requestHeaders == null) ? null : (CharSequence)this.requestHeaders.headers().get(name);
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public CharSequence responseHeader(CharSequence name) {
/* 65 */     Objects.requireNonNull(name, "name");
/* 66 */     return (this.responseHeaders == null) ? null : (CharSequence)this.responseHeaders.headers().get(name);
/*    */   }
/*    */ 
/*    */   
/*    */   void onRequest() {
/* 71 */     super.onRequest();
/* 72 */     if (this.requestHeaders != null) {
/* 73 */       this.method = this.requestHeaders.headers().method();
/* 74 */       this.uri = this.requestHeaders.headers().path();
/* 75 */       this.protocol = "HTTP/2.0";
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   void clear() {
/* 81 */     super.clear();
/* 82 */     this.requestHeaders = null;
/* 83 */     this.responseHeaders = null;
/*    */   }
/*    */ 
/*    */   
/*    */   public AccessLogArgProviderH2 get() {
/* 88 */     return this;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\server\logging\AccessLogArgProviderH2.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */