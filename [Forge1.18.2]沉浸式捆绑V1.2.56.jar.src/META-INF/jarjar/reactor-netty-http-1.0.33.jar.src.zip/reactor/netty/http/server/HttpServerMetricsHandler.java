/*    */ package reactor.netty.http.server;
/*    */ 
/*    */ import java.util.function.Function;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class HttpServerMetricsHandler
/*    */   extends AbstractHttpServerMetricsHandler
/*    */ {
/*    */   final HttpServerMetricsRecorder recorder;
/*    */   
/*    */   HttpServerMetricsHandler(HttpServerMetricsRecorder recorder, @Nullable Function<String, String> uriTagValue) {
/* 30 */     super(uriTagValue);
/* 31 */     this.recorder = recorder;
/*    */   }
/*    */   
/*    */   HttpServerMetricsHandler(HttpServerMetricsHandler copy) {
/* 35 */     super(copy);
/* 36 */     this.recorder = copy.recorder;
/*    */   }
/*    */ 
/*    */   
/*    */   protected HttpServerMetricsRecorder recorder() {
/* 41 */     return this.recorder;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\server\HttpServerMetricsHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */