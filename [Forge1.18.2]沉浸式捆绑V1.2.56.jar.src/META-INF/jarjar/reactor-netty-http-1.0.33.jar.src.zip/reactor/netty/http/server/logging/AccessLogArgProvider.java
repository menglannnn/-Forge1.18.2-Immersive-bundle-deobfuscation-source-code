package reactor.netty.http.server.logging;

import io.netty.handler.codec.http.cookie.Cookie;
import java.net.SocketAddress;
import java.time.ZonedDateTime;
import java.util.Map;
import java.util.Set;
import reactor.netty.http.server.ConnectionInformation;
import reactor.util.annotation.Nullable;

public interface AccessLogArgProvider {
  @Nullable
  @Deprecated
  String zonedDateTime();
  
  @Nullable
  ZonedDateTime accessDateTime();
  
  @Nullable
  @Deprecated
  SocketAddress remoteAddress();
  
  @Nullable
  ConnectionInformation connectionInformation();
  
  @Nullable
  CharSequence method();
  
  @Nullable
  CharSequence uri();
  
  @Nullable
  String protocol();
  
  @Nullable
  String user();
  
  @Nullable
  CharSequence status();
  
  long contentLength();
  
  long duration();
  
  @Nullable
  CharSequence requestHeader(CharSequence paramCharSequence);
  
  @Nullable
  CharSequence responseHeader(CharSequence paramCharSequence);
  
  @Nullable
  Map<CharSequence, Set<Cookie>> cookies();
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\server\logging\AccessLogArgProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */