/*     */ package reactor.netty.http.server;
/*     */ 
/*     */ import io.netty.channel.Channel;
/*     */ import io.netty.handler.codec.http.HttpHeaderNames;
/*     */ import io.netty.handler.codec.http.HttpRequest;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.SocketAddress;
/*     */ import java.util.Objects;
/*     */ import java.util.function.BiFunction;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ConnectionInfo
/*     */ {
/*     */   static final int DEFAULT_HTTP_PORT = 80;
/*     */   static final int DEFAULT_HTTPS_PORT = 443;
/*     */   static final String DEFAULT_HOST_NAME = "localhost";
/*     */   final SocketAddress hostAddress;
/*     */   final SocketAddress remoteAddress;
/*     */   final String scheme;
/*     */   final String hostName;
/*     */   final int hostPort;
/*     */   final boolean isInetAddress;
/*     */   
/*     */   static ConnectionInfo from(Channel channel, HttpRequest request, boolean secured, SocketAddress remoteAddress, @Nullable BiFunction<ConnectionInfo, HttpRequest, ConnectionInfo> forwardedHeaderHandler) {
/*  62 */     String hostName = "localhost";
/*  63 */     int hostPort = -1;
/*  64 */     String scheme = secured ? "https" : "http";
/*     */     
/*  66 */     String header = request.headers().get((CharSequence)HttpHeaderNames.HOST);
/*  67 */     if (header != null) {
/*  68 */       hostName = header;
/*  69 */       if (!header.isEmpty()) {
/*  70 */         int portIndex = (header.charAt(0) == '[') ? header.indexOf(':', header.indexOf(']')) : header.indexOf(':');
/*  71 */         if (portIndex != -1) {
/*  72 */           hostName = header.substring(0, portIndex);
/*  73 */           hostPort = Integer.parseInt(header.substring(portIndex + 1));
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/*  78 */     if (!(remoteAddress instanceof InetSocketAddress)) {
/*  79 */       return new ConnectionInfo(channel.localAddress(), hostName, hostPort, remoteAddress, scheme, false);
/*     */     }
/*     */ 
/*     */     
/*  83 */     ConnectionInfo connectionInfo = new ConnectionInfo(channel.localAddress(), hostName, hostPort, remoteAddress, scheme, true);
/*  84 */     if (forwardedHeaderHandler != null) {
/*  85 */       return forwardedHeaderHandler.apply(connectionInfo, request);
/*     */     }
/*  87 */     return connectionInfo;
/*     */   }
/*     */ 
/*     */   
/*     */   ConnectionInfo(SocketAddress hostAddress, SocketAddress remoteAddress, boolean secured) {
/*  92 */     this(hostAddress, "localhost", -1, remoteAddress, secured ? "https" : "http", remoteAddress instanceof InetSocketAddress);
/*     */   }
/*     */ 
/*     */   
/*     */   ConnectionInfo(SocketAddress hostAddress, String hostName, int hostPort, SocketAddress remoteAddress, String scheme, boolean isInetAddress) {
/*  97 */     this.hostAddress = hostAddress;
/*  98 */     this.hostName = hostName;
/*  99 */     this.hostPort = hostPort;
/* 100 */     this.isInetAddress = isInetAddress;
/* 101 */     this.remoteAddress = remoteAddress;
/* 102 */     this.scheme = scheme;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public InetSocketAddress getHostAddress() {
/* 111 */     return this.isInetAddress ? (InetSocketAddress)this.hostAddress : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public InetSocketAddress getRemoteAddress() {
/* 120 */     return this.isInetAddress ? (InetSocketAddress)this.remoteAddress : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getScheme() {
/* 128 */     return this.scheme;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConnectionInfo withHostAddress(InetSocketAddress hostAddress) {
/* 137 */     Objects.requireNonNull(hostAddress, "hostAddress");
/* 138 */     return new ConnectionInfo(hostAddress, hostAddress.getHostString(), hostAddress.getPort(), this.remoteAddress, this.scheme, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConnectionInfo withHostAddress(InetSocketAddress hostAddress, String hostName, int hostPort) {
/* 151 */     Objects.requireNonNull(hostAddress, "hostAddress");
/* 152 */     Objects.requireNonNull(hostName, "hostName");
/* 153 */     return new ConnectionInfo(hostAddress, hostName, hostPort, this.remoteAddress, this.scheme, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConnectionInfo withRemoteAddress(InetSocketAddress remoteAddress) {
/* 162 */     Objects.requireNonNull(remoteAddress, "remoteAddress");
/* 163 */     return new ConnectionInfo(this.hostAddress, this.hostName, this.hostPort, remoteAddress, this.scheme, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConnectionInfo withScheme(String scheme) {
/* 172 */     Objects.requireNonNull(scheme, "scheme");
/* 173 */     return new ConnectionInfo(this.hostAddress, this.hostName, this.hostPort, this.remoteAddress, scheme, this.isInetAddress);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getHostName() {
/* 182 */     return this.hostName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getHostPort() {
/* 191 */     return (this.hostPort != -1) ? this.hostPort : getDefaultHostPort(this.scheme);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getDefaultHostPort(String scheme) {
/* 201 */     return (scheme.equalsIgnoreCase("https") || scheme.equalsIgnoreCase("wss")) ? 
/* 202 */       443 : 80;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\server\ConnectionInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */