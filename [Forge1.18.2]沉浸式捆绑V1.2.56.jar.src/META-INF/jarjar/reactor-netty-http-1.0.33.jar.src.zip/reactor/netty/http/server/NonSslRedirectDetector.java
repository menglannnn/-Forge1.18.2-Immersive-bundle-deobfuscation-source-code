/*    */ package reactor.netty.http.server;
/*    */ 
/*    */ import io.netty.buffer.ByteBuf;
/*    */ import io.netty.channel.ChannelHandler;
/*    */ import io.netty.channel.ChannelHandlerContext;
/*    */ import io.netty.channel.ChannelPipeline;
/*    */ import io.netty.handler.codec.ByteToMessageDecoder;
/*    */ import io.netty.handler.ssl.SslHandler;
/*    */ import java.net.SocketAddress;
/*    */ import java.util.List;
/*    */ import javax.annotation.Nullable;
/*    */ import reactor.netty.tcp.SslProvider;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class NonSslRedirectDetector
/*    */   extends ByteToMessageDecoder
/*    */ {
/*    */   private static final int SSL_RECORD_HEADER_LENGTH = 5;
/*    */   private final SslProvider sslProvider;
/*    */   private final SocketAddress remoteAddress;
/*    */   private final boolean sslDebug;
/*    */   
/*    */   public NonSslRedirectDetector(SslProvider sslProvider, @Nullable SocketAddress remoteAddress, boolean sslDebug) {
/* 48 */     this.sslProvider = sslProvider;
/* 49 */     this.remoteAddress = remoteAddress;
/* 50 */     this.sslDebug = sslDebug;
/*    */   }
/*    */ 
/*    */   
/*    */   protected void decode(ChannelHandlerContext ctx, ByteBuf in, List<Object> out) {
/* 55 */     if (in.readableBytes() < 5) {
/*    */       return;
/*    */     }
/* 58 */     ChannelPipeline pipeline = ctx.pipeline();
/* 59 */     if (SslHandler.isEncrypted(in)) {
/* 60 */       this.sslProvider.addSslHandler(ctx.channel(), this.remoteAddress, this.sslDebug);
/*    */     } else {
/*    */       
/* 63 */       pipeline.addBefore("reactor.right.reactiveBridge", "reactor.left.nonSslRedirectHandler", (ChannelHandler)new NonSslRedirectHandler());
/*    */     } 
/* 65 */     pipeline.remove((ChannelHandler)this);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\server\NonSslRedirectDetector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */