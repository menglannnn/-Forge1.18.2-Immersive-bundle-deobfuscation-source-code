/*    */ package reactor.netty.http.server;
/*    */ 
/*    */ import io.netty.handler.codec.http.HttpHeaderNames;
/*    */ import io.netty.handler.codec.http.HttpHeaders;
/*    */ import io.netty.handler.codec.http.cookie.Cookie;
/*    */ import io.netty.handler.codec.http.cookie.CookieDecoder;
/*    */ import io.netty.handler.codec.http.cookie.ServerCookieDecoder;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import java.util.HashMap;
/*    */ import java.util.HashSet;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ import reactor.netty.http.Cookies;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ServerCookies
/*    */   extends Cookies
/*    */ {
/*    */   final ServerCookieDecoder serverCookieDecoder;
/*    */   Map<CharSequence, List<Cookie>> allCachedCookies;
/*    */   
/*    */   public static ServerCookies newServerRequestHolder(HttpHeaders headers, ServerCookieDecoder decoder) {
/* 47 */     return new ServerCookies(headers, (CharSequence)HttpHeaderNames.COOKIE, false, decoder);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   ServerCookies(HttpHeaders nettyHeaders, CharSequence cookiesHeaderName, boolean isClientChannel, ServerCookieDecoder decoder) {
/* 56 */     super(nettyHeaders, cookiesHeaderName, isClientChannel, (CookieDecoder)decoder);
/* 57 */     this.serverCookieDecoder = decoder;
/* 58 */     this.allCachedCookies = Collections.emptyMap();
/*    */   }
/*    */ 
/*    */   
/*    */   public Map<CharSequence, Set<Cookie>> getCachedCookies() {
/* 63 */     getAllCachedCookies();
/* 64 */     return this.cachedCookies;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Map<CharSequence, List<Cookie>> getAllCachedCookies() {
/* 74 */     if (!markReadingCookies()) { do {
/*    */       
/* 76 */       } while (!hasReadCookies());
/* 77 */       return this.allCachedCookies; }
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 82 */     List<String> allCookieHeaders = allCookieHeaders();
/* 83 */     Map<String, Set<Cookie>> cookies = new HashMap<>();
/* 84 */     Map<String, List<Cookie>> allCookies = new HashMap<>();
/* 85 */     for (String aCookieHeader : allCookieHeaders) {
/* 86 */       List<Cookie> decode = this.serverCookieDecoder.decodeAll(aCookieHeader);
/* 87 */       for (Cookie cookie : decode) {
/* 88 */         Set<Cookie> existingCookiesOfNameSet = cookies.computeIfAbsent(cookie.name(), k -> new HashSet());
/* 89 */         existingCookiesOfNameSet.add(cookie);
/* 90 */         List<Cookie> existingCookiesOfNameList = allCookies.computeIfAbsent(cookie.name(), k -> new ArrayList());
/* 91 */         existingCookiesOfNameList.add(cookie);
/*    */       } 
/*    */     } 
/* 94 */     this.cachedCookies = Collections.unmodifiableMap(cookies);
/* 95 */     this.allCachedCookies = Collections.unmodifiableMap((Map)allCookies);
/* 96 */     markReadCookies();
/* 97 */     return this.allCachedCookies;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\server\ServerCookies.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */