/*      */ package reactor.netty.http.server;
/*      */ 
/*      */ import io.netty.channel.Channel;
/*      */ import io.netty.channel.ChannelHandler;
/*      */ import io.netty.channel.ChannelHandlerAdapter;
/*      */ import io.netty.channel.ChannelHandlerContext;
/*      */ import io.netty.channel.ChannelInitializer;
/*      */ import io.netty.channel.ChannelOption;
/*      */ import io.netty.channel.ChannelPipeline;
/*      */ import io.netty.channel.ChannelPromise;
/*      */ import io.netty.handler.codec.haproxy.HAProxyMessageDecoder;
/*      */ import io.netty.handler.codec.http.HttpHeaderNames;
/*      */ import io.netty.handler.codec.http.HttpRequest;
/*      */ import io.netty.handler.codec.http.HttpServerCodec;
/*      */ import io.netty.handler.codec.http.HttpServerUpgradeHandler;
/*      */ import io.netty.handler.codec.http.cookie.ServerCookieDecoder;
/*      */ import io.netty.handler.codec.http.cookie.ServerCookieEncoder;
/*      */ import io.netty.handler.codec.http2.CleartextHttp2ServerUpgradeHandler;
/*      */ import io.netty.handler.codec.http2.Http2CodecUtil;
/*      */ import io.netty.handler.codec.http2.Http2Connection;
/*      */ import io.netty.handler.codec.http2.Http2ConnectionAdapter;
/*      */ import io.netty.handler.codec.http2.Http2FrameCodec;
/*      */ import io.netty.handler.codec.http2.Http2FrameCodecBuilder;
/*      */ import io.netty.handler.codec.http2.Http2FrameLogger;
/*      */ import io.netty.handler.codec.http2.Http2MultiplexHandler;
/*      */ import io.netty.handler.codec.http2.Http2ServerUpgradeCodec;
/*      */ import io.netty.handler.codec.http2.Http2Settings;
/*      */ import io.netty.handler.codec.http2.Http2Stream;
/*      */ import io.netty.handler.codec.http2.Http2StreamFrameToHttpObjectCodec;
/*      */ import io.netty.handler.logging.LogLevel;
/*      */ import io.netty.handler.logging.LoggingHandler;
/*      */ import io.netty.handler.ssl.ApplicationProtocolNegotiationHandler;
/*      */ import io.netty.util.AsciiString;
/*      */ import java.net.SocketAddress;
/*      */ import java.nio.charset.Charset;
/*      */ import java.time.Duration;
/*      */ import java.util.Map;
/*      */ import java.util.function.BiFunction;
/*      */ import java.util.function.BiPredicate;
/*      */ import java.util.function.Function;
/*      */ import java.util.function.Supplier;
/*      */ import reactor.core.publisher.Mono;
/*      */ import reactor.netty.ChannelPipelineConfigurer;
/*      */ import reactor.netty.Connection;
/*      */ import reactor.netty.ConnectionObserver;
/*      */ import reactor.netty.ReactorNetty;
/*      */ import reactor.netty.channel.AbstractChannelMetricsHandler;
/*      */ import reactor.netty.channel.ChannelMetricsRecorder;
/*      */ import reactor.netty.channel.ChannelOperations;
/*      */ import reactor.netty.http.Http2SettingsSpec;
/*      */ import reactor.netty.http.HttpProtocol;
/*      */ import reactor.netty.http.HttpResources;
/*      */ import reactor.netty.http.logging.HttpMessageLogFactory;
/*      */ import reactor.netty.http.logging.ReactorNettyHttpMessageLogFactory;
/*      */ import reactor.netty.http.server.logging.AccessLog;
/*      */ import reactor.netty.http.server.logging.AccessLogArgProvider;
/*      */ import reactor.netty.http.server.logging.AccessLogHandlerFactory;
/*      */ import reactor.netty.resources.LoopResources;
/*      */ import reactor.netty.tcp.SslProvider;
/*      */ import reactor.netty.transport.ServerTransportConfig;
/*      */ import reactor.netty.transport.logging.AdvancedByteBufFormat;
/*      */ import reactor.util.Logger;
/*      */ import reactor.util.Loggers;
/*      */ import reactor.util.annotation.Nullable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class HttpServerConfig
/*      */   extends ServerTransportConfig<HttpServerConfig>
/*      */ {
/*      */   boolean accessLogEnabled;
/*      */   Function<AccessLogArgProvider, AccessLog> accessLog;
/*      */   BiPredicate<HttpServerRequest, HttpServerResponse> compressPredicate;
/*      */   ServerCookieDecoder cookieDecoder;
/*      */   ServerCookieEncoder cookieEncoder;
/*      */   HttpRequestDecoderSpec decoder;
/*      */   HttpServerFormDecoderProvider formDecoderProvider;
/*      */   BiFunction<ConnectionInfo, HttpRequest, ConnectionInfo> forwardedHeaderHandler;
/*      */   Http2SettingsSpec http2Settings;
/*      */   HttpMessageLogFactory httpMessageLogFactory;
/*      */   Duration idleTimeout;
/*      */   BiFunction<? super Mono<Void>, ? super Connection, ? extends Mono<Void>> mapHandle;
/*      */   int maxKeepAliveRequests;
/*      */   int minCompressionSize;
/*      */   HttpProtocol[] protocols;
/*      */   int _protocols;
/*      */   ProxyProtocolSupportType proxyProtocolSupportType;
/*      */   boolean redirectHttpToHttps;
/*      */   SslProvider sslProvider;
/*      */   Function<String, String> uriTagValue;
/*      */   
/*      */   @Nullable
/*      */   public BiPredicate<HttpServerRequest, HttpServerResponse> compressPredicate() {
/*  103 */     return this.compressPredicate;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ServerCookieDecoder cookieDecoder() {
/*  112 */     return this.cookieDecoder;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ServerCookieEncoder cookieEncoder() {
/*  121 */     return this.cookieEncoder;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequestDecoderSpec decoder() {
/*  130 */     return this.decoder;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpServerFormDecoderProvider formDecoderProvider() {
/*  140 */     return this.formDecoderProvider;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Http2SettingsSpec http2SettingsSpec() {
/*  149 */     return this.http2Settings;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public Duration idleTimeout() {
/*  159 */     return this.idleTimeout;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isForwarded() {
/*  170 */     return (this.forwardedHeaderHandler != null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isSecure() {
/*  179 */     return (this.sslProvider != null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int maxKeepAliveRequests() {
/*  190 */     return this.maxKeepAliveRequests;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int minCompressionSize() {
/*  199 */     return this.minCompressionSize;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpProtocol[] protocols() {
/*  208 */     return this.protocols;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ProxyProtocolSupportType proxyProtocolSupportType() {
/*  218 */     return this.proxyProtocolSupportType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean redirectHttpToHttps() {
/*  231 */     return this.redirectHttpToHttps;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public SslProvider sslProvider() {
/*  243 */     return this.sslProvider;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public Function<String, String> uriTagValue() {
/*  255 */     return this.uriTagValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   HttpServerConfig(Map<ChannelOption<?>, ?> options, Map<ChannelOption<?>, ?> childOptions, Supplier<? extends SocketAddress> localAddress) {
/*  284 */     super(options, childOptions, localAddress);
/*  285 */     this.cookieDecoder = ServerCookieDecoder.STRICT;
/*  286 */     this.cookieEncoder = ServerCookieEncoder.STRICT;
/*  287 */     this.decoder = new HttpRequestDecoderSpec();
/*  288 */     this.formDecoderProvider = HttpServerFormDecoderProvider.DEFAULT_FORM_DECODER_SPEC;
/*  289 */     this.httpMessageLogFactory = (HttpMessageLogFactory)ReactorNettyHttpMessageLogFactory.INSTANCE;
/*  290 */     this.maxKeepAliveRequests = -1;
/*  291 */     this.minCompressionSize = -1;
/*  292 */     this.protocols = new HttpProtocol[] { HttpProtocol.HTTP11 };
/*  293 */     this._protocols = 4;
/*  294 */     this.proxyProtocolSupportType = ProxyProtocolSupportType.OFF;
/*  295 */     this.accessLogEnabled = ACCESS_LOG;
/*      */   }
/*      */   
/*      */   HttpServerConfig(HttpServerConfig parent) {
/*  299 */     super(parent);
/*  300 */     this.accessLogEnabled = parent.accessLogEnabled;
/*  301 */     this.accessLog = parent.accessLog;
/*  302 */     this.compressPredicate = parent.compressPredicate;
/*  303 */     this.cookieDecoder = parent.cookieDecoder;
/*  304 */     this.cookieEncoder = parent.cookieEncoder;
/*  305 */     this.decoder = parent.decoder;
/*  306 */     this.formDecoderProvider = parent.formDecoderProvider;
/*  307 */     this.forwardedHeaderHandler = parent.forwardedHeaderHandler;
/*  308 */     this.http2Settings = parent.http2Settings;
/*  309 */     this.httpMessageLogFactory = parent.httpMessageLogFactory;
/*  310 */     this.idleTimeout = parent.idleTimeout;
/*  311 */     this.mapHandle = parent.mapHandle;
/*  312 */     this.maxKeepAliveRequests = parent.maxKeepAliveRequests;
/*  313 */     this.minCompressionSize = parent.minCompressionSize;
/*  314 */     this.protocols = parent.protocols;
/*  315 */     this._protocols = parent._protocols;
/*  316 */     this.proxyProtocolSupportType = parent.proxyProtocolSupportType;
/*  317 */     this.redirectHttpToHttps = parent.redirectHttpToHttps;
/*  318 */     this.sslProvider = parent.sslProvider;
/*  319 */     this.uriTagValue = parent.uriTagValue;
/*      */   }
/*      */ 
/*      */   
/*      */   protected LoggingHandler defaultLoggingHandler() {
/*  324 */     return LOGGING_HANDLER;
/*      */   }
/*      */ 
/*      */   
/*      */   protected LoopResources defaultLoopResources() {
/*  329 */     return (LoopResources)HttpResources.get();
/*      */   }
/*      */ 
/*      */   
/*      */   protected ChannelMetricsRecorder defaultMetricsRecorder() {
/*  334 */     return (ChannelMetricsRecorder)MicrometerHttpServerMetricsRecorder.INSTANCE;
/*      */   }
/*      */ 
/*      */   
/*      */   protected ChannelPipelineConfigurer defaultOnChannelInit() {
/*  339 */     return super.defaultOnChannelInit()
/*  340 */       .then(new HttpServerChannelInitializer(this));
/*      */   }
/*      */ 
/*      */   
/*      */   protected void loggingHandler(LoggingHandler loggingHandler) {
/*  345 */     super.loggingHandler(loggingHandler);
/*      */   }
/*      */ 
/*      */   
/*      */   protected void metricsRecorder(@Nullable Supplier<? extends ChannelMetricsRecorder> metricsRecorder) {
/*  350 */     super.metricsRecorder(metricsRecorder);
/*      */   }
/*      */   
/*      */   void protocols(HttpProtocol... protocols) {
/*  354 */     this.protocols = protocols;
/*  355 */     int _protocols = 0;
/*      */     
/*  357 */     for (HttpProtocol p : protocols) {
/*  358 */       if (p == HttpProtocol.HTTP11) {
/*  359 */         _protocols |= 0x4;
/*      */       }
/*  361 */       else if (p == HttpProtocol.H2) {
/*  362 */         _protocols |= 0x2;
/*      */       }
/*  364 */       else if (p == HttpProtocol.H2C) {
/*  365 */         _protocols |= 0x1;
/*      */       } 
/*      */     } 
/*  368 */     this._protocols = _protocols;
/*      */   }
/*      */   
/*      */   static Http2Settings http2Settings(@Nullable Http2SettingsSpec http2Settings) {
/*  372 */     Http2Settings settings = Http2Settings.defaultSettings();
/*      */     
/*  374 */     if (http2Settings != null) {
/*  375 */       Long headerTableSize = http2Settings.headerTableSize();
/*  376 */       if (headerTableSize != null) {
/*  377 */         settings.headerTableSize(headerTableSize.longValue());
/*      */       }
/*      */       
/*  380 */       Integer initialWindowSize = http2Settings.initialWindowSize();
/*  381 */       if (initialWindowSize != null) {
/*  382 */         settings.initialWindowSize(initialWindowSize.intValue());
/*      */       }
/*      */       
/*  385 */       Long maxConcurrentStreams = http2Settings.maxConcurrentStreams();
/*  386 */       if (maxConcurrentStreams != null) {
/*  387 */         settings.maxConcurrentStreams(maxConcurrentStreams.longValue());
/*      */       }
/*      */       
/*  390 */       Integer maxFrameSize = http2Settings.maxFrameSize();
/*  391 */       if (maxFrameSize != null) {
/*  392 */         settings.maxFrameSize(maxFrameSize.intValue());
/*      */       }
/*      */       
/*  395 */       settings.maxHeaderListSize(http2Settings.maxHeaderListSize().longValue());
/*      */       
/*  397 */       Boolean pushEnabled = http2Settings.pushEnabled();
/*  398 */       if (pushEnabled != null) {
/*  399 */         settings.pushEnabled(pushEnabled.booleanValue());
/*      */       }
/*      */     } 
/*      */     
/*  403 */     return settings;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void addStreamHandlers(Channel ch, boolean accessLogEnabled, @Nullable Function<AccessLogArgProvider, AccessLog> accessLog, @Nullable BiPredicate<HttpServerRequest, HttpServerResponse> compressPredicate, ServerCookieDecoder decoder, ServerCookieEncoder encoder, HttpServerFormDecoderProvider formDecoderProvider, @Nullable BiFunction<ConnectionInfo, HttpRequest, ConnectionInfo> forwardedHeaderHandler, HttpMessageLogFactory httpMessageLogFactory, ConnectionObserver listener, @Nullable BiFunction<? super Mono<Void>, ? super Connection, ? extends Mono<Void>> mapHandle, @Nullable ChannelMetricsRecorder metricsRecorder, int minCompressionSize, ChannelOperations.OnSetup opsFactory, @Nullable Function<String, String> uriTagValue) {
/*  421 */     ChannelPipeline pipeline = ch.pipeline();
/*  422 */     if (accessLogEnabled) {
/*  423 */       pipeline.addLast("reactor.left.accessLogHandler", AccessLogHandlerFactory.H2.create(accessLog));
/*      */     }
/*  425 */     pipeline.addLast("reactor.left.h2ToHttp11Codec", (ChannelHandler)HTTP2_STREAM_FRAME_TO_HTTP_OBJECT)
/*  426 */       .addLast("reactor.left.httpTrafficHandler", (ChannelHandler)new Http2StreamBridgeServerHandler(compressPredicate, decoder, encoder, formDecoderProvider, forwardedHeaderHandler, httpMessageLogFactory, listener, mapHandle));
/*      */ 
/*      */ 
/*      */     
/*  430 */     boolean alwaysCompress = (compressPredicate == null && minCompressionSize == 0);
/*      */     
/*  432 */     if (alwaysCompress) {
/*  433 */       pipeline.addLast("reactor.left.compressionHandler", (ChannelHandler)new SimpleCompressionHandler());
/*      */     }
/*      */     
/*  436 */     ChannelOperations.addReactiveBridge(ch, opsFactory, listener);
/*      */     
/*  438 */     if (metricsRecorder != null && 
/*  439 */       metricsRecorder instanceof HttpServerMetricsRecorder) {
/*      */       ChannelHandler handler;
/*  441 */       Channel parent = ch.parent();
/*  442 */       ChannelHandler existingHandler = parent.pipeline().get("reactor.left.httpMetricsHandler");
/*  443 */       if (existingHandler != null) {
/*      */         
/*  445 */         if (metricsRecorder instanceof MicrometerHttpServerMetricsRecorder) {
/*  446 */           parent.pipeline().replace("reactor.left.httpMetricsHandler", "reactor.left.channelMetricsHandler", (ChannelHandler)new H2ChannelMetricsHandler(metricsRecorder));
/*      */         }
/*      */         else {
/*      */           
/*  450 */           parent.pipeline().remove("reactor.left.httpMetricsHandler");
/*      */         } 
/*      */ 
/*      */         
/*  454 */         handler = (metricsRecorder instanceof ContextAwareHttpServerMetricsRecorder) ? (ChannelHandler)new ContextAwareHttpServerMetricsHandler((ContextAwareHttpServerMetricsHandler)existingHandler) : (ChannelHandler)new HttpServerMetricsHandler((HttpServerMetricsHandler)existingHandler);
/*      */       
/*      */       }
/*      */       else {
/*      */         
/*  459 */         handler = (metricsRecorder instanceof ContextAwareHttpServerMetricsRecorder) ? (ChannelHandler)new ContextAwareHttpServerMetricsHandler((ContextAwareHttpServerMetricsRecorder)metricsRecorder, uriTagValue) : (ChannelHandler)new HttpServerMetricsHandler((HttpServerMetricsRecorder)metricsRecorder, uriTagValue);
/*      */       } 
/*  461 */       pipeline.addBefore("reactor.right.reactiveBridge", "reactor.left.httpMetricsHandler", handler);
/*      */     } 
/*      */ 
/*      */     
/*  465 */     if (log.isDebugEnabled()) {
/*  466 */       log.debug(ReactorNetty.format(ch, "Initialized HTTP/2 stream pipeline {}"), new Object[] { pipeline });
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   static BiPredicate<HttpServerRequest, HttpServerResponse> compressPredicate(@Nullable BiPredicate<HttpServerRequest, HttpServerResponse> compressionPredicate, int minResponseSize) {
/*  475 */     if (minResponseSize <= 0) {
/*  476 */       return compressionPredicate;
/*      */     }
/*      */     
/*  479 */     BiPredicate<HttpServerRequest, HttpServerResponse> lengthPredicate = (req, res) -> {
/*      */         String length = res.responseHeaders().get((CharSequence)HttpHeaderNames.CONTENT_LENGTH);
/*      */ 
/*      */ 
/*      */         
/*      */         if (length == null) {
/*      */           return true;
/*      */         }
/*      */ 
/*      */         
/*      */         try {
/*      */           return (Long.parseLong(length) >= minResponseSize);
/*  491 */         } catch (NumberFormatException nfe) {
/*      */           return true;
/*      */         } 
/*      */       };
/*      */     
/*  496 */     if (compressionPredicate != null) {
/*  497 */       lengthPredicate = lengthPredicate.and(compressionPredicate);
/*      */     }
/*  499 */     return lengthPredicate;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void configureH2Pipeline(ChannelPipeline p, boolean accessLogEnabled, @Nullable Function<AccessLogArgProvider, AccessLog> accessLog, @Nullable BiPredicate<HttpServerRequest, HttpServerResponse> compressPredicate, ServerCookieDecoder cookieDecoder, ServerCookieEncoder cookieEncoder, boolean enableGracefulShutdown, HttpServerFormDecoderProvider formDecoderProvider, @Nullable BiFunction<ConnectionInfo, HttpRequest, ConnectionInfo> forwardedHeaderHandler, @Nullable Http2SettingsSpec http2SettingsSpec, HttpMessageLogFactory httpMessageLogFactory, @Nullable Duration idleTimeout, ConnectionObserver listener, @Nullable BiFunction<? super Mono<Void>, ? super Connection, ? extends Mono<Void>> mapHandle, @Nullable ChannelMetricsRecorder metricsRecorder, int minCompressionSize, ChannelOperations.OnSetup opsFactory, @Nullable Function<String, String> uriTagValue, boolean validate) {
/*  521 */     p.remove("reactor.right.reactiveBridge");
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  526 */     Http2FrameCodecBuilder http2FrameCodecBuilder = Http2FrameCodecBuilder.forServer().validateHeaders(validate).initialSettings(http2Settings(http2SettingsSpec));
/*      */     
/*  528 */     Long maxStreams = (http2SettingsSpec != null) ? http2SettingsSpec.maxStreams() : null;
/*  529 */     if (enableGracefulShutdown || maxStreams != null)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  536 */       http2FrameCodecBuilder.gracefulShutdownTimeoutMillis(-1L);
/*      */     }
/*      */     
/*  539 */     if (p.get("reactor.left.loggingHandler") != null) {
/*  540 */       http2FrameCodecBuilder.frameLogger(new Http2FrameLogger(LogLevel.DEBUG, "reactor.netty.http.server.h2"));
/*      */     }
/*      */ 
/*      */     
/*  544 */     Http2FrameCodec http2FrameCodec = http2FrameCodecBuilder.build();
/*  545 */     if (maxStreams != null) {
/*  546 */       http2FrameCodec.connection().addListener((Http2Connection.Listener)new H2ConnectionListener(p.channel(), maxStreams.longValue()));
/*      */     }
/*  548 */     p.addLast("reactor.left.httpCodec", (ChannelHandler)http2FrameCodec)
/*  549 */       .addLast("reactor.left.h2MultiplexHandler", (ChannelHandler)new Http2MultiplexHandler((ChannelHandler)new H2Codec(accessLogEnabled, accessLog, compressPredicate, cookieDecoder, cookieEncoder, formDecoderProvider, forwardedHeaderHandler, httpMessageLogFactory, listener, mapHandle, metricsRecorder, minCompressionSize, opsFactory, uriTagValue)));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  554 */     IdleTimeoutHandler.addIdleTimeoutHandler(p, idleTimeout);
/*      */     
/*  556 */     if (metricsRecorder != null && 
/*  557 */       metricsRecorder instanceof MicrometerHttpServerMetricsRecorder)
/*      */     {
/*      */       
/*  560 */       p.replace("reactor.left.channelMetricsHandler", "reactor.left.channelMetricsHandler", (ChannelHandler)new H2ChannelMetricsHandler(metricsRecorder));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void configureHttp11OrH2CleartextPipeline(ChannelPipeline p, boolean accessLogEnabled, @Nullable Function<AccessLogArgProvider, AccessLog> accessLog, @Nullable BiPredicate<HttpServerRequest, HttpServerResponse> compressPredicate, ServerCookieDecoder cookieDecoder, ServerCookieEncoder cookieEncoder, HttpRequestDecoderSpec decoder, boolean enableGracefulShutdown, HttpServerFormDecoderProvider formDecoderProvider, @Nullable BiFunction<ConnectionInfo, HttpRequest, ConnectionInfo> forwardedHeaderHandler, @Nullable Http2SettingsSpec http2SettingsSpec, HttpMessageLogFactory httpMessageLogFactory, @Nullable Duration idleTimeout, ConnectionObserver listener, @Nullable BiFunction<? super Mono<Void>, ? super Connection, ? extends Mono<Void>> mapHandle, int maxKeepAliveRequests, @Nullable ChannelMetricsRecorder metricsRecorder, int minCompressionSize, ChannelOperations.OnSetup opsFactory, @Nullable Function<String, String> uriTagValue) {
/*  589 */     HttpServerCodec httpServerCodec = new HttpServerCodec(decoder.maxInitialLineLength(), decoder.maxHeaderSize(), decoder.maxChunkSize(), decoder.validateHeaders(), decoder.initialBufferSize(), decoder.allowDuplicateContentLengths());
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  594 */     Http11OrH2CleartextCodec upgrader = new Http11OrH2CleartextCodec(accessLogEnabled, accessLog, compressPredicate, cookieDecoder, cookieEncoder, (p.get("reactor.left.loggingHandler") != null), enableGracefulShutdown, formDecoderProvider, forwardedHeaderHandler, http2SettingsSpec, httpMessageLogFactory, listener, mapHandle, metricsRecorder, minCompressionSize, opsFactory, uriTagValue, decoder.validateHeaders());
/*      */     
/*  596 */     H2CleartextCodec h2CleartextCodec = new H2CleartextCodec(upgrader, (http2SettingsSpec != null) ? http2SettingsSpec.maxStreams() : null);
/*      */ 
/*      */     
/*  599 */     CleartextHttp2ServerUpgradeHandler h2cUpgradeHandler = new CleartextHttp2ServerUpgradeHandler(httpServerCodec, new HttpServerUpgradeHandler((HttpServerUpgradeHandler.SourceCodec)httpServerCodec, upgrader, decoder.h2cMaxContentLength()), (ChannelHandler)h2CleartextCodec);
/*      */ 
/*      */     
/*  602 */     p.addBefore("reactor.right.reactiveBridge", "reactor.left.h2cUpgradeHandler", (ChannelHandler)h2cUpgradeHandler)
/*      */       
/*  604 */       .addBefore("reactor.right.reactiveBridge", "reactor.left.httpTrafficHandler", (ChannelHandler)new HttpTrafficHandler(compressPredicate, cookieDecoder, cookieEncoder, formDecoderProvider, forwardedHeaderHandler, httpMessageLogFactory, idleTimeout, listener, mapHandle, maxKeepAliveRequests));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  609 */     if (accessLogEnabled) {
/*  610 */       p.addAfter("reactor.left.httpTrafficHandler", "reactor.left.accessLogHandler", AccessLogHandlerFactory.H1.create(accessLog));
/*      */     }
/*      */     
/*  613 */     boolean alwaysCompress = (compressPredicate == null && minCompressionSize == 0);
/*      */     
/*  615 */     if (alwaysCompress) {
/*  616 */       p.addBefore("reactor.left.httpTrafficHandler", "reactor.left.compressionHandler", (ChannelHandler)new SimpleCompressionHandler());
/*      */     }
/*      */     
/*  619 */     if (metricsRecorder != null && 
/*  620 */       metricsRecorder instanceof HttpServerMetricsRecorder) {
/*      */ 
/*      */       
/*  623 */       ChannelHandler handler = (metricsRecorder instanceof ContextAwareHttpServerMetricsRecorder) ? (ChannelHandler)new ContextAwareHttpServerMetricsHandler((ContextAwareHttpServerMetricsRecorder)metricsRecorder, uriTagValue) : (ChannelHandler)new HttpServerMetricsHandler((HttpServerMetricsRecorder)metricsRecorder, uriTagValue);
/*  624 */       p.addAfter("reactor.left.httpTrafficHandler", "reactor.left.httpMetricsHandler", handler);
/*  625 */       if (metricsRecorder instanceof MicrometerHttpServerMetricsRecorder)
/*      */       {
/*      */         
/*  628 */         p.remove("reactor.left.channelMetricsHandler");
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void configureHttp11Pipeline(ChannelPipeline p, boolean accessLogEnabled, @Nullable Function<AccessLogArgProvider, AccessLog> accessLog, @Nullable BiPredicate<HttpServerRequest, HttpServerResponse> compressPredicate, ServerCookieDecoder cookieDecoder, ServerCookieEncoder cookieEncoder, HttpRequestDecoderSpec decoder, HttpServerFormDecoderProvider formDecoderProvider, @Nullable BiFunction<ConnectionInfo, HttpRequest, ConnectionInfo> forwardedHeaderHandler, HttpMessageLogFactory httpMessageLogFactory, @Nullable Duration idleTimeout, ConnectionObserver listener, @Nullable BiFunction<? super Mono<Void>, ? super Connection, ? extends Mono<Void>> mapHandle, int maxKeepAliveRequests, @Nullable ChannelMetricsRecorder metricsRecorder, int minCompressionSize, @Nullable Function<String, String> uriTagValue) {
/*  651 */     p.addBefore("reactor.right.reactiveBridge", "reactor.left.httpCodec", (ChannelHandler)new HttpServerCodec(decoder
/*      */           
/*  653 */           .maxInitialLineLength(), decoder.maxHeaderSize(), decoder
/*  654 */           .maxChunkSize(), decoder.validateHeaders(), decoder.initialBufferSize(), decoder
/*  655 */           .allowDuplicateContentLengths()))
/*  656 */       .addBefore("reactor.right.reactiveBridge", "reactor.left.httpTrafficHandler", (ChannelHandler)new HttpTrafficHandler(compressPredicate, cookieDecoder, cookieEncoder, formDecoderProvider, forwardedHeaderHandler, httpMessageLogFactory, idleTimeout, listener, mapHandle, maxKeepAliveRequests));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  661 */     if (accessLogEnabled) {
/*  662 */       p.addAfter("reactor.left.httpTrafficHandler", "reactor.left.accessLogHandler", AccessLogHandlerFactory.H1.create(accessLog));
/*      */     }
/*      */     
/*  665 */     boolean alwaysCompress = (compressPredicate == null && minCompressionSize == 0);
/*      */     
/*  667 */     if (alwaysCompress) {
/*  668 */       p.addBefore("reactor.left.httpTrafficHandler", "reactor.left.compressionHandler", (ChannelHandler)new SimpleCompressionHandler());
/*      */     }
/*      */     
/*  671 */     if (metricsRecorder != null && 
/*  672 */       metricsRecorder instanceof HttpServerMetricsRecorder) {
/*      */ 
/*      */       
/*  675 */       ChannelHandler handler = (metricsRecorder instanceof ContextAwareHttpServerMetricsRecorder) ? (ChannelHandler)new ContextAwareHttpServerMetricsHandler((ContextAwareHttpServerMetricsRecorder)metricsRecorder, uriTagValue) : (ChannelHandler)new HttpServerMetricsHandler((HttpServerMetricsRecorder)metricsRecorder, uriTagValue);
/*  676 */       p.addAfter("reactor.left.httpTrafficHandler", "reactor.left.httpMetricsHandler", handler);
/*  677 */       if (metricsRecorder instanceof MicrometerHttpServerMetricsRecorder)
/*      */       {
/*      */         
/*  680 */         p.remove("reactor.left.channelMetricsHandler");
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*  686 */   static final boolean ACCESS_LOG = Boolean.parseBoolean(System.getProperty("reactor.netty.http.server.accessLogEnabled", "false"));
/*      */   
/*      */   static final int h2 = 2;
/*      */   
/*      */   static final int h2c = 1;
/*      */   
/*      */   static final int h11 = 4;
/*      */   
/*      */   static final int h11orH2 = 6;
/*      */   
/*      */   static final int h11orH2C = 5;
/*      */   
/*  698 */   static final Http2StreamFrameToHttpObjectCodec HTTP2_STREAM_FRAME_TO_HTTP_OBJECT = new Http2StreamFrameToHttpObjectCodec(true);
/*      */ 
/*      */   
/*  701 */   static final Logger log = Loggers.getLogger(HttpServerConfig.class);
/*      */   
/*  703 */   static final LoggingHandler LOGGING_HANDLER = AdvancedByteBufFormat.HEX_DUMP
/*      */     
/*  705 */     .toLoggingHandler(HttpServer.class.getName(), LogLevel.DEBUG, Charset.defaultCharset());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  711 */   static final boolean SSL_DEBUG = Boolean.parseBoolean(System.getProperty("reactor.netty.tcp.ssl.server.debug", "false"));
/*      */   
/*      */   static final class H2ChannelMetricsHandler
/*      */     extends AbstractChannelMetricsHandler {
/*      */     final ChannelMetricsRecorder recorder;
/*      */     
/*      */     H2ChannelMetricsHandler(ChannelMetricsRecorder recorder) {
/*  718 */       super(null, true);
/*  719 */       this.recorder = recorder;
/*      */     }
/*      */ 
/*      */     
/*      */     public void channelRead(ChannelHandlerContext ctx, Object msg) {
/*  724 */       ctx.fireChannelRead(msg);
/*      */     }
/*      */ 
/*      */     
/*      */     public void channelRegistered(ChannelHandlerContext ctx) {
/*  729 */       ctx.fireChannelRegistered();
/*      */     }
/*      */ 
/*      */     
/*      */     public ChannelHandler connectMetricsHandler() {
/*  734 */       return null;
/*      */     }
/*      */ 
/*      */     
/*      */     public ChannelHandler tlsMetricsHandler() {
/*  739 */       return null;
/*      */     }
/*      */ 
/*      */     
/*      */     public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) {
/*  744 */       ctx.fireExceptionCaught(cause);
/*      */     }
/*      */ 
/*      */     
/*      */     public ChannelMetricsRecorder recorder() {
/*  749 */       return this.recorder;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void write(ChannelHandlerContext ctx, Object msg, ChannelPromise promise) {
/*  756 */       ctx.write(msg, promise);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   static final class H2CleartextCodec
/*      */     extends ChannelHandlerAdapter
/*      */   {
/*      */     final HttpServerConfig.Http11OrH2CleartextCodec upgrader;
/*      */     
/*      */     final boolean addHttp2FrameCodec;
/*      */     final boolean removeMetricsHandler;
/*      */     final Long maxStreams;
/*      */     
/*      */     H2CleartextCodec(HttpServerConfig.Http11OrH2CleartextCodec upgrader, @Nullable Long maxStreams) {
/*  771 */       this(upgrader, true, true, maxStreams);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     H2CleartextCodec(HttpServerConfig.Http11OrH2CleartextCodec upgrader, boolean addHttp2FrameCodec, boolean removeMetricsHandler, @Nullable Long maxStreams) {
/*  780 */       this.upgrader = upgrader;
/*  781 */       this.addHttp2FrameCodec = addHttp2FrameCodec;
/*  782 */       this.removeMetricsHandler = removeMetricsHandler;
/*  783 */       this.maxStreams = maxStreams;
/*      */     }
/*      */ 
/*      */     
/*      */     public void handlerAdded(ChannelHandlerContext ctx) {
/*  788 */       ChannelPipeline pipeline = ctx.pipeline();
/*  789 */       if (this.maxStreams != null) {
/*  790 */         this.upgrader.http2FrameCodec.connection().addListener((Http2Connection.Listener)new HttpServerConfig.H2ConnectionListener(ctx.channel(), this.maxStreams.longValue()));
/*      */       }
/*  792 */       if (this.addHttp2FrameCodec) {
/*  793 */         pipeline.addAfter(ctx.name(), "reactor.left.httpCodec", (ChannelHandler)this.upgrader.http2FrameCodec);
/*      */       }
/*      */ 
/*      */       
/*  797 */       pipeline.addLast("reactor.left.h2MultiplexHandler", (ChannelHandler)new Http2MultiplexHandler((ChannelHandler)this.upgrader));
/*      */       
/*  799 */       pipeline.remove((ChannelHandler)this);
/*      */       
/*  801 */       if (pipeline.get("reactor.left.accessLogHandler") != null) {
/*  802 */         pipeline.remove("reactor.left.accessLogHandler");
/*      */       }
/*  804 */       if (pipeline.get("reactor.left.compressionHandler") != null) {
/*  805 */         pipeline.remove("reactor.left.compressionHandler");
/*      */       }
/*  807 */       if (this.removeMetricsHandler && pipeline.get("reactor.left.httpMetricsHandler") != null) {
/*      */         
/*  809 */         AbstractHttpServerMetricsHandler handler = (AbstractHttpServerMetricsHandler)pipeline.get("reactor.left.httpMetricsHandler");
/*  810 */         if (handler.recorder() instanceof MicrometerHttpServerMetricsRecorder) {
/*  811 */           pipeline.replace("reactor.left.httpMetricsHandler", "reactor.left.channelMetricsHandler", (ChannelHandler)new HttpServerConfig.H2ChannelMetricsHandler((ChannelMetricsRecorder)handler
/*  812 */                 .recorder()));
/*      */         } else {
/*      */           
/*  815 */           pipeline.remove("reactor.left.httpMetricsHandler");
/*      */         } 
/*      */       } 
/*  818 */       pipeline.remove("reactor.left.httpTrafficHandler");
/*  819 */       pipeline.remove("reactor.right.reactiveBridge");
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   static final class H2Codec
/*      */     extends ChannelInitializer<Channel>
/*      */   {
/*      */     final boolean accessLogEnabled;
/*      */     
/*      */     final Function<AccessLogArgProvider, AccessLog> accessLog;
/*      */     
/*      */     final BiPredicate<HttpServerRequest, HttpServerResponse> compressPredicate;
/*      */     
/*      */     final ServerCookieDecoder cookieDecoder;
/*      */     
/*      */     final ServerCookieEncoder cookieEncoder;
/*      */     
/*      */     final HttpServerFormDecoderProvider formDecoderProvider;
/*      */     
/*      */     final BiFunction<ConnectionInfo, HttpRequest, ConnectionInfo> forwardedHeaderHandler;
/*      */     
/*      */     final HttpMessageLogFactory httpMessageLogFactory;
/*      */     
/*      */     final ConnectionObserver listener;
/*      */     
/*      */     final BiFunction<? super Mono<Void>, ? super Connection, ? extends Mono<Void>> mapHandle;
/*      */     
/*      */     final ChannelMetricsRecorder metricsRecorder;
/*      */     
/*      */     final int minCompressionSize;
/*      */     
/*      */     final ChannelOperations.OnSetup opsFactory;
/*      */     
/*      */     final Function<String, String> uriTagValue;
/*      */     
/*      */     H2Codec(boolean accessLogEnabled, @Nullable Function<AccessLogArgProvider, AccessLog> accessLog, @Nullable BiPredicate<HttpServerRequest, HttpServerResponse> compressPredicate, ServerCookieDecoder decoder, ServerCookieEncoder encoder, HttpServerFormDecoderProvider formDecoderProvider, @Nullable BiFunction<ConnectionInfo, HttpRequest, ConnectionInfo> forwardedHeaderHandler, HttpMessageLogFactory httpMessageLogFactory, ConnectionObserver listener, @Nullable BiFunction<? super Mono<Void>, ? super Connection, ? extends Mono<Void>> mapHandle, @Nullable ChannelMetricsRecorder metricsRecorder, int minCompressionSize, ChannelOperations.OnSetup opsFactory, @Nullable Function<String, String> uriTagValue) {
/*  856 */       this.accessLogEnabled = accessLogEnabled;
/*  857 */       this.accessLog = accessLog;
/*  858 */       this.compressPredicate = compressPredicate;
/*  859 */       this.cookieDecoder = decoder;
/*  860 */       this.cookieEncoder = encoder;
/*  861 */       this.formDecoderProvider = formDecoderProvider;
/*  862 */       this.forwardedHeaderHandler = forwardedHeaderHandler;
/*  863 */       this.httpMessageLogFactory = httpMessageLogFactory;
/*  864 */       this.listener = listener;
/*  865 */       this.mapHandle = mapHandle;
/*  866 */       this.metricsRecorder = metricsRecorder;
/*  867 */       this.minCompressionSize = minCompressionSize;
/*  868 */       this.opsFactory = opsFactory;
/*  869 */       this.uriTagValue = uriTagValue;
/*      */     }
/*      */ 
/*      */     
/*      */     protected void initChannel(Channel ch) {
/*  874 */       ch.pipeline().remove((ChannelHandler)this);
/*  875 */       HttpServerConfig.addStreamHandlers(ch, this.accessLogEnabled, this.accessLog, this.compressPredicate, this.cookieDecoder, this.cookieEncoder, this.formDecoderProvider, this.forwardedHeaderHandler, this.httpMessageLogFactory, this.listener, this.mapHandle, this.metricsRecorder, this.minCompressionSize, this.opsFactory, this.uriTagValue);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static final class Http11OrH2CleartextCodec
/*      */     extends ChannelInitializer<Channel>
/*      */     implements HttpServerUpgradeHandler.UpgradeCodecFactory
/*      */   {
/*      */     final boolean accessLogEnabled;
/*      */ 
/*      */     
/*      */     final Function<AccessLogArgProvider, AccessLog> accessLog;
/*      */ 
/*      */     
/*      */     final BiPredicate<HttpServerRequest, HttpServerResponse> compressPredicate;
/*      */     
/*      */     final ServerCookieDecoder cookieDecoder;
/*      */     
/*      */     final ServerCookieEncoder cookieEncoder;
/*      */     
/*      */     final HttpServerFormDecoderProvider formDecoderProvider;
/*      */     
/*      */     final BiFunction<ConnectionInfo, HttpRequest, ConnectionInfo> forwardedHeaderHandler;
/*      */     
/*      */     final Http2FrameCodec http2FrameCodec;
/*      */     
/*      */     final HttpMessageLogFactory httpMessageLogFactory;
/*      */     
/*      */     final ConnectionObserver listener;
/*      */     
/*      */     final BiFunction<? super Mono<Void>, ? super Connection, ? extends Mono<Void>> mapHandle;
/*      */     
/*      */     final Long maxStreams;
/*      */     
/*      */     final ChannelMetricsRecorder metricsRecorder;
/*      */     
/*      */     final int minCompressionSize;
/*      */     
/*      */     final ChannelOperations.OnSetup opsFactory;
/*      */     
/*      */     final Function<String, String> uriTagValue;
/*      */ 
/*      */     
/*      */     Http11OrH2CleartextCodec(boolean accessLogEnabled, @Nullable Function<AccessLogArgProvider, AccessLog> accessLog, @Nullable BiPredicate<HttpServerRequest, HttpServerResponse> compressPredicate, ServerCookieDecoder cookieDecoder, ServerCookieEncoder cookieEncoder, boolean debug, boolean enableGracefulShutdown, HttpServerFormDecoderProvider formDecoderProvider, @Nullable BiFunction<ConnectionInfo, HttpRequest, ConnectionInfo> forwardedHeaderHandler, @Nullable Http2SettingsSpec http2SettingsSpec, HttpMessageLogFactory httpMessageLogFactory, ConnectionObserver listener, @Nullable BiFunction<? super Mono<Void>, ? super Connection, ? extends Mono<Void>> mapHandle, @Nullable ChannelMetricsRecorder metricsRecorder, int minCompressionSize, ChannelOperations.OnSetup opsFactory, @Nullable Function<String, String> uriTagValue, boolean validate) {
/*  921 */       this.accessLogEnabled = accessLogEnabled;
/*  922 */       this.accessLog = accessLog;
/*  923 */       this.compressPredicate = compressPredicate;
/*  924 */       this.cookieDecoder = cookieDecoder;
/*  925 */       this.cookieEncoder = cookieEncoder;
/*  926 */       this.formDecoderProvider = formDecoderProvider;
/*  927 */       this.forwardedHeaderHandler = forwardedHeaderHandler;
/*      */ 
/*      */ 
/*      */       
/*  931 */       Http2FrameCodecBuilder http2FrameCodecBuilder = Http2FrameCodecBuilder.forServer().validateHeaders(validate).initialSettings(HttpServerConfig.http2Settings(http2SettingsSpec));
/*      */       
/*  933 */       this.maxStreams = (http2SettingsSpec != null) ? http2SettingsSpec.maxStreams() : null;
/*  934 */       if (enableGracefulShutdown || this.maxStreams != null)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  941 */         http2FrameCodecBuilder.gracefulShutdownTimeoutMillis(-1L);
/*      */       }
/*      */       
/*  944 */       if (debug) {
/*  945 */         http2FrameCodecBuilder.frameLogger(new Http2FrameLogger(LogLevel.DEBUG, "reactor.netty.http.server.h2"));
/*      */       }
/*      */ 
/*      */       
/*  949 */       this.http2FrameCodec = http2FrameCodecBuilder.build();
/*  950 */       this.httpMessageLogFactory = httpMessageLogFactory;
/*  951 */       this.listener = listener;
/*  952 */       this.mapHandle = mapHandle;
/*  953 */       this.metricsRecorder = metricsRecorder;
/*  954 */       this.minCompressionSize = minCompressionSize;
/*  955 */       this.opsFactory = opsFactory;
/*  956 */       this.uriTagValue = uriTagValue;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected void initChannel(Channel ch) {
/*  964 */       ch.pipeline().remove((ChannelHandler)this);
/*  965 */       HttpServerConfig.addStreamHandlers(ch, this.accessLogEnabled, this.accessLog, this.compressPredicate, this.cookieDecoder, this.cookieEncoder, this.formDecoderProvider, this.forwardedHeaderHandler, this.httpMessageLogFactory, this.listener, this.mapHandle, this.metricsRecorder, this.minCompressionSize, this.opsFactory, this.uriTagValue);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     public HttpServerUpgradeHandler.UpgradeCodec newUpgradeCodec(CharSequence protocol) {
/*  973 */       if (AsciiString.contentEquals(Http2CodecUtil.HTTP_UPGRADE_PROTOCOL_NAME, protocol)) {
/*  974 */         return (HttpServerUpgradeHandler.UpgradeCodec)new Http2ServerUpgradeCodec(this.http2FrameCodec, new ChannelHandler[] { (ChannelHandler)new HttpServerConfig.H2CleartextCodec(this, false, false, this.maxStreams) });
/*      */       }
/*      */       
/*  977 */       return null;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   static final class H2ConnectionListener
/*      */     extends Http2ConnectionAdapter
/*      */   {
/*      */     final Channel channel;
/*      */     final long maxStreams;
/*      */     long numStreams;
/*      */     
/*      */     H2ConnectionListener(Channel channel, long maxStreams) {
/*  990 */       this.channel = channel;
/*  991 */       this.maxStreams = maxStreams;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void onStreamActive(Http2Stream stream) {
/*  997 */       assert this.channel.eventLoop().inEventLoop();
/*  998 */       if (++this.numStreams == this.maxStreams)
/*      */       {
/* 1000 */         this.channel.close();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   static final class H2OrHttp11Codec
/*      */     extends ApplicationProtocolNegotiationHandler
/*      */   {
/*      */     final boolean accessLogEnabled;
/*      */     final Function<AccessLogArgProvider, AccessLog> accessLog;
/*      */     final BiPredicate<HttpServerRequest, HttpServerResponse> compressPredicate;
/*      */     final ServerCookieDecoder cookieDecoder;
/*      */     final ServerCookieEncoder cookieEncoder;
/*      */     final HttpRequestDecoderSpec decoder;
/*      */     final boolean enableGracefulShutdown;
/*      */     final HttpServerFormDecoderProvider formDecoderProvider;
/*      */     final BiFunction<ConnectionInfo, HttpRequest, ConnectionInfo> forwardedHeaderHandler;
/*      */     final Http2SettingsSpec http2SettingsSpec;
/*      */     final HttpMessageLogFactory httpMessageLogFactory;
/*      */     final Duration idleTimeout;
/*      */     final ConnectionObserver listener;
/*      */     final BiFunction<? super Mono<Void>, ? super Connection, ? extends Mono<Void>> mapHandle;
/*      */     final int maxKeepAliveRequests;
/*      */     final ChannelMetricsRecorder metricsRecorder;
/*      */     final int minCompressionSize;
/*      */     final ChannelOperations.OnSetup opsFactory;
/*      */     final Function<String, String> uriTagValue;
/*      */     
/*      */     H2OrHttp11Codec(HttpServerConfig.HttpServerChannelInitializer initializer, ConnectionObserver listener) {
/* 1029 */       super("http/1.1");
/* 1030 */       this.accessLogEnabled = initializer.accessLogEnabled;
/* 1031 */       this.accessLog = initializer.accessLog;
/* 1032 */       this.compressPredicate = HttpServerConfig.compressPredicate(initializer.compressPredicate, initializer.minCompressionSize);
/* 1033 */       this.cookieDecoder = initializer.cookieDecoder;
/* 1034 */       this.cookieEncoder = initializer.cookieEncoder;
/* 1035 */       this.decoder = initializer.decoder;
/* 1036 */       this.enableGracefulShutdown = initializer.enableGracefulShutdown;
/* 1037 */       this.formDecoderProvider = initializer.formDecoderProvider;
/* 1038 */       this.forwardedHeaderHandler = initializer.forwardedHeaderHandler;
/* 1039 */       this.http2SettingsSpec = initializer.http2SettingsSpec;
/* 1040 */       this.httpMessageLogFactory = initializer.httpMessageLogFactory;
/* 1041 */       this.idleTimeout = initializer.idleTimeout;
/* 1042 */       this.listener = listener;
/* 1043 */       this.mapHandle = initializer.mapHandle;
/* 1044 */       this.maxKeepAliveRequests = initializer.maxKeepAliveRequests;
/* 1045 */       this.metricsRecorder = initializer.metricsRecorder;
/* 1046 */       this.minCompressionSize = initializer.minCompressionSize;
/* 1047 */       this.opsFactory = initializer.opsFactory;
/* 1048 */       this.uriTagValue = initializer.uriTagValue;
/*      */     }
/*      */ 
/*      */     
/*      */     protected void configurePipeline(ChannelHandlerContext ctx, String protocol) {
/* 1053 */       if (HttpServerConfig.log.isDebugEnabled()) {
/* 1054 */         HttpServerConfig.log.debug(ReactorNetty.format(ctx.channel(), "Negotiated application-level protocol [" + protocol + "]"));
/*      */       }
/*      */       
/* 1057 */       ChannelPipeline p = ctx.pipeline();
/*      */       
/* 1059 */       if ("h2".equals(protocol)) {
/* 1060 */         HttpServerConfig.configureH2Pipeline(p, this.accessLogEnabled, this.accessLog, this.compressPredicate, this.cookieDecoder, this.cookieEncoder, this.enableGracefulShutdown, this.formDecoderProvider, this.forwardedHeaderHandler, this.http2SettingsSpec, this.httpMessageLogFactory, this.idleTimeout, this.listener, this.mapHandle, this.metricsRecorder, this.minCompressionSize, this.opsFactory, this.uriTagValue, this.decoder
/*      */             
/* 1062 */             .validateHeaders());
/*      */         
/*      */         return;
/*      */       } 
/* 1066 */       if ("http/1.1".equals(protocol)) {
/* 1067 */         HttpServerConfig.configureHttp11Pipeline(p, this.accessLogEnabled, this.accessLog, this.compressPredicate, this.cookieDecoder, this.cookieEncoder, this.decoder, this.formDecoderProvider, this.forwardedHeaderHandler, this.httpMessageLogFactory, this.idleTimeout, this.listener, this.mapHandle, this.maxKeepAliveRequests, this.metricsRecorder, this.minCompressionSize, this.uriTagValue);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1074 */         IdleTimeoutHandler.addIdleTimeoutHandler(ctx.pipeline(), this.idleTimeout);
/*      */         
/*      */         return;
/*      */       } 
/* 1078 */       throw new IllegalStateException("unknown protocol: " + protocol);
/*      */     }
/*      */   }
/*      */   
/*      */   static final class HttpServerChannelInitializer
/*      */     implements ChannelPipelineConfigurer
/*      */   {
/*      */     final boolean accessLogEnabled;
/*      */     final Function<AccessLogArgProvider, AccessLog> accessLog;
/*      */     final BiPredicate<HttpServerRequest, HttpServerResponse> compressPredicate;
/*      */     final ServerCookieDecoder cookieDecoder;
/*      */     final ServerCookieEncoder cookieEncoder;
/*      */     final HttpRequestDecoderSpec decoder;
/*      */     final boolean enableGracefulShutdown;
/*      */     final HttpServerFormDecoderProvider formDecoderProvider;
/*      */     final BiFunction<ConnectionInfo, HttpRequest, ConnectionInfo> forwardedHeaderHandler;
/*      */     final Http2SettingsSpec http2SettingsSpec;
/*      */     final HttpMessageLogFactory httpMessageLogFactory;
/*      */     final Duration idleTimeout;
/*      */     final BiFunction<? super Mono<Void>, ? super Connection, ? extends Mono<Void>> mapHandle;
/*      */     final int maxKeepAliveRequests;
/*      */     final ChannelMetricsRecorder metricsRecorder;
/*      */     final int minCompressionSize;
/*      */     final ChannelOperations.OnSetup opsFactory;
/*      */     final int protocols;
/*      */     final ProxyProtocolSupportType proxyProtocolSupportType;
/*      */     final boolean redirectHttpToHttps;
/*      */     final SslProvider sslProvider;
/*      */     final Function<String, String> uriTagValue;
/*      */     
/*      */     HttpServerChannelInitializer(HttpServerConfig config) {
/* 1109 */       this.accessLogEnabled = config.accessLogEnabled;
/* 1110 */       this.accessLog = config.accessLog;
/* 1111 */       this.compressPredicate = config.compressPredicate;
/* 1112 */       this.cookieDecoder = config.cookieDecoder;
/* 1113 */       this.cookieEncoder = config.cookieEncoder;
/* 1114 */       this.decoder = config.decoder;
/* 1115 */       this.enableGracefulShutdown = (config.channelGroup() != null);
/* 1116 */       this.formDecoderProvider = config.formDecoderProvider;
/* 1117 */       this.forwardedHeaderHandler = config.forwardedHeaderHandler;
/* 1118 */       this.http2SettingsSpec = config.http2Settings;
/* 1119 */       this.httpMessageLogFactory = config.httpMessageLogFactory;
/* 1120 */       this.idleTimeout = config.idleTimeout;
/* 1121 */       this.mapHandle = config.mapHandle;
/* 1122 */       this.maxKeepAliveRequests = config.maxKeepAliveRequests;
/* 1123 */       this.metricsRecorder = config.metricsRecorderInternal();
/* 1124 */       this.minCompressionSize = config.minCompressionSize;
/* 1125 */       this.opsFactory = config.channelOperationsProvider();
/* 1126 */       this.protocols = config._protocols;
/* 1127 */       this.proxyProtocolSupportType = config.proxyProtocolSupportType;
/* 1128 */       this.redirectHttpToHttps = config.redirectHttpToHttps;
/* 1129 */       this.sslProvider = config.sslProvider;
/* 1130 */       this.uriTagValue = config.uriTagValue;
/*      */     }
/*      */ 
/*      */     
/*      */     public void onChannelInit(ConnectionObserver observer, Channel channel, @Nullable SocketAddress remoteAddress) {
/* 1135 */       boolean needRead = false;
/*      */       
/* 1137 */       if (this.sslProvider != null) {
/* 1138 */         ChannelPipeline pipeline = channel.pipeline();
/* 1139 */         if (this.redirectHttpToHttps && (this.protocols & 0x2) != 2) {
/* 1140 */           NonSslRedirectDetector nonSslRedirectDetector = new NonSslRedirectDetector(this.sslProvider, remoteAddress, HttpServerConfig.SSL_DEBUG);
/*      */ 
/*      */           
/* 1143 */           pipeline.addFirst("reactor.left.nonSslRedirectDetector", (ChannelHandler)nonSslRedirectDetector);
/*      */         } else {
/*      */           
/* 1146 */           this.sslProvider.addSslHandler(channel, remoteAddress, HttpServerConfig.SSL_DEBUG);
/*      */         } 
/*      */         
/* 1149 */         if ((this.protocols & 0x6) == 6) {
/* 1150 */           channel.pipeline()
/* 1151 */             .addBefore("reactor.right.reactiveBridge", "reactor.left.h2OrHttp11Codec", (ChannelHandler)new HttpServerConfig.H2OrHttp11Codec(this, observer));
/*      */ 
/*      */         
/*      */         }
/* 1155 */         else if ((this.protocols & 0x4) == 4) {
/* 1156 */           HttpServerConfig.configureHttp11Pipeline(channel
/* 1157 */               .pipeline(), this.accessLogEnabled, this.accessLog, 
/*      */ 
/*      */               
/* 1160 */               HttpServerConfig.compressPredicate(this.compressPredicate, this.minCompressionSize), this.cookieDecoder, this.cookieEncoder, this.decoder, this.formDecoderProvider, this.forwardedHeaderHandler, this.httpMessageLogFactory, this.idleTimeout, observer, this.mapHandle, this.maxKeepAliveRequests, this.metricsRecorder, this.minCompressionSize, this.uriTagValue);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         }
/* 1175 */         else if ((this.protocols & 0x2) == 2) {
/* 1176 */           HttpServerConfig.configureH2Pipeline(channel
/* 1177 */               .pipeline(), this.accessLogEnabled, this.accessLog, 
/*      */ 
/*      */               
/* 1180 */               HttpServerConfig.compressPredicate(this.compressPredicate, this.minCompressionSize), this.cookieDecoder, this.cookieEncoder, this.enableGracefulShutdown, this.formDecoderProvider, this.forwardedHeaderHandler, this.http2SettingsSpec, this.httpMessageLogFactory, this.idleTimeout, observer, this.mapHandle, this.metricsRecorder, this.minCompressionSize, this.opsFactory, this.uriTagValue, this.decoder
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 1195 */               .validateHeaders());
/*      */         }
/*      */       
/*      */       }
/* 1199 */       else if ((this.protocols & 0x5) == 5) {
/* 1200 */         HttpServerConfig.configureHttp11OrH2CleartextPipeline(channel
/* 1201 */             .pipeline(), this.accessLogEnabled, this.accessLog, 
/*      */ 
/*      */             
/* 1204 */             HttpServerConfig.compressPredicate(this.compressPredicate, this.minCompressionSize), this.cookieDecoder, this.cookieEncoder, this.decoder, this.enableGracefulShutdown, this.formDecoderProvider, this.forwardedHeaderHandler, this.http2SettingsSpec, this.httpMessageLogFactory, this.idleTimeout, observer, this.mapHandle, this.maxKeepAliveRequests, this.metricsRecorder, this.minCompressionSize, this.opsFactory, this.uriTagValue);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/* 1222 */       else if ((this.protocols & 0x4) == 4) {
/* 1223 */         HttpServerConfig.configureHttp11Pipeline(channel
/* 1224 */             .pipeline(), this.accessLogEnabled, this.accessLog, 
/*      */ 
/*      */             
/* 1227 */             HttpServerConfig.compressPredicate(this.compressPredicate, this.minCompressionSize), this.cookieDecoder, this.cookieEncoder, this.decoder, this.formDecoderProvider, this.forwardedHeaderHandler, this.httpMessageLogFactory, this.idleTimeout, observer, this.mapHandle, this.maxKeepAliveRequests, this.metricsRecorder, this.minCompressionSize, this.uriTagValue);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/* 1242 */       else if ((this.protocols & 0x1) == 1) {
/* 1243 */         HttpServerConfig.configureH2Pipeline(channel
/* 1244 */             .pipeline(), this.accessLogEnabled, this.accessLog, 
/*      */ 
/*      */             
/* 1247 */             HttpServerConfig.compressPredicate(this.compressPredicate, this.minCompressionSize), this.cookieDecoder, this.cookieEncoder, this.enableGracefulShutdown, this.formDecoderProvider, this.forwardedHeaderHandler, this.http2SettingsSpec, this.httpMessageLogFactory, this.idleTimeout, observer, this.mapHandle, this.metricsRecorder, this.minCompressionSize, this.opsFactory, this.uriTagValue, this.decoder
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1262 */             .validateHeaders());
/* 1263 */         needRead = true;
/*      */       } 
/*      */ 
/*      */       
/* 1267 */       if (this.proxyProtocolSupportType == ProxyProtocolSupportType.ON) {
/* 1268 */         channel.pipeline()
/* 1269 */           .addFirst("reactor.left.proxyProtocolDecoder", (ChannelHandler)new HAProxyMessageDecoder())
/* 1270 */           .addAfter("reactor.left.proxyProtocolDecoder", "reactor.left.proxyProtocolReader", (ChannelHandler)new HAProxyMessageReader());
/*      */ 
/*      */       
/*      */       }
/* 1274 */       else if (this.proxyProtocolSupportType == ProxyProtocolSupportType.AUTO) {
/* 1275 */         channel.pipeline()
/* 1276 */           .addFirst("reactor.left.proxyProtocolDecoder", (ChannelHandler)new HAProxyMessageDetector());
/*      */       } 
/*      */       
/* 1279 */       if (needRead)
/* 1280 */         channel.read(); 
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\server\HttpServerConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */