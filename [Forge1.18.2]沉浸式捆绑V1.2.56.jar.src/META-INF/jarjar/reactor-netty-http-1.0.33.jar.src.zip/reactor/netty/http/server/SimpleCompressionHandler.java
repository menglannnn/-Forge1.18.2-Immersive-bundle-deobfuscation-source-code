/*    */ package reactor.netty.http.server;
/*    */ 
/*    */ import io.netty.buffer.ByteBuf;
/*    */ import io.netty.channel.ChannelHandlerContext;
/*    */ import io.netty.channel.ChannelPromise;
/*    */ import io.netty.handler.codec.DecoderException;
/*    */ import io.netty.handler.codec.http.DefaultHttpContent;
/*    */ import io.netty.handler.codec.http.DefaultHttpRequest;
/*    */ import io.netty.handler.codec.http.FullHttpRequest;
/*    */ import io.netty.handler.codec.http.HttpContentCompressor;
/*    */ import io.netty.handler.codec.http.HttpRequest;
/*    */ import io.netty.util.ReferenceCountUtil;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class SimpleCompressionHandler
/*    */   extends HttpContentCompressor
/*    */ {
/*    */   public void write(ChannelHandlerContext ctx, Object msg, ChannelPromise promise) throws Exception {
/* 41 */     if (msg instanceof ByteBuf) {
/* 42 */       super.write(ctx, new DefaultHttpContent((ByteBuf)msg), promise);
/*    */     } else {
/*    */       
/* 45 */       super.write(ctx, msg, promise);
/*    */     } 
/*    */   }
/*    */   void decode(ChannelHandlerContext ctx, HttpRequest msg) {
/*    */     DefaultHttpRequest defaultHttpRequest;
/* 50 */     List<Object> out = new ArrayList();
/* 51 */     HttpRequest request = msg;
/*    */     try {
/* 53 */       if (msg instanceof FullHttpRequest && ((FullHttpRequest)msg).content().refCnt() == 0)
/*    */       {
/*    */ 
/*    */         
/* 57 */         defaultHttpRequest = new DefaultHttpRequest(msg.protocolVersion(), msg.method(), msg.uri(), msg.headers());
/*    */       }
/* 59 */       decode(ctx, (HttpRequest)defaultHttpRequest, out);
/*    */     }
/* 61 */     catch (DecoderException e) {
/* 62 */       throw e;
/*    */     }
/* 64 */     catch (Exception e) {
/* 65 */       throw new DecoderException(e);
/*    */     }
/*    */     finally {
/*    */       
/* 69 */       ReferenceCountUtil.release(defaultHttpRequest);
/* 70 */       out.clear();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\server\SimpleCompressionHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */