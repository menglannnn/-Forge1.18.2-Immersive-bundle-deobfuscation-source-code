package reactor.netty.http.server;

import java.net.SocketAddress;
import java.time.Duration;
import reactor.netty.http.HttpMetricsRecorder;

public interface HttpServerMetricsRecorder extends HttpMetricsRecorder {
  void recordDataReceivedTime(String paramString1, String paramString2, Duration paramDuration);
  
  void recordDataSentTime(String paramString1, String paramString2, String paramString3, Duration paramDuration);
  
  void recordResponseTime(String paramString1, String paramString2, String paramString3, Duration paramDuration);
  
  default void recordServerConnectionActive(SocketAddress localAddress) {}
  
  default void recordServerConnectionInactive(SocketAddress localAddress) {}
  
  default void recordStreamOpened(SocketAddress localAddress) {}
  
  default void recordStreamClosed(SocketAddress localAddress) {}
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\server\HttpServerMetricsRecorder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */