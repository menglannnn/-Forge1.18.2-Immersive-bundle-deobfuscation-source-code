/*     */ package reactor.netty.http.server;
/*     */ 
/*     */ import io.netty.handler.codec.http.HttpMethod;
/*     */ import io.netty.handler.codec.http.HttpVersion;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Predicate;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import reactor.netty.internal.util.MapUtils;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class HttpPredicate
/*     */   implements Predicate<HttpServerRequest>, Function<Object, Map<String, String>>
/*     */ {
/*     */   final HttpVersion protocol;
/*     */   final HttpMethod method;
/*     */   final String uri;
/*     */   final UriPathTemplate template;
/*     */   
/*     */   public static Predicate<HttpServerRequest> delete(String uri) {
/*  56 */     return http(uri, null, HttpMethod.DELETE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Predicate<HttpServerRequest> get(String uri) {
/*  73 */     return http(uri, null, HttpMethod.GET);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Predicate<HttpServerRequest> head(String uri) {
/*  90 */     return http(uri, null, HttpMethod.HEAD);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Predicate<HttpServerRequest> http(String uri, @Nullable HttpVersion protocol, HttpMethod method) {
/* 106 */     return new HttpPredicate(uri, protocol, method);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Predicate<HttpServerRequest> options(String uri) {
/* 123 */     return http(uri, null, HttpMethod.OPTIONS);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Predicate<HttpServerRequest> post(String uri) {
/* 140 */     return http(uri, null, HttpMethod.POST);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Predicate<HttpServerRequest> prefix(String prefix) {
/* 156 */     return prefix(prefix, HttpMethod.GET);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Predicate<HttpServerRequest> prefix(String prefix, HttpMethod method) {
/* 172 */     Objects.requireNonNull(prefix, "Prefix must be provided");
/* 173 */     Objects.requireNonNull(method, "method");
/*     */     
/* 175 */     String target = prefix.startsWith("/") ? prefix : "/".concat(prefix);
/*     */     
/* 177 */     return new HttpPrefixPredicate(target, method);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Predicate<HttpServerRequest> put(String uri) {
/* 194 */     return http(uri, null, HttpMethod.PUT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpPredicate(String uri, @Nullable HttpVersion protocol, HttpMethod method) {
/* 205 */     this.protocol = protocol;
/* 206 */     this.uri = Objects.<String>requireNonNull(uri, "uri");
/* 207 */     this.method = Objects.<HttpMethod>requireNonNull(method, "method");
/* 208 */     this.template = new UriPathTemplate(uri);
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, String> apply(Object key) {
/* 213 */     Map<String, String> headers = this.template.match(key.toString());
/* 214 */     if (null != headers && !headers.isEmpty()) {
/* 215 */       return headers;
/*     */     }
/* 217 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean test(HttpServerRequest key) {
/* 222 */     return ((this.protocol == null || this.protocol.equals(key.version())) && this.method.equals(key.method()) && this.template
/* 223 */       .matches(key.uri()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class UriPathTemplate
/*     */   {
/* 239 */     private static final Pattern FULL_SPLAT_PATTERN = Pattern.compile("[\\*][\\*]");
/*     */     
/*     */     private static final String FULL_SPLAT_REPLACEMENT = ".*";
/*     */     
/* 243 */     private static final Pattern NAME_SPLAT_PATTERN = Pattern.compile("\\{([^/]+?)\\}[\\*][\\*]");
/*     */     
/* 245 */     private static final Pattern NAME_PATTERN = Pattern.compile("\\{([^/]+?)\\}");
/*     */ 
/*     */ 
/*     */     
/* 249 */     private static final Pattern URL_PATTERN = Pattern.compile("(?:(\\w+)://)?((?:\\[.+?])|(?<!\\[)(?:[^/?]+?))(?::(\\d{2,5}))?([/?].*)?");
/*     */     
/* 251 */     private final List<String> pathVariables = new ArrayList<>();
/*     */     
/*     */     private final Pattern uriPattern;
/*     */     
/*     */     private static String getNameSplatReplacement(String name) {
/* 256 */       return "(?<" + name + ">.*)";
/*     */     }
/*     */     
/*     */     private static String getNameReplacement(String name) {
/* 260 */       return "(?<" + name + ">[^\\/]*)";
/*     */     }
/*     */     
/*     */     static String filterQueryParams(String uri) {
/* 264 */       int hasQuery = uri.lastIndexOf('?');
/* 265 */       if (hasQuery != -1) {
/* 266 */         return uri.substring(0, hasQuery);
/*     */       }
/*     */       
/* 269 */       return uri;
/*     */     }
/*     */ 
/*     */     
/*     */     static String filterHostAndPort(String uri) {
/* 274 */       if (uri.startsWith("/")) {
/* 275 */         return uri;
/*     */       }
/*     */       
/* 278 */       Matcher matcher = URL_PATTERN.matcher(uri);
/* 279 */       if (matcher.matches()) {
/* 280 */         String path = matcher.group(4);
/* 281 */         return (path == null) ? "/" : path;
/*     */       } 
/*     */       
/* 284 */       throw new IllegalArgumentException("Unable to parse url [" + uri + "]");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     UriPathTemplate(String uriPattern) {
/* 295 */       String s = "^" + filterQueryParams(filterHostAndPort(uriPattern));
/*     */       
/* 297 */       Matcher m = NAME_SPLAT_PATTERN.matcher(s);
/* 298 */       while (m.find()) {
/* 299 */         for (int i = 1; i <= m.groupCount(); i++) {
/* 300 */           String name = m.group(i);
/* 301 */           this.pathVariables.add(name);
/* 302 */           s = m.replaceFirst(getNameSplatReplacement(name));
/* 303 */           m.reset(s);
/*     */         } 
/*     */       } 
/*     */       
/* 307 */       m = NAME_PATTERN.matcher(s);
/* 308 */       while (m.find()) {
/* 309 */         for (int i = 1; i <= m.groupCount(); i++) {
/* 310 */           String name = m.group(i);
/* 311 */           this.pathVariables.add(name);
/* 312 */           s = m.replaceFirst(getNameReplacement(name));
/* 313 */           m.reset(s);
/*     */         } 
/*     */       } 
/*     */       
/* 317 */       m = FULL_SPLAT_PATTERN.matcher(s);
/* 318 */       while (m.find()) {
/* 319 */         s = m.replaceAll(".*");
/* 320 */         m.reset(s);
/*     */       } 
/*     */       
/* 323 */       this.uriPattern = Pattern.compile(s + "$");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean matches(String uri) {
/* 335 */       return matcher(uri).matches();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     final Map<String, String> match(String uri) {
/* 348 */       Map<String, String> pathParameters = new HashMap<>(MapUtils.calculateInitialCapacity(this.pathVariables.size()));
/*     */       
/* 350 */       Matcher m = matcher(uri);
/* 351 */       if (m.matches()) {
/* 352 */         int i = 1;
/* 353 */         for (String name : this.pathVariables) {
/* 354 */           String val = m.group(i++);
/* 355 */           pathParameters.put(name, val);
/*     */         } 
/*     */       } 
/* 358 */       return pathParameters;
/*     */     }
/*     */     
/*     */     private Matcher matcher(String uri) {
/* 362 */       uri = filterQueryParams(filterHostAndPort(uri));
/* 363 */       return this.uriPattern.matcher(uri);
/*     */     }
/*     */   }
/*     */   
/*     */   static final class HttpPrefixPredicate
/*     */     implements Predicate<HttpServerRequest>
/*     */   {
/*     */     final HttpMethod method;
/*     */     final String prefix;
/*     */     
/*     */     public HttpPrefixPredicate(String prefix, HttpMethod method) {
/* 374 */       this.prefix = prefix;
/* 375 */       this.method = method;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean test(HttpServerRequest key) {
/* 380 */       return (this.method.equals(key.method()) && key.uri().startsWith(this.prefix));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\server\HttpPredicate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */