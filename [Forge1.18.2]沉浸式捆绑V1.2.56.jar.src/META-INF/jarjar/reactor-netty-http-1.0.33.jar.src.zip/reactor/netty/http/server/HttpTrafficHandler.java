/*     */ package reactor.netty.http.server;
/*     */ 
/*     */ import io.netty.channel.ChannelDuplexHandler;
/*     */ import io.netty.channel.ChannelFuture;
/*     */ import io.netty.channel.ChannelFutureListener;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.channel.ChannelPromise;
/*     */ import io.netty.handler.codec.DecoderResult;
/*     */ import io.netty.handler.codec.DecoderResultProvider;
/*     */ import io.netty.handler.codec.http.HttpHeaderNames;
/*     */ import io.netty.handler.codec.http.HttpMessage;
/*     */ import io.netty.handler.codec.http.HttpRequest;
/*     */ import io.netty.handler.codec.http.HttpResponse;
/*     */ import io.netty.handler.codec.http.HttpResponseStatus;
/*     */ import io.netty.handler.codec.http.HttpStatusClass;
/*     */ import io.netty.handler.codec.http.HttpUtil;
/*     */ import io.netty.handler.codec.http.HttpVersion;
/*     */ import io.netty.handler.codec.http.LastHttpContent;
/*     */ import io.netty.handler.codec.http.cookie.ServerCookieDecoder;
/*     */ import io.netty.handler.codec.http.cookie.ServerCookieEncoder;
/*     */ import io.netty.handler.ssl.SslHandler;
/*     */ import io.netty.util.ReferenceCountUtil;
/*     */ import io.netty.util.concurrent.Future;
/*     */ import io.netty.util.concurrent.GenericFutureListener;
/*     */ import java.net.SocketAddress;
/*     */ import java.time.Duration;
/*     */ import java.time.ZonedDateTime;
/*     */ import java.util.Optional;
/*     */ import java.util.Queue;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.BiPredicate;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.netty.Connection;
/*     */ import reactor.netty.ConnectionObserver;
/*     */ import reactor.netty.ReactorNetty;
/*     */ import reactor.netty.http.logging.HttpMessageArgProviderFactory;
/*     */ import reactor.netty.http.logging.HttpMessageLogFactory;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.concurrent.Queues;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class HttpTrafficHandler
/*     */   extends ChannelDuplexHandler
/*     */   implements Runnable, ChannelFutureListener
/*     */ {
/*     */   static final String MULTIPART_PREFIX = "multipart";
/*  70 */   static final HttpVersion H2 = HttpVersion.valueOf("HTTP/2.0");
/*     */   
/*     */   final BiPredicate<HttpServerRequest, HttpServerResponse> compress;
/*     */   
/*     */   final ServerCookieDecoder cookieDecoder;
/*     */   
/*     */   final ServerCookieEncoder cookieEncoder;
/*     */   
/*     */   final HttpServerFormDecoderProvider formDecoderProvider;
/*     */   
/*     */   final BiFunction<ConnectionInfo, HttpRequest, ConnectionInfo> forwardedHeaderHandler;
/*     */   
/*     */   final HttpMessageLogFactory httpMessageLogFactory;
/*     */   
/*     */   final Duration idleTimeout;
/*     */   
/*     */   final ConnectionObserver listener;
/*     */   
/*     */   final BiFunction<? super Mono<Void>, ? super Connection, ? extends Mono<Void>> mapHandle;
/*     */   
/*     */   final int maxKeepAliveRequests;
/*     */   
/*     */   ChannelHandlerContext ctx;
/*     */   
/*     */   boolean nonInformationalResponse;
/*     */   
/*     */   boolean overflow;
/*     */   
/*     */   int pendingResponses;
/*     */   
/*     */   boolean persistentConnection = true;
/*     */   
/*     */   Queue<Object> pipelined;
/*     */   
/*     */   SocketAddress remoteAddress;
/*     */   
/*     */   Boolean secure;
/*     */ 
/*     */   
/*     */   HttpTrafficHandler(@Nullable BiPredicate<HttpServerRequest, HttpServerResponse> compress, ServerCookieDecoder decoder, ServerCookieEncoder encoder, HttpServerFormDecoderProvider formDecoderProvider, @Nullable BiFunction<ConnectionInfo, HttpRequest, ConnectionInfo> forwardedHeaderHandler, HttpMessageLogFactory httpMessageLogFactory, @Nullable Duration idleTimeout, ConnectionObserver listener, @Nullable BiFunction<? super Mono<Void>, ? super Connection, ? extends Mono<Void>> mapHandle, int maxKeepAliveRequests) {
/* 110 */     this.listener = listener;
/* 111 */     this.formDecoderProvider = formDecoderProvider;
/* 112 */     this.forwardedHeaderHandler = forwardedHeaderHandler;
/* 113 */     this.compress = compress;
/* 114 */     this.cookieEncoder = encoder;
/* 115 */     this.cookieDecoder = decoder;
/* 116 */     this.httpMessageLogFactory = httpMessageLogFactory;
/* 117 */     this.idleTimeout = idleTimeout;
/* 118 */     this.mapHandle = mapHandle;
/* 119 */     this.maxKeepAliveRequests = maxKeepAliveRequests;
/*     */   }
/*     */ 
/*     */   
/*     */   public void handlerAdded(ChannelHandlerContext ctx) throws Exception {
/* 124 */     super.handlerAdded(ctx);
/* 125 */     this.ctx = ctx;
/* 126 */     if (HttpServerOperations.log.isDebugEnabled()) {
/* 127 */       HttpServerOperations.log.debug(ReactorNetty.format(ctx.channel(), "New http connection, requesting read"));
/*     */     }
/* 129 */     ctx.read();
/*     */   }
/*     */ 
/*     */   
/*     */   public void channelActive(ChannelHandlerContext ctx) {
/* 134 */     IdleTimeoutHandler.addIdleTimeoutHandler(ctx.pipeline(), this.idleTimeout);
/*     */     
/* 136 */     ctx.fireChannelActive();
/*     */   }
/*     */ 
/*     */   
/*     */   public void channelRead(ChannelHandlerContext ctx, Object msg) {
/* 141 */     if (this.secure == null) {
/* 142 */       this.secure = Boolean.valueOf((ctx.channel().pipeline().get(SslHandler.class) != null));
/*     */     }
/* 144 */     if (this.remoteAddress == null) {
/* 145 */       this
/*     */         
/* 147 */         .remoteAddress = Optional.<SocketAddress>ofNullable(HAProxyMessageReader.resolveRemoteAddressFromProxyProtocol(ctx.channel())).orElse(ctx.channel().remoteAddress());
/*     */     }
/*     */     
/* 150 */     if (msg instanceof HttpRequest) {
/* 151 */       HttpServerOperations ops; IdleTimeoutHandler.removeIdleTimeoutHandler(ctx.pipeline());
/*     */       
/* 153 */       HttpRequest request = (HttpRequest)msg;
/*     */       
/* 155 */       if (H2.equals(request.protocolVersion())) {
/*     */         
/* 157 */         IllegalStateException e = new IllegalStateException("Unexpected request [" + request.method() + " " + request.uri() + " HTTP/2.0]");
/* 158 */         request.setDecoderResult(DecoderResult.failure((e.getCause() != null) ? e.getCause() : e));
/* 159 */         sendDecodingFailures(e, msg);
/*     */         
/*     */         return;
/*     */       } 
/* 163 */       if (this.persistentConnection) {
/* 164 */         this.pendingResponses++;
/* 165 */         if (HttpServerOperations.log.isDebugEnabled())
/* 166 */           HttpServerOperations.log.debug(ReactorNetty.format(ctx.channel(), "Increasing pending responses, now {}"), new Object[] {
/* 167 */                 Integer.valueOf(this.pendingResponses)
/*     */               }); 
/* 169 */         this.persistentConnection = HttpUtil.isKeepAlive((HttpMessage)request);
/*     */       } else {
/*     */         
/* 172 */         if (HttpServerOperations.log.isDebugEnabled()) {
/* 173 */           HttpServerOperations.log.debug(ReactorNetty.format(ctx.channel(), "Dropping pipelined HTTP request, previous response requested connection close"));
/*     */         }
/*     */         
/* 176 */         ReferenceCountUtil.release(msg);
/*     */         return;
/*     */       } 
/* 179 */       if (this.pendingResponses > 1) {
/* 180 */         if (HttpServerOperations.log.isDebugEnabled())
/* 181 */           HttpServerOperations.log.debug(ReactorNetty.format(ctx.channel(), "Buffering pipelined HTTP request, pending response count: {}, queue: {}"), new Object[] {
/*     */                 
/* 183 */                 Integer.valueOf(this.pendingResponses), 
/* 184 */                 Integer.valueOf((this.pipelined != null) ? this.pipelined.size() : 0)
/*     */               }); 
/* 186 */         this.overflow = true;
/* 187 */         doPipeline(ctx, new HttpRequestHolder(request));
/*     */         
/*     */         return;
/*     */       } 
/* 191 */       this.overflow = false;
/*     */       
/* 193 */       DecoderResult decoderResult = request.decoderResult();
/* 194 */       if (decoderResult.isFailure()) {
/* 195 */         sendDecodingFailures(decoderResult.cause(), msg);
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/* 200 */       ZonedDateTime timestamp = ZonedDateTime.now(ReactorNetty.ZONE_ID_SYSTEM);
/* 201 */       ConnectionInfo connectionInfo = null;
/*     */       try {
/* 203 */         connectionInfo = ConnectionInfo.from(ctx.channel(), request, this.secure
/*     */             
/* 205 */             .booleanValue(), this.remoteAddress, this.forwardedHeaderHandler);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 219 */         ops = new HttpServerOperations(Connection.from(ctx.channel()), this.listener, request, this.compress, connectionInfo, this.cookieDecoder, this.cookieEncoder, this.formDecoderProvider, this.httpMessageLogFactory, false, this.mapHandle, this.secure.booleanValue(), timestamp);
/*     */       
/*     */       }
/* 222 */       catch (RuntimeException e) {
/* 223 */         request.setDecoderResult(DecoderResult.failure((e.getCause() != null) ? e.getCause() : e));
/* 224 */         sendDecodingFailures(e, msg, timestamp, connectionInfo);
/*     */         return;
/*     */       } 
/* 227 */       ops.bind();
/* 228 */       this.listener.onStateChange((Connection)ops, ConnectionObserver.State.CONFIGURED);
/*     */       
/* 230 */       ctx.fireChannelRead(msg);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 235 */     if (this.persistentConnection && this.pendingResponses == 0) {
/* 236 */       if (msg instanceof LastHttpContent) {
/* 237 */         DecoderResult decoderResult = ((LastHttpContent)msg).decoderResult();
/* 238 */         if (decoderResult.isFailure()) {
/* 239 */           sendDecodingFailures(decoderResult.cause(), msg);
/*     */           
/*     */           return;
/*     */         } 
/* 243 */         ctx.fireChannelRead(msg);
/*     */       } else {
/*     */         
/* 246 */         if (HttpServerOperations.log.isDebugEnabled())
/* 247 */           HttpServerOperations.log.debug(
/* 248 */               ReactorNetty.format(ctx.channel(), "Dropped HTTP content, since response has been sent already: {}"), new Object[] {
/* 249 */                 (msg instanceof io.netty.handler.codec.http.HttpObject) ? 
/* 250 */                 this.httpMessageLogFactory.debug(HttpMessageArgProviderFactory.create(msg)) : msg
/*     */               }); 
/* 252 */         ReferenceCountUtil.release(msg);
/*     */       } 
/* 254 */       ctx.read();
/*     */       return;
/*     */     } 
/* 257 */     if (this.overflow) {
/* 258 */       if (HttpServerOperations.log.isDebugEnabled())
/* 259 */         HttpServerOperations.log.debug(ReactorNetty.format(ctx.channel(), "Buffering pipelined HTTP content, pending response count: {}, pending pipeline:{}"), new Object[] {
/*     */               
/* 261 */               Integer.valueOf(this.pendingResponses), 
/* 262 */               Integer.valueOf((this.pipelined != null) ? this.pipelined.size() : 0)
/*     */             }); 
/* 264 */       doPipeline(ctx, msg);
/*     */       
/*     */       return;
/*     */     } 
/* 268 */     if (msg instanceof DecoderResultProvider) {
/* 269 */       DecoderResult decoderResult = ((DecoderResultProvider)msg).decoderResult();
/* 270 */       if (decoderResult.isFailure()) {
/* 271 */         sendDecodingFailures(decoderResult.cause(), msg);
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/* 276 */     ctx.fireChannelRead(msg);
/*     */   }
/*     */   
/*     */   void sendDecodingFailures(Throwable t, Object msg) {
/* 280 */     sendDecodingFailures(t, msg, null, null);
/*     */   }
/*     */   
/*     */   void sendDecodingFailures(Throwable t, Object msg, @Nullable ZonedDateTime timestamp, @Nullable ConnectionInfo connectionInfo) {
/* 284 */     this.persistentConnection = false;
/* 285 */     HttpServerOperations.sendDecodingFailures(this.ctx, this.listener, this.secure.booleanValue(), t, msg, this.httpMessageLogFactory, timestamp, connectionInfo, this.remoteAddress);
/*     */   }
/*     */ 
/*     */   
/*     */   void doPipeline(ChannelHandlerContext ctx, Object msg) {
/* 290 */     if (this.pipelined == null) {
/* 291 */       this
/* 292 */         .pipelined = Queues.unbounded().get();
/*     */     }
/* 294 */     if (!this.pipelined.offer(msg)) {
/* 295 */       ctx.fireExceptionCaught(Exceptions.failWithOverflow());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(ChannelHandlerContext ctx, Object msg, ChannelPromise promise) {
/* 303 */     if (msg instanceof HttpResponse) {
/* 304 */       HttpResponse response = (HttpResponse)msg;
/* 305 */       this.nonInformationalResponse = !isInformational(response);
/*     */       
/* 307 */       boolean maxKeepAliveRequestsReached = (this.maxKeepAliveRequests != -1 && HttpServerOperations.requestsCounter(ctx.channel()) == this.maxKeepAliveRequests);
/* 308 */       if (maxKeepAliveRequestsReached || !HttpUtil.isKeepAlive((HttpMessage)response) || !isSelfDefinedMessageLength(response)) {
/*     */         
/* 310 */         this.pendingResponses = 0;
/* 311 */         this.persistentConnection = false;
/*     */       } 
/*     */       
/* 314 */       if (!shouldKeepAlive()) {
/* 315 */         HttpUtil.setKeepAlive((HttpMessage)response, false);
/*     */       }
/*     */       
/* 318 */       if (response.status().equals(HttpResponseStatus.CONTINUE)) {
/*     */         
/* 320 */         ctx.write(msg, promise);
/*     */         return;
/*     */       } 
/*     */     } 
/* 324 */     if (msg instanceof LastHttpContent) {
/* 325 */       if (!shouldKeepAlive()) {
/* 326 */         if (HttpServerOperations.log.isDebugEnabled())
/* 327 */           HttpServerOperations.log.debug(ReactorNetty.format(ctx.channel(), "Detected non persistent http connection, preparing to close"), new Object[] {
/*     */                 
/* 329 */                 Integer.valueOf(this.pendingResponses)
/*     */               }); 
/* 331 */         ctx.write(msg, promise.unvoid())
/* 332 */           .addListener((GenericFutureListener)this)
/* 333 */           .addListener((GenericFutureListener)ChannelFutureListener.CLOSE);
/*     */         
/*     */         return;
/*     */       } 
/* 337 */       ctx.write(msg, promise.unvoid())
/* 338 */         .addListener((GenericFutureListener)this);
/*     */       
/* 340 */       if (!this.persistentConnection) {
/*     */         return;
/*     */       }
/*     */       
/* 344 */       if (this.nonInformationalResponse) {
/* 345 */         this.nonInformationalResponse = false;
/* 346 */         this.pendingResponses--;
/* 347 */         if (HttpServerOperations.log.isDebugEnabled()) {
/* 348 */           HttpServerOperations.log.debug(ReactorNetty.format(ctx.channel(), "Decreasing pending responses, now {}"), new Object[] {
/* 349 */                 Integer.valueOf(this.pendingResponses)
/*     */               });
/*     */         }
/*     */       } 
/* 353 */       if (this.pipelined != null && !this.pipelined.isEmpty()) {
/* 354 */         if (HttpServerOperations.log.isDebugEnabled())
/* 355 */           HttpServerOperations.log.debug(ReactorNetty.format(ctx.channel(), "Draining next pipelined request, pending response count: {}, queued: {}"), new Object[] {
/*     */                 
/* 357 */                 Integer.valueOf(this.pendingResponses), Integer.valueOf(this.pipelined.size())
/*     */               }); 
/* 359 */         ctx.executor()
/* 360 */           .execute(this);
/*     */       } else {
/*     */         
/* 363 */         ctx.read();
/*     */       } 
/*     */       return;
/*     */     } 
/* 367 */     if (this.persistentConnection && this.pendingResponses == 0) {
/* 368 */       if (HttpServerOperations.log.isDebugEnabled())
/* 369 */         HttpServerOperations.log.debug(
/* 370 */             ReactorNetty.format(ctx.channel(), "Dropped HTTP content, since response has been sent already: {}"), new Object[] {
/* 371 */               (msg instanceof io.netty.handler.codec.http.HttpObject) ? 
/* 372 */               this.httpMessageLogFactory.debug(HttpMessageArgProviderFactory.create(msg)) : msg
/*     */             }); 
/* 374 */       ReferenceCountUtil.release(msg);
/* 375 */       promise.setSuccess();
/*     */       
/*     */       return;
/*     */     } 
/* 379 */     ctx.write(msg, promise);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void run() {
/* 385 */     HttpRequest nextRequest = null; Object next;
/* 386 */     while ((next = this.pipelined.peek()) != null) {
/* 387 */       if (next instanceof HttpRequestHolder) {
/* 388 */         HttpServerOperations ops; if (nextRequest != null) {
/*     */           return;
/*     */         }
/* 391 */         if (!this.persistentConnection) {
/* 392 */           discard();
/*     */           
/*     */           return;
/*     */         } 
/* 396 */         HttpRequestHolder holder = (HttpRequestHolder)next;
/* 397 */         nextRequest = holder.request;
/*     */         
/* 399 */         DecoderResult decoderResult = nextRequest.decoderResult();
/* 400 */         if (decoderResult.isFailure()) {
/* 401 */           sendDecodingFailures(decoderResult.cause(), nextRequest, holder.timestamp, null);
/* 402 */           discard();
/*     */           
/*     */           return;
/*     */         } 
/*     */         
/* 407 */         ConnectionInfo connectionInfo = null;
/*     */         try {
/* 409 */           connectionInfo = ConnectionInfo.from(this.ctx.channel(), nextRequest, this.secure
/*     */               
/* 411 */               .booleanValue(), this.remoteAddress, this.forwardedHeaderHandler);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 425 */           ops = new HttpServerOperations(Connection.from(this.ctx.channel()), this.listener, nextRequest, this.compress, connectionInfo, this.cookieDecoder, this.cookieEncoder, this.formDecoderProvider, this.httpMessageLogFactory, false, this.mapHandle, this.secure.booleanValue(), holder.timestamp);
/*     */         
/*     */         }
/* 428 */         catch (RuntimeException e) {
/* 429 */           holder.request.setDecoderResult(DecoderResult.failure((e.getCause() != null) ? e.getCause() : e));
/* 430 */           sendDecodingFailures(e, holder.request, holder.timestamp, connectionInfo);
/*     */           return;
/*     */         } 
/* 433 */         ops.bind();
/* 434 */         this.listener.onStateChange((Connection)ops, ConnectionObserver.State.CONFIGURED);
/*     */         
/* 436 */         this.pipelined.poll();
/* 437 */         this.ctx.fireChannelRead(holder.request);
/*     */         continue;
/*     */       } 
/* 440 */       this.ctx.fireChannelRead(this.pipelined.poll());
/*     */     } 
/*     */     
/* 443 */     this.overflow = false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void operationComplete(ChannelFuture future) {
/* 448 */     if (!future.isSuccess()) {
/* 449 */       if (HttpServerOperations.log.isDebugEnabled()) {
/* 450 */         HttpServerOperations.log.debug(ReactorNetty.format(future.channel(), "Sending last HTTP packet was not successful, terminating the channel"), future
/*     */             
/* 452 */             .cause());
/*     */       
/*     */       }
/*     */     }
/* 456 */     else if (HttpServerOperations.log.isDebugEnabled()) {
/* 457 */       HttpServerOperations.log.debug(ReactorNetty.format(future.channel(), "Last HTTP packet was sent, terminating the channel"));
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 462 */     IdleTimeoutHandler.addIdleTimeoutHandler(future.channel().pipeline(), this.idleTimeout);
/*     */     
/* 464 */     HttpServerOperations.cleanHandlerTerminate(future.channel());
/*     */   }
/*     */ 
/*     */   
/*     */   public void handlerRemoved(ChannelHandlerContext ctx) {
/* 469 */     discard();
/*     */   }
/*     */   
/*     */   final void discard() {
/* 473 */     if (this.pipelined != null && !this.pipelined.isEmpty()) {
/*     */       Object o;
/* 475 */       while ((o = this.pipelined.poll()) != null) {
/* 476 */         ReferenceCountUtil.release(o);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   boolean shouldKeepAlive() {
/* 483 */     return (this.pendingResponses != 0 && this.persistentConnection);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean isSelfDefinedMessageLength(HttpResponse response) {
/* 498 */     return (HttpUtil.isContentLengthSet((HttpMessage)response) || HttpUtil.isTransferEncodingChunked((HttpMessage)response) || isMultipart(response) || 
/* 499 */       isInformational(response) || isNotModified(response) || isNoContent(response));
/*     */   }
/*     */   
/*     */   static boolean isInformational(HttpResponse response) {
/* 503 */     return 
/* 504 */       (response.status().codeClass() == HttpStatusClass.INFORMATIONAL);
/*     */   }
/*     */   
/*     */   static boolean isNoContent(HttpResponse response) {
/* 508 */     return (HttpResponseStatus.NO_CONTENT.code() == response.status().code());
/*     */   }
/*     */   
/*     */   static boolean isNotModified(HttpResponse response) {
/* 512 */     return (HttpResponseStatus.NOT_MODIFIED.code() == response.status().code());
/*     */   }
/*     */ 
/*     */   
/*     */   static boolean isMultipart(HttpResponse response) {
/* 517 */     String contentType = response.headers().get((CharSequence)HttpHeaderNames.CONTENT_TYPE);
/* 518 */     return (contentType != null && contentType.regionMatches(true, 0, "multipart", 0, "multipart"
/*     */ 
/*     */ 
/*     */         
/* 522 */         .length()));
/*     */   }
/*     */   
/*     */   static final class HttpRequestHolder {
/*     */     final HttpRequest request;
/*     */     final ZonedDateTime timestamp;
/*     */     
/*     */     HttpRequestHolder(HttpRequest request) {
/* 530 */       this.request = request;
/* 531 */       this.timestamp = ZonedDateTime.now(ReactorNetty.ZONE_ID_SYSTEM);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\server\HttpTrafficHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */