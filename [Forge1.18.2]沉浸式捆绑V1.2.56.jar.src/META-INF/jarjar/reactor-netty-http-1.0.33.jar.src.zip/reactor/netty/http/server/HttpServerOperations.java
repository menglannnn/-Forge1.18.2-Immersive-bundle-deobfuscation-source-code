/*      */ package reactor.netty.http.server;
/*      */ 
/*      */ import io.netty.buffer.ByteBuf;
/*      */ import io.netty.buffer.Unpooled;
/*      */ import io.netty.channel.Channel;
/*      */ import io.netty.channel.ChannelFuture;
/*      */ import io.netty.channel.ChannelFutureListener;
/*      */ import io.netty.channel.ChannelHandler;
/*      */ import io.netty.channel.ChannelHandlerContext;
/*      */ import io.netty.handler.codec.DefaultHeaders;
/*      */ import io.netty.handler.codec.http.DefaultFullHttpResponse;
/*      */ import io.netty.handler.codec.http.DefaultHttpHeaders;
/*      */ import io.netty.handler.codec.http.DefaultHttpResponse;
/*      */ import io.netty.handler.codec.http.DefaultLastHttpContent;
/*      */ import io.netty.handler.codec.http.FullHttpRequest;
/*      */ import io.netty.handler.codec.http.FullHttpResponse;
/*      */ import io.netty.handler.codec.http.HttpContent;
/*      */ import io.netty.handler.codec.http.HttpHeaderNames;
/*      */ import io.netty.handler.codec.http.HttpHeaderValues;
/*      */ import io.netty.handler.codec.http.HttpHeaders;
/*      */ import io.netty.handler.codec.http.HttpMessage;
/*      */ import io.netty.handler.codec.http.HttpMethod;
/*      */ import io.netty.handler.codec.http.HttpRequest;
/*      */ import io.netty.handler.codec.http.HttpResponse;
/*      */ import io.netty.handler.codec.http.HttpResponseStatus;
/*      */ import io.netty.handler.codec.http.HttpUtil;
/*      */ import io.netty.handler.codec.http.HttpVersion;
/*      */ import io.netty.handler.codec.http.LastHttpContent;
/*      */ import io.netty.handler.codec.http.cookie.Cookie;
/*      */ import io.netty.handler.codec.http.cookie.ServerCookieDecoder;
/*      */ import io.netty.handler.codec.http.cookie.ServerCookieEncoder;
/*      */ import io.netty.handler.codec.http.multipart.HttpData;
/*      */ import io.netty.handler.codec.http.multipart.HttpPostRequestDecoder;
/*      */ import io.netty.handler.codec.http.multipart.InterfaceHttpPostRequestDecoder;
/*      */ import io.netty.handler.codec.http.websocketx.CloseWebSocketFrame;
/*      */ import io.netty.handler.codec.http.websocketx.WebSocketCloseStatus;
/*      */ import io.netty.util.AsciiString;
/*      */ import io.netty.util.ReferenceCountUtil;
/*      */ import io.netty.util.concurrent.Future;
/*      */ import io.netty.util.concurrent.GenericFutureListener;
/*      */ import java.io.IOException;
/*      */ import java.net.InetSocketAddress;
/*      */ import java.net.SocketAddress;
/*      */ import java.nio.file.Files;
/*      */ import java.nio.file.Path;
/*      */ import java.time.ZonedDateTime;
/*      */ import java.util.HashSet;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Objects;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.atomic.AtomicLong;
/*      */ import java.util.function.BiFunction;
/*      */ import java.util.function.BiPredicate;
/*      */ import java.util.function.Consumer;
/*      */ import java.util.function.Function;
/*      */ import org.reactivestreams.Publisher;
/*      */ import org.reactivestreams.Subscriber;
/*      */ import org.reactivestreams.Subscription;
/*      */ import reactor.core.CoreSubscriber;
/*      */ import reactor.core.publisher.Flux;
/*      */ import reactor.core.publisher.Mono;
/*      */ import reactor.core.publisher.Signal;
/*      */ import reactor.core.publisher.SignalType;
/*      */ import reactor.netty.Connection;
/*      */ import reactor.netty.ConnectionObserver;
/*      */ import reactor.netty.FutureMono;
/*      */ import reactor.netty.NettyInbound;
/*      */ import reactor.netty.NettyOutbound;
/*      */ import reactor.netty.ReactorNetty;
/*      */ import reactor.netty.channel.AbortedException;
/*      */ import reactor.netty.channel.ChannelOperations;
/*      */ import reactor.netty.http.HttpOperations;
/*      */ import reactor.netty.http.logging.HttpMessageArgProviderFactory;
/*      */ import reactor.netty.http.logging.HttpMessageLogFactory;
/*      */ import reactor.netty.http.websocket.WebsocketInbound;
/*      */ import reactor.netty.http.websocket.WebsocketOutbound;
/*      */ import reactor.util.Logger;
/*      */ import reactor.util.Loggers;
/*      */ import reactor.util.annotation.Nullable;
/*      */ import reactor.util.context.Context;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class HttpServerOperations
/*      */   extends HttpOperations<HttpServerRequest, HttpServerResponse>
/*      */   implements HttpServerRequest, HttpServerResponse
/*      */ {
/*      */   final BiPredicate<HttpServerRequest, HttpServerResponse> configuredCompressionPredicate;
/*      */   final ConnectionInfo connectionInfo;
/*      */   final ServerCookieDecoder cookieDecoder;
/*      */   final ServerCookieEncoder cookieEncoder;
/*      */   final ServerCookies cookieHolder;
/*      */   final HttpServerFormDecoderProvider formDecoderProvider;
/*      */   final boolean isHttp2;
/*      */   final BiFunction<? super Mono<Void>, ? super Connection, ? extends Mono<Void>> mapHandle;
/*      */   final HttpRequest nettyRequest;
/*      */   final HttpResponse nettyResponse;
/*      */   final HttpHeaders responseHeaders;
/*      */   final String scheme;
/*      */   final ZonedDateTime timestamp;
/*      */   BiPredicate<HttpServerRequest, HttpServerResponse> compressionPredicate;
/*      */   Function<? super String, Map<String, String>> paramsResolver;
/*      */   String path;
/*      */   Consumer<? super HttpHeaders> trailerHeadersConsumer;
/*      */   volatile Context currentContext;
/*      */   
/*      */   HttpServerOperations(HttpServerOperations replaced) {
/*  132 */     super(replaced);
/*  133 */     this.compressionPredicate = replaced.compressionPredicate;
/*  134 */     this.configuredCompressionPredicate = replaced.configuredCompressionPredicate;
/*  135 */     this.connectionInfo = replaced.connectionInfo;
/*  136 */     this.cookieDecoder = replaced.cookieDecoder;
/*  137 */     this.cookieEncoder = replaced.cookieEncoder;
/*  138 */     this.cookieHolder = replaced.cookieHolder;
/*  139 */     this.currentContext = replaced.currentContext;
/*  140 */     this.formDecoderProvider = replaced.formDecoderProvider;
/*  141 */     this.isHttp2 = replaced.isHttp2;
/*  142 */     this.mapHandle = replaced.mapHandle;
/*  143 */     this.nettyRequest = replaced.nettyRequest;
/*  144 */     this.nettyResponse = replaced.nettyResponse;
/*  145 */     this.paramsResolver = replaced.paramsResolver;
/*  146 */     this.path = replaced.path;
/*  147 */     this.responseHeaders = replaced.responseHeaders;
/*  148 */     this.scheme = replaced.scheme;
/*  149 */     this.timestamp = replaced.timestamp;
/*  150 */     this.trailerHeadersConsumer = replaced.trailerHeadersConsumer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   HttpServerOperations(Connection c, ConnectionObserver listener, HttpRequest nettyRequest, @Nullable BiPredicate<HttpServerRequest, HttpServerResponse> compressionPredicate, ConnectionInfo connectionInfo, ServerCookieDecoder decoder, ServerCookieEncoder encoder, HttpServerFormDecoderProvider formDecoderProvider, HttpMessageLogFactory httpMessageLogFactory, boolean isHttp2, @Nullable BiFunction<? super Mono<Void>, ? super Connection, ? extends Mono<Void>> mapHandle, boolean secured, ZonedDateTime timestamp) {
/*  164 */     this(c, listener, nettyRequest, compressionPredicate, connectionInfo, decoder, encoder, formDecoderProvider, httpMessageLogFactory, isHttp2, mapHandle, true, secured, timestamp);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   HttpServerOperations(Connection c, ConnectionObserver listener, HttpRequest nettyRequest, @Nullable BiPredicate<HttpServerRequest, HttpServerResponse> compressionPredicate, ConnectionInfo connectionInfo, ServerCookieDecoder decoder, ServerCookieEncoder encoder, HttpServerFormDecoderProvider formDecoderProvider, HttpMessageLogFactory httpMessageLogFactory, boolean isHttp2, @Nullable BiFunction<? super Mono<Void>, ? super Connection, ? extends Mono<Void>> mapHandle, boolean resolvePath, boolean secured, ZonedDateTime timestamp) {
/*  180 */     super(c, listener, httpMessageLogFactory);
/*  181 */     this.compressionPredicate = compressionPredicate;
/*  182 */     this.configuredCompressionPredicate = compressionPredicate;
/*  183 */     this.connectionInfo = connectionInfo;
/*  184 */     this.cookieDecoder = decoder;
/*  185 */     this.cookieEncoder = encoder;
/*  186 */     this.cookieHolder = ServerCookies.newServerRequestHolder(nettyRequest.headers(), decoder);
/*  187 */     this.currentContext = Context.empty();
/*  188 */     this.formDecoderProvider = formDecoderProvider;
/*  189 */     this.isHttp2 = isHttp2;
/*  190 */     this.mapHandle = mapHandle;
/*  191 */     this.nettyRequest = nettyRequest;
/*  192 */     this.nettyResponse = (HttpResponse)new DefaultHttpResponse(HttpVersion.HTTP_1_1, HttpResponseStatus.OK);
/*  193 */     if (resolvePath) {
/*  194 */       this.path = resolvePath(nettyRequest.uri());
/*      */     } else {
/*      */       
/*  197 */       this.path = null;
/*      */     } 
/*  199 */     this.responseHeaders = this.nettyResponse.headers();
/*  200 */     this.responseHeaders.set((CharSequence)HttpHeaderNames.TRANSFER_ENCODING, HttpHeaderValues.CHUNKED);
/*  201 */     this.scheme = secured ? "https" : "http";
/*  202 */     this.timestamp = timestamp;
/*      */   }
/*      */ 
/*      */   
/*      */   public NettyOutbound sendHeaders() {
/*  207 */     if (hasSentHeaders()) {
/*  208 */       return this;
/*      */     }
/*      */     
/*  211 */     return then((Publisher)Mono.empty());
/*      */   }
/*      */ 
/*      */   
/*      */   public HttpServerOperations withConnection(Consumer<? super Connection> withConnection) {
/*  216 */     Objects.requireNonNull(withConnection, "withConnection");
/*  217 */     withConnection.accept(this);
/*  218 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected HttpMessage newFullBodyMessage(ByteBuf body) {
/*  224 */     DefaultFullHttpResponse defaultFullHttpResponse = new DefaultFullHttpResponse(version(), status(), body);
/*      */     
/*  226 */     if (!HttpMethod.HEAD.equals(method())) {
/*  227 */       this.responseHeaders.remove((CharSequence)HttpHeaderNames.TRANSFER_ENCODING);
/*  228 */       int code = status().code();
/*  229 */       if (HttpResponseStatus.NOT_MODIFIED.code() != code && HttpResponseStatus.NO_CONTENT
/*  230 */         .code() != code)
/*      */       {
/*  232 */         if (HttpUtil.getContentLength((HttpMessage)this.nettyResponse, -1) == -1) {
/*  233 */           this.responseHeaders.setInt((CharSequence)HttpHeaderNames.CONTENT_LENGTH, body.readableBytes());
/*      */ 
/*      */ 
/*      */         
/*      */         }
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*      */ 
/*      */     
/*      */     }
/*  245 */     else if (HttpUtil.getContentLength((HttpMessage)this.nettyResponse, -1) != -1) {
/*  246 */       this.responseHeaders.remove((CharSequence)HttpHeaderNames.TRANSFER_ENCODING);
/*      */     } 
/*      */     
/*  249 */     defaultFullHttpResponse.headers().set(this.responseHeaders);
/*  250 */     return (HttpMessage)defaultFullHttpResponse;
/*      */   }
/*      */ 
/*      */   
/*      */   public HttpServerResponse addCookie(Cookie cookie) {
/*  255 */     if (!hasSentHeaders()) {
/*  256 */       this.responseHeaders.add((CharSequence)HttpHeaderNames.SET_COOKIE, this.cookieEncoder
/*  257 */           .encode(cookie));
/*      */     } else {
/*      */       
/*  260 */       throw new IllegalStateException("Status and headers already sent");
/*      */     } 
/*  262 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public HttpServerResponse addHeader(CharSequence name, CharSequence value) {
/*  267 */     if (!hasSentHeaders()) {
/*  268 */       this.responseHeaders.add(name, value);
/*      */     } else {
/*      */       
/*  271 */       throw new IllegalStateException("Status and headers already sent");
/*      */     } 
/*  273 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public HttpServerOperations chunkedTransfer(boolean chunked) {
/*  278 */     if (!hasSentHeaders() && HttpUtil.isTransferEncodingChunked((HttpMessage)this.nettyResponse) != chunked) {
/*  279 */       this.responseHeaders.remove((CharSequence)HttpHeaderNames.TRANSFER_ENCODING);
/*  280 */       HttpUtil.setTransferEncodingChunked((HttpMessage)this.nettyResponse, chunked);
/*      */     } 
/*  282 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public Map<CharSequence, Set<Cookie>> cookies() {
/*  287 */     if (this.cookieHolder != null) {
/*  288 */       return this.cookieHolder.getCachedCookies();
/*      */     }
/*  290 */     throw new IllegalStateException("request not parsed");
/*      */   }
/*      */ 
/*      */   
/*      */   public Map<CharSequence, List<Cookie>> allCookies() {
/*  295 */     if (this.cookieHolder != null) {
/*  296 */       return this.cookieHolder.getAllCachedCookies();
/*      */     }
/*  298 */     throw new IllegalStateException("request not parsed");
/*      */   }
/*      */ 
/*      */   
/*      */   public Context currentContext() {
/*  303 */     return this.currentContext;
/*      */   }
/*      */ 
/*      */   
/*      */   public HttpServerResponse header(CharSequence name, CharSequence value) {
/*  308 */     if (!hasSentHeaders()) {
/*  309 */       this.responseHeaders.set(name, value);
/*      */     } else {
/*      */       
/*  312 */       throw new IllegalStateException("Status and headers already sent");
/*      */     } 
/*  314 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public HttpServerResponse headers(HttpHeaders headers) {
/*  319 */     if (!hasSentHeaders()) {
/*  320 */       this.responseHeaders.set(headers);
/*      */     } else {
/*      */       
/*  323 */       throw new IllegalStateException("Status and headers already sent");
/*      */     } 
/*  325 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isFormUrlencoded() {
/*  330 */     CharSequence mimeType = HttpUtil.getMimeType((HttpMessage)this.nettyRequest);
/*  331 */     return (mimeType != null && HttpHeaderValues.APPLICATION_X_WWW_FORM_URLENCODED
/*  332 */       .contentEqualsIgnoreCase(mimeType.toString().trim()));
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isKeepAlive() {
/*  337 */     return HttpUtil.isKeepAlive((HttpMessage)this.nettyRequest);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isMultipart() {
/*  342 */     return HttpPostRequestDecoder.isMultipart(this.nettyRequest);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isWebsocket() {
/*  347 */     return get(channel()) instanceof WebsocketServerOperations;
/*      */   }
/*      */   
/*      */   final boolean isHttp2() {
/*  351 */     return this.isHttp2;
/*      */   }
/*      */ 
/*      */   
/*      */   public HttpServerResponse keepAlive(boolean keepAlive) {
/*  356 */     HttpUtil.setKeepAlive((HttpMessage)this.nettyResponse, keepAlive);
/*  357 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public HttpMethod method() {
/*  362 */     return this.nettyRequest.method();
/*      */   }
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public String param(CharSequence key) {
/*  368 */     Objects.requireNonNull(key, "key");
/*  369 */     Map<String, String> params = null;
/*  370 */     if (this.paramsResolver != null) {
/*  371 */       params = this.paramsResolver.apply(uri());
/*      */     }
/*  373 */     return (null != params) ? params.get(key.toString()) : null;
/*      */   }
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public Map<String, String> params() {
/*  379 */     return (null != this.paramsResolver) ? this.paramsResolver.apply(uri()) : null;
/*      */   }
/*      */ 
/*      */   
/*      */   public HttpServerRequest paramsResolver(Function<? super String, Map<String, String>> paramsResolver) {
/*  384 */     this.paramsResolver = paramsResolver;
/*  385 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public Flux<HttpData> receiveForm() {
/*  390 */     return receiveFormInternal(this.formDecoderProvider);
/*      */   }
/*      */ 
/*      */   
/*      */   public Flux<HttpData> receiveForm(Consumer<HttpServerFormDecoderProvider.Builder> formDecoderBuilder) {
/*  395 */     Objects.requireNonNull(formDecoderBuilder, "formDecoderBuilder");
/*  396 */     HttpServerFormDecoderProvider.Build builder = new HttpServerFormDecoderProvider.Build();
/*  397 */     formDecoderBuilder.accept(builder);
/*  398 */     HttpServerFormDecoderProvider config = builder.build();
/*  399 */     return receiveFormInternal(config);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Flux<?> receiveObject() {
/*  409 */     if (HttpUtil.is100ContinueExpected((HttpMessage)this.nettyRequest)) {
/*  410 */       return FutureMono.deferFuture(() -> !hasSentHeaders() ? channel().writeAndFlush(CONTINUE) : channel().newSucceededFuture())
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  417 */         .thenMany((Publisher)super.receiveObject());
/*      */     }
/*      */     
/*  420 */     return super.receiveObject();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public InetSocketAddress hostAddress() {
/*  427 */     return this.connectionInfo.getHostAddress();
/*      */   }
/*      */   
/*      */   final SocketAddress hostSocketAddress() {
/*  431 */     return this.connectionInfo.hostAddress;
/*      */   }
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public SocketAddress connectionHostAddress() {
/*  437 */     return channel().localAddress();
/*      */   }
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public InetSocketAddress remoteAddress() {
/*  443 */     return this.connectionInfo.getRemoteAddress();
/*      */   }
/*      */   
/*      */   final SocketAddress remoteSocketAddress() {
/*  447 */     return this.connectionInfo.remoteAddress;
/*      */   }
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public SocketAddress connectionRemoteAddress() {
/*  453 */     return channel().remoteAddress();
/*      */   }
/*      */ 
/*      */   
/*      */   public HttpHeaders requestHeaders() {
/*  458 */     if (this.nettyRequest != null) {
/*  459 */       return this.nettyRequest.headers();
/*      */     }
/*  461 */     throw new IllegalStateException("request not parsed");
/*      */   }
/*      */ 
/*      */   
/*      */   public String scheme() {
/*  466 */     return this.connectionInfo.getScheme();
/*      */   }
/*      */ 
/*      */   
/*      */   public String connectionScheme() {
/*  471 */     return this.scheme;
/*      */   }
/*      */ 
/*      */   
/*      */   public String hostName() {
/*  476 */     return this.connectionInfo.getHostName();
/*      */   }
/*      */ 
/*      */   
/*      */   public int hostPort() {
/*  481 */     return this.connectionInfo.getHostPort();
/*      */   }
/*      */ 
/*      */   
/*      */   public HttpHeaders responseHeaders() {
/*  486 */     return this.responseHeaders;
/*      */   }
/*      */ 
/*      */   
/*      */   public String protocol() {
/*  491 */     return this.nettyRequest.protocolVersion().text();
/*      */   }
/*      */ 
/*      */   
/*      */   public ZonedDateTime timestamp() {
/*  496 */     return this.timestamp;
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<Void> send() {
/*  501 */     return FutureMono.deferFuture(() -> markSentHeaderAndBody(new Object[0]) ? channel().writeAndFlush(newFullBodyMessage(Unpooled.EMPTY_BUFFER)) : channel().newSucceededFuture());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NettyOutbound sendFile(Path file) {
/*      */     try {
/*  509 */       return sendFile(file, 0L, Files.size(file));
/*      */     }
/*  511 */     catch (IOException e) {
/*  512 */       if (log.isDebugEnabled()) {
/*  513 */         log.debug(ReactorNetty.format(channel(), "Path not resolved"), e);
/*      */       }
/*  515 */       return then((Publisher)sendNotFound());
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<Void> sendNotFound() {
/*  521 */     return status(HttpResponseStatus.NOT_FOUND)
/*  522 */       .send();
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<Void> sendRedirect(String location) {
/*  527 */     Objects.requireNonNull(location, "location");
/*  528 */     return status(HttpResponseStatus.FOUND)
/*  529 */       .header((CharSequence)HttpHeaderNames.LOCATION, location)
/*  530 */       .send();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpServerResponse sse() {
/*  538 */     header((CharSequence)HttpHeaderNames.CONTENT_TYPE, (CharSequence)EVENT_STREAM);
/*  539 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public HttpResponseStatus status() {
/*  544 */     return this.nettyResponse.status();
/*      */   }
/*      */ 
/*      */   
/*      */   public HttpServerResponse status(HttpResponseStatus status) {
/*  549 */     if (!hasSentHeaders()) {
/*  550 */       this.nettyResponse.setStatus(status);
/*      */     } else {
/*      */       
/*  553 */       throw new IllegalStateException("Status and headers already sent");
/*      */     } 
/*  555 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public HttpServerResponse trailerHeaders(Consumer<? super HttpHeaders> trailerHeaders) {
/*  560 */     this.trailerHeadersConsumer = Objects.<Consumer<? super HttpHeaders>>requireNonNull(trailerHeaders, "trailerHeaders");
/*  561 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<Void> sendWebsocket(BiFunction<? super WebsocketInbound, ? super WebsocketOutbound, ? extends Publisher<Void>> websocketHandler, WebsocketServerSpec configurer) {
/*  568 */     return withWebsocketSupport(uri(), configurer, websocketHandler);
/*      */   }
/*      */ 
/*      */   
/*      */   public String uri() {
/*  573 */     if (this.nettyRequest != null) {
/*  574 */       return this.nettyRequest.uri();
/*      */     }
/*  576 */     throw new IllegalStateException("request not parsed");
/*      */   }
/*      */ 
/*      */   
/*      */   public String fullPath() {
/*  581 */     if (this.path != null) {
/*  582 */       return this.path;
/*      */     }
/*  584 */     throw new IllegalStateException("request not parsed");
/*      */   }
/*      */ 
/*      */   
/*      */   public HttpVersion version() {
/*  589 */     if (this.nettyRequest != null) {
/*  590 */       return this.nettyRequest.protocolVersion();
/*      */     }
/*  592 */     throw new IllegalStateException("request not parsed");
/*      */   }
/*      */ 
/*      */   
/*      */   public HttpServerResponse compression(boolean compress) {
/*  597 */     this.compressionPredicate = compress ? this.configuredCompressionPredicate : COMPRESSION_DISABLED;
/*  598 */     if (!compress) {
/*  599 */       removeHandler("reactor.left.compressionHandler");
/*      */     }
/*  601 */     else if (channel().pipeline()
/*  602 */       .get("reactor.left.compressionHandler") == null) {
/*  603 */       SimpleCompressionHandler handler = new SimpleCompressionHandler();
/*      */       
/*      */       try {
/*  606 */         handler.decode(channel().pipeline().context("reactor.right.reactiveBridge"), this.nettyRequest);
/*      */         
/*  608 */         addHandlerFirst("reactor.left.compressionHandler", (ChannelHandler)handler);
/*      */       }
/*  610 */       catch (Throwable e) {
/*  611 */         log.error(ReactorNetty.format(channel(), ""), e);
/*      */       } 
/*      */     } 
/*  614 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   protected void onInboundNext(ChannelHandlerContext ctx, Object msg) {
/*  619 */     if (msg instanceof HttpRequest) {
/*      */       try {
/*  621 */         listener().onStateChange((Connection)this, HttpServerState.REQUEST_RECEIVED);
/*      */       }
/*  623 */       catch (Exception e) {
/*  624 */         onInboundError(e);
/*  625 */         ReferenceCountUtil.release(msg);
/*      */         return;
/*      */       } 
/*  628 */       if (msg instanceof FullHttpRequest) {
/*  629 */         FullHttpRequest request = (FullHttpRequest)msg;
/*  630 */         if (request.content().readableBytes() > 0) {
/*  631 */           super.onInboundNext(ctx, msg);
/*      */         } else {
/*      */           
/*  634 */           request.release();
/*      */         } 
/*  636 */         if (isHttp2()) {
/*      */           
/*  638 */           channel().config().setAutoRead(true);
/*  639 */           onInboundComplete();
/*      */         } 
/*      */       } 
/*      */       return;
/*      */     } 
/*  644 */     if (msg instanceof HttpContent) {
/*  645 */       if (msg != LastHttpContent.EMPTY_LAST_CONTENT) {
/*  646 */         super.onInboundNext(ctx, msg);
/*      */       }
/*  648 */       if (msg instanceof LastHttpContent) {
/*      */         
/*  650 */         channel().config().setAutoRead(true);
/*  651 */         onInboundComplete();
/*      */       } 
/*      */     } else {
/*      */       
/*  655 */       super.onInboundNext(ctx, msg);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void onInboundClose() {
/*  661 */     discardWhenNoReceiver();
/*  662 */     if (!isInboundCancelled() && !isInboundDisposed()) {
/*  663 */       onInboundError((Throwable)new AbortedException("Connection has been closed"));
/*      */     }
/*  665 */     terminate();
/*      */   }
/*      */ 
/*      */   
/*      */   protected void afterMarkSentHeaders() {
/*  670 */     if (this.compressionPredicate != null && this.compressionPredicate.test(this, this)) {
/*  671 */       compression(true);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void beforeMarkSentHeaders() {}
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isContentAlwaysEmpty() {
/*  682 */     int code = status().code();
/*  683 */     if (HttpResponseStatus.NOT_MODIFIED.code() == code) {
/*  684 */       this.responseHeaders.remove((CharSequence)HttpHeaderNames.TRANSFER_ENCODING)
/*  685 */         .remove((CharSequence)HttpHeaderNames.CONTENT_LENGTH);
/*  686 */       return true;
/*      */     } 
/*  688 */     return (HttpResponseStatus.NO_CONTENT.code() == code || HttpResponseStatus.RESET_CONTENT
/*  689 */       .code() == code);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void onHeadersSent() {}
/*      */ 
/*      */   
/*      */   protected void onOutboundComplete() {
/*      */     ChannelFuture f;
/*  699 */     if (isWebsocket()) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  704 */     if (log.isDebugEnabled()) {
/*  705 */       log.debug(ReactorNetty.format(channel(), "Last HTTP response frame"));
/*      */     }
/*  707 */     if (markSentHeaderAndBody(new Object[0])) {
/*  708 */       if (log.isDebugEnabled()) {
/*  709 */         log.debug(ReactorNetty.format(channel(), "No sendHeaders() called before complete, sending zero-length header"));
/*      */       }
/*      */ 
/*      */       
/*  713 */       f = channel().writeAndFlush(newFullBodyMessage(Unpooled.EMPTY_BUFFER));
/*      */     }
/*  715 */     else if (markSentBody()) {
/*  716 */       TrailerHeaders trailerHeaders1; HttpHeaders trailerHeaders = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  723 */       if (this.trailerHeadersConsumer != null && HttpUtil.isTransferEncodingChunked((HttpMessage)this.nettyResponse)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  730 */         String declaredHeaderNames = this.responseHeaders.get((CharSequence)HttpHeaderNames.TRAILER);
/*  731 */         if (declaredHeaderNames != null) {
/*  732 */           trailerHeaders1 = new TrailerHeaders(declaredHeaderNames);
/*      */           try {
/*  734 */             this.trailerHeadersConsumer.accept(trailerHeaders1);
/*      */           }
/*  736 */           catch (IllegalArgumentException e) {
/*      */ 
/*      */             
/*  739 */             log.error(ReactorNetty.format(channel(), "Cannot apply trailer headers [{}]"), new Object[] { declaredHeaderNames, e });
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       
/*  744 */       f = channel().writeAndFlush((trailerHeaders1 != null && !trailerHeaders1.isEmpty()) ? 
/*  745 */           new DefaultLastHttpContent(Unpooled.buffer(0), (HttpHeaders)trailerHeaders1) : 
/*  746 */           LastHttpContent.EMPTY_LAST_CONTENT);
/*      */     } else {
/*      */       
/*  749 */       discard();
/*      */       return;
/*      */     } 
/*  752 */     f.addListener(s -> {
/*      */           discard();
/*      */           if (!s.isSuccess() && log.isDebugEnabled()) {
/*      */             log.debug(ReactorNetty.format(channel(), "Failed flushing last frame"), s.cause());
/*      */           }
/*      */         });
/*      */   }
/*      */ 
/*      */   
/*      */   static void cleanHandlerTerminate(Channel ch) {
/*  762 */     ChannelOperations<?, ?> ops = get(ch);
/*      */     
/*  764 */     if (ops == null) {
/*      */       return;
/*      */     }
/*      */     
/*  768 */     ops.discard();
/*      */ 
/*      */     
/*  771 */     if (!ops.isSubscriptionDisposed()) {
/*  772 */       Objects.requireNonNull((HttpServerOperations)ops); ch.eventLoop()
/*  773 */         .execute((HttpServerOperations)ops::terminate);
/*      */     }
/*      */     else {
/*      */       
/*  777 */       ((HttpServerOperations)ops).terminate();
/*      */     } 
/*      */   }
/*      */   
/*      */   static long requestsCounter(Channel channel) {
/*  782 */     HttpServerOperations ops = (HttpServerOperations)Connection.from(channel).as(HttpServerOperations.class);
/*      */     
/*  784 */     if (ops == null) {
/*  785 */       return -1L;
/*      */     }
/*      */     
/*  788 */     return ((AtomicLong)ops.connection()).get();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void sendDecodingFailures(ChannelHandlerContext ctx, ConnectionObserver listener, boolean secure, Throwable t, Object msg, HttpMessageLogFactory httpMessageLogFactory, @Nullable ZonedDateTime timestamp, @Nullable ConnectionInfo connectionInfo, SocketAddress remoteAddress) {
/*  801 */     sendDecodingFailures(ctx, listener, secure, t, msg, httpMessageLogFactory, false, timestamp, connectionInfo, remoteAddress);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void sendDecodingFailures(ChannelHandlerContext ctx, ConnectionObserver listener, boolean secure, Throwable t, Object msg, HttpMessageLogFactory httpMessageLogFactory, boolean isHttp2, @Nullable ZonedDateTime timestamp, @Nullable ConnectionInfo connectionInfo, SocketAddress remoteAddress) {
/*      */     HttpResponseStatus status;
/*      */     Connection connection;
/*  817 */     Throwable cause = (t.getCause() != null) ? t.getCause() : t;
/*      */     
/*  819 */     if (log.isWarnEnabled()) {
/*  820 */       log.warn(ReactorNetty.format(ctx.channel(), "Decoding failed: {}"), new Object[] {
/*  821 */             (msg instanceof io.netty.handler.codec.http.HttpObject) ? 
/*  822 */             httpMessageLogFactory.warn(HttpMessageArgProviderFactory.create(msg)) : msg
/*      */           });
/*      */     }
/*  825 */     ReferenceCountUtil.release(msg);
/*      */ 
/*      */     
/*  828 */     if (cause instanceof io.netty.handler.codec.http.TooLongHttpLineException) {
/*  829 */       status = HttpResponseStatus.REQUEST_URI_TOO_LONG;
/*      */     }
/*  831 */     else if (cause instanceof io.netty.handler.codec.http.TooLongHttpHeaderException) {
/*  832 */       status = HttpResponseStatus.REQUEST_HEADER_FIELDS_TOO_LARGE;
/*      */     } else {
/*      */       
/*  835 */       status = HttpResponseStatus.BAD_REQUEST;
/*      */     } 
/*  837 */     DefaultFullHttpResponse defaultFullHttpResponse = new DefaultFullHttpResponse(HttpVersion.HTTP_1_1, status);
/*  838 */     defaultFullHttpResponse.headers()
/*  839 */       .setInt((CharSequence)HttpHeaderNames.CONTENT_LENGTH, 0)
/*  840 */       .set((CharSequence)HttpHeaderNames.CONNECTION, HttpHeaderValues.CLOSE);
/*      */     
/*  842 */     ChannelOperations channelOperations = ChannelOperations.get(ctx.channel());
/*  843 */     if (channelOperations == null) {
/*  844 */       Connection conn = Connection.from(ctx.channel());
/*  845 */       if (msg instanceof HttpRequest) {
/*      */ 
/*      */         
/*  848 */         FailedHttpServerRequest failedHttpServerRequest = new FailedHttpServerRequest(conn, listener, (HttpRequest)msg, (HttpResponse)defaultFullHttpResponse, httpMessageLogFactory, isHttp2, secure, (timestamp == null) ? ZonedDateTime.now(ReactorNetty.ZONE_ID_SYSTEM) : timestamp, (connectionInfo == null) ? new ConnectionInfo(ctx.channel().localAddress(), remoteAddress, secure) : connectionInfo);
/*  849 */         failedHttpServerRequest.bind();
/*      */       } else {
/*      */         
/*  852 */         connection = conn;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  857 */     ctx.channel().writeAndFlush(defaultFullHttpResponse);
/*      */     
/*  859 */     listener.onStateChange(connection, HttpServerState.REQUEST_DECODING_FAILED);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void onOutboundError(Throwable err) {
/*  871 */     if (!channel().isActive()) {
/*  872 */       super.onOutboundError(err);
/*      */       
/*      */       return;
/*      */     } 
/*  876 */     if (markSentHeaders(new Object[0])) {
/*  877 */       log.error(ReactorNetty.format(channel(), "Error starting response. Replying error status"), err);
/*      */       
/*  879 */       this.nettyResponse.setStatus(HttpResponseStatus.INTERNAL_SERVER_ERROR);
/*  880 */       this.responseHeaders.set((CharSequence)HttpHeaderNames.CONNECTION, HttpHeaderValues.CLOSE);
/*  881 */       channel().writeAndFlush(newFullBodyMessage(Unpooled.EMPTY_BUFFER))
/*  882 */         .addListener((GenericFutureListener)ChannelFutureListener.CLOSE);
/*      */       
/*      */       return;
/*      */     } 
/*  886 */     markSentBody();
/*  887 */     log.error(ReactorNetty.format(channel(), "Error finishing response. Closing connection"), err);
/*  888 */     channel().writeAndFlush(Unpooled.EMPTY_BUFFER)
/*  889 */       .addListener((GenericFutureListener)ChannelFutureListener.CLOSE);
/*      */   }
/*      */ 
/*      */   
/*      */   protected HttpMessage outboundHttpMessage() {
/*  894 */     return (HttpMessage)this.nettyResponse;
/*      */   }
/*      */   
/*      */   final Flux<HttpData> receiveFormInternal(HttpServerFormDecoderProvider config) {
/*  898 */     boolean isMultipart = isMultipart();
/*  899 */     if (!Objects.equals(method(), HttpMethod.POST) || (!isFormUrlencoded() && !isMultipart)) {
/*  900 */       return Flux.error(new IllegalStateException("Request is not POST or does not have Content-Type with value 'application/x-www-form-urlencoded' or 'multipart/form-data'"));
/*      */     }
/*      */ 
/*      */     
/*  904 */     return Flux.defer(() -> config.newHttpPostRequestDecoder(this.nettyRequest, isMultipart).flatMapMany(()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final Mono<Void> withWebsocketSupport(String url, WebsocketServerSpec websocketServerSpec, BiFunction<? super WebsocketInbound, ? super WebsocketOutbound, ? extends Publisher<Void>> websocketHandler) {
/*  935 */     Objects.requireNonNull(websocketServerSpec, "websocketServerSpec");
/*  936 */     Objects.requireNonNull(websocketHandler, "websocketHandler");
/*  937 */     if (markSentHeaders(new Object[0])) {
/*  938 */       WebsocketServerOperations ops = new WebsocketServerOperations(url, websocketServerSpec, this);
/*      */       
/*  940 */       return FutureMono.from((Future)ops.handshakerResult)
/*  941 */         .doOnEach(signal -> {
/*      */             if (!signal.hasError() && (websocketServerSpec.protocols() == null || ops.selectedSubprotocol() != null)) {
/*      */               ((Publisher)websocketHandler.apply(ops, ops)).subscribe((Subscriber)new WebsocketSubscriber(ops, Context.of(signal.getContextView())));
/*      */             }
/*      */           });
/*      */     } 
/*      */ 
/*      */     
/*  949 */     log.error(ReactorNetty.format(channel(), "Cannot enable websocket if headers have already been sent"));
/*      */     
/*  951 */     return Mono.error(new IllegalStateException("Failed to upgrade to websocket"));
/*      */   }
/*      */   
/*      */   static final class WebsocketSubscriber implements CoreSubscriber<Void>, ChannelFutureListener {
/*      */     final WebsocketServerOperations ops;
/*      */     final Context context;
/*      */     
/*      */     WebsocketSubscriber(WebsocketServerOperations ops, Context context) {
/*  959 */       this.ops = ops;
/*  960 */       this.context = context;
/*      */     }
/*      */ 
/*      */     
/*      */     public void onSubscribe(Subscription s) {
/*  965 */       s.request(Long.MAX_VALUE);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void onNext(Void aVoid) {}
/*      */ 
/*      */ 
/*      */     
/*      */     public void onError(Throwable t) {
/*  975 */       this.ops.onError(t);
/*      */     }
/*      */ 
/*      */     
/*      */     public void operationComplete(ChannelFuture future) {
/*  980 */       this.ops.terminate();
/*      */     }
/*      */ 
/*      */     
/*      */     public void onComplete() {
/*  985 */       if (this.ops.channel()
/*  986 */         .isActive()) {
/*  987 */         this.ops.sendCloseNow(new CloseWebSocketFrame(WebSocketCloseStatus.NORMAL_CLOSURE), this);
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*      */     public Context currentContext() {
/*  993 */       return this.context;
/*      */     }
/*      */   }
/*      */   
/*  997 */   static final Logger log = Loggers.getLogger(HttpServerOperations.class);
/*  998 */   static final AsciiString EVENT_STREAM = new AsciiString("text/event-stream");
/*      */   
/*      */   static final BiPredicate<HttpServerRequest, HttpServerResponse> COMPRESSION_DISABLED = (req, res) -> false;
/*      */   
/* 1002 */   static final FullHttpResponse CONTINUE = (FullHttpResponse)new DefaultFullHttpResponse(HttpVersion.HTTP_1_1, HttpResponseStatus.CONTINUE, Unpooled.EMPTY_BUFFER);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final class FailedHttpServerRequest
/*      */     extends HttpServerOperations
/*      */   {
/*      */     final HttpResponse customResponse;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     FailedHttpServerRequest(Connection c, ConnectionObserver listener, HttpRequest nettyRequest, HttpResponse nettyResponse, HttpMessageLogFactory httpMessageLogFactory, boolean isHttp2, boolean secure, ZonedDateTime timestamp, ConnectionInfo connectionInfo) {
/* 1021 */       super(c, listener, nettyRequest, (BiPredicate<HttpServerRequest, HttpServerResponse>)null, connectionInfo, ServerCookieDecoder.STRICT, ServerCookieEncoder.STRICT, HttpServerFormDecoderProvider.DEFAULT_FORM_DECODER_SPEC, httpMessageLogFactory, isHttp2, (BiFunction<? super Mono<Void>, ? super Connection, ? extends Mono<Void>>)null, false, secure, timestamp);
/*      */ 
/*      */       
/* 1024 */       this.customResponse = nettyResponse;
/* 1025 */       String tempPath = "";
/*      */       try {
/* 1027 */         tempPath = resolvePath(nettyRequest.uri());
/*      */       }
/* 1029 */       catch (RuntimeException e) {
/* 1030 */         tempPath = "/bad-request";
/*      */       } finally {
/*      */         
/* 1033 */         this.path = tempPath;
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     protected HttpMessage outboundHttpMessage() {
/* 1039 */       return (HttpMessage)this.customResponse;
/*      */     }
/*      */ 
/*      */     
/*      */     public HttpResponseStatus status() {
/* 1044 */       return this.customResponse.status();
/*      */     }
/*      */   }
/*      */   
/*      */   static final class TrailerHeaders
/*      */     extends DefaultHttpHeaders {
/* 1050 */     static final Set<String> DISALLOWED_TRAILER_HEADER_NAMES = new HashSet<>(14);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     static {
/* 1060 */       DISALLOWED_TRAILER_HEADER_NAMES.add("age");
/* 1061 */       DISALLOWED_TRAILER_HEADER_NAMES.add("cache-control");
/* 1062 */       DISALLOWED_TRAILER_HEADER_NAMES.add("content-encoding");
/* 1063 */       DISALLOWED_TRAILER_HEADER_NAMES.add("content-length");
/* 1064 */       DISALLOWED_TRAILER_HEADER_NAMES.add("content-range");
/* 1065 */       DISALLOWED_TRAILER_HEADER_NAMES.add("content-type");
/* 1066 */       DISALLOWED_TRAILER_HEADER_NAMES.add("date");
/* 1067 */       DISALLOWED_TRAILER_HEADER_NAMES.add("expires");
/* 1068 */       DISALLOWED_TRAILER_HEADER_NAMES.add("location");
/* 1069 */       DISALLOWED_TRAILER_HEADER_NAMES.add("retry-after");
/* 1070 */       DISALLOWED_TRAILER_HEADER_NAMES.add("trailer");
/* 1071 */       DISALLOWED_TRAILER_HEADER_NAMES.add("transfer-encoding");
/* 1072 */       DISALLOWED_TRAILER_HEADER_NAMES.add("vary");
/* 1073 */       DISALLOWED_TRAILER_HEADER_NAMES.add("warning");
/*      */     }
/*      */     
/*      */     TrailerHeaders(String declaredHeaderNames) {
/* 1077 */       super(true, new TrailerNameValidator(filterHeaderNames(declaredHeaderNames)));
/*      */     }
/*      */     
/*      */     static Set<String> filterHeaderNames(String declaredHeaderNames) {
/* 1081 */       Objects.requireNonNull(declaredHeaderNames, "declaredHeaderNames");
/* 1082 */       Set<String> result = new HashSet<>();
/* 1083 */       String[] names = declaredHeaderNames.split(",", -1);
/* 1084 */       for (String name : names) {
/* 1085 */         String trimmedStr = name.trim();
/* 1086 */         if (!trimmedStr.isEmpty() && 
/* 1087 */           !DISALLOWED_TRAILER_HEADER_NAMES.contains(trimmedStr.toLowerCase(Locale.ENGLISH)))
/*      */         {
/*      */           
/* 1090 */           result.add(trimmedStr); } 
/*      */       } 
/* 1092 */       return result;
/*      */     }
/*      */ 
/*      */     
/*      */     static final class TrailerNameValidator
/*      */       implements DefaultHeaders.NameValidator<CharSequence>
/*      */     {
/*      */       final Set<String> declaredHeaderNames;
/*      */ 
/*      */       
/*      */       TrailerNameValidator(Set<String> declaredHeaderNames) {
/* 1103 */         this.declaredHeaderNames = declaredHeaderNames;
/*      */       }
/*      */ 
/*      */       
/*      */       public void validateName(CharSequence name) {
/* 1108 */         if (!this.declaredHeaderNames.contains(name.toString()))
/* 1109 */           throw new IllegalArgumentException("Trailer header name [" + name + "] not declared with [Trailer] header, or it is not a valid trailer header name"); 
/*      */       }
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\server\HttpServerOperations.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */