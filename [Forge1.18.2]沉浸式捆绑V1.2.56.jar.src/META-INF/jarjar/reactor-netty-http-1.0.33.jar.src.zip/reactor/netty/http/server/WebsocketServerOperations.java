/*     */ package reactor.netty.http.server;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.channel.Channel;
/*     */ import io.netty.channel.ChannelFuture;
/*     */ import io.netty.channel.ChannelFutureListener;
/*     */ import io.netty.channel.ChannelHandler;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.channel.ChannelPromise;
/*     */ import io.netty.handler.codec.http.DefaultFullHttpRequest;
/*     */ import io.netty.handler.codec.http.HttpHeaderNames;
/*     */ import io.netty.handler.codec.http.HttpHeaders;
/*     */ import io.netty.handler.codec.http.HttpRequest;
/*     */ import io.netty.handler.codec.http.LastHttpContent;
/*     */ import io.netty.handler.codec.http.websocketx.CloseWebSocketFrame;
/*     */ import io.netty.handler.codec.http.websocketx.PingWebSocketFrame;
/*     */ import io.netty.handler.codec.http.websocketx.PongWebSocketFrame;
/*     */ import io.netty.handler.codec.http.websocketx.WebSocketCloseStatus;
/*     */ import io.netty.handler.codec.http.websocketx.WebSocketServerHandshaker;
/*     */ import io.netty.handler.codec.http.websocketx.WebSocketServerHandshakerFactory;
/*     */ import io.netty.handler.codec.http.websocketx.extensions.compression.WebSocketServerCompressionHandler;
/*     */ import io.netty.util.concurrent.Future;
/*     */ import io.netty.util.concurrent.GenericFutureListener;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.core.publisher.Sinks;
/*     */ import reactor.netty.Connection;
/*     */ import reactor.netty.FutureMono;
/*     */ import reactor.netty.NettyOutbound;
/*     */ import reactor.netty.ReactorNetty;
/*     */ import reactor.netty.http.websocket.WebsocketInbound;
/*     */ import reactor.netty.http.websocket.WebsocketOutbound;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class WebsocketServerOperations
/*     */   extends HttpServerOperations
/*     */   implements WebsocketInbound, WebsocketOutbound
/*     */ {
/*     */   final WebSocketServerHandshaker handshaker;
/*     */   final ChannelPromise handshakerResult;
/*     */   final Sinks.One<WebSocketCloseStatus> onCloseState;
/*     */   final boolean proxyPing;
/*     */   volatile int closeSent;
/*     */   static final String INBOUND_CANCEL_LOG = "WebSocket server inbound receiver cancelled, closing Websocket.";
/*     */   
/*     */   WebsocketServerOperations(String wsUrl, WebsocketServerSpec websocketServerSpec, HttpServerOperations replaced) {
/*  72 */     super(replaced);
/*  73 */     this.proxyPing = websocketServerSpec.handlePing();
/*     */     
/*  75 */     Channel channel = replaced.channel();
/*  76 */     this.onCloseState = Sinks.unsafe().one();
/*     */ 
/*     */ 
/*     */     
/*  80 */     WebSocketServerHandshakerFactory wsFactory = new WebSocketServerHandshakerFactory(wsUrl, websocketServerSpec.protocols(), true, websocketServerSpec.maxFramePayloadLength());
/*  81 */     this.handshaker = wsFactory.newHandshaker(replaced.nettyRequest);
/*  82 */     if (this.handshaker == null) {
/*     */       
/*  84 */       WebSocketServerHandshakerFactory.sendUnsupportedVersionResponse(channel);
/*  85 */       this.handshakerResult = null;
/*     */     } else {
/*     */       
/*  88 */       removeHandler("reactor.left.httpTrafficHandler");
/*  89 */       removeHandler("reactor.left.accessLogHandler");
/*  90 */       removeHandler("reactor.left.httpMetricsHandler");
/*     */       
/*  92 */       this.handshakerResult = channel.newPromise();
/*     */ 
/*     */       
/*  95 */       DefaultFullHttpRequest defaultFullHttpRequest = new DefaultFullHttpRequest(replaced.version(), replaced.method(), replaced.uri());
/*     */       
/*  97 */       defaultFullHttpRequest.headers()
/*  98 */         .set(replaced.nettyRequest.headers());
/*     */       
/* 100 */       if (websocketServerSpec.compress()) {
/* 101 */         removeHandler("reactor.left.compressionHandler");
/*     */         
/* 103 */         WebSocketServerCompressionHandler wsServerCompressionHandler = new WebSocketServerCompressionHandler();
/*     */         
/*     */         try {
/* 106 */           wsServerCompressionHandler.channelRead(channel.pipeline()
/* 107 */               .context("reactor.right.reactiveBridge"), defaultFullHttpRequest);
/*     */ 
/*     */           
/* 110 */           addHandlerFirst("reactor.left.wsCompressionHandler", (ChannelHandler)wsServerCompressionHandler);
/*     */         }
/* 112 */         catch (Throwable e) {
/* 113 */           log.error(ReactorNetty.format(channel(), ""), e);
/*     */         } 
/*     */       } 
/*     */       
/* 117 */       this.handshaker.handshake(channel, (HttpRequest)defaultFullHttpRequest, replaced.responseHeaders
/*     */ 
/*     */           
/* 120 */           .remove((CharSequence)HttpHeaderNames.TRANSFER_ENCODING), this.handshakerResult)
/*     */         
/* 122 */         .addListener(f -> {
/*     */             if (replaced.rebind((Connection)this)) {
/*     */               markPersistent(false);
/*     */               channel.read();
/*     */             } else if (log.isDebugEnabled()) {
/*     */               log.debug(ReactorNetty.format(channel, "Cannot bind WebsocketServerOperations after the handshake."));
/*     */             } 
/*     */           });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NettyOutbound send(Publisher<? extends ByteBuf> dataStream) {
/* 137 */     return sendObject((Publisher)Flux.from(dataStream).map(bytebufToWebsocketFrame));
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpHeaders headers() {
/* 142 */     return requestHeaders();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onInboundNext(ChannelHandlerContext ctx, Object frame) {
/* 148 */     if (frame instanceof CloseWebSocketFrame && ((CloseWebSocketFrame)frame).isFinalFragment()) {
/* 149 */       if (log.isDebugEnabled()) {
/* 150 */         log.debug(ReactorNetty.format(channel(), "CloseWebSocketFrame detected. Closing Websocket"));
/*     */       }
/*     */       
/* 153 */       CloseWebSocketFrame closeFrame = new CloseWebSocketFrame(true, ((CloseWebSocketFrame)frame).rsv(), ((CloseWebSocketFrame)frame).content());
/* 154 */       if (closeFrame.statusCode() != -1) {
/*     */         
/* 156 */         sendCloseNow(closeFrame, f -> terminate());
/*     */       }
/*     */       else {
/*     */         
/* 160 */         sendCloseNow(closeFrame, WebSocketCloseStatus.EMPTY, f -> terminate());
/*     */       } 
/*     */       return;
/*     */     } 
/* 164 */     if (!this.proxyPing && frame instanceof PingWebSocketFrame) {
/*     */       
/* 166 */       ctx.writeAndFlush(new PongWebSocketFrame(((PingWebSocketFrame)frame).content()));
/* 167 */       ctx.read();
/*     */       return;
/*     */     } 
/* 170 */     if (frame != LastHttpContent.EMPTY_LAST_CONTENT) {
/* 171 */       super.onInboundNext(ctx, frame);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onOutboundComplete() {}
/*     */ 
/*     */   
/*     */   protected void onOutboundError(Throwable err) {
/* 181 */     if (channel().isActive()) {
/* 182 */       if (log.isDebugEnabled()) {
/* 183 */         log.debug(ReactorNetty.format(channel(), "Outbound error happened"), err);
/*     */       }
/* 185 */       sendCloseNow(new CloseWebSocketFrame(WebSocketCloseStatus.PROTOCOL_ERROR), f -> terminate());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onInboundCancel() {
/* 192 */     if (log.isDebugEnabled()) {
/* 193 */       log.debug(ReactorNetty.format(channel(), "WebSocket server inbound receiver cancelled, closing Websocket."));
/*     */     }
/* 195 */     sendCloseNow(new CloseWebSocketFrame(), WebSocketCloseStatus.ABNORMAL_CLOSURE, f -> terminate());
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> sendClose() {
/* 200 */     return sendClose(new CloseWebSocketFrame());
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> sendClose(int rsv) {
/* 205 */     return sendClose(new CloseWebSocketFrame(true, rsv));
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> sendClose(int statusCode, @Nullable String reasonText) {
/* 210 */     return sendClose(new CloseWebSocketFrame(statusCode, reasonText));
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> sendClose(int rsv, int statusCode, @Nullable String reasonText) {
/* 215 */     return sendClose(new CloseWebSocketFrame(true, rsv, statusCode, reasonText));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<WebSocketCloseStatus> receiveCloseStatus() {
/* 221 */     return this.onCloseState.asMono().or(onTerminate());
/*     */   }
/*     */   
/*     */   Mono<Void> sendClose(CloseWebSocketFrame frame) {
/* 225 */     if (CLOSE_SENT.get(this) == 0)
/*     */     {
/*     */       
/* 228 */       return FutureMono.deferFuture(() -> {
/*     */             if (CLOSE_SENT.getAndSet(this, 1) == 0) {
/*     */               discard();
/*     */ 
/*     */               
/*     */               this.onCloseState.tryEmitValue(new WebSocketCloseStatus(frame.statusCode(), frame.reasonText()));
/*     */               
/*     */               return channel().writeAndFlush(frame).addListener((GenericFutureListener)ChannelFutureListener.CLOSE);
/*     */             } 
/*     */             
/*     */             frame.release();
/*     */             
/*     */             return channel().newSucceededFuture();
/* 241 */           }).doOnCancel(() -> ReactorNetty.safeRelease(frame));
/*     */     }
/* 243 */     frame.release();
/* 244 */     return Mono.empty();
/*     */   }
/*     */   void sendCloseNow(CloseWebSocketFrame frame, ChannelFutureListener listener) {
/* 247 */     sendCloseNow(frame, new WebSocketCloseStatus(frame.statusCode(), frame.reasonText()), listener);
/*     */   }
/*     */ 
/*     */   
/*     */   void sendCloseNow(CloseWebSocketFrame frame, WebSocketCloseStatus closeStatus, ChannelFutureListener listener) {
/* 252 */     if (!frame.isFinalFragment()) {
/*     */       
/* 254 */       channel().writeAndFlush(frame);
/*     */       return;
/*     */     } 
/* 257 */     if (CLOSE_SENT.getAndSet(this, 1) == 0) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 262 */       this.onCloseState.tryEmitValue(closeStatus);
/* 263 */       channel().writeAndFlush(frame)
/* 264 */         .addListener((GenericFutureListener)listener);
/*     */     } else {
/*     */       
/* 267 */       frame.release();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isWebsocket() {
/* 273 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String selectedSubprotocol() {
/* 279 */     return this.handshaker.selectedSubprotocol();
/*     */   }
/*     */ 
/*     */   
/* 283 */   static final AtomicIntegerFieldUpdater<WebsocketServerOperations> CLOSE_SENT = AtomicIntegerFieldUpdater.newUpdater(WebsocketServerOperations.class, "closeSent");
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\server\WebsocketServerOperations.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */