/*     */ package reactor.netty.http.server;
/*     */ 
/*     */ import io.netty.handler.codec.http.HttpRequest;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import reactor.netty.transport.AddressUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class DefaultHttpForwardedHeaderHandler
/*     */   implements BiFunction<ConnectionInfo, HttpRequest, ConnectionInfo>
/*     */ {
/*  33 */   static final DefaultHttpForwardedHeaderHandler INSTANCE = new DefaultHttpForwardedHeaderHandler();
/*     */   
/*     */   static final String FORWARDED_HEADER = "Forwarded";
/*     */   
/*     */   static final String X_FORWARDED_IP_HEADER = "X-Forwarded-For";
/*     */   static final String X_FORWARDED_HOST_HEADER = "X-Forwarded-Host";
/*     */   static final String X_FORWARDED_PORT_HEADER = "X-Forwarded-Port";
/*     */   static final String X_FORWARDED_PROTO_HEADER = "X-Forwarded-Proto";
/*  41 */   static final Pattern FORWARDED_HOST_PATTERN = Pattern.compile("host=\"?([^;,\"]+)\"?");
/*  42 */   static final Pattern FORWARDED_PROTO_PATTERN = Pattern.compile("proto=\"?([^;,\"]+)\"?");
/*  43 */   static final Pattern FORWARDED_FOR_PATTERN = Pattern.compile("for=\"?([^;,\"]+)\"?");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   static final String FORWARDED_HEADER_VALIDATION = "reactor.netty.http.server.forwarded.strictValidation";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  54 */   static final boolean DEFAULT_FORWARDED_HEADER_VALIDATION = Boolean.parseBoolean(System.getProperty("reactor.netty.http.server.forwarded.strictValidation", "true"));
/*     */ 
/*     */   
/*     */   public ConnectionInfo apply(ConnectionInfo connectionInfo, HttpRequest request) {
/*  58 */     String forwardedHeader = request.headers().get("Forwarded");
/*  59 */     if (forwardedHeader != null) {
/*  60 */       return parseForwardedInfo(connectionInfo, forwardedHeader);
/*     */     }
/*  62 */     return parseXForwardedInfo(connectionInfo, request);
/*     */   }
/*     */   
/*     */   private ConnectionInfo parseForwardedInfo(ConnectionInfo connectionInfo, String forwardedHeader) {
/*  66 */     String forwarded = forwardedHeader.split(",", 2)[0];
/*  67 */     Matcher protoMatcher = FORWARDED_PROTO_PATTERN.matcher(forwarded);
/*  68 */     if (protoMatcher.find()) {
/*  69 */       connectionInfo = connectionInfo.withScheme(protoMatcher.group(1).trim());
/*     */     }
/*  71 */     Matcher hostMatcher = FORWARDED_HOST_PATTERN.matcher(forwarded);
/*  72 */     if (hostMatcher.find()) {
/*  73 */       connectionInfo = connectionInfo.withHostAddress(
/*  74 */           AddressUtils.parseAddress(hostMatcher.group(1), 
/*  75 */             ConnectionInfo.getDefaultHostPort(connectionInfo.getScheme()), DEFAULT_FORWARDED_HEADER_VALIDATION));
/*     */     }
/*  77 */     Matcher forMatcher = FORWARDED_FOR_PATTERN.matcher(forwarded);
/*  78 */     if (forMatcher.find()) {
/*  79 */       connectionInfo = connectionInfo.withRemoteAddress(
/*  80 */           AddressUtils.parseAddress(forMatcher.group(1).trim(), connectionInfo.getRemoteAddress().getPort(), DEFAULT_FORWARDED_HEADER_VALIDATION));
/*     */     }
/*     */     
/*  83 */     return connectionInfo;
/*     */   }
/*     */   
/*     */   private ConnectionInfo parseXForwardedInfo(ConnectionInfo connectionInfo, HttpRequest request) {
/*  87 */     String ipHeader = request.headers().get("X-Forwarded-For");
/*  88 */     if (ipHeader != null) {
/*  89 */       connectionInfo = connectionInfo.withRemoteAddress(
/*  90 */           AddressUtils.parseAddress(ipHeader.split(",", 2)[0], connectionInfo.getRemoteAddress().getPort()));
/*     */     }
/*  92 */     String protoHeader = request.headers().get("X-Forwarded-Proto");
/*  93 */     if (protoHeader != null) {
/*  94 */       connectionInfo = connectionInfo.withScheme(protoHeader.split(",", 2)[0].trim());
/*     */     }
/*  96 */     String hostHeader = request.headers().get("X-Forwarded-Host");
/*  97 */     if (hostHeader != null) {
/*  98 */       connectionInfo = connectionInfo.withHostAddress(
/*  99 */           AddressUtils.parseAddress(hostHeader.split(",", 2)[0].trim(), 
/* 100 */             ConnectionInfo.getDefaultHostPort(connectionInfo.getScheme()), DEFAULT_FORWARDED_HEADER_VALIDATION));
/*     */     }
/*     */     
/* 103 */     String portHeader = request.headers().get("X-Forwarded-Port");
/* 104 */     if (portHeader != null && !portHeader.isEmpty()) {
/* 105 */       String portStr = portHeader.split(",", 2)[0].trim();
/* 106 */       if (portStr.chars().allMatch(Character::isDigit)) {
/* 107 */         int port = Integer.parseInt(portStr);
/* 108 */         connectionInfo = connectionInfo.withHostAddress(
/* 109 */             AddressUtils.createUnresolved(connectionInfo.getHostAddress().getHostString(), port), connectionInfo
/* 110 */             .getHostName(), port);
/*     */       }
/* 112 */       else if (DEFAULT_FORWARDED_HEADER_VALIDATION) {
/* 113 */         throw new IllegalArgumentException("Failed to parse a port from " + portHeader);
/*     */       } 
/*     */     } 
/* 116 */     return connectionInfo;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\server\DefaultHttpForwardedHeaderHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */