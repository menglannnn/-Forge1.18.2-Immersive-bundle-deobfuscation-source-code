/*    */ package reactor.netty.http.server;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum ProxyProtocolSupportType
/*    */ {
/* 29 */   AUTO,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 35 */   ON,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 40 */   OFF;
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\server\ProxyProtocolSupportType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */