/*    */ package reactor.netty.http.server;
/*    */ 
/*    */ import io.netty.channel.ChannelFutureListener;
/*    */ import io.netty.channel.ChannelHandler;
/*    */ import io.netty.channel.ChannelHandlerContext;
/*    */ import io.netty.channel.ChannelInboundHandlerAdapter;
/*    */ import io.netty.handler.codec.http.DefaultFullHttpResponse;
/*    */ import io.netty.handler.codec.http.HttpHeaderNames;
/*    */ import io.netty.handler.codec.http.HttpRequest;
/*    */ import io.netty.handler.codec.http.HttpResponseStatus;
/*    */ import io.netty.util.concurrent.GenericFutureListener;
/*    */ import javax.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class NonSslRedirectHandler
/*    */   extends ChannelInboundHandlerAdapter
/*    */ {
/*    */   private static final String HTTP_PROTOCOL = "http://";
/*    */   private static final String HTTPS_PROTOCOL = "https://";
/*    */   
/*    */   public void channelRead(ChannelHandlerContext ctx, Object msg) {
/* 50 */     if (msg instanceof HttpRequest) {
/* 51 */       ctx.pipeline().remove((ChannelHandler)this);
/* 52 */       HttpRequest request = (HttpRequest)msg;
/* 53 */       String url = getRequestedUrlInHttps(request);
/* 54 */       if (url == null) {
/*    */         
/* 56 */         ctx.close();
/*    */       } else {
/*    */         
/* 59 */         DefaultFullHttpResponse defaultFullHttpResponse = new DefaultFullHttpResponse(request.protocolVersion(), HttpResponseStatus.PERMANENT_REDIRECT);
/* 60 */         defaultFullHttpResponse.headers().set((CharSequence)HttpHeaderNames.LOCATION, url);
/* 61 */         ctx.channel().writeAndFlush(defaultFullHttpResponse)
/* 62 */           .addListener((GenericFutureListener)ChannelFutureListener.CLOSE);
/*    */       } 
/*    */     } else {
/*    */       
/* 66 */       ctx.fireChannelRead(msg);
/*    */     } 
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   private String getRequestedUrlInHttps(HttpRequest request) {
/* 72 */     String uri = request.uri();
/* 73 */     boolean isAbsoluteUri = uri.startsWith("http://");
/* 74 */     if (isAbsoluteUri)
/*    */     {
/* 76 */       return "https://" + uri.substring("http://".length());
/*    */     }
/* 78 */     String host = request.headers().get((CharSequence)HttpHeaderNames.HOST);
/* 79 */     if (host == null) {
/* 80 */       return null;
/*    */     }
/* 82 */     return "https://" + host + uri;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\server\NonSslRedirectHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */