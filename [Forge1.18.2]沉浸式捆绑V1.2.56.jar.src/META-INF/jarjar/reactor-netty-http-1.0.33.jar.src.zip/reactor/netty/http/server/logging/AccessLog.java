/*    */ package reactor.netty.http.server.logging;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import reactor.util.Logger;
/*    */ import reactor.util.Loggers;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AccessLog
/*    */ {
/* 34 */   static final Logger LOG = Loggers.getLogger("reactor.netty.http.server.AccessLog");
/*    */   
/*    */   final String logFormat;
/*    */   final Object[] args;
/*    */   
/*    */   private AccessLog(String logFormat, Object... args) {
/* 40 */     Objects.requireNonNull(logFormat, "logFormat");
/* 41 */     this.logFormat = logFormat;
/* 42 */     this.args = args;
/*    */   }
/*    */   
/*    */   public static AccessLog create(String logFormat, Object... args) {
/* 46 */     return new AccessLog(logFormat, args);
/*    */   }
/*    */   
/*    */   void log() {
/* 50 */     if (LOG.isInfoEnabled())
/* 51 */       LOG.info(this.logFormat, this.args); 
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\server\logging\AccessLog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */