/*     */ package reactor.netty.http.server;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.buffer.ByteBufHolder;
/*     */ import io.netty.channel.ChannelDuplexHandler;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.channel.ChannelPromise;
/*     */ import io.netty.handler.codec.http.HttpResponse;
/*     */ import io.netty.handler.codec.http.HttpResponseStatus;
/*     */ import io.netty.util.concurrent.Future;
/*     */ import java.time.Duration;
/*     */ import java.util.function.Function;
/*     */ import reactor.netty.ReactorNetty;
/*     */ import reactor.netty.channel.ChannelOperations;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.Loggers;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class AbstractHttpServerMetricsHandler
/*     */   extends ChannelDuplexHandler
/*     */ {
/*  44 */   private static final Logger log = Loggers.getLogger(AbstractHttpServerMetricsHandler.class);
/*     */   
/*     */   boolean channelActivated;
/*     */   
/*     */   long dataReceived;
/*     */   
/*     */   long dataSent;
/*     */   
/*     */   long dataReceivedTime;
/*     */   
/*     */   long dataSentTime;
/*     */   
/*     */   final Function<String, String> uriTagValue;
/*     */   
/*     */   protected AbstractHttpServerMetricsHandler(@Nullable Function<String, String> uriTagValue) {
/*  59 */     this.uriTagValue = uriTagValue;
/*     */   }
/*     */   
/*     */   protected AbstractHttpServerMetricsHandler(AbstractHttpServerMetricsHandler copy) {
/*  63 */     this.channelActivated = copy.channelActivated;
/*  64 */     this.dataReceived = copy.dataReceived;
/*  65 */     this.dataReceivedTime = copy.dataReceivedTime;
/*  66 */     this.dataSent = copy.dataSent;
/*  67 */     this.dataSentTime = copy.dataSentTime;
/*  68 */     this.uriTagValue = copy.uriTagValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void channelActive(ChannelHandlerContext ctx) {
/*  76 */     if (!(ctx.channel() instanceof io.netty.handler.codec.http2.Http2StreamChannel) && recorder() instanceof MicrometerHttpServerMetricsRecorder) {
/*     */       try {
/*  78 */         recorder().recordServerConnectionOpened(ctx.channel().localAddress());
/*     */       }
/*  80 */       catch (RuntimeException e) {
/*  81 */         if (log.isWarnEnabled()) {
/*  82 */           log.warn(ReactorNetty.format(ctx.channel(), "Exception caught while recording metrics."), e);
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*  87 */     ctx.fireChannelActive();
/*     */   }
/*     */ 
/*     */   
/*     */   public void channelInactive(ChannelHandlerContext ctx) {
/*  92 */     if (!(ctx.channel() instanceof io.netty.handler.codec.http2.Http2StreamChannel) && recorder() instanceof MicrometerHttpServerMetricsRecorder) {
/*     */       try {
/*  94 */         recorder().recordServerConnectionClosed(ctx.channel().localAddress());
/*     */       }
/*  96 */       catch (RuntimeException e) {
/*  97 */         if (log.isWarnEnabled()) {
/*  98 */           log.warn(ReactorNetty.format(ctx.channel(), "Exception caught while recording metrics."), e);
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 103 */     ChannelOperations<?, ?> channelOps = ChannelOperations.get(ctx.channel());
/* 104 */     if (channelOps instanceof HttpServerOperations) {
/* 105 */       recordInactiveConnectionOrStream((HttpServerOperations)channelOps);
/*     */     }
/* 107 */     ctx.fireChannelInactive();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(ChannelHandlerContext ctx, Object msg, ChannelPromise promise) {
/*     */     try {
/* 114 */       if (msg instanceof HttpResponse) {
/* 115 */         if (((HttpResponse)msg).status().equals(HttpResponseStatus.CONTINUE)) {
/*     */           return;
/*     */         }
/*     */         
/* 119 */         this.dataSentTime = System.nanoTime();
/*     */       } 
/*     */       
/* 122 */       this.dataSent += extractProcessedDataFromBuffer(msg);
/*     */       
/* 124 */       if (msg instanceof io.netty.handler.codec.http.LastHttpContent) {
/* 125 */         promise.addListener(future -> {
/*     */               ChannelOperations<?, ?> channelOps = ChannelOperations.get(ctx.channel());
/*     */               
/*     */               if (channelOps instanceof HttpServerOperations) {
/*     */                 HttpServerOperations ops = (HttpServerOperations)channelOps;
/*     */                 
/*     */                 try {
/*     */                   recordWrite(ops, (this.uriTagValue == null) ? ops.path : this.uriTagValue.apply(ops.path), ops.method().name(), ops.status().codeAsText().toString());
/* 133 */                 } catch (RuntimeException e) {
/*     */                   if (log.isWarnEnabled()) {
/*     */                     log.warn(ReactorNetty.format(ctx.channel(), "Exception caught while recording metrics."), e);
/*     */                   }
/*     */                 } 
/*     */ 
/*     */                 
/*     */                 recordInactiveConnectionOrStream(ops);
/*     */               } 
/*     */               
/*     */               this.dataSent = 0L;
/*     */             });
/*     */       }
/* 146 */     } catch (RuntimeException e) {
/* 147 */       if (log.isWarnEnabled()) {
/* 148 */         log.warn(ReactorNetty.format(ctx.channel(), "Exception caught while recording metrics."), e);
/*     */       
/*     */       }
/*     */     }
/*     */     finally {
/*     */       
/* 154 */       ctx.write(msg, promise);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void channelRead(ChannelHandlerContext ctx, Object msg) {
/*     */     try {
/* 161 */       if (msg instanceof io.netty.handler.codec.http.HttpRequest) {
/* 162 */         this.dataReceivedTime = System.nanoTime();
/* 163 */         ChannelOperations<?, ?> channelOps = ChannelOperations.get(ctx.channel());
/* 164 */         if (channelOps instanceof HttpServerOperations) {
/* 165 */           this.channelActivated = true;
/* 166 */           HttpServerOperations ops = (HttpServerOperations)channelOps;
/* 167 */           if (ops.isHttp2()) {
/* 168 */             recordOpenStream(ops);
/*     */           } else {
/*     */             
/* 171 */             recordActiveConnection(ops);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 176 */       this.dataReceived += extractProcessedDataFromBuffer(msg);
/*     */       
/* 178 */       if (msg instanceof io.netty.handler.codec.http.LastHttpContent) {
/* 179 */         ChannelOperations<?, ?> channelOps = ChannelOperations.get(ctx.channel());
/* 180 */         if (channelOps instanceof HttpServerOperations) {
/* 181 */           HttpServerOperations ops = (HttpServerOperations)channelOps;
/* 182 */           recordRead(ops, (this.uriTagValue == null) ? ops.path : this.uriTagValue.apply(ops.path), ops.method().name());
/*     */         } 
/*     */         
/* 185 */         this.dataReceived = 0L;
/*     */       }
/*     */     
/* 188 */     } catch (RuntimeException e) {
/* 189 */       if (log.isWarnEnabled()) {
/* 190 */         log.warn(ReactorNetty.format(ctx.channel(), "Exception caught while recording metrics."), e);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 195 */     ctx.fireChannelRead(msg);
/*     */   }
/*     */ 
/*     */   
/*     */   public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) {
/*     */     try {
/* 201 */       ChannelOperations<?, ?> channelOps = ChannelOperations.get(ctx.channel());
/* 202 */       if (channelOps instanceof HttpServerOperations) {
/* 203 */         HttpServerOperations ops = (HttpServerOperations)channelOps;
/*     */         
/* 205 */         recordException(ops, (this.uriTagValue == null) ? ops.path : this.uriTagValue.apply(ops.path));
/*     */       }
/*     */     
/* 208 */     } catch (RuntimeException e) {
/* 209 */       if (log.isWarnEnabled()) {
/* 210 */         log.warn(ReactorNetty.format(ctx.channel(), "Exception caught while recording metrics."), e);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 215 */     ctx.fireExceptionCaught(cause);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private long extractProcessedDataFromBuffer(Object msg) {
/* 221 */     if (msg instanceof ByteBufHolder) {
/* 222 */       return ((ByteBufHolder)msg).content().readableBytes();
/*     */     }
/* 224 */     if (msg instanceof ByteBuf) {
/* 225 */       return ((ByteBuf)msg).readableBytes();
/*     */     }
/* 227 */     return 0L;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void recordException(HttpServerOperations ops, String path) {
/* 233 */     recorder().incrementErrorsCount(ops.remoteSocketAddress(), path);
/*     */   }
/*     */   
/*     */   protected void recordRead(HttpServerOperations ops, String path, String method) {
/* 237 */     recorder().recordDataReceivedTime(path, method, Duration.ofNanos(System.nanoTime() - this.dataReceivedTime));
/*     */ 
/*     */ 
/*     */     
/* 241 */     recorder().recordDataReceived(ops.remoteSocketAddress(), path, this.dataReceived);
/*     */   }
/*     */   
/*     */   protected void recordWrite(HttpServerOperations ops, String path, String method, String status) {
/* 245 */     Duration dataSentTimeDuration = Duration.ofNanos(System.nanoTime() - this.dataSentTime);
/* 246 */     recorder().recordDataSentTime(path, method, status, dataSentTimeDuration);
/*     */     
/* 248 */     if (this.dataReceivedTime != 0L) {
/* 249 */       recorder().recordResponseTime(path, method, status, Duration.ofNanos(System.nanoTime() - this.dataReceivedTime));
/*     */     } else {
/*     */       
/* 252 */       recorder().recordResponseTime(path, method, status, dataSentTimeDuration);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 257 */     recorder().recordDataSent(ops.remoteSocketAddress(), path, this.dataSent);
/*     */   }
/*     */   
/*     */   protected void recordActiveConnection(HttpServerOperations ops) {
/* 261 */     recorder().recordServerConnectionActive(ops.hostSocketAddress());
/*     */   }
/*     */   
/*     */   protected void recordInactiveConnection(HttpServerOperations ops) {
/* 265 */     recorder().recordServerConnectionInactive(ops.hostSocketAddress());
/*     */   }
/*     */   
/*     */   protected void recordOpenStream(HttpServerOperations ops) {
/* 269 */     recorder().recordStreamOpened(ops.hostSocketAddress());
/*     */   }
/*     */   
/*     */   protected void recordClosedStream(HttpServerOperations ops) {
/* 273 */     recorder().recordStreamClosed(ops.hostSocketAddress());
/*     */   }
/*     */   
/*     */   void recordInactiveConnectionOrStream(HttpServerOperations ops) {
/* 277 */     if (this.channelActivated) {
/* 278 */       this.channelActivated = false;
/*     */       try {
/* 280 */         if (ops.isHttp2()) {
/* 281 */           recordClosedStream(ops);
/*     */         } else {
/*     */           
/* 284 */           recordInactiveConnection(ops);
/*     */         }
/*     */       
/* 287 */       } catch (RuntimeException e) {
/* 288 */         if (log.isWarnEnabled())
/* 289 */           log.warn(ReactorNetty.format(ops.channel(), "Exception caught while recording metrics."), e); 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   protected abstract HttpServerMetricsRecorder recorder();
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\server\AbstractHttpServerMetricsHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */