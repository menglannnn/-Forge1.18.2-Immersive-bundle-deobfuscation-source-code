/*     */ package reactor.netty.http.server;
/*     */ 
/*     */ import io.netty.handler.codec.http.HttpHeaders;
/*     */ import io.netty.handler.codec.http.HttpResponseStatus;
/*     */ import io.netty.handler.codec.http.cookie.Cookie;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.Consumer;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.netty.Connection;
/*     */ import reactor.netty.NettyOutbound;
/*     */ import reactor.netty.http.websocket.WebsocketInbound;
/*     */ import reactor.netty.http.websocket.WebsocketOutbound;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface HttpServerResponse
/*     */   extends NettyOutbound, HttpServerInfos
/*     */ {
/*     */   default Mono<Void> sendWebsocket(BiFunction<? super WebsocketInbound, ? super WebsocketOutbound, ? extends Publisher<Void>> websocketHandler) {
/* 161 */     return sendWebsocket(websocketHandler, WebsocketServerSpec.builder().build());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default HttpServerResponse status(int status) {
/* 207 */     return status(HttpResponseStatus.valueOf(status));
/*     */   }
/*     */   
/*     */   HttpServerResponse addCookie(Cookie paramCookie);
/*     */   
/*     */   HttpServerResponse addHeader(CharSequence paramCharSequence1, CharSequence paramCharSequence2);
/*     */   
/*     */   HttpServerResponse chunkedTransfer(boolean paramBoolean);
/*     */   
/*     */   HttpServerResponse withConnection(Consumer<? super Connection> paramConsumer);
/*     */   
/*     */   HttpServerResponse compression(boolean paramBoolean);
/*     */   
/*     */   boolean hasSentHeaders();
/*     */   
/*     */   HttpServerResponse header(CharSequence paramCharSequence1, CharSequence paramCharSequence2);
/*     */   
/*     */   HttpServerResponse headers(HttpHeaders paramHttpHeaders);
/*     */   
/*     */   HttpServerResponse keepAlive(boolean paramBoolean);
/*     */   
/*     */   HttpHeaders responseHeaders();
/*     */   
/*     */   Mono<Void> send();
/*     */   
/*     */   NettyOutbound sendHeaders();
/*     */   
/*     */   Mono<Void> sendNotFound();
/*     */   
/*     */   Mono<Void> sendRedirect(String paramString);
/*     */   
/*     */   Mono<Void> sendWebsocket(BiFunction<? super WebsocketInbound, ? super WebsocketOutbound, ? extends Publisher<Void>> paramBiFunction, WebsocketServerSpec paramWebsocketServerSpec);
/*     */   
/*     */   HttpServerResponse sse();
/*     */   
/*     */   HttpResponseStatus status();
/*     */   
/*     */   HttpServerResponse status(HttpResponseStatus paramHttpResponseStatus);
/*     */   
/*     */   HttpServerResponse trailerHeaders(Consumer<? super HttpHeaders> paramConsumer);
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\server\HttpServerResponse.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */