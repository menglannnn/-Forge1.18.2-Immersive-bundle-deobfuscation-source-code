/*     */ package reactor.netty.http.server;
/*     */ 
/*     */ import io.netty.channel.ChannelOption;
/*     */ import io.netty.channel.EventLoopGroup;
/*     */ import io.netty.channel.group.ChannelGroup;
/*     */ import io.netty.handler.logging.LogLevel;
/*     */ import io.netty.util.AttributeKey;
/*     */ import java.net.SocketAddress;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Supplier;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.netty.ChannelPipelineConfigurer;
/*     */ import reactor.netty.Connection;
/*     */ import reactor.netty.ConnectionObserver;
/*     */ import reactor.netty.DisposableServer;
/*     */ import reactor.netty.NettyInbound;
/*     */ import reactor.netty.NettyOutbound;
/*     */ import reactor.netty.channel.ChannelMetricsRecorder;
/*     */ import reactor.netty.resources.LoopResources;
/*     */ import reactor.netty.tcp.SslProvider;
/*     */ import reactor.netty.tcp.TcpServer;
/*     */ import reactor.netty.tcp.TcpServerConfig;
/*     */ import reactor.netty.transport.ServerTransport;
/*     */ import reactor.netty.transport.Transport;
/*     */ import reactor.netty.transport.TransportConfig;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ final class HttpServerTcpConfig
/*     */   extends TcpServer
/*     */ {
/*     */   HttpServer httpServer;
/*     */   
/*     */   HttpServerTcpConfig(HttpServer httpServer) {
/*  55 */     this.httpServer = httpServer;
/*     */   }
/*     */ 
/*     */   
/*     */   public <A> TcpServer attr(AttributeKey<A> key, @Nullable A value) {
/*  60 */     this.httpServer = (HttpServer)this.httpServer.attr(key, value);
/*  61 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<? extends DisposableServer> bind() {
/*  66 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpServer bindAddress(Supplier<? extends SocketAddress> bindAddressSupplier) {
/*  71 */     this.httpServer = this.httpServer.bindAddress(bindAddressSupplier);
/*  72 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpServer channelGroup(ChannelGroup channelGroup) {
/*  77 */     this.httpServer = this.httpServer.channelGroup(channelGroup);
/*  78 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public <A> TcpServer childAttr(AttributeKey<A> key, @Nullable A value) {
/*  83 */     this.httpServer = (HttpServer)this.httpServer.childAttr(key, value);
/*  84 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpServer childObserve(ConnectionObserver observer) {
/*  89 */     this.httpServer = (HttpServer)this.httpServer.childObserve(observer);
/*  90 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public <A> TcpServer childOption(ChannelOption<A> key, @Nullable A value) {
/*  95 */     this.httpServer = (HttpServer)this.httpServer.childOption(key, value);
/*  96 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpServerConfig configuration() {
/* 101 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpServer doOnBind(Consumer<? super TcpServerConfig> doOnBind) {
/* 106 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpServer doOnBound(Consumer<? super DisposableServer> doOnBound) {
/* 111 */     this.httpServer = (HttpServer)this.httpServer.doOnBound(doOnBound);
/* 112 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpServer doOnChannelInit(ChannelPipelineConfigurer doOnChannelInit) {
/* 117 */     this.httpServer = (HttpServer)this.httpServer.doOnChannelInit(doOnChannelInit);
/* 118 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpServer doOnConnection(Consumer<? super Connection> doOnConnection) {
/* 123 */     this.httpServer = (HttpServer)this.httpServer.doOnConnection(doOnConnection);
/* 124 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpServer doOnUnbound(Consumer<? super DisposableServer> doOnUnbound) {
/* 129 */     this.httpServer = (HttpServer)this.httpServer.doOnUnbound(doOnUnbound);
/* 130 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpServer handle(BiFunction<? super NettyInbound, ? super NettyOutbound, ? extends Publisher<Void>> handler) {
/* 135 */     this.httpServer = this.httpServer.handle((BiFunction)handler);
/* 136 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpServer host(String host) {
/* 141 */     this.httpServer = this.httpServer.host(host);
/* 142 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpServer metrics(boolean enable) {
/* 147 */     this.httpServer = this.httpServer.metrics(enable, Function.identity());
/* 148 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpServer metrics(boolean enable, Supplier<? extends ChannelMetricsRecorder> recorder) {
/* 153 */     this.httpServer = this.httpServer.metrics(enable, recorder);
/* 154 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpServer observe(ConnectionObserver observer) {
/* 159 */     this.httpServer = (HttpServer)this.httpServer.observe(observer);
/* 160 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public <O> TcpServer option(ChannelOption<O> key, @Nullable O value) {
/* 165 */     this.httpServer = (HttpServer)this.httpServer.option(key, value);
/* 166 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpServer noSSL() {
/* 171 */     this.httpServer = this.httpServer.noSSL();
/* 172 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpServer port(int port) {
/* 177 */     this.httpServer = this.httpServer.port(port);
/* 178 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpServer runOn(EventLoopGroup eventLoopGroup) {
/* 183 */     this.httpServer = (HttpServer)this.httpServer.runOn(eventLoopGroup);
/* 184 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpServer runOn(LoopResources channelResources) {
/* 189 */     this.httpServer = (HttpServer)this.httpServer.runOn(channelResources);
/* 190 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpServer runOn(LoopResources loopResources, boolean preferNative) {
/* 195 */     this.httpServer = (HttpServer)this.httpServer.runOn(loopResources, preferNative);
/* 196 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpServer secure(Consumer<? super SslProvider.SslContextSpec> sslProviderBuilder) {
/* 201 */     this.httpServer = this.httpServer.secure(sslProviderBuilder);
/* 202 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpServer secure(SslProvider sslProvider) {
/* 207 */     this.httpServer = this.httpServer.secure(sslProvider);
/* 208 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpServer wiretap(boolean enable) {
/* 213 */     this.httpServer = this.httpServer.wiretap(enable);
/* 214 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpServer wiretap(String category) {
/* 219 */     this.httpServer = (HttpServer)this.httpServer.wiretap(category);
/* 220 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpServer wiretap(String category, LogLevel level) {
/* 225 */     this.httpServer = (HttpServer)this.httpServer.wiretap(category, level);
/* 226 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   protected TcpServer duplicate() {
/* 231 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\server\HttpServerTcpConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */