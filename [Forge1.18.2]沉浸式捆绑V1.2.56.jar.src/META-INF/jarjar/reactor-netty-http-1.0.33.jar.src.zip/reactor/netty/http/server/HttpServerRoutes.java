/*     */ package reactor.netty.http.server;
/*     */ 
/*     */ import io.netty.handler.codec.http.HttpHeaderNames;
/*     */ import io.netty.handler.codec.http.HttpHeaderValues;
/*     */ import io.netty.handler.codec.http.HttpMethod;
/*     */ import java.net.URI;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.Path;
/*     */ import java.nio.file.Paths;
/*     */ import java.util.Comparator;
/*     */ import java.util.Objects;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Predicate;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.netty.ByteBufFlux;
/*     */ import reactor.netty.http.websocket.WebsocketInbound;
/*     */ import reactor.netty.http.websocket.WebsocketOutbound;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface HttpServerRoutes
/*     */   extends BiFunction<HttpServerRequest, HttpServerResponse, Publisher<Void>>
/*     */ {
/*     */   public static final Predicate<HttpServerRequest> INDEX_PREDICATE;
/*     */   
/*     */   static HttpServerRoutes newRoutes() {
/*  52 */     return new DefaultHttpServerRoutes();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default HttpServerRoutes delete(String path, BiFunction<? super HttpServerRequest, ? super HttpServerResponse, ? extends Publisher<Void>> handler) {
/*  69 */     return route(HttpPredicate.delete(path), handler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default HttpServerRoutes directory(String uri, Path directory) {
/*  85 */     return directory(uri, directory, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default HttpServerRoutes file(String uri, Path path) {
/* 116 */     return file(HttpPredicate.get(uri), path, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default HttpServerRoutes file(String uri, String path) {
/* 131 */     Objects.requireNonNull(path, "path");
/* 132 */     return file(HttpPredicate.get(uri), Paths.get(path, new String[0]), null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default HttpServerRoutes file(Predicate<HttpServerRequest> uri, Path path, @Nullable Function<HttpServerResponse, HttpServerResponse> interceptor) {
/* 150 */     Objects.requireNonNull(path, "path");
/* 151 */     return route(uri, (req, resp) -> !Files.isReadable(path) ? resp.send((Publisher)ByteBufFlux.fromPath(path)) : ((interceptor != null) ? ((HttpServerResponse)interceptor.apply(resp)).sendFile(path) : resp.sendFile(path)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default HttpServerRoutes get(String path, BiFunction<? super HttpServerRequest, ? super HttpServerResponse, ? extends Publisher<Void>> handler) {
/* 176 */     return route(HttpPredicate.get(path), handler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default HttpServerRoutes head(String path, BiFunction<? super HttpServerRequest, ? super HttpServerResponse, ? extends Publisher<Void>> handler) {
/* 192 */     return route(HttpPredicate.head(path), handler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default HttpServerRoutes index(BiFunction<? super HttpServerRequest, ? super HttpServerResponse, ? extends Publisher<Void>> handler) {
/* 203 */     return route(INDEX_PREDICATE, handler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default HttpServerRoutes options(String path, BiFunction<? super HttpServerRequest, ? super HttpServerResponse, ? extends Publisher<Void>> handler) {
/* 219 */     return route(HttpPredicate.options(path), handler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default HttpServerRoutes post(String path, BiFunction<? super HttpServerRequest, ? super HttpServerResponse, ? extends Publisher<Void>> handler) {
/* 235 */     return route(HttpPredicate.post(path), handler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default HttpServerRoutes put(String path, BiFunction<? super HttpServerRequest, ? super HttpServerResponse, ? extends Publisher<Void>> handler) {
/* 251 */     return route(HttpPredicate.put(path), handler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default HttpServerRoutes ws(String path, BiFunction<? super WebsocketInbound, ? super WebsocketOutbound, ? extends Publisher<Void>> handler) {
/* 309 */     return ws(path, handler, WebsocketServerSpec.builder().build());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default HttpServerRoutes ws(String path, BiFunction<? super WebsocketInbound, ? super WebsocketOutbound, ? extends Publisher<Void>> handler, WebsocketServerSpec configurer) {
/* 328 */     return ws(HttpPredicate.get(path), handler, configurer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default HttpServerRoutes ws(Predicate<? super HttpServerRequest> condition, BiFunction<? super WebsocketInbound, ? super WebsocketOutbound, ? extends Publisher<Void>> handler, WebsocketServerSpec websocketServerSpec) {
/* 343 */     return route(condition, (req, resp) -> {
/*     */           if (req.requestHeaders().containsValue((CharSequence)HttpHeaderNames.CONNECTION, (CharSequence)HttpHeaderValues.UPGRADE, true)) {
/*     */             HttpServerOperations ops = (HttpServerOperations)req;
/*     */             return (Publisher)ops.withWebsocketSupport(req.uri(), websocketServerSpec, handler);
/*     */           } 
/*     */           return (Publisher)resp.sendNotFound();
/*     */         });
/*     */   }
/*     */   
/*     */   static {
/* 353 */     INDEX_PREDICATE = (req -> {
/*     */         URI uri = URI.create(req.uri());
/* 355 */         return (Objects.equals(req.method(), HttpMethod.GET) && (uri.getPath().endsWith("/") || uri.getPath().indexOf('.', uri.getPath().lastIndexOf('/')) == -1));
/*     */       });
/*     */   }
/*     */   
/*     */   HttpServerRoutes directory(String paramString, Path paramPath, @Nullable Function<HttpServerResponse, HttpServerResponse> paramFunction);
/*     */   
/*     */   HttpServerRoutes removeIf(Predicate<? super HttpRouteHandlerMetadata> paramPredicate);
/*     */   
/*     */   HttpServerRoutes route(Predicate<? super HttpServerRequest> paramPredicate, BiFunction<? super HttpServerRequest, ? super HttpServerResponse, ? extends Publisher<Void>> paramBiFunction);
/*     */   
/*     */   HttpServerRoutes comparator(Comparator<HttpRouteHandlerMetadata> paramComparator);
/*     */   
/*     */   HttpServerRoutes noComparator();
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\server\HttpServerRoutes.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */