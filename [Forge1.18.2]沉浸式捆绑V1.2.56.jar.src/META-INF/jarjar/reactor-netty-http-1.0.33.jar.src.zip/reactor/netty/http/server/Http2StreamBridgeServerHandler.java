/*     */ package reactor.netty.http.server;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.channel.ChannelDuplexHandler;
/*     */ import io.netty.channel.ChannelFuture;
/*     */ import io.netty.channel.ChannelFutureListener;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.channel.ChannelPromise;
/*     */ import io.netty.handler.codec.DecoderResult;
/*     */ import io.netty.handler.codec.http.DefaultHttpContent;
/*     */ import io.netty.handler.codec.http.HttpRequest;
/*     */ import io.netty.handler.codec.http.cookie.ServerCookieDecoder;
/*     */ import io.netty.handler.codec.http.cookie.ServerCookieEncoder;
/*     */ import io.netty.handler.ssl.SslHandler;
/*     */ import io.netty.util.ReferenceCountUtil;
/*     */ import io.netty.util.concurrent.Future;
/*     */ import io.netty.util.concurrent.GenericFutureListener;
/*     */ import java.net.SocketAddress;
/*     */ import java.time.ZonedDateTime;
/*     */ import java.util.Optional;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.BiPredicate;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.netty.Connection;
/*     */ import reactor.netty.ConnectionObserver;
/*     */ import reactor.netty.ReactorNetty;
/*     */ import reactor.netty.http.logging.HttpMessageArgProviderFactory;
/*     */ import reactor.netty.http.logging.HttpMessageLogFactory;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class Http2StreamBridgeServerHandler
/*     */   extends ChannelDuplexHandler
/*     */   implements ChannelFutureListener
/*     */ {
/*     */   final BiPredicate<HttpServerRequest, HttpServerResponse> compress;
/*     */   final ServerCookieDecoder cookieDecoder;
/*     */   final ServerCookieEncoder cookieEncoder;
/*     */   final HttpServerFormDecoderProvider formDecoderProvider;
/*     */   final BiFunction<ConnectionInfo, HttpRequest, ConnectionInfo> forwardedHeaderHandler;
/*     */   final HttpMessageLogFactory httpMessageLogFactory;
/*     */   final ConnectionObserver listener;
/*     */   final BiFunction<? super Mono<Void>, ? super Connection, ? extends Mono<Void>> mapHandle;
/*     */   SocketAddress remoteAddress;
/*     */   Boolean secured;
/*     */   boolean pendingResponse;
/*     */   
/*     */   Http2StreamBridgeServerHandler(@Nullable BiPredicate<HttpServerRequest, HttpServerResponse> compress, ServerCookieDecoder decoder, ServerCookieEncoder encoder, HttpServerFormDecoderProvider formDecoderProvider, @Nullable BiFunction<ConnectionInfo, HttpRequest, ConnectionInfo> forwardedHeaderHandler, HttpMessageLogFactory httpMessageLogFactory, ConnectionObserver listener, @Nullable BiFunction<? super Mono<Void>, ? super Connection, ? extends Mono<Void>> mapHandle) {
/*  87 */     this.compress = compress;
/*  88 */     this.cookieDecoder = decoder;
/*  89 */     this.cookieEncoder = encoder;
/*  90 */     this.formDecoderProvider = formDecoderProvider;
/*  91 */     this.forwardedHeaderHandler = forwardedHeaderHandler;
/*  92 */     this.httpMessageLogFactory = httpMessageLogFactory;
/*  93 */     this.listener = listener;
/*  94 */     this.mapHandle = mapHandle;
/*     */   }
/*     */ 
/*     */   
/*     */   public void handlerAdded(ChannelHandlerContext ctx) {
/*  99 */     if (HttpServerOperations.log.isDebugEnabled()) {
/* 100 */       HttpServerOperations.log.debug(ReactorNetty.format(ctx.channel(), "New HTTP/2 stream"));
/*     */     }
/* 102 */     ctx.read();
/*     */   }
/*     */ 
/*     */   
/*     */   public void channelRead(ChannelHandlerContext ctx, Object msg) {
/* 107 */     if (this.secured == null) {
/* 108 */       this.secured = Boolean.valueOf((ctx.channel().parent().pipeline().get(SslHandler.class) != null));
/*     */     }
/* 110 */     if (this.remoteAddress == null) {
/* 111 */       this
/*     */         
/* 113 */         .remoteAddress = Optional.<SocketAddress>ofNullable(HAProxyMessageReader.resolveRemoteAddressFromProxyProtocol(ctx.channel().parent())).orElse(ctx.channel().parent().remoteAddress());
/*     */     }
/* 115 */     if (msg instanceof HttpRequest) {
/* 116 */       HttpServerOperations ops; HttpRequest request = (HttpRequest)msg;
/*     */       
/* 118 */       ZonedDateTime timestamp = ZonedDateTime.now(ReactorNetty.ZONE_ID_SYSTEM);
/* 119 */       ConnectionInfo connectionInfo = null;
/*     */       try {
/* 121 */         this.pendingResponse = true;
/* 122 */         connectionInfo = ConnectionInfo.from(ctx.channel(), request, this.secured
/*     */             
/* 124 */             .booleanValue(), this.remoteAddress, this.forwardedHeaderHandler);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 138 */         ops = new HttpServerOperations(Connection.from(ctx.channel()), this.listener, request, this.compress, connectionInfo, this.cookieDecoder, this.cookieEncoder, this.formDecoderProvider, this.httpMessageLogFactory, true, this.mapHandle, this.secured.booleanValue(), timestamp);
/*     */       
/*     */       }
/* 141 */       catch (RuntimeException e) {
/* 142 */         this.pendingResponse = false;
/* 143 */         request.setDecoderResult(DecoderResult.failure((e.getCause() != null) ? e.getCause() : e));
/* 144 */         HttpServerOperations.sendDecodingFailures(ctx, this.listener, this.secured.booleanValue(), e, msg, this.httpMessageLogFactory, true, timestamp, connectionInfo, this.remoteAddress);
/*     */         return;
/*     */       } 
/* 147 */       ops.bind();
/* 148 */       this.listener.onStateChange((Connection)ops, ConnectionObserver.State.CONFIGURED);
/*     */     }
/* 150 */     else if (!this.pendingResponse) {
/* 151 */       if (HttpServerOperations.log.isDebugEnabled())
/* 152 */         HttpServerOperations.log.debug(
/* 153 */             ReactorNetty.format(ctx.channel(), "Dropped HTTP content, since response has been sent already: {}"), new Object[] {
/* 154 */               (msg instanceof io.netty.handler.codec.http.HttpObject) ? 
/* 155 */               this.httpMessageLogFactory.debug(HttpMessageArgProviderFactory.create(msg)) : msg
/*     */             }); 
/* 157 */       ReferenceCountUtil.release(msg);
/* 158 */       ctx.read();
/*     */       return;
/*     */     } 
/* 161 */     ctx.fireChannelRead(msg);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(ChannelHandlerContext ctx, Object msg, ChannelPromise promise) {
/* 167 */     if (msg instanceof ByteBuf) {
/*     */       
/* 169 */       ctx.write(new DefaultHttpContent((ByteBuf)msg), promise);
/*     */     }
/*     */     else {
/*     */       
/* 173 */       ChannelFuture f = ctx.write(msg, promise);
/* 174 */       if (msg instanceof io.netty.handler.codec.http.LastHttpContent) {
/* 175 */         this.pendingResponse = false;
/* 176 */         f.addListener((GenericFutureListener)this);
/* 177 */         ctx.read();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void operationComplete(ChannelFuture future) {
/* 184 */     if (!future.isSuccess()) {
/* 185 */       if (HttpServerOperations.log.isDebugEnabled()) {
/* 186 */         HttpServerOperations.log.debug(ReactorNetty.format(future.channel(), "Sending last HTTP packet was not successful, terminating the channel"), future
/*     */             
/* 188 */             .cause());
/*     */       
/*     */       }
/*     */     }
/* 192 */     else if (HttpServerOperations.log.isDebugEnabled()) {
/* 193 */       HttpServerOperations.log.debug(ReactorNetty.format(future.channel(), "Last HTTP packet was sent, terminating the channel"));
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 198 */     HttpServerOperations.cleanHandlerTerminate(future.channel());
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\server\Http2StreamBridgeServerHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */