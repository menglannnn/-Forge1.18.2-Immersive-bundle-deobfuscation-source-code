/*    */ package reactor.netty.http.server;
/*    */ 
/*    */ import io.netty.channel.ChannelHandler;
/*    */ import io.netty.channel.ChannelHandlerContext;
/*    */ import io.netty.channel.ChannelPipeline;
/*    */ import io.netty.handler.codec.http.HttpServerCodec;
/*    */ import io.netty.handler.codec.http.HttpServerUpgradeHandler;
/*    */ import io.netty.handler.timeout.IdleState;
/*    */ import io.netty.handler.timeout.IdleStateEvent;
/*    */ import io.netty.handler.timeout.IdleStateHandler;
/*    */ import java.time.Duration;
/*    */ import java.util.concurrent.TimeUnit;
/*    */ import reactor.netty.ReactorNetty;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class IdleTimeoutHandler
/*    */   extends IdleStateHandler
/*    */ {
/*    */   IdleTimeoutHandler(long idleTimeout) {
/* 37 */     super(idleTimeout, 0L, 0L, TimeUnit.MILLISECONDS);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void channelIdle(ChannelHandlerContext ctx, IdleStateEvent evt) {
/* 43 */     if (evt.state() == IdleState.READER_IDLE) {
/* 44 */       if (HttpServerOperations.log.isDebugEnabled()) {
/* 45 */         HttpServerOperations.log.debug(ReactorNetty.format(ctx.channel(), "Connection was idle for [{}ms], as per configuration the connection will be closed."), new Object[] {
/*    */               
/* 47 */               Long.valueOf(getReaderIdleTimeInMillis())
/*    */             });
/*    */       }
/* 50 */       ctx.close();
/*    */     } 
/* 52 */     ctx.fireUserEventTriggered(evt);
/*    */   }
/*    */   
/*    */   static void addIdleTimeoutHandler(ChannelPipeline pipeline, @Nullable Duration idleTimeout) {
/* 56 */     if (pipeline.get("reactor.left.idleTimeoutHandler") == null && idleTimeout != null) {
/* 57 */       String baseName = null;
/* 58 */       if (pipeline.get("reactor.left.httpCodec") != null) {
/* 59 */         baseName = "reactor.left.httpCodec";
/*    */       } else {
/*    */         
/* 62 */         ChannelHandler httpServerUpgradeHandler = pipeline.get(HttpServerUpgradeHandler.class);
/* 63 */         if (httpServerUpgradeHandler != null) {
/* 64 */           baseName = pipeline.context(httpServerUpgradeHandler).name();
/*    */         } else {
/*    */           
/* 67 */           ChannelHandler httpServerCodec = pipeline.get(HttpServerCodec.class);
/* 68 */           if (httpServerCodec != null) {
/* 69 */             baseName = pipeline.context(httpServerCodec).name();
/*    */           }
/*    */         } 
/*    */       } 
/*    */       
/* 74 */       pipeline.addAfter(baseName, "reactor.left.idleTimeoutHandler", (ChannelHandler)new IdleTimeoutHandler(idleTimeout
/*    */             
/* 76 */             .toMillis()));
/*    */     } 
/*    */   }
/*    */   
/*    */   static void removeIdleTimeoutHandler(ChannelPipeline pipeline) {
/* 81 */     if (pipeline.get("reactor.left.idleTimeoutHandler") != null)
/* 82 */       pipeline.remove("reactor.left.idleTimeoutHandler"); 
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\server\IdleTimeoutHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */