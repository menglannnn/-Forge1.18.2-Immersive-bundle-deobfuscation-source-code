/*    */ package reactor.netty.http.server.logging;
/*    */ 
/*    */ import io.netty.handler.codec.http.HttpResponse;
/*    */ import java.net.SocketAddress;
/*    */ import java.util.Objects;
/*    */ import reactor.netty.http.server.ConnectionInformation;
/*    */ import reactor.netty.http.server.HttpServerRequest;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class AccessLogArgProviderH1
/*    */   extends AbstractAccessLogArgProvider<AccessLogArgProviderH1>
/*    */ {
/*    */   HttpServerRequest request;
/*    */   HttpResponse response;
/*    */   
/*    */   AccessLogArgProviderH1(@Nullable SocketAddress remoteAddress) {
/* 34 */     super(remoteAddress);
/*    */   }
/*    */   
/*    */   AccessLogArgProviderH1 request(HttpServerRequest request) {
/* 38 */     this.request = Objects.<HttpServerRequest>requireNonNull(request, "request");
/* 39 */     onRequest();
/* 40 */     return get();
/*    */   }
/*    */   
/*    */   AccessLogArgProviderH1 response(HttpResponse response) {
/* 44 */     this.response = Objects.<HttpResponse>requireNonNull(response, "response");
/* 45 */     return get();
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public CharSequence status() {
/* 51 */     return (this.response == null) ? null : (CharSequence)this.response.status().codeAsText();
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public CharSequence requestHeader(CharSequence name) {
/* 57 */     Objects.requireNonNull(name, "name");
/* 58 */     return (this.request == null) ? null : this.request.requestHeaders().get(name);
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public CharSequence responseHeader(CharSequence name) {
/* 64 */     Objects.requireNonNull(name, "name");
/* 65 */     return (this.response == null) ? null : this.response.headers().get(name);
/*    */   }
/*    */ 
/*    */   
/*    */   void onRequest() {
/* 70 */     if (this.request != null) {
/* 71 */       this.accessDateTime = this.request.timestamp();
/* 72 */       this.zonedDateTime = this.accessDateTime.format(DATE_TIME_FORMATTER);
/* 73 */       this.startTime = this.accessDateTime.toInstant().toEpochMilli();
/* 74 */       this.method = this.request.method().name();
/* 75 */       this.uri = this.request.uri();
/* 76 */       this.protocol = this.request.protocol();
/* 77 */       this.cookies = this.request.cookies();
/* 78 */       this.connectionInfo = (ConnectionInformation)this.request;
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   void clear() {
/* 84 */     super.clear();
/* 85 */     this.request = null;
/* 86 */     this.response = null;
/*    */   }
/*    */   
/*    */   AccessLogArgProviderH1 contentLength(long contentLength) {
/* 90 */     this.contentLength = contentLength;
/* 91 */     return get();
/*    */   }
/*    */ 
/*    */   
/*    */   public AccessLogArgProviderH1 get() {
/* 96 */     return this;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\server\logging\AccessLogArgProviderH1.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */