/*    */ package reactor.netty.http.server.logging;
/*    */ 
/*    */ import io.netty.channel.ChannelHandlerContext;
/*    */ import io.netty.channel.ChannelPromise;
/*    */ import io.netty.handler.codec.http2.Http2DataFrame;
/*    */ import io.netty.handler.codec.http2.Http2HeadersFrame;
/*    */ import io.netty.util.concurrent.Future;
/*    */ import java.util.function.Function;
/*    */ import reactor.netty.channel.ChannelOperations;
/*    */ import reactor.netty.http.server.HttpServerInfos;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class AccessLogHandlerH2
/*    */   extends BaseAccessLogHandler
/*    */ {
/*    */   AccessLogArgProviderH2 accessLogArgProvider;
/*    */   
/*    */   AccessLogHandlerH2(@Nullable Function<AccessLogArgProvider, AccessLog> accessLog) {
/* 40 */     super(accessLog);
/*    */   }
/*    */ 
/*    */   
/*    */   public void channelRead(ChannelHandlerContext ctx, Object msg) {
/* 45 */     if (msg instanceof Http2HeadersFrame) {
/* 46 */       Http2HeadersFrame requestHeaders = (Http2HeadersFrame)msg;
/*    */       
/* 48 */       if (this.accessLogArgProvider == null) {
/* 49 */         this.accessLogArgProvider = new AccessLogArgProviderH2(ctx.channel().remoteAddress());
/*    */       }
/* 51 */       this.accessLogArgProvider.requestHeaders(requestHeaders);
/*    */     } 
/* 53 */     ctx.fireChannelRead(msg);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void write(ChannelHandlerContext ctx, Object msg, ChannelPromise promise) {
/* 59 */     boolean lastContent = false;
/* 60 */     if (msg instanceof Http2HeadersFrame) {
/* 61 */       Http2HeadersFrame responseHeaders = (Http2HeadersFrame)msg;
/* 62 */       lastContent = responseHeaders.isEndStream();
/*    */       
/* 64 */       this.accessLogArgProvider.responseHeaders(responseHeaders)
/* 65 */         .chunked(true);
/*    */       
/* 67 */       ChannelOperations<?, ?> ops = ChannelOperations.get(ctx.channel());
/* 68 */       if (ops instanceof HttpServerInfos) {
/* 69 */         applyServerInfos(this.accessLogArgProvider, (HttpServerInfos)ops);
/*    */       }
/*    */     } 
/* 72 */     if (msg instanceof Http2DataFrame) {
/* 73 */       Http2DataFrame data = (Http2DataFrame)msg;
/* 74 */       lastContent = data.isEndStream();
/*    */       
/* 76 */       this.accessLogArgProvider.increaseContentLength(data.content().readableBytes());
/*    */     } 
/* 78 */     if (lastContent) {
/* 79 */       ctx.write(msg, promise.unvoid())
/* 80 */         .addListener(future -> {
/*    */             if (future.isSuccess()) {
/*    */               AccessLog log = this.accessLog.apply(this.accessLogArgProvider);
/*    */               
/*    */               if (log != null) {
/*    */                 log.log();
/*    */               }
/*    */               this.accessLogArgProvider.clear();
/*    */             } 
/*    */           });
/*    */       return;
/*    */     } 
/* 92 */     ctx.write(msg, promise);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\server\logging\AccessLogHandlerH2.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */