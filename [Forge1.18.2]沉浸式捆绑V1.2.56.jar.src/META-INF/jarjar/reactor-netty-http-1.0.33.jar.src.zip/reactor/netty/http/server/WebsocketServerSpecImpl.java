/*    */ package reactor.netty.http.server;
/*    */ 
/*    */ import reactor.netty.http.websocket.WebsocketSpecImpl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class WebsocketServerSpecImpl
/*    */   extends WebsocketSpecImpl
/*    */   implements WebsocketServerSpec
/*    */ {
/*    */   WebsocketServerSpecImpl(WebsocketServerSpec.Builder builder) {
/* 27 */     super(builder);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\server\WebsocketServerSpecImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */