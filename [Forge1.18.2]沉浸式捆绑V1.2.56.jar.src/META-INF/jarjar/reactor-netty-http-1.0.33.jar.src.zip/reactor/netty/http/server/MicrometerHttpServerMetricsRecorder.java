/*     */ package reactor.netty.http.server;
/*     */ 
/*     */ import io.micrometer.core.instrument.Counter;
/*     */ import io.micrometer.core.instrument.DistributionSummary;
/*     */ import io.micrometer.core.instrument.Gauge;
/*     */ import io.micrometer.core.instrument.Meter;
/*     */ import io.micrometer.core.instrument.Timer;
/*     */ import java.net.SocketAddress;
/*     */ import java.time.Duration;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import java.util.concurrent.atomic.LongAdder;
/*     */ import reactor.netty.Metrics;
/*     */ import reactor.netty.channel.MeterKey;
/*     */ import reactor.netty.http.MicrometerHttpMetricsRecorder;
/*     */ import reactor.netty.internal.util.MapUtils;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MicrometerHttpServerMetricsRecorder
/*     */   extends MicrometerHttpMetricsRecorder
/*     */   implements HttpServerMetricsRecorder
/*     */ {
/*  54 */   static final MicrometerHttpServerMetricsRecorder INSTANCE = new MicrometerHttpServerMetricsRecorder();
/*     */   private static final String PROTOCOL_VALUE_HTTP = "http";
/*     */   private static final String ACTIVE_CONNECTIONS_DESCRIPTION = "The number of http connections currently processing requests";
/*     */   private static final String ACTIVE_STREAMS_DESCRIPTION = "The number of HTTP/2 streams currently active on the server";
/*  58 */   private final LongAdder activeConnectionsAdder = new LongAdder();
/*  59 */   private final LongAdder activeStreamsAdder = new LongAdder();
/*  60 */   private final ConcurrentMap<String, LongAdder> activeConnectionsCache = new ConcurrentHashMap<>();
/*  61 */   private final ConcurrentMap<String, LongAdder> activeStreamsCache = new ConcurrentHashMap<>();
/*  62 */   private final ConcurrentMap<String, DistributionSummary> dataReceivedCache = new ConcurrentHashMap<>();
/*  63 */   private final ConcurrentMap<String, DistributionSummary> dataSentCache = new ConcurrentHashMap<>();
/*  64 */   private final ConcurrentMap<String, Counter> errorsCache = new ConcurrentHashMap<>();
/*     */   
/*     */   private MicrometerHttpServerMetricsRecorder() {
/*  67 */     super("reactor.netty.http.server", "http");
/*     */   }
/*     */ 
/*     */   
/*     */   public void recordDataReceivedTime(String uri, String method, Duration time) {
/*  72 */     MeterKey meterKey = new MeterKey(uri, null, method, null);
/*  73 */     Timer dataReceivedTime = (Timer)MapUtils.computeIfAbsent(this.dataReceivedTimeCache, meterKey, key -> (Timer)filter((Meter)Timer.builder(name() + ".data.received.time").description("Time spent in consuming incoming data").tags(new String[] { "uri", uri, "method", method }).register(Metrics.REGISTRY)));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  78 */     if (dataReceivedTime != null) {
/*  79 */       dataReceivedTime.record(time);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void recordDataSentTime(String uri, String method, String status, Duration time) {
/*  85 */     MeterKey meterKey = new MeterKey(uri, null, method, status);
/*  86 */     Timer dataSentTime = (Timer)MapUtils.computeIfAbsent(this.dataSentTimeCache, meterKey, key -> (Timer)filter((Meter)Timer.builder(name() + ".data.sent.time").description("Time spent in sending outgoing data").tags(new String[] { "uri", uri, "method", method, "status", status }).register(Metrics.REGISTRY)));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  91 */     if (dataSentTime != null) {
/*  92 */       dataSentTime.record(time);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void recordResponseTime(String uri, String method, String status, Duration time) {
/*  98 */     MeterKey meterKey = new MeterKey(uri, null, method, status);
/*  99 */     Timer responseTime = (Timer)MapUtils.computeIfAbsent(this.responseTimeCache, meterKey, key -> (Timer)filter((Meter)Timer.builder(name() + ".response.time").description("Total time for the request/response").tags(new String[] { "uri", uri, "method", method, "status", status }).register(Metrics.REGISTRY)));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 104 */     if (responseTime != null) {
/* 105 */       responseTime.record(time);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void recordDataReceived(SocketAddress remoteAddress, String uri, long bytes) {
/* 111 */     DistributionSummary dataReceived = (DistributionSummary)MapUtils.computeIfAbsent(this.dataReceivedCache, uri, key -> (DistributionSummary)filter((Meter)DistributionSummary.builder(name() + ".data.received").baseUnit("bytes").description("Amount of the data received, in bytes").tags(new String[] { "uri", uri }).register(Metrics.REGISTRY)));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 116 */     if (dataReceived != null) {
/* 117 */       dataReceived.record(bytes);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void recordDataSent(SocketAddress remoteAddress, String uri, long bytes) {
/* 123 */     DistributionSummary dataSent = (DistributionSummary)MapUtils.computeIfAbsent(this.dataSentCache, uri, key -> (DistributionSummary)filter((Meter)DistributionSummary.builder(name() + ".data.sent").baseUnit("bytes").description("Amount of the data sent, in bytes").tags(new String[] { "uri", uri }).register(Metrics.REGISTRY)));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 129 */     if (dataSent != null) {
/* 130 */       dataSent.record(bytes);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void incrementErrorsCount(SocketAddress remoteAddress, String uri) {
/* 136 */     Counter errors = (Counter)MapUtils.computeIfAbsent(this.errorsCache, uri, key -> (Counter)filter((Meter)Counter.builder(name() + ".errors").description("Number of errors that occurred").tags(new String[] { "uri", uri }).register(Metrics.REGISTRY)));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 141 */     if (errors != null) {
/* 142 */       errors.increment();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void recordServerConnectionActive(SocketAddress localAddress) {
/* 148 */     LongAdder adder = getServerConnectionAdder(localAddress);
/* 149 */     if (adder != null) {
/* 150 */       adder.increment();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void recordServerConnectionInactive(SocketAddress localAddress) {
/* 156 */     LongAdder adder = getServerConnectionAdder(localAddress);
/* 157 */     if (adder != null) {
/* 158 */       adder.decrement();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void recordStreamOpened(SocketAddress localAddress) {
/* 164 */     LongAdder adder = getActiveStreamsAdder(localAddress);
/* 165 */     if (adder != null) {
/* 166 */       adder.increment();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void recordStreamClosed(SocketAddress localAddress) {
/* 172 */     LongAdder adder = getActiveStreamsAdder(localAddress);
/* 173 */     if (adder != null) {
/* 174 */       adder.decrement();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void recordDataReceived(SocketAddress remoteAddress, long bytes) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void recordDataSent(SocketAddress remoteAddress, long bytes) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void incrementErrorsCount(SocketAddress remoteAddress) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void recordTlsHandshakeTime(SocketAddress remoteAddress, Duration time, String status) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void recordConnectTime(SocketAddress remoteAddress, Duration time, String status) {
/* 200 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public void recordResolveAddressTime(SocketAddress remoteAddress, Duration time, String status) {
/* 205 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private LongAdder getActiveStreamsAdder(SocketAddress localAddress) {
/* 210 */     String address = Metrics.formatSocketAddress(localAddress);
/* 211 */     return (LongAdder)MapUtils.computeIfAbsent(this.activeStreamsCache, address, key -> {
/*     */           Gauge gauge = (Gauge)filter((Meter)Gauge.builder(name() + ".streams.active", this.activeStreamsAdder, LongAdder::longValue).tags(new String[] { "uri", "http", "local.address", address }).description("The number of HTTP/2 streams currently active on the server").register(Metrics.REGISTRY));
/*     */           return (gauge != null) ? this.activeStreamsAdder : null;
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private LongAdder getServerConnectionAdder(SocketAddress localAddress) {
/* 224 */     String address = Metrics.formatSocketAddress(localAddress);
/* 225 */     return (LongAdder)MapUtils.computeIfAbsent(this.activeConnectionsCache, address, key -> {
/*     */           Gauge gauge = (Gauge)filter((Meter)Gauge.builder("reactor.netty.http.server.connections.active", this.activeConnectionsAdder, LongAdder::longValue).tags(new String[] { "uri", "http", "local.address", address }).description("The number of http connections currently processing requests").register(Metrics.REGISTRY));
/*     */           return (gauge != null) ? this.activeConnectionsAdder : null;
/*     */         });
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\server\MicrometerHttpServerMetricsRecorder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */