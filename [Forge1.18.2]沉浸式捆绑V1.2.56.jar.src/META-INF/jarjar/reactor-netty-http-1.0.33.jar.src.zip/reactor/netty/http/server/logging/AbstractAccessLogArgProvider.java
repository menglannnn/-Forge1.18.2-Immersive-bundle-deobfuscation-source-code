/*     */ package reactor.netty.http.server.logging;
/*     */ 
/*     */ import io.netty.handler.codec.http.HttpMethod;
/*     */ import io.netty.handler.codec.http.cookie.Cookie;
/*     */ import java.net.SocketAddress;
/*     */ import java.time.ZonedDateTime;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.function.Supplier;
/*     */ import reactor.netty.ReactorNetty;
/*     */ import reactor.netty.http.server.ConnectionInformation;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class AbstractAccessLogArgProvider<SELF extends AbstractAccessLogArgProvider<SELF>>
/*     */   implements AccessLogArgProvider, Supplier<SELF>
/*     */ {
/*  38 */   static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("dd/MMM/yyyy:HH:mm:ss Z");
/*     */   
/*     */   static final String MISSING = "-";
/*     */   final SocketAddress remoteAddress;
/*  42 */   final String user = "-";
/*     */   ConnectionInformation connectionInfo;
/*     */   String zonedDateTime;
/*     */   ZonedDateTime accessDateTime;
/*     */   CharSequence method;
/*     */   CharSequence uri;
/*     */   String protocol;
/*     */   boolean chunked;
/*  50 */   long contentLength = -1L;
/*     */   long startTime;
/*     */   Map<CharSequence, Set<Cookie>> cookies;
/*     */   
/*     */   AbstractAccessLogArgProvider(@Nullable SocketAddress remoteAddress) {
/*  55 */     this.remoteAddress = remoteAddress;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   @Deprecated
/*     */   public String zonedDateTime() {
/*  62 */     return this.zonedDateTime;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public ZonedDateTime accessDateTime() {
/*  68 */     return this.accessDateTime;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public SocketAddress remoteAddress() {
/*  75 */     return this.remoteAddress;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public ConnectionInformation connectionInformation() {
/*  81 */     return this.connectionInfo;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public CharSequence method() {
/*  87 */     return this.method;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public CharSequence uri() {
/*  93 */     return this.uri;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String protocol() {
/*  99 */     return this.protocol;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String user() {
/* 105 */     return "-";
/*     */   }
/*     */ 
/*     */   
/*     */   public long contentLength() {
/* 110 */     return this.contentLength;
/*     */   }
/*     */ 
/*     */   
/*     */   public long duration() {
/* 115 */     return System.currentTimeMillis() - this.startTime;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Map<CharSequence, Set<Cookie>> cookies() {
/* 121 */     return this.cookies;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void onRequest() {
/* 129 */     this.accessDateTime = ZonedDateTime.now(ReactorNetty.ZONE_ID_SYSTEM);
/* 130 */     this.zonedDateTime = this.accessDateTime.format(DATE_TIME_FORMATTER);
/* 131 */     this.startTime = System.currentTimeMillis();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void clear() {
/* 138 */     this.accessDateTime = null;
/* 139 */     this.zonedDateTime = null;
/* 140 */     this.method = null;
/* 141 */     this.uri = null;
/* 142 */     this.protocol = null;
/* 143 */     this.chunked = false;
/* 144 */     this.contentLength = -1L;
/* 145 */     this.startTime = 0L;
/* 146 */     this.cookies = null;
/* 147 */     this.connectionInfo = null;
/*     */   }
/*     */   
/*     */   SELF cookies(Map<CharSequence, Set<Cookie>> cookies) {
/* 151 */     this.cookies = cookies;
/* 152 */     return get();
/*     */   }
/*     */   
/*     */   SELF chunked(boolean chunked) {
/* 156 */     this.chunked = chunked;
/* 157 */     return get();
/*     */   }
/*     */   
/*     */   SELF increaseContentLength(long contentLength) {
/* 161 */     if (this.chunked && contentLength >= 0L && !HttpMethod.HEAD.asciiName().contentEqualsIgnoreCase(this.method)) {
/* 162 */       if (this.contentLength == -1L) {
/* 163 */         this.contentLength = 0L;
/*     */       }
/* 165 */       this.contentLength += contentLength;
/*     */     } 
/* 167 */     return get();
/*     */   }
/*     */   
/*     */   SELF connectionInformation(ConnectionInformation connectionInfo) {
/* 171 */     this.connectionInfo = connectionInfo;
/* 172 */     return get();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\server\logging\AbstractAccessLogArgProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */