/*     */ package reactor.netty.http.server;
/*     */ 
/*     */ import io.netty.channel.ChannelOption;
/*     */ import io.netty.util.AttributeKey;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.SocketAddress;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.netty.DisposableServer;
/*     */ import reactor.netty.http.HttpProtocol;
/*     */ import reactor.netty.internal.util.MapUtils;
/*     */ import reactor.netty.tcp.SslProvider;
/*     */ import reactor.netty.tcp.TcpServerConfig;
/*     */ import reactor.netty.transport.Transport;
/*     */ import reactor.netty.transport.TransportConfig;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class HttpServerBind
/*     */   extends HttpServer
/*     */ {
/*  40 */   static final HttpServerBind INSTANCE = new HttpServerBind();
/*     */   final HttpServerConfig config;
/*     */   static final int DEFAULT_PORT = 0;
/*     */   
/*     */   HttpServerBind() {
/*  45 */     Map<ChannelOption<?>, Boolean> childOptions = new HashMap<>(MapUtils.calculateInitialCapacity(2));
/*  46 */     childOptions.put(ChannelOption.AUTO_READ, Boolean.valueOf(false));
/*  47 */     childOptions.put(ChannelOption.TCP_NODELAY, Boolean.valueOf(true));
/*  48 */     this
/*  49 */       .config = new HttpServerConfig(Collections.singletonMap(ChannelOption.SO_REUSEADDR, Boolean.valueOf(true)), childOptions, () -> new InetSocketAddress(0));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   HttpServerBind(HttpServerConfig config) {
/*  55 */     this.config = config;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<? extends DisposableServer> bind() {
/*  61 */     if (this.config.sslProvider != null) {
/*  62 */       if ((this.config._protocols & 0x1) == 1) {
/*  63 */         return Mono.error(new IllegalArgumentException("Configured H2 Clear-Text protocol with TLS. Use the non Clear-Text H2 protocol via HttpServer#protocol or disable TLS via HttpServer#noSSL())"));
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*  68 */       if (this.config.sslProvider.getDefaultConfigurationType() == null) {
/*  69 */         HttpServer dup = duplicate();
/*  70 */         HttpServerConfig _config = (HttpServerConfig)dup.configuration();
/*  71 */         if ((_config._protocols & 0x2) == 2) {
/*  72 */           _config.sslProvider = SslProvider.updateDefaultConfiguration(_config.sslProvider, SslProvider.DefaultConfigurationType.H2);
/*     */         }
/*     */         else {
/*     */           
/*  76 */           _config.sslProvider = SslProvider.updateDefaultConfiguration(_config.sslProvider, SslProvider.DefaultConfigurationType.TCP);
/*     */         } 
/*     */         
/*  79 */         return dup.bind();
/*     */       }
/*     */     
/*     */     }
/*  83 */     else if ((this.config._protocols & 0x2) == 2) {
/*  84 */       return Mono.error(new IllegalArgumentException("Configured H2 protocol without TLS. Use a Clear-Text H2 protocol via HttpServer#protocol or configure TLS via HttpServer#secure"));
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  90 */     return super.bind();
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpServerConfig configuration() {
/*  95 */     return this.config;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 100 */     return "HttpServer{protocols=" + 
/* 101 */       Arrays.<HttpProtocol>asList((configuration()).protocols) + ", secure=" + 
/* 102 */       configuration().isSecure() + '}';
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected HttpServer duplicate() {
/* 108 */     return new HttpServerBind(new HttpServerConfig(this.config));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static HttpServer applyTcpServerConfig(TcpServerConfig config) {
/* 117 */     HttpServer httpServer = (HttpServer)((HttpServer)((HttpServer)((HttpServer)create().childObserve(config.childObserver())).doOnChannelInit(config.doOnChannelInit())).observe(config.connectionObserver())).runOn(config.loopResources(), config.isPreferNative());
/*     */     
/* 119 */     for (Map.Entry<AttributeKey<?>, ?> entry : (Iterable<Map.Entry<AttributeKey<?>, ?>>)config.attributes().entrySet()) {
/* 120 */       httpServer = (HttpServer)httpServer.attr(entry.getKey(), entry.getValue());
/*     */     }
/*     */     
/* 123 */     if (config.bindAddress() != null) {
/* 124 */       httpServer = httpServer.bindAddress(config.bindAddress());
/*     */     }
/*     */     
/* 127 */     if (config.channelGroup() != null) {
/* 128 */       httpServer = httpServer.channelGroup(config.channelGroup());
/*     */     }
/*     */     
/* 131 */     for (Map.Entry<AttributeKey<?>, ?> entry : (Iterable<Map.Entry<AttributeKey<?>, ?>>)config.childAttributes().entrySet()) {
/* 132 */       httpServer = (HttpServer)httpServer.childAttr(entry.getKey(), entry.getValue());
/*     */     }
/*     */     
/* 135 */     for (Map.Entry<ChannelOption<?>, ?> entry : (Iterable<Map.Entry<ChannelOption<?>, ?>>)config.childOptions().entrySet()) {
/* 136 */       httpServer = (HttpServer)httpServer.childOption(entry.getKey(), entry.getValue());
/*     */     }
/*     */     
/* 139 */     if (config.doOnBound() != null) {
/* 140 */       httpServer = (HttpServer)httpServer.doOnBound(config.doOnBound());
/*     */     }
/*     */     
/* 143 */     if (config.doOnConnection() != null) {
/* 144 */       httpServer = (HttpServer)httpServer.doOnConnection(config.doOnConnection());
/*     */     }
/*     */     
/* 147 */     if (config.doOnUnbound() != null) {
/* 148 */       httpServer = (HttpServer)httpServer.doOnUnbound(config.doOnUnbound());
/*     */     }
/*     */     
/* 151 */     if (config.loggingHandler() != null) {
/* 152 */       ((HttpServerConfig)httpServer.configuration()).loggingHandler(config.loggingHandler());
/*     */     }
/*     */     
/* 155 */     if (config.metricsRecorder() != null) {
/* 156 */       httpServer = httpServer.metrics(true, config.metricsRecorder());
/*     */     }
/*     */     
/* 159 */     for (Map.Entry<ChannelOption<?>, ?> entry : (Iterable<Map.Entry<ChannelOption<?>, ?>>)config.options().entrySet()) {
/* 160 */       httpServer = (HttpServer)httpServer.option(entry.getKey(), entry.getValue());
/*     */     }
/*     */     
/* 163 */     if (config.sslProvider() != null) {
/* 164 */       httpServer.secure(config.sslProvider());
/*     */     }
/*     */     
/* 167 */     return httpServer;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\server\HttpServerBind.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */