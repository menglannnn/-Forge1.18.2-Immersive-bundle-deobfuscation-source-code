/*    */ package reactor.netty.http.server.logging;
/*    */ 
/*    */ import io.netty.channel.ChannelDuplexHandler;
/*    */ import java.net.InetSocketAddress;
/*    */ import java.net.SocketAddress;
/*    */ import java.util.function.Function;
/*    */ import reactor.netty.http.server.ConnectionInformation;
/*    */ import reactor.netty.http.server.HttpServerInfos;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class BaseAccessLogHandler
/*    */   extends ChannelDuplexHandler
/*    */ {
/*    */   static final String DEFAULT_LOG_FORMAT = "{} - {} [{}] \"{} {} {}\" {} {} {}";
/*    */   static final Function<AccessLogArgProvider, AccessLog> DEFAULT_ACCESS_LOG;
/*    */   final Function<AccessLogArgProvider, AccessLog> accessLog;
/*    */   
/*    */   static {
/* 37 */     DEFAULT_ACCESS_LOG = (args -> AccessLog.create("{} - {} [{}] \"{} {} {}\" {} {} {}", new Object[] { applyAddress(args.remoteAddress()), args.user(), args.zonedDateTime(), args.method(), args.uri(), args.protocol(), args.status(), (args.contentLength() > -1L) ? Long.valueOf(args.contentLength()) : "-", Long.valueOf(args.duration()) }));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   BaseAccessLogHandler(@Nullable Function<AccessLogArgProvider, AccessLog> accessLog) {
/* 45 */     this.accessLog = (accessLog == null) ? DEFAULT_ACCESS_LOG : accessLog;
/*    */   }
/*    */   
/*    */   static String applyAddress(@Nullable SocketAddress socketAddress) {
/* 49 */     return (socketAddress instanceof InetSocketAddress) ? ((InetSocketAddress)socketAddress).getHostString() : "-";
/*    */   }
/*    */   
/*    */   final <T extends AbstractAccessLogArgProvider<T>> void applyServerInfos(AbstractAccessLogArgProvider<T> accessLogArgs, HttpServerInfos serverInfos) {
/* 53 */     accessLogArgs.cookies(serverInfos.cookies());
/* 54 */     accessLogArgs.connectionInformation((ConnectionInformation)serverInfos);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\server\logging\BaseAccessLogHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */