/*    */ package reactor.netty.http.server;
/*    */ 
/*    */ import io.netty.handler.codec.http.HttpContent;
/*    */ import io.netty.handler.codec.http.HttpHeaders;
/*    */ import io.netty.handler.codec.http.multipart.HttpData;
/*    */ import java.net.InetSocketAddress;
/*    */ import java.net.SocketAddress;
/*    */ import java.time.ZonedDateTime;
/*    */ import java.util.Map;
/*    */ import java.util.function.Consumer;
/*    */ import java.util.function.Function;
/*    */ import reactor.core.publisher.Flux;
/*    */ import reactor.netty.Connection;
/*    */ import reactor.netty.NettyInbound;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface HttpServerRequest
/*    */   extends NettyInbound, HttpServerInfos
/*    */ {
/*    */   ZonedDateTime timestamp();
/*    */   
/*    */   String protocol();
/*    */   
/*    */   HttpHeaders requestHeaders();
/*    */   
/*    */   @Nullable
/*    */   InetSocketAddress remoteAddress();
/*    */   
/*    */   @Nullable
/*    */   InetSocketAddress hostAddress();
/*    */   
/*    */   Flux<HttpData> receiveForm(Consumer<HttpServerFormDecoderProvider.Builder> paramConsumer);
/*    */   
/*    */   Flux<HttpData> receiveForm();
/*    */   
/*    */   boolean isMultipart();
/*    */   
/*    */   boolean isFormUrlencoded();
/*    */   
/*    */   default Flux<HttpContent> receiveContent() {
/* 78 */     return receiveObject().ofType(HttpContent.class);
/*    */   }
/*    */   
/*    */   HttpServerRequest paramsResolver(Function<? super String, Map<String, String>> paramFunction);
/*    */   
/*    */   @Nullable
/*    */   Map<String, String> params();
/*    */   
/*    */   @Nullable
/*    */   String param(CharSequence paramCharSequence);
/*    */   
/*    */   HttpServerRequest withConnection(Consumer<? super Connection> paramConsumer);
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\server\HttpServerRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */