/*    */ package reactor.netty.http.server;
/*    */ 
/*    */ import reactor.netty.ConnectionObserver;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum HttpServerState
/*    */   implements ConnectionObserver.State
/*    */ {
/* 30 */   REQUEST_RECEIVED
/*    */   {
/*    */     public String toString() {
/* 33 */       return "[request_received]";
/*    */     }
/*    */   },
/*    */ 
/*    */ 
/*    */   
/* 39 */   REQUEST_DECODING_FAILED
/*    */   {
/*    */     public String toString() {
/* 42 */       return "[request_decoding_failed]";
/*    */     }
/*    */   };
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\server\HttpServerState.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */