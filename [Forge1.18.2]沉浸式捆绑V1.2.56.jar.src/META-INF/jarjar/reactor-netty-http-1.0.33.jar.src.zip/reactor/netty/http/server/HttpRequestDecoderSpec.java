/*    */ package reactor.netty.http.server;
/*    */ 
/*    */ import reactor.netty.http.HttpDecoderSpec;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class HttpRequestDecoderSpec
/*    */   extends HttpDecoderSpec<HttpRequestDecoderSpec>
/*    */ {
/*    */   public static final int DEFAULT_H2C_MAX_CONTENT_LENGTH = 0;
/*    */   
/*    */   public HttpRequestDecoderSpec get() {
/* 54 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   HttpRequestDecoderSpec build() {
/* 61 */     HttpRequestDecoderSpec decoder = new HttpRequestDecoderSpec();
/* 62 */     decoder.initialBufferSize = this.initialBufferSize;
/* 63 */     decoder.maxChunkSize = this.maxChunkSize;
/* 64 */     decoder.maxHeaderSize = this.maxHeaderSize;
/* 65 */     decoder.maxInitialLineLength = this.maxInitialLineLength;
/* 66 */     decoder.validateHeaders = this.validateHeaders;
/* 67 */     decoder.allowDuplicateContentLengths = this.allowDuplicateContentLengths;
/* 68 */     decoder.h2cMaxContentLength = this.h2cMaxContentLength;
/* 69 */     return decoder;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\server\HttpRequestDecoderSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */