/*    */ package reactor.netty.http.server;
/*    */ 
/*    */ import reactor.netty.http.websocket.WebsocketSpec;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface WebsocketServerSpec
/*    */   extends WebsocketSpec
/*    */ {
/*    */   static Builder builder() {
/* 41 */     return new Builder();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static final class Builder
/*    */     extends WebsocketSpec.Builder<Builder>
/*    */   {
/*    */     private Builder() {}
/*    */ 
/*    */ 
/*    */     
/*    */     public final WebsocketServerSpec build() {
/* 55 */       return new WebsocketServerSpecImpl(this);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\server\WebsocketServerSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */