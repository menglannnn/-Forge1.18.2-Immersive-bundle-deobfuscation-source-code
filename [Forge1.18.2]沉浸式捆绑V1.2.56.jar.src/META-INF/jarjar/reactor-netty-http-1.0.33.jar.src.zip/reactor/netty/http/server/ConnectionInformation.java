package reactor.netty.http.server;

import java.net.SocketAddress;
import reactor.util.annotation.Nullable;

public interface ConnectionInformation {
  @Nullable
  SocketAddress hostAddress();
  
  @Nullable
  SocketAddress connectionHostAddress();
  
  @Nullable
  SocketAddress remoteAddress();
  
  @Nullable
  SocketAddress connectionRemoteAddress();
  
  String scheme();
  
  String connectionScheme();
  
  String hostName();
  
  int hostPort();
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\server\ConnectionInformation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */