/*      */ package reactor.netty.http.server;
/*      */ 
/*      */ import io.netty.channel.group.ChannelGroup;
/*      */ import io.netty.handler.codec.http.HttpRequest;
/*      */ import io.netty.handler.codec.http.cookie.ServerCookieDecoder;
/*      */ import io.netty.handler.codec.http.cookie.ServerCookieEncoder;
/*      */ import io.netty.handler.ssl.OpenSsl;
/*      */ import java.net.SocketAddress;
/*      */ import java.time.Duration;
/*      */ import java.util.Objects;
/*      */ import java.util.function.BiFunction;
/*      */ import java.util.function.BiPredicate;
/*      */ import java.util.function.Consumer;
/*      */ import java.util.function.Function;
/*      */ import java.util.function.Supplier;
/*      */ import org.reactivestreams.Publisher;
/*      */ import reactor.core.publisher.Mono;
/*      */ import reactor.netty.Connection;
/*      */ import reactor.netty.ConnectionObserver;
/*      */ import reactor.netty.ReactorNetty;
/*      */ import reactor.netty.channel.ChannelMetricsRecorder;
/*      */ import reactor.netty.http.Http2SettingsSpec;
/*      */ import reactor.netty.http.HttpProtocol;
/*      */ import reactor.netty.http.logging.HttpMessageLogFactory;
/*      */ import reactor.netty.http.server.logging.AccessLog;
/*      */ import reactor.netty.http.server.logging.AccessLogArgProvider;
/*      */ import reactor.netty.http.server.logging.AccessLogFactory;
/*      */ import reactor.netty.tcp.SslProvider;
/*      */ import reactor.netty.tcp.TcpServer;
/*      */ import reactor.netty.tcp.TcpServerConfig;
/*      */ import reactor.netty.transport.ServerTransport;
/*      */ import reactor.netty.transport.Transport;
/*      */ import reactor.util.Logger;
/*      */ import reactor.util.Loggers;
/*      */ import reactor.util.Metrics;
/*      */ import reactor.util.context.Context;
/*      */ import reactor.util.context.ContextView;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class HttpServer
/*      */   extends ServerTransport<HttpServer, HttpServerConfig>
/*      */ {
/*      */   public static HttpServer create() {
/*   86 */     return HttpServerBind.INSTANCE;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static HttpServer from(TcpServer tcpServer) {
/*  156 */     Objects.requireNonNull(tcpServer, "tcpServer");
/*  157 */     return HttpServerBind.applyTcpServerConfig((TcpServerConfig)tcpServer.configuration());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final HttpServer accessLog(boolean enable) {
/*  186 */     HttpServer dup = (HttpServer)duplicate();
/*  187 */     ((HttpServerConfig)dup.configuration()).accessLog = null;
/*  188 */     ((HttpServerConfig)dup.configuration()).accessLogEnabled = enable;
/*  189 */     return dup;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final HttpServer accessLog(boolean enable, AccessLogFactory accessLogFactory) {
/*  224 */     Objects.requireNonNull(accessLogFactory);
/*  225 */     HttpServer dup = (HttpServer)duplicate();
/*  226 */     ((HttpServerConfig)dup.configuration()).accessLog = enable ? (Function<AccessLogArgProvider, AccessLog>)accessLogFactory : null;
/*  227 */     ((HttpServerConfig)dup.configuration()).accessLogEnabled = enable;
/*  228 */     return dup;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public final HttpServer accessLog(Function<AccessLogArgProvider, AccessLog> accessLogFactory) {
/*  260 */     Objects.requireNonNull(accessLogFactory, "accessLogFactory");
/*  261 */     HttpServer dup = (HttpServer)duplicate();
/*  262 */     ((HttpServerConfig)dup.configuration()).accessLog = accessLogFactory;
/*  263 */     return dup;
/*      */   }
/*      */ 
/*      */   
/*      */   public final HttpServer bindAddress(Supplier<? extends SocketAddress> bindAddressSupplier) {
/*  268 */     return (HttpServer)super.bindAddress(bindAddressSupplier);
/*      */   }
/*      */ 
/*      */   
/*      */   public final HttpServer channelGroup(ChannelGroup channelGroup) {
/*  273 */     return (HttpServer)super.channelGroup(channelGroup);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final HttpServer compress(BiPredicate<HttpServerRequest, HttpServerResponse> predicate) {
/*  290 */     Objects.requireNonNull(predicate, "compressionPredicate");
/*  291 */     HttpServer dup = (HttpServer)duplicate();
/*  292 */     ((HttpServerConfig)dup.configuration()).compressPredicate = predicate;
/*  293 */     return dup;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final HttpServer compress(boolean compressionEnabled) {
/*  305 */     HttpServer dup = (HttpServer)duplicate();
/*  306 */     if (compressionEnabled) {
/*  307 */       ((HttpServerConfig)dup.configuration()).minCompressionSize = 0;
/*      */     } else {
/*      */       
/*  310 */       ((HttpServerConfig)dup.configuration()).minCompressionSize = -1;
/*  311 */       ((HttpServerConfig)dup.configuration()).compressPredicate = null;
/*      */     } 
/*  313 */     return dup;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final HttpServer compress(int minResponseSize) {
/*  326 */     if (minResponseSize < 0) {
/*  327 */       throw new IllegalArgumentException("minResponseSize must be positive");
/*      */     }
/*  329 */     HttpServer dup = (HttpServer)duplicate();
/*  330 */     ((HttpServerConfig)dup.configuration()).minCompressionSize = minResponseSize;
/*  331 */     return dup;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final HttpServer cookieCodec(ServerCookieEncoder encoder) {
/*  344 */     Objects.requireNonNull(encoder, "encoder");
/*      */     
/*  346 */     ServerCookieDecoder decoder = (encoder == ServerCookieEncoder.LAX) ? ServerCookieDecoder.LAX : ServerCookieDecoder.STRICT;
/*  347 */     HttpServer dup = (HttpServer)duplicate();
/*  348 */     ((HttpServerConfig)dup.configuration()).cookieEncoder = encoder;
/*  349 */     ((HttpServerConfig)dup.configuration()).cookieDecoder = decoder;
/*  350 */     return dup;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final HttpServer cookieCodec(ServerCookieEncoder encoder, ServerCookieDecoder decoder) {
/*  363 */     Objects.requireNonNull(encoder, "encoder");
/*  364 */     Objects.requireNonNull(decoder, "decoder");
/*  365 */     HttpServer dup = (HttpServer)duplicate();
/*  366 */     ((HttpServerConfig)dup.configuration()).cookieEncoder = encoder;
/*  367 */     ((HttpServerConfig)dup.configuration()).cookieDecoder = decoder;
/*  368 */     return dup;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final HttpServer forwarded(BiFunction<ConnectionInfo, HttpRequest, ConnectionInfo> handler) {
/*  379 */     Objects.requireNonNull(handler, "handler");
/*  380 */     HttpServer dup = (HttpServer)duplicate();
/*  381 */     ((HttpServerConfig)dup.configuration()).forwardedHeaderHandler = handler;
/*  382 */     return dup;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final HttpServer forwarded(boolean forwardedEnabled) {
/*  396 */     if (forwardedEnabled) {
/*  397 */       if (((HttpServerConfig)configuration()).forwardedHeaderHandler == DefaultHttpForwardedHeaderHandler.INSTANCE) {
/*  398 */         return this;
/*      */       }
/*  400 */       HttpServer dup = (HttpServer)duplicate();
/*  401 */       ((HttpServerConfig)dup.configuration()).forwardedHeaderHandler = DefaultHttpForwardedHeaderHandler.INSTANCE;
/*  402 */       return dup;
/*      */     } 
/*  404 */     if (((HttpServerConfig)configuration()).forwardedHeaderHandler != null) {
/*  405 */       HttpServer dup = (HttpServer)duplicate();
/*  406 */       ((HttpServerConfig)dup.configuration()).forwardedHeaderHandler = null;
/*  407 */       return dup;
/*      */     } 
/*  409 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final HttpServer handle(BiFunction<? super HttpServerRequest, ? super HttpServerResponse, ? extends Publisher<Void>> handler) {
/*  424 */     Objects.requireNonNull(handler, "handler");
/*  425 */     return (HttpServer)childObserve(new HttpServerHandle(handler));
/*      */   }
/*      */ 
/*      */   
/*      */   public final HttpServer host(String host) {
/*  430 */     return (HttpServer)super.host(host);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final HttpServer http2Settings(Consumer<Http2SettingsSpec.Builder> http2Settings) {
/*  440 */     Objects.requireNonNull(http2Settings, "http2Settings");
/*  441 */     Http2SettingsSpec.Builder builder = Http2SettingsSpec.builder();
/*  442 */     http2Settings.accept(builder);
/*  443 */     Http2SettingsSpec settings = builder.build();
/*  444 */     if (settings.equals(((HttpServerConfig)configuration()).http2Settings)) {
/*  445 */       return this;
/*      */     }
/*  447 */     HttpServer dup = (HttpServer)duplicate();
/*  448 */     ((HttpServerConfig)dup.configuration()).http2Settings = settings;
/*  449 */     return dup;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final HttpServer httpFormDecoder(Consumer<HttpServerFormDecoderProvider.Builder> formDecoderBuilder) {
/*  463 */     Objects.requireNonNull(formDecoderBuilder, "formDecoderBuilder");
/*  464 */     HttpServerFormDecoderProvider.Build builder = new HttpServerFormDecoderProvider.Build();
/*  465 */     formDecoderBuilder.accept(builder);
/*  466 */     HttpServerFormDecoderProvider formDecoderProvider = builder.build();
/*  467 */     if (formDecoderProvider.equals(((HttpServerConfig)configuration()).formDecoderProvider)) {
/*  468 */       return this;
/*      */     }
/*  470 */     HttpServer dup = (HttpServer)duplicate();
/*  471 */     ((HttpServerConfig)dup.configuration()).formDecoderProvider = formDecoderProvider;
/*  472 */     return dup;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final HttpServer httpMessageLogFactory(HttpMessageLogFactory httpMessageLogFactory) {
/*  491 */     Objects.requireNonNull(httpMessageLogFactory, "httpMessageLogFactory");
/*  492 */     HttpServer dup = (HttpServer)duplicate();
/*  493 */     ((HttpServerConfig)dup.configuration()).httpMessageLogFactory = httpMessageLogFactory;
/*  494 */     return dup;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final HttpServer httpRequestDecoder(Function<HttpRequestDecoderSpec, HttpRequestDecoderSpec> requestDecoderOptions) {
/*  504 */     Objects.requireNonNull(requestDecoderOptions, "requestDecoderOptions");
/*  505 */     HttpRequestDecoderSpec decoder = ((HttpRequestDecoderSpec)requestDecoderOptions.apply(new HttpRequestDecoderSpec())).build();
/*  506 */     if (decoder.equals(((HttpServerConfig)configuration()).decoder)) {
/*  507 */       return this;
/*      */     }
/*  509 */     HttpServer dup = (HttpServer)duplicate();
/*  510 */     ((HttpServerConfig)dup.configuration()).decoder = decoder;
/*  511 */     return dup;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final HttpServer idleTimeout(Duration idleTimeout) {
/*  527 */     Objects.requireNonNull(idleTimeout, "idleTimeout");
/*  528 */     HttpServer dup = (HttpServer)duplicate();
/*  529 */     ((HttpServerConfig)dup.configuration()).idleTimeout = idleTimeout;
/*  530 */     return dup;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final HttpServer mapHandle(BiFunction<? super Mono<Void>, ? super Connection, ? extends Mono<Void>> mapHandle) {
/*  541 */     Objects.requireNonNull(mapHandle, "mapHandle");
/*  542 */     HttpServer dup = (HttpServer)duplicate();
/*  543 */     ((HttpServerConfig)dup.configuration()).mapHandle = mapHandle;
/*  544 */     return dup;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final HttpServer maxKeepAliveRequests(int maxKeepAliveRequests) {
/*  563 */     if (maxKeepAliveRequests < -1 || maxKeepAliveRequests == 0) {
/*  564 */       throw new IllegalArgumentException("maxKeepAliveRequests must be positive or -1");
/*      */     }
/*  566 */     HttpServer dup = (HttpServer)duplicate();
/*  567 */     ((HttpServerConfig)dup.configuration()).maxKeepAliveRequests = maxKeepAliveRequests;
/*  568 */     return dup;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final HttpServer metrics(boolean enable, Function<String, String> uriTagValue) {
/*  599 */     if (enable) {
/*  600 */       if (!Metrics.isInstrumentationAvailable()) {
/*  601 */         throw new UnsupportedOperationException("To enable metrics, you must add the dependency `io.micrometer:micrometer-core` to the class path first");
/*      */       }
/*      */ 
/*      */       
/*  605 */       if (uriTagValue == Function.identity()) {
/*  606 */         log.debug("Metrics are enabled with [uriTagValue=Function#identity]. It is strongly recommended to provide template-like form for the URIs. Without a conversion to a template-like form, each distinct URI leads to the creation of a distinct tag, which takes a lot of memory for the metrics.");
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  611 */       HttpServer dup = (HttpServer)duplicate();
/*  612 */       ((HttpServerConfig)dup.configuration()).metricsRecorder(() -> ((HttpServerConfig)configuration()).defaultMetricsRecorder());
/*  613 */       ((HttpServerConfig)dup.configuration()).uriTagValue = uriTagValue;
/*  614 */       return dup;
/*      */     } 
/*  616 */     if (((HttpServerConfig)configuration()).metricsRecorder() != null) {
/*  617 */       HttpServer dup = (HttpServer)duplicate();
/*  618 */       ((HttpServerConfig)dup.configuration()).metricsRecorder((Supplier<? extends ChannelMetricsRecorder>)null);
/*  619 */       ((HttpServerConfig)dup.configuration()).uriTagValue = null;
/*  620 */       return dup;
/*      */     } 
/*      */     
/*  623 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final HttpServer metrics(boolean enable, Supplier<? extends ChannelMetricsRecorder> recorder) {
/*  629 */     return (HttpServer)super.metrics(enable, recorder);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final HttpServer metrics(boolean enable, Supplier<? extends ChannelMetricsRecorder> recorder, Function<String, String> uriValue) {
/*  649 */     if (enable) {
/*  650 */       HttpServer dup = (HttpServer)duplicate();
/*  651 */       ((HttpServerConfig)dup.configuration()).metricsRecorder(recorder);
/*  652 */       ((HttpServerConfig)dup.configuration()).uriTagValue = uriValue;
/*  653 */       return dup;
/*      */     } 
/*  655 */     if (((HttpServerConfig)configuration()).metricsRecorder() != null) {
/*  656 */       HttpServer dup = (HttpServer)duplicate();
/*  657 */       ((HttpServerConfig)dup.configuration()).metricsRecorder((Supplier<? extends ChannelMetricsRecorder>)null);
/*  658 */       ((HttpServerConfig)dup.configuration()).uriTagValue = null;
/*  659 */       return dup;
/*      */     } 
/*      */     
/*  662 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final HttpServer noSSL() {
/*  672 */     if (((HttpServerConfig)configuration()).isSecure()) {
/*  673 */       HttpServer dup = (HttpServer)duplicate();
/*  674 */       ((HttpServerConfig)dup.configuration()).sslProvider = null;
/*  675 */       return dup;
/*      */     } 
/*  677 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public final HttpServer port(int port) {
/*  682 */     return (HttpServer)super.port(port);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final HttpServer protocol(HttpProtocol... supportedProtocols) {
/*  693 */     Objects.requireNonNull(supportedProtocols, "supportedProtocols");
/*  694 */     HttpServer dup = (HttpServer)duplicate();
/*  695 */     ((HttpServerConfig)dup.configuration()).protocols(supportedProtocols);
/*  696 */     return dup;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final HttpServer proxyProtocol(ProxyProtocolSupportType proxyProtocolSupportType) {
/*  721 */     Objects.requireNonNull(proxyProtocolSupportType, "The parameter: proxyProtocolSupportType must not be null.");
/*  722 */     if (proxyProtocolSupportType == ((HttpServerConfig)configuration()).proxyProtocolSupportType) {
/*  723 */       return this;
/*      */     }
/*  725 */     if (proxyProtocolSupportType == ProxyProtocolSupportType.ON || proxyProtocolSupportType == ProxyProtocolSupportType.AUTO)
/*      */     {
/*  727 */       if (!HAProxyMessageReader.isProxyProtocolAvailable()) {
/*  728 */         throw new UnsupportedOperationException("To enable proxyProtocol, you must add the dependency `io.netty:netty-codec-haproxy` to the class path first");
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*  733 */     HttpServer dup = (HttpServer)duplicate();
/*  734 */     ((HttpServerConfig)dup.configuration()).proxyProtocolSupportType = proxyProtocolSupportType;
/*  735 */     return dup;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final HttpServer route(Consumer<? super HttpServerRoutes> routesBuilder) {
/*  745 */     Objects.requireNonNull(routesBuilder, "routeBuilder");
/*  746 */     HttpServerRoutes routes = HttpServerRoutes.newRoutes();
/*  747 */     routesBuilder.accept(routes);
/*  748 */     return handle(routes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final HttpServer secure(Consumer<? super SslProvider.SslContextSpec> sslProviderBuilder) {
/*  772 */     return secure(sslProviderBuilder, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final HttpServer secure(Consumer<? super SslProvider.SslContextSpec> sslProviderBuilder, boolean redirectHttpToHttps) {
/*  800 */     Objects.requireNonNull(sslProviderBuilder, "sslProviderBuilder");
/*  801 */     HttpServer dup = (HttpServer)duplicate();
/*  802 */     SslProvider.SslContextSpec builder = SslProvider.builder();
/*  803 */     sslProviderBuilder.accept(builder);
/*  804 */     ((HttpServerConfig)dup.configuration()).sslProvider = ((SslProvider.Builder)builder).build();
/*  805 */     ((HttpServerConfig)dup.configuration()).redirectHttpToHttps = redirectHttpToHttps;
/*  806 */     return dup;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final HttpServer secure(SslProvider sslProvider) {
/*  828 */     return secure(sslProvider, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final HttpServer secure(SslProvider sslProvider, boolean redirectHttpToHttps) {
/*  853 */     Objects.requireNonNull(sslProvider, "sslProvider");
/*  854 */     HttpServer dup = (HttpServer)duplicate();
/*  855 */     ((HttpServerConfig)dup.configuration()).sslProvider = sslProvider;
/*  856 */     ((HttpServerConfig)dup.configuration()).redirectHttpToHttps = redirectHttpToHttps;
/*  857 */     return dup;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public final HttpServer tcpConfiguration(Function<? super TcpServer, ? extends TcpServer> tcpMapper) {
/*  939 */     Objects.requireNonNull(tcpMapper, "tcpMapper");
/*  940 */     HttpServerTcpConfig tcpServer = new HttpServerTcpConfig(this);
/*      */     
/*  942 */     tcpMapper.apply(tcpServer);
/*  943 */     return tcpServer.httpServer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<Void> warmup() {
/*  960 */     return Mono.when(new Publisher[] { (Publisher)super
/*  961 */           .warmup(), 
/*  962 */           (Publisher)Mono.fromRunnable(() -> {
/*      */               SslProvider provider = ((HttpServerConfig)configuration()).sslProvider();
/*      */               if (provider != null && !(provider.getSslContext() instanceof io.netty.handler.ssl.JdkSslContext)) {
/*      */                 OpenSsl.version();
/*      */               }
/*      */             }) });
/*      */   }
/*      */ 
/*      */   
/*      */   public final HttpServer wiretap(boolean enable) {
/*  972 */     return (HttpServer)super.wiretap(enable);
/*      */   }
/*      */   
/*  975 */   static final Logger log = Loggers.getLogger(HttpServer.class);
/*      */   
/*      */   static final class HttpServerHandle
/*      */     implements ConnectionObserver {
/*      */     final BiFunction<? super HttpServerRequest, ? super HttpServerResponse, ? extends Publisher<Void>> handler;
/*      */     
/*      */     HttpServerHandle(BiFunction<? super HttpServerRequest, ? super HttpServerResponse, ? extends Publisher<Void>> handler) {
/*  982 */       this.handler = handler;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void onStateChange(Connection connection, ConnectionObserver.State newState) {
/*  988 */       if (newState == HttpServerState.REQUEST_RECEIVED)
/*      */         try {
/*  990 */           if (HttpServer.log.isDebugEnabled()) {
/*  991 */             HttpServer.log.debug(ReactorNetty.format(connection.channel(), "Handler is being applied: {}"), new Object[] { this.handler });
/*      */           }
/*  993 */           HttpServerOperations ops = (HttpServerOperations)connection;
/*  994 */           Publisher<Void> publisher = this.handler.apply(ops, ops);
/*  995 */           Mono<Void> mono = Mono.deferContextual(ctx -> {
/*      */                 ops.currentContext = Context.of(ctx);
/*      */                 return Mono.fromDirect(publisher);
/*      */               });
/*  999 */           if (ops.mapHandle != null) {
/* 1000 */             mono = ops.mapHandle.apply(mono, connection);
/*      */           }
/* 1002 */           mono.subscribe(ops.disposeSubscriber());
/*      */         }
/* 1004 */         catch (Throwable t) {
/* 1005 */           HttpServer.log.error(ReactorNetty.format(connection.channel(), ""), t);
/*      */           
/* 1007 */           connection.channel()
/* 1008 */             .close();
/*      */         }  
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\server\HttpServer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */