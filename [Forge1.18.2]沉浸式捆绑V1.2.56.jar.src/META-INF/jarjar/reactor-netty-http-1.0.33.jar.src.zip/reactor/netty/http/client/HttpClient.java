/*      */ package reactor.netty.http.client;
/*      */ 
/*      */ import io.netty.buffer.ByteBuf;
/*      */ import io.netty.handler.codec.http.HttpHeaderNames;
/*      */ import io.netty.handler.codec.http.HttpHeaderValues;
/*      */ import io.netty.handler.codec.http.HttpHeaders;
/*      */ import io.netty.handler.codec.http.HttpMethod;
/*      */ import io.netty.handler.codec.http.HttpUtil;
/*      */ import io.netty.handler.codec.http.HttpVersion;
/*      */ import io.netty.handler.codec.http.cookie.ClientCookieDecoder;
/*      */ import io.netty.handler.codec.http.cookie.ClientCookieEncoder;
/*      */ import io.netty.handler.codec.http.cookie.Cookie;
/*      */ import io.netty.handler.codec.http.cookie.DefaultCookie;
/*      */ import io.netty.handler.ssl.OpenSsl;
/*      */ import java.net.SocketAddress;
/*      */ import java.net.URI;
/*      */ import java.time.Duration;
/*      */ import java.util.Objects;
/*      */ import java.util.Optional;
/*      */ import java.util.function.BiConsumer;
/*      */ import java.util.function.BiFunction;
/*      */ import java.util.function.BiPredicate;
/*      */ import java.util.function.Consumer;
/*      */ import java.util.function.Function;
/*      */ import java.util.function.Supplier;
/*      */ import org.reactivestreams.Publisher;
/*      */ import reactor.core.publisher.Flux;
/*      */ import reactor.core.publisher.Mono;
/*      */ import reactor.netty.ByteBufFlux;
/*      */ import reactor.netty.ByteBufMono;
/*      */ import reactor.netty.Connection;
/*      */ import reactor.netty.ConnectionObserver;
/*      */ import reactor.netty.NettyOutbound;
/*      */ import reactor.netty.channel.ChannelMetricsRecorder;
/*      */ import reactor.netty.http.Http2SettingsSpec;
/*      */ import reactor.netty.http.HttpProtocol;
/*      */ import reactor.netty.http.logging.HttpMessageLogFactory;
/*      */ import reactor.netty.http.websocket.WebsocketInbound;
/*      */ import reactor.netty.http.websocket.WebsocketOutbound;
/*      */ import reactor.netty.resources.ConnectionProvider;
/*      */ import reactor.netty.tcp.SslProvider;
/*      */ import reactor.netty.tcp.TcpClient;
/*      */ import reactor.netty.tcp.TcpClientConfig;
/*      */ import reactor.netty.transport.ClientTransport;
/*      */ import reactor.netty.transport.Transport;
/*      */ import reactor.util.Logger;
/*      */ import reactor.util.Loggers;
/*      */ import reactor.util.Metrics;
/*      */ import reactor.util.annotation.Nullable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class HttpClient
/*      */   extends ClientTransport<HttpClient, HttpClientConfig>
/*      */ {
/*  109 */   public static final String USER_AGENT = String.format("ReactorNetty/%s", new Object[] { reactorNettyVersion() });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static interface RedirectSendHandler
/*      */     extends BiFunction<HttpClientRequest, NettyOutbound, Publisher<Void>> {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static interface WebsocketReceiver<S extends WebsocketReceiver<?>>
/*      */     extends UriConfiguration<S>
/*      */   {
/*      */     Mono<? extends Connection> connect();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     <V> Flux<V> handle(BiFunction<? super WebsocketInbound, ? super WebsocketOutbound, ? extends Publisher<V>> param1BiFunction);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     ByteBufFlux receive();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static interface ResponseReceiver<S extends ResponseReceiver<?>>
/*      */     extends UriConfiguration<S>
/*      */   {
/*      */     Mono<HttpClientResponse> response();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     <V> Flux<V> response(BiFunction<? super HttpClientResponse, ? super ByteBufFlux, ? extends Publisher<V>> param1BiFunction);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     <V> Flux<V> responseConnection(BiFunction<? super HttpClientResponse, ? super Connection, ? extends Publisher<V>> param1BiFunction);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     ByteBufFlux responseContent();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     <V> Mono<V> responseSingle(BiFunction<? super HttpClientResponse, ? super ByteBufMono, ? extends Mono<V>> param1BiFunction);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static interface WebsocketSender
/*      */     extends WebsocketReceiver<WebsocketSender>
/*      */   {
/*      */     HttpClient.WebsocketReceiver<?> send(Function<? super HttpClientRequest, ? extends Publisher<Void>> param1Function);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static interface RequestSender
/*      */     extends ResponseReceiver<RequestSender>
/*      */   {
/*      */     HttpClient.ResponseReceiver<?> send(Publisher<? extends ByteBuf> param1Publisher);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     HttpClient.ResponseReceiver<?> send(BiFunction<? super HttpClientRequest, ? super NettyOutbound, ? extends Publisher<Void>> param1BiFunction);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     default HttpClient.ResponseReceiver<?> sendForm(BiConsumer<? super HttpClientRequest, HttpClientForm> formCallback) {
/*  211 */       return sendForm(formCallback, null);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     HttpClient.ResponseReceiver<?> sendForm(BiConsumer<? super HttpClientRequest, HttpClientForm> param1BiConsumer, @Nullable Consumer<Flux<Long>> param1Consumer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static HttpClient create() {
/*  398 */     return new HttpClientConnect(new HttpConnectionProvider());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static HttpClient create(ConnectionProvider connectionProvider) {
/*  410 */     Objects.requireNonNull(connectionProvider, "connectionProvider");
/*  411 */     return new HttpClientConnect(new HttpConnectionProvider(connectionProvider));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static HttpClient from(TcpClient tcpClient) {
/*  479 */     Objects.requireNonNull(tcpClient, "tcpClient");
/*  480 */     return HttpClientConnect.applyTcpClientConfig((TcpClientConfig)tcpClient.configuration());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static HttpClient newConnection() {
/*  491 */     return new HttpClientConnect(new HttpConnectionProvider(ConnectionProvider.newConnection()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final HttpClient baseUrl(String baseUrl) {
/*  505 */     Objects.requireNonNull(baseUrl, "baseUrl");
/*  506 */     HttpClient dup = (HttpClient)duplicate();
/*  507 */     ((HttpClientConfig)dup.configuration()).baseUrl = baseUrl;
/*  508 */     return dup;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final HttpClient compress(boolean compressionEnabled) {
/*  518 */     if (compressionEnabled) {
/*  519 */       if (!((HttpClientConfig)configuration()).acceptGzip) {
/*  520 */         HttpClient dup = (HttpClient)duplicate();
/*  521 */         HttpHeaders headers = ((HttpClientConfig)configuration()).headers.copy();
/*  522 */         headers.add((CharSequence)HttpHeaderNames.ACCEPT_ENCODING, HttpHeaderValues.GZIP);
/*  523 */         ((HttpClientConfig)dup.configuration()).headers = headers;
/*  524 */         ((HttpClientConfig)dup.configuration()).acceptGzip = true;
/*  525 */         return dup;
/*      */       }
/*      */     
/*  528 */     } else if (((HttpClientConfig)configuration()).acceptGzip) {
/*  529 */       HttpClient dup = (HttpClient)duplicate();
/*  530 */       if (isCompressing(((HttpClientConfig)configuration()).headers)) {
/*  531 */         HttpHeaders headers = ((HttpClientConfig)configuration()).headers.copy();
/*  532 */         headers.remove((CharSequence)HttpHeaderNames.ACCEPT_ENCODING);
/*  533 */         ((HttpClientConfig)dup.configuration()).headers = headers;
/*      */       } 
/*  535 */       ((HttpClientConfig)dup.configuration()).acceptGzip = false;
/*  536 */       return dup;
/*      */     } 
/*  538 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final HttpClient cookie(Cookie cookie) {
/*  549 */     Objects.requireNonNull(cookie, "cookie");
/*  550 */     if (!cookie.value().isEmpty()) {
/*  551 */       HttpClient dup = (HttpClient)duplicate();
/*  552 */       HttpHeaders headers = ((HttpClientConfig)configuration()).headers.copy();
/*  553 */       headers.add((CharSequence)HttpHeaderNames.COOKIE, ((HttpClientConfig)dup.configuration()).cookieEncoder.encode(cookie));
/*  554 */       ((HttpClientConfig)dup.configuration()).headers = headers;
/*  555 */       return dup;
/*      */     } 
/*  557 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final HttpClient cookie(String name, Consumer<? super Cookie> cookieBuilder) {
/*  568 */     Objects.requireNonNull(name, "name");
/*  569 */     Objects.requireNonNull(cookieBuilder, "cookieBuilder");
/*  570 */     DefaultCookie defaultCookie = new DefaultCookie(name, "");
/*  571 */     cookieBuilder.accept(defaultCookie);
/*  572 */     return cookie((Cookie)defaultCookie);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final HttpClient cookieCodec(ClientCookieEncoder encoder) {
/*  585 */     Objects.requireNonNull(encoder, "encoder");
/*      */     
/*  587 */     ClientCookieDecoder decoder = (encoder == ClientCookieEncoder.LAX) ? ClientCookieDecoder.LAX : ClientCookieDecoder.STRICT;
/*  588 */     return cookieCodec(encoder, decoder);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final HttpClient cookieCodec(ClientCookieEncoder encoder, ClientCookieDecoder decoder) {
/*  601 */     Objects.requireNonNull(encoder, "encoder");
/*  602 */     Objects.requireNonNull(decoder, "decoder");
/*  603 */     HttpClient dup = (HttpClient)duplicate();
/*  604 */     ((HttpClientConfig)dup.configuration()).cookieEncoder = encoder;
/*  605 */     ((HttpClientConfig)dup.configuration()).cookieDecoder = decoder;
/*  606 */     return dup;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final HttpClient cookiesWhen(String name, Function<? super Cookie, Mono<? extends Cookie>> cookieBuilder) {
/*  617 */     Objects.requireNonNull(name, "name");
/*  618 */     Objects.requireNonNull(cookieBuilder, "cookieBuilder");
/*  619 */     HttpClient dup = (HttpClient)duplicate();
/*  620 */     ((HttpClientConfig)dup.configuration()).deferredConf(config -> ((Mono)cookieBuilder.apply(new DefaultCookie(name, ""))).map(()));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  630 */     return dup;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final RequestSender delete() {
/*  639 */     return request(HttpMethod.DELETE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final HttpClient disableRetry(boolean disableRetry) {
/*  653 */     if (disableRetry == ((HttpClientConfig)configuration()).retryDisabled) {
/*  654 */       return this;
/*      */     }
/*  656 */     HttpClient dup = (HttpClient)duplicate();
/*  657 */     ((HttpClientConfig)dup.configuration()).retryDisabled = disableRetry;
/*  658 */     return dup;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final HttpClient doAfterRequest(BiConsumer<? super HttpClientRequest, ? super Connection> doAfterRequest) {
/*  670 */     Objects.requireNonNull(doAfterRequest, "doAfterRequest");
/*  671 */     HttpClient dup = (HttpClient)duplicate();
/*      */ 
/*      */     
/*  674 */     BiConsumer<? super HttpClientRequest, ? super Connection> biConsumer = ((HttpClientConfig)configuration()).doAfterRequest;
/*  675 */     ((HttpClientConfig)dup.configuration()).doAfterRequest = (biConsumer == null) ? doAfterRequest : biConsumer.andThen(doAfterRequest);
/*  676 */     return dup;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final HttpClient doAfterResponseSuccess(BiConsumer<? super HttpClientResponse, ? super Connection> doAfterResponseSuccess) {
/*  690 */     Objects.requireNonNull(doAfterResponseSuccess, "doAfterResponseSuccess");
/*  691 */     HttpClient dup = (HttpClient)duplicate();
/*      */ 
/*      */     
/*  694 */     BiConsumer<? super HttpClientResponse, ? super Connection> biConsumer = ((HttpClientConfig)configuration()).doAfterResponseSuccess;
/*  695 */     ((HttpClientConfig)dup.configuration()).doAfterResponseSuccess = (biConsumer == null) ? doAfterResponseSuccess : biConsumer.andThen(doAfterResponseSuccess);
/*  696 */     return dup;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final HttpClient doOnError(BiConsumer<? super HttpClientRequest, ? super Throwable> doOnRequestError, BiConsumer<? super HttpClientResponse, ? super Throwable> doOnResponseError) {
/*  714 */     Objects.requireNonNull(doOnRequestError, "doOnRequestError");
/*  715 */     Objects.requireNonNull(doOnResponseError, "doOnResponseError");
/*  716 */     HttpClient dup = (HttpClient)duplicate();
/*      */ 
/*      */     
/*  719 */     BiConsumer<? super HttpClientRequest, ? super Throwable> biConsumer = ((HttpClientConfig)configuration()).doOnRequestError;
/*  720 */     ((HttpClientConfig)dup.configuration())
/*  721 */       .doOnRequestError = (biConsumer == null) ? doOnRequestError : biConsumer.andThen(doOnRequestError);
/*      */ 
/*      */     
/*  724 */     BiConsumer<? super HttpClientResponse, ? super Throwable> biConsumer1 = ((HttpClientConfig)configuration()).doOnResponseError;
/*  725 */     ((HttpClientConfig)dup.configuration())
/*  726 */       .doOnResponseError = (biConsumer1 == null) ? doOnResponseError : biConsumer1.andThen(doOnResponseError);
/*  727 */     return dup;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final HttpClient doOnRedirect(BiConsumer<? super HttpClientResponse, ? super Connection> doOnRedirect) {
/*  744 */     Objects.requireNonNull(doOnRedirect, "doOnRedirect");
/*  745 */     HttpClient dup = (HttpClient)duplicate();
/*      */ 
/*      */     
/*  748 */     BiConsumer<? super HttpClientResponse, ? super Connection> biConsumer = ((HttpClientConfig)configuration()).doOnRedirect;
/*  749 */     ((HttpClientConfig)dup.configuration()).doOnRedirect = (biConsumer == null) ? doOnRedirect : biConsumer.andThen(doOnRedirect);
/*  750 */     return dup;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final HttpClient doOnRequest(BiConsumer<? super HttpClientRequest, ? super Connection> doOnRequest) {
/*  762 */     Objects.requireNonNull(doOnRequest, "doOnRequest");
/*  763 */     HttpClient dup = (HttpClient)duplicate();
/*      */ 
/*      */     
/*  766 */     BiConsumer<? super HttpClientRequest, ? super Connection> biConsumer = ((HttpClientConfig)configuration()).doOnRequest;
/*  767 */     ((HttpClientConfig)dup.configuration()).doOnRequest = (biConsumer == null) ? doOnRequest : biConsumer.andThen(doOnRequest);
/*  768 */     return dup;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final HttpClient doOnRequestError(BiConsumer<? super HttpClientRequest, ? super Throwable> doOnRequestError) {
/*  782 */     Objects.requireNonNull(doOnRequestError, "doOnRequestError");
/*  783 */     HttpClient dup = (HttpClient)duplicate();
/*      */ 
/*      */     
/*  786 */     BiConsumer<? super HttpClientRequest, ? super Throwable> biConsumer = ((HttpClientConfig)configuration()).doOnRequestError;
/*  787 */     ((HttpClientConfig)dup.configuration()).doOnRequestError = (biConsumer == null) ? doOnRequestError : biConsumer.andThen(doOnRequestError);
/*  788 */     return dup;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final HttpClient doOnResponse(BiConsumer<? super HttpClientResponse, ? super Connection> doOnResponse) {
/*  800 */     Objects.requireNonNull(doOnResponse, "doOnResponse");
/*  801 */     HttpClient dup = (HttpClient)duplicate();
/*      */ 
/*      */     
/*  804 */     BiConsumer<? super HttpClientResponse, ? super Connection> biConsumer = ((HttpClientConfig)configuration()).doOnResponse;
/*  805 */     ((HttpClientConfig)dup.configuration()).doOnResponse = (biConsumer == null) ? doOnResponse : biConsumer.andThen(doOnResponse);
/*  806 */     return dup;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final HttpClient doOnResponseError(BiConsumer<? super HttpClientResponse, ? super Throwable> doOnResponseError) {
/*  818 */     Objects.requireNonNull(doOnResponseError, "doOnResponseError");
/*  819 */     HttpClient dup = (HttpClient)duplicate();
/*      */ 
/*      */     
/*  822 */     BiConsumer<? super HttpClientResponse, ? super Throwable> biConsumer = ((HttpClientConfig)configuration()).doOnResponseError;
/*  823 */     ((HttpClientConfig)dup.configuration()).doOnResponseError = (biConsumer == null) ? doOnResponseError : biConsumer.andThen(doOnResponseError);
/*  824 */     return dup;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final HttpClient followRedirect(BiPredicate<HttpClientRequest, HttpClientResponse> predicate) {
/*  843 */     return followRedirect(predicate, (Consumer<HttpClientRequest>)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final HttpClient followRedirect(BiPredicate<HttpClientRequest, HttpClientResponse> predicate, @Nullable BiConsumer<HttpHeaders, HttpClientRequest> redirectRequestBiConsumer) {
/*  872 */     Objects.requireNonNull(predicate, "predicate");
/*  873 */     HttpClient dup = (HttpClient)duplicate();
/*  874 */     ((HttpClientConfig)dup.configuration()).followRedirectPredicate = predicate;
/*  875 */     ((HttpClientConfig)dup.configuration()).redirectRequestBiConsumer = redirectRequestBiConsumer;
/*  876 */     ((HttpClientConfig)dup.configuration()).redirectRequestConsumer = null;
/*  877 */     return dup;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final HttpClient followRedirect(BiPredicate<HttpClientRequest, HttpClientResponse> predicate, @Nullable Consumer<HttpClientRequest> redirectRequestConsumer) {
/*  905 */     Objects.requireNonNull(predicate, "predicate");
/*  906 */     HttpClient dup = (HttpClient)duplicate();
/*  907 */     ((HttpClientConfig)dup.configuration()).followRedirectPredicate = predicate;
/*  908 */     ((HttpClientConfig)dup.configuration()).redirectRequestBiConsumer = null;
/*  909 */     ((HttpClientConfig)dup.configuration()).redirectRequestConsumer = redirectRequestConsumer;
/*  910 */     return dup;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final HttpClient followRedirect(boolean followRedirect) {
/*  925 */     if (!followRedirect && ((HttpClientConfig)configuration()).followRedirectPredicate == null && ((HttpClientConfig)
/*  926 */       configuration()).redirectRequestConsumer == null && ((HttpClientConfig)
/*  927 */       configuration()).redirectRequestBiConsumer == null) {
/*  928 */       return this;
/*      */     }
/*  930 */     return followRedirect(followRedirect, (Consumer<HttpClientRequest>)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final HttpClient followRedirect(boolean followRedirect, @Nullable BiConsumer<HttpHeaders, HttpClientRequest> redirectRequestBiConsumer) {
/*  960 */     if (followRedirect) {
/*  961 */       return followRedirect(HttpClientConfig.FOLLOW_REDIRECT_PREDICATE, redirectRequestBiConsumer);
/*      */     }
/*      */     
/*  964 */     HttpClient dup = (HttpClient)duplicate();
/*  965 */     ((HttpClientConfig)dup.configuration()).followRedirectPredicate = null;
/*  966 */     ((HttpClientConfig)dup.configuration()).redirectRequestBiConsumer = null;
/*  967 */     ((HttpClientConfig)dup.configuration()).redirectRequestConsumer = null;
/*  968 */     return dup;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final HttpClient followRedirect(boolean followRedirect, @Nullable Consumer<HttpClientRequest> redirectRequestConsumer) {
/*  997 */     if (followRedirect) {
/*  998 */       return followRedirect(HttpClientConfig.FOLLOW_REDIRECT_PREDICATE, redirectRequestConsumer);
/*      */     }
/*      */     
/* 1001 */     HttpClient dup = (HttpClient)duplicate();
/* 1002 */     ((HttpClientConfig)dup.configuration()).followRedirectPredicate = null;
/* 1003 */     ((HttpClientConfig)dup.configuration()).redirectRequestBiConsumer = null;
/* 1004 */     ((HttpClientConfig)dup.configuration()).redirectRequestConsumer = null;
/* 1005 */     return dup;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ResponseReceiver<?> get() {
/* 1015 */     return request(HttpMethod.GET);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ResponseReceiver<?> head() {
/* 1024 */     return request(HttpMethod.HEAD);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final HttpClient headers(Consumer<? super HttpHeaders> headerBuilder) {
/* 1035 */     Objects.requireNonNull(headerBuilder, "headerBuilder");
/* 1036 */     HttpClient dup = (HttpClient)duplicate();
/* 1037 */     HttpHeaders headers = ((HttpClientConfig)configuration()).headers.copy();
/* 1038 */     headerBuilder.accept(headers);
/* 1039 */     ((HttpClientConfig)dup.configuration()).headers = headers;
/* 1040 */     return dup;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final HttpClient headersWhen(Function<? super HttpHeaders, Mono<? extends HttpHeaders>> headerBuilder) {
/* 1051 */     Objects.requireNonNull(headerBuilder, "headerBuilder");
/* 1052 */     HttpClient dup = (HttpClient)duplicate();
/* 1053 */     ((HttpClientConfig)dup.configuration()).deferredConf(config -> ((Mono)headerBuilder.apply(config.headers.copy())).map(()));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1059 */     return dup;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final HttpClient http2Settings(Consumer<Http2SettingsSpec.Builder> http2Settings) {
/* 1069 */     Objects.requireNonNull(http2Settings, "http2Settings");
/* 1070 */     Http2SettingsSpec.Builder builder = Http2SettingsSpec.builder();
/* 1071 */     http2Settings.accept(builder);
/* 1072 */     Http2SettingsSpec settings = builder.build();
/* 1073 */     if (settings.equals(((HttpClientConfig)configuration()).http2Settings)) {
/* 1074 */       return this;
/*      */     }
/* 1076 */     HttpClient dup = (HttpClient)duplicate();
/* 1077 */     ((HttpClientConfig)dup.configuration()).http2Settings = settings;
/* 1078 */     return dup;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final HttpClient httpMessageLogFactory(HttpMessageLogFactory httpMessageLogFactory) {
/* 1097 */     Objects.requireNonNull(httpMessageLogFactory, "httpMessageLogFactory");
/* 1098 */     HttpClient dup = (HttpClient)duplicate();
/* 1099 */     ((HttpClientConfig)dup.configuration()).httpMessageLogFactory = httpMessageLogFactory;
/* 1100 */     return dup;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final HttpClient httpResponseDecoder(Function<HttpResponseDecoderSpec, HttpResponseDecoderSpec> responseDecoderOptions) {
/* 1110 */     Objects.requireNonNull(responseDecoderOptions, "responseDecoderOptions");
/* 1111 */     HttpResponseDecoderSpec decoder = ((HttpResponseDecoderSpec)responseDecoderOptions.apply(new HttpResponseDecoderSpec())).build();
/* 1112 */     if (decoder.equals(((HttpClientConfig)configuration()).decoder)) {
/* 1113 */       return this;
/*      */     }
/* 1115 */     HttpClient dup = (HttpClient)duplicate();
/* 1116 */     ((HttpClientConfig)dup.configuration()).decoder = decoder;
/* 1117 */     return dup;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final HttpClient keepAlive(boolean keepAlive) {
/* 1128 */     HttpClient dup = (HttpClient)duplicate();
/* 1129 */     HttpHeaders headers = ((HttpClientConfig)configuration()).headers.copy();
/* 1130 */     HttpUtil.setKeepAlive(headers, HttpVersion.HTTP_1_1, keepAlive);
/* 1131 */     ((HttpClientConfig)dup.configuration()).headers = headers;
/* 1132 */     return dup;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final HttpClient mapConnect(Function<? super Mono<? extends Connection>, ? extends Mono<? extends Connection>> connector) {
/* 1146 */     Objects.requireNonNull(connector, "mapConnect");
/* 1147 */     HttpClient dup = (HttpClient)duplicate();
/*      */     
/* 1149 */     Function<? super Mono<? extends Connection>, ? extends Mono<? extends Connection>> currentConnector = ((HttpClientConfig)configuration()).connector;
/* 1150 */     ((HttpClientConfig)dup.configuration()).connector = (currentConnector == null) ? connector : currentConnector.<Mono<? extends Connection>>andThen(connector);
/* 1151 */     return dup;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final HttpClient metrics(boolean enable, Function<String, String> uriTagValue) {
/* 1182 */     if (enable) {
/* 1183 */       if (!Metrics.isInstrumentationAvailable()) {
/* 1184 */         throw new UnsupportedOperationException("To enable metrics, you must add the dependency `io.micrometer:micrometer-core` to the class path first");
/*      */       }
/*      */ 
/*      */       
/* 1188 */       if (uriTagValue == Function.identity()) {
/* 1189 */         log.debug("Metrics are enabled with [uriTagValue=Function#identity]. It is strongly recommended to provide template-like form for the URIs. Without a conversion to a template-like form, each distinct URI leads to the creation of a distinct tag, which takes a lot of memory for the metrics.");
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 1194 */       HttpClient dup = (HttpClient)duplicate();
/* 1195 */       ((HttpClientConfig)dup.configuration()).metricsRecorder(() -> ((HttpClientConfig)configuration()).defaultMetricsRecorder());
/* 1196 */       ((HttpClientConfig)dup.configuration()).uriTagValue = uriTagValue;
/* 1197 */       return dup;
/*      */     } 
/* 1199 */     if (((HttpClientConfig)configuration()).metricsRecorder() != null) {
/* 1200 */       HttpClient dup = (HttpClient)duplicate();
/* 1201 */       ((HttpClientConfig)dup.configuration()).metricsRecorder((Supplier<? extends ChannelMetricsRecorder>)null);
/* 1202 */       ((HttpClientConfig)dup.configuration()).uriTagValue = null;
/* 1203 */       return dup;
/*      */     } 
/*      */     
/* 1206 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final HttpClient metrics(boolean enable, Supplier<? extends ChannelMetricsRecorder> recorder) {
/* 1212 */     return (HttpClient)super.metrics(enable, recorder);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final HttpClient metrics(boolean enable, Supplier<? extends ChannelMetricsRecorder> recorder, Function<String, String> uriValue) {
/* 1232 */     if (enable) {
/* 1233 */       HttpClient dup = (HttpClient)duplicate();
/* 1234 */       ((HttpClientConfig)dup.configuration()).metricsRecorder(recorder);
/* 1235 */       ((HttpClientConfig)dup.configuration()).uriTagValue = uriValue;
/* 1236 */       return dup;
/*      */     } 
/* 1238 */     if (((HttpClientConfig)configuration()).metricsRecorder() != null) {
/* 1239 */       HttpClient dup = (HttpClient)duplicate();
/* 1240 */       ((HttpClientConfig)dup.configuration()).metricsRecorder((Supplier<? extends ChannelMetricsRecorder>)null);
/* 1241 */       ((HttpClientConfig)dup.configuration()).uriTagValue = null;
/* 1242 */       return dup;
/*      */     } 
/*      */     
/* 1245 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final HttpClient noSSL() {
/* 1255 */     if (((HttpClientConfig)configuration()).isSecure()) {
/* 1256 */       HttpClient dup = (HttpClient)duplicate();
/* 1257 */       ((HttpClientConfig)dup.configuration()).sslProvider = null;
/* 1258 */       return dup;
/*      */     } 
/* 1260 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public final HttpClient observe(ConnectionObserver observer) {
/* 1265 */     return (HttpClient)super.observe(observer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ResponseReceiver<?> options() {
/* 1274 */     return request(HttpMethod.OPTIONS);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final RequestSender patch() {
/* 1283 */     return request(HttpMethod.PATCH);
/*      */   }
/*      */ 
/*      */   
/*      */   public final HttpClient port(int port) {
/* 1288 */     return (HttpClient)super.port(port);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final RequestSender post() {
/* 1297 */     return request(HttpMethod.POST);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final HttpClient protocol(HttpProtocol... supportedProtocols) {
/* 1308 */     Objects.requireNonNull(supportedProtocols, "supportedProtocols");
/* 1309 */     HttpClient dup = (HttpClient)duplicate();
/* 1310 */     HttpClientConfig config = (HttpClientConfig)dup.configuration();
/* 1311 */     config.protocols(supportedProtocols);
/*      */     
/* 1313 */     boolean isH2c = config.checkProtocol(1);
/* 1314 */     if ((!isH2c || config._protocols > 1) && HttpClientSecure.hasDefaultSslProvider(config)) {
/* 1315 */       ((HttpClientConfig)dup.configuration()).sslProvider = HttpClientSecure.defaultSslProvider(config);
/*      */     }
/* 1317 */     return dup;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final RequestSender put() {
/* 1326 */     return request(HttpMethod.PUT);
/*      */   }
/*      */ 
/*      */   
/*      */   public final HttpClient remoteAddress(Supplier<? extends SocketAddress> remoteAddressSupplier) {
/* 1331 */     return (HttpClient)super.remoteAddress(remoteAddressSupplier);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RequestSender request(HttpMethod method) {
/* 1342 */     Objects.requireNonNull(method, "method");
/* 1343 */     HttpClientFinalizer dup = new HttpClientFinalizer(new HttpClientConfig((HttpClientConfig)configuration()));
/* 1344 */     (dup.configuration()).method = method;
/* 1345 */     return dup;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final HttpClient responseTimeout(@Nullable Duration maxReadOperationInterval) {
/* 1366 */     if (Objects.equals(maxReadOperationInterval, ((HttpClientConfig)configuration()).responseTimeout)) {
/* 1367 */       return this;
/*      */     }
/* 1369 */     HttpClient dup = (HttpClient)duplicate();
/* 1370 */     ((HttpClientConfig)dup.configuration()).responseTimeout = maxReadOperationInterval;
/* 1371 */     return dup;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final HttpClient secure() {
/* 1387 */     SslProvider sslProvider = HttpClientSecure.defaultSslProvider((HttpClientConfig)configuration());
/* 1388 */     if (sslProvider.equals(((HttpClientConfig)configuration()).sslProvider)) {
/* 1389 */       return this;
/*      */     }
/* 1391 */     HttpClient dup = (HttpClient)duplicate();
/* 1392 */     ((HttpClientConfig)dup.configuration()).sslProvider = sslProvider;
/* 1393 */     return dup;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final HttpClient secure(Consumer<? super SslProvider.SslContextSpec> sslProviderBuilder) {
/* 1410 */     Objects.requireNonNull(sslProviderBuilder, "sslProviderBuilder");
/* 1411 */     SslProvider.SslContextSpec builder = SslProvider.builder();
/* 1412 */     sslProviderBuilder.accept(builder);
/* 1413 */     SslProvider sslProvider = HttpClientSecure.sslProvider(((SslProvider.Builder)builder).build());
/* 1414 */     if (sslProvider.equals(((HttpClientConfig)configuration()).sslProvider)) {
/* 1415 */       return this;
/*      */     }
/* 1417 */     HttpClient dup = (HttpClient)duplicate();
/* 1418 */     ((HttpClientConfig)dup.configuration()).sslProvider = sslProvider;
/* 1419 */     return dup;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpClient secure(SslProvider sslProvider) {
/* 1444 */     Objects.requireNonNull(sslProvider, "sslProvider");
/* 1445 */     HttpClient dup = (HttpClient)duplicate();
/* 1446 */     ((HttpClientConfig)dup.configuration()).sslProvider = sslProvider;
/* 1447 */     return dup;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public final HttpClient tcpConfiguration(Function<? super TcpClient, ? extends TcpClient> tcpMapper) {
/* 1527 */     Objects.requireNonNull(tcpMapper, "tcpMapper");
/* 1528 */     HttpClientTcpConfig tcpClient = new HttpClientTcpConfig(this);
/*      */     
/* 1530 */     tcpMapper.apply(tcpClient);
/* 1531 */     return tcpClient.httpClient;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<Void> warmup() {
/* 1549 */     return Mono.when(new Publisher[] { (Publisher)super
/* 1550 */           .warmup(), 
/*      */ 
/*      */ 
/*      */           
/* 1554 */           (Publisher)Mono.fromRunnable(OpenSsl::version) });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final WebsocketSender websocket() {
/* 1563 */     return websocket(WebsocketClientSpec.builder().build());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final WebsocketSender websocket(WebsocketClientSpec websocketClientSpec) {
/* 1574 */     Objects.requireNonNull(websocketClientSpec, "websocketClientSpec");
/* 1575 */     WebsocketFinalizer dup = new WebsocketFinalizer(new HttpClientConfig((HttpClientConfig)configuration()));
/* 1576 */     HttpClientConfig config = dup.configuration();
/* 1577 */     config.websocketClientSpec = websocketClientSpec;
/* 1578 */     return dup;
/*      */   }
/*      */ 
/*      */   
/*      */   public final HttpClient wiretap(boolean enable) {
/* 1583 */     return (HttpClient)super.wiretap(enable);
/*      */   }
/*      */   
/*      */   static boolean isCompressing(HttpHeaders h) {
/* 1587 */     return h.contains((CharSequence)HttpHeaderNames.ACCEPT_ENCODING, (CharSequence)HttpHeaderValues.GZIP, true);
/*      */   }
/*      */   
/*      */   static String reactorNettyVersion() {
/* 1591 */     return Optional.<String>ofNullable(HttpClient.class.getPackage()
/* 1592 */         .getImplementationVersion())
/* 1593 */       .orElse("dev");
/*      */   }
/*      */   
/* 1596 */   static final Logger log = Loggers.getLogger(HttpClient.class);
/*      */   static final String HTTP_SCHEME = "http";
/*      */   static final String HTTPS_SCHEME = "https";
/*      */   static final String WS_SCHEME = "ws";
/*      */   static final String WSS_SCHEME = "wss";
/*      */   
/*      */   public static interface UriConfiguration<S extends UriConfiguration<?>> {
/*      */     S uri(String param1String);
/*      */     
/*      */     S uri(Mono<String> param1Mono);
/*      */     
/*      */     S uri(URI param1URI);
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\client\HttpClient.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */