/*    */ package reactor.netty.http.client;
/*    */ 
/*    */ import io.micrometer.core.instrument.Gauge;
/*    */ import io.micrometer.core.instrument.Meter;
/*    */ import io.micrometer.core.instrument.Tags;
/*    */ import java.net.SocketAddress;
/*    */ import reactor.netty.Metrics;
/*    */ import reactor.netty.internal.shaded.reactor.pool.InstrumentedPool;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MicrometerHttp2ConnectionProviderMeterRegistrar
/*    */ {
/*    */   static final String ACTIVE_CONNECTIONS_DESCRIPTION = "The number of the connections that have been successfully acquired and are in active use";
/*    */   static final String ACTIVE_STREAMS_DESCRIPTION = "The number of the active HTTP/2 streams";
/*    */   static final String IDLE_CONNECTIONS_DESCRIPTION = "The number of the idle connections";
/*    */   static final String PENDING_STREAMS_DESCRIPTION = "The number of requests that are waiting for opening HTTP/2 stream";
/* 44 */   static final MicrometerHttp2ConnectionProviderMeterRegistrar INSTANCE = new MicrometerHttp2ConnectionProviderMeterRegistrar();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   void registerMetrics(String poolName, String id, SocketAddress remoteAddress, InstrumentedPool.PoolMetrics metrics) {
/* 51 */     String addressAsString = Metrics.formatSocketAddress(remoteAddress);
/* 52 */     Tags tags = Tags.of(new String[] { "id", id, "remote.address", addressAsString, "name", poolName });
/*    */     
/* 54 */     Gauge.builder("reactor.netty.connection.provider.active.connections", metrics, InstrumentedPool.PoolMetrics::acquiredSize)
/* 55 */       .description("The number of the connections that have been successfully acquired and are in active use")
/* 56 */       .tags((Iterable)tags)
/* 57 */       .register(Metrics.REGISTRY);
/*    */     
/* 59 */     Gauge.builder("reactor.netty.connection.provider.active.streams", metrics, poolMetrics -> ((Http2Pool)poolMetrics).activeStreams())
/* 60 */       .description("The number of the active HTTP/2 streams")
/* 61 */       .tags((Iterable)tags)
/* 62 */       .register(Metrics.REGISTRY);
/*    */     
/* 64 */     Gauge.builder("reactor.netty.connection.provider.idle.connections", metrics, InstrumentedPool.PoolMetrics::idleSize)
/* 65 */       .description("The number of the idle connections")
/* 66 */       .tags((Iterable)tags)
/* 67 */       .register(Metrics.REGISTRY);
/*    */     
/* 69 */     Gauge.builder("reactor.netty.connection.provider.pending.streams", metrics, InstrumentedPool.PoolMetrics::pendingAcquireSize)
/* 70 */       .description("The number of requests that are waiting for opening HTTP/2 stream")
/* 71 */       .tags((Iterable)tags)
/* 72 */       .register(Metrics.REGISTRY);
/*    */   }
/*    */   
/*    */   void deRegisterMetrics(String poolName, String id, SocketAddress remoteAddress) {
/* 76 */     String addressAsString = Metrics.formatSocketAddress(remoteAddress);
/* 77 */     Tags tags = Tags.of(new String[] { "id", id, "remote.address", addressAsString, "name", poolName });
/*    */     
/* 79 */     Metrics.REGISTRY.remove(new Meter.Id("reactor.netty.connection.provider.active.connections", tags, null, null, Meter.Type.GAUGE));
/* 80 */     Metrics.REGISTRY.remove(new Meter.Id("reactor.netty.connection.provider.active.streams", tags, null, null, Meter.Type.GAUGE));
/* 81 */     Metrics.REGISTRY.remove(new Meter.Id("reactor.netty.connection.provider.idle.connections", tags, null, null, Meter.Type.GAUGE));
/* 82 */     Metrics.REGISTRY.remove(new Meter.Id("reactor.netty.connection.provider.pending.streams", tags, null, null, Meter.Type.GAUGE));
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\client\MicrometerHttp2ConnectionProviderMeterRegistrar.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */