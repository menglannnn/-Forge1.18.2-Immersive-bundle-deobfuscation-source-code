/*    */ package reactor.netty.http.client;
/*    */ 
/*    */ import java.util.function.Function;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class HttpClientMetricsHandler
/*    */   extends AbstractHttpClientMetricsHandler
/*    */ {
/*    */   final HttpClientMetricsRecorder recorder;
/*    */   
/*    */   HttpClientMetricsHandler(HttpClientMetricsRecorder recorder, @Nullable Function<String, String> uriTagValue) {
/* 30 */     super(uriTagValue);
/* 31 */     this.recorder = recorder;
/*    */   }
/*    */   
/*    */   HttpClientMetricsHandler(HttpClientMetricsHandler copy) {
/* 35 */     super(copy);
/* 36 */     this.recorder = copy.recorder;
/*    */   }
/*    */ 
/*    */   
/*    */   protected HttpClientMetricsRecorder recorder() {
/* 41 */     return this.recorder;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\client\HttpClientMetricsHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */