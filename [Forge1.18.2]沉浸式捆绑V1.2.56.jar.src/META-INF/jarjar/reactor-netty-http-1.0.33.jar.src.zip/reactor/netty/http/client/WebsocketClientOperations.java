/*     */ package reactor.netty.http.client;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.channel.Channel;
/*     */ import io.netty.channel.ChannelFuture;
/*     */ import io.netty.channel.ChannelFutureListener;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.handler.codec.http.FullHttpResponse;
/*     */ import io.netty.handler.codec.http.HttpHeaderNames;
/*     */ import io.netty.handler.codec.http.HttpHeaders;
/*     */ import io.netty.handler.codec.http.HttpObjectAggregator;
/*     */ import io.netty.handler.codec.http.HttpResponse;
/*     */ import io.netty.handler.codec.http.LastHttpContent;
/*     */ import io.netty.handler.codec.http.websocketx.CloseWebSocketFrame;
/*     */ import io.netty.handler.codec.http.websocketx.PingWebSocketFrame;
/*     */ import io.netty.handler.codec.http.websocketx.PongWebSocketFrame;
/*     */ import io.netty.handler.codec.http.websocketx.WebSocketClientHandshakeException;
/*     */ import io.netty.handler.codec.http.websocketx.WebSocketClientHandshaker;
/*     */ import io.netty.handler.codec.http.websocketx.WebSocketClientHandshakerFactory;
/*     */ import io.netty.handler.codec.http.websocketx.WebSocketCloseStatus;
/*     */ import io.netty.util.concurrent.Future;
/*     */ import io.netty.util.concurrent.GenericFutureListener;
/*     */ import java.net.URI;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.core.publisher.Sinks;
/*     */ import reactor.netty.Connection;
/*     */ import reactor.netty.FutureMono;
/*     */ import reactor.netty.NettyOutbound;
/*     */ import reactor.netty.ReactorNetty;
/*     */ import reactor.netty.http.websocket.WebsocketInbound;
/*     */ import reactor.netty.http.websocket.WebsocketOutbound;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class WebsocketClientOperations
/*     */   extends HttpClientOperations
/*     */   implements WebsocketInbound, WebsocketOutbound
/*     */ {
/*     */   final WebSocketClientHandshaker handshaker;
/*     */   final Sinks.One<WebSocketCloseStatus> onCloseState;
/*     */   final boolean proxyPing;
/*     */   volatile int closeSent;
/*     */   static final String INBOUND_CANCEL_LOG = "WebSocket client inbound receiver cancelled, closing Websocket.";
/*     */   
/*     */   WebsocketClientOperations(URI currentURI, WebsocketClientSpec websocketClientSpec, HttpClientOperations replaced) {
/*  68 */     super(replaced);
/*  69 */     this.proxyPing = websocketClientSpec.handlePing();
/*  70 */     Channel channel = channel();
/*  71 */     this.onCloseState = Sinks.unsafe().one();
/*     */     
/*  73 */     String subprotocols = websocketClientSpec.protocols();
/*  74 */     this.handshaker = WebSocketClientHandshakerFactory.newHandshaker(currentURI, websocketClientSpec
/*  75 */         .version(), (
/*  76 */         subprotocols != null && !subprotocols.isEmpty()) ? subprotocols : null, true, replaced
/*     */         
/*  78 */         .requestHeaders()
/*  79 */         .remove((CharSequence)HttpHeaderNames.HOST), websocketClientSpec
/*  80 */         .maxFramePayloadLength());
/*     */     
/*  82 */     this.handshaker.handshake(channel)
/*  83 */       .addListener(f -> {
/*     */           markPersistent(false);
/*     */           channel.read();
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpHeaders headers() {
/*  91 */     return responseHeaders();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isWebsocket() {
/*  96 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String selectedSubprotocol() {
/* 102 */     return this.handshaker.actualSubprotocol();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onInboundNext(ChannelHandlerContext ctx, Object msg) {
/* 108 */     if (msg instanceof FullHttpResponse) {
/* 109 */       this.started = true;
/* 110 */       channel().pipeline()
/* 111 */         .remove(HttpObjectAggregator.class);
/* 112 */       FullHttpResponse response = (FullHttpResponse)msg;
/*     */       
/* 114 */       setNettyResponse((HttpResponse)response);
/*     */       
/* 116 */       if (notRedirected((HttpResponse)response)) {
/*     */         try {
/* 118 */           this.handshaker.finishHandshake(channel(), response);
/*     */           
/* 120 */           ctx.read();
/* 121 */           listener().onStateChange((Connection)this, HttpClientState.RESPONSE_RECEIVED);
/*     */         }
/* 123 */         catch (Exception e) {
/* 124 */           onInboundError(e);
/*     */           
/* 126 */           ctx.close();
/*     */         }
/*     */         finally {
/*     */           
/* 130 */           response.content()
/* 131 */             .release();
/*     */         } 
/*     */       } else {
/*     */         
/* 135 */         response.content()
/* 136 */           .release();
/* 137 */         listener().onUncaughtException((Connection)this, this.redirecting);
/*     */       } 
/*     */       return;
/*     */     } 
/* 141 */     if (!this.proxyPing && msg instanceof PingWebSocketFrame) {
/*     */       
/* 143 */       ctx.writeAndFlush(new PongWebSocketFrame(((PingWebSocketFrame)msg).content()));
/* 144 */       ctx.read();
/*     */       return;
/*     */     } 
/* 147 */     if (msg instanceof CloseWebSocketFrame && ((CloseWebSocketFrame)msg)
/* 148 */       .isFinalFragment()) {
/* 149 */       if (log.isDebugEnabled()) {
/* 150 */         log.debug(ReactorNetty.format(channel(), "CloseWebSocketFrame detected. Closing Websocket"));
/*     */       }
/*     */       
/* 153 */       CloseWebSocketFrame closeFrame = new CloseWebSocketFrame(true, ((CloseWebSocketFrame)msg).rsv(), ((CloseWebSocketFrame)msg).content());
/* 154 */       if (closeFrame.statusCode() != -1) {
/* 155 */         sendCloseNow(closeFrame);
/*     */       } else {
/*     */         
/* 158 */         sendCloseNow(closeFrame, WebSocketCloseStatus.EMPTY);
/*     */       } 
/* 160 */       onInboundComplete();
/*     */     }
/* 162 */     else if (msg != LastHttpContent.EMPTY_LAST_CONTENT) {
/* 163 */       super.onInboundNext(ctx, msg);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void onInboundCancel() {
/* 169 */     if (log.isDebugEnabled()) {
/* 170 */       log.debug(ReactorNetty.format(channel(), "WebSocket client inbound receiver cancelled, closing Websocket."));
/*     */     }
/* 172 */     sendCloseNow(new CloseWebSocketFrame(), WebSocketCloseStatus.ABNORMAL_CLOSURE);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void onInboundClose() {
/* 177 */     if (this.handshaker.isHandshakeComplete()) {
/* 178 */       terminate();
/*     */     } else {
/*     */       
/* 181 */       onInboundError((Throwable)new WebSocketClientHandshakeException("Connection prematurely closed BEFORE opening handshake is complete."));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onOutboundComplete() {}
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onOutboundError(Throwable err) {
/* 192 */     if (channel().isActive()) {
/* 193 */       if (log.isDebugEnabled()) {
/* 194 */         log.debug(ReactorNetty.format(channel(), "Outbound error happened"), err);
/*     */       }
/* 196 */       sendCloseNow(new CloseWebSocketFrame(WebSocketCloseStatus.PROTOCOL_ERROR));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public NettyOutbound send(Publisher<? extends ByteBuf> dataStream) {
/* 202 */     return sendObject((Publisher)Flux.from(dataStream).map(bytebufToWebsocketFrame));
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> sendClose() {
/* 207 */     return sendClose(new CloseWebSocketFrame());
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> sendClose(int rsv) {
/* 212 */     return sendClose(new CloseWebSocketFrame(true, rsv));
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> sendClose(int statusCode, @Nullable String reasonText) {
/* 217 */     return sendClose(new CloseWebSocketFrame(statusCode, reasonText));
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> sendClose(int rsv, int statusCode, @Nullable String reasonText) {
/* 222 */     return sendClose(new CloseWebSocketFrame(true, rsv, statusCode, reasonText));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<WebSocketCloseStatus> receiveCloseStatus() {
/* 228 */     return this.onCloseState.asMono().or(onTerminate());
/*     */   }
/*     */   
/*     */   Mono<Void> sendClose(CloseWebSocketFrame frame) {
/* 232 */     if (CLOSE_SENT.get(this) == 0)
/*     */     {
/*     */       
/* 235 */       return FutureMono.deferFuture(() -> {
/*     */             if (CLOSE_SENT.getAndSet(this, 1) == 0) {
/*     */               discard();
/*     */ 
/*     */               
/*     */               this.onCloseState.tryEmitValue(new WebSocketCloseStatus(frame.statusCode(), frame.reasonText()));
/*     */               
/*     */               return channel().writeAndFlush(frame).addListener((GenericFutureListener)ChannelFutureListener.CLOSE);
/*     */             } 
/*     */             
/*     */             frame.release();
/*     */             
/*     */             return channel().newSucceededFuture();
/* 248 */           }).doOnCancel(() -> ReactorNetty.safeRelease(frame));
/*     */     }
/* 250 */     frame.release();
/* 251 */     return Mono.empty();
/*     */   }
/*     */   
/*     */   void sendCloseNow(CloseWebSocketFrame frame) {
/* 255 */     sendCloseNow(frame, new WebSocketCloseStatus(frame.statusCode(), frame.reasonText()));
/*     */   }
/*     */ 
/*     */   
/*     */   void sendCloseNow(CloseWebSocketFrame frame, WebSocketCloseStatus closeStatus) {
/* 260 */     if (!frame.isFinalFragment()) {
/*     */       
/* 262 */       channel().writeAndFlush(frame);
/*     */       return;
/*     */     } 
/* 265 */     if (CLOSE_SENT.getAndSet(this, 1) == 0) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 270 */       this.onCloseState.tryEmitValue(closeStatus);
/* 271 */       channel().writeAndFlush(frame)
/* 272 */         .addListener((GenericFutureListener)ChannelFutureListener.CLOSE);
/*     */     } else {
/*     */       
/* 275 */       frame.release();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/* 280 */   static final AtomicIntegerFieldUpdater<WebsocketClientOperations> CLOSE_SENT = AtomicIntegerFieldUpdater.newUpdater(WebsocketClientOperations.class, "closeSent");
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\client\WebsocketClientOperations.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */