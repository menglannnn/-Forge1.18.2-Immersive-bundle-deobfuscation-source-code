/*    */ package reactor.netty.http.client;
/*    */ 
/*    */ import io.netty.handler.codec.http.websocketx.WebSocketVersion;
/*    */ import java.util.Objects;
/*    */ import reactor.netty.http.websocket.WebsocketSpec;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface WebsocketClientSpec
/*    */   extends WebsocketSpec
/*    */ {
/*    */   WebSocketVersion version();
/*    */   
/*    */   static Builder builder() {
/* 54 */     return new Builder();
/*    */   }
/*    */   
/*    */   public static final class Builder
/*    */     extends WebsocketSpec.Builder<Builder> {
/* 59 */     WebSocketVersion version = WebSocketVersion.V13;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     public final Builder version(WebSocketVersion version) {
/* 75 */       Objects.requireNonNull(version, "version");
/* 76 */       if (WebSocketVersion.UNKNOWN.equals(version)) {
/* 77 */         throw new IllegalArgumentException("WebSocketVersion.UNKNOWN represents an invalid version, please provide a proper version");
/*    */       }
/* 79 */       this.version = version;
/* 80 */       return this;
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     public final WebsocketClientSpec build() {
/* 89 */       return new WebsocketClientSpecImpl(this);
/*    */     }
/*    */     
/*    */     private Builder() {}
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\client\WebsocketClientSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */