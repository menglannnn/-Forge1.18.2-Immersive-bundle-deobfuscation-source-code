/*      */ package reactor.netty.http.client;
/*      */ 
/*      */ import io.netty.channel.Channel;
/*      */ import io.netty.channel.ChannelHandler;
/*      */ import io.netty.channel.ChannelHandlerAdapter;
/*      */ import io.netty.channel.ChannelHandlerContext;
/*      */ import io.netty.channel.ChannelInboundHandlerAdapter;
/*      */ import io.netty.channel.ChannelInitializer;
/*      */ import io.netty.channel.ChannelOption;
/*      */ import io.netty.channel.ChannelPipeline;
/*      */ import io.netty.handler.codec.http.DefaultHttpHeaders;
/*      */ import io.netty.handler.codec.http.HttpClientCodec;
/*      */ import io.netty.handler.codec.http.HttpClientUpgradeHandler;
/*      */ import io.netty.handler.codec.http.HttpContentDecompressor;
/*      */ import io.netty.handler.codec.http.HttpHeaders;
/*      */ import io.netty.handler.codec.http.HttpMethod;
/*      */ import io.netty.handler.codec.http.cookie.ClientCookieDecoder;
/*      */ import io.netty.handler.codec.http.cookie.ClientCookieEncoder;
/*      */ import io.netty.handler.codec.http2.Http2ClientUpgradeCodec;
/*      */ import io.netty.handler.codec.http2.Http2FrameCodec;
/*      */ import io.netty.handler.codec.http2.Http2FrameCodecBuilder;
/*      */ import io.netty.handler.codec.http2.Http2FrameLogger;
/*      */ import io.netty.handler.codec.http2.Http2MultiplexHandler;
/*      */ import io.netty.handler.codec.http2.Http2Settings;
/*      */ import io.netty.handler.codec.http2.Http2StreamFrameToHttpObjectCodec;
/*      */ import io.netty.handler.flush.FlushConsolidationHandler;
/*      */ import io.netty.handler.logging.LogLevel;
/*      */ import io.netty.handler.logging.LoggingHandler;
/*      */ import io.netty.handler.ssl.SslHandler;
/*      */ import io.netty.handler.timeout.ReadTimeoutHandler;
/*      */ import io.netty.resolver.AddressResolverGroup;
/*      */ import java.net.SocketAddress;
/*      */ import java.net.URI;
/*      */ import java.nio.charset.Charset;
/*      */ import java.time.Duration;
/*      */ import java.util.Map;
/*      */ import java.util.Objects;
/*      */ import java.util.concurrent.TimeUnit;
/*      */ import java.util.function.BiConsumer;
/*      */ import java.util.function.BiFunction;
/*      */ import java.util.function.BiPredicate;
/*      */ import java.util.function.Consumer;
/*      */ import java.util.function.Function;
/*      */ import java.util.function.Supplier;
/*      */ import java.util.regex.Pattern;
/*      */ import org.reactivestreams.Publisher;
/*      */ import reactor.core.publisher.Mono;
/*      */ import reactor.netty.ChannelPipelineConfigurer;
/*      */ import reactor.netty.Connection;
/*      */ import reactor.netty.ConnectionObserver;
/*      */ import reactor.netty.NettyOutbound;
/*      */ import reactor.netty.ReactorNetty;
/*      */ import reactor.netty.channel.ChannelMetricsRecorder;
/*      */ import reactor.netty.channel.ChannelOperations;
/*      */ import reactor.netty.http.Http2SettingsSpec;
/*      */ import reactor.netty.http.HttpProtocol;
/*      */ import reactor.netty.http.HttpResources;
/*      */ import reactor.netty.http.logging.HttpMessageLogFactory;
/*      */ import reactor.netty.http.logging.ReactorNettyHttpMessageLogFactory;
/*      */ import reactor.netty.resources.ConnectionProvider;
/*      */ import reactor.netty.resources.LoopResources;
/*      */ import reactor.netty.tcp.SslProvider;
/*      */ import reactor.netty.transport.ClientTransportConfig;
/*      */ import reactor.netty.transport.ProxyProvider;
/*      */ import reactor.netty.transport.logging.AdvancedByteBufFormat;
/*      */ import reactor.util.Logger;
/*      */ import reactor.util.Loggers;
/*      */ import reactor.util.annotation.Nullable;
/*      */ import reactor.util.context.Context;
/*      */ import reactor.util.context.ContextView;
/*      */ 
/*      */ public final class HttpClientConfig
/*      */   extends ClientTransportConfig<HttpClientConfig> {
/*      */   boolean acceptGzip;
/*      */   String baseUrl;
/*      */   BiFunction<? super HttpClientRequest, ? super NettyOutbound, ? extends Publisher<Void>> body;
/*      */   Function<? super Mono<? extends Connection>, ? extends Mono<? extends Connection>> connector;
/*      */   ClientCookieDecoder cookieDecoder;
/*      */   ClientCookieEncoder cookieEncoder;
/*      */   HttpResponseDecoderSpec decoder;
/*      */   Function<Mono<HttpClientConfig>, Mono<HttpClientConfig>> deferredConf;
/*      */   BiConsumer<? super HttpClientRequest, ? super Connection> doAfterRequest;
/*      */   BiConsumer<? super HttpClientResponse, ? super Connection> doAfterResponseSuccess;
/*      */   BiConsumer<? super HttpClientResponse, ? super Connection> doOnRedirect;
/*      */   BiConsumer<? super HttpClientRequest, ? super Connection> doOnRequest;
/*      */   BiConsumer<? super HttpClientRequest, ? super Throwable> doOnRequestError;
/*      */   BiConsumer<? super HttpClientResponse, ? super Connection> doOnResponse;
/*      */   BiConsumer<? super HttpClientResponse, ? super Throwable> doOnResponseError;
/*      */   BiPredicate<HttpClientRequest, HttpClientResponse> followRedirectPredicate;
/*      */   HttpHeaders headers;
/*      */   Http2SettingsSpec http2Settings;
/*      */   HttpMessageLogFactory httpMessageLogFactory;
/*      */   HttpMethod method;
/*      */   HttpProtocol[] protocols;
/*      */   int _protocols;
/*      */   BiConsumer<HttpHeaders, HttpClientRequest> redirectRequestBiConsumer;
/*      */   Consumer<HttpClientRequest> redirectRequestConsumer;
/*      */   Duration responseTimeout;
/*      */   boolean retryDisabled;
/*      */   SslProvider sslProvider;
/*      */   URI uri;
/*      */   String uriStr;
/*      */   Function<String, String> uriTagValue;
/*      */   WebsocketClientSpec websocketClientSpec;
/*      */   
/*      */   @Nullable
/*      */   public String baseUrl() {
/*  108 */     return this.baseUrl;
/*      */   }
/*      */ 
/*      */   
/*      */   public int channelHash() {
/*  113 */     int result = super.channelHash();
/*  114 */     result = 31 * result + Boolean.hashCode(this.acceptGzip);
/*  115 */     result = 31 * result + Objects.hashCode(this.decoder);
/*  116 */     result = 31 * result + this._protocols;
/*  117 */     result = 31 * result + Objects.hashCode(this.sslProvider);
/*  118 */     result = 31 * result + Objects.hashCode(this.uriTagValue);
/*  119 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelOperations.OnSetup channelOperationsProvider() {
/*  124 */     return (ch, c, msg) -> new HttpClientOperations(ch, c, this.cookieEncoder, this.cookieDecoder, this.httpMessageLogFactory);
/*      */   }
/*      */ 
/*      */   
/*      */   public ConnectionProvider connectionProvider() {
/*  129 */     return httpConnectionProvider().http1ConnectionProvider();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ClientCookieDecoder cookieDecoder() {
/*  138 */     return this.cookieDecoder;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ClientCookieEncoder cookieEncoder() {
/*  147 */     return this.cookieEncoder;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpResponseDecoderSpec decoder() {
/*  156 */     return this.decoder;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public BiPredicate<HttpClientRequest, HttpClientResponse> followRedirectPredicate() {
/*  166 */     return this.followRedirectPredicate;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpHeaders headers() {
/*  175 */     return this.headers.copy();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Http2SettingsSpec http2SettingsSpec() {
/*  184 */     return this.http2Settings;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isAcceptGzip() {
/*  193 */     return this.acceptGzip;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isRetryDisabled() {
/*  202 */     return this.retryDisabled;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isSecure() {
/*  211 */     return (this.sslProvider != null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpMethod method() {
/*  220 */     return this.method;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpProtocol[] protocols() {
/*  229 */     return this.protocols;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public BiConsumer<HttpHeaders, HttpClientRequest> redirectRequestBiConsumer() {
/*  239 */     return this.redirectRequestBiConsumer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public Consumer<HttpClientRequest> redirectRequestConsumer() {
/*  249 */     return this.redirectRequestConsumer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public Duration responseTimeout() {
/*  259 */     return this.responseTimeout;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public SslProvider sslProvider() {
/*  271 */     return this.sslProvider;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String uri() {
/*  280 */     return (this.uri == null) ? this.uriStr : this.uri.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public Function<String, String> uriTagValue() {
/*  292 */     return this.uriTagValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WebsocketClientSpec websocketClientSpec() {
/*  301 */     return this.websocketClientSpec;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   HttpClientConfig(HttpConnectionProvider connectionProvider, Map<ChannelOption<?>, ?> options, Supplier<? extends SocketAddress> remoteAddress) {
/*  341 */     super(connectionProvider, options, remoteAddress);
/*  342 */     this.acceptGzip = false;
/*  343 */     this.cookieDecoder = ClientCookieDecoder.STRICT;
/*  344 */     this.cookieEncoder = ClientCookieEncoder.STRICT;
/*  345 */     this.decoder = new HttpResponseDecoderSpec();
/*  346 */     this.headers = (HttpHeaders)new DefaultHttpHeaders();
/*  347 */     this.httpMessageLogFactory = (HttpMessageLogFactory)ReactorNettyHttpMessageLogFactory.INSTANCE;
/*  348 */     this.method = HttpMethod.GET;
/*  349 */     this.protocols = new HttpProtocol[] { HttpProtocol.HTTP11 };
/*  350 */     this._protocols = 4;
/*  351 */     this.retryDisabled = false;
/*      */   }
/*      */   
/*      */   HttpClientConfig(HttpClientConfig parent) {
/*  355 */     super(parent);
/*  356 */     this.acceptGzip = parent.acceptGzip;
/*  357 */     this.baseUrl = parent.baseUrl;
/*  358 */     this.body = parent.body;
/*  359 */     this.connector = parent.connector;
/*  360 */     this.cookieDecoder = parent.cookieDecoder;
/*  361 */     this.cookieEncoder = parent.cookieEncoder;
/*  362 */     this.decoder = parent.decoder;
/*  363 */     this.deferredConf = parent.deferredConf;
/*  364 */     this.doAfterRequest = parent.doAfterRequest;
/*  365 */     this.doAfterResponseSuccess = parent.doAfterResponseSuccess;
/*  366 */     this.doOnRedirect = parent.doOnRedirect;
/*  367 */     this.doOnRequest = parent.doOnRequest;
/*  368 */     this.doOnRequestError = parent.doOnRequestError;
/*  369 */     this.doOnResponse = parent.doOnResponse;
/*  370 */     this.doOnResponseError = parent.doOnResponseError;
/*  371 */     this.followRedirectPredicate = parent.followRedirectPredicate;
/*  372 */     this.headers = parent.headers;
/*  373 */     this.http2Settings = parent.http2Settings;
/*  374 */     this.httpMessageLogFactory = parent.httpMessageLogFactory;
/*  375 */     this.method = parent.method;
/*  376 */     this.protocols = parent.protocols;
/*  377 */     this._protocols = parent._protocols;
/*  378 */     this.redirectRequestBiConsumer = parent.redirectRequestBiConsumer;
/*  379 */     this.redirectRequestConsumer = parent.redirectRequestConsumer;
/*  380 */     this.responseTimeout = parent.responseTimeout;
/*  381 */     this.retryDisabled = parent.retryDisabled;
/*  382 */     this.sslProvider = parent.sslProvider;
/*  383 */     this.uri = parent.uri;
/*  384 */     this.uriStr = parent.uriStr;
/*  385 */     this.uriTagValue = parent.uriTagValue;
/*  386 */     this.websocketClientSpec = parent.websocketClientSpec;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AddressResolverGroup<?> defaultAddressResolverGroup() {
/*  398 */     return HttpResources.get().getOrCreateDefaultResolver();
/*      */   }
/*      */ 
/*      */   
/*      */   protected ConnectionObserver defaultConnectionObserver() {
/*  403 */     if (this.doAfterRequest == null && this.doAfterResponseSuccess == null && this.doOnRedirect == null && this.doOnRequest == null && this.doOnRequestError == null && this.doOnResponse == null && this.doOnResponseError == null)
/*      */     {
/*  405 */       return super.defaultConnectionObserver();
/*      */     }
/*      */     
/*  408 */     return super.defaultConnectionObserver()
/*  409 */       .then(new HttpClientDoOn(this.doAfterRequest, this.doAfterResponseSuccess, this.doOnRedirect, this.doOnRequest, this.doOnRequestError, this.doOnResponse, this.doOnResponseError));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected LoggingHandler defaultLoggingHandler() {
/*  416 */     return LOGGING_HANDLER;
/*      */   }
/*      */ 
/*      */   
/*      */   protected LoopResources defaultLoopResources() {
/*  421 */     return (LoopResources)HttpResources.get();
/*      */   }
/*      */ 
/*      */   
/*      */   protected ChannelMetricsRecorder defaultMetricsRecorder() {
/*  426 */     return (ChannelMetricsRecorder)MicrometerHttpClientMetricsRecorder.INSTANCE;
/*      */   }
/*      */ 
/*      */   
/*      */   protected ChannelPipelineConfigurer defaultOnChannelInit() {
/*  431 */     return super.defaultOnChannelInit()
/*  432 */       .then(new HttpClientChannelInitializer(this));
/*      */   }
/*      */ 
/*      */   
/*      */   protected void loggingHandler(LoggingHandler loggingHandler) {
/*  437 */     super.loggingHandler(loggingHandler);
/*      */   }
/*      */ 
/*      */   
/*      */   protected void metricsRecorder(@Nullable Supplier<? extends ChannelMetricsRecorder> metricsRecorder) {
/*  442 */     super.metricsRecorder(metricsRecorder);
/*      */   }
/*      */ 
/*      */   
/*      */   protected void proxyProvider(ProxyProvider proxyProvider) {
/*  447 */     super.proxyProvider(proxyProvider);
/*      */   }
/*      */ 
/*      */   
/*      */   protected AddressResolverGroup<?> resolverInternal() {
/*  452 */     return super.resolverInternal();
/*      */   }
/*      */   
/*      */   void deferredConf(Function<HttpClientConfig, Mono<HttpClientConfig>> deferrer) {
/*  456 */     if (this.deferredConf != null) {
/*  457 */       this.deferredConf = this.deferredConf.andThen(deferredConf -> deferredConf.flatMap(deferrer));
/*      */     } else {
/*      */       
/*  460 */       this.deferredConf = (deferredConf -> deferredConf.flatMap(deferrer));
/*      */     } 
/*      */   }
/*      */   
/*      */   HttpConnectionProvider httpConnectionProvider() {
/*  465 */     return (HttpConnectionProvider)super.connectionProvider();
/*      */   }
/*      */   
/*      */   void protocols(HttpProtocol... protocols) {
/*  469 */     this.protocols = protocols;
/*  470 */     int _protocols = 0;
/*      */     
/*  472 */     for (HttpProtocol p : protocols) {
/*  473 */       if (p == HttpProtocol.HTTP11) {
/*  474 */         _protocols |= 0x4;
/*      */       }
/*  476 */       else if (p == HttpProtocol.H2) {
/*  477 */         _protocols |= 0x2;
/*      */       }
/*  479 */       else if (p == HttpProtocol.H2C) {
/*  480 */         _protocols |= 0x1;
/*      */       } 
/*      */     } 
/*      */     
/*  484 */     this._protocols = _protocols;
/*      */   }
/*      */   
/*      */   boolean checkProtocol(int protocol) {
/*  488 */     return ((this._protocols & protocol) == protocol);
/*      */   }
/*      */   
/*      */   Http2Settings http2Settings() {
/*  492 */     Http2Settings settings = Http2Settings.defaultSettings();
/*      */     
/*  494 */     if (this.http2Settings != null) {
/*  495 */       Long headerTableSize = this.http2Settings.headerTableSize();
/*  496 */       if (headerTableSize != null) {
/*  497 */         settings.headerTableSize(headerTableSize.longValue());
/*      */       }
/*      */       
/*  500 */       Integer initialWindowSize = this.http2Settings.initialWindowSize();
/*  501 */       if (initialWindowSize != null) {
/*  502 */         settings.initialWindowSize(initialWindowSize.intValue());
/*      */       }
/*      */       
/*  505 */       Long maxConcurrentStreams = this.http2Settings.maxConcurrentStreams();
/*  506 */       if (maxConcurrentStreams != null) {
/*  507 */         settings.maxConcurrentStreams(maxConcurrentStreams.longValue());
/*      */       }
/*      */       
/*  510 */       Integer maxFrameSize = this.http2Settings.maxFrameSize();
/*  511 */       if (maxFrameSize != null) {
/*  512 */         settings.maxFrameSize(maxFrameSize.intValue());
/*      */       }
/*      */       
/*  515 */       settings.maxHeaderListSize(this.http2Settings.maxHeaderListSize().longValue());
/*      */       
/*  517 */       Boolean pushEnabled = this.http2Settings.pushEnabled();
/*  518 */       if (pushEnabled != null) {
/*  519 */         settings.pushEnabled(pushEnabled.booleanValue());
/*      */       }
/*      */     } 
/*      */     
/*  523 */     return settings;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void addStreamHandlers(Channel ch, ConnectionObserver obs, ChannelOperations.OnSetup opsFactory, boolean acceptGzip, @Nullable ChannelMetricsRecorder metricsRecorder, long responseTimeoutMillis, @Nullable Function<String, String> uriTagValue) {
/*  535 */     if (HttpClientOperations.log.isDebugEnabled()) {
/*  536 */       HttpClientOperations.log.debug(ReactorNetty.format(ch, "New HTTP/2 stream"));
/*      */     }
/*      */     
/*  539 */     ChannelPipeline pipeline = ch.pipeline();
/*  540 */     pipeline.addLast("reactor.left.h2ToHttp11Codec", (ChannelHandler)HTTP2_STREAM_FRAME_TO_HTTP_OBJECT)
/*  541 */       .addLast("reactor.left.httpTrafficHandler", (ChannelHandler)HTTP_2_STREAM_BRIDGE_CLIENT_HANDLER);
/*      */     
/*  543 */     if (acceptGzip) {
/*  544 */       pipeline.addLast("reactor.left.httpDecompressor", (ChannelHandler)new HttpContentDecompressor());
/*      */     }
/*      */     
/*  547 */     ChannelOperations.addReactiveBridge(ch, opsFactory, obs);
/*      */     
/*  549 */     if (metricsRecorder != null && 
/*  550 */       metricsRecorder instanceof HttpClientMetricsRecorder) {
/*      */       ChannelHandler handler;
/*  552 */       Channel parent = ch.parent();
/*  553 */       ChannelHandler existingHandler = parent.pipeline().get("reactor.left.httpMetricsHandler");
/*  554 */       if (existingHandler != null) {
/*      */         
/*  556 */         parent.pipeline().remove("reactor.left.httpMetricsHandler");
/*      */ 
/*      */         
/*  559 */         handler = (metricsRecorder instanceof ContextAwareHttpClientMetricsRecorder) ? (ChannelHandler)new ContextAwareHttpClientMetricsHandler((ContextAwareHttpClientMetricsHandler)existingHandler) : (ChannelHandler)new HttpClientMetricsHandler((HttpClientMetricsHandler)existingHandler);
/*      */       
/*      */       }
/*      */       else {
/*      */         
/*  564 */         handler = (metricsRecorder instanceof ContextAwareHttpClientMetricsRecorder) ? (ChannelHandler)new ContextAwareHttpClientMetricsHandler((ContextAwareHttpClientMetricsRecorder)metricsRecorder, uriTagValue) : (ChannelHandler)new HttpClientMetricsHandler((HttpClientMetricsRecorder)metricsRecorder, uriTagValue);
/*      */       } 
/*  566 */       pipeline.addBefore("reactor.right.reactiveBridge", "reactor.left.httpMetricsHandler", handler);
/*      */     } 
/*      */ 
/*      */     
/*  570 */     if (responseTimeoutMillis > -1L) {
/*  571 */       Connection.from(ch).addHandlerFirst("reactor.left.responseTimeoutHandler", (ChannelHandler)new ReadTimeoutHandler(responseTimeoutMillis, TimeUnit.MILLISECONDS));
/*      */     }
/*      */ 
/*      */     
/*  575 */     if (log.isDebugEnabled()) {
/*  576 */       log.debug(ReactorNetty.format(ch, "Initialized HTTP/2 stream pipeline {}"), new Object[] { ch.pipeline() });
/*      */     }
/*      */     
/*  579 */     ChannelOperations<?, ?> ops = opsFactory.create(Connection.from(ch), obs, null);
/*  580 */     if (ops != null) {
/*  581 */       ops.bind();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void configureHttp2Pipeline(ChannelPipeline p, boolean acceptGzip, HttpResponseDecoderSpec decoder, Http2Settings http2Settings, ConnectionObserver observer) {
/*  590 */     Http2FrameCodecBuilder http2FrameCodecBuilder = Http2FrameCodecBuilder.forClient().validateHeaders(decoder.validateHeaders()).initialSettings(http2Settings);
/*      */     
/*  592 */     if (p.get("reactor.left.loggingHandler") != null) {
/*  593 */       http2FrameCodecBuilder.frameLogger(new Http2FrameLogger(LogLevel.DEBUG, "reactor.netty.http.client.h2"));
/*      */     }
/*      */ 
/*      */     
/*  597 */     p.addBefore("reactor.right.reactiveBridge", "reactor.left.h2Flush", (ChannelHandler)new FlushConsolidationHandler(1024, true))
/*  598 */       .addBefore("reactor.right.reactiveBridge", "reactor.left.httpCodec", (ChannelHandler)http2FrameCodecBuilder.build())
/*  599 */       .addBefore("reactor.right.reactiveBridge", "reactor.left.h2MultiplexHandler", (ChannelHandler)new Http2MultiplexHandler(H2InboundStreamHandler.INSTANCE))
/*  600 */       .addBefore("reactor.right.reactiveBridge", "reactor.left.httpTrafficHandler", (ChannelHandler)new HttpTrafficHandler(observer));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void configureHttp11OrH2CleartextPipeline(ChannelPipeline p, boolean acceptGzip, HttpResponseDecoderSpec decoder, Http2Settings http2Settings, @Nullable ChannelMetricsRecorder metricsRecorder, ConnectionObserver observer, ChannelOperations.OnSetup opsFactory, @Nullable Function<String, String> uriTagValue) {
/*  621 */     HttpClientCodec httpClientCodec = new HttpClientCodec(decoder.maxInitialLineLength(), decoder.maxHeaderSize(), decoder.maxChunkSize(), decoder.failOnMissingResponse, decoder.validateHeaders(), decoder.initialBufferSize(), decoder.parseHttpAfterConnectRequest, decoder.allowDuplicateContentLengths());
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  626 */     Http2FrameCodecBuilder http2FrameCodecBuilder = Http2FrameCodecBuilder.forClient().validateHeaders(decoder.validateHeaders()).initialSettings(http2Settings);
/*      */     
/*  628 */     if (p.get("reactor.left.loggingHandler") != null) {
/*  629 */       http2FrameCodecBuilder.frameLogger(new Http2FrameLogger(LogLevel.DEBUG, "reactor.netty.http.client.h2"));
/*      */     }
/*      */ 
/*      */     
/*  633 */     Http2FrameCodec http2FrameCodec = http2FrameCodecBuilder.build();
/*      */     
/*  635 */     Http2ClientUpgradeCodec upgradeCodec = new Http2ClientUpgradeCodec(http2FrameCodec, (ChannelHandler)new H2CleartextCodec(http2FrameCodec, opsFactory, acceptGzip, metricsRecorder, uriTagValue));
/*      */ 
/*      */     
/*  638 */     HttpClientUpgradeHandler upgradeHandler = new HttpClientUpgradeHandler((HttpClientUpgradeHandler.SourceCodec)httpClientCodec, (HttpClientUpgradeHandler.UpgradeCodec)upgradeCodec, decoder.h2cMaxContentLength());
/*      */     
/*  640 */     p.addBefore("reactor.right.reactiveBridge", null, (ChannelHandler)httpClientCodec)
/*  641 */       .addBefore("reactor.right.reactiveBridge", "reactor.left.h2cUpgradeHandler", (ChannelHandler)upgradeHandler)
/*  642 */       .addBefore("reactor.right.reactiveBridge", "reactor.left.httpTrafficHandler", (ChannelHandler)new HttpTrafficHandler(observer));
/*      */     
/*  644 */     if (acceptGzip) {
/*  645 */       p.addBefore("reactor.right.reactiveBridge", "reactor.left.httpDecompressor", (ChannelHandler)new HttpContentDecompressor());
/*      */     }
/*      */     
/*  648 */     if (metricsRecorder != null && 
/*  649 */       metricsRecorder instanceof HttpClientMetricsRecorder) {
/*      */ 
/*      */       
/*  652 */       ChannelHandler handler = (metricsRecorder instanceof ContextAwareHttpClientMetricsRecorder) ? (ChannelHandler)new ContextAwareHttpClientMetricsHandler((ContextAwareHttpClientMetricsRecorder)metricsRecorder, uriTagValue) : (ChannelHandler)new HttpClientMetricsHandler((HttpClientMetricsRecorder)metricsRecorder, uriTagValue);
/*  653 */       p.addBefore("reactor.right.reactiveBridge", "reactor.left.httpMetricsHandler", handler);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void configureHttp11Pipeline(ChannelPipeline p, boolean acceptGzip, HttpResponseDecoderSpec decoder, @Nullable ChannelMetricsRecorder metricsRecorder, @Nullable Function<String, String> uriTagValue) {
/*  664 */     p.addBefore("reactor.right.reactiveBridge", "reactor.left.httpCodec", (ChannelHandler)new HttpClientCodec(decoder
/*      */ 
/*      */           
/*  667 */           .maxInitialLineLength(), decoder
/*  668 */           .maxHeaderSize(), decoder
/*  669 */           .maxChunkSize(), decoder.failOnMissingResponse, decoder
/*      */           
/*  671 */           .validateHeaders(), decoder
/*  672 */           .initialBufferSize(), decoder.parseHttpAfterConnectRequest, decoder
/*      */           
/*  674 */           .allowDuplicateContentLengths()));
/*      */     
/*  676 */     if (acceptGzip) {
/*  677 */       p.addAfter("reactor.left.httpCodec", "reactor.left.httpDecompressor", (ChannelHandler)new HttpContentDecompressor());
/*      */     }
/*      */     
/*  680 */     if (metricsRecorder != null && 
/*  681 */       metricsRecorder instanceof HttpClientMetricsRecorder) {
/*      */ 
/*      */       
/*  684 */       ChannelHandler handler = (metricsRecorder instanceof ContextAwareHttpClientMetricsRecorder) ? (ChannelHandler)new ContextAwareHttpClientMetricsHandler((ContextAwareHttpClientMetricsRecorder)metricsRecorder, uriTagValue) : (ChannelHandler)new HttpClientMetricsHandler((HttpClientMetricsRecorder)metricsRecorder, uriTagValue);
/*  685 */       p.addBefore("reactor.right.reactiveBridge", "reactor.left.httpMetricsHandler", handler);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*  690 */   static final Pattern FOLLOW_REDIRECT_CODES = Pattern.compile("30[12378]");
/*      */   static {
/*  692 */     FOLLOW_REDIRECT_PREDICATE = ((req, res) -> FOLLOW_REDIRECT_CODES.matcher((CharSequence)res.status().codeAsText()).matches());
/*      */   }
/*      */ 
/*      */   
/*      */   static final BiPredicate<HttpClientRequest, HttpClientResponse> FOLLOW_REDIRECT_PREDICATE;
/*      */   
/*      */   static final int h2 = 2;
/*      */   
/*      */   static final int h2c = 1;
/*      */   
/*      */   static final int h11 = 4;
/*      */   
/*      */   static final int h11orH2 = 6;
/*      */   
/*      */   static final int h11orH2C = 5;
/*  707 */   static final Http2StreamFrameToHttpObjectCodec HTTP2_STREAM_FRAME_TO_HTTP_OBJECT = new Http2StreamFrameToHttpObjectCodec(false);
/*      */ 
/*      */   
/*  710 */   static final Http2StreamBridgeClientHandler HTTP_2_STREAM_BRIDGE_CLIENT_HANDLER = new Http2StreamBridgeClientHandler();
/*      */ 
/*      */   
/*  713 */   static final Logger log = Loggers.getLogger(HttpClientConfig.class);
/*      */   
/*  715 */   static final LoggingHandler LOGGING_HANDLER = AdvancedByteBufFormat.HEX_DUMP
/*      */     
/*  717 */     .toLoggingHandler(HttpClient.class.getName(), LogLevel.DEBUG, Charset.defaultCharset());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  723 */   static final boolean SSL_DEBUG = Boolean.parseBoolean(System.getProperty("reactor.netty.tcp.ssl.client.debug", "false"));
/*      */ 
/*      */   
/*      */   static final class H2CleartextCodec
/*      */     extends ChannelHandlerAdapter
/*      */   {
/*      */     final boolean acceptGzip;
/*      */     
/*      */     final Http2FrameCodec http2FrameCodec;
/*      */     
/*      */     final ChannelMetricsRecorder metricsRecorder;
/*      */     
/*      */     final ChannelOperations.OnSetup opsFactory;
/*      */     final Function<String, String> uriTagValue;
/*      */     
/*      */     H2CleartextCodec(Http2FrameCodec http2FrameCodec, ChannelOperations.OnSetup opsFactory, boolean acceptGzip, @Nullable ChannelMetricsRecorder metricsRecorder, @Nullable Function<String, String> uriTagValue) {
/*  739 */       this.acceptGzip = acceptGzip;
/*  740 */       this.http2FrameCodec = http2FrameCodec;
/*  741 */       this.metricsRecorder = metricsRecorder;
/*  742 */       this.opsFactory = opsFactory;
/*  743 */       this.uriTagValue = uriTagValue;
/*      */     }
/*      */     
/*      */     public void handlerAdded(ChannelHandlerContext ctx) {
/*      */       Http2MultiplexHandler http2MultiplexHandler;
/*  748 */       ChannelPipeline pipeline = ctx.pipeline();
/*      */       
/*  750 */       ReadTimeoutHandler responseTimeoutHandler = (ReadTimeoutHandler)pipeline.get("reactor.left.responseTimeoutHandler");
/*      */       
/*  752 */       ConnectionObserver channelOwner = (ConnectionObserver)ctx.channel().attr(Http2ConnectionProvider.OWNER).get();
/*  753 */       Http2ConnectionProvider.DisposableAcquire owner = null;
/*  754 */       ConnectionObserver obs = null;
/*  755 */       if (channelOwner instanceof Http2ConnectionProvider.DisposableAcquire) {
/*  756 */         owner = (Http2ConnectionProvider.DisposableAcquire)channelOwner;
/*  757 */         obs = owner.obs;
/*      */       } 
/*  759 */       if (responseTimeoutHandler != null) {
/*  760 */         pipeline.remove("reactor.left.responseTimeoutHandler");
/*      */ 
/*      */         
/*  763 */         http2MultiplexHandler = new Http2MultiplexHandler(HttpClientConfig.H2InboundStreamHandler.INSTANCE, (ChannelHandler)new HttpClientConfig.H2Codec(owner, obs, this.opsFactory, this.acceptGzip, this.metricsRecorder, responseTimeoutHandler.getReaderIdleTimeInMillis(), this.uriTagValue));
/*      */       } else {
/*      */         
/*  766 */         http2MultiplexHandler = new Http2MultiplexHandler(HttpClientConfig.H2InboundStreamHandler.INSTANCE, (ChannelHandler)new HttpClientConfig.H2Codec(owner, obs, this.opsFactory, this.acceptGzip, this.metricsRecorder, this.uriTagValue));
/*      */       } 
/*      */       
/*  769 */       pipeline.addAfter(ctx.name(), "reactor.left.httpCodec", (ChannelHandler)this.http2FrameCodec)
/*  770 */         .addAfter("reactor.left.httpCodec", "reactor.left.h2MultiplexHandler", (ChannelHandler)http2MultiplexHandler);
/*  771 */       if (pipeline.get("reactor.left.httpDecompressor") != null) {
/*  772 */         pipeline.remove("reactor.left.httpDecompressor");
/*      */       }
/*  774 */       pipeline.remove("reactor.right.reactiveBridge");
/*  775 */       pipeline.remove((ChannelHandler)this);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   static final class H2Codec
/*      */     extends ChannelInitializer<Channel>
/*      */   {
/*      */     final boolean acceptGzip;
/*      */     
/*      */     final ChannelMetricsRecorder metricsRecorder;
/*      */     
/*      */     final ConnectionObserver observer;
/*      */     
/*      */     final ChannelOperations.OnSetup opsFactory;
/*      */     
/*      */     final Http2ConnectionProvider.DisposableAcquire owner;
/*      */     
/*      */     final long responseTimeoutMillis;
/*      */     final Function<String, String> uriTagValue;
/*      */     
/*      */     H2Codec(@Nullable Http2ConnectionProvider.DisposableAcquire owner, @Nullable ConnectionObserver observer, ChannelOperations.OnSetup opsFactory, boolean acceptGzip, @Nullable ChannelMetricsRecorder metricsRecorder, @Nullable Function<String, String> uriTagValue) {
/*  797 */       this(owner, observer, opsFactory, acceptGzip, metricsRecorder, -1L, uriTagValue);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     H2Codec(@Nullable Http2ConnectionProvider.DisposableAcquire owner, @Nullable ConnectionObserver observer, ChannelOperations.OnSetup opsFactory, boolean acceptGzip, @Nullable ChannelMetricsRecorder metricsRecorder, long responseTimeoutMillis, @Nullable Function<String, String> uriTagValue) {
/*  809 */       this.acceptGzip = acceptGzip;
/*  810 */       this.metricsRecorder = metricsRecorder;
/*  811 */       this.observer = observer;
/*  812 */       this.opsFactory = opsFactory;
/*  813 */       this.owner = owner;
/*  814 */       this.responseTimeoutMillis = responseTimeoutMillis;
/*  815 */       this.uriTagValue = uriTagValue;
/*      */     }
/*      */ 
/*      */     
/*      */     protected void initChannel(Channel ch) {
/*  820 */       if (this.observer != null && this.opsFactory != null && this.owner != null) {
/*  821 */         Http2ConnectionProvider.registerClose(ch, this.owner);
/*  822 */         if (!this.owner.currentContext().isEmpty()) {
/*  823 */           ReactorNetty.setChannelContext(ch, (ContextView)this.owner.currentContext());
/*      */         }
/*  825 */         HttpClientConfig.addStreamHandlers(ch, this.observer.then(new HttpClientConfig.StreamConnectionObserver(this.owner.currentContext())), this.opsFactory, this.acceptGzip, this.metricsRecorder, this.responseTimeoutMillis, this.uriTagValue);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final class H2InboundStreamHandler
/*      */     extends ChannelHandlerAdapter
/*      */   {
/*  840 */     static final ChannelHandler INSTANCE = (ChannelHandler)new H2InboundStreamHandler();
/*      */ 
/*      */     
/*      */     public boolean isSharable() {
/*  844 */       return true;
/*      */     }
/*      */   }
/*      */   
/*      */   static final class H2OrHttp11Codec extends ChannelInboundHandlerAdapter {
/*      */     final boolean acceptGzip;
/*      */     final HttpResponseDecoderSpec decoder;
/*      */     final Http2Settings http2Settings;
/*      */     final ChannelMetricsRecorder metricsRecorder;
/*      */     final ConnectionObserver observer;
/*      */     final Function<String, String> uriTagValue;
/*      */     
/*      */     H2OrHttp11Codec(HttpClientConfig.HttpClientChannelInitializer initializer, ConnectionObserver observer) {
/*  857 */       this.acceptGzip = initializer.acceptGzip;
/*  858 */       this.decoder = initializer.decoder;
/*  859 */       this.http2Settings = initializer.http2Settings;
/*  860 */       this.metricsRecorder = initializer.metricsRecorder;
/*  861 */       this.observer = observer;
/*  862 */       this.uriTagValue = initializer.uriTagValue;
/*      */     }
/*      */ 
/*      */     
/*      */     public void channelActive(ChannelHandlerContext ctx) {
/*  867 */       ChannelHandler handler = ctx.pipeline().get("reactor.left.sslHandler");
/*  868 */       if (handler instanceof SslHandler) {
/*  869 */         SslHandler sslHandler = (SslHandler)handler;
/*      */         
/*  871 */         String protocol = (sslHandler.applicationProtocol() != null) ? sslHandler.applicationProtocol() : "http/1.1";
/*  872 */         if (HttpClientConfig.log.isDebugEnabled()) {
/*  873 */           HttpClientConfig.log.debug(ReactorNetty.format(ctx.channel(), "Negotiated application-level protocol [" + protocol + "]"));
/*      */         }
/*  875 */         if ("h2".equals(protocol)) {
/*  876 */           HttpClientConfig.configureHttp2Pipeline(ctx.channel().pipeline(), this.acceptGzip, this.decoder, this.http2Settings, this.observer);
/*      */         }
/*  878 */         else if ("http/1.1".equals(protocol)) {
/*  879 */           HttpClientConfig.configureHttp11Pipeline(ctx.channel().pipeline(), this.acceptGzip, this.decoder, this.metricsRecorder, this.uriTagValue);
/*      */         } else {
/*      */           
/*  882 */           throw new IllegalStateException("unknown protocol: " + protocol);
/*      */         } 
/*      */         
/*  885 */         ctx.fireChannelActive();
/*      */         
/*  887 */         ctx.channel().pipeline().remove((ChannelHandler)this);
/*      */       } else {
/*      */         
/*  890 */         throw new IllegalStateException("Cannot determine negotiated application-level protocol.");
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   static final class HttpClientChannelInitializer
/*      */     implements ChannelPipelineConfigurer {
/*      */     final boolean acceptGzip;
/*      */     final HttpResponseDecoderSpec decoder;
/*      */     final Http2Settings http2Settings;
/*      */     final ChannelMetricsRecorder metricsRecorder;
/*      */     final ChannelOperations.OnSetup opsFactory;
/*      */     final int protocols;
/*      */     final SslProvider sslProvider;
/*      */     final Function<String, String> uriTagValue;
/*      */     
/*      */     HttpClientChannelInitializer(HttpClientConfig config) {
/*  907 */       this.acceptGzip = config.acceptGzip;
/*  908 */       this.decoder = config.decoder;
/*  909 */       this.http2Settings = config.http2Settings();
/*  910 */       this.metricsRecorder = config.metricsRecorderInternal();
/*  911 */       this.opsFactory = config.channelOperationsProvider();
/*  912 */       this.protocols = config._protocols;
/*  913 */       this.sslProvider = config.sslProvider;
/*  914 */       this.uriTagValue = config.uriTagValue;
/*      */     }
/*      */ 
/*      */     
/*      */     public void onChannelInit(ConnectionObserver observer, Channel channel, @Nullable SocketAddress remoteAddress) {
/*  919 */       if (this.sslProvider != null) {
/*  920 */         this.sslProvider.addSslHandler(channel, remoteAddress, HttpClientConfig.SSL_DEBUG);
/*      */         
/*  922 */         if ((this.protocols & 0x6) == 6) {
/*  923 */           channel.pipeline()
/*  924 */             .addBefore("reactor.right.reactiveBridge", "reactor.left.h2OrHttp11Codec", (ChannelHandler)new HttpClientConfig.H2OrHttp11Codec(this, observer));
/*      */         
/*      */         }
/*  927 */         else if ((this.protocols & 0x4) == 4) {
/*  928 */           HttpClientConfig.configureHttp11Pipeline(channel.pipeline(), this.acceptGzip, this.decoder, this.metricsRecorder, this.uriTagValue);
/*      */         }
/*  930 */         else if ((this.protocols & 0x2) == 2) {
/*  931 */           HttpClientConfig.configureHttp2Pipeline(channel.pipeline(), this.acceptGzip, this.decoder, this.http2Settings, observer);
/*      */         }
/*      */       
/*      */       }
/*  935 */       else if ((this.protocols & 0x5) == 5) {
/*  936 */         HttpClientConfig.configureHttp11OrH2CleartextPipeline(channel.pipeline(), this.acceptGzip, this.decoder, this.http2Settings, this.metricsRecorder, observer, this.opsFactory, this.uriTagValue);
/*      */       }
/*  938 */       else if ((this.protocols & 0x4) == 4) {
/*  939 */         HttpClientConfig.configureHttp11Pipeline(channel.pipeline(), this.acceptGzip, this.decoder, this.metricsRecorder, this.uriTagValue);
/*      */       }
/*  941 */       else if ((this.protocols & 0x1) == 1) {
/*  942 */         HttpClientConfig.configureHttp2Pipeline(channel.pipeline(), this.acceptGzip, this.decoder, this.http2Settings, observer);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   static final class HttpClientDoOn
/*      */     implements ConnectionObserver
/*      */   {
/*      */     final BiConsumer<? super HttpClientRequest, ? super Connection> doAfterRequest;
/*      */     
/*      */     final BiConsumer<? super HttpClientResponse, ? super Connection> doAfterResponseSuccess;
/*      */     
/*      */     final BiConsumer<? super HttpClientResponse, ? super Connection> doOnRedirect;
/*      */     
/*      */     final BiConsumer<? super HttpClientRequest, ? super Connection> doOnRequest;
/*      */     
/*      */     final BiConsumer<? super HttpClientRequest, ? super Throwable> doOnRequestError;
/*      */     
/*      */     final BiConsumer<? super HttpClientResponse, ? super Connection> doOnResponse;
/*      */     final BiConsumer<? super HttpClientResponse, ? super Throwable> doOnResponseError;
/*      */     
/*      */     HttpClientDoOn(@Nullable BiConsumer<? super HttpClientRequest, ? super Connection> doAfterRequest, @Nullable BiConsumer<? super HttpClientResponse, ? super Connection> doAfterResponseSuccess, @Nullable BiConsumer<? super HttpClientResponse, ? super Connection> doOnRedirect, @Nullable BiConsumer<? super HttpClientRequest, ? super Connection> doOnRequest, @Nullable BiConsumer<? super HttpClientRequest, ? super Throwable> doOnRequestError, @Nullable BiConsumer<? super HttpClientResponse, ? super Connection> doOnResponse, @Nullable BiConsumer<? super HttpClientResponse, ? super Throwable> doOnResponseError) {
/*  965 */       this.doAfterRequest = doAfterRequest;
/*  966 */       this.doAfterResponseSuccess = doAfterResponseSuccess;
/*  967 */       this.doOnRedirect = doOnRedirect;
/*  968 */       this.doOnRequest = doOnRequest;
/*  969 */       this.doOnRequestError = doOnRequestError;
/*  970 */       this.doOnResponse = doOnResponse;
/*  971 */       this.doOnResponseError = doOnResponseError;
/*      */     }
/*      */ 
/*      */     
/*      */     public void onStateChange(Connection connection, ConnectionObserver.State newState) {
/*  976 */       if (this.doOnRequest != null && newState == HttpClientState.REQUEST_PREPARED) {
/*  977 */         this.doOnRequest.accept(connection.as(HttpClientOperations.class), connection);
/*      */         return;
/*      */       } 
/*  980 */       if (this.doAfterResponseSuccess != null && newState == HttpClientState.RESPONSE_COMPLETED) {
/*  981 */         this.doAfterResponseSuccess.accept(connection.as(HttpClientOperations.class), connection);
/*      */         return;
/*      */       } 
/*  984 */       if (this.doAfterRequest != null && newState == HttpClientState.REQUEST_SENT) {
/*  985 */         this.doAfterRequest.accept(connection.as(HttpClientOperations.class), connection);
/*      */         return;
/*      */       } 
/*  988 */       if (this.doOnResponse != null && newState == HttpClientState.RESPONSE_RECEIVED) {
/*  989 */         this.doOnResponse.accept(connection.as(HttpClientOperations.class), connection);
/*      */         return;
/*      */       } 
/*  992 */       if (this.doOnResponseError != null && newState == HttpClientState.RESPONSE_INCOMPLETE) {
/*  993 */         HttpClientOperations ops = (HttpClientOperations)connection.as(HttpClientOperations.class);
/*  994 */         if (ops == null) {
/*      */           return;
/*      */         }
/*  997 */         if (ops.responseState != null) {
/*  998 */           this.doOnResponseError.accept(ops, new PrematureCloseException("Connection prematurely closed DURING response"));
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void onUncaughtException(Connection connection, Throwable error) {
/* 1005 */       if (this.doOnRedirect != null && error instanceof RedirectClientException) {
/* 1006 */         this.doOnRedirect.accept(connection.as(HttpClientOperations.class), connection);
/*      */         return;
/*      */       } 
/* 1009 */       HttpClientOperations ops = (HttpClientOperations)connection.as(HttpClientOperations.class);
/* 1010 */       if (ops == null) {
/*      */         return;
/*      */       }
/* 1013 */       if (this.doOnRequestError != null && ops.retrying && ops.responseState == null) {
/* 1014 */         this.doOnRequestError.accept(connection.as(HttpClientOperations.class), error);
/*      */         return;
/*      */       } 
/* 1017 */       if (this.doOnResponseError != null && ops.responseState != null && !(error instanceof RedirectClientException))
/*      */       {
/* 1019 */         this.doOnResponseError.accept(connection.as(HttpClientOperations.class), error);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   static final class StreamConnectionObserver
/*      */     implements ConnectionObserver {
/*      */     final Context context;
/*      */     
/*      */     StreamConnectionObserver(Context context) {
/* 1029 */       this.context = context;
/*      */     }
/*      */ 
/*      */     
/*      */     public Context currentContext() {
/* 1034 */       return this.context;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void onStateChange(Connection connection, ConnectionObserver.State state) {
/* 1040 */       if (state == ConnectionObserver.State.DISCONNECTING && 
/* 1041 */         !connection.isPersistent() && connection.channel().isActive())
/*      */       {
/*      */         
/* 1044 */         connection.channel().close();
/*      */       }
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\client\HttpClientConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */