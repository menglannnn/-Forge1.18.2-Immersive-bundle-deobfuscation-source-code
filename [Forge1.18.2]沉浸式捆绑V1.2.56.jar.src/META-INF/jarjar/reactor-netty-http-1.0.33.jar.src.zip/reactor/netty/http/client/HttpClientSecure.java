/*    */ package reactor.netty.http.client;
/*    */ 
/*    */ import reactor.netty.http.Http2SslContextSpec;
/*    */ import reactor.netty.tcp.SslProvider;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class HttpClientSecure
/*    */ {
/*    */   static final SslProvider HTTP2_SSL_PROVIDER;
/*    */   
/*    */   static SslProvider defaultSslProvider(HttpClientConfig config) {
/* 35 */     if (config.checkProtocol(2)) {
/* 36 */       return DEFAULT_HTTP2_SSL_PROVIDER;
/*    */     }
/*    */     
/* 39 */     return DEFAULT_HTTP_SSL_PROVIDER;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static boolean hasDefaultSslProvider(HttpClientConfig config) {
/* 46 */     return (DEFAULT_HTTP_SSL_PROVIDER == config.sslProvider || DEFAULT_HTTP2_SSL_PROVIDER == config.sslProvider);
/*    */   }
/*    */   
/*    */   static SslProvider sslProvider(SslProvider sslProvider) {
/* 50 */     return SslProvider.addHandlerConfigurator(sslProvider, HttpClientSecurityUtils.HOSTNAME_VERIFICATION_CONFIGURER);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static {
/*    */     SslProvider sslProvider;
/*    */     try {
/* 59 */       sslProvider = SslProvider.builder().sslContext((SslProvider.ProtocolSslContextSpec)Http2SslContextSpec.forClient()).build();
/*    */     }
/* 61 */     catch (Exception e) {
/* 62 */       sslProvider = null;
/*    */     } 
/* 64 */     HTTP2_SSL_PROVIDER = sslProvider;
/*    */   }
/*    */ 
/*    */   
/* 68 */   static final SslProvider DEFAULT_HTTP_SSL_PROVIDER = SslProvider.addHandlerConfigurator(SslProvider.defaultClientProvider(), HttpClientSecurityUtils.HOSTNAME_VERIFICATION_CONFIGURER);
/*    */ 
/*    */   
/* 71 */   static final SslProvider DEFAULT_HTTP2_SSL_PROVIDER = SslProvider.addHandlerConfigurator(HTTP2_SSL_PROVIDER, HttpClientSecurityUtils.HOSTNAME_VERIFICATION_CONFIGURER);
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\client\HttpClientSecure.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */