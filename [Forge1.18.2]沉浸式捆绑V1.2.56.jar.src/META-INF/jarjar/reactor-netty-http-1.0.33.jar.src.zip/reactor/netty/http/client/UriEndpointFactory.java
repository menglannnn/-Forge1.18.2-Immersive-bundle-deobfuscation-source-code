/*     */ package reactor.netty.http.client;
/*     */ 
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.SocketAddress;
/*     */ import java.net.URI;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class UriEndpointFactory
/*     */ {
/*     */   final Supplier<? extends SocketAddress> connectAddress;
/*     */   final boolean defaultSecure;
/*     */   final BiFunction<String, Integer, InetSocketAddress> inetSocketAddressFunction;
/*  33 */   static final Pattern URL_PATTERN = Pattern.compile("(?:(\\w+)://)?((?:\\[.+?])|(?<!\\[)(?:[^/?]+?))(?::(\\d{2,5}))?([/?].*)?");
/*     */ 
/*     */ 
/*     */   
/*     */   UriEndpointFactory(Supplier<? extends SocketAddress> connectAddress, boolean defaultSecure, BiFunction<String, Integer, InetSocketAddress> inetSocketAddressFunction) {
/*  38 */     this.connectAddress = connectAddress;
/*  39 */     this.defaultSecure = defaultSecure;
/*  40 */     this.inetSocketAddressFunction = inetSocketAddressFunction;
/*     */   }
/*     */   
/*     */   UriEndpoint createUriEndpoint(String url, boolean isWs) {
/*  44 */     return createUriEndpoint(url, isWs, this.connectAddress);
/*     */   }
/*     */   
/*     */   UriEndpoint createUriEndpoint(String url, boolean isWs, Supplier<? extends SocketAddress> connectAddress) {
/*  48 */     if (url.startsWith("/")) {
/*  49 */       return new UriEndpoint(resolveScheme(isWs), "localhost", 80, connectAddress, url);
/*     */     }
/*     */     
/*  52 */     Matcher matcher = URL_PATTERN.matcher(url);
/*  53 */     if (matcher.matches()) {
/*     */ 
/*     */       
/*  56 */       String scheme = (matcher.group(1) != null) ? matcher.group(1).toLowerCase() : resolveScheme(isWs);
/*  57 */       String host = cleanHostString(matcher.group(2));
/*     */       
/*  59 */       String portString = matcher.group(3);
/*     */       
/*  61 */       int port = (portString != null) ? Integer.parseInt(portString) : (UriEndpoint.isSecureScheme(scheme) ? 443 : 80);
/*  62 */       String pathAndQuery = cleanPathAndQuery(matcher.group(4));
/*  63 */       return new UriEndpoint(scheme, host, port, () -> (InetSocketAddress)this.inetSocketAddressFunction.apply(host, Integer.valueOf(port)), pathAndQuery);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  68 */     throw new IllegalArgumentException("Unable to parse url [" + url + "]");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   UriEndpoint createUriEndpoint(URI url, boolean isWs) {
/*  74 */     if (!url.isAbsolute()) {
/*  75 */       throw new IllegalArgumentException("URI is not absolute: " + url);
/*     */     }
/*  77 */     if (url.getHost() == null) {
/*  78 */       throw new IllegalArgumentException("Host is not specified");
/*     */     }
/*  80 */     String scheme = (url.getScheme() != null) ? url.getScheme().toLowerCase() : resolveScheme(isWs);
/*  81 */     String host = cleanHostString(url.getHost());
/*  82 */     int port = (url.getPort() != -1) ? url.getPort() : (UriEndpoint.isSecureScheme(scheme) ? 443 : 80);
/*  83 */     String path = (url.getRawPath() != null) ? url.getRawPath() : "";
/*  84 */     String query = (url.getRawQuery() != null) ? ('?' + url.getRawQuery()) : "";
/*  85 */     return new UriEndpoint(scheme, host, port, () -> (InetSocketAddress)this.inetSocketAddressFunction.apply(host, Integer.valueOf(port)), 
/*     */         
/*  87 */         cleanPathAndQuery(path + query));
/*     */   }
/*     */   
/*     */   UriEndpoint createUriEndpoint(UriEndpoint from, String to, Supplier<? extends SocketAddress> connectAddress) {
/*  91 */     if (to.startsWith("/")) {
/*  92 */       return new UriEndpoint(from.scheme, from.host, from.port, connectAddress, to);
/*     */     }
/*     */     
/*  95 */     throw new IllegalArgumentException("Must provide a relative address in parameter `to`");
/*     */   }
/*     */ 
/*     */   
/*     */   String cleanPathAndQuery(@Nullable String pathAndQuery) {
/* 100 */     if (pathAndQuery == null) {
/* 101 */       pathAndQuery = "/";
/*     */     }
/*     */     else {
/*     */       
/* 105 */       int pos = pathAndQuery.indexOf('#');
/* 106 */       if (pos > -1) {
/* 107 */         pathAndQuery = pathAndQuery.substring(0, pos);
/*     */       }
/*     */     } 
/* 110 */     if (pathAndQuery.length() == 0) {
/* 111 */       pathAndQuery = "/";
/*     */     }
/* 113 */     else if (pathAndQuery.charAt(0) == '?') {
/* 114 */       pathAndQuery = "/" + pathAndQuery;
/*     */     } 
/* 116 */     return pathAndQuery;
/*     */   }
/*     */ 
/*     */   
/*     */   String cleanHostString(String host) {
/* 121 */     if (host.charAt(0) == '[' && host.charAt(host.length() - 1) == ']') {
/* 122 */       host = host.substring(1, host.length() - 1);
/*     */     }
/* 124 */     return host;
/*     */   }
/*     */   
/*     */   String resolveScheme(boolean isWs) {
/* 128 */     if (isWs) {
/* 129 */       return this.defaultSecure ? "wss" : "ws";
/*     */     }
/*     */     
/* 132 */     return this.defaultSecure ? "https" : "http";
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\client\UriEndpointFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */