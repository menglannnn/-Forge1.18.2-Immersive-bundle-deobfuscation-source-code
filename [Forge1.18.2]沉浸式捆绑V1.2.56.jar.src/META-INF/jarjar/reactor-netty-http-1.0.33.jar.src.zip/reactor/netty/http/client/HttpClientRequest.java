package reactor.netty.http.client;

import io.netty.handler.codec.http.HttpHeaders;
import io.netty.handler.codec.http.cookie.Cookie;
import java.time.Duration;

public interface HttpClientRequest extends HttpClientInfos {
  HttpClientRequest addCookie(Cookie paramCookie);
  
  HttpClientRequest addHeader(CharSequence paramCharSequence1, CharSequence paramCharSequence2);
  
  HttpClientRequest header(CharSequence paramCharSequence1, CharSequence paramCharSequence2);
  
  HttpClientRequest headers(HttpHeaders paramHttpHeaders);
  
  boolean isFollowRedirect();
  
  HttpClientRequest responseTimeout(Duration paramDuration);
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\client\HttpClientRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */