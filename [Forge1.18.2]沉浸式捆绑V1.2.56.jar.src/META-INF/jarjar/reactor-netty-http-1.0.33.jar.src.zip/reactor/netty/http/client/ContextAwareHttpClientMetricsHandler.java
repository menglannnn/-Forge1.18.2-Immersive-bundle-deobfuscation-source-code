/*    */ package reactor.netty.http.client;
/*    */ 
/*    */ import io.netty.channel.ChannelHandlerContext;
/*    */ import java.net.SocketAddress;
/*    */ import java.time.Duration;
/*    */ import java.util.function.Function;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class ContextAwareHttpClientMetricsHandler
/*    */   extends AbstractHttpClientMetricsHandler
/*    */ {
/*    */   final ContextAwareHttpClientMetricsRecorder recorder;
/*    */   
/*    */   ContextAwareHttpClientMetricsHandler(ContextAwareHttpClientMetricsRecorder recorder, @Nullable Function<String, String> uriTagValue) {
/* 35 */     super(uriTagValue);
/* 36 */     this.recorder = recorder;
/*    */   }
/*    */   
/*    */   ContextAwareHttpClientMetricsHandler(ContextAwareHttpClientMetricsHandler copy) {
/* 40 */     super(copy);
/* 41 */     this.recorder = copy.recorder;
/*    */   }
/*    */ 
/*    */   
/*    */   protected ContextAwareHttpClientMetricsRecorder recorder() {
/* 46 */     return this.recorder;
/*    */   }
/*    */ 
/*    */   
/*    */   protected void recordException(ChannelHandlerContext ctx) {
/* 51 */     if (this.contextView != null) {
/* 52 */       recorder().incrementErrorsCount(this.contextView, ctx.channel().remoteAddress(), this.path);
/*    */     } else {
/*    */       
/* 55 */       super.recordException(ctx);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   protected void recordWrite(SocketAddress address) {
/* 61 */     if (this.contextView != null) {
/* 62 */       this.recorder.recordDataSentTime(this.contextView, address, this.path, this.method, 
/*    */           
/* 64 */           Duration.ofNanos(System.nanoTime() - this.dataSentTime));
/*    */       
/* 66 */       this.recorder.recordDataSent(this.contextView, address, this.path, this.dataSent);
/*    */     } else {
/*    */       
/* 69 */       super.recordWrite(address);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   protected void recordRead(SocketAddress address) {
/* 75 */     if (this.contextView != null) {
/* 76 */       this.recorder.recordDataReceivedTime(this.contextView, address, this.path, this.method, this.status, 
/*    */           
/* 78 */           Duration.ofNanos(System.nanoTime() - this.dataReceivedTime));
/*    */       
/* 80 */       this.recorder.recordResponseTime(this.contextView, address, this.path, this.method, this.status, 
/*    */           
/* 82 */           Duration.ofNanos(System.nanoTime() - this.dataSentTime));
/*    */       
/* 84 */       this.recorder.recordDataReceived(this.contextView, address, this.path, this.dataReceived);
/*    */     } else {
/*    */       
/* 87 */       super.recordRead(address);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\client\ContextAwareHttpClientMetricsHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */