/*     */ package reactor.netty.http.client;
/*     */ 
/*     */ import reactor.netty.http.HttpDecoderSpec;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class HttpResponseDecoderSpec
/*     */   extends HttpDecoderSpec<HttpResponseDecoderSpec>
/*     */ {
/*     */   public static final boolean DEFAULT_FAIL_ON_MISSING_RESPONSE = false;
/*     */   public static final boolean DEFAULT_PARSE_HTTP_AFTER_CONNECT_REQUEST = false;
/*     */   public static final int DEFAULT_H2C_MAX_CONTENT_LENGTH = 65536;
/*     */   boolean failOnMissingResponse = false;
/*     */   boolean parseHttpAfterConnectRequest = false;
/*     */   
/*     */   HttpResponseDecoderSpec() {
/*  56 */     this.h2cMaxContentLength = 65536;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpResponseDecoderSpec get() {
/*  61 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpResponseDecoderSpec failOnMissingResponse(boolean failOnMissingResponse) {
/*  73 */     this.failOnMissingResponse = failOnMissingResponse;
/*  74 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpResponseDecoderSpec parseHttpAfterConnectRequest(boolean parseHttpAfterConnectRequest) {
/*  84 */     this.parseHttpAfterConnectRequest = parseHttpAfterConnectRequest;
/*  85 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/*  90 */     if (this == o) {
/*  91 */       return true;
/*     */     }
/*  93 */     if (o == null || getClass() != o.getClass()) {
/*  94 */       return false;
/*     */     }
/*  96 */     if (!super.equals(o)) {
/*  97 */       return false;
/*     */     }
/*  99 */     HttpResponseDecoderSpec that = (HttpResponseDecoderSpec)o;
/* 100 */     return (this.failOnMissingResponse == that.failOnMissingResponse && this.parseHttpAfterConnectRequest == that.parseHttpAfterConnectRequest);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 106 */     int result = super.hashCode();
/* 107 */     result = 31 * result + Boolean.hashCode(this.failOnMissingResponse);
/* 108 */     result = 31 * result + Boolean.hashCode(this.parseHttpAfterConnectRequest);
/* 109 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   HttpResponseDecoderSpec build() {
/* 116 */     HttpResponseDecoderSpec decoder = new HttpResponseDecoderSpec();
/* 117 */     decoder.initialBufferSize = this.initialBufferSize;
/* 118 */     decoder.maxChunkSize = this.maxChunkSize;
/* 119 */     decoder.maxHeaderSize = this.maxHeaderSize;
/* 120 */     decoder.maxInitialLineLength = this.maxInitialLineLength;
/* 121 */     decoder.validateHeaders = this.validateHeaders;
/* 122 */     decoder.allowDuplicateContentLengths = this.allowDuplicateContentLengths;
/* 123 */     decoder.failOnMissingResponse = this.failOnMissingResponse;
/* 124 */     decoder.parseHttpAfterConnectRequest = this.parseHttpAfterConnectRequest;
/* 125 */     decoder.h2cMaxContentLength = this.h2cMaxContentLength;
/* 126 */     return decoder;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\client\HttpResponseDecoderSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */