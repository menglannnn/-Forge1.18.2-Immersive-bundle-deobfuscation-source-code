/*    */ package reactor.netty.http.client;
/*    */ 
/*    */ import reactor.netty.ConnectionObserver;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum HttpClientState
/*    */   implements ConnectionObserver.State
/*    */ {
/* 29 */   REQUEST_PREPARED
/*    */   {
/*    */     public String toString() {
/* 32 */       return "[request_prepared]";
/*    */     }
/*    */   },
/*    */ 
/*    */ 
/*    */   
/* 38 */   REQUEST_SENT
/*    */   {
/*    */     public String toString() {
/* 41 */       return "[request_sent]";
/*    */     }
/*    */   },
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 48 */   RESPONSE_INCOMPLETE
/*    */   {
/*    */     public String toString() {
/* 51 */       return "[response_incomplete]";
/*    */     }
/*    */   },
/*    */ 
/*    */ 
/*    */   
/* 57 */   RESPONSE_RECEIVED
/*    */   {
/*    */     public String toString() {
/* 60 */       return "[response_received]";
/*    */     }
/*    */   },
/*    */ 
/*    */ 
/*    */   
/* 66 */   RESPONSE_COMPLETED
/*    */   {
/*    */     public String toString() {
/* 69 */       return "[response_completed]";
/*    */     }
/*    */   },
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 76 */   STREAM_CONFIGURED
/*    */   {
/*    */     public String toString() {
/* 79 */       return "[stream_configured]";
/*    */     }
/*    */   },
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 87 */   UPGRADE_REJECTED
/*    */   {
/*    */     public String toString() {
/* 90 */       return "[upgrade_rejected]";
/*    */     }
/*    */   },
/*    */ 
/*    */ 
/*    */   
/* 96 */   UPGRADE_SUCCESSFUL
/*    */   {
/*    */     public String toString() {
/* 99 */       return "[upgrade_successful]";
/*    */     }
/*    */   };
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\client\HttpClientState.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */