/*     */ package reactor.netty.http.client;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.buffer.ByteBufAllocator;
/*     */ import io.netty.buffer.ByteBufHolder;
/*     */ import io.netty.buffer.CompositeByteBuf;
/*     */ import io.netty.buffer.Unpooled;
/*     */ import io.netty.channel.ChannelFuture;
/*     */ import io.netty.channel.ChannelHandler;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.handler.codec.http.DefaultFullHttpRequest;
/*     */ import io.netty.handler.codec.http.DefaultHttpRequest;
/*     */ import io.netty.handler.codec.http.FullHttpResponse;
/*     */ import io.netty.handler.codec.http.HttpConstants;
/*     */ import io.netty.handler.codec.http.HttpHeaderNames;
/*     */ import io.netty.handler.codec.http.HttpHeaders;
/*     */ import io.netty.handler.codec.http.HttpMessage;
/*     */ import io.netty.handler.codec.http.HttpMethod;
/*     */ import io.netty.handler.codec.http.HttpObjectAggregator;
/*     */ import io.netty.handler.codec.http.HttpRequest;
/*     */ import io.netty.handler.codec.http.HttpResponse;
/*     */ import io.netty.handler.codec.http.HttpResponseStatus;
/*     */ import io.netty.handler.codec.http.HttpUtil;
/*     */ import io.netty.handler.codec.http.HttpVersion;
/*     */ import io.netty.handler.codec.http.LastHttpContent;
/*     */ import io.netty.handler.codec.http.cookie.ClientCookieDecoder;
/*     */ import io.netty.handler.codec.http.cookie.ClientCookieEncoder;
/*     */ import io.netty.handler.codec.http.cookie.Cookie;
/*     */ import io.netty.handler.codec.http.multipart.DefaultHttpDataFactory;
/*     */ import io.netty.handler.codec.http.multipart.HttpDataFactory;
/*     */ import io.netty.handler.codec.http.multipart.HttpPostRequestEncoder;
/*     */ import io.netty.handler.codec.http.websocketx.extensions.compression.WebSocketClientCompressionHandler;
/*     */ import io.netty.handler.stream.ChunkedWriteHandler;
/*     */ import io.netty.handler.timeout.ReadTimeoutHandler;
/*     */ import io.netty.util.ReferenceCountUtil;
/*     */ import io.netty.util.ReferenceCounted;
/*     */ import io.netty.util.concurrent.Future;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.SocketAddress;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.time.Duration;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.function.BiConsumer;
/*     */ import java.util.function.BiPredicate;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Supplier;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.core.publisher.Operators;
/*     */ import reactor.core.publisher.Sinks;
/*     */ import reactor.netty.Connection;
/*     */ import reactor.netty.ConnectionObserver;
/*     */ import reactor.netty.DisposableChannel;
/*     */ import reactor.netty.FutureMono;
/*     */ import reactor.netty.NettyInbound;
/*     */ import reactor.netty.NettyOutbound;
/*     */ import reactor.netty.ReactorNetty;
/*     */ import reactor.netty.channel.AbortedException;
/*     */ import reactor.netty.channel.ChannelOperations;
/*     */ import reactor.netty.http.Cookies;
/*     */ import reactor.netty.http.HttpOperations;
/*     */ import reactor.netty.http.logging.HttpMessageArgProviderFactory;
/*     */ import reactor.netty.http.logging.HttpMessageLogFactory;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.Loggers;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.ContextView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class HttpClientOperations
/*     */   extends HttpOperations<NettyInbound, NettyOutbound>
/*     */   implements HttpClientResponse, HttpClientRequest
/*     */ {
/*     */   final boolean isSecure;
/*     */   final HttpRequest nettyRequest;
/*     */   final HttpHeaders requestHeaders;
/*     */   final ClientCookieEncoder cookieEncoder;
/*     */   final ClientCookieDecoder cookieDecoder;
/*     */   final Sinks.One<HttpHeaders> trailerHeaders;
/* 108 */   Supplier<String>[] redirectedFrom = EMPTY_REDIRECTIONS;
/*     */   
/*     */   String resourceUrl;
/*     */   
/*     */   String path;
/*     */   
/*     */   Duration responseTimeout;
/*     */   volatile ResponseState responseState;
/*     */   boolean started;
/*     */   boolean retrying;
/*     */   boolean is100Continue;
/*     */   RedirectClientException redirecting;
/*     */   BiPredicate<HttpClientRequest, HttpClientResponse> followRedirectPredicate;
/*     */   Consumer<HttpClientRequest> redirectRequestConsumer;
/*     */   HttpHeaders previousRequestHeaders;
/*     */   BiConsumer<HttpHeaders, HttpClientRequest> redirectRequestBiConsumer;
/*     */   static final String INBOUND_CANCEL_LOG = "Http client inbound receiver cancelled, closing channel.";
/*     */   static final int MAX_REDIRECTS = 50;
/*     */   
/*     */   HttpClientOperations(HttpClientOperations replaced) {
/* 128 */     super(replaced);
/* 129 */     this.started = replaced.started;
/* 130 */     this.retrying = replaced.retrying;
/* 131 */     this.redirecting = replaced.redirecting;
/* 132 */     this.redirectedFrom = replaced.redirectedFrom;
/* 133 */     this.redirectRequestConsumer = replaced.redirectRequestConsumer;
/* 134 */     this.previousRequestHeaders = replaced.previousRequestHeaders;
/* 135 */     this.redirectRequestBiConsumer = replaced.redirectRequestBiConsumer;
/* 136 */     this.isSecure = replaced.isSecure;
/* 137 */     this.nettyRequest = replaced.nettyRequest;
/* 138 */     this.responseState = replaced.responseState;
/* 139 */     this.followRedirectPredicate = replaced.followRedirectPredicate;
/* 140 */     this.requestHeaders = replaced.requestHeaders;
/* 141 */     this.cookieEncoder = replaced.cookieEncoder;
/* 142 */     this.cookieDecoder = replaced.cookieDecoder;
/* 143 */     this.resourceUrl = replaced.resourceUrl;
/* 144 */     this.path = replaced.path;
/* 145 */     this.responseTimeout = replaced.responseTimeout;
/* 146 */     this.is100Continue = replaced.is100Continue;
/* 147 */     this.trailerHeaders = replaced.trailerHeaders;
/*     */   }
/*     */ 
/*     */   
/*     */   HttpClientOperations(Connection c, ConnectionObserver listener, ClientCookieEncoder encoder, ClientCookieDecoder decoder, HttpMessageLogFactory httpMessageLogFactory) {
/* 152 */     super(c, listener, httpMessageLogFactory);
/* 153 */     this
/*     */       
/* 155 */       .isSecure = (c.channel().pipeline().get("reactor.left.sslHandler") != null);
/* 156 */     this.nettyRequest = (HttpRequest)new DefaultHttpRequest(HttpVersion.HTTP_1_1, HttpMethod.GET, "/");
/* 157 */     this.requestHeaders = this.nettyRequest.headers();
/* 158 */     this.cookieDecoder = decoder;
/* 159 */     this.cookieEncoder = encoder;
/* 160 */     this.trailerHeaders = Sinks.unsafe().one();
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpClientRequest addCookie(Cookie cookie) {
/* 165 */     if (!hasSentHeaders()) {
/* 166 */       this.requestHeaders.add((CharSequence)HttpHeaderNames.COOKIE, this.cookieEncoder
/* 167 */           .encode(cookie));
/*     */     } else {
/*     */       
/* 170 */       throw new IllegalStateException("Status and headers already sent");
/*     */     } 
/* 172 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpClientOperations addHandlerLast(ChannelHandler handler) {
/* 177 */     super.addHandlerLast(handler);
/* 178 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpClientOperations addHandlerLast(String name, ChannelHandler handler) {
/* 183 */     super.addHandlerLast(name, handler);
/* 184 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpClientOperations addHandlerFirst(ChannelHandler handler) {
/* 189 */     super.addHandlerFirst(handler);
/* 190 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpClientOperations addHandlerFirst(String name, ChannelHandler handler) {
/* 195 */     super.addHandlerFirst(name, handler);
/* 196 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpClientOperations addHandler(ChannelHandler handler) {
/* 202 */     super.addHandler(handler);
/* 203 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpClientOperations addHandler(String name, ChannelHandler handler) {
/* 210 */     super.addHandler(name, handler);
/* 211 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpClientOperations replaceHandler(String name, ChannelHandler handler) {
/* 216 */     super.replaceHandler(name, handler);
/* 217 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpClientOperations removeHandler(String name) {
/* 222 */     super.removeHandler(name);
/* 223 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpClientRequest addHeader(CharSequence name, CharSequence value) {
/* 228 */     if (!hasSentHeaders()) {
/* 229 */       this.requestHeaders.add(name, value);
/*     */     } else {
/*     */       
/* 232 */       throw new IllegalStateException("Status and headers already sent");
/*     */     } 
/* 234 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public InetSocketAddress address() {
/* 239 */     return (InetSocketAddress)channel().remoteAddress();
/*     */   }
/*     */   
/*     */   public void chunkedTransfer(boolean chunked) {
/* 243 */     if (!hasSentHeaders() && HttpUtil.isTransferEncodingChunked((HttpMessage)this.nettyRequest) != chunked) {
/* 244 */       this.requestHeaders.remove((CharSequence)HttpHeaderNames.TRANSFER_ENCODING);
/* 245 */       HttpUtil.setTransferEncodingChunked((HttpMessage)this.nettyRequest, chunked);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpClientOperations withConnection(Consumer<? super Connection> withConnection) {
/* 251 */     Objects.requireNonNull(withConnection, "withConnection");
/* 252 */     withConnection.accept(this);
/* 253 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<CharSequence, Set<Cookie>> cookies() {
/* 258 */     ResponseState responseState = this.responseState;
/* 259 */     if (responseState != null && responseState.cookieHolder != null) {
/* 260 */       return responseState.cookieHolder.getCachedCookies();
/*     */     }
/* 262 */     return Collections.emptyMap();
/*     */   }
/*     */   
/*     */   void followRedirectPredicate(BiPredicate<HttpClientRequest, HttpClientResponse> predicate) {
/* 266 */     this.followRedirectPredicate = predicate;
/*     */   }
/*     */   
/*     */   void redirectRequestConsumer(@Nullable Consumer<HttpClientRequest> redirectRequestConsumer) {
/* 270 */     this.redirectRequestConsumer = redirectRequestConsumer;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onInboundCancel() {
/* 276 */     if (isInboundDisposed()) {
/*     */       return;
/*     */     }
/*     */     
/* 280 */     if (log.isDebugEnabled()) {
/* 281 */       log.debug(ReactorNetty.format(channel(), "Http client inbound receiver cancelled, closing channel."));
/*     */     }
/* 283 */     channel().close();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void onInboundClose() {
/* 288 */     if (isInboundCancelled() || isInboundDisposed()) {
/* 289 */       listener().onStateChange((Connection)this, ConnectionObserver.State.DISCONNECTING);
/*     */       return;
/*     */     } 
/* 292 */     listener().onStateChange((Connection)this, HttpClientState.RESPONSE_INCOMPLETE);
/* 293 */     if (this.responseState == null) {
/* 294 */       if (markSentHeaderAndBody(new Object[0])) {
/* 295 */         listener().onUncaughtException((Connection)this, (Throwable)AbortedException.beforeSend());
/*     */       }
/* 297 */       else if (markSentBody()) {
/* 298 */         listener().onUncaughtException((Connection)this, new PrematureCloseException("Connection has been closed BEFORE response, while sending request body"));
/*     */       } else {
/*     */         
/* 301 */         listener().onUncaughtException((Connection)this, new PrematureCloseException("Connection prematurely closed BEFORE response"));
/*     */       } 
/*     */       return;
/*     */     } 
/* 305 */     onInboundError(new PrematureCloseException("Connection prematurely closed DURING response"));
/*     */   }
/*     */ 
/*     */   
/*     */   protected void afterInboundComplete() {
/* 310 */     if (this.redirecting != null) {
/* 311 */       listener().onUncaughtException((Connection)this, this.redirecting);
/*     */     } else {
/*     */       
/* 314 */       listener().onStateChange((Connection)this, HttpClientState.RESPONSE_COMPLETED);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpClientRequest header(CharSequence name, CharSequence value) {
/* 320 */     if (!hasSentHeaders()) {
/* 321 */       this.requestHeaders.set(name, value);
/*     */     } else {
/*     */       
/* 324 */       throw new IllegalStateException("Status and headers already sent");
/*     */     } 
/* 326 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpClientRequest headers(HttpHeaders headers) {
/* 331 */     if (!hasSentHeaders()) {
/* 332 */       String host = this.requestHeaders.get((CharSequence)HttpHeaderNames.HOST);
/* 333 */       this.requestHeaders.set(headers);
/* 334 */       this.requestHeaders.set((CharSequence)HttpHeaderNames.HOST, host);
/*     */     } else {
/*     */       
/* 337 */       throw new IllegalStateException("Status and headers already sent");
/*     */     } 
/* 339 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isFollowRedirect() {
/* 344 */     return (this.followRedirectPredicate != null && this.redirectedFrom.length <= 50);
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpClientRequest responseTimeout(Duration maxReadOperationInterval) {
/* 349 */     if (!hasSentHeaders()) {
/* 350 */       this.responseTimeout = maxReadOperationInterval;
/*     */     } else {
/*     */       
/* 353 */       throw new IllegalStateException("Status and headers already sent");
/*     */     } 
/* 355 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isKeepAlive() {
/* 360 */     ResponseState rs = this.responseState;
/* 361 */     if (rs != null) {
/* 362 */       return HttpUtil.isKeepAlive((HttpMessage)rs.response);
/*     */     }
/* 364 */     return HttpUtil.isKeepAlive((HttpMessage)this.nettyRequest);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isWebsocket() {
/* 369 */     ChannelOperations<?, ?> ops = get(channel());
/* 370 */     return (ops != null && ops.getClass().equals(WebsocketClientOperations.class));
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpMethod method() {
/* 375 */     return this.nettyRequest.method();
/*     */   }
/*     */ 
/*     */   
/*     */   public final HttpClientOperations onDispose(Disposable onDispose) {
/* 380 */     super.onDispose(onDispose);
/* 381 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public ContextView currentContextView() {
/* 386 */     return (ContextView)currentContext();
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] redirectedFrom() {
/* 391 */     Supplier<String>[] redirectedFrom = this.redirectedFrom;
/* 392 */     String[] dest = new String[redirectedFrom.length];
/* 393 */     for (int i = 0; i < redirectedFrom.length; i++) {
/* 394 */       dest[i] = redirectedFrom[i].get();
/*     */     }
/* 396 */     return dest;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpHeaders requestHeaders() {
/* 401 */     return this.nettyRequest.headers();
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpHeaders responseHeaders() {
/* 406 */     ResponseState responseState = this.responseState;
/* 407 */     if (responseState != null) {
/* 408 */       return responseState.headers;
/*     */     }
/* 410 */     throw new IllegalStateException("Response headers cannot be accessed without server response");
/*     */   }
/*     */ 
/*     */   
/*     */   public NettyOutbound send(Publisher<? extends ByteBuf> source) {
/* 415 */     if (!channel().isActive()) {
/* 416 */       return then((Publisher)Mono.error((Throwable)AbortedException.beforeSend()));
/*     */     }
/* 418 */     if (source instanceof Mono) {
/* 419 */       return super.send(source);
/*     */     }
/* 421 */     if (Objects.equals(method(), HttpMethod.GET) || Objects.equals(method(), HttpMethod.HEAD)) {
/*     */       
/* 423 */       ByteBufAllocator alloc = channel().alloc();
/* 424 */       return (NettyOutbound)new HttpOperations.PostHeadersNettyOutbound(Flux.from(source)
/* 425 */           .collectList()
/* 426 */           .doOnDiscard(ByteBuf.class, ReferenceCounted::release)
/* 427 */           .flatMap(list -> { if (markSentHeaderAndBody(list.toArray())) { CompositeByteBuf compositeByteBuf; if (list.isEmpty()) return FutureMono.from((Future)channel().writeAndFlush(newFullBodyMessage(Unpooled.EMPTY_BUFFER)));  int i = list.size(); if (i == 1) { ByteBuf output = list.get(0); } else { CompositeByteBuf agg = alloc.compositeBuffer(list.size()); for (ByteBuf component : list) agg.addComponent(true, component);  compositeByteBuf = agg; }  if (compositeByteBuf.readableBytes() > 0) return FutureMono.from((Future)channel().writeAndFlush(newFullBodyMessage((ByteBuf)compositeByteBuf)));  compositeByteBuf.release(); return FutureMono.from((Future)channel().writeAndFlush(newFullBodyMessage(Unpooled.EMPTY_BUFFER))); }  for (ByteBuf bb : list) { if (log.isDebugEnabled()) log.debug(ReactorNetty.format(channel(), "Ignoring accumulated bytebuf on http GET {}"), new Object[] { bb });  bb.release(); }  return Mono.empty(); }), this, null);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 464 */     return super.send(source);
/*     */   }
/*     */   
/*     */   final URI websocketUri() {
/*     */     URI uri;
/*     */     try {
/* 470 */       String url = uri();
/* 471 */       if (url.startsWith("http") || url.startsWith("ws")) {
/* 472 */         uri = new URI(url);
/*     */       } else {
/*     */         
/* 475 */         String host = requestHeaders().get((CharSequence)HttpHeaderNames.HOST);
/*     */         
/* 477 */         uri = new URI((this.isSecure ? "wss" : "ws") + "://" + host + (url.startsWith("/") ? url : ("/" + url)));
/*     */       }
/*     */     
/* 480 */     } catch (URISyntaxException e) {
/* 481 */       throw new IllegalArgumentException(e);
/*     */     } 
/* 483 */     return uri;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpResponseStatus status() {
/* 488 */     ResponseState responseState = this.responseState;
/* 489 */     if (responseState != null) {
/* 490 */       return responseState.response.status();
/*     */     }
/* 492 */     throw new IllegalStateException("Trying to access status() while missing response");
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<HttpHeaders> trailerHeaders() {
/* 497 */     return this.trailerHeaders.asMono();
/*     */   }
/*     */ 
/*     */   
/*     */   public final String uri() {
/* 502 */     return this.nettyRequest.uri();
/*     */   }
/*     */ 
/*     */   
/*     */   public final String fullPath() {
/* 507 */     return this.path;
/*     */   }
/*     */ 
/*     */   
/*     */   public String resourceUrl() {
/* 512 */     return this.resourceUrl;
/*     */   }
/*     */ 
/*     */   
/*     */   public final HttpVersion version() {
/* 517 */     HttpVersion version = this.nettyRequest.protocolVersion();
/* 518 */     if (version.equals(HttpVersion.HTTP_1_0)) {
/* 519 */       return HttpVersion.HTTP_1_0;
/*     */     }
/* 521 */     if (version.equals(HttpVersion.HTTP_1_1)) {
/* 522 */       return HttpVersion.HTTP_1_1;
/*     */     }
/* 524 */     throw new IllegalStateException(version.protocolName() + " not supported");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void afterMarkSentHeaders() {}
/*     */ 
/*     */ 
/*     */   
/*     */   protected void beforeMarkSentHeaders() {
/* 534 */     if (this.redirectedFrom.length > 0) {
/* 535 */       if (this.redirectRequestConsumer != null) {
/* 536 */         this.redirectRequestConsumer.accept(this);
/*     */       }
/* 538 */       if (this.redirectRequestBiConsumer != null && this.previousRequestHeaders != null) {
/* 539 */         this.redirectRequestBiConsumer.accept(this.previousRequestHeaders, this);
/* 540 */         this.previousRequestHeaders = null;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isContentAlwaysEmpty() {
/* 547 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void onHeadersSent() {
/* 552 */     channel().read();
/* 553 */     if (channel().parent() != null) {
/* 554 */       channel().parent().read();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onOutboundComplete() {
/* 561 */     if (isWebsocket() || isInboundCancelled()) {
/*     */       return;
/*     */     }
/* 564 */     if (markSentHeaderAndBody(new Object[0])) {
/* 565 */       if (log.isDebugEnabled()) {
/* 566 */         log.debug(ReactorNetty.format(channel(), "No sendHeaders() called before complete, sending zero-length header"));
/*     */       }
/*     */ 
/*     */       
/* 570 */       channel().writeAndFlush(newFullBodyMessage(Unpooled.EMPTY_BUFFER));
/*     */     }
/* 572 */     else if (markSentBody()) {
/*     */       
/* 574 */       channel().writeAndFlush(LastHttpContent.EMPTY_LAST_CONTENT);
/*     */     } 
/* 576 */     listener().onStateChange((Connection)this, HttpClientState.REQUEST_SENT);
/* 577 */     if (this.responseTimeout != null) {
/* 578 */       addHandlerFirst("reactor.left.responseTimeoutHandler", (ChannelHandler)new ReadTimeoutHandler(this.responseTimeout
/* 579 */             .toMillis(), TimeUnit.MILLISECONDS));
/*     */     }
/* 581 */     channel().read();
/* 582 */     if (channel().parent() != null) {
/* 583 */       channel().parent().read();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected void onOutboundError(Throwable err) {
/* 589 */     if (isPersistent() && this.responseState == null) {
/* 590 */       if (log.isDebugEnabled()) {
/* 591 */         log.debug(ReactorNetty.format(channel(), "Outbound error happened"), err);
/*     */       }
/* 593 */       listener().onUncaughtException((Connection)this, err);
/* 594 */       if (markSentBody()) {
/* 595 */         markPersistent(false);
/*     */       }
/* 597 */       terminate();
/*     */       return;
/*     */     } 
/* 600 */     super.onOutboundError(err);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void onInboundNext(ChannelHandlerContext ctx, Object msg) {
/* 605 */     if (msg instanceof HttpResponse) {
/* 606 */       HttpResponse response = (HttpResponse)msg;
/* 607 */       if (response.decoderResult()
/* 608 */         .isFailure()) {
/* 609 */         onInboundError(response.decoderResult()
/* 610 */             .cause());
/* 611 */         ReferenceCountUtil.release(msg);
/*     */         return;
/*     */       } 
/* 614 */       if (HttpResponseStatus.CONTINUE.equals(response.status())) {
/* 615 */         this.is100Continue = true;
/* 616 */         ReferenceCountUtil.release(msg);
/*     */         return;
/*     */       } 
/* 619 */       if (this.started) {
/* 620 */         if (log.isDebugEnabled())
/* 621 */           log.debug(ReactorNetty.format(channel(), "HttpClientOperations cannot proceed more than one response {}"), new Object[] {
/* 622 */                 httpMessageLogFactory().debug(HttpMessageArgProviderFactory.create(response))
/*     */               }); 
/* 624 */         ReferenceCountUtil.release(msg);
/*     */         return;
/*     */       } 
/* 627 */       this.is100Continue = false;
/* 628 */       this.started = true;
/* 629 */       setNettyResponse(response);
/*     */       
/* 631 */       if (!isKeepAlive()) {
/* 632 */         markPersistent(false);
/*     */       }
/* 634 */       if (isInboundCancelled()) {
/* 635 */         ReferenceCountUtil.release(msg);
/*     */         
/*     */         return;
/*     */       } 
/* 639 */       if (log.isDebugEnabled()) {
/* 640 */         log.debug(ReactorNetty.format(channel(), "Received response (auto-read:{}) : {}"), new Object[] {
/* 641 */               Boolean.valueOf(channel().config().isAutoRead()), 
/* 642 */               httpMessageLogFactory().debug(HttpMessageArgProviderFactory.create(response))
/*     */             });
/*     */       }
/* 645 */       if (notRedirected(response)) {
/*     */         try {
/* 647 */           listener().onStateChange((Connection)this, HttpClientState.RESPONSE_RECEIVED);
/*     */         }
/* 649 */         catch (Exception e) {
/* 650 */           onInboundError(e);
/* 651 */           ReferenceCountUtil.release(msg);
/*     */ 
/*     */           
/*     */           return;
/*     */         } 
/*     */       } else {
/* 657 */         channel().config().setAutoRead(true);
/*     */       } 
/*     */       
/* 660 */       if (msg instanceof FullHttpResponse) {
/* 661 */         FullHttpResponse request = (FullHttpResponse)msg;
/* 662 */         if (request.content().readableBytes() > 0) {
/* 663 */           super.onInboundNext(ctx, msg);
/*     */         } else {
/*     */           
/* 666 */           request.release();
/*     */         } 
/* 668 */         terminate();
/*     */       } 
/*     */       
/*     */       return;
/*     */     } 
/* 673 */     if (msg instanceof LastHttpContent) {
/* 674 */       if (this.is100Continue) {
/* 675 */         ReferenceCountUtil.release(msg);
/* 676 */         channel().read();
/*     */         return;
/*     */       } 
/* 679 */       if (!this.started) {
/* 680 */         if (log.isDebugEnabled()) {
/* 681 */           log.debug(ReactorNetty.format(channel(), "HttpClientOperations received an incorrect end delimiter (previously used connection?)"));
/*     */         }
/*     */         
/* 684 */         ReferenceCountUtil.release(msg);
/*     */         return;
/*     */       } 
/* 687 */       if (log.isDebugEnabled()) {
/* 688 */         log.debug(ReactorNetty.format(channel(), "Received last HTTP packet"));
/*     */       }
/* 690 */       if (msg != LastHttpContent.EMPTY_LAST_CONTENT) {
/* 691 */         if (this.redirecting != null) {
/* 692 */           ReferenceCountUtil.release(msg);
/*     */         } else {
/*     */           
/* 695 */           super.onInboundNext(ctx, msg);
/*     */         } 
/*     */       }
/*     */       
/* 699 */       if (this.redirecting == null)
/*     */       {
/*     */ 
/*     */ 
/*     */         
/* 704 */         this.trailerHeaders.tryEmitValue(((LastHttpContent)msg).trailingHeaders());
/*     */       }
/*     */ 
/*     */       
/* 708 */       channel().config().setAutoRead(true);
/* 709 */       if (markSentBody()) {
/* 710 */         markPersistent(false);
/*     */       }
/* 712 */       terminate();
/*     */       
/*     */       return;
/*     */     } 
/* 716 */     if (!this.started) {
/* 717 */       if (log.isDebugEnabled()) {
/* 718 */         if (msg instanceof ByteBufHolder) {
/* 719 */           msg = ((ByteBufHolder)msg).content();
/*     */         }
/* 721 */         log.debug(ReactorNetty.format(channel(), "HttpClientOperations received an incorrect chunk {} (previously used connection?)"), new Object[] { msg });
/*     */       } 
/*     */ 
/*     */       
/* 725 */       ReferenceCountUtil.release(msg);
/*     */       
/*     */       return;
/*     */     } 
/* 729 */     if (this.redirecting != null) {
/* 730 */       ReferenceCountUtil.release(msg);
/*     */       
/*     */       return;
/*     */     } 
/* 734 */     super.onInboundNext(ctx, msg);
/*     */   }
/*     */ 
/*     */   
/*     */   protected HttpMessage outboundHttpMessage() {
/* 739 */     return (HttpMessage)this.nettyRequest;
/*     */   }
/*     */   
/*     */   final boolean notRedirected(HttpResponse response) {
/* 743 */     if (isFollowRedirect() && this.followRedirectPredicate.test(this, this)) {
/*     */       try {
/* 745 */         this.redirecting = new RedirectClientException(response.headers(), response.status());
/*     */       }
/* 747 */       catch (RuntimeException e) {
/* 748 */         if (log.isDebugEnabled()) {
/* 749 */           log.debug(ReactorNetty.format(channel(), "The request cannot be redirected"), e);
/*     */         }
/* 751 */         return true;
/*     */       } 
/* 753 */       if (log.isDebugEnabled())
/* 754 */         log.debug(ReactorNetty.format(channel(), "Received redirect location: {}"), new Object[] {
/* 755 */               httpMessageLogFactory().debug(HttpMessageArgProviderFactory.create(response))
/*     */             }); 
/* 757 */       return false;
/*     */     } 
/* 759 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected HttpMessage newFullBodyMessage(ByteBuf body) {
/* 764 */     DefaultFullHttpRequest defaultFullHttpRequest = new DefaultFullHttpRequest(version(), method(), uri(), body);
/*     */     
/* 766 */     this.requestHeaders.setInt((CharSequence)HttpHeaderNames.CONTENT_LENGTH, body.readableBytes());
/* 767 */     this.requestHeaders.remove((CharSequence)HttpHeaderNames.TRANSFER_ENCODING);
/*     */     
/* 769 */     defaultFullHttpRequest.headers()
/* 770 */       .set(this.requestHeaders);
/* 771 */     return (HttpMessage)defaultFullHttpRequest;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Throwable wrapInboundError(Throwable err) {
/* 776 */     if (err instanceof java.nio.channels.ClosedChannelException) {
/* 777 */       return new PrematureCloseException(err);
/*     */     }
/* 779 */     return super.wrapInboundError(err);
/*     */   }
/*     */   
/*     */   final HttpRequest getNettyRequest() {
/* 783 */     return this.nettyRequest;
/*     */   }
/*     */   
/*     */   final Mono<Void> send() {
/* 787 */     if (!channel().isActive()) {
/* 788 */       return Mono.error((Throwable)AbortedException.beforeSend());
/*     */     }
/* 790 */     return FutureMono.deferFuture(() -> markSentHeaderAndBody(new Object[0]) ? channel().writeAndFlush(newFullBodyMessage(Unpooled.EMPTY_BUFFER)) : channel().newSucceededFuture());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final void setNettyResponse(HttpResponse nettyResponse) {
/* 796 */     ResponseState state = this.responseState;
/* 797 */     if (state == null) {
/* 798 */       this
/* 799 */         .responseState = new ResponseState(nettyResponse, nettyResponse.headers(), this.cookieDecoder);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   final void withWebsocketSupport(WebsocketClientSpec websocketClientSpec, boolean compress) {
/* 805 */     URI url = websocketUri();
/*     */     
/* 807 */     if (markSentHeaders(new Object[0])) {
/*     */       
/* 809 */       addHandlerFirst("reactor.left.httpAggregator", (ChannelHandler)new HttpObjectAggregator(8192));
/* 810 */       removeHandler("reactor.left.httpMetricsHandler");
/*     */       
/* 812 */       if (websocketClientSpec.compress()) {
/* 813 */         requestHeaders().remove((CharSequence)HttpHeaderNames.ACCEPT_ENCODING);
/*     */         
/* 815 */         removeHandler("reactor.left.httpDecompressor");
/*     */         
/* 817 */         addHandlerFirst("reactor.left.wsCompressionHandler", (ChannelHandler)WebSocketClientCompressionHandler.INSTANCE);
/*     */       } 
/*     */       
/* 820 */       if (log.isDebugEnabled()) {
/* 821 */         log.debug(ReactorNetty.format(channel(), "Attempting to perform websocket handshake with {}"), new Object[] { url });
/*     */       }
/* 823 */       WebsocketClientOperations ops = new WebsocketClientOperations(url, websocketClientSpec, this);
/*     */       
/* 825 */       if (!rebind((Connection)ops)) {
/* 826 */         log.error(ReactorNetty.format(channel(), "Error while rebinding websocket in channel attribute: " + 
/* 827 */               get(channel()) + " to " + ops));
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   static final class ResponseState
/*     */   {
/*     */     final HttpResponse response;
/*     */     final HttpHeaders headers;
/*     */     final Cookies cookieHolder;
/*     */     
/*     */     ResponseState(HttpResponse response, HttpHeaders headers, ClientCookieDecoder decoder) {
/* 839 */       this.response = response;
/* 840 */       this.headers = headers;
/* 841 */       this.cookieHolder = Cookies.newClientResponseHolder(headers, decoder);
/*     */     }
/*     */   }
/*     */   
/*     */   static final class SendForm
/*     */     extends Mono<Void> {
/* 847 */     static final HttpDataFactory DEFAULT_FACTORY = (HttpDataFactory)new DefaultHttpDataFactory(16384L);
/*     */     
/*     */     final HttpClientOperations parent;
/*     */     
/*     */     final BiConsumer<? super HttpClientRequest, HttpClientForm> formCallback;
/*     */     
/*     */     final Consumer<Flux<Long>> progressCallback;
/*     */     
/*     */     SendForm(HttpClientOperations parent, BiConsumer<? super HttpClientRequest, HttpClientForm> formCallback, @Nullable Consumer<Flux<Long>> progressCallback) {
/* 856 */       this.parent = parent;
/* 857 */       this.formCallback = formCallback;
/* 858 */       this.progressCallback = progressCallback;
/*     */     }
/*     */ 
/*     */     
/*     */     public void subscribe(CoreSubscriber<? super Void> s) {
/* 863 */       if (!this.parent.markSentHeaders(new Object[0])) {
/* 864 */         Operators.error((Subscriber)s, new IllegalStateException("headers have already been sent"));
/*     */         
/*     */         return;
/*     */       } 
/* 868 */       Subscription subscription = Operators.emptySubscription();
/* 869 */       s.onSubscribe(subscription);
/* 870 */       if (this.parent.channel()
/* 871 */         .eventLoop()
/* 872 */         .inEventLoop()) {
/* 873 */         _subscribe(s);
/*     */       } else {
/*     */         
/* 876 */         this.parent.channel()
/* 877 */           .eventLoop()
/* 878 */           .execute(() -> _subscribe(s));
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     void _subscribe(CoreSubscriber<? super Void> s) {
/* 884 */       HttpDataFactory df = DEFAULT_FACTORY;
/*     */       
/*     */       try {
/* 887 */         HttpClientFormEncoder encoder = new HttpClientFormEncoder(df, this.parent.nettyRequest, false, HttpConstants.DEFAULT_CHARSET, HttpPostRequestEncoder.EncoderMode.RFC1738);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 893 */         this.formCallback.accept(this.parent, encoder);
/*     */         
/* 895 */         encoder = encoder.applyChanges(this.parent.nettyRequest);
/* 896 */         df = encoder.newFactory;
/*     */         
/* 898 */         if (!encoder.isMultipart()) {
/* 899 */           this.parent.requestHeaders.remove((CharSequence)HttpHeaderNames.TRANSFER_ENCODING);
/*     */         }
/*     */ 
/*     */         
/* 903 */         this.parent.addHandlerFirst("reactor.left.chunkedWriter", (ChannelHandler)new ChunkedWriteHandler());
/*     */         
/* 905 */         boolean chunked = HttpUtil.isTransferEncodingChunked((HttpMessage)this.parent.nettyRequest);
/*     */         
/* 907 */         HttpRequest r = encoder.finalizeRequest();
/*     */         
/* 909 */         if (!chunked) {
/* 910 */           HttpUtil.setTransferEncodingChunked((HttpMessage)r, false);
/* 911 */           HttpUtil.setContentLength((HttpMessage)r, encoder.length());
/*     */         } 
/*     */ 
/*     */         
/* 915 */         ChannelFuture f = this.parent.channel().writeAndFlush(r);
/*     */         
/* 917 */         if (encoder.isChunked()) {
/* 918 */           Flux<Long> tail = encoder.progressSink.asFlux().onBackpressureLatest();
/*     */           
/* 920 */           if (encoder.cleanOnTerminate)
/*     */           {
/* 922 */             tail = tail.doOnCancel(encoder).doAfterTerminate(encoder);
/*     */           }
/*     */           
/* 925 */           if (this.progressCallback != null) {
/* 926 */             this.progressCallback.accept(tail);
/*     */           } else {
/*     */             
/* 929 */             tail.subscribe();
/*     */           } 
/*     */           
/* 932 */           this.parent.channel()
/* 933 */             .writeAndFlush(encoder);
/*     */         } else {
/*     */           
/* 936 */           Mono<Void> mono = FutureMono.from((Future)f);
/*     */           
/* 938 */           if (encoder.cleanOnTerminate)
/*     */           {
/* 940 */             mono = mono.doOnCancel(encoder).doAfterTerminate(encoder);
/*     */           }
/*     */           
/* 943 */           if (this.progressCallback != null) {
/* 944 */             this.progressCallback.accept(mono.cast(Long.class)
/* 945 */                 .switchIfEmpty(Mono.just(Long.valueOf(encoder.length())))
/* 946 */                 .flux());
/*     */           } else {
/*     */             
/* 949 */             mono.subscribe();
/*     */           } 
/*     */         } 
/* 952 */         s.onComplete();
/*     */ 
/*     */       
/*     */       }
/* 956 */       catch (Throwable e) {
/* 957 */         Exceptions.throwIfJvmFatal(e);
/* 958 */         df.cleanRequestHttpData(this.parent.nettyRequest);
/* 959 */         s.onError(Exceptions.unwrap(e));
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 966 */   static final Supplier<String>[] EMPTY_REDIRECTIONS = (Supplier<String>[])new Supplier[0];
/* 967 */   static final Logger log = Loggers.getLogger(HttpClientOperations.class);
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\client\HttpClientOperations.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */