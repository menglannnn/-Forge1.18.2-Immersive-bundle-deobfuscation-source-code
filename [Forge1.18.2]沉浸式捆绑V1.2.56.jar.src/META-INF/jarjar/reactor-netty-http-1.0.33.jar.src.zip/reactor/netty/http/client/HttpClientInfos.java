package reactor.netty.http.client;

import io.netty.handler.codec.http.HttpHeaders;
import reactor.netty.http.HttpInfos;
import reactor.util.annotation.Nullable;
import reactor.util.context.Context;
import reactor.util.context.ContextView;

public interface HttpClientInfos extends HttpInfos {
  @Deprecated
  Context currentContext();
  
  ContextView currentContextView();
  
  String[] redirectedFrom();
  
  HttpHeaders requestHeaders();
  
  @Nullable
  String resourceUrl();
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\client\HttpClientInfos.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */