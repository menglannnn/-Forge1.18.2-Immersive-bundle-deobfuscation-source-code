/*    */ package reactor.netty.http.client;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class PrematureCloseException
/*    */   extends IOException
/*    */ {
/* 33 */   public static final PrematureCloseException TEST_EXCEPTION = new PrematureCloseException("Simulated prematurely closed connection");
/*    */   private static final long serialVersionUID = -3569621032752341973L;
/*    */   
/*    */   PrematureCloseException(String message) {
/* 37 */     super(message);
/*    */   }
/*    */   
/*    */   PrematureCloseException(Throwable throwable) {
/* 41 */     super(throwable);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public synchronized Throwable fillInStackTrace() {
/* 47 */     return this;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\client\PrematureCloseException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */