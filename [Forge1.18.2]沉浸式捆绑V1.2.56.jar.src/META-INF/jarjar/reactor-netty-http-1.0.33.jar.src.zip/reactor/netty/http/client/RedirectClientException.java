/*    */ package reactor.netty.http.client;
/*    */ 
/*    */ import io.netty.handler.codec.http.HttpHeaderNames;
/*    */ import io.netty.handler.codec.http.HttpHeaders;
/*    */ import io.netty.handler.codec.http.HttpResponseStatus;
/*    */ import java.util.Objects;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class RedirectClientException
/*    */   extends RuntimeException
/*    */ {
/*    */   final String location;
/*    */   final HttpResponseStatus status;
/*    */   private static final long serialVersionUID = -8887076761196723045L;
/*    */   
/*    */   RedirectClientException(HttpHeaders headers, HttpResponseStatus status) {
/* 34 */     this.location = Objects.<String>requireNonNull(headers.get((CharSequence)HttpHeaderNames.LOCATION), "location");
/* 35 */     this.status = Objects.<HttpResponseStatus>requireNonNull(status, "status");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public synchronized Throwable fillInStackTrace() {
/* 41 */     return this;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\client\RedirectClientException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */