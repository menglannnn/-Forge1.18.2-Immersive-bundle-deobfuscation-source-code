/*     */ package reactor.netty.http.client;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.buffer.ByteBufAllocator;
/*     */ import io.netty.channel.ChannelOption;
/*     */ import java.net.URI;
/*     */ import java.util.Objects;
/*     */ import java.util.function.BiConsumer;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Function;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.core.publisher.SignalType;
/*     */ import reactor.netty.ByteBufFlux;
/*     */ import reactor.netty.ByteBufMono;
/*     */ import reactor.netty.Connection;
/*     */ import reactor.netty.NettyOutbound;
/*     */ import reactor.netty.channel.ChannelOperations;
/*     */ import reactor.netty.transport.Transport;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class HttpClientFinalizer
/*     */   extends HttpClientConnect
/*     */   implements HttpClient.RequestSender
/*     */ {
/*     */   HttpClientFinalizer(HttpClientConfig config) {
/*  48 */     super(config);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpClient.RequestSender uri(Mono<String> uri) {
/*  55 */     Objects.requireNonNull(uri, "uri");
/*  56 */     HttpClient dup = duplicate();
/*  57 */     ((HttpClientConfig)dup.configuration()).deferredConf(config -> uri.map(()));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  62 */     return (HttpClientFinalizer)dup;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpClient.RequestSender uri(String uri) {
/*  67 */     Objects.requireNonNull(uri, "uri");
/*  68 */     HttpClient dup = duplicate();
/*  69 */     ((HttpClientConfig)dup.configuration()).uriStr = uri;
/*  70 */     ((HttpClientConfig)dup.configuration()).uri = null;
/*  71 */     return (HttpClientFinalizer)dup;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpClient.RequestSender uri(URI uri) {
/*  76 */     Objects.requireNonNull(uri, "uri");
/*  77 */     if (!uri.isAbsolute()) {
/*  78 */       throw new IllegalArgumentException("URI is not absolute: " + uri);
/*     */     }
/*  80 */     HttpClient dup = duplicate();
/*  81 */     ((HttpClientConfig)dup.configuration()).uriStr = null;
/*  82 */     ((HttpClientConfig)dup.configuration()).uri = uri;
/*  83 */     return (HttpClientFinalizer)dup;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<HttpClientResponse> response() {
/*  90 */     return _connect().map(RESPONSE_ONLY);
/*     */   }
/*     */ 
/*     */   
/*     */   public <V> Flux<V> response(BiFunction<? super HttpClientResponse, ? super ByteBufFlux, ? extends Publisher<V>> receiver) {
/*  95 */     return _connect().flatMapMany(resp -> Flux.from(receiver.apply(resp, resp.receive())).doFinally(()).contextWrite(resp.currentContextView()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <V> Flux<V> responseConnection(BiFunction<? super HttpClientResponse, ? super Connection, ? extends Publisher<V>> receiver) {
/* 102 */     return _connect().flatMapMany(resp -> Flux.from(receiver.apply(resp, resp)).contextWrite(resp.currentContextView()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ByteBufFlux responseContent() {
/* 109 */     ByteBufAllocator alloc = (ByteBufAllocator)configuration().options().get(ChannelOption.ALLOCATOR);
/* 110 */     if (alloc == null) {
/* 111 */       alloc = ByteBufAllocator.DEFAULT;
/*     */     }
/*     */ 
/*     */     
/* 115 */     Mono<ChannelOperations<?, ?>> connector = (Mono)connect();
/* 116 */     return ByteBufFlux.fromInbound((Publisher)connector.flatMapMany(contentReceiver), alloc);
/*     */   }
/*     */ 
/*     */   
/*     */   public <V> Mono<V> responseSingle(BiFunction<? super HttpClientResponse, ? super ByteBufMono, ? extends Mono<V>> receiver) {
/* 121 */     return _connect().flatMap(resp -> ((Mono)receiver.apply(resp, resp.receive().aggregate())).doFinally(()).contextWrite(resp.currentContextView()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpClientFinalizer send(BiFunction<? super HttpClientRequest, ? super NettyOutbound, ? extends Publisher<Void>> sender) {
/* 131 */     Objects.requireNonNull(sender, "requestBody");
/* 132 */     HttpClient dup = duplicate();
/* 133 */     ((HttpClientConfig)dup.configuration()).body = sender;
/* 134 */     return (HttpClientFinalizer)dup;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpClientFinalizer send(Publisher<? extends ByteBuf> requestBody) {
/* 139 */     Objects.requireNonNull(requestBody, "requestBody");
/* 140 */     return send((req, out) -> out.send(requestBody));
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpClientFinalizer sendForm(BiConsumer<? super HttpClientRequest, HttpClientForm> formCallback, @Nullable Consumer<Flux<Long>> progress) {
/* 145 */     Objects.requireNonNull(formCallback, "formCallback");
/* 146 */     return send((req, out) -> {
/*     */           HttpClientOperations ops = (HttpClientOperations)out;
/*     */           return (Publisher)new HttpClientOperations.SendForm(ops, formCallback, progress);
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   protected HttpClient duplicate() {
/* 154 */     return new HttpClientFinalizer(new HttpClientConfig(this.config));
/*     */   }
/*     */ 
/*     */   
/*     */   Mono<HttpClientOperations> _connect() {
/* 159 */     return (Mono)connect();
/*     */   }
/*     */   
/*     */   static void discard(HttpClientOperations c) {
/* 163 */     if (!c.isInboundDisposed()) {
/* 164 */       c.discard();
/*     */     }
/*     */   }
/*     */   
/* 168 */   static final Function<ChannelOperations<?, ?>, Flux<?>> contentReceiver = ChannelOperations::receiveObject;
/*     */   static {
/* 170 */     RESPONSE_ONLY = (ops -> {
/*     */         discard(ops);
/*     */         return ops;
/*     */       });
/*     */   }
/*     */   
/*     */   static final Function<HttpClientOperations, HttpClientResponse> RESPONSE_ONLY;
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\client\HttpClientFinalizer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */