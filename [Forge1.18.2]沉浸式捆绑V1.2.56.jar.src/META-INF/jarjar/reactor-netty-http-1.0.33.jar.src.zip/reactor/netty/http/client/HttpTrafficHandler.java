/*     */ package reactor.netty.http.client;
/*     */ 
/*     */ import io.netty.channel.Channel;
/*     */ import io.netty.channel.ChannelHandler;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.channel.ChannelInboundHandlerAdapter;
/*     */ import io.netty.handler.codec.http.HttpClientUpgradeHandler;
/*     */ import reactor.netty.Connection;
/*     */ import reactor.netty.ConnectionObserver;
/*     */ import reactor.netty.ReactorNetty;
/*     */ import reactor.netty.channel.ChannelOperations;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.Loggers;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class HttpTrafficHandler
/*     */   extends ChannelInboundHandlerAdapter
/*     */ {
/*     */   final ConnectionObserver listener;
/*     */   
/*     */   HttpTrafficHandler(ConnectionObserver listener) {
/*  50 */     this.listener = listener;
/*     */   }
/*     */ 
/*     */   
/*     */   public void channelActive(ChannelHandlerContext ctx) {
/*  55 */     Channel channel = ctx.channel();
/*  56 */     if (channel.isActive()) {
/*  57 */       if (ctx.pipeline().get("reactor.left.h2MultiplexHandler") == null) {
/*     */         
/*  59 */         ctx.fireChannelActive();
/*     */       }
/*  61 */       else if (ctx.pipeline().get("reactor.left.sslHandler") == null) {
/*     */         
/*  63 */         sendNewState(Connection.from(channel), ConnectionObserver.State.CONNECTED);
/*  64 */         ctx.flush();
/*  65 */         ctx.read();
/*     */       }
/*     */       else {
/*     */         
/*  69 */         sendNewState(Connection.from(channel), ConnectionObserver.State.CONNECTED);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void channelRead(ChannelHandlerContext ctx, Object msg) {
/*  76 */     if (msg instanceof io.netty.handler.codec.http2.Http2SettingsFrame) {
/*  77 */       sendNewState(Connection.from(ctx.channel()), ConnectionObserver.State.CONFIGURED);
/*  78 */       ctx.pipeline().remove("reactor.right.reactiveBridge");
/*  79 */       ctx.pipeline().remove((ChannelHandler)this);
/*     */       
/*     */       return;
/*     */     } 
/*  83 */     ctx.fireChannelRead(msg);
/*     */   }
/*     */ 
/*     */   
/*     */   public void channelInactive(ChannelHandlerContext ctx) {
/*  88 */     ctx.fireExceptionCaught(new PrematureCloseException("Connection prematurely closed BEFORE response"));
/*     */   }
/*     */ 
/*     */   
/*     */   public void userEventTriggered(ChannelHandlerContext ctx, Object evt) {
/*  93 */     Channel channel = ctx.channel();
/*  94 */     if (evt == HttpClientUpgradeHandler.UpgradeEvent.UPGRADE_ISSUED) {
/*  95 */       if (log.isDebugEnabled()) {
/*  96 */         log.debug(ReactorNetty.format(channel, "An upgrade request was sent to the server."));
/*     */       }
/*     */     }
/*  99 */     else if (evt == HttpClientUpgradeHandler.UpgradeEvent.UPGRADE_SUCCESSFUL) {
/* 100 */       if (log.isDebugEnabled()) {
/* 101 */         log.debug(ReactorNetty.format(channel, "The upgrade to H2C protocol was successful."));
/*     */       }
/* 103 */       sendNewState(Connection.from(channel), HttpClientState.UPGRADE_SUCCESSFUL);
/* 104 */       ctx.pipeline().remove((ChannelHandler)this);
/*     */     }
/* 106 */     else if (evt == HttpClientUpgradeHandler.UpgradeEvent.UPGRADE_REJECTED) {
/* 107 */       if (log.isDebugEnabled()) {
/* 108 */         log.debug(ReactorNetty.format(channel, "The upgrade to H2C protocol was rejected, continue using HTTP/1.x protocol."));
/*     */       }
/* 110 */       sendNewState(Connection.from(channel), HttpClientState.UPGRADE_REJECTED);
/* 111 */       ctx.pipeline().remove((ChannelHandler)this);
/*     */     } 
/* 113 */     ctx.fireUserEventTriggered(evt);
/*     */   }
/*     */   
/*     */   void sendNewState(Connection connection, ConnectionObserver.State state) {
/* 117 */     ChannelOperations<?, ?> ops = (ChannelOperations<?, ?>)connection.as(ChannelOperations.class);
/* 118 */     if (ops != null) {
/* 119 */       this.listener.onStateChange((Connection)ops, state);
/*     */     } else {
/*     */       
/* 122 */       this.listener.onStateChange(connection, state);
/*     */     } 
/*     */   }
/*     */   
/* 126 */   static final Logger log = Loggers.getLogger(HttpTrafficHandler.class);
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\client\HttpTrafficHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */