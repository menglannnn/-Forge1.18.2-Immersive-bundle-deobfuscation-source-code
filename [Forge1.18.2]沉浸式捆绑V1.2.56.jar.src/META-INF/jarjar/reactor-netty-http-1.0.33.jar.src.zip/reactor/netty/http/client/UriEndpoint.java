/*     */ package reactor.netty.http.client;
/*     */ 
/*     */ import io.netty.channel.unix.DomainSocketAddress;
/*     */ import io.netty.util.NetUtil;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.SocketAddress;
/*     */ import java.util.Objects;
/*     */ import java.util.function.Supplier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class UriEndpoint
/*     */ {
/*     */   final String scheme;
/*     */   final String host;
/*     */   final int port;
/*     */   final Supplier<? extends SocketAddress> remoteAddress;
/*     */   final String pathAndQuery;
/*     */   
/*     */   UriEndpoint(String scheme, String host, int port, Supplier<? extends SocketAddress> remoteAddress, String pathAndQuery) {
/*  34 */     this.host = host;
/*  35 */     this.port = port;
/*  36 */     this.scheme = Objects.<String>requireNonNull(scheme, "scheme");
/*  37 */     this.remoteAddress = Objects.<Supplier<? extends SocketAddress>>requireNonNull(remoteAddress, "remoteAddressSupplier");
/*  38 */     this.pathAndQuery = Objects.<String>requireNonNull(pathAndQuery, "pathAndQuery");
/*     */   }
/*     */   
/*     */   boolean isWs() {
/*  42 */     return ("ws".equals(this.scheme) || "wss".equals(this.scheme));
/*     */   }
/*     */   
/*     */   boolean isSecure() {
/*  46 */     return isSecureScheme(this.scheme);
/*     */   }
/*     */   
/*     */   static boolean isSecureScheme(String scheme) {
/*  50 */     return ("https".equals(scheme) || "wss".equals(scheme));
/*     */   }
/*     */   
/*     */   String getPathAndQuery() {
/*  54 */     return this.pathAndQuery;
/*     */   }
/*     */   
/*     */   SocketAddress getRemoteAddress() {
/*  58 */     return this.remoteAddress.get();
/*     */   }
/*     */   
/*     */   String toExternalForm() {
/*  62 */     StringBuilder sb = new StringBuilder();
/*  63 */     SocketAddress address = this.remoteAddress.get();
/*  64 */     if (address instanceof DomainSocketAddress) {
/*  65 */       sb.append(((DomainSocketAddress)address).path());
/*     */     } else {
/*     */       
/*  68 */       sb.append(this.scheme);
/*  69 */       sb.append("://");
/*  70 */       sb.append((address != null) ? 
/*  71 */           toSocketAddressStringWithoutDefaultPort(address, isSecure()) : 
/*  72 */           "localhost");
/*  73 */       sb.append(this.pathAndQuery);
/*     */     } 
/*  75 */     return sb.toString();
/*     */   }
/*     */   
/*     */   static String toSocketAddressStringWithoutDefaultPort(SocketAddress address, boolean secure) {
/*  79 */     if (!(address instanceof InetSocketAddress)) {
/*  80 */       throw new IllegalStateException("Only support InetSocketAddress representation");
/*     */     }
/*  82 */     String addressString = NetUtil.toSocketAddressString((InetSocketAddress)address);
/*  83 */     if (secure) {
/*  84 */       if (addressString.endsWith(":443")) {
/*  85 */         addressString = addressString.substring(0, addressString.length() - 4);
/*     */       
/*     */       }
/*     */     }
/*  89 */     else if (addressString.endsWith(":80")) {
/*  90 */       addressString = addressString.substring(0, addressString.length() - 3);
/*     */     } 
/*     */     
/*  93 */     return addressString;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  98 */     return toExternalForm();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 103 */     if (this == o) {
/* 104 */       return true;
/*     */     }
/* 106 */     if (o == null || getClass() != o.getClass()) {
/* 107 */       return false;
/*     */     }
/* 109 */     UriEndpoint that = (UriEndpoint)o;
/* 110 */     return getRemoteAddress().equals(that.getRemoteAddress());
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 115 */     return Objects.hash(new Object[] { getRemoteAddress() });
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\client\UriEndpoint.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */