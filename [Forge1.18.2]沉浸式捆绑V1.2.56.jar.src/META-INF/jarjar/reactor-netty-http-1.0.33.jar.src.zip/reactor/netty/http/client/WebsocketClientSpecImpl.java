/*    */ package reactor.netty.http.client;
/*    */ 
/*    */ import io.netty.handler.codec.http.websocketx.WebSocketVersion;
/*    */ import reactor.netty.http.websocket.WebsocketSpecImpl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class WebsocketClientSpecImpl
/*    */   extends WebsocketSpecImpl
/*    */   implements WebsocketClientSpec
/*    */ {
/*    */   private final WebSocketVersion version;
/*    */   
/*    */   public WebSocketVersion version() {
/* 31 */     return this.version;
/*    */   }
/*    */   
/*    */   WebsocketClientSpecImpl(WebsocketClientSpec.Builder builder) {
/* 35 */     super(builder);
/* 36 */     this.version = builder.version;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\client\WebsocketClientSpecImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */