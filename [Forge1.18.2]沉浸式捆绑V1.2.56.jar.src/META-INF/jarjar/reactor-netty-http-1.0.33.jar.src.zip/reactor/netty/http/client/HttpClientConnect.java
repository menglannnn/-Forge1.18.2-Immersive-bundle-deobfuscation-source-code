/*     */ package reactor.netty.http.client;
/*     */ 
/*     */ import io.netty.channel.ChannelOption;
/*     */ import io.netty.handler.codec.http.HttpHeaderNames;
/*     */ import io.netty.handler.codec.http.HttpHeaders;
/*     */ import io.netty.handler.codec.http.HttpMethod;
/*     */ import io.netty.handler.codec.http.HttpResponseStatus;
/*     */ import io.netty.handler.codec.http.HttpUtil;
/*     */ import io.netty.handler.codec.http.HttpVersion;
/*     */ import io.netty.resolver.AddressResolverGroup;
/*     */ import io.netty.util.AsciiString;
/*     */ import io.netty.util.AttributeKey;
/*     */ import io.netty.util.NetUtil;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.SocketAddress;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.time.Duration;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.function.BiConsumer;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.BiPredicate;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Predicate;
/*     */ import java.util.function.Supplier;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.core.publisher.MonoSink;
/*     */ import reactor.netty.Connection;
/*     */ import reactor.netty.ConnectionObserver;
/*     */ import reactor.netty.NettyOutbound;
/*     */ import reactor.netty.ReactorNetty;
/*     */ import reactor.netty.channel.AbortedException;
/*     */ import reactor.netty.http.HttpOperations;
/*     */ import reactor.netty.http.HttpProtocol;
/*     */ import reactor.netty.tcp.SslProvider;
/*     */ import reactor.netty.tcp.TcpClientConfig;
/*     */ import reactor.netty.transport.AddressUtils;
/*     */ import reactor.netty.transport.ProxyProvider;
/*     */ import reactor.netty.transport.Transport;
/*     */ import reactor.netty.transport.TransportConfig;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.Loggers;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ import reactor.util.context.ContextView;
/*     */ import reactor.util.retry.Retry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class HttpClientConnect
/*     */   extends HttpClient
/*     */ {
/*     */   final HttpClientConfig config;
/*     */   
/*     */   HttpClientConnect(HttpConnectionProvider provider) {
/*  84 */     this
/*     */       
/*  86 */       .config = new HttpClientConfig(provider, Collections.singletonMap(ChannelOption.AUTO_READ, Boolean.valueOf(false)), () -> AddressUtils.createUnresolved(NetUtil.LOCALHOST.getHostAddress(), DEFAULT_PORT));
/*     */   }
/*     */ 
/*     */   
/*     */   HttpClientConnect(HttpClientConfig config) {
/*  91 */     this.config = config;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpClientConfig configuration() {
/*  96 */     return this.config;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 101 */     return "HttpClient{protocols=" + 
/* 102 */       Arrays.<HttpProtocol>asList((configuration()).protocols) + ", secure=" + 
/* 103 */       configuration().isSecure() + '}';
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Mono<? extends Connection> connect() {
/* 109 */     HttpClientConfig config = configuration();
/*     */ 
/*     */     
/* 112 */     if (config.deferredConf != null) {
/* 113 */       return ((Mono)config.deferredConf.apply(Mono.just(config)))
/* 114 */         .flatMap(MonoHttpConnect::new);
/*     */     }
/*     */     
/* 117 */     Mono<? extends Connection> mono = new MonoHttpConnect(config);
/*     */ 
/*     */     
/* 120 */     if (config.doOnConnect() != null) {
/* 121 */       mono = mono.doOnSubscribe(s -> config.doOnConnect().accept(config));
/*     */     }
/*     */     
/* 124 */     if (config.doOnRequestError != null) {
/* 125 */       mono = mono.onErrorResume(error -> Mono.deferContextual(Mono::just).doOnNext(()).then(Mono.error(error)));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 131 */     if (config.connector != null) {
/* 132 */       mono = config.connector.apply(mono);
/*     */     }
/* 134 */     return mono;
/*     */   }
/*     */ 
/*     */   
/*     */   protected HttpClient duplicate() {
/* 139 */     return new HttpClientConnect(new HttpClientConfig(this.config));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static HttpClient applyTcpClientConfig(TcpClientConfig config) {
/* 148 */     HttpClient httpClient = (HttpClient)((HttpClient)create(config.connectionProvider()).doOnChannelInit(config.doOnChannelInit())).observe(config.connectionObserver()).remoteAddress(config.remoteAddress()).runOn(config.loopResources(), config.isPreferNative());
/*     */     
/* 150 */     if (config.resolver() != null) {
/* 151 */       httpClient = (HttpClient)httpClient.resolver(config.resolver());
/*     */     }
/*     */     
/* 154 */     for (Map.Entry<AttributeKey<?>, ?> entry : (Iterable<Map.Entry<AttributeKey<?>, ?>>)config.attributes().entrySet()) {
/* 155 */       httpClient = (HttpClient)httpClient.attr(entry.getKey(), entry.getValue());
/*     */     }
/*     */     
/* 158 */     if (config.bindAddress() != null) {
/* 159 */       httpClient = (HttpClient)httpClient.bindAddress(config.bindAddress());
/*     */     }
/*     */     
/* 162 */     if (config.channelGroup() != null) {
/* 163 */       httpClient = (HttpClient)httpClient.channelGroup(config.channelGroup());
/*     */     }
/*     */     
/* 166 */     if (config.doOnConnected() != null) {
/* 167 */       httpClient = (HttpClient)httpClient.doOnConnected(config.doOnConnected());
/*     */     }
/*     */     
/* 170 */     if (config.doOnDisconnected() != null) {
/* 171 */       httpClient = (HttpClient)httpClient.doOnDisconnected(config.doOnDisconnected());
/*     */     }
/*     */     
/* 174 */     if (config.loggingHandler() != null) {
/* 175 */       ((HttpClientConfig)httpClient.configuration()).loggingHandler(config.loggingHandler());
/*     */     }
/*     */     
/* 178 */     if (config.metricsRecorder() != null) {
/* 179 */       httpClient = httpClient.metrics(true, config.metricsRecorder());
/*     */     }
/*     */     
/* 182 */     for (Map.Entry<ChannelOption<?>, ?> entry : (Iterable<Map.Entry<ChannelOption<?>, ?>>)config.options().entrySet()) {
/* 183 */       httpClient = (HttpClient)httpClient.option(entry.getKey(), entry.getValue());
/*     */     }
/*     */     
/* 186 */     if (config.proxyProvider() != null) {
/* 187 */       ((HttpClientConfig)httpClient.configuration()).proxyProvider(config.proxyProvider());
/*     */     }
/*     */     
/* 190 */     if (config.sslProvider() != null) {
/* 191 */       httpClient = httpClient.secure(config.sslProvider());
/*     */     }
/*     */     
/* 194 */     return httpClient;
/*     */   }
/*     */   
/*     */   static final class MonoHttpConnect
/*     */     extends Mono<Connection> {
/*     */     final HttpClientConfig config;
/*     */     
/*     */     MonoHttpConnect(HttpClientConfig config) {
/* 202 */       this.config = config;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void subscribe(CoreSubscriber<? super Connection> actual) {
/* 208 */       HttpClientConnect.HttpClientHandler handler = new HttpClientConnect.HttpClientHandler(this.config);
/*     */       
/* 210 */       Mono.create(sink -> {
/*     */             HttpClientConfig _config = this.config;
/*     */ 
/*     */ 
/*     */             
/*     */             if (handler.toURI.isSecure()) {
/*     */               if (_config.sslProvider == null) {
/*     */                 _config = new HttpClientConfig(this.config);
/*     */ 
/*     */ 
/*     */                 
/*     */                 _config.sslProvider = HttpClientSecure.defaultSslProvider(_config);
/*     */               } 
/*     */ 
/*     */ 
/*     */               
/*     */               if (_config.checkProtocol(1)) {
/*     */                 if (_config.protocols.length > 1) {
/*     */                   removeIncompatibleProtocol(_config, HttpProtocol.H2C);
/*     */                 } else {
/*     */                   sink.error(new IllegalArgumentException("Configured H2 Clear-Text protocol with TLS. Use the non Clear-Text H2 protocol via HttpClient#protocol or disable TLS via HttpClient#noSSL()"));
/*     */ 
/*     */ 
/*     */                   
/*     */                   return;
/*     */                 } 
/*     */               }
/*     */ 
/*     */               
/*     */               if (_config.sslProvider.getDefaultConfigurationType() == null) {
/*     */                 if (_config.checkProtocol(2)) {
/*     */                   _config.sslProvider = SslProvider.updateDefaultConfiguration(_config.sslProvider, SslProvider.DefaultConfigurationType.H2);
/*     */                 } else {
/*     */                   _config.sslProvider = SslProvider.updateDefaultConfiguration(_config.sslProvider, SslProvider.DefaultConfigurationType.TCP);
/*     */                 } 
/*     */               }
/*     */             } else {
/*     */               if (_config.sslProvider != null) {
/*     */                 _config = new HttpClientConfig(this.config);
/*     */ 
/*     */                 
/*     */                 _config.sslProvider = null;
/*     */               } 
/*     */ 
/*     */               
/*     */               if (_config.checkProtocol(2)) {
/*     */                 if (_config.protocols.length > 1) {
/*     */                   removeIncompatibleProtocol(_config, HttpProtocol.H2);
/*     */                 } else {
/*     */                   sink.error(new IllegalArgumentException("Configured H2 protocol without TLS. Use H2 Clear-Text protocol via HttpClient#protocol or configure TLS via HttpClient#secure"));
/*     */ 
/*     */                   
/*     */                   return;
/*     */                 } 
/*     */               }
/*     */             } 
/*     */ 
/*     */             
/*     */             ConnectionObserver observer = (new HttpClientConnect.HttpObserver(sink, handler)).then(_config.defaultConnectionObserver()).then(_config.connectionObserver()).then(new HttpClientConnect.HttpIOHandlerObserver(sink, handler));
/*     */ 
/*     */             
/*     */             AddressResolverGroup<?> resolver = _config.resolverInternal();
/*     */ 
/*     */             
/*     */             _config.httpConnectionProvider().acquire((TransportConfig)_config, observer, handler, resolver).subscribe(new ClientTransportSubscriber(sink));
/* 275 */           }).retryWhen((Retry)Retry.indefinitely().filter(handler))
/* 276 */         .subscribe(actual);
/*     */     }
/*     */     
/*     */     private void removeIncompatibleProtocol(HttpClientConfig config, HttpProtocol protocol) {
/* 280 */       List<HttpProtocol> newProtocols = new ArrayList<>();
/* 281 */       for (int i = 0; i < config.protocols.length; i++) {
/* 282 */         if (config.protocols[i] != protocol) {
/* 283 */           newProtocols.add(config.protocols[i]);
/*     */         }
/*     */       } 
/* 286 */       config.protocols(newProtocols.<HttpProtocol>toArray(new HttpProtocol[0]));
/*     */     }
/*     */     
/*     */     static final class ClientTransportSubscriber
/*     */       implements CoreSubscriber<Connection> {
/*     */       final MonoSink<Connection> sink;
/*     */       final Context currentContext;
/*     */       
/*     */       ClientTransportSubscriber(MonoSink<Connection> sink) {
/* 295 */         this.sink = sink;
/* 296 */         this.currentContext = Context.of(sink.contextView());
/*     */       }
/*     */ 
/*     */       
/*     */       public void onSubscribe(Subscription s) {
/* 301 */         s.request(Long.MAX_VALUE);
/*     */       }
/*     */ 
/*     */       
/*     */       public void onNext(Connection connection) {
/* 306 */         this.sink.onCancel((Disposable)connection);
/*     */       }
/*     */ 
/*     */       
/*     */       public void onError(Throwable throwable) {
/* 311 */         this.sink.error(throwable);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       public void onComplete() {}
/*     */ 
/*     */       
/*     */       public Context currentContext() {
/* 320 */         return this.currentContext;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   static final class HttpObserver
/*     */     implements ConnectionObserver {
/*     */     final MonoSink<Connection> sink;
/*     */     final Context currentContext;
/*     */     final HttpClientConnect.HttpClientHandler handler;
/*     */     
/*     */     HttpObserver(MonoSink<Connection> sink, HttpClientConnect.HttpClientHandler handler) {
/* 332 */       this.sink = sink;
/* 333 */       this.currentContext = Context.of(sink.contextView());
/* 334 */       this.handler = handler;
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/* 339 */       return this.currentContext;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onUncaughtException(Connection connection, Throwable error) {
/* 344 */       if (error instanceof RedirectClientException) {
/* 345 */         if (HttpClientConnect.log.isDebugEnabled()) {
/* 346 */           HttpClientConnect.log.debug(ReactorNetty.format(connection.channel(), "The request will be redirected"));
/*     */         }
/* 348 */         HttpClientOperations ops = (HttpClientOperations)connection.as(HttpClientOperations.class);
/* 349 */         if (ops != null && this.handler.redirectRequestBiConsumer != null) {
/* 350 */           this.handler.previousRequestHeaders = ops.requestHeaders;
/*     */         }
/*     */       }
/* 353 */       else if (this.handler.shouldRetry && AbortedException.isConnectionReset(error)) {
/* 354 */         HttpClientOperations ops = (HttpClientOperations)connection.as(HttpClientOperations.class);
/* 355 */         if (ops != null && ops.hasSentHeaders())
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 363 */           ops.markPersistent(false);
/*     */           
/* 365 */           this.handler.shouldRetry = false;
/* 366 */           if (HttpClientConnect.log.isWarnEnabled()) {
/* 367 */             HttpClientConnect.log.warn(ReactorNetty.format(connection.channel(), "The connection observed an error, the request cannot be retried as the headers/body were sent"), error);
/*     */           
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/* 373 */           if (ops != null) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 381 */             ops.markPersistent(false);
/* 382 */             ops.retrying = true;
/*     */           } 
/* 384 */           if (HttpClientConnect.log.isDebugEnabled()) {
/* 385 */             HttpClientConnect.log.debug(ReactorNetty.format(connection.channel(), "The connection observed an error, the request will be retried"), error);
/*     */           }
/*     */         }
/*     */       
/*     */       }
/* 390 */       else if (error instanceof io.netty.handler.ssl.SslClosedEngineException) {
/* 391 */         if (HttpClientConnect.log.isWarnEnabled()) {
/* 392 */           HttpClientConnect.log.warn(ReactorNetty.format(connection.channel(), "The connection observed an error"), error);
/*     */         }
/* 394 */         HttpClientOperations ops = (HttpClientOperations)connection.as(HttpClientOperations.class);
/* 395 */         if (ops != null)
/*     */         {
/* 397 */           ops.markPersistent(false);
/*     */         }
/*     */       }
/* 400 */       else if (HttpClientConnect.log.isWarnEnabled()) {
/* 401 */         HttpClientConnect.log.warn(ReactorNetty.format(connection.channel(), "The connection observed an error"), error);
/*     */       } 
/* 403 */       this.sink.error(error);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onStateChange(Connection connection, ConnectionObserver.State newState) {
/* 408 */       if ((newState == ConnectionObserver.State.CONFIGURED || newState == HttpClientState.STREAM_CONFIGURED) && HttpClientOperations.class == connection
/* 409 */         .getClass())
/* 410 */         this.handler.channel((HttpClientOperations)connection); 
/*     */     }
/*     */   }
/*     */   
/*     */   static final class HttpIOHandlerObserver
/*     */     implements ConnectionObserver
/*     */   {
/*     */     final MonoSink<Connection> sink;
/*     */     final Context currentContext;
/*     */     final HttpClientConnect.HttpClientHandler handler;
/*     */     
/*     */     HttpIOHandlerObserver(MonoSink<Connection> sink, HttpClientConnect.HttpClientHandler handler) {
/* 422 */       this.sink = sink;
/* 423 */       this.currentContext = Context.of(sink.contextView());
/* 424 */       this.handler = handler;
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/* 429 */       return this.currentContext;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onStateChange(Connection connection, ConnectionObserver.State newState) {
/* 434 */       if (newState == HttpClientState.RESPONSE_RECEIVED) {
/* 435 */         this.sink.success(connection);
/*     */         return;
/*     */       } 
/* 438 */       if ((newState == ConnectionObserver.State.CONFIGURED || newState == HttpClientState.STREAM_CONFIGURED) && HttpClientOperations.class == connection
/* 439 */         .getClass()) {
/* 440 */         if (HttpClientConnect.log.isDebugEnabled()) {
/* 441 */           HttpClientConnect.log.debug(ReactorNetty.format(connection.channel(), "Handler is being applied: {}"), new Object[] { this.handler });
/*     */         }
/*     */         
/* 444 */         Mono.defer(() -> Mono.fromDirect(this.handler.requestWithBody((HttpClientOperations)connection)))
/* 445 */           .subscribe(connection.disposeSubscriber());
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class HttpClientHandler
/*     */     extends SocketAddress
/*     */     implements Predicate<Throwable>, Supplier<SocketAddress>
/*     */   {
/*     */     volatile HttpMethod method;
/*     */     
/*     */     final HttpHeaders defaultHeaders;
/*     */     
/*     */     final BiFunction<? super HttpClientRequest, ? super NettyOutbound, ? extends Publisher<Void>> handler;
/*     */     
/*     */     final boolean compress;
/*     */     final UriEndpointFactory uriEndpointFactory;
/*     */     final WebsocketClientSpec websocketClientSpec;
/*     */     final BiPredicate<HttpClientRequest, HttpClientResponse> followRedirectPredicate;
/*     */     final BiConsumer<HttpHeaders, HttpClientRequest> redirectRequestBiConsumer;
/*     */     final Consumer<HttpClientRequest> redirectRequestConsumer;
/*     */     final HttpResponseDecoderSpec decoder;
/*     */     final ProxyProvider proxyProvider;
/*     */     final Duration responseTimeout;
/*     */     volatile UriEndpoint toURI;
/*     */     volatile String resourceUrl;
/*     */     volatile UriEndpoint fromURI;
/*     */     volatile Supplier<String>[] redirectedFrom;
/*     */     volatile boolean shouldRetry;
/*     */     volatile HttpHeaders previousRequestHeaders;
/*     */     
/*     */     HttpClientHandler(HttpClientConfig configuration) {
/* 478 */       this.method = configuration.method;
/* 479 */       this.compress = configuration.acceptGzip;
/* 480 */       this.followRedirectPredicate = configuration.followRedirectPredicate;
/* 481 */       this.redirectRequestBiConsumer = configuration.redirectRequestBiConsumer;
/* 482 */       this.redirectRequestConsumer = configuration.redirectRequestConsumer;
/* 483 */       this.decoder = configuration.decoder;
/* 484 */       this.proxyProvider = configuration.proxyProvider();
/* 485 */       this.responseTimeout = configuration.responseTimeout;
/* 486 */       this.defaultHeaders = configuration.headers;
/*     */       
/* 488 */       String baseUrl = configuration.baseUrl;
/*     */       
/* 490 */       this
/* 491 */         .uriEndpointFactory = new UriEndpointFactory(configuration.remoteAddress(), configuration.isSecure(), HttpClientConnect.URI_ADDRESS_MAPPER);
/*     */       
/* 493 */       this.websocketClientSpec = configuration.websocketClientSpec;
/* 494 */       this.shouldRetry = !configuration.retryDisabled;
/* 495 */       this.handler = configuration.body;
/*     */       
/* 497 */       if (configuration.uri == null) {
/* 498 */         String uri = configuration.uriStr;
/*     */         
/* 500 */         uri = (uri == null) ? "/" : uri;
/*     */         
/* 502 */         if (baseUrl != null && uri.startsWith("/")) {
/* 503 */           if (baseUrl.endsWith("/")) {
/* 504 */             baseUrl = baseUrl.substring(0, baseUrl.length() - 1);
/*     */           }
/* 506 */           uri = baseUrl + uri;
/*     */         } 
/*     */         
/* 509 */         this.toURI = this.uriEndpointFactory.createUriEndpoint(uri, (configuration.websocketClientSpec != null));
/*     */       } else {
/*     */         
/* 512 */         this.toURI = this.uriEndpointFactory.createUriEndpoint(configuration.uri, (configuration.websocketClientSpec != null));
/*     */       } 
/* 514 */       this.resourceUrl = this.toURI.toExternalForm();
/*     */     }
/*     */ 
/*     */     
/*     */     public SocketAddress get() {
/* 519 */       SocketAddress address = this.toURI.getRemoteAddress();
/* 520 */       if (this.proxyProvider != null && !this.proxyProvider.shouldProxy(address) && address instanceof InetSocketAddress) {
/* 521 */         address = AddressUtils.replaceWithResolved((InetSocketAddress)address);
/*     */       }
/*     */       
/* 524 */       return address;
/*     */     }
/*     */     
/*     */     Publisher<Void> requestWithBody(HttpClientOperations ch) {
/*     */       try {
/* 529 */         ch.resourceUrl = this.resourceUrl;
/* 530 */         ch.responseTimeout = this.responseTimeout;
/*     */         
/* 532 */         UriEndpoint uri = this.toURI;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 537 */         HttpHeaders headers = ch.getNettyRequest().setUri(uri.getPathAndQuery()).setMethod(this.method).setProtocolVersion(HttpVersion.HTTP_1_1).headers();
/*     */         
/* 539 */         ch.path = HttpOperations.resolvePath(ch.uri());
/*     */         
/* 541 */         if (!this.defaultHeaders.isEmpty()) {
/* 542 */           headers.set(this.defaultHeaders);
/*     */         }
/*     */         
/* 545 */         if (!headers.contains((CharSequence)HttpHeaderNames.USER_AGENT)) {
/* 546 */           headers.set((CharSequence)HttpHeaderNames.USER_AGENT, HttpClient.USER_AGENT);
/*     */         }
/*     */         
/* 549 */         SocketAddress remoteAddress = uri.getRemoteAddress();
/* 550 */         if (!headers.contains((CharSequence)HttpHeaderNames.HOST)) {
/* 551 */           headers.set((CharSequence)HttpHeaderNames.HOST, resolveHostHeaderValue(remoteAddress));
/*     */         }
/*     */         
/* 554 */         if (!headers.contains((CharSequence)HttpHeaderNames.ACCEPT)) {
/* 555 */           headers.set((CharSequence)HttpHeaderNames.ACCEPT, HttpClientConnect.ALL);
/*     */         }
/*     */         
/* 558 */         ch.followRedirectPredicate(this.followRedirectPredicate);
/*     */         
/* 560 */         if (!Objects.equals(this.method, HttpMethod.GET) && 
/* 561 */           !Objects.equals(this.method, HttpMethod.HEAD) && 
/* 562 */           !Objects.equals(this.method, HttpMethod.DELETE) && 
/* 563 */           !headers.contains((CharSequence)HttpHeaderNames.CONTENT_LENGTH)) {
/* 564 */           ch.chunkedTransfer(true);
/*     */         }
/*     */         
/* 567 */         ch.listener().onStateChange((Connection)ch, HttpClientState.REQUEST_PREPARED);
/* 568 */         if (this.websocketClientSpec != null) {
/*     */           
/* 570 */           Mono<Void> result = Mono.fromRunnable(() -> ch.withWebsocketSupport(this.websocketClientSpec, this.compress));
/* 571 */           if (this.handler != null) {
/* 572 */             result = result.thenEmpty((Publisher)Mono.fromRunnable(() -> Flux.concat(new Publisher[] { this.handler.apply(ch, ch) })));
/*     */           }
/* 574 */           return (Publisher<Void>)result;
/*     */         } 
/*     */         
/* 577 */         Consumer<HttpClientRequest> consumer = null;
/* 578 */         if (this.fromURI != null && !this.toURI.equals(this.fromURI)) {
/* 579 */           if (this.handler instanceof HttpClient.RedirectSendHandler) {
/* 580 */             headers.remove((CharSequence)HttpHeaderNames.EXPECT)
/* 581 */               .remove((CharSequence)HttpHeaderNames.COOKIE)
/* 582 */               .remove((CharSequence)HttpHeaderNames.AUTHORIZATION)
/* 583 */               .remove((CharSequence)HttpHeaderNames.PROXY_AUTHORIZATION);
/*     */           } else {
/*     */             
/* 586 */             consumer = (request -> request.requestHeaders().remove((CharSequence)HttpHeaderNames.EXPECT).remove((CharSequence)HttpHeaderNames.COOKIE).remove((CharSequence)HttpHeaderNames.AUTHORIZATION).remove((CharSequence)HttpHeaderNames.PROXY_AUTHORIZATION));
/*     */           } 
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 594 */         if (this.redirectRequestConsumer != null) {
/* 595 */           consumer = (consumer != null) ? consumer.andThen(this.redirectRequestConsumer) : this.redirectRequestConsumer;
/*     */         }
/*     */         
/* 598 */         if (this.redirectRequestBiConsumer != null) {
/* 599 */           ch.previousRequestHeaders = this.previousRequestHeaders;
/* 600 */           ch.redirectRequestBiConsumer = this.redirectRequestBiConsumer;
/*     */         } 
/*     */         
/* 603 */         ch.redirectRequestConsumer(consumer);
/* 604 */         return (this.handler != null) ? this.handler.apply(ch, ch) : (Publisher<Void>)ch.send();
/*     */       }
/* 606 */       catch (Throwable t) {
/* 607 */         return (Publisher<Void>)Mono.error(t);
/*     */       } 
/*     */     }
/*     */     
/*     */     static String resolveHostHeaderValue(@Nullable SocketAddress remoteAddress) {
/* 612 */       if (remoteAddress instanceof InetSocketAddress) {
/* 613 */         InetSocketAddress address = (InetSocketAddress)remoteAddress;
/* 614 */         String host = HttpUtil.formatHostnameForHttp(address);
/* 615 */         int port = address.getPort();
/* 616 */         if (port != 80 && port != 443) {
/* 617 */           host = host + ':' + port;
/*     */         }
/* 619 */         return host;
/*     */       } 
/*     */       
/* 622 */       return "localhost";
/*     */     }
/*     */     
/*     */     void redirect(String to) {
/*     */       UriEndpoint toURITemp;
/* 627 */       Supplier<String>[] redirectedFrom = this.redirectedFrom;
/*     */       
/* 629 */       UriEndpoint from = this.toURI;
/* 630 */       SocketAddress address = from.getRemoteAddress();
/* 631 */       if (address instanceof InetSocketAddress) {
/*     */         try {
/* 633 */           URI redirectUri = new URI(to);
/* 634 */           if (!redirectUri.isAbsolute()) {
/* 635 */             URI requestUri = new URI(this.resourceUrl);
/* 636 */             redirectUri = requestUri.resolve(redirectUri);
/*     */           } 
/* 638 */           toURITemp = this.uriEndpointFactory.createUriEndpoint(redirectUri, from.isWs());
/*     */         }
/* 640 */         catch (URISyntaxException e) {
/* 641 */           throw new IllegalArgumentException("Cannot resolve location header", e);
/*     */         } 
/*     */       } else {
/*     */         
/* 645 */         toURITemp = this.uriEndpointFactory.createUriEndpoint(from, to, () -> address);
/*     */       } 
/* 647 */       this.fromURI = from;
/* 648 */       this.toURI = toURITemp;
/* 649 */       this.resourceUrl = toURITemp.toExternalForm();
/* 650 */       this.redirectedFrom = addToRedirectedFromArray(redirectedFrom, from);
/*     */     }
/*     */ 
/*     */     
/*     */     static Supplier<String>[] addToRedirectedFromArray(@Nullable Supplier<String>[] redirectedFrom, UriEndpoint from) {
/* 655 */       Objects.requireNonNull(from); Supplier<String> fromUrlSupplier = from::toExternalForm;
/* 656 */       if (redirectedFrom == null) {
/* 657 */         return (Supplier<String>[])new Supplier[] { fromUrlSupplier };
/*     */       }
/*     */       
/* 660 */       Supplier[] arrayOfSupplier = new Supplier[redirectedFrom.length + 1];
/* 661 */       System.arraycopy(redirectedFrom, 0, arrayOfSupplier, 0, redirectedFrom.length);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 666 */       arrayOfSupplier[redirectedFrom.length] = fromUrlSupplier;
/* 667 */       return (Supplier<String>[])arrayOfSupplier;
/*     */     }
/*     */ 
/*     */     
/*     */     void channel(HttpClientOperations ops) {
/* 672 */       Supplier<String>[] redirectedFrom = this.redirectedFrom;
/* 673 */       if (redirectedFrom != null) {
/* 674 */         ops.redirectedFrom = redirectedFrom;
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean test(Throwable throwable) {
/* 680 */       if (throwable instanceof RedirectClientException) {
/* 681 */         RedirectClientException re = (RedirectClientException)throwable;
/* 682 */         if (HttpResponseStatus.SEE_OTHER.equals(re.status)) {
/* 683 */           this.method = HttpMethod.GET;
/*     */         }
/* 685 */         redirect(re.location);
/* 686 */         return true;
/*     */       } 
/* 688 */       if (this.shouldRetry && AbortedException.isConnectionReset(throwable)) {
/* 689 */         this.shouldRetry = false;
/* 690 */         redirect(this.toURI.toString());
/* 691 */         return true;
/*     */       } 
/* 693 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 698 */       return "{uri=" + this.toURI + ", method=" + this.method + '}';
/*     */     }
/*     */   }
/*     */   
/* 702 */   static final AsciiString ALL = new AsciiString("*/*");
/*     */   
/* 704 */   static final int DEFAULT_PORT = (System.getenv("PORT") != null) ? Integer.parseInt(System.getenv("PORT")) : 80;
/*     */   
/* 706 */   static final Logger log = Loggers.getLogger(HttpClientConnect.class);
/*     */   
/* 708 */   static final BiFunction<String, Integer, InetSocketAddress> URI_ADDRESS_MAPPER = AddressUtils::createUnresolved;
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\client\HttpClientConnect.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */