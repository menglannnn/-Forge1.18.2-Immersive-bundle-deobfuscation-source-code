/*     */ package reactor.netty.http.client;
/*     */ 
/*     */ import io.netty.buffer.ByteBufAllocator;
/*     */ import io.netty.channel.ChannelOption;
/*     */ import java.net.URI;
/*     */ import java.util.Objects;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.Function;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.core.publisher.SignalType;
/*     */ import reactor.netty.ByteBufFlux;
/*     */ import reactor.netty.Connection;
/*     */ import reactor.netty.NettyOutbound;
/*     */ import reactor.netty.channel.ChannelOperations;
/*     */ import reactor.netty.http.websocket.WebsocketInbound;
/*     */ import reactor.netty.http.websocket.WebsocketOutbound;
/*     */ import reactor.netty.transport.Transport;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class WebsocketFinalizer
/*     */   extends HttpClientConnect
/*     */   implements HttpClient.WebsocketSender
/*     */ {
/*     */   WebsocketFinalizer(HttpClientConfig config) {
/*  46 */     super(config);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpClient.WebsocketSender uri(Mono<String> uri) {
/*  53 */     Objects.requireNonNull(uri, "uri");
/*  54 */     HttpClient dup = duplicate();
/*  55 */     ((HttpClientConfig)dup.configuration()).deferredConf(config -> uri.map(()));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  60 */     return (WebsocketFinalizer)dup;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpClient.WebsocketSender uri(String uri) {
/*  65 */     Objects.requireNonNull(uri, "uri");
/*  66 */     HttpClient dup = duplicate();
/*  67 */     ((HttpClientConfig)dup.configuration()).uriStr = uri;
/*  68 */     ((HttpClientConfig)dup.configuration()).uri = null;
/*  69 */     return (WebsocketFinalizer)dup;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpClient.WebsocketSender uri(URI uri) {
/*  74 */     Objects.requireNonNull(uri, "uri");
/*  75 */     if (!uri.isAbsolute()) {
/*  76 */       throw new IllegalArgumentException("URI is not absolute: " + uri);
/*     */     }
/*  78 */     HttpClient dup = duplicate();
/*  79 */     ((HttpClientConfig)dup.configuration()).uriStr = null;
/*  80 */     ((HttpClientConfig)dup.configuration()).uri = uri;
/*  81 */     return (WebsocketFinalizer)dup;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebsocketFinalizer send(Function<? super HttpClientRequest, ? extends Publisher<Void>> sender) {
/*  88 */     Objects.requireNonNull(sender, "requestBody");
/*  89 */     HttpClient dup = duplicate();
/*  90 */     ((HttpClientConfig)dup.configuration()).body = ((req, out) -> (Publisher)sender.apply(req));
/*  91 */     return (WebsocketFinalizer)dup;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<? extends Connection> connect() {
/*  98 */     return super.connect();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <V> Flux<V> handle(BiFunction<? super WebsocketInbound, ? super WebsocketOutbound, ? extends Publisher<V>> receiver) {
/* 104 */     Mono<WebsocketClientOperations> connector = (Mono)connect();
/* 105 */     return connector.flatMapMany(c -> Flux.from(receiver.apply(c, c)).doFinally(()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ByteBufFlux receive() {
/* 112 */     ByteBufAllocator alloc = (ByteBufAllocator)configuration().options().get(ChannelOption.ALLOCATOR);
/* 113 */     if (alloc == null) {
/* 114 */       alloc = ByteBufAllocator.DEFAULT;
/*     */     }
/*     */ 
/*     */     
/* 118 */     Mono<ChannelOperations<?, ?>> connector = (Mono)connect();
/* 119 */     return ByteBufFlux.fromInbound((Publisher)connector.flatMapMany(HttpClientFinalizer.contentReceiver), alloc);
/*     */   }
/*     */ 
/*     */   
/*     */   protected HttpClient duplicate() {
/* 124 */     return new WebsocketFinalizer(new HttpClientConfig(this.config));
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\client\WebsocketFinalizer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */