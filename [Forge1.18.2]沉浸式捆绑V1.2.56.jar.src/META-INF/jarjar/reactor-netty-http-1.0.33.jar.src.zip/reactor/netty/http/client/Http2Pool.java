/*      */ package reactor.netty.http.client;
/*      */ 
/*      */ import io.netty.channel.ChannelHandlerContext;
/*      */ import io.netty.handler.codec.http2.Http2FrameCodec;
/*      */ import io.netty.handler.codec.http2.Http2MultiplexHandler;
/*      */ import io.netty.handler.ssl.SslHandler;
/*      */ import io.netty.util.concurrent.Future;
/*      */ import java.time.Clock;
/*      */ import java.time.Duration;
/*      */ import java.util.Iterator;
/*      */ import java.util.Objects;
/*      */ import java.util.concurrent.ConcurrentLinkedDeque;
/*      */ import java.util.concurrent.ConcurrentLinkedQueue;
/*      */ import java.util.concurrent.TimeUnit;
/*      */ import java.util.concurrent.atomic.AtomicBoolean;
/*      */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*      */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*      */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*      */ import java.util.function.Function;
/*      */ import org.reactivestreams.Publisher;
/*      */ import org.reactivestreams.Subscription;
/*      */ import reactor.core.CoreSubscriber;
/*      */ import reactor.core.Disposable;
/*      */ import reactor.core.Disposables;
/*      */ import reactor.core.Scannable;
/*      */ import reactor.core.publisher.Mono;
/*      */ import reactor.core.publisher.Operators;
/*      */ import reactor.core.publisher.Signal;
/*      */ import reactor.core.publisher.SignalType;
/*      */ import reactor.netty.Connection;
/*      */ import reactor.netty.FutureMono;
/*      */ import reactor.netty.ReactorNetty;
/*      */ import reactor.netty.internal.shaded.reactor.pool.InstrumentedPool;
/*      */ import reactor.netty.internal.shaded.reactor.pool.PoolAcquirePendingLimitException;
/*      */ import reactor.netty.internal.shaded.reactor.pool.PoolAcquireTimeoutException;
/*      */ import reactor.netty.internal.shaded.reactor.pool.PoolConfig;
/*      */ import reactor.netty.internal.shaded.reactor.pool.PoolShutdownException;
/*      */ import reactor.netty.internal.shaded.reactor.pool.PooledRef;
/*      */ import reactor.netty.internal.shaded.reactor.pool.PooledRefMetadata;
/*      */ import reactor.netty.resources.ConnectionProvider;
/*      */ import reactor.util.Logger;
/*      */ import reactor.util.Loggers;
/*      */ import reactor.util.annotation.Nullable;
/*      */ import reactor.util.context.Context;
/*      */ import reactor.util.context.ContextView;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ final class Http2Pool
/*      */   implements InstrumentedPool<Connection>, InstrumentedPool.PoolMetrics
/*      */ {
/*  111 */   static final Logger log = Loggers.getLogger(Http2Pool.class);
/*      */   
/*      */   volatile int acquired;
/*      */   
/*  115 */   static final AtomicIntegerFieldUpdater<Http2Pool> ACQUIRED = AtomicIntegerFieldUpdater.newUpdater(Http2Pool.class, "acquired");
/*      */ 
/*      */   
/*      */   volatile ConcurrentLinkedQueue<Slot> connections;
/*      */   
/*  120 */   static final AtomicReferenceFieldUpdater<Http2Pool, ConcurrentLinkedQueue> CONNECTIONS = AtomicReferenceFieldUpdater.newUpdater(Http2Pool.class, ConcurrentLinkedQueue.class, "connections");
/*      */   
/*      */   volatile int idleSize;
/*      */   
/*  124 */   private static final AtomicIntegerFieldUpdater<Http2Pool> IDLE_SIZE = AtomicIntegerFieldUpdater.newUpdater(Http2Pool.class, "idleSize");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   volatile ConcurrentLinkedDeque<Borrower> pending;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  138 */   static final AtomicReferenceFieldUpdater<Http2Pool, ConcurrentLinkedDeque> PENDING = AtomicReferenceFieldUpdater.newUpdater(Http2Pool.class, ConcurrentLinkedDeque.class, "pending");
/*      */   
/*      */   volatile int pendingSize;
/*      */   
/*  142 */   private static final AtomicIntegerFieldUpdater<Http2Pool> PENDING_SIZE = AtomicIntegerFieldUpdater.newUpdater(Http2Pool.class, "pendingSize");
/*      */ 
/*      */   
/*  145 */   static final ConcurrentLinkedDeque TERMINATED = new ConcurrentLinkedDeque();
/*      */   
/*      */   volatile long totalMaxConcurrentStreams;
/*      */   
/*  149 */   static final AtomicLongFieldUpdater<Http2Pool> TOTAL_MAX_CONCURRENT_STREAMS = AtomicLongFieldUpdater.newUpdater(Http2Pool.class, "totalMaxConcurrentStreams");
/*      */   
/*      */   volatile int wip;
/*      */   
/*  153 */   static final AtomicIntegerFieldUpdater<Http2Pool> WIP = AtomicIntegerFieldUpdater.newUpdater(Http2Pool.class, "wip");
/*      */   
/*      */   final Clock clock;
/*      */   
/*      */   final Long maxConcurrentStreams;
/*      */   final int minConnections;
/*      */   final PoolConfig<Connection> poolConfig;
/*      */   long lastInteractionTimestamp;
/*      */   Disposable evictionTask;
/*      */   static final Function<Connection, Publisher<Void>> DEFAULT_DESTROY_HANDLER;
/*      */   
/*      */   Http2Pool(PoolConfig<Connection> poolConfig, @Nullable ConnectionProvider.AllocationStrategy<?> allocationStrategy) {
/*  165 */     this.clock = poolConfig.clock();
/*  166 */     this.connections = new ConcurrentLinkedQueue<>();
/*  167 */     this.lastInteractionTimestamp = this.clock.millis();
/*  168 */     this.maxConcurrentStreams = Long.valueOf((allocationStrategy instanceof Http2AllocationStrategy) ? (
/*  169 */         (Http2AllocationStrategy)allocationStrategy).maxConcurrentStreams() : -1L);
/*  170 */     this.minConnections = (allocationStrategy == null) ? 0 : allocationStrategy.permitMinimum();
/*  171 */     this.pending = new ConcurrentLinkedDeque<>();
/*  172 */     this.poolConfig = poolConfig;
/*      */     
/*  174 */     recordInteractionTimestamp();
/*  175 */     scheduleEviction();
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<PooledRef<Connection>> acquire() {
/*  180 */     return new BorrowerMono(this, Duration.ZERO);
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<PooledRef<Connection>> acquire(Duration timeout) {
/*  185 */     return new BorrowerMono(this, timeout);
/*      */   }
/*      */ 
/*      */   
/*      */   public int acquiredSize() {
/*  190 */     return allocatedSize() - idleSize();
/*      */   }
/*      */ 
/*      */   
/*      */   public int allocatedSize() {
/*  195 */     return this.poolConfig.allocationStrategy().permitGranted();
/*      */   }
/*      */ 
/*      */   
/*      */   public PoolConfig<Connection> config() {
/*  200 */     return this.poolConfig;
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<Void> disposeLater() {
/*  205 */     return Mono.defer(() -> {
/*      */           recordInteractionTimestamp();
/*      */           ConcurrentLinkedDeque<Borrower> q = PENDING.getAndSet(this, TERMINATED);
/*      */           if (q != TERMINATED) {
/*      */             this.evictionTask.dispose();
/*      */             Borrower p;
/*      */             while ((p = pollPending(q, true)) != null) {
/*      */               p.fail((Throwable)new PoolShutdownException());
/*      */             }
/*      */             ConcurrentLinkedQueue<Slot> slots = CONNECTIONS.getAndSet(this, null);
/*      */             if (slots != null) {
/*      */               Mono<Void> closeMonos = Mono.empty();
/*      */               while (!slots.isEmpty()) {
/*      */                 Slot slot = pollSlot(slots);
/*      */                 if (slot != null) {
/*      */                   slot.invalidate();
/*      */                   closeMonos = closeMonos.and(DEFAULT_DESTROY_HANDLER.apply(slot.connection));
/*      */                 } 
/*      */               } 
/*      */               return closeMonos;
/*      */             } 
/*      */           } 
/*      */           return Mono.empty();
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMaxAllocatedSize() {
/*  238 */     return Integer.MAX_VALUE;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getMaxPendingAcquireSize() {
/*  243 */     return (this.poolConfig.maxPending() < 0) ? Integer.MAX_VALUE : this.poolConfig.maxPending();
/*      */   }
/*      */ 
/*      */   
/*      */   public int idleSize() {
/*  248 */     return this.idleSize;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isDisposed() {
/*  253 */     return (PENDING.get(this) == TERMINATED || CONNECTIONS.get(this) == null);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isInactiveForMoreThan(Duration duration) {
/*  258 */     return (pendingAcquireSize() == 0 && allocatedSize() == 0 && 
/*  259 */       secondsSinceLastInteraction() >= duration.getSeconds());
/*      */   }
/*      */ 
/*      */   
/*      */   public InstrumentedPool.PoolMetrics metrics() {
/*  264 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public int pendingAcquireSize() {
/*  269 */     return this.pendingSize;
/*      */   }
/*      */ 
/*      */   
/*      */   public long secondsSinceLastInteraction() {
/*  274 */     long sinceMs = this.clock.millis() - this.lastInteractionTimestamp;
/*  275 */     return sinceMs / 1000L;
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<Integer> warmup() {
/*  280 */     return Mono.just(Integer.valueOf(0));
/*      */   }
/*      */   
/*      */   int activeStreams() {
/*  284 */     return this.acquired;
/*      */   }
/*      */   
/*      */   void cancelAcquire(Borrower borrower) {
/*  288 */     if (!isDisposed()) {
/*  289 */       ConcurrentLinkedDeque<Borrower> q = this.pending;
/*  290 */       removePending(q, borrower);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   Mono<Void> destroyPoolable(Http2PooledRef ref) {
/*  296 */     assert ref.slot.connection.channel().eventLoop().inEventLoop();
/*  297 */     Mono<Void> mono = Mono.empty();
/*      */     
/*      */     try {
/*  300 */       if (ref.slot.decrementConcurrencyAndGet() == 0)
/*      */       {
/*  302 */         if (ref.slot.http2FrameCodecCtx() == null) {
/*  303 */           ref.slot.invalidate();
/*  304 */           removeSlot(ref.slot);
/*      */         
/*      */         }
/*  307 */         else if (this.poolConfig.evictInBackgroundInterval().isZero()) {
/*      */           
/*  309 */           if (!ref.poolable().channel().isActive()) {
/*  310 */             ref.slot.invalidate();
/*  311 */             removeSlot(ref.slot);
/*      */           } 
/*      */           
/*  314 */           if (ref.slot.goAwayReceived()) {
/*  315 */             ref.slot.invalidate();
/*  316 */             removeSlot(ref.slot);
/*      */           
/*      */           }
/*  319 */           else if (testEvictionPredicate(ref.slot)) {
/*      */             
/*  321 */             ref.slot.connection.channel().close();
/*  322 */             ref.slot.invalidate();
/*  323 */             removeSlot(ref.slot);
/*      */           }
/*      */         
/*      */         } 
/*      */       }
/*  328 */     } catch (Throwable destroyFunctionError) {
/*  329 */       mono = Mono.error(destroyFunctionError);
/*      */     } 
/*  331 */     return mono;
/*      */   }
/*      */   
/*      */   void doAcquire(Borrower borrower) {
/*  335 */     if (isDisposed()) {
/*  336 */       borrower.fail((Throwable)new PoolShutdownException());
/*      */       
/*      */       return;
/*      */     } 
/*  340 */     pendingOffer(borrower);
/*  341 */     drain();
/*      */   }
/*      */   
/*      */   void drain() {
/*  345 */     if (WIP.getAndIncrement(this) == 0) {
/*  346 */       drainLoop();
/*      */     }
/*      */   }
/*      */   
/*      */   void drainLoop() {
/*  351 */     recordInteractionTimestamp();
/*  352 */     int maxPending = this.poolConfig.maxPending();
/*      */ 
/*      */     
/*      */     while (true) {
/*  356 */       ConcurrentLinkedQueue<Slot> resources = CONNECTIONS.get(this);
/*      */       
/*  358 */       ConcurrentLinkedDeque<Borrower> borrowers = PENDING.get(this);
/*  359 */       if (resources == null || borrowers == TERMINATED) {
/*      */         return;
/*      */       }
/*      */       
/*  363 */       int borrowersCount = this.pendingSize;
/*      */       
/*  365 */       if (borrowersCount != 0) {
/*      */ 
/*      */ 
/*      */         
/*  369 */         boolean belowMinConnections = (this.minConnections > 0 && this.poolConfig.allocationStrategy().permitGranted() < this.minConnections);
/*  370 */         Slot slot = belowMinConnections ? null : findConnection(resources);
/*  371 */         if (slot != null) {
/*  372 */           Borrower borrower = pollPending(borrowers, true);
/*  373 */           if (borrower == null) {
/*  374 */             offerSlot(resources, slot);
/*      */             continue;
/*      */           } 
/*  377 */           if (isDisposed()) {
/*  378 */             borrower.fail((Throwable)new PoolShutdownException());
/*      */             return;
/*      */           } 
/*  381 */           borrower.stopPendingCountdown();
/*  382 */           if (log.isDebugEnabled()) {
/*  383 */             log.debug(ReactorNetty.format(slot.connection.channel(), "Channel activated"));
/*      */           }
/*  385 */           ACQUIRED.incrementAndGet(this);
/*  386 */           slot.connection.channel().eventLoop().execute(() -> {
/*      */                 borrower.deliver(new Http2PooledRef(slot));
/*      */                 
/*      */                 drain();
/*      */               });
/*      */         } else {
/*  392 */           int resourcesCount = this.idleSize;
/*  393 */           if (this.minConnections <= 0 || this.poolConfig
/*  394 */             .allocationStrategy().permitGranted() < this.minConnections || resourcesCount != 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  399 */             int permits = this.poolConfig.allocationStrategy().getPermits(1);
/*  400 */             if (permits <= 0) {
/*  401 */               if (maxPending >= 0) {
/*  402 */                 borrowersCount = this.pendingSize;
/*  403 */                 int toCull = borrowersCount - maxPending;
/*  404 */                 for (int i = 0; i < toCull; i++) {
/*  405 */                   Borrower extraneous = pollPending(borrowers, true);
/*  406 */                   if (extraneous != null) {
/*  407 */                     pendingAcquireLimitReached(extraneous, maxPending);
/*      */                   }
/*      */                 } 
/*      */               } 
/*      */             } else {
/*      */               
/*  413 */               if (permits > 1)
/*      */               {
/*  415 */                 this.poolConfig.allocationStrategy().returnPermits(permits - 1);
/*      */               }
/*  417 */               Borrower borrower = pollPending(borrowers, true);
/*  418 */               if (borrower == null) {
/*      */                 continue;
/*      */               }
/*  421 */               if (isDisposed()) {
/*  422 */                 borrower.fail((Throwable)new PoolShutdownException());
/*      */                 return;
/*      */               } 
/*  425 */               borrower.stopPendingCountdown();
/*  426 */               Mono<Connection> allocator = this.poolConfig.allocator();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*  446 */               Mono<Connection> primary = allocator.doOnEach(sig -> { if (sig.isOnNext()) { Connection newInstance = (Connection)sig.get(); assert newInstance != null; Slot newSlot = new Slot(this, newInstance); if (log.isDebugEnabled()) log.debug(ReactorNetty.format(newInstance.channel(), "Channel activated"));  ACQUIRED.incrementAndGet(this); borrower.deliver(new Http2PooledRef(newSlot)); } else if (sig.isOnError()) { Throwable error = sig.getThrowable(); assert error != null; this.poolConfig.allocationStrategy().returnPermits(1); borrower.fail(error); }  }).contextWrite((ContextView)borrower.currentContext());
/*      */               
/*  448 */               primary.subscribe(alreadyPropagated -> {  }alreadyPropagatedOrLogged -> drain(), this::drain);
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       
/*  454 */       if (WIP.decrementAndGet(this) == 0) {
/*  455 */         recordInteractionTimestamp();
/*      */         return;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void evictInBackground() {
/*  464 */     ConcurrentLinkedQueue<Slot> resources = CONNECTIONS.get(this);
/*  465 */     if (resources == null) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  470 */     if (WIP.getAndIncrement(this) == 0) {
/*  471 */       if (this.pendingSize == 0) {
/*  472 */         Iterator<Slot> slots = resources.iterator();
/*  473 */         while (slots.hasNext()) {
/*  474 */           Slot slot = slots.next();
/*  475 */           if (slot.concurrency() == 0) {
/*  476 */             if (!slot.connection.channel().isActive()) {
/*  477 */               if (log.isDebugEnabled()) {
/*  478 */                 log.debug(ReactorNetty.format(slot.connection.channel(), "Channel is closed, remove from pool"));
/*      */               }
/*  480 */               recordInteractionTimestamp();
/*  481 */               slots.remove();
/*  482 */               IDLE_SIZE.decrementAndGet(this);
/*  483 */               slot.invalidate();
/*      */               
/*      */               continue;
/*      */             } 
/*  487 */             if (slot.goAwayReceived()) {
/*  488 */               if (log.isDebugEnabled()) {
/*  489 */                 log.debug(ReactorNetty.format(slot.connection.channel(), "Channel received GO_AWAY, remove from pool"));
/*      */               }
/*  491 */               recordInteractionTimestamp();
/*  492 */               slots.remove();
/*  493 */               IDLE_SIZE.decrementAndGet(this);
/*  494 */               slot.invalidate();
/*      */               
/*      */               continue;
/*      */             } 
/*  498 */             if (testEvictionPredicate(slot)) {
/*  499 */               if (log.isDebugEnabled()) {
/*  500 */                 log.debug(ReactorNetty.format(slot.connection.channel(), "Eviction predicate was true, remove from pool"));
/*      */               }
/*      */               
/*  503 */               slot.connection.channel().close();
/*  504 */               recordInteractionTimestamp();
/*  505 */               slots.remove();
/*  506 */               IDLE_SIZE.decrementAndGet(this);
/*  507 */               slot.invalidate();
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       
/*  513 */       if (WIP.decrementAndGet(this) > 0) {
/*  514 */         drainLoop();
/*      */       }
/*      */     } 
/*      */     
/*  518 */     scheduleEviction();
/*      */   }
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   Slot findConnection(ConcurrentLinkedQueue<Slot> resources) {
/*  524 */     int resourcesCount = this.idleSize;
/*  525 */     while (resourcesCount > 0) {
/*      */ 
/*      */       
/*  528 */       resourcesCount--;
/*      */ 
/*      */       
/*  531 */       Slot slot = pollSlot(resources);
/*  532 */       if (slot == null) {
/*      */         continue;
/*      */       }
/*      */ 
/*      */       
/*  537 */       if (!slot.connection.channel().isActive()) {
/*  538 */         if (slot.concurrency() > 0) {
/*  539 */           if (log.isDebugEnabled())
/*  540 */             log.debug(ReactorNetty.format(slot.connection.channel(), "Channel is closed, {} active streams"), new Object[] {
/*  541 */                   Integer.valueOf(slot.concurrency())
/*      */                 }); 
/*  543 */           offerSlot(resources, slot);
/*      */           continue;
/*      */         } 
/*  546 */         if (log.isDebugEnabled()) {
/*  547 */           log.debug(ReactorNetty.format(slot.connection.channel(), "Channel is closed, remove from pool"));
/*      */         }
/*  549 */         slot.invalidate();
/*      */ 
/*      */         
/*      */         continue;
/*      */       } 
/*      */       
/*  555 */       if (slot.goAwayReceived()) {
/*  556 */         if (slot.concurrency() > 0) {
/*  557 */           if (log.isDebugEnabled())
/*  558 */             log.debug(ReactorNetty.format(slot.connection.channel(), "Channel received GO_AWAY, {} active streams"), new Object[] {
/*  559 */                   Integer.valueOf(slot.concurrency())
/*      */                 }); 
/*  561 */           offerSlot(resources, slot);
/*      */           continue;
/*      */         } 
/*  564 */         if (log.isDebugEnabled()) {
/*  565 */           log.debug(ReactorNetty.format(slot.connection.channel(), "Channel received GO_AWAY, remove from pool"));
/*      */         }
/*  567 */         slot.invalidate();
/*      */ 
/*      */         
/*      */         continue;
/*      */       } 
/*      */       
/*  573 */       if (testEvictionPredicate(slot)) {
/*  574 */         if (slot.concurrency() > 0) {
/*  575 */           if (log.isDebugEnabled())
/*  576 */             log.debug(ReactorNetty.format(slot.connection.channel(), "Eviction predicate was true, {} active streams"), new Object[] {
/*  577 */                   Integer.valueOf(slot.concurrency())
/*      */                 }); 
/*  579 */           offerSlot(resources, slot);
/*      */           continue;
/*      */         } 
/*  582 */         if (log.isDebugEnabled()) {
/*  583 */           log.debug(ReactorNetty.format(slot.connection.channel(), "Eviction predicate was true, remove from pool"));
/*      */         }
/*      */         
/*  586 */         slot.connection.channel().close();
/*  587 */         slot.invalidate();
/*      */ 
/*      */         
/*      */         continue;
/*      */       } 
/*      */       
/*  593 */       if (!slot.canOpenStream()) {
/*  594 */         offerSlot(resources, slot);
/*  595 */         if (log.isDebugEnabled()) {
/*  596 */           log.debug(ReactorNetty.format(slot.connection.channel(), "Max active streams is reached"));
/*      */         }
/*      */         
/*      */         continue;
/*      */       } 
/*  601 */       return slot;
/*      */     } 
/*      */     
/*  604 */     return null;
/*      */   }
/*      */   
/*      */   boolean testEvictionPredicate(Slot slot) {
/*  608 */     return this.poolConfig.evictionPredicate().test(slot.connection, slot);
/*      */   }
/*      */   
/*      */   void pendingAcquireLimitReached(Borrower borrower, int maxPending) {
/*  612 */     if (maxPending == 0) {
/*  613 */       borrower.fail((Throwable)new PoolAcquirePendingLimitException(0, "No pending allowed and pool has reached allocation limit"));
/*      */     }
/*      */     else {
/*      */       
/*  617 */       borrower.fail((Throwable)new PoolAcquirePendingLimitException(maxPending));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void pendingOffer(Borrower borrower) {
/*  625 */     int maxPending = this.poolConfig.maxPending();
/*  626 */     ConcurrentLinkedDeque<Borrower> pendingQueue = this.pending;
/*  627 */     if (pendingQueue == TERMINATED) {
/*      */       return;
/*      */     }
/*  630 */     int postOffer = addPending(pendingQueue, borrower, false);
/*      */     
/*  632 */     if (WIP.getAndIncrement(this) == 0) {
/*  633 */       ConcurrentLinkedQueue<Slot> ir = this.connections;
/*  634 */       if (maxPending >= 0 && postOffer > maxPending && ir.isEmpty() && this.poolConfig.allocationStrategy().estimatePermitCount() == 0) {
/*  635 */         Borrower toCull = pollPending(pendingQueue, false);
/*  636 */         if (toCull != null) {
/*  637 */           pendingAcquireLimitReached(toCull, maxPending);
/*      */         }
/*      */         
/*  640 */         if (WIP.decrementAndGet(this) > 0) {
/*  641 */           drainLoop();
/*      */         }
/*      */         
/*      */         return;
/*      */       } 
/*  646 */       drainLoop();
/*      */     } 
/*      */   }
/*      */   
/*      */   void recordInteractionTimestamp() {
/*  651 */     this.lastInteractionTimestamp = this.clock.millis();
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   Borrower pollPending(ConcurrentLinkedDeque<Borrower> borrowers, boolean pollFirst) {
/*  656 */     Borrower borrower = pollFirst ? borrowers.pollFirst() : borrowers.pollLast();
/*  657 */     if (borrower != null) {
/*  658 */       PENDING_SIZE.decrementAndGet(this);
/*      */     }
/*  660 */     return borrower;
/*      */   }
/*      */   
/*      */   void removePending(ConcurrentLinkedDeque<Borrower> borrowers, Borrower borrower) {
/*  664 */     if (borrowers.remove(borrower)) {
/*  665 */       PENDING_SIZE.decrementAndGet(this);
/*      */     }
/*      */   }
/*      */   
/*      */   int addPending(ConcurrentLinkedDeque<Borrower> borrowers, Borrower borrower, boolean first) {
/*  670 */     if (first) {
/*  671 */       borrowers.offerFirst(borrower);
/*      */     } else {
/*      */       
/*  674 */       borrowers.offerLast(borrower);
/*      */     } 
/*  676 */     return PENDING_SIZE.incrementAndGet(this);
/*      */   }
/*      */   
/*      */   void offerSlot(@Nullable ConcurrentLinkedQueue<Slot> slots, Slot slot) {
/*  680 */     if (slots != null && slots.offer(slot)) {
/*  681 */       IDLE_SIZE.incrementAndGet(this);
/*      */     }
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   Slot pollSlot(@Nullable ConcurrentLinkedQueue<Slot> slots) {
/*  687 */     if (slots == null) {
/*  688 */       return null;
/*      */     }
/*  690 */     Slot slot = slots.poll();
/*  691 */     if (slot != null) {
/*  692 */       IDLE_SIZE.decrementAndGet(this);
/*      */     }
/*  694 */     return slot;
/*      */   }
/*      */ 
/*      */   
/*      */   void removeSlot(Slot slot) {
/*  699 */     ConcurrentLinkedQueue<Slot> q = CONNECTIONS.get(slot.pool);
/*  700 */     if (q != null && q.remove(slot)) {
/*  701 */       IDLE_SIZE.decrementAndGet(this);
/*      */     }
/*      */   }
/*      */   
/*      */   void scheduleEviction() {
/*  706 */     if (!this.poolConfig.evictInBackgroundInterval().isZero()) {
/*  707 */       long nanosEvictionInterval = this.poolConfig.evictInBackgroundInterval().toNanos();
/*  708 */       this
/*  709 */         .evictionTask = this.poolConfig.evictInBackgroundScheduler().schedule(this::evictInBackground, nanosEvictionInterval, TimeUnit.NANOSECONDS);
/*      */     } else {
/*      */       
/*  712 */       this.evictionTask = Disposables.disposed();
/*      */     } 
/*      */   }
/*      */   static {
/*  716 */     DEFAULT_DESTROY_HANDLER = (connection -> !connection.channel().isActive() ? Mono.empty() : FutureMono.from((Future)connection.channel().close()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final class Borrower
/*      */     extends AtomicBoolean
/*      */     implements Scannable, Subscription, Runnable
/*      */   {
/*  726 */     static final Disposable TIMEOUT_DISPOSED = Disposables.disposed();
/*      */     
/*      */     final Duration acquireTimeout;
/*      */     
/*      */     final CoreSubscriber<? super Http2Pool.Http2PooledRef> actual;
/*      */     final Http2Pool pool;
/*      */     Disposable timeoutTask;
/*      */     
/*      */     Borrower(CoreSubscriber<? super Http2Pool.Http2PooledRef> actual, Http2Pool pool, Duration acquireTimeout) {
/*  735 */       this.acquireTimeout = acquireTimeout;
/*  736 */       this.actual = actual;
/*  737 */       this.pool = pool;
/*  738 */       this.timeoutTask = TIMEOUT_DISPOSED;
/*      */     }
/*      */ 
/*      */     
/*      */     public void cancel() {
/*  743 */       stopPendingCountdown();
/*  744 */       if (compareAndSet(false, true)) {
/*  745 */         this.pool.cancelAcquire(this);
/*      */       }
/*      */     }
/*      */     
/*      */     Context currentContext() {
/*  750 */       return this.actual.currentContext();
/*      */     }
/*      */ 
/*      */     
/*      */     public void request(long n) {
/*  755 */       if (Operators.validate(n)) {
/*  756 */         long estimateStreamsCount = this.pool.totalMaxConcurrentStreams - this.pool.acquired;
/*  757 */         int permits = this.pool.poolConfig.allocationStrategy().estimatePermitCount();
/*  758 */         int pending = this.pool.pendingSize;
/*  759 */         if (!this.acquireTimeout.isZero() && permits + estimateStreamsCount <= pending) {
/*  760 */           this.timeoutTask = this.pool.poolConfig.pendingAcquireTimer().apply(this, this.acquireTimeout);
/*      */         }
/*  762 */         this.pool.doAcquire(this);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void run() {
/*  768 */       if (compareAndSet(false, true)) {
/*  769 */         this.pool.cancelAcquire(this);
/*  770 */         this.actual.onError((Throwable)new PoolAcquireTimeoutException(this.acquireTimeout));
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     public Object scanUnsafe(Scannable.Attr key) {
/*  778 */       if (key == Scannable.Attr.CANCELLED) {
/*  779 */         return Boolean.valueOf(get());
/*      */       }
/*  781 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) {
/*  782 */         return Integer.valueOf(1);
/*      */       }
/*  784 */       if (key == Scannable.Attr.ACTUAL) {
/*  785 */         return this.actual;
/*      */       }
/*      */       
/*  788 */       return null;
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/*  793 */       return get() ? "Borrower(cancelled)" : "Borrower";
/*      */     }
/*      */     
/*      */     void deliver(Http2Pool.Http2PooledRef poolSlot) {
/*  797 */       assert poolSlot.slot.connection.channel().eventLoop().inEventLoop();
/*  798 */       poolSlot.slot.incrementConcurrencyAndGet();
/*  799 */       poolSlot.slot.deactivate();
/*  800 */       if (get()) {
/*      */         
/*  802 */         poolSlot.invalidate().subscribe(aVoid -> { 
/*      */             }e -> Operators.onErrorDropped(e, Context.empty()));
/*      */       } else {
/*  805 */         this.actual.onNext(poolSlot);
/*  806 */         this.actual.onComplete();
/*      */       } 
/*      */     }
/*      */     
/*      */     void fail(Throwable error) {
/*  811 */       stopPendingCountdown();
/*  812 */       if (!get()) {
/*  813 */         this.actual.onError(error);
/*      */       }
/*      */     }
/*      */     
/*      */     void stopPendingCountdown() {
/*  818 */       this.timeoutTask.dispose();
/*      */     }
/*      */   }
/*      */   
/*      */   static final class BorrowerMono
/*      */     extends Mono<PooledRef<Connection>> {
/*      */     final Duration acquireTimeout;
/*      */     final Http2Pool parent;
/*      */     
/*      */     BorrowerMono(Http2Pool pool, Duration acquireTimeout) {
/*  828 */       this.acquireTimeout = acquireTimeout;
/*  829 */       this.parent = pool;
/*      */     }
/*      */ 
/*      */     
/*      */     public void subscribe(CoreSubscriber<? super PooledRef<Connection>> actual) {
/*  834 */       Objects.requireNonNull(actual, "subscribing with null");
/*  835 */       Http2Pool.Borrower borrower = new Http2Pool.Borrower((CoreSubscriber)actual, this.parent, this.acquireTimeout);
/*  836 */       actual.onSubscribe(borrower);
/*      */     }
/*      */   }
/*      */   
/*      */   static final class Http2PooledRef
/*      */     extends AtomicBoolean implements PooledRef<Connection>, PooledRefMetadata {
/*      */     final int acquireCount;
/*      */     final Http2Pool.Slot slot;
/*      */     
/*      */     Http2PooledRef(Http2Pool.Slot slot) {
/*  846 */       this.acquireCount = 0;
/*  847 */       this.slot = slot;
/*      */     }
/*      */ 
/*      */     
/*      */     public int acquireCount() {
/*  852 */       return 1;
/*      */     }
/*      */ 
/*      */     
/*      */     public long allocationTimestamp() {
/*  857 */       return 0L;
/*      */     }
/*      */ 
/*      */     
/*      */     public long idleTime() {
/*  862 */       return 0L;
/*      */     }
/*      */ 
/*      */     
/*      */     public Mono<Void> invalidate() {
/*  867 */       return Mono.defer(() -> {
/*      */             if (compareAndSet(false, true)) {
/*      */               Http2Pool.ACQUIRED.decrementAndGet(this.slot.pool);
/*      */               return this.slot.pool.destroyPoolable(this).doFinally(());
/*      */             } 
/*      */             return Mono.empty();
/*      */           });
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public long lifeTime() {
/*  880 */       return 0L;
/*      */     }
/*      */ 
/*      */     
/*      */     public PooledRefMetadata metadata() {
/*  885 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public Connection poolable() {
/*  890 */       return this.slot.connection;
/*      */     }
/*      */ 
/*      */     
/*      */     public Mono<Void> release() {
/*  895 */       return invalidate();
/*      */     }
/*      */ 
/*      */     
/*      */     public long releaseTimestamp() {
/*  900 */       return 0L;
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/*  905 */       return "PooledRef{poolable=" + this.slot.connection + '}';
/*      */     }
/*      */   }
/*      */   
/*      */   static final class Slot
/*      */     extends AtomicBoolean
/*      */     implements PooledRefMetadata {
/*      */     volatile int concurrency;
/*  913 */     static final AtomicIntegerFieldUpdater<Slot> CONCURRENCY = AtomicIntegerFieldUpdater.newUpdater(Slot.class, "concurrency");
/*      */     
/*      */     final Connection connection;
/*      */     
/*      */     final long creationTimestamp;
/*      */     
/*      */     final Http2Pool pool;
/*      */     final String applicationProtocol;
/*      */     long idleTimestamp;
/*      */     long maxConcurrentStreams;
/*      */     volatile ChannelHandlerContext http2FrameCodecCtx;
/*      */     volatile ChannelHandlerContext http2MultiplexHandlerCtx;
/*      */     volatile ChannelHandlerContext h2cUpgradeHandlerCtx;
/*      */     
/*      */     Slot(Http2Pool pool, Connection connection) {
/*  928 */       this.connection = connection;
/*  929 */       this.creationTimestamp = pool.clock.millis();
/*  930 */       this.pool = pool;
/*  931 */       SslHandler handler = (SslHandler)connection.channel().pipeline().get(SslHandler.class);
/*  932 */       if (handler != null) {
/*  933 */         this
/*  934 */           .applicationProtocol = (handler.applicationProtocol() != null) ? handler.applicationProtocol() : "http/1.1";
/*      */       } else {
/*      */         
/*  937 */         this.applicationProtocol = null;
/*      */       } 
/*  939 */       ChannelHandlerContext frameCodec = http2FrameCodecCtx();
/*  940 */       if (frameCodec != null && http2MultiplexHandlerCtx() != null) {
/*  941 */         this.maxConcurrentStreams = ((Http2FrameCodec)frameCodec.handler()).connection().local().maxActiveStreams();
/*  942 */         this
/*  943 */           .maxConcurrentStreams = (pool.maxConcurrentStreams.longValue() == -1L) ? this.maxConcurrentStreams : Math.min(pool.maxConcurrentStreams.longValue(), this.maxConcurrentStreams);
/*      */       } 
/*  945 */       Http2Pool.TOTAL_MAX_CONCURRENT_STREAMS.addAndGet(this.pool, this.maxConcurrentStreams);
/*      */     }
/*      */     
/*      */     boolean canOpenStream() {
/*  949 */       ChannelHandlerContext frameCodec = http2FrameCodecCtx();
/*  950 */       if (frameCodec != null && http2MultiplexHandlerCtx() != null) {
/*  951 */         long maxActiveStreams = ((Http2FrameCodec)frameCodec.handler()).connection().local().maxActiveStreams();
/*      */         
/*  953 */         maxActiveStreams = (this.pool.maxConcurrentStreams.longValue() == -1L) ? maxActiveStreams : Math.min(this.pool.maxConcurrentStreams.longValue(), maxActiveStreams);
/*  954 */         long diff = maxActiveStreams - this.maxConcurrentStreams;
/*  955 */         if (diff != 0L) {
/*  956 */           this.maxConcurrentStreams = maxActiveStreams;
/*  957 */           Http2Pool.TOTAL_MAX_CONCURRENT_STREAMS.addAndGet(this.pool, diff);
/*      */         } 
/*  959 */         int concurrency = this.concurrency;
/*  960 */         return (concurrency < maxActiveStreams);
/*      */       } 
/*  962 */       return false;
/*      */     }
/*      */     
/*      */     int concurrency() {
/*  966 */       return this.concurrency;
/*      */     }
/*      */     
/*      */     void deactivate() {
/*  970 */       if (Http2Pool.log.isDebugEnabled()) {
/*  971 */         Http2Pool.log.debug(ReactorNetty.format(this.connection.channel(), "Channel deactivated"));
/*      */       }
/*      */       
/*  974 */       ConcurrentLinkedQueue<Slot> slots = Http2Pool.CONNECTIONS.get(this.pool);
/*  975 */       this.pool.offerSlot(slots, this);
/*      */     }
/*      */     
/*      */     int decrementConcurrencyAndGet() {
/*  979 */       int concurrency = CONCURRENCY.decrementAndGet(this);
/*  980 */       this.idleTimestamp = this.pool.clock.millis();
/*  981 */       return concurrency;
/*      */     }
/*      */     
/*      */     boolean goAwayReceived() {
/*  985 */       ChannelHandlerContext frameCodec = http2FrameCodecCtx();
/*  986 */       return (frameCodec != null && ((Http2FrameCodec)frameCodec.handler()).connection().goAwayReceived());
/*      */     }
/*      */     
/*      */     @Nullable
/*      */     ChannelHandlerContext http2FrameCodecCtx() {
/*  991 */       ChannelHandlerContext ctx = this.http2FrameCodecCtx;
/*  992 */       if (ctx != null && !ctx.isRemoved()) {
/*  993 */         return ctx;
/*      */       }
/*  995 */       ctx = this.connection.channel().pipeline().context(Http2FrameCodec.class);
/*  996 */       this.http2FrameCodecCtx = ctx;
/*  997 */       return ctx;
/*      */     }
/*      */     
/*      */     @Nullable
/*      */     ChannelHandlerContext http2MultiplexHandlerCtx() {
/* 1002 */       ChannelHandlerContext ctx = this.http2MultiplexHandlerCtx;
/* 1003 */       if (ctx != null && !ctx.isRemoved()) {
/* 1004 */         return ctx;
/*      */       }
/* 1006 */       ctx = this.connection.channel().pipeline().context(Http2MultiplexHandler.class);
/* 1007 */       this.http2MultiplexHandlerCtx = ctx;
/* 1008 */       return ctx;
/*      */     }
/*      */     
/*      */     @Nullable
/*      */     ChannelHandlerContext h2cUpgradeHandlerCtx() {
/* 1013 */       ChannelHandlerContext ctx = this.h2cUpgradeHandlerCtx;
/* 1014 */       if (ctx != null && !ctx.isRemoved()) {
/* 1015 */         return ctx;
/*      */       }
/* 1017 */       ctx = this.connection.channel().pipeline().context("reactor.left.h2cUpgradeHandler");
/* 1018 */       this.h2cUpgradeHandlerCtx = ctx;
/* 1019 */       return ctx;
/*      */     }
/*      */     
/*      */     void incrementConcurrencyAndGet() {
/* 1023 */       CONCURRENCY.incrementAndGet(this);
/*      */     }
/*      */     
/*      */     void invalidate() {
/* 1027 */       if (compareAndSet(false, true)) {
/* 1028 */         if (Http2Pool.log.isDebugEnabled()) {
/* 1029 */           Http2Pool.log.debug(ReactorNetty.format(this.connection.channel(), "Channel removed from pool"));
/*      */         }
/* 1031 */         this.pool.poolConfig.allocationStrategy().returnPermits(1);
/* 1032 */         Http2Pool.TOTAL_MAX_CONCURRENT_STREAMS.addAndGet(this.pool, -this.maxConcurrentStreams);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public long idleTime() {
/* 1038 */       if (concurrency() > 0) {
/* 1039 */         return 0L;
/*      */       }
/* 1041 */       long idleTime = (this.idleTimestamp != 0L) ? this.idleTimestamp : this.creationTimestamp;
/* 1042 */       return this.pool.clock.millis() - idleTime;
/*      */     }
/*      */ 
/*      */     
/*      */     public int acquireCount() {
/* 1047 */       return 1;
/*      */     }
/*      */ 
/*      */     
/*      */     public long lifeTime() {
/* 1052 */       return this.pool.clock.millis() - this.creationTimestamp;
/*      */     }
/*      */ 
/*      */     
/*      */     public long releaseTimestamp() {
/* 1057 */       return 0L;
/*      */     }
/*      */ 
/*      */     
/*      */     public long allocationTimestamp() {
/* 1062 */       return this.creationTimestamp;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\client\Http2Pool.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */