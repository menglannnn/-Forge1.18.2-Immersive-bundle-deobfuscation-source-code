/*    */ package reactor.netty.http.client;
/*    */ 
/*    */ import io.netty.buffer.ByteBuf;
/*    */ import io.netty.channel.ChannelDuplexHandler;
/*    */ import io.netty.channel.ChannelHandler.Sharable;
/*    */ import io.netty.channel.ChannelHandlerContext;
/*    */ import io.netty.channel.ChannelPromise;
/*    */ import io.netty.handler.codec.http.DefaultHttpContent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Sharable
/*    */ final class Http2StreamBridgeClientHandler
/*    */   extends ChannelDuplexHandler
/*    */ {
/*    */   public void channelActive(ChannelHandlerContext ctx) {
/* 39 */     ctx.read();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void write(ChannelHandlerContext ctx, Object msg, ChannelPromise promise) {
/* 45 */     if (msg instanceof ByteBuf) {
/*    */       
/* 47 */       ctx.write(new DefaultHttpContent((ByteBuf)msg), promise);
/*    */     }
/*    */     else {
/*    */       
/* 51 */       ctx.write(msg, promise);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\client\Http2StreamBridgeClientHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */