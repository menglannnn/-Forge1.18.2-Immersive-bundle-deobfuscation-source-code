/*    */ package reactor.netty.http.client;
/*    */ 
/*    */ import java.net.SocketAddress;
/*    */ import java.time.Duration;
/*    */ import reactor.netty.http.ContextAwareHttpMetricsRecorder;
/*    */ import reactor.util.context.Context;
/*    */ import reactor.util.context.ContextView;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ContextAwareHttpClientMetricsRecorder
/*    */   extends ContextAwareHttpMetricsRecorder
/*    */   implements HttpClientMetricsRecorder
/*    */ {
/*    */   public abstract void recordDataReceivedTime(ContextView paramContextView, SocketAddress paramSocketAddress, String paramString1, String paramString2, String paramString3, Duration paramDuration);
/*    */   
/*    */   public abstract void recordDataSentTime(ContextView paramContextView, SocketAddress paramSocketAddress, String paramString1, String paramString2, Duration paramDuration);
/*    */   
/*    */   public abstract void recordResponseTime(ContextView paramContextView, SocketAddress paramSocketAddress, String paramString1, String paramString2, String paramString3, Duration paramDuration);
/*    */   
/*    */   public void recordDataReceivedTime(SocketAddress remoteAddress, String uri, String method, String status, Duration time) {
/* 74 */     recordDataReceivedTime((ContextView)Context.empty(), remoteAddress, uri, method, status, time);
/*    */   }
/*    */ 
/*    */   
/*    */   public void recordDataSentTime(SocketAddress remoteAddress, String uri, String method, Duration time) {
/* 79 */     recordDataSentTime((ContextView)Context.empty(), remoteAddress, uri, method, time);
/*    */   }
/*    */ 
/*    */   
/*    */   public void recordResponseTime(SocketAddress remoteAddress, String uri, String method, String status, Duration time) {
/* 84 */     recordResponseTime((ContextView)Context.empty(), remoteAddress, uri, method, status, time);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\client\ContextAwareHttpClientMetricsRecorder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */