/*     */ package reactor.netty.http.client;
/*     */ 
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import reactor.netty.resources.ConnectionProvider;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Http2AllocationStrategy
/*     */   implements ConnectionProvider.AllocationStrategy<Http2AllocationStrategy>
/*     */ {
/*     */   final long maxConcurrentStreams;
/*     */   final int maxConnections;
/*     */   final int minConnections;
/*     */   volatile int permits;
/*     */   
/*     */   public static Builder builder() {
/*  77 */     return new Build();
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2AllocationStrategy copy() {
/*  82 */     return new Http2AllocationStrategy(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public int estimatePermitCount() {
/*  87 */     return PERMITS.get(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPermits(int desired) {
/*  92 */     if (desired < 0) {
/*  93 */       return 0;
/*     */     }
/*     */     
/*     */     while (true) {
/*  97 */       int p = this.permits;
/*  98 */       int target = Math.min(desired, p);
/*     */       
/* 100 */       if (PERMITS.compareAndSet(this, p, p - target)) {
/* 101 */         return target;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long maxConcurrentStreams() {
/* 112 */     return this.maxConcurrentStreams;
/*     */   }
/*     */ 
/*     */   
/*     */   public int permitGranted() {
/* 117 */     return this.maxConnections - PERMITS.get(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public int permitMinimum() {
/* 122 */     return this.minConnections;
/*     */   }
/*     */ 
/*     */   
/*     */   public int permitMaximum() {
/* 127 */     return this.maxConnections;
/*     */   }
/*     */   
/*     */   public void returnPermits(int returned) {
/*     */     int p;
/*     */     do {
/* 133 */       p = PERMITS.get(this);
/* 134 */       if (p + returned > this.maxConnections) {
/* 135 */         throw new IllegalArgumentException("Too many permits returned: returned=" + returned + ", would bring to " + (p + returned) + "/" + this.maxConnections);
/*     */       }
/*     */     }
/* 138 */     while (!PERMITS.compareAndSet(this, p, p + returned));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 149 */   static final AtomicIntegerFieldUpdater<Http2AllocationStrategy> PERMITS = AtomicIntegerFieldUpdater.newUpdater(Http2AllocationStrategy.class, "permits");
/*     */   
/*     */   Http2AllocationStrategy(Build build) {
/* 152 */     this.maxConcurrentStreams = build.maxConcurrentStreams;
/* 153 */     this.maxConnections = build.maxConnections;
/* 154 */     this.minConnections = build.minConnections;
/* 155 */     PERMITS.lazySet(this, this.maxConnections);
/*     */   }
/*     */   
/*     */   Http2AllocationStrategy(Http2AllocationStrategy copy) {
/* 159 */     this.maxConcurrentStreams = copy.maxConcurrentStreams;
/* 160 */     this.maxConnections = copy.maxConnections;
/* 161 */     this.minConnections = copy.minConnections;
/* 162 */     PERMITS.lazySet(this, this.maxConnections);
/*     */   }
/*     */   
/*     */   static final class Build
/*     */     implements Builder {
/*     */     static final long DEFAULT_MAX_CONCURRENT_STREAMS = -1L;
/*     */     static final int DEFAULT_MAX_CONNECTIONS = 2147483647;
/*     */     static final int DEFAULT_MIN_CONNECTIONS = 0;
/* 170 */     long maxConcurrentStreams = -1L;
/* 171 */     int maxConnections = Integer.MAX_VALUE;
/* 172 */     int minConnections = 0;
/*     */ 
/*     */     
/*     */     public Http2AllocationStrategy build() {
/* 176 */       if (this.minConnections > this.maxConnections) {
/* 177 */         throw new IllegalArgumentException("minConnections (" + this.minConnections + ") must be less than or equal to maxConnections (" + this.maxConnections + ")");
/*     */       }
/*     */       
/* 180 */       return new Http2AllocationStrategy(this);
/*     */     }
/*     */ 
/*     */     
/*     */     public Http2AllocationStrategy.Builder maxConcurrentStreams(long maxConcurrentStreams) {
/* 185 */       if (maxConcurrentStreams < -1L) {
/* 186 */         throw new IllegalArgumentException("maxConcurrentStreams must be greater than or equal to -1");
/*     */       }
/* 188 */       this.maxConcurrentStreams = maxConcurrentStreams;
/* 189 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public Http2AllocationStrategy.Builder maxConnections(int maxConnections) {
/* 194 */       if (maxConnections < 1) {
/* 195 */         throw new IllegalArgumentException("maxConnections must be strictly positive");
/*     */       }
/* 197 */       this.maxConnections = maxConnections;
/* 198 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public Http2AllocationStrategy.Builder minConnections(int minConnections) {
/* 203 */       if (minConnections < 0) {
/* 204 */         throw new IllegalArgumentException("minConnections must be positive or zero");
/*     */       }
/* 206 */       this.minConnections = minConnections;
/* 207 */       return this;
/*     */     }
/*     */   }
/*     */   
/*     */   public static interface Builder {
/*     */     Http2AllocationStrategy build();
/*     */     
/*     */     Builder maxConcurrentStreams(long param1Long);
/*     */     
/*     */     Builder maxConnections(int param1Int);
/*     */     
/*     */     Builder minConnections(int param1Int);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\client\Http2AllocationStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */