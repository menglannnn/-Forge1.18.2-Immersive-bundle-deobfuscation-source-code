/*     */ package reactor.netty.http.client;
/*     */ 
/*     */ import io.netty.resolver.AddressResolverGroup;
/*     */ import java.net.SocketAddress;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Supplier;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.netty.Connection;
/*     */ import reactor.netty.ConnectionObserver;
/*     */ import reactor.netty.http.HttpResources;
/*     */ import reactor.netty.resources.ConnectionProvider;
/*     */ import reactor.netty.transport.TransportConfig;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class HttpConnectionProvider
/*     */   implements ConnectionProvider
/*     */ {
/*     */   final ConnectionProvider http1ConnectionProvider;
/*     */   
/*     */   public Mono<? extends Connection> acquire(TransportConfig config, ConnectionObserver connectionObserver, @Nullable Supplier<? extends SocketAddress> remoteAddress, @Nullable AddressResolverGroup<?> resolverGroup) {
/*  47 */     if (((HttpClientConfig)config)._protocols == 4) {
/*  48 */       return http1ConnectionProvider().acquire(config, connectionObserver, remoteAddress, resolverGroup);
/*     */     }
/*  50 */     if (this.http1ConnectionProvider == null) {
/*  51 */       return HttpResources.get().getOrCreateHttp2ConnectionProvider(HTTP2_CONNECTION_PROVIDER_FACTORY)
/*  52 */         .acquire(config, connectionObserver, remoteAddress, resolverGroup);
/*     */     }
/*     */     
/*  55 */     return getOrCreate().acquire(config, connectionObserver, remoteAddress, resolverGroup);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void disposeWhen(SocketAddress address) {
/*  61 */     http1ConnectionProvider().disposeWhen(address);
/*     */   }
/*     */ 
/*     */   
/*     */   public int maxConnections() {
/*  66 */     return http1ConnectionProvider().maxConnections();
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<SocketAddress, Integer> maxConnectionsPerHost() {
/*  71 */     return http1ConnectionProvider().maxConnectionsPerHost();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*  76 */   final AtomicReference<ConnectionProvider> h2ConnectionProvider = new AtomicReference<>();
/*     */   
/*     */   HttpConnectionProvider() {
/*  79 */     this(null);
/*     */   }
/*     */   
/*     */   HttpConnectionProvider(@Nullable ConnectionProvider http1ConnectionProvider) {
/*  83 */     this.http1ConnectionProvider = http1ConnectionProvider;
/*     */   }
/*     */   
/*     */   ConnectionProvider getOrCreate() {
/*  87 */     ConnectionProvider provider = this.h2ConnectionProvider.get();
/*  88 */     if (provider == null) {
/*  89 */       ConnectionProvider newProvider = HTTP2_CONNECTION_PROVIDER_FACTORY.apply(this.http1ConnectionProvider);
/*  90 */       if (!this.h2ConnectionProvider.compareAndSet(null, newProvider)) {
/*  91 */         newProvider.dispose();
/*     */       }
/*  93 */       provider = getOrCreate();
/*     */     } 
/*  95 */     return provider;
/*     */   }
/*     */   
/*     */   ConnectionProvider http1ConnectionProvider() {
/*  99 */     return (this.http1ConnectionProvider != null) ? this.http1ConnectionProvider : (ConnectionProvider)HttpResources.get();
/*     */   }
/*     */   
/* 102 */   static final Function<ConnectionProvider, ConnectionProvider> HTTP2_CONNECTION_PROVIDER_FACTORY = Http2ConnectionProvider::new;
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\client\HttpConnectionProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */