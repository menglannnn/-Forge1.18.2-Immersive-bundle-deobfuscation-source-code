/*     */ package reactor.netty.http.client;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.buffer.ByteBufHolder;
/*     */ import io.netty.channel.ChannelDuplexHandler;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.channel.ChannelPromise;
/*     */ import io.netty.handler.codec.http.HttpRequest;
/*     */ import io.netty.handler.codec.http.HttpResponse;
/*     */ import io.netty.util.concurrent.Future;
/*     */ import java.net.SocketAddress;
/*     */ import java.time.Duration;
/*     */ import java.util.function.Function;
/*     */ import reactor.netty.ReactorNetty;
/*     */ import reactor.netty.channel.ChannelOperations;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.Loggers;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.ContextView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class AbstractHttpClientMetricsHandler
/*     */   extends ChannelDuplexHandler
/*     */ {
/*  44 */   private static final Logger log = Loggers.getLogger(AbstractHttpClientMetricsHandler.class);
/*     */ 
/*     */   
/*     */   String path;
/*     */   
/*     */   String method;
/*     */   
/*     */   String status;
/*     */   
/*     */   ContextView contextView;
/*     */   
/*     */   long dataReceived;
/*     */   
/*     */   long dataSent;
/*     */   
/*     */   long dataReceivedTime;
/*     */   
/*     */   long dataSentTime;
/*     */   
/*     */   final Function<String, String> uriTagValue;
/*     */ 
/*     */   
/*     */   protected AbstractHttpClientMetricsHandler(@Nullable Function<String, String> uriTagValue) {
/*  67 */     this.uriTagValue = uriTagValue;
/*     */   }
/*     */   
/*     */   protected AbstractHttpClientMetricsHandler(AbstractHttpClientMetricsHandler copy) {
/*  71 */     this.contextView = copy.contextView;
/*  72 */     this.dataReceived = copy.dataReceived;
/*  73 */     this.dataReceivedTime = copy.dataReceivedTime;
/*  74 */     this.dataSent = copy.dataSent;
/*  75 */     this.dataSentTime = copy.dataSentTime;
/*  76 */     this.method = copy.method;
/*  77 */     this.path = copy.path;
/*  78 */     this.status = copy.status;
/*  79 */     this.uriTagValue = copy.uriTagValue;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(ChannelHandlerContext ctx, Object msg, ChannelPromise promise) {
/*     */     try {
/*  86 */       if (msg instanceof HttpRequest) {
/*  87 */         extractDetailsFromHttpRequest(ctx, (HttpRequest)msg);
/*     */       }
/*     */       
/*  90 */       this.dataSent += extractProcessedDataFromBuffer(msg);
/*     */       
/*  92 */       if (msg instanceof io.netty.handler.codec.http.LastHttpContent) {
/*  93 */         SocketAddress address = ctx.channel().remoteAddress();
/*  94 */         promise.addListener(future -> {
/*     */               
/*     */               try {
/*     */                 recordWrite(address);
/*  98 */               } catch (RuntimeException e) {
/*     */                 
/*     */                 if (log.isWarnEnabled()) {
/*     */                   log.warn(ReactorNetty.format(ctx.channel(), "Exception caught while recording metrics."), e);
/*     */                 }
/*     */               }
/*     */             
/*     */             });
/*     */       } 
/* 107 */     } catch (RuntimeException e) {
/* 108 */       if (log.isWarnEnabled()) {
/* 109 */         log.warn(ReactorNetty.format(ctx.channel(), "Exception caught while recording metrics."), e);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 114 */     ctx.write(msg, promise);
/*     */   }
/*     */ 
/*     */   
/*     */   public void channelRead(ChannelHandlerContext ctx, Object msg) {
/*     */     try {
/* 120 */       if (msg instanceof HttpResponse) {
/* 121 */         this.status = ((HttpResponse)msg).status().codeAsText().toString();
/*     */         
/* 123 */         this.dataReceivedTime = System.nanoTime();
/*     */       } 
/*     */       
/* 126 */       this.dataReceived += extractProcessedDataFromBuffer(msg);
/*     */       
/* 128 */       if (msg instanceof io.netty.handler.codec.http.LastHttpContent) {
/* 129 */         recordRead(ctx.channel().remoteAddress());
/* 130 */         reset();
/*     */       }
/*     */     
/* 133 */     } catch (RuntimeException e) {
/* 134 */       if (log.isWarnEnabled()) {
/* 135 */         log.warn(ReactorNetty.format(ctx.channel(), "Exception caught while recording metrics."), e);
/*     */       }
/*     */     } 
/*     */     
/* 139 */     ctx.fireChannelRead(msg);
/*     */   }
/*     */ 
/*     */   
/*     */   public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) {
/*     */     try {
/* 145 */       recordException(ctx);
/*     */     }
/* 147 */     catch (RuntimeException e) {
/* 148 */       if (log.isWarnEnabled()) {
/* 149 */         log.warn(ReactorNetty.format(ctx.channel(), "Exception caught while recording metrics."), e);
/*     */       }
/*     */     } 
/*     */     
/* 153 */     ctx.fireExceptionCaught(cause);
/*     */   }
/*     */   
/*     */   private void extractDetailsFromHttpRequest(ChannelHandlerContext ctx, HttpRequest request) {
/* 157 */     this.method = request.method().name();
/*     */     
/* 159 */     ChannelOperations<?, ?> channelOps = ChannelOperations.get(ctx.channel());
/* 160 */     if (channelOps instanceof HttpClientOperations) {
/* 161 */       HttpClientOperations ops = (HttpClientOperations)channelOps;
/* 162 */       this.path = (this.uriTagValue == null) ? ops.path : this.uriTagValue.apply(ops.path);
/* 163 */       this.contextView = ops.currentContextView();
/*     */     } 
/*     */     
/* 166 */     this.dataSentTime = System.nanoTime();
/*     */   }
/*     */   
/*     */   private long extractProcessedDataFromBuffer(Object msg) {
/* 170 */     if (msg instanceof ByteBufHolder) {
/* 171 */       return ((ByteBufHolder)msg).content().readableBytes();
/*     */     }
/* 173 */     if (msg instanceof ByteBuf) {
/* 174 */       return ((ByteBuf)msg).readableBytes();
/*     */     }
/* 176 */     return 0L;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void recordException(ChannelHandlerContext ctx) {
/* 182 */     recorder().incrementErrorsCount(ctx.channel().remoteAddress(), 
/* 183 */         (this.path != null) ? this.path : resolveUri(ctx));
/*     */   }
/*     */   
/*     */   protected void recordRead(SocketAddress address) {
/* 187 */     recorder().recordDataReceivedTime(address, this.path, this.method, this.status, 
/*     */         
/* 189 */         Duration.ofNanos(System.nanoTime() - this.dataReceivedTime));
/*     */     
/* 191 */     recorder().recordResponseTime(address, this.path, this.method, this.status, 
/*     */         
/* 193 */         Duration.ofNanos(System.nanoTime() - this.dataSentTime));
/*     */     
/* 195 */     recorder().recordDataReceived(address, this.path, this.dataReceived);
/*     */   }
/*     */   
/*     */   protected void recordWrite(SocketAddress address) {
/* 199 */     recorder().recordDataSentTime(address, this.path, this.method, 
/*     */         
/* 201 */         Duration.ofNanos(System.nanoTime() - this.dataSentTime));
/*     */     
/* 203 */     recorder().recordDataSent(address, this.path, this.dataSent);
/*     */   }
/*     */   
/*     */   private String resolveUri(ChannelHandlerContext ctx) {
/* 207 */     ChannelOperations<?, ?> channelOps = ChannelOperations.get(ctx.channel());
/* 208 */     if (channelOps instanceof HttpClientOperations) {
/* 209 */       String path = ((HttpClientOperations)channelOps).uri();
/* 210 */       return (this.uriTagValue == null) ? path : this.uriTagValue.apply(path);
/*     */     } 
/*     */     
/* 213 */     return "unknown";
/*     */   }
/*     */ 
/*     */   
/*     */   private void reset() {
/* 218 */     this.path = null;
/* 219 */     this.method = null;
/* 220 */     this.status = null;
/* 221 */     this.contextView = null;
/* 222 */     this.dataReceived = 0L;
/* 223 */     this.dataSent = 0L;
/* 224 */     this.dataReceivedTime = 0L;
/* 225 */     this.dataSentTime = 0L;
/*     */   }
/*     */   
/*     */   protected abstract HttpClientMetricsRecorder recorder();
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\client\AbstractHttpClientMetricsHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */