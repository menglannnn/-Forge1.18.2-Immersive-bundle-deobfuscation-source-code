/*     */ package reactor.netty.http.client;
/*     */ 
/*     */ import io.netty.buffer.ByteBufAllocator;
/*     */ import io.netty.handler.codec.http.HttpContent;
/*     */ import io.netty.handler.codec.http.HttpRequest;
/*     */ import io.netty.handler.codec.http.multipart.DiskAttribute;
/*     */ import io.netty.handler.codec.http.multipart.DiskFileUpload;
/*     */ import io.netty.handler.codec.http.multipart.FileUpload;
/*     */ import io.netty.handler.codec.http.multipart.HttpDataFactory;
/*     */ import io.netty.handler.codec.http.multipart.HttpPostRequestEncoder;
/*     */ import io.netty.handler.codec.http.multipart.InterfaceHttpData;
/*     */ import io.netty.handler.stream.ChunkedInput;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.regex.Pattern;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.publisher.Sinks;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class HttpClientFormEncoder
/*     */   extends HttpPostRequestEncoder
/*     */   implements ChunkedInput<HttpContent>, Runnable, HttpClientForm
/*     */ {
/*     */   final Sinks.Many<Long> progressSink;
/*     */   final HttpRequest request;
/*     */   boolean needNewEncoder;
/*     */   HttpDataFactory newFactory;
/*     */   boolean cleanOnTerminate;
/*     */   Charset newCharset;
/*     */   boolean newMultipart;
/*     */   HttpPostRequestEncoder.EncoderMode newMode;
/*     */   
/*     */   HttpClientFormEncoder(HttpDataFactory factory, HttpRequest request, boolean multipart, Charset charset, HttpPostRequestEncoder.EncoderMode encoderMode) throws HttpPostRequestEncoder.ErrorDataEncoderException {
/*  75 */     super(factory, request, multipart, charset, encoderMode);
/*  76 */     this.newCharset = charset;
/*  77 */     this.request = request;
/*  78 */     this.cleanOnTerminate = true;
/*  79 */     this.progressSink = Sinks.many().unicast().onBackpressureError();
/*  80 */     this.newMode = encoderMode;
/*  81 */     this.newFactory = factory;
/*  82 */     this.newMultipart = multipart;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpContent readChunk(ByteBufAllocator allocator) throws Exception {
/*  87 */     HttpContent c = super.readChunk(allocator);
/*  88 */     if (c == null) {
/*  89 */       this.progressSink.emitComplete(Sinks.EmitFailureHandler.FAIL_FAST);
/*     */     } else {
/*     */       
/*  92 */       this.progressSink.emitNext(Long.valueOf(progress()), Sinks.EmitFailureHandler.FAIL_FAST);
/*  93 */       if (isEndOfInput()) {
/*  94 */         this.progressSink.emitComplete(Sinks.EmitFailureHandler.FAIL_FAST);
/*     */       }
/*     */     } 
/*  97 */     return c;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpClientForm attr(String name, String value) {
/*     */     try {
/* 103 */       addBodyAttribute(name, value);
/*     */     }
/* 105 */     catch (io.netty.handler.codec.http.multipart.HttpPostRequestEncoder.ErrorDataEncoderException e) {
/* 106 */       throw Exceptions.propagate(e);
/*     */     } 
/* 108 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpClientForm charset(Charset charset) {
/* 113 */     this.newCharset = Objects.<Charset>requireNonNull(charset, "charset");
/* 114 */     this.needNewEncoder = true;
/* 115 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpClientForm cleanOnTerminate(boolean clean) {
/* 120 */     this.cleanOnTerminate = clean;
/* 121 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpClientForm factory(HttpDataFactory factory) {
/* 126 */     if (!getBodyListAttributes().isEmpty()) {
/* 127 */       throw new IllegalStateException("Cannot set a new HttpDataFactory after starting appending Parts, call factory(f) at the earliest occasion offered");
/*     */     }
/*     */ 
/*     */     
/* 131 */     this.newFactory = Objects.<HttpDataFactory>requireNonNull(factory, "factory");
/* 132 */     this.needNewEncoder = true;
/* 133 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpClientForm file(String name, File file) {
/* 138 */     file(name, file, (String)null);
/* 139 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpClientForm file(String name, InputStream inputStream) {
/* 144 */     file(name, inputStream, (String)null);
/* 145 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpClientForm file(String name, String filename, File file, @Nullable String contentType) {
/* 153 */     Objects.requireNonNull(name, "name");
/* 154 */     Objects.requireNonNull(file, "file");
/* 155 */     Objects.requireNonNull(filename, "filename");
/* 156 */     String scontentType = contentType;
/* 157 */     if (contentType == null) {
/* 158 */       scontentType = "application/octet-stream";
/*     */     }
/* 160 */     FileUpload fileUpload = this.newFactory.createFileUpload(this.request, name, filename, scontentType, "binary", null, file
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 166 */         .length());
/*     */     try {
/* 168 */       fileUpload.setContent(file);
/* 169 */       addBodyHttpData((InterfaceHttpData)fileUpload);
/*     */     }
/* 171 */     catch (io.netty.handler.codec.http.multipart.HttpPostRequestEncoder.ErrorDataEncoderException e) {
/* 172 */       throw Exceptions.propagate(e);
/*     */     }
/* 174 */     catch (IOException e) {
/* 175 */       throw Exceptions.propagate(new HttpPostRequestEncoder.ErrorDataEncoderException(e));
/*     */     } 
/* 177 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpClientForm file(String name, String filename, InputStream stream, @Nullable String contentType) {
/* 185 */     Objects.requireNonNull(name, "name");
/* 186 */     Objects.requireNonNull(stream, "stream");
/*     */     try {
/* 188 */       String scontentType = contentType;
/* 189 */       if (contentType == null) {
/* 190 */         scontentType = "application/octet-stream";
/*     */       }
/* 192 */       FileUpload fileUpload = this.newFactory.createFileUpload(this.request, name, filename, scontentType, "binary", this.newCharset, -1L);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 199 */       fileUpload.setMaxSize(-1L);
/* 200 */       fileUpload.setContent(stream);
/* 201 */       addBodyHttpData((InterfaceHttpData)fileUpload);
/*     */     }
/* 203 */     catch (io.netty.handler.codec.http.multipart.HttpPostRequestEncoder.ErrorDataEncoderException e) {
/* 204 */       throw Exceptions.propagate(e);
/*     */     }
/* 206 */     catch (IOException e) {
/* 207 */       throw Exceptions.propagate(new HttpPostRequestEncoder.ErrorDataEncoderException(e));
/*     */     } 
/* 209 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpClientForm files(String name, File[] files, String[] contentTypes) {
/* 216 */     for (int i = 0; i < files.length; i++) {
/* 217 */       file(name, files[i], contentTypes[i]);
/*     */     }
/* 219 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpClientForm files(String name, File[] files, String[] contentTypes, boolean[] textFiles) {
/*     */     try {
/* 228 */       addBodyFileUploads(name, files, contentTypes, textFiles);
/*     */     }
/* 230 */     catch (io.netty.handler.codec.http.multipart.HttpPostRequestEncoder.ErrorDataEncoderException e) {
/* 231 */       throw Exceptions.propagate(e);
/*     */     } 
/* 233 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpClientForm encoding(HttpPostRequestEncoder.EncoderMode mode) {
/* 238 */     this.newMode = Objects.<HttpPostRequestEncoder.EncoderMode>requireNonNull(mode, "mode");
/* 239 */     this.needNewEncoder = true;
/* 240 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpClientForm multipart(boolean isMultipart) {
/* 245 */     this.needNewEncoder = (isChunked() != isMultipart);
/* 246 */     this.newMultipart = isMultipart;
/* 247 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpClientForm textFile(String name, File file) {
/* 252 */     textFile(name, file, (String)null);
/* 253 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpClientForm textFile(String name, File file, @Nullable String contentType) {
/*     */     try {
/* 259 */       addBodyFileUpload(name, file, contentType, true);
/*     */     }
/* 261 */     catch (io.netty.handler.codec.http.multipart.HttpPostRequestEncoder.ErrorDataEncoderException e) {
/* 262 */       throw Exceptions.propagate(e);
/*     */     } 
/* 264 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpClientForm textFile(String name, InputStream stream) {
/* 269 */     textFile(name, stream, (String)null);
/* 270 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpClientForm textFile(String name, InputStream stream, @Nullable String contentType) {
/* 277 */     Objects.requireNonNull(name, "name");
/* 278 */     Objects.requireNonNull(stream, "stream");
/*     */     try {
/* 280 */       String scontentType = contentType;
/*     */       
/* 282 */       if (contentType == null) {
/* 283 */         scontentType = "text/plain";
/*     */       }
/*     */       
/* 286 */       FileUpload fileUpload = this.newFactory.createFileUpload(this.request, name, "", scontentType, null, this.newCharset, -1L);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 293 */       fileUpload.setMaxSize(-1L);
/* 294 */       fileUpload.setContent(stream);
/* 295 */       addBodyHttpData((InterfaceHttpData)fileUpload);
/*     */     }
/* 297 */     catch (io.netty.handler.codec.http.multipart.HttpPostRequestEncoder.ErrorDataEncoderException e) {
/* 298 */       throw Exceptions.propagate(e);
/*     */     }
/* 300 */     catch (IOException e) {
/* 301 */       throw Exceptions.propagate(new HttpPostRequestEncoder.ErrorDataEncoderException(e));
/*     */     } 
/* 303 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public void run() {
/* 308 */     cleanFiles();
/*     */   }
/*     */   
/*     */   final HttpClientFormEncoder applyChanges(HttpRequest request) {
/* 312 */     if (!this.needNewEncoder) {
/* 313 */       return this;
/*     */     }
/*     */     
/*     */     try {
/* 317 */       HttpClientFormEncoder encoder = new HttpClientFormEncoder(this.newFactory, request, this.newMultipart, this.newCharset, this.newMode);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 323 */       encoder.setBodyHttpDatas(getBodyListAttributes());
/*     */       
/* 325 */       this.needNewEncoder = false;
/*     */       
/* 327 */       return encoder;
/*     */     }
/* 329 */     catch (io.netty.handler.codec.http.multipart.HttpPostRequestEncoder.ErrorDataEncoderException ee) {
/* 330 */       throw Exceptions.propagate(ee);
/*     */     } 
/*     */   }
/*     */   
/* 334 */   static final Map<Pattern, String> percentEncodings = new HashMap<>();
/*     */   
/*     */   static final String DEFAULT_BINARY_CONTENT_TYPE = "application/octet-stream";
/*     */   static final String DEFAULT_TRANSFER_ENCODING = "binary";
/*     */   static final String DEFAULT_TEXT_CONTENT_TYPE = "text/plain";
/*     */   
/*     */   static {
/* 341 */     DiskFileUpload.deleteOnExitTemporaryFile = true;
/*     */ 
/*     */     
/* 344 */     DiskFileUpload.baseDirectory = null;
/* 345 */     DiskAttribute.deleteOnExitTemporaryFile = true;
/*     */     
/* 347 */     DiskAttribute.baseDirectory = null;
/*     */     
/* 349 */     percentEncodings.put(Pattern.compile("\\*"), "%2A");
/* 350 */     percentEncodings.put(Pattern.compile("\\+"), "%20");
/* 351 */     percentEncodings.put(Pattern.compile("%7E"), "~");
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\client\HttpClientFormEncoder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */