/*     */ package reactor.netty.http.client;
/*     */ 
/*     */ import io.netty.channel.ChannelOption;
/*     */ import io.netty.channel.EventLoopGroup;
/*     */ import io.netty.channel.group.ChannelGroup;
/*     */ import io.netty.handler.logging.LogLevel;
/*     */ import io.netty.resolver.AddressResolverGroup;
/*     */ import io.netty.util.AttributeKey;
/*     */ import java.net.SocketAddress;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Supplier;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.netty.ChannelPipelineConfigurer;
/*     */ import reactor.netty.Connection;
/*     */ import reactor.netty.ConnectionObserver;
/*     */ import reactor.netty.NettyInbound;
/*     */ import reactor.netty.NettyOutbound;
/*     */ import reactor.netty.channel.ChannelMetricsRecorder;
/*     */ import reactor.netty.resources.LoopResources;
/*     */ import reactor.netty.tcp.SslProvider;
/*     */ import reactor.netty.tcp.TcpClient;
/*     */ import reactor.netty.tcp.TcpClientConfig;
/*     */ import reactor.netty.transport.ClientTransport;
/*     */ import reactor.netty.transport.ProxyProvider;
/*     */ import reactor.netty.transport.Transport;
/*     */ import reactor.netty.transport.TransportConfig;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ final class HttpClientTcpConfig
/*     */   extends TcpClient
/*     */ {
/*     */   HttpClient httpClient;
/*     */   
/*     */   HttpClientTcpConfig(HttpClient httpClient) {
/*  56 */     this.httpClient = httpClient;
/*     */   }
/*     */ 
/*     */   
/*     */   public <A> TcpClient attr(AttributeKey<A> key, @Nullable A value) {
/*  61 */     this.httpClient = (HttpClient)this.httpClient.attr(key, value);
/*  62 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpClient bindAddress(Supplier<? extends SocketAddress> bindAddressSupplier) {
/*  67 */     this.httpClient = (HttpClient)this.httpClient.bindAddress(bindAddressSupplier);
/*  68 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpClient channelGroup(ChannelGroup channelGroup) {
/*  73 */     this.httpClient = (HttpClient)this.httpClient.channelGroup(channelGroup);
/*  74 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpClientConfig configuration() {
/*  79 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<? extends Connection> connect() {
/*  84 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpClient doOnChannelInit(ChannelPipelineConfigurer doOnChannelInit) {
/*  89 */     this.httpClient = (HttpClient)this.httpClient.doOnChannelInit(doOnChannelInit);
/*  90 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpClient doOnConnect(Consumer<? super TcpClientConfig> doOnConnect) {
/*  95 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpClient doOnConnected(Consumer<? super Connection> doOnConnected) {
/* 100 */     this.httpClient = (HttpClient)this.httpClient.doOnConnected(doOnConnected);
/* 101 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpClient doOnDisconnected(Consumer<? super Connection> doOnDisconnected) {
/* 106 */     this.httpClient = (HttpClient)this.httpClient.doOnDisconnected(doOnDisconnected);
/* 107 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpClient handle(BiFunction<? super NettyInbound, ? super NettyOutbound, ? extends Publisher<Void>> handler) {
/* 112 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpClient host(String host) {
/* 117 */     this.httpClient = (HttpClient)this.httpClient.host(host);
/* 118 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpClient metrics(boolean enable) {
/* 123 */     this.httpClient = this.httpClient.metrics(enable, Function.identity());
/* 124 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpClient metrics(boolean enable, Supplier<? extends ChannelMetricsRecorder> recorder) {
/* 129 */     this.httpClient = this.httpClient.metrics(enable, recorder);
/* 130 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpClient noProxy() {
/* 135 */     this.httpClient = (HttpClient)this.httpClient.noProxy();
/* 136 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpClient noSSL() {
/* 141 */     this.httpClient = this.httpClient.noSSL();
/* 142 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpClient observe(ConnectionObserver observer) {
/* 147 */     this.httpClient = this.httpClient.observe(observer);
/* 148 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public <O> TcpClient option(ChannelOption<O> key, @Nullable O value) {
/* 153 */     this.httpClient = (HttpClient)this.httpClient.option(key, value);
/* 154 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpClient port(int port) {
/* 159 */     this.httpClient = this.httpClient.port(port);
/* 160 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpClient proxy(Consumer<? super ProxyProvider.TypeSpec> proxyOptions) {
/* 165 */     this.httpClient = (HttpClient)this.httpClient.proxy(proxyOptions);
/* 166 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpClient remoteAddress(Supplier<? extends SocketAddress> remoteAddressSupplier) {
/* 171 */     this.httpClient = this.httpClient.remoteAddress(remoteAddressSupplier);
/* 172 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpClient resolver(AddressResolverGroup<?> resolver) {
/* 177 */     this.httpClient = (HttpClient)this.httpClient.resolver(resolver);
/* 178 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpClient runOn(EventLoopGroup eventLoopGroup) {
/* 183 */     this.httpClient = (HttpClient)this.httpClient.runOn(eventLoopGroup);
/* 184 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpClient runOn(LoopResources channelResources) {
/* 189 */     this.httpClient = (HttpClient)this.httpClient.runOn(channelResources);
/* 190 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpClient runOn(LoopResources loopResources, boolean preferNative) {
/* 195 */     this.httpClient = (HttpClient)this.httpClient.runOn(loopResources, preferNative);
/* 196 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpClient secure() {
/* 201 */     this.httpClient = this.httpClient.secure();
/* 202 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpClient secure(Consumer<? super SslProvider.SslContextSpec> sslProviderBuilder) {
/* 207 */     this.httpClient = this.httpClient.secure(sslProviderBuilder);
/* 208 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpClient secure(SslProvider sslProvider) {
/* 213 */     this.httpClient = this.httpClient.secure(sslProvider);
/* 214 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpClient wiretap(boolean enable) {
/* 219 */     this.httpClient = this.httpClient.wiretap(enable);
/* 220 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpClient wiretap(String category) {
/* 225 */     this.httpClient = (HttpClient)this.httpClient.wiretap(category);
/* 226 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpClient wiretap(String category, LogLevel level) {
/* 231 */     this.httpClient = (HttpClient)this.httpClient.wiretap(category, level);
/* 232 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   protected TcpClient duplicate() {
/* 237 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\client\HttpClientTcpConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */