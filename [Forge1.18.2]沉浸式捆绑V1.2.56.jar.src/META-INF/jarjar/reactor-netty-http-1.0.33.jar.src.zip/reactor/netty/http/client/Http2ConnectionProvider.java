/*     */ package reactor.netty.http.client;
/*     */ 
/*     */ import io.netty.channel.Channel;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.handler.codec.http2.Http2Connection;
/*     */ import io.netty.handler.codec.http2.Http2FrameCodec;
/*     */ import io.netty.handler.codec.http2.Http2LocalFlowController;
/*     */ import io.netty.handler.codec.http2.Http2StreamChannel;
/*     */ import io.netty.handler.codec.http2.Http2StreamChannelBootstrap;
/*     */ import io.netty.resolver.AddressResolverGroup;
/*     */ import io.netty.util.AttributeKey;
/*     */ import io.netty.util.concurrent.Future;
/*     */ import io.netty.util.concurrent.GenericFutureListener;
/*     */ import java.io.IOException;
/*     */ import java.net.SocketAddress;
/*     */ import java.time.Duration;
/*     */ import java.util.Queue;
/*     */ import java.util.function.BiPredicate;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Supplier;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.Disposables;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.core.publisher.MonoSink;
/*     */ import reactor.core.publisher.Operators;
/*     */ import reactor.netty.Connection;
/*     */ import reactor.netty.ConnectionObserver;
/*     */ import reactor.netty.ReactorNetty;
/*     */ import reactor.netty.channel.ChannelMetricsRecorder;
/*     */ import reactor.netty.channel.ChannelOperations;
/*     */ import reactor.netty.internal.shaded.reactor.pool.InstrumentedPool;
/*     */ import reactor.netty.internal.shaded.reactor.pool.PoolConfig;
/*     */ import reactor.netty.internal.shaded.reactor.pool.PooledRef;
/*     */ import reactor.netty.internal.shaded.reactor.pool.PooledRefMetadata;
/*     */ import reactor.netty.resources.ConnectionProvider;
/*     */ import reactor.netty.resources.PooledConnectionProvider;
/*     */ import reactor.netty.transport.TransportConfig;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.Loggers;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.concurrent.Queues;
/*     */ import reactor.util.context.Context;
/*     */ import reactor.util.context.ContextView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class Http2ConnectionProvider
/*     */   extends PooledConnectionProvider<Connection>
/*     */ {
/*     */   final ConnectionProvider parent;
/*     */   static final String CONNECTION_PROVIDER_NAME = "http2";
/*     */   static final String NAME_SEPARATOR = ".";
/*     */   
/*     */   Http2ConnectionProvider(ConnectionProvider parent) {
/*  78 */     super(initConfiguration(parent));
/*  79 */     this.parent = parent;
/*  80 */     if (parent instanceof PooledConnectionProvider) {
/*  81 */       ((PooledConnectionProvider)parent).onDispose(disposeLater());
/*     */     }
/*     */   }
/*     */   
/*     */   static ConnectionProvider.Builder initConfiguration(ConnectionProvider parent) {
/*  86 */     String name = (parent.name() == null) ? "http2" : ("http2." + parent.name());
/*  87 */     ConnectionProvider.Builder builder = parent.mutate();
/*  88 */     if (builder != null) {
/*  89 */       return (ConnectionProvider.Builder)builder.name(name).pendingAcquireMaxCount(-1);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  94 */     return (ConnectionProvider.Builder)((ConnectionProvider.Builder)ConnectionProvider.builder(name)
/*  95 */       .maxConnections(parent.maxConnections()))
/*  96 */       .pendingAcquireMaxCount(-1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected CoreSubscriber<PooledRef<Connection>> createDisposableAcquire(TransportConfig config, ConnectionObserver connectionObserver, long pendingAcquireTimeout, InstrumentedPool<Connection> pool, MonoSink<Connection> sink) {
/* 107 */     boolean acceptGzip = false;
/* 108 */     ChannelMetricsRecorder metricsRecorder = (config.metricsRecorder() != null) ? config.metricsRecorder().get() : null;
/* 109 */     Function<String, String> uriTagValue = null;
/* 110 */     if (config instanceof HttpClientConfig) {
/* 111 */       acceptGzip = ((HttpClientConfig)config).acceptGzip;
/* 112 */       uriTagValue = ((HttpClientConfig)config).uriTagValue;
/*     */     } 
/* 114 */     return new DisposableAcquire(connectionObserver, config.channelOperationsProvider(), acceptGzip, metricsRecorder, pendingAcquireTimeout, pool, sink, uriTagValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected InstrumentedPool<Connection> createPool(TransportConfig config, PooledConnectionProvider.PoolFactory<Connection> poolFactory, SocketAddress remoteAddress, AddressResolverGroup<?> resolverGroup) {
/* 124 */     return (new PooledConnectionAllocator(this.parent, config, poolFactory, () -> remoteAddress, resolverGroup)).pool;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void registerDefaultMetrics(String id, SocketAddress remoteAddress, InstrumentedPool.PoolMetrics metrics) {
/* 129 */     MicrometerHttp2ConnectionProviderMeterRegistrar.INSTANCE
/* 130 */       .registerMetrics(name(), id, remoteAddress, metrics);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void deRegisterDefaultMetrics(String id, SocketAddress remoteAddress) {
/* 135 */     MicrometerHttp2ConnectionProviderMeterRegistrar.INSTANCE
/* 136 */       .deRegisterMetrics(name(), id, remoteAddress);
/*     */   }
/*     */   
/*     */   static void invalidate(@Nullable ConnectionObserver owner) {
/* 140 */     if (owner instanceof DisposableAcquire) {
/* 141 */       DisposableAcquire da = (DisposableAcquire)owner;
/* 142 */       da.pooledRef
/* 143 */         .invalidate()
/* 144 */         .subscribe();
/*     */     } 
/*     */   }
/*     */   
/*     */   static void logStreamsState(Channel channel, Http2Connection.Endpoint<Http2LocalFlowController> localEndpoint, String msg) {
/* 149 */     log.debug(ReactorNetty.format(channel, "{}, now: {} active streams and {} max active streams."), new Object[] { msg, 
/*     */           
/* 151 */           Integer.valueOf(localEndpoint.numActiveStreams()), 
/* 152 */           Integer.valueOf(localEndpoint.maxActiveStreams()) });
/*     */   }
/*     */   
/*     */   static void registerClose(Channel channel, ConnectionObserver owner) {
/* 156 */     channel.closeFuture()
/* 157 */       .addListener(f -> {
/*     */           if (log.isDebugEnabled()) {
/*     */             Http2FrameCodec frameCodec = (Http2FrameCodec)channel.parent().pipeline().get(Http2FrameCodec.class);
/*     */             if (frameCodec != null) {
/*     */               Http2Connection.Endpoint<Http2LocalFlowController> localEndpoint = frameCodec.connection().local();
/*     */               logStreamsState(channel, localEndpoint, "Stream closed");
/*     */             } 
/*     */           } 
/*     */           invalidate(owner);
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 173 */   static final Logger log = Loggers.getLogger(Http2ConnectionProvider.class);
/*     */   
/* 175 */   static final AttributeKey<ConnectionObserver> OWNER = AttributeKey.valueOf("http2ConnectionOwner");
/*     */   
/*     */   static final class DelegatingConnectionObserver
/*     */     implements ConnectionObserver
/*     */   {
/*     */     public void onUncaughtException(Connection connection, Throwable error) {
/* 181 */       owner(connection.channel()).onUncaughtException(connection, error);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onStateChange(Connection connection, ConnectionObserver.State newState) {
/* 186 */       owner(connection.channel()).onStateChange(connection, newState);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     ConnectionObserver owner(Channel channel) {
/*     */       while (true) {
/* 194 */         ConnectionObserver obs = (ConnectionObserver)channel.attr(Http2ConnectionProvider.OWNER).get();
/* 195 */         if (obs == null) {
/* 196 */           obs = new Http2ConnectionProvider.PendingConnectionObserver();
/*     */         } else {
/*     */           
/* 199 */           return obs;
/*     */         } 
/* 201 */         if (channel.attr(Http2ConnectionProvider.OWNER)
/* 202 */           .compareAndSet(null, obs)) {
/* 203 */           return obs;
/*     */         }
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class DisposableAcquire
/*     */     implements CoreSubscriber<PooledRef<Connection>>, ConnectionObserver, Disposable, GenericFutureListener<Future<Http2StreamChannel>>
/*     */   {
/*     */     final Disposable.Composite cancellations;
/*     */     
/*     */     final Context currentContext;
/*     */     
/*     */     final ConnectionObserver obs;
/*     */     
/*     */     final ChannelOperations.OnSetup opsFactory;
/*     */     
/*     */     final boolean acceptGzip;
/*     */     
/*     */     final ChannelMetricsRecorder metricsRecorder;
/*     */     
/*     */     final long pendingAcquireTimeout;
/*     */     
/*     */     final InstrumentedPool<Connection> pool;
/*     */     final boolean retried;
/*     */     final MonoSink<Connection> sink;
/*     */     final Function<String, String> uriTagValue;
/*     */     PooledRef<Connection> pooledRef;
/*     */     Subscription subscription;
/*     */     
/*     */     DisposableAcquire(ConnectionObserver obs, ChannelOperations.OnSetup opsFactory, boolean acceptGzip, @Nullable ChannelMetricsRecorder metricsRecorder, long pendingAcquireTimeout, InstrumentedPool<Connection> pool, MonoSink<Connection> sink, @Nullable Function<String, String> uriTagValue) {
/* 235 */       this.cancellations = Disposables.composite();
/* 236 */       this.currentContext = Context.of(sink.contextView());
/* 237 */       this.obs = obs;
/* 238 */       this.opsFactory = opsFactory;
/* 239 */       this.acceptGzip = acceptGzip;
/* 240 */       this.metricsRecorder = metricsRecorder;
/* 241 */       this.pendingAcquireTimeout = pendingAcquireTimeout;
/* 242 */       this.pool = pool;
/* 243 */       this.retried = false;
/* 244 */       this.sink = sink;
/* 245 */       this.uriTagValue = uriTagValue;
/*     */     }
/*     */     
/*     */     DisposableAcquire(DisposableAcquire parent) {
/* 249 */       this.cancellations = parent.cancellations;
/* 250 */       this.currentContext = parent.currentContext;
/* 251 */       this.obs = parent.obs;
/* 252 */       this.opsFactory = parent.opsFactory;
/* 253 */       this.acceptGzip = parent.acceptGzip;
/* 254 */       this.metricsRecorder = parent.metricsRecorder;
/* 255 */       this.pendingAcquireTimeout = parent.pendingAcquireTimeout;
/* 256 */       this.pool = parent.pool;
/* 257 */       this.retried = true;
/* 258 */       this.sink = parent.sink;
/* 259 */       this.uriTagValue = parent.uriTagValue;
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/* 264 */       return this.currentContext;
/*     */     }
/*     */ 
/*     */     
/*     */     public void dispose() {
/* 269 */       this.subscription.cancel();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onComplete() {}
/*     */ 
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 279 */       this.sink.error(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(PooledRef<Connection> pooledRef) {
/* 284 */       this.pooledRef = pooledRef;
/* 285 */       Channel channel = ((Connection)pooledRef.poolable()).channel();
/*     */ 
/*     */       
/* 288 */       ConnectionObserver current = (ConnectionObserver)channel.attr(Http2ConnectionProvider.OWNER).getAndSet(this);
/*     */       
/* 290 */       if (current instanceof Http2ConnectionProvider.PendingConnectionObserver) {
/* 291 */         Http2ConnectionProvider.PendingConnectionObserver pending = (Http2ConnectionProvider.PendingConnectionObserver)current;
/*     */         
/*     */         Http2ConnectionProvider.PendingConnectionObserver.Pending p;
/* 294 */         while ((p = pending.pendingQueue.poll()) != null) {
/* 295 */           if (p.error != null) {
/* 296 */             onUncaughtException(p.connection, p.error); continue;
/*     */           } 
/* 298 */           if (p.state != null) {
/* 299 */             onStateChange(p.connection, p.state);
/*     */           }
/*     */         } 
/*     */       } 
/*     */       
/* 304 */       if (notHttp2()) {
/*     */         return;
/*     */       }
/*     */       
/* 308 */       if (isH2cUpgrade()) {
/*     */         return;
/*     */       }
/*     */       
/* 312 */       if (ReactorNetty.getChannelContext(channel) != null) {
/* 313 */         ReactorNetty.setChannelContext(channel, null);
/*     */       }
/* 315 */       http2StreamChannelBootstrap(channel).open().addListener(this);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onStateChange(Connection connection, ConnectionObserver.State newState) {
/* 320 */       if (newState == HttpClientState.UPGRADE_REJECTED) {
/* 321 */         Http2ConnectionProvider.invalidate((ConnectionObserver)connection.channel().attr(Http2ConnectionProvider.OWNER).get());
/*     */       }
/*     */       
/* 324 */       this.obs.onStateChange(connection, newState);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 329 */       if (Operators.validate(this.subscription, s)) {
/* 330 */         this.subscription = s;
/* 331 */         this.cancellations.add(this);
/* 332 */         if (!this.retried) {
/* 333 */           this.sink.onCancel((Disposable)this.cancellations);
/*     */         }
/* 335 */         s.request(Long.MAX_VALUE);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onUncaughtException(Connection connection, Throwable error) {
/* 341 */       this.obs.onUncaughtException(connection, error);
/*     */     }
/*     */ 
/*     */     
/*     */     public void operationComplete(Future<Http2StreamChannel> future) {
/* 346 */       Channel channel = ((Connection)this.pooledRef.poolable()).channel();
/* 347 */       Http2Pool.Http2PooledRef http2PooledRef = http2PooledRef(this.pooledRef);
/* 348 */       ChannelHandlerContext frameCodec = http2PooledRef.slot.http2FrameCodecCtx();
/* 349 */       if (future.isSuccess()) {
/* 350 */         Http2StreamChannel ch = (Http2StreamChannel)future.getNow();
/*     */         
/* 352 */         if (!channel.isActive() || frameCodec == null || ((Http2FrameCodec)frameCodec
/* 353 */           .handler()).connection().goAwayReceived() || 
/* 354 */           !((Http2FrameCodec)frameCodec.handler()).connection().local().canOpenStream()) {
/* 355 */           Http2ConnectionProvider.invalidate(this);
/* 356 */           if (!this.retried) {
/* 357 */             if (Http2ConnectionProvider.log.isDebugEnabled()) {
/* 358 */               Http2ConnectionProvider.log.debug(ReactorNetty.format((Channel)ch, "Immediately aborted pooled channel, max active streams is reached, re-acquiring a new channel"));
/*     */             }
/*     */             
/* 361 */             this.pool.acquire(Duration.ofMillis(this.pendingAcquireTimeout))
/* 362 */               .contextWrite(ctx -> ctx.put("callereventloop", channel.eventLoop()))
/* 363 */               .subscribe(new DisposableAcquire(this));
/*     */           } else {
/*     */             
/* 366 */             this.sink.error(new IOException("Error while acquiring from " + this.pool + ". Max active streams is reached."));
/*     */           } 
/*     */         } else {
/*     */           
/* 370 */           Http2ConnectionProvider.registerClose((Channel)ch, this);
/* 371 */           if (!currentContext().isEmpty()) {
/* 372 */             ReactorNetty.setChannelContext((Channel)ch, (ContextView)currentContext());
/*     */           }
/* 374 */           HttpClientConfig.addStreamHandlers((Channel)ch, this.obs.then(new HttpClientConfig.StreamConnectionObserver(currentContext())), this.opsFactory, this.acceptGzip, this.metricsRecorder, -1L, this.uriTagValue);
/*     */ 
/*     */           
/* 377 */           ChannelOperations<?, ?> ops = ChannelOperations.get((Channel)ch);
/* 378 */           if (ops != null) {
/* 379 */             this.obs.onStateChange((Connection)ops, HttpClientState.STREAM_CONFIGURED);
/* 380 */             this.sink.success(ops);
/*     */           } 
/*     */           
/* 383 */           if (Http2ConnectionProvider.log.isDebugEnabled()) {
/* 384 */             Http2Connection.Endpoint<Http2LocalFlowController> localEndpoint = ((Http2FrameCodec)frameCodec.handler()).connection().local();
/* 385 */             Http2ConnectionProvider.logStreamsState((Channel)ch, localEndpoint, "Stream opened");
/*     */           } 
/*     */         } 
/*     */       } else {
/*     */         
/* 390 */         Http2ConnectionProvider.invalidate(this);
/* 391 */         this.sink.error(future.cause());
/*     */       } 
/*     */     }
/*     */     
/*     */     boolean isH2cUpgrade() {
/* 396 */       Channel channel = ((Connection)this.pooledRef.poolable()).channel();
/* 397 */       Http2Pool.Http2PooledRef http2PooledRef = http2PooledRef(this.pooledRef);
/* 398 */       if (http2PooledRef.slot.h2cUpgradeHandlerCtx() != null && http2PooledRef.slot
/* 399 */         .http2MultiplexHandlerCtx() == null) {
/* 400 */         ChannelOperations<?, ?> ops = ChannelOperations.get(channel);
/* 401 */         if (ops != null) {
/* 402 */           this.sink.success(ops);
/* 403 */           return true;
/*     */         } 
/*     */       } 
/* 406 */       return false;
/*     */     }
/*     */     
/*     */     boolean notHttp2() {
/* 410 */       Channel channel = ((Connection)this.pooledRef.poolable()).channel();
/* 411 */       Http2Pool.Http2PooledRef http2PooledRef = http2PooledRef(this.pooledRef);
/* 412 */       String applicationProtocol = http2PooledRef.slot.applicationProtocol;
/* 413 */       if (applicationProtocol != null) {
/* 414 */         if ("http/1.1".equals(applicationProtocol)) {
/*     */ 
/*     */ 
/*     */           
/* 418 */           ChannelOperations<?, ?> ops = ChannelOperations.get(channel);
/* 419 */           if (ops != null) {
/* 420 */             this.sink.success(ops);
/* 421 */             Http2ConnectionProvider.invalidate(this);
/* 422 */             return true;
/*     */           }
/*     */         
/* 425 */         } else if (!"h2".equals(applicationProtocol)) {
/* 426 */           channel.attr(Http2ConnectionProvider.OWNER).set(null);
/* 427 */           Http2ConnectionProvider.invalidate(this);
/* 428 */           this.sink.error(new IOException("Unknown protocol [" + applicationProtocol + "]."));
/* 429 */           return true;
/*     */         }
/*     */       
/* 432 */       } else if (http2PooledRef.slot.h2cUpgradeHandlerCtx() == null && http2PooledRef.slot
/* 433 */         .http2MultiplexHandlerCtx() == null) {
/*     */ 
/*     */         
/* 436 */         ChannelOperations<?, ?> ops = ChannelOperations.get(channel);
/* 437 */         if (ops != null) {
/* 438 */           this.sink.success(ops);
/* 439 */           Http2ConnectionProvider.invalidate(this);
/* 440 */           return true;
/*     */         } 
/*     */       } 
/* 443 */       return false;
/*     */     }
/*     */     
/*     */     static Http2Pool.Http2PooledRef http2PooledRef(PooledRef<Connection> pooledRef) {
/* 447 */       return (pooledRef instanceof Http2Pool.Http2PooledRef) ? 
/* 448 */         (Http2Pool.Http2PooledRef)pooledRef : 
/* 449 */         (Http2Pool.Http2PooledRef)pooledRef.metadata();
/*     */     }
/*     */ 
/*     */     
/* 453 */     static final AttributeKey<Http2StreamChannelBootstrap> HTTP2_STREAM_CHANNEL_BOOTSTRAP = AttributeKey.valueOf("http2StreamChannelBootstrap");
/*     */ 
/*     */ 
/*     */     
/*     */     static Http2StreamChannelBootstrap http2StreamChannelBootstrap(Channel channel) {
/*     */       while (true) {
/* 459 */         Http2StreamChannelBootstrap http2StreamChannelBootstrap = (Http2StreamChannelBootstrap)channel.attr(HTTP2_STREAM_CHANNEL_BOOTSTRAP).get();
/* 460 */         if (http2StreamChannelBootstrap == null) {
/* 461 */           http2StreamChannelBootstrap = new Http2StreamChannelBootstrap(channel);
/*     */         } else {
/*     */           
/* 464 */           return http2StreamChannelBootstrap;
/*     */         } 
/* 466 */         if (channel.attr(HTTP2_STREAM_CHANNEL_BOOTSTRAP)
/* 467 */           .compareAndSet(null, http2StreamChannelBootstrap))
/* 468 */           return http2StreamChannelBootstrap; 
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   static final class PendingConnectionObserver
/*     */     implements ConnectionObserver {
/* 475 */     final Queue<Pending> pendingQueue = Queues.unbounded(4).get();
/*     */ 
/*     */     
/*     */     public void onStateChange(Connection connection, ConnectionObserver.State newState) {
/* 479 */       this.pendingQueue.add(new Pending(connection, null, newState));
/*     */     }
/*     */ 
/*     */     
/*     */     public void onUncaughtException(Connection connection, Throwable error) {
/* 484 */       this.pendingQueue.add(new Pending(connection, error, null));
/*     */     }
/*     */     
/*     */     static class Pending {
/*     */       final Connection connection;
/*     */       final Throwable error;
/*     */       final ConnectionObserver.State state;
/*     */       
/*     */       Pending(Connection connection, @Nullable Throwable error, @Nullable ConnectionObserver.State state) {
/* 493 */         this.connection = connection;
/* 494 */         this.error = error;
/* 495 */         this.state = state;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class PooledConnectionAllocator
/*     */   {
/*     */     final ConnectionProvider parent;
/*     */     
/*     */     final HttpClientConfig config;
/*     */     
/*     */     final InstrumentedPool<Connection> pool;
/*     */     
/*     */     final Supplier<SocketAddress> remoteAddress;
/*     */     final AddressResolverGroup<?> resolver;
/*     */     
/*     */     PooledConnectionAllocator(ConnectionProvider parent, TransportConfig config, PooledConnectionProvider.PoolFactory<Connection> poolFactory, Supplier<SocketAddress> remoteAddress, AddressResolverGroup<?> resolver) {
/* 513 */       this.parent = parent;
/* 514 */       this.config = (HttpClientConfig)config;
/* 515 */       this.remoteAddress = remoteAddress;
/* 516 */       this.resolver = resolver;
/* 517 */       this.pool = poolFactory.newPool(connectChannel(), null, DEFAULT_DESTROY_HANDLER, DEFAULT_EVICTION_PREDICATE, poolConfig -> new Http2Pool(poolConfig, poolFactory.allocationStrategy()));
/*     */     }
/*     */ 
/*     */     
/*     */     Publisher<Connection> connectChannel() {
/* 522 */       return (Publisher<Connection>)this.parent.acquire((TransportConfig)this.config, new Http2ConnectionProvider.DelegatingConnectionObserver(), this.remoteAddress, this.resolver)
/* 523 */         .map(conn -> conn);
/*     */     }
/*     */     
/*     */     static final BiPredicate<Connection, PooledRefMetadata> DEFAULT_EVICTION_PREDICATE = (connection, metadata) -> false;
/*     */     static final Function<Connection, Publisher<Void>> DEFAULT_DESTROY_HANDLER = connection -> Mono.empty();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\client\Http2ConnectionProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */