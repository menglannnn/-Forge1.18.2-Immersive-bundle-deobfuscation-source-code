/*    */ package reactor.netty.http.client;
/*    */ 
/*    */ import io.netty.handler.ssl.SslHandler;
/*    */ import java.util.function.Consumer;
/*    */ import javax.net.ssl.SSLEngine;
/*    */ import javax.net.ssl.SSLParameters;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class HttpClientSecurityUtils
/*    */ {
/*    */   public static final Consumer<? super SslHandler> HOSTNAME_VERIFICATION_CONFIGURER;
/*    */   
/*    */   static {
/* 35 */     HOSTNAME_VERIFICATION_CONFIGURER = (handler -> {
/*    */         SSLEngine sslEngine = handler.engine();
/*    */         SSLParameters sslParameters = sslEngine.getSSLParameters();
/*    */         sslParameters.setEndpointIdentificationAlgorithm("HTTPS");
/*    */         sslEngine.setSSLParameters(sslParameters);
/*    */       });
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\client\HttpClientSecurityUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */