package reactor.netty.http.client;

import java.net.SocketAddress;
import java.time.Duration;
import reactor.netty.http.HttpMetricsRecorder;

public interface HttpClientMetricsRecorder extends HttpMetricsRecorder {
  void recordDataReceivedTime(SocketAddress paramSocketAddress, String paramString1, String paramString2, String paramString3, Duration paramDuration);
  
  void recordDataSentTime(SocketAddress paramSocketAddress, String paramString1, String paramString2, Duration paramDuration);
  
  void recordResponseTime(SocketAddress paramSocketAddress, String paramString1, String paramString2, String paramString3, Duration paramDuration);
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\client\HttpClientMetricsRecorder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */