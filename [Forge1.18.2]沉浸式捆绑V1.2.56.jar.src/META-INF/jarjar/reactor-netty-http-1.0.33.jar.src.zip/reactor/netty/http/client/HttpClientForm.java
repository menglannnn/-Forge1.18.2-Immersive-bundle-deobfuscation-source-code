/*     */ package reactor.netty.http.client;
/*     */ 
/*     */ import io.netty.handler.codec.http.multipart.HttpDataFactory;
/*     */ import io.netty.handler.codec.http.multipart.HttpPostRequestEncoder;
/*     */ import java.io.File;
/*     */ import java.io.InputStream;
/*     */ import java.nio.charset.Charset;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface HttpClientForm
/*     */ {
/*     */   HttpClientForm attr(String paramString1, String paramString2);
/*     */   
/*     */   HttpClientForm charset(Charset paramCharset);
/*     */   
/*     */   HttpClientForm cleanOnTerminate(boolean paramBoolean);
/*     */   
/*     */   HttpClientForm encoding(HttpPostRequestEncoder.EncoderMode paramEncoderMode);
/*     */   
/*     */   HttpClientForm factory(HttpDataFactory paramHttpDataFactory);
/*     */   
/*     */   HttpClientForm file(String paramString, File paramFile);
/*     */   
/*     */   HttpClientForm file(String paramString, InputStream paramInputStream);
/*     */   
/*     */   default HttpClientForm file(String name, File file, @Nullable String contentType) {
/* 106 */     return file(name, file.getName(), file, contentType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   HttpClientForm file(String paramString1, String paramString2, File paramFile, @Nullable String paramString3);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default HttpClientForm file(String name, InputStream stream, @Nullable String contentType) {
/* 131 */     return file(name, "", stream, contentType);
/*     */   }
/*     */   
/*     */   HttpClientForm file(String paramString1, String paramString2, InputStream paramInputStream, @Nullable String paramString3);
/*     */   
/*     */   HttpClientForm files(String paramString, File[] paramArrayOfFile, String[] paramArrayOfString);
/*     */   
/*     */   HttpClientForm files(String paramString, File[] paramArrayOfFile, String[] paramArrayOfString, boolean[] paramArrayOfboolean);
/*     */   
/*     */   HttpClientForm multipart(boolean paramBoolean);
/*     */   
/*     */   HttpClientForm textFile(String paramString, File paramFile);
/*     */   
/*     */   HttpClientForm textFile(String paramString, InputStream paramInputStream);
/*     */   
/*     */   HttpClientForm textFile(String paramString1, File paramFile, @Nullable String paramString2);
/*     */   
/*     */   HttpClientForm textFile(String paramString1, InputStream paramInputStream, @Nullable String paramString2);
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\client\HttpClientForm.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */