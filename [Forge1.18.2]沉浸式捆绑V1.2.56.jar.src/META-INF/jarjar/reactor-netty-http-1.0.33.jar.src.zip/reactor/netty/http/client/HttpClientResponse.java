package reactor.netty.http.client;

import io.netty.handler.codec.http.HttpHeaders;
import io.netty.handler.codec.http.HttpResponseStatus;
import reactor.core.publisher.Mono;

public interface HttpClientResponse extends HttpClientInfos {
  HttpHeaders responseHeaders();
  
  HttpResponseStatus status();
  
  Mono<HttpHeaders> trailerHeaders();
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\client\HttpClientResponse.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */