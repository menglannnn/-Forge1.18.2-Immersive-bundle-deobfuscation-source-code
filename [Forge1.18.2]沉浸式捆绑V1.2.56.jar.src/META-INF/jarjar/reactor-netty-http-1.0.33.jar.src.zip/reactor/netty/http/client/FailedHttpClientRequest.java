/*     */ package reactor.netty.http.client;
/*     */ 
/*     */ import io.netty.handler.codec.http.HttpHeaderNames;
/*     */ import io.netty.handler.codec.http.HttpHeaderValues;
/*     */ import io.netty.handler.codec.http.HttpHeaders;
/*     */ import io.netty.handler.codec.http.HttpMethod;
/*     */ import io.netty.handler.codec.http.HttpVersion;
/*     */ import io.netty.handler.codec.http.cookie.ClientCookieDecoder;
/*     */ import io.netty.handler.codec.http.cookie.Cookie;
/*     */ import java.time.Duration;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import reactor.netty.http.Cookies;
/*     */ import reactor.netty.http.HttpOperations;
/*     */ import reactor.util.context.Context;
/*     */ import reactor.util.context.ContextView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FailedHttpClientRequest
/*     */   implements HttpClientRequest
/*     */ {
/*     */   final ContextView contextView;
/*     */   final ClientCookieDecoder cookieDecoder;
/*     */   final HttpHeaders headers;
/*     */   final boolean isWebsocket;
/*     */   final HttpMethod method;
/*     */   final String path;
/*     */   final Duration responseTimeout;
/*     */   final String uri;
/*     */   
/*     */   FailedHttpClientRequest(ContextView contextView, HttpClientConfig c) {
/*  53 */     this.contextView = contextView;
/*  54 */     this.cookieDecoder = c.cookieDecoder;
/*  55 */     this.headers = c.headers;
/*  56 */     this.isWebsocket = (c.websocketClientSpec != null);
/*  57 */     this.method = c.method;
/*  58 */     this.uri = (c.uri == null) ? c.uriStr : c.uri.toString();
/*  59 */     this.path = (this.uri != null) ? HttpOperations.resolvePath(this.uri) : null;
/*  60 */     this.responseTimeout = c.responseTimeout;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpClientRequest addCookie(Cookie cookie) {
/*  65 */     throw new UnsupportedOperationException("Should not add Cookie");
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpClientRequest addHeader(CharSequence name, CharSequence value) {
/*  70 */     throw new UnsupportedOperationException("Should not add Header");
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<CharSequence, Set<Cookie>> cookies() {
/*  75 */     return Cookies.newClientResponseHolder(this.headers, this.cookieDecoder)
/*  76 */       .getCachedCookies();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Context currentContext() {
/*  82 */     return Context.of(this.contextView);
/*     */   }
/*     */ 
/*     */   
/*     */   public ContextView currentContextView() {
/*  87 */     return this.contextView;
/*     */   }
/*     */ 
/*     */   
/*     */   public String fullPath() {
/*  92 */     return this.path;
/*     */   }
/*     */ 
/*     */   
/*     */   public String requestId() {
/*  97 */     return "";
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpClientRequest header(CharSequence name, CharSequence value) {
/* 102 */     throw new UnsupportedOperationException("Should not add Header");
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpClientRequest headers(HttpHeaders headers) {
/* 107 */     throw new UnsupportedOperationException("Should not add Header");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isFollowRedirect() {
/* 112 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isKeepAlive() {
/* 117 */     return HttpHeaderValues.CLOSE.contentEqualsIgnoreCase(this.headers.get((CharSequence)HttpHeaderNames.CONNECTION));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isWebsocket() {
/* 122 */     return this.isWebsocket;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpMethod method() {
/* 127 */     return this.method;
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] redirectedFrom() {
/* 132 */     return EMPTY;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpHeaders requestHeaders() {
/* 137 */     return this.headers;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpClientRequest responseTimeout(Duration maxReadOperationInterval) {
/* 142 */     throw new UnsupportedOperationException("Should not add request timeout");
/*     */   }
/*     */ 
/*     */   
/*     */   public String resourceUrl() {
/* 147 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String uri() {
/* 152 */     return this.uri;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpVersion version() {
/* 157 */     return HttpVersion.HTTP_1_1;
/*     */   }
/*     */   
/* 160 */   static final String[] EMPTY = new String[0];
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\client\FailedHttpClientRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */