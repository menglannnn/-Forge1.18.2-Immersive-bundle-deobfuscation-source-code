/*    */ package reactor.netty.http.client;
/*    */ 
/*    */ import io.micrometer.core.instrument.Meter;
/*    */ import io.micrometer.core.instrument.Timer;
/*    */ import java.net.SocketAddress;
/*    */ import java.time.Duration;
/*    */ import reactor.netty.Metrics;
/*    */ import reactor.netty.channel.MeterKey;
/*    */ import reactor.netty.http.MicrometerHttpMetricsRecorder;
/*    */ import reactor.netty.internal.util.MapUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MicrometerHttpClientMetricsRecorder
/*    */   extends MicrometerHttpMetricsRecorder
/*    */   implements HttpClientMetricsRecorder
/*    */ {
/* 43 */   static final MicrometerHttpClientMetricsRecorder INSTANCE = new MicrometerHttpClientMetricsRecorder();
/*    */   
/*    */   private MicrometerHttpClientMetricsRecorder() {
/* 46 */     super("reactor.netty.http.client", "http");
/*    */   }
/*    */ 
/*    */   
/*    */   public void recordDataReceivedTime(SocketAddress remoteAddress, String uri, String method, String status, Duration time) {
/* 51 */     String address = Metrics.formatSocketAddress(remoteAddress);
/* 52 */     MeterKey meterKey = new MeterKey(uri, address, method, status);
/* 53 */     Timer dataReceivedTime = (Timer)MapUtils.computeIfAbsent(this.dataReceivedTimeCache, meterKey, key -> (Timer)filter((Meter)Timer.builder(name() + ".data.received.time").description("Time spent in consuming incoming data").tags(new String[] { "remote.address", address, "uri", uri, "method", method, "status", status }).register(Metrics.REGISTRY)));
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 58 */     if (dataReceivedTime != null) {
/* 59 */       dataReceivedTime.record(time);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public void recordDataSentTime(SocketAddress remoteAddress, String uri, String method, Duration time) {
/* 65 */     String address = Metrics.formatSocketAddress(remoteAddress);
/* 66 */     MeterKey meterKey = new MeterKey(uri, address, method, null);
/* 67 */     Timer dataSentTime = (Timer)MapUtils.computeIfAbsent(this.dataSentTimeCache, meterKey, key -> (Timer)filter((Meter)Timer.builder(name() + ".data.sent.time").description("Time spent in sending outgoing data").tags(new String[] { "remote.address", address, "uri", uri, "method", method }).register(Metrics.REGISTRY)));
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 72 */     if (dataSentTime != null) {
/* 73 */       dataSentTime.record(time);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public void recordResponseTime(SocketAddress remoteAddress, String uri, String method, String status, Duration time) {
/* 79 */     String address = Metrics.formatSocketAddress(remoteAddress);
/* 80 */     MeterKey meterKey = new MeterKey(uri, address, method, status);
/* 81 */     Timer responseTime = (Timer)MapUtils.computeIfAbsent(this.responseTimeCache, meterKey, key -> (Timer)filter((Meter)Timer.builder(name() + ".response.time").description("Total time for the request/response").tags(new String[] { "remote.address", address, "uri", uri, "method", method, "status", status }).register(Metrics.REGISTRY)));
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 86 */     if (responseTime != null)
/* 87 */       responseTime.record(time); 
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\client\MicrometerHttpClientMetricsRecorder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */