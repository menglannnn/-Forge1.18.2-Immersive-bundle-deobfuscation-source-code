/*     */ package reactor.netty.http;
/*     */ 
/*     */ import io.netty.handler.codec.http2.Http2Settings;
/*     */ import java.util.Objects;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Http2SettingsSpec
/*     */ {
/*     */   final Long headerTableSize;
/*     */   final Integer initialWindowSize;
/*     */   final Long maxConcurrentStreams;
/*     */   final Integer maxFrameSize;
/*     */   final Long maxHeaderListSize;
/*     */   final Long maxStreams;
/*     */   final Boolean pushEnabled;
/*     */   
/*     */   public static Builder builder() {
/* 104 */     return new Build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Long headerTableSize() {
/* 114 */     return this.headerTableSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Integer initialWindowSize() {
/* 124 */     return this.initialWindowSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Long maxConcurrentStreams() {
/* 134 */     return this.maxConcurrentStreams;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Integer maxFrameSize() {
/* 144 */     return this.maxFrameSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Long maxHeaderListSize() {
/* 155 */     return this.maxHeaderListSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Long maxStreams() {
/* 166 */     return this.maxStreams;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Boolean pushEnabled() {
/* 176 */     return this.pushEnabled;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 181 */     if (this == o) {
/* 182 */       return true;
/*     */     }
/* 184 */     if (!(o instanceof Http2SettingsSpec)) {
/* 185 */       return false;
/*     */     }
/* 187 */     Http2SettingsSpec that = (Http2SettingsSpec)o;
/* 188 */     return (Objects.equals(this.headerTableSize, that.headerTableSize) && 
/* 189 */       Objects.equals(this.initialWindowSize, that.initialWindowSize) && 
/* 190 */       Objects.equals(this.maxConcurrentStreams, that.maxConcurrentStreams) && 
/* 191 */       Objects.equals(this.maxFrameSize, that.maxFrameSize) && this.maxHeaderListSize
/* 192 */       .equals(that.maxHeaderListSize) && 
/* 193 */       Objects.equals(this.maxStreams, that.maxStreams) && 
/* 194 */       Objects.equals(this.pushEnabled, that.pushEnabled));
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 199 */     int result = 1;
/* 200 */     result = 31 * result + Long.hashCode(this.headerTableSize.longValue());
/* 201 */     result = 31 * result + this.initialWindowSize.intValue();
/* 202 */     result = 31 * result + Long.hashCode(this.maxConcurrentStreams.longValue());
/* 203 */     result = 31 * result + this.maxFrameSize.intValue();
/* 204 */     result = 31 * result + Long.hashCode(this.maxHeaderListSize.longValue());
/* 205 */     result = 31 * result + Long.hashCode(this.maxStreams.longValue());
/* 206 */     result = 31 * result + Boolean.hashCode(this.pushEnabled.booleanValue());
/* 207 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Http2SettingsSpec(Build build) {
/* 219 */     Http2Settings settings = build.http2Settings;
/* 220 */     this.headerTableSize = settings.headerTableSize();
/* 221 */     this.initialWindowSize = settings.initialWindowSize();
/* 222 */     if (settings.maxConcurrentStreams() != null) {
/* 223 */       this.maxConcurrentStreams = Long.valueOf((build.maxStreams != null) ? 
/* 224 */           Math.min(settings.maxConcurrentStreams().longValue(), build.maxStreams.longValue()) : settings.maxConcurrentStreams().longValue());
/*     */     } else {
/*     */       
/* 227 */       this.maxConcurrentStreams = build.maxStreams;
/*     */     } 
/* 229 */     this.maxFrameSize = settings.maxFrameSize();
/* 230 */     this.maxHeaderListSize = settings.maxHeaderListSize();
/* 231 */     this.maxStreams = build.maxStreams;
/* 232 */     this.pushEnabled = settings.pushEnabled();
/*     */   }
/*     */   
/*     */   static final class Build implements Builder {
/*     */     Long maxStreams;
/* 237 */     final Http2Settings http2Settings = Http2Settings.defaultSettings();
/*     */ 
/*     */     
/*     */     public Http2SettingsSpec build() {
/* 241 */       return new Http2SettingsSpec(this);
/*     */     }
/*     */ 
/*     */     
/*     */     public Http2SettingsSpec.Builder headerTableSize(long headerTableSize) {
/* 246 */       this.http2Settings.headerTableSize(headerTableSize);
/* 247 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public Http2SettingsSpec.Builder initialWindowSize(int initialWindowSize) {
/* 252 */       this.http2Settings.initialWindowSize(initialWindowSize);
/* 253 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public Http2SettingsSpec.Builder maxConcurrentStreams(long maxConcurrentStreams) {
/* 258 */       this.http2Settings.maxConcurrentStreams(maxConcurrentStreams);
/* 259 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public Http2SettingsSpec.Builder maxFrameSize(int maxFrameSize) {
/* 264 */       this.http2Settings.maxFrameSize(maxFrameSize);
/* 265 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public Http2SettingsSpec.Builder maxHeaderListSize(long maxHeaderListSize) {
/* 270 */       this.http2Settings.maxHeaderListSize(maxHeaderListSize);
/* 271 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public Http2SettingsSpec.Builder maxStreams(long maxStreams) {
/* 276 */       if (maxStreams < 1L) {
/* 277 */         throw new IllegalArgumentException("maxStreams must be positive");
/*     */       }
/* 279 */       this.maxStreams = Long.valueOf(maxStreams);
/* 280 */       return this;
/*     */     }
/*     */   }
/*     */   
/*     */   public static interface Builder {
/*     */     Http2SettingsSpec build();
/*     */     
/*     */     Builder headerTableSize(long param1Long);
/*     */     
/*     */     Builder initialWindowSize(int param1Int);
/*     */     
/*     */     Builder maxConcurrentStreams(long param1Long);
/*     */     
/*     */     Builder maxFrameSize(int param1Int);
/*     */     
/*     */     Builder maxHeaderListSize(long param1Long);
/*     */     
/*     */     Builder maxStreams(long param1Long);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\Http2SettingsSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */