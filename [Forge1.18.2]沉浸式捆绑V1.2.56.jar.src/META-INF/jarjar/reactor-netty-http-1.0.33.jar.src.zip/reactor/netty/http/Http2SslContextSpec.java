/*     */ package reactor.netty.http;
/*     */ 
/*     */ import io.netty.handler.codec.http2.Http2SecurityUtil;
/*     */ import io.netty.handler.ssl.ApplicationProtocolConfig;
/*     */ import io.netty.handler.ssl.CipherSuiteFilter;
/*     */ import io.netty.handler.ssl.SslContextBuilder;
/*     */ import io.netty.handler.ssl.SslProvider;
/*     */ import io.netty.handler.ssl.SupportedCipherSuiteFilter;
/*     */ import java.io.File;
/*     */ import java.io.InputStream;
/*     */ import java.security.PrivateKey;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.function.Consumer;
/*     */ import javax.net.ssl.KeyManager;
/*     */ import javax.net.ssl.KeyManagerFactory;
/*     */ import reactor.netty.tcp.AbstractProtocolSslContextSpec;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Http2SslContextSpec
/*     */   extends AbstractProtocolSslContextSpec<Http2SslContextSpec>
/*     */ {
/*     */   static final Consumer<SslContextBuilder> DEFAULT_CONFIGURATOR;
/*     */   
/*     */   public static Http2SslContextSpec forClient() {
/*  59 */     return new Http2SslContextSpec(SslContextBuilder.forClient());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Http2SslContextSpec forServer(File keyCertChainFile, File keyFile) {
/*  68 */     return new Http2SslContextSpec(SslContextBuilder.forServer(keyCertChainFile, keyFile));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Http2SslContextSpec forServer(File keyCertChainFile, File keyFile, String keyPassword) {
/*  77 */     return new Http2SslContextSpec(SslContextBuilder.forServer(keyCertChainFile, keyFile, keyPassword));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Http2SslContextSpec forServer(InputStream keyCertChainInputStream, InputStream keyInputStream) {
/*  86 */     return new Http2SslContextSpec(SslContextBuilder.forServer(keyCertChainInputStream, keyInputStream));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Http2SslContextSpec forServer(InputStream keyCertChainInputStream, InputStream keyInputStream, String keyPassword) {
/*  96 */     return new Http2SslContextSpec(SslContextBuilder.forServer(keyCertChainInputStream, keyInputStream, keyPassword));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Http2SslContextSpec forServer(KeyManager keyManager) {
/* 105 */     return new Http2SslContextSpec(SslContextBuilder.forServer(keyManager));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Http2SslContextSpec forServer(KeyManagerFactory keyManagerFactory) {
/* 114 */     return new Http2SslContextSpec(SslContextBuilder.forServer(keyManagerFactory));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Http2SslContextSpec forServer(PrivateKey key, Iterable<? extends X509Certificate> keyCertChain) {
/* 123 */     return new Http2SslContextSpec(SslContextBuilder.forServer(key, keyCertChain));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Http2SslContextSpec forServer(PrivateKey key, String keyPassword, Iterable<? extends X509Certificate> keyCertChain) {
/* 133 */     return new Http2SslContextSpec(SslContextBuilder.forServer(key, keyPassword, keyCertChain));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Http2SslContextSpec forServer(PrivateKey key, String keyPassword, X509Certificate... keyCertChain) {
/* 142 */     return new Http2SslContextSpec(SslContextBuilder.forServer(key, keyPassword, keyCertChain));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Http2SslContextSpec forServer(PrivateKey key, X509Certificate... keyCertChain) {
/* 151 */     return new Http2SslContextSpec(SslContextBuilder.forServer(key, keyCertChain));
/*     */   }
/*     */   
/*     */   Http2SslContextSpec(SslContextBuilder sslContextBuilder) {
/* 155 */     super(sslContextBuilder);
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2SslContextSpec get() {
/* 160 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Consumer<SslContextBuilder> defaultConfiguration() {
/* 165 */     return DEFAULT_CONFIGURATOR;
/*     */   }
/*     */   static {
/* 168 */     DEFAULT_CONFIGURATOR = (sslCtxBuilder -> sslCtxBuilder.sslProvider(SslProvider.isAlpnSupported(SslProvider.OPENSSL) ? SslProvider.OPENSSL : SslProvider.JDK).ciphers(Http2SecurityUtil.CIPHERS, (CipherSuiteFilter)SupportedCipherSuiteFilter.INSTANCE).applicationProtocolConfig(new ApplicationProtocolConfig(ApplicationProtocolConfig.Protocol.ALPN, ApplicationProtocolConfig.SelectorFailureBehavior.NO_ADVERTISE, ApplicationProtocolConfig.SelectedListenerFailureBehavior.ACCEPT, new String[] { "h2", "http/1.1" })));
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\Http2SslContextSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */