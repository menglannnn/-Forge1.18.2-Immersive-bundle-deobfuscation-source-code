/*     */ package reactor.netty.http;
/*     */ 
/*     */ import io.netty.handler.codec.http.HttpHeaderNames;
/*     */ import io.netty.handler.codec.http.HttpHeaders;
/*     */ import io.netty.handler.codec.http.cookie.ClientCookieDecoder;
/*     */ import io.netty.handler.codec.http.cookie.Cookie;
/*     */ import io.netty.handler.codec.http.cookie.CookieDecoder;
/*     */ import io.netty.handler.codec.http.cookie.ServerCookieDecoder;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Cookies
/*     */ {
/*     */   static final int NOT_READ = 0;
/*     */   static final int READING = 1;
/*     */   static final int READ = 2;
/*     */   final HttpHeaders nettyHeaders;
/*     */   final CharSequence cookiesHeaderName;
/*     */   final boolean isClientChannel;
/*     */   final CookieDecoder decoder;
/*     */   protected Map<CharSequence, Set<Cookie>> cachedCookies;
/*     */   volatile int state;
/*     */   
/*     */   public static Cookies newClientResponseHolder(HttpHeaders headers, ClientCookieDecoder decoder) {
/*  48 */     return new Cookies(headers, (CharSequence)HttpHeaderNames.SET_COOKIE, true, (CookieDecoder)decoder);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static Cookies newServerRequestHolder(HttpHeaders headers, ServerCookieDecoder decoder) {
/*  62 */     return new Cookies(headers, (CharSequence)HttpHeaderNames.COOKIE, false, (CookieDecoder)decoder);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  79 */   static final AtomicIntegerFieldUpdater<Cookies> STATE = AtomicIntegerFieldUpdater.newUpdater(Cookies.class, "state");
/*     */ 
/*     */   
/*     */   protected Cookies(HttpHeaders nettyHeaders, CharSequence cookiesHeaderName, boolean isClientChannel, CookieDecoder decoder) {
/*  83 */     this.nettyHeaders = Objects.<HttpHeaders>requireNonNull(nettyHeaders, "nettyHeaders");
/*  84 */     this.cookiesHeaderName = cookiesHeaderName;
/*  85 */     this.isClientChannel = isClientChannel;
/*  86 */     this.decoder = Objects.<CookieDecoder>requireNonNull(decoder, "decoder");
/*  87 */     this.cachedCookies = Collections.emptyMap();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<CharSequence, Set<Cookie>> getCachedCookies() {
/*  96 */     if (!markReadingCookies()) { do {
/*     */       
/*  98 */       } while (!hasReadCookies());
/*  99 */       return this.cachedCookies; }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 104 */     List<String> allCookieHeaders = allCookieHeaders();
/* 105 */     Map<String, Set<Cookie>> cookies = new HashMap<>();
/* 106 */     for (String aCookieHeader : allCookieHeaders) {
/*     */       
/* 108 */       if (this.isClientChannel) {
/* 109 */         Cookie c = ((ClientCookieDecoder)this.decoder).decode(aCookieHeader);
/* 110 */         if (c == null) {
/*     */           continue;
/*     */         }
/* 113 */         Set<Cookie> existingCookiesOfName = cookies.computeIfAbsent(c.name(), k -> new HashSet());
/* 114 */         existingCookiesOfName.add(c);
/*     */         continue;
/*     */       } 
/* 117 */       Set<Cookie> decode = ((ServerCookieDecoder)this.decoder).decode(aCookieHeader);
/* 118 */       for (Cookie cookie : decode) {
/* 119 */         Set<Cookie> existingCookiesOfName = cookies.computeIfAbsent(cookie.name(), k -> new HashSet());
/* 120 */         existingCookiesOfName.add(cookie);
/*     */       } 
/*     */     } 
/*     */     
/* 124 */     this.cachedCookies = Collections.unmodifiableMap((Map)cookies);
/* 125 */     markReadCookies();
/* 126 */     return this.cachedCookies;
/*     */   }
/*     */   
/*     */   protected List<String> allCookieHeaders() {
/* 130 */     return this.nettyHeaders.getAll(this.cookiesHeaderName);
/*     */   }
/*     */   
/*     */   protected final boolean hasReadCookies() {
/* 134 */     return (this.state == 2);
/*     */   }
/*     */   
/*     */   protected final boolean markReadCookies() {
/* 138 */     return STATE.compareAndSet(this, 1, 2);
/*     */   }
/*     */   
/*     */   protected final boolean markReadingCookies() {
/* 142 */     return STATE.compareAndSet(this, 0, 1);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-http-1.0.33.jar!\reactor\netty\http\Cookies.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */