/*    */ package discord4j.rest.http;
/*    */ 
/*    */ import io.netty.buffer.ByteBuf;
/*    */ import reactor.core.publisher.Mono;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EmptyReaderStrategy
/*    */   implements ReaderStrategy<Void>
/*    */ {
/*    */   public boolean canRead(@Nullable Class<?> type, @Nullable String contentType) {
/* 30 */     return (type == Void.class);
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Void> read(Mono<ByteBuf> content, Class<Void> responseType) {
/* 35 */     return Mono.empty();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\http\EmptyReaderStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */