/*    */ package discord4j.rest.http;
/*    */ 
/*    */ import com.fasterxml.jackson.core.JsonProcessingException;
/*    */ import com.fasterxml.jackson.databind.ObjectMapper;
/*    */ import discord4j.rest.util.MultipartRequest;
/*    */ import java.io.InputStream;
/*    */ import java.util.List;
/*    */ import reactor.core.Exceptions;
/*    */ import reactor.core.publisher.Mono;
/*    */ import reactor.netty.http.client.HttpClient;
/*    */ import reactor.netty.http.client.HttpClientForm;
/*    */ import reactor.netty.http.client.HttpClientRequest;
/*    */ import reactor.util.Logger;
/*    */ import reactor.util.Loggers;
/*    */ import reactor.util.annotation.Nullable;
/*    */ import reactor.util.function.Tuple2;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MultipartWriterStrategy
/*    */   implements WriterStrategy<MultipartRequest<?>>
/*    */ {
/* 42 */   private static final Logger log = Loggers.getLogger(MultipartWriterStrategy.class);
/*    */   
/*    */   private final ObjectMapper objectMapper;
/*    */   
/*    */   public MultipartWriterStrategy(ObjectMapper objectMapper) {
/* 47 */     this.objectMapper = objectMapper;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean canWrite(@Nullable Class<?> type, @Nullable String contentType) {
/* 52 */     return (contentType != null && contentType.equals("multipart/form-data"));
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<HttpClient.ResponseReceiver<?>> write(HttpClient.RequestSender send, @Nullable MultipartRequest<?> body) {
/* 57 */     if (body == null) {
/* 58 */       return Mono.empty();
/*    */     }
/* 60 */     Object createRequest = body.getJsonPayload();
/* 61 */     List<Tuple2<String, InputStream>> files = body.getFiles();
/* 62 */     return Mono.fromCallable(() -> send.sendForm(()));
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\http\MultipartWriterStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */