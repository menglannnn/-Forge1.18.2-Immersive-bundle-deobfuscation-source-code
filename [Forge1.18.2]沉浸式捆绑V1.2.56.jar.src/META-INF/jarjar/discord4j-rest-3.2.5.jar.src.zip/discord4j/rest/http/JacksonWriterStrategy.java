/*    */ package discord4j.rest.http;
/*    */ 
/*    */ import com.fasterxml.jackson.core.JsonProcessingException;
/*    */ import com.fasterxml.jackson.databind.JavaType;
/*    */ import com.fasterxml.jackson.databind.ObjectMapper;
/*    */ import com.fasterxml.jackson.databind.type.TypeFactory;
/*    */ import io.netty.buffer.ByteBufAllocator;
/*    */ import java.lang.reflect.Type;
/*    */ import java.nio.charset.StandardCharsets;
/*    */ import org.reactivestreams.Publisher;
/*    */ import reactor.core.Exceptions;
/*    */ import reactor.core.publisher.Mono;
/*    */ import reactor.netty.ByteBufFlux;
/*    */ import reactor.netty.http.client.HttpClient;
/*    */ import reactor.util.Logger;
/*    */ import reactor.util.Loggers;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JacksonWriterStrategy
/*    */   implements WriterStrategy<Object>
/*    */ {
/* 40 */   private static final Logger log = Loggers.getLogger(JacksonWriterStrategy.class);
/*    */   
/*    */   private final ObjectMapper objectMapper;
/*    */   
/*    */   public JacksonWriterStrategy(ObjectMapper objectMapper) {
/* 45 */     this.objectMapper = objectMapper;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean canWrite(@Nullable Class<?> type, @Nullable String contentType) {
/* 50 */     if (type == null || contentType == null || !contentType.startsWith("application/json")) {
/* 51 */       return false;
/*    */     }
/* 53 */     Class<?> rawClass = getJavaType(type).getRawClass();
/*    */     
/* 55 */     return (Object.class == rawClass || (
/* 56 */       !String.class.isAssignableFrom(rawClass) && this.objectMapper.canSerialize(rawClass)));
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<HttpClient.ResponseReceiver<?>> write(HttpClient.RequestSender sender, @Nullable Object body) {
/* 61 */     if (body == null) {
/* 62 */       return Mono.error(new RuntimeException("Missing body"));
/*    */     }
/*    */     
/* 65 */     Mono<String> source = Mono.fromCallable(() -> mapToString(body)).doOnNext(json -> {
/*    */           if (log.isTraceEnabled()) {
/*    */             log.trace("{}", new Object[] { json });
/*    */           }
/*    */         });
/* 70 */     return Mono.fromCallable(() -> sender.send((Publisher)ByteBufFlux.fromString((Publisher)source, StandardCharsets.UTF_8, ByteBufAllocator.DEFAULT)));
/*    */   }
/*    */ 
/*    */   
/*    */   private String mapToString(Object value) {
/*    */     try {
/* 76 */       return this.objectMapper.writeValueAsString(value);
/* 77 */     } catch (JsonProcessingException e) {
/* 78 */       throw Exceptions.propagate(e);
/*    */     } 
/*    */   }
/*    */   
/*    */   private JavaType getJavaType(Type type) {
/* 83 */     TypeFactory typeFactory = this.objectMapper.getTypeFactory();
/* 84 */     return typeFactory.constructType(type);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\http\JacksonWriterStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */