/*    */ package discord4j.rest.http;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class DefaultExchangeStrategies
/*    */   implements ExchangeStrategies
/*    */ {
/*    */   private final List<WriterStrategy<?>> writers;
/*    */   private final List<ReaderStrategy<?>> readers;
/*    */   
/*    */   DefaultExchangeStrategies(List<WriterStrategy<?>> writers, List<ReaderStrategy<?>> readers) {
/* 29 */     this.writers = Collections.unmodifiableList(writers);
/* 30 */     this.readers = Collections.unmodifiableList(readers);
/*    */   }
/*    */ 
/*    */   
/*    */   public List<WriterStrategy<?>> writers() {
/* 35 */     return this.writers;
/*    */   }
/*    */ 
/*    */   
/*    */   public List<ReaderStrategy<?>> readers() {
/* 40 */     return this.readers;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\http\DefaultExchangeStrategies.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */