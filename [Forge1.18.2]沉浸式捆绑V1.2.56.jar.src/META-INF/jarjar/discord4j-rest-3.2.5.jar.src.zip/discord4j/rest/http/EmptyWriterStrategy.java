/*    */ package discord4j.rest.http;
/*    */ 
/*    */ import org.reactivestreams.Publisher;
/*    */ import reactor.core.publisher.Mono;
/*    */ import reactor.netty.ByteBufFlux;
/*    */ import reactor.netty.http.client.HttpClient;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EmptyWriterStrategy
/*    */   implements WriterStrategy<Void>
/*    */ {
/*    */   public boolean canWrite(@Nullable Class<?> type, @Nullable String contentType) {
/* 31 */     return (type == null);
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<HttpClient.ResponseReceiver<?>> write(HttpClient.RequestSender sender, @Nullable Void body) {
/* 36 */     return Mono.just(sender.send((Publisher)ByteBufFlux.empty()));
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\http\EmptyWriterStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */