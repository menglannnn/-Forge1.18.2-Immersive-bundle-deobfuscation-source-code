/*    */ package discord4j.rest.http;
/*    */ 
/*    */ import com.fasterxml.jackson.core.JsonProcessingException;
/*    */ import com.fasterxml.jackson.databind.JavaType;
/*    */ import com.fasterxml.jackson.databind.ObjectMapper;
/*    */ import io.netty.buffer.ByteBuf;
/*    */ import io.netty.util.IllegalReferenceCountException;
/*    */ import java.io.IOException;
/*    */ import java.lang.reflect.Type;
/*    */ import java.nio.charset.StandardCharsets;
/*    */ import reactor.core.Exceptions;
/*    */ import reactor.core.publisher.Mono;
/*    */ import reactor.core.publisher.SynchronousSink;
/*    */ import reactor.util.Logger;
/*    */ import reactor.util.Loggers;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JacksonReaderStrategy<T>
/*    */   implements ReaderStrategy<T>
/*    */ {
/* 41 */   private static final Logger log = Loggers.getLogger(JacksonReaderStrategy.class);
/*    */   
/*    */   private final ObjectMapper objectMapper;
/*    */   
/*    */   public JacksonReaderStrategy(ObjectMapper objectMapper) {
/* 46 */     this.objectMapper = objectMapper;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean canRead(@Nullable Class<?> type, @Nullable String contentType) {
/* 51 */     if (type == null || contentType == null || !contentType.startsWith("application/json")) {
/* 52 */       return false;
/*    */     }
/*    */ 
/*    */     
/* 56 */     return (!CharSequence.class.isAssignableFrom(type) && this.objectMapper.canDeserialize(getJavaType(type)));
/*    */   }
/*    */   
/*    */   private JavaType getJavaType(Type type) {
/* 60 */     return this.objectMapper.getTypeFactory().constructType(type);
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<T> read(Mono<ByteBuf> content, Class<T> responseType) {
/* 65 */     return ((Mono)content.as(JacksonReaderStrategy::byteArray))
/* 66 */       .map(bytes -> {
/*    */           if (log.isTraceEnabled()) {
/*    */             log.trace("{}", new Object[] { new String(bytes, StandardCharsets.UTF_8) });
/*    */           }
/*    */           try {
/*    */             return this.objectMapper.readValue(bytes, responseType);
/* 72 */           } catch (JsonProcessingException e) {
/*    */             
/*    */             throw Exceptions.propagate(new RuntimeException(e.toString().replaceAll("(\"token\": ?\")([A-Za-z0-9._-]*)(\")", "$1hunter2$3")));
/* 75 */           } catch (IOException e) {
/*    */             throw Exceptions.propagate(e);
/*    */           } 
/*    */         });
/*    */   }
/*    */   
/*    */   private static Mono<byte[]> byteArray(Mono<ByteBuf> byteBufMono) {
/* 82 */     return byteBufMono.handle((buf, sink) -> {
/*    */           try {
/*    */             byte[] bytes = new byte[buf.readableBytes()];
/*    */             buf.readBytes(bytes);
/*    */             sink.next(bytes);
/* 87 */           } catch (IllegalReferenceCountException e) {
/*    */             sink.complete();
/*    */           } 
/*    */         });
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\http\JacksonReaderStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */