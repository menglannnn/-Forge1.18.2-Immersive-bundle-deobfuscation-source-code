/*    */ package discord4j.rest.http;
/*    */ 
/*    */ import discord4j.rest.json.response.ErrorResponse;
/*    */ import io.netty.buffer.ByteBuf;
/*    */ import io.netty.util.IllegalReferenceCountException;
/*    */ import java.nio.charset.StandardCharsets;
/*    */ import reactor.core.publisher.Mono;
/*    */ import reactor.core.publisher.SynchronousSink;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FallbackReaderStrategy
/*    */   implements ReaderStrategy<Object>
/*    */ {
/*    */   public boolean canRead(@Nullable Class<?> type, @Nullable String contentType) {
/* 35 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Object> read(Mono<ByteBuf> content, Class<Object> responseType) {
/* 40 */     if (ErrorResponse.class.isAssignableFrom(responseType)) {
/* 41 */       return content.handle((buf, sink) -> {
/*    */             try {
/*    */               ErrorResponse response = new ErrorResponse();
/*    */               response.getFields().put("body", asString(buf));
/*    */               sink.next(response);
/* 46 */             } catch (IllegalReferenceCountException e) {
/*    */               sink.complete();
/*    */             } 
/*    */           });
/*    */     }
/* 51 */     return content.handle((buf, sink) -> {
/*    */           try {
/*    */             sink.next(asString(buf));
/* 54 */           } catch (IllegalReferenceCountException e) {
/*    */             sink.complete();
/*    */           } 
/*    */         });
/*    */   }
/*    */   
/*    */   private String asString(ByteBuf buf) {
/* 61 */     return buf.readCharSequence(buf.readableBytes(), StandardCharsets.UTF_8).toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\http\FallbackReaderStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */