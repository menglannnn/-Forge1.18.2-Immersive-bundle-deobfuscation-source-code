/*     */ package discord4j.rest.http;
/*     */ 
/*     */ import com.fasterxml.jackson.databind.ObjectMapper;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface ExchangeStrategies
/*     */ {
/*     */   List<WriterStrategy<?>> writers();
/*     */   
/*     */   List<ReaderStrategy<?>> readers();
/*     */   
/*     */   static ExchangeStrategies jackson(ObjectMapper mapper) {
/*  52 */     List<WriterStrategy<?>> writerStrategies = new ArrayList<>();
/*  53 */     writerStrategies.add(new MultipartWriterStrategy(mapper));
/*  54 */     writerStrategies.add(new JacksonWriterStrategy(mapper));
/*  55 */     writerStrategies.add(new EmptyWriterStrategy());
/*  56 */     writerStrategies.add(new FormUrlEncodedWriterStrategy());
/*  57 */     List<ReaderStrategy<?>> readerStrategies = new ArrayList<>();
/*  58 */     readerStrategies.add(new JacksonReaderStrategy(mapper));
/*  59 */     readerStrategies.add(new EmptyReaderStrategy());
/*  60 */     readerStrategies.add(new FallbackReaderStrategy());
/*  61 */     return new DefaultExchangeStrategies(writerStrategies, readerStrategies);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Builder
/*     */   {
/*  69 */     private final List<WriterStrategy<?>> writerStrategies = new ArrayList<>();
/*  70 */     private final List<ReaderStrategy<?>> readerStrategies = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder writerStrategy(WriterStrategy<?> writerStrategy) {
/*  79 */       this.writerStrategies.add(writerStrategy);
/*  80 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder readerStrategy(ReaderStrategy<?> readerStrategy) {
/*  90 */       this.readerStrategies.add(readerStrategy);
/*  91 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ExchangeStrategies build() {
/* 100 */       return new DefaultExchangeStrategies(this.writerStrategies, this.readerStrategies);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\http\ExchangeStrategies.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */