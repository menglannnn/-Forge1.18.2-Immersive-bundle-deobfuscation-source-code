/*    */ package discord4j.rest.http;
/*    */ 
/*    */ import io.netty.buffer.ByteBufAllocator;
/*    */ import java.nio.charset.StandardCharsets;
/*    */ import org.reactivestreams.Publisher;
/*    */ import reactor.core.publisher.Mono;
/*    */ import reactor.netty.ByteBufFlux;
/*    */ import reactor.netty.http.client.HttpClient;
/*    */ import reactor.util.Logger;
/*    */ import reactor.util.Loggers;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FormUrlEncodedWriterStrategy
/*    */   implements WriterStrategy<String>
/*    */ {
/* 35 */   private static final Logger log = Loggers.getLogger(FormUrlEncodedWriterStrategy.class);
/*    */ 
/*    */   
/*    */   public boolean canWrite(@Nullable Class<?> type, @Nullable String contentType) {
/* 39 */     return (type != null && contentType != null && contentType.startsWith("application/x-www-form-urlencoded") && String.class
/* 40 */       .isAssignableFrom(type));
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<HttpClient.ResponseReceiver<?>> write(HttpClient.RequestSender sender, @Nullable String body) {
/* 45 */     if (body == null) {
/* 46 */       return Mono.error(new RuntimeException("Missing body"));
/*    */     }
/* 48 */     Mono<String> source = Mono.just(body).doOnNext(payload -> {
/*    */           if (log.isTraceEnabled()) {
/*    */             log.trace("{}", new Object[] { body });
/*    */           }
/*    */         });
/* 53 */     return Mono.fromCallable(() -> sender.send((Publisher)ByteBufFlux.fromString((Publisher)source, StandardCharsets.UTF_8, ByteBufAllocator.DEFAULT)));
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\http\FormUrlEncodedWriterStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */