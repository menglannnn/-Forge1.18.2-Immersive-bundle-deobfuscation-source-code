package discord4j.rest.http;

import reactor.core.publisher.Mono;
import reactor.netty.http.client.HttpClient;
import reactor.util.annotation.Nullable;

public interface WriterStrategy<R> {
  boolean canWrite(@Nullable Class<?> paramClass, @Nullable String paramString);
  
  Mono<HttpClient.ResponseReceiver<?>> write(HttpClient.RequestSender paramRequestSender, @Nullable R paramR);
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\http\WriterStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */