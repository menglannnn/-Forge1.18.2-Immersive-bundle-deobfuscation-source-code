/*     */ package discord4j.rest.http.client;
/*     */ 
/*     */ import discord4j.rest.http.ExchangeStrategies;
/*     */ import discord4j.rest.http.ReaderStrategy;
/*     */ import discord4j.rest.json.response.ErrorResponse;
/*     */ import discord4j.rest.request.DiscordWebRequest;
/*     */ import discord4j.rest.response.ResponseFunction;
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.handler.codec.http.HttpHeaderNames;
/*     */ import io.netty.util.ReferenceCounted;
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import java.util.function.Function;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.netty.NettyInbound;
/*     */ import reactor.netty.http.client.HttpClientResponse;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.Loggers;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClientResponse
/*     */ {
/*  48 */   private static final Logger log = Loggers.getLogger(ClientResponse.class);
/*     */   
/*     */   private final HttpClientResponse response;
/*     */   private final NettyInbound inbound;
/*     */   private final ExchangeStrategies exchangeStrategies;
/*     */   private final ClientRequest clientRequest;
/*     */   private final List<ResponseFunction> responseFunctions;
/*  55 */   private final AtomicBoolean reject = new AtomicBoolean();
/*     */ 
/*     */   
/*     */   ClientResponse(HttpClientResponse response, NettyInbound inbound, ExchangeStrategies exchangeStrategies, ClientRequest clientRequest, List<ResponseFunction> responseFunctions) {
/*  59 */     this.response = response;
/*  60 */     this.inbound = inbound;
/*  61 */     this.exchangeStrategies = exchangeStrategies;
/*  62 */     this.clientRequest = clientRequest;
/*  63 */     this.responseFunctions = responseFunctions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpClientResponse getHttpResponse() {
/*  73 */     return this.response;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<ByteBuf> getBody() {
/*  83 */     return this.inbound.receive()
/*  84 */       .aggregate()
/*  85 */       .doOnSubscribe(s -> {
/*     */           
/*     */           if (this.reject.get()) {
/*     */             throw new IllegalStateException("Response body can only be consumed once");
/*     */           }
/*  90 */         }).doOnCancel(() -> this.reject.set(true))
/*     */       
/*  92 */       .doOnNext(buf -> buf.touch("discord4j.client.response"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> Mono<T> bodyToMono(Class<T> responseType) {
/* 105 */     return Mono.defer(() -> (this.response.status().code() >= 400) ? createException().flatMap(Mono::error) : Mono.just(this))
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 113 */       .transform(getResponseTransformers(this.clientRequest.getDiscordRequest()))
/* 114 */       .flatMap(res -> {
/*     */           String responseContentType = this.response.responseHeaders().get((CharSequence)HttpHeaderNames.CONTENT_TYPE);
/*     */           Optional<ReaderStrategy<?>> readerStrategy = this.exchangeStrategies.readers().stream().filter(()).findFirst();
/*     */           return ((Mono)readerStrategy.map(ClientResponse::cast).map(()).orElseGet(())).checkpoint("Body from " + this.clientRequest.getDescription() + " [ClientResponse]");
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Function<Mono<ClientResponse>, Mono<ClientResponse>> getResponseTransformers(DiscordWebRequest discordRequest) {
/* 127 */     return this.responseFunctions.stream()
/* 128 */       .map(rt -> rt.transform(discordRequest).andThen(()))
/*     */ 
/*     */       
/* 131 */       .reduce(Function::andThen)
/* 132 */       .orElse(mono -> mono);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<ClientException> createException() {
/* 142 */     String responseContentType = this.response.responseHeaders().get((CharSequence)HttpHeaderNames.CONTENT_TYPE);
/*     */ 
/*     */     
/* 145 */     Optional<ReaderStrategy<?>> readerStrategy = this.exchangeStrategies.readers().stream().filter(s -> s.canRead(ErrorResponse.class, responseContentType)).findFirst();
/* 146 */     return Mono.justOrEmpty(readerStrategy)
/* 147 */       .map(ClientResponse::cast)
/* 148 */       .flatMap(s -> s.read(getBody(), ErrorResponse.class))
/* 149 */       .flatMap(s -> Mono.just(clientException(this.clientRequest, this.response, s)))
/* 150 */       .switchIfEmpty(Mono.just(clientException(this.clientRequest, this.response, null)))
/* 151 */       .checkpoint(this.response.status().toString() + " from " + this.clientRequest
/* 152 */         .getDescription() + " [ClientResponse]");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> skipBody() {
/* 161 */     return getBody().map(ReferenceCounted::release).then();
/*     */   }
/*     */ 
/*     */   
/*     */   private static <T> ReaderStrategy<T> cast(ReaderStrategy<?> strategy) {
/* 166 */     return (ReaderStrategy)strategy;
/*     */   }
/*     */ 
/*     */   
/*     */   private static ClientException clientException(ClientRequest request, HttpClientResponse response, @Nullable ErrorResponse errorResponse) {
/* 171 */     return new ClientException(request, response, errorResponse);
/*     */   }
/*     */   
/*     */   private static RuntimeException noReaderException(Object body, String contentType) {
/* 175 */     return new RuntimeException("No strategies to read this response: " + body + " - " + contentType);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 180 */     return "ClientResponse{response=" + this.response + '}';
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\http\client\ClientResponse.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */