/*    */ package discord4j.rest.http.client;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum AuthorizationScheme
/*    */ {
/* 21 */   BOT("Bot"), BEARER("Bearer"), BASIC("Basic"), NONE("");
/*    */   
/*    */   private final String scheme;
/*    */   
/*    */   AuthorizationScheme(String scheme) {
/* 26 */     this.scheme = scheme;
/*    */   }
/*    */   
/*    */   public String getScheme() {
/* 30 */     return this.scheme;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\http\client\AuthorizationScheme.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */