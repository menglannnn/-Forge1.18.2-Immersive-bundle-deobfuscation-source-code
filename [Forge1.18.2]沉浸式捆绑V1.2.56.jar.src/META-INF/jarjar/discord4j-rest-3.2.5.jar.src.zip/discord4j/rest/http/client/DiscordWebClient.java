/*     */ package discord4j.rest.http.client;
/*     */ 
/*     */ import discord4j.common.GitProperties;
/*     */ import discord4j.common.LogUtil;
/*     */ import discord4j.rest.http.ExchangeStrategies;
/*     */ import discord4j.rest.http.WriterStrategy;
/*     */ import discord4j.rest.response.ResponseFunction;
/*     */ import io.netty.handler.codec.http.DefaultHttpHeaders;
/*     */ import io.netty.handler.codec.http.HttpHeaderNames;
/*     */ import io.netty.handler.codec.http.HttpHeaders;
/*     */ import java.time.Instant;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.netty.Connection;
/*     */ import reactor.netty.ConnectionObserver;
/*     */ import reactor.netty.http.client.HttpClient;
/*     */ import reactor.netty.http.client.HttpClientRequest;
/*     */ import reactor.netty.http.client.HttpClientResponse;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.Loggers;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ import reactor.util.context.ContextView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DiscordWebClient
/*     */ {
/*  46 */   private static final Logger log = Loggers.getLogger(DiscordWebClient.class);
/*     */   
/*     */   public static final String KEY_REQUEST_TIMESTAMP = "discord4j.request.timestamp";
/*     */   
/*     */   private final HttpClient httpClient;
/*     */   
/*     */   private final HttpHeaders defaultHeaders;
/*     */   
/*     */   private final ExchangeStrategies exchangeStrategies;
/*     */   private final List<ResponseFunction> responseFunctions;
/*     */   
/*     */   public DiscordWebClient(HttpClient httpClient, ExchangeStrategies exchangeStrategies, AuthorizationScheme authorizationScheme, String token, List<ResponseFunction> responseFunctions, String discordBaseUrl) {
/*  58 */     this(httpClient, exchangeStrategies, authorizationScheme.getScheme(), token, responseFunctions, discordBaseUrl);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DiscordWebClient(HttpClient httpClient, ExchangeStrategies exchangeStrategies, String authorizationScheme, String token, List<ResponseFunction> responseFunctions, String discordBaseUrl) {
/*  73 */     Properties properties = GitProperties.getProperties();
/*  74 */     String version = properties.getProperty("git.build.version", "3");
/*  75 */     String url = properties.getProperty("application.url", "https://discord4j.com");
/*     */     
/*  77 */     DefaultHttpHeaders defaultHttpHeaders = new DefaultHttpHeaders();
/*  78 */     defaultHttpHeaders.add((CharSequence)HttpHeaderNames.CONTENT_TYPE, "application/json");
/*  79 */     defaultHttpHeaders.add((CharSequence)HttpHeaderNames.AUTHORIZATION, authorizationScheme + " " + token);
/*  80 */     defaultHttpHeaders.add((CharSequence)HttpHeaderNames.USER_AGENT, "DiscordBot(" + url + ", " + version + ")");
/*     */     
/*  82 */     this.httpClient = configureHttpClient(httpClient.baseUrl(discordBaseUrl));
/*  83 */     this.defaultHeaders = (HttpHeaders)defaultHttpHeaders;
/*  84 */     this.exchangeStrategies = exchangeStrategies;
/*  85 */     this.responseFunctions = responseFunctions;
/*     */   }
/*     */   
/*     */   private HttpClient configureHttpClient(HttpClient httpClient) {
/*  89 */     if (log.isTraceEnabled()) {
/*  90 */       return httpClient.observe((connection, state) -> {
/*     */             if (connection instanceof ConnectionObserver) {
/*     */               ConnectionObserver observer = (ConnectionObserver)connection;
/*     */               log.trace(LogUtil.format((ContextView)observer.currentContext(), "{} {}"), new Object[] { state, connection });
/*     */             } else if (connection instanceof HttpClientRequest) {
/*     */               HttpClientRequest httpClientRequest = (HttpClientRequest)connection;
/*     */               log.trace(LogUtil.format(httpClientRequest.currentContextView(), "{} {}"), new Object[] { state, connection });
/*     */             } 
/*     */           });
/*     */     }
/* 100 */     return httpClient;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpClient getHttpClient() {
/* 109 */     return this.httpClient;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpHeaders getDefaultHeaders() {
/* 118 */     return this.defaultHeaders;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ExchangeStrategies getExchangeStrategies() {
/* 127 */     return this.exchangeStrategies;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<ClientResponse> exchange(ClientRequest request) {
/* 139 */     return Mono.defer(() -> {
/*     */           HttpHeaders requestHeaders = buildHttpHeaders(request);
/*     */ 
/*     */ 
/*     */           
/*     */           String contentType = requestHeaders.get((CharSequence)HttpHeaderNames.CONTENT_TYPE);
/*     */ 
/*     */           
/*     */           HttpClient.RequestSender sender = (HttpClient.RequestSender)this.httpClient.headers(()).request(request.getMethod()).uri(request.getUrl());
/*     */ 
/*     */           
/*     */           Object body = request.getBody();
/*     */ 
/*     */           
/*     */           return this.exchangeStrategies.writers().stream().filter(()).findFirst().map(DiscordWebClient::cast).map(()).orElseGet(());
/* 154 */         }).flatMap(receiver -> receiver.responseConnection(()).next())
/*     */ 
/*     */       
/* 157 */       .contextWrite(ctx -> ctx.put("discord4j.request.timestamp", Long.valueOf(Instant.now().toEpochMilli())));
/*     */   }
/*     */   
/*     */   private <R> HttpHeaders buildHttpHeaders(ClientRequest request) {
/* 161 */     HttpHeaders headers = (new DefaultHttpHeaders()).add(this.defaultHeaders).setAll(request.getHeaders());
/* 162 */     if (request.getAuthorizationScheme() == AuthorizationScheme.NONE) {
/* 163 */       headers.remove((CharSequence)HttpHeaderNames.AUTHORIZATION);
/* 164 */     } else if (request.getAuthorizationScheme() != null) {
/* 165 */       headers.set((CharSequence)HttpHeaderNames.AUTHORIZATION, request
/* 166 */           .getAuthorizationScheme().getScheme() + " " + request.getAuthorizationValue());
/*     */     } 
/* 168 */     if (request.getBody() == null) {
/* 169 */       headers.remove((CharSequence)HttpHeaderNames.CONTENT_TYPE);
/*     */     }
/* 171 */     return headers;
/*     */   }
/*     */ 
/*     */   
/*     */   private static <T> WriterStrategy<T> cast(WriterStrategy<?> strategy) {
/* 176 */     return (WriterStrategy)strategy;
/*     */   }
/*     */   
/*     */   private static RuntimeException noWriterException(@Nullable Object body, String contentType) {
/* 180 */     return new RuntimeException("No strategies to write this request: " + body + " - " + contentType);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\http\client\DiscordWebClient.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */