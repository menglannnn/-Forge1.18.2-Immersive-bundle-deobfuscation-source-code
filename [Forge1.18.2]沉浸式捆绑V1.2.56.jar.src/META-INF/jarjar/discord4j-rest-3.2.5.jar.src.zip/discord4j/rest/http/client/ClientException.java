/*     */ package discord4j.rest.http.client;
/*     */ 
/*     */ import discord4j.rest.json.response.ErrorResponse;
/*     */ import io.netty.handler.codec.http.HttpHeaders;
/*     */ import io.netty.handler.codec.http.HttpResponseStatus;
/*     */ import java.time.Duration;
/*     */ import java.util.Arrays;
/*     */ import java.util.Optional;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Predicate;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.netty.http.client.HttpClientResponse;
/*     */ import reactor.retry.RetryContext;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.retry.Retry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClientException
/*     */   extends RuntimeException
/*     */ {
/*     */   private final ClientRequest request;
/*     */   private final HttpClientResponse response;
/*     */   private final ErrorResponse errorResponse;
/*     */   
/*     */   public ClientException(ClientRequest request, HttpClientResponse response, @Nullable ErrorResponse errorResponse) {
/*  84 */     super(request.getMethod().toString() + " " + request.getUrl() + " returned " + response.status().toString() + (
/*  85 */         (errorResponse != null) ? (" with response " + errorResponse.getFields()) : ""));
/*  86 */     this.request = request;
/*  87 */     this.response = response;
/*  88 */     this.errorResponse = errorResponse;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClientRequest getRequest() {
/*  97 */     return this.request;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpClientResponse getResponse() {
/* 106 */     return this.response;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpResponseStatus getStatus() {
/* 116 */     return getResponse().status();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpHeaders getHeaders() {
/* 126 */     return getResponse().responseHeaders();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<ErrorResponse> getErrorResponse() {
/* 137 */     return Optional.ofNullable(this.errorResponse);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Predicate<Throwable> isStatusCode(int code) {
/* 149 */     return t -> {
/*     */         if (t instanceof ClientException) {
/*     */           ClientException e = (ClientException)t;
/*     */           return (e.getStatus().code() == code);
/*     */         } 
/*     */         return false;
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Predicate<Throwable> isStatusCode(Integer... codes) {
/* 167 */     return t -> {
/*     */         if (t instanceof ClientException) {
/*     */           ClientException e = (ClientException)t;
/*     */           return Arrays.<Integer>asList(codes).contains(Integer.valueOf(e.getStatus().code()));
/*     */         } 
/*     */         return false;
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Predicate<RetryContext<?>> isRetryContextStatusCode(int code) {
/* 186 */     return ctx -> isStatusCode(code).test(ctx.exception());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Predicate<RetryContext<?>> isRetryContextStatusCode(Integer... codes) {
/* 199 */     return ctx -> isStatusCode(codes).test(ctx.exception());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Function<Mono<T>, Publisher<T>> emptyOnStatus(int code) {
/* 213 */     return mono -> mono.onErrorResume(isStatusCode(code), ());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Function<Mono<T>, Publisher<T>> retryOnceOnStatus(int code) {
/* 227 */     return mono -> mono.retryWhen((Retry)Retry.backoff(1L, Duration.ofSeconds(1L)).filter(isStatusCode(code)));
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\http\client\ClientException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */