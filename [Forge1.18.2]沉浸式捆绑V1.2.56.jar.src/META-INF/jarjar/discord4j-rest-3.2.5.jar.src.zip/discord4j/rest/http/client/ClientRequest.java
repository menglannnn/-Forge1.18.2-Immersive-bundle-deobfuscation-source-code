/*     */ package discord4j.rest.http.client;
/*     */ 
/*     */ import discord4j.rest.request.DiscordWebRequest;
/*     */ import discord4j.rest.route.Route;
/*     */ import discord4j.rest.util.RouteUtils;
/*     */ import io.netty.handler.codec.http.DefaultHttpHeaders;
/*     */ import io.netty.handler.codec.http.HttpHeaderNames;
/*     */ import io.netty.handler.codec.http.HttpHeaders;
/*     */ import io.netty.handler.codec.http.HttpMethod;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import java.util.Set;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClientRequest
/*     */ {
/*     */   private final String id;
/*     */   private final DiscordWebRequest request;
/*     */   private final String url;
/*     */   private final HttpHeaders headers;
/*     */   private final Object body;
/*     */   @Nullable
/*     */   private final AuthorizationScheme authorizationScheme;
/*     */   @Nullable
/*     */   private final String authorizationValue;
/*     */   
/*     */   public ClientRequest(DiscordWebRequest request) {
/*  54 */     this.request = request;
/*  55 */     this.url = RouteUtils.expandQuery(request.getCompleteUri(), request.getQueryParams());
/*  56 */     this
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  63 */       .headers = (HttpHeaders)Optional.<Map>ofNullable(request.getHeaders()).map(map -> (HttpHeaders)map.entrySet().stream().reduce(new DefaultHttpHeaders(), (), HttpHeaders::add)).orElse(new DefaultHttpHeaders());
/*  64 */     this.body = request.getBody();
/*  65 */     this.id = Integer.toHexString(System.identityHashCode(this));
/*  66 */     this.authorizationScheme = request.getAuthorizationScheme();
/*  67 */     this.authorizationValue = request.getAuthorizationValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getId() {
/*  76 */     return this.id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpMethod getMethod() {
/*  85 */     return this.request.getRoute().getMethod();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getUrl() {
/*  94 */     return this.url;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpHeaders getHeaders() {
/* 103 */     return this.headers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object getBody() {
/* 113 */     return this.body;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DiscordWebRequest getDiscordRequest() {
/* 122 */     return this.request;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Route getRoute() {
/* 131 */     return this.request.getRoute();
/*     */   }
/*     */   
/*     */   public String getDescription() {
/* 135 */     return this.request.getDescription();
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public AuthorizationScheme getAuthorizationScheme() {
/* 140 */     return this.authorizationScheme;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public String getAuthorizationValue() {
/* 145 */     return this.authorizationValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 150 */     return "ClientRequest{method=" + 
/* 151 */       getMethod() + ", url='" + this.url + '\'' + ", headers=" + this.headers
/*     */       
/* 153 */       .copy().remove((CharSequence)HttpHeaderNames.AUTHORIZATION).toString() + ", body=" + this.body + ", id=" + this.id + '}';
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\http\client\ClientRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */