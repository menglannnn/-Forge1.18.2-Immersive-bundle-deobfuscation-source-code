package discord4j.rest.http;

import io.netty.buffer.ByteBuf;
import reactor.core.publisher.Mono;
import reactor.util.annotation.Nullable;

public interface ReaderStrategy<T> {
  boolean canRead(@Nullable Class<?> paramClass, @Nullable String paramString);
  
  Mono<T> read(Mono<ByteBuf> paramMono, Class<T> paramClass);
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\http\ReaderStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */