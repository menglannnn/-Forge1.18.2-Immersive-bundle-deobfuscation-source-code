/*     */ package discord4j.rest.interaction;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.discordjson.Id;
/*     */ import discord4j.discordjson.json.ApplicationCommandInteractionData;
/*     */ import discord4j.discordjson.json.FollowupMessageRequest;
/*     */ import discord4j.discordjson.json.ImmutableFollowupMessageRequest;
/*     */ import discord4j.discordjson.json.ImmutableInteractionResponseData;
/*     */ import discord4j.discordjson.json.InteractionApplicationCommandCallbackData;
/*     */ import discord4j.discordjson.json.InteractionData;
/*     */ import discord4j.discordjson.json.InteractionResponseData;
/*     */ import discord4j.discordjson.json.MessageData;
/*     */ import discord4j.discordjson.json.UserData;
/*     */ import discord4j.discordjson.json.WebhookExecuteRequest;
/*     */ import discord4j.discordjson.json.WebhookMessageEditRequest;
/*     */ import discord4j.rest.RestClient;
/*     */ import discord4j.rest.util.InteractionResponseType;
/*     */ import discord4j.rest.util.MultipartRequest;
/*     */ import java.util.Collections;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class InteractionOperations
/*     */   implements RestInteraction, InteractionResponse, GuildInteraction, DirectInteraction
/*     */ {
/*     */   private final RestClient restClient;
/*     */   private final InteractionData interactionData;
/*     */   private final long applicationId;
/*     */   private final InteractionMemberOperations memberOperations;
/*     */   
/*     */   InteractionOperations(RestClient restClient, InteractionData interactionData) {
/*  37 */     this.restClient = restClient;
/*  38 */     this.interactionData = interactionData;
/*  39 */     this.applicationId = Snowflake.asLong(interactionData.applicationId());
/*  40 */     this.memberOperations = new InteractionMemberOperations(restClient, interactionData);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getGuildId() {
/*  48 */     return Snowflake.of((Id)this.interactionData.guildId().get());
/*     */   }
/*     */ 
/*     */   
/*     */   public InteractionMember getInteractionMember() {
/*  53 */     return this.memberOperations;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UserData getUserData() {
/*  61 */     return (UserData)this.interactionData.user().get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InteractionData getData() {
/*  69 */     return this.interactionData;
/*     */   }
/*     */ 
/*     */   
/*     */   public Snowflake getId() {
/*  74 */     return Snowflake.of(this.interactionData.id());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getChannelId() {
/*  80 */     return Snowflake.of((Id)this.interactionData.channelId().get());
/*     */   }
/*     */ 
/*     */   
/*     */   public ApplicationCommandInteractionData getCommandInteractionData() {
/*  85 */     return (ApplicationCommandInteractionData)this.interactionData.data().get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FollowupInteractionHandler acknowledge() {
/*  93 */     ImmutableInteractionResponseData immutableInteractionResponseData = InteractionResponseData.builder().type(InteractionResponseType.DEFERRED_CHANNEL_MESSAGE_WITH_SOURCE.getValue()).data((InteractionApplicationCommandCallbackData)InteractionApplicationCommandCallbackData.builder().build()).build();
/*  94 */     return new FollowupInteractionHandler((InteractionResponseData)immutableInteractionResponseData, __ -> Mono.empty());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FollowupInteractionHandler acknowledgeEphemeral() {
/* 104 */     ImmutableInteractionResponseData immutableInteractionResponseData = InteractionResponseData.builder().type(InteractionResponseType.DEFERRED_CHANNEL_MESSAGE_WITH_SOURCE.getValue()).data((InteractionApplicationCommandCallbackData)InteractionApplicationCommandCallbackData.builder().flags(Integer.valueOf(64)).build()).build();
/* 105 */     return new FollowupInteractionHandler((InteractionResponseData)immutableInteractionResponseData, __ -> Mono.empty());
/*     */   }
/*     */ 
/*     */   
/*     */   public FollowupInteractionHandler reply(String content) {
/* 110 */     return reply((InteractionApplicationCommandCallbackData)InteractionApplicationCommandCallbackData.builder()
/* 111 */         .content(content)
/* 112 */         .build());
/*     */   }
/*     */ 
/*     */   
/*     */   public FollowupInteractionHandler replyEphemeral(String content) {
/* 117 */     return reply((InteractionApplicationCommandCallbackData)InteractionApplicationCommandCallbackData.builder()
/* 118 */         .content(content)
/* 119 */         .flags(Integer.valueOf(6))
/* 120 */         .build());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FollowupInteractionHandler reply(InteractionApplicationCommandCallbackData callbackData) {
/* 128 */     ImmutableInteractionResponseData immutableInteractionResponseData = InteractionResponseData.builder().type(InteractionResponseType.CHANNEL_MESSAGE_WITH_SOURCE.getValue()).data(callbackData).build();
/* 129 */     return new FollowupInteractionHandler((InteractionResponseData)immutableInteractionResponseData, __ -> Mono.empty());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<MessageData> getInitialResponse() {
/* 137 */     return this.restClient.getWebhookService()
/* 138 */       .getWebhookMessage(this.applicationId, this.interactionData.token(), "@original");
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<MessageData> editInitialResponse(WebhookMessageEditRequest request) {
/* 143 */     return this.restClient.getWebhookService()
/* 144 */       .modifyWebhookMessage(this.applicationId, this.interactionData.token(), "@original", request);
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<MessageData> editInitialResponse(MultipartRequest<WebhookMessageEditRequest> request) {
/* 149 */     return this.restClient.getWebhookService()
/* 150 */       .modifyWebhookMessage(this.applicationId, this.interactionData.token(), "@original", request);
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> deleteInitialResponse() {
/* 155 */     return this.restClient.getWebhookService()
/* 156 */       .deleteWebhookMessage(this.applicationId, this.interactionData.token(), "@original");
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<MessageData> createFollowupMessage(String content) {
/* 161 */     ImmutableFollowupMessageRequest immutableFollowupMessageRequest = FollowupMessageRequest.builder().content(content).build();
/* 162 */     return this.restClient.getWebhookService()
/* 163 */       .executeWebhook(this.applicationId, this.interactionData.token(), true, 
/* 164 */         MultipartRequest.ofRequestAndFiles(immutableFollowupMessageRequest, Collections.emptyList()));
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<MessageData> createFollowupMessage(MultipartRequest<? extends WebhookExecuteRequest> request) {
/* 169 */     return this.restClient.getWebhookService()
/* 170 */       .executeWebhook(this.applicationId, this.interactionData.token(), true, request);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<MessageData> createFollowupMessageEphemeral(String content) {
/* 178 */     ImmutableFollowupMessageRequest immutableFollowupMessageRequest = FollowupMessageRequest.builder().content(content).flags(Integer.valueOf(64)).build();
/* 179 */     return this.restClient.getWebhookService()
/* 180 */       .executeWebhook(this.applicationId, this.interactionData.token(), true, MultipartRequest.ofRequest(immutableFollowupMessageRequest));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<MessageData> createFollowupMessageEphemeral(MultipartRequest<WebhookExecuteRequest> request) {
/* 188 */     ImmutableFollowupMessageRequest immutableFollowupMessageRequest = FollowupMessageRequest.builder().from((WebhookExecuteRequest)request.getJsonPayload()).flags(Integer.valueOf(64)).build();
/* 189 */     return this.restClient.getWebhookService()
/* 190 */       .executeWebhook(this.applicationId, this.interactionData.token(), true, MultipartRequest.ofRequest(immutableFollowupMessageRequest));
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<MessageData> editFollowupMessage(long messageId, WebhookMessageEditRequest request, boolean wait) {
/* 195 */     return this.restClient.getWebhookService()
/* 196 */       .modifyWebhookMessage(this.applicationId, this.interactionData.token(), String.valueOf(messageId), request);
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<MessageData> editFollowupMessage(long messageId, MultipartRequest<WebhookMessageEditRequest> request) {
/* 201 */     return this.restClient.getWebhookService()
/* 202 */       .modifyWebhookMessage(this.applicationId, this.interactionData.token(), String.valueOf(messageId), request);
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> deleteFollowupMessage(long messageId) {
/* 207 */     return this.restClient.getWebhookService()
/* 208 */       .deleteWebhookMessage(this.applicationId, this.interactionData.token(), String.valueOf(messageId));
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\interaction\InteractionOperations.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */