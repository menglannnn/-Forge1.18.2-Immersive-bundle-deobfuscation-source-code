/*    */ package discord4j.rest.interaction;
/*    */ 
/*    */ import discord4j.common.util.Snowflake;
/*    */ import discord4j.discordjson.json.ApplicationCommandData;
/*    */ import discord4j.discordjson.json.ApplicationCommandRequest;
/*    */ import discord4j.rest.RestClient;
/*    */ import java.util.List;
/*    */ import org.reactivestreams.Publisher;
/*    */ import reactor.core.publisher.Flux;
/*    */ import reactor.core.publisher.Mono;
/*    */ import reactor.util.Logger;
/*    */ import reactor.util.Loggers;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GuildCommandRegistrar
/*    */ {
/* 37 */   private static final Logger log = Loggers.getLogger(GuildCommandRegistrar.class);
/*    */   
/*    */   private final RestClient restClient;
/*    */   private final List<ApplicationCommandRequest> commandRequests;
/*    */   private final Mono<Long> applicationId;
/*    */   
/*    */   private GuildCommandRegistrar(RestClient restClient, List<ApplicationCommandRequest> commandRequests) {
/* 44 */     this.restClient = restClient;
/* 45 */     this.commandRequests = commandRequests;
/* 46 */     this.applicationId = restClient.getApplicationId().cache();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static GuildCommandRegistrar create(RestClient restClient, List<ApplicationCommandRequest> commandRequests) {
/* 58 */     return new GuildCommandRegistrar(restClient, commandRequests);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Flux<ApplicationCommandData> registerCommands(Snowflake guildId) {
/* 68 */     return bulkOverwriteCommands(guildId, this.commandRequests);
/*    */   }
/*    */ 
/*    */   
/*    */   private Flux<ApplicationCommandData> bulkOverwriteCommands(Snowflake guildId, List<ApplicationCommandRequest> requests) {
/* 73 */     return this.applicationId.flatMapMany(id -> this.restClient.getApplicationService().bulkOverwriteGuildApplicationCommand(id.longValue(), guildId.asLong(), requests).doOnNext(()));
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\interaction\GuildCommandRegistrar.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */