package discord4j.rest.interaction;

import discord4j.common.annotations.Experimental;
import discord4j.common.util.Snowflake;

@Experimental
public interface GuildInteraction extends RestInteraction {
  Snowflake getGuildId();
  
  InteractionMember getInteractionMember();
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\interaction\GuildInteraction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */