package discord4j.rest.interaction;

import discord4j.common.annotations.Experimental;
import discord4j.discordjson.json.ApplicationCommandInteractionData;

@Experimental
public interface ApplicationCommandDefinition {
  boolean test(ApplicationCommandInteractionData paramApplicationCommandInteractionData);
  
  InteractionHandler createResponseHandler(RestInteraction paramRestInteraction);
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\interaction\ApplicationCommandDefinition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */