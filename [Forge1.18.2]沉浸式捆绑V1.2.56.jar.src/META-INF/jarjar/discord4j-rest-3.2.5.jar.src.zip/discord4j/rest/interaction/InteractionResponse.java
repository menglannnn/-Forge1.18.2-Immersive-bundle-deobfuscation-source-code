package discord4j.rest.interaction;

import discord4j.common.annotations.Experimental;
import discord4j.discordjson.json.MessageData;
import discord4j.discordjson.json.WebhookExecuteRequest;
import discord4j.discordjson.json.WebhookMessageEditRequest;
import discord4j.rest.util.MultipartRequest;
import reactor.core.publisher.Mono;

@Experimental
public interface InteractionResponse {
  Mono<MessageData> getInitialResponse();
  
  Mono<MessageData> editInitialResponse(WebhookMessageEditRequest paramWebhookMessageEditRequest);
  
  Mono<MessageData> editInitialResponse(MultipartRequest<WebhookMessageEditRequest> paramMultipartRequest);
  
  Mono<Void> deleteInitialResponse();
  
  Mono<MessageData> createFollowupMessage(String paramString);
  
  Mono<MessageData> createFollowupMessage(MultipartRequest<? extends WebhookExecuteRequest> paramMultipartRequest);
  
  Mono<MessageData> createFollowupMessageEphemeral(String paramString);
  
  Mono<MessageData> createFollowupMessageEphemeral(MultipartRequest<WebhookExecuteRequest> paramMultipartRequest);
  
  Mono<MessageData> editFollowupMessage(long paramLong, WebhookMessageEditRequest paramWebhookMessageEditRequest, boolean paramBoolean);
  
  Mono<MessageData> editFollowupMessage(long paramLong, MultipartRequest<WebhookMessageEditRequest> paramMultipartRequest);
  
  Mono<Void> deleteFollowupMessage(long paramLong);
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\interaction\InteractionResponse.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */