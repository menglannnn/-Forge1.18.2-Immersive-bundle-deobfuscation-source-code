/*    */ package discord4j.rest.interaction;
/*    */ 
/*    */ import discord4j.common.util.Snowflake;
/*    */ import discord4j.discordjson.Id;
/*    */ import discord4j.discordjson.json.InteractionData;
/*    */ import discord4j.discordjson.json.MemberData;
/*    */ import discord4j.rest.RestClient;
/*    */ import discord4j.rest.entity.RestMember;
/*    */ import discord4j.rest.entity.RestRole;
/*    */ import discord4j.rest.util.PermissionSet;
/*    */ import java.util.Set;
/*    */ import java.util.stream.Collectors;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class InteractionMemberOperations
/*    */   implements InteractionMember
/*    */ {
/*    */   final RestClient restClient;
/*    */   final InteractionData interactionData;
/*    */   
/*    */   InteractionMemberOperations(RestClient restClient, InteractionData interactionData) {
/* 37 */     this.restClient = restClient;
/* 38 */     this.interactionData = interactionData;
/*    */   }
/*    */ 
/*    */   
/*    */   public MemberData getMemberData() {
/* 43 */     return (MemberData)this.interactionData.member().get();
/*    */   }
/*    */ 
/*    */   
/*    */   public Snowflake getGuildId() {
/* 48 */     return Snowflake.of((Id)this.interactionData.guildId().get());
/*    */   }
/*    */ 
/*    */   
/*    */   public Snowflake getUserId() {
/* 53 */     return Snowflake.of(getMemberData().user().id());
/*    */   }
/*    */ 
/*    */   
/*    */   public Set<RestRole> getRoles() {
/* 58 */     return (Set<RestRole>)getMemberData().roles().stream()
/* 59 */       .map(id -> RestRole.create(this.restClient, getGuildId(), Snowflake.of(id)))
/* 60 */       .collect(Collectors.toSet());
/*    */   }
/*    */ 
/*    */   
/*    */   public PermissionSet getPermissions() {
/* 65 */     return PermissionSet.of(Long.parseLong((String)getMemberData().permissions().get()));
/*    */   }
/*    */ 
/*    */   
/*    */   public RestMember asRestMember() {
/* 70 */     return RestMember.create(this.restClient, getGuildId(), getUserId());
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\interaction\InteractionMemberOperations.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */