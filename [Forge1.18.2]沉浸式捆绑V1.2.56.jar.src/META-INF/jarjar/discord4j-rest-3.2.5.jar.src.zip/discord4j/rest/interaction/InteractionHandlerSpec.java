/*    */ package discord4j.rest.interaction;
/*    */ 
/*    */ import discord4j.common.annotations.Experimental;
/*    */ import java.util.function.Function;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Experimental
/*    */ public final class InteractionHandlerSpec
/*    */ {
/*    */   private final Function<GuildInteraction, InteractionHandler> guildInteractionHandlerFunction;
/*    */   private final Function<DirectInteraction, InteractionHandler> directInteractionHandlerFunction;
/*    */   
/*    */   InteractionHandlerSpec(Function<GuildInteraction, InteractionHandler> guildInteractionHandlerFunction, Function<DirectInteraction, InteractionHandler> directInteractionHandlerFunction) {
/* 39 */     this.guildInteractionHandlerFunction = guildInteractionHandlerFunction;
/* 40 */     this.directInteractionHandlerFunction = directInteractionHandlerFunction;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public InteractionHandlerSpec guild(Function<GuildInteraction, InteractionHandler> guildInteractionHandlerFunction) {
/* 52 */     return new InteractionHandlerSpec(guildInteractionHandlerFunction, this.directInteractionHandlerFunction);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public InteractionHandlerSpec direct(Function<DirectInteraction, InteractionHandler> directInteractionHandlerFunction) {
/* 64 */     return new InteractionHandlerSpec(this.guildInteractionHandlerFunction, directInteractionHandlerFunction);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Function<RestInteraction, InteractionHandler> build() {
/* 75 */     return interaction -> interaction.getData().guildId().isAbsent() ? this.directInteractionHandlerFunction.apply((DirectInteraction)interaction) : this.guildInteractionHandlerFunction.apply((GuildInteraction)interaction);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\interaction\InteractionHandlerSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */