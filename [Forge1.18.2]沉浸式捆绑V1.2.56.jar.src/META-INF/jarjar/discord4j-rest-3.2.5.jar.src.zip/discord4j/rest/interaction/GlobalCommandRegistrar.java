/*    */ package discord4j.rest.interaction;
/*    */ 
/*    */ import discord4j.discordjson.json.ApplicationCommandData;
/*    */ import discord4j.discordjson.json.ApplicationCommandRequest;
/*    */ import discord4j.rest.RestClient;
/*    */ import java.util.List;
/*    */ import org.reactivestreams.Publisher;
/*    */ import reactor.core.publisher.Flux;
/*    */ import reactor.core.publisher.Mono;
/*    */ import reactor.util.Logger;
/*    */ import reactor.util.Loggers;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GlobalCommandRegistrar
/*    */ {
/* 36 */   private static final Logger log = Loggers.getLogger(GlobalCommandRegistrar.class);
/*    */   
/*    */   private final RestClient restClient;
/*    */   private final List<ApplicationCommandRequest> commandRequests;
/*    */   private final Mono<Long> applicationId;
/*    */   
/*    */   private GlobalCommandRegistrar(RestClient restClient, List<ApplicationCommandRequest> commandRequests) {
/* 43 */     this.restClient = restClient;
/* 44 */     this.commandRequests = commandRequests;
/* 45 */     this.applicationId = restClient.getApplicationId().cache();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static GlobalCommandRegistrar create(RestClient restClient, List<ApplicationCommandRequest> commandRequests) {
/* 58 */     return new GlobalCommandRegistrar(restClient, commandRequests);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Flux<ApplicationCommandData> registerCommands() {
/* 67 */     return bulkOverwriteCommands(this.commandRequests);
/*    */   }
/*    */   
/*    */   private Flux<ApplicationCommandData> bulkOverwriteCommands(List<ApplicationCommandRequest> requests) {
/* 71 */     return this.applicationId.flatMapMany(id -> this.restClient.getApplicationService().bulkOverwriteGlobalApplicationCommand(id.longValue(), requests).doOnNext(()));
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\interaction\GlobalCommandRegistrar.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */