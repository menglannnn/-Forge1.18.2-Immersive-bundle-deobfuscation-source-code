/*    */ package discord4j.rest.interaction;
/*    */ 
/*    */ import com.iwebpp.crypto.TweetNaclFast;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TweetNaclFastInteractionValidator
/*    */   implements InteractionValidator
/*    */ {
/*    */   private final TweetNaclFast.Signature signature;
/*    */   
/*    */   public TweetNaclFastInteractionValidator(String publicKey) {
/* 27 */     this.signature = new TweetNaclFast.Signature(hexStringToByteArray(publicKey), null);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean validateSignature(String signature, String timestamp, String body) {
/* 32 */     return this.signature.detached_verify((timestamp + body).getBytes(), hexStringToByteArray(signature));
/*    */   }
/*    */   
/*    */   private static byte[] hexStringToByteArray(String s) {
/* 36 */     int len = s.length();
/* 37 */     byte[] data = new byte[len / 2];
/* 38 */     for (int i = 0; i < len; i += 2) {
/* 39 */       data[i / 2] = 
/* 40 */         (byte)((Character.digit(s.charAt(i), 16) << 4) + Character.digit(s.charAt(i + 1), 16));
/*    */     }
/* 42 */     return data;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\interaction\TweetNaclFastInteractionValidator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */