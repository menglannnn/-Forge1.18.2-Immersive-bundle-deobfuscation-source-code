package discord4j.rest.interaction;

public interface InteractionValidator {
  boolean validateSignature(String paramString1, String paramString2, String paramString3);
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\interaction\InteractionValidator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */