package discord4j.rest.interaction;

import discord4j.common.util.Snowflake;
import discord4j.discordjson.json.MemberData;
import discord4j.rest.entity.RestMember;
import discord4j.rest.entity.RestRole;
import discord4j.rest.util.PermissionSet;
import java.util.Set;

public interface InteractionMember {
  MemberData getMemberData();
  
  Snowflake getGuildId();
  
  Snowflake getUserId();
  
  Set<RestRole> getRoles();
  
  PermissionSet getPermissions();
  
  RestMember asRestMember();
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\interaction\InteractionMember.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */