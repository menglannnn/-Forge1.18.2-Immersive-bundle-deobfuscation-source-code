package discord4j.rest.interaction;

import discord4j.common.annotations.Experimental;
import discord4j.common.util.Snowflake;
import discord4j.discordjson.json.ApplicationCommandInteractionData;
import discord4j.discordjson.json.InteractionApplicationCommandCallbackData;
import discord4j.discordjson.json.InteractionData;

@Experimental
public interface RestInteraction {
  InteractionData getData();
  
  Snowflake getId();
  
  Snowflake getChannelId();
  
  ApplicationCommandInteractionData getCommandInteractionData();
  
  FollowupInteractionHandler acknowledge();
  
  FollowupInteractionHandler acknowledgeEphemeral();
  
  FollowupInteractionHandler reply(String paramString);
  
  FollowupInteractionHandler replyEphemeral(String paramString);
  
  FollowupInteractionHandler reply(InteractionApplicationCommandCallbackData paramInteractionApplicationCommandCallbackData);
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\interaction\RestInteraction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */