/*     */ package discord4j.rest.interaction;
/*     */ 
/*     */ import com.fasterxml.jackson.databind.JsonNode;
/*     */ import com.fasterxml.jackson.databind.ObjectMapper;
/*     */ import discord4j.common.annotations.Experimental;
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.discordjson.json.ApplicationCommandInteractionData;
/*     */ import discord4j.discordjson.json.ApplicationCommandRequest;
/*     */ import discord4j.discordjson.json.InteractionData;
/*     */ import discord4j.discordjson.json.InteractionResponseData;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import discord4j.rest.RestClient;
/*     */ import io.netty.handler.codec.http.HttpResponseStatus;
/*     */ import java.time.Duration;
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ import java.util.concurrent.CopyOnWriteArrayList;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Predicate;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.core.publisher.SignalType;
/*     */ import reactor.core.scheduler.Scheduler;
/*     */ import reactor.function.TupleUtils;
/*     */ import reactor.netty.http.server.HttpServerRequest;
/*     */ import reactor.netty.http.server.HttpServerResponse;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.Loggers;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Experimental
/*     */ public class Interactions
/*     */ {
/*  72 */   private static final Logger log = Loggers.getLogger(Interactions.class);
/*     */ 
/*     */   
/*     */   private final List<ApplicationCommandDefinition> commands;
/*     */ 
/*     */   
/*     */   private final List<ApplicationCommandRequestDefinition> createRequests;
/*     */ 
/*     */ 
/*     */   
/*     */   public static Interactions create() {
/*  83 */     return new Interactions();
/*     */   }
/*     */   
/*     */   Interactions() {
/*  87 */     this.commands = new CopyOnWriteArrayList<>();
/*  88 */     this.createRequests = new CopyOnWriteArrayList<>();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Interactions onCommand(Snowflake id, Function<RestInteraction, InteractionHandler> action) {
/* 100 */     this.commands.add(new RequestApplicationCommandDefinition(acid -> acid.id().equals(Possible.of(id.asString())), action));
/* 101 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Interactions onCommand(String name, Function<RestInteraction, InteractionHandler> action) {
/* 113 */     this.commands.add(new RequestApplicationCommandDefinition(acid -> acid.name().equals(Possible.of(name)), action));
/* 114 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Interactions onGuildCommand(ApplicationCommandRequest createRequest, Snowflake guildId, Function<GuildInteraction, InteractionHandler> action) {
/* 129 */     this.commands.add(new GuildApplicationCommandDefinition(acid -> acid.name().equals(Possible.of(createRequest.name())), action));
/* 130 */     this.createRequests.add(new GuildApplicationCommandRequest(createRequest, guildId));
/* 131 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Interactions onGlobalCommand(ApplicationCommandRequest createRequest, Function<RestInteraction, InteractionHandler> action) {
/* 148 */     this.commands.add(new RequestApplicationCommandDefinition(acid -> acid.name().equals(Possible.of(createRequest.name())), action));
/* 149 */     this.createRequests.add(new GlobalApplicationCommandRequest(createRequest));
/* 150 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> createCommands(RestClient restClient) {
/* 161 */     Mono<Long> appIdMono = restClient.getApplicationId();
/*     */     
/* 163 */     return Flux.fromIterable(this.createRequests)
/* 164 */       .zipWith((Publisher)appIdMono.repeat())
/* 165 */       .flatMap(TupleUtils.function((req, appId) -> {
/*     */             if (req instanceof GuildApplicationCommandRequest) {
/*     */               GuildApplicationCommandRequest guildCommandRequest = (GuildApplicationCommandRequest)req;
/*     */ 
/*     */ 
/*     */ 
/*     */               
/*     */               return restClient.getApplicationService().createGuildApplicationCommand(appId.longValue(), guildCommandRequest.getGuild(), req.getRequest()).doOnError(()).onErrorResume(());
/*     */             } 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             return restClient.getApplicationService().createGlobalApplicationCommand(appId.longValue(), req.getRequest()).doOnError(()).onErrorResume(());
/* 179 */           })).then();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ApplicationCommandDefinition findHandler(InteractionData interactionData) {
/* 189 */     return interactionData.data().toOptional()
/* 190 */       .flatMap(acid -> this.commands.stream().filter(()).findFirst())
/*     */ 
/*     */       
/* 193 */       .orElse(NOOP_DEF);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReactorNettyServerHandler buildReactorNettyHandler(RestClient restClient) {
/* 208 */     return buildReactorNettyHandler(restClient, new NoopInteractionValidator());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReactorNettyServerHandler buildReactorNettyHandler(RestClient restClient, InteractionValidator interactionValidator) {
/* 224 */     return (serverRequest, serverResponse) -> serverRequest.receive().aggregate().asString().flatMap(());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Mono<Void> handleValidated(String body, HttpServerResponse serverResponse, RestClient restClient) {
/* 239 */     ObjectMapper mapper = restClient.getRestResources().getJacksonResources().getObjectMapper();
/* 240 */     return Mono.fromCallable(() -> (JsonNode)mapper.readValue(body, JsonNode.class))
/* 241 */       .flatMap(node -> {
/*     */           int type = node.get("type").asInt();
/*     */ 
/*     */           
/*     */           if (type == 1) {
/*     */             return serverResponse.addHeader("content-type", "application/json").chunkedTransfer(false).sendString((Publisher)Mono.just("{\"type\":1}")).then();
/*     */           }
/*     */ 
/*     */           
/*     */           if (type == 2) {
/*     */             InteractionData interactionData = (InteractionData)mapper.convertValue(node, InteractionData.class);
/*     */ 
/*     */             
/*     */             InteractionOperations ops = new InteractionOperations(restClient, interactionData);
/*     */ 
/*     */             
/*     */             InteractionHandler handler = findHandler(interactionData).createResponseHandler(ops);
/*     */ 
/*     */             
/*     */             Scheduler timedScheduler = restClient.getRestResources().getReactorResources().getTimerTaskScheduler();
/*     */ 
/*     */             
/*     */             Scheduler blockScheduler = restClient.getRestResources().getReactorResources().getBlockingTaskScheduler();
/*     */ 
/*     */             
/*     */             return serverResponse.addHeader("content-type", "application/json").chunkedTransfer(false).sendString((Publisher)Mono.fromCallable(())).then().doFinally(());
/*     */           } 
/*     */ 
/*     */           
/*     */           return serverResponse.sendNotFound();
/* 271 */         }).then();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Function<RestInteraction, InteractionHandler> guild(Function<GuildInteraction, InteractionHandler> handlerFunction) {
/* 284 */     return (new InteractionHandlerSpec(handlerFunction, it -> (InteractionHandler)NOOP_HANDLER_FUNCTION.apply(it))).build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Function<RestInteraction, InteractionHandler> direct(Function<DirectInteraction, InteractionHandler> handlerFunction) {
/* 298 */     return (new InteractionHandlerSpec(it -> (InteractionHandler)NOOP_HANDLER_FUNCTION.apply(it), handlerFunction)).build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static InteractionHandlerSpec createHandler() {
/* 310 */     return new InteractionHandlerSpec(it -> (InteractionHandler)NOOP_HANDLER_FUNCTION.apply(it), it -> (InteractionHandler)NOOP_HANDLER_FUNCTION.apply(it));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class GuildApplicationCommandRequest
/*     */     implements ApplicationCommandRequestDefinition
/*     */   {
/*     */     private final ApplicationCommandRequest request;
/*     */ 
/*     */ 
/*     */     
/*     */     private final long guild;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public GuildApplicationCommandRequest(ApplicationCommandRequest request, Snowflake guild) {
/* 330 */       this.request = request;
/* 331 */       this.guild = guild.asLong();
/*     */     }
/*     */ 
/*     */     
/*     */     public ApplicationCommandRequest getRequest() {
/* 336 */       return this.request;
/*     */     }
/*     */     
/*     */     public long getGuild() {
/* 340 */       return this.guild;
/*     */     }
/*     */   }
/*     */   
/*     */   static class GlobalApplicationCommandRequest
/*     */     implements ApplicationCommandRequestDefinition {
/*     */     private final ApplicationCommandRequest request;
/*     */     
/*     */     public GlobalApplicationCommandRequest(ApplicationCommandRequest request) {
/* 349 */       this.request = request;
/*     */     }
/*     */ 
/*     */     
/*     */     public ApplicationCommandRequest getRequest() {
/* 354 */       return this.request;
/*     */     }
/*     */   }
/*     */   
/*     */   static class RequestApplicationCommandDefinition
/*     */     implements ApplicationCommandDefinition
/*     */   {
/*     */     private final Predicate<ApplicationCommandInteractionData> matcher;
/*     */     private final Function<RestInteraction, InteractionHandler> action;
/*     */     
/*     */     public RequestApplicationCommandDefinition(Predicate<ApplicationCommandInteractionData> matcher, Function<RestInteraction, InteractionHandler> action) {
/* 365 */       this.matcher = matcher;
/* 366 */       this.action = action;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean test(ApplicationCommandInteractionData acid) {
/* 371 */       return this.matcher.test(acid);
/*     */     }
/*     */     
/*     */     public InteractionHandler createResponseHandler(RestInteraction interaction) {
/* 375 */       return this.action.apply(interaction);
/*     */     }
/*     */   }
/*     */   
/*     */   static class GuildApplicationCommandDefinition
/*     */     implements ApplicationCommandDefinition
/*     */   {
/*     */     private final Predicate<ApplicationCommandInteractionData> matcher;
/*     */     private final Function<GuildInteraction, InteractionHandler> action;
/*     */     
/*     */     public GuildApplicationCommandDefinition(Predicate<ApplicationCommandInteractionData> matcher, Function<GuildInteraction, InteractionHandler> action) {
/* 386 */       this.matcher = matcher;
/* 387 */       this.action = action;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean test(ApplicationCommandInteractionData acid) {
/* 392 */       return this.matcher.test(acid);
/*     */     }
/*     */     
/*     */     public InteractionHandler createResponseHandler(RestInteraction interaction) {
/* 396 */       return this.action.apply((GuildInteraction)interaction);
/*     */     }
/*     */   }
/*     */   
/* 400 */   static ApplicationCommandDefinition NOOP_DEF = new ApplicationCommandDefinition()
/*     */     {
/*     */       public boolean test(ApplicationCommandInteractionData acid) {
/* 403 */         return true;
/*     */       }
/*     */ 
/*     */       
/*     */       public InteractionHandler createResponseHandler(RestInteraction interaction) {
/* 408 */         return Interactions.NOOP_HANDLER_FUNCTION.apply(interaction);
/*     */       }
/*     */     };
/*     */   
/*     */   static Function<RestInteraction, InteractionHandler> NOOP_HANDLER_FUNCTION = it -> new InteractionHandler()
/*     */     {
/*     */       public InteractionResponseData response() {
/* 415 */         return it.acknowledge().response();
/*     */       }
/*     */ 
/*     */       
/*     */       public Publisher<?> onInteractionResponse(InteractionResponse response) {
/* 420 */         return (Publisher<?>)Mono.empty();
/*     */       }
/*     */     };
/*     */   
/*     */   private static class NoopInteractionValidator implements InteractionValidator {
/*     */     private NoopInteractionValidator() {}
/*     */     
/*     */     public boolean validateSignature(String body, String signature, String timestamp) {
/* 428 */       return true;
/*     */     }
/*     */   }
/*     */   
/*     */   static interface ApplicationCommandRequestDefinition {
/*     */     ApplicationCommandRequest getRequest();
/*     */   }
/*     */   
/*     */   public static interface ReactorNettyServerHandler extends BiFunction<HttpServerRequest, HttpServerResponse, Publisher<Void>> {}
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\interaction\Interactions.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */