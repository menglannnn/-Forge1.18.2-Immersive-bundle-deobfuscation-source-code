/*    */ package discord4j.rest.interaction;
/*    */ 
/*    */ import discord4j.common.annotations.Experimental;
/*    */ import discord4j.discordjson.json.InteractionResponseData;
/*    */ import java.util.function.Function;
/*    */ import org.reactivestreams.Publisher;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Experimental
/*    */ public class FollowupInteractionHandler
/*    */   implements InteractionHandler
/*    */ {
/*    */   private final InteractionResponseData responseData;
/*    */   private final Function<InteractionResponse, Publisher<?>> followupHandler;
/*    */   
/*    */   FollowupInteractionHandler(InteractionResponseData responseData, Function<InteractionResponse, Publisher<?>> followupHandler) {
/* 38 */     this.responseData = responseData;
/* 39 */     this.followupHandler = followupHandler;
/*    */   }
/*    */ 
/*    */   
/*    */   public InteractionResponseData response() {
/* 44 */     return this.responseData;
/*    */   }
/*    */ 
/*    */   
/*    */   public Publisher<?> onInteractionResponse(InteractionResponse response) {
/* 49 */     return this.followupHandler.apply(response);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public InteractionHandler withFollowup(Function<InteractionResponse, Publisher<?>> followupHandler) {
/* 61 */     return new FollowupInteractionHandler(this.responseData, followupHandler);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\interaction\FollowupInteractionHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */