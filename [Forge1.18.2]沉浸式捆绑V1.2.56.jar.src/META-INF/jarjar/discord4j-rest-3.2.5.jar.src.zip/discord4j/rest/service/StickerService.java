/*    */ package discord4j.rest.service;
/*    */ 
/*    */ import discord4j.discordjson.json.GuildStickerCreateRequest;
/*    */ import discord4j.discordjson.json.GuildStickerModifyRequest;
/*    */ import discord4j.discordjson.json.StickerData;
/*    */ import discord4j.discordjson.json.StickerPackData;
/*    */ import discord4j.rest.request.Router;
/*    */ import discord4j.rest.route.Routes;
/*    */ import reactor.core.publisher.Flux;
/*    */ import reactor.core.publisher.Mono;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ public class StickerService
/*    */   extends RestService {
/*    */   public StickerService(Router router) {
/* 16 */     super(router);
/*    */   }
/*    */   
/*    */   public Mono<StickerData> getSticker(long stickerId) {
/* 20 */     return Routes.STICKER_GET.newRequest(new Object[] { Long.valueOf(stickerId)
/* 21 */         }).exchange(getRouter())
/* 22 */       .bodyToMono(StickerData.class);
/*    */   }
/*    */   
/*    */   public Flux<StickerPackData> getStickerPacks() {
/* 26 */     return Routes.NITRO_STICKER_PACKS_GET.newRequest(new Object[0])
/* 27 */       .exchange(getRouter())
/* 28 */       .bodyToMono(StickerPackData[].class)
/* 29 */       .flatMapMany(Flux::fromArray);
/*    */   }
/*    */   
/*    */   public Flux<StickerData> getGuildStickers(long guildId) {
/* 33 */     return Routes.GUILD_STICKERS_GET.newRequest(new Object[] { Long.valueOf(guildId)
/* 34 */         }).exchange(getRouter())
/* 35 */       .bodyToMono(StickerData[].class)
/* 36 */       .flatMapMany(Flux::fromArray);
/*    */   }
/*    */   
/*    */   public Mono<StickerData> getGuildSticker(long guildId, long stickerId) {
/* 40 */     return Routes.GUILD_STICKER_GET.newRequest(new Object[] { Long.valueOf(guildId), Long.valueOf(stickerId)
/* 41 */         }).exchange(getRouter())
/* 42 */       .bodyToMono(StickerData.class);
/*    */   }
/*    */   
/*    */   public Mono<StickerData> createGuildSticker(long guildId, GuildStickerCreateRequest request, @Nullable String reason) {
/* 46 */     return Routes.GUILD_STICKER_CREATE.newRequest(new Object[] { Long.valueOf(guildId)
/* 47 */         }).body(request)
/* 48 */       .optionalHeader("X-Audit-Log-Reason", reason)
/* 49 */       .exchange(getRouter())
/* 50 */       .bodyToMono(StickerData.class);
/*    */   }
/*    */   
/*    */   public Mono<StickerData> modifyGuildSticker(long guildId, long stickerId, GuildStickerModifyRequest request, @Nullable String reason) {
/* 54 */     return Routes.GUILD_STICKER_MODIFY.newRequest(new Object[] { Long.valueOf(guildId), Long.valueOf(stickerId)
/* 55 */         }).body(request)
/* 56 */       .optionalHeader("X-Audit-Log-Reason", reason)
/* 57 */       .exchange(getRouter())
/* 58 */       .bodyToMono(StickerData.class);
/*    */   }
/*    */   
/*    */   public Mono<Void> deleteGuildSticker(long guildId, long stickerId, @Nullable String reason) {
/* 62 */     return Routes.GUILD_STICKER_DELETE.newRequest(new Object[] { Long.valueOf(guildId), Long.valueOf(stickerId)
/* 63 */         }).optionalHeader("X-Audit-Log-Reason", reason)
/* 64 */       .exchange(getRouter())
/* 65 */       .bodyToMono(Void.class);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\service\StickerService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */