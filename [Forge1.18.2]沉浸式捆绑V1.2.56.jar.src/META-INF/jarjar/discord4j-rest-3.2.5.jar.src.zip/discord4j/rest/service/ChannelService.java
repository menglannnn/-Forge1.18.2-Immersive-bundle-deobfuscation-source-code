/*     */ package discord4j.rest.service;
/*     */ 
/*     */ import discord4j.discordjson.json.BulkDeleteRequest;
/*     */ import discord4j.discordjson.json.ChannelData;
/*     */ import discord4j.discordjson.json.ChannelModifyRequest;
/*     */ import discord4j.discordjson.json.FollowedChannelData;
/*     */ import discord4j.discordjson.json.GroupAddRecipientRequest;
/*     */ import discord4j.discordjson.json.InviteCreateRequest;
/*     */ import discord4j.discordjson.json.InviteData;
/*     */ import discord4j.discordjson.json.MessageCreateRequest;
/*     */ import discord4j.discordjson.json.MessageData;
/*     */ import discord4j.discordjson.json.MessageEditRequest;
/*     */ import discord4j.discordjson.json.NewsChannelFollowRequest;
/*     */ import discord4j.discordjson.json.PermissionsEditRequest;
/*     */ import discord4j.discordjson.json.SuppressEmbedsRequest;
/*     */ import discord4j.discordjson.json.UserData;
/*     */ import discord4j.rest.request.Router;
/*     */ import discord4j.rest.route.Routes;
/*     */ import discord4j.rest.util.MultipartRequest;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ChannelService
/*     */   extends RestService
/*     */ {
/*     */   public ChannelService(Router router) {
/*  34 */     super(router);
/*     */   }
/*     */   
/*     */   public Mono<ChannelData> getChannel(long channelId) {
/*  38 */     return Routes.CHANNEL_GET.newRequest(new Object[] { Long.valueOf(channelId)
/*  39 */         }).exchange(getRouter())
/*  40 */       .bodyToMono(ChannelData.class);
/*     */   }
/*     */   
/*     */   public Mono<ChannelData> modifyChannel(long channelId, ChannelModifyRequest request, @Nullable String reason) {
/*  44 */     return Routes.CHANNEL_MODIFY_PARTIAL.newRequest(new Object[] { Long.valueOf(channelId)
/*  45 */         }).body(request)
/*  46 */       .optionalHeader("X-Audit-Log-Reason", reason)
/*  47 */       .exchange(getRouter())
/*  48 */       .bodyToMono(ChannelData.class);
/*     */   }
/*     */   
/*     */   public Mono<ChannelData> deleteChannel(long channelId, @Nullable String reason) {
/*  52 */     return Routes.CHANNEL_DELETE.newRequest(new Object[] { Long.valueOf(channelId)
/*  53 */         }).optionalHeader("X-Audit-Log-Reason", reason)
/*  54 */       .exchange(getRouter())
/*  55 */       .bodyToMono(ChannelData.class);
/*     */   }
/*     */   
/*     */   public Flux<MessageData> getMessages(long channelId, Map<String, Object> queryParams) {
/*  59 */     return Routes.MESSAGES_GET.newRequest(new Object[] { Long.valueOf(channelId)
/*  60 */         }).query(queryParams)
/*  61 */       .exchange(getRouter())
/*  62 */       .bodyToMono(MessageData[].class)
/*  63 */       .flatMapMany(Flux::fromArray);
/*     */   }
/*     */   
/*     */   public Mono<MessageData> getMessage(long channelId, long messageId) {
/*  67 */     return Routes.MESSAGE_GET.newRequest(new Object[] { Long.valueOf(channelId), Long.valueOf(messageId)
/*  68 */         }).exchange(getRouter())
/*  69 */       .bodyToMono(MessageData.class);
/*     */   }
/*     */   
/*     */   public Mono<MessageData> createMessage(long channelId, MultipartRequest<MessageCreateRequest> request) {
/*  73 */     return Routes.MESSAGE_CREATE.newRequest(new Object[] { Long.valueOf(channelId)
/*  74 */         }).header("content-type", request.getFiles().isEmpty() ? "application/json" : "multipart/form-data")
/*  75 */       .body(Objects.requireNonNull(request.getFiles().isEmpty() ? request.getJsonPayload() : request))
/*  76 */       .exchange(getRouter())
/*  77 */       .bodyToMono(MessageData.class);
/*     */   }
/*     */   
/*     */   public Mono<Void> createReaction(long channelId, long messageId, String emoji) {
/*  81 */     return Routes.REACTION_CREATE.newRequest(new Object[] { Long.valueOf(channelId), Long.valueOf(messageId), emoji
/*  82 */         }).exchange(getRouter())
/*  83 */       .bodyToMono(Void.class);
/*     */   }
/*     */   
/*     */   public Mono<Void> deleteOwnReaction(long channelId, long messageId, String emoji) {
/*  87 */     return Routes.REACTION_DELETE_OWN.newRequest(new Object[] { Long.valueOf(channelId), Long.valueOf(messageId), emoji
/*  88 */         }).exchange(getRouter())
/*  89 */       .bodyToMono(Void.class);
/*     */   }
/*     */   
/*     */   public Mono<Void> deleteReaction(long channelId, long messageId, String emoji, long userId) {
/*  93 */     return Routes.REACTION_DELETE_USER.newRequest(new Object[] { Long.valueOf(channelId), Long.valueOf(messageId), emoji, Long.valueOf(userId)
/*  94 */         }).exchange(getRouter())
/*  95 */       .bodyToMono(Void.class);
/*     */   }
/*     */   
/*     */   public Mono<Void> deleteReactions(long channelId, long messageId, String emoji) {
/*  99 */     return Routes.REACTION_DELETE.newRequest(new Object[] { Long.valueOf(channelId), Long.valueOf(messageId), emoji
/* 100 */         }).exchange(getRouter())
/* 101 */       .bodyToMono(Void.class);
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<UserData> getReactions(long channelId, long messageId, String emoji, Map<String, Object> queryParams) {
/* 106 */     return Routes.REACTIONS_GET.newRequest(new Object[] { Long.valueOf(channelId), Long.valueOf(messageId), emoji
/* 107 */         }).query(queryParams)
/* 108 */       .exchange(getRouter())
/* 109 */       .bodyToMono(UserData[].class)
/* 110 */       .flatMapMany(Flux::fromArray);
/*     */   }
/*     */   
/*     */   public Mono<Void> deleteAllReactions(long channelId, long messageId) {
/* 114 */     return Routes.REACTIONS_DELETE_ALL.newRequest(new Object[] { Long.valueOf(channelId), Long.valueOf(messageId)
/* 115 */         }).exchange(getRouter())
/* 116 */       .bodyToMono(Void.class);
/*     */   }
/*     */   
/*     */   public Mono<MessageData> editMessage(long channelId, long messageId, MultipartRequest<MessageEditRequest> request) {
/* 120 */     return Routes.MESSAGE_EDIT.newRequest(new Object[] { Long.valueOf(channelId), Long.valueOf(messageId)
/* 121 */         }).header("content-type", request.getFiles().isEmpty() ? "application/json" : "multipart/form-data")
/* 122 */       .body(Objects.requireNonNull(request.getFiles().isEmpty() ? request.getJsonPayload() : request))
/* 123 */       .exchange(getRouter())
/* 124 */       .bodyToMono(MessageData.class);
/*     */   }
/*     */   
/*     */   public Mono<Void> deleteMessage(long channelId, long messageId, @Nullable String reason) {
/* 128 */     return Routes.MESSAGE_DELETE.newRequest(new Object[] { Long.valueOf(channelId), Long.valueOf(messageId)
/* 129 */         }).optionalHeader("X-Audit-Log-Reason", reason)
/* 130 */       .exchange(getRouter())
/* 131 */       .bodyToMono(Void.class);
/*     */   }
/*     */   
/*     */   public Mono<Void> bulkDeleteMessages(long channelId, BulkDeleteRequest request) {
/* 135 */     return Routes.MESSAGE_DELETE_BULK.newRequest(new Object[] { Long.valueOf(channelId)
/* 136 */         }).body(request)
/* 137 */       .exchange(getRouter())
/* 138 */       .bodyToMono(Void.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Mono<Void> suppressEmbeds(long channelId, long messageId, SuppressEmbedsRequest request) {
/* 148 */     return Routes.MESSAGE_SUPPRESS_EMBEDS.newRequest(new Object[] { Long.valueOf(channelId), Long.valueOf(messageId)
/* 149 */         }).header("content-type", "application/json")
/* 150 */       .body(request)
/* 151 */       .exchange(getRouter())
/* 152 */       .bodyToMono(Void.class);
/*     */   }
/*     */   
/*     */   public Mono<MessageData> publishMessage(long channelId, long messageId) {
/* 156 */     return Routes.CROSSPOST_MESSAGE.newRequest(new Object[] { Long.valueOf(channelId), Long.valueOf(messageId)
/* 157 */         }).exchange(getRouter())
/* 158 */       .bodyToMono(MessageData.class);
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> editChannelPermissions(long channelId, long overwriteId, PermissionsEditRequest request, @Nullable String reason) {
/* 163 */     return Routes.CHANNEL_PERMISSIONS_EDIT.newRequest(new Object[] { Long.valueOf(channelId), Long.valueOf(overwriteId)
/* 164 */         }).body(request)
/* 165 */       .optionalHeader("X-Audit-Log-Reason", reason)
/* 166 */       .exchange(getRouter())
/* 167 */       .bodyToMono(Void.class);
/*     */   }
/*     */   
/*     */   public Flux<InviteData> getChannelInvites(long channelId) {
/* 171 */     return Routes.CHANNEL_INVITES_GET.newRequest(new Object[] { Long.valueOf(channelId)
/* 172 */         }).exchange(getRouter())
/* 173 */       .bodyToMono(InviteData[].class)
/* 174 */       .flatMapMany(Flux::fromArray);
/*     */   }
/*     */   
/*     */   public Mono<InviteData> createChannelInvite(long channelId, InviteCreateRequest request, @Nullable String reason) {
/* 178 */     return Routes.CHANNEL_INVITE_CREATE.newRequest(new Object[] { Long.valueOf(channelId)
/* 179 */         }).body(request)
/* 180 */       .optionalHeader("X-Audit-Log-Reason", reason)
/* 181 */       .exchange(getRouter())
/* 182 */       .bodyToMono(InviteData.class);
/*     */   }
/*     */   
/*     */   public Mono<Void> deleteChannelPermission(long channelId, long overwriteId, @Nullable String reason) {
/* 186 */     return Routes.CHANNEL_PERMISSION_DELETE.newRequest(new Object[] { Long.valueOf(channelId), Long.valueOf(overwriteId)
/* 187 */         }).optionalHeader("X-Audit-Log-Reason", reason)
/* 188 */       .exchange(getRouter())
/* 189 */       .bodyToMono(Void.class);
/*     */   }
/*     */   
/*     */   public Mono<FollowedChannelData> followNewsChannel(long channelId, NewsChannelFollowRequest request) {
/* 193 */     return Routes.FOLLOW_NEWS_CHANNEL.newRequest(new Object[] { Long.valueOf(channelId)
/* 194 */         }).body(request)
/* 195 */       .exchange(getRouter())
/* 196 */       .bodyToMono(FollowedChannelData.class);
/*     */   }
/*     */   
/*     */   public Mono<Void> triggerTypingIndicator(long channelId) {
/* 200 */     return Routes.TYPING_INDICATOR_TRIGGER.newRequest(new Object[] { Long.valueOf(channelId)
/* 201 */         }).exchange(getRouter())
/* 202 */       .bodyToMono(Void.class);
/*     */   }
/*     */   
/*     */   public Flux<MessageData> getPinnedMessages(long channelId) {
/* 206 */     return Routes.MESSAGES_PINNED_GET.newRequest(new Object[] { Long.valueOf(channelId)
/* 207 */         }).exchange(getRouter())
/* 208 */       .bodyToMono(MessageData[].class)
/* 209 */       .flatMapMany(Flux::fromArray);
/*     */   }
/*     */   
/*     */   public Mono<Void> addPinnedMessage(long channelId, long messageId) {
/* 213 */     return Routes.MESSAGES_PINNED_ADD.newRequest(new Object[] { Long.valueOf(channelId), Long.valueOf(messageId)
/* 214 */         }).exchange(getRouter())
/* 215 */       .bodyToMono(Void.class);
/*     */   }
/*     */   
/*     */   public Mono<Void> deletePinnedMessage(long channelId, long messageId) {
/* 219 */     return Routes.MESSAGES_PINNED_DELETE.newRequest(new Object[] { Long.valueOf(channelId), Long.valueOf(messageId)
/* 220 */         }).exchange(getRouter())
/* 221 */       .bodyToMono(Void.class);
/*     */   }
/*     */   
/*     */   public Mono<Void> addGroupDMRecipient(long channelId, long userId, GroupAddRecipientRequest request) {
/* 225 */     return Routes.GROUP_DM_RECIPIENT_ADD.newRequest(new Object[] { Long.valueOf(channelId), Long.valueOf(userId)
/* 226 */         }).body(request)
/* 227 */       .exchange(getRouter())
/* 228 */       .bodyToMono(Void.class);
/*     */   }
/*     */   
/*     */   public Mono<Void> deleteGroupDMRecipient(long channelId, long userId) {
/* 232 */     return Routes.GROUP_DM_RECIPIENT_DELETE.newRequest(new Object[] { Long.valueOf(channelId), Long.valueOf(userId)
/* 233 */         }).exchange(getRouter())
/* 234 */       .bodyToMono(Void.class);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\service\ChannelService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */