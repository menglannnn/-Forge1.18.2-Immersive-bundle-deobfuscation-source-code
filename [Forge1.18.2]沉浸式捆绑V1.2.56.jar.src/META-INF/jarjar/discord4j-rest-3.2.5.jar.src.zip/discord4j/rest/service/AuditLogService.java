/*    */ package discord4j.rest.service;
/*    */ 
/*    */ import discord4j.discordjson.json.AuditLogData;
/*    */ import discord4j.rest.request.Router;
/*    */ import discord4j.rest.route.Routes;
/*    */ import java.util.Map;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AuditLogService
/*    */   extends RestService
/*    */ {
/*    */   public AuditLogService(Router router) {
/* 29 */     super(router);
/*    */   }
/*    */   
/*    */   public Mono<AuditLogData> getAuditLog(long guildId, Map<String, Object> queryParams) {
/* 33 */     return Routes.AUDIT_LOG_GET.newRequest(new Object[] { Long.valueOf(guildId)
/* 34 */         }).query(queryParams)
/* 35 */       .exchange(getRouter())
/* 36 */       .bodyToMono(AuditLogData.class);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\service\AuditLogService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */