/*    */ package discord4j.rest.service;
/*    */ 
/*    */ import discord4j.discordjson.json.GatewayData;
/*    */ import discord4j.rest.request.Router;
/*    */ import discord4j.rest.route.Routes;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GatewayService
/*    */   extends RestService
/*    */ {
/*    */   public GatewayService(Router router) {
/* 27 */     super(router);
/*    */   }
/*    */   
/*    */   public Mono<GatewayData> getGateway() {
/* 31 */     return Routes.GATEWAY_GET.newRequest(new Object[0])
/* 32 */       .exchange(getRouter())
/* 33 */       .bodyToMono(GatewayData.class);
/*    */   }
/*    */   
/*    */   public Mono<GatewayData> getGatewayBot() {
/* 37 */     return Routes.GATEWAY_BOT_GET.newRequest(new Object[0])
/* 38 */       .exchange(getRouter())
/* 39 */       .bodyToMono(GatewayData.class);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\service\GatewayService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */