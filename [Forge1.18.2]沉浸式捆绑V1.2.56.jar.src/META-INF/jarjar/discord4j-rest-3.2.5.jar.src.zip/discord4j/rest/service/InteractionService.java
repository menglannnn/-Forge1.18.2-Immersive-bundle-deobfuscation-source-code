/*    */ package discord4j.rest.service;
/*    */ 
/*    */ import discord4j.discordjson.json.InteractionResponseData;
/*    */ import discord4j.rest.request.Router;
/*    */ import discord4j.rest.route.Routes;
/*    */ import discord4j.rest.util.MultipartRequest;
/*    */ import java.util.Objects;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InteractionService
/*    */   extends RestService
/*    */ {
/*    */   public InteractionService(Router router) {
/* 30 */     super(router);
/*    */   }
/*    */   
/*    */   @Deprecated
/*    */   public Mono<Void> createInteractionResponse(long interactionId, String interactionToken, InteractionResponseData response) {
/* 35 */     return Routes.INTERACTION_RESPONSE_CREATE.newRequest(new Object[] { Long.valueOf(interactionId), interactionToken
/* 36 */         }).body(response)
/* 37 */       .exchange(getRouter())
/* 38 */       .bodyToMono(Void.class);
/*    */   }
/*    */   
/*    */   public Mono<Void> createInteractionResponse(long interactionId, String interactionToken, MultipartRequest<InteractionResponseData> request) {
/* 42 */     return Routes.INTERACTION_RESPONSE_CREATE.newRequest(new Object[] { Long.valueOf(interactionId), interactionToken
/* 43 */         }).header("content-type", request.getFiles().isEmpty() ? "application/json" : "multipart/form-data")
/* 44 */       .body(Objects.requireNonNull(request.getFiles().isEmpty() ? request.getJsonPayload() : request))
/* 45 */       .exchange(getRouter())
/* 46 */       .bodyToMono(Void.class);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\service\InteractionService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */