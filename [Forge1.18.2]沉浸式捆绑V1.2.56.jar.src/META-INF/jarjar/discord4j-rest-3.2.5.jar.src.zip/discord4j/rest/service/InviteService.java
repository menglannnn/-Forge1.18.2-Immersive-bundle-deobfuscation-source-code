/*    */ package discord4j.rest.service;
/*    */ 
/*    */ import discord4j.discordjson.json.InviteData;
/*    */ import discord4j.rest.request.Router;
/*    */ import discord4j.rest.route.Routes;
/*    */ import java.util.Collections;
/*    */ import java.util.Map;
/*    */ import reactor.core.publisher.Mono;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InviteService
/*    */   extends RestService
/*    */ {
/*    */   public InviteService(Router router) {
/* 31 */     super(router);
/*    */   }
/*    */   
/*    */   public Mono<InviteData> getInvite(String inviteCode) {
/* 35 */     return getInvite(inviteCode, Collections.emptyMap());
/*    */   }
/*    */   
/*    */   public Mono<InviteData> getInvite(String inviteCode, Map<String, Object> queryParams) {
/* 39 */     return Routes.INVITE_GET.newRequest(new Object[] { inviteCode
/* 40 */         }).query(queryParams)
/* 41 */       .exchange(getRouter())
/* 42 */       .bodyToMono(InviteData.class);
/*    */   }
/*    */   
/*    */   public Mono<InviteData> deleteInvite(String inviteCode, @Nullable String reason) {
/* 46 */     return Routes.INVITE_DELETE.newRequest(new Object[] { inviteCode
/* 47 */         }).optionalHeader("X-Audit-Log-Reason", reason)
/* 48 */       .exchange(getRouter())
/* 49 */       .bodyToMono(InviteData.class);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\service\InviteService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */