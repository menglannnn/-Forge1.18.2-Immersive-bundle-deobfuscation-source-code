/*    */ package discord4j.rest.service;
/*    */ 
/*    */ import discord4j.discordjson.json.ChannelData;
/*    */ import discord4j.discordjson.json.ConnectionData;
/*    */ import discord4j.discordjson.json.DMCreateRequest;
/*    */ import discord4j.discordjson.json.GroupDMCreateRequest;
/*    */ import discord4j.discordjson.json.UserData;
/*    */ import discord4j.discordjson.json.UserGuildData;
/*    */ import discord4j.discordjson.json.UserModifyRequest;
/*    */ import discord4j.rest.request.Router;
/*    */ import discord4j.rest.route.Routes;
/*    */ import java.util.Map;
/*    */ import reactor.core.publisher.Flux;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UserService
/*    */   extends RestService
/*    */ {
/*    */   public UserService(Router router) {
/* 30 */     super(router);
/*    */   }
/*    */   
/*    */   public Mono<UserData> getCurrentUser() {
/* 34 */     return Routes.CURRENT_USER_GET.newRequest(new Object[0])
/* 35 */       .exchange(getRouter())
/* 36 */       .bodyToMono(UserData.class);
/*    */   }
/*    */   
/*    */   public Mono<UserData> getUser(long userId) {
/* 40 */     return Routes.USER_GET.newRequest(new Object[] { Long.valueOf(userId)
/* 41 */         }).exchange(getRouter())
/* 42 */       .bodyToMono(UserData.class);
/*    */   }
/*    */   
/*    */   public Mono<UserData> modifyCurrentUser(UserModifyRequest request) {
/* 46 */     return Routes.CURRENT_USER_MODIFY.newRequest(new Object[0])
/* 47 */       .body(request)
/* 48 */       .exchange(getRouter())
/* 49 */       .bodyToMono(UserData.class);
/*    */   }
/*    */   
/*    */   public Flux<UserGuildData> getCurrentUserGuilds(Map<String, Object> queryParams) {
/* 53 */     return Routes.CURRENT_USER_GUILDS_GET.newRequest(new Object[0])
/* 54 */       .query(queryParams)
/* 55 */       .exchange(getRouter())
/* 56 */       .bodyToMono(UserGuildData[].class)
/* 57 */       .flatMapMany(Flux::fromArray);
/*    */   }
/*    */   
/*    */   public Mono<Void> leaveGuild(long guildId) {
/* 61 */     return Routes.GUILD_LEAVE.newRequest(new Object[] { Long.valueOf(guildId)
/* 62 */         }).header("content-type", "")
/* 63 */       .exchange(getRouter())
/* 64 */       .bodyToMono(Void.class);
/*    */   }
/*    */   
/*    */   public Mono<ChannelData> createDM(DMCreateRequest request) {
/* 68 */     return Routes.USER_DM_CREATE.newRequest(new Object[0])
/* 69 */       .body(request)
/* 70 */       .exchange(getRouter())
/* 71 */       .bodyToMono(ChannelData.class);
/*    */   }
/*    */   
/*    */   public Mono<ChannelData> createGroupDM(GroupDMCreateRequest request) {
/* 75 */     return Routes.GROUP_DM_CREATE.newRequest(new Object[0])
/* 76 */       .body(request)
/* 77 */       .exchange(getRouter())
/* 78 */       .bodyToMono(ChannelData.class);
/*    */   }
/*    */   
/*    */   public Flux<ConnectionData> getUserConnections() {
/* 82 */     return Routes.USER_CONNECTIONS_GET.newRequest(new Object[0])
/* 83 */       .exchange(getRouter())
/* 84 */       .bodyToMono(ConnectionData[].class)
/* 85 */       .flatMapMany(Flux::fromArray);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\service\UserService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */