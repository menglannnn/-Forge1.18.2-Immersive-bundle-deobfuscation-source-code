/*    */ package discord4j.rest.service;
/*    */ 
/*    */ import discord4j.discordjson.json.RegionData;
/*    */ import discord4j.rest.request.Router;
/*    */ import discord4j.rest.route.Routes;
/*    */ import reactor.core.publisher.Flux;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VoiceService
/*    */   extends RestService
/*    */ {
/*    */   public VoiceService(Router router) {
/* 27 */     super(router);
/*    */   }
/*    */   
/*    */   public Flux<RegionData> getVoiceRegions() {
/* 31 */     return Routes.VOICE_REGION_LIST.newRequest(new Object[0])
/* 32 */       .exchange(getRouter())
/* 33 */       .bodyToMono(RegionData[].class)
/* 34 */       .flatMapMany(Flux::fromArray);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\service\VoiceService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */