/*    */ package discord4j.rest.service;
/*    */ 
/*    */ import discord4j.discordjson.json.GuildData;
/*    */ import discord4j.discordjson.json.TemplateCreateGuildRequest;
/*    */ import discord4j.discordjson.json.TemplateCreateRequest;
/*    */ import discord4j.discordjson.json.TemplateData;
/*    */ import discord4j.discordjson.json.TemplateModifyRequest;
/*    */ import discord4j.rest.request.Router;
/*    */ import discord4j.rest.route.Routes;
/*    */ import reactor.core.publisher.Flux;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TemplateService
/*    */   extends RestService
/*    */ {
/*    */   public TemplateService(Router router) {
/* 29 */     super(router);
/*    */   }
/*    */   
/*    */   public Mono<TemplateData> getTemplate(String templateCode) {
/* 33 */     return Routes.GUILD_TEMPLATE_GET.newRequest(new Object[] { templateCode
/* 34 */         }).exchange(getRouter())
/* 35 */       .bodyToMono(TemplateData.class);
/*    */   }
/*    */   
/*    */   public Mono<GuildData> createGuild(String templateCode, TemplateCreateGuildRequest request) {
/* 39 */     return Routes.TEMPLATE_GUILD_CREATE.newRequest(new Object[] { templateCode
/* 40 */         }).body(request)
/* 41 */       .exchange(getRouter())
/* 42 */       .bodyToMono(GuildData.class);
/*    */   }
/*    */   public Flux<TemplateData> getTemplates(long guildId) {
/* 45 */     return Routes.GUILD_TEMPLATE_LIST_GET.newRequest(new Object[] { Long.valueOf(guildId)
/* 46 */         }).exchange(getRouter())
/* 47 */       .bodyToMono(TemplateData[].class)
/* 48 */       .flatMapMany(Flux::fromArray);
/*    */   }
/*    */   
/*    */   public Mono<TemplateData> createTemplate(long guildId, TemplateCreateRequest request) {
/* 52 */     return Routes.GUILD_TEMPLATE_CREATE.newRequest(new Object[] { Long.valueOf(guildId)
/* 53 */         }).body(request)
/* 54 */       .exchange(getRouter())
/* 55 */       .bodyToMono(TemplateData.class);
/*    */   }
/*    */   
/*    */   public Mono<TemplateData> syncTemplate(long guildId, String templateCode) {
/* 59 */     return Routes.GUILD_TEMPLATE_SYNC.newRequest(new Object[] { Long.valueOf(guildId), templateCode
/* 60 */         }).exchange(getRouter())
/* 61 */       .bodyToMono(TemplateData.class);
/*    */   }
/*    */   
/*    */   public Mono<TemplateData> modifyTemplate(long guildId, String templateCode, TemplateModifyRequest request) {
/* 65 */     return Routes.GUILD_TEMPLATE_MODIFY.newRequest(new Object[] { Long.valueOf(guildId), templateCode
/* 66 */         }).body(request)
/* 67 */       .exchange(getRouter())
/* 68 */       .bodyToMono(TemplateData.class);
/*    */   }
/*    */   
/*    */   public Mono<TemplateData> deleteTemplate(long guildId, String templateCode) {
/* 72 */     return Routes.GUILD_TEMPLATE_DELETE.newRequest(new Object[] { Long.valueOf(guildId), templateCode
/* 73 */         }).exchange(getRouter())
/* 74 */       .bodyToMono(TemplateData.class);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\service\TemplateService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */