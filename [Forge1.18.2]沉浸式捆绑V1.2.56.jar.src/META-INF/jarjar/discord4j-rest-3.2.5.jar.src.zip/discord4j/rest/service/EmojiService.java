/*    */ package discord4j.rest.service;
/*    */ 
/*    */ import discord4j.discordjson.json.EmojiData;
/*    */ import discord4j.discordjson.json.GuildEmojiCreateRequest;
/*    */ import discord4j.discordjson.json.GuildEmojiModifyRequest;
/*    */ import discord4j.rest.request.Router;
/*    */ import discord4j.rest.route.Routes;
/*    */ import reactor.core.publisher.Flux;
/*    */ import reactor.core.publisher.Mono;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EmojiService
/*    */   extends RestService
/*    */ {
/*    */   public EmojiService(Router router) {
/* 31 */     super(router);
/*    */   }
/*    */   
/*    */   public Flux<EmojiData> getGuildEmojis(long guildId) {
/* 35 */     return Routes.GUILD_EMOJIS_GET.newRequest(new Object[] { Long.valueOf(guildId)
/* 36 */         }).exchange(getRouter())
/* 37 */       .bodyToMono(EmojiData[].class)
/* 38 */       .flatMapMany(Flux::fromArray);
/*    */   }
/*    */   
/*    */   public Mono<EmojiData> getGuildEmoji(long guildId, long emojiId) {
/* 42 */     return Routes.GUILD_EMOJI_GET.newRequest(new Object[] { Long.valueOf(guildId), Long.valueOf(emojiId)
/* 43 */         }).exchange(getRouter())
/* 44 */       .bodyToMono(EmojiData.class);
/*    */   }
/*    */   
/*    */   public Mono<EmojiData> createGuildEmoji(long guildId, GuildEmojiCreateRequest request, @Nullable String reason) {
/* 48 */     return Routes.GUILD_EMOJI_CREATE.newRequest(new Object[] { Long.valueOf(guildId)
/* 49 */         }).body(request)
/* 50 */       .optionalHeader("X-Audit-Log-Reason", reason)
/* 51 */       .exchange(getRouter())
/* 52 */       .bodyToMono(EmojiData.class);
/*    */   }
/*    */   
/*    */   public Mono<EmojiData> modifyGuildEmoji(long guildId, long emojiId, GuildEmojiModifyRequest request, @Nullable String reason) {
/* 56 */     return Routes.GUILD_EMOJI_MODIFY.newRequest(new Object[] { Long.valueOf(guildId), Long.valueOf(emojiId)
/* 57 */         }).body(request)
/* 58 */       .optionalHeader("X-Audit-Log-Reason", reason)
/* 59 */       .exchange(getRouter())
/* 60 */       .bodyToMono(EmojiData.class);
/*    */   }
/*    */   
/*    */   public Mono<Void> deleteGuildEmoji(long guildId, long emojiId, @Nullable String reason) {
/* 64 */     return Routes.GUILD_EMOJI_DELETE.newRequest(new Object[] { Long.valueOf(guildId), Long.valueOf(emojiId)
/* 65 */         }).optionalHeader("X-Audit-Log-Reason", reason)
/* 66 */       .exchange(getRouter())
/* 67 */       .bodyToMono(Void.class);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\service\EmojiService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */