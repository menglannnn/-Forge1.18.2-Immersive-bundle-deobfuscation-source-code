/*     */ package discord4j.rest.service;
/*     */ 
/*     */ import discord4j.discordjson.json.ApplicationCommandData;
/*     */ import discord4j.discordjson.json.ApplicationCommandPermissionsRequest;
/*     */ import discord4j.discordjson.json.ApplicationCommandRequest;
/*     */ import discord4j.discordjson.json.ApplicationInfoData;
/*     */ import discord4j.discordjson.json.GuildApplicationCommandPermissionsData;
/*     */ import discord4j.discordjson.json.PartialGuildApplicationCommandPermissionsData;
/*     */ import discord4j.rest.request.Router;
/*     */ import discord4j.rest.route.Routes;
/*     */ import java.util.List;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ApplicationService
/*     */   extends RestService
/*     */ {
/*     */   public ApplicationService(Router router) {
/*  30 */     super(router);
/*     */   }
/*     */   
/*     */   public Mono<ApplicationInfoData> getCurrentApplicationInfo() {
/*  34 */     return Routes.APPLICATION_INFO_GET.newRequest(new Object[0])
/*  35 */       .exchange(getRouter())
/*  36 */       .bodyToMono(ApplicationInfoData.class);
/*     */   }
/*     */   
/*     */   public Flux<ApplicationCommandData> getGlobalApplicationCommands(long applicationId) {
/*  40 */     return Routes.GLOBAL_APPLICATION_COMMANDS_GET.newRequest(new Object[] { Long.valueOf(applicationId)
/*  41 */         }).exchange(getRouter())
/*  42 */       .bodyToMono(ApplicationCommandData[].class)
/*  43 */       .flatMapMany(Flux::fromArray);
/*     */   }
/*     */   
/*     */   public Mono<ApplicationCommandData> createGlobalApplicationCommand(long applicationId, ApplicationCommandRequest request) {
/*  47 */     return Routes.GLOBAL_APPLICATION_COMMANDS_CREATE.newRequest(new Object[] { Long.valueOf(applicationId)
/*  48 */         }).body(request)
/*  49 */       .exchange(getRouter())
/*  50 */       .bodyToMono(ApplicationCommandData.class);
/*     */   }
/*     */   
/*     */   public Flux<ApplicationCommandData> bulkOverwriteGlobalApplicationCommand(long applicationId, List<ApplicationCommandRequest> requests) {
/*  54 */     return Routes.GLOBAL_APPLICATION_COMMANDS_BULK_OVERWRITE.newRequest(new Object[] { Long.valueOf(applicationId)
/*  55 */         }).body(requests)
/*  56 */       .exchange(getRouter())
/*  57 */       .bodyToMono(ApplicationCommandData[].class)
/*  58 */       .flatMapMany(Flux::fromArray);
/*     */   }
/*     */   
/*     */   public Mono<ApplicationCommandData> getGlobalApplicationCommand(long applicationId, long commandId) {
/*  62 */     return Routes.GLOBAL_APPLICATION_COMMAND_GET.newRequest(new Object[] { Long.valueOf(applicationId), Long.valueOf(commandId)
/*  63 */         }).exchange(getRouter())
/*  64 */       .bodyToMono(ApplicationCommandData.class);
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<ApplicationCommandData> modifyGlobalApplicationCommand(long applicationId, long commandId, ApplicationCommandRequest request) {
/*  69 */     return Routes.GLOBAL_APPLICATION_COMMAND_MODIFY.newRequest(new Object[] { Long.valueOf(applicationId), Long.valueOf(commandId)
/*  70 */         }).body(request)
/*  71 */       .exchange(getRouter())
/*  72 */       .bodyToMono(ApplicationCommandData.class);
/*     */   }
/*     */   
/*     */   public Mono<Void> deleteGlobalApplicationCommand(long applicationId, long commandId) {
/*  76 */     return Routes.GLOBAL_APPLICATION_COMMAND_DELETE.newRequest(new Object[] { Long.valueOf(applicationId), Long.valueOf(commandId)
/*  77 */         }).exchange(getRouter())
/*  78 */       .bodyToMono(Void.class);
/*     */   }
/*     */   
/*     */   public Flux<ApplicationCommandData> getGuildApplicationCommands(long applicationId, long guildId) {
/*  82 */     return Routes.GUILD_APPLICATION_COMMANDS_GET.newRequest(new Object[] { Long.valueOf(applicationId), Long.valueOf(guildId)
/*  83 */         }).exchange(getRouter())
/*  84 */       .bodyToMono(ApplicationCommandData[].class)
/*  85 */       .flatMapMany(Flux::fromArray);
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<ApplicationCommandData> createGuildApplicationCommand(long applicationId, long guildId, ApplicationCommandRequest request) {
/*  90 */     return Routes.GUILD_APPLICATION_COMMANDS_CREATE.newRequest(new Object[] { Long.valueOf(applicationId), Long.valueOf(guildId)
/*  91 */         }).body(request)
/*  92 */       .exchange(getRouter())
/*  93 */       .bodyToMono(ApplicationCommandData.class);
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<ApplicationCommandData> bulkOverwriteGuildApplicationCommand(long applicationId, long guildId, List<ApplicationCommandRequest> requests) {
/*  98 */     return Routes.GUILD_APPLICATION_COMMANDS_BULK_OVERWRITE.newRequest(new Object[] { Long.valueOf(applicationId), Long.valueOf(guildId)
/*  99 */         }).body(requests)
/* 100 */       .exchange(getRouter())
/* 101 */       .bodyToMono(ApplicationCommandData[].class)
/* 102 */       .flatMapMany(Flux::fromArray);
/*     */   }
/*     */   
/*     */   public Mono<ApplicationCommandData> getGuildApplicationCommand(long applicationId, long guildId, long commandId) {
/* 106 */     return Routes.GUILD_APPLICATION_COMMAND_GET.newRequest(new Object[] { Long.valueOf(applicationId), Long.valueOf(guildId), Long.valueOf(commandId)
/* 107 */         }).exchange(getRouter())
/* 108 */       .bodyToMono(ApplicationCommandData.class);
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<ApplicationCommandData> modifyGuildApplicationCommand(long applicationId, long guildId, long commandId, ApplicationCommandRequest request) {
/* 113 */     return Routes.GUILD_APPLICATION_COMMAND_MODIFY.newRequest(new Object[] { Long.valueOf(applicationId), Long.valueOf(guildId), Long.valueOf(commandId)
/* 114 */         }).body(request)
/* 115 */       .exchange(getRouter())
/* 116 */       .bodyToMono(ApplicationCommandData.class);
/*     */   }
/*     */   
/*     */   public Mono<Void> deleteGuildApplicationCommand(long applicationId, long guildId, long commandId) {
/* 120 */     return Routes.GUILD_APPLICATION_COMMAND_DELETE.newRequest(new Object[] { Long.valueOf(applicationId), Long.valueOf(guildId), Long.valueOf(commandId)
/* 121 */         }).exchange(getRouter())
/* 122 */       .bodyToMono(Void.class);
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<GuildApplicationCommandPermissionsData> getGuildApplicationCommandPermissions(long applicationId, long guildId) {
/* 127 */     return Routes.GUILD_APPLICATION_COMMAND_PERMISSIONS_GET.newRequest(new Object[] { Long.valueOf(applicationId), Long.valueOf(guildId)
/* 128 */         }).exchange(getRouter())
/* 129 */       .bodyToMono(GuildApplicationCommandPermissionsData[].class)
/* 130 */       .flatMapMany(Flux::fromArray);
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<GuildApplicationCommandPermissionsData> getApplicationCommandPermissions(long applicationId, long guildId, long commandId) {
/* 135 */     return Routes.APPLICATION_COMMAND_PERMISSIONS_GET.newRequest(new Object[] { Long.valueOf(applicationId), Long.valueOf(guildId), Long.valueOf(commandId)
/* 136 */         }).exchange(getRouter())
/* 137 */       .bodyToMono(GuildApplicationCommandPermissionsData.class);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<GuildApplicationCommandPermissionsData> modifyApplicationCommandPermissions(long applicationId, long guildId, long commandId, ApplicationCommandPermissionsRequest request) {
/* 143 */     return Routes.APPLICATION_COMMAND_PERMISSIONS_MODIFY.newRequest(new Object[] { Long.valueOf(applicationId), Long.valueOf(guildId), Long.valueOf(commandId)
/* 144 */         }).body(request)
/* 145 */       .exchange(getRouter())
/* 146 */       .bodyToMono(GuildApplicationCommandPermissionsData.class);
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<GuildApplicationCommandPermissionsData> bulkModifyApplicationCommandPermissions(long applicationId, long guildId, List<PartialGuildApplicationCommandPermissionsData> permissions) {
/* 151 */     return Routes.APPLICATION_COMMAND_PERMISSIONS_BULK_MODIFY.newRequest(new Object[] { Long.valueOf(applicationId), Long.valueOf(guildId)
/* 152 */         }).body(permissions)
/* 153 */       .exchange(getRouter())
/* 154 */       .bodyToMono(GuildApplicationCommandPermissionsData[].class)
/* 155 */       .flatMapMany(Flux::fromArray);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\service\ApplicationService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */