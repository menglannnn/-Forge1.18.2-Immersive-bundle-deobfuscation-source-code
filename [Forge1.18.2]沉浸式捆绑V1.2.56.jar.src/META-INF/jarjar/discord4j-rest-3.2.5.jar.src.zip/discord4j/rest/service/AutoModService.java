/*    */ package discord4j.rest.service;
/*    */ import discord4j.discordjson.json.AutoModRuleCreateRequest;
/*    */ import discord4j.discordjson.json.AutoModRuleData;
/*    */ import discord4j.discordjson.json.AutoModRuleModifyRequest;
/*    */ import discord4j.rest.request.Router;
/*    */ import discord4j.rest.route.Routes;
/*    */ import reactor.core.publisher.Flux;
/*    */ import reactor.core.publisher.Mono;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ public class AutoModService extends RestService {
/*    */   public AutoModService(Router router) {
/* 13 */     super(router);
/*    */   }
/*    */   
/*    */   public Flux<AutoModRuleData> getAutoModRules(long guildId) {
/* 17 */     return Routes.AUTO_MOD_RULES_GET.newRequest(new Object[] { Long.valueOf(guildId)
/* 18 */         }).exchange(getRouter())
/* 19 */       .bodyToMono(AutoModRuleData[].class)
/* 20 */       .flatMapMany(Flux::fromArray);
/*    */   }
/*    */   
/*    */   public Mono<AutoModRuleData> getAutoModRule(long guildId, long ruleId) {
/* 24 */     return Routes.AUTO_MOD_RULE_GET.newRequest(new Object[] { Long.valueOf(guildId), Long.valueOf(ruleId)
/* 25 */         }).exchange(getRouter())
/* 26 */       .bodyToMono(AutoModRuleData.class);
/*    */   }
/*    */   
/*    */   public Mono<AutoModRuleData> createAutoModRule(long guildId, AutoModRuleCreateRequest request, @Nullable String reason) {
/* 30 */     return Routes.AUTO_MOD_RULE_MODIFY.newRequest(new Object[] { Long.valueOf(guildId)
/* 31 */         }).body(request)
/* 32 */       .optionalHeader("X-Audit-Log-Reason", reason)
/* 33 */       .exchange(getRouter())
/* 34 */       .bodyToMono(AutoModRuleData.class);
/*    */   }
/*    */   
/*    */   public Mono<AutoModRuleData> modifyAutoModRule(long guildId, long ruleId, AutoModRuleModifyRequest request, @Nullable String reason) {
/* 38 */     return Routes.AUTO_MOD_RULE_MODIFY.newRequest(new Object[] { Long.valueOf(guildId), Long.valueOf(ruleId)
/* 39 */         }).body(request)
/* 40 */       .optionalHeader("X-Audit-Log-Reason", reason)
/* 41 */       .exchange(getRouter())
/* 42 */       .bodyToMono(AutoModRuleData.class);
/*    */   }
/*    */   
/*    */   public Mono<Void> deleteAutoModRule(long guildId, long ruleId, @Nullable String reason) {
/* 46 */     return Routes.AUTO_MOD_RULE_DELETE.newRequest(new Object[] { Long.valueOf(guildId), Long.valueOf(ruleId)
/* 47 */         }).optionalHeader("X-Audit-Log-Reason", reason)
/* 48 */       .exchange(getRouter())
/* 49 */       .bodyToMono(Void.class);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\service\AutoModService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */