/*     */ package discord4j.rest.service;
/*     */ import discord4j.discordjson.json.BanData;
/*     */ import discord4j.discordjson.json.ChannelCreateRequest;
/*     */ import discord4j.discordjson.json.ChannelData;
/*     */ import discord4j.discordjson.json.CurrentMemberModifyData;
/*     */ import discord4j.discordjson.json.GuildMemberModifyRequest;
/*     */ import discord4j.discordjson.json.GuildScheduledEventCreateRequest;
/*     */ import discord4j.discordjson.json.GuildScheduledEventData;
/*     */ import discord4j.discordjson.json.GuildScheduledEventModifyRequest;
/*     */ import discord4j.discordjson.json.GuildUpdateData;
/*     */ import discord4j.discordjson.json.GuildWidgetData;
/*     */ import discord4j.discordjson.json.GuildWidgetModifyRequest;
/*     */ import discord4j.discordjson.json.IntegrationCreateRequest;
/*     */ import discord4j.discordjson.json.IntegrationModifyRequest;
/*     */ import discord4j.discordjson.json.MemberData;
/*     */ import discord4j.discordjson.json.NicknameModifyData;
/*     */ import discord4j.discordjson.json.PositionModifyRequest;
/*     */ import discord4j.discordjson.json.PruneData;
/*     */ import discord4j.discordjson.json.RoleCreateRequest;
/*     */ import discord4j.discordjson.json.RoleData;
/*     */ import discord4j.discordjson.json.RoleModifyRequest;
/*     */ import discord4j.discordjson.json.UpdateUserVoiceStateRequest;
/*     */ import discord4j.rest.route.Routes;
/*     */ import discord4j.rest.util.Multimap;
/*     */ import java.util.Map;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ public class GuildService extends RestService {
/*     */   public GuildService(Router router) {
/*  32 */     super(router);
/*     */   }
/*     */   
/*     */   public Mono<GuildUpdateData> createGuild(GuildCreateRequest request) {
/*  36 */     return Routes.GUILD_CREATE.newRequest(new Object[0])
/*  37 */       .body(request)
/*  38 */       .exchange(getRouter())
/*  39 */       .bodyToMono(GuildUpdateData.class);
/*     */   }
/*     */   
/*     */   public Mono<GuildUpdateData> getGuild(long guildId, Map<String, Object> queryParams) {
/*  43 */     return Routes.GUILD_GET.newRequest(new Object[] { Long.valueOf(guildId)
/*  44 */         }).query(queryParams)
/*  45 */       .exchange(getRouter())
/*  46 */       .bodyToMono(GuildUpdateData.class);
/*     */   }
/*     */   
/*     */   public Mono<GuildUpdateData> getGuild(long guildId) {
/*  50 */     return Routes.GUILD_GET.newRequest(new Object[] { Long.valueOf(guildId)
/*  51 */         }).exchange(getRouter())
/*  52 */       .bodyToMono(GuildUpdateData.class);
/*     */   }
/*     */   
/*     */   public Mono<GuildUpdateData> modifyGuild(long guildId, GuildModifyRequest request, @Nullable String reason) {
/*  56 */     return Routes.GUILD_MODIFY.newRequest(new Object[] { Long.valueOf(guildId)
/*  57 */         }).body(request)
/*  58 */       .optionalHeader("X-Audit-Log-Reason", reason)
/*  59 */       .exchange(getRouter())
/*  60 */       .bodyToMono(GuildUpdateData.class);
/*     */   }
/*     */   
/*     */   public Mono<Void> deleteGuild(long guildId) {
/*  64 */     return Routes.GUILD_DELETE.newRequest(new Object[] { Long.valueOf(guildId)
/*  65 */         }).exchange(getRouter())
/*  66 */       .bodyToMono(Void.class);
/*     */   }
/*     */   
/*     */   public Flux<ChannelData> getGuildChannels(long guildId) {
/*  70 */     return Routes.GUILD_CHANNELS_GET.newRequest(new Object[] { Long.valueOf(guildId)
/*  71 */         }).exchange(getRouter())
/*  72 */       .bodyToMono(ChannelData[].class)
/*  73 */       .flatMapMany(Flux::fromArray);
/*     */   }
/*     */   
/*     */   public Mono<ChannelData> createGuildChannel(long guildId, ChannelCreateRequest request, @Nullable String reason) {
/*  77 */     return Routes.GUILD_CHANNEL_CREATE.newRequest(new Object[] { Long.valueOf(guildId)
/*  78 */         }).body(request)
/*  79 */       .optionalHeader("X-Audit-Log-Reason", reason)
/*  80 */       .exchange(getRouter())
/*  81 */       .bodyToMono(ChannelData.class);
/*     */   }
/*     */   
/*     */   public Flux<RoleData> modifyGuildChannelPositions(long guildId, PositionModifyRequest[] request) {
/*  85 */     return Routes.GUILD_CHANNEL_POSITIONS_MODIFY.newRequest(new Object[] { Long.valueOf(guildId)
/*  86 */         }).body(request)
/*  87 */       .exchange(getRouter())
/*  88 */       .bodyToMono(RoleData[].class)
/*  89 */       .flatMapMany(Flux::fromArray);
/*     */   }
/*     */   
/*     */   public Mono<MemberData> getGuildMember(long guildId, long userId) {
/*  93 */     return Routes.GUILD_MEMBER_GET.newRequest(new Object[] { Long.valueOf(guildId), Long.valueOf(userId)
/*  94 */         }).exchange(getRouter())
/*  95 */       .bodyToMono(MemberData.class);
/*     */   }
/*     */   
/*     */   public Flux<MemberData> getGuildMembers(long guildId, Map<String, Object> queryParams) {
/*  99 */     return Routes.GUILD_MEMBERS_LIST.newRequest(new Object[] { Long.valueOf(guildId)
/* 100 */         }).query(queryParams)
/* 101 */       .exchange(getRouter())
/* 102 */       .bodyToMono(MemberData[].class)
/* 103 */       .flatMapMany(Flux::fromArray);
/*     */   }
/*     */   
/*     */   public Flux<MemberData> searchGuildMembers(long guildId, Map<String, Object> queryParams) {
/* 107 */     return Routes.SEARCH_GUILD_MEMBERS_GET.newRequest(new Object[] { Long.valueOf(guildId)
/* 108 */         }).query(queryParams)
/* 109 */       .exchange(getRouter())
/* 110 */       .bodyToMono(MemberData[].class)
/* 111 */       .flatMapMany(Flux::fromArray);
/*     */   }
/*     */   
/*     */   public Mono<MemberData> addGuildMember(long guildId, long userId, GuildMemberAddRequest request) {
/* 115 */     return Routes.GUILD_MEMBER_ADD.newRequest(new Object[] { Long.valueOf(guildId), Long.valueOf(userId)
/* 116 */         }).body(request)
/* 117 */       .exchange(getRouter())
/* 118 */       .bodyToMono(MemberData.class);
/*     */   }
/*     */   
/*     */   public Mono<MemberData> modifyGuildMember(long guildId, long userId, GuildMemberModifyRequest request, @Nullable String reason) {
/* 122 */     return Routes.GUILD_MEMBER_MODIFY.newRequest(new Object[] { Long.valueOf(guildId), Long.valueOf(userId)
/* 123 */         }).body(request)
/* 124 */       .optionalHeader("X-Audit-Log-Reason", reason)
/* 125 */       .exchange(getRouter())
/* 126 */       .bodyToMono(MemberData.class);
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public Mono<NicknameModifyData> modifyOwnNickname(long guildId, NicknameModifyData request) {
/* 131 */     return Routes.NICKNAME_MODIFY_OWN.newRequest(new Object[] { Long.valueOf(guildId)
/* 132 */         }).body(request)
/* 133 */       .exchange(getRouter())
/* 134 */       .bodyToMono(NicknameModifyData.class);
/*     */   }
/*     */   
/*     */   public Mono<MemberData> modifyCurrentMember(long guildId, CurrentMemberModifyData request) {
/* 138 */     return Routes.CURRENT_MEMBER_MODIFY.newRequest(new Object[] { Long.valueOf(guildId)
/* 139 */         }).body(request)
/* 140 */       .exchange(getRouter())
/* 141 */       .bodyToMono(MemberData.class);
/*     */   }
/*     */   
/*     */   public Mono<Void> addGuildMemberRole(long guildId, long userId, long roleId, @Nullable String reason) {
/* 145 */     return Routes.GUILD_MEMBER_ROLE_ADD.newRequest(new Object[] { Long.valueOf(guildId), Long.valueOf(userId), Long.valueOf(roleId)
/* 146 */         }).optionalHeader("X-Audit-Log-Reason", reason)
/* 147 */       .exchange(getRouter())
/* 148 */       .bodyToMono(Void.class);
/*     */   }
/*     */   
/*     */   public Mono<Void> removeGuildMemberRole(long guildId, long userId, long roleId, @Nullable String reason) {
/* 152 */     return Routes.GUILD_MEMBER_ROLE_REMOVE.newRequest(new Object[] { Long.valueOf(guildId), Long.valueOf(userId), Long.valueOf(roleId)
/* 153 */         }).optionalHeader("X-Audit-Log-Reason", reason)
/* 154 */       .exchange(getRouter())
/* 155 */       .bodyToMono(Void.class);
/*     */   }
/*     */   
/*     */   public Mono<Void> removeGuildMember(long guildId, long userId, @Nullable String reason) {
/* 159 */     return Routes.GUILD_MEMBER_REMOVE.newRequest(new Object[] { Long.valueOf(guildId), Long.valueOf(userId)
/* 160 */         }).optionalHeader("X-Audit-Log-Reason", reason)
/* 161 */       .exchange(getRouter())
/* 162 */       .bodyToMono(Void.class);
/*     */   }
/*     */   
/*     */   public Flux<BanData> getGuildBans(long guildId) {
/* 166 */     return Routes.GUILD_BANS_GET.newRequest(new Object[] { Long.valueOf(guildId)
/* 167 */         }).exchange(getRouter())
/* 168 */       .bodyToMono(BanData[].class)
/* 169 */       .flatMapMany(Flux::fromArray);
/*     */   }
/*     */   
/*     */   public Mono<BanData> getGuildBan(long guildId, long userId) {
/* 173 */     return Routes.GUILD_BAN_GET.newRequest(new Object[] { Long.valueOf(guildId), Long.valueOf(userId)
/* 174 */         }).exchange(getRouter())
/* 175 */       .bodyToMono(BanData.class);
/*     */   }
/*     */   
/*     */   public Mono<Void> createGuildBan(long guildId, long userId, Map<String, Object> queryParams, @Nullable String reason) {
/* 179 */     return Routes.GUILD_BAN_CREATE.newRequest(new Object[] { Long.valueOf(guildId), Long.valueOf(userId)
/* 180 */         }).query(queryParams)
/* 181 */       .optionalHeader("X-Audit-Log-Reason", reason)
/* 182 */       .exchange(getRouter())
/* 183 */       .bodyToMono(Void.class);
/*     */   }
/*     */   
/*     */   public Mono<Void> removeGuildBan(long guildId, long userId, @Nullable String reason) {
/* 187 */     return Routes.GUILD_BAN_REMOVE.newRequest(new Object[] { Long.valueOf(guildId), Long.valueOf(userId)
/* 188 */         }).optionalHeader("X-Audit-Log-Reason", reason)
/* 189 */       .exchange(getRouter())
/* 190 */       .bodyToMono(Void.class);
/*     */   }
/*     */   
/*     */   public Flux<RoleData> getGuildRoles(long guildId) {
/* 194 */     return Routes.GUILD_ROLES_GET.newRequest(new Object[] { Long.valueOf(guildId)
/* 195 */         }).exchange(getRouter())
/* 196 */       .bodyToMono(RoleData[].class)
/* 197 */       .flatMapMany(Flux::fromArray);
/*     */   }
/*     */   
/*     */   public Mono<RoleData> createGuildRole(long guildId, RoleCreateRequest request, @Nullable String reason) {
/* 201 */     return Routes.GUILD_ROLE_CREATE.newRequest(new Object[] { Long.valueOf(guildId)
/* 202 */         }).body(request)
/* 203 */       .optionalHeader("X-Audit-Log-Reason", reason)
/* 204 */       .exchange(getRouter())
/* 205 */       .bodyToMono(RoleData.class);
/*     */   }
/*     */   
/*     */   public Flux<RoleData> modifyGuildRolePositions(long guildId, PositionModifyRequest[] request) {
/* 209 */     return Routes.GUILD_ROLE_POSITIONS_MODIFY.newRequest(new Object[] { Long.valueOf(guildId)
/* 210 */         }).body(request)
/* 211 */       .exchange(getRouter())
/* 212 */       .bodyToMono(RoleData[].class)
/* 213 */       .flatMapMany(Flux::fromArray);
/*     */   }
/*     */   
/*     */   public Mono<RoleData> modifyGuildRole(long guildId, long roleId, RoleModifyRequest request, @Nullable String reason) {
/* 217 */     return Routes.GUILD_ROLE_MODIFY.newRequest(new Object[] { Long.valueOf(guildId), Long.valueOf(roleId)
/* 218 */         }).body(request)
/* 219 */       .optionalHeader("X-Audit-Log-Reason", reason)
/* 220 */       .exchange(getRouter())
/* 221 */       .bodyToMono(RoleData.class);
/*     */   }
/*     */   
/*     */   public Mono<Void> deleteGuildRole(long guildId, long roleId, @Nullable String reason) {
/* 225 */     return Routes.GUILD_ROLE_DELETE.newRequest(new Object[] { Long.valueOf(guildId), Long.valueOf(roleId)
/* 226 */         }).optionalHeader("X-Audit-Log-Reason", reason)
/* 227 */       .exchange(getRouter())
/* 228 */       .bodyToMono(Void.class);
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public Mono<PruneData> getGuildPruneCount(long guildId, Map<String, Object> queryParams) {
/* 233 */     return Routes.GUILD_PRUNE_COUNT_GET.newRequest(new Object[] { Long.valueOf(guildId)
/* 234 */         }).query(queryParams)
/* 235 */       .exchange(getRouter())
/* 236 */       .bodyToMono(PruneData.class);
/*     */   }
/*     */   
/*     */   public Mono<PruneData> getGuildPruneCount(long guildId, Multimap<String, Object> params) {
/* 240 */     return Routes.GUILD_PRUNE_COUNT_GET.newRequest(new Object[] { Long.valueOf(guildId)
/* 241 */         }).query(params)
/* 242 */       .exchange(getRouter())
/* 243 */       .bodyToMono(PruneData.class);
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public Mono<PruneData> beginGuildPrune(long guildId, Map<String, Object> queryParams, @Nullable String reason) {
/* 248 */     return Routes.GUILD_PRUNE_BEGIN.newRequest(new Object[] { Long.valueOf(guildId)
/* 249 */         }).query(queryParams)
/* 250 */       .optionalHeader("X-Audit-Log-Reason", reason)
/* 251 */       .exchange(getRouter())
/* 252 */       .bodyToMono(PruneData.class);
/*     */   }
/*     */   
/*     */   public Mono<PruneData> beginGuildPrune(long guildId, Multimap<String, Object> params, @Nullable String reason) {
/* 256 */     return Routes.GUILD_PRUNE_BEGIN.newRequest(new Object[] { Long.valueOf(guildId)
/* 257 */         }).query(params)
/* 258 */       .optionalHeader("X-Audit-Log-Reason", reason)
/* 259 */       .exchange(getRouter())
/* 260 */       .bodyToMono(PruneData.class);
/*     */   }
/*     */   
/*     */   public Flux<RegionData> getGuildVoiceRegions(long guildId) {
/* 264 */     return Routes.GUILD_VOICE_REGIONS_GET.newRequest(new Object[] { Long.valueOf(guildId)
/* 265 */         }).exchange(getRouter())
/* 266 */       .bodyToMono(RegionData[].class)
/* 267 */       .flatMapMany(Flux::fromArray);
/*     */   }
/*     */   
/*     */   public Flux<InviteData> getGuildInvites(long guildId) {
/* 271 */     return Routes.GUILD_INVITES_GET.newRequest(new Object[] { Long.valueOf(guildId)
/* 272 */         }).exchange(getRouter())
/* 273 */       .bodyToMono(InviteData[].class)
/* 274 */       .flatMapMany(Flux::fromArray);
/*     */   }
/*     */   
/*     */   public Flux<IntegrationData> getGuildIntegrations(long guildId) {
/* 278 */     return Routes.GUILD_INTEGRATIONS_GET.newRequest(new Object[] { Long.valueOf(guildId)
/* 279 */         }).exchange(getRouter())
/* 280 */       .bodyToMono(IntegrationData[].class)
/* 281 */       .flatMapMany(Flux::fromArray);
/*     */   }
/*     */   
/*     */   public Mono<Void> createGuildIntegration(long guildId, IntegrationCreateRequest request) {
/* 285 */     return Routes.GUILD_INTEGRATION_CREATE.newRequest(new Object[] { Long.valueOf(guildId)
/* 286 */         }).body(request)
/* 287 */       .exchange(getRouter())
/* 288 */       .bodyToMono(Void.class);
/*     */   }
/*     */   
/*     */   public Mono<Void> modifyGuildIntegration(long guildId, long integrationId, IntegrationModifyRequest request) {
/* 292 */     return Routes.GUILD_INTEGRATION_MODIFY.newRequest(new Object[] { Long.valueOf(guildId), Long.valueOf(integrationId)
/* 293 */         }).body(request)
/* 294 */       .exchange(getRouter())
/* 295 */       .bodyToMono(Void.class);
/*     */   }
/*     */   
/*     */   public Mono<Void> deleteGuildIntegration(long guildId, long integrationId) {
/* 299 */     return Routes.GUILD_INTEGRATION_DELETE.newRequest(new Object[] { Long.valueOf(guildId), Long.valueOf(integrationId)
/* 300 */         }).exchange(getRouter())
/* 301 */       .bodyToMono(Void.class);
/*     */   }
/*     */   
/*     */   public Mono<Void> syncGuildIntegration(long guildId, long integrationId) {
/* 305 */     return Routes.GUILD_INTEGRATION_SYNC.newRequest(new Object[] { Long.valueOf(guildId), Long.valueOf(integrationId)
/* 306 */         }).exchange(getRouter())
/* 307 */       .bodyToMono(Void.class);
/*     */   }
/*     */   
/*     */   public Mono<GuildWidgetData> getGuildWidget(long guildId) {
/* 311 */     return Routes.GUILD_WIDGET_GET.newRequest(new Object[] { Long.valueOf(guildId)
/* 312 */         }).exchange(getRouter())
/* 313 */       .bodyToMono(GuildWidgetData.class);
/*     */   }
/*     */   
/*     */   public Mono<GuildWidgetData> modifyGuildWidget(long guildId, GuildWidgetModifyRequest request) {
/* 317 */     return Routes.GUILD_WIDGET_MODIFY.newRequest(new Object[] { Long.valueOf(guildId)
/* 318 */         }).body(request)
/* 319 */       .exchange(getRouter())
/* 320 */       .bodyToMono(GuildWidgetData.class);
/*     */   }
/*     */   
/*     */   public Mono<GuildPreviewData> getGuildPreview(long guildId) {
/* 324 */     return Routes.GUILD_PREVIEW_GET.newRequest(new Object[] { Long.valueOf(guildId)
/* 325 */         }).exchange(getRouter())
/* 326 */       .bodyToMono(GuildPreviewData.class);
/*     */   }
/*     */   
/*     */   public Mono<Void> modifySelfVoiceState(long guildId, UpdateCurrentUserVoiceStateRequest request) {
/* 330 */     return Routes.SELF_VOICE_STATE_MODIFY.newRequest(new Object[] { Long.valueOf(guildId)
/* 331 */         }).body(request)
/* 332 */       .exchange(getRouter())
/* 333 */       .bodyToMono(Void.class);
/*     */   }
/*     */   
/*     */   public Mono<Void> modifyOthersVoiceState(long guildId, long userId, UpdateUserVoiceStateRequest request) {
/* 337 */     return Routes.OTHERS_VOICE_STATE_MODIFY.newRequest(new Object[] { Long.valueOf(guildId), Long.valueOf(userId)
/* 338 */         }).body(request)
/* 339 */       .exchange(getRouter())
/* 340 */       .bodyToMono(Void.class);
/*     */   }
/*     */   
/*     */   public Mono<GuildScheduledEventData> getScheduledEvent(long guildId, long eventId, Map<String, Object> queryParams) {
/* 344 */     return Routes.GUILD_SCHEDULED_EVENT_GET.newRequest(new Object[] { Long.valueOf(guildId), Long.valueOf(eventId)
/* 345 */         }).query(queryParams)
/* 346 */       .exchange(getRouter())
/* 347 */       .bodyToMono(GuildScheduledEventData.class);
/*     */   }
/*     */   
/*     */   public Flux<GuildScheduledEventData> getScheduledEvents(long guildId, Map<String, Object> queryParams) {
/* 351 */     return Routes.GUILD_SCHEDULED_EVENTS_GET.newRequest(new Object[] { Long.valueOf(guildId)
/* 352 */         }).query(queryParams)
/* 353 */       .exchange(getRouter())
/* 354 */       .bodyToMono(GuildScheduledEventData[].class)
/* 355 */       .flatMapMany(Flux::fromArray);
/*     */   }
/*     */   
/*     */   public Mono<GuildScheduledEventData> createScheduledEvent(long guildId, GuildScheduledEventCreateRequest request) {
/* 359 */     return Routes.GUILD_SCHEDULED_EVENT_CREATE.newRequest(new Object[] { Long.valueOf(guildId)
/* 360 */         }).body(request)
/* 361 */       .exchange(getRouter())
/* 362 */       .bodyToMono(GuildScheduledEventData.class);
/*     */   }
/*     */   
/*     */   public Mono<GuildScheduledEventData> modifyScheduledEvent(long guildId, long eventId, GuildScheduledEventModifyRequest request, @Nullable String reason) {
/* 366 */     return Routes.GUILD_SCHEDULED_EVENT_MODIFY.newRequest(new Object[] { Long.valueOf(guildId), Long.valueOf(eventId)
/* 367 */         }).body(request)
/* 368 */       .optionalHeader("X-Audit-Log-Reason", reason)
/* 369 */       .exchange(getRouter())
/* 370 */       .bodyToMono(GuildScheduledEventData.class);
/*     */   }
/*     */   
/*     */   public Mono<Void> deleteScheduledEvent(long guildId, long eventId, @Nullable String reason) {
/* 374 */     return Routes.GUILD_SCHEDULED_EVENT_DELETE.newRequest(new Object[] { Long.valueOf(guildId), Long.valueOf(eventId)
/* 375 */         }).optionalHeader("X-Audit-Log-Reason", reason)
/* 376 */       .exchange(getRouter())
/* 377 */       .bodyToMono(Void.class);
/*     */   }
/*     */   
/*     */   public Flux<GuildScheduledEventUserData> getScheduledEventUsers(long guildId, long eventId, Map<String, Object> queryParams) {
/* 381 */     return Routes.GUILD_SCHEDULED_EVENT_USERS_GET.newRequest(new Object[] { Long.valueOf(guildId), Long.valueOf(eventId)
/* 382 */         }).query(queryParams)
/* 383 */       .exchange(getRouter())
/* 384 */       .bodyToMono(GuildScheduledEventUserData[].class)
/* 385 */       .flatMapMany(Flux::fromArray);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\service\GuildService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */