/*     */ package discord4j.rest.service;
/*     */ 
/*     */ import discord4j.discordjson.json.MessageData;
/*     */ import discord4j.discordjson.json.WebhookCreateRequest;
/*     */ import discord4j.discordjson.json.WebhookData;
/*     */ import discord4j.discordjson.json.WebhookExecuteRequest;
/*     */ import discord4j.discordjson.json.WebhookMessageEditRequest;
/*     */ import discord4j.discordjson.json.WebhookModifyRequest;
/*     */ import discord4j.discordjson.json.WebhookModifyWithTokenRequest;
/*     */ import discord4j.rest.request.Router;
/*     */ import discord4j.rest.route.Routes;
/*     */ import discord4j.rest.util.MultipartRequest;
/*     */ import java.util.Objects;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WebhookService
/*     */   extends RestService
/*     */ {
/*     */   public WebhookService(Router router) {
/*  32 */     super(router);
/*     */   }
/*     */   
/*     */   public Mono<WebhookData> createWebhook(long channelId, WebhookCreateRequest request, @Nullable String reason) {
/*  36 */     return Routes.CHANNEL_WEBHOOK_CREATE.newRequest(new Object[] { Long.valueOf(channelId)
/*  37 */         }).body(request)
/*  38 */       .optionalHeader("X-Audit-Log-Reason", reason)
/*  39 */       .exchange(getRouter())
/*  40 */       .bodyToMono(WebhookData.class);
/*     */   }
/*     */   
/*     */   public Flux<WebhookData> getChannelWebhooks(long channelId) {
/*  44 */     return Routes.CHANNEL_WEBHOOKS_GET.newRequest(new Object[] { Long.valueOf(channelId)
/*  45 */         }).exchange(getRouter())
/*  46 */       .bodyToMono(WebhookData[].class)
/*  47 */       .flatMapMany(Flux::fromArray);
/*     */   }
/*     */   
/*     */   public Flux<WebhookData> getGuildWebhooks(long guildId) {
/*  51 */     return Routes.GUILD_WEBHOOKS_GET.newRequest(new Object[] { Long.valueOf(guildId)
/*  52 */         }).exchange(getRouter())
/*  53 */       .bodyToMono(WebhookData[].class)
/*  54 */       .flatMapMany(Flux::fromArray);
/*     */   }
/*     */   
/*     */   public Mono<WebhookData> getWebhook(long webhookId) {
/*  58 */     return Routes.WEBHOOK_GET.newRequest(new Object[] { Long.valueOf(webhookId)
/*  59 */         }).exchange(getRouter())
/*  60 */       .bodyToMono(WebhookData.class);
/*     */   }
/*     */   
/*     */   public Mono<WebhookData> getWebhookWithToken(long webhookId, String token) {
/*  64 */     return Routes.WEBHOOK_TOKEN_GET.newRequest(new Object[] { Long.valueOf(webhookId), token
/*  65 */         }).exchange(getRouter())
/*  66 */       .bodyToMono(WebhookData.class);
/*     */   }
/*     */   
/*     */   public Mono<WebhookData> modifyWebhook(long webhookId, WebhookModifyRequest request, @Nullable String reason) {
/*  70 */     return Routes.WEBHOOK_MODIFY.newRequest(new Object[] { Long.valueOf(webhookId)
/*  71 */         }).body(request)
/*  72 */       .optionalHeader("X-Audit-Log-Reason", reason)
/*  73 */       .exchange(getRouter())
/*  74 */       .bodyToMono(WebhookData.class);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<WebhookData> modifyWebhookWithToken(long webhookId, String token, WebhookModifyWithTokenRequest request) {
/*  80 */     return Routes.WEBHOOK_TOKEN_MODIFY.newRequest(new Object[] { Long.valueOf(webhookId), token
/*  81 */         }).body(request)
/*  82 */       .exchange(getRouter())
/*  83 */       .bodyToMono(WebhookData.class);
/*     */   }
/*     */   
/*     */   public Mono<Void> deleteWebhook(long webhookId, @Nullable String reason) {
/*  87 */     return Routes.WEBHOOK_DELETE.newRequest(new Object[] { Long.valueOf(webhookId)
/*  88 */         }).optionalHeader("X-Audit-Log-Reason", reason)
/*  89 */       .exchange(getRouter())
/*  90 */       .bodyToMono(Void.class);
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> deleteWebhookWithToken(long webhookId, String token) {
/*  95 */     return Routes.WEBHOOK_TOKEN_DELETE.newRequest(new Object[] { Long.valueOf(webhookId), token
/*  96 */         }).exchange(getRouter())
/*  97 */       .bodyToMono(Void.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<MessageData> executeWebhook(long webhookId, String token, boolean wait, MultipartRequest<? extends WebhookExecuteRequest> request) {
/* 110 */     return Routes.WEBHOOK_EXECUTE
/* 111 */       .newRequest(new Object[] { Long.valueOf(webhookId), token
/* 112 */         }).query("wait", Boolean.valueOf(wait))
/* 113 */       .header("content-type", request.getFiles().isEmpty() ? "application/json" : "multipart/form-data")
/* 114 */       .body(Objects.requireNonNull(request.getFiles().isEmpty() ? request.getJsonPayload() : request))
/* 115 */       .exchange(getRouter())
/* 116 */       .bodyToMono(MessageData.class);
/*     */   }
/*     */   
/*     */   public Mono<MessageData> getWebhookMessage(long webhookId, String webhookToken, String messageId) {
/* 120 */     return Routes.WEBHOOK_MESSAGE_GET.newRequest(new Object[] { Long.valueOf(webhookId), webhookToken, messageId
/* 121 */         }).exchange(getRouter())
/* 122 */       .bodyToMono(MessageData.class);
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<MessageData> modifyWebhookMessage(long webhookId, String webhookToken, String messageId, WebhookMessageEditRequest request) {
/* 127 */     return Routes.WEBHOOK_MESSAGE_EDIT.newRequest(new Object[] { Long.valueOf(webhookId), webhookToken, messageId
/* 128 */         }).body(request)
/* 129 */       .exchange(getRouter())
/* 130 */       .bodyToMono(MessageData.class);
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<MessageData> modifyWebhookMessage(long webhookId, String webhookToken, String messageId, MultipartRequest<WebhookMessageEditRequest> request) {
/* 135 */     return Routes.WEBHOOK_MESSAGE_EDIT.newRequest(new Object[] { Long.valueOf(webhookId), webhookToken, messageId
/* 136 */         }).header("content-type", request.getFiles().isEmpty() ? "application/json" : "multipart/form-data")
/* 137 */       .body(Objects.requireNonNull(request.getFiles().isEmpty() ? request.getJsonPayload() : request))
/* 138 */       .exchange(getRouter())
/* 139 */       .bodyToMono(MessageData.class);
/*     */   }
/*     */   
/*     */   public Mono<Void> deleteWebhookMessage(long webhookId, String webhookToken, String messageId) {
/* 143 */     return Routes.WEBHOOK_MESSAGE_DELETE.newRequest(new Object[] { Long.valueOf(webhookId), webhookToken, messageId
/* 144 */         }).exchange(getRouter())
/* 145 */       .bodyToMono(Void.class);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\service\WebhookService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */