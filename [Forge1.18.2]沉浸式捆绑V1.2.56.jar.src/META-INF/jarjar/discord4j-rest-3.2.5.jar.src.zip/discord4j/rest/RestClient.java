/*     */ package discord4j.rest;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.discordjson.Id;
/*     */ import discord4j.discordjson.json.ApplicationInfoData;
/*     */ import discord4j.discordjson.json.ChannelData;
/*     */ import discord4j.discordjson.json.EmojiData;
/*     */ import discord4j.discordjson.json.GuildCreateRequest;
/*     */ import discord4j.discordjson.json.GuildData;
/*     */ import discord4j.discordjson.json.GuildScheduledEventData;
/*     */ import discord4j.discordjson.json.GuildUpdateData;
/*     */ import discord4j.discordjson.json.InviteData;
/*     */ import discord4j.discordjson.json.MemberData;
/*     */ import discord4j.discordjson.json.MessageData;
/*     */ import discord4j.discordjson.json.RegionData;
/*     */ import discord4j.discordjson.json.RoleData;
/*     */ import discord4j.discordjson.json.StickerData;
/*     */ import discord4j.discordjson.json.TemplateData;
/*     */ import discord4j.discordjson.json.UserData;
/*     */ import discord4j.discordjson.json.UserGuildData;
/*     */ import discord4j.discordjson.json.UserModifyRequest;
/*     */ import discord4j.discordjson.json.WebhookData;
/*     */ import discord4j.rest.entity.RestChannel;
/*     */ import discord4j.rest.entity.RestEmoji;
/*     */ import discord4j.rest.entity.RestGuild;
/*     */ import discord4j.rest.entity.RestMember;
/*     */ import discord4j.rest.entity.RestMessage;
/*     */ import discord4j.rest.entity.RestRole;
/*     */ import discord4j.rest.entity.RestScheduledEvent;
/*     */ import discord4j.rest.entity.RestSticker;
/*     */ import discord4j.rest.entity.RestUser;
/*     */ import discord4j.rest.entity.RestWebhook;
/*     */ import discord4j.rest.request.Router;
/*     */ import discord4j.rest.request.RouterOptions;
/*     */ import discord4j.rest.service.ApplicationService;
/*     */ import discord4j.rest.service.AuditLogService;
/*     */ import discord4j.rest.service.AutoModService;
/*     */ import discord4j.rest.service.ChannelService;
/*     */ import discord4j.rest.service.EmojiService;
/*     */ import discord4j.rest.service.GatewayService;
/*     */ import discord4j.rest.service.GuildService;
/*     */ import discord4j.rest.service.InteractionService;
/*     */ import discord4j.rest.service.InviteService;
/*     */ import discord4j.rest.service.StickerService;
/*     */ import discord4j.rest.service.TemplateService;
/*     */ import discord4j.rest.service.UserService;
/*     */ import discord4j.rest.service.VoiceService;
/*     */ import discord4j.rest.service.WebhookService;
/*     */ import discord4j.rest.util.PaginationUtil;
/*     */ import java.time.Duration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.function.Function;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ public class RestClient {
/*     */   private final RestResources restResources;
/*     */   private final ApplicationService applicationService;
/*     */   private final AuditLogService auditLogService;
/*     */   private final ChannelService channelService;
/*     */   
/*     */   public static RestClient create(String token) {
/*  65 */     return RestClientBuilder.createRest(token).build();
/*     */   }
/*     */   private final EmojiService emojiService; private final StickerService stickerService; private final GatewayService gatewayService; private final GuildService guildService; private final InteractionService interactionService; private final InviteService inviteService;
/*     */   private final TemplateService templateService;
/*     */   private final UserService userService;
/*     */   private final VoiceService voiceService;
/*     */   private final WebhookService webhookService;
/*     */   private final Mono<Long> applicationIdMono;
/*     */   private final AutoModService autoModService;
/*     */   
/*     */   public static RestClientBuilder<RestClient, RouterOptions> restBuilder(String token) {
/*  76 */     return RestClientBuilder.createRest(token);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected RestClient(RestResources restResources) {
/*  85 */     this.restResources = restResources;
/*  86 */     Router router = restResources.getRouter();
/*  87 */     this.applicationService = new ApplicationService(router);
/*  88 */     this.auditLogService = new AuditLogService(router);
/*  89 */     this.channelService = new ChannelService(router);
/*  90 */     this.emojiService = new EmojiService(router);
/*  91 */     this.stickerService = new StickerService(router);
/*  92 */     this.gatewayService = new GatewayService(router);
/*  93 */     this.guildService = new GuildService(router);
/*  94 */     this.interactionService = new InteractionService(router);
/*  95 */     this.inviteService = new InviteService(router);
/*  96 */     this.templateService = new TemplateService(router);
/*  97 */     this.userService = new UserService(router);
/*  98 */     this.voiceService = new VoiceService(router);
/*  99 */     this.webhookService = new WebhookService(router);
/* 100 */     this.autoModService = new AutoModService(router);
/*     */     
/* 102 */     this
/*     */       
/* 104 */       .applicationIdMono = getApplicationInfo().map(app -> Long.valueOf(Snowflake.asLong(app.id()))).cache(__ -> Duration.ofMillis(Long.MAX_VALUE), __ -> Duration.ZERO, () -> Duration.ZERO);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestResources getRestResources() {
/* 113 */     return this.restResources;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestChannel getChannelById(Snowflake channelId) {
/* 123 */     return RestChannel.create(this, channelId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestChannel restChannel(ChannelData data) {
/* 133 */     return RestChannel.create(this, Snowflake.of(data.id()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestGuild getGuildById(Snowflake guildId) {
/* 143 */     return RestGuild.create(this, guildId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestGuild restGuild(GuildData data) {
/* 153 */     return RestGuild.create(this, Snowflake.of(data.id()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestEmoji getGuildEmojiById(Snowflake guildId, Snowflake emojiId) {
/* 164 */     return RestEmoji.create(this, guildId, emojiId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestEmoji restGuildEmoji(Snowflake guildId, EmojiData data) {
/* 175 */     return RestEmoji.create(this, guildId, 
/* 176 */         Snowflake.of((Id)data.id().orElseThrow(() -> new IllegalArgumentException("Not a guild emoji"))));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestSticker getGuildStickerById(Snowflake guildId, Snowflake stickerId) {
/* 187 */     return RestSticker.create(this, guildId, stickerId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestSticker restGuildSticker(Snowflake guildId, StickerData data) {
/* 198 */     return RestSticker.create(this, guildId, 
/* 199 */         Snowflake.of(data.id()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestMember getMemberById(Snowflake guildId, Snowflake userId) {
/* 210 */     return RestMember.create(this, guildId, userId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestMember restMember(Snowflake guildId, MemberData data) {
/* 221 */     return RestMember.create(this, guildId, Snowflake.of(data.user().id()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestMember selfRestMember(Snowflake guildId) {
/* 231 */     return RestMember.create(this, guildId, this.restResources.getSelfId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestMessage getMessageById(Snowflake channelId, Snowflake messageId) {
/* 242 */     return RestMessage.create(this, channelId, messageId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestMessage restMessage(MessageData data) {
/* 252 */     return RestMessage.create(this, Snowflake.of(data.channelId()), Snowflake.of(data.id()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestRole getRoleById(Snowflake guildId, Snowflake roleId) {
/* 263 */     return RestRole.create(this, guildId, roleId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestRole restRole(Snowflake guildId, RoleData data) {
/* 274 */     return RestRole.create(this, guildId, Snowflake.of(data.id()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestScheduledEvent getScheduledEventById(Snowflake guildId, Snowflake eventId) {
/* 285 */     return RestScheduledEvent.create(this, guildId, eventId);
/*     */   }
/*     */   
/*     */   public RestScheduledEvent restScheduledEvent(Snowflake guildId, GuildScheduledEventData data) {
/* 289 */     return RestScheduledEvent.create(this, guildId, Snowflake.of(data.id()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestUser getUserById(Snowflake userId) {
/* 299 */     return RestUser.create(this, userId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestUser restUser(UserData data) {
/* 309 */     return RestUser.create(this, Snowflake.of(data.id()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestWebhook getWebhookById(Snowflake webhookId) {
/* 319 */     return RestWebhook.create(this, webhookId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestWebhook restWebhook(WebhookData data) {
/* 329 */     return RestWebhook.create(this, Snowflake.of(data.id()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<ApplicationInfoData> getApplicationInfo() {
/* 339 */     return getApplicationService()
/* 340 */       .getCurrentApplicationInfo();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Flux<UserGuildData> getGuilds() {
/* 350 */     Function<Map<String, Object>, Flux<UserGuildData>> makeRequest = params -> getUserService().getCurrentUserGuilds(params);
/*     */ 
/*     */ 
/*     */     
/* 354 */     return PaginationUtil.paginateAfter(makeRequest, data -> Snowflake.asLong(data.id()), 0L, 100);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Flux<RegionData> getRegions() {
/* 364 */     return getVoiceService().getVoiceRegions();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<UserData> getSelf() {
/* 374 */     return this.userService.getCurrentUser();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<MemberData> getSelfMember(Snowflake guildId) {
/* 385 */     return this.guildService.getGuildMember(guildId.asLong(), this.restResources.getSelfId().asLong());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<GuildUpdateData> createGuild(GuildCreateRequest request) {
/* 396 */     return this.guildService.createGuild(request);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<InviteData> getInvite(String inviteCode) {
/* 407 */     return this.inviteService.getInvite(inviteCode);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<InviteData> getInvite(String inviteCode, boolean withCounts, boolean withExpiration, @Nullable Snowflake guildScheduledEventId) {
/* 422 */     Map<String, Object> queryParams = new HashMap<>();
/* 423 */     queryParams.put("with_counts", Boolean.valueOf(withCounts));
/* 424 */     queryParams.put("with_expiration", Boolean.valueOf(withExpiration));
/* 425 */     if (guildScheduledEventId != null) {
/* 426 */       queryParams.put("guild_scheduled_event_id", guildScheduledEventId.asString());
/*     */     }
/* 428 */     return this.inviteService.getInvite(inviteCode, queryParams);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<TemplateData> getTemplate(String templateCode) {
/* 439 */     return this.templateService.getTemplate(templateCode);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<UserData> edit(UserModifyRequest request) {
/* 450 */     return this.userService.modifyCurrentUser(request);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ApplicationService getApplicationService() {
/* 459 */     return this.applicationService;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AuditLogService getAuditLogService() {
/* 468 */     return this.auditLogService;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelService getChannelService() {
/* 479 */     return this.channelService;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EmojiService getEmojiService() {
/* 490 */     return this.emojiService;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StickerService getStickerService() {
/* 501 */     return this.stickerService;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GatewayService getGatewayService() {
/* 510 */     return this.gatewayService;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GuildService getGuildService() {
/* 521 */     return this.guildService;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InteractionService getInteractionService() {
/* 529 */     return this.interactionService;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InviteService getInviteService() {
/* 539 */     return this.inviteService;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TemplateService getTemplateService() {
/* 549 */     return this.templateService;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UserService getUserService() {
/* 560 */     return this.userService;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public VoiceService getVoiceService() {
/* 569 */     return this.voiceService;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebhookService getWebhookService() {
/* 580 */     return this.webhookService;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AutoModService getAutoModService() {
/* 589 */     return this.autoModService;
/*     */   }
/*     */   
/*     */   public Mono<Long> getApplicationId() {
/* 593 */     return this.applicationIdMono;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\RestClient.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */