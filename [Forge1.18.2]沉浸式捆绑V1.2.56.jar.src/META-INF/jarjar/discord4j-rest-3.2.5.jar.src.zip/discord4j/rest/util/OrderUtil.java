/*    */ package discord4j.rest.util;
/*    */ 
/*    */ import discord4j.common.util.Snowflake;
/*    */ import discord4j.discordjson.json.RoleData;
/*    */ import java.util.Comparator;
/*    */ import reactor.core.publisher.Flux;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OrderUtil
/*    */ {
/* 42 */   public static final Comparator<RoleData> ROLE_ORDER = Comparator.comparing(RoleData::position).thenComparing(OrderUtil::idFromRoleData);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Flux<RoleData> orderRoles(Flux<RoleData> roles) {
/* 53 */     return roles.sort(ROLE_ORDER);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static Snowflake idFromRoleData(RoleData data) {
/* 63 */     return Snowflake.of(data.id());
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\res\\util\OrderUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */