/*     */ package discord4j.rest.util;
/*     */ 
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Color
/*     */ {
/*  24 */   public static final Color WHITE = of(255, 255, 255);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  30 */   public static final Color DISCORD_WHITE = of(255, 255, 254);
/*     */ 
/*     */   
/*  33 */   public static final Color LIGHT_GRAY = of(192, 192, 192);
/*     */ 
/*     */   
/*  36 */   public static final Color GRAY = of(128, 128, 128);
/*     */ 
/*     */   
/*  39 */   public static final Color DARK_GRAY = of(64, 64, 64);
/*     */ 
/*     */   
/*  42 */   public static final Color BLACK = of(0, 0, 0);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  48 */   public static final Color DISCORD_BLACK = of(0, 0, 1);
/*     */ 
/*     */   
/*  51 */   public static final Color RED = of(255, 0, 0);
/*     */ 
/*     */   
/*  54 */   public static final Color PINK = of(255, 175, 175);
/*     */ 
/*     */   
/*  57 */   public static final Color ORANGE = of(255, 200, 0);
/*     */ 
/*     */   
/*  60 */   public static final Color YELLOW = of(255, 255, 0);
/*     */ 
/*     */   
/*  63 */   public static final Color GREEN = of(0, 255, 0);
/*     */ 
/*     */   
/*  66 */   public static final Color MAGENTA = of(255, 0, 255);
/*     */ 
/*     */   
/*  69 */   public static final Color CYAN = of(0, 255, 255);
/*     */ 
/*     */   
/*  72 */   public static final Color BLUE = of(0, 0, 255);
/*     */ 
/*     */   
/*  75 */   public static final Color LIGHT_SEA_GREEN = of(1752220);
/*     */ 
/*     */   
/*  78 */   public static final Color MEDIUM_SEA_GREEN = of(3066993);
/*     */ 
/*     */   
/*  81 */   public static final Color SUMMER_SKY = of(3447003);
/*     */ 
/*     */   
/*  84 */   public static final Color DEEP_LILAC = of(10181046);
/*     */ 
/*     */   
/*  87 */   public static final Color RUBY = of(15277667);
/*     */ 
/*     */   
/*  90 */   public static final Color MOON_YELLOW = of(15844367);
/*     */ 
/*     */   
/*  93 */   public static final Color TAHITI_GOLD = of(15105570);
/*     */ 
/*     */   
/*  96 */   public static final Color CINNABAR = of(15158332);
/*     */ 
/*     */   
/*  99 */   public static final Color SUBMARINE = of(9807270);
/*     */ 
/*     */   
/* 102 */   public static final Color HOKI = of(6323595);
/*     */ 
/*     */   
/* 105 */   public static final Color DEEP_SEA = of(1146986);
/*     */ 
/*     */   
/* 108 */   public static final Color SEA_GREEN = of(2067276);
/*     */ 
/*     */   
/* 111 */   public static final Color ENDEAVOUR = of(2123412);
/*     */ 
/*     */   
/* 114 */   public static final Color VIVID_VIOLET = of(7419530);
/*     */ 
/*     */   
/* 117 */   public static final Color JAZZBERRY_JAM = of(11342935);
/*     */ 
/*     */   
/* 120 */   public static final Color DARK_GOLDENROD = of(12745742);
/*     */ 
/*     */   
/* 123 */   public static final Color RUST = of(11027200);
/*     */ 
/*     */   
/* 126 */   public static final Color BROWN = of(10038562);
/*     */ 
/*     */   
/* 129 */   public static final Color GRAY_CHATEAU = of(9936031);
/*     */ 
/*     */   
/* 132 */   public static final Color BISMARK = of(5533306);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int rgb;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Color of(float red, float green, float blue) {
/* 143 */     return of((int)(red * 255.0F + 0.5F), (int)(green * 255.0F + 0.5F), (int)(blue * 255.0F + 0.5F));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Color of(int red, int green, int blue) {
/* 155 */     if ((red & 0xFF) != red || (green & 0xFF) != green || (blue & 0xFF) != blue) {
/* 156 */       throw new IllegalArgumentException("Illegal RGB arguments red=0x" + 
/* 157 */           Integer.toHexString(red) + " green=0x" + 
/* 158 */           Integer.toHexString(green) + " blue=0x" + 
/* 159 */           Integer.toHexString(blue));
/*     */     }
/*     */     
/* 162 */     return of(red << 16 | green << 8 | blue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Color of(int rgb) {
/* 172 */     return new Color(rgb & 0xFFFFFF);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Color(int rgb) {
/* 185 */     this.rgb = rgb;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getRGB() {
/* 194 */     return this.rgb;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getRed() {
/* 203 */     return this.rgb >> 16 & 0xFF;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getGreen() {
/* 212 */     return this.rgb >> 8 & 0xFF;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getBlue() {
/* 221 */     return this.rgb & 0xFF;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 226 */     return "Color{red=" + 
/* 227 */       getRed() + ", green=" + 
/* 228 */       getGreen() + ", blue=" + 
/* 229 */       getBlue() + '}';
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object obj) {
/* 234 */     return (obj instanceof Color && ((Color)obj).getRGB() == getRGB());
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 238 */     return getRGB();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\res\\util\Color.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */