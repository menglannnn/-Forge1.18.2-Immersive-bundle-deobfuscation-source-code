/*     */ package discord4j.rest.util;
/*     */ 
/*     */ import java.util.AbstractSet;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.EnumSet;
/*     */ import java.util.Iterator;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PermissionSet
/*     */   extends AbstractSet<Permission>
/*     */ {
/*     */   private static final long ALL_RAW;
/*     */   private static final long NONE_RAW = 0L;
/*     */   
/*     */   static {
/*  39 */     ALL_RAW = Arrays.<Permission>stream(Permission.values()).mapToLong(Permission::getValue).reduce(0L, (a, b) -> a | b);
/*     */   }
/*     */ 
/*     */   
/*  43 */   private static final PermissionSet ALL = new PermissionSet(ALL_RAW);
/*     */ 
/*     */   
/*  46 */   private static final PermissionSet NONE = new PermissionSet(0L);
/*     */ 
/*     */   
/*     */   private final long rawValue;
/*     */ 
/*     */ 
/*     */   
/*     */   public static PermissionSet all() {
/*  54 */     return ALL;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PermissionSet none() {
/*  63 */     return NONE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PermissionSet of(long rawValue) {
/*  73 */     return new PermissionSet(rawValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PermissionSet of(String rawValue) {
/*  84 */     return new PermissionSet(Long.parseUnsignedLong(rawValue));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PermissionSet of(Permission... permissions) {
/*  96 */     long rawValue = Arrays.<Permission>stream(permissions).mapToLong(Permission::getValue).reduce(0L, (left, right) -> left | right);
/*  97 */     return new PermissionSet(rawValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private PermissionSet(long rawValue) {
/* 109 */     this.rawValue = rawValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PermissionSet and(PermissionSet other) {
/* 130 */     return of(this.rawValue & other.rawValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PermissionSet or(PermissionSet other) {
/* 151 */     return of(this.rawValue | other.rawValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PermissionSet xor(PermissionSet other) {
/* 172 */     return of(this.rawValue ^ other.rawValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PermissionSet andNot(PermissionSet other) {
/* 194 */     return of(this.rawValue & (other.rawValue ^ 0xFFFFFFFFFFFFFFFFL));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public PermissionSet subtract(PermissionSet other) {
/* 218 */     return of(this.rawValue & (other.rawValue ^ 0xFFFFFFFFFFFFFFFFL));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PermissionSet not() {
/* 237 */     return of((this.rawValue ^ 0xFFFFFFFFFFFFFFFFL) & ALL_RAW);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EnumSet<Permission> asEnumSet() {
/* 246 */     EnumSet<Permission> permissions = EnumSet.allOf(Permission.class);
/* 247 */     permissions.removeIf(permission -> !contains(permission));
/* 248 */     return permissions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getRawValue() {
/* 258 */     return this.rawValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean contains(Object o) {
/* 263 */     return (o instanceof Permission && (((Permission)o).getValue() & this.rawValue) > 0L);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<Permission> iterator() {
/* 269 */     return Collections.<Permission>unmodifiableSet(asEnumSet()).iterator();
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/* 274 */     return Long.bitCount(this.rawValue);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object o) {
/* 279 */     if (this == o) {
/* 280 */       return true;
/*     */     }
/* 282 */     if (o == null || getClass() != o.getClass()) {
/* 283 */       return false;
/*     */     }
/*     */     
/* 286 */     PermissionSet that = (PermissionSet)o;
/* 287 */     return (this.rawValue == that.rawValue);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 292 */     return Long.hashCode(this.rawValue);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 297 */     return "PermissionSet{rawValue=" + this.rawValue + "} " + super
/*     */       
/* 299 */       .toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\res\\util\PermissionSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */