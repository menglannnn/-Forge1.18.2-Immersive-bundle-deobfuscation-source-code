/*     */ package discord4j.rest.util;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.ConcurrentModificationException;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import java.util.function.BiConsumer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Multimap<K, V>
/*     */   implements Map<K, List<V>>
/*     */ {
/*     */   private final Map<K, List<V>> map;
/*     */   
/*     */   public Multimap() {
/*  38 */     this.map = new LinkedHashMap<>();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Multimap(int initialCapacity) {
/*  47 */     this.map = new LinkedHashMap<>(initialCapacity);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(K key, V value) {
/*  57 */     ((List<V>)this.map.computeIfAbsent(key, k -> new LinkedList())).add(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addAll(K key, Collection<? extends V> values) {
/*  67 */     ((List<V>)this.map.computeIfAbsent(key, k -> new LinkedList())).addAll(values);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addAll(Multimap<K, V> values) {
/*  76 */     values.forEach(this::addAll);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void set(K key, V value) {
/*  86 */     List<V> list = new LinkedList<>();
/*  87 */     list.add(value);
/*  88 */     this.map.put(key, list);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAll(Map<K, V> values) {
/*  97 */     values.forEach(this::set);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Multimap<K, V> deepCopy() {
/* 106 */     Multimap<K, V> copy = new Multimap(this.map.size());
/* 107 */     this.map.forEach((key, value) -> copy.put(key, new LinkedList(value)));
/* 108 */     return copy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void forEachElement(BiConsumer<? super K, ? super V> action) {
/* 122 */     Objects.requireNonNull(action);
/* 123 */     for (Map.Entry<K, List<V>> entry : entrySet()) {
/*     */       
/*     */       try {
/* 126 */         for (V v : entry.getValue()) {
/* 127 */           K k = entry.getKey();
/* 128 */           action.accept(k, v);
/*     */         } 
/* 130 */       } catch (IllegalStateException ise) {
/* 131 */         throw new ConcurrentModificationException(ise);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/* 138 */     return this.map.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 143 */     return this.map.isEmpty();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsKey(Object key) {
/* 148 */     return this.map.containsKey(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsValue(Object value) {
/* 153 */     return this.map.containsValue(value);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<V> get(Object key) {
/* 158 */     return this.map.get(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<V> put(K key, List<V> value) {
/* 163 */     return this.map.put(key, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<V> remove(Object key) {
/* 168 */     return this.map.remove(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public void putAll(Map<? extends K, ? extends List<V>> m) {
/* 173 */     this.map.putAll(m);
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/* 178 */     this.map.clear();
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<K> keySet() {
/* 183 */     return this.map.keySet();
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<List<V>> values() {
/* 188 */     return this.map.values();
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<Map.Entry<K, List<V>>> entrySet() {
/* 193 */     return this.map.entrySet();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\res\\util\Multimap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */