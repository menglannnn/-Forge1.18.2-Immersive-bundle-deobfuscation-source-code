/*     */ package discord4j.rest.util;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.discordjson.json.AllowedMentionsData;
/*     */ import discord4j.discordjson.json.ImmutableAllowedMentionsData;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.function.Function;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AllowedMentions
/*     */ {
/*     */   private final Possible<Set<Type>> parse;
/*     */   private final Possible<Set<Snowflake>> userIds;
/*     */   private final Possible<Set<Snowflake>> roleIds;
/*     */   private final Possible<Boolean> repliedUser;
/*     */   
/*     */   public static Builder builder() {
/*  43 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder(AllowedMentions template) {
/*  53 */     return new Builder(template.parse, template.userIds, template.roleIds, template.repliedUser);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AllowedMentions suppressAll() {
/*  62 */     return builder().build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AllowedMentions suppressEveryone() {
/*  71 */     return builder().parseType(new Type[] { Type.USER, Type.ROLE }).build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private AllowedMentions(Possible<Set<Type>> parse, Possible<Set<Snowflake>> userIds, Possible<Set<Snowflake>> roleIds, Possible<Boolean> repliedUser) {
/*  81 */     this.parse = parse;
/*  82 */     this.userIds = userIds;
/*  83 */     this.roleIds = roleIds;
/*  84 */     this.repliedUser = repliedUser;
/*     */   }
/*     */   
/*     */   private <T, U> List<T> mapSetToList(Set<U> list, Function<? super U, ? extends T> mapper) {
/*  88 */     List<T> data = new ArrayList<>(list.size());
/*  89 */     list.forEach(u -> data.add(mapper.apply(u)));
/*  90 */     return data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Builder mutate() {
/*  99 */     return new Builder(this.parse, this.userIds, this.roleIds, this.repliedUser);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AllowedMentionsData toData() {
/* 108 */     ImmutableAllowedMentionsData.Builder builder = AllowedMentionsData.builder();
/* 109 */     if (!this.parse.isAbsent()) {
/* 110 */       builder.parse(mapSetToList((Set)this.parse.get(), Type::getRaw));
/*     */     }
/* 112 */     if (!this.userIds.isAbsent()) {
/* 113 */       builder.users(mapSetToList((Set)this.userIds.get(), Snowflake::asString));
/*     */     }
/* 115 */     if (!this.roleIds.isAbsent()) {
/* 116 */       builder.roles(mapSetToList((Set)this.roleIds.get(), Snowflake::asString));
/*     */     }
/* 118 */     if (this.parse.isAbsent() && this.userIds.isAbsent() && this.roleIds.isAbsent()) {
/* 119 */       builder.parse(Collections.emptyList());
/*     */     }
/* 121 */     if (!this.repliedUser.isAbsent()) {
/* 122 */       builder.repliedUser((Boolean)this.repliedUser.get());
/*     */     }
/* 124 */     return (AllowedMentionsData)builder.build();
/*     */   }
/*     */ 
/*     */   
/*     */   public static class Builder
/*     */   {
/*     */     private Possible<Set<AllowedMentions.Type>> parse;
/*     */     
/*     */     private Possible<Set<Snowflake>> userIds;
/*     */     
/*     */     private Possible<Set<Snowflake>> roleIds;
/*     */     
/*     */     private Possible<Boolean> repliedUser;
/*     */ 
/*     */     
/*     */     private Builder() {
/* 140 */       this(
/* 141 */           Possible.absent(), 
/* 142 */           Possible.absent(), 
/* 143 */           Possible.absent(), 
/* 144 */           Possible.absent());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private Builder(Possible<Set<AllowedMentions.Type>> parse, Possible<Set<Snowflake>> userIds, Possible<Set<Snowflake>> roleIds, Possible<Boolean> repliedUser) {
/* 150 */       this.parse = parse;
/* 151 */       this.userIds = userIds;
/* 152 */       this.roleIds = roleIds;
/* 153 */       this.repliedUser = repliedUser;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder parseType(AllowedMentions.Type type) {
/* 163 */       if (this.parse.isAbsent()) {
/* 164 */         this.parse = Possible.of(new HashSet());
/*     */       }
/* 166 */       ((Set<AllowedMentions.Type>)this.parse.get()).add(type);
/* 167 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder allowUser(Snowflake userId) {
/* 177 */       if (this.userIds.isAbsent()) {
/* 178 */         this.userIds = Possible.of(new HashSet());
/*     */       }
/* 180 */       ((Set<Snowflake>)this.userIds.get()).add(userId);
/* 181 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder allowRole(Snowflake roleId) {
/* 191 */       if (this.roleIds.isAbsent()) {
/* 192 */         this.roleIds = Possible.of(new HashSet());
/*     */       }
/* 194 */       ((Set<Snowflake>)this.roleIds.get()).add(roleId);
/* 195 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder parseType(AllowedMentions.Type... type) {
/* 205 */       if (this.parse.isAbsent()) {
/* 206 */         this.parse = Possible.of(new HashSet());
/*     */       }
/* 208 */       ((Set)this.parse.get()).addAll(Arrays.asList(type));
/* 209 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder allowUser(Snowflake... userId) {
/* 219 */       if (this.userIds.isAbsent()) {
/* 220 */         this.userIds = Possible.of(new HashSet());
/*     */       }
/* 222 */       ((Set)this.userIds.get()).addAll(Arrays.asList(userId));
/* 223 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder allowRole(Snowflake... roleId) {
/* 233 */       if (this.roleIds.isAbsent()) {
/* 234 */         this.roleIds = Possible.of(new HashSet());
/*     */       }
/* 236 */       ((Set)this.roleIds.get()).addAll(Arrays.asList(roleId));
/* 237 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder repliedUser(boolean repliedUser) {
/* 247 */       this.repliedUser = Possible.of(Boolean.valueOf(repliedUser));
/* 248 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AllowedMentions build() {
/* 257 */       return new AllowedMentions(this.parse, this.userIds, this.roleIds, this.repliedUser);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Type
/*     */   {
/* 269 */     ROLE("roles"),
/*     */ 
/*     */ 
/*     */     
/* 273 */     USER("users"),
/*     */ 
/*     */ 
/*     */     
/* 277 */     EVERYONE_AND_HERE("everyone");
/*     */     
/*     */     private final String raw;
/*     */     
/*     */     Type(String raw) {
/* 282 */       this.raw = raw;
/*     */     }
/*     */     
/*     */     public String getRaw() {
/* 286 */       return this.raw;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\res\\util\AllowedMentions.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */