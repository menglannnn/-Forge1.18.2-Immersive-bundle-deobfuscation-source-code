/*     */ package discord4j.rest.util;
/*     */ 
/*     */ import discord4j.common.ReactorResources;
/*     */ import java.util.Arrays;
/*     */ import java.util.Base64;
/*     */ import java.util.Objects;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.netty.ByteBufMono;
/*     */ import reactor.netty.http.client.HttpClient;
/*     */ import reactor.netty.http.client.HttpClientResponse;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Image
/*     */ {
/*     */   private final byte[] data;
/*     */   private final Format format;
/*     */   
/*     */   public static Image ofRaw(byte[] data, Format format) {
/*  42 */     return new Image(data, format);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Mono<Image> ofUrl(String url) {
/*  53 */     return ((HttpClient.ResponseReceiver)((HttpClient)ReactorResources.DEFAULT_HTTP_CLIENT.get())
/*  54 */       .get()
/*  55 */       .uri(url))
/*  56 */       .responseSingle((res, body) -> body.asByteArray().map(()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Image(byte[] data, Format format) {
/*  69 */     this.data = data;
/*  70 */     this.format = format;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getData() {
/*  79 */     return this.data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Format getFormat() {
/*  88 */     return this.format;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getHash() {
/*  97 */     return Base64.getEncoder().encodeToString(this.data);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDataUri() {
/* 106 */     return String.format("data:image/%s;base64,%s", new Object[] { Format.access$000(this.format), getHash() });
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 111 */     return "Image{data=" + 
/* 112 */       Arrays.toString(this.data) + ", format=" + this.format + '}';
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object o) {
/* 119 */     if (this == o) {
/* 120 */       return true;
/*     */     }
/* 122 */     if (o == null || getClass() != o.getClass()) {
/* 123 */       return false;
/*     */     }
/* 125 */     Image image = (Image)o;
/* 126 */     return (Arrays.equals(this.data, image.data) && this.format == image.format);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 132 */     int result = Objects.hash(new Object[] { this.format });
/* 133 */     result = 31 * result + Arrays.hashCode(this.data);
/* 134 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Format
/*     */   {
/* 145 */     UNKNOWN("UNKNOWN"),
/*     */ 
/*     */     
/* 148 */     JPEG("jpeg"),
/*     */ 
/*     */     
/* 151 */     PNG("png"),
/*     */ 
/*     */     
/* 154 */     WEB_P("webp"),
/*     */ 
/*     */     
/* 157 */     GIF("gif"),
/*     */ 
/*     */     
/* 160 */     LOTTIE("json");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final String extension;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Format(String extension) {
/* 171 */       this.extension = extension;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getExtension() {
/* 180 */       return this.extension;
/*     */     }
/*     */     
/*     */     private static Format fromContentType(String contentType) {
/* 184 */       switch (contentType) { case "image/jpeg":
/* 185 */           return JPEG;
/* 186 */         case "image/png": return PNG;
/* 187 */         case "image/webp": return WEB_P;
/* 188 */         case "image/gif": return GIF; }
/* 189 */        return UNKNOWN;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\res\\util\Image.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */