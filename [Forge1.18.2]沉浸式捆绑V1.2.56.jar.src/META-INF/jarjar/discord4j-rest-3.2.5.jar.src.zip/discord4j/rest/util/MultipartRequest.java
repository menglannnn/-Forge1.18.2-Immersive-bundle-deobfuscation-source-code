/*    */ package discord4j.rest.util;
/*    */ 
/*    */ import discord4j.discordjson.json.MessageCreateRequest;
/*    */ import java.io.InputStream;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import reactor.util.annotation.Nullable;
/*    */ import reactor.util.function.Tuple2;
/*    */ import reactor.util.function.Tuples;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MultipartRequest<T>
/*    */ {
/*    */   private final T jsonPayload;
/*    */   private final List<Tuple2<String, InputStream>> files;
/*    */   
/*    */   private MultipartRequest(T jsonPayload, List<Tuple2<String, InputStream>> files) {
/* 36 */     this.jsonPayload = jsonPayload;
/* 37 */     this.files = Collections.unmodifiableList(files);
/*    */   }
/*    */   
/*    */   public static <T> MultipartRequest<T> ofRequest(T body) {
/* 41 */     return new MultipartRequest<>(body, Collections.emptyList());
/*    */   }
/*    */   
/*    */   public static <T> MultipartRequest<T> ofRequestAndFiles(T body, List<Tuple2<String, InputStream>> files) {
/* 45 */     return new MultipartRequest<>(body, files);
/*    */   }
/*    */   
/*    */   public <R> MultipartRequest<R> withRequest(R body) {
/* 49 */     return new MultipartRequest((T)body, this.files);
/*    */   }
/*    */   
/*    */   public MultipartRequest<T> addFile(String fileName, InputStream file) {
/* 53 */     List<Tuple2<String, InputStream>> list = new ArrayList<>(this.files);
/* 54 */     list.add(Tuples.of(fileName, file));
/* 55 */     return new MultipartRequest(this.jsonPayload, Collections.unmodifiableList(list));
/*    */   }
/*    */   
/*    */   public MultipartRequest<T> addFiles(List<Tuple2<String, InputStream>> filesList) {
/* 59 */     List<Tuple2<String, InputStream>> list = new ArrayList<>(this.files);
/* 60 */     list.addAll(filesList);
/* 61 */     return new MultipartRequest(this.jsonPayload, Collections.unmodifiableList(list));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Deprecated
/*    */   @Nullable
/*    */   public MessageCreateRequest getCreateRequest() {
/* 70 */     return (MessageCreateRequest)this.jsonPayload;
/*    */   }
/*    */   public T getJsonPayload() {
/* 73 */     return this.jsonPayload;
/*    */   }
/*    */   public List<Tuple2<String, InputStream>> getFiles() {
/* 76 */     return this.files;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\res\\util\MultipartRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */