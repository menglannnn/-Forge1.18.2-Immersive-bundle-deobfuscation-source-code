/*     */ package discord4j.rest.util;
/*     */ 
/*     */ import discord4j.common.annotations.Experimental;
/*     */ import io.netty.handler.codec.http.QueryStringEncoder;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RouteUtils
/*     */ {
/*  37 */   private static final Pattern PARAMETER_PATTERN = Pattern.compile("\\{([\\w.]+)\\}");
/*  38 */   private static final Charset UTF_8 = StandardCharsets.UTF_8;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String expand(String template, Object... variables) {
/*  44 */     if (variables.length == 0) {
/*  45 */       return template;
/*     */     }
/*  47 */     StringBuffer buf = new StringBuffer();
/*  48 */     Matcher matcher = PARAMETER_PATTERN.matcher(template);
/*  49 */     int index = 0;
/*  50 */     while (matcher.find()) {
/*  51 */       matcher.appendReplacement(buf, encodeUriPathSegment(variables[index++].toString()));
/*     */     }
/*  53 */     matcher.appendTail(buf);
/*  54 */     return buf.toString();
/*     */   }
/*     */   
/*     */   @Experimental
/*     */   public static Map<String, String> createVariableMap(String template, Object... variables) {
/*  59 */     Map<String, String> variableMap = new LinkedHashMap<>();
/*  60 */     if (variables.length == 0) {
/*  61 */       return variableMap;
/*     */     }
/*  63 */     Matcher matcher = PARAMETER_PATTERN.matcher(template);
/*  64 */     int index = 0;
/*  65 */     while (matcher.find()) {
/*  66 */       variableMap.put(matcher.group().replaceAll("[{}]", ""), variables[index++].toString());
/*     */     }
/*  68 */     return variableMap;
/*     */   }
/*     */   
/*     */   public static String expandQuery(String uri, @Nullable Multimap<String, Object> values) {
/*  72 */     if (values == null) {
/*  73 */       return uri;
/*     */     }
/*  75 */     QueryStringEncoder encoder = new QueryStringEncoder(uri);
/*  76 */     values.forEach((key, value) -> value.forEach(()));
/*  77 */     return encoder.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static String getMajorParam(String template, String complete) {
/*  83 */     if (template.contains("{channel.id}") || template.contains("{guild.id}") || template.contains("{webhook.id}")) {
/*  84 */       int start = template.indexOf('{');
/*  85 */       if (start == -1) {
/*  86 */         return null;
/*     */       }
/*     */       
/*  89 */       int end = complete.indexOf('/', start);
/*  90 */       if (end == -1) {
/*  91 */         end = complete.length();
/*     */       }
/*     */       
/*  94 */       return complete.substring(start, end);
/*     */     } 
/*  96 */     return null;
/*     */   }
/*     */   
/*     */   private static String encodeUriPathSegment(@Nullable String source) {
/* 100 */     if (source == null || source.isEmpty()) {
/* 101 */       return "";
/*     */     }
/*     */     
/* 104 */     byte[] bytes = source.getBytes(UTF_8);
/* 105 */     ByteArrayOutputStream bos = new ByteArrayOutputStream(bytes.length);
/* 106 */     boolean changed = false;
/* 107 */     for (byte b : bytes) {
/* 108 */       if (b < 0) {
/* 109 */         b = (byte)(b + 256);
/*     */       }
/* 111 */       if (isPathSegmentAllowed(b)) {
/* 112 */         bos.write(b);
/*     */       } else {
/* 114 */         bos.write(37);
/* 115 */         char hex1 = Character.toUpperCase(Character.forDigit(b >> 4 & 0xF, 16));
/* 116 */         char hex2 = Character.toUpperCase(Character.forDigit(b & 0xF, 16));
/* 117 */         bos.write(hex1);
/* 118 */         bos.write(hex2);
/* 119 */         changed = true;
/*     */       } 
/*     */     } 
/* 122 */     return changed ? new String(bos.toByteArray(), UTF_8) : source;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isPathSegmentAllowed(int c) {
/* 131 */     return ((c >= 97 && c <= 122) || (c >= 65 && c <= 90) || (c >= 48 && c <= 57) || c == 45 || c == 46 || c == 95 || c == 126 || c == 33 || c == 36 || c == 38 || c == 39 || c == 40 || c == 41 || c == 42 || c == 43 || c == 44 || c == 59 || c == 61 || c == 58 || c == 64);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\res\\util\RouteUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */