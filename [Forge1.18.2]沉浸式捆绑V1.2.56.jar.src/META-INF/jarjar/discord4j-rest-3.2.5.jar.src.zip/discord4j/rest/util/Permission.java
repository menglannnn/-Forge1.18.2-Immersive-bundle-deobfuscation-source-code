/*     */ package discord4j.rest.util;
/*     */ 
/*     */ import discord4j.common.annotations.Experimental;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum Permission
/*     */ {
/*  29 */   CREATE_INSTANT_INVITE(1L, false),
/*     */ 
/*     */   
/*  32 */   KICK_MEMBERS(2L, true),
/*     */ 
/*     */   
/*  35 */   BAN_MEMBERS(4L, true),
/*     */ 
/*     */   
/*  38 */   ADMINISTRATOR(8L, true),
/*     */ 
/*     */   
/*  41 */   MANAGE_CHANNELS(16L, true),
/*     */ 
/*     */   
/*  44 */   MANAGE_GUILD(32L, true),
/*     */ 
/*     */   
/*  47 */   ADD_REACTIONS(64L, false),
/*     */ 
/*     */   
/*  50 */   VIEW_AUDIT_LOG(128L, false),
/*     */ 
/*     */   
/*  53 */   PRIORITY_SPEAKER(256L, false),
/*     */ 
/*     */   
/*  56 */   STREAM(512L, false),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  62 */   VIEW_CHANNEL(1024L, false),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  68 */   SEND_MESSAGES(2048L, false),
/*     */ 
/*     */   
/*  71 */   SEND_TTS_MESSAGES(4096L, false),
/*     */ 
/*     */   
/*  74 */   MANAGE_MESSAGES(8192L, true),
/*     */ 
/*     */   
/*  77 */   EMBED_LINKS(16384L, false),
/*     */ 
/*     */   
/*  80 */   ATTACH_FILES(32768L, false),
/*     */ 
/*     */   
/*  83 */   READ_MESSAGE_HISTORY(65536L, false),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  89 */   MENTION_EVERYONE(131072L, false),
/*     */ 
/*     */   
/*  92 */   USE_EXTERNAL_EMOJIS(262144L, false),
/*     */ 
/*     */   
/*  95 */   VIEW_GUILD_INSIGHTS(524288L, false),
/*     */ 
/*     */   
/*  98 */   CONNECT(1048576L, false),
/*     */ 
/*     */   
/* 101 */   SPEAK(2097152L, false),
/*     */ 
/*     */   
/* 104 */   MUTE_MEMBERS(4194304L, false),
/*     */ 
/*     */   
/* 107 */   DEAFEN_MEMBERS(8388608L, false),
/*     */ 
/*     */   
/* 110 */   MOVE_MEMBERS(16777216L, false),
/*     */ 
/*     */   
/* 113 */   USE_VAD(33554432L, false),
/*     */ 
/*     */   
/* 116 */   CHANGE_NICKNAME(67108864L, false),
/*     */ 
/*     */   
/* 119 */   MANAGE_NICKNAMES(134217728L, false),
/*     */ 
/*     */   
/* 122 */   MANAGE_ROLES(268435456L, true),
/*     */ 
/*     */   
/* 125 */   MANAGE_WEBHOOKS(536870912L, true),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 132 */   MANAGE_EMOJIS(1073741824L, true),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 140 */   MANAGE_EMOJIS_AND_STICKERS(1073741824L, true),
/*     */ 
/*     */ 
/*     */   
/* 144 */   MANAGE_GUILD_EXPRESSIONS(1073741824L, true),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 150 */   USE_SLASH_COMMANDS(2147483648L, false),
/*     */ 
/*     */ 
/*     */   
/* 154 */   USE_APPLICATION_COMMANDS(2147483648L, false),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 159 */   REQUEST_TO_SPEAK(4294967296L, false),
/*     */ 
/*     */ 
/*     */   
/* 163 */   MANAGE_EVENTS(8589934592L, false),
/*     */ 
/*     */   
/* 166 */   MANAGE_THREADS(17179869184L, true),
/*     */ 
/*     */   
/* 169 */   CREATE_PUBLIC_THREADS(34359738368L, false),
/*     */ 
/*     */   
/* 172 */   CREATE_PRIVATE_THREADS(68719476736L, false),
/*     */ 
/*     */   
/* 175 */   USE_EXTERNAL_STICKERS(137438953472L, false),
/*     */ 
/*     */   
/* 178 */   SEND_MESSAGES_IN_THREADS(274877906944L, false),
/*     */ 
/*     */   
/* 181 */   USE_EMBEDDED_ACTIVITIES(549755813888L, false),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 186 */   MODERATE_MEMBERS(1099511627776L, false),
/*     */ 
/*     */   
/* 189 */   VIEW_CREATOR_MONETIZATION_ANALYTICS(2199023255552L, true),
/*     */ 
/*     */   
/* 192 */   USE_SOUNDBOARD(4398046511104L, false),
/*     */ 
/*     */   
/* 195 */   USE_EXTERNAL_SOUNDS(35184372088832L, false),
/*     */ 
/*     */   
/* 198 */   SEND_VOICE_MESSAGES(70368744177664L, false);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final boolean mfa;
/*     */ 
/*     */ 
/*     */   
/*     */   private final long value;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Permission(long value, boolean mfa) {
/* 213 */     this.value = value;
/* 214 */     this.mfa = mfa;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean requiresMfa() {
/* 225 */     return this.mfa;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getValue() {
/* 234 */     return this.value;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\res\\util\Permission.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */