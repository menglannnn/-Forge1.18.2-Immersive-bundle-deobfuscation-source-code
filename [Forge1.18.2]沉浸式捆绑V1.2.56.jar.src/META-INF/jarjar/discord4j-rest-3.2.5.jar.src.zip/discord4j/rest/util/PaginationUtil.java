/*    */ package discord4j.rest.util;
/*    */ 
/*    */ import java.util.Comparator;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.concurrent.atomic.AtomicLong;
/*    */ import java.util.function.Function;
/*    */ import java.util.function.LongFunction;
/*    */ import java.util.function.ToLongFunction;
/*    */ import org.reactivestreams.Publisher;
/*    */ import reactor.core.publisher.Flux;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class PaginationUtil
/*    */ {
/*    */   public static <T> Flux<T> paginateAfter(Function<Map<String, Object>, Flux<T>> tProducer, ToLongFunction<T> keyExtractor, long startAt, int pageSize) {
/* 36 */     return paginateWithQueryParams(tProducer, keyExtractor, startAt, pageSize, "after", false);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static <T> Flux<T> paginateBefore(Function<Map<String, Object>, Flux<T>> tProducer, ToLongFunction<T> keyExtractor, long startAt, int pageSize) {
/* 43 */     return paginateWithQueryParams(tProducer, keyExtractor, startAt, pageSize, "before", true);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static <T> Flux<T> paginateWithQueryParams(Function<Map<String, Object>, Flux<T>> tProducer, ToLongFunction<T> keyExtractor, long startAt, int pageSize, String queryKey, boolean reverse) {
/* 51 */     LongFunction<Flux<T>> nextPage = id -> {
/*    */         Map<String, Object> parameters = new HashMap<>(2);
/*    */         
/*    */         parameters.put("limit", Integer.valueOf(pageSize));
/*    */         
/*    */         parameters.put(queryKey, Long.valueOf(id));
/*    */         return tProducer.apply(parameters);
/*    */       };
/* 59 */     return paginate(nextPage, keyExtractor, startAt, reverse);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   private static <T> Flux<T> paginate(LongFunction<Flux<T>> nextPage, ToLongFunction<T> keyExtractor, long startAt, boolean reverse) {
/* 65 */     ToLongFunction<List<T>> updateLast = list -> list.isEmpty() ? startAt : keyExtractor.applyAsLong(list.get(list.size() - 1));
/*    */ 
/*    */     
/* 68 */     Comparator<T> comparator = Comparator.comparingLong(keyExtractor);
/* 69 */     AtomicLong previousStart = new AtomicLong(startAt);
/*    */     
/* 71 */     return Flux.defer(() -> (Publisher)nextPage.apply(previousStart.get()))
/* 72 */       .sort(reverse ? comparator.reversed() : comparator)
/* 73 */       .collectList()
/* 74 */       .doOnNext(list -> previousStart.set(updateLast.applyAsLong(list)))
/* 75 */       .flatMapMany(Flux::fromIterable)
/* 76 */       .repeat(() -> (previousStart.get() != startAt));
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\res\\util\PaginationUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */