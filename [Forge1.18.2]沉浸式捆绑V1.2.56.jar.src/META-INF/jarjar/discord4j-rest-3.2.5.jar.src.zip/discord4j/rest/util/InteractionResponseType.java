/*    */ package discord4j.rest.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum InteractionResponseType
/*    */ {
/* 24 */   UNKNOWN(-1),
/*    */ 
/*    */ 
/*    */   
/* 28 */   PONG(1),
/*    */ 
/*    */ 
/*    */   
/* 32 */   CHANNEL_MESSAGE_WITH_SOURCE(4),
/*    */ 
/*    */ 
/*    */   
/* 36 */   DEFERRED_CHANNEL_MESSAGE_WITH_SOURCE(5),
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 41 */   DEFERRED_UPDATE_MESSAGE(6),
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 46 */   UPDATE_MESSAGE(7),
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 51 */   APPLICATION_COMMAND_AUTOCOMPLETE_RESULT(8),
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 56 */   MODAL(9);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private final int value;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   InteractionResponseType(int value) {
/* 69 */     this.value = value;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getValue() {
/* 78 */     return this.value;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static InteractionResponseType of(int value) {
/* 89 */     switch (value) { case 1:
/* 90 */         return PONG;
/* 91 */       case 4: return CHANNEL_MESSAGE_WITH_SOURCE;
/* 92 */       case 5: return DEFERRED_CHANNEL_MESSAGE_WITH_SOURCE;
/* 93 */       case 6: return DEFERRED_UPDATE_MESSAGE;
/* 94 */       case 7: return UPDATE_MESSAGE;
/* 95 */       case 8: return APPLICATION_COMMAND_AUTOCOMPLETE_RESULT;
/* 96 */       case 9: return MODAL; }
/* 97 */      return UNKNOWN;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\res\\util\InteractionResponseType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */