/*     */ package discord4j.rest.entity;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.discordjson.json.WebhookData;
/*     */ import discord4j.discordjson.json.WebhookModifyRequest;
/*     */ import discord4j.rest.RestClient;
/*     */ import java.util.Objects;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RestWebhook
/*     */ {
/*     */   private final RestClient restClient;
/*     */   private final long id;
/*     */   
/*     */   private RestWebhook(RestClient restClient, long id) {
/*  39 */     this.restClient = restClient;
/*  40 */     this.id = id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RestWebhook create(RestClient restClient, Snowflake id) {
/*  51 */     return new RestWebhook(restClient, id.asLong());
/*     */   }
/*     */   
/*     */   static RestWebhook create(RestClient restClient, long id) {
/*  55 */     return new RestWebhook(restClient, id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getId() {
/*  64 */     return Snowflake.of(this.id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<WebhookData> getData() {
/*  74 */     return this.restClient.getWebhookService().getWebhook(this.id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<WebhookData> modify(WebhookModifyRequest request, @Nullable String reason) {
/*  87 */     return this.restClient.getWebhookService().modifyWebhook(this.id, request, reason);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> delete(@Nullable String reason) {
/*  99 */     return this.restClient.getWebhookService().deleteWebhook(this.id, reason);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 104 */     if (this == o) return true; 
/* 105 */     if (o == null || getClass() != o.getClass()) return false; 
/* 106 */     RestWebhook that = (RestWebhook)o;
/* 107 */     return (this.id == that.id);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 112 */     return Objects.hash(new Object[] { Long.valueOf(this.id) });
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\entity\RestWebhook.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */