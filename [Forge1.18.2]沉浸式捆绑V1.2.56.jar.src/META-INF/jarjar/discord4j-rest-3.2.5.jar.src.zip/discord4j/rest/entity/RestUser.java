/*    */ package discord4j.rest.entity;
/*    */ 
/*    */ import discord4j.common.util.Snowflake;
/*    */ import discord4j.discordjson.json.ChannelData;
/*    */ import discord4j.discordjson.json.DMCreateRequest;
/*    */ import discord4j.discordjson.json.UserData;
/*    */ import discord4j.rest.RestClient;
/*    */ import java.util.Objects;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RestUser
/*    */ {
/*    */   private final RestClient restClient;
/*    */   private final long id;
/*    */   
/*    */   private RestUser(RestClient restClient, long id) {
/* 39 */     this.restClient = restClient;
/* 40 */     this.id = id;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static RestUser create(RestClient restClient, Snowflake id) {
/* 51 */     return new RestUser(restClient, id.asLong());
/*    */   }
/*    */   
/*    */   static RestUser create(RestClient restClient, long id) {
/* 55 */     return new RestUser(restClient, id);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Snowflake getId() {
/* 64 */     return Snowflake.of(this.id);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Mono<UserData> getData() {
/* 74 */     return this.restClient.getUserService().getUser(this.id);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final Mono<ChannelData> getPrivateChannel() {
/* 84 */     return this.restClient.getUserService().createDM((DMCreateRequest)DMCreateRequest.builder().recipientId(Snowflake.asString(this.id)).build());
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 89 */     if (this == o) return true; 
/* 90 */     if (o == null || getClass() != o.getClass()) return false; 
/* 91 */     RestUser restUser = (RestUser)o;
/* 92 */     return (this.id == restUser.id);
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 97 */     return Objects.hash(new Object[] { Long.valueOf(this.id) });
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\entity\RestUser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */