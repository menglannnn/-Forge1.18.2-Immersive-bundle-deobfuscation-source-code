/*     */ package discord4j.rest.entity;
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.discordjson.json.BanData;
/*     */ import discord4j.discordjson.json.ChannelCreateRequest;
/*     */ import discord4j.discordjson.json.ChannelData;
/*     */ import discord4j.discordjson.json.CurrentMemberModifyData;
/*     */ import discord4j.discordjson.json.EmojiData;
/*     */ import discord4j.discordjson.json.GuildEmojiCreateRequest;
/*     */ import discord4j.discordjson.json.GuildMemberAddRequest;
/*     */ import discord4j.discordjson.json.GuildMemberModifyRequest;
/*     */ import discord4j.discordjson.json.GuildModifyRequest;
/*     */ import discord4j.discordjson.json.GuildScheduledEventCreateRequest;
/*     */ import discord4j.discordjson.json.GuildScheduledEventData;
/*     */ import discord4j.discordjson.json.GuildScheduledEventModifyRequest;
/*     */ import discord4j.discordjson.json.GuildUpdateData;
/*     */ import discord4j.discordjson.json.GuildWidgetData;
/*     */ import discord4j.discordjson.json.GuildWidgetModifyRequest;
/*     */ import discord4j.discordjson.json.IntegrationCreateRequest;
/*     */ import discord4j.discordjson.json.IntegrationData;
/*     */ import discord4j.discordjson.json.IntegrationModifyRequest;
/*     */ import discord4j.discordjson.json.MemberData;
/*     */ import discord4j.discordjson.json.NicknameModifyData;
/*     */ import discord4j.discordjson.json.PositionModifyRequest;
/*     */ import discord4j.discordjson.json.PruneData;
/*     */ import discord4j.discordjson.json.RegionData;
/*     */ import discord4j.discordjson.json.RoleCreateRequest;
/*     */ import discord4j.discordjson.json.RoleData;
/*     */ import discord4j.discordjson.json.RoleModifyRequest;
/*     */ import discord4j.discordjson.json.WebhookData;
/*     */ import discord4j.rest.RestClient;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import java.util.function.Function;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ public class RestGuild {
/*     */   private RestGuild(RestClient restClient, long id) {
/*  42 */     this.restClient = restClient;
/*  43 */     this.id = id;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private final RestClient restClient;
/*     */   
/*     */   private final long id;
/*     */ 
/*     */   
/*     */   public static RestGuild create(RestClient restClient, Snowflake id) {
/*  54 */     return new RestGuild(restClient, id.asLong());
/*     */   }
/*     */   
/*     */   static RestGuild create(RestClient restClient, long id) {
/*  58 */     return new RestGuild(restClient, id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getId() {
/*  67 */     return Snowflake.of(this.id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<GuildUpdateData> getData(@Nullable Boolean withCounts) {
/*  79 */     Map<String, Object> queryParams = new HashMap<>();
/*  80 */     Optional.<Boolean>ofNullable(withCounts).ifPresent(value -> queryParams.put("with_counts", value));
/*  81 */     return this.restClient.getGuildService().getGuild(this.id, queryParams);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<GuildUpdateData> getData() {
/*  91 */     return getData(Boolean.valueOf(true));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestEmoji emoji(Snowflake emojiId) {
/* 101 */     return RestEmoji.create(this.restClient, this.id, emojiId.asLong());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestMember member(Snowflake memberId) {
/* 111 */     return RestMember.create(this.restClient, this.id, memberId.asLong());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestRole role(Snowflake roleId) {
/* 121 */     return RestRole.create(this.restClient, this.id, roleId.asLong());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestScheduledEvent scheduledEvent(Snowflake eventId) {
/* 132 */     return RestScheduledEvent.create(this.restClient, this.id, eventId.asLong());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<GuildUpdateData> modify(GuildModifyRequest request, @Nullable String reason) {
/* 145 */     return this.restClient.getGuildService().modifyGuild(this.id, request, reason);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> delete() {
/* 155 */     return this.restClient.getGuildService().deleteGuild(this.id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Flux<ChannelData> getChannels() {
/* 164 */     return this.restClient.getGuildService().getGuildChannels(this.id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<ChannelData> createChannel(ChannelCreateRequest request, @Nullable String reason) {
/* 177 */     return this.restClient.getGuildService().createGuildChannel(this.id, request, reason);
/*     */   }
/*     */   
/*     */   public Flux<RoleData> modifyChannelPositions(List<PositionModifyRequest> requests) {
/* 181 */     return this.restClient.getGuildService()
/* 182 */       .modifyGuildChannelPositions(this.id, requests.<PositionModifyRequest>toArray(new PositionModifyRequest[0]));
/*     */   }
/*     */   
/*     */   public Mono<MemberData> getMember(Snowflake userId) {
/* 186 */     return this.restClient.getGuildService().getGuildMember(this.id, userId.asLong());
/*     */   }
/*     */   
/*     */   public Mono<MemberData> getSelfMember() {
/* 190 */     return this.restClient.getSelf()
/* 191 */       .map(UserData::id)
/* 192 */       .map(Snowflake::of)
/* 193 */       .flatMap(this::getMember);
/*     */   }
/*     */   
/*     */   public Flux<MemberData> getMembers() {
/* 197 */     Function<Map<String, Object>, Flux<MemberData>> doRequest = params -> this.restClient.getGuildService().getGuildMembers(this.id, params);
/*     */     
/* 199 */     return PaginationUtil.paginateAfter(doRequest, data -> Snowflake.asLong(data.user().id()), 0L, 100);
/*     */   }
/*     */   
/*     */   public Flux<MemberData> searchMembers(Map<String, Object> queryParams) {
/* 203 */     return this.restClient.getGuildService().searchGuildMembers(this.id, queryParams);
/*     */   }
/*     */   
/*     */   public Mono<MemberData> addMember(Snowflake userId, GuildMemberAddRequest request) {
/* 207 */     return this.restClient.getGuildService().addGuildMember(this.id, userId.asLong(), request);
/*     */   }
/*     */   
/*     */   public Mono<MemberData> modifyMember(Snowflake userId, GuildMemberModifyRequest request, @Nullable String reason) {
/* 211 */     return this.restClient.getGuildService().modifyGuildMember(this.id, userId.asLong(), request, reason);
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public Mono<NicknameModifyData> modifyOwnNickname(NicknameModifyData request) {
/* 216 */     return this.restClient.getGuildService().modifyOwnNickname(this.id, request);
/*     */   }
/*     */   
/*     */   public Mono<MemberData> modifyCurrentMember(CurrentMemberModifyData request) {
/* 220 */     return this.restClient.getGuildService().modifyCurrentMember(this.id, request);
/*     */   }
/*     */   
/*     */   public Mono<Void> addMemberRole(Snowflake userId, Snowflake roleId, @Nullable String reason) {
/* 224 */     return this.restClient.getGuildService().addGuildMemberRole(this.id, userId.asLong(), roleId.asLong(), reason);
/*     */   }
/*     */   
/*     */   public Mono<Void> removeMemberRole(Snowflake userId, Snowflake roleId, @Nullable String reason) {
/* 228 */     return this.restClient.getGuildService().removeGuildMemberRole(this.id, userId.asLong(), roleId.asLong(), reason);
/*     */   }
/*     */   
/*     */   public Mono<Void> removeGuildMember(Snowflake userId, @Nullable String reason) {
/* 232 */     return this.restClient.getGuildService().removeGuildMember(this.id, userId.asLong(), reason);
/*     */   }
/*     */   
/*     */   public Flux<BanData> getBans() {
/* 236 */     return this.restClient.getGuildService().getGuildBans(this.id);
/*     */   }
/*     */   
/*     */   public Mono<BanData> getBan(Snowflake userId) {
/* 240 */     return this.restClient.getGuildService().getGuildBan(this.id, userId.asLong());
/*     */   }
/*     */   
/*     */   public Mono<Void> createBan(Snowflake userId, @Nullable Integer deleteMessageDays, @Nullable String reason) {
/* 244 */     Map<String, Object> queryParams = new HashMap<>();
/* 245 */     Optional.<Integer>ofNullable(deleteMessageDays).ifPresent(value -> queryParams.put("delete_message_days", value));
/* 246 */     Optional.<String>ofNullable(reason).ifPresent(value -> queryParams.put("reason", value));
/* 247 */     return this.restClient.getGuildService().createGuildBan(this.id, userId.asLong(), queryParams, reason);
/*     */   }
/*     */   
/*     */   public Mono<Void> removeGuildBan(Snowflake userId, @Nullable String reason) {
/* 251 */     return this.restClient.getGuildService().removeGuildBan(this.id, userId.asLong(), reason);
/*     */   }
/*     */   
/*     */   public Flux<RoleData> getRoles() {
/* 255 */     return this.restClient.getGuildService().getGuildRoles(this.id);
/*     */   }
/*     */   
/*     */   public Mono<RoleData> createRole(RoleCreateRequest request, @Nullable String reason) {
/* 259 */     return this.restClient.getGuildService().createGuildRole(this.id, request, reason);
/*     */   }
/*     */   
/*     */   public Flux<RoleData> modifyRolePositions(List<PositionModifyRequest> requests) {
/* 263 */     return this.restClient.getGuildService().modifyGuildRolePositions(this.id, requests
/* 264 */         .<PositionModifyRequest>toArray(new PositionModifyRequest[0]));
/*     */   }
/*     */   
/*     */   public Mono<RoleData> modifyRole(Snowflake roleId, RoleModifyRequest request, @Nullable String reason) {
/* 268 */     return this.restClient.getGuildService().modifyGuildRole(this.id, roleId.asLong(), request, reason);
/*     */   }
/*     */   
/*     */   public Mono<Void> deleteRole(Snowflake roleId, @Nullable String reason) {
/* 272 */     return this.restClient.getGuildService().deleteGuildRole(this.id, roleId.asLong(), reason);
/*     */   }
/*     */   
/*     */   public Mono<PruneData> getPruneCount(@Nullable Integer days) {
/* 276 */     Map<String, Object> queryParams = new HashMap<>();
/* 277 */     Optional.<Integer>ofNullable(days).ifPresent(value -> queryParams.put("days", value));
/* 278 */     return this.restClient.getGuildService().getGuildPruneCount(this.id, queryParams);
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<PruneData> beginGuildPrune(@Nullable Integer days, @Nullable Boolean computePruneCount, @Nullable String reason) {
/* 283 */     Map<String, Object> queryParams = new HashMap<>();
/* 284 */     Optional.<Integer>ofNullable(days).ifPresent(value -> queryParams.put("days", value));
/* 285 */     Optional.<Boolean>ofNullable(computePruneCount).ifPresent(value -> queryParams.put("compute_prune_count", value));
/* 286 */     return this.restClient.getGuildService().beginGuildPrune(this.id, queryParams, reason);
/*     */   }
/*     */   
/*     */   public Flux<RegionData> getRegions() {
/* 290 */     return this.restClient.getGuildService().getGuildVoiceRegions(this.id);
/*     */   }
/*     */   
/*     */   public Flux<InviteData> getInvites() {
/* 294 */     return this.restClient.getGuildService().getGuildInvites(this.id);
/*     */   }
/*     */   
/*     */   public Flux<IntegrationData> getIntegrations() {
/* 298 */     return this.restClient.getGuildService().getGuildIntegrations(this.id);
/*     */   }
/*     */   
/*     */   public Mono<Void> createIntegration(IntegrationCreateRequest request) {
/* 302 */     return this.restClient.getGuildService().createGuildIntegration(this.id, request);
/*     */   }
/*     */   
/*     */   public Mono<Void> modifyIntegration(Snowflake integrationId, IntegrationModifyRequest request) {
/* 306 */     return this.restClient.getGuildService().modifyGuildIntegration(this.id, integrationId.asLong(), request);
/*     */   }
/*     */   
/*     */   public Mono<Void> deleteIntegration(Snowflake integrationId) {
/* 310 */     return this.restClient.getGuildService().deleteGuildIntegration(this.id, integrationId.asLong());
/*     */   }
/*     */   
/*     */   public Mono<Void> syncIntegration(Snowflake integrationId) {
/* 314 */     return this.restClient.getGuildService().syncGuildIntegration(this.id, integrationId.asLong());
/*     */   }
/*     */   
/*     */   public Mono<GuildWidgetData> getWidget() {
/* 318 */     return this.restClient.getGuildService().getGuildWidget(this.id);
/*     */   }
/*     */   
/*     */   public Mono<GuildWidgetData> modifyWidget(GuildWidgetModifyRequest request) {
/* 322 */     return this.restClient.getGuildService().modifyGuildWidget(this.id, request);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Flux<EmojiData> getEmojis() {
/* 329 */     return this.restClient.getEmojiService().getGuildEmojis(this.id);
/*     */   }
/*     */   
/*     */   public Mono<EmojiData> createEmoji(GuildEmojiCreateRequest request, @Nullable String reason) {
/* 333 */     return this.restClient.getEmojiService().createGuildEmoji(this.id, request, reason);
/*     */   }
/*     */   
/*     */   public Flux<WebhookData> getWebhooks() {
/* 337 */     return this.restClient.getWebhookService().getGuildWebhooks(this.id);
/*     */   }
/*     */   
/*     */   public Mono<GuildPreviewData> getPreview() {
/* 341 */     return this.restClient.getGuildService().getGuildPreview(this.id);
/*     */   }
/*     */   
/*     */   public Flux<TemplateData> getTemplates() {
/* 345 */     return this.restClient.getTemplateService().getTemplates(this.id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<GuildScheduledEventData> getScheduledEvent(Snowflake eventId, @Nullable Boolean withUserCount) {
/* 357 */     Map<String, Object> queryParams = new HashMap<>();
/* 358 */     Optional.<Boolean>ofNullable(withUserCount).ifPresent(value -> queryParams.put("with_user_count", value));
/* 359 */     return this.restClient.getGuildService().getScheduledEvent(this.id, eventId.asLong(), queryParams);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Flux<GuildScheduledEventData> getScheduledEvents(@Nullable Boolean withUserCount) {
/* 370 */     Map<String, Object> queryParams = new HashMap<>();
/* 371 */     Optional.<Boolean>ofNullable(withUserCount).ifPresent(value -> queryParams.put("with_user_count", value));
/* 372 */     return this.restClient.getGuildService().getScheduledEvents(this.id, queryParams);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<GuildScheduledEventData> createScheduledEvent(GuildScheduledEventCreateRequest request) {
/* 384 */     return this.restClient.getGuildService().createScheduledEvent(this.id, request);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<GuildScheduledEventData> modifyScheduledEvent(Snowflake eventId, GuildScheduledEventModifyRequest request, @Nullable String reason) {
/* 400 */     return this.restClient.getGuildService().modifyScheduledEvent(this.id, eventId.asLong(), request, reason);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> deleteScheduledEvent(Snowflake eventId, @Nullable String reason) {
/* 412 */     return this.restClient.getGuildService().deleteScheduledEvent(this.id, eventId.asLong(), reason);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 419 */     if (this == o) return true; 
/* 420 */     if (o == null || getClass() != o.getClass()) return false; 
/* 421 */     RestGuild restGuild = (RestGuild)o;
/* 422 */     return (this.id == restGuild.id);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 427 */     return Objects.hash(new Object[] { Long.valueOf(this.id) });
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\entity\RestGuild.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */