/*     */ package discord4j.rest.entity;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.discordjson.json.BulkDeleteRequest;
/*     */ import discord4j.discordjson.json.ChannelData;
/*     */ import discord4j.discordjson.json.ChannelModifyRequest;
/*     */ import discord4j.discordjson.json.EmbedData;
/*     */ import discord4j.discordjson.json.FollowedChannelData;
/*     */ import discord4j.discordjson.json.GroupAddRecipientRequest;
/*     */ import discord4j.discordjson.json.InviteCreateRequest;
/*     */ import discord4j.discordjson.json.InviteData;
/*     */ import discord4j.discordjson.json.MessageCreateRequest;
/*     */ import discord4j.discordjson.json.MessageData;
/*     */ import discord4j.discordjson.json.NewsChannelFollowRequest;
/*     */ import discord4j.discordjson.json.PermissionsEditRequest;
/*     */ import discord4j.discordjson.json.WebhookData;
/*     */ import discord4j.rest.RestClient;
/*     */ import discord4j.rest.util.MultipartRequest;
/*     */ import discord4j.rest.util.PaginationUtil;
/*     */ import java.time.Duration;
/*     */ import java.time.Instant;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.function.Function;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RestChannel
/*     */ {
/*     */   private final RestClient restClient;
/*     */   private final long id;
/*     */   
/*     */   private RestChannel(RestClient restClient, long id) {
/*  45 */     this.restClient = restClient;
/*  46 */     this.id = id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RestChannel create(RestClient restClient, Snowflake id) {
/*  56 */     return new RestChannel(restClient, id.asLong());
/*     */   }
/*     */   
/*     */   static RestChannel create(RestClient restClient, long id) {
/*  60 */     return new RestChannel(restClient, id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getId() {
/*  69 */     return Snowflake.of(this.id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<ChannelData> getData() {
/*  80 */     return this.restClient.getChannelService().getChannel(this.id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestMessage message(Snowflake messageId) {
/*  90 */     return RestMessage.create(this.restClient, this.id, messageId.asLong());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<ChannelData> modify(ChannelModifyRequest request, @Nullable String reason) {
/* 103 */     return this.restClient.getChannelService().modifyChannel(this.id, request, reason);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> delete(@Nullable String reason) {
/* 115 */     return this.restClient.getChannelService().deleteChannel(this.id, reason).then();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Flux<MessageData> getMessagesBefore(Snowflake messageId) {
/* 135 */     Function<Map<String, Object>, Flux<MessageData>> doRequest = params -> this.restClient.getChannelService().getMessages(this.id, params);
/*     */     
/* 137 */     return PaginationUtil.paginateBefore(doRequest, data -> Snowflake.asLong(data.id()), messageId.asLong(), 100);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Flux<MessageData> getMessagesAfter(Snowflake messageId) {
/* 157 */     Function<Map<String, Object>, Flux<MessageData>> doRequest = params -> this.restClient.getChannelService().getMessages(this.id, params);
/*     */     
/* 159 */     return PaginationUtil.paginateAfter(doRequest, data -> Snowflake.asLong(data.id()), messageId.asLong(), 100);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestMessage getRestMessage(Snowflake messageId) {
/* 170 */     return RestMessage.create(this.restClient, this.id, messageId.asLong());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<MessageData> createMessage(MessageCreateRequest request) {
/* 183 */     return this.restClient.getChannelService().createMessage(this.id, MultipartRequest.ofRequest(request));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<MessageData> createMessage(MultipartRequest<MessageCreateRequest> request) {
/* 197 */     return this.restClient.getChannelService().createMessage(this.id, request);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<MessageData> createMessage(String content) {
/* 208 */     return createMessage((MessageCreateRequest)MessageCreateRequest.builder().content(content).build());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<MessageData> createMessage(EmbedData embed) {
/* 219 */     return createMessage((MessageCreateRequest)MessageCreateRequest.builder().embed(embed).build());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Flux<Snowflake> bulkDelete(Publisher<Snowflake> messageIds) {
/* 319 */     Instant timeLimit = Instant.now().minus(Duration.ofDays(14L));
/*     */     
/* 321 */     return Flux.from(messageIds)
/* 322 */       .distinct()
/* 323 */       .buffer(100)
/* 324 */       .flatMap(ids -> {
/*     */           List<String> eligibleIds = new ArrayList<>(0);
/*     */           Collection<Snowflake> ineligibleIds = new ArrayList<>(0);
/*     */           for (Snowflake id : ids) {
/*     */             if (id.getTimestamp().isBefore(timeLimit)) {
/*     */               ineligibleIds.add(id);
/*     */               continue;
/*     */             } 
/*     */             eligibleIds.add(id.asString());
/*     */           } 
/*     */           if (eligibleIds.size() == 1) {
/*     */             ineligibleIds.add(Snowflake.of(eligibleIds.get(0)));
/*     */             eligibleIds.clear();
/*     */           } 
/*     */           return (Publisher)Mono.just(eligibleIds).filter(()).flatMap(()).thenMany((Publisher)Flux.fromIterable(ineligibleIds));
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> editChannelPermissions(Snowflake targetId, PermissionsEditRequest request, @Nullable String reason) {
/* 363 */     return this.restClient.getChannelService().editChannelPermissions(this.id, targetId.asLong(), request, reason);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Flux<InviteData> getInvites() {
/* 374 */     return this.restClient.getChannelService().getChannelInvites(this.id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<InviteData> createInvite(InviteCreateRequest request, @Nullable String reason) {
/* 388 */     return this.restClient.getChannelService().createChannelInvite(this.id, request, reason);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> deleteChannelPermission(Snowflake targetId, @Nullable String reason) {
/* 401 */     return this.restClient.getChannelService().deleteChannelPermission(this.id, targetId.asLong(), reason);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<FollowedChannelData> follow(NewsChannelFollowRequest request) {
/* 413 */     return this.restClient.getChannelService().followNewsChannel(this.id, request);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> type() {
/* 426 */     return this.restClient.getChannelService().triggerTypingIndicator(this.id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Flux<MessageData> getPinnedMessages() {
/* 437 */     return this.restClient.getChannelService().getPinnedMessages(this.id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> addPinnedMessage(Snowflake messageId) {
/* 447 */     return this.restClient.getChannelService().addPinnedMessage(this.id, messageId.asLong());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> deletePinnedMessage(Snowflake messageId) {
/* 457 */     return this.restClient.getChannelService().deletePinnedMessage(this.id, messageId.asLong());
/*     */   }
/*     */   
/*     */   public Mono<Void> addGroupDMRecipient(Snowflake userId, GroupAddRecipientRequest request) {
/* 461 */     return this.restClient.getChannelService().addGroupDMRecipient(this.id, userId.asLong(), request);
/*     */   }
/*     */   
/*     */   public Mono<Void> deleteGroupDMRecipient(Snowflake userId) {
/* 465 */     return this.restClient.getChannelService().deleteGroupDMRecipient(this.id, userId.asLong());
/*     */   }
/*     */   
/*     */   public Flux<WebhookData> getWebhooks() {
/* 469 */     return this.restClient.getWebhookService().getChannelWebhooks(this.id);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 474 */     if (this == o) return true; 
/* 475 */     if (o == null || getClass() != o.getClass()) return false; 
/* 476 */     RestChannel that = (RestChannel)o;
/* 477 */     return (this.id == that.id);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 482 */     return Objects.hash(new Object[] { Long.valueOf(this.id) });
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\entity\RestChannel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */