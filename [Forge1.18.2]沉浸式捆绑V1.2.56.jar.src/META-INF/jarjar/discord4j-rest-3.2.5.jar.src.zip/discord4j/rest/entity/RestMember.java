/*     */ package discord4j.rest.entity;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.discordjson.Id;
/*     */ import discord4j.discordjson.json.GuildUpdateFields;
/*     */ import discord4j.discordjson.json.MemberData;
/*     */ import discord4j.discordjson.json.PartialMemberData;
/*     */ import discord4j.discordjson.json.RoleData;
/*     */ import discord4j.rest.RestClient;
/*     */ import discord4j.rest.util.OrderUtil;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.math.MathFlux;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RestMember
/*     */ {
/*     */   private final RestClient restClient;
/*     */   private final long guildId;
/*     */   private final long id;
/*     */   
/*     */   private RestMember(RestClient restClient, long guildId, long id) {
/*  44 */     this.restClient = restClient;
/*  45 */     this.guildId = guildId;
/*  46 */     this.id = id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RestMember create(RestClient restClient, Snowflake guildId, Snowflake id) {
/*  58 */     return new RestMember(restClient, guildId.asLong(), id.asLong());
/*     */   }
/*     */   
/*     */   static RestMember create(RestClient restClient, long guildId, long id) {
/*  62 */     return new RestMember(restClient, guildId, id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getGuildId() {
/*  71 */     return Snowflake.of(this.guildId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getId() {
/*  80 */     return Snowflake.of(this.id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestGuild guild() {
/*  89 */     return RestGuild.create(this.restClient, this.guildId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestUser user() {
/*  98 */     return RestUser.create(this.restClient, this.id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<MemberData> getData() {
/* 108 */     return this.restClient.getGuildService()
/* 109 */       .getGuildMember(this.guildId, this.id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<RoleData> getHighestRole() {
/* 122 */     return getData().map(PartialMemberData::roles)
/* 123 */       .flatMap(roles -> MathFlux.max((Publisher)Flux.fromIterable(roles).map(()).flatMap(RestRole::getData), OrderUtil.ROLE_ORDER));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Boolean> isHigher(RestMember otherMember) {
/* 139 */     if (this.guildId != otherMember.guildId) {
/* 140 */       return Mono.error(new IllegalArgumentException("The provided member is in a different guild."));
/*     */     }
/*     */ 
/*     */     
/* 144 */     if (equals(otherMember)) {
/* 145 */       return Mono.just(Boolean.valueOf(false));
/*     */     }
/*     */     
/* 148 */     return guild().getData().map(GuildUpdateFields::ownerId)
/* 149 */       .flatMap(ownerId -> (ownerId.asLong() == this.id) ? Mono.just(Boolean.valueOf(true)) : ((ownerId.asLong() == otherMember.id) ? Mono.just(Boolean.valueOf(false)) : otherMember.getData().flatMapMany(()).map(Snowflake::of).collectList().flatMap(this::hasHigherRoles)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Boolean> isHigher(Snowflake id) {
/* 179 */     return Mono.just(this.restClient.getMemberById(Snowflake.of(this.guildId), id)).flatMap(this::isHigher);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Boolean> hasHigherRoles(Collection<Snowflake> otherRoles) {
/* 194 */     return guild().getRoles()
/* 195 */       .transform(OrderUtil::orderRoles)
/* 196 */       .collectList()
/* 197 */       .flatMap(guildRoles -> {
/*     */           Mono<List<Snowflake>> thisRoleIds = getData().map(PartialMemberData::roles).flatMapMany(Flux::fromIterable).map(Snowflake::of).collectList().cache();
/*     */           Mono<Integer> thisHighestRolePos = thisRoleIds.map(());
/*     */           Objects.requireNonNull(guildRoles);
/*     */           int otherHighestPos = ((Integer)guildRoles.stream().filter(()).max(OrderUtil.ROLE_ORDER).map(guildRoles::indexOf).orElse(Integer.valueOf(0))).intValue();
/*     */           return thisHighestRolePos.map(());
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 228 */     if (this == o) return true; 
/* 229 */     if (o == null || getClass() != o.getClass()) return false; 
/* 230 */     RestMember that = (RestMember)o;
/* 231 */     return (this.guildId == that.guildId && this.id == that.id);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 236 */     return Objects.hash(new Object[] { Long.valueOf(this.guildId), Long.valueOf(this.id) });
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\entity\RestMember.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */