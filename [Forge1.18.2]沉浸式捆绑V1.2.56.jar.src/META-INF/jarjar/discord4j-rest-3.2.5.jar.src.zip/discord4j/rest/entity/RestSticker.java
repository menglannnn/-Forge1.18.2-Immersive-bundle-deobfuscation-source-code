/*     */ package discord4j.rest.entity;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.discordjson.json.GuildStickerModifyRequest;
/*     */ import discord4j.discordjson.json.StickerData;
/*     */ import discord4j.rest.RestClient;
/*     */ import java.util.Objects;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RestSticker
/*     */ {
/*     */   private final RestClient restClient;
/*     */   private final long guildId;
/*     */   private final long id;
/*     */   
/*     */   private RestSticker(RestClient restClient, long guildId, long id) {
/*  22 */     this.restClient = restClient;
/*  23 */     this.guildId = guildId;
/*  24 */     this.id = id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RestSticker create(RestClient restClient, Snowflake guildId, Snowflake id) {
/*  36 */     return new RestSticker(restClient, guildId.asLong(), id.asLong());
/*     */   }
/*     */   
/*     */   static RestSticker create(RestClient restClient, long guildId, long id) {
/*  40 */     return new RestSticker(restClient, guildId, id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getGuildId() {
/*  49 */     return Snowflake.of(this.guildId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getId() {
/*  58 */     return Snowflake.of(this.id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestGuild guild() {
/*  67 */     return RestGuild.create(this.restClient, this.guildId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<StickerData> getData() {
/*  77 */     return this.restClient.getStickerService().getGuildSticker(this.guildId, this.id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<StickerData> modify(GuildStickerModifyRequest request, @Nullable String reason) {
/*  90 */     return this.restClient.getStickerService().modifyGuildSticker(this.guildId, this.id, request, reason);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> delete(@Nullable String reason) {
/* 101 */     return this.restClient.getStickerService().deleteGuildSticker(this.guildId, this.id, reason);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 106 */     if (this == o) return true; 
/* 107 */     if (o == null || getClass() != o.getClass()) return false; 
/* 108 */     RestSticker restSticker = (RestSticker)o;
/* 109 */     return (this.guildId == restSticker.guildId && this.id == restSticker.id);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 114 */     return Objects.hash(new Object[] { Long.valueOf(this.guildId), Long.valueOf(this.id) });
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\entity\RestSticker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */