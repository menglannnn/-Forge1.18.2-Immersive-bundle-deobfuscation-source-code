/*     */ package discord4j.rest.entity;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.discordjson.json.InviteData;
/*     */ import discord4j.rest.RestClient;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RestInvite
/*     */ {
/*     */   private final RestClient restClient;
/*     */   private final String code;
/*     */   
/*     */   private RestInvite(RestClient restClient, String code) {
/*  39 */     this.restClient = restClient;
/*  40 */     this.code = code;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RestInvite create(RestClient restClient, String code) {
/*  51 */     return new RestInvite(restClient, code);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCode() {
/*  60 */     return this.code;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<InviteData> getData() {
/*  69 */     return this.restClient.getInviteService().getInvite(this.code);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<InviteData> getData(boolean withCounts, boolean withExpiration, @Nullable Snowflake guildScheduledEventId) {
/*  82 */     Map<String, Object> queryParams = new HashMap<>();
/*  83 */     queryParams.put("with_counts", Boolean.valueOf(withCounts));
/*  84 */     queryParams.put("with_expiration", Boolean.valueOf(withExpiration));
/*  85 */     if (guildScheduledEventId != null) {
/*  86 */       queryParams.put("guild_scheduled_event_id", guildScheduledEventId.asString());
/*     */     }
/*  88 */     return this.restClient.getInviteService().getInvite(this.code, queryParams);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<InviteData> delete(@Nullable String reason) {
/*  98 */     return this.restClient.getInviteService().deleteInvite(this.code, reason);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 103 */     if (this == o) return true; 
/* 104 */     if (o == null || getClass() != o.getClass()) return false; 
/* 105 */     RestInvite that = (RestInvite)o;
/* 106 */     return this.code.equals(that.code);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 111 */     return Objects.hash(new Object[] { this.code });
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\entity\RestInvite.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */