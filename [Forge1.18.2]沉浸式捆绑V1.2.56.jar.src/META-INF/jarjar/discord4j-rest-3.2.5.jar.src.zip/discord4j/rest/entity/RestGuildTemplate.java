/*    */ package discord4j.rest.entity;
/*    */ 
/*    */ import discord4j.discordjson.json.GuildData;
/*    */ import discord4j.discordjson.json.TemplateCreateGuildRequest;
/*    */ import discord4j.discordjson.json.TemplateData;
/*    */ import discord4j.rest.RestClient;
/*    */ import java.util.Objects;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RestGuildTemplate
/*    */ {
/*    */   private final RestClient restClient;
/*    */   private final String code;
/*    */   
/*    */   private RestGuildTemplate(RestClient restClient, String code) {
/* 34 */     this.restClient = restClient;
/* 35 */     this.code = code;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static RestGuildTemplate create(RestClient restClient, String code) {
/* 46 */     return new RestGuildTemplate(restClient, code);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getCode() {
/* 55 */     return this.code;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Mono<TemplateData> getData() {
/* 64 */     return this.restClient.getTemplateService().getTemplate(this.code);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Mono<GuildData> createGuild(TemplateCreateGuildRequest request) {
/* 75 */     return this.restClient.getTemplateService().createGuild(this.code, request);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 80 */     if (this == o) return true; 
/* 81 */     if (o == null || getClass() != o.getClass()) return false; 
/* 82 */     RestGuildTemplate that = (RestGuildTemplate)o;
/* 83 */     return Objects.equals(this.code, that.code);
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 88 */     return Objects.hash(new Object[] { this.code });
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\entity\RestGuildTemplate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */