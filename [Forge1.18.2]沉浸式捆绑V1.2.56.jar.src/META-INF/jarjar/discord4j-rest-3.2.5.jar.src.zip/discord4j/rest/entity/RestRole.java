/*     */ package discord4j.rest.entity;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.discordjson.json.PositionModifyRequest;
/*     */ import discord4j.discordjson.json.RoleData;
/*     */ import discord4j.discordjson.json.RoleModifyRequest;
/*     */ import discord4j.rest.RestClient;
/*     */ import java.util.Objects;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RestRole
/*     */ {
/*     */   private final RestClient restClient;
/*     */   private final long guildId;
/*     */   private final long id;
/*     */   
/*     */   private RestRole(RestClient restClient, long guildId, long id) {
/*  41 */     this.restClient = restClient;
/*  42 */     this.guildId = guildId;
/*  43 */     this.id = id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RestRole create(RestClient restClient, Snowflake guildId, Snowflake id) {
/*  54 */     return new RestRole(restClient, guildId.asLong(), id.asLong());
/*     */   }
/*     */   
/*     */   static RestRole create(RestClient restClient, long guildId, long id) {
/*  58 */     return new RestRole(restClient, guildId, id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getGuildId() {
/*  67 */     return Snowflake.of(this.guildId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getId() {
/*  76 */     return Snowflake.of(this.id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestGuild guild() {
/*  85 */     return RestGuild.create(this.restClient, this.guildId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<RoleData> edit(RoleModifyRequest request, @Nullable String reason) {
/*  97 */     return this.restClient.getGuildService().modifyGuildRole(this.guildId, this.id, request, reason);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> delete(@Nullable String reason) {
/* 108 */     return this.restClient.getGuildService().deleteGuildRole(this.guildId, this.id, reason);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Flux<RoleData> changePosition(int position) {
/* 122 */     PositionModifyRequest[] requests = { (PositionModifyRequest)PositionModifyRequest.builder().id(Snowflake.asString(this.id)).position(position).build() };
/* 123 */     return this.restClient.getGuildService().modifyGuildRolePositions(this.guildId, requests);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<RoleData> getData() {
/* 133 */     return this.restClient.getGuildService()
/* 134 */       .getGuildRoles(this.guildId)
/* 135 */       .filter(response -> (Snowflake.asLong(response.id()) == this.id))
/* 136 */       .singleOrEmpty();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 141 */     if (this == o) return true; 
/* 142 */     if (o == null || getClass() != o.getClass()) return false; 
/* 143 */     RestRole restRole = (RestRole)o;
/* 144 */     return (this.guildId == restRole.guildId && this.id == restRole.id);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 149 */     return Objects.hash(new Object[] { Long.valueOf(this.guildId), Long.valueOf(this.id) });
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\entity\RestRole.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */