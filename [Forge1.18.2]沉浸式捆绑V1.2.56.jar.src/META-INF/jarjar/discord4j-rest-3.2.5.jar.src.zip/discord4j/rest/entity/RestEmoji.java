/*     */ package discord4j.rest.entity;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.discordjson.json.EmojiData;
/*     */ import discord4j.discordjson.json.GuildEmojiModifyRequest;
/*     */ import discord4j.rest.RestClient;
/*     */ import java.util.Objects;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RestEmoji
/*     */ {
/*     */   private final RestClient restClient;
/*     */   private final long guildId;
/*     */   private final long id;
/*     */   
/*     */   private RestEmoji(RestClient restClient, long guildId, long id) {
/*  40 */     this.restClient = restClient;
/*  41 */     this.guildId = guildId;
/*  42 */     this.id = id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RestEmoji create(RestClient restClient, Snowflake guildId, Snowflake id) {
/*  54 */     return new RestEmoji(restClient, guildId.asLong(), id.asLong());
/*     */   }
/*     */   
/*     */   static RestEmoji create(RestClient restClient, long guildId, long id) {
/*  58 */     return new RestEmoji(restClient, guildId, id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getGuildId() {
/*  67 */     return Snowflake.of(this.guildId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getId() {
/*  76 */     return Snowflake.of(this.id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestGuild guild() {
/*  85 */     return RestGuild.create(this.restClient, this.guildId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<EmojiData> getData() {
/*  95 */     return this.restClient.getEmojiService().getGuildEmoji(this.guildId, this.id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<EmojiData> modify(GuildEmojiModifyRequest request, @Nullable String reason) {
/* 108 */     return this.restClient.getEmojiService().modifyGuildEmoji(this.guildId, this.id, request, reason);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> delete(@Nullable String reason) {
/* 119 */     return this.restClient.getEmojiService().deleteGuildEmoji(this.guildId, this.id, reason);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 124 */     if (this == o) return true; 
/* 125 */     if (o == null || getClass() != o.getClass()) return false; 
/* 126 */     RestEmoji restEmoji = (RestEmoji)o;
/* 127 */     return (this.guildId == restEmoji.guildId && this.id == restEmoji.id);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 132 */     return Objects.hash(new Object[] { Long.valueOf(this.guildId), Long.valueOf(this.id) });
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\entity\RestEmoji.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */