/*     */ package discord4j.rest.entity;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.discordjson.json.GuildScheduledEventData;
/*     */ import discord4j.discordjson.json.GuildScheduledEventModifyRequest;
/*     */ import discord4j.discordjson.json.GuildScheduledEventUserData;
/*     */ import discord4j.rest.RestClient;
/*     */ import discord4j.rest.util.PaginationUtil;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import java.util.function.Function;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RestScheduledEvent
/*     */ {
/*     */   private final RestClient restClient;
/*     */   private final long guildId;
/*     */   private final long id;
/*     */   
/*     */   private RestScheduledEvent(RestClient restClient, long guildId, long id) {
/*  48 */     this.restClient = restClient;
/*  49 */     this.guildId = guildId;
/*  50 */     this.id = id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RestScheduledEvent create(RestClient restClient, Snowflake guildId, Snowflake id) {
/*  62 */     return new RestScheduledEvent(restClient, guildId.asLong(), id.asLong());
/*     */   }
/*     */   
/*     */   static RestScheduledEvent create(RestClient restClient, long guildId, long id) {
/*  66 */     return new RestScheduledEvent(restClient, guildId, id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getGuildId() {
/*  75 */     return Snowflake.of(this.guildId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getId() {
/*  84 */     return Snowflake.of(this.id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestGuild guild() {
/*  93 */     return RestGuild.create(this.restClient, this.guildId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<GuildScheduledEventData> edit(GuildScheduledEventModifyRequest request, @Nullable String reason) {
/* 105 */     return this.restClient.getGuildService().modifyScheduledEvent(this.guildId, this.id, request, reason);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> delete(@Nullable String reason) {
/* 116 */     return this.restClient.getGuildService().deleteScheduledEvent(this.guildId, this.id, reason);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Flux<GuildScheduledEventUserData> getSubscribedUsersBefore(Snowflake userId, @Nullable Boolean withMember) {
/* 138 */     Function<Map<String, Object>, Flux<GuildScheduledEventUserData>> doRequest = params -> {
/*     */         Optional.<Boolean>ofNullable(withMember).ifPresent(());
/*     */         return this.restClient.getGuildService().getScheduledEventUsers(this.guildId, this.id, params);
/*     */       };
/* 142 */     return PaginationUtil.paginateBefore(doRequest, data -> Snowflake.asLong(data.user().id()), userId.asLong(), 100);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Flux<GuildScheduledEventUserData> getSubscribedUsersAfter(Snowflake userId, @Nullable Boolean withMember) {
/* 164 */     Function<Map<String, Object>, Flux<GuildScheduledEventUserData>> doRequest = params -> {
/*     */         Optional.<Boolean>ofNullable(withMember).ifPresent(());
/*     */         return this.restClient.getGuildService().getScheduledEventUsers(this.guildId, this.id, params);
/*     */       };
/* 168 */     return PaginationUtil.paginateAfter(doRequest, data -> Snowflake.asLong(data.user().id()), userId.asLong(), 100);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<GuildScheduledEventData> getData(@Nullable Boolean withUserCount) {
/* 179 */     Map<String, Object> queryParams = new HashMap<>();
/* 180 */     Optional.<Boolean>ofNullable(withUserCount).ifPresent(value -> queryParams.put("with_user_count", value));
/* 181 */     return this.restClient.getGuildService().getScheduledEvent(this.guildId, this.id, queryParams);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\entity\RestScheduledEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */