/*     */ package discord4j.rest.entity;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.discordjson.json.MessageData;
/*     */ import discord4j.discordjson.json.MessageEditRequest;
/*     */ import discord4j.rest.RestClient;
/*     */ import discord4j.rest.util.MultipartRequest;
/*     */ import java.util.Objects;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RestMessage
/*     */ {
/*     */   private final RestClient restClient;
/*     */   private final long channelId;
/*     */   private final long id;
/*     */   
/*     */   private RestMessage(RestClient restClient, long channelId, long id) {
/*  40 */     this.restClient = restClient;
/*  41 */     this.channelId = channelId;
/*  42 */     this.id = id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RestMessage create(RestClient restClient, Snowflake channelId, Snowflake id) {
/*  54 */     return new RestMessage(restClient, channelId.asLong(), id.asLong());
/*     */   }
/*     */   
/*     */   static RestMessage create(RestClient restClient, long channelId, long id) {
/*  58 */     return new RestMessage(restClient, channelId, id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getChannelId() {
/*  67 */     return Snowflake.of(this.channelId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getId() {
/*  76 */     return Snowflake.of(this.id);
/*     */   }
/*     */   
/*     */   public RestChannel channel() {
/*  80 */     return RestChannel.create(this.restClient, this.channelId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<MessageData> getData() {
/*  91 */     return this.restClient.getChannelService().getMessage(this.channelId, this.id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> createReaction(String emoji) {
/* 104 */     return this.restClient.getChannelService().createReaction(this.channelId, this.id, emoji);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> deleteOwnReaction(String emoji) {
/* 116 */     return this.restClient.getChannelService().deleteOwnReaction(this.channelId, this.id, emoji);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> deleteUserReaction(String emoji, Snowflake userId) {
/* 130 */     return this.restClient.getChannelService().deleteReaction(this.channelId, this.id, emoji, userId.asLong());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> deleteAllReactions() {
/* 142 */     return this.restClient.getChannelService().deleteAllReactions(this.channelId, this.id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> deleteReactions(String emoji) {
/* 155 */     return this.restClient.getChannelService().deleteReactions(this.channelId, this.id, emoji);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<MessageData> edit(MessageEditRequest request) {
/* 167 */     return this.restClient.getChannelService().editMessage(this.channelId, this.id, MultipartRequest.ofRequest(request));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> delete(@Nullable String reason) {
/* 179 */     return this.restClient.getChannelService().deleteMessage(this.channelId, this.id, reason);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<MessageData> publish() {
/* 191 */     return this.restClient.getChannelService().publishMessage(this.channelId, this.id);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 196 */     if (this == o) return true; 
/* 197 */     if (o == null || getClass() != o.getClass()) return false; 
/* 198 */     RestMessage that = (RestMessage)o;
/* 199 */     return (this.channelId == that.channelId && this.id == that.id);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 204 */     return Objects.hash(new Object[] { Long.valueOf(this.channelId), Long.valueOf(this.id) });
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\entity\RestMessage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */