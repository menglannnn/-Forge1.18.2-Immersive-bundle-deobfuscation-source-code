/*     */ package discord4j.rest;
/*     */ 
/*     */ import discord4j.common.JacksonResources;
/*     */ import discord4j.common.ReactorResources;
/*     */ import discord4j.rest.http.ExchangeStrategies;
/*     */ import discord4j.rest.http.client.AuthorizationScheme;
/*     */ import discord4j.rest.request.BucketGlobalRateLimiter;
/*     */ import discord4j.rest.request.GlobalRateLimiter;
/*     */ import discord4j.rest.request.RequestQueueFactory;
/*     */ import discord4j.rest.request.Router;
/*     */ import discord4j.rest.request.RouterOptions;
/*     */ import discord4j.rest.response.ResponseFunction;
/*     */ import discord4j.rest.util.AllowedMentions;
/*     */ import java.time.Duration;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.function.Function;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RestClientBuilder<C, O extends RouterOptions>
/*     */ {
/*     */   protected final Function<Config, C> clientFactory;
/*     */   protected final Function<RouterOptions, O> optionsModifier;
/*     */   protected String token;
/*     */   protected ReactorResources reactorResources;
/*     */   protected JacksonResources jacksonResources;
/*     */   protected ExchangeStrategies exchangeStrategies;
/*  49 */   protected List<ResponseFunction> responseTransformers = new ArrayList<>();
/*     */ 
/*     */   
/*     */   protected GlobalRateLimiter globalRateLimiter;
/*     */   
/*     */   protected RequestQueueFactory requestQueueFactory;
/*     */   
/*     */   @Nullable
/*     */   protected AllowedMentions allowedMentions;
/*     */ 
/*     */   
/*     */   public static RestClientBuilder<RestClient, RouterOptions> createRest(String token) {
/*  61 */     Function<Config, RestClient> clientFactory = config -> {
/*     */         RestResources restResources = new RestResources(config.getToken(), config.getReactorResources(), config.getJacksonResources(), config.getRouter(), config.getAllowedMentions().orElse(null));
/*     */         
/*     */         return new RestClient(restResources);
/*     */       };
/*  66 */     return new RestClientBuilder<>(token, clientFactory, Function.identity());
/*     */   }
/*     */   
/*     */   public static RestClientBuilder<RestClient, RouterOptions> createRestApplication() {
/*  70 */     Function<Config, RestClient> clientFactory = config -> {
/*     */         RestResources restResources = new RestResources(AuthorizationScheme.NONE, "", config.getReactorResources(), config.getJacksonResources(), config.getRouter(), config.getAllowedMentions().orElse(null));
/*     */         
/*     */         return new RestClient(restResources);
/*     */       };
/*     */     
/*  76 */     return new RestClientBuilder<>("", clientFactory, Function.identity());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected RestClientBuilder(String token, Function<Config, C> clientFactory, Function<RouterOptions, O> optionsModifier) {
/*  82 */     this.token = Objects.<String>requireNonNull(token, "token");
/*  83 */     this.clientFactory = Objects.<Function<Config, C>>requireNonNull(clientFactory, "clientFactory");
/*  84 */     this.optionsModifier = Objects.<Function<RouterOptions, O>>requireNonNull(optionsModifier, "optionsModifier");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected RestClientBuilder(RestClientBuilder<?, ?> source, Function<Config, C> clientFactory, Function<RouterOptions, O> optionsModifier) {
/*  90 */     this.clientFactory = clientFactory;
/*  91 */     this.optionsModifier = optionsModifier;
/*     */     
/*  93 */     this.token = source.token;
/*  94 */     this.reactorResources = source.reactorResources;
/*  95 */     this.jacksonResources = source.jacksonResources;
/*  96 */     this.exchangeStrategies = source.exchangeStrategies;
/*  97 */     this.responseTransformers = source.responseTransformers;
/*  98 */     this.globalRateLimiter = source.globalRateLimiter;
/*  99 */     this.requestQueueFactory = source.requestQueueFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <O2 extends RouterOptions> RestClientBuilder<C, O2> setExtraOptions(Function<? super O, O2> optionsModifier) {
/* 112 */     return new RestClientBuilder(this, this.clientFactory, this.optionsModifier.andThen(optionsModifier));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestClientBuilder<C, O> setToken(String token) {
/* 122 */     this.token = Objects.<String>requireNonNull(token, "token");
/* 123 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestClientBuilder<C, O> setReactorResources(ReactorResources reactorResources) {
/* 134 */     this.reactorResources = reactorResources;
/* 135 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestClientBuilder<C, O> setJacksonResources(JacksonResources jacksonResources) {
/* 146 */     this.jacksonResources = jacksonResources;
/* 147 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestClientBuilder<C, O> setExchangeStrategies(ExchangeStrategies exchangeStrategies) {
/* 159 */     this.exchangeStrategies = Objects.<ExchangeStrategies>requireNonNull(exchangeStrategies, "exchangeStrategies");
/* 160 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestClientBuilder<C, O> onClientResponse(ResponseFunction responseFunction) {
/* 187 */     this.responseTransformers.add(responseFunction);
/* 188 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestClientBuilder<C, O> setGlobalRateLimiter(GlobalRateLimiter globalRateLimiter) {
/* 202 */     this.globalRateLimiter = globalRateLimiter;
/* 203 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestClientBuilder<C, O> setRequestQueueFactory(RequestQueueFactory requestQueueFactory) {
/* 219 */     this.requestQueueFactory = requestQueueFactory;
/* 220 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestClientBuilder<C, O> setDefaultAllowedMentions(AllowedMentions allowedMentions) {
/* 231 */     this.allowedMentions = allowedMentions;
/* 232 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public C build() {
/* 242 */     return build(discord4j.rest.request.DefaultRouter::new);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public C build(Function<O, Router> routerFactory) {
/* 253 */     ReactorResources reactor = initReactorResources();
/* 254 */     JacksonResources jackson = initJacksonResources();
/* 255 */     O options = buildOptions(reactor, jackson);
/* 256 */     Router router = routerFactory.apply(options);
/*     */     
/* 258 */     Config config = new Config(this.token, reactor, jackson, initExchangeStrategies(jackson), Collections.unmodifiableList(this.responseTransformers), this.globalRateLimiter, router, this.allowedMentions);
/* 259 */     return this.clientFactory.apply(config);
/*     */   }
/*     */ 
/*     */   
/*     */   private O buildOptions(ReactorResources reactor, JacksonResources jackson) {
/* 264 */     RouterOptions options = new RouterOptions(this.token, reactor, initExchangeStrategies(jackson), this.responseTransformers, initGlobalRateLimiter(reactor), initRequestQueueFactory(), "https://discord.com/api/v8");
/* 265 */     return this.optionsModifier.apply(options);
/*     */   }
/*     */   
/*     */   private ReactorResources initReactorResources() {
/* 269 */     if (this.reactorResources != null) {
/* 270 */       return this.reactorResources;
/*     */     }
/* 272 */     return new ReactorResources();
/*     */   }
/*     */   
/*     */   private JacksonResources initJacksonResources() {
/* 276 */     if (this.jacksonResources != null) {
/* 277 */       return this.jacksonResources;
/*     */     }
/* 279 */     return JacksonResources.create();
/*     */   }
/*     */   
/*     */   private ExchangeStrategies initExchangeStrategies(JacksonResources jacksonResources) {
/* 283 */     if (this.exchangeStrategies != null) {
/* 284 */       return this.exchangeStrategies;
/*     */     }
/* 286 */     return ExchangeStrategies.jackson(jacksonResources.getObjectMapper());
/*     */   }
/*     */   
/*     */   private GlobalRateLimiter initGlobalRateLimiter(ReactorResources reactorResources) {
/* 290 */     if (this.globalRateLimiter != null) {
/* 291 */       return this.globalRateLimiter;
/*     */     }
/* 293 */     return (GlobalRateLimiter)BucketGlobalRateLimiter.create(50, Duration.ofSeconds(1L), reactorResources.getTimerTaskScheduler());
/*     */   }
/*     */   
/*     */   private RequestQueueFactory initRequestQueueFactory() {
/* 297 */     if (this.requestQueueFactory != null) {
/* 298 */       return this.requestQueueFactory;
/*     */     }
/* 300 */     return RequestQueueFactory.buffering();
/*     */   }
/*     */ 
/*     */   
/*     */   protected static class Config
/*     */   {
/*     */     private final String token;
/*     */     
/*     */     private final ReactorResources reactorResources;
/*     */     private final JacksonResources jacksonResources;
/*     */     private final ExchangeStrategies exchangeStrategies;
/*     */     private final List<ResponseFunction> responseTransformers;
/*     */     private final GlobalRateLimiter globalRateLimiter;
/*     */     private final Router router;
/*     */     private final AllowedMentions allowedMentions;
/*     */     
/*     */     public Config(String token, ReactorResources reactorResources, JacksonResources jacksonResources, ExchangeStrategies exchangeStrategies, List<ResponseFunction> responseTransformers, GlobalRateLimiter globalRateLimiter, Router router, @Nullable AllowedMentions allowedMentions) {
/* 317 */       this.token = token;
/* 318 */       this.reactorResources = reactorResources;
/* 319 */       this.jacksonResources = jacksonResources;
/* 320 */       this.exchangeStrategies = exchangeStrategies;
/* 321 */       this.responseTransformers = responseTransformers;
/* 322 */       this.globalRateLimiter = globalRateLimiter;
/* 323 */       this.router = router;
/* 324 */       this.allowedMentions = allowedMentions;
/*     */     }
/*     */     
/*     */     public String getToken() {
/* 328 */       return this.token;
/*     */     }
/*     */     
/*     */     public ReactorResources getReactorResources() {
/* 332 */       return this.reactorResources;
/*     */     }
/*     */     
/*     */     public JacksonResources getJacksonResources() {
/* 336 */       return this.jacksonResources;
/*     */     }
/*     */     
/*     */     public ExchangeStrategies getExchangeStrategies() {
/* 340 */       return this.exchangeStrategies;
/*     */     }
/*     */     
/*     */     public List<ResponseFunction> getResponseTransformers() {
/* 344 */       return this.responseTransformers;
/*     */     }
/*     */     
/*     */     public GlobalRateLimiter getGlobalRateLimiter() {
/* 348 */       return this.globalRateLimiter;
/*     */     }
/*     */     
/*     */     public Router getRouter() {
/* 352 */       return this.router;
/*     */     }
/*     */     
/*     */     public Optional<AllowedMentions> getAllowedMentions() {
/* 356 */       return Optional.ofNullable(this.allowedMentions);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\RestClientBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */