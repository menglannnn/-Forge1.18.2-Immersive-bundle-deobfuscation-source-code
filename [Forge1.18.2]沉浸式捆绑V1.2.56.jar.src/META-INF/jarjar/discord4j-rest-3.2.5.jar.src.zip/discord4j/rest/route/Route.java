/*     */ package discord4j.rest.route;
/*     */ 
/*     */ import discord4j.rest.request.DiscordWebRequest;
/*     */ import io.netty.handler.codec.http.HttpMethod;
/*     */ import java.util.Objects;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Route
/*     */ {
/*     */   private final HttpMethod method;
/*     */   private final String uriTemplate;
/*     */   
/*     */   private Route(HttpMethod method, String uriTemplate) {
/*  34 */     this.method = method;
/*  35 */     this.uriTemplate = uriTemplate;
/*     */   }
/*     */   
/*     */   public static Route get(String uri) {
/*  39 */     return new Route(HttpMethod.GET, uri);
/*     */   }
/*     */   
/*     */   public static Route post(String uri) {
/*  43 */     return new Route(HttpMethod.POST, uri);
/*     */   }
/*     */   
/*     */   public static Route put(String uri) {
/*  47 */     return new Route(HttpMethod.PUT, uri);
/*     */   }
/*     */   
/*     */   public static Route patch(String uri) {
/*  51 */     return new Route(HttpMethod.PATCH, uri);
/*     */   }
/*     */   
/*     */   public static Route delete(String uri) {
/*  55 */     return new Route(HttpMethod.DELETE, uri);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpMethod getMethod() {
/*  64 */     return this.method;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DiscordWebRequest newRequest(Object... uriVars) {
/*  75 */     return new DiscordWebRequest(this, uriVars);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getUriTemplate() {
/*  84 */     return this.uriTemplate;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  89 */     return Objects.hash(new Object[] { this.method, this.uriTemplate });
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object obj) {
/*  94 */     if (obj == null) {
/*  95 */       return false;
/*     */     }
/*     */     
/*  98 */     if (!obj.getClass().isAssignableFrom(Route.class)) {
/*  99 */       return false;
/*     */     }
/*     */     
/* 102 */     Route other = (Route)obj;
/*     */     
/* 104 */     return (other.method.equals(this.method) && other.uriTemplate.equals(this.uriTemplate));
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 109 */     return "Route{method=" + this.method + ", uriTemplate='" + this.uriTemplate + '\'' + '}';
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\route\Route.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */