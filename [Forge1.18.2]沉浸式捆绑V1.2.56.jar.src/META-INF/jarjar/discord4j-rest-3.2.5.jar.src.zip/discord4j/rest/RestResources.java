/*     */ package discord4j.rest;
/*     */ 
/*     */ import discord4j.common.JacksonResources;
/*     */ import discord4j.common.ReactorResources;
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.common.util.TokenUtil;
/*     */ import discord4j.rest.http.client.AuthorizationScheme;
/*     */ import discord4j.rest.request.Router;
/*     */ import discord4j.rest.util.AllowedMentions;
/*     */ import java.util.Optional;
/*     */ import java.util.function.Supplier;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RestResources
/*     */ {
/*     */   private final AuthorizationScheme scheme;
/*     */   private final String token;
/*     */   private final ReactorResources reactorResources;
/*     */   private final JacksonResources jacksonResources;
/*     */   private final Router router;
/*     */   @Nullable
/*     */   private final Long selfId;
/*     */   @Nullable
/*     */   private final AllowedMentions allowedMentions;
/*     */   
/*     */   public RestResources(String token, ReactorResources reactorResources, JacksonResources jacksonResources, Router router, @Nullable AllowedMentions allowedMentions) {
/*  48 */     this(AuthorizationScheme.BOT, token, reactorResources, jacksonResources, router, allowedMentions);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestResources(AuthorizationScheme scheme, String token, ReactorResources reactorResources, JacksonResources jacksonResources, Router router, @Nullable AllowedMentions allowedMentions) {
/*  62 */     this.scheme = scheme;
/*  63 */     this.token = token;
/*  64 */     this.reactorResources = reactorResources;
/*  65 */     this.jacksonResources = jacksonResources;
/*  66 */     this.router = router;
/*  67 */     this.selfId = (scheme == AuthorizationScheme.BOT) ? Long.valueOf(TokenUtil.getSelfId(token)) : null;
/*  68 */     this.allowedMentions = allowedMentions;
/*     */   }
/*     */   
/*     */   public AuthorizationScheme getScheme() {
/*  72 */     return this.scheme;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getToken() {
/*  81 */     return this.token;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReactorResources getReactorResources() {
/*  90 */     return this.reactorResources;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JacksonResources getJacksonResources() {
/*  99 */     return this.jacksonResources;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Router getRouter() {
/* 108 */     return this.router;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getSelfId() {
/* 117 */     return Snowflake.of(((Long)Optional.<Long>ofNullable(this.selfId).orElseThrow(UnsupportedOperationException::new)).longValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<AllowedMentions> getAllowedMentions() {
/* 126 */     return Optional.ofNullable(this.allowedMentions);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\RestResources.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */