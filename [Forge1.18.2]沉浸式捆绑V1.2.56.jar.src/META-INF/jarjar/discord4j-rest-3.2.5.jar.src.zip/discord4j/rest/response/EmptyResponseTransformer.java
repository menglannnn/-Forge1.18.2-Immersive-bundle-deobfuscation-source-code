/*    */ package discord4j.rest.response;
/*    */ 
/*    */ import discord4j.common.annotations.Experimental;
/*    */ import discord4j.rest.http.client.ClientResponse;
/*    */ import discord4j.rest.request.DiscordWebRequest;
/*    */ import discord4j.rest.request.RouteMatcher;
/*    */ import java.util.function.Function;
/*    */ import java.util.function.Predicate;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Experimental
/*    */ public class EmptyResponseTransformer
/*    */   implements ResponseFunction
/*    */ {
/*    */   private final RouteMatcher routeMatcher;
/*    */   private final Predicate<Throwable> predicate;
/*    */   
/*    */   public EmptyResponseTransformer(RouteMatcher routeMatcher, Predicate<Throwable> predicate) {
/* 44 */     this.routeMatcher = routeMatcher;
/* 45 */     this.predicate = predicate;
/*    */   }
/*    */ 
/*    */   
/*    */   public Function<Mono<ClientResponse>, Mono<ClientResponse>> transform(DiscordWebRequest request) {
/* 50 */     if (this.routeMatcher.matches(request)) {
/* 51 */       return mono -> mono.onErrorResume(this.predicate, ());
/*    */     }
/* 53 */     return mono -> mono;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\response\EmptyResponseTransformer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */