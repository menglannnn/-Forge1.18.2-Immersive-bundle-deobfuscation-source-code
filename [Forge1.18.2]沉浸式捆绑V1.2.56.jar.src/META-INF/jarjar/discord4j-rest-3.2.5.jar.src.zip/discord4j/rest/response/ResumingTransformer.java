/*    */ package discord4j.rest.response;
/*    */ 
/*    */ import discord4j.common.annotations.Experimental;
/*    */ import discord4j.rest.http.client.ClientResponse;
/*    */ import discord4j.rest.request.DiscordWebRequest;
/*    */ import discord4j.rest.request.RouteMatcher;
/*    */ import java.util.function.Function;
/*    */ import java.util.function.Predicate;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Experimental
/*    */ public class ResumingTransformer
/*    */   implements ResponseFunction
/*    */ {
/*    */   private final RouteMatcher routeMatcher;
/*    */   private final Predicate<Throwable> predicate;
/*    */   private Function<Throwable, Mono<?>> fallback;
/*    */   
/*    */   public ResumingTransformer(RouteMatcher routeMatcher, Predicate<Throwable> predicate, Function<Throwable, Mono<?>> fallback) {
/* 41 */     this.routeMatcher = routeMatcher;
/* 42 */     this.predicate = predicate;
/* 43 */     this.fallback = fallback;
/*    */   }
/*    */ 
/*    */   
/*    */   public Function<Mono<ClientResponse>, Mono<ClientResponse>> transform(DiscordWebRequest request) {
/* 48 */     if (this.routeMatcher.matches(request)) {
/* 49 */       return mono -> mono.onErrorResume(this.predicate, adaptFallback(this.fallback));
/*    */     }
/* 51 */     return mono -> mono;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   private <T> Function<? super Throwable, ? extends Mono<? extends T>> adaptFallback(Function<? super Throwable, ? extends Mono<?>> fallback) {
/* 57 */     return (Function)fallback;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\response\ResumingTransformer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */