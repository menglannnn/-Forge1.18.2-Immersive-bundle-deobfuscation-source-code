/*    */ package discord4j.rest.response;
/*    */ 
/*    */ import discord4j.common.annotations.Experimental;
/*    */ import discord4j.rest.http.client.ClientResponse;
/*    */ import discord4j.rest.request.DiscordWebRequest;
/*    */ import discord4j.rest.request.RouteMatcher;
/*    */ import java.util.function.Function;
/*    */ import reactor.core.publisher.Mono;
/*    */ import reactor.retry.Retry;
/*    */ import reactor.util.retry.Retry;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Experimental
/*    */ public class RetryingTransformer
/*    */   implements ResponseFunction
/*    */ {
/*    */   private final RouteMatcher routeMatcher;
/*    */   private final Retry<?> retryFactory;
/*    */   
/*    */   public RetryingTransformer(RouteMatcher routeMatcher, Retry<?> retryFactory) {
/* 39 */     this.routeMatcher = routeMatcher;
/* 40 */     this.retryFactory = retryFactory;
/*    */   }
/*    */ 
/*    */   
/*    */   public Function<Mono<ClientResponse>, Mono<ClientResponse>> transform(DiscordWebRequest request) {
/* 45 */     if (this.routeMatcher.matches(request)) {
/* 46 */       return mono -> mono.retryWhen(Retry.withThrowable((Function)this.retryFactory));
/*    */     }
/* 48 */     return mono -> mono;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\response\RetryingTransformer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */