/*     */ package discord4j.rest.response;
/*     */ 
/*     */ import discord4j.common.annotations.Experimental;
/*     */ import discord4j.rest.http.client.ClientException;
/*     */ import discord4j.rest.http.client.ClientResponse;
/*     */ import discord4j.rest.request.DiscordWebRequest;
/*     */ import discord4j.rest.request.RouteMatcher;
/*     */ import java.time.Duration;
/*     */ import java.util.function.Function;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.retry.Retry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Experimental
/*     */ public interface ResponseFunction
/*     */ {
/*     */   Function<Mono<ClientResponse>, Mono<ClientResponse>> transform(DiscordWebRequest paramDiscordWebRequest);
/*     */   
/*     */   static EmptyResponseTransformer emptyIfNotFound() {
/*  63 */     return new EmptyResponseTransformer(RouteMatcher.any(), ClientException.isStatusCode(404));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static EmptyResponseTransformer emptyIfNotFound(RouteMatcher routeMatcher) {
/*  75 */     return new EmptyResponseTransformer(routeMatcher, ClientException.isStatusCode(404));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static EmptyResponseTransformer emptyOnErrorStatus(RouteMatcher routeMatcher, Integer... codes) {
/*  90 */     return new EmptyResponseTransformer(routeMatcher, ClientException.isStatusCode(codes));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static RetryingTransformer retryOnceOnErrorStatus(Integer... codes) {
/* 109 */     return new RetryingTransformer(RouteMatcher.any(), 
/* 110 */         Retry.onlyIf(ClientException.isRetryContextStatusCode(codes))
/* 111 */         .fixedBackoff(Duration.ofSeconds(1L))
/* 112 */         .retryOnce());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static RetryingTransformer retryOnceOnErrorStatus(RouteMatcher routeMatcher, Integer... codes) {
/* 132 */     return new RetryingTransformer(routeMatcher, 
/* 133 */         Retry.onlyIf(ClientException.isRetryContextStatusCode(codes))
/* 134 */         .fixedBackoff(Duration.ofSeconds(1L))
/* 135 */         .retryOnce());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static RetryingTransformer retryWhen(RouteMatcher routeMatcher, Retry<?> retry) {
/* 151 */     return new RetryingTransformer(routeMatcher, retry);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\response\ResponseFunction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */