/*    */ package discord4j.rest.response;
/*    */ 
/*    */ import discord4j.common.annotations.Experimental;
/*    */ import discord4j.rest.http.client.ClientResponse;
/*    */ import discord4j.rest.request.DiscordWebRequest;
/*    */ import java.util.List;
/*    */ import java.util.function.Function;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Experimental
/*    */ public class CompositeTransformer
/*    */   implements ResponseFunction
/*    */ {
/*    */   private final List<ResponseFunction> responseFunctions;
/*    */   
/*    */   public CompositeTransformer(List<ResponseFunction> responseFunctions) {
/* 37 */     this.responseFunctions = responseFunctions;
/*    */   }
/*    */ 
/*    */   
/*    */   public Function<Mono<ClientResponse>, Mono<ClientResponse>> transform(DiscordWebRequest request) {
/* 42 */     return this.responseFunctions.stream()
/* 43 */       .map(rt -> rt.transform(request))
/* 44 */       .reduce(Function::andThen)
/* 45 */       .orElse(mono -> mono);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\response\CompositeTransformer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */