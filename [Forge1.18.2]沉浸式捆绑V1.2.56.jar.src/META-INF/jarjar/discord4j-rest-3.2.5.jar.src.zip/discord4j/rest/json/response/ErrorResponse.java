/*    */ package discord4j.rest.json.response;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonAnySetter;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ErrorResponse
/*    */ {
/* 27 */   private Map<String, Object> fields = new HashMap<>();
/*    */   
/*    */   public Map<String, Object> getFields() {
/* 30 */     return this.fields;
/*    */   }
/*    */   
/*    */   @JsonAnySetter
/*    */   public void anySetter(String key, Object value) {
/* 35 */     this.fields.put(key, value);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 40 */     return "ErrorResponse{fields=" + this.fields + '}';
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\json\response\ErrorResponse.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */