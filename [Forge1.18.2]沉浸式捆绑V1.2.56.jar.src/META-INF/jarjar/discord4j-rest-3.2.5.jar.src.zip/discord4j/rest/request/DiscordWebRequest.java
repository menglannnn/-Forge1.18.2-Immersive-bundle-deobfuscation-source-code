/*     */ package discord4j.rest.request;
/*     */ 
/*     */ import discord4j.rest.http.client.AuthorizationScheme;
/*     */ import discord4j.rest.route.Route;
/*     */ import discord4j.rest.util.Multimap;
/*     */ import discord4j.rest.util.RouteUtils;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.function.Predicate;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DiscordWebRequest
/*     */ {
/*     */   private final Route route;
/*     */   private final String completeUri;
/*     */   private final Map<String, String> uriVariableMap;
/*     */   @Nullable
/*     */   private Object body;
/*     */   @Nullable
/*     */   private Multimap<String, Object> queryParams;
/*     */   @Nullable
/*     */   private Map<String, Set<String>> headers;
/*     */   @Nullable
/*     */   private AuthorizationScheme authorizationScheme;
/*     */   @Nullable
/*     */   private String authorizationValue;
/*     */   
/*     */   public DiscordWebRequest(Route route, Object... uriVars) {
/*  59 */     this.route = route;
/*  60 */     this.completeUri = RouteUtils.expand(route.getUriTemplate(), uriVars);
/*  61 */     this.uriVariableMap = RouteUtils.createVariableMap(route.getUriTemplate(), uriVars);
/*     */   }
/*     */   
/*     */   DiscordWebRequest(DiscordWebRequest other) {
/*  65 */     this.route = other.route;
/*  66 */     this.completeUri = other.completeUri;
/*  67 */     this.uriVariableMap = other.uriVariableMap;
/*  68 */     this.body = other.body;
/*  69 */     this.queryParams = other.queryParams;
/*  70 */     this.headers = other.headers;
/*  71 */     this.authorizationScheme = other.authorizationScheme;
/*  72 */     this.authorizationValue = other.authorizationValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DiscordWebRequest copy() {
/*  81 */     return new DiscordWebRequest(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Route getRoute() {
/*  90 */     return this.route;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCompleteUri() {
/*  99 */     return this.completeUri;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object getBody() {
/* 109 */     return this.body;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Multimap<String, Object> getQueryParams() {
/* 119 */     return this.queryParams;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Map<String, Set<String>> getHeaders() {
/* 129 */     return this.headers;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public AuthorizationScheme getAuthorizationScheme() {
/* 134 */     return this.authorizationScheme;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public String getAuthorizationValue() {
/* 139 */     return this.authorizationValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DiscordWebRequest body(Object body) {
/* 149 */     this.body = body;
/* 150 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DiscordWebRequest query(String key, Object value) {
/* 161 */     if (this.queryParams == null) {
/* 162 */       this.queryParams = new Multimap();
/*     */     }
/* 164 */     this.queryParams.add(key, value);
/* 165 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DiscordWebRequest query(Map<String, Object> params) {
/* 175 */     params.forEach(this::query);
/* 176 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DiscordWebRequest query(Multimap<String, Object> params) {
/* 186 */     params.forEachElement(this::query);
/* 187 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DiscordWebRequest header(String key, String value) {
/* 198 */     ((Set<String>)initHeaders().computeIfAbsent(key.toLowerCase(), k -> new LinkedHashSet())).add(value);
/* 199 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DiscordWebRequest optionalHeader(String key, @Nullable String value) {
/* 211 */     return (value == null) ? this : header(key, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DiscordWebRequest bearerAuth(String accessToken) {
/* 221 */     this.authorizationScheme = AuthorizationScheme.BEARER;
/* 222 */     this.authorizationValue = accessToken;
/* 223 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DiscordWebRequest basicAuth(String base64EncodedValue) {
/* 233 */     this.authorizationScheme = AuthorizationScheme.BASIC;
/* 234 */     this.authorizationValue = base64EncodedValue;
/* 235 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DiscordWebRequest unauthenticated() {
/* 244 */     this.authorizationScheme = AuthorizationScheme.NONE;
/* 245 */     this.authorizationValue = null;
/* 246 */     return this;
/*     */   }
/*     */   
/*     */   private Map<String, Set<String>> initHeaders() {
/* 250 */     if (this.headers == null) {
/* 251 */       this.headers = new LinkedHashMap<>();
/*     */     }
/* 253 */     return this.headers;
/*     */   }
/*     */   
/*     */   boolean matchesVariables(Predicate<Map<String, String>> matcher) {
/* 257 */     return matcher.test(this.uriVariableMap);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DiscordWebResponse exchange(Router router) {
/* 267 */     return router.exchange(this);
/*     */   }
/*     */   
/*     */   public String getDescription() {
/* 271 */     return this.route.getMethod() + " " + this.completeUri;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 276 */     return "DiscordRequest{route=" + this.route + ", completeUri='" + this.completeUri + '\'' + ", body=" + this.body + ", queryParams=" + this.queryParams + ", headers=" + this.headers + '}';
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\request\DiscordWebRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */