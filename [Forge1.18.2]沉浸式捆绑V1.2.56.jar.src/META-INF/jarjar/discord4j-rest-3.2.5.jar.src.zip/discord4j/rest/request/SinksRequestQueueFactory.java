/*    */ package discord4j.rest.request;
/*    */ 
/*    */ import discord4j.common.sinks.EmissionStrategy;
/*    */ import java.util.function.Function;
/*    */ import reactor.core.publisher.Flux;
/*    */ import reactor.core.publisher.Sinks;
/*    */ import reactor.util.Logger;
/*    */ import reactor.util.Loggers;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SinksRequestQueueFactory
/*    */   implements RequestQueueFactory
/*    */ {
/* 29 */   private static final Logger log = Loggers.getLogger(SinksRequestQueueFactory.class);
/*    */   
/*    */   private final Function<Sinks.ManySpec, Sinks.Many<Object>> requestSinkFactory;
/*    */   
/*    */   private final EmissionStrategy emissionStrategy;
/*    */   
/*    */   SinksRequestQueueFactory(Function<Sinks.ManySpec, Sinks.Many<Object>> requestSinkFactory, EmissionStrategy emissionStrategy) {
/* 36 */     this.requestSinkFactory = requestSinkFactory;
/* 37 */     this.emissionStrategy = emissionStrategy;
/*    */   }
/*    */ 
/*    */   
/*    */   public <T> RequestQueue<T> create() {
/* 42 */     return new RequestQueue<T>()
/*    */       {
/* 44 */         private final Sinks.Many<Object> sink = SinksRequestQueueFactory.this.requestSinkFactory.apply(Sinks.many());
/*    */ 
/*    */         
/*    */         public boolean push(T request) {
/* 48 */           return SinksRequestQueueFactory.this.emissionStrategy.emitNext(this.sink, request);
/*    */         }
/*    */ 
/*    */ 
/*    */         
/*    */         public Flux<T> requests() {
/* 54 */           return this.sink.asFlux();
/*    */         }
/*    */       };
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\request\SinksRequestQueueFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */