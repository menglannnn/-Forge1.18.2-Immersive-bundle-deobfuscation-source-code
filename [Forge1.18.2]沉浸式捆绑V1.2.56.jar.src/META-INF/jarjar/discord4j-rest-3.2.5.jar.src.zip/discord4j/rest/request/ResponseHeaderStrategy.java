/*    */ package discord4j.rest.request;
/*    */ 
/*    */ import io.netty.handler.codec.http.HttpHeaders;
/*    */ import java.time.Duration;
/*    */ import reactor.netty.http.client.HttpClientResponse;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ResponseHeaderStrategy
/*    */   implements RateLimitStrategy
/*    */ {
/*    */   public Duration apply(HttpClientResponse response) {
/* 29 */     HttpHeaders headers = response.responseHeaders();
/* 30 */     int remaining = headers.getInt("X-RateLimit-Remaining", -1);
/* 31 */     if (remaining == 0) {
/* 32 */       long resetAfter = (long)(Double.parseDouble(headers.get("X-RateLimit-Reset-After")) * 1000.0D);
/* 33 */       return Duration.ofMillis(resetAfter);
/*    */     } 
/* 35 */     return Duration.ZERO;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\request\ResponseHeaderStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */