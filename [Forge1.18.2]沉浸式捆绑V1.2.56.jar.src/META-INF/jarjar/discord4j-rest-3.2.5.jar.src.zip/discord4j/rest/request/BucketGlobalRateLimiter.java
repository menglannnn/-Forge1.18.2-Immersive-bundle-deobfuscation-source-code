/*    */ package discord4j.rest.request;
/*    */ 
/*    */ import discord4j.common.operator.RateLimitOperator;
/*    */ import java.time.Duration;
/*    */ import java.util.function.Function;
/*    */ import org.reactivestreams.Publisher;
/*    */ import reactor.core.publisher.Flux;
/*    */ import reactor.core.publisher.Mono;
/*    */ import reactor.core.scheduler.Scheduler;
/*    */ import reactor.core.scheduler.Schedulers;
/*    */ import reactor.util.Logger;
/*    */ import reactor.util.Loggers;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BucketGlobalRateLimiter
/*    */   implements GlobalRateLimiter
/*    */ {
/* 36 */   private static final Logger log = Loggers.getLogger(BucketGlobalRateLimiter.class);
/*    */   
/*    */   private final RateLimitOperator<Integer> operator;
/*    */   
/* 40 */   private volatile long limitedUntil = 0L;
/*    */   
/*    */   BucketGlobalRateLimiter(int capacity, Duration refillPeriod, Scheduler delayScheduler) {
/* 43 */     this.operator = new RateLimitOperator(capacity, refillPeriod, delayScheduler);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static BucketGlobalRateLimiter create() {
/* 52 */     return new BucketGlobalRateLimiter(50, Duration.ofSeconds(1L), Schedulers.parallel());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static BucketGlobalRateLimiter create(int capacity, Duration refillPeriod, Scheduler delayScheduler) {
/* 65 */     return new BucketGlobalRateLimiter(capacity, refillPeriod, delayScheduler);
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Void> rateLimitFor(Duration duration) {
/* 70 */     return Mono.fromRunnable(() -> this.limitedUntil = System.nanoTime() + duration.toNanos());
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Duration> getRemaining() {
/* 75 */     return Mono.fromCallable(() -> Duration.ofNanos(this.limitedUntil - System.nanoTime()));
/*    */   }
/*    */ 
/*    */   
/*    */   public <T> Flux<T> withLimiter(Publisher<T> stage) {
/* 80 */     return Mono.just(Integer.valueOf(0))
/* 81 */       .transform((Function)this.operator)
/* 82 */       .then(getRemaining())
/* 83 */       .filter(delay -> (delay.getSeconds() > 0L))
/* 84 */       .flatMapMany(delay -> {
/*    */           log.trace("[{}] Delaying for {}", new Object[] { Integer.toHexString(hashCode()), delay });
/*    */           
/*    */           return (Publisher)Mono.delay(delay).flatMapMany(());
/* 88 */         }).switchIfEmpty(stage);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\request\BucketGlobalRateLimiter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */