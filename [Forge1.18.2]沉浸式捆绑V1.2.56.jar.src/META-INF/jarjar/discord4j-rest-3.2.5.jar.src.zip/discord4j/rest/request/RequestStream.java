/*     */ package discord4j.rest.request;
/*     */ 
/*     */ import discord4j.common.LogUtil;
/*     */ import discord4j.rest.http.client.ClientException;
/*     */ import discord4j.rest.http.client.ClientRequest;
/*     */ import discord4j.rest.http.client.ClientResponse;
/*     */ import discord4j.rest.http.client.DiscordWebClient;
/*     */ import discord4j.rest.response.ResponseFunction;
/*     */ import java.time.Duration;
/*     */ import java.time.Instant;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ import java.util.function.Function;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.publisher.BaseSubscriber;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.core.publisher.SignalType;
/*     */ import reactor.core.publisher.Sinks;
/*     */ import reactor.core.scheduler.Scheduler;
/*     */ import reactor.netty.http.client.HttpClientResponse;
/*     */ import reactor.retry.Retry;
/*     */ import reactor.retry.RetryContext;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.Loggers;
/*     */ import reactor.util.context.Context;
/*     */ import reactor.util.context.ContextView;
/*     */ import reactor.util.retry.Retry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class RequestStream
/*     */ {
/*  56 */   private static final Logger log = Loggers.getLogger(RequestStream.class);
/*     */   
/*     */   private final BucketKey id;
/*     */   private final RequestQueue<RequestCorrelation<ClientResponse>> requestQueue;
/*     */   private final GlobalRateLimiter globalRateLimiter;
/*     */   private final Scheduler timedTaskScheduler;
/*     */   private final List<ResponseFunction> responseFunctions;
/*     */   private final DiscordWebClient httpClient;
/*     */   private final RequestSubscriber requestSubscriber;
/*     */   private final RateLimitRetryOperator rateLimitRetryOperator;
/*  66 */   private final AtomicLong requestsInFlight = new AtomicLong(0L);
/*  67 */   private final Sinks.Empty<?> stopCallback = Sinks.empty();
/*     */ 
/*     */   
/*     */   RequestStream(BucketKey id, RouterOptions routerOptions, DiscordWebClient httpClient, RateLimitStrategy rateLimitStrategy) {
/*  71 */     this.id = id;
/*  72 */     this.requestQueue = routerOptions.getRequestQueueFactory().create();
/*  73 */     this.globalRateLimiter = routerOptions.getGlobalRateLimiter();
/*  74 */     this.timedTaskScheduler = routerOptions.getReactorResources().getTimerTaskScheduler();
/*  75 */     this.responseFunctions = routerOptions.getResponseTransformers();
/*  76 */     this.httpClient = httpClient;
/*  77 */     Objects.requireNonNull(this.requestsInFlight); this.requestSubscriber = new RequestSubscriber(rateLimitStrategy, this.requestsInFlight::decrementAndGet);
/*  78 */     this.rateLimitRetryOperator = new RateLimitRetryOperator(this.timedTaskScheduler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Retry serverErrorRetryFactory() {
/*  86 */     return Retry.withThrowable((Function)Retry.onlyIf(ClientException.isRetryContextStatusCode(new Integer[] { Integer.valueOf(500), Integer.valueOf(502), Integer.valueOf(503), 
/*  87 */               Integer.valueOf(504), Integer.valueOf(520)
/*  88 */             })).withBackoffScheduler(this.timedTaskScheduler)
/*  89 */         .exponentialBackoffWithJitter(Duration.ofSeconds(2L), Duration.ofSeconds(30L))
/*  90 */         .doOnRetry(ctx -> {
/*     */             if (log.isDebugEnabled()) {
/*     */               log.debug("Retry {} in bucket {} due to {} for {}", new Object[] { Long.valueOf(ctx.iteration()), this.id.toString(), ctx.exception().toString(), ctx.backoff() });
/*     */             }
/*     */           }));
/*     */   }
/*     */ 
/*     */   
/*     */   boolean push(RequestCorrelation<ClientResponse> request) {
/*  99 */     this.requestsInFlight.incrementAndGet();
/* 100 */     boolean accepted = this.requestQueue.push(request);
/* 101 */     if (!accepted) {
/* 102 */       this.requestsInFlight.decrementAndGet();
/*     */     }
/* 104 */     return accepted;
/*     */   }
/*     */   
/*     */   void start() {
/* 108 */     this.requestQueue.requests()
/* 109 */       .doOnDiscard(RequestCorrelation.class, this::onDiscard)
/* 110 */       .takeUntilOther((Publisher)this.stopCallback.asMono())
/* 111 */       .subscribe((CoreSubscriber)this.requestSubscriber);
/*     */   }
/*     */   
/*     */   void stop() {
/* 115 */     this.stopCallback.emitEmpty(Sinks.EmitFailureHandler.FAIL_FAST);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Instant getResetAt() {
/* 122 */     return this.requestSubscriber.getResetAt();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   long countRequestsInFlight() {
/* 129 */     return this.requestsInFlight.get();
/*     */   }
/*     */   
/*     */   private void onDiscard(RequestCorrelation<?> requestCorrelation) {
/* 133 */     this.requestsInFlight.decrementAndGet();
/* 134 */     requestCorrelation.getResponse()
/* 135 */       .emitError(new DiscardedRequestException(requestCorrelation.getRequest()), Sinks.EmitFailureHandler.FAIL_FAST);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class RequestSubscriber
/*     */     extends BaseSubscriber<RequestCorrelation<ClientResponse>>
/*     */   {
/* 145 */     private volatile Instant resetAt = Instant.EPOCH;
/*     */     private final Function<ClientResponse, Mono<ClientResponse>> responseFunction;
/*     */     private final Runnable processedCallback;
/*     */     
/*     */     public Instant getResetAt() {
/* 150 */       return this.resetAt;
/*     */     }
/*     */     
/*     */     public RequestSubscriber(RateLimitStrategy strategy, Runnable processedCallback) {
/* 154 */       this.processedCallback = processedCallback;
/* 155 */       this.responseFunction = (response -> {
/*     */           HttpClientResponse httpResponse = response.getHttpResponse();
/*     */           if (RequestStream.log.isDebugEnabled()) {
/*     */             Instant requestTimestamp = Instant.ofEpochMilli(((Long)httpResponse.currentContextView().get("discord4j.request.timestamp")).longValue());
/*     */             Duration responseTime = Duration.between(requestTimestamp, Instant.now());
/*     */             LogUtil.traceDebug(RequestStream.log, ());
/*     */           } 
/*     */           Duration resetAfter = strategy.apply(httpResponse);
/*     */           if (!resetAfter.isZero()) {
/*     */             if (RequestStream.log.isDebugEnabled()) {
/*     */               RequestStream.log.debug(LogUtil.format(httpResponse.currentContextView(), "Delaying next request by {}"), new Object[] { resetAfter });
/*     */             }
/*     */             this.resetAt = Instant.now().plus(resetAfter);
/*     */           } 
/*     */           boolean global = Boolean.parseBoolean(httpResponse.responseHeaders().get("X-RateLimit-Global"));
/*     */           Mono<Void> action = Mono.empty();
/*     */           if (global) {
/*     */             long retryAfter = Long.parseLong(httpResponse.responseHeaders().get("Retry-After"));
/*     */             Duration fixedBackoff = Duration.ofSeconds(retryAfter);
/*     */             action = RequestStream.this.globalRateLimiter.rateLimitFor(fixedBackoff).doOnTerminate(());
/*     */           } 
/*     */           return (httpResponse.status().code() >= 400) ? action.then(response.createException().flatMap(Mono::error)) : action.thenReturn(response);
/*     */         });
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void hookOnSubscribe(Subscription subscription) {
/* 191 */       request(1L);
/*     */     }
/*     */ 
/*     */     
/*     */     protected void hookOnNext(RequestCorrelation<ClientResponse> correlation) {
/* 196 */       DiscordWebRequest request = correlation.getRequest();
/* 197 */       ClientRequest clientRequest = new ClientRequest(request);
/* 198 */       Sinks.One<ClientResponse> callback = correlation.getResponse();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 208 */       Objects.requireNonNull(RequestStream.this.rateLimitRetryOperator); Mono.just(clientRequest).flatMap(req -> Mono.deferContextual(())).contextWrite(ctx -> ctx.putAll(correlation.getContext()).put("discord4j.request", clientRequest.getId()).put("discord4j.bucket", RequestStream.this.id.toString())).retryWhen(Retry.withThrowable(RequestStream.this.rateLimitRetryOperator::apply))
/* 209 */         .transform(getResponseTransformers(request))
/* 210 */         .retryWhen(RequestStream.this.serverErrorRetryFactory())
/* 211 */         .takeUntilOther((Publisher)correlation.onCancel())
/* 212 */         .doFinally(this::next)
/* 213 */         .checkpoint("Request to " + clientRequest.getDescription() + " [RequestStream]")
/* 214 */         .subscribe(response -> callback.emitValue(response, Sinks.EmitFailureHandler.FAIL_FAST), t -> {
/*     */             RequestStream.log.trace("Error while processing {}: {}", new Object[] { request, t });
/*     */             callback.emitError(t, Sinks.EmitFailureHandler.FAIL_FAST);
/*     */           }() -> callback.emitEmpty(Sinks.EmitFailureHandler.FAIL_FAST));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Function<Mono<ClientResponse>, Mono<ClientResponse>> getResponseTransformers(DiscordWebRequest discordRequest) {
/* 224 */       return RequestStream.this.responseFunctions.stream()
/* 225 */         .map(rt -> rt.transform(discordRequest).andThen(()))
/*     */ 
/*     */         
/* 228 */         .reduce(Function::andThen)
/* 229 */         .orElse(mono -> mono);
/*     */     }
/*     */     
/*     */     private void next(SignalType signal) {
/* 233 */       Duration wait = Duration.between(Instant.now(), this.resetAt);
/* 234 */       Mono<Long> timer = (wait.isNegative() || wait.isZero()) ? Mono.just(Long.valueOf(0L)) : Mono.delay(wait, RequestStream.this.timedTaskScheduler);
/* 235 */       timer
/* 236 */         .doFinally(__ -> this.processedCallback.run())
/* 237 */         .subscribe(l -> {
/*     */             if (RequestStream.log.isDebugEnabled()) {
/*     */               RequestStream.log.debug("[B:{}] Ready to consume next request after {}", new Object[] { RequestStream.access$400(this.this$0).toString(), signal });
/*     */             }
/*     */             request(1L);
/*     */           }t -> RequestStream.log.error("[B:{}] Error while scheduling next request", new Object[] { RequestStream.access$400(this.this$0).toString(), t }));
/*     */     }
/*     */ 
/*     */     
/*     */     protected void hookOnComplete() {
/* 247 */       RequestStream.log.debug("[B:{}] RequestStream completed", new Object[] { RequestStream.access$400(this.this$0).toString() });
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\request\RequestStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */