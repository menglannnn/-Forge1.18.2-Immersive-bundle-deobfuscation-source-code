/*     */ package discord4j.rest.request;
/*     */ 
/*     */ import discord4j.common.annotations.Experimental;
/*     */ import discord4j.rest.route.Route;
/*     */ import java.util.Map;
/*     */ import java.util.function.Predicate;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Experimental
/*     */ public class RouteMatcher
/*     */ {
/*     */   @Nullable
/*     */   private final DiscordWebRequest request;
/*     */   @Nullable
/*     */   private final Predicate<Map<String, String>> requestVariableMatcher;
/*     */   
/*     */   private RouteMatcher(@Nullable DiscordWebRequest request) {
/*  42 */     this(request, null);
/*     */   }
/*     */   
/*     */   public RouteMatcher(@Nullable DiscordWebRequest request, @Nullable Predicate<Map<String, String>> requestVariableMatcher) {
/*  46 */     this.request = request;
/*  47 */     this.requestVariableMatcher = requestVariableMatcher;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RouteMatcher any() {
/*  56 */     return new RouteMatcher(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RouteMatcher route(Route route) {
/*  67 */     return new RouteMatcher(route.newRequest(new Object[0]));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RouteMatcher route(Route route, Predicate<Map<String, String>> requestVariableMatcher) {
/*  86 */     return new RouteMatcher(route.newRequest(new Object[0]), requestVariableMatcher);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean matches(DiscordWebRequest otherRequest) {
/*  96 */     return (matchesRoute(otherRequest) && matchesVariables(otherRequest));
/*     */   }
/*     */   
/*     */   private boolean matchesRoute(DiscordWebRequest otherRequest) {
/* 100 */     return (this.request == null || this.request.getRoute().equals(otherRequest.getRoute()));
/*     */   }
/*     */   
/*     */   private boolean matchesVariables(DiscordWebRequest otherRequest) {
/* 104 */     return (this.requestVariableMatcher == null || otherRequest.matchesVariables(this.requestVariableMatcher));
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\request\RouteMatcher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */