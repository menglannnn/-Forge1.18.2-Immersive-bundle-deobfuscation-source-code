/*    */ package discord4j.rest.request;
/*    */ 
/*    */ import discord4j.rest.route.Routes;
/*    */ import discord4j.rest.util.RouteUtils;
/*    */ import java.util.Objects;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class BucketKey
/*    */ {
/*    */   private final String uriTemplate;
/*    */   @Nullable
/*    */   private final String majorParam;
/*    */   
/*    */   private BucketKey(String uriTemplate, String completeUri) {
/* 51 */     this.uriTemplate = uriTemplate;
/* 52 */     this.majorParam = RouteUtils.getMajorParam(uriTemplate, completeUri);
/*    */   }
/*    */   
/*    */   public static BucketKey of(String uriTemplate, String completeUri) {
/* 56 */     return new BucketKey(uriTemplate, completeUri);
/*    */   }
/*    */   
/*    */   public static BucketKey of(DiscordWebRequest request) {
/* 60 */     if (Routes.MESSAGE_DELETE.equals(request.getRoute())) {
/* 61 */       return of("DELETE " + request.getRoute().getUriTemplate(), request.getCompleteUri());
/*    */     }
/* 63 */     return of(request.getRoute().getUriTemplate(), request.getCompleteUri());
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 68 */     return Objects.hash(new Object[] { this.uriTemplate, this.majorParam });
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(@Nullable Object obj) {
/* 73 */     if (this == obj) {
/* 74 */       return true;
/*    */     }
/* 76 */     if (obj == null || getClass() != obj.getClass()) {
/* 77 */       return false;
/*    */     }
/*    */     
/* 80 */     BucketKey bucket = (BucketKey)obj;
/*    */     
/* 82 */     return (this.uriTemplate.equals(bucket.uriTemplate) && Objects.equals(this.majorParam, bucket.majorParam));
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 87 */     return Integer.toHexString(hashCode());
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\request\BucketKey.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */