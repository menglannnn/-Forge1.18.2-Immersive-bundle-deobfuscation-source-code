/*    */ package discord4j.rest.request;
/*    */ 
/*    */ import reactor.core.publisher.Mono;
/*    */ import reactor.core.publisher.Sinks;
/*    */ import reactor.util.context.ContextView;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class RequestCorrelation<T>
/*    */ {
/*    */   private final DiscordWebRequest request;
/*    */   private final Sinks.One<T> response;
/*    */   private final ContextView context;
/*    */   private final Sinks.Empty<Void> cancel;
/*    */   
/*    */   RequestCorrelation(DiscordWebRequest request, Sinks.One<T> response, ContextView context, Sinks.Empty<Void> cancel) {
/* 32 */     this.request = request;
/* 33 */     this.response = response;
/* 34 */     this.context = context;
/* 35 */     this.cancel = cancel;
/*    */   }
/*    */   
/*    */   public DiscordWebRequest getRequest() {
/* 39 */     return this.request;
/*    */   }
/*    */   
/*    */   public Sinks.One<T> getResponse() {
/* 43 */     return this.response;
/*    */   }
/*    */   
/*    */   public ContextView getContext() {
/* 47 */     return this.context;
/*    */   }
/*    */   
/*    */   public Mono<Void> onCancel() {
/* 51 */     return this.cancel.asMono();
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 56 */     return "RequestCorrelation{request=" + this.request
/* 57 */       .getDescription() + ", response=" + this.response + ", context=" + this.context + '}';
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\request\RequestCorrelation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */