/*    */ package discord4j.rest.request;
/*    */ 
/*    */ import discord4j.common.sinks.EmissionStrategy;
/*    */ import java.time.Duration;
/*    */ import java.util.function.Function;
/*    */ import java.util.function.Supplier;
/*    */ import reactor.core.publisher.FluxProcessor;
/*    */ import reactor.core.publisher.FluxSink;
/*    */ import reactor.core.publisher.Sinks;
/*    */ import reactor.util.concurrent.Queues;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface RequestQueueFactory
/*    */ {
/*    */   <T> RequestQueue<T> create();
/*    */   
/*    */   @Deprecated
/*    */   static RequestQueueFactory backedByProcessor(Supplier<FluxProcessor<Object, Object>> processorSupplier, FluxSink.OverflowStrategy overflowStrategy) {
/* 55 */     return new ProcessorRequestQueueFactory(processorSupplier, overflowStrategy);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static RequestQueueFactory createFromSink(Function<Sinks.ManySpec, Sinks.Many<Object>> requestSinkFactory, EmissionStrategy emissionStrategy) {
/* 69 */     return new SinksRequestQueueFactory(requestSinkFactory, emissionStrategy);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static RequestQueueFactory buffering() {
/* 80 */     return createFromSink(spec -> spec.multicast().onBackpressureBuffer(Queues.SMALL_BUFFER_SIZE, false), 
/*    */         
/* 82 */         EmissionStrategy.park(Duration.ofMillis(10L)));
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\request\RequestQueueFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */