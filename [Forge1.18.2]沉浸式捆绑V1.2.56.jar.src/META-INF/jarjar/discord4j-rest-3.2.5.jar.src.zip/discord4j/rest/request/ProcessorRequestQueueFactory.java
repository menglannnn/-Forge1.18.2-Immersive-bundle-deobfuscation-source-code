/*    */ package discord4j.rest.request;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import java.util.function.Supplier;
/*    */ import reactor.core.publisher.Flux;
/*    */ import reactor.core.publisher.FluxProcessor;
/*    */ import reactor.core.publisher.FluxSink;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ProcessorRequestQueueFactory
/*    */   implements RequestQueueFactory
/*    */ {
/*    */   private final Supplier<FluxProcessor<Object, Object>> processorSupplier;
/*    */   private final FluxSink.OverflowStrategy overflowStrategy;
/*    */   
/*    */   ProcessorRequestQueueFactory(Supplier<FluxProcessor<Object, Object>> processorSupplier, FluxSink.OverflowStrategy overflowStrategy) {
/* 32 */     this.processorSupplier = processorSupplier;
/* 33 */     this.overflowStrategy = overflowStrategy;
/*    */   }
/*    */ 
/*    */   
/*    */   public <T> RequestQueue<T> create() {
/* 38 */     return new RequestQueue<T>()
/*    */       {
/* 40 */         private final FluxProcessor<Object, Object> processor = ProcessorRequestQueueFactory.this.processorSupplier.get();
/* 41 */         private final FluxSink<Object> sink = this.processor.sink(FluxSink.OverflowStrategy.BUFFER);
/*    */ 
/*    */         
/*    */         public boolean push(T request) {
/* 45 */           this.sink.next(request);
/* 46 */           return true;
/*    */         }
/*    */ 
/*    */ 
/*    */         
/*    */         public Flux<T> requests() {
/* 52 */           return Flux.create(sink -> { Objects.requireNonNull(sink); this.processor.subscribe(sink::next); }ProcessorRequestQueueFactory.this.overflowStrategy);
/*    */         }
/*    */       };
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\request\ProcessorRequestQueueFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */