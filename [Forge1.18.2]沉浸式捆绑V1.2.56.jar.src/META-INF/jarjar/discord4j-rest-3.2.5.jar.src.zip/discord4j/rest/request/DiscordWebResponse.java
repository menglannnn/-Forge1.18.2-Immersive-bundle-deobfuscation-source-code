/*    */ package discord4j.rest.request;
/*    */ 
/*    */ import discord4j.common.ReactorResources;
/*    */ import discord4j.rest.http.client.ClientResponse;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DiscordWebResponse
/*    */ {
/*    */   private final Mono<ClientResponse> responseMono;
/*    */   private final ReactorResources reactorResources;
/*    */   
/*    */   public DiscordWebResponse(Mono<ClientResponse> responseMono, ReactorResources reactorResources) {
/* 34 */     this.responseMono = responseMono;
/* 35 */     this.reactorResources = reactorResources;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public <T> Mono<T> bodyToMono(Class<T> responseClass) {
/* 48 */     return this.responseMono.flatMap(res -> res.bodyToMono(responseClass))
/* 49 */       .publishOn(this.reactorResources.getBlockingTaskScheduler());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Mono<Void> skipBody() {
/* 58 */     return this.responseMono.flatMap(ClientResponse::skipBody)
/* 59 */       .publishOn(this.reactorResources.getBlockingTaskScheduler());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Mono<ClientResponse> mono() {
/* 68 */     return this.responseMono;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\request\DiscordWebResponse.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */