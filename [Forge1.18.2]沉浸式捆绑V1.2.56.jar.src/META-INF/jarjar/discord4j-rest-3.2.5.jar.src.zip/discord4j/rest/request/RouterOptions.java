/*     */ package discord4j.rest.request;
/*     */ 
/*     */ import discord4j.common.ReactorResources;
/*     */ import discord4j.rest.http.ExchangeStrategies;
/*     */ import discord4j.rest.http.client.AuthorizationScheme;
/*     */ import discord4j.rest.response.ResponseFunction;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RouterOptions
/*     */ {
/*     */   private final AuthorizationScheme authorizationScheme;
/*     */   private final String token;
/*     */   private final ReactorResources reactorResources;
/*     */   private final ExchangeStrategies exchangeStrategies;
/*     */   private final List<ResponseFunction> responseTransformers;
/*     */   private final GlobalRateLimiter globalRateLimiter;
/*     */   private final RequestQueueFactory requestQueueFactory;
/*     */   private final String discordBaseUrl;
/*     */   
/*     */   public RouterOptions(String token, ReactorResources reactorResources, ExchangeStrategies exchangeStrategies, List<ResponseFunction> responseTransformers, GlobalRateLimiter globalRateLimiter, RequestQueueFactory requestQueueFactory, String discordBaseUrl) {
/*  45 */     this(AuthorizationScheme.BOT, token, reactorResources, exchangeStrategies, responseTransformers, globalRateLimiter, requestQueueFactory, discordBaseUrl);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RouterOptions(AuthorizationScheme authorizationScheme, String token, ReactorResources reactorResources, ExchangeStrategies exchangeStrategies, List<ResponseFunction> responseTransformers, GlobalRateLimiter globalRateLimiter, RequestQueueFactory requestQueueFactory, String discordBaseUrl) {
/*  54 */     this.authorizationScheme = Objects.<AuthorizationScheme>requireNonNull(authorizationScheme, "authorizationScheme");
/*  55 */     this.token = Objects.<String>requireNonNull(token, "token");
/*  56 */     this.reactorResources = Objects.<ReactorResources>requireNonNull(reactorResources, "reactorResources");
/*  57 */     this.exchangeStrategies = Objects.<ExchangeStrategies>requireNonNull(exchangeStrategies, "exchangeStrategies");
/*  58 */     this.responseTransformers = Objects.<List<ResponseFunction>>requireNonNull(responseTransformers, "responseTransformers");
/*  59 */     this.globalRateLimiter = Objects.<GlobalRateLimiter>requireNonNull(globalRateLimiter, "globalRateLimiter");
/*  60 */     this.requestQueueFactory = Objects.<RequestQueueFactory>requireNonNull(requestQueueFactory, "requestQueueFactory");
/*  61 */     this.discordBaseUrl = Objects.<String>requireNonNull(discordBaseUrl, "discordBaseUrl");
/*     */   }
/*     */   
/*     */   public AuthorizationScheme getAuthorizationScheme() {
/*  65 */     return this.authorizationScheme;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getToken() {
/*  74 */     return this.token;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReactorResources getReactorResources() {
/*  83 */     return this.reactorResources;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ExchangeStrategies getExchangeStrategies() {
/*  92 */     return this.exchangeStrategies;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<ResponseFunction> getResponseTransformers() {
/* 102 */     return this.responseTransformers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GlobalRateLimiter getGlobalRateLimiter() {
/* 111 */     return this.globalRateLimiter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RequestQueueFactory getRequestQueueFactory() {
/* 120 */     return this.requestQueueFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDiscordBaseUrl() {
/* 129 */     return this.discordBaseUrl;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\request\RouterOptions.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */