package discord4j.rest.request;

import java.time.Duration;
import reactor.netty.http.client.HttpClientResponse;

@FunctionalInterface
public interface RateLimitStrategy {
  Duration apply(HttpClientResponse paramHttpClientResponse);
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\request\RateLimitStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */