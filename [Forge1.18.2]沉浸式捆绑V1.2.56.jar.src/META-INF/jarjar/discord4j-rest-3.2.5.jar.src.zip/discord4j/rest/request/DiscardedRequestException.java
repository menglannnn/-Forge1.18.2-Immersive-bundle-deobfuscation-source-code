/*    */ package discord4j.rest.request;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DiscardedRequestException
/*    */   extends RuntimeException
/*    */ {
/*    */   private final DiscordWebRequest request;
/*    */   
/*    */   public DiscardedRequestException(DiscordWebRequest request) {
/* 27 */     super("Request discarded due to backpressure: " + request.getDescription());
/* 28 */     this.request = request;
/*    */   }
/*    */   
/*    */   public DiscordWebRequest getRequest() {
/* 32 */     return this.request;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\request\DiscardedRequestException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */