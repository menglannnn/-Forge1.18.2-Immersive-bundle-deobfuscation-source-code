/*     */ package discord4j.rest.request;
/*     */ 
/*     */ import discord4j.common.ReactorResources;
/*     */ import discord4j.rest.http.client.ClientResponse;
/*     */ import discord4j.rest.http.client.DiscordWebClient;
/*     */ import java.time.Duration;
/*     */ import java.time.Instant;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.core.publisher.Sinks;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.Loggers;
/*     */ import reactor.util.context.ContextView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultRouter
/*     */   implements Router
/*     */ {
/*  41 */   private static final Logger log = Loggers.getLogger(DefaultRouter.class);
/*  42 */   private static final ResponseHeaderStrategy HEADER_STRATEGY = new ResponseHeaderStrategy();
/*  43 */   private static final Duration HOUSE_KEEPING_PERIOD = Duration.ofSeconds(30L);
/*     */   
/*     */   private final ReactorResources reactorResources;
/*     */   private final DiscordWebClient httpClient;
/*  47 */   private final Map<BucketKey, RequestStream> streamMap = new ConcurrentHashMap<>();
/*     */   
/*     */   private final RouterOptions routerOptions;
/*  50 */   private final AtomicBoolean isHousekeeping = new AtomicBoolean(false);
/*  51 */   private volatile Instant lastHousekeepingTime = Instant.EPOCH;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultRouter(RouterOptions routerOptions) {
/*  59 */     this.routerOptions = routerOptions;
/*  60 */     this.reactorResources = routerOptions.getReactorResources();
/*  61 */     this
/*     */       
/*  63 */       .httpClient = new DiscordWebClient(this.reactorResources.getHttpClient(), routerOptions.getExchangeStrategies(), routerOptions.getAuthorizationScheme(), routerOptions.getToken(), routerOptions.getResponseTransformers(), routerOptions.getDiscordBaseUrl());
/*     */   }
/*     */ 
/*     */   
/*     */   public DiscordWebResponse exchange(DiscordWebRequest request) {
/*  68 */     Sinks.Empty<Void> cancelSink = Sinks.empty();
/*  69 */     return new DiscordWebResponse(Mono.deferContextual(ctx -> {
/*     */             Sinks.One<ClientResponse> callback = Sinks.one();
/*     */             
/*     */             housekeepIfNecessary();
/*     */             
/*     */             BucketKey bucketKey = BucketKey.of(request);
/*     */             RequestStream stream = this.streamMap.computeIfAbsent(bucketKey, ());
/*     */             if (!stream.push(new RequestCorrelation<>(request, callback, ctx, cancelSink))) {
/*     */               callback.emitError(new DiscardedRequestException(request), Sinks.EmitFailureHandler.FAIL_FAST);
/*     */             }
/*     */             return callback.asMono();
/*  80 */           }).doOnCancel(() -> cancelSink.emitEmpty(Sinks.EmitFailureHandler.FAIL_FAST))
/*  81 */         .checkpoint("Request to " + request.getDescription() + " [DefaultRouter]"), this.reactorResources);
/*     */   }
/*     */   
/*     */   private RequestStream createStream(BucketKey bucketKey, DiscordWebRequest request) {
/*  85 */     if (log.isTraceEnabled()) {
/*  86 */       log.trace("Creating RequestStream with key {} for request: {} -> {}", new Object[] { bucketKey, request
/*  87 */             .getRoute().getUriTemplate(), request.getCompleteUri() });
/*     */     }
/*  89 */     RequestStream stream = new RequestStream(bucketKey, this.routerOptions, this.httpClient, HEADER_STRATEGY);
/*  90 */     stream.start();
/*  91 */     return stream;
/*     */   }
/*     */   
/*     */   private void housekeepIfNecessary() {
/*  95 */     Instant now = Instant.now();
/*  96 */     if (this.lastHousekeepingTime.plus(HOUSE_KEEPING_PERIOD).isAfter(now)) {
/*     */       return;
/*     */     }
/*     */     
/* 100 */     tryHousekeep(now);
/*     */   }
/*     */   
/*     */   private void tryHousekeep(Instant now) {
/* 104 */     if (this.isHousekeeping.compareAndSet(false, true)) {
/*     */       try {
/* 106 */         doHousekeep(now);
/*     */       } finally {
/* 108 */         this.lastHousekeepingTime = Instant.now();
/* 109 */         this.isHousekeeping.set(false);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private void doHousekeep(Instant now) {
/* 115 */     this.streamMap.keySet().forEach(key -> this.streamMap.compute(key, ()));
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\request\DefaultRouter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */