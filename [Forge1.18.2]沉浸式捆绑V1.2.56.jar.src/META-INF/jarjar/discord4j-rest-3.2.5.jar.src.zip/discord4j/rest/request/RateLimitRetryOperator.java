/*    */ package discord4j.rest.request;
/*    */ 
/*    */ import discord4j.rest.http.client.ClientException;
/*    */ import io.netty.handler.codec.http.HttpHeaders;
/*    */ import java.time.Duration;
/*    */ import org.reactivestreams.Publisher;
/*    */ import reactor.core.publisher.Flux;
/*    */ import reactor.core.publisher.Mono;
/*    */ import reactor.core.scheduler.Scheduler;
/*    */ import reactor.util.Logger;
/*    */ import reactor.util.Loggers;
/*    */ import reactor.util.context.Context;
/*    */ import reactor.util.function.Tuple2;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RateLimitRetryOperator
/*    */ {
/* 38 */   private static final Logger log = Loggers.getLogger(RateLimitRetryOperator.class);
/*    */   
/*    */   private final Scheduler backoffScheduler;
/*    */   
/*    */   public RateLimitRetryOperator(Scheduler backoffScheduler) {
/* 43 */     this.backoffScheduler = backoffScheduler;
/*    */   }
/*    */   
/*    */   public Publisher<Context> apply(Flux<Throwable> errors) {
/* 47 */     return (Publisher<Context>)errors.index().concatMap(tuple -> retry((Throwable)tuple.getT2(), ((Long)tuple.getT1()).longValue() + 1L));
/*    */   }
/*    */   
/*    */   private Publisher<Context> retry(Throwable error, long iteration) {
/* 51 */     if (!isRateLimitError(error)) {
/* 52 */       return (Publisher<Context>)Mono.error(error);
/*    */     }
/* 54 */     ClientException clientException = (ClientException)error;
/* 55 */     HttpHeaders headers = clientException.getHeaders();
/*    */     try {
/* 57 */       boolean global = Boolean.parseBoolean(headers.get("X-RateLimit-Global"));
/* 58 */       Context context = Context.of("iteration", Long.valueOf(iteration));
/* 59 */       String retryAfter = headers.get("Retry-After");
/* 60 */       String resetAfter = headers.get("X-RateLimit-Reset-After");
/* 61 */       if (global) {
/* 62 */         Duration duration = Duration.ofSeconds(Long.parseLong(retryAfter));
/* 63 */         return (Publisher<Context>)retryMono(duration).thenReturn(context);
/* 64 */       }  if (resetAfter != null) {
/* 65 */         long resetAt = (long)(Double.parseDouble(resetAfter) * 1000.0D);
/* 66 */         Duration duration = Duration.ofMillis(resetAt);
/* 67 */         return (Publisher<Context>)retryMono(duration).thenReturn(context);
/*    */       } 
/* 69 */       Duration fixedBackoff = Duration.ofSeconds(Long.parseLong(retryAfter));
/* 70 */       return (Publisher<Context>)retryMono(fixedBackoff).thenReturn(context);
/*    */     }
/* 72 */     catch (Exception e) {
/* 73 */       log.error("Unable to parse rate limit headers: {}", new Object[] { headers });
/* 74 */       return (Publisher<Context>)Mono.error(e);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   private boolean isRateLimitError(Throwable error) {
/* 80 */     if (error instanceof ClientException) {
/* 81 */       ClientException clientException = (ClientException)error;
/* 82 */       return (clientException.getStatus().code() == 429);
/*    */     } 
/* 84 */     return false;
/*    */   }
/*    */   
/*    */   private Mono<Long> retryMono(Duration delay) {
/* 88 */     if (delay == Duration.ZERO) {
/* 89 */       return Mono.just(Long.valueOf(0L));
/*    */     }
/* 91 */     return Mono.delay(delay, this.backoffScheduler);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-rest-3.2.5.jar!\discord4j\rest\request\RateLimitRetryOperator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */