package com.austinv11.servicer;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({ElementType.TYPE})
@Retention(RetentionPolicy.CLASS)
@Documented
@interface WireServices {
  WireService[] value();
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\Servicer-1.0.3.jar!\com\austinv11\servicer\WireServices.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */