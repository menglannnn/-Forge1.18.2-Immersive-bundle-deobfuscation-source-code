/*     */ package com.austinv11.servicer;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javax.annotation.processing.AbstractProcessor;
/*     */ import javax.annotation.processing.Messager;
/*     */ import javax.annotation.processing.ProcessingEnvironment;
/*     */ import javax.annotation.processing.RoundEnvironment;
/*     */ import javax.annotation.processing.SupportedSourceVersion;
/*     */ import javax.lang.model.SourceVersion;
/*     */ import javax.lang.model.element.Element;
/*     */ import javax.lang.model.type.MirroredTypeException;
/*     */ import javax.lang.model.util.Elements;
/*     */ import javax.tools.Diagnostic;
/*     */ import javax.tools.FileObject;
/*     */ import javax.tools.StandardLocation;
/*     */ 
/*     */ @SupportedSourceVersion(SourceVersion.RELEASE_8)
/*     */ @SupportedAnnotationTypes({"com.austinv11.servicer.WireService"})
/*     */ public class ServicerProcessor extends AbstractProcessor {
/*  28 */   private final Map<String, Services> services = new HashMap<>();
/*     */   private Types typeUtils;
/*     */   private Elements elements;
/*     */   private Filer filer;
/*     */   private Messager messager;
/*     */   
/*     */   public synchronized void init(ProcessingEnvironment processingEnv) {
/*  35 */     super.init(processingEnv);
/*  36 */     this.typeUtils = processingEnv.getTypeUtils();
/*  37 */     this.elements = processingEnv.getElementUtils();
/*  38 */     this.filer = processingEnv.getFiler();
/*  39 */     this.messager = processingEnv.getMessager();
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized boolean process(Set<? extends TypeElement> annotations, RoundEnvironment roundEnv) {
/*  44 */     if (roundEnv.errorRaised()) {
/*  45 */       return false;
/*     */     }
/*     */     
/*  48 */     for (Element annotated : roundEnv.getElementsAnnotatedWith((Class)WireService.class)) {
/*  49 */       if (annotated.getKind() == ElementKind.CLASS) {
/*  50 */         WireService[] serviceAnnotations = annotated.<WireService>getAnnotationsByType(WireService.class);
/*  51 */         for (WireService service : serviceAnnotations) {
/*     */           String serviceName;
/*     */           try {
/*  54 */             serviceName = service.value().getCanonicalName();
/*  55 */           } catch (MirroredTypeException e) {
/*  56 */             serviceName = e.getTypeMirror().toString();
/*     */           } 
/*  58 */           ((Services)this.services.computeIfAbsent(serviceName, name -> new Services())).add(annotated);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/*  63 */     this.messager.printMessage(Diagnostic.Kind.NOTE, "Found " + this.services.size() + " services!\n");
/*     */     
/*  65 */     if (!roundEnv.processingOver()) {
/*  66 */       return true;
/*     */     }
/*  68 */     this.services.forEach((k, s) -> {
/*     */           String serviceLocation = "META-INF/services/" + k;
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           List<String> oldServices = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           try {
/*     */             FileObject fo = this.filer.getResource(StandardLocation.CLASS_OUTPUT, "", serviceLocation);
/*     */ 
/*     */ 
/*     */             
/*     */             try (BufferedReader reader = new BufferedReader(new InputStreamReader(fo.openInputStream(), StandardCharsets.UTF_8))) {
/*     */               reader.lines().map(()).filter(()).forEach(oldServices::add);
/*     */             } 
/*     */ 
/*     */ 
/*     */             
/*     */             fo.delete();
/*  91 */           } catch (Throwable e) {
/*     */             this.messager.printMessage(Diagnostic.Kind.NOTE, serviceLocation + " does not yet exist!\n");
/*     */           } 
/*     */           
/*     */           try {
/*     */             FileObject fo = this.filer.createResource(StandardLocation.CLASS_OUTPUT, "", serviceLocation, s.getElements(this.elements));
/*     */             try (OutputStreamWriter w = new OutputStreamWriter(fo.openOutputStream())) {
/*     */               for (String oldService : oldServices) {
/*     */                 w.append(oldService).append("\n");
/*     */               }
/*     */               for (String impl : s.getImpls()) {
/*     */                 this.messager.printMessage(Diagnostic.Kind.NOTE, "Setting up " + impl + " for use as a " + k + " implementation!\n");
/*     */                 w.append(impl).append("\n");
/*     */               } 
/*     */             } 
/* 106 */           } catch (Throwable e) {
/*     */             this.messager.printMessage(Diagnostic.Kind.NOTE, "Error caught attempting to process services.\n");
/*     */           } 
/*     */         });
/* 110 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public SourceVersion getSupportedSourceVersion() {
/* 115 */     return super.getSupportedSourceVersion();
/*     */   }
/*     */   
/*     */   private static class Services {
/* 119 */     private final Set<String> impls = new HashSet<>();
/*     */     
/*     */     void add(Element annotated) {
/* 122 */       this.impls.add(annotated.asType().toString());
/*     */     }
/*     */     
/*     */     Collection<String> getImpls() {
/* 126 */       return this.impls;
/*     */     }
/*     */     
/*     */     Element[] getElements(Elements elements) {
/* 130 */       return (Element[])this.impls.stream().map(elements::getTypeElement).toArray(x$0 -> new Element[x$0]);
/*     */     }
/*     */     
/*     */     private Services() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\Servicer-1.0.3.jar!\com\austinv11\servicer\ServicerProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */