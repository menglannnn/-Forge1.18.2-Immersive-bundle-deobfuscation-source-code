/*      */ package io.netty.resolver.dns;
/*      */ import io.netty.bootstrap.Bootstrap;
/*      */ import io.netty.buffer.ByteBuf;
/*      */ import io.netty.buffer.Unpooled;
/*      */ import io.netty.channel.AddressedEnvelope;
/*      */ import io.netty.channel.Channel;
/*      */ import io.netty.channel.ChannelFactory;
/*      */ import io.netty.channel.ChannelFuture;
/*      */ import io.netty.channel.ChannelFutureListener;
/*      */ import io.netty.channel.ChannelHandler;
/*      */ import io.netty.channel.ChannelHandlerContext;
/*      */ import io.netty.channel.ChannelInboundHandlerAdapter;
/*      */ import io.netty.channel.ChannelInitializer;
/*      */ import io.netty.channel.ChannelOption;
/*      */ import io.netty.channel.ChannelPromise;
/*      */ import io.netty.channel.EventLoop;
/*      */ import io.netty.channel.EventLoopGroup;
/*      */ import io.netty.channel.FixedRecvByteBufAllocator;
/*      */ import io.netty.channel.RecvByteBufAllocator;
/*      */ import io.netty.channel.socket.DatagramChannel;
/*      */ import io.netty.channel.socket.DatagramPacket;
/*      */ import io.netty.channel.socket.InternetProtocolFamily;
/*      */ import io.netty.channel.socket.SocketChannel;
/*      */ import io.netty.handler.codec.dns.DatagramDnsQueryEncoder;
/*      */ import io.netty.handler.codec.dns.DatagramDnsResponse;
/*      */ import io.netty.handler.codec.dns.DatagramDnsResponseDecoder;
/*      */ import io.netty.handler.codec.dns.DefaultDnsRawRecord;
/*      */ import io.netty.handler.codec.dns.DnsQuestion;
/*      */ import io.netty.handler.codec.dns.DnsRecord;
/*      */ import io.netty.handler.codec.dns.DnsRecordType;
/*      */ import io.netty.handler.codec.dns.DnsResponse;
/*      */ import io.netty.handler.codec.dns.TcpDnsQueryEncoder;
/*      */ import io.netty.handler.codec.dns.TcpDnsResponseDecoder;
/*      */ import io.netty.resolver.HostsFileEntriesResolver;
/*      */ import io.netty.resolver.InetNameResolver;
/*      */ import io.netty.resolver.ResolvedAddressTypes;
/*      */ import io.netty.util.NetUtil;
/*      */ import io.netty.util.ReferenceCounted;
/*      */ import io.netty.util.concurrent.EventExecutor;
/*      */ import io.netty.util.concurrent.FastThreadLocal;
/*      */ import io.netty.util.concurrent.Future;
/*      */ import io.netty.util.concurrent.FutureListener;
/*      */ import io.netty.util.concurrent.GenericFutureListener;
/*      */ import io.netty.util.concurrent.Promise;
/*      */ import io.netty.util.internal.EmptyArrays;
/*      */ import io.netty.util.internal.ObjectUtil;
/*      */ import io.netty.util.internal.PlatformDependent;
/*      */ import io.netty.util.internal.StringUtil;
/*      */ import io.netty.util.internal.logging.InternalLogger;
/*      */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*      */ import java.lang.reflect.Method;
/*      */ import java.net.IDN;
/*      */ import java.net.InetAddress;
/*      */ import java.net.InetSocketAddress;
/*      */ import java.net.NetworkInterface;
/*      */ import java.net.SocketAddress;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Comparator;
/*      */ import java.util.Enumeration;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.concurrent.TimeUnit;
/*      */ 
/*      */ public class DnsNameResolver extends InetNameResolver {
/*      */   private static final InternalLogger logger;
/*      */   private static final String LOCALHOST = "localhost";
/*      */   private static final String WINDOWS_HOST_NAME;
/*      */   private static final InetAddress LOCALHOST_ADDRESS;
/*      */   private static final DnsRecord[] EMPTY_ADDITIONALS;
/*      */   private static final DnsRecordType[] IPV4_ONLY_RESOLVED_RECORD_TYPES;
/*      */   private static final InternetProtocolFamily[] IPV4_ONLY_RESOLVED_PROTOCOL_FAMILIES;
/*      */   private static final DnsRecordType[] IPV4_PREFERRED_RESOLVED_RECORD_TYPES;
/*      */   private static final InternetProtocolFamily[] IPV4_PREFERRED_RESOLVED_PROTOCOL_FAMILIES;
/*      */   private static final DnsRecordType[] IPV6_ONLY_RESOLVED_RECORD_TYPES;
/*      */   private static final InternetProtocolFamily[] IPV6_ONLY_RESOLVED_PROTOCOL_FAMILIES;
/*      */   private static final DnsRecordType[] IPV6_PREFERRED_RESOLVED_RECORD_TYPES;
/*      */   private static final InternetProtocolFamily[] IPV6_PREFERRED_RESOLVED_PROTOCOL_FAMILIES;
/*      */   static final ResolvedAddressTypes DEFAULT_RESOLVE_ADDRESS_TYPES;
/*      */   static final String[] DEFAULT_SEARCH_DOMAINS;
/*      */   private static final UnixResolverOptions DEFAULT_OPTIONS;
/*      */   private static final DatagramDnsResponseDecoder DATAGRAM_DECODER;
/*      */   private static final DatagramDnsQueryEncoder DATAGRAM_ENCODER;
/*      */   private static final TcpDnsQueryEncoder TCP_ENCODER;
/*      */   final Promise<Channel> channelReadyPromise;
/*      */   final Channel ch;
/*      */   private final Comparator<InetSocketAddress> nameServerComparator;
/*      */   final DnsQueryContextManager queryContextManager;
/*      */   private final DnsCache resolveCache;
/*      */   
/*      */   static {
/*   95 */     logger = InternalLoggerFactory.getInstance(DnsNameResolver.class);
/*      */ 
/*      */ 
/*      */     
/*   99 */     EMPTY_ADDITIONALS = new DnsRecord[0];
/*  100 */     IPV4_ONLY_RESOLVED_RECORD_TYPES = new DnsRecordType[] { DnsRecordType.A };
/*      */     
/*  102 */     IPV4_ONLY_RESOLVED_PROTOCOL_FAMILIES = new InternetProtocolFamily[] { InternetProtocolFamily.IPv4 };
/*      */     
/*  104 */     IPV4_PREFERRED_RESOLVED_RECORD_TYPES = new DnsRecordType[] { DnsRecordType.A, DnsRecordType.AAAA };
/*      */     
/*  106 */     IPV4_PREFERRED_RESOLVED_PROTOCOL_FAMILIES = new InternetProtocolFamily[] { InternetProtocolFamily.IPv4, InternetProtocolFamily.IPv6 };
/*      */     
/*  108 */     IPV6_ONLY_RESOLVED_RECORD_TYPES = new DnsRecordType[] { DnsRecordType.AAAA };
/*      */     
/*  110 */     IPV6_ONLY_RESOLVED_PROTOCOL_FAMILIES = new InternetProtocolFamily[] { InternetProtocolFamily.IPv6 };
/*      */     
/*  112 */     IPV6_PREFERRED_RESOLVED_RECORD_TYPES = new DnsRecordType[] { DnsRecordType.AAAA, DnsRecordType.A };
/*      */     
/*  114 */     IPV6_PREFERRED_RESOLVED_PROTOCOL_FAMILIES = new InternetProtocolFamily[] { InternetProtocolFamily.IPv6, InternetProtocolFamily.IPv4 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  122 */     if (NetUtil.isIpV4StackPreferred() || !anyInterfaceSupportsIpV6()) {
/*  123 */       DEFAULT_RESOLVE_ADDRESS_TYPES = ResolvedAddressTypes.IPV4_ONLY;
/*  124 */       LOCALHOST_ADDRESS = NetUtil.LOCALHOST4;
/*      */     }
/*  126 */     else if (NetUtil.isIpV6AddressesPreferred()) {
/*  127 */       DEFAULT_RESOLVE_ADDRESS_TYPES = ResolvedAddressTypes.IPV6_PREFERRED;
/*  128 */       LOCALHOST_ADDRESS = NetUtil.LOCALHOST6;
/*      */     } else {
/*  130 */       DEFAULT_RESOLVE_ADDRESS_TYPES = ResolvedAddressTypes.IPV4_PREFERRED;
/*  131 */       LOCALHOST_ADDRESS = NetUtil.LOCALHOST4;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  137 */       hostName = PlatformDependent.isWindows() ? InetAddress.getLocalHost().getHostName() : null;
/*  138 */     } catch (Exception ignore) {
/*  139 */       hostName = null;
/*      */     } 
/*  141 */     WINDOWS_HOST_NAME = hostName;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  149 */       List<String> list = PlatformDependent.isWindows() ? getSearchDomainsHack() : UnixResolverDnsServerAddressStreamProvider.parseEtcResolverSearchDomains();
/*  150 */       searchDomains = list.<String>toArray(new String[0]);
/*  151 */     } catch (Exception ignore) {
/*      */       
/*  153 */       searchDomains = EmptyArrays.EMPTY_STRINGS;
/*      */     } 
/*  155 */     DEFAULT_SEARCH_DOMAINS = searchDomains;
/*      */ 
/*      */     
/*      */     try {
/*  159 */       options = UnixResolverDnsServerAddressStreamProvider.parseEtcResolverOptions();
/*  160 */     } catch (Exception ignore) {
/*  161 */       options = UnixResolverOptions.newBuilder().build();
/*      */     } 
/*  163 */     DEFAULT_OPTIONS = options;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  200 */     DATAGRAM_DECODER = new DatagramDnsResponseDecoder()
/*      */       {
/*      */         protected DnsResponse decodeResponse(ChannelHandlerContext ctx, DatagramPacket packet) throws Exception {
/*  203 */           DnsResponse response = super.decodeResponse(ctx, packet);
/*  204 */           if (((ByteBuf)packet.content()).isReadable()) {
/*      */ 
/*      */ 
/*      */             
/*  208 */             response.setTruncated(true);
/*      */             
/*  210 */             if (DnsNameResolver.logger.isDebugEnabled()) {
/*  211 */               DnsNameResolver.logger.debug("{} RECEIVED: UDP truncated packet received, consider adjusting maxPayloadSize for the {}.", ctx
/*      */                   
/*  213 */                   .channel(), StringUtil.simpleClassName(DnsNameResolver.class));
/*      */             }
/*      */           } 
/*  216 */           return response;
/*      */         }
/*      */       };
/*  219 */     DATAGRAM_ENCODER = new DatagramDnsQueryEncoder();
/*  220 */     TCP_ENCODER = new TcpDnsQueryEncoder();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final AuthoritativeDnsServerCache authoritativeDnsServerCache;
/*      */ 
/*      */   
/*      */   private final DnsCnameCache cnameCache;
/*      */ 
/*      */   
/*      */   private final FastThreadLocal<DnsServerAddressStream> nameServerAddrStream;
/*      */ 
/*      */   
/*      */   private final long queryTimeoutMillis;
/*      */ 
/*      */   
/*      */   private final int maxQueriesPerResolve;
/*      */ 
/*      */   
/*      */   private final ResolvedAddressTypes resolvedAddressTypes;
/*      */ 
/*      */   
/*      */   private final InternetProtocolFamily[] resolvedInternetProtocolFamilies;
/*      */ 
/*      */   
/*      */   private final boolean recursionDesired;
/*      */   
/*      */   private final int maxPayloadSize;
/*      */   
/*      */   private final boolean optResourceEnabled;
/*      */   
/*      */   private final HostsFileEntriesResolver hostsFileEntriesResolver;
/*      */   
/*      */   private final DnsServerAddressStreamProvider dnsServerAddressStreamProvider;
/*      */   
/*      */   private final String[] searchDomains;
/*      */   
/*      */   private final int ndots;
/*      */   
/*      */   private final boolean supportsAAAARecords;
/*      */   
/*      */   private final boolean supportsARecords;
/*      */   
/*      */   private final InternetProtocolFamily preferredAddressType;
/*      */   
/*      */   private final DnsRecordType[] resolveRecordTypes;
/*      */   
/*      */   private final boolean decodeIdn;
/*      */   
/*      */   private final DnsQueryLifecycleObserverFactory dnsQueryLifecycleObserverFactory;
/*      */   
/*      */   private final boolean completeOncePreferredResolved;
/*      */   
/*      */   private final ChannelFactory<? extends SocketChannel> socketChannelFactory;
/*      */   
/*      */   private final int maxNumConsolidation;
/*      */   
/*      */   private final Map<String, Future<List<InetAddress>>> inflightLookups;
/*      */ 
/*      */   
/*      */   static {
/*      */     String hostName, searchDomains[];
/*      */     UnixResolverOptions options;
/*      */   }
/*      */ 
/*      */   
/*      */   private static boolean anyInterfaceSupportsIpV6() {
/*      */     for (NetworkInterface iface : NetUtil.NETWORK_INTERFACES) {
/*      */       Enumeration<InetAddress> addresses = iface.getInetAddresses();
/*      */       while (addresses.hasMoreElements()) {
/*      */         InetAddress inetAddress = addresses.nextElement();
/*      */         if (inetAddress instanceof java.net.Inet6Address && !inetAddress.isAnyLocalAddress() && !inetAddress.isLoopbackAddress() && !inetAddress.isLinkLocalAddress()) {
/*      */           return true;
/*      */         }
/*      */       } 
/*      */     } 
/*      */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private static List<String> getSearchDomainsHack() throws Exception {
/*      */     if (PlatformDependent.javaVersion() < 9) {
/*      */       Class<?> configClass = Class.forName("sun.net.dns.ResolverConfiguration");
/*      */       Method open = configClass.getMethod("open", new Class[0]);
/*      */       Method nameservers = configClass.getMethod("searchlist", new Class[0]);
/*      */       Object instance = open.invoke(null, new Object[0]);
/*      */       return (List<String>)nameservers.invoke(instance, new Object[0]);
/*      */     } 
/*      */     return Collections.emptyList();
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public DnsNameResolver(EventLoop eventLoop, ChannelFactory<? extends DatagramChannel> channelFactory, DnsCache resolveCache, DnsCache authoritativeDnsServerCache, DnsQueryLifecycleObserverFactory dnsQueryLifecycleObserverFactory, long queryTimeoutMillis, ResolvedAddressTypes resolvedAddressTypes, boolean recursionDesired, int maxQueriesPerResolve, boolean traceEnabled, int maxPayloadSize, boolean optResourceEnabled, HostsFileEntriesResolver hostsFileEntriesResolver, DnsServerAddressStreamProvider dnsServerAddressStreamProvider, String[] searchDomains, int ndots, boolean decodeIdn) {
/*  315 */     this(eventLoop, channelFactory, resolveCache, new AuthoritativeDnsServerCacheAdapter(authoritativeDnsServerCache), dnsQueryLifecycleObserverFactory, queryTimeoutMillis, resolvedAddressTypes, recursionDesired, maxQueriesPerResolve, traceEnabled, maxPayloadSize, optResourceEnabled, hostsFileEntriesResolver, dnsServerAddressStreamProvider, searchDomains, ndots, decodeIdn);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public DnsNameResolver(EventLoop eventLoop, ChannelFactory<? extends DatagramChannel> channelFactory, DnsCache resolveCache, AuthoritativeDnsServerCache authoritativeDnsServerCache, DnsQueryLifecycleObserverFactory dnsQueryLifecycleObserverFactory, long queryTimeoutMillis, ResolvedAddressTypes resolvedAddressTypes, boolean recursionDesired, int maxQueriesPerResolve, boolean traceEnabled, int maxPayloadSize, boolean optResourceEnabled, HostsFileEntriesResolver hostsFileEntriesResolver, DnsServerAddressStreamProvider dnsServerAddressStreamProvider, String[] searchDomains, int ndots, boolean decodeIdn) {
/*  367 */     this(eventLoop, channelFactory, null, resolveCache, NoopDnsCnameCache.INSTANCE, authoritativeDnsServerCache, dnsQueryLifecycleObserverFactory, queryTimeoutMillis, resolvedAddressTypes, recursionDesired, maxQueriesPerResolve, traceEnabled, maxPayloadSize, optResourceEnabled, hostsFileEntriesResolver, dnsServerAddressStreamProvider, searchDomains, ndots, decodeIdn, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   DnsNameResolver(EventLoop eventLoop, ChannelFactory<? extends DatagramChannel> channelFactory, ChannelFactory<? extends SocketChannel> socketChannelFactory, DnsCache resolveCache, DnsCnameCache cnameCache, AuthoritativeDnsServerCache authoritativeDnsServerCache, DnsQueryLifecycleObserverFactory dnsQueryLifecycleObserverFactory, long queryTimeoutMillis, ResolvedAddressTypes resolvedAddressTypes, boolean recursionDesired, int maxQueriesPerResolve, boolean traceEnabled, int maxPayloadSize, boolean optResourceEnabled, HostsFileEntriesResolver hostsFileEntriesResolver, DnsServerAddressStreamProvider dnsServerAddressStreamProvider, String[] searchDomains, int ndots, boolean decodeIdn, boolean completeOncePreferredResolved) {
/*  394 */     this(eventLoop, channelFactory, socketChannelFactory, resolveCache, cnameCache, authoritativeDnsServerCache, null, dnsQueryLifecycleObserverFactory, queryTimeoutMillis, resolvedAddressTypes, recursionDesired, maxQueriesPerResolve, traceEnabled, maxPayloadSize, optResourceEnabled, hostsFileEntriesResolver, dnsServerAddressStreamProvider, searchDomains, ndots, decodeIdn, completeOncePreferredResolved, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   DnsNameResolver(EventLoop eventLoop, ChannelFactory<? extends DatagramChannel> channelFactory, ChannelFactory<? extends SocketChannel> socketChannelFactory, final DnsCache resolveCache, final DnsCnameCache cnameCache, final AuthoritativeDnsServerCache authoritativeDnsServerCache, SocketAddress localAddress, DnsQueryLifecycleObserverFactory dnsQueryLifecycleObserverFactory, long queryTimeoutMillis, ResolvedAddressTypes resolvedAddressTypes, boolean recursionDesired, int maxQueriesPerResolve, boolean traceEnabled, int maxPayloadSize, boolean optResourceEnabled, HostsFileEntriesResolver hostsFileEntriesResolver, DnsServerAddressStreamProvider dnsServerAddressStreamProvider, String[] searchDomains, int ndots, boolean decodeIdn, boolean completeOncePreferredResolved, int maxNumConsolidation) {
/*  424 */     super((EventExecutor)eventLoop); ChannelFuture future; this.queryContextManager = new DnsQueryContextManager(); this.nameServerAddrStream = new FastThreadLocal<DnsServerAddressStream>() { protected DnsServerAddressStream initialValue() { return DnsNameResolver.this.dnsServerAddressStreamProvider.nameServerAddressStream(""); } }
/*  425 */       ; this
/*      */       
/*  427 */       .queryTimeoutMillis = (queryTimeoutMillis > 0L) ? queryTimeoutMillis : TimeUnit.SECONDS.toMillis(DEFAULT_OPTIONS.timeout());
/*  428 */     this.resolvedAddressTypes = (resolvedAddressTypes != null) ? resolvedAddressTypes : DEFAULT_RESOLVE_ADDRESS_TYPES;
/*  429 */     this.recursionDesired = recursionDesired;
/*  430 */     this.maxQueriesPerResolve = (maxQueriesPerResolve > 0) ? maxQueriesPerResolve : DEFAULT_OPTIONS.attempts();
/*  431 */     this.maxPayloadSize = ObjectUtil.checkPositive(maxPayloadSize, "maxPayloadSize");
/*  432 */     this.optResourceEnabled = optResourceEnabled;
/*  433 */     this.hostsFileEntriesResolver = (HostsFileEntriesResolver)ObjectUtil.checkNotNull(hostsFileEntriesResolver, "hostsFileEntriesResolver");
/*  434 */     this
/*  435 */       .dnsServerAddressStreamProvider = (DnsServerAddressStreamProvider)ObjectUtil.checkNotNull(dnsServerAddressStreamProvider, "dnsServerAddressStreamProvider");
/*  436 */     this.resolveCache = (DnsCache)ObjectUtil.checkNotNull(resolveCache, "resolveCache");
/*  437 */     this.cnameCache = (DnsCnameCache)ObjectUtil.checkNotNull(cnameCache, "cnameCache");
/*  438 */     this
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  443 */       .dnsQueryLifecycleObserverFactory = traceEnabled ? ((dnsQueryLifecycleObserverFactory instanceof NoopDnsQueryLifecycleObserverFactory) ? new LoggingDnsQueryLifeCycleObserverFactory() : new BiDnsQueryLifecycleObserverFactory(new LoggingDnsQueryLifeCycleObserverFactory(), dnsQueryLifecycleObserverFactory)) : (DnsQueryLifecycleObserverFactory)ObjectUtil.checkNotNull(dnsQueryLifecycleObserverFactory, "dnsQueryLifecycleObserverFactory");
/*  444 */     this.searchDomains = (searchDomains != null) ? (String[])searchDomains.clone() : DEFAULT_SEARCH_DOMAINS;
/*  445 */     this.ndots = (ndots >= 0) ? ndots : DEFAULT_OPTIONS.ndots();
/*  446 */     this.decodeIdn = decodeIdn;
/*  447 */     this.completeOncePreferredResolved = completeOncePreferredResolved;
/*  448 */     this.socketChannelFactory = socketChannelFactory;
/*  449 */     switch (this.resolvedAddressTypes) {
/*      */       case IPV4_ONLY:
/*  451 */         this.supportsAAAARecords = false;
/*  452 */         this.supportsARecords = true;
/*  453 */         this.resolveRecordTypes = IPV4_ONLY_RESOLVED_RECORD_TYPES;
/*  454 */         this.resolvedInternetProtocolFamilies = IPV4_ONLY_RESOLVED_PROTOCOL_FAMILIES;
/*      */         break;
/*      */       case IPV4_PREFERRED:
/*  457 */         this.supportsAAAARecords = true;
/*  458 */         this.supportsARecords = true;
/*  459 */         this.resolveRecordTypes = IPV4_PREFERRED_RESOLVED_RECORD_TYPES;
/*  460 */         this.resolvedInternetProtocolFamilies = IPV4_PREFERRED_RESOLVED_PROTOCOL_FAMILIES;
/*      */         break;
/*      */       case IPV6_ONLY:
/*  463 */         this.supportsAAAARecords = true;
/*  464 */         this.supportsARecords = false;
/*  465 */         this.resolveRecordTypes = IPV6_ONLY_RESOLVED_RECORD_TYPES;
/*  466 */         this.resolvedInternetProtocolFamilies = IPV6_ONLY_RESOLVED_PROTOCOL_FAMILIES;
/*      */         break;
/*      */       case IPV6_PREFERRED:
/*  469 */         this.supportsAAAARecords = true;
/*  470 */         this.supportsARecords = true;
/*  471 */         this.resolveRecordTypes = IPV6_PREFERRED_RESOLVED_RECORD_TYPES;
/*  472 */         this.resolvedInternetProtocolFamilies = IPV6_PREFERRED_RESOLVED_PROTOCOL_FAMILIES;
/*      */         break;
/*      */       default:
/*  475 */         throw new IllegalArgumentException("Unknown ResolvedAddressTypes " + resolvedAddressTypes);
/*      */     } 
/*  477 */     this.preferredAddressType = preferredAddressType(this.resolvedAddressTypes);
/*  478 */     this.authoritativeDnsServerCache = (AuthoritativeDnsServerCache)ObjectUtil.checkNotNull(authoritativeDnsServerCache, "authoritativeDnsServerCache");
/*  479 */     this.nameServerComparator = new NameServerComparator(this.preferredAddressType.addressType());
/*  480 */     this.maxNumConsolidation = maxNumConsolidation;
/*  481 */     if (maxNumConsolidation > 0) {
/*  482 */       this.inflightLookups = new HashMap<String, Future<List<InetAddress>>>();
/*      */     } else {
/*  484 */       this.inflightLookups = null;
/*      */     } 
/*      */     
/*  487 */     Bootstrap b = new Bootstrap();
/*  488 */     b.group((EventLoopGroup)executor());
/*  489 */     b.channelFactory(channelFactory);
/*  490 */     this.channelReadyPromise = executor().newPromise();
/*  491 */     final DnsResponseHandler responseHandler = new DnsResponseHandler(this.channelReadyPromise);
/*      */     
/*  493 */     b.handler((ChannelHandler)new ChannelInitializer<DatagramChannel>()
/*      */         {
/*      */           protected void initChannel(DatagramChannel ch) {
/*  496 */             ch.pipeline().addLast(new ChannelHandler[] { (ChannelHandler)DnsNameResolver.access$200(), (ChannelHandler)DnsNameResolver.access$300(), (ChannelHandler)this.val$responseHandler });
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  501 */     if (localAddress == null) {
/*  502 */       b.option(ChannelOption.DATAGRAM_CHANNEL_ACTIVE_ON_REGISTRATION, Boolean.valueOf(true));
/*  503 */       future = b.register();
/*      */     } else {
/*  505 */       future = b.bind(localAddress);
/*      */     } 
/*  507 */     if (future.isDone()) {
/*  508 */       Throwable cause = future.cause();
/*  509 */       if (cause != null) {
/*  510 */         if (cause instanceof RuntimeException) {
/*  511 */           throw (RuntimeException)cause;
/*      */         }
/*  513 */         if (cause instanceof Error) {
/*  514 */           throw (Error)cause;
/*      */         }
/*  516 */         throw new IllegalStateException("Unable to create / register Channel", cause);
/*      */       } 
/*      */     } else {
/*  519 */       future.addListener((GenericFutureListener)new ChannelFutureListener()
/*      */           {
/*      */             public void operationComplete(ChannelFuture future) {
/*  522 */               Throwable cause = future.cause();
/*  523 */               if (cause != null) {
/*  524 */                 DnsNameResolver.this.channelReadyPromise.tryFailure(cause);
/*      */               }
/*      */             }
/*      */           });
/*      */     } 
/*  529 */     this.ch = future.channel();
/*  530 */     this.ch.config().setRecvByteBufAllocator((RecvByteBufAllocator)new FixedRecvByteBufAllocator(maxPayloadSize));
/*      */     
/*  532 */     this.ch.closeFuture().addListener((GenericFutureListener)new ChannelFutureListener()
/*      */         {
/*      */           public void operationComplete(ChannelFuture future) {
/*  535 */             resolveCache.clear();
/*  536 */             cnameCache.clear();
/*  537 */             authoritativeDnsServerCache.clear();
/*      */           }
/*      */         });
/*      */   }
/*      */   
/*      */   static InternetProtocolFamily preferredAddressType(ResolvedAddressTypes resolvedAddressTypes) {
/*  543 */     switch (resolvedAddressTypes) {
/*      */       case IPV4_ONLY:
/*      */       case IPV4_PREFERRED:
/*  546 */         return InternetProtocolFamily.IPv4;
/*      */       case IPV6_ONLY:
/*      */       case IPV6_PREFERRED:
/*  549 */         return InternetProtocolFamily.IPv6;
/*      */     } 
/*  551 */     throw new IllegalArgumentException("Unknown ResolvedAddressTypes " + resolvedAddressTypes);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   InetSocketAddress newRedirectServerAddress(InetAddress server) {
/*  557 */     return new InetSocketAddress(server, 53);
/*      */   }
/*      */   
/*      */   final DnsQueryLifecycleObserverFactory dnsQueryLifecycleObserverFactory() {
/*  561 */     return this.dnsQueryLifecycleObserverFactory;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected DnsServerAddressStream newRedirectDnsServerStream(String hostname, List<InetSocketAddress> nameservers) {
/*  577 */     DnsServerAddressStream cached = authoritativeDnsServerCache().get(hostname);
/*  578 */     if (cached == null || cached.size() == 0) {
/*      */ 
/*      */       
/*  581 */       Collections.sort(nameservers, this.nameServerComparator);
/*  582 */       return new SequentialDnsServerAddressStream(nameservers, 0);
/*      */     } 
/*  584 */     return cached;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DnsCache resolveCache() {
/*  591 */     return this.resolveCache;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DnsCnameCache cnameCache() {
/*  598 */     return this.cnameCache;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AuthoritativeDnsServerCache authoritativeDnsServerCache() {
/*  605 */     return this.authoritativeDnsServerCache;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long queryTimeoutMillis() {
/*  613 */     return this.queryTimeoutMillis;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResolvedAddressTypes resolvedAddressTypes() {
/*  621 */     return this.resolvedAddressTypes;
/*      */   }
/*      */   
/*      */   InternetProtocolFamily[] resolvedInternetProtocolFamiliesUnsafe() {
/*  625 */     return this.resolvedInternetProtocolFamilies;
/*      */   }
/*      */   
/*      */   final String[] searchDomains() {
/*  629 */     return this.searchDomains;
/*      */   }
/*      */   
/*      */   final int ndots() {
/*  633 */     return this.ndots;
/*      */   }
/*      */   
/*      */   final boolean supportsAAAARecords() {
/*  637 */     return this.supportsAAAARecords;
/*      */   }
/*      */   
/*      */   final boolean supportsARecords() {
/*  641 */     return this.supportsARecords;
/*      */   }
/*      */   
/*      */   final InternetProtocolFamily preferredAddressType() {
/*  645 */     return this.preferredAddressType;
/*      */   }
/*      */   
/*      */   final DnsRecordType[] resolveRecordTypes() {
/*  649 */     return this.resolveRecordTypes;
/*      */   }
/*      */   
/*      */   final boolean isDecodeIdn() {
/*  653 */     return this.decodeIdn;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isRecursionDesired() {
/*  661 */     return this.recursionDesired;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int maxQueriesPerResolve() {
/*  669 */     return this.maxQueriesPerResolve;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int maxPayloadSize() {
/*  676 */     return this.maxPayloadSize;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isOptResourceEnabled() {
/*  684 */     return this.optResourceEnabled;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HostsFileEntriesResolver hostsFileEntriesResolver() {
/*  692 */     return this.hostsFileEntriesResolver;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void close() {
/*  702 */     if (this.ch.isOpen()) {
/*  703 */       this.ch.close();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   protected EventLoop executor() {
/*  709 */     return (EventLoop)super.executor();
/*      */   }
/*      */   
/*      */   private InetAddress resolveHostsFileEntry(String hostname) {
/*  713 */     if (this.hostsFileEntriesResolver == null) {
/*  714 */       return null;
/*      */     }
/*  716 */     InetAddress address = this.hostsFileEntriesResolver.address(hostname, this.resolvedAddressTypes);
/*  717 */     return (address == null && isLocalWindowsHost(hostname)) ? LOCALHOST_ADDRESS : address;
/*      */   }
/*      */   private List<InetAddress> resolveHostsFileEntries(String hostname) {
/*      */     List<InetAddress> addresses;
/*  721 */     if (this.hostsFileEntriesResolver == null) {
/*  722 */       return null;
/*      */     }
/*      */     
/*  725 */     if (this.hostsFileEntriesResolver instanceof DefaultHostsFileEntriesResolver) {
/*      */       
/*  727 */       addresses = ((DefaultHostsFileEntriesResolver)this.hostsFileEntriesResolver).addresses(hostname, this.resolvedAddressTypes);
/*      */     } else {
/*  729 */       InetAddress address = this.hostsFileEntriesResolver.address(hostname, this.resolvedAddressTypes);
/*  730 */       addresses = (address != null) ? Collections.<InetAddress>singletonList(address) : null;
/*      */     } 
/*  732 */     return (addresses == null && isLocalWindowsHost(hostname)) ? 
/*  733 */       Collections.<InetAddress>singletonList(LOCALHOST_ADDRESS) : addresses;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean isLocalWindowsHost(String hostname) {
/*  744 */     return (PlatformDependent.isWindows() && ("localhost"
/*  745 */       .equalsIgnoreCase(hostname) || (WINDOWS_HOST_NAME != null && WINDOWS_HOST_NAME
/*  746 */       .equalsIgnoreCase(hostname))));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Future<InetAddress> resolve(String inetHost, Iterable<DnsRecord> additionals) {
/*  758 */     return resolve(inetHost, additionals, executor().newPromise());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Future<InetAddress> resolve(String inetHost, Iterable<DnsRecord> additionals, Promise<InetAddress> promise) {
/*  772 */     ObjectUtil.checkNotNull(promise, "promise");
/*  773 */     DnsRecord[] additionalsArray = toArray(additionals, true);
/*      */     try {
/*  775 */       doResolve(inetHost, additionalsArray, promise, this.resolveCache);
/*  776 */       return (Future<InetAddress>)promise;
/*  777 */     } catch (Exception e) {
/*  778 */       return (Future<InetAddress>)promise.setFailure(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Future<List<InetAddress>> resolveAll(String inetHost, Iterable<DnsRecord> additionals) {
/*  791 */     return resolveAll(inetHost, additionals, executor().newPromise());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Future<List<InetAddress>> resolveAll(String inetHost, Iterable<DnsRecord> additionals, Promise<List<InetAddress>> promise) {
/*  805 */     ObjectUtil.checkNotNull(promise, "promise");
/*  806 */     DnsRecord[] additionalsArray = toArray(additionals, true);
/*      */     try {
/*  808 */       doResolveAll(inetHost, additionalsArray, promise, this.resolveCache);
/*  809 */       return (Future<List<InetAddress>>)promise;
/*  810 */     } catch (Exception e) {
/*  811 */       return (Future<List<InetAddress>>)promise.setFailure(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void doResolve(String inetHost, Promise<InetAddress> promise) throws Exception {
/*  817 */     doResolve(inetHost, EMPTY_ADDITIONALS, promise, this.resolveCache);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Future<List<DnsRecord>> resolveAll(DnsQuestion question) {
/*  832 */     return resolveAll(question, EMPTY_ADDITIONALS, executor().newPromise());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Future<List<DnsRecord>> resolveAll(DnsQuestion question, Iterable<DnsRecord> additionals) {
/*  848 */     return resolveAll(question, additionals, executor().newPromise());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Future<List<DnsRecord>> resolveAll(DnsQuestion question, Iterable<DnsRecord> additionals, Promise<List<DnsRecord>> promise) {
/*  866 */     DnsRecord[] additionalsArray = toArray(additionals, true);
/*  867 */     return resolveAll(question, additionalsArray, promise);
/*      */   }
/*      */ 
/*      */   
/*      */   private Future<List<DnsRecord>> resolveAll(DnsQuestion question, DnsRecord[] additionals, Promise<List<DnsRecord>> promise) {
/*  872 */     ObjectUtil.checkNotNull(question, "question");
/*  873 */     ObjectUtil.checkNotNull(promise, "promise");
/*      */ 
/*      */     
/*  876 */     DnsRecordType type = question.type();
/*  877 */     String hostname = question.name();
/*      */     
/*  879 */     if (type == DnsRecordType.A || type == DnsRecordType.AAAA) {
/*  880 */       List<InetAddress> hostsFileEntries = resolveHostsFileEntries(hostname);
/*  881 */       if (hostsFileEntries != null) {
/*  882 */         List<DnsRecord> result = new ArrayList<DnsRecord>();
/*  883 */         for (InetAddress hostsFileEntry : hostsFileEntries) {
/*  884 */           ByteBuf content = null;
/*  885 */           if (hostsFileEntry instanceof java.net.Inet4Address) {
/*  886 */             if (type == DnsRecordType.A) {
/*  887 */               content = Unpooled.wrappedBuffer(hostsFileEntry.getAddress());
/*      */             }
/*  889 */           } else if (hostsFileEntry instanceof java.net.Inet6Address && 
/*  890 */             type == DnsRecordType.AAAA) {
/*  891 */             content = Unpooled.wrappedBuffer(hostsFileEntry.getAddress());
/*      */           } 
/*      */           
/*  894 */           if (content != null)
/*      */           {
/*      */             
/*  897 */             result.add(new DefaultDnsRawRecord(hostname, type, 86400L, content));
/*      */           }
/*      */         } 
/*      */         
/*  901 */         if (!result.isEmpty()) {
/*  902 */           trySuccess(promise, result);
/*  903 */           return (Future<List<DnsRecord>>)promise;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  910 */     DnsServerAddressStream nameServerAddrs = this.dnsServerAddressStreamProvider.nameServerAddressStream(hostname);
/*  911 */     (new DnsRecordResolveContext(this, promise, question, additionals, nameServerAddrs, this.maxQueriesPerResolve))
/*  912 */       .resolve(promise);
/*  913 */     return (Future<List<DnsRecord>>)promise;
/*      */   }
/*      */   
/*      */   private static DnsRecord[] toArray(Iterable<DnsRecord> additionals, boolean validateType) {
/*  917 */     ObjectUtil.checkNotNull(additionals, "additionals");
/*  918 */     if (additionals instanceof Collection) {
/*  919 */       Collection<DnsRecord> collection = (Collection<DnsRecord>)additionals;
/*  920 */       for (DnsRecord r : additionals) {
/*  921 */         validateAdditional(r, validateType);
/*      */       }
/*  923 */       return collection.<DnsRecord>toArray(new DnsRecord[collection.size()]);
/*      */     } 
/*      */     
/*  926 */     Iterator<DnsRecord> additionalsIt = additionals.iterator();
/*  927 */     if (!additionalsIt.hasNext()) {
/*  928 */       return EMPTY_ADDITIONALS;
/*      */     }
/*  930 */     List<DnsRecord> records = new ArrayList<DnsRecord>();
/*      */     do {
/*  932 */       DnsRecord r = additionalsIt.next();
/*  933 */       validateAdditional(r, validateType);
/*  934 */       records.add(r);
/*  935 */     } while (additionalsIt.hasNext());
/*      */     
/*  937 */     return records.<DnsRecord>toArray(new DnsRecord[records.size()]);
/*      */   }
/*      */   
/*      */   private static void validateAdditional(DnsRecord record, boolean validateType) {
/*  941 */     ObjectUtil.checkNotNull(record, "record");
/*  942 */     if (validateType && record instanceof io.netty.handler.codec.dns.DnsRawRecord) {
/*  943 */       throw new IllegalArgumentException("DnsRawRecord implementations not allowed: " + record);
/*      */     }
/*      */   }
/*      */   
/*      */   private InetAddress loopbackAddress() {
/*  948 */     return preferredAddressType().localhost();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doResolve(String inetHost, DnsRecord[] additionals, Promise<InetAddress> promise, DnsCache resolveCache) throws Exception {
/*  959 */     if (inetHost == null || inetHost.isEmpty()) {
/*      */       
/*  961 */       promise.setSuccess(loopbackAddress());
/*      */       return;
/*      */     } 
/*  964 */     InetAddress address = NetUtil.createInetAddressFromIpAddressString(inetHost);
/*  965 */     if (address != null) {
/*      */       
/*  967 */       promise.setSuccess(address);
/*      */       
/*      */       return;
/*      */     } 
/*  971 */     String hostname = hostname(inetHost);
/*      */     
/*  973 */     InetAddress hostsFileEntry = resolveHostsFileEntry(hostname);
/*  974 */     if (hostsFileEntry != null) {
/*  975 */       promise.setSuccess(hostsFileEntry);
/*      */       
/*      */       return;
/*      */     } 
/*  979 */     if (!doResolveCached(hostname, additionals, promise, resolveCache)) {
/*  980 */       doResolveUncached(hostname, additionals, promise, resolveCache, this.completeOncePreferredResolved);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean doResolveCached(String hostname, DnsRecord[] additionals, Promise<InetAddress> promise, DnsCache resolveCache) {
/*  988 */     List<? extends DnsCacheEntry> cachedEntries = resolveCache.get(hostname, additionals);
/*  989 */     if (cachedEntries == null || cachedEntries.isEmpty()) {
/*  990 */       return false;
/*      */     }
/*      */     
/*  993 */     Throwable cause = ((DnsCacheEntry)cachedEntries.get(0)).cause();
/*  994 */     if (cause == null) {
/*  995 */       int numEntries = cachedEntries.size();
/*      */       
/*  997 */       for (InternetProtocolFamily f : this.resolvedInternetProtocolFamilies) {
/*  998 */         for (int i = 0; i < numEntries; i++) {
/*  999 */           DnsCacheEntry e = cachedEntries.get(i);
/* 1000 */           if (f.addressType().isInstance(e.address())) {
/* 1001 */             trySuccess(promise, e.address());
/* 1002 */             return true;
/*      */           } 
/*      */         } 
/*      */       } 
/* 1006 */       return false;
/*      */     } 
/* 1008 */     tryFailure(promise, cause);
/* 1009 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   static <T> boolean trySuccess(Promise<T> promise, T result) {
/* 1014 */     boolean notifiedRecords = promise.trySuccess(result);
/* 1015 */     if (!notifiedRecords)
/*      */     {
/*      */ 
/*      */       
/* 1019 */       logger.trace("Failed to notify success ({}) to a promise: {}", result, promise);
/*      */     }
/* 1021 */     return notifiedRecords;
/*      */   }
/*      */   
/*      */   private static void tryFailure(Promise<?> promise, Throwable cause) {
/* 1025 */     if (!promise.tryFailure(cause))
/*      */     {
/*      */ 
/*      */       
/* 1029 */       logger.trace("Failed to notify failure to a promise: {}", promise, cause);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void doResolveUncached(String hostname, DnsRecord[] additionals, final Promise<InetAddress> promise, DnsCache resolveCache, boolean completeEarlyIfPossible) {
/* 1037 */     Promise<List<InetAddress>> allPromise = executor().newPromise();
/* 1038 */     doResolveAllUncached(hostname, additionals, promise, allPromise, resolveCache, completeEarlyIfPossible);
/* 1039 */     allPromise.addListener((GenericFutureListener)new FutureListener<List<InetAddress>>()
/*      */         {
/*      */           public void operationComplete(Future<List<InetAddress>> future) {
/* 1042 */             if (future.isSuccess()) {
/* 1043 */               DnsNameResolver.trySuccess(promise, ((List)future.getNow()).get(0));
/*      */             } else {
/* 1045 */               DnsNameResolver.tryFailure(promise, future.cause());
/*      */             } 
/*      */           }
/*      */         });
/*      */   }
/*      */ 
/*      */   
/*      */   protected void doResolveAll(String inetHost, Promise<List<InetAddress>> promise) throws Exception {
/* 1053 */     doResolveAll(inetHost, EMPTY_ADDITIONALS, promise, this.resolveCache);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doResolveAll(String inetHost, DnsRecord[] additionals, Promise<List<InetAddress>> promise, DnsCache resolveCache) throws Exception {
/* 1064 */     if (inetHost == null || inetHost.isEmpty()) {
/*      */       
/* 1066 */       promise.setSuccess(Collections.singletonList(loopbackAddress()));
/*      */       return;
/*      */     } 
/* 1069 */     InetAddress address = NetUtil.createInetAddressFromIpAddressString(inetHost);
/* 1070 */     if (address != null) {
/*      */       
/* 1072 */       promise.setSuccess(Collections.singletonList(address));
/*      */       
/*      */       return;
/*      */     } 
/* 1076 */     String hostname = hostname(inetHost);
/*      */     
/* 1078 */     List<InetAddress> hostsFileEntries = resolveHostsFileEntries(hostname);
/* 1079 */     if (hostsFileEntries != null) {
/* 1080 */       promise.setSuccess(hostsFileEntries);
/*      */       
/*      */       return;
/*      */     } 
/* 1084 */     if (!doResolveAllCached(hostname, additionals, promise, resolveCache, this.resolvedInternetProtocolFamilies)) {
/* 1085 */       doResolveAllUncached(hostname, additionals, promise, promise, resolveCache, this.completeOncePreferredResolved);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static boolean doResolveAllCached(String hostname, DnsRecord[] additionals, Promise<List<InetAddress>> promise, DnsCache resolveCache, InternetProtocolFamily[] resolvedInternetProtocolFamilies) {
/* 1095 */     List<? extends DnsCacheEntry> cachedEntries = resolveCache.get(hostname, additionals);
/* 1096 */     if (cachedEntries == null || cachedEntries.isEmpty()) {
/* 1097 */       return false;
/*      */     }
/*      */     
/* 1100 */     Throwable cause = ((DnsCacheEntry)cachedEntries.get(0)).cause();
/* 1101 */     if (cause == null) {
/* 1102 */       List<InetAddress> result = null;
/* 1103 */       int numEntries = cachedEntries.size();
/* 1104 */       for (InternetProtocolFamily f : resolvedInternetProtocolFamilies) {
/* 1105 */         for (int i = 0; i < numEntries; i++) {
/* 1106 */           DnsCacheEntry e = cachedEntries.get(i);
/* 1107 */           if (f.addressType().isInstance(e.address())) {
/* 1108 */             if (result == null) {
/* 1109 */               result = new ArrayList<InetAddress>(numEntries);
/*      */             }
/* 1111 */             result.add(e.address());
/*      */           } 
/*      */         } 
/*      */       } 
/* 1115 */       if (result != null) {
/* 1116 */         trySuccess(promise, result);
/* 1117 */         return true;
/*      */       } 
/* 1119 */       return false;
/*      */     } 
/* 1121 */     tryFailure(promise, cause);
/* 1122 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void doResolveAllUncached(final String hostname, final DnsRecord[] additionals, final Promise<?> originalPromise, final Promise<List<InetAddress>> promise, final DnsCache resolveCache, final boolean completeEarlyIfPossible) {
/* 1134 */     EventLoop eventLoop = executor();
/* 1135 */     if (eventLoop.inEventLoop()) {
/* 1136 */       doResolveAllUncached0(hostname, additionals, originalPromise, promise, resolveCache, completeEarlyIfPossible);
/*      */     } else {
/*      */       
/* 1139 */       eventLoop.execute(new Runnable()
/*      */           {
/*      */             public void run() {
/* 1142 */               DnsNameResolver.this.doResolveAllUncached0(hostname, additionals, originalPromise, promise, resolveCache, completeEarlyIfPossible);
/*      */             }
/*      */           });
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void doResolveAllUncached0(final String hostname, final DnsRecord[] additionals, final Promise<?> originalPromise, final Promise<List<InetAddress>> promise, final DnsCache resolveCache, final boolean completeEarlyIfPossible) {
/* 1156 */     assert executor().inEventLoop();
/*      */     
/* 1158 */     if (this.inflightLookups != null && (additionals == null || additionals.length == 0)) {
/* 1159 */       Future<List<InetAddress>> inflightFuture = this.inflightLookups.get(hostname);
/* 1160 */       if (inflightFuture != null) {
/* 1161 */         inflightFuture.addListener(new GenericFutureListener<Future<? super List<InetAddress>>>()
/*      */             {
/*      */               public void operationComplete(Future<? super List<InetAddress>> future)
/*      */               {
/* 1165 */                 if (future.isSuccess()) {
/* 1166 */                   promise.setSuccess(future.getNow());
/*      */                 } else {
/* 1168 */                   Throwable cause = future.cause();
/* 1169 */                   if (DnsNameResolver.isTimeoutError(cause)) {
/*      */ 
/*      */ 
/*      */ 
/*      */                     
/* 1174 */                     DnsNameResolver.this.resolveNow(hostname, additionals, originalPromise, promise, resolveCache, completeEarlyIfPossible);
/*      */                   } else {
/*      */                     
/* 1177 */                     promise.setFailure(cause);
/*      */                   } 
/*      */                 } 
/*      */               }
/*      */             });
/*      */         return;
/*      */       } 
/* 1184 */       if (this.inflightLookups.size() < this.maxNumConsolidation) {
/* 1185 */         this.inflightLookups.put(hostname, promise);
/* 1186 */         promise.addListener(new GenericFutureListener<Future<? super List<InetAddress>>>()
/*      */             {
/*      */               public void operationComplete(Future<? super List<InetAddress>> future) {
/* 1189 */                 DnsNameResolver.this.inflightLookups.remove(hostname);
/*      */               }
/*      */             });
/*      */       } 
/*      */     } 
/* 1194 */     resolveNow(hostname, additionals, originalPromise, promise, resolveCache, completeEarlyIfPossible);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void resolveNow(String hostname, DnsRecord[] additionals, Promise<?> originalPromise, Promise<List<InetAddress>> promise, DnsCache resolveCache, boolean completeEarlyIfPossible) {
/* 1204 */     DnsServerAddressStream nameServerAddrs = this.dnsServerAddressStreamProvider.nameServerAddressStream(hostname);
/* 1205 */     DnsAddressResolveContext ctx = new DnsAddressResolveContext(this, originalPromise, hostname, additionals, nameServerAddrs, this.maxQueriesPerResolve, resolveCache, this.authoritativeDnsServerCache, completeEarlyIfPossible);
/*      */ 
/*      */     
/* 1208 */     ctx.resolve(promise);
/*      */   }
/*      */   
/*      */   private static String hostname(String inetHost) {
/* 1212 */     String hostname = IDN.toASCII(inetHost);
/*      */     
/* 1214 */     if (StringUtil.endsWith(inetHost, '.') && !StringUtil.endsWith(hostname, '.')) {
/* 1215 */       hostname = hostname + ".";
/*      */     }
/* 1217 */     return hostname;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Future<AddressedEnvelope<DnsResponse, InetSocketAddress>> query(DnsQuestion question) {
/* 1224 */     return query(nextNameServerAddress(), question);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Future<AddressedEnvelope<DnsResponse, InetSocketAddress>> query(DnsQuestion question, Iterable<DnsRecord> additionals) {
/* 1232 */     return query(nextNameServerAddress(), question, additionals);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Future<AddressedEnvelope<DnsResponse, InetSocketAddress>> query(DnsQuestion question, Promise<AddressedEnvelope<? extends DnsResponse, InetSocketAddress>> promise) {
/* 1240 */     return query(nextNameServerAddress(), question, Collections.emptyList(), promise);
/*      */   }
/*      */   
/*      */   private InetSocketAddress nextNameServerAddress() {
/* 1244 */     return ((DnsServerAddressStream)this.nameServerAddrStream.get()).next();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Future<AddressedEnvelope<DnsResponse, InetSocketAddress>> query(InetSocketAddress nameServerAddr, DnsQuestion question) {
/* 1253 */     return query0(nameServerAddr, question, EMPTY_ADDITIONALS, true, this.ch.newPromise(), this.ch
/* 1254 */         .eventLoop().newPromise());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Future<AddressedEnvelope<DnsResponse, InetSocketAddress>> query(InetSocketAddress nameServerAddr, DnsQuestion question, Iterable<DnsRecord> additionals) {
/* 1263 */     return query0(nameServerAddr, question, toArray(additionals, false), true, this.ch.newPromise(), this.ch
/* 1264 */         .eventLoop().newPromise());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Future<AddressedEnvelope<DnsResponse, InetSocketAddress>> query(InetSocketAddress nameServerAddr, DnsQuestion question, Promise<AddressedEnvelope<? extends DnsResponse, InetSocketAddress>> promise) {
/* 1274 */     return query0(nameServerAddr, question, EMPTY_ADDITIONALS, true, this.ch.newPromise(), promise);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Future<AddressedEnvelope<DnsResponse, InetSocketAddress>> query(InetSocketAddress nameServerAddr, DnsQuestion question, Iterable<DnsRecord> additionals, Promise<AddressedEnvelope<? extends DnsResponse, InetSocketAddress>> promise) {
/* 1285 */     return query0(nameServerAddr, question, toArray(additionals, false), true, this.ch.newPromise(), promise);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isTransportOrTimeoutError(Throwable cause) {
/* 1294 */     return (cause != null && cause.getCause() instanceof DnsNameResolverException);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isTimeoutError(Throwable cause) {
/* 1303 */     return (cause != null && cause.getCause() instanceof DnsNameResolverTimeoutException);
/*      */   }
/*      */   
/*      */   final void flushQueries() {
/* 1307 */     this.ch.flush();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final Future<AddressedEnvelope<DnsResponse, InetSocketAddress>> query0(InetSocketAddress nameServerAddr, DnsQuestion question, DnsRecord[] additionals, boolean flush, ChannelPromise writePromise, Promise<AddressedEnvelope<? extends DnsResponse, InetSocketAddress>> promise) {
/* 1316 */     assert !writePromise.isVoid();
/*      */     
/* 1318 */     Promise<AddressedEnvelope<DnsResponse, InetSocketAddress>> castPromise = cast(
/* 1319 */         (Promise)ObjectUtil.checkNotNull(promise, "promise"));
/*      */     try {
/* 1321 */       (new DatagramDnsQueryContext(this, nameServerAddr, question, additionals, castPromise))
/* 1322 */         .query(flush, writePromise);
/* 1323 */       return (Future<AddressedEnvelope<DnsResponse, InetSocketAddress>>)castPromise;
/* 1324 */     } catch (Exception e) {
/* 1325 */       return (Future<AddressedEnvelope<DnsResponse, InetSocketAddress>>)castPromise.setFailure(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private static Promise<AddressedEnvelope<DnsResponse, InetSocketAddress>> cast(Promise<?> promise) {
/* 1331 */     return (Promise)promise;
/*      */   }
/*      */   
/*      */   final DnsServerAddressStream newNameServerAddressStream(String hostname) {
/* 1335 */     return this.dnsServerAddressStreamProvider.nameServerAddressStream(hostname);
/*      */   }
/*      */   
/*      */   private final class DnsResponseHandler
/*      */     extends ChannelInboundHandlerAdapter {
/*      */     private final Promise<Channel> channelActivePromise;
/*      */     
/*      */     DnsResponseHandler(Promise<Channel> channelActivePromise) {
/* 1343 */       this.channelActivePromise = channelActivePromise;
/*      */     }
/*      */ 
/*      */     
/*      */     public void channelRead(ChannelHandlerContext ctx, Object msg) {
/* 1348 */       final DatagramDnsResponse res = (DatagramDnsResponse)msg;
/* 1349 */       final int queryId = res.id();
/*      */       
/* 1351 */       if (DnsNameResolver.logger.isDebugEnabled()) {
/* 1352 */         DnsNameResolver.logger.debug("{} RECEIVED: UDP [{}: {}], {}", new Object[] { this.this$0.ch, Integer.valueOf(queryId), res.sender(), res });
/*      */       }
/*      */       
/* 1355 */       final DnsQueryContext qCtx = DnsNameResolver.this.queryContextManager.get(res.sender(), queryId);
/* 1356 */       if (qCtx == null) {
/* 1357 */         DnsNameResolver.logger.debug("Received a DNS response with an unknown ID: UDP [{}: {}]", DnsNameResolver.this.ch, Integer.valueOf(queryId));
/* 1358 */         res.release();
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/* 1363 */       if (!res.isTruncated() || DnsNameResolver.this.socketChannelFactory == null) {
/* 1364 */         qCtx.finish((AddressedEnvelope<? extends DnsResponse, InetSocketAddress>)res);
/*      */         
/*      */         return;
/*      */       } 
/* 1368 */       Bootstrap bs = new Bootstrap();
/* 1369 */       ((Bootstrap)((Bootstrap)((Bootstrap)bs.option(ChannelOption.SO_REUSEADDR, Boolean.valueOf(true)))
/* 1370 */         .group((EventLoopGroup)DnsNameResolver.this.executor()))
/* 1371 */         .channelFactory(DnsNameResolver.this.socketChannelFactory))
/* 1372 */         .handler((ChannelHandler)DnsNameResolver.TCP_ENCODER);
/* 1373 */       bs.connect(res.sender()).addListener((GenericFutureListener)new ChannelFutureListener()
/*      */           {
/*      */             public void operationComplete(ChannelFuture future) {
/* 1376 */               if (!future.isSuccess()) {
/* 1377 */                 if (DnsNameResolver.logger.isDebugEnabled()) {
/* 1378 */                   DnsNameResolver.logger.debug("Unable to fallback to TCP [{}]", Integer.valueOf(queryId), future.cause());
/*      */                 }
/*      */ 
/*      */                 
/* 1382 */                 qCtx.finish((AddressedEnvelope<? extends DnsResponse, InetSocketAddress>)res);
/*      */                 return;
/*      */               } 
/* 1385 */               final Channel channel = future.channel();
/*      */ 
/*      */               
/* 1388 */               Promise<AddressedEnvelope<DnsResponse, InetSocketAddress>> promise = channel.eventLoop().newPromise();
/*      */ 
/*      */               
/* 1391 */               final TcpDnsQueryContext tcpCtx = new TcpDnsQueryContext(DnsNameResolver.this, channel, (InetSocketAddress)channel.remoteAddress(), qCtx.question(), DnsNameResolver.EMPTY_ADDITIONALS, promise);
/*      */               
/* 1393 */               channel.pipeline().addLast(new ChannelHandler[] { (ChannelHandler)new TcpDnsResponseDecoder() });
/* 1394 */               channel.pipeline().addLast(new ChannelHandler[] { (ChannelHandler)new ChannelInboundHandlerAdapter()
/*      */                     {
/*      */                       public void channelRead(ChannelHandlerContext ctx, Object msg) {
/* 1397 */                         Channel channel = ctx.channel();
/* 1398 */                         DnsResponse response = (DnsResponse)msg;
/* 1399 */                         int queryId = response.id();
/*      */                         
/* 1401 */                         if (DnsNameResolver.logger.isDebugEnabled()) {
/* 1402 */                           DnsNameResolver.logger.debug("{} RECEIVED: TCP [{}: {}], {}", new Object[] { channel, Integer.valueOf(queryId), channel
/* 1403 */                                 .remoteAddress(), response });
/*      */                         }
/*      */                         
/* 1406 */                         DnsQueryContext foundCtx = DnsNameResolver.this.queryContextManager.get(res.sender(), queryId);
/* 1407 */                         if (foundCtx == tcpCtx) {
/* 1408 */                           tcpCtx.finish(new DnsNameResolver.AddressedEnvelopeAdapter((InetSocketAddress)ctx
/* 1409 */                                 .channel().remoteAddress(), (InetSocketAddress)ctx
/* 1410 */                                 .channel().localAddress(), response));
/*      */                         } else {
/*      */                           
/* 1413 */                           response.release();
/* 1414 */                           tcpCtx.tryFailure("Received TCP DNS response with unexpected ID", null, false);
/* 1415 */                           DnsNameResolver.logger.debug("Received a DNS response with an unexpected ID: TCP [{}: {}]", channel, 
/* 1416 */                               Integer.valueOf(queryId));
/*      */                         } 
/*      */                       }
/*      */ 
/*      */                       
/*      */                       public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) {
/* 1422 */                         if (tcpCtx.tryFailure("TCP fallback error", cause, false) && DnsNameResolver.logger.isDebugEnabled()) {
/* 1423 */                           DnsNameResolver.logger.debug("{} Error during processing response: TCP [{}: {}]", new Object[] { ctx
/* 1424 */                                 .channel(), Integer.valueOf(this.this$2.val$queryId), ctx
/* 1425 */                                 .channel().remoteAddress(), cause });
/*      */                         }
/*      */                       }
/*      */                     } });
/*      */               
/* 1430 */               promise.addListener((GenericFutureListener)new FutureListener<AddressedEnvelope<DnsResponse, InetSocketAddress>>()
/*      */                   {
/*      */                     
/*      */                     public void operationComplete(Future<AddressedEnvelope<DnsResponse, InetSocketAddress>> future)
/*      */                     {
/* 1435 */                       channel.close();
/*      */                       
/* 1437 */                       if (future.isSuccess()) {
/* 1438 */                         qCtx.finish((AddressedEnvelope<? extends DnsResponse, InetSocketAddress>)future.getNow());
/* 1439 */                         res.release();
/*      */                       } else {
/*      */                         
/* 1442 */                         qCtx.finish((AddressedEnvelope<? extends DnsResponse, InetSocketAddress>)res);
/*      */                       } 
/*      */                     }
/*      */                   });
/* 1446 */               tcpCtx.query(true, future.channel().newPromise());
/*      */             }
/*      */           });
/*      */     }
/*      */ 
/*      */     
/*      */     public void channelActive(ChannelHandlerContext ctx) throws Exception {
/* 1453 */       super.channelActive(ctx);
/* 1454 */       this.channelActivePromise.trySuccess(ctx.channel());
/*      */     }
/*      */ 
/*      */     
/*      */     public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) {
/* 1459 */       if (cause instanceof io.netty.handler.codec.CorruptedFrameException) {
/* 1460 */         DnsNameResolver.logger.debug("Unable to decode DNS response: UDP [{}]", ctx.channel(), cause);
/*      */       } else {
/* 1462 */         DnsNameResolver.logger.warn("Unexpected exception: UDP [{}]", ctx.channel(), cause);
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   private static final class AddressedEnvelopeAdapter implements AddressedEnvelope<DnsResponse, InetSocketAddress> {
/*      */     private final InetSocketAddress sender;
/*      */     private final InetSocketAddress recipient;
/*      */     private final DnsResponse response;
/*      */     
/*      */     AddressedEnvelopeAdapter(InetSocketAddress sender, InetSocketAddress recipient, DnsResponse response) {
/* 1473 */       this.sender = sender;
/* 1474 */       this.recipient = recipient;
/* 1475 */       this.response = response;
/*      */     }
/*      */ 
/*      */     
/*      */     public DnsResponse content() {
/* 1480 */       return this.response;
/*      */     }
/*      */ 
/*      */     
/*      */     public InetSocketAddress sender() {
/* 1485 */       return this.sender;
/*      */     }
/*      */ 
/*      */     
/*      */     public InetSocketAddress recipient() {
/* 1490 */       return this.recipient;
/*      */     }
/*      */ 
/*      */     
/*      */     public AddressedEnvelope<DnsResponse, InetSocketAddress> retain() {
/* 1495 */       this.response.retain();
/* 1496 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public AddressedEnvelope<DnsResponse, InetSocketAddress> retain(int increment) {
/* 1501 */       this.response.retain(increment);
/* 1502 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public AddressedEnvelope<DnsResponse, InetSocketAddress> touch() {
/* 1507 */       this.response.touch();
/* 1508 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public AddressedEnvelope<DnsResponse, InetSocketAddress> touch(Object hint) {
/* 1513 */       this.response.touch(hint);
/* 1514 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public int refCnt() {
/* 1519 */       return this.response.refCnt();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean release() {
/* 1524 */       return this.response.release();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean release(int decrement) {
/* 1529 */       return this.response.release(decrement);
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean equals(Object obj) {
/* 1534 */       if (this == obj) {
/* 1535 */         return true;
/*      */       }
/*      */       
/* 1538 */       if (!(obj instanceof AddressedEnvelope)) {
/* 1539 */         return false;
/*      */       }
/*      */ 
/*      */       
/* 1543 */       AddressedEnvelope<?, SocketAddress> that = (AddressedEnvelope<?, SocketAddress>)obj;
/* 1544 */       if (sender() == null) {
/* 1545 */         if (that.sender() != null) {
/* 1546 */           return false;
/*      */         }
/* 1548 */       } else if (!sender().equals(that.sender())) {
/* 1549 */         return false;
/*      */       } 
/*      */       
/* 1552 */       if (recipient() == null) {
/* 1553 */         if (that.recipient() != null) {
/* 1554 */           return false;
/*      */         }
/* 1556 */       } else if (!recipient().equals(that.recipient())) {
/* 1557 */         return false;
/*      */       } 
/*      */       
/* 1560 */       return this.response.equals(obj);
/*      */     }
/*      */ 
/*      */     
/*      */     public int hashCode() {
/* 1565 */       int hashCode = this.response.hashCode();
/* 1566 */       if (sender() != null) {
/* 1567 */         hashCode = hashCode * 31 + sender().hashCode();
/*      */       }
/* 1569 */       if (recipient() != null) {
/* 1570 */         hashCode = hashCode * 31 + recipient().hashCode();
/*      */       }
/* 1572 */       return hashCode;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-resolver-dns-4.1.93.Final.jar!\io\netty\resolver\dns\DnsNameResolver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */