/*    */ package io.netty.resolver.dns;
/*    */ 
/*    */ import io.netty.channel.ChannelFactory;
/*    */ import io.netty.channel.EventLoop;
/*    */ import io.netty.channel.socket.DatagramChannel;
/*    */ import io.netty.resolver.AddressResolver;
/*    */ import io.netty.resolver.NameResolver;
/*    */ import io.netty.resolver.RoundRobinInetAddressResolver;
/*    */ import io.netty.util.concurrent.EventExecutor;
/*    */ import java.net.InetAddress;
/*    */ import java.net.InetSocketAddress;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RoundRobinDnsAddressResolverGroup
/*    */   extends DnsAddressResolverGroup
/*    */ {
/*    */   public RoundRobinDnsAddressResolverGroup(DnsNameResolverBuilder dnsResolverBuilder) {
/* 38 */     super(dnsResolverBuilder);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public RoundRobinDnsAddressResolverGroup(Class<? extends DatagramChannel> channelType, DnsServerAddressStreamProvider nameServerProvider) {
/* 44 */     super(channelType, nameServerProvider);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public RoundRobinDnsAddressResolverGroup(ChannelFactory<? extends DatagramChannel> channelFactory, DnsServerAddressStreamProvider nameServerProvider) {
/* 50 */     super(channelFactory, nameServerProvider);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected final AddressResolver<InetSocketAddress> newAddressResolver(EventLoop eventLoop, NameResolver<InetAddress> resolver) throws Exception {
/* 64 */     return (new RoundRobinInetAddressResolver((EventExecutor)eventLoop, resolver)).asAddressResolver();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-resolver-dns-4.1.93.Final.jar!\io\netty\resolver\dns\RoundRobinDnsAddressResolverGroup.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */