/*    */ package io.netty.resolver.dns;
/*    */ 
/*    */ import io.netty.handler.codec.dns.DnsQuestion;
/*    */ import io.netty.handler.logging.LogLevel;
/*    */ import io.netty.util.internal.ObjectUtil;
/*    */ import io.netty.util.internal.logging.InternalLogLevel;
/*    */ import io.netty.util.internal.logging.InternalLogger;
/*    */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class LoggingDnsQueryLifeCycleObserverFactory
/*    */   implements DnsQueryLifecycleObserverFactory
/*    */ {
/* 35 */   private static final InternalLogger DEFAULT_LOGGER = InternalLoggerFactory.getInstance(LoggingDnsQueryLifeCycleObserverFactory.class);
/*    */   
/*    */   private final InternalLogger logger;
/*    */   
/*    */   private final InternalLogLevel level;
/*    */ 
/*    */   
/*    */   public LoggingDnsQueryLifeCycleObserverFactory() {
/* 43 */     this(LogLevel.DEBUG);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public LoggingDnsQueryLifeCycleObserverFactory(LogLevel level) {
/* 51 */     this.level = checkAndConvertLevel(level);
/* 52 */     this.logger = DEFAULT_LOGGER;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public LoggingDnsQueryLifeCycleObserverFactory(Class<?> classContext, LogLevel level) {
/* 62 */     this.level = checkAndConvertLevel(level);
/* 63 */     this.logger = InternalLoggerFactory.getInstance((Class)ObjectUtil.checkNotNull(classContext, "classContext"));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public LoggingDnsQueryLifeCycleObserverFactory(String name, LogLevel level) {
/* 73 */     this.level = checkAndConvertLevel(level);
/* 74 */     this.logger = InternalLoggerFactory.getInstance((String)ObjectUtil.checkNotNull(name, "name"));
/*    */   }
/*    */   
/*    */   private static InternalLogLevel checkAndConvertLevel(LogLevel level) {
/* 78 */     return ((LogLevel)ObjectUtil.checkNotNull(level, "level")).toInternalLevel();
/*    */   }
/*    */ 
/*    */   
/*    */   public DnsQueryLifecycleObserver newDnsQueryLifecycleObserver(DnsQuestion question) {
/* 83 */     return new LoggingDnsQueryLifecycleObserver(question, this.logger, this.level);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-resolver-dns-4.1.93.Final.jar!\io\netty\resolver\dns\LoggingDnsQueryLifeCycleObserverFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */