/*     */ package io.netty.resolver.dns;
/*     */ 
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class DnsServerAddresses
/*     */ {
/*     */   @Deprecated
/*     */   public static List<InetSocketAddress> defaultAddressList() {
/*  41 */     return DefaultDnsServerAddressStreamProvider.defaultAddressList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static DnsServerAddresses defaultAddresses() {
/*  59 */     return DefaultDnsServerAddressStreamProvider.defaultAddresses();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DnsServerAddresses sequential(Iterable<? extends InetSocketAddress> addresses) {
/*  67 */     return sequential0(sanitize(addresses));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DnsServerAddresses sequential(InetSocketAddress... addresses) {
/*  75 */     return sequential0(sanitize(addresses));
/*     */   }
/*     */   
/*     */   private static DnsServerAddresses sequential0(List<InetSocketAddress> addresses) {
/*  79 */     if (addresses.size() == 1) {
/*  80 */       return singleton(addresses.get(0));
/*     */     }
/*     */     
/*  83 */     return new DefaultDnsServerAddresses("sequential", addresses)
/*     */       {
/*     */         public DnsServerAddressStream stream() {
/*  86 */           return new SequentialDnsServerAddressStream(this.addresses, 0);
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DnsServerAddresses shuffled(Iterable<? extends InetSocketAddress> addresses) {
/*  96 */     return shuffled0(sanitize(addresses));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DnsServerAddresses shuffled(InetSocketAddress... addresses) {
/* 104 */     return shuffled0(sanitize(addresses));
/*     */   }
/*     */   
/*     */   private static DnsServerAddresses shuffled0(List<InetSocketAddress> addresses) {
/* 108 */     if (addresses.size() == 1) {
/* 109 */       return singleton(addresses.get(0));
/*     */     }
/*     */     
/* 112 */     return new DefaultDnsServerAddresses("shuffled", addresses)
/*     */       {
/*     */         public DnsServerAddressStream stream() {
/* 115 */           return new ShuffledDnsServerAddressStream(this.addresses);
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DnsServerAddresses rotational(Iterable<? extends InetSocketAddress> addresses) {
/* 127 */     return rotational0(sanitize(addresses));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DnsServerAddresses rotational(InetSocketAddress... addresses) {
/* 137 */     return rotational0(sanitize(addresses));
/*     */   }
/*     */   
/*     */   private static DnsServerAddresses rotational0(List<InetSocketAddress> addresses) {
/* 141 */     if (addresses.size() == 1) {
/* 142 */       return singleton(addresses.get(0));
/*     */     }
/*     */     
/* 145 */     return new RotationalDnsServerAddresses(addresses);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DnsServerAddresses singleton(InetSocketAddress address) {
/* 152 */     ObjectUtil.checkNotNull(address, "address");
/* 153 */     if (address.isUnresolved()) {
/* 154 */       throw new IllegalArgumentException("cannot use an unresolved DNS server address: " + address);
/*     */     }
/*     */     
/* 157 */     return new SingletonDnsServerAddresses(address);
/*     */   }
/*     */   private static List<InetSocketAddress> sanitize(Iterable<? extends InetSocketAddress> addresses) {
/*     */     List<InetSocketAddress> list;
/* 161 */     ObjectUtil.checkNotNull(addresses, "addresses");
/*     */ 
/*     */     
/* 164 */     if (addresses instanceof Collection) {
/* 165 */       list = new ArrayList<InetSocketAddress>(((Collection)addresses).size());
/*     */     } else {
/* 167 */       list = new ArrayList<InetSocketAddress>(4);
/*     */     } 
/*     */     
/* 170 */     for (InetSocketAddress a : addresses) {
/* 171 */       if (a == null) {
/*     */         break;
/*     */       }
/* 174 */       if (a.isUnresolved()) {
/* 175 */         throw new IllegalArgumentException("cannot use an unresolved DNS server address: " + a);
/*     */       }
/* 177 */       list.add(a);
/*     */     } 
/*     */     
/* 180 */     return (List<InetSocketAddress>)ObjectUtil.checkNonEmpty(list, "list");
/*     */   }
/*     */   
/*     */   private static List<InetSocketAddress> sanitize(InetSocketAddress[] addresses) {
/* 184 */     ObjectUtil.checkNotNull(addresses, "addresses");
/*     */     
/* 186 */     List<InetSocketAddress> list = new ArrayList<InetSocketAddress>(addresses.length);
/* 187 */     for (InetSocketAddress a : addresses) {
/* 188 */       if (a == null) {
/*     */         break;
/*     */       }
/* 191 */       if (a.isUnresolved()) {
/* 192 */         throw new IllegalArgumentException("cannot use an unresolved DNS server address: " + a);
/*     */       }
/* 194 */       list.add(a);
/*     */     } 
/*     */     
/* 197 */     if (list.isEmpty()) {
/* 198 */       return DefaultDnsServerAddressStreamProvider.defaultAddressList();
/*     */     }
/*     */     
/* 201 */     return list;
/*     */   }
/*     */   
/*     */   public abstract DnsServerAddressStream stream();
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-resolver-dns-4.1.93.Final.jar!\io\netty\resolver\dns\DnsServerAddresses.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */