/*     */ package io.netty.resolver.dns;
/*     */ 
/*     */ import io.netty.channel.ChannelFuture;
/*     */ import io.netty.handler.codec.dns.DnsQuestion;
/*     */ import io.netty.handler.codec.dns.DnsResponseCode;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class BiDnsQueryLifecycleObserver
/*     */   implements DnsQueryLifecycleObserver
/*     */ {
/*     */   private final DnsQueryLifecycleObserver a;
/*     */   private final DnsQueryLifecycleObserver b;
/*     */   
/*     */   public BiDnsQueryLifecycleObserver(DnsQueryLifecycleObserver a, DnsQueryLifecycleObserver b) {
/*  40 */     this.a = (DnsQueryLifecycleObserver)ObjectUtil.checkNotNull(a, "a");
/*  41 */     this.b = (DnsQueryLifecycleObserver)ObjectUtil.checkNotNull(b, "b");
/*     */   }
/*     */ 
/*     */   
/*     */   public void queryWritten(InetSocketAddress dnsServerAddress, ChannelFuture future) {
/*     */     try {
/*  47 */       this.a.queryWritten(dnsServerAddress, future);
/*     */     } finally {
/*  49 */       this.b.queryWritten(dnsServerAddress, future);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void queryCancelled(int queriesRemaining) {
/*     */     try {
/*  56 */       this.a.queryCancelled(queriesRemaining);
/*     */     } finally {
/*  58 */       this.b.queryCancelled(queriesRemaining);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public DnsQueryLifecycleObserver queryRedirected(List<InetSocketAddress> nameServers) {
/*     */     try {
/*  65 */       this.a.queryRedirected(nameServers);
/*     */     } finally {
/*  67 */       this.b.queryRedirected(nameServers);
/*     */     } 
/*  69 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public DnsQueryLifecycleObserver queryCNAMEd(DnsQuestion cnameQuestion) {
/*     */     try {
/*  75 */       this.a.queryCNAMEd(cnameQuestion);
/*     */     } finally {
/*  77 */       this.b.queryCNAMEd(cnameQuestion);
/*     */     } 
/*  79 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public DnsQueryLifecycleObserver queryNoAnswer(DnsResponseCode code) {
/*     */     try {
/*  85 */       this.a.queryNoAnswer(code);
/*     */     } finally {
/*  87 */       this.b.queryNoAnswer(code);
/*     */     } 
/*  89 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public void queryFailed(Throwable cause) {
/*     */     try {
/*  95 */       this.a.queryFailed(cause);
/*     */     } finally {
/*  97 */       this.b.queryFailed(cause);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void querySucceed() {
/*     */     try {
/* 104 */       this.a.querySucceed();
/*     */     } finally {
/* 106 */       this.b.querySucceed();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-resolver-dns-4.1.93.Final.jar!\io\netty\resolver\dns\BiDnsQueryLifecycleObserver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */