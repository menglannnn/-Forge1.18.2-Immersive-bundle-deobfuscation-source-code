/*    */ package io.netty.resolver.dns;
/*    */ 
/*    */ import io.netty.util.internal.PlatformDependent;
/*    */ import java.net.InetSocketAddress;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class ShuffledDnsServerAddressStream
/*    */   implements DnsServerAddressStream
/*    */ {
/*    */   private final List<InetSocketAddress> addresses;
/*    */   private int i;
/*    */   
/*    */   ShuffledDnsServerAddressStream(List<InetSocketAddress> addresses) {
/* 36 */     this.addresses = addresses;
/*    */     
/* 38 */     shuffle();
/*    */   }
/*    */   
/*    */   private ShuffledDnsServerAddressStream(List<InetSocketAddress> addresses, int startIdx) {
/* 42 */     this.addresses = addresses;
/* 43 */     this.i = startIdx;
/*    */   }
/*    */   
/*    */   private void shuffle() {
/* 47 */     Collections.shuffle(this.addresses, PlatformDependent.threadLocalRandom());
/*    */   }
/*    */ 
/*    */   
/*    */   public InetSocketAddress next() {
/* 52 */     int i = this.i;
/* 53 */     InetSocketAddress next = this.addresses.get(i);
/* 54 */     if (++i < this.addresses.size()) {
/* 55 */       this.i = i;
/*    */     } else {
/* 57 */       this.i = 0;
/* 58 */       shuffle();
/*    */     } 
/* 60 */     return next;
/*    */   }
/*    */ 
/*    */   
/*    */   public int size() {
/* 65 */     return this.addresses.size();
/*    */   }
/*    */ 
/*    */   
/*    */   public ShuffledDnsServerAddressStream duplicate() {
/* 70 */     return new ShuffledDnsServerAddressStream(this.addresses, this.i);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 75 */     return SequentialDnsServerAddressStream.toString("shuffled", this.i, this.addresses);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-resolver-dns-4.1.93.Final.jar!\io\netty\resolver\dns\ShuffledDnsServerAddressStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */