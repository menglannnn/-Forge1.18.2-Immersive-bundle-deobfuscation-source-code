/*    */ package io.netty.resolver.dns;
/*    */ 
/*    */ import io.netty.handler.codec.dns.DnsQuestion;
/*    */ import io.netty.util.internal.ObjectUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class BiDnsQueryLifecycleObserverFactory
/*    */   implements DnsQueryLifecycleObserverFactory
/*    */ {
/*    */   private final DnsQueryLifecycleObserverFactory a;
/*    */   private final DnsQueryLifecycleObserverFactory b;
/*    */   
/*    */   public BiDnsQueryLifecycleObserverFactory(DnsQueryLifecycleObserverFactory a, DnsQueryLifecycleObserverFactory b) {
/* 35 */     this.a = (DnsQueryLifecycleObserverFactory)ObjectUtil.checkNotNull(a, "a");
/* 36 */     this.b = (DnsQueryLifecycleObserverFactory)ObjectUtil.checkNotNull(b, "b");
/*    */   }
/*    */ 
/*    */   
/*    */   public DnsQueryLifecycleObserver newDnsQueryLifecycleObserver(DnsQuestion question) {
/* 41 */     return new BiDnsQueryLifecycleObserver(this.a.newDnsQueryLifecycleObserver(question), this.b
/* 42 */         .newDnsQueryLifecycleObserver(question));
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-resolver-dns-4.1.93.Final.jar!\io\netty\resolver\dns\BiDnsQueryLifecycleObserverFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */