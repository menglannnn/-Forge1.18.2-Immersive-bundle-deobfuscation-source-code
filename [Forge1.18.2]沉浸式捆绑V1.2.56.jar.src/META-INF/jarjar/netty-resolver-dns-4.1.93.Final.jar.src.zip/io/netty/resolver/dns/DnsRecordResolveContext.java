/*    */ package io.netty.resolver.dns;
/*    */ 
/*    */ import io.netty.channel.EventLoop;
/*    */ import io.netty.handler.codec.dns.DnsQuestion;
/*    */ import io.netty.handler.codec.dns.DnsRecord;
/*    */ import io.netty.handler.codec.dns.DnsRecordType;
/*    */ import io.netty.util.ReferenceCountUtil;
/*    */ import io.netty.util.concurrent.Promise;
/*    */ import java.net.UnknownHostException;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class DnsRecordResolveContext
/*    */   extends DnsResolveContext<DnsRecord>
/*    */ {
/*    */   DnsRecordResolveContext(DnsNameResolver parent, Promise<?> originalPromise, DnsQuestion question, DnsRecord[] additionals, DnsServerAddressStream nameServerAddrs, int allowedQueries) {
/* 32 */     this(parent, originalPromise, question.name(), question.dnsClass(), new DnsRecordType[] { question
/* 33 */           .type() }, additionals, nameServerAddrs, allowedQueries);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private DnsRecordResolveContext(DnsNameResolver parent, Promise<?> originalPromise, String hostname, int dnsClass, DnsRecordType[] expectedTypes, DnsRecord[] additionals, DnsServerAddressStream nameServerAddrs, int allowedQueries) {
/* 42 */     super(parent, originalPromise, hostname, dnsClass, expectedTypes, additionals, nameServerAddrs, allowedQueries);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   DnsResolveContext<DnsRecord> newResolverContext(DnsNameResolver parent, Promise<?> originalPromise, String hostname, int dnsClass, DnsRecordType[] expectedTypes, DnsRecord[] additionals, DnsServerAddressStream nameServerAddrs, int allowedQueries) {
/* 52 */     return new DnsRecordResolveContext(parent, originalPromise, hostname, dnsClass, expectedTypes, additionals, nameServerAddrs, allowedQueries);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   DnsRecord convertRecord(DnsRecord record, String hostname, DnsRecord[] additionals, EventLoop eventLoop) {
/* 58 */     return (DnsRecord)ReferenceCountUtil.retain(record);
/*    */   }
/*    */ 
/*    */   
/*    */   List<DnsRecord> filterResults(List<DnsRecord> unfiltered) {
/* 63 */     return unfiltered;
/*    */   }
/*    */ 
/*    */   
/*    */   boolean isCompleteEarly(DnsRecord resolved) {
/* 68 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   boolean isDuplicateAllowed() {
/* 73 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   void cache(String hostname, DnsRecord[] additionals, DnsRecord result, DnsRecord convertedResult) {}
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   void cache(String hostname, DnsRecord[] additionals, UnknownHostException cause) {}
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   DnsCnameCache cnameCache() {
/* 91 */     return NoopDnsCnameCache.INSTANCE;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-resolver-dns-4.1.93.Final.jar!\io\netty\resolver\dns\DnsRecordResolveContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */