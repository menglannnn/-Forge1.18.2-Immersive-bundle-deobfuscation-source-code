/*    */ package io.netty.resolver.dns;
/*    */ 
/*    */ import io.netty.util.internal.ObjectUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class UniSequentialDnsServerAddressStreamProvider
/*    */   implements DnsServerAddressStreamProvider
/*    */ {
/*    */   private final DnsServerAddresses addresses;
/*    */   
/*    */   UniSequentialDnsServerAddressStreamProvider(DnsServerAddresses addresses) {
/* 27 */     this.addresses = (DnsServerAddresses)ObjectUtil.checkNotNull(addresses, "addresses");
/*    */   }
/*    */ 
/*    */   
/*    */   public final DnsServerAddressStream nameServerAddressStream(String hostname) {
/* 32 */     return this.addresses.stream();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-resolver-dns-4.1.93.Final.jar!\io\netty\resolver\dns\UniSequentialDnsServerAddressStreamProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */