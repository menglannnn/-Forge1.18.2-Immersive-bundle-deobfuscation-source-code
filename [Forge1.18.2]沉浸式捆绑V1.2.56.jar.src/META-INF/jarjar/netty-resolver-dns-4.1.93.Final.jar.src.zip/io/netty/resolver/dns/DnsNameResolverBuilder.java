/*     */ package io.netty.resolver.dns;
/*     */ 
/*     */ import io.netty.channel.ChannelFactory;
/*     */ import io.netty.channel.EventLoop;
/*     */ import io.netty.channel.ReflectiveChannelFactory;
/*     */ import io.netty.channel.socket.DatagramChannel;
/*     */ import io.netty.channel.socket.InternetProtocolFamily;
/*     */ import io.netty.channel.socket.SocketChannel;
/*     */ import io.netty.resolver.HostsFileEntriesResolver;
/*     */ import io.netty.resolver.ResolvedAddressTypes;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import io.netty.util.internal.logging.InternalLogger;
/*     */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*     */ import java.net.SocketAddress;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DnsNameResolverBuilder
/*     */ {
/*  44 */   private static final InternalLogger logger = InternalLoggerFactory.getInstance(DnsNameResolverBuilder.class);
/*     */   
/*     */   volatile EventLoop eventLoop;
/*     */   private ChannelFactory<? extends DatagramChannel> channelFactory;
/*     */   private ChannelFactory<? extends SocketChannel> socketChannelFactory;
/*     */   private DnsCache resolveCache;
/*     */   private DnsCnameCache cnameCache;
/*     */   private AuthoritativeDnsServerCache authoritativeDnsServerCache;
/*     */   private SocketAddress localAddress;
/*     */   private Integer minTtl;
/*     */   private Integer maxTtl;
/*     */   private Integer negativeTtl;
/*  56 */   private long queryTimeoutMillis = -1L;
/*  57 */   private ResolvedAddressTypes resolvedAddressTypes = DnsNameResolver.DEFAULT_RESOLVE_ADDRESS_TYPES;
/*     */   private boolean completeOncePreferredResolved;
/*     */   private boolean recursionDesired = true;
/*  60 */   private int maxQueriesPerResolve = -1;
/*     */   private boolean traceEnabled;
/*  62 */   private int maxPayloadSize = 4096;
/*     */   private boolean optResourceEnabled = true;
/*  64 */   private HostsFileEntriesResolver hostsFileEntriesResolver = HostsFileEntriesResolver.DEFAULT;
/*     */   
/*  66 */   private DnsServerAddressStreamProvider dnsServerAddressStreamProvider = DnsServerAddressStreamProviders.platformDefault();
/*  67 */   private DnsQueryLifecycleObserverFactory dnsQueryLifecycleObserverFactory = NoopDnsQueryLifecycleObserverFactory.INSTANCE;
/*     */   
/*     */   private String[] searchDomains;
/*  70 */   private int ndots = -1;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean decodeIdn = true;
/*     */ 
/*     */ 
/*     */   
/*     */   private int maxNumConsolidation;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DnsNameResolverBuilder() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public DnsNameResolverBuilder(EventLoop eventLoop) {
/*  88 */     eventLoop(eventLoop);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DnsNameResolverBuilder eventLoop(EventLoop eventLoop) {
/*  98 */     this.eventLoop = eventLoop;
/*  99 */     return this;
/*     */   }
/*     */   
/*     */   protected ChannelFactory<? extends DatagramChannel> channelFactory() {
/* 103 */     return this.channelFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DnsNameResolverBuilder channelFactory(ChannelFactory<? extends DatagramChannel> channelFactory) {
/* 113 */     this.channelFactory = channelFactory;
/* 114 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DnsNameResolverBuilder channelType(Class<? extends DatagramChannel> channelType) {
/* 125 */     return channelFactory((ChannelFactory<? extends DatagramChannel>)new ReflectiveChannelFactory(channelType));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DnsNameResolverBuilder socketChannelFactory(ChannelFactory<? extends SocketChannel> channelFactory) {
/* 137 */     this.socketChannelFactory = channelFactory;
/* 138 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DnsNameResolverBuilder socketChannelType(Class<? extends SocketChannel> channelType) {
/* 151 */     if (channelType == null) {
/* 152 */       return socketChannelFactory(null);
/*     */     }
/* 154 */     return socketChannelFactory((ChannelFactory<? extends SocketChannel>)new ReflectiveChannelFactory(channelType));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DnsNameResolverBuilder resolveCache(DnsCache resolveCache) {
/* 164 */     this.resolveCache = resolveCache;
/* 165 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DnsNameResolverBuilder cnameCache(DnsCnameCache cnameCache) {
/* 175 */     this.cnameCache = cnameCache;
/* 176 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DnsNameResolverBuilder dnsQueryLifecycleObserverFactory(DnsQueryLifecycleObserverFactory lifecycleObserverFactory) {
/* 186 */     this.dnsQueryLifecycleObserverFactory = (DnsQueryLifecycleObserverFactory)ObjectUtil.checkNotNull(lifecycleObserverFactory, "lifecycleObserverFactory");
/* 187 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public DnsNameResolverBuilder authoritativeDnsServerCache(DnsCache authoritativeDnsServerCache) {
/* 199 */     this.authoritativeDnsServerCache = new AuthoritativeDnsServerCacheAdapter(authoritativeDnsServerCache);
/* 200 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DnsNameResolverBuilder authoritativeDnsServerCache(AuthoritativeDnsServerCache authoritativeDnsServerCache) {
/* 210 */     this.authoritativeDnsServerCache = authoritativeDnsServerCache;
/* 211 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DnsNameResolverBuilder localAddress(SocketAddress localAddress) {
/* 220 */     this.localAddress = localAddress;
/* 221 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DnsNameResolverBuilder ttl(int minTtl, int maxTtl) {
/* 237 */     this.maxTtl = Integer.valueOf(maxTtl);
/* 238 */     this.minTtl = Integer.valueOf(minTtl);
/* 239 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DnsNameResolverBuilder negativeTtl(int negativeTtl) {
/* 249 */     this.negativeTtl = Integer.valueOf(negativeTtl);
/* 250 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DnsNameResolverBuilder queryTimeoutMillis(long queryTimeoutMillis) {
/* 260 */     this.queryTimeoutMillis = queryTimeoutMillis;
/* 261 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ResolvedAddressTypes computeResolvedAddressTypes(InternetProtocolFamily... internetProtocolFamilies) {
/* 272 */     if (internetProtocolFamilies == null || internetProtocolFamilies.length == 0) {
/* 273 */       return DnsNameResolver.DEFAULT_RESOLVE_ADDRESS_TYPES;
/*     */     }
/* 275 */     if (internetProtocolFamilies.length > 2) {
/* 276 */       throw new IllegalArgumentException("No more than 2 InternetProtocolFamilies");
/*     */     }
/*     */     
/* 279 */     switch (internetProtocolFamilies[0]) {
/*     */       case IPv4:
/* 281 */         return (internetProtocolFamilies.length >= 2 && internetProtocolFamilies[1] == InternetProtocolFamily.IPv6) ? ResolvedAddressTypes.IPV4_PREFERRED : ResolvedAddressTypes.IPV4_ONLY;
/*     */ 
/*     */       
/*     */       case IPv6:
/* 285 */         return (internetProtocolFamilies.length >= 2 && internetProtocolFamilies[1] == InternetProtocolFamily.IPv4) ? ResolvedAddressTypes.IPV6_PREFERRED : ResolvedAddressTypes.IPV6_ONLY;
/*     */     } 
/*     */ 
/*     */     
/* 289 */     throw new IllegalArgumentException("Couldn't resolve ResolvedAddressTypes from InternetProtocolFamily array");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DnsNameResolverBuilder resolvedAddressTypes(ResolvedAddressTypes resolvedAddressTypes) {
/* 303 */     this.resolvedAddressTypes = resolvedAddressTypes;
/* 304 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DnsNameResolverBuilder completeOncePreferredResolved(boolean completeOncePreferredResolved) {
/* 315 */     this.completeOncePreferredResolved = completeOncePreferredResolved;
/* 316 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DnsNameResolverBuilder recursionDesired(boolean recursionDesired) {
/* 326 */     this.recursionDesired = recursionDesired;
/* 327 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DnsNameResolverBuilder maxQueriesPerResolve(int maxQueriesPerResolve) {
/* 337 */     this.maxQueriesPerResolve = maxQueriesPerResolve;
/* 338 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public DnsNameResolverBuilder traceEnabled(boolean traceEnabled) {
/* 352 */     this.traceEnabled = traceEnabled;
/* 353 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DnsNameResolverBuilder maxPayloadSize(int maxPayloadSize) {
/* 363 */     this.maxPayloadSize = maxPayloadSize;
/* 364 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DnsNameResolverBuilder optResourceEnabled(boolean optResourceEnabled) {
/* 376 */     this.optResourceEnabled = optResourceEnabled;
/* 377 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DnsNameResolverBuilder hostsFileEntriesResolver(HostsFileEntriesResolver hostsFileEntriesResolver) {
/* 386 */     this.hostsFileEntriesResolver = hostsFileEntriesResolver;
/* 387 */     return this;
/*     */   }
/*     */   
/*     */   protected DnsServerAddressStreamProvider nameServerProvider() {
/* 391 */     return this.dnsServerAddressStreamProvider;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DnsNameResolverBuilder nameServerProvider(DnsServerAddressStreamProvider dnsServerAddressStreamProvider) {
/* 400 */     this
/* 401 */       .dnsServerAddressStreamProvider = (DnsServerAddressStreamProvider)ObjectUtil.checkNotNull(dnsServerAddressStreamProvider, "dnsServerAddressStreamProvider");
/* 402 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DnsNameResolverBuilder searchDomains(Iterable<String> searchDomains) {
/* 412 */     ObjectUtil.checkNotNull(searchDomains, "searchDomains");
/*     */     
/* 414 */     List<String> list = new ArrayList<String>(4);
/*     */     
/* 416 */     for (String f : searchDomains) {
/* 417 */       if (f == null) {
/*     */         break;
/*     */       }
/*     */ 
/*     */       
/* 422 */       if (list.contains(f)) {
/*     */         continue;
/*     */       }
/*     */       
/* 426 */       list.add(f);
/*     */     } 
/*     */     
/* 429 */     this.searchDomains = list.<String>toArray(new String[0]);
/* 430 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DnsNameResolverBuilder ndots(int ndots) {
/* 441 */     this.ndots = ndots;
/* 442 */     return this;
/*     */   }
/*     */   
/*     */   private DnsCache newCache() {
/* 446 */     return new DefaultDnsCache(ObjectUtil.intValue(this.minTtl, 0), ObjectUtil.intValue(this.maxTtl, 2147483647), ObjectUtil.intValue(this.negativeTtl, 0));
/*     */   }
/*     */   
/*     */   private AuthoritativeDnsServerCache newAuthoritativeDnsServerCache() {
/* 450 */     return new DefaultAuthoritativeDnsServerCache(
/* 451 */         ObjectUtil.intValue(this.minTtl, 0), ObjectUtil.intValue(this.maxTtl, 2147483647), new NameServerComparator(
/*     */ 
/*     */           
/* 454 */           DnsNameResolver.preferredAddressType(this.resolvedAddressTypes).addressType()));
/*     */   }
/*     */   
/*     */   private DnsCnameCache newCnameCache() {
/* 458 */     return new DefaultDnsCnameCache(
/* 459 */         ObjectUtil.intValue(this.minTtl, 0), ObjectUtil.intValue(this.maxTtl, 2147483647));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DnsNameResolverBuilder decodeIdn(boolean decodeIdn) {
/* 470 */     this.decodeIdn = decodeIdn;
/* 471 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DnsNameResolverBuilder consolidateCacheSize(int maxNumConsolidation) {
/* 484 */     this.maxNumConsolidation = ObjectUtil.checkPositiveOrZero(maxNumConsolidation, "maxNumConsolidation");
/* 485 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DnsNameResolver build() {
/* 494 */     if (this.eventLoop == null) {
/* 495 */       throw new IllegalStateException("eventLoop should be specified to build a DnsNameResolver.");
/*     */     }
/*     */     
/* 498 */     if (this.resolveCache != null && (this.minTtl != null || this.maxTtl != null || this.negativeTtl != null)) {
/* 499 */       logger.debug("resolveCache and TTLs are mutually exclusive. TTLs are ignored.");
/*     */     }
/*     */     
/* 502 */     if (this.cnameCache != null && (this.minTtl != null || this.maxTtl != null || this.negativeTtl != null)) {
/* 503 */       logger.debug("cnameCache and TTLs are mutually exclusive. TTLs are ignored.");
/*     */     }
/*     */     
/* 506 */     if (this.authoritativeDnsServerCache != null && (this.minTtl != null || this.maxTtl != null || this.negativeTtl != null)) {
/* 507 */       logger.debug("authoritativeDnsServerCache and TTLs are mutually exclusive. TTLs are ignored.");
/*     */     }
/*     */     
/* 510 */     DnsCache resolveCache = (this.resolveCache != null) ? this.resolveCache : newCache();
/* 511 */     DnsCnameCache cnameCache = (this.cnameCache != null) ? this.cnameCache : newCnameCache();
/*     */     
/* 513 */     AuthoritativeDnsServerCache authoritativeDnsServerCache = (this.authoritativeDnsServerCache != null) ? this.authoritativeDnsServerCache : newAuthoritativeDnsServerCache();
/* 514 */     return new DnsNameResolver(this.eventLoop, this.channelFactory, this.socketChannelFactory, resolveCache, cnameCache, authoritativeDnsServerCache, this.localAddress, this.dnsQueryLifecycleObserverFactory, this.queryTimeoutMillis, this.resolvedAddressTypes, this.recursionDesired, this.maxQueriesPerResolve, this.traceEnabled, this.maxPayloadSize, this.optResourceEnabled, this.hostsFileEntriesResolver, this.dnsServerAddressStreamProvider, this.searchDomains, this.ndots, this.decodeIdn, this.completeOncePreferredResolved, this.maxNumConsolidation);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DnsNameResolverBuilder copy() {
/* 545 */     DnsNameResolverBuilder copiedBuilder = new DnsNameResolverBuilder();
/*     */     
/* 547 */     if (this.eventLoop != null) {
/* 548 */       copiedBuilder.eventLoop(this.eventLoop);
/*     */     }
/*     */     
/* 551 */     if (this.channelFactory != null) {
/* 552 */       copiedBuilder.channelFactory(this.channelFactory);
/*     */     }
/*     */     
/* 555 */     if (this.socketChannelFactory != null) {
/* 556 */       copiedBuilder.socketChannelFactory(this.socketChannelFactory);
/*     */     }
/*     */     
/* 559 */     if (this.resolveCache != null) {
/* 560 */       copiedBuilder.resolveCache(this.resolveCache);
/*     */     }
/*     */     
/* 563 */     if (this.cnameCache != null) {
/* 564 */       copiedBuilder.cnameCache(this.cnameCache);
/*     */     }
/* 566 */     if (this.maxTtl != null && this.minTtl != null) {
/* 567 */       copiedBuilder.ttl(this.minTtl.intValue(), this.maxTtl.intValue());
/*     */     }
/*     */     
/* 570 */     if (this.negativeTtl != null) {
/* 571 */       copiedBuilder.negativeTtl(this.negativeTtl.intValue());
/*     */     }
/*     */     
/* 574 */     if (this.authoritativeDnsServerCache != null) {
/* 575 */       copiedBuilder.authoritativeDnsServerCache(this.authoritativeDnsServerCache);
/*     */     }
/*     */     
/* 578 */     if (this.dnsQueryLifecycleObserverFactory != null) {
/* 579 */       copiedBuilder.dnsQueryLifecycleObserverFactory(this.dnsQueryLifecycleObserverFactory);
/*     */     }
/*     */     
/* 582 */     copiedBuilder.queryTimeoutMillis(this.queryTimeoutMillis);
/* 583 */     copiedBuilder.resolvedAddressTypes(this.resolvedAddressTypes);
/* 584 */     copiedBuilder.recursionDesired(this.recursionDesired);
/* 585 */     copiedBuilder.maxQueriesPerResolve(this.maxQueriesPerResolve);
/* 586 */     copiedBuilder.traceEnabled(this.traceEnabled);
/* 587 */     copiedBuilder.maxPayloadSize(this.maxPayloadSize);
/* 588 */     copiedBuilder.optResourceEnabled(this.optResourceEnabled);
/* 589 */     copiedBuilder.hostsFileEntriesResolver(this.hostsFileEntriesResolver);
/*     */     
/* 591 */     if (this.dnsServerAddressStreamProvider != null) {
/* 592 */       copiedBuilder.nameServerProvider(this.dnsServerAddressStreamProvider);
/*     */     }
/*     */     
/* 595 */     if (this.searchDomains != null) {
/* 596 */       copiedBuilder.searchDomains(Arrays.asList(this.searchDomains));
/*     */     }
/*     */     
/* 599 */     copiedBuilder.ndots(this.ndots);
/* 600 */     copiedBuilder.decodeIdn(this.decodeIdn);
/* 601 */     copiedBuilder.completeOncePreferredResolved(this.completeOncePreferredResolved);
/* 602 */     copiedBuilder.localAddress(this.localAddress);
/* 603 */     copiedBuilder.consolidateCacheSize(this.maxNumConsolidation);
/* 604 */     return copiedBuilder;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-resolver-dns-4.1.93.Final.jar!\io\netty\resolver\dns\DnsNameResolverBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */