/*    */ package io.netty.resolver.dns;
/*    */ 
/*    */ import io.netty.handler.codec.dns.DnsQuestion;
/*    */ import io.netty.util.internal.EmptyArrays;
/*    */ import io.netty.util.internal.ObjectUtil;
/*    */ import java.net.InetSocketAddress;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DnsNameResolverException
/*    */   extends RuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = -8826717909627131850L;
/*    */   private final InetSocketAddress remoteAddress;
/*    */   private final DnsQuestion question;
/*    */   
/*    */   public DnsNameResolverException(InetSocketAddress remoteAddress, DnsQuestion question, String message) {
/* 35 */     super(message);
/* 36 */     this.remoteAddress = validateRemoteAddress(remoteAddress);
/* 37 */     this.question = validateQuestion(question);
/*    */   }
/*    */ 
/*    */   
/*    */   public DnsNameResolverException(InetSocketAddress remoteAddress, DnsQuestion question, String message, Throwable cause) {
/* 42 */     super(message, cause);
/* 43 */     this.remoteAddress = validateRemoteAddress(remoteAddress);
/* 44 */     this.question = validateQuestion(question);
/*    */   }
/*    */   
/*    */   private static InetSocketAddress validateRemoteAddress(InetSocketAddress remoteAddress) {
/* 48 */     return (InetSocketAddress)ObjectUtil.checkNotNull(remoteAddress, "remoteAddress");
/*    */   }
/*    */   
/*    */   private static DnsQuestion validateQuestion(DnsQuestion question) {
/* 52 */     return (DnsQuestion)ObjectUtil.checkNotNull(question, "question");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public InetSocketAddress remoteAddress() {
/* 59 */     return this.remoteAddress;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public DnsQuestion question() {
/* 66 */     return this.question;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Throwable fillInStackTrace() {
/* 72 */     setStackTrace(EmptyArrays.EMPTY_STACK_TRACE);
/* 73 */     return this;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-resolver-dns-4.1.93.Final.jar!\io\netty\resolver\dns\DnsNameResolverException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */