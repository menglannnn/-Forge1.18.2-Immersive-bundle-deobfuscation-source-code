/*     */ package io.netty.resolver.dns;
/*     */ 
/*     */ import io.netty.channel.ChannelFactory;
/*     */ import io.netty.channel.EventLoop;
/*     */ import io.netty.channel.socket.DatagramChannel;
/*     */ import io.netty.resolver.AddressResolver;
/*     */ import io.netty.resolver.AddressResolverGroup;
/*     */ import io.netty.resolver.InetSocketAddressResolver;
/*     */ import io.netty.resolver.NameResolver;
/*     */ import io.netty.util.concurrent.EventExecutor;
/*     */ import io.netty.util.concurrent.Promise;
/*     */ import io.netty.util.internal.PlatformDependent;
/*     */ import io.netty.util.internal.StringUtil;
/*     */ import java.net.InetAddress;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DnsAddressResolverGroup
/*     */   extends AddressResolverGroup<InetSocketAddress>
/*     */ {
/*     */   private final DnsNameResolverBuilder dnsResolverBuilder;
/*  44 */   private final ConcurrentMap<String, Promise<InetAddress>> resolvesInProgress = PlatformDependent.newConcurrentHashMap();
/*  45 */   private final ConcurrentMap<String, Promise<List<InetAddress>>> resolveAllsInProgress = PlatformDependent.newConcurrentHashMap();
/*     */   
/*     */   public DnsAddressResolverGroup(DnsNameResolverBuilder dnsResolverBuilder) {
/*  48 */     this.dnsResolverBuilder = dnsResolverBuilder.copy();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public DnsAddressResolverGroup(Class<? extends DatagramChannel> channelType, DnsServerAddressStreamProvider nameServerProvider) {
/*  54 */     this.dnsResolverBuilder = new DnsNameResolverBuilder();
/*  55 */     this.dnsResolverBuilder.channelType(channelType).nameServerProvider(nameServerProvider);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public DnsAddressResolverGroup(ChannelFactory<? extends DatagramChannel> channelFactory, DnsServerAddressStreamProvider nameServerProvider) {
/*  61 */     this.dnsResolverBuilder = new DnsNameResolverBuilder();
/*  62 */     this.dnsResolverBuilder.channelFactory(channelFactory).nameServerProvider(nameServerProvider);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected final AddressResolver<InetSocketAddress> newResolver(EventExecutor executor) throws Exception {
/*  68 */     if (!(executor instanceof EventLoop)) {
/*  69 */       throw new IllegalStateException("unsupported executor type: " + 
/*  70 */           StringUtil.simpleClassName(executor) + " (expected: " + 
/*  71 */           StringUtil.simpleClassName(EventLoop.class));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  76 */     EventLoop loop = this.dnsResolverBuilder.eventLoop;
/*  77 */     return newResolver((loop == null) ? (EventLoop)executor : loop, this.dnsResolverBuilder
/*  78 */         .channelFactory(), this.dnsResolverBuilder
/*  79 */         .nameServerProvider());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected AddressResolver<InetSocketAddress> newResolver(EventLoop eventLoop, ChannelFactory<? extends DatagramChannel> channelFactory, DnsServerAddressStreamProvider nameServerProvider) throws Exception {
/*  92 */     NameResolver<InetAddress> resolver = new InflightNameResolver<InetAddress>((EventExecutor)eventLoop, newNameResolver(eventLoop, channelFactory, nameServerProvider), this.resolvesInProgress, this.resolveAllsInProgress);
/*     */ 
/*     */ 
/*     */     
/*  96 */     return newAddressResolver(eventLoop, resolver);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected NameResolver<InetAddress> newNameResolver(EventLoop eventLoop, ChannelFactory<? extends DatagramChannel> channelFactory, DnsServerAddressStreamProvider nameServerProvider) throws Exception {
/* 107 */     DnsNameResolverBuilder builder = this.dnsResolverBuilder.copy();
/*     */ 
/*     */ 
/*     */     
/* 111 */     return (NameResolver<InetAddress>)builder.eventLoop(eventLoop)
/* 112 */       .channelFactory(channelFactory)
/* 113 */       .nameServerProvider(nameServerProvider)
/* 114 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AddressResolver<InetSocketAddress> newAddressResolver(EventLoop eventLoop, NameResolver<InetAddress> resolver) throws Exception {
/* 124 */     return (AddressResolver<InetSocketAddress>)new InetSocketAddressResolver((EventExecutor)eventLoop, resolver);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-resolver-dns-4.1.93.Final.jar!\io\netty\resolver\dns\DnsAddressResolverGroup.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */