/*      */ package io.netty.resolver.dns;
/*      */ 
/*      */ import io.netty.buffer.ByteBuf;
/*      */ import io.netty.buffer.ByteBufHolder;
/*      */ import io.netty.channel.AddressedEnvelope;
/*      */ import io.netty.channel.ChannelFuture;
/*      */ import io.netty.channel.ChannelPromise;
/*      */ import io.netty.channel.EventLoop;
/*      */ import io.netty.handler.codec.CorruptedFrameException;
/*      */ import io.netty.handler.codec.dns.DefaultDnsQuestion;
/*      */ import io.netty.handler.codec.dns.DefaultDnsRecordDecoder;
/*      */ import io.netty.handler.codec.dns.DnsQuestion;
/*      */ import io.netty.handler.codec.dns.DnsRecord;
/*      */ import io.netty.handler.codec.dns.DnsRecordType;
/*      */ import io.netty.handler.codec.dns.DnsResponse;
/*      */ import io.netty.handler.codec.dns.DnsResponseCode;
/*      */ import io.netty.handler.codec.dns.DnsSection;
/*      */ import io.netty.util.ReferenceCountUtil;
/*      */ import io.netty.util.concurrent.Future;
/*      */ import io.netty.util.concurrent.FutureListener;
/*      */ import io.netty.util.concurrent.GenericFutureListener;
/*      */ import io.netty.util.concurrent.Promise;
/*      */ import io.netty.util.internal.ObjectUtil;
/*      */ import io.netty.util.internal.PlatformDependent;
/*      */ import io.netty.util.internal.StringUtil;
/*      */ import io.netty.util.internal.SuppressJava6Requirement;
/*      */ import io.netty.util.internal.ThrowableUtil;
/*      */ import io.netty.util.internal.logging.InternalLogger;
/*      */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*      */ import java.net.InetAddress;
/*      */ import java.net.InetSocketAddress;
/*      */ import java.net.UnknownHostException;
/*      */ import java.util.AbstractList;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.IdentityHashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.NoSuchElementException;
/*      */ import java.util.Set;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ abstract class DnsResolveContext<T>
/*      */ {
/*   67 */   private static final InternalLogger logger = InternalLoggerFactory.getInstance(DnsResolveContext.class);
/*      */ 
/*      */   
/*   70 */   private static final RuntimeException NXDOMAIN_QUERY_FAILED_EXCEPTION = DnsResolveContextException.newStatic("No answer found and NXDOMAIN response code returned", DnsResolveContext.class, "onResponse(..)");
/*      */ 
/*      */   
/*   73 */   private static final RuntimeException CNAME_NOT_FOUND_QUERY_FAILED_EXCEPTION = DnsResolveContextException.newStatic("No matching CNAME record found", DnsResolveContext.class, "onResponseCNAME(..)");
/*      */ 
/*      */   
/*   76 */   private static final RuntimeException NO_MATCHING_RECORD_QUERY_FAILED_EXCEPTION = DnsResolveContextException.newStatic("No matching record type found", DnsResolveContext.class, "onResponseAorAAAA(..)");
/*      */ 
/*      */   
/*   79 */   private static final RuntimeException UNRECOGNIZED_TYPE_QUERY_FAILED_EXCEPTION = DnsResolveContextException.newStatic("Response type was unrecognized", DnsResolveContext.class, "onResponse(..)");
/*      */ 
/*      */   
/*   82 */   private static final RuntimeException NAME_SERVERS_EXHAUSTED_EXCEPTION = DnsResolveContextException.newStatic("No name servers returned an answer", DnsResolveContext.class, "tryToFinishResolve(..)");
/*      */   
/*      */   final DnsNameResolver parent;
/*      */   
/*      */   private final Promise<?> originalPromise;
/*      */   
/*      */   private final DnsServerAddressStream nameServerAddrs;
/*      */   
/*      */   private final String hostname;
/*      */   private final int dnsClass;
/*      */   private final DnsRecordType[] expectedTypes;
/*      */   final DnsRecord[] additionals;
/*   94 */   private final Set<Future<AddressedEnvelope<DnsResponse, InetSocketAddress>>> queriesInProgress = Collections.newSetFromMap(new IdentityHashMap<Future<AddressedEnvelope<DnsResponse, InetSocketAddress>>, Boolean>());
/*      */   
/*      */   private List<T> finalResult;
/*      */   
/*      */   private int allowedQueries;
/*      */   
/*      */   private boolean triedCNAME;
/*      */   
/*      */   private boolean completeEarly;
/*      */   
/*      */   DnsResolveContext(DnsNameResolver parent, Promise<?> originalPromise, String hostname, int dnsClass, DnsRecordType[] expectedTypes, DnsRecord[] additionals, DnsServerAddressStream nameServerAddrs, int allowedQueries) {
/*  105 */     assert expectedTypes.length > 0;
/*      */     
/*  107 */     this.parent = parent;
/*  108 */     this.originalPromise = originalPromise;
/*  109 */     this.hostname = hostname;
/*  110 */     this.dnsClass = dnsClass;
/*  111 */     this.expectedTypes = expectedTypes;
/*  112 */     this.additionals = additionals;
/*      */     
/*  114 */     this.nameServerAddrs = (DnsServerAddressStream)ObjectUtil.checkNotNull(nameServerAddrs, "nameServerAddrs");
/*  115 */     this.allowedQueries = allowedQueries;
/*      */   }
/*      */   
/*      */   static final class DnsResolveContextException
/*      */     extends RuntimeException {
/*      */     private static final long serialVersionUID = 1209303419266433003L;
/*      */     
/*      */     private DnsResolveContextException(String message) {
/*  123 */       super(message);
/*      */     }
/*      */ 
/*      */     
/*      */     @SuppressJava6Requirement(reason = "uses Java 7+ Exception.<init>(String, Throwable, boolean, boolean) but is guarded by version checks")
/*      */     private DnsResolveContextException(String message, boolean shared) {
/*  129 */       super(message, null, false, true);
/*  130 */       assert shared;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Throwable fillInStackTrace() {
/*  137 */       return this;
/*      */     }
/*      */     
/*      */     static DnsResolveContextException newStatic(String message, Class<?> clazz, String method) {
/*      */       DnsResolveContextException exception;
/*  142 */       if (PlatformDependent.javaVersion() >= 7) {
/*  143 */         exception = new DnsResolveContextException(message, true);
/*      */       } else {
/*  145 */         exception = new DnsResolveContextException(message);
/*      */       } 
/*  147 */       return (DnsResolveContextException)ThrowableUtil.unknownStackTrace(exception, clazz, method);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   DnsCache resolveCache() {
/*  155 */     return this.parent.resolveCache();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   DnsCnameCache cnameCache() {
/*  162 */     return this.parent.cnameCache();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   AuthoritativeDnsServerCache authoritativeDnsServerCache() {
/*  169 */     return this.parent.authoritativeDnsServerCache();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void resolve(final Promise<List<T>> promise) {
/*  213 */     final String[] searchDomains = this.parent.searchDomains();
/*  214 */     if (searchDomains.length == 0 || this.parent.ndots() == 0 || StringUtil.endsWith(this.hostname, '.')) {
/*  215 */       internalResolve(this.hostname, promise);
/*      */     } else {
/*  217 */       final boolean startWithoutSearchDomain = hasNDots();
/*  218 */       String initialHostname = startWithoutSearchDomain ? this.hostname : (this.hostname + '.' + searchDomains[0]);
/*  219 */       final int initialSearchDomainIdx = startWithoutSearchDomain ? 0 : 1;
/*      */       
/*  221 */       Promise<List<T>> searchDomainPromise = this.parent.executor().newPromise();
/*  222 */       searchDomainPromise.addListener((GenericFutureListener)new FutureListener<List<T>>() {
/*  223 */             private int searchDomainIdx = initialSearchDomainIdx;
/*      */             
/*      */             public void operationComplete(Future<List<T>> future) {
/*  226 */               Throwable cause = future.cause();
/*  227 */               if (cause == null) {
/*  228 */                 List<T> result = (List<T>)future.getNow();
/*  229 */                 if (!promise.trySuccess(result)) {
/*  230 */                   for (T item : result) {
/*  231 */                     ReferenceCountUtil.safeRelease(item);
/*      */                   }
/*      */                 }
/*      */               }
/*  235 */               else if (DnsNameResolver.isTransportOrTimeoutError(cause)) {
/*  236 */                 promise.tryFailure(new DnsResolveContext.SearchDomainUnknownHostException(cause, DnsResolveContext.this.hostname, DnsResolveContext.this.expectedTypes, searchDomains));
/*      */               }
/*  238 */               else if (this.searchDomainIdx < searchDomains.length) {
/*  239 */                 Promise<List<T>> newPromise = DnsResolveContext.this.parent.executor().newPromise();
/*  240 */                 newPromise.addListener((GenericFutureListener)this);
/*  241 */                 DnsResolveContext.this.doSearchDomainQuery(DnsResolveContext.this.hostname + '.' + searchDomains[this.searchDomainIdx++], newPromise);
/*  242 */               } else if (!startWithoutSearchDomain) {
/*  243 */                 DnsResolveContext.this.internalResolve(DnsResolveContext.this.hostname, promise);
/*      */               } else {
/*  245 */                 promise.tryFailure(new DnsResolveContext.SearchDomainUnknownHostException(cause, DnsResolveContext.this.hostname, DnsResolveContext.this.expectedTypes, searchDomains));
/*      */               } 
/*      */             }
/*      */           });
/*      */ 
/*      */       
/*  251 */       doSearchDomainQuery(initialHostname, searchDomainPromise);
/*      */     } 
/*      */   }
/*      */   
/*      */   private boolean hasNDots() {
/*  256 */     for (int idx = this.hostname.length() - 1, dots = 0; idx >= 0; idx--) {
/*  257 */       if (this.hostname.charAt(idx) == '.' && ++dots >= this.parent.ndots()) {
/*  258 */         return true;
/*      */       }
/*      */     } 
/*  261 */     return false;
/*      */   }
/*      */   
/*      */   private static final class SearchDomainUnknownHostException
/*      */     extends UnknownHostException {
/*      */     private static final long serialVersionUID = -8573510133644997085L;
/*      */     
/*      */     SearchDomainUnknownHostException(Throwable cause, String originalHostname, DnsRecordType[] queryTypes, String[] searchDomains) {
/*  269 */       super("Failed to resolve '" + originalHostname + "' " + Arrays.toString((Object[])queryTypes) + " and search domain query for configured domains failed as well: " + 
/*      */           
/*  271 */           Arrays.toString((Object[])searchDomains));
/*  272 */       setStackTrace(cause.getStackTrace());
/*      */       
/*  274 */       initCause(cause.getCause());
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Throwable fillInStackTrace() {
/*  280 */       return this;
/*      */     }
/*      */   }
/*      */   
/*      */   void doSearchDomainQuery(String hostname, Promise<List<T>> nextPromise) {
/*  285 */     DnsResolveContext<T> nextContext = newResolverContext(this.parent, this.originalPromise, hostname, this.dnsClass, this.expectedTypes, this.additionals, this.nameServerAddrs, this.parent
/*      */         
/*  287 */         .maxQueriesPerResolve());
/*  288 */     nextContext.internalResolve(hostname, nextPromise);
/*      */   }
/*      */   
/*      */   private static String hostnameWithDot(String name) {
/*  292 */     if (StringUtil.endsWith(name, '.')) {
/*  293 */       return name;
/*      */     }
/*  295 */     return name + '.';
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static String cnameResolveFromCache(DnsCnameCache cnameCache, String name) throws UnknownHostException {
/*  303 */     String first = cnameCache.get(hostnameWithDot(name));
/*  304 */     if (first == null)
/*      */     {
/*  306 */       return name;
/*      */     }
/*      */     
/*  309 */     String second = cnameCache.get(hostnameWithDot(first));
/*  310 */     if (second == null)
/*      */     {
/*  312 */       return first;
/*      */     }
/*      */     
/*  315 */     checkCnameLoop(name, first, second);
/*  316 */     return cnameResolveFromCacheLoop(cnameCache, name, first, second);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String cnameResolveFromCacheLoop(DnsCnameCache cnameCache, String hostname, String first, String mapping) throws UnknownHostException {
/*  323 */     boolean advance = false;
/*      */     
/*  325 */     String name = mapping;
/*      */     
/*  327 */     while ((mapping = cnameCache.get(hostnameWithDot(name))) != null) {
/*  328 */       checkCnameLoop(hostname, first, mapping);
/*  329 */       name = mapping;
/*  330 */       if (advance) {
/*  331 */         first = cnameCache.get(first);
/*      */       }
/*  333 */       advance = !advance;
/*      */     } 
/*  335 */     return name;
/*      */   }
/*      */   
/*      */   private static void checkCnameLoop(String hostname, String first, String second) throws UnknownHostException {
/*  339 */     if (first.equals(second))
/*      */     {
/*  341 */       throw new UnknownHostException("CNAME loop detected for '" + hostname + '\'');
/*      */     }
/*      */   }
/*      */   
/*      */   private void internalResolve(String name, Promise<List<T>> promise) {
/*      */     try {
/*  347 */       name = cnameResolveFromCache(cnameCache(), name);
/*  348 */     } catch (Throwable cause) {
/*  349 */       promise.tryFailure(cause);
/*      */       
/*      */       return;
/*      */     } 
/*      */     try {
/*  354 */       DnsServerAddressStream nameServerAddressStream = getNameServers(name);
/*      */       
/*  356 */       int end = this.expectedTypes.length - 1;
/*  357 */       for (int i = 0; i < end; i++) {
/*  358 */         if (!query(name, this.expectedTypes[i], nameServerAddressStream.duplicate(), false, promise)) {
/*      */           return;
/*      */         }
/*      */       } 
/*  362 */       query(name, this.expectedTypes[end], nameServerAddressStream, false, promise);
/*      */     } finally {
/*      */       
/*  365 */       this.parent.flushQueries();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private DnsServerAddressStream getNameServersFromCache(String hostname) {
/*      */     DnsServerAddressStream entries;
/*  374 */     int len = hostname.length();
/*      */     
/*  376 */     if (len == 0)
/*      */     {
/*  378 */       return null;
/*      */     }
/*      */ 
/*      */     
/*  382 */     if (hostname.charAt(len - 1) != '.') {
/*  383 */       hostname = hostname + ".";
/*      */     }
/*      */     
/*  386 */     int idx = hostname.indexOf('.');
/*  387 */     if (idx == hostname.length() - 1)
/*      */     {
/*  389 */       return null;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     do {
/*  395 */       hostname = hostname.substring(idx + 1);
/*      */       
/*  397 */       int idx2 = hostname.indexOf('.');
/*  398 */       if (idx2 <= 0 || idx2 == hostname.length() - 1)
/*      */       {
/*  400 */         return null;
/*      */       }
/*  402 */       idx = idx2;
/*      */       
/*  404 */       entries = authoritativeDnsServerCache().get(hostname);
/*  405 */     } while (entries == null);
/*      */ 
/*      */     
/*  408 */     return entries;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void query(final DnsServerAddressStream nameServerAddrStream, final int nameServerAddrStreamIndex, final DnsQuestion question, final DnsQueryLifecycleObserver queryLifecycleObserver, boolean flush, final Promise<List<T>> promise, Throwable cause) {
/*      */     final long queryStartTimeNanos;
/*      */     final boolean isFeedbackAddressStream;
/*  420 */     if (this.completeEarly || nameServerAddrStreamIndex >= nameServerAddrStream.size() || this.allowedQueries == 0 || this.originalPromise
/*  421 */       .isCancelled() || promise.isCancelled()) {
/*  422 */       tryToFinishResolve(nameServerAddrStream, nameServerAddrStreamIndex, question, queryLifecycleObserver, promise, cause);
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/*  427 */     this.allowedQueries--;
/*      */     
/*  429 */     final InetSocketAddress nameServerAddr = nameServerAddrStream.next();
/*  430 */     if (nameServerAddr.isUnresolved()) {
/*  431 */       queryUnresolvedNameServer(nameServerAddr, nameServerAddrStream, nameServerAddrStreamIndex, question, queryLifecycleObserver, promise, cause);
/*      */       
/*      */       return;
/*      */     } 
/*  435 */     ChannelPromise writePromise = this.parent.ch.newPromise();
/*      */     
/*  437 */     Promise<AddressedEnvelope<? extends DnsResponse, InetSocketAddress>> queryPromise = this.parent.ch.eventLoop().newPromise();
/*      */ 
/*      */ 
/*      */     
/*  441 */     if (nameServerAddrStream instanceof DnsServerResponseFeedbackAddressStream) {
/*  442 */       queryStartTimeNanos = System.nanoTime();
/*  443 */       isFeedbackAddressStream = true;
/*      */     } else {
/*  445 */       queryStartTimeNanos = -1L;
/*  446 */       isFeedbackAddressStream = false;
/*      */     } 
/*      */ 
/*      */     
/*  450 */     Future<AddressedEnvelope<DnsResponse, InetSocketAddress>> f = this.parent.query0(nameServerAddr, question, this.additionals, flush, writePromise, queryPromise);
/*      */     
/*  452 */     this.queriesInProgress.add(f);
/*      */     
/*  454 */     queryLifecycleObserver.queryWritten(nameServerAddr, (ChannelFuture)writePromise);
/*      */     
/*  456 */     f.addListener((GenericFutureListener)new FutureListener<AddressedEnvelope<DnsResponse, InetSocketAddress>>()
/*      */         {
/*      */           public void operationComplete(Future<AddressedEnvelope<DnsResponse, InetSocketAddress>> future) {
/*  459 */             DnsResolveContext.this.queriesInProgress.remove(future);
/*      */             
/*  461 */             if (promise.isDone() || future.isCancelled()) {
/*  462 */               queryLifecycleObserver.queryCancelled(DnsResolveContext.this.allowedQueries);
/*      */ 
/*      */ 
/*      */               
/*  466 */               AddressedEnvelope<DnsResponse, InetSocketAddress> result = (AddressedEnvelope<DnsResponse, InetSocketAddress>)future.getNow();
/*  467 */               if (result != null) {
/*  468 */                 result.release();
/*      */               }
/*      */               
/*      */               return;
/*      */             } 
/*  473 */             Throwable queryCause = future.cause();
/*      */             try {
/*  475 */               if (queryCause == null) {
/*  476 */                 if (isFeedbackAddressStream) {
/*  477 */                   DnsServerResponseFeedbackAddressStream feedbackNameServerAddrStream = (DnsServerResponseFeedbackAddressStream)nameServerAddrStream;
/*      */                   
/*  479 */                   feedbackNameServerAddrStream.feedbackSuccess(nameServerAddr, 
/*  480 */                       System.nanoTime() - queryStartTimeNanos);
/*      */                 } 
/*  482 */                 DnsResolveContext.this.onResponse(nameServerAddrStream, nameServerAddrStreamIndex, question, (AddressedEnvelope)future.getNow(), queryLifecycleObserver, promise);
/*      */               }
/*      */               else {
/*      */                 
/*  486 */                 if (isFeedbackAddressStream) {
/*  487 */                   DnsServerResponseFeedbackAddressStream feedbackNameServerAddrStream = (DnsServerResponseFeedbackAddressStream)nameServerAddrStream;
/*      */                   
/*  489 */                   feedbackNameServerAddrStream.feedbackFailure(nameServerAddr, queryCause, 
/*  490 */                       System.nanoTime() - queryStartTimeNanos);
/*      */                 } 
/*  492 */                 queryLifecycleObserver.queryFailed(queryCause);
/*  493 */                 DnsResolveContext.this.query(nameServerAddrStream, nameServerAddrStreamIndex + 1, question, DnsResolveContext.this
/*  494 */                     .newDnsQueryLifecycleObserver(question), true, promise, queryCause);
/*      */               } 
/*      */             } finally {
/*  497 */               DnsResolveContext.this.tryToFinishResolve(nameServerAddrStream, nameServerAddrStreamIndex, question, NoopDnsQueryLifecycleObserver.INSTANCE, promise, queryCause);
/*      */             } 
/*      */           }
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void queryUnresolvedNameServer(final InetSocketAddress nameServerAddr, final DnsServerAddressStream nameServerAddrStream, final int nameServerAddrStreamIndex, final DnsQuestion question, final DnsQueryLifecycleObserver queryLifecycleObserver, final Promise<List<T>> promise, final Throwable cause) {
/*  515 */     String nameServerName = (PlatformDependent.javaVersion() >= 7) ? nameServerAddr.getHostString() : nameServerAddr.getHostName();
/*  516 */     assert nameServerName != null;
/*      */ 
/*      */ 
/*      */     
/*  520 */     final Future<AddressedEnvelope<DnsResponse, InetSocketAddress>> resolveFuture = this.parent.executor().newSucceededFuture(null);
/*  521 */     this.queriesInProgress.add(resolveFuture);
/*      */     
/*  523 */     Promise<List<InetAddress>> resolverPromise = this.parent.executor().newPromise();
/*  524 */     resolverPromise.addListener((GenericFutureListener)new FutureListener<List<InetAddress>>()
/*      */         {
/*      */           public void operationComplete(Future<List<InetAddress>> future)
/*      */           {
/*  528 */             DnsResolveContext.this.queriesInProgress.remove(resolveFuture);
/*      */             
/*  530 */             if (future.isSuccess()) {
/*  531 */               List<InetAddress> resolvedAddresses = (List<InetAddress>)future.getNow();
/*  532 */               DnsServerAddressStream addressStream = new DnsResolveContext.CombinedDnsServerAddressStream(nameServerAddr, resolvedAddresses, nameServerAddrStream);
/*      */               
/*  534 */               DnsResolveContext.this.query(addressStream, nameServerAddrStreamIndex, question, queryLifecycleObserver, true, promise, cause);
/*      */             }
/*      */             else {
/*      */               
/*  538 */               DnsResolveContext.this.query(nameServerAddrStream, nameServerAddrStreamIndex + 1, question, queryLifecycleObserver, true, promise, cause);
/*      */             } 
/*      */           }
/*      */         });
/*      */     
/*  543 */     DnsCache resolveCache = resolveCache();
/*  544 */     if (!DnsNameResolver.doResolveAllCached(nameServerName, this.additionals, resolverPromise, resolveCache, this.parent
/*  545 */         .resolvedInternetProtocolFamiliesUnsafe()))
/*      */     {
/*  547 */       (new DnsAddressResolveContext(this.parent, this.originalPromise, nameServerName, this.additionals, this.parent
/*  548 */           .newNameServerAddressStream(nameServerName), this.allowedQueries, resolveCache, 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  553 */           redirectAuthoritativeDnsServerCache(authoritativeDnsServerCache()), false))
/*  554 */         .resolve(resolverPromise);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static AuthoritativeDnsServerCache redirectAuthoritativeDnsServerCache(AuthoritativeDnsServerCache authoritativeDnsServerCache) {
/*  562 */     if (authoritativeDnsServerCache instanceof RedirectAuthoritativeDnsServerCache) {
/*  563 */       return authoritativeDnsServerCache;
/*      */     }
/*  565 */     return new RedirectAuthoritativeDnsServerCache(authoritativeDnsServerCache);
/*      */   }
/*      */   
/*      */   private static final class RedirectAuthoritativeDnsServerCache implements AuthoritativeDnsServerCache {
/*      */     private final AuthoritativeDnsServerCache wrapped;
/*      */     
/*      */     RedirectAuthoritativeDnsServerCache(AuthoritativeDnsServerCache authoritativeDnsServerCache) {
/*  572 */       this.wrapped = authoritativeDnsServerCache;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public DnsServerAddressStream get(String hostname) {
/*  579 */       return null;
/*      */     }
/*      */ 
/*      */     
/*      */     public void cache(String hostname, InetSocketAddress address, long originalTtl, EventLoop loop) {
/*  584 */       this.wrapped.cache(hostname, address, originalTtl, loop);
/*      */     }
/*      */ 
/*      */     
/*      */     public void clear() {
/*  589 */       this.wrapped.clear();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean clear(String hostname) {
/*  594 */       return this.wrapped.clear(hostname);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void onResponse(DnsServerAddressStream nameServerAddrStream, int nameServerAddrStreamIndex, DnsQuestion question, AddressedEnvelope<DnsResponse, InetSocketAddress> envelope, DnsQueryLifecycleObserver queryLifecycleObserver, Promise<List<T>> promise) {
/*      */     try {
/*  603 */       DnsResponse res = (DnsResponse)envelope.content();
/*  604 */       DnsResponseCode code = res.code();
/*  605 */       if (code == DnsResponseCode.NOERROR) {
/*  606 */         if (handleRedirect(question, envelope, queryLifecycleObserver, promise)) {
/*      */           return;
/*      */         }
/*      */         
/*  610 */         DnsRecordType type = question.type();
/*      */         
/*  612 */         if (type == DnsRecordType.CNAME) {
/*  613 */           onResponseCNAME(question, buildAliasMap((DnsResponse)envelope.content(), cnameCache(), this.parent.executor()), queryLifecycleObserver, promise);
/*      */           
/*      */           return;
/*      */         } 
/*      */         
/*  618 */         for (DnsRecordType expectedType : this.expectedTypes) {
/*  619 */           if (type == expectedType) {
/*  620 */             onExpectedResponse(question, envelope, queryLifecycleObserver, promise);
/*      */             
/*      */             return;
/*      */           } 
/*      */         } 
/*  625 */         queryLifecycleObserver.queryFailed(UNRECOGNIZED_TYPE_QUERY_FAILED_EXCEPTION);
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/*  630 */       if (code != DnsResponseCode.NXDOMAIN) {
/*  631 */         query(nameServerAddrStream, nameServerAddrStreamIndex + 1, question, queryLifecycleObserver
/*  632 */             .queryNoAnswer(code), true, promise, null);
/*      */       } else {
/*  634 */         queryLifecycleObserver.queryFailed(NXDOMAIN_QUERY_FAILED_EXCEPTION);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  654 */         if (!res.isAuthoritativeAnswer()) {
/*  655 */           query(nameServerAddrStream, nameServerAddrStreamIndex + 1, question, 
/*  656 */               newDnsQueryLifecycleObserver(question), true, promise, null);
/*      */         }
/*      */       } 
/*      */     } finally {
/*  660 */       ReferenceCountUtil.safeRelease(envelope);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean handleRedirect(DnsQuestion question, AddressedEnvelope<DnsResponse, InetSocketAddress> envelope, DnsQueryLifecycleObserver queryLifecycleObserver, Promise<List<T>> promise) {
/*  670 */     DnsResponse res = (DnsResponse)envelope.content();
/*      */ 
/*      */     
/*  673 */     if (res.count(DnsSection.ANSWER) == 0) {
/*  674 */       AuthoritativeNameServerList serverNames = extractAuthoritativeNameServers(question.name(), res);
/*  675 */       if (serverNames != null) {
/*  676 */         int additionalCount = res.count(DnsSection.ADDITIONAL);
/*      */         
/*  678 */         AuthoritativeDnsServerCache authoritativeDnsServerCache = authoritativeDnsServerCache();
/*  679 */         for (int i = 0; i < additionalCount; i++) {
/*  680 */           DnsRecord r = res.recordAt(DnsSection.ADDITIONAL, i);
/*      */           
/*  682 */           if ((r.type() != DnsRecordType.A || this.parent.supportsARecords()) && (r
/*  683 */             .type() != DnsRecordType.AAAA || this.parent.supportsAAAARecords()))
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  689 */             serverNames.handleWithAdditional(this.parent, r, authoritativeDnsServerCache);
/*      */           }
/*      */         } 
/*      */         
/*  693 */         serverNames.handleWithoutAdditionals(this.parent, resolveCache(), authoritativeDnsServerCache);
/*      */         
/*  695 */         List<InetSocketAddress> addresses = serverNames.addressList();
/*      */ 
/*      */         
/*  698 */         DnsServerAddressStream serverStream = this.parent.newRedirectDnsServerStream(question
/*  699 */             .name(), addresses);
/*      */         
/*  701 */         if (serverStream != null) {
/*  702 */           query(serverStream, 0, question, queryLifecycleObserver
/*  703 */               .queryRedirected(new DnsAddressStreamList(serverStream)), true, promise, null);
/*      */           
/*  705 */           return true;
/*      */         } 
/*      */       } 
/*      */     } 
/*  709 */     return false;
/*      */   }
/*      */   
/*      */   private static final class DnsAddressStreamList
/*      */     extends AbstractList<InetSocketAddress> {
/*      */     private final DnsServerAddressStream duplicate;
/*      */     private List<InetSocketAddress> addresses;
/*      */     
/*      */     DnsAddressStreamList(DnsServerAddressStream stream) {
/*  718 */       this.duplicate = stream.duplicate();
/*      */     }
/*      */ 
/*      */     
/*      */     public InetSocketAddress get(int index) {
/*  723 */       if (this.addresses == null) {
/*  724 */         DnsServerAddressStream stream = this.duplicate.duplicate();
/*  725 */         this.addresses = new ArrayList<InetSocketAddress>(size());
/*  726 */         for (int i = 0; i < stream.size(); i++) {
/*  727 */           this.addresses.add(stream.next());
/*      */         }
/*      */       } 
/*  730 */       return this.addresses.get(index);
/*      */     }
/*      */ 
/*      */     
/*      */     public int size() {
/*  735 */       return this.duplicate.size();
/*      */     }
/*      */ 
/*      */     
/*      */     public Iterator<InetSocketAddress> iterator() {
/*  740 */       return new Iterator<InetSocketAddress>() {
/*  741 */           private final DnsServerAddressStream stream = DnsResolveContext.DnsAddressStreamList.this.duplicate.duplicate();
/*      */           
/*      */           private int i;
/*      */           
/*      */           public boolean hasNext() {
/*  746 */             return (this.i < this.stream.size());
/*      */           }
/*      */ 
/*      */           
/*      */           public InetSocketAddress next() {
/*  751 */             if (!hasNext()) {
/*  752 */               throw new NoSuchElementException();
/*      */             }
/*  754 */             this.i++;
/*  755 */             return this.stream.next();
/*      */           }
/*      */ 
/*      */           
/*      */           public void remove() {
/*  760 */             throw new UnsupportedOperationException();
/*      */           }
/*      */         };
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static AuthoritativeNameServerList extractAuthoritativeNameServers(String questionName, DnsResponse res) {
/*  771 */     int authorityCount = res.count(DnsSection.AUTHORITY);
/*  772 */     if (authorityCount == 0) {
/*  773 */       return null;
/*      */     }
/*      */     
/*  776 */     AuthoritativeNameServerList serverNames = new AuthoritativeNameServerList(questionName);
/*  777 */     for (int i = 0; i < authorityCount; i++) {
/*  778 */       serverNames.add(res.recordAt(DnsSection.AUTHORITY, i));
/*      */     }
/*  780 */     return serverNames.isEmpty() ? null : serverNames;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void onExpectedResponse(DnsQuestion question, AddressedEnvelope<DnsResponse, InetSocketAddress> envelope, DnsQueryLifecycleObserver queryLifecycleObserver, Promise<List<T>> promise) {
/*  788 */     DnsResponse response = (DnsResponse)envelope.content();
/*  789 */     Map<String, String> cnames = buildAliasMap(response, cnameCache(), this.parent.executor());
/*  790 */     int answerCount = response.count(DnsSection.ANSWER);
/*      */     
/*  792 */     boolean found = false;
/*  793 */     boolean completeEarly = this.completeEarly;
/*  794 */     boolean cnameNeedsFollow = !cnames.isEmpty();
/*  795 */     for (int i = 0; i < answerCount; i++) {
/*  796 */       DnsRecord r = response.recordAt(DnsSection.ANSWER, i);
/*  797 */       DnsRecordType type = r.type();
/*  798 */       boolean matches = false;
/*  799 */       for (DnsRecordType expectedType : this.expectedTypes) {
/*  800 */         if (type == expectedType) {
/*  801 */           matches = true;
/*      */           
/*      */           break;
/*      */         } 
/*      */       } 
/*  806 */       if (!matches) {
/*      */         continue;
/*      */       }
/*      */       
/*  810 */       String questionName = question.name().toLowerCase(Locale.US);
/*  811 */       String recordName = r.name().toLowerCase(Locale.US);
/*      */ 
/*      */       
/*  814 */       if (!recordName.equals(questionName)) {
/*  815 */         Map<String, String> cnamesCopy = new HashMap<String, String>(cnames);
/*      */         
/*  817 */         String resolved = questionName;
/*      */         do {
/*  819 */           resolved = cnamesCopy.remove(resolved);
/*  820 */           if (recordName.equals(resolved)) {
/*      */             
/*  822 */             cnameNeedsFollow = false;
/*      */             break;
/*      */           } 
/*  825 */         } while (resolved != null);
/*      */         
/*  827 */         if (resolved == null) {
/*  828 */           assert questionName.isEmpty() || questionName.charAt(questionName.length() - 1) == '.';
/*      */           
/*  830 */           for (String searchDomain : this.parent.searchDomains()) {
/*  831 */             if (!searchDomain.isEmpty()) {
/*      */               String fqdn;
/*      */ 
/*      */ 
/*      */               
/*  836 */               if (searchDomain.charAt(searchDomain.length() - 1) == '.') {
/*  837 */                 fqdn = questionName + searchDomain;
/*      */               } else {
/*  839 */                 fqdn = questionName + searchDomain + '.';
/*      */               } 
/*  841 */               if (recordName.equals(fqdn)) {
/*  842 */                 resolved = recordName; break;
/*      */               } 
/*      */             } 
/*      */           } 
/*  846 */           if (resolved == null) {
/*  847 */             if (logger.isDebugEnabled()) {
/*  848 */               logger.debug("Ignoring record {} as it contains a different name than the question name [{}]. Cnames: {}, Search domains: {}", new Object[] { r
/*      */                     
/*  850 */                     .toString(), questionName, cnames, this.parent.searchDomains() });
/*      */             }
/*      */             
/*      */             continue;
/*      */           } 
/*      */         } 
/*      */       } 
/*  857 */       T converted = convertRecord(r, this.hostname, this.additionals, this.parent.executor());
/*  858 */       if (converted == null) {
/*  859 */         if (logger.isDebugEnabled()) {
/*  860 */           logger.debug("Ignoring record {} as the converted record is null. hostname [{}], Additionals: {}", new Object[] { r
/*  861 */                 .toString(), this.hostname, this.additionals });
/*      */         }
/*      */       }
/*      */       else {
/*      */         
/*  866 */         boolean shouldRelease = false;
/*      */ 
/*      */         
/*  869 */         if (!completeEarly) {
/*  870 */           completeEarly = isCompleteEarly(converted);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*  875 */         if (!promise.isDone()) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  881 */           if (this.finalResult == null) {
/*  882 */             this.finalResult = new ArrayList<T>(8);
/*  883 */             this.finalResult.add(converted);
/*  884 */           } else if (isDuplicateAllowed() || !this.finalResult.contains(converted)) {
/*  885 */             this.finalResult.add(converted);
/*      */           } else {
/*  887 */             shouldRelease = true;
/*      */           } 
/*      */         } else {
/*  890 */           shouldRelease = true;
/*      */         } 
/*      */         
/*  893 */         cache(this.hostname, this.additionals, r, converted);
/*  894 */         found = true;
/*      */         
/*  896 */         if (shouldRelease) {
/*  897 */           ReferenceCountUtil.release(converted);
/*      */         }
/*      */       } 
/*      */       continue;
/*      */     } 
/*  902 */     if (found && !cnameNeedsFollow) {
/*      */ 
/*      */       
/*  905 */       if (completeEarly) {
/*  906 */         this.completeEarly = true;
/*      */       }
/*  908 */       queryLifecycleObserver.querySucceed();
/*  909 */     } else if (cnames.isEmpty()) {
/*  910 */       queryLifecycleObserver.queryFailed(NO_MATCHING_RECORD_QUERY_FAILED_EXCEPTION);
/*      */     } else {
/*  912 */       queryLifecycleObserver.querySucceed();
/*      */       
/*  914 */       onResponseCNAME(question, cnames, newDnsQueryLifecycleObserver(question), promise);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void onResponseCNAME(DnsQuestion question, Map<String, String> cnames, DnsQueryLifecycleObserver queryLifecycleObserver, Promise<List<T>> promise) {
/*  924 */     String resolved = question.name().toLowerCase(Locale.US);
/*  925 */     boolean found = false;
/*  926 */     while (!cnames.isEmpty()) {
/*      */ 
/*      */       
/*  929 */       String next = cnames.remove(resolved);
/*  930 */       if (next != null) {
/*  931 */         found = true;
/*  932 */         resolved = next;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  938 */     if (found) {
/*  939 */       followCname(question, resolved, queryLifecycleObserver, promise);
/*      */     } else {
/*  941 */       queryLifecycleObserver.queryFailed(CNAME_NOT_FOUND_QUERY_FAILED_EXCEPTION);
/*      */     } 
/*      */   }
/*      */   
/*      */   private static Map<String, String> buildAliasMap(DnsResponse response, DnsCnameCache cache, EventLoop loop) {
/*  946 */     int answerCount = response.count(DnsSection.ANSWER);
/*  947 */     Map<String, String> cnames = null;
/*  948 */     for (int i = 0; i < answerCount; i++) {
/*  949 */       DnsRecord r = response.recordAt(DnsSection.ANSWER, i);
/*  950 */       DnsRecordType type = r.type();
/*  951 */       if (type == DnsRecordType.CNAME)
/*      */       {
/*      */ 
/*      */         
/*  955 */         if (r instanceof io.netty.handler.codec.dns.DnsRawRecord) {
/*      */ 
/*      */ 
/*      */           
/*  959 */           ByteBuf recordContent = ((ByteBufHolder)r).content();
/*  960 */           String domainName = decodeDomainName(recordContent);
/*  961 */           if (domainName != null) {
/*      */ 
/*      */ 
/*      */             
/*  965 */             if (cnames == null) {
/*  966 */               cnames = new HashMap<String, String>(Math.min(8, answerCount));
/*      */             }
/*      */             
/*  969 */             String name = r.name().toLowerCase(Locale.US);
/*  970 */             String mapping = domainName.toLowerCase(Locale.US);
/*      */ 
/*      */             
/*  973 */             String nameWithDot = hostnameWithDot(name);
/*  974 */             String mappingWithDot = hostnameWithDot(mapping);
/*  975 */             if (!nameWithDot.equalsIgnoreCase(mappingWithDot)) {
/*  976 */               cache.cache(nameWithDot, mappingWithDot, r.timeToLive(), loop);
/*  977 */               cnames.put(name, mapping);
/*      */             } 
/*      */           } 
/*      */         }  } 
/*  981 */     }  return (cnames != null) ? cnames : Collections.<String, String>emptyMap();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void tryToFinishResolve(DnsServerAddressStream nameServerAddrStream, int nameServerAddrStreamIndex, DnsQuestion question, DnsQueryLifecycleObserver queryLifecycleObserver, Promise<List<T>> promise, Throwable cause) {
/*  992 */     if (!this.completeEarly && !this.queriesInProgress.isEmpty()) {
/*  993 */       queryLifecycleObserver.queryCancelled(this.allowedQueries);
/*      */ 
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */ 
/*      */     
/* 1001 */     if (this.finalResult == null) {
/* 1002 */       if (nameServerAddrStreamIndex < nameServerAddrStream.size()) {
/* 1003 */         if (queryLifecycleObserver == NoopDnsQueryLifecycleObserver.INSTANCE) {
/*      */ 
/*      */           
/* 1006 */           query(nameServerAddrStream, nameServerAddrStreamIndex + 1, question, 
/* 1007 */               newDnsQueryLifecycleObserver(question), true, promise, cause);
/*      */         } else {
/* 1009 */           query(nameServerAddrStream, nameServerAddrStreamIndex + 1, question, queryLifecycleObserver, true, promise, cause);
/*      */         } 
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/* 1015 */       queryLifecycleObserver.queryFailed(NAME_SERVERS_EXHAUSTED_EXCEPTION);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1022 */       if (cause == null && !this.triedCNAME && (question
/* 1023 */         .type() == DnsRecordType.A || question.type() == DnsRecordType.AAAA)) {
/*      */         
/* 1025 */         this.triedCNAME = true;
/*      */         
/* 1027 */         query(this.hostname, DnsRecordType.CNAME, getNameServers(this.hostname), true, promise);
/*      */         return;
/*      */       } 
/*      */     } else {
/* 1031 */       queryLifecycleObserver.queryCancelled(this.allowedQueries);
/*      */     } 
/*      */ 
/*      */     
/* 1035 */     finishResolve(promise, cause);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void finishResolve(Promise<List<T>> promise, Throwable cause) {
/* 1041 */     if (!this.completeEarly && !this.queriesInProgress.isEmpty()) {
/*      */       
/* 1043 */       Iterator<Future<AddressedEnvelope<DnsResponse, InetSocketAddress>>> i = this.queriesInProgress.iterator();
/* 1044 */       while (i.hasNext()) {
/* 1045 */         Future<AddressedEnvelope<DnsResponse, InetSocketAddress>> f = i.next();
/* 1046 */         i.remove();
/*      */         
/* 1048 */         f.cancel(false);
/*      */       } 
/*      */     } 
/*      */     
/* 1052 */     if (this.finalResult != null) {
/* 1053 */       if (!promise.isDone()) {
/*      */         
/* 1055 */         List<T> result = filterResults(this.finalResult);
/*      */         
/* 1057 */         this.finalResult = Collections.emptyList();
/* 1058 */         if (!DnsNameResolver.trySuccess(promise, result)) {
/* 1059 */           for (T item : result) {
/* 1060 */             ReferenceCountUtil.safeRelease(item);
/*      */           }
/*      */         }
/*      */       }
/*      */       else {
/*      */         
/* 1066 */         assert this.finalResult.isEmpty();
/*      */       } 
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 1072 */     int maxAllowedQueries = this.parent.maxQueriesPerResolve();
/* 1073 */     int tries = maxAllowedQueries - this.allowedQueries;
/* 1074 */     StringBuilder buf = new StringBuilder(64);
/*      */     
/* 1076 */     buf.append("Failed to resolve '").append(this.hostname).append("' ").append(Arrays.toString((Object[])this.expectedTypes));
/* 1077 */     if (tries > 1) {
/* 1078 */       if (tries < maxAllowedQueries) {
/* 1079 */         buf.append(" after ")
/* 1080 */           .append(tries)
/* 1081 */           .append(" queries ");
/*      */       } else {
/* 1083 */         buf.append(". Exceeded max queries per resolve ")
/* 1084 */           .append(maxAllowedQueries)
/* 1085 */           .append(' ');
/*      */       } 
/*      */     }
/* 1088 */     UnknownHostException unknownHostException = new UnknownHostException(buf.toString());
/* 1089 */     if (cause == null) {
/*      */ 
/*      */       
/* 1092 */       cache(this.hostname, this.additionals, unknownHostException);
/*      */     } else {
/* 1094 */       unknownHostException.initCause(cause);
/*      */     } 
/* 1096 */     promise.tryFailure(unknownHostException);
/*      */   }
/*      */   
/*      */   static String decodeDomainName(ByteBuf in) {
/* 1100 */     in.markReaderIndex();
/*      */     try {
/* 1102 */       return DefaultDnsRecordDecoder.decodeName(in);
/* 1103 */     } catch (CorruptedFrameException e) {
/*      */       
/* 1105 */       return null;
/*      */     } finally {
/* 1107 */       in.resetReaderIndex();
/*      */     } 
/*      */   }
/*      */   
/*      */   private DnsServerAddressStream getNameServers(String name) {
/* 1112 */     DnsServerAddressStream stream = getNameServersFromCache(name);
/* 1113 */     if (stream == null) {
/*      */ 
/*      */ 
/*      */       
/* 1117 */       if (name.equals(this.hostname)) {
/* 1118 */         return this.nameServerAddrs.duplicate();
/*      */       }
/* 1120 */       return this.parent.newNameServerAddressStream(name);
/*      */     } 
/* 1122 */     return stream;
/*      */   }
/*      */ 
/*      */   
/*      */   private void followCname(DnsQuestion question, String cname, DnsQueryLifecycleObserver queryLifecycleObserver, Promise<List<T>> promise) {
/*      */     DefaultDnsQuestion defaultDnsQuestion;
/*      */     DnsServerAddressStream stream;
/*      */     try {
/* 1130 */       cname = cnameResolveFromCache(cnameCache(), cname);
/* 1131 */       stream = getNameServers(cname);
/* 1132 */       defaultDnsQuestion = new DefaultDnsQuestion(cname, question.type(), this.dnsClass);
/* 1133 */     } catch (Throwable cause) {
/* 1134 */       queryLifecycleObserver.queryFailed(cause);
/* 1135 */       PlatformDependent.throwException(cause);
/*      */       return;
/*      */     } 
/* 1138 */     query(stream, 0, (DnsQuestion)defaultDnsQuestion, queryLifecycleObserver.queryCNAMEd((DnsQuestion)defaultDnsQuestion), true, promise, null);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean query(String hostname, DnsRecordType type, DnsServerAddressStream dnsServerAddressStream, boolean flush, Promise<List<T>> promise) {
/*      */     DefaultDnsQuestion defaultDnsQuestion;
/*      */     try {
/* 1146 */       defaultDnsQuestion = new DefaultDnsQuestion(hostname, type, this.dnsClass);
/* 1147 */     } catch (Throwable cause) {
/*      */ 
/*      */       
/* 1150 */       promise.tryFailure(new IllegalArgumentException("Unable to create DNS Question for: [" + hostname + ", " + type + ']', cause));
/*      */       
/* 1152 */       return false;
/*      */     } 
/* 1154 */     query(dnsServerAddressStream, 0, (DnsQuestion)defaultDnsQuestion, newDnsQueryLifecycleObserver((DnsQuestion)defaultDnsQuestion), flush, promise, null);
/* 1155 */     return true;
/*      */   }
/*      */   
/*      */   private DnsQueryLifecycleObserver newDnsQueryLifecycleObserver(DnsQuestion question) {
/* 1159 */     return this.parent.dnsQueryLifecycleObserverFactory().newDnsQueryLifecycleObserver(question);
/*      */   }
/*      */   abstract DnsResolveContext<T> newResolverContext(DnsNameResolver paramDnsNameResolver, Promise<?> paramPromise, String paramString, int paramInt1, DnsRecordType[] paramArrayOfDnsRecordType, DnsRecord[] paramArrayOfDnsRecord, DnsServerAddressStream paramDnsServerAddressStream, int paramInt2);
/*      */   abstract T convertRecord(DnsRecord paramDnsRecord, String paramString, DnsRecord[] paramArrayOfDnsRecord, EventLoop paramEventLoop);
/*      */   abstract List<T> filterResults(List<T> paramList);
/*      */   abstract boolean isCompleteEarly(T paramT);
/*      */   abstract boolean isDuplicateAllowed();
/*      */   abstract void cache(String paramString, DnsRecord[] paramArrayOfDnsRecord, DnsRecord paramDnsRecord, T paramT);
/*      */   abstract void cache(String paramString, DnsRecord[] paramArrayOfDnsRecord, UnknownHostException paramUnknownHostException);
/*      */   private final class CombinedDnsServerAddressStream implements DnsServerAddressStream { private final InetSocketAddress replaced; private final DnsServerAddressStream originalStream;
/*      */     CombinedDnsServerAddressStream(InetSocketAddress replaced, List<InetAddress> resolvedAddresses, DnsServerAddressStream originalStream) {
/* 1170 */       this.replaced = replaced;
/* 1171 */       this.resolvedAddresses = resolvedAddresses;
/* 1172 */       this.originalStream = originalStream;
/* 1173 */       this.resolved = resolvedAddresses.iterator();
/*      */     }
/*      */     private final List<InetAddress> resolvedAddresses; private Iterator<InetAddress> resolved;
/*      */     
/*      */     public InetSocketAddress next() {
/* 1178 */       if (this.resolved.hasNext()) {
/* 1179 */         return nextResolved0();
/*      */       }
/* 1181 */       InetSocketAddress address = this.originalStream.next();
/* 1182 */       if (address.equals(this.replaced)) {
/* 1183 */         this.resolved = this.resolvedAddresses.iterator();
/* 1184 */         return nextResolved0();
/*      */       } 
/* 1186 */       return address;
/*      */     }
/*      */     
/*      */     private InetSocketAddress nextResolved0() {
/* 1190 */       return DnsResolveContext.this.parent.newRedirectServerAddress(this.resolved.next());
/*      */     }
/*      */ 
/*      */     
/*      */     public int size() {
/* 1195 */       return this.originalStream.size() + this.resolvedAddresses.size() - 1;
/*      */     }
/*      */ 
/*      */     
/*      */     public DnsServerAddressStream duplicate() {
/* 1200 */       return new CombinedDnsServerAddressStream(this.replaced, this.resolvedAddresses, this.originalStream.duplicate());
/*      */     } }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final class AuthoritativeNameServerList
/*      */   {
/*      */     private final String questionName;
/*      */ 
/*      */     
/*      */     private DnsResolveContext.AuthoritativeNameServer head;
/*      */     
/*      */     private int nameServerCount;
/*      */ 
/*      */     
/*      */     AuthoritativeNameServerList(String questionName) {
/* 1217 */       this.questionName = questionName.toLowerCase(Locale.US);
/*      */     }
/*      */     
/*      */     void add(DnsRecord r) {
/* 1221 */       if (r.type() != DnsRecordType.NS || !(r instanceof io.netty.handler.codec.dns.DnsRawRecord)) {
/*      */         return;
/*      */       }
/*      */ 
/*      */       
/* 1226 */       if (this.questionName.length() < r.name().length()) {
/*      */         return;
/*      */       }
/*      */       
/* 1230 */       String recordName = r.name().toLowerCase(Locale.US);
/*      */       
/* 1232 */       int dots = 0;
/* 1233 */       for (int a = recordName.length() - 1, b = this.questionName.length() - 1; a >= 0; a--, b--) {
/* 1234 */         char c = recordName.charAt(a);
/* 1235 */         if (this.questionName.charAt(b) != c) {
/*      */           return;
/*      */         }
/* 1238 */         if (c == '.') {
/* 1239 */           dots++;
/*      */         }
/*      */       } 
/*      */       
/* 1243 */       if (this.head != null && this.head.dots > dots) {
/*      */         return;
/*      */       }
/*      */ 
/*      */       
/* 1248 */       ByteBuf recordContent = ((ByteBufHolder)r).content();
/* 1249 */       String domainName = DnsResolveContext.decodeDomainName(recordContent);
/* 1250 */       if (domainName == null) {
/*      */         return;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1257 */       if (this.head == null || this.head.dots < dots) {
/* 1258 */         this.nameServerCount = 1;
/* 1259 */         this.head = new DnsResolveContext.AuthoritativeNameServer(dots, r.timeToLive(), recordName, domainName);
/* 1260 */       } else if (this.head.dots == dots) {
/* 1261 */         DnsResolveContext.AuthoritativeNameServer serverName = this.head;
/* 1262 */         while (serverName.next != null) {
/* 1263 */           serverName = serverName.next;
/*      */         }
/* 1265 */         serverName.next = new DnsResolveContext.AuthoritativeNameServer(dots, r.timeToLive(), recordName, domainName);
/* 1266 */         this.nameServerCount++;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     void handleWithAdditional(DnsNameResolver parent, DnsRecord r, AuthoritativeDnsServerCache authoritativeCache) {
/* 1273 */       DnsResolveContext.AuthoritativeNameServer serverName = this.head;
/*      */       
/* 1275 */       String nsName = r.name();
/* 1276 */       InetAddress resolved = DnsAddressDecoder.decodeAddress(r, nsName, parent.isDecodeIdn());
/* 1277 */       if (resolved == null) {
/*      */         return;
/*      */       }
/*      */ 
/*      */       
/* 1282 */       while (serverName != null) {
/* 1283 */         if (serverName.nsName.equalsIgnoreCase(nsName)) {
/* 1284 */           if (serverName.address != null) {
/*      */ 
/*      */             
/* 1287 */             while (serverName.next != null && serverName.next.isCopy) {
/* 1288 */               serverName = serverName.next;
/*      */             }
/* 1290 */             DnsResolveContext.AuthoritativeNameServer server = new DnsResolveContext.AuthoritativeNameServer(serverName);
/* 1291 */             server.next = serverName.next;
/* 1292 */             serverName.next = server;
/* 1293 */             serverName = server;
/*      */             
/* 1295 */             this.nameServerCount++;
/*      */           } 
/*      */ 
/*      */           
/* 1299 */           serverName.update(parent.newRedirectServerAddress(resolved), r.timeToLive());
/*      */ 
/*      */           
/* 1302 */           cache(serverName, authoritativeCache, parent.executor());
/*      */           return;
/*      */         } 
/* 1305 */         serverName = serverName.next;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     void handleWithoutAdditionals(DnsNameResolver parent, DnsCache cache, AuthoritativeDnsServerCache authoritativeCache) {
/* 1312 */       DnsResolveContext.AuthoritativeNameServer serverName = this.head;
/*      */       
/* 1314 */       while (serverName != null) {
/* 1315 */         if (serverName.address == null) {
/*      */           
/* 1317 */           cacheUnresolved(serverName, authoritativeCache, parent.executor());
/*      */ 
/*      */ 
/*      */           
/* 1321 */           List<? extends DnsCacheEntry> entries = cache.get(serverName.nsName, null);
/* 1322 */           if (entries != null && !entries.isEmpty()) {
/* 1323 */             InetAddress address = ((DnsCacheEntry)entries.get(0)).address();
/*      */ 
/*      */             
/* 1326 */             if (address != null) {
/* 1327 */               serverName.update(parent.newRedirectServerAddress(address));
/*      */               
/* 1329 */               for (int i = 1; i < entries.size(); i++) {
/* 1330 */                 address = ((DnsCacheEntry)entries.get(i)).address();
/*      */                 
/* 1332 */                 assert address != null : "Cache returned a cached failure, should never return anything else";
/*      */ 
/*      */                 
/* 1335 */                 DnsResolveContext.AuthoritativeNameServer server = new DnsResolveContext.AuthoritativeNameServer(serverName);
/* 1336 */                 server.next = serverName.next;
/* 1337 */                 serverName.next = server;
/* 1338 */                 serverName = server;
/* 1339 */                 serverName.update(parent.newRedirectServerAddress(address));
/*      */                 
/* 1341 */                 this.nameServerCount++;
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/* 1346 */         serverName = serverName.next;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private static void cacheUnresolved(DnsResolveContext.AuthoritativeNameServer server, AuthoritativeDnsServerCache authoritativeCache, EventLoop loop) {
/* 1353 */       server.address = InetSocketAddress.createUnresolved(server.nsName, 53);
/*      */ 
/*      */ 
/*      */       
/* 1357 */       cache(server, authoritativeCache, loop);
/*      */     }
/*      */ 
/*      */     
/*      */     private static void cache(DnsResolveContext.AuthoritativeNameServer server, AuthoritativeDnsServerCache cache, EventLoop loop) {
/* 1362 */       if (!server.isRootServer()) {
/* 1363 */         cache.cache(server.domainName, server.address, server.ttl, loop);
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     boolean isEmpty() {
/* 1371 */       return (this.nameServerCount == 0);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     List<InetSocketAddress> addressList() {
/* 1378 */       List<InetSocketAddress> addressList = new ArrayList<InetSocketAddress>(this.nameServerCount);
/*      */       
/* 1380 */       DnsResolveContext.AuthoritativeNameServer server = this.head;
/* 1381 */       while (server != null) {
/* 1382 */         if (server.address != null) {
/* 1383 */           addressList.add(server.address);
/*      */         }
/* 1385 */         server = server.next;
/*      */       } 
/* 1387 */       return addressList;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private static final class AuthoritativeNameServer
/*      */   {
/*      */     private final int dots;
/*      */     private final String domainName;
/*      */     final boolean isCopy;
/*      */     final String nsName;
/*      */     private long ttl;
/*      */     private InetSocketAddress address;
/*      */     AuthoritativeNameServer next;
/*      */     
/*      */     AuthoritativeNameServer(int dots, long ttl, String domainName, String nsName) {
/* 1403 */       this.dots = dots;
/* 1404 */       this.ttl = ttl;
/* 1405 */       this.nsName = nsName;
/* 1406 */       this.domainName = domainName;
/* 1407 */       this.isCopy = false;
/*      */     }
/*      */     
/*      */     AuthoritativeNameServer(AuthoritativeNameServer server) {
/* 1411 */       this.dots = server.dots;
/* 1412 */       this.ttl = server.ttl;
/* 1413 */       this.nsName = server.nsName;
/* 1414 */       this.domainName = server.domainName;
/* 1415 */       this.isCopy = true;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     boolean isRootServer() {
/* 1422 */       return (this.dots == 1);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void update(InetSocketAddress address, long ttl) {
/* 1429 */       assert this.address == null || this.address.isUnresolved();
/* 1430 */       this.address = address;
/* 1431 */       this.ttl = Math.min(this.ttl, ttl);
/*      */     }
/*      */     
/*      */     void update(InetSocketAddress address) {
/* 1435 */       update(address, Long.MAX_VALUE);
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-resolver-dns-4.1.93.Final.jar!\io\netty\resolver\dns\DnsResolveContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */