/*     */ package io.netty.resolver.dns;
/*     */ 
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import io.netty.util.internal.StringUtil;
/*     */ import io.netty.util.internal.logging.InternalLogger;
/*     */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileReader;
/*     */ import java.io.IOException;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class UnixResolverDnsServerAddressStreamProvider
/*     */   implements DnsServerAddressStreamProvider
/*     */ {
/*  48 */   private static final InternalLogger logger = InternalLoggerFactory.getInstance(UnixResolverDnsServerAddressStreamProvider.class);
/*     */   
/*  50 */   private static final Pattern WHITESPACE_PATTERN = Pattern.compile("\\s+");
/*  51 */   private static final String RES_OPTIONS = System.getenv("RES_OPTIONS");
/*     */   
/*     */   private static final String ETC_RESOLV_CONF_FILE = "/etc/resolv.conf";
/*     */   
/*     */   private static final String ETC_RESOLVER_DIR = "/etc/resolver";
/*     */   
/*     */   private static final String NAMESERVER_ROW_LABEL = "nameserver";
/*     */   
/*     */   private static final String SORTLIST_ROW_LABEL = "sortlist";
/*     */   
/*     */   private static final String OPTIONS_ROW_LABEL = "options ";
/*     */   
/*     */   private static final String OPTIONS_ROTATE_FLAG = "rotate";
/*     */   private static final String DOMAIN_ROW_LABEL = "domain";
/*     */   private static final String SEARCH_ROW_LABEL = "search";
/*     */   private static final String PORT_ROW_LABEL = "port";
/*     */   private final DnsServerAddresses defaultNameServerAddresses;
/*     */   private final Map<String, DnsServerAddresses> domainToNameServerStreamMap;
/*     */   
/*     */   static DnsServerAddressStreamProvider parseSilently() {
/*     */     try {
/*  72 */       UnixResolverDnsServerAddressStreamProvider nameServerCache = new UnixResolverDnsServerAddressStreamProvider("/etc/resolv.conf", "/etc/resolver");
/*     */       
/*  74 */       return nameServerCache.mayOverrideNameServers() ? nameServerCache : DefaultDnsServerAddressStreamProvider.INSTANCE;
/*     */     }
/*  76 */     catch (Exception e) {
/*  77 */       if (logger.isDebugEnabled()) {
/*  78 */         logger.debug("failed to parse {} and/or {}", new Object[] { "/etc/resolv.conf", "/etc/resolver", e });
/*     */       }
/*  80 */       return DefaultDnsServerAddressStreamProvider.INSTANCE;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UnixResolverDnsServerAddressStreamProvider(File etcResolvConf, File... etcResolverFiles) throws IOException {
/*  98 */     Map<String, DnsServerAddresses> etcResolvConfMap = parse(new File[] { (File)ObjectUtil.checkNotNull(etcResolvConf, "etcResolvConf") });
/*  99 */     boolean useEtcResolverFiles = (etcResolverFiles != null && etcResolverFiles.length != 0);
/* 100 */     this.domainToNameServerStreamMap = useEtcResolverFiles ? parse(etcResolverFiles) : etcResolvConfMap;
/*     */ 
/*     */     
/* 103 */     DnsServerAddresses defaultNameServerAddresses = etcResolvConfMap.get(etcResolvConf.getName());
/* 104 */     if (defaultNameServerAddresses == null) {
/* 105 */       Collection<DnsServerAddresses> values = etcResolvConfMap.values();
/* 106 */       if (values.isEmpty()) {
/* 107 */         throw new IllegalArgumentException(etcResolvConf + " didn't provide any name servers");
/*     */       }
/* 109 */       this.defaultNameServerAddresses = values.iterator().next();
/*     */     } else {
/* 111 */       this.defaultNameServerAddresses = defaultNameServerAddresses;
/*     */     } 
/*     */     
/* 114 */     if (useEtcResolverFiles) {
/* 115 */       this.domainToNameServerStreamMap.putAll(etcResolvConfMap);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UnixResolverDnsServerAddressStreamProvider(String etcResolvConf, String etcResolverDir) throws IOException {
/* 133 */     this((etcResolvConf == null) ? null : new File(etcResolvConf), (etcResolverDir == null) ? null : (new File(etcResolverDir))
/* 134 */         .listFiles());
/*     */   }
/*     */ 
/*     */   
/*     */   public DnsServerAddressStream nameServerAddressStream(String hostname) {
/*     */     while (true) {
/* 140 */       int i = hostname.indexOf('.', 1);
/* 141 */       if (i < 0 || i == hostname.length() - 1) {
/* 142 */         return this.defaultNameServerAddresses.stream();
/*     */       }
/*     */       
/* 145 */       DnsServerAddresses addresses = this.domainToNameServerStreamMap.get(hostname);
/* 146 */       if (addresses != null) {
/* 147 */         return addresses.stream();
/*     */       }
/*     */       
/* 150 */       hostname = hostname.substring(i + 1);
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean mayOverrideNameServers() {
/* 155 */     return (!this.domainToNameServerStreamMap.isEmpty() || this.defaultNameServerAddresses.stream().next() != null);
/*     */   }
/*     */   
/*     */   private static Map<String, DnsServerAddresses> parse(File... etcResolverFiles) throws IOException {
/* 159 */     Map<String, DnsServerAddresses> domainToNameServerStreamMap = new HashMap<String, DnsServerAddresses>(etcResolverFiles.length << 1);
/*     */     
/* 161 */     boolean rotateGlobal = (RES_OPTIONS != null && RES_OPTIONS.contains("rotate"));
/* 162 */     for (File etcResolverFile : etcResolverFiles) {
/* 163 */       if (etcResolverFile.isFile()) {
/*     */ 
/*     */         
/* 166 */         FileReader fr = new FileReader(etcResolverFile);
/* 167 */         BufferedReader br = null;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 251 */     return domainToNameServerStreamMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void putIfAbsent(Map<String, DnsServerAddresses> domainToNameServerStreamMap, String domainName, List<InetSocketAddress> addresses, boolean rotate) {
/* 261 */     DnsServerAddresses addrs = rotate ? DnsServerAddresses.rotational(addresses) : DnsServerAddresses.sequential(addresses);
/* 262 */     putIfAbsent(domainToNameServerStreamMap, domainName, addrs);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static void putIfAbsent(Map<String, DnsServerAddresses> domainToNameServerStreamMap, String domainName, DnsServerAddresses addresses) {
/* 268 */     DnsServerAddresses existingAddresses = domainToNameServerStreamMap.put(domainName, addresses);
/* 269 */     if (existingAddresses != null) {
/* 270 */       domainToNameServerStreamMap.put(domainName, existingAddresses);
/* 271 */       if (logger.isDebugEnabled()) {
/* 272 */         logger.debug("Domain name {} already maps to addresses {} so new addresses {} will be discarded", new Object[] { domainName, existingAddresses, addresses });
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static UnixResolverOptions parseEtcResolverOptions() throws IOException {
/* 285 */     return parseEtcResolverOptions(new File("/etc/resolv.conf"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static UnixResolverOptions parseEtcResolverOptions(File etcResolvConf) throws IOException {
/* 296 */     UnixResolverOptions.Builder optionsBuilder = UnixResolverOptions.newBuilder();
/*     */     
/* 298 */     FileReader fr = new FileReader(etcResolvConf);
/* 299 */     BufferedReader br = null;
/*     */     try {
/* 301 */       br = new BufferedReader(fr);
/*     */       String line;
/* 303 */       while ((line = br.readLine()) != null) {
/* 304 */         if (line.startsWith("options ")) {
/* 305 */           parseResOptions(line.substring("options ".length()), optionsBuilder);
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } finally {
/* 310 */       if (br == null) {
/* 311 */         fr.close();
/*     */       } else {
/* 313 */         br.close();
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 318 */     if (RES_OPTIONS != null) {
/* 319 */       parseResOptions(RES_OPTIONS, optionsBuilder);
/*     */     }
/*     */     
/* 322 */     return optionsBuilder.build();
/*     */   }
/*     */   
/*     */   private static void parseResOptions(String line, UnixResolverOptions.Builder builder) {
/* 326 */     String[] opts = WHITESPACE_PATTERN.split(line);
/* 327 */     for (String opt : opts) {
/*     */       try {
/* 329 */         if (opt.startsWith("ndots:")) {
/* 330 */           builder.setNdots(parseResIntOption(opt, "ndots:"));
/* 331 */         } else if (opt.startsWith("attempts:")) {
/* 332 */           builder.setAttempts(parseResIntOption(opt, "attempts:"));
/* 333 */         } else if (opt.startsWith("timeout:")) {
/* 334 */           builder.setTimeout(parseResIntOption(opt, "timeout:"));
/*     */         } 
/* 336 */       } catch (NumberFormatException numberFormatException) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static int parseResIntOption(String opt, String fullLabel) {
/* 343 */     String optValue = opt.substring(fullLabel.length());
/* 344 */     return Integer.parseInt(optValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static List<String> parseEtcResolverSearchDomains() throws IOException {
/* 354 */     return parseEtcResolverSearchDomains(new File("/etc/resolv.conf"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static List<String> parseEtcResolverSearchDomains(File etcResolvConf) throws IOException {
/* 365 */     String localDomain = null;
/* 366 */     List<String> searchDomains = new ArrayList<String>();
/*     */     
/* 368 */     FileReader fr = new FileReader(etcResolvConf);
/* 369 */     BufferedReader br = null;
/*     */     try {
/* 371 */       br = new BufferedReader(fr);
/*     */       String line;
/* 373 */       while ((line = br.readLine()) != null) {
/* 374 */         if (localDomain == null && line.startsWith("domain")) {
/* 375 */           int i = StringUtil.indexOfNonWhiteSpace(line, "domain".length());
/* 376 */           if (i >= 0)
/* 377 */             localDomain = line.substring(i);  continue;
/*     */         } 
/* 379 */         if (line.startsWith("search")) {
/* 380 */           int i = StringUtil.indexOfNonWhiteSpace(line, "search".length());
/* 381 */           if (i >= 0) {
/*     */ 
/*     */             
/* 384 */             String[] domains = WHITESPACE_PATTERN.split(line.substring(i));
/* 385 */             Collections.addAll(searchDomains, domains);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } finally {
/* 390 */       if (br == null) {
/* 391 */         fr.close();
/*     */       } else {
/* 393 */         br.close();
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 398 */     return (localDomain != null && searchDomains.isEmpty()) ? 
/* 399 */       Collections.<String>singletonList(localDomain) : searchDomains;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-resolver-dns-4.1.93.Final.jar!\io\netty\resolver\dns\UnixResolverDnsServerAddressStreamProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */