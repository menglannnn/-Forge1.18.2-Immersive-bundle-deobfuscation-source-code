/*     */ package io.netty.resolver.dns;
/*     */ 
/*     */ import io.netty.channel.AddressedEnvelope;
/*     */ import io.netty.channel.Channel;
/*     */ import io.netty.channel.ChannelFuture;
/*     */ import io.netty.channel.ChannelFutureListener;
/*     */ import io.netty.channel.ChannelPromise;
/*     */ import io.netty.handler.codec.dns.AbstractDnsOptPseudoRrRecord;
/*     */ import io.netty.handler.codec.dns.DnsQuery;
/*     */ import io.netty.handler.codec.dns.DnsQuestion;
/*     */ import io.netty.handler.codec.dns.DnsRecord;
/*     */ import io.netty.handler.codec.dns.DnsRecordType;
/*     */ import io.netty.handler.codec.dns.DnsResponse;
/*     */ import io.netty.handler.codec.dns.DnsSection;
/*     */ import io.netty.util.ReferenceCountUtil;
/*     */ import io.netty.util.concurrent.Future;
/*     */ import io.netty.util.concurrent.FutureListener;
/*     */ import io.netty.util.concurrent.GenericFutureListener;
/*     */ import io.netty.util.concurrent.Promise;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import io.netty.util.internal.logging.InternalLogger;
/*     */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class DnsQueryContext
/*     */   implements FutureListener<AddressedEnvelope<DnsResponse, InetSocketAddress>>
/*     */ {
/*  45 */   private static final InternalLogger logger = InternalLoggerFactory.getInstance(DnsQueryContext.class);
/*     */   
/*     */   private final DnsNameResolver parent;
/*     */   
/*     */   private final Promise<AddressedEnvelope<DnsResponse, InetSocketAddress>> promise;
/*     */   
/*     */   private final int id;
/*     */   
/*     */   private final DnsQuestion question;
/*     */   
/*     */   private final DnsRecord[] additionals;
/*     */   
/*     */   private final DnsRecord optResource;
/*     */   
/*     */   private final InetSocketAddress nameServerAddr;
/*     */   private final boolean recursionDesired;
/*     */   private volatile Future<?> timeoutFuture;
/*     */   
/*     */   DnsQueryContext(DnsNameResolver parent, InetSocketAddress nameServerAddr, DnsQuestion question, DnsRecord[] additionals, Promise<AddressedEnvelope<DnsResponse, InetSocketAddress>> promise) {
/*  64 */     this.parent = (DnsNameResolver)ObjectUtil.checkNotNull(parent, "parent");
/*  65 */     this.nameServerAddr = (InetSocketAddress)ObjectUtil.checkNotNull(nameServerAddr, "nameServerAddr");
/*  66 */     this.question = (DnsQuestion)ObjectUtil.checkNotNull(question, "question");
/*  67 */     this.additionals = (DnsRecord[])ObjectUtil.checkNotNull(additionals, "additionals");
/*  68 */     this.promise = (Promise<AddressedEnvelope<DnsResponse, InetSocketAddress>>)ObjectUtil.checkNotNull(promise, "promise");
/*  69 */     this.recursionDesired = parent.isRecursionDesired();
/*  70 */     this.id = parent.queryContextManager.add(this);
/*     */ 
/*     */     
/*  73 */     promise.addListener((GenericFutureListener)this);
/*     */     
/*  75 */     if (parent.isOptResourceEnabled() && 
/*     */ 
/*     */ 
/*     */       
/*  79 */       !hasOptRecord(additionals)) {
/*  80 */       this.optResource = (DnsRecord)new AbstractDnsOptPseudoRrRecord(parent.maxPayloadSize(), 0, 0) {
/*     */         
/*     */         };
/*     */     } else {
/*  84 */       this.optResource = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static boolean hasOptRecord(DnsRecord[] additionals) {
/*  89 */     if (additionals != null && additionals.length > 0) {
/*  90 */       for (DnsRecord additional : additionals) {
/*  91 */         if (additional.type() == DnsRecordType.OPT) {
/*  92 */           return true;
/*     */         }
/*     */       } 
/*     */     }
/*  96 */     return false;
/*     */   }
/*     */   
/*     */   InetSocketAddress nameServerAddr() {
/* 100 */     return this.nameServerAddr;
/*     */   }
/*     */   
/*     */   DnsQuestion question() {
/* 104 */     return this.question;
/*     */   }
/*     */   
/*     */   DnsNameResolver parent() {
/* 108 */     return this.parent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void query(boolean flush, ChannelPromise writePromise) {
/* 116 */     DnsQuestion question = question();
/* 117 */     InetSocketAddress nameServerAddr = nameServerAddr();
/* 118 */     DnsQuery query = newQuery(this.id);
/*     */     
/* 120 */     query.setRecursionDesired(this.recursionDesired);
/*     */     
/* 122 */     query.addRecord(DnsSection.QUESTION, (DnsRecord)question);
/*     */     
/* 124 */     for (DnsRecord record : this.additionals) {
/* 125 */       query.addRecord(DnsSection.ADDITIONAL, record);
/*     */     }
/*     */     
/* 128 */     if (this.optResource != null) {
/* 129 */       query.addRecord(DnsSection.ADDITIONAL, this.optResource);
/*     */     }
/*     */     
/* 132 */     if (logger.isDebugEnabled()) {
/* 133 */       logger.debug("{} WRITE: {}, [{}: {}], {}", new Object[] { channel(), protocol(), Integer.valueOf(this.id), nameServerAddr, question });
/*     */     }
/*     */     
/* 136 */     sendQuery(query, flush, writePromise);
/*     */   }
/*     */   
/*     */   private void sendQuery(final DnsQuery query, boolean flush, final ChannelPromise writePromise) {
/* 140 */     if (this.parent.channelReadyPromise.isSuccess()) {
/* 141 */       writeQuery(query, flush, writePromise);
/*     */     } else {
/* 143 */       Throwable cause = this.parent.channelReadyPromise.cause();
/* 144 */       if (cause != null) {
/*     */         
/* 146 */         failQuery(query, cause, writePromise);
/*     */       } else {
/*     */         
/* 149 */         this.parent.channelReadyPromise.addListener(new GenericFutureListener<Future<? super Channel>>()
/*     */             {
/*     */               public void operationComplete(Future<? super Channel> future) {
/* 152 */                 if (future.isSuccess()) {
/*     */ 
/*     */ 
/*     */                   
/* 156 */                   DnsQueryContext.this.writeQuery(query, true, writePromise);
/*     */                 } else {
/* 158 */                   Throwable cause = future.cause();
/* 159 */                   DnsQueryContext.this.failQuery(query, cause, writePromise);
/*     */                 } 
/*     */               }
/*     */             });
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void failQuery(DnsQuery query, Throwable cause, ChannelPromise writePromise) {
/*     */     try {
/* 169 */       this.promise.tryFailure(cause);
/* 170 */       writePromise.setFailure(cause);
/*     */     } finally {
/* 172 */       ReferenceCountUtil.release(query);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeQuery(DnsQuery query, boolean flush, ChannelPromise writePromise) {
/* 178 */     final ChannelFuture writeFuture = flush ? channel().writeAndFlush(query, writePromise) : channel().write(query, writePromise);
/* 179 */     if (writeFuture.isDone()) {
/* 180 */       onQueryWriteCompletion(writeFuture);
/*     */     } else {
/* 182 */       writeFuture.addListener((GenericFutureListener)new ChannelFutureListener()
/*     */           {
/*     */             public void operationComplete(ChannelFuture future) {
/* 185 */               DnsQueryContext.this.onQueryWriteCompletion(writeFuture);
/*     */             }
/*     */           });
/*     */     } 
/*     */   }
/*     */   
/*     */   private void onQueryWriteCompletion(ChannelFuture writeFuture) {
/* 192 */     if (!writeFuture.isSuccess()) {
/* 193 */       tryFailure("failed to send a query '" + this.id + "' via " + protocol(), writeFuture.cause(), false);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 198 */     final long queryTimeoutMillis = this.parent.queryTimeoutMillis();
/* 199 */     if (queryTimeoutMillis > 0L) {
/* 200 */       this.timeoutFuture = (Future<?>)this.parent.ch.eventLoop().schedule(new Runnable()
/*     */           {
/*     */             public void run() {
/* 203 */               if (DnsQueryContext.this.promise.isDone()) {
/*     */                 return;
/*     */               }
/*     */ 
/*     */               
/* 208 */               DnsQueryContext.this.tryFailure("query '" + DnsQueryContext.this.id + "' via " + DnsQueryContext.this.protocol() + " timed out after " + queryTimeoutMillis + " milliseconds", null, true);
/*     */             }
/*     */           }queryTimeoutMillis, TimeUnit.MILLISECONDS);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void finish(AddressedEnvelope<? extends DnsResponse, InetSocketAddress> envelope) {
/* 219 */     DnsResponse res = (DnsResponse)envelope.content();
/* 220 */     if (res.count(DnsSection.QUESTION) != 1) {
/* 221 */       logger.warn("Received a DNS response with invalid number of questions: {}", envelope);
/* 222 */     } else if (!question().equals(res.recordAt(DnsSection.QUESTION))) {
/* 223 */       logger.warn("Received a mismatching DNS response: {}", envelope);
/* 224 */     } else if (trySuccess(envelope)) {
/*     */       return;
/*     */     } 
/* 227 */     envelope.release();
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean trySuccess(AddressedEnvelope<? extends DnsResponse, InetSocketAddress> envelope) {
/* 232 */     return this.promise.trySuccess(envelope);
/*     */   }
/*     */   boolean tryFailure(String message, Throwable cause, boolean timeout) {
/*     */     DnsNameResolverException e;
/* 236 */     if (this.promise.isDone()) {
/* 237 */       return false;
/*     */     }
/* 239 */     InetSocketAddress nameServerAddr = nameServerAddr();
/* 240 */     DnsQuestion question = question();
/*     */     
/* 242 */     StringBuilder buf = new StringBuilder(message.length() + 128);
/* 243 */     buf.append('[')
/* 244 */       .append(this.id)
/* 245 */       .append(": ")
/* 246 */       .append(nameServerAddr)
/* 247 */       .append("] ")
/* 248 */       .append(question)
/* 249 */       .append(' ')
/* 250 */       .append(message)
/* 251 */       .append(" (no stack trace available)");
/*     */ 
/*     */     
/* 254 */     if (timeout) {
/*     */ 
/*     */       
/* 257 */       e = new DnsNameResolverTimeoutException(nameServerAddr, question, buf.toString());
/*     */     } else {
/* 259 */       e = new DnsNameResolverException(nameServerAddr, question, buf.toString(), cause);
/*     */     } 
/* 261 */     return this.promise.tryFailure(e);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void operationComplete(Future<AddressedEnvelope<DnsResponse, InetSocketAddress>> future) {
/* 267 */     Future<?> timeoutFuture = this.timeoutFuture;
/* 268 */     if (timeoutFuture != null) {
/* 269 */       this.timeoutFuture = null;
/* 270 */       timeoutFuture.cancel(false);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 275 */     this.parent.queryContextManager.remove(this.nameServerAddr, this.id);
/*     */   }
/*     */   
/*     */   protected abstract DnsQuery newQuery(int paramInt);
/*     */   
/*     */   protected abstract Channel channel();
/*     */   
/*     */   protected abstract String protocol();
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-resolver-dns-4.1.93.Final.jar!\io\netty\resolver\dns\DnsQueryContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */