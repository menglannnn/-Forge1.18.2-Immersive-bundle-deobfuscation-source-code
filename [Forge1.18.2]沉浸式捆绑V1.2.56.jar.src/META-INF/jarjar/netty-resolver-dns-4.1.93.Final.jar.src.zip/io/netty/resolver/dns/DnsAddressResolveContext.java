/*     */ package io.netty.resolver.dns;
/*     */ 
/*     */ import io.netty.channel.EventLoop;
/*     */ import io.netty.handler.codec.dns.DnsRecord;
/*     */ import io.netty.handler.codec.dns.DnsRecordType;
/*     */ import io.netty.util.concurrent.Promise;
/*     */ import java.net.InetAddress;
/*     */ import java.net.UnknownHostException;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class DnsAddressResolveContext
/*     */   extends DnsResolveContext<InetAddress>
/*     */ {
/*     */   private final DnsCache resolveCache;
/*     */   private final AuthoritativeDnsServerCache authoritativeDnsServerCache;
/*     */   private final boolean completeEarlyIfPossible;
/*     */   
/*     */   DnsAddressResolveContext(DnsNameResolver parent, Promise<?> originalPromise, String hostname, DnsRecord[] additionals, DnsServerAddressStream nameServerAddrs, int allowedQueries, DnsCache resolveCache, AuthoritativeDnsServerCache authoritativeDnsServerCache, boolean completeEarlyIfPossible) {
/*  41 */     super(parent, originalPromise, hostname, 1, parent
/*  42 */         .resolveRecordTypes(), additionals, nameServerAddrs, allowedQueries);
/*  43 */     this.resolveCache = resolveCache;
/*  44 */     this.authoritativeDnsServerCache = authoritativeDnsServerCache;
/*  45 */     this.completeEarlyIfPossible = completeEarlyIfPossible;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   DnsResolveContext<InetAddress> newResolverContext(DnsNameResolver parent, Promise<?> originalPromise, String hostname, int dnsClass, DnsRecordType[] expectedTypes, DnsRecord[] additionals, DnsServerAddressStream nameServerAddrs, int allowedQueries) {
/*  54 */     return new DnsAddressResolveContext(parent, originalPromise, hostname, additionals, nameServerAddrs, allowedQueries, this.resolveCache, this.authoritativeDnsServerCache, this.completeEarlyIfPossible);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   InetAddress convertRecord(DnsRecord record, String hostname, DnsRecord[] additionals, EventLoop eventLoop) {
/*  60 */     return DnsAddressDecoder.decodeAddress(record, hostname, this.parent.isDecodeIdn());
/*     */   }
/*     */ 
/*     */   
/*     */   List<InetAddress> filterResults(List<InetAddress> unfiltered) {
/*  65 */     Collections.sort(unfiltered, PreferredAddressTypeComparator.comparator(this.parent.preferredAddressType()));
/*  66 */     return unfiltered;
/*     */   }
/*     */ 
/*     */   
/*     */   boolean isCompleteEarly(InetAddress resolved) {
/*  71 */     return (this.completeEarlyIfPossible && this.parent.preferredAddressType().addressType() == resolved.getClass());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isDuplicateAllowed() {
/*  77 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void cache(String hostname, DnsRecord[] additionals, DnsRecord result, InetAddress convertedResult) {
/*  83 */     this.resolveCache.cache(hostname, additionals, convertedResult, result.timeToLive(), this.parent.ch.eventLoop());
/*     */   }
/*     */ 
/*     */   
/*     */   void cache(String hostname, DnsRecord[] additionals, UnknownHostException cause) {
/*  88 */     this.resolveCache.cache(hostname, additionals, cause, this.parent.ch.eventLoop());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void doSearchDomainQuery(String hostname, Promise<List<InetAddress>> nextPromise) {
/*  94 */     if (!DnsNameResolver.doResolveAllCached(hostname, this.additionals, nextPromise, this.resolveCache, this.parent
/*  95 */         .resolvedInternetProtocolFamiliesUnsafe())) {
/*  96 */       super.doSearchDomainQuery(hostname, nextPromise);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   DnsCache resolveCache() {
/* 102 */     return this.resolveCache;
/*     */   }
/*     */ 
/*     */   
/*     */   AuthoritativeDnsServerCache authoritativeDnsServerCache() {
/* 107 */     return this.authoritativeDnsServerCache;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-resolver-dns-4.1.93.Final.jar!\io\netty\resolver\dns\DnsAddressResolveContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */