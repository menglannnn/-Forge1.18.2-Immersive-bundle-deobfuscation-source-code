package io.netty.resolver.dns;

import io.netty.channel.EventLoop;

public interface DnsCnameCache {
  String get(String paramString);
  
  void cache(String paramString1, String paramString2, long paramLong, EventLoop paramEventLoop);
  
  void clear();
  
  boolean clear(String paramString);
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-resolver-dns-4.1.93.Final.jar!\io\netty\resolver\dns\DnsCnameCache.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */