/*    */ package io.netty.resolver.dns;
/*    */ 
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class MultiDnsServerAddressStreamProvider
/*    */   implements DnsServerAddressStreamProvider
/*    */ {
/*    */   private final DnsServerAddressStreamProvider[] providers;
/*    */   
/*    */   public MultiDnsServerAddressStreamProvider(List<DnsServerAddressStreamProvider> providers) {
/* 32 */     this.providers = providers.<DnsServerAddressStreamProvider>toArray(new DnsServerAddressStreamProvider[0]);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public MultiDnsServerAddressStreamProvider(DnsServerAddressStreamProvider... providers) {
/* 40 */     this.providers = (DnsServerAddressStreamProvider[])providers.clone();
/*    */   }
/*    */ 
/*    */   
/*    */   public DnsServerAddressStream nameServerAddressStream(String hostname) {
/* 45 */     for (DnsServerAddressStreamProvider provider : this.providers) {
/* 46 */       DnsServerAddressStream stream = provider.nameServerAddressStream(hostname);
/* 47 */       if (stream != null) {
/* 48 */         return stream;
/*    */       }
/*    */     } 
/* 51 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-resolver-dns-4.1.93.Final.jar!\io\netty\resolver\dns\MultiDnsServerAddressStreamProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */