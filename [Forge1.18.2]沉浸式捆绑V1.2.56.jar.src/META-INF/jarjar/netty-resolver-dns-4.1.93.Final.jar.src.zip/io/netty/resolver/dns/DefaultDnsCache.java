/*     */ package io.netty.resolver.dns;
/*     */ 
/*     */ import io.netty.channel.EventLoop;
/*     */ import io.netty.handler.codec.dns.DnsRecord;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import io.netty.util.internal.StringUtil;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.net.InetAddress;
/*     */ import java.net.UnknownHostException;
/*     */ import java.util.AbstractList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultDnsCache
/*     */   implements DnsCache
/*     */ {
/*  43 */   private final Cache<DefaultDnsCacheEntry> resolveCache = new Cache<DefaultDnsCacheEntry>()
/*     */     {
/*     */       protected boolean shouldReplaceAll(DefaultDnsCache.DefaultDnsCacheEntry entry)
/*     */       {
/*  47 */         return (entry.cause() != null);
/*     */       }
/*     */ 
/*     */       
/*     */       protected boolean equals(DefaultDnsCache.DefaultDnsCacheEntry entry, DefaultDnsCache.DefaultDnsCacheEntry otherEntry) {
/*  52 */         if (entry.address() != null) {
/*  53 */           return entry.address().equals(otherEntry.address());
/*     */         }
/*  55 */         if (otherEntry.address() != null) {
/*  56 */           return false;
/*     */         }
/*  58 */         return entry.cause().equals(otherEntry.cause());
/*     */       }
/*     */     };
/*     */ 
/*     */   
/*     */   private final int minTtl;
/*     */   
/*     */   private final int maxTtl;
/*     */   
/*     */   private final int negativeTtl;
/*     */ 
/*     */   
/*     */   public DefaultDnsCache() {
/*  71 */     this(0, Cache.MAX_SUPPORTED_TTL_SECS, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultDnsCache(int minTtl, int maxTtl, int negativeTtl) {
/*  81 */     this.minTtl = Math.min(Cache.MAX_SUPPORTED_TTL_SECS, ObjectUtil.checkPositiveOrZero(minTtl, "minTtl"));
/*  82 */     this.maxTtl = Math.min(Cache.MAX_SUPPORTED_TTL_SECS, ObjectUtil.checkPositiveOrZero(maxTtl, "maxTtl"));
/*  83 */     if (minTtl > maxTtl) {
/*  84 */       throw new IllegalArgumentException("minTtl: " + minTtl + ", maxTtl: " + maxTtl + " (expected: 0 <= minTtl <= maxTtl)");
/*     */     }
/*     */     
/*  87 */     this.negativeTtl = ObjectUtil.checkPositiveOrZero(negativeTtl, "negativeTtl");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int minTtl() {
/*  96 */     return this.minTtl;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int maxTtl() {
/* 105 */     return this.maxTtl;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int negativeTtl() {
/* 113 */     return this.negativeTtl;
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/* 118 */     this.resolveCache.clear();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean clear(String hostname) {
/* 123 */     ObjectUtil.checkNotNull(hostname, "hostname");
/* 124 */     return this.resolveCache.clear(appendDot(hostname));
/*     */   }
/*     */   
/*     */   private static boolean emptyAdditionals(DnsRecord[] additionals) {
/* 128 */     return (additionals == null || additionals.length == 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<? extends DnsCacheEntry> get(String hostname, DnsRecord[] additionals) {
/* 133 */     ObjectUtil.checkNotNull(hostname, "hostname");
/* 134 */     if (!emptyAdditionals(additionals)) {
/* 135 */       return Collections.emptyList();
/*     */     }
/*     */     
/* 138 */     List<? extends DnsCacheEntry> entries = this.resolveCache.get(appendDot(hostname));
/* 139 */     if (entries == null || entries.isEmpty()) {
/* 140 */       return entries;
/*     */     }
/* 142 */     return new DnsCacheEntryList(entries);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public DnsCacheEntry cache(String hostname, DnsRecord[] additionals, InetAddress address, long originalTtl, EventLoop loop) {
/* 148 */     ObjectUtil.checkNotNull(hostname, "hostname");
/* 149 */     ObjectUtil.checkNotNull(address, "address");
/* 150 */     ObjectUtil.checkNotNull(loop, "loop");
/* 151 */     DefaultDnsCacheEntry e = new DefaultDnsCacheEntry(hostname, address);
/* 152 */     if (this.maxTtl == 0 || !emptyAdditionals(additionals)) {
/* 153 */       return e;
/*     */     }
/* 155 */     this.resolveCache.cache(appendDot(hostname), e, Math.max(this.minTtl, (int)Math.min(this.maxTtl, originalTtl)), loop);
/* 156 */     return e;
/*     */   }
/*     */ 
/*     */   
/*     */   public DnsCacheEntry cache(String hostname, DnsRecord[] additionals, Throwable cause, EventLoop loop) {
/* 161 */     ObjectUtil.checkNotNull(hostname, "hostname");
/* 162 */     ObjectUtil.checkNotNull(cause, "cause");
/* 163 */     ObjectUtil.checkNotNull(loop, "loop");
/*     */     
/* 165 */     DefaultDnsCacheEntry e = new DefaultDnsCacheEntry(hostname, cause);
/* 166 */     if (this.negativeTtl == 0 || !emptyAdditionals(additionals)) {
/* 167 */       return e;
/*     */     }
/*     */     
/* 170 */     this.resolveCache.cache(appendDot(hostname), e, this.negativeTtl, loop);
/* 171 */     return e;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 176 */     return "DefaultDnsCache(minTtl=" + 
/* 177 */       this.minTtl + 
/* 178 */       ", maxTtl=" + this.maxTtl + 
/* 179 */       ", negativeTtl=" + this.negativeTtl + 
/* 180 */       ", cached resolved hostname=" + this.resolveCache
/* 181 */       .size() + ')';
/*     */   }
/*     */   
/*     */   private static final class DefaultDnsCacheEntry
/*     */     implements DnsCacheEntry {
/*     */     private final String hostname;
/*     */     private final InetAddress address;
/*     */     private final Throwable cause;
/*     */     private final int hash;
/*     */     
/*     */     DefaultDnsCacheEntry(String hostname, InetAddress address) {
/* 192 */       this.hostname = hostname;
/* 193 */       this.address = address;
/* 194 */       this.cause = null;
/* 195 */       this.hash = System.identityHashCode(this);
/*     */     }
/*     */     
/*     */     DefaultDnsCacheEntry(String hostname, Throwable cause) {
/* 199 */       this.hostname = hostname;
/* 200 */       this.cause = cause;
/* 201 */       this.address = null;
/* 202 */       this.hash = System.identityHashCode(this);
/*     */     }
/*     */     
/*     */     private DefaultDnsCacheEntry(DefaultDnsCacheEntry entry) {
/* 206 */       this.hostname = entry.hostname;
/* 207 */       if (entry.cause == null) {
/* 208 */         this.address = entry.address;
/* 209 */         this.cause = null;
/*     */       } else {
/* 211 */         this.address = null;
/* 212 */         this.cause = DefaultDnsCache.copyThrowable(entry.cause);
/*     */       } 
/* 214 */       this.hash = entry.hash;
/*     */     }
/*     */ 
/*     */     
/*     */     public InetAddress address() {
/* 219 */       return this.address;
/*     */     }
/*     */ 
/*     */     
/*     */     public Throwable cause() {
/* 224 */       return this.cause;
/*     */     }
/*     */     
/*     */     String hostname() {
/* 228 */       return this.hostname;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 233 */       if (this.cause != null) {
/* 234 */         return this.hostname + '/' + this.cause;
/*     */       }
/* 236 */       return this.address.toString();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 242 */       return this.hash;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/* 247 */       return (obj instanceof DefaultDnsCacheEntry && ((DefaultDnsCacheEntry)obj).hash == this.hash);
/*     */     }
/*     */     
/*     */     DnsCacheEntry copyIfNeeded() {
/* 251 */       if (this.cause == null) {
/* 252 */         return this;
/*     */       }
/* 254 */       return new DefaultDnsCacheEntry(this);
/*     */     }
/*     */   }
/*     */   
/*     */   private static String appendDot(String hostname) {
/* 259 */     return StringUtil.endsWith(hostname, '.') ? hostname : (hostname + '.');
/*     */   }
/*     */   
/*     */   private static Throwable copyThrowable(Throwable error) {
/* 263 */     if (error.getClass() == UnknownHostException.class) {
/*     */       
/* 265 */       UnknownHostException copy = new UnknownHostException(error.getMessage())
/*     */         {
/*     */           public Throwable fillInStackTrace()
/*     */           {
/* 269 */             return this;
/*     */           }
/*     */         };
/* 272 */       copy.initCause(error.getCause());
/* 273 */       copy.setStackTrace(error.getStackTrace());
/* 274 */       return copy;
/*     */     } 
/* 276 */     ObjectOutputStream oos = null;
/* 277 */     ObjectInputStream ois = null;
/*     */ 
/*     */     
/*     */     try {
/* 281 */       ByteArrayOutputStream baos = new ByteArrayOutputStream();
/* 282 */       oos = new ObjectOutputStream(baos);
/* 283 */       oos.writeObject(error);
/*     */       
/* 285 */       ByteArrayInputStream bais = new ByteArrayInputStream(baos.toByteArray());
/* 286 */       ois = new ObjectInputStream(bais);
/* 287 */       return (Throwable)ois.readObject();
/* 288 */     } catch (IOException e) {
/* 289 */       throw new IllegalStateException(e);
/* 290 */     } catch (ClassNotFoundException e) {
/* 291 */       throw new IllegalStateException(e);
/*     */     } finally {
/* 293 */       if (oos != null) {
/*     */         try {
/* 295 */           oos.close();
/* 296 */         } catch (IOException iOException) {}
/*     */       }
/*     */ 
/*     */       
/* 300 */       if (ois != null) {
/*     */         try {
/* 302 */           ois.close();
/* 303 */         } catch (IOException iOException) {}
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private static final class DnsCacheEntryList
/*     */     extends AbstractList<DnsCacheEntry>
/*     */   {
/*     */     private final List<? extends DnsCacheEntry> entries;
/*     */     
/*     */     DnsCacheEntryList(List<? extends DnsCacheEntry> entries) {
/* 314 */       this.entries = entries;
/*     */     }
/*     */ 
/*     */     
/*     */     public DnsCacheEntry get(int index) {
/* 319 */       DefaultDnsCache.DefaultDnsCacheEntry entry = (DefaultDnsCache.DefaultDnsCacheEntry)this.entries.get(index);
/*     */ 
/*     */ 
/*     */       
/* 323 */       return entry.copyIfNeeded();
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 328 */       return this.entries.size();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 334 */       return super.hashCode();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/* 339 */       if (o instanceof DnsCacheEntryList)
/*     */       {
/* 341 */         return this.entries.equals(((DnsCacheEntryList)o).entries);
/*     */       }
/* 343 */       return super.equals(o);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-resolver-dns-4.1.93.Final.jar!\io\netty\resolver\dns\DefaultDnsCache.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */