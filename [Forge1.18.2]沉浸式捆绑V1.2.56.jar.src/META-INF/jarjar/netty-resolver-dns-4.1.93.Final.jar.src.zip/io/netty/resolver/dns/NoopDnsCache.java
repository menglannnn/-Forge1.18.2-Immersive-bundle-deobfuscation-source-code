/*    */ package io.netty.resolver.dns;
/*    */ 
/*    */ import io.netty.channel.EventLoop;
/*    */ import io.netty.handler.codec.dns.DnsRecord;
/*    */ import java.net.InetAddress;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class NoopDnsCache
/*    */   implements DnsCache
/*    */ {
/* 30 */   public static final NoopDnsCache INSTANCE = new NoopDnsCache();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void clear() {}
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean clear(String hostname) {
/* 44 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public List<? extends DnsCacheEntry> get(String hostname, DnsRecord[] additionals) {
/* 49 */     return Collections.emptyList();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public DnsCacheEntry cache(String hostname, DnsRecord[] additional, InetAddress address, long originalTtl, EventLoop loop) {
/* 55 */     return new NoopDnsCacheEntry(address);
/*    */   }
/*    */ 
/*    */   
/*    */   public DnsCacheEntry cache(String hostname, DnsRecord[] additional, Throwable cause, EventLoop loop) {
/* 60 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 65 */     return NoopDnsCache.class.getSimpleName();
/*    */   }
/*    */   
/*    */   private static final class NoopDnsCacheEntry implements DnsCacheEntry {
/*    */     private final InetAddress address;
/*    */     
/*    */     NoopDnsCacheEntry(InetAddress address) {
/* 72 */       this.address = address;
/*    */     }
/*    */ 
/*    */     
/*    */     public InetAddress address() {
/* 77 */       return this.address;
/*    */     }
/*    */ 
/*    */     
/*    */     public Throwable cause() {
/* 82 */       return null;
/*    */     }
/*    */ 
/*    */     
/*    */     public String toString() {
/* 87 */       return this.address.toString();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-resolver-dns-4.1.93.Final.jar!\io\netty\resolver\dns\NoopDnsCache.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */