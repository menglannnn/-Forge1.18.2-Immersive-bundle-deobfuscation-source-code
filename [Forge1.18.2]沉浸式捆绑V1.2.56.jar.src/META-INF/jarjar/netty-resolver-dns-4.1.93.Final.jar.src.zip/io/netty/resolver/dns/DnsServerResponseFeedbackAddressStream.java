package io.netty.resolver.dns;

import java.net.InetSocketAddress;

public interface DnsServerResponseFeedbackAddressStream extends DnsServerAddressStream {
  void feedbackSuccess(InetSocketAddress paramInetSocketAddress, long paramLong);
  
  void feedbackFailure(InetSocketAddress paramInetSocketAddress, Throwable paramThrowable, long paramLong);
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-resolver-dns-4.1.93.Final.jar!\io\netty\resolver\dns\DnsServerResponseFeedbackAddressStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */