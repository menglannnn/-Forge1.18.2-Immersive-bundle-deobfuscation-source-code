/*     */ package io.netty.resolver.dns;
/*     */ 
/*     */ import io.netty.util.NetUtil;
/*     */ import io.netty.util.internal.PlatformDependent;
/*     */ import io.netty.util.internal.SocketUtils;
/*     */ import io.netty.util.internal.SystemPropertyUtil;
/*     */ import io.netty.util.internal.logging.InternalLogger;
/*     */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DefaultDnsServerAddressStreamProvider
/*     */   implements DnsServerAddressStreamProvider
/*     */ {
/*  42 */   private static final InternalLogger logger = InternalLoggerFactory.getInstance(DefaultDnsServerAddressStreamProvider.class);
/*     */   private static final String DEFAULT_FALLBACK_SERVER_PROPERTY = "io.netty.resolver.dns.defaultNameServerFallback";
/*  44 */   public static final DefaultDnsServerAddressStreamProvider INSTANCE = new DefaultDnsServerAddressStreamProvider();
/*     */ 
/*     */   
/*     */   private static final List<InetSocketAddress> DEFAULT_NAME_SERVER_LIST;
/*     */ 
/*     */   
/*     */   static {
/*  51 */     List<InetSocketAddress> defaultNameServers = new ArrayList<InetSocketAddress>(2);
/*  52 */     if (!PlatformDependent.isAndroid())
/*     */     {
/*     */       
/*  55 */       DirContextUtils.addNameServers(defaultNameServers, 53);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  60 */     if (PlatformDependent.javaVersion() < 9 && defaultNameServers.isEmpty()) {
/*     */       try {
/*  62 */         Class<?> configClass = Class.forName("sun.net.dns.ResolverConfiguration");
/*  63 */         Method open = configClass.getMethod("open", new Class[0]);
/*  64 */         Method nameservers = configClass.getMethod("nameservers", new Class[0]);
/*  65 */         Object instance = open.invoke(null, new Object[0]);
/*     */ 
/*     */         
/*  68 */         List<String> list = (List<String>)nameservers.invoke(instance, new Object[0]);
/*  69 */         for (String a : list) {
/*  70 */           if (a != null) {
/*  71 */             defaultNameServers.add(new InetSocketAddress(SocketUtils.addressByName(a), 53));
/*     */           }
/*     */         } 
/*  74 */       } catch (Exception exception) {}
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  80 */     if (!defaultNameServers.isEmpty()) {
/*  81 */       if (logger.isDebugEnabled()) {
/*  82 */         logger.debug("Default DNS servers: {} (sun.net.dns.ResolverConfiguration)", defaultNameServers);
/*     */       }
/*     */     } else {
/*     */       
/*  86 */       String defaultNameserverString = SystemPropertyUtil.get("io.netty.resolver.dns.defaultNameServerFallback", null);
/*  87 */       if (defaultNameserverString != null) {
/*  88 */         for (String server : defaultNameserverString.split(",")) {
/*  89 */           String dns = server.trim();
/*  90 */           if (!NetUtil.isValidIpV4Address(dns) && !NetUtil.isValidIpV6Address(dns)) {
/*  91 */             throw new ExceptionInInitializerError("io.netty.resolver.dns.defaultNameServerFallback doesn't contain a valid list of NameServers: " + defaultNameserverString);
/*     */           }
/*     */           
/*  94 */           defaultNameServers.add(SocketUtils.socketAddress(server.trim(), 53));
/*     */         } 
/*  96 */         if (defaultNameServers.isEmpty()) {
/*  97 */           throw new ExceptionInInitializerError("io.netty.resolver.dns.defaultNameServerFallback doesn't contain a valid list of NameServers: " + defaultNameserverString);
/*     */         }
/*     */ 
/*     */         
/* 101 */         if (logger.isWarnEnabled()) {
/* 102 */           logger.warn("Default DNS servers: {} (Configured by {} system property)", defaultNameServers, "io.netty.resolver.dns.defaultNameServerFallback");
/*     */         
/*     */         }
/*     */       
/*     */       }
/*     */       else {
/*     */ 
/*     */         
/* 110 */         if (NetUtil.isIpV6AddressesPreferred() || (NetUtil.LOCALHOST instanceof java.net.Inet6Address && 
/* 111 */           !NetUtil.isIpV4StackPreferred())) {
/* 112 */           Collections.addAll(defaultNameServers, new InetSocketAddress[] {
/*     */                 
/* 114 */                 SocketUtils.socketAddress("2001:4860:4860::8888", 53), 
/* 115 */                 SocketUtils.socketAddress("2001:4860:4860::8844", 53) });
/*     */         } else {
/* 117 */           Collections.addAll(defaultNameServers, new InetSocketAddress[] {
/*     */                 
/* 119 */                 SocketUtils.socketAddress("8.8.8.8", 53), 
/* 120 */                 SocketUtils.socketAddress("8.8.4.4", 53)
/*     */               });
/*     */         } 
/* 123 */         if (logger.isWarnEnabled()) {
/* 124 */           logger.warn("Default DNS servers: {} (Google Public DNS as a fallback)", defaultNameServers);
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 130 */     DEFAULT_NAME_SERVER_LIST = Collections.unmodifiableList(defaultNameServers);
/* 131 */   } private static final DnsServerAddresses DEFAULT_NAME_SERVERS = DnsServerAddresses.sequential(DEFAULT_NAME_SERVER_LIST);
/*     */ 
/*     */   
/*     */   static final int DNS_PORT = 53;
/*     */ 
/*     */ 
/*     */   
/*     */   public DnsServerAddressStream nameServerAddressStream(String hostname) {
/* 139 */     return DEFAULT_NAME_SERVERS.stream();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<InetSocketAddress> defaultAddressList() {
/* 148 */     return DEFAULT_NAME_SERVER_LIST;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DnsServerAddresses defaultAddresses() {
/* 163 */     return DEFAULT_NAME_SERVERS;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-resolver-dns-4.1.93.Final.jar!\io\netty\resolver\dns\DefaultDnsServerAddressStreamProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */