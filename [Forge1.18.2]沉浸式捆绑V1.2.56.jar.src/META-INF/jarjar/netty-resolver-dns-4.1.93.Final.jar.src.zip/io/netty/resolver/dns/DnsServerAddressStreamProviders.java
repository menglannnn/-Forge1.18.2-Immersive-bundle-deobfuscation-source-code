/*     */ package io.netty.resolver.dns;
/*     */ 
/*     */ import io.netty.util.internal.PlatformDependent;
/*     */ import io.netty.util.internal.logging.InternalLogger;
/*     */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DnsServerAddressStreamProviders
/*     */ {
/*  35 */   private static final InternalLogger LOGGER = InternalLoggerFactory.getInstance(DnsServerAddressStreamProviders.class);
/*     */   
/*     */   private static final Constructor<? extends DnsServerAddressStreamProvider> STREAM_PROVIDER_CONSTRUCTOR;
/*     */   private static final String MACOS_PROVIDER_CLASS_NAME = "io.netty.resolver.dns.macos.MacOSDnsServerAddressStreamProvider";
/*     */   
/*     */   static {
/*  41 */     Constructor<? extends DnsServerAddressStreamProvider> constructor = null;
/*  42 */     if (PlatformDependent.isOsx()) {
/*     */       
/*     */       try {
/*     */         
/*  46 */         Object maybeProvider = AccessController.doPrivileged(new PrivilegedAction()
/*     */             {
/*     */               public Object run() {
/*     */                 try {
/*  50 */                   return Class.forName("io.netty.resolver.dns.macos.MacOSDnsServerAddressStreamProvider", true, DnsServerAddressStreamProviders.class
/*     */ 
/*     */                       
/*  53 */                       .getClassLoader());
/*  54 */                 } catch (Throwable cause) {
/*  55 */                   return cause;
/*     */                 } 
/*     */               }
/*     */             });
/*  59 */         if (maybeProvider instanceof Class) {
/*     */           
/*  61 */           Class<? extends DnsServerAddressStreamProvider> providerClass = (Class<? extends DnsServerAddressStreamProvider>)maybeProvider;
/*     */           
/*  63 */           constructor = providerClass.getConstructor(new Class[0]);
/*  64 */           constructor.newInstance(new Object[0]);
/*  65 */           LOGGER.debug("{}: available", "io.netty.resolver.dns.macos.MacOSDnsServerAddressStreamProvider");
/*     */         } else {
/*  67 */           throw (Throwable)maybeProvider;
/*     */         } 
/*  69 */       } catch (ClassNotFoundException cause) {
/*  70 */         LOGGER.warn("Can not find {} in the classpath, fallback to system defaults. This may result in incorrect DNS resolutions on MacOS. Check whether you have a dependency on 'io.netty:netty-resolver-dns-native-macos'", "io.netty.resolver.dns.macos.MacOSDnsServerAddressStreamProvider");
/*     */       
/*     */       }
/*  73 */       catch (Throwable cause) {
/*  74 */         if (LOGGER.isDebugEnabled()) {
/*  75 */           LOGGER.error("Unable to load {}, fallback to system defaults. This may result in incorrect DNS resolutions on MacOS. Check whether you have a dependency on 'io.netty:netty-resolver-dns-native-macos'", "io.netty.resolver.dns.macos.MacOSDnsServerAddressStreamProvider", cause);
/*     */         }
/*     */         else {
/*     */           
/*  79 */           LOGGER.error("Unable to load {}, fallback to system defaults. This may result in incorrect DNS resolutions on MacOS. Check whether you have a dependency on 'io.netty:netty-resolver-dns-native-macos'. Use DEBUG level to see the full stack: {}", "io.netty.resolver.dns.macos.MacOSDnsServerAddressStreamProvider", 
/*     */ 
/*     */ 
/*     */               
/*  83 */               (cause.getCause() != null) ? cause.getCause().toString() : cause.toString());
/*     */         } 
/*  85 */         constructor = null;
/*     */       } 
/*     */     }
/*  88 */     STREAM_PROVIDER_CONSTRUCTOR = constructor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DnsServerAddressStreamProvider platformDefault() {
/* 102 */     if (STREAM_PROVIDER_CONSTRUCTOR != null) {
/*     */       try {
/* 104 */         return STREAM_PROVIDER_CONSTRUCTOR.newInstance(new Object[0]);
/* 105 */       } catch (IllegalAccessException illegalAccessException) {
/*     */       
/* 107 */       } catch (InstantiationException instantiationException) {
/*     */       
/* 109 */       } catch (InvocationTargetException invocationTargetException) {}
/*     */     }
/*     */ 
/*     */     
/* 113 */     return unixDefault();
/*     */   }
/*     */   
/*     */   public static DnsServerAddressStreamProvider unixDefault() {
/* 117 */     return DefaultProviderHolder.DEFAULT_DNS_SERVER_ADDRESS_STREAM_PROVIDER;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class DefaultProviderHolder
/*     */   {
/* 124 */     private static final long REFRESH_INTERVAL = TimeUnit.MINUTES.toNanos(5L);
/*     */ 
/*     */ 
/*     */     
/* 128 */     static final DnsServerAddressStreamProvider DEFAULT_DNS_SERVER_ADDRESS_STREAM_PROVIDER = new DnsServerAddressStreamProvider()
/*     */       {
/* 130 */         private volatile DnsServerAddressStreamProvider currentProvider = provider();
/* 131 */         private final AtomicLong lastRefresh = new AtomicLong(System.nanoTime());
/*     */ 
/*     */         
/*     */         public DnsServerAddressStream nameServerAddressStream(String hostname) {
/* 135 */           long last = this.lastRefresh.get();
/* 136 */           DnsServerAddressStreamProvider current = this.currentProvider;
/* 137 */           if (System.nanoTime() - last > DnsServerAddressStreamProviders.DefaultProviderHolder.REFRESH_INTERVAL)
/*     */           {
/*     */             
/* 140 */             if (this.lastRefresh.compareAndSet(last, System.nanoTime())) {
/* 141 */               current = this.currentProvider = provider();
/*     */             }
/*     */           }
/* 144 */           return current.nameServerAddressStream(hostname);
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         private DnsServerAddressStreamProvider provider() {
/* 150 */           return PlatformDependent.isWindows() ? DefaultDnsServerAddressStreamProvider.INSTANCE : 
/* 151 */             UnixResolverDnsServerAddressStreamProvider.parseSilently();
/*     */         }
/*     */       };
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-resolver-dns-4.1.93.Final.jar!\io\netty\resolver\dns\DnsServerAddressStreamProviders.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */