/*     */ package com.fasterxml.jackson.core.io;
/*     */ 
/*     */ import com.fasterxml.jackson.core.util.ByteArrayBuilder;
/*     */ import com.fasterxml.jackson.core.util.TextBuffer;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class JsonStringEncoder
/*     */ {
/*  24 */   private static final char[] HC = CharTypes.copyHexChars();
/*     */   
/*  26 */   private static final byte[] HB = CharTypes.copyHexBytes();
/*     */ 
/*     */   
/*     */   private static final int SURR1_FIRST = 55296;
/*     */ 
/*     */   
/*     */   private static final int SURR1_LAST = 56319;
/*     */ 
/*     */   
/*     */   private static final int SURR2_FIRST = 56320;
/*     */   
/*     */   private static final int SURR2_LAST = 57343;
/*     */   
/*     */   private static final int INITIAL_CHAR_BUFFER_SIZE = 120;
/*     */   
/*     */   private static final int INITIAL_BYTE_BUFFER_SIZE = 200;
/*     */   
/*  43 */   private static final JsonStringEncoder instance = new JsonStringEncoder();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JsonStringEncoder getInstance() {
/*  54 */     return instance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public char[] quoteAsString(String input) {
/*  73 */     char[] outputBuffer = new char[120];
/*  74 */     int[] escCodes = CharTypes.get7BitOutputEscapes();
/*  75 */     int escCodeCount = escCodes.length;
/*  76 */     int inPtr = 0;
/*  77 */     int inputLen = input.length();
/*  78 */     TextBuffer textBuffer = null;
/*  79 */     int outPtr = 0;
/*  80 */     char[] qbuf = null;
/*     */ 
/*     */     
/*  83 */     while (inPtr < inputLen) {
/*     */       
/*     */       label35: while (true) {
/*  86 */         char d, c = input.charAt(inPtr);
/*  87 */         if (c < escCodeCount && escCodes[c] != 0)
/*     */         
/*     */         { 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 103 */           if (qbuf == null) {
/* 104 */             qbuf = _qbuf();
/*     */           }
/* 106 */           d = input.charAt(inPtr++);
/* 107 */           int escCode = escCodes[d];
/*     */ 
/*     */           
/* 110 */           int length = (escCode < 0) ? _appendNumeric(d, qbuf) : _appendNamed(escCode, qbuf);
/*     */           
/* 112 */           if (outPtr + length > outputBuffer.length) {
/* 113 */             int first = outputBuffer.length - outPtr;
/* 114 */             if (first > 0) {
/* 115 */               System.arraycopy(qbuf, 0, outputBuffer, outPtr, first);
/*     */             }
/* 117 */             if (textBuffer == null) {
/* 118 */               textBuffer = TextBuffer.fromInitial(outputBuffer); break label35;
/*     */             } 
/* 120 */             outputBuffer = textBuffer.finishCurrentSegment();
/* 121 */             int second = length - first;
/* 122 */             System.arraycopy(qbuf, first, outputBuffer, 0, second);
/* 123 */             outPtr = second; continue;
/*     */           } 
/* 125 */           System.arraycopy(qbuf, 0, outputBuffer, outPtr, length);
/* 126 */           outPtr += length; continue; }  if (outPtr >= outputBuffer.length) { if (textBuffer == null)
/*     */             textBuffer = TextBuffer.fromInitial(outputBuffer);  outputBuffer = textBuffer.finishCurrentSegment(); outPtr = 0; }  outputBuffer[outPtr++] = d; if (++inPtr >= inputLen)
/*     */           break; 
/*     */       } 
/* 130 */     }  if (textBuffer == null) {
/* 131 */       return Arrays.copyOfRange(outputBuffer, 0, outPtr);
/*     */     }
/* 133 */     textBuffer.setCurrentLength(outPtr);
/* 134 */     return textBuffer.contentsAsArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public char[] quoteAsString(CharSequence input) {
/* 149 */     if (input instanceof String) {
/* 150 */       return quoteAsString((String)input);
/*     */     }
/*     */     
/* 153 */     TextBuffer textBuffer = null;
/*     */     
/* 155 */     char[] outputBuffer = new char[120];
/* 156 */     int[] escCodes = CharTypes.get7BitOutputEscapes();
/* 157 */     int escCodeCount = escCodes.length;
/* 158 */     int inPtr = 0;
/* 159 */     int inputLen = input.length();
/* 160 */     int outPtr = 0;
/* 161 */     char[] qbuf = null;
/*     */ 
/*     */     
/* 164 */     while (inPtr < inputLen) {
/*     */       
/*     */       label37: while (true) {
/* 167 */         char d, c = input.charAt(inPtr);
/* 168 */         if (c < escCodeCount && escCodes[c] != 0)
/*     */         
/*     */         { 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 184 */           if (qbuf == null) {
/* 185 */             qbuf = _qbuf();
/*     */           }
/* 187 */           d = input.charAt(inPtr++);
/* 188 */           int escCode = escCodes[d];
/*     */ 
/*     */           
/* 191 */           int length = (escCode < 0) ? _appendNumeric(d, qbuf) : _appendNamed(escCode, qbuf);
/*     */           
/* 193 */           if (outPtr + length > outputBuffer.length) {
/* 194 */             int first = outputBuffer.length - outPtr;
/* 195 */             if (first > 0) {
/* 196 */               System.arraycopy(qbuf, 0, outputBuffer, outPtr, first);
/*     */             }
/* 198 */             if (textBuffer == null) {
/* 199 */               textBuffer = TextBuffer.fromInitial(outputBuffer); break label37;
/*     */             } 
/* 201 */             outputBuffer = textBuffer.finishCurrentSegment();
/* 202 */             int second = length - first;
/* 203 */             System.arraycopy(qbuf, first, outputBuffer, 0, second);
/* 204 */             outPtr = second; continue;
/*     */           } 
/* 206 */           System.arraycopy(qbuf, 0, outputBuffer, outPtr, length);
/* 207 */           outPtr += length; continue; }  if (outPtr >= outputBuffer.length) { if (textBuffer == null)
/*     */             textBuffer = TextBuffer.fromInitial(outputBuffer);  outputBuffer = textBuffer.finishCurrentSegment(); outPtr = 0; }  outputBuffer[outPtr++] = d; if (++inPtr >= inputLen)
/*     */           break; 
/*     */       } 
/* 211 */     }  if (textBuffer == null) {
/* 212 */       return Arrays.copyOfRange(outputBuffer, 0, outPtr);
/*     */     }
/* 214 */     textBuffer.setCurrentLength(outPtr);
/* 215 */     return textBuffer.contentsAsArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void quoteAsString(CharSequence input, StringBuilder output) {
/* 230 */     int[] escCodes = CharTypes.get7BitOutputEscapes();
/* 231 */     int escCodeCount = escCodes.length;
/* 232 */     int inPtr = 0;
/* 233 */     int inputLen = input.length();
/* 234 */     char[] qbuf = null;
/*     */ 
/*     */     
/* 237 */     while (inPtr < inputLen) {
/*     */       
/*     */       while (true) {
/* 240 */         char d, c = input.charAt(inPtr);
/* 241 */         if (c < escCodeCount && escCodes[c] != 0) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 250 */           if (qbuf == null) {
/* 251 */             qbuf = _qbuf();
/*     */           }
/* 253 */           d = input.charAt(inPtr++);
/* 254 */           int escCode = escCodes[d];
/* 255 */           if (escCode < 0);
/*     */           
/* 257 */           int length = _appendNamed(escCode, qbuf);
/* 258 */           output.append(qbuf, 0, length);
/*     */           continue;
/*     */         } 
/*     */         output.append(d);
/*     */         if (++inPtr >= inputLen) {
/*     */           break;
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] quoteAsUTF8(String text) {
/* 274 */     int inputPtr = 0;
/* 275 */     int inputEnd = text.length();
/* 276 */     int outputPtr = 0;
/* 277 */     byte[] outputBuffer = new byte[200];
/* 278 */     ByteArrayBuilder bb = null;
/*     */ 
/*     */     
/* 281 */     while (inputPtr < inputEnd)
/* 282 */     { int[] escCodes = CharTypes.get7BitOutputEscapes();
/*     */ 
/*     */       
/*     */       label55: while (true)
/* 286 */       { int ch = text.charAt(inputPtr);
/* 287 */         if (ch > 127 || escCodes[ch] != 0)
/*     */         
/*     */         { 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 302 */           if (bb == null) {
/* 303 */             bb = ByteArrayBuilder.fromInitial(outputBuffer, outputPtr);
/*     */           }
/* 305 */           if (outputPtr >= outputBuffer.length) {
/* 306 */             outputBuffer = bb.finishCurrentSegment();
/* 307 */             outputPtr = 0;
/*     */           } 
/*     */           
/* 310 */           ch = text.charAt(inputPtr++);
/* 311 */           if (ch <= 127) {
/* 312 */             int escape = escCodes[ch];
/*     */             
/* 314 */             outputPtr = _appendByte(ch, escape, bb, outputPtr);
/* 315 */             outputBuffer = bb.getCurrentSegment();
/*     */             continue;
/*     */           } 
/* 318 */           if (ch <= 2047) {
/* 319 */             outputBuffer[outputPtr++] = (byte)(0xC0 | ch >> 6);
/* 320 */             ch = 0x80 | ch & 0x3F;
/*     */           
/*     */           }
/* 323 */           else if (ch < 55296 || ch > 57343) {
/* 324 */             outputBuffer[outputPtr++] = (byte)(0xE0 | ch >> 12);
/* 325 */             if (outputPtr >= outputBuffer.length) {
/* 326 */               outputBuffer = bb.finishCurrentSegment();
/* 327 */               outputPtr = 0;
/*     */             } 
/* 329 */             outputBuffer[outputPtr++] = (byte)(0x80 | ch >> 6 & 0x3F);
/* 330 */             ch = 0x80 | ch & 0x3F;
/*     */           } else {
/* 332 */             if (ch > 56319) {
/* 333 */               _illegal(ch);
/*     */             }
/*     */             
/* 336 */             if (inputPtr >= inputEnd) {
/* 337 */               _illegal(ch);
/*     */             }
/* 339 */             ch = _convert(ch, text.charAt(inputPtr++));
/* 340 */             if (ch > 1114111) {
/* 341 */               _illegal(ch);
/*     */             }
/* 343 */             outputBuffer[outputPtr++] = (byte)(0xF0 | ch >> 18);
/* 344 */             if (outputPtr >= outputBuffer.length) {
/* 345 */               outputBuffer = bb.finishCurrentSegment();
/* 346 */               outputPtr = 0;
/*     */             } 
/* 348 */             outputBuffer[outputPtr++] = (byte)(0x80 | ch >> 12 & 0x3F);
/* 349 */             if (outputPtr >= outputBuffer.length) {
/* 350 */               outputBuffer = bb.finishCurrentSegment();
/* 351 */               outputPtr = 0;
/*     */             } 
/* 353 */             outputBuffer[outputPtr++] = (byte)(0x80 | ch >> 6 & 0x3F);
/* 354 */             ch = 0x80 | ch & 0x3F;
/*     */           } 
/*     */           
/* 357 */           if (outputPtr >= outputBuffer.length) {
/* 358 */             outputBuffer = bb.finishCurrentSegment();
/* 359 */             outputPtr = 0; break label55;
/*     */           } 
/* 361 */           outputBuffer[outputPtr++] = (byte)ch; continue; }  if (outputPtr >= outputBuffer.length) { if (bb == null)
/*     */             bb = ByteArrayBuilder.fromInitial(outputBuffer, outputPtr);  outputBuffer = bb.finishCurrentSegment(); outputPtr = 0; }  outputBuffer[outputPtr++] = (byte)ch; if (++inputPtr >= inputEnd)
/* 363 */           break;  }  }  if (bb == null) {
/* 364 */       return Arrays.copyOfRange(outputBuffer, 0, outputPtr);
/*     */     }
/* 366 */     return bb.completeAndCoalesce(outputPtr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] encodeAsUTF8(String text) {
/* 380 */     int inputPtr = 0;
/* 381 */     int inputEnd = text.length();
/* 382 */     int outputPtr = 0;
/* 383 */     byte[] outputBuffer = new byte[200];
/* 384 */     int outputEnd = outputBuffer.length;
/* 385 */     ByteArrayBuilder bb = null;
/*     */ 
/*     */     
/* 388 */     label51: while (inputPtr < inputEnd) {
/* 389 */       int c = text.charAt(inputPtr++);
/*     */ 
/*     */       
/* 392 */       while (c <= 127) {
/* 393 */         if (outputPtr >= outputEnd) {
/* 394 */           if (bb == null) {
/* 395 */             bb = ByteArrayBuilder.fromInitial(outputBuffer, outputPtr);
/*     */           }
/* 397 */           outputBuffer = bb.finishCurrentSegment();
/* 398 */           outputEnd = outputBuffer.length;
/* 399 */           outputPtr = 0;
/*     */         } 
/* 401 */         outputBuffer[outputPtr++] = (byte)c;
/* 402 */         if (inputPtr >= inputEnd) {
/*     */           break label51;
/*     */         }
/* 405 */         c = text.charAt(inputPtr++);
/*     */       } 
/*     */ 
/*     */       
/* 409 */       if (bb == null) {
/* 410 */         bb = ByteArrayBuilder.fromInitial(outputBuffer, outputPtr);
/*     */       }
/* 412 */       if (outputPtr >= outputEnd) {
/* 413 */         outputBuffer = bb.finishCurrentSegment();
/* 414 */         outputEnd = outputBuffer.length;
/* 415 */         outputPtr = 0;
/*     */       } 
/* 417 */       if (c < 2048) {
/* 418 */         outputBuffer[outputPtr++] = (byte)(0xC0 | c >> 6);
/*     */       
/*     */       }
/* 421 */       else if (c < 55296 || c > 57343) {
/* 422 */         outputBuffer[outputPtr++] = (byte)(0xE0 | c >> 12);
/* 423 */         if (outputPtr >= outputEnd) {
/* 424 */           outputBuffer = bb.finishCurrentSegment();
/* 425 */           outputEnd = outputBuffer.length;
/* 426 */           outputPtr = 0;
/*     */         } 
/* 428 */         outputBuffer[outputPtr++] = (byte)(0x80 | c >> 6 & 0x3F);
/*     */       } else {
/* 430 */         if (c > 56319) {
/* 431 */           _illegal(c);
/*     */         }
/*     */         
/* 434 */         if (inputPtr >= inputEnd) {
/* 435 */           _illegal(c);
/*     */         }
/* 437 */         c = _convert(c, text.charAt(inputPtr++));
/* 438 */         if (c > 1114111) {
/* 439 */           _illegal(c);
/*     */         }
/* 441 */         outputBuffer[outputPtr++] = (byte)(0xF0 | c >> 18);
/* 442 */         if (outputPtr >= outputEnd) {
/* 443 */           outputBuffer = bb.finishCurrentSegment();
/* 444 */           outputEnd = outputBuffer.length;
/* 445 */           outputPtr = 0;
/*     */         } 
/* 447 */         outputBuffer[outputPtr++] = (byte)(0x80 | c >> 12 & 0x3F);
/* 448 */         if (outputPtr >= outputEnd) {
/* 449 */           outputBuffer = bb.finishCurrentSegment();
/* 450 */           outputEnd = outputBuffer.length;
/* 451 */           outputPtr = 0;
/*     */         } 
/* 453 */         outputBuffer[outputPtr++] = (byte)(0x80 | c >> 6 & 0x3F);
/*     */       } 
/*     */       
/* 456 */       if (outputPtr >= outputEnd) {
/* 457 */         outputBuffer = bb.finishCurrentSegment();
/* 458 */         outputEnd = outputBuffer.length;
/* 459 */         outputPtr = 0;
/*     */       } 
/* 461 */       outputBuffer[outputPtr++] = (byte)(0x80 | c & 0x3F);
/*     */     } 
/* 463 */     if (bb == null) {
/* 464 */       return Arrays.copyOfRange(outputBuffer, 0, outputPtr);
/*     */     }
/* 466 */     return bb.completeAndCoalesce(outputPtr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] encodeAsUTF8(CharSequence text) {
/* 481 */     int inputPtr = 0;
/* 482 */     int inputEnd = text.length();
/* 483 */     int outputPtr = 0;
/* 484 */     byte[] outputBuffer = new byte[200];
/* 485 */     int outputEnd = outputBuffer.length;
/* 486 */     ByteArrayBuilder bb = null;
/*     */ 
/*     */     
/* 489 */     label51: while (inputPtr < inputEnd) {
/* 490 */       int c = text.charAt(inputPtr++);
/*     */ 
/*     */       
/* 493 */       while (c <= 127) {
/* 494 */         if (outputPtr >= outputEnd) {
/* 495 */           if (bb == null) {
/* 496 */             bb = ByteArrayBuilder.fromInitial(outputBuffer, outputPtr);
/*     */           }
/* 498 */           outputBuffer = bb.finishCurrentSegment();
/* 499 */           outputEnd = outputBuffer.length;
/* 500 */           outputPtr = 0;
/*     */         } 
/* 502 */         outputBuffer[outputPtr++] = (byte)c;
/* 503 */         if (inputPtr >= inputEnd) {
/*     */           break label51;
/*     */         }
/* 506 */         c = text.charAt(inputPtr++);
/*     */       } 
/*     */ 
/*     */       
/* 510 */       if (bb == null) {
/* 511 */         bb = ByteArrayBuilder.fromInitial(outputBuffer, outputPtr);
/*     */       }
/* 513 */       if (outputPtr >= outputEnd) {
/* 514 */         outputBuffer = bb.finishCurrentSegment();
/* 515 */         outputEnd = outputBuffer.length;
/* 516 */         outputPtr = 0;
/*     */       } 
/* 518 */       if (c < 2048) {
/* 519 */         outputBuffer[outputPtr++] = (byte)(0xC0 | c >> 6);
/*     */       
/*     */       }
/* 522 */       else if (c < 55296 || c > 57343) {
/* 523 */         outputBuffer[outputPtr++] = (byte)(0xE0 | c >> 12);
/* 524 */         if (outputPtr >= outputEnd) {
/* 525 */           outputBuffer = bb.finishCurrentSegment();
/* 526 */           outputEnd = outputBuffer.length;
/* 527 */           outputPtr = 0;
/*     */         } 
/* 529 */         outputBuffer[outputPtr++] = (byte)(0x80 | c >> 6 & 0x3F);
/*     */       } else {
/* 531 */         if (c > 56319) {
/* 532 */           _illegal(c);
/*     */         }
/*     */         
/* 535 */         if (inputPtr >= inputEnd) {
/* 536 */           _illegal(c);
/*     */         }
/* 538 */         c = _convert(c, text.charAt(inputPtr++));
/* 539 */         if (c > 1114111) {
/* 540 */           _illegal(c);
/*     */         }
/* 542 */         outputBuffer[outputPtr++] = (byte)(0xF0 | c >> 18);
/* 543 */         if (outputPtr >= outputEnd) {
/* 544 */           outputBuffer = bb.finishCurrentSegment();
/* 545 */           outputEnd = outputBuffer.length;
/* 546 */           outputPtr = 0;
/*     */         } 
/* 548 */         outputBuffer[outputPtr++] = (byte)(0x80 | c >> 12 & 0x3F);
/* 549 */         if (outputPtr >= outputEnd) {
/* 550 */           outputBuffer = bb.finishCurrentSegment();
/* 551 */           outputEnd = outputBuffer.length;
/* 552 */           outputPtr = 0;
/*     */         } 
/* 554 */         outputBuffer[outputPtr++] = (byte)(0x80 | c >> 6 & 0x3F);
/*     */       } 
/*     */       
/* 557 */       if (outputPtr >= outputEnd) {
/* 558 */         outputBuffer = bb.finishCurrentSegment();
/* 559 */         outputEnd = outputBuffer.length;
/* 560 */         outputPtr = 0;
/*     */       } 
/* 562 */       outputBuffer[outputPtr++] = (byte)(0x80 | c & 0x3F);
/*     */     } 
/* 564 */     if (bb == null) {
/* 565 */       return Arrays.copyOfRange(outputBuffer, 0, outputPtr);
/*     */     }
/* 567 */     return bb.completeAndCoalesce(outputPtr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private char[] _qbuf() {
/* 577 */     char[] qbuf = new char[6];
/* 578 */     qbuf[0] = '\\';
/* 579 */     qbuf[2] = '0';
/* 580 */     qbuf[3] = '0';
/* 581 */     return qbuf;
/*     */   }
/*     */   
/*     */   private int _appendNumeric(int value, char[] qbuf) {
/* 585 */     qbuf[1] = 'u';
/*     */     
/* 587 */     qbuf[4] = HC[value >> 4];
/* 588 */     qbuf[5] = HC[value & 0xF];
/* 589 */     return 6;
/*     */   }
/*     */   
/*     */   private int _appendNamed(int esc, char[] qbuf) {
/* 593 */     qbuf[1] = (char)esc;
/* 594 */     return 2;
/*     */   }
/*     */ 
/*     */   
/*     */   private int _appendByte(int ch, int esc, ByteArrayBuilder bb, int ptr) {
/* 599 */     bb.setCurrentSegmentLength(ptr);
/* 600 */     bb.append(92);
/* 601 */     if (esc < 0) {
/* 602 */       bb.append(117);
/* 603 */       if (ch > 255) {
/* 604 */         int hi = ch >> 8;
/* 605 */         bb.append(HB[hi >> 4]);
/* 606 */         bb.append(HB[hi & 0xF]);
/* 607 */         ch &= 0xFF;
/*     */       } else {
/* 609 */         bb.append(48);
/* 610 */         bb.append(48);
/*     */       } 
/* 612 */       bb.append(HB[ch >> 4]);
/* 613 */       bb.append(HB[ch & 0xF]);
/*     */     } else {
/* 615 */       bb.append((byte)esc);
/*     */     } 
/* 617 */     return bb.getCurrentSegmentLength();
/*     */   }
/*     */ 
/*     */   
/*     */   private static int _convert(int p1, int p2) {
/* 622 */     if (p2 < 56320 || p2 > 57343) {
/* 623 */       throw new IllegalArgumentException("Broken surrogate pair: first char 0x" + Integer.toHexString(p1) + ", second 0x" + Integer.toHexString(p2) + "; illegal combination");
/*     */     }
/* 625 */     return 65536 + (p1 - 55296 << 10) + p2 - 56320;
/*     */   }
/*     */   
/*     */   private static void _illegal(int c) {
/* 629 */     throw new IllegalArgumentException(UTF8Writer.illegalSurrogateDesc(c));
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-core-2.12.4.jar!\com\fasterxml\jackson\core\io\JsonStringEncoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */