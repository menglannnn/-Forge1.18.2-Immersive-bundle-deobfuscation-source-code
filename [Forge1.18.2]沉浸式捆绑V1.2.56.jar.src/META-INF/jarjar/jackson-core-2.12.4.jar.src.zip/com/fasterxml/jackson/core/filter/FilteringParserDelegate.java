/*     */ package com.fasterxml.jackson.core.filter;
/*     */ 
/*     */ import com.fasterxml.jackson.core.Base64Variant;
/*     */ import com.fasterxml.jackson.core.JsonLocation;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonStreamContext;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.core.util.JsonParserDelegate;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FilteringParserDelegate
/*     */   extends JsonParserDelegate
/*     */ {
/*     */   protected TokenFilter rootFilter;
/*     */   protected boolean _allowMultipleMatches;
/*     */   protected TokenFilter.Inclusion _inclusion;
/*     */   protected JsonToken _currToken;
/*     */   protected JsonToken _lastClearedToken;
/*     */   protected TokenFilterContext _headContext;
/*     */   protected TokenFilterContext _exposedContext;
/*     */   protected TokenFilter _itemFilter;
/*     */   protected int _matchCount;
/*     */   
/*     */   @Deprecated
/*     */   public FilteringParserDelegate(JsonParser p, TokenFilter f, boolean includePath, boolean allowMultipleMatches) {
/* 108 */     this(p, f, includePath ? TokenFilter.Inclusion.INCLUDE_ALL_AND_PATH : TokenFilter.Inclusion.ONLY_INCLUDE_ALL, allowMultipleMatches);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public FilteringParserDelegate(JsonParser p, TokenFilter f, TokenFilter.Inclusion inclusion, boolean allowMultipleMatches) {
/* 114 */     super(p);
/* 115 */     this.rootFilter = f;
/*     */     
/* 117 */     this._itemFilter = f;
/* 118 */     this._headContext = TokenFilterContext.createRootContext(f);
/* 119 */     this._inclusion = inclusion;
/* 120 */     this._allowMultipleMatches = allowMultipleMatches;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TokenFilter getFilter() {
/* 129 */     return this.rootFilter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMatchCount() {
/* 136 */     return this._matchCount;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonToken getCurrentToken() {
/* 145 */     return this._currToken; } public JsonToken currentToken() {
/* 146 */     return this._currToken;
/*     */   }
/*     */   @Deprecated
/*     */   public final int getCurrentTokenId() {
/* 150 */     return currentTokenId();
/*     */   }
/*     */   public final int currentTokenId() {
/* 153 */     JsonToken t = this._currToken;
/* 154 */     return (t == null) ? 0 : t.id();
/*     */   }
/*     */   public boolean hasCurrentToken() {
/* 157 */     return (this._currToken != null);
/*     */   } public boolean hasTokenId(int id) {
/* 159 */     JsonToken t = this._currToken;
/* 160 */     if (t == null) {
/* 161 */       return (0 == id);
/*     */     }
/* 163 */     return (t.id() == id);
/*     */   }
/*     */   
/*     */   public final boolean hasToken(JsonToken t) {
/* 167 */     return (this._currToken == t);
/*     */   }
/*     */   
/* 170 */   public boolean isExpectedStartArrayToken() { return (this._currToken == JsonToken.START_ARRAY); } public boolean isExpectedStartObjectToken() {
/* 171 */     return (this._currToken == JsonToken.START_OBJECT);
/*     */   } public JsonLocation getCurrentLocation() {
/* 173 */     return this.delegate.getCurrentLocation();
/*     */   }
/*     */   
/*     */   public JsonStreamContext getParsingContext() {
/* 177 */     return _filterContext();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCurrentName() throws IOException {
/* 183 */     JsonStreamContext ctxt = _filterContext();
/* 184 */     if (this._currToken == JsonToken.START_OBJECT || this._currToken == JsonToken.START_ARRAY) {
/* 185 */       JsonStreamContext parent = ctxt.getParent();
/* 186 */       return (parent == null) ? null : parent.getCurrentName();
/*     */     } 
/* 188 */     return ctxt.getCurrentName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clearCurrentToken() {
/* 199 */     if (this._currToken != null) {
/* 200 */       this._lastClearedToken = this._currToken;
/* 201 */       this._currToken = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public JsonToken getLastClearedToken() {
/* 206 */     return this._lastClearedToken;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void overrideCurrentName(String name) {
/* 214 */     throw new UnsupportedOperationException("Can not currently override name during filtering read");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonToken nextToken() throws IOException {
/*     */     boolean returnEnd;
/*     */     String name;
/* 234 */     if (!this._allowMultipleMatches && this._currToken != null && this._exposedContext == null)
/*     */     {
/*     */       
/* 237 */       if (this._currToken.isScalarValue() && !this._headContext.isStartHandled() && this._inclusion == TokenFilter.Inclusion.ONLY_INCLUDE_ALL && this._itemFilter == TokenFilter.INCLUDE_ALL)
/*     */       {
/*     */         
/* 240 */         return this._currToken = null;
/*     */       }
/*     */     }
/*     */     
/* 244 */     TokenFilterContext ctxt = this._exposedContext;
/*     */     
/* 246 */     if (ctxt != null) {
/*     */       while (true) {
/* 248 */         JsonToken jsonToken = ctxt.nextTokenToRead();
/* 249 */         if (jsonToken != null) {
/* 250 */           this._currToken = jsonToken;
/* 251 */           return jsonToken;
/*     */         } 
/*     */         
/* 254 */         if (ctxt == this._headContext) {
/* 255 */           this._exposedContext = null;
/* 256 */           if (ctxt.inArray()) {
/* 257 */             jsonToken = this.delegate.getCurrentToken();
/*     */ 
/*     */             
/* 260 */             this._currToken = jsonToken;
/* 261 */             return jsonToken;
/*     */           } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           break;
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 276 */         ctxt = this._headContext.findChildOf(ctxt);
/* 277 */         this._exposedContext = ctxt;
/* 278 */         if (ctxt == null) {
/* 279 */           throw _constructError("Unexpected problem: chain of filtered context broken");
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 285 */     JsonToken t = this.delegate.nextToken();
/* 286 */     if (t == null) {
/*     */       
/* 288 */       this._currToken = t;
/* 289 */       return t;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 295 */     switch (t.id())
/*     */     { case 3:
/* 297 */         f = this._itemFilter;
/* 298 */         if (f == TokenFilter.INCLUDE_ALL) {
/* 299 */           this._headContext = this._headContext.createChildArrayContext(f, true);
/* 300 */           return this._currToken = t;
/*     */         } 
/* 302 */         if (f == null) {
/* 303 */           this.delegate.skipChildren();
/*     */         }
/*     */         else {
/*     */           
/* 307 */           f = this._headContext.checkValue(f);
/* 308 */           if (f == null) {
/* 309 */             this.delegate.skipChildren();
/*     */           } else {
/*     */             
/* 312 */             if (f != TokenFilter.INCLUDE_ALL) {
/* 313 */               f = f.filterStartArray();
/*     */             }
/* 315 */             this._itemFilter = f;
/* 316 */             if (f == TokenFilter.INCLUDE_ALL) {
/* 317 */               this._headContext = this._headContext.createChildArrayContext(f, true);
/* 318 */               return this._currToken = t;
/* 319 */             }  if (f != null && this._inclusion == TokenFilter.Inclusion.INCLUDE_NON_NULL) {
/*     */               
/* 321 */               this._headContext = this._headContext.createChildArrayContext(f, true);
/* 322 */               return this._currToken = t;
/*     */             } 
/* 324 */             this._headContext = this._headContext.createChildArrayContext(f, false);
/*     */ 
/*     */             
/* 327 */             if (this._inclusion == TokenFilter.Inclusion.INCLUDE_ALL_AND_PATH) {
/* 328 */               t = _nextTokenWithBuffering(this._headContext);
/* 329 */               if (t != null) {
/* 330 */                 this._currToken = t;
/* 331 */                 return t;
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 453 */         return _nextToken2();case 1: f = this._itemFilter; if (f == TokenFilter.INCLUDE_ALL) { this._headContext = this._headContext.createChildObjectContext(f, true); return this._currToken = t; }  if (f == null) { this.delegate.skipChildren(); } else { f = this._headContext.checkValue(f); if (f == null) { this.delegate.skipChildren(); } else { if (f != TokenFilter.INCLUDE_ALL) f = f.filterStartObject();  this._itemFilter = f; if (f == TokenFilter.INCLUDE_ALL) { this._headContext = this._headContext.createChildObjectContext(f, true); return this._currToken = t; }  if (f != null && this._inclusion == TokenFilter.Inclusion.INCLUDE_NON_NULL) { this._headContext = this._headContext.createChildObjectContext(f, true); return this._currToken = t; }  this._headContext = this._headContext.createChildObjectContext(f, false); if (this._inclusion == TokenFilter.Inclusion.INCLUDE_ALL_AND_PATH) { t = _nextTokenWithBuffering(this._headContext); if (t != null) { this._currToken = t; return t; }  }  }  }  return _nextToken2();case 2: case 4: returnEnd = this._headContext.isStartHandled(); f = this._headContext.getFilter(); if (f != null && f != TokenFilter.INCLUDE_ALL) f.filterFinishArray();  this._headContext = this._headContext.getParent(); this._itemFilter = this._headContext.getFilter(); if (returnEnd) return this._currToken = t;  return _nextToken2();case 5: name = this.delegate.getCurrentName(); f = this._headContext.setFieldName(name); if (f == TokenFilter.INCLUDE_ALL) { this._itemFilter = f; return this._currToken = t; }  if (f == null) { this.delegate.nextToken(); this.delegate.skipChildren(); } else { f = f.includeProperty(name); if (f == null) { this.delegate.nextToken(); this.delegate.skipChildren(); } else { this._itemFilter = f; if (f == TokenFilter.INCLUDE_ALL) if (_verifyAllowedMatches()) { if (this._inclusion == TokenFilter.Inclusion.INCLUDE_ALL_AND_PATH) return this._currToken = t;  } else { this.delegate.nextToken(); this.delegate.skipChildren(); }   if (this._inclusion != TokenFilter.Inclusion.ONLY_INCLUDE_ALL) { t = _nextTokenWithBuffering(this._headContext); if (t != null) { this._currToken = t; return t; }  }  }  }  return _nextToken2(); }  TokenFilter f = this._itemFilter; if (f == TokenFilter.INCLUDE_ALL) return this._currToken = t;  if (f != null) { f = this._headContext.checkValue(f); if ((f == TokenFilter.INCLUDE_ALL || (f != null && f.includeValue(this.delegate))) && _verifyAllowedMatches()) return this._currToken = t;  }  return _nextToken2();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final JsonToken _nextToken2() throws IOException {
/*     */     while (true) {
/*     */       boolean returnEnd;
/*     */       String name;
/* 466 */       JsonToken t = this.delegate.nextToken();
/* 467 */       if (t == null) {
/* 468 */         this._currToken = t;
/* 469 */         return t;
/*     */       } 
/*     */ 
/*     */       
/* 473 */       switch (t.id()) {
/*     */         case 3:
/* 475 */           f = this._itemFilter;
/* 476 */           if (f == TokenFilter.INCLUDE_ALL) {
/* 477 */             this._headContext = this._headContext.createChildArrayContext(f, true);
/* 478 */             return this._currToken = t;
/*     */           } 
/* 480 */           if (f == null) {
/* 481 */             this.delegate.skipChildren();
/*     */             
/*     */             continue;
/*     */           } 
/* 485 */           f = this._headContext.checkValue(f);
/* 486 */           if (f == null) {
/* 487 */             this.delegate.skipChildren();
/*     */             continue;
/*     */           } 
/* 490 */           if (f != TokenFilter.INCLUDE_ALL) {
/* 491 */             f = f.filterStartArray();
/*     */           }
/* 493 */           this._itemFilter = f;
/* 494 */           if (f == TokenFilter.INCLUDE_ALL) {
/* 495 */             this._headContext = this._headContext.createChildArrayContext(f, true);
/* 496 */             return this._currToken = t;
/* 497 */           }  if (f != null && this._inclusion == TokenFilter.Inclusion.INCLUDE_NON_NULL) {
/* 498 */             this._headContext = this._headContext.createChildArrayContext(f, true);
/* 499 */             return this._currToken = t;
/*     */           } 
/* 501 */           this._headContext = this._headContext.createChildArrayContext(f, false);
/*     */           
/* 503 */           if (this._inclusion == TokenFilter.Inclusion.INCLUDE_ALL_AND_PATH) {
/* 504 */             t = _nextTokenWithBuffering(this._headContext);
/* 505 */             if (t != null) {
/* 506 */               this._currToken = t;
/* 507 */               return t;
/*     */             } 
/*     */           } 
/*     */           continue;
/*     */         
/*     */         case 1:
/* 513 */           f = this._itemFilter;
/* 514 */           if (f == TokenFilter.INCLUDE_ALL) {
/* 515 */             this._headContext = this._headContext.createChildObjectContext(f, true);
/* 516 */             return this._currToken = t;
/*     */           } 
/* 518 */           if (f == null) {
/* 519 */             this.delegate.skipChildren();
/*     */             
/*     */             continue;
/*     */           } 
/* 523 */           f = this._headContext.checkValue(f);
/* 524 */           if (f == null) {
/* 525 */             this.delegate.skipChildren();
/*     */             continue;
/*     */           } 
/* 528 */           if (f != TokenFilter.INCLUDE_ALL) {
/* 529 */             f = f.filterStartObject();
/*     */           }
/* 531 */           this._itemFilter = f;
/* 532 */           if (f == TokenFilter.INCLUDE_ALL) {
/* 533 */             this._headContext = this._headContext.createChildObjectContext(f, true);
/* 534 */             return this._currToken = t;
/* 535 */           }  if (f != null && this._inclusion == TokenFilter.Inclusion.INCLUDE_NON_NULL) {
/* 536 */             this._headContext = this._headContext.createChildObjectContext(f, true);
/* 537 */             return this._currToken = t;
/*     */           } 
/* 539 */           this._headContext = this._headContext.createChildObjectContext(f, false);
/* 540 */           if (this._inclusion == TokenFilter.Inclusion.INCLUDE_ALL_AND_PATH) {
/* 541 */             t = _nextTokenWithBuffering(this._headContext);
/* 542 */             if (t != null) {
/* 543 */               this._currToken = t;
/* 544 */               return t;
/*     */             } 
/*     */           } 
/*     */           continue;
/*     */ 
/*     */         
/*     */         case 2:
/*     */         case 4:
/* 552 */           returnEnd = this._headContext.isStartHandled();
/* 553 */           f = this._headContext.getFilter();
/* 554 */           if (f != null && f != TokenFilter.INCLUDE_ALL) {
/* 555 */             f.filterFinishArray();
/*     */           }
/* 557 */           this._headContext = this._headContext.getParent();
/* 558 */           this._itemFilter = this._headContext.getFilter();
/* 559 */           if (returnEnd) {
/* 560 */             return this._currToken = t;
/*     */           }
/*     */           continue;
/*     */ 
/*     */ 
/*     */         
/*     */         case 5:
/* 567 */           name = this.delegate.getCurrentName();
/* 568 */           f = this._headContext.setFieldName(name);
/* 569 */           if (f == TokenFilter.INCLUDE_ALL) {
/* 570 */             this._itemFilter = f;
/* 571 */             return this._currToken = t;
/*     */           } 
/* 573 */           if (f == null) {
/* 574 */             this.delegate.nextToken();
/* 575 */             this.delegate.skipChildren();
/*     */             continue;
/*     */           } 
/* 578 */           f = f.includeProperty(name);
/* 579 */           if (f == null) {
/* 580 */             this.delegate.nextToken();
/* 581 */             this.delegate.skipChildren();
/*     */             continue;
/*     */           } 
/* 584 */           this._itemFilter = f;
/* 585 */           if (f == TokenFilter.INCLUDE_ALL) {
/* 586 */             if (_verifyAllowedMatches() && this._inclusion == TokenFilter.Inclusion.INCLUDE_ALL_AND_PATH) {
/* 587 */               return this._currToken = t;
/*     */             }
/*     */             continue;
/*     */           } 
/* 591 */           if (this._inclusion != TokenFilter.Inclusion.ONLY_INCLUDE_ALL) {
/* 592 */             t = _nextTokenWithBuffering(this._headContext);
/* 593 */             if (t != null) {
/* 594 */               this._currToken = t;
/* 595 */               return t;
/*     */             } 
/*     */           } 
/*     */           continue;
/*     */       } 
/*     */ 
/*     */       
/* 602 */       TokenFilter f = this._itemFilter;
/* 603 */       if (f == TokenFilter.INCLUDE_ALL) {
/* 604 */         return this._currToken = t;
/*     */       }
/* 606 */       if (f != null) {
/* 607 */         f = this._headContext.checkValue(f);
/* 608 */         if ((f == TokenFilter.INCLUDE_ALL || (f != null && f
/* 609 */           .includeValue(this.delegate))) && 
/* 610 */           _verifyAllowedMatches()) {
/* 611 */           return this._currToken = t;
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final JsonToken _nextTokenWithBuffering(TokenFilterContext buffRoot) throws IOException {
/*     */     while (true) {
/*     */       boolean gotEnd;
/*     */       String name;
/*     */       boolean returnEnd;
/* 629 */       JsonToken t = this.delegate.nextToken();
/* 630 */       if (t == null) {
/* 631 */         return t;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 639 */       switch (t.id()) {
/*     */         case 3:
/* 641 */           f = this._headContext.checkValue(this._itemFilter);
/* 642 */           if (f == null) {
/* 643 */             this.delegate.skipChildren();
/*     */             continue;
/*     */           } 
/* 646 */           if (f != TokenFilter.INCLUDE_ALL) {
/* 647 */             f = f.filterStartArray();
/*     */           }
/* 649 */           this._itemFilter = f;
/* 650 */           if (f == TokenFilter.INCLUDE_ALL) {
/* 651 */             this._headContext = this._headContext.createChildArrayContext(f, true);
/* 652 */             return _nextBuffered(buffRoot);
/* 653 */           }  if (f != null && this._inclusion == TokenFilter.Inclusion.INCLUDE_NON_NULL) {
/*     */             
/* 655 */             this._headContext = this._headContext.createChildArrayContext(f, true);
/* 656 */             return _nextBuffered(buffRoot);
/*     */           } 
/* 658 */           this._headContext = this._headContext.createChildArrayContext(f, false);
/*     */           continue;
/*     */         
/*     */         case 1:
/* 662 */           f = this._itemFilter;
/* 663 */           if (f == TokenFilter.INCLUDE_ALL) {
/* 664 */             this._headContext = this._headContext.createChildObjectContext(f, true);
/* 665 */             return t;
/*     */           } 
/* 667 */           if (f == null) {
/* 668 */             this.delegate.skipChildren();
/*     */             
/*     */             continue;
/*     */           } 
/* 672 */           f = this._headContext.checkValue(f);
/* 673 */           if (f == null) {
/* 674 */             this.delegate.skipChildren();
/*     */             continue;
/*     */           } 
/* 677 */           if (f != TokenFilter.INCLUDE_ALL) {
/* 678 */             f = f.filterStartObject();
/*     */           }
/* 680 */           this._itemFilter = f;
/* 681 */           if (f == TokenFilter.INCLUDE_ALL) {
/* 682 */             this._headContext = this._headContext.createChildObjectContext(f, true);
/* 683 */             return _nextBuffered(buffRoot);
/* 684 */           }  if (f != null && this._inclusion == TokenFilter.Inclusion.INCLUDE_NON_NULL) {
/*     */             
/* 686 */             this._headContext = this._headContext.createChildArrayContext(f, true);
/* 687 */             return _nextBuffered(buffRoot);
/*     */           } 
/* 689 */           this._headContext = this._headContext.createChildObjectContext(f, false);
/*     */           continue;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case 2:
/*     */         case 4:
/* 697 */           f = this._headContext.getFilter();
/* 698 */           if (f != null && f != TokenFilter.INCLUDE_ALL) {
/* 699 */             f.filterFinishArray();
/*     */           }
/* 701 */           gotEnd = (this._headContext == buffRoot);
/* 702 */           returnEnd = (gotEnd && this._headContext.isStartHandled());
/*     */           
/* 704 */           this._headContext = this._headContext.getParent();
/* 705 */           this._itemFilter = this._headContext.getFilter();
/*     */           
/* 707 */           if (returnEnd) {
/* 708 */             return t;
/*     */           }
/*     */           continue;
/*     */ 
/*     */ 
/*     */         
/*     */         case 5:
/* 715 */           name = this.delegate.getCurrentName();
/* 716 */           f = this._headContext.setFieldName(name);
/* 717 */           if (f == TokenFilter.INCLUDE_ALL) {
/* 718 */             this._itemFilter = f;
/* 719 */             return _nextBuffered(buffRoot);
/*     */           } 
/* 721 */           if (f == null) {
/* 722 */             this.delegate.nextToken();
/* 723 */             this.delegate.skipChildren();
/*     */             continue;
/*     */           } 
/* 726 */           f = f.includeProperty(name);
/* 727 */           if (f == null) {
/* 728 */             this.delegate.nextToken();
/* 729 */             this.delegate.skipChildren();
/*     */             continue;
/*     */           } 
/* 732 */           this._itemFilter = f;
/* 733 */           if (f == TokenFilter.INCLUDE_ALL) {
/* 734 */             if (_verifyAllowedMatches()) {
/* 735 */               return _nextBuffered(buffRoot);
/*     */             }
/*     */ 
/*     */             
/* 739 */             this._itemFilter = this._headContext.setFieldName(name);
/*     */           } 
/*     */           continue;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 746 */       TokenFilter f = this._itemFilter;
/* 747 */       if (f == TokenFilter.INCLUDE_ALL) {
/* 748 */         return _nextBuffered(buffRoot);
/*     */       }
/* 750 */       if (f != null) {
/* 751 */         f = this._headContext.checkValue(f);
/* 752 */         if ((f == TokenFilter.INCLUDE_ALL || (f != null && f
/* 753 */           .includeValue(this.delegate))) && 
/* 754 */           _verifyAllowedMatches()) {
/* 755 */           return _nextBuffered(buffRoot);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private JsonToken _nextBuffered(TokenFilterContext buffRoot) throws IOException {
/* 767 */     this._exposedContext = buffRoot;
/* 768 */     TokenFilterContext ctxt = buffRoot;
/* 769 */     JsonToken t = ctxt.nextTokenToRead();
/* 770 */     if (t != null) {
/* 771 */       return t;
/*     */     }
/*     */     
/*     */     while (true) {
/* 775 */       if (ctxt == this._headContext) {
/* 776 */         throw _constructError("Internal error: failed to locate expected buffered tokens");
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 783 */       ctxt = this._exposedContext.findChildOf(ctxt);
/* 784 */       this._exposedContext = ctxt;
/* 785 */       if (ctxt == null) {
/* 786 */         throw _constructError("Unexpected problem: chain of filtered context broken");
/*     */       }
/* 788 */       t = this._exposedContext.nextTokenToRead();
/* 789 */       if (t != null) {
/* 790 */         return t;
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private final boolean _verifyAllowedMatches() throws IOException {
/* 796 */     if (this._matchCount == 0 || this._allowMultipleMatches) {
/* 797 */       this._matchCount++;
/* 798 */       return true;
/*     */     } 
/* 800 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonToken nextValue() throws IOException {
/* 806 */     JsonToken t = nextToken();
/* 807 */     if (t == JsonToken.FIELD_NAME) {
/* 808 */       t = nextToken();
/*     */     }
/* 810 */     return t;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonParser skipChildren() throws IOException {
/* 821 */     if (this._currToken != JsonToken.START_OBJECT && this._currToken != JsonToken.START_ARRAY)
/*     */     {
/* 823 */       return (JsonParser)this;
/*     */     }
/* 825 */     int open = 1;
/*     */ 
/*     */ 
/*     */     
/*     */     while (true) {
/* 830 */       JsonToken t = nextToken();
/* 831 */       if (t == null) {
/* 832 */         return (JsonParser)this;
/*     */       }
/* 834 */       if (t.isStructStart()) {
/* 835 */         open++; continue;
/* 836 */       }  if (t.isStructEnd() && 
/* 837 */         --open == 0) {
/* 838 */         return (JsonParser)this;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getText() throws IOException {
/* 850 */     return this.delegate.getText();
/* 851 */   } public boolean hasTextCharacters() { return this.delegate.hasTextCharacters(); }
/* 852 */   public char[] getTextCharacters() throws IOException { return this.delegate.getTextCharacters(); }
/* 853 */   public int getTextLength() throws IOException { return this.delegate.getTextLength(); } public int getTextOffset() throws IOException {
/* 854 */     return this.delegate.getTextOffset();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BigInteger getBigIntegerValue() throws IOException {
/* 863 */     return this.delegate.getBigIntegerValue();
/*     */   }
/*     */   public boolean getBooleanValue() throws IOException {
/* 866 */     return this.delegate.getBooleanValue();
/*     */   }
/*     */   public byte getByteValue() throws IOException {
/* 869 */     return this.delegate.getByteValue();
/*     */   }
/*     */   public short getShortValue() throws IOException {
/* 872 */     return this.delegate.getShortValue();
/*     */   }
/*     */   public BigDecimal getDecimalValue() throws IOException {
/* 875 */     return this.delegate.getDecimalValue();
/*     */   }
/*     */   public double getDoubleValue() throws IOException {
/* 878 */     return this.delegate.getDoubleValue();
/*     */   }
/*     */   public float getFloatValue() throws IOException {
/* 881 */     return this.delegate.getFloatValue();
/*     */   }
/*     */   public int getIntValue() throws IOException {
/* 884 */     return this.delegate.getIntValue();
/*     */   }
/*     */   public long getLongValue() throws IOException {
/* 887 */     return this.delegate.getLongValue();
/*     */   }
/*     */   public JsonParser.NumberType getNumberType() throws IOException {
/* 890 */     return this.delegate.getNumberType();
/*     */   }
/*     */   public Number getNumberValue() throws IOException {
/* 893 */     return this.delegate.getNumberValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getValueAsInt() throws IOException {
/* 901 */     return this.delegate.getValueAsInt();
/* 902 */   } public int getValueAsInt(int defaultValue) throws IOException { return this.delegate.getValueAsInt(defaultValue); }
/* 903 */   public long getValueAsLong() throws IOException { return this.delegate.getValueAsLong(); }
/* 904 */   public long getValueAsLong(long defaultValue) throws IOException { return this.delegate.getValueAsLong(defaultValue); }
/* 905 */   public double getValueAsDouble() throws IOException { return this.delegate.getValueAsDouble(); }
/* 906 */   public double getValueAsDouble(double defaultValue) throws IOException { return this.delegate.getValueAsDouble(defaultValue); }
/* 907 */   public boolean getValueAsBoolean() throws IOException { return this.delegate.getValueAsBoolean(); }
/* 908 */   public boolean getValueAsBoolean(boolean defaultValue) throws IOException { return this.delegate.getValueAsBoolean(defaultValue); }
/* 909 */   public String getValueAsString() throws IOException { return this.delegate.getValueAsString(); } public String getValueAsString(String defaultValue) throws IOException {
/* 910 */     return this.delegate.getValueAsString(defaultValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getEmbeddedObject() throws IOException {
/* 918 */     return this.delegate.getEmbeddedObject();
/* 919 */   } public byte[] getBinaryValue(Base64Variant b64variant) throws IOException { return this.delegate.getBinaryValue(b64variant); }
/* 920 */   public int readBinaryValue(Base64Variant b64variant, OutputStream out) throws IOException { return this.delegate.readBinaryValue(b64variant, out); } public JsonLocation getTokenLocation() {
/* 921 */     return this.delegate.getTokenLocation();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonStreamContext _filterContext() {
/* 930 */     if (this._exposedContext != null) {
/* 931 */       return this._exposedContext;
/*     */     }
/* 933 */     return this._headContext;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-core-2.12.4.jar!\com\fasterxml\jackson\core\filter\FilteringParserDelegate.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */