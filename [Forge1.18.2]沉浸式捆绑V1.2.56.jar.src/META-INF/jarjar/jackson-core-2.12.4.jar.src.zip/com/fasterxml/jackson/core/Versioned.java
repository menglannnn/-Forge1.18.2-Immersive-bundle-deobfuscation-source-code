package com.fasterxml.jackson.core;

public interface Versioned {
  Version version();
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-core-2.12.4.jar!\com\fasterxml\jackson\core\Versioned.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */