/*    */ package com.fasterxml.jackson.core.util;
/*    */ 
/*    */ import java.lang.ref.SoftReference;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BufferRecyclers
/*    */ {
/*    */   public static final String SYSTEM_PROPERTY_TRACK_REUSABLE_BUFFERS = "com.fasterxml.jackson.core.util.BufferRecyclers.trackReusableBuffers";
/*    */   private static final ThreadLocalBufferManager _bufferRecyclerTracker;
/*    */   
/*    */   static {
/* 36 */     boolean trackReusableBuffers = false;
/*    */     try {
/* 38 */       trackReusableBuffers = "true".equals(System.getProperty("com.fasterxml.jackson.core.util.BufferRecyclers.trackReusableBuffers"));
/* 39 */     } catch (SecurityException securityException) {}
/*    */     
/* 41 */     _bufferRecyclerTracker = trackReusableBuffers ? ThreadLocalBufferManager.instance() : null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 55 */   protected static final ThreadLocal<SoftReference<BufferRecycler>> _recyclerRef = new ThreadLocal<SoftReference<BufferRecycler>>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static BufferRecycler getBufferRecycler() {
/* 65 */     SoftReference<BufferRecycler> ref = _recyclerRef.get();
/* 66 */     BufferRecycler br = (ref == null) ? null : ref.get();
/*    */     
/* 68 */     if (br == null) {
/* 69 */       br = new BufferRecycler();
/* 70 */       if (_bufferRecyclerTracker != null) {
/* 71 */         ref = _bufferRecyclerTracker.wrapAndTrack(br);
/*    */       } else {
/* 73 */         ref = new SoftReference<BufferRecycler>(br);
/*    */       } 
/* 75 */       _recyclerRef.set(ref);
/*    */     } 
/* 77 */     return br;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static int releaseBuffers() {
/* 94 */     if (_bufferRecyclerTracker != null) {
/* 95 */       return _bufferRecyclerTracker.releaseBuffers();
/*    */     }
/* 97 */     return -1;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-core-2.12.4.jar!\com\fasterxml\jackson\cor\\util\BufferRecyclers.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */