/*      */ package com.fasterxml.jackson.core.json;
/*      */ 
/*      */ import com.fasterxml.jackson.core.Base64Variant;
/*      */ import com.fasterxml.jackson.core.JsonLocation;
/*      */ import com.fasterxml.jackson.core.JsonParseException;
/*      */ import com.fasterxml.jackson.core.JsonParser;
/*      */ import com.fasterxml.jackson.core.JsonToken;
/*      */ import com.fasterxml.jackson.core.ObjectCodec;
/*      */ import com.fasterxml.jackson.core.StreamReadCapability;
/*      */ import com.fasterxml.jackson.core.base.ParserBase;
/*      */ import com.fasterxml.jackson.core.io.CharTypes;
/*      */ import com.fasterxml.jackson.core.io.IOContext;
/*      */ import com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer;
/*      */ import com.fasterxml.jackson.core.util.ByteArrayBuilder;
/*      */ import com.fasterxml.jackson.core.util.JacksonFeatureSet;
/*      */ import java.io.DataInput;
/*      */ import java.io.EOFException;
/*      */ import java.io.IOException;
/*      */ import java.io.OutputStream;
/*      */ import java.io.Writer;
/*      */ import java.util.Arrays;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class UTF8DataInputJsonParser
/*      */   extends ParserBase
/*      */ {
/*      */   static final byte BYTE_LF = 10;
/*   44 */   private static final int FEAT_MASK_TRAILING_COMMA = JsonParser.Feature.ALLOW_TRAILING_COMMA.getMask();
/*      */   
/*   46 */   private static final int FEAT_MASK_LEADING_ZEROS = JsonParser.Feature.ALLOW_NUMERIC_LEADING_ZEROS.getMask();
/*      */   
/*   48 */   private static final int FEAT_MASK_NON_NUM_NUMBERS = JsonParser.Feature.ALLOW_NON_NUMERIC_NUMBERS.getMask();
/*      */   
/*   50 */   private static final int FEAT_MASK_ALLOW_MISSING = JsonParser.Feature.ALLOW_MISSING_VALUES.getMask();
/*   51 */   private static final int FEAT_MASK_ALLOW_SINGLE_QUOTES = JsonParser.Feature.ALLOW_SINGLE_QUOTES.getMask();
/*   52 */   private static final int FEAT_MASK_ALLOW_UNQUOTED_NAMES = JsonParser.Feature.ALLOW_UNQUOTED_FIELD_NAMES.getMask();
/*   53 */   private static final int FEAT_MASK_ALLOW_JAVA_COMMENTS = JsonParser.Feature.ALLOW_COMMENTS.getMask();
/*   54 */   private static final int FEAT_MASK_ALLOW_YAML_COMMENTS = JsonParser.Feature.ALLOW_YAML_COMMENTS.getMask();
/*      */ 
/*      */   
/*   57 */   private static final int[] _icUTF8 = CharTypes.getInputCodeUtf8();
/*      */ 
/*      */ 
/*      */   
/*   61 */   protected static final int[] _icLatin1 = CharTypes.getInputCodeLatin1();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ObjectCodec _objectCodec;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final ByteQuadsCanonicalizer _symbols;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   90 */   protected int[] _quadBuffer = new int[16];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _tokenIncomplete;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int _quad1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected DataInput _inputData;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  116 */   protected int _nextByte = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public UTF8DataInputJsonParser(IOContext ctxt, int features, DataInput inputData, ObjectCodec codec, ByteQuadsCanonicalizer sym, int firstByte) {
/*  128 */     super(ctxt, features);
/*  129 */     this._objectCodec = codec;
/*  130 */     this._symbols = sym;
/*  131 */     this._inputData = inputData;
/*  132 */     this._nextByte = firstByte;
/*      */   }
/*      */ 
/*      */   
/*      */   public ObjectCodec getCodec() {
/*  137 */     return this._objectCodec;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setCodec(ObjectCodec c) {
/*  142 */     this._objectCodec = c;
/*      */   }
/*      */ 
/*      */   
/*      */   public JacksonFeatureSet<StreamReadCapability> getReadCapabilities() {
/*  147 */     return JSON_READ_CAPABILITIES;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int releaseBuffered(OutputStream out) throws IOException {
/*  158 */     return 0;
/*      */   }
/*      */ 
/*      */   
/*      */   public Object getInputSource() {
/*  163 */     return this._inputData;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _closeInput() throws IOException {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _releaseBuffers() throws IOException {
/*  184 */     super._releaseBuffers();
/*      */     
/*  186 */     this._symbols.release();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getText() throws IOException {
/*  198 */     if (this._currToken == JsonToken.VALUE_STRING) {
/*  199 */       if (this._tokenIncomplete) {
/*  200 */         this._tokenIncomplete = false;
/*  201 */         return _finishAndReturnString();
/*      */       } 
/*  203 */       return this._textBuffer.contentsAsString();
/*      */     } 
/*  205 */     return _getText2(this._currToken);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getText(Writer writer) throws IOException {
/*  211 */     JsonToken t = this._currToken;
/*  212 */     if (t == JsonToken.VALUE_STRING) {
/*  213 */       if (this._tokenIncomplete) {
/*  214 */         this._tokenIncomplete = false;
/*  215 */         _finishString();
/*      */       } 
/*  217 */       return this._textBuffer.contentsToWriter(writer);
/*      */     } 
/*  219 */     if (t == JsonToken.FIELD_NAME) {
/*  220 */       String n = this._parsingContext.getCurrentName();
/*  221 */       writer.write(n);
/*  222 */       return n.length();
/*      */     } 
/*  224 */     if (t != null) {
/*  225 */       if (t.isNumeric()) {
/*  226 */         return this._textBuffer.contentsToWriter(writer);
/*      */       }
/*  228 */       char[] ch = t.asCharArray();
/*  229 */       writer.write(ch);
/*  230 */       return ch.length;
/*      */     } 
/*  232 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getValueAsString() throws IOException {
/*  239 */     if (this._currToken == JsonToken.VALUE_STRING) {
/*  240 */       if (this._tokenIncomplete) {
/*  241 */         this._tokenIncomplete = false;
/*  242 */         return _finishAndReturnString();
/*      */       } 
/*  244 */       return this._textBuffer.contentsAsString();
/*      */     } 
/*  246 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  247 */       return getCurrentName();
/*      */     }
/*  249 */     return super.getValueAsString(null);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getValueAsString(String defValue) throws IOException {
/*  255 */     if (this._currToken == JsonToken.VALUE_STRING) {
/*  256 */       if (this._tokenIncomplete) {
/*  257 */         this._tokenIncomplete = false;
/*  258 */         return _finishAndReturnString();
/*      */       } 
/*  260 */       return this._textBuffer.contentsAsString();
/*      */     } 
/*  262 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  263 */       return getCurrentName();
/*      */     }
/*  265 */     return super.getValueAsString(defValue);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getValueAsInt() throws IOException {
/*  271 */     JsonToken t = this._currToken;
/*  272 */     if (t == JsonToken.VALUE_NUMBER_INT || t == JsonToken.VALUE_NUMBER_FLOAT) {
/*      */       
/*  274 */       if ((this._numTypesValid & 0x1) == 0) {
/*  275 */         if (this._numTypesValid == 0) {
/*  276 */           return _parseIntValue();
/*      */         }
/*  278 */         if ((this._numTypesValid & 0x1) == 0) {
/*  279 */           convertNumberToInt();
/*      */         }
/*      */       } 
/*  282 */       return this._numberInt;
/*      */     } 
/*  284 */     return super.getValueAsInt(0);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getValueAsInt(int defValue) throws IOException {
/*  290 */     JsonToken t = this._currToken;
/*  291 */     if (t == JsonToken.VALUE_NUMBER_INT || t == JsonToken.VALUE_NUMBER_FLOAT) {
/*      */       
/*  293 */       if ((this._numTypesValid & 0x1) == 0) {
/*  294 */         if (this._numTypesValid == 0) {
/*  295 */           return _parseIntValue();
/*      */         }
/*  297 */         if ((this._numTypesValid & 0x1) == 0) {
/*  298 */           convertNumberToInt();
/*      */         }
/*      */       } 
/*  301 */       return this._numberInt;
/*      */     } 
/*  303 */     return super.getValueAsInt(defValue);
/*      */   }
/*      */ 
/*      */   
/*      */   protected final String _getText2(JsonToken t) {
/*  308 */     if (t == null) {
/*  309 */       return null;
/*      */     }
/*  311 */     switch (t.id()) {
/*      */       case 5:
/*  313 */         return this._parsingContext.getCurrentName();
/*      */ 
/*      */       
/*      */       case 6:
/*      */       case 7:
/*      */       case 8:
/*  319 */         return this._textBuffer.contentsAsString();
/*      */     } 
/*  321 */     return t.asString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public char[] getTextCharacters() throws IOException {
/*  328 */     if (this._currToken != null) {
/*  329 */       switch (this._currToken.id()) {
/*      */         
/*      */         case 5:
/*  332 */           if (!this._nameCopied) {
/*  333 */             String name = this._parsingContext.getCurrentName();
/*  334 */             int nameLen = name.length();
/*  335 */             if (this._nameCopyBuffer == null) {
/*  336 */               this._nameCopyBuffer = this._ioContext.allocNameCopyBuffer(nameLen);
/*  337 */             } else if (this._nameCopyBuffer.length < nameLen) {
/*  338 */               this._nameCopyBuffer = new char[nameLen];
/*      */             } 
/*  340 */             name.getChars(0, nameLen, this._nameCopyBuffer, 0);
/*  341 */             this._nameCopied = true;
/*      */           } 
/*  343 */           return this._nameCopyBuffer;
/*      */         
/*      */         case 6:
/*  346 */           if (this._tokenIncomplete) {
/*  347 */             this._tokenIncomplete = false;
/*  348 */             _finishString();
/*      */           } 
/*      */         
/*      */         case 7:
/*      */         case 8:
/*  353 */           return this._textBuffer.getTextBuffer();
/*      */       } 
/*      */       
/*  356 */       return this._currToken.asCharArray();
/*      */     } 
/*      */     
/*  359 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getTextLength() throws IOException {
/*  365 */     if (this._currToken == JsonToken.VALUE_STRING) {
/*  366 */       if (this._tokenIncomplete) {
/*  367 */         this._tokenIncomplete = false;
/*  368 */         _finishString();
/*      */       } 
/*  370 */       return this._textBuffer.size();
/*      */     } 
/*  372 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  373 */       return this._parsingContext.getCurrentName().length();
/*      */     }
/*  375 */     if (this._currToken != null) {
/*  376 */       if (this._currToken.isNumeric()) {
/*  377 */         return this._textBuffer.size();
/*      */       }
/*  379 */       return (this._currToken.asCharArray()).length;
/*      */     } 
/*  381 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getTextOffset() throws IOException {
/*  388 */     if (this._currToken != null) {
/*  389 */       switch (this._currToken.id()) {
/*      */         case 5:
/*  391 */           return 0;
/*      */         case 6:
/*  393 */           if (this._tokenIncomplete) {
/*  394 */             this._tokenIncomplete = false;
/*  395 */             _finishString();
/*      */           } 
/*      */         
/*      */         case 7:
/*      */         case 8:
/*  400 */           return this._textBuffer.getTextOffset();
/*      */       } 
/*      */     
/*      */     }
/*  404 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] getBinaryValue(Base64Variant b64variant) throws IOException {
/*  410 */     if (this._currToken != JsonToken.VALUE_STRING && (this._currToken != JsonToken.VALUE_EMBEDDED_OBJECT || this._binaryValue == null))
/*      */     {
/*  412 */       _reportError("Current token (" + this._currToken + ") not VALUE_STRING or VALUE_EMBEDDED_OBJECT, can not access as binary");
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  417 */     if (this._tokenIncomplete) {
/*      */       try {
/*  419 */         this._binaryValue = _decodeBase64(b64variant);
/*  420 */       } catch (IllegalArgumentException iae) {
/*  421 */         throw _constructError("Failed to decode VALUE_STRING as base64 (" + b64variant + "): " + iae.getMessage());
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  426 */       this._tokenIncomplete = false;
/*      */     }
/*  428 */     else if (this._binaryValue == null) {
/*      */       
/*  430 */       ByteArrayBuilder builder = _getByteArrayBuilder();
/*  431 */       _decodeBase64(getText(), builder, b64variant);
/*  432 */       this._binaryValue = builder.toByteArray();
/*      */     } 
/*      */     
/*  435 */     return this._binaryValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int readBinaryValue(Base64Variant b64variant, OutputStream out) throws IOException {
/*  442 */     if (!this._tokenIncomplete || this._currToken != JsonToken.VALUE_STRING) {
/*  443 */       byte[] b = getBinaryValue(b64variant);
/*  444 */       out.write(b);
/*  445 */       return b.length;
/*      */     } 
/*      */     
/*  448 */     byte[] buf = this._ioContext.allocBase64Buffer();
/*      */     try {
/*  450 */       return _readBinary(b64variant, out, buf);
/*      */     } finally {
/*  452 */       this._ioContext.releaseBase64Buffer(buf);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _readBinary(Base64Variant b64variant, OutputStream out, byte[] buffer) throws IOException {
/*  459 */     int outputPtr = 0;
/*  460 */     int outputEnd = buffer.length - 3;
/*  461 */     int outputCount = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/*  467 */       int ch = this._inputData.readUnsignedByte();
/*  468 */       if (ch > 32) {
/*  469 */         int bits = b64variant.decodeBase64Char(ch);
/*  470 */         if (bits < 0) {
/*  471 */           if (ch == 34) {
/*      */             break;
/*      */           }
/*  474 */           bits = _decodeBase64Escape(b64variant, ch, 0);
/*  475 */           if (bits < 0) {
/*      */             continue;
/*      */           }
/*      */         } 
/*      */ 
/*      */         
/*  481 */         if (outputPtr > outputEnd) {
/*  482 */           outputCount += outputPtr;
/*  483 */           out.write(buffer, 0, outputPtr);
/*  484 */           outputPtr = 0;
/*      */         } 
/*      */         
/*  487 */         int decodedData = bits;
/*      */ 
/*      */         
/*  490 */         ch = this._inputData.readUnsignedByte();
/*  491 */         bits = b64variant.decodeBase64Char(ch);
/*  492 */         if (bits < 0) {
/*  493 */           bits = _decodeBase64Escape(b64variant, ch, 1);
/*      */         }
/*  495 */         decodedData = decodedData << 6 | bits;
/*      */ 
/*      */         
/*  498 */         ch = this._inputData.readUnsignedByte();
/*  499 */         bits = b64variant.decodeBase64Char(ch);
/*      */ 
/*      */         
/*  502 */         if (bits < 0) {
/*  503 */           if (bits != -2) {
/*      */             
/*  505 */             if (ch == 34) {
/*  506 */               decodedData >>= 4;
/*  507 */               buffer[outputPtr++] = (byte)decodedData;
/*  508 */               if (b64variant.usesPadding()) {
/*  509 */                 _handleBase64MissingPadding(b64variant);
/*      */               }
/*      */               break;
/*      */             } 
/*  513 */             bits = _decodeBase64Escape(b64variant, ch, 2);
/*      */           } 
/*  515 */           if (bits == -2) {
/*      */             
/*  517 */             ch = this._inputData.readUnsignedByte();
/*  518 */             if (!b64variant.usesPaddingChar(ch) && (
/*  519 */               ch != 92 || 
/*  520 */               _decodeBase64Escape(b64variant, ch, 3) != -2)) {
/*  521 */               throw reportInvalidBase64Char(b64variant, ch, 3, "expected padding character '" + b64variant.getPaddingChar() + "'");
/*      */             }
/*      */ 
/*      */             
/*  525 */             decodedData >>= 4;
/*  526 */             buffer[outputPtr++] = (byte)decodedData;
/*      */             
/*      */             continue;
/*      */           } 
/*      */         } 
/*  531 */         decodedData = decodedData << 6 | bits;
/*      */         
/*  533 */         ch = this._inputData.readUnsignedByte();
/*  534 */         bits = b64variant.decodeBase64Char(ch);
/*  535 */         if (bits < 0) {
/*  536 */           if (bits != -2) {
/*      */             
/*  538 */             if (ch == 34) {
/*  539 */               decodedData >>= 2;
/*  540 */               buffer[outputPtr++] = (byte)(decodedData >> 8);
/*  541 */               buffer[outputPtr++] = (byte)decodedData;
/*  542 */               if (b64variant.usesPadding()) {
/*  543 */                 _handleBase64MissingPadding(b64variant);
/*      */               }
/*      */               break;
/*      */             } 
/*  547 */             bits = _decodeBase64Escape(b64variant, ch, 3);
/*      */           } 
/*  549 */           if (bits == -2) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  556 */             decodedData >>= 2;
/*  557 */             buffer[outputPtr++] = (byte)(decodedData >> 8);
/*  558 */             buffer[outputPtr++] = (byte)decodedData;
/*      */             
/*      */             continue;
/*      */           } 
/*      */         } 
/*  563 */         decodedData = decodedData << 6 | bits;
/*  564 */         buffer[outputPtr++] = (byte)(decodedData >> 16);
/*  565 */         buffer[outputPtr++] = (byte)(decodedData >> 8);
/*  566 */         buffer[outputPtr++] = (byte)decodedData;
/*      */       } 
/*  568 */     }  this._tokenIncomplete = false;
/*  569 */     if (outputPtr > 0) {
/*  570 */       outputCount += outputPtr;
/*  571 */       out.write(buffer, 0, outputPtr);
/*      */     } 
/*  573 */     return outputCount;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonToken nextToken() throws IOException {
/*  589 */     if (this._closed) {
/*  590 */       return null;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  596 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  597 */       return _nextAfterName();
/*      */     }
/*      */ 
/*      */     
/*  601 */     this._numTypesValid = 0;
/*  602 */     if (this._tokenIncomplete) {
/*  603 */       _skipString();
/*      */     }
/*  605 */     int i = _skipWSOrEnd();
/*  606 */     if (i < 0) {
/*      */       
/*  608 */       close();
/*  609 */       return this._currToken = null;
/*      */     } 
/*      */     
/*  612 */     this._binaryValue = null;
/*  613 */     this._tokenInputRow = this._currInputRow;
/*      */ 
/*      */     
/*  616 */     if (i == 93 || i == 125) {
/*  617 */       _closeScope(i);
/*  618 */       return this._currToken;
/*      */     } 
/*      */ 
/*      */     
/*  622 */     if (this._parsingContext.expectComma()) {
/*  623 */       if (i != 44) {
/*  624 */         _reportUnexpectedChar(i, "was expecting comma to separate " + this._parsingContext.typeDesc() + " entries");
/*      */       }
/*  626 */       i = _skipWS();
/*      */ 
/*      */       
/*  629 */       if ((this._features & FEAT_MASK_TRAILING_COMMA) != 0 && (
/*  630 */         i == 93 || i == 125)) {
/*  631 */         _closeScope(i);
/*  632 */         return this._currToken;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  641 */     if (!this._parsingContext.inObject()) {
/*  642 */       return _nextTokenNotInObject(i);
/*      */     }
/*      */     
/*  645 */     String n = _parseName(i);
/*  646 */     this._parsingContext.setCurrentName(n);
/*  647 */     this._currToken = JsonToken.FIELD_NAME;
/*      */     
/*  649 */     i = _skipColon();
/*      */ 
/*      */     
/*  652 */     if (i == 34) {
/*  653 */       this._tokenIncomplete = true;
/*  654 */       this._nextToken = JsonToken.VALUE_STRING;
/*  655 */       return this._currToken;
/*      */     } 
/*      */ 
/*      */     
/*  659 */     switch (i)
/*      */     { case 45:
/*  661 */         t = _parseNegNumber();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  704 */         this._nextToken = t;
/*  705 */         return this._currToken;case 46: t = _parseFloatThatStartsWithPeriod(); this._nextToken = t; return this._currToken;case 48: case 49: case 50: case 51: case 52: case 53: case 54: case 55: case 56: case 57: t = _parsePosNumber(i); this._nextToken = t; return this._currToken;case 102: _matchToken("false", 1); t = JsonToken.VALUE_FALSE; this._nextToken = t; return this._currToken;case 110: _matchToken("null", 1); t = JsonToken.VALUE_NULL; this._nextToken = t; return this._currToken;case 116: _matchToken("true", 1); t = JsonToken.VALUE_TRUE; this._nextToken = t; return this._currToken;case 91: t = JsonToken.START_ARRAY; this._nextToken = t; return this._currToken;case 123: t = JsonToken.START_OBJECT; this._nextToken = t; return this._currToken; }  JsonToken t = _handleUnexpectedValue(i); this._nextToken = t; return this._currToken;
/*      */   }
/*      */ 
/*      */   
/*      */   private final JsonToken _nextTokenNotInObject(int i) throws IOException {
/*  710 */     if (i == 34) {
/*  711 */       this._tokenIncomplete = true;
/*  712 */       return this._currToken = JsonToken.VALUE_STRING;
/*      */     } 
/*  714 */     switch (i) {
/*      */       case 91:
/*  716 */         this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/*  717 */         return this._currToken = JsonToken.START_ARRAY;
/*      */       case 123:
/*  719 */         this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*  720 */         return this._currToken = JsonToken.START_OBJECT;
/*      */       case 116:
/*  722 */         _matchToken("true", 1);
/*  723 */         return this._currToken = JsonToken.VALUE_TRUE;
/*      */       case 102:
/*  725 */         _matchToken("false", 1);
/*  726 */         return this._currToken = JsonToken.VALUE_FALSE;
/*      */       case 110:
/*  728 */         _matchToken("null", 1);
/*  729 */         return this._currToken = JsonToken.VALUE_NULL;
/*      */       case 45:
/*  731 */         return this._currToken = _parseNegNumber();
/*      */ 
/*      */ 
/*      */       
/*      */       case 46:
/*  736 */         return this._currToken = _parseFloatThatStartsWithPeriod();
/*      */       case 48:
/*      */       case 49:
/*      */       case 50:
/*      */       case 51:
/*      */       case 52:
/*      */       case 53:
/*      */       case 54:
/*      */       case 55:
/*      */       case 56:
/*      */       case 57:
/*  747 */         return this._currToken = _parsePosNumber(i);
/*      */     } 
/*  749 */     return this._currToken = _handleUnexpectedValue(i);
/*      */   }
/*      */ 
/*      */   
/*      */   private final JsonToken _nextAfterName() {
/*  754 */     this._nameCopied = false;
/*  755 */     JsonToken t = this._nextToken;
/*  756 */     this._nextToken = null;
/*      */ 
/*      */     
/*  759 */     if (t == JsonToken.START_ARRAY) {
/*  760 */       this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/*  761 */     } else if (t == JsonToken.START_OBJECT) {
/*  762 */       this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */     } 
/*  764 */     return this._currToken = t;
/*      */   }
/*      */ 
/*      */   
/*      */   public void finishToken() throws IOException {
/*  769 */     if (this._tokenIncomplete) {
/*  770 */       this._tokenIncomplete = false;
/*  771 */       _finishString();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String nextFieldName() throws IOException {
/*  789 */     this._numTypesValid = 0;
/*  790 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  791 */       _nextAfterName();
/*  792 */       return null;
/*      */     } 
/*  794 */     if (this._tokenIncomplete) {
/*  795 */       _skipString();
/*      */     }
/*  797 */     int i = _skipWS();
/*  798 */     this._binaryValue = null;
/*  799 */     this._tokenInputRow = this._currInputRow;
/*      */     
/*  801 */     if (i == 93 || i == 125) {
/*  802 */       _closeScope(i);
/*  803 */       return null;
/*      */     } 
/*      */ 
/*      */     
/*  807 */     if (this._parsingContext.expectComma()) {
/*  808 */       if (i != 44) {
/*  809 */         _reportUnexpectedChar(i, "was expecting comma to separate " + this._parsingContext.typeDesc() + " entries");
/*      */       }
/*  811 */       i = _skipWS();
/*      */ 
/*      */       
/*  814 */       if ((this._features & FEAT_MASK_TRAILING_COMMA) != 0 && (
/*  815 */         i == 93 || i == 125)) {
/*  816 */         _closeScope(i);
/*  817 */         return null;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  822 */     if (!this._parsingContext.inObject()) {
/*  823 */       _nextTokenNotInObject(i);
/*  824 */       return null;
/*      */     } 
/*      */     
/*  827 */     String nameStr = _parseName(i);
/*  828 */     this._parsingContext.setCurrentName(nameStr);
/*  829 */     this._currToken = JsonToken.FIELD_NAME;
/*      */     
/*  831 */     i = _skipColon();
/*  832 */     if (i == 34) {
/*  833 */       this._tokenIncomplete = true;
/*  834 */       this._nextToken = JsonToken.VALUE_STRING;
/*  835 */       return nameStr;
/*      */     } 
/*      */     
/*  838 */     switch (i)
/*      */     { case 45:
/*  840 */         t = _parseNegNumber();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  878 */         this._nextToken = t;
/*  879 */         return nameStr;case 46: t = _parseFloatThatStartsWithPeriod();case 48: case 49: case 50: case 51: case 52: case 53: case 54: case 55: case 56: case 57: t = _parsePosNumber(i); this._nextToken = t; return nameStr;case 102: _matchToken("false", 1); t = JsonToken.VALUE_FALSE; this._nextToken = t; return nameStr;case 110: _matchToken("null", 1); t = JsonToken.VALUE_NULL; this._nextToken = t; return nameStr;case 116: _matchToken("true", 1); t = JsonToken.VALUE_TRUE; this._nextToken = t; return nameStr;case 91: t = JsonToken.START_ARRAY; this._nextToken = t; return nameStr;case 123: t = JsonToken.START_OBJECT; this._nextToken = t; return nameStr; }  JsonToken t = _handleUnexpectedValue(i); this._nextToken = t; return nameStr;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String nextTextValue() throws IOException {
/*  886 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  887 */       this._nameCopied = false;
/*  888 */       JsonToken t = this._nextToken;
/*  889 */       this._nextToken = null;
/*  890 */       this._currToken = t;
/*  891 */       if (t == JsonToken.VALUE_STRING) {
/*  892 */         if (this._tokenIncomplete) {
/*  893 */           this._tokenIncomplete = false;
/*  894 */           return _finishAndReturnString();
/*      */         } 
/*  896 */         return this._textBuffer.contentsAsString();
/*      */       } 
/*  898 */       if (t == JsonToken.START_ARRAY) {
/*  899 */         this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/*  900 */       } else if (t == JsonToken.START_OBJECT) {
/*  901 */         this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */       } 
/*  903 */       return null;
/*      */     } 
/*  905 */     return (nextToken() == JsonToken.VALUE_STRING) ? getText() : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int nextIntValue(int defaultValue) throws IOException {
/*  912 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  913 */       this._nameCopied = false;
/*  914 */       JsonToken t = this._nextToken;
/*  915 */       this._nextToken = null;
/*  916 */       this._currToken = t;
/*  917 */       if (t == JsonToken.VALUE_NUMBER_INT) {
/*  918 */         return getIntValue();
/*      */       }
/*  920 */       if (t == JsonToken.START_ARRAY) {
/*  921 */         this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/*  922 */       } else if (t == JsonToken.START_OBJECT) {
/*  923 */         this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */       } 
/*  925 */       return defaultValue;
/*      */     } 
/*  927 */     return (nextToken() == JsonToken.VALUE_NUMBER_INT) ? getIntValue() : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long nextLongValue(long defaultValue) throws IOException {
/*  934 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  935 */       this._nameCopied = false;
/*  936 */       JsonToken t = this._nextToken;
/*  937 */       this._nextToken = null;
/*  938 */       this._currToken = t;
/*  939 */       if (t == JsonToken.VALUE_NUMBER_INT) {
/*  940 */         return getLongValue();
/*      */       }
/*  942 */       if (t == JsonToken.START_ARRAY) {
/*  943 */         this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/*  944 */       } else if (t == JsonToken.START_OBJECT) {
/*  945 */         this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */       } 
/*  947 */       return defaultValue;
/*      */     } 
/*  949 */     return (nextToken() == JsonToken.VALUE_NUMBER_INT) ? getLongValue() : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Boolean nextBooleanValue() throws IOException {
/*  956 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  957 */       this._nameCopied = false;
/*  958 */       JsonToken jsonToken = this._nextToken;
/*  959 */       this._nextToken = null;
/*  960 */       this._currToken = jsonToken;
/*  961 */       if (jsonToken == JsonToken.VALUE_TRUE) {
/*  962 */         return Boolean.TRUE;
/*      */       }
/*  964 */       if (jsonToken == JsonToken.VALUE_FALSE) {
/*  965 */         return Boolean.FALSE;
/*      */       }
/*  967 */       if (jsonToken == JsonToken.START_ARRAY) {
/*  968 */         this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/*  969 */       } else if (jsonToken == JsonToken.START_OBJECT) {
/*  970 */         this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */       } 
/*  972 */       return null;
/*      */     } 
/*      */     
/*  975 */     JsonToken t = nextToken();
/*  976 */     if (t == JsonToken.VALUE_TRUE) {
/*  977 */       return Boolean.TRUE;
/*      */     }
/*  979 */     if (t == JsonToken.VALUE_FALSE) {
/*  980 */       return Boolean.FALSE;
/*      */     }
/*  982 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final JsonToken _parseFloatThatStartsWithPeriod() throws IOException {
/*  995 */     if (!isEnabled(JsonReadFeature.ALLOW_LEADING_DECIMAL_POINT_FOR_NUMBERS.mappedFeature())) {
/*  996 */       return _handleUnexpectedValue(46);
/*      */     }
/*  998 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/*  999 */     return _parseFloat(outBuf, 0, 46, false, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonToken _parsePosNumber(int c) throws IOException {
/*      */     int outPtr;
/* 1019 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1024 */     if (c == 48) {
/* 1025 */       c = _handleLeadingZeroes();
/* 1026 */       if (c <= 57 && c >= 48) {
/* 1027 */         outPtr = 0;
/*      */       } else {
/* 1029 */         outBuf[0] = '0';
/* 1030 */         outPtr = 1;
/*      */       } 
/*      */     } else {
/* 1033 */       outBuf[0] = (char)c;
/* 1034 */       c = this._inputData.readUnsignedByte();
/* 1035 */       outPtr = 1;
/*      */     } 
/* 1037 */     int intLen = outPtr;
/*      */ 
/*      */     
/* 1040 */     while (c <= 57 && c >= 48) {
/* 1041 */       intLen++;
/* 1042 */       if (outPtr >= outBuf.length) {
/* 1043 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 1044 */         outPtr = 0;
/*      */       } 
/* 1046 */       outBuf[outPtr++] = (char)c;
/* 1047 */       c = this._inputData.readUnsignedByte();
/*      */     } 
/* 1049 */     if (c == 46 || c == 101 || c == 69) {
/* 1050 */       return _parseFloat(outBuf, outPtr, c, false, intLen);
/*      */     }
/* 1052 */     this._textBuffer.setCurrentLength(outPtr);
/*      */     
/* 1054 */     if (this._parsingContext.inRoot()) {
/* 1055 */       _verifyRootSpace();
/*      */     } else {
/* 1057 */       this._nextByte = c;
/*      */     } 
/*      */     
/* 1060 */     return resetInt(false, intLen);
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _parseNegNumber() throws IOException {
/* 1065 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 1066 */     int outPtr = 0;
/*      */ 
/*      */     
/* 1069 */     outBuf[outPtr++] = '-';
/* 1070 */     int c = this._inputData.readUnsignedByte();
/* 1071 */     outBuf[outPtr++] = (char)c;
/*      */     
/* 1073 */     if (c <= 48) {
/*      */       
/* 1075 */       if (c == 48) {
/* 1076 */         c = _handleLeadingZeroes();
/*      */       } else {
/* 1078 */         return _handleInvalidNumberStart(c, true);
/*      */       } 
/*      */     } else {
/* 1081 */       if (c > 57) {
/* 1082 */         return _handleInvalidNumberStart(c, true);
/*      */       }
/* 1084 */       c = this._inputData.readUnsignedByte();
/*      */     } 
/*      */     
/* 1087 */     int intLen = 1;
/*      */ 
/*      */     
/* 1090 */     while (c <= 57 && c >= 48) {
/* 1091 */       intLen++;
/* 1092 */       outBuf[outPtr++] = (char)c;
/* 1093 */       c = this._inputData.readUnsignedByte();
/*      */     } 
/* 1095 */     if (c == 46 || c == 101 || c == 69) {
/* 1096 */       return _parseFloat(outBuf, outPtr, c, true, intLen);
/*      */     }
/* 1098 */     this._textBuffer.setCurrentLength(outPtr);
/*      */     
/* 1100 */     this._nextByte = c;
/* 1101 */     if (this._parsingContext.inRoot()) {
/* 1102 */       _verifyRootSpace();
/*      */     }
/*      */     
/* 1105 */     return resetInt(true, intLen);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _handleLeadingZeroes() throws IOException {
/* 1117 */     int ch = this._inputData.readUnsignedByte();
/*      */     
/* 1119 */     if (ch < 48 || ch > 57) {
/* 1120 */       return ch;
/*      */     }
/*      */     
/* 1123 */     if ((this._features & FEAT_MASK_LEADING_ZEROS) == 0) {
/* 1124 */       reportInvalidNumber("Leading zeroes not allowed");
/*      */     }
/*      */     
/* 1127 */     while (ch == 48) {
/* 1128 */       ch = this._inputData.readUnsignedByte();
/*      */     }
/* 1130 */     return ch;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final JsonToken _parseFloat(char[] outBuf, int outPtr, int c, boolean negative, int integerPartLength) throws IOException {
/* 1136 */     int fractLen = 0;
/*      */ 
/*      */     
/* 1139 */     if (c == 46) {
/* 1140 */       outBuf[outPtr++] = (char)c;
/*      */ 
/*      */       
/*      */       while (true) {
/* 1144 */         c = this._inputData.readUnsignedByte();
/* 1145 */         if (c < 48 || c > 57) {
/*      */           break;
/*      */         }
/* 1148 */         fractLen++;
/* 1149 */         if (outPtr >= outBuf.length) {
/* 1150 */           outBuf = this._textBuffer.finishCurrentSegment();
/* 1151 */           outPtr = 0;
/*      */         } 
/* 1153 */         outBuf[outPtr++] = (char)c;
/*      */       } 
/*      */       
/* 1156 */       if (fractLen == 0) {
/* 1157 */         reportUnexpectedNumberChar(c, "Decimal point not followed by a digit");
/*      */       }
/*      */     } 
/*      */     
/* 1161 */     int expLen = 0;
/* 1162 */     if (c == 101 || c == 69) {
/* 1163 */       if (outPtr >= outBuf.length) {
/* 1164 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 1165 */         outPtr = 0;
/*      */       } 
/* 1167 */       outBuf[outPtr++] = (char)c;
/* 1168 */       c = this._inputData.readUnsignedByte();
/*      */       
/* 1170 */       if (c == 45 || c == 43) {
/* 1171 */         if (outPtr >= outBuf.length) {
/* 1172 */           outBuf = this._textBuffer.finishCurrentSegment();
/* 1173 */           outPtr = 0;
/*      */         } 
/* 1175 */         outBuf[outPtr++] = (char)c;
/* 1176 */         c = this._inputData.readUnsignedByte();
/*      */       } 
/* 1178 */       while (c <= 57 && c >= 48) {
/* 1179 */         expLen++;
/* 1180 */         if (outPtr >= outBuf.length) {
/* 1181 */           outBuf = this._textBuffer.finishCurrentSegment();
/* 1182 */           outPtr = 0;
/*      */         } 
/* 1184 */         outBuf[outPtr++] = (char)c;
/* 1185 */         c = this._inputData.readUnsignedByte();
/*      */       } 
/*      */       
/* 1188 */       if (expLen == 0) {
/* 1189 */         reportUnexpectedNumberChar(c, "Exponent indicator not followed by a digit");
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1195 */     this._nextByte = c;
/* 1196 */     if (this._parsingContext.inRoot()) {
/* 1197 */       _verifyRootSpace();
/*      */     }
/* 1199 */     this._textBuffer.setCurrentLength(outPtr);
/*      */ 
/*      */     
/* 1202 */     return resetFloat(negative, integerPartLength, fractLen, expLen);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _verifyRootSpace() throws IOException {
/* 1215 */     int ch = this._nextByte;
/* 1216 */     if (ch <= 32) {
/* 1217 */       this._nextByte = -1;
/* 1218 */       if (ch == 13 || ch == 10) {
/* 1219 */         this._currInputRow++;
/*      */       }
/*      */       return;
/*      */     } 
/* 1223 */     _reportMissingRootWS(ch);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final String _parseName(int i) throws IOException {
/* 1234 */     if (i != 34) {
/* 1235 */       return _handleOddName(i);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1243 */     int[] codes = _icLatin1;
/*      */     
/* 1245 */     int q = this._inputData.readUnsignedByte();
/*      */     
/* 1247 */     if (codes[q] == 0) {
/* 1248 */       i = this._inputData.readUnsignedByte();
/* 1249 */       if (codes[i] == 0) {
/* 1250 */         q = q << 8 | i;
/* 1251 */         i = this._inputData.readUnsignedByte();
/* 1252 */         if (codes[i] == 0) {
/* 1253 */           q = q << 8 | i;
/* 1254 */           i = this._inputData.readUnsignedByte();
/* 1255 */           if (codes[i] == 0) {
/* 1256 */             q = q << 8 | i;
/* 1257 */             i = this._inputData.readUnsignedByte();
/* 1258 */             if (codes[i] == 0) {
/* 1259 */               this._quad1 = q;
/* 1260 */               return _parseMediumName(i);
/*      */             } 
/* 1262 */             if (i == 34) {
/* 1263 */               return findName(q, 4);
/*      */             }
/* 1265 */             return parseName(q, i, 4);
/*      */           } 
/* 1267 */           if (i == 34) {
/* 1268 */             return findName(q, 3);
/*      */           }
/* 1270 */           return parseName(q, i, 3);
/*      */         } 
/* 1272 */         if (i == 34) {
/* 1273 */           return findName(q, 2);
/*      */         }
/* 1275 */         return parseName(q, i, 2);
/*      */       } 
/* 1277 */       if (i == 34) {
/* 1278 */         return findName(q, 1);
/*      */       }
/* 1280 */       return parseName(q, i, 1);
/*      */     } 
/* 1282 */     if (q == 34) {
/* 1283 */       return "";
/*      */     }
/* 1285 */     return parseName(0, q, 0);
/*      */   }
/*      */ 
/*      */   
/*      */   private final String _parseMediumName(int q2) throws IOException {
/* 1290 */     int[] codes = _icLatin1;
/*      */ 
/*      */     
/* 1293 */     int i = this._inputData.readUnsignedByte();
/* 1294 */     if (codes[i] != 0) {
/* 1295 */       if (i == 34) {
/* 1296 */         return findName(this._quad1, q2, 1);
/*      */       }
/* 1298 */       return parseName(this._quad1, q2, i, 1);
/*      */     } 
/* 1300 */     q2 = q2 << 8 | i;
/* 1301 */     i = this._inputData.readUnsignedByte();
/* 1302 */     if (codes[i] != 0) {
/* 1303 */       if (i == 34) {
/* 1304 */         return findName(this._quad1, q2, 2);
/*      */       }
/* 1306 */       return parseName(this._quad1, q2, i, 2);
/*      */     } 
/* 1308 */     q2 = q2 << 8 | i;
/* 1309 */     i = this._inputData.readUnsignedByte();
/* 1310 */     if (codes[i] != 0) {
/* 1311 */       if (i == 34) {
/* 1312 */         return findName(this._quad1, q2, 3);
/*      */       }
/* 1314 */       return parseName(this._quad1, q2, i, 3);
/*      */     } 
/* 1316 */     q2 = q2 << 8 | i;
/* 1317 */     i = this._inputData.readUnsignedByte();
/* 1318 */     if (codes[i] != 0) {
/* 1319 */       if (i == 34) {
/* 1320 */         return findName(this._quad1, q2, 4);
/*      */       }
/* 1322 */       return parseName(this._quad1, q2, i, 4);
/*      */     } 
/* 1324 */     return _parseMediumName2(i, q2);
/*      */   }
/*      */ 
/*      */   
/*      */   private final String _parseMediumName2(int q3, int q2) throws IOException {
/* 1329 */     int[] codes = _icLatin1;
/*      */ 
/*      */     
/* 1332 */     int i = this._inputData.readUnsignedByte();
/* 1333 */     if (codes[i] != 0) {
/* 1334 */       if (i == 34) {
/* 1335 */         return findName(this._quad1, q2, q3, 1);
/*      */       }
/* 1337 */       return parseName(this._quad1, q2, q3, i, 1);
/*      */     } 
/* 1339 */     q3 = q3 << 8 | i;
/* 1340 */     i = this._inputData.readUnsignedByte();
/* 1341 */     if (codes[i] != 0) {
/* 1342 */       if (i == 34) {
/* 1343 */         return findName(this._quad1, q2, q3, 2);
/*      */       }
/* 1345 */       return parseName(this._quad1, q2, q3, i, 2);
/*      */     } 
/* 1347 */     q3 = q3 << 8 | i;
/* 1348 */     i = this._inputData.readUnsignedByte();
/* 1349 */     if (codes[i] != 0) {
/* 1350 */       if (i == 34) {
/* 1351 */         return findName(this._quad1, q2, q3, 3);
/*      */       }
/* 1353 */       return parseName(this._quad1, q2, q3, i, 3);
/*      */     } 
/* 1355 */     q3 = q3 << 8 | i;
/* 1356 */     i = this._inputData.readUnsignedByte();
/* 1357 */     if (codes[i] != 0) {
/* 1358 */       if (i == 34) {
/* 1359 */         return findName(this._quad1, q2, q3, 4);
/*      */       }
/* 1361 */       return parseName(this._quad1, q2, q3, i, 4);
/*      */     } 
/* 1363 */     return _parseLongName(i, q2, q3);
/*      */   }
/*      */ 
/*      */   
/*      */   private final String _parseLongName(int q, int q2, int q3) throws IOException {
/* 1368 */     this._quadBuffer[0] = this._quad1;
/* 1369 */     this._quadBuffer[1] = q2;
/* 1370 */     this._quadBuffer[2] = q3;
/*      */ 
/*      */     
/* 1373 */     int[] codes = _icLatin1;
/* 1374 */     int qlen = 3;
/*      */     
/*      */     while (true) {
/* 1377 */       int i = this._inputData.readUnsignedByte();
/* 1378 */       if (codes[i] != 0) {
/* 1379 */         if (i == 34) {
/* 1380 */           return findName(this._quadBuffer, qlen, q, 1);
/*      */         }
/* 1382 */         return parseEscapedName(this._quadBuffer, qlen, q, i, 1);
/*      */       } 
/*      */       
/* 1385 */       q = q << 8 | i;
/* 1386 */       i = this._inputData.readUnsignedByte();
/* 1387 */       if (codes[i] != 0) {
/* 1388 */         if (i == 34) {
/* 1389 */           return findName(this._quadBuffer, qlen, q, 2);
/*      */         }
/* 1391 */         return parseEscapedName(this._quadBuffer, qlen, q, i, 2);
/*      */       } 
/*      */       
/* 1394 */       q = q << 8 | i;
/* 1395 */       i = this._inputData.readUnsignedByte();
/* 1396 */       if (codes[i] != 0) {
/* 1397 */         if (i == 34) {
/* 1398 */           return findName(this._quadBuffer, qlen, q, 3);
/*      */         }
/* 1400 */         return parseEscapedName(this._quadBuffer, qlen, q, i, 3);
/*      */       } 
/*      */       
/* 1403 */       q = q << 8 | i;
/* 1404 */       i = this._inputData.readUnsignedByte();
/* 1405 */       if (codes[i] != 0) {
/* 1406 */         if (i == 34) {
/* 1407 */           return findName(this._quadBuffer, qlen, q, 4);
/*      */         }
/* 1409 */         return parseEscapedName(this._quadBuffer, qlen, q, i, 4);
/*      */       } 
/*      */ 
/*      */       
/* 1413 */       if (qlen >= this._quadBuffer.length) {
/* 1414 */         this._quadBuffer = _growArrayBy(this._quadBuffer, qlen);
/*      */       }
/* 1416 */       this._quadBuffer[qlen++] = q;
/* 1417 */       q = i;
/*      */     } 
/*      */   }
/*      */   
/*      */   private final String parseName(int q1, int ch, int lastQuadBytes) throws IOException {
/* 1422 */     return parseEscapedName(this._quadBuffer, 0, q1, ch, lastQuadBytes);
/*      */   }
/*      */   
/*      */   private final String parseName(int q1, int q2, int ch, int lastQuadBytes) throws IOException {
/* 1426 */     this._quadBuffer[0] = q1;
/* 1427 */     return parseEscapedName(this._quadBuffer, 1, q2, ch, lastQuadBytes);
/*      */   }
/*      */   
/*      */   private final String parseName(int q1, int q2, int q3, int ch, int lastQuadBytes) throws IOException {
/* 1431 */     this._quadBuffer[0] = q1;
/* 1432 */     this._quadBuffer[1] = q2;
/* 1433 */     return parseEscapedName(this._quadBuffer, 2, q3, ch, lastQuadBytes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final String parseEscapedName(int[] quads, int qlen, int currQuad, int ch, int currQuadBytes) throws IOException {
/* 1450 */     int[] codes = _icLatin1;
/*      */     
/*      */     while (true) {
/* 1453 */       if (codes[ch] != 0) {
/* 1454 */         if (ch == 34) {
/*      */           break;
/*      */         }
/*      */         
/* 1458 */         if (ch != 92) {
/*      */           
/* 1460 */           _throwUnquotedSpace(ch, "name");
/*      */         } else {
/*      */           
/* 1463 */           ch = _decodeEscaped();
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1470 */         if (ch > 127) {
/*      */           
/* 1472 */           if (currQuadBytes >= 4) {
/* 1473 */             if (qlen >= quads.length) {
/* 1474 */               this._quadBuffer = quads = _growArrayBy(quads, quads.length);
/*      */             }
/* 1476 */             quads[qlen++] = currQuad;
/* 1477 */             currQuad = 0;
/* 1478 */             currQuadBytes = 0;
/*      */           } 
/* 1480 */           if (ch < 2048) {
/* 1481 */             currQuad = currQuad << 8 | 0xC0 | ch >> 6;
/* 1482 */             currQuadBytes++;
/*      */           } else {
/*      */             
/* 1485 */             currQuad = currQuad << 8 | 0xE0 | ch >> 12;
/* 1486 */             currQuadBytes++;
/*      */             
/* 1488 */             if (currQuadBytes >= 4) {
/* 1489 */               if (qlen >= quads.length) {
/* 1490 */                 this._quadBuffer = quads = _growArrayBy(quads, quads.length);
/*      */               }
/* 1492 */               quads[qlen++] = currQuad;
/* 1493 */               currQuad = 0;
/* 1494 */               currQuadBytes = 0;
/*      */             } 
/* 1496 */             currQuad = currQuad << 8 | 0x80 | ch >> 6 & 0x3F;
/* 1497 */             currQuadBytes++;
/*      */           } 
/*      */           
/* 1500 */           ch = 0x80 | ch & 0x3F;
/*      */         } 
/*      */       } 
/*      */       
/* 1504 */       if (currQuadBytes < 4) {
/* 1505 */         currQuadBytes++;
/* 1506 */         currQuad = currQuad << 8 | ch;
/*      */       } else {
/* 1508 */         if (qlen >= quads.length) {
/* 1509 */           this._quadBuffer = quads = _growArrayBy(quads, quads.length);
/*      */         }
/* 1511 */         quads[qlen++] = currQuad;
/* 1512 */         currQuad = ch;
/* 1513 */         currQuadBytes = 1;
/*      */       } 
/* 1515 */       ch = this._inputData.readUnsignedByte();
/*      */     } 
/*      */     
/* 1518 */     if (currQuadBytes > 0) {
/* 1519 */       if (qlen >= quads.length) {
/* 1520 */         this._quadBuffer = quads = _growArrayBy(quads, quads.length);
/*      */       }
/* 1522 */       quads[qlen++] = pad(currQuad, currQuadBytes);
/*      */     } 
/* 1524 */     String name = this._symbols.findName(quads, qlen);
/* 1525 */     if (name == null) {
/* 1526 */       name = addName(quads, qlen, currQuadBytes);
/*      */     }
/* 1528 */     return name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String _handleOddName(int ch) throws IOException {
/* 1539 */     if (ch == 39 && (this._features & FEAT_MASK_ALLOW_SINGLE_QUOTES) != 0) {
/* 1540 */       return _parseAposName();
/*      */     }
/* 1542 */     if ((this._features & FEAT_MASK_ALLOW_UNQUOTED_NAMES) == 0) {
/* 1543 */       char c = (char)_decodeCharForError(ch);
/* 1544 */       _reportUnexpectedChar(c, "was expecting double-quote to start field name");
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1550 */     int[] codes = CharTypes.getInputCodeUtf8JsNames();
/*      */     
/* 1552 */     if (codes[ch] != 0) {
/* 1553 */       _reportUnexpectedChar(ch, "was expecting either valid name character (for unquoted name) or double-quote (for quoted) to start field name");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1560 */     int[] quads = this._quadBuffer;
/* 1561 */     int qlen = 0;
/* 1562 */     int currQuad = 0;
/* 1563 */     int currQuadBytes = 0;
/*      */ 
/*      */     
/*      */     do {
/* 1567 */       if (currQuadBytes < 4) {
/* 1568 */         currQuadBytes++;
/* 1569 */         currQuad = currQuad << 8 | ch;
/*      */       } else {
/* 1571 */         if (qlen >= quads.length) {
/* 1572 */           this._quadBuffer = quads = _growArrayBy(quads, quads.length);
/*      */         }
/* 1574 */         quads[qlen++] = currQuad;
/* 1575 */         currQuad = ch;
/* 1576 */         currQuadBytes = 1;
/*      */       } 
/* 1578 */       ch = this._inputData.readUnsignedByte();
/* 1579 */     } while (codes[ch] == 0);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1584 */     this._nextByte = ch;
/* 1585 */     if (currQuadBytes > 0) {
/* 1586 */       if (qlen >= quads.length) {
/* 1587 */         this._quadBuffer = quads = _growArrayBy(quads, quads.length);
/*      */       }
/* 1589 */       quads[qlen++] = currQuad;
/*      */     } 
/* 1591 */     String name = this._symbols.findName(quads, qlen);
/* 1592 */     if (name == null) {
/* 1593 */       name = addName(quads, qlen, currQuadBytes);
/*      */     }
/* 1595 */     return name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String _parseAposName() throws IOException {
/* 1606 */     int ch = this._inputData.readUnsignedByte();
/* 1607 */     if (ch == 39) {
/* 1608 */       return "";
/*      */     }
/* 1610 */     int[] quads = this._quadBuffer;
/* 1611 */     int qlen = 0;
/* 1612 */     int currQuad = 0;
/* 1613 */     int currQuadBytes = 0;
/*      */ 
/*      */ 
/*      */     
/* 1617 */     int[] codes = _icLatin1;
/*      */ 
/*      */     
/* 1620 */     while (ch != 39) {
/*      */ 
/*      */ 
/*      */       
/* 1624 */       if (ch != 34 && codes[ch] != 0) {
/* 1625 */         if (ch != 92) {
/*      */ 
/*      */           
/* 1628 */           _throwUnquotedSpace(ch, "name");
/*      */         } else {
/*      */           
/* 1631 */           ch = _decodeEscaped();
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1637 */         if (ch > 127) {
/*      */           
/* 1639 */           if (currQuadBytes >= 4) {
/* 1640 */             if (qlen >= quads.length) {
/* 1641 */               this._quadBuffer = quads = _growArrayBy(quads, quads.length);
/*      */             }
/* 1643 */             quads[qlen++] = currQuad;
/* 1644 */             currQuad = 0;
/* 1645 */             currQuadBytes = 0;
/*      */           } 
/* 1647 */           if (ch < 2048) {
/* 1648 */             currQuad = currQuad << 8 | 0xC0 | ch >> 6;
/* 1649 */             currQuadBytes++;
/*      */           } else {
/*      */             
/* 1652 */             currQuad = currQuad << 8 | 0xE0 | ch >> 12;
/* 1653 */             currQuadBytes++;
/*      */             
/* 1655 */             if (currQuadBytes >= 4) {
/* 1656 */               if (qlen >= quads.length) {
/* 1657 */                 this._quadBuffer = quads = _growArrayBy(quads, quads.length);
/*      */               }
/* 1659 */               quads[qlen++] = currQuad;
/* 1660 */               currQuad = 0;
/* 1661 */               currQuadBytes = 0;
/*      */             } 
/* 1663 */             currQuad = currQuad << 8 | 0x80 | ch >> 6 & 0x3F;
/* 1664 */             currQuadBytes++;
/*      */           } 
/*      */           
/* 1667 */           ch = 0x80 | ch & 0x3F;
/*      */         } 
/*      */       } 
/*      */       
/* 1671 */       if (currQuadBytes < 4) {
/* 1672 */         currQuadBytes++;
/* 1673 */         currQuad = currQuad << 8 | ch;
/*      */       } else {
/* 1675 */         if (qlen >= quads.length) {
/* 1676 */           this._quadBuffer = quads = _growArrayBy(quads, quads.length);
/*      */         }
/* 1678 */         quads[qlen++] = currQuad;
/* 1679 */         currQuad = ch;
/* 1680 */         currQuadBytes = 1;
/*      */       } 
/* 1682 */       ch = this._inputData.readUnsignedByte();
/*      */     } 
/*      */     
/* 1685 */     if (currQuadBytes > 0) {
/* 1686 */       if (qlen >= quads.length) {
/* 1687 */         this._quadBuffer = quads = _growArrayBy(quads, quads.length);
/*      */       }
/* 1689 */       quads[qlen++] = pad(currQuad, currQuadBytes);
/*      */     } 
/* 1691 */     String name = this._symbols.findName(quads, qlen);
/* 1692 */     if (name == null) {
/* 1693 */       name = addName(quads, qlen, currQuadBytes);
/*      */     }
/* 1695 */     return name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final String findName(int q1, int lastQuadBytes) throws JsonParseException {
/* 1706 */     q1 = pad(q1, lastQuadBytes);
/*      */     
/* 1708 */     String name = this._symbols.findName(q1);
/* 1709 */     if (name != null) {
/* 1710 */       return name;
/*      */     }
/*      */     
/* 1713 */     this._quadBuffer[0] = q1;
/* 1714 */     return addName(this._quadBuffer, 1, lastQuadBytes);
/*      */   }
/*      */ 
/*      */   
/*      */   private final String findName(int q1, int q2, int lastQuadBytes) throws JsonParseException {
/* 1719 */     q2 = pad(q2, lastQuadBytes);
/*      */     
/* 1721 */     String name = this._symbols.findName(q1, q2);
/* 1722 */     if (name != null) {
/* 1723 */       return name;
/*      */     }
/*      */     
/* 1726 */     this._quadBuffer[0] = q1;
/* 1727 */     this._quadBuffer[1] = q2;
/* 1728 */     return addName(this._quadBuffer, 2, lastQuadBytes);
/*      */   }
/*      */ 
/*      */   
/*      */   private final String findName(int q1, int q2, int q3, int lastQuadBytes) throws JsonParseException {
/* 1733 */     q3 = pad(q3, lastQuadBytes);
/* 1734 */     String name = this._symbols.findName(q1, q2, q3);
/* 1735 */     if (name != null) {
/* 1736 */       return name;
/*      */     }
/* 1738 */     int[] quads = this._quadBuffer;
/* 1739 */     quads[0] = q1;
/* 1740 */     quads[1] = q2;
/* 1741 */     quads[2] = pad(q3, lastQuadBytes);
/* 1742 */     return addName(quads, 3, lastQuadBytes);
/*      */   }
/*      */ 
/*      */   
/*      */   private final String findName(int[] quads, int qlen, int lastQuad, int lastQuadBytes) throws JsonParseException {
/* 1747 */     if (qlen >= quads.length) {
/* 1748 */       this._quadBuffer = quads = _growArrayBy(quads, quads.length);
/*      */     }
/* 1750 */     quads[qlen++] = pad(lastQuad, lastQuadBytes);
/* 1751 */     String name = this._symbols.findName(quads, qlen);
/* 1752 */     if (name == null) {
/* 1753 */       return addName(quads, qlen, lastQuadBytes);
/*      */     }
/* 1755 */     return name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final String addName(int[] quads, int qlen, int lastQuadBytes) throws JsonParseException {
/* 1771 */     int lastQuad, byteLen = (qlen << 2) - 4 + lastQuadBytes;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1780 */     if (lastQuadBytes < 4) {
/* 1781 */       lastQuad = quads[qlen - 1];
/*      */       
/* 1783 */       quads[qlen - 1] = lastQuad << 4 - lastQuadBytes << 3;
/*      */     } else {
/* 1785 */       lastQuad = 0;
/*      */     } 
/*      */ 
/*      */     
/* 1789 */     char[] cbuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 1790 */     int cix = 0;
/*      */     
/* 1792 */     for (int ix = 0; ix < byteLen; ) {
/* 1793 */       int ch = quads[ix >> 2];
/* 1794 */       int byteIx = ix & 0x3;
/* 1795 */       ch = ch >> 3 - byteIx << 3 & 0xFF;
/* 1796 */       ix++;
/*      */       
/* 1798 */       if (ch > 127) {
/*      */         int needed;
/* 1800 */         if ((ch & 0xE0) == 192) {
/* 1801 */           ch &= 0x1F;
/* 1802 */           needed = 1;
/* 1803 */         } else if ((ch & 0xF0) == 224) {
/* 1804 */           ch &= 0xF;
/* 1805 */           needed = 2;
/* 1806 */         } else if ((ch & 0xF8) == 240) {
/* 1807 */           ch &= 0x7;
/* 1808 */           needed = 3;
/*      */         } else {
/* 1810 */           _reportInvalidInitial(ch);
/* 1811 */           needed = ch = 1;
/*      */         } 
/* 1813 */         if (ix + needed > byteLen) {
/* 1814 */           _reportInvalidEOF(" in field name", JsonToken.FIELD_NAME);
/*      */         }
/*      */ 
/*      */         
/* 1818 */         int ch2 = quads[ix >> 2];
/* 1819 */         byteIx = ix & 0x3;
/* 1820 */         ch2 >>= 3 - byteIx << 3;
/* 1821 */         ix++;
/*      */         
/* 1823 */         if ((ch2 & 0xC0) != 128) {
/* 1824 */           _reportInvalidOther(ch2);
/*      */         }
/* 1826 */         ch = ch << 6 | ch2 & 0x3F;
/* 1827 */         if (needed > 1) {
/* 1828 */           ch2 = quads[ix >> 2];
/* 1829 */           byteIx = ix & 0x3;
/* 1830 */           ch2 >>= 3 - byteIx << 3;
/* 1831 */           ix++;
/*      */           
/* 1833 */           if ((ch2 & 0xC0) != 128) {
/* 1834 */             _reportInvalidOther(ch2);
/*      */           }
/* 1836 */           ch = ch << 6 | ch2 & 0x3F;
/* 1837 */           if (needed > 2) {
/* 1838 */             ch2 = quads[ix >> 2];
/* 1839 */             byteIx = ix & 0x3;
/* 1840 */             ch2 >>= 3 - byteIx << 3;
/* 1841 */             ix++;
/* 1842 */             if ((ch2 & 0xC0) != 128) {
/* 1843 */               _reportInvalidOther(ch2 & 0xFF);
/*      */             }
/* 1845 */             ch = ch << 6 | ch2 & 0x3F;
/*      */           } 
/*      */         } 
/* 1848 */         if (needed > 2) {
/* 1849 */           ch -= 65536;
/* 1850 */           if (cix >= cbuf.length) {
/* 1851 */             cbuf = this._textBuffer.expandCurrentSegment();
/*      */           }
/* 1853 */           cbuf[cix++] = (char)(55296 + (ch >> 10));
/* 1854 */           ch = 0xDC00 | ch & 0x3FF;
/*      */         } 
/*      */       } 
/* 1857 */       if (cix >= cbuf.length) {
/* 1858 */         cbuf = this._textBuffer.expandCurrentSegment();
/*      */       }
/* 1860 */       cbuf[cix++] = (char)ch;
/*      */     } 
/*      */ 
/*      */     
/* 1864 */     String baseName = new String(cbuf, 0, cix);
/*      */     
/* 1866 */     if (lastQuadBytes < 4) {
/* 1867 */       quads[qlen - 1] = lastQuad;
/*      */     }
/* 1869 */     return this._symbols.addName(baseName, quads, qlen);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _finishString() throws IOException {
/* 1881 */     int outPtr = 0;
/* 1882 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 1883 */     int[] codes = _icUTF8;
/* 1884 */     int outEnd = outBuf.length;
/*      */     
/*      */     while (true) {
/* 1887 */       int c = this._inputData.readUnsignedByte();
/* 1888 */       if (codes[c] != 0) {
/* 1889 */         if (c == 34) {
/* 1890 */           this._textBuffer.setCurrentLength(outPtr);
/*      */           return;
/*      */         } 
/* 1893 */         _finishString2(outBuf, outPtr, c);
/*      */         return;
/*      */       } 
/* 1896 */       outBuf[outPtr++] = (char)c;
/* 1897 */       if (outPtr >= outEnd) {
/* 1898 */         _finishString2(outBuf, outPtr, this._inputData.readUnsignedByte());
/*      */         return;
/*      */       } 
/*      */     } 
/*      */   } private String _finishAndReturnString() throws IOException {
/* 1903 */     int outPtr = 0;
/* 1904 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 1905 */     int[] codes = _icUTF8;
/* 1906 */     int outEnd = outBuf.length;
/*      */     
/*      */     while (true) {
/* 1909 */       int c = this._inputData.readUnsignedByte();
/* 1910 */       if (codes[c] != 0) {
/* 1911 */         if (c == 34) {
/* 1912 */           return this._textBuffer.setCurrentAndReturn(outPtr);
/*      */         }
/* 1914 */         _finishString2(outBuf, outPtr, c);
/* 1915 */         return this._textBuffer.contentsAsString();
/*      */       } 
/* 1917 */       outBuf[outPtr++] = (char)c;
/* 1918 */       if (outPtr >= outEnd) {
/* 1919 */         _finishString2(outBuf, outPtr, this._inputData.readUnsignedByte());
/* 1920 */         return this._textBuffer.contentsAsString();
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private final void _finishString2(char[] outBuf, int outPtr, int c) throws IOException {
/* 1927 */     int[] codes = _icUTF8;
/* 1928 */     int outEnd = outBuf.length;
/*      */ 
/*      */     
/* 1931 */     for (;; c = this._inputData.readUnsignedByte()) {
/*      */       
/* 1933 */       while (codes[c] == 0) {
/* 1934 */         if (outPtr >= outEnd) {
/* 1935 */           outBuf = this._textBuffer.finishCurrentSegment();
/* 1936 */           outPtr = 0;
/* 1937 */           outEnd = outBuf.length;
/*      */         } 
/* 1939 */         outBuf[outPtr++] = (char)c;
/* 1940 */         c = this._inputData.readUnsignedByte();
/*      */       } 
/*      */       
/* 1943 */       if (c == 34) {
/*      */         break;
/*      */       }
/* 1946 */       switch (codes[c]) {
/*      */         case 1:
/* 1948 */           c = _decodeEscaped();
/*      */           break;
/*      */         case 2:
/* 1951 */           c = _decodeUtf8_2(c);
/*      */           break;
/*      */         case 3:
/* 1954 */           c = _decodeUtf8_3(c);
/*      */           break;
/*      */         case 4:
/* 1957 */           c = _decodeUtf8_4(c);
/*      */           
/* 1959 */           if (outPtr >= outBuf.length) {
/* 1960 */             outBuf = this._textBuffer.finishCurrentSegment();
/* 1961 */             outPtr = 0;
/* 1962 */             outEnd = outBuf.length;
/*      */           } 
/* 1964 */           outBuf[outPtr++] = (char)(0xD800 | c >> 10);
/* 1965 */           c = 0xDC00 | c & 0x3FF;
/*      */           break;
/*      */         
/*      */         default:
/* 1969 */           if (c < 32) {
/* 1970 */             _throwUnquotedSpace(c, "string value");
/*      */             break;
/*      */           } 
/* 1973 */           _reportInvalidChar(c);
/*      */           break;
/*      */       } 
/*      */       
/* 1977 */       if (outPtr >= outBuf.length) {
/* 1978 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 1979 */         outPtr = 0;
/* 1980 */         outEnd = outBuf.length;
/*      */       } 
/*      */       
/* 1983 */       outBuf[outPtr++] = (char)c;
/*      */     } 
/* 1985 */     this._textBuffer.setCurrentLength(outPtr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _skipString() throws IOException {
/* 1995 */     this._tokenIncomplete = false;
/*      */ 
/*      */     
/* 1998 */     int[] codes = _icUTF8;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/* 2006 */       int c = this._inputData.readUnsignedByte();
/* 2007 */       if (codes[c] != 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2012 */         if (c == 34) {
/*      */           break;
/*      */         }
/*      */         
/* 2016 */         switch (codes[c]) {
/*      */           case 1:
/* 2018 */             _decodeEscaped();
/*      */             continue;
/*      */           case 2:
/* 2021 */             _skipUtf8_2();
/*      */             continue;
/*      */           case 3:
/* 2024 */             _skipUtf8_3();
/*      */             continue;
/*      */           case 4:
/* 2027 */             _skipUtf8_4();
/*      */             continue;
/*      */         } 
/* 2030 */         if (c < 32) {
/* 2031 */           _throwUnquotedSpace(c, "string value");
/*      */           continue;
/*      */         } 
/* 2034 */         _reportInvalidChar(c);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonToken _handleUnexpectedValue(int c) throws IOException {
/* 2048 */     switch (c) {
/*      */       case 93:
/* 2050 */         if (!this._parsingContext.inArray()) {
/*      */           break;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 44:
/* 2059 */         if (!this._parsingContext.inRoot() && (
/* 2060 */           this._features & FEAT_MASK_ALLOW_MISSING) != 0) {
/*      */           
/* 2062 */           this._nextByte = c;
/* 2063 */           return JsonToken.VALUE_NULL;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 125:
/* 2070 */         _reportUnexpectedChar(c, "expected a value");
/*      */       case 39:
/* 2072 */         if ((this._features & FEAT_MASK_ALLOW_SINGLE_QUOTES) != 0) {
/* 2073 */           return _handleApos();
/*      */         }
/*      */         break;
/*      */       case 78:
/* 2077 */         _matchToken("NaN", 1);
/* 2078 */         if ((this._features & FEAT_MASK_NON_NUM_NUMBERS) != 0) {
/* 2079 */           return resetAsNaN("NaN", Double.NaN);
/*      */         }
/* 2081 */         _reportError("Non-standard token 'NaN': enable JsonParser.Feature.ALLOW_NON_NUMERIC_NUMBERS to allow");
/*      */         break;
/*      */       case 73:
/* 2084 */         _matchToken("Infinity", 1);
/* 2085 */         if ((this._features & FEAT_MASK_NON_NUM_NUMBERS) != 0) {
/* 2086 */           return resetAsNaN("Infinity", Double.POSITIVE_INFINITY);
/*      */         }
/* 2088 */         _reportError("Non-standard token 'Infinity': enable JsonParser.Feature.ALLOW_NON_NUMERIC_NUMBERS to allow");
/*      */         break;
/*      */       case 43:
/* 2091 */         return _handleInvalidNumberStart(this._inputData.readUnsignedByte(), false);
/*      */     } 
/*      */     
/* 2094 */     if (Character.isJavaIdentifierStart(c)) {
/* 2095 */       _reportInvalidToken(c, "" + (char)c, _validJsonTokenList());
/*      */     }
/*      */     
/* 2098 */     _reportUnexpectedChar(c, "expected a valid value " + _validJsonValueList());
/* 2099 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _handleApos() throws IOException {
/* 2104 */     int c = 0;
/*      */     
/* 2106 */     int outPtr = 0;
/* 2107 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/*      */ 
/*      */     
/* 2110 */     int[] codes = _icUTF8;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     label35: while (true) {
/* 2117 */       int outEnd = outBuf.length;
/* 2118 */       if (outPtr >= outBuf.length) {
/* 2119 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 2120 */         outPtr = 0;
/* 2121 */         outEnd = outBuf.length;
/*      */       } 
/*      */       while (true)
/* 2124 */       { c = this._inputData.readUnsignedByte();
/* 2125 */         if (c == 39) {
/*      */           break;
/*      */         }
/* 2128 */         if (codes[c] != 0)
/*      */         
/*      */         { 
/*      */ 
/*      */ 
/*      */           
/* 2134 */           switch (codes[c]) {
/*      */             case 1:
/* 2136 */               c = _decodeEscaped();
/*      */               break;
/*      */             case 2:
/* 2139 */               c = _decodeUtf8_2(c);
/*      */               break;
/*      */             case 3:
/* 2142 */               c = _decodeUtf8_3(c);
/*      */               break;
/*      */             case 4:
/* 2145 */               c = _decodeUtf8_4(c);
/*      */               
/* 2147 */               outBuf[outPtr++] = (char)(0xD800 | c >> 10);
/* 2148 */               if (outPtr >= outBuf.length) {
/* 2149 */                 outBuf = this._textBuffer.finishCurrentSegment();
/* 2150 */                 outPtr = 0;
/*      */               } 
/* 2152 */               c = 0xDC00 | c & 0x3FF;
/*      */               break;
/*      */             
/*      */             default:
/* 2156 */               if (c < 32) {
/* 2157 */                 _throwUnquotedSpace(c, "string value");
/*      */               }
/*      */               
/* 2160 */               _reportInvalidChar(c);
/*      */               break;
/*      */           } 
/* 2163 */           if (outPtr >= outBuf.length) {
/* 2164 */             outBuf = this._textBuffer.finishCurrentSegment();
/* 2165 */             outPtr = 0;
/*      */           } 
/*      */           
/* 2168 */           outBuf[outPtr++] = (char)c; continue; }  outBuf[outPtr++] = (char)c; if (outPtr >= outEnd)
/*      */           continue label35;  }  break;
/* 2170 */     }  this._textBuffer.setCurrentLength(outPtr);
/*      */     
/* 2172 */     return JsonToken.VALUE_STRING;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonToken _handleInvalidNumberStart(int ch, boolean neg) throws IOException {
/* 2182 */     while (ch == 73) {
/* 2183 */       String match; ch = this._inputData.readUnsignedByte();
/*      */       
/* 2185 */       if (ch == 78) {
/* 2186 */         match = neg ? "-INF" : "+INF";
/* 2187 */       } else if (ch == 110) {
/* 2188 */         match = neg ? "-Infinity" : "+Infinity";
/*      */       } else {
/*      */         break;
/*      */       } 
/* 2192 */       _matchToken(match, 3);
/* 2193 */       if ((this._features & FEAT_MASK_NON_NUM_NUMBERS) != 0) {
/* 2194 */         return resetAsNaN(match, neg ? Double.NEGATIVE_INFINITY : Double.POSITIVE_INFINITY);
/*      */       }
/* 2196 */       _reportError("Non-standard token '" + match + "': enable JsonParser.Feature.ALLOW_NON_NUMERIC_NUMBERS to allow");
/*      */     } 
/* 2198 */     reportUnexpectedNumberChar(ch, "expected digit (0-9) to follow minus sign, for valid numeric value");
/* 2199 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   protected final void _matchToken(String matchStr, int i) throws IOException {
/* 2204 */     int len = matchStr.length();
/*      */     do {
/* 2206 */       int j = this._inputData.readUnsignedByte();
/* 2207 */       if (j == matchStr.charAt(i))
/* 2208 */         continue;  _reportInvalidToken(j, matchStr.substring(0, i));
/*      */     }
/* 2210 */     while (++i < len);
/*      */     
/* 2212 */     int ch = this._inputData.readUnsignedByte();
/* 2213 */     if (ch >= 48 && ch != 93 && ch != 125) {
/* 2214 */       _checkMatchEnd(matchStr, i, ch);
/*      */     }
/* 2216 */     this._nextByte = ch;
/*      */   }
/*      */ 
/*      */   
/*      */   private final void _checkMatchEnd(String matchStr, int i, int ch) throws IOException {
/* 2221 */     char c = (char)_decodeCharForError(ch);
/* 2222 */     if (Character.isJavaIdentifierPart(c)) {
/* 2223 */       _reportInvalidToken(c, matchStr.substring(0, i));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _skipWS() throws IOException {
/* 2235 */     int i = this._nextByte;
/* 2236 */     if (i < 0) {
/* 2237 */       i = this._inputData.readUnsignedByte();
/*      */     } else {
/* 2239 */       this._nextByte = -1;
/*      */     } 
/*      */     while (true) {
/* 2242 */       if (i > 32) {
/* 2243 */         if (i == 47 || i == 35) {
/* 2244 */           return _skipWSComment(i);
/*      */         }
/* 2246 */         return i;
/*      */       } 
/*      */ 
/*      */       
/* 2250 */       if (i == 13 || i == 10) {
/* 2251 */         this._currInputRow++;
/*      */       }
/*      */       
/* 2254 */       i = this._inputData.readUnsignedByte();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _skipWSOrEnd() throws IOException {
/* 2266 */     int i = this._nextByte;
/* 2267 */     if (i < 0) {
/*      */       try {
/* 2269 */         i = this._inputData.readUnsignedByte();
/* 2270 */       } catch (EOFException e) {
/* 2271 */         return _eofAsNextChar();
/*      */       } 
/*      */     } else {
/* 2274 */       this._nextByte = -1;
/*      */     } 
/*      */     while (true) {
/* 2277 */       if (i > 32) {
/* 2278 */         if (i == 47 || i == 35) {
/* 2279 */           return _skipWSComment(i);
/*      */         }
/* 2281 */         return i;
/*      */       } 
/*      */ 
/*      */       
/* 2285 */       if (i == 13 || i == 10) {
/* 2286 */         this._currInputRow++;
/*      */       }
/*      */       
/*      */       try {
/* 2290 */         i = this._inputData.readUnsignedByte();
/* 2291 */       } catch (EOFException e) {
/* 2292 */         return _eofAsNextChar();
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private final int _skipWSComment(int i) throws IOException {
/*      */     while (true) {
/* 2300 */       if (i > 32) {
/* 2301 */         if (i == 47) {
/* 2302 */           _skipComment();
/* 2303 */         } else if (i == 35) {
/* 2304 */           if (!_skipYAMLComment()) {
/* 2305 */             return i;
/*      */           }
/*      */         } else {
/* 2308 */           return i;
/*      */         
/*      */         }
/*      */       
/*      */       }
/* 2313 */       else if (i == 13 || i == 10) {
/* 2314 */         this._currInputRow++;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2322 */       i = this._inputData.readUnsignedByte();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private final int _skipColon() throws IOException {
/* 2328 */     int i = this._nextByte;
/* 2329 */     if (i < 0) {
/* 2330 */       i = this._inputData.readUnsignedByte();
/*      */     } else {
/* 2332 */       this._nextByte = -1;
/*      */     } 
/*      */     
/* 2335 */     if (i == 58) {
/* 2336 */       i = this._inputData.readUnsignedByte();
/* 2337 */       if (i > 32) {
/* 2338 */         if (i == 47 || i == 35) {
/* 2339 */           return _skipColon2(i, true);
/*      */         }
/* 2341 */         return i;
/*      */       } 
/* 2343 */       if (i == 32 || i == 9) {
/* 2344 */         i = this._inputData.readUnsignedByte();
/* 2345 */         if (i > 32) {
/* 2346 */           if (i == 47 || i == 35) {
/* 2347 */             return _skipColon2(i, true);
/*      */           }
/* 2349 */           return i;
/*      */         } 
/*      */       } 
/* 2352 */       return _skipColon2(i, true);
/*      */     } 
/* 2354 */     if (i == 32 || i == 9) {
/* 2355 */       i = this._inputData.readUnsignedByte();
/*      */     }
/* 2357 */     if (i == 58) {
/* 2358 */       i = this._inputData.readUnsignedByte();
/* 2359 */       if (i > 32) {
/* 2360 */         if (i == 47 || i == 35) {
/* 2361 */           return _skipColon2(i, true);
/*      */         }
/* 2363 */         return i;
/*      */       } 
/* 2365 */       if (i == 32 || i == 9) {
/* 2366 */         i = this._inputData.readUnsignedByte();
/* 2367 */         if (i > 32) {
/* 2368 */           if (i == 47 || i == 35) {
/* 2369 */             return _skipColon2(i, true);
/*      */           }
/* 2371 */           return i;
/*      */         } 
/*      */       } 
/* 2374 */       return _skipColon2(i, true);
/*      */     } 
/* 2376 */     return _skipColon2(i, false);
/*      */   }
/*      */ 
/*      */   
/*      */   private final int _skipColon2(int i, boolean gotColon) throws IOException {
/* 2381 */     for (;; i = this._inputData.readUnsignedByte()) {
/* 2382 */       if (i > 32) {
/* 2383 */         if (i == 47) {
/* 2384 */           _skipComment();
/*      */         
/*      */         }
/* 2387 */         else if (i != 35 || 
/* 2388 */           !_skipYAMLComment()) {
/*      */ 
/*      */ 
/*      */           
/* 2392 */           if (gotColon) {
/* 2393 */             return i;
/*      */           }
/* 2395 */           if (i != 58) {
/* 2396 */             _reportUnexpectedChar(i, "was expecting a colon to separate field name and value");
/*      */           }
/* 2398 */           gotColon = true;
/*      */         }
/*      */       
/*      */       }
/* 2402 */       else if (i == 13 || i == 10) {
/* 2403 */         this._currInputRow++;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _skipComment() throws IOException {
/* 2411 */     if ((this._features & FEAT_MASK_ALLOW_JAVA_COMMENTS) == 0) {
/* 2412 */       _reportUnexpectedChar(47, "maybe a (non-standard) comment? (not recognized as one since Feature 'ALLOW_COMMENTS' not enabled for parser)");
/*      */     }
/* 2414 */     int c = this._inputData.readUnsignedByte();
/* 2415 */     if (c == 47) {
/* 2416 */       _skipLine();
/* 2417 */     } else if (c == 42) {
/* 2418 */       _skipCComment();
/*      */     } else {
/* 2420 */       _reportUnexpectedChar(c, "was expecting either '*' or '/' for a comment");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _skipCComment() throws IOException {
/* 2427 */     int[] codes = CharTypes.getInputCodeComment();
/* 2428 */     int i = this._inputData.readUnsignedByte();
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/* 2433 */       int code = codes[i];
/* 2434 */       if (code != 0)
/* 2435 */         switch (code) {
/*      */           case 42:
/* 2437 */             i = this._inputData.readUnsignedByte();
/* 2438 */             if (i == 47) {
/*      */               return;
/*      */             }
/*      */             continue;
/*      */           case 10:
/*      */           case 13:
/* 2444 */             this._currInputRow++;
/*      */             break;
/*      */           case 2:
/* 2447 */             _skipUtf8_2();
/*      */             break;
/*      */           case 3:
/* 2450 */             _skipUtf8_3();
/*      */             break;
/*      */           case 4:
/* 2453 */             _skipUtf8_4();
/*      */             break;
/*      */           
/*      */           default:
/* 2457 */             _reportInvalidChar(i);
/*      */             break;
/*      */         }  
/* 2460 */       i = this._inputData.readUnsignedByte();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private final boolean _skipYAMLComment() throws IOException {
/* 2466 */     if ((this._features & FEAT_MASK_ALLOW_YAML_COMMENTS) == 0) {
/* 2467 */       return false;
/*      */     }
/* 2469 */     _skipLine();
/* 2470 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _skipLine() throws IOException {
/* 2480 */     int[] codes = CharTypes.getInputCodeComment();
/*      */     while (true) {
/* 2482 */       int i = this._inputData.readUnsignedByte();
/* 2483 */       int code = codes[i];
/* 2484 */       if (code != 0) {
/* 2485 */         switch (code) {
/*      */           case 10:
/*      */           case 13:
/* 2488 */             this._currInputRow++;
/*      */             return;
/*      */           case 42:
/*      */             continue;
/*      */           case 2:
/* 2493 */             _skipUtf8_2();
/*      */             continue;
/*      */           case 3:
/* 2496 */             _skipUtf8_3();
/*      */             continue;
/*      */           case 4:
/* 2499 */             _skipUtf8_4();
/*      */             continue;
/*      */         } 
/* 2502 */         if (code < 0)
/*      */         {
/* 2504 */           _reportInvalidChar(i);
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected char _decodeEscaped() throws IOException {
/* 2514 */     int c = this._inputData.readUnsignedByte();
/*      */     
/* 2516 */     switch (c) {
/*      */       
/*      */       case 98:
/* 2519 */         return '\b';
/*      */       case 116:
/* 2521 */         return '\t';
/*      */       case 110:
/* 2523 */         return '\n';
/*      */       case 102:
/* 2525 */         return '\f';
/*      */       case 114:
/* 2527 */         return '\r';
/*      */ 
/*      */       
/*      */       case 34:
/*      */       case 47:
/*      */       case 92:
/* 2533 */         return (char)c;
/*      */       
/*      */       case 117:
/*      */         break;
/*      */       
/*      */       default:
/* 2539 */         return _handleUnrecognizedCharacterEscape((char)_decodeCharForError(c));
/*      */     } 
/*      */ 
/*      */     
/* 2543 */     int value = 0;
/* 2544 */     for (int i = 0; i < 4; i++) {
/* 2545 */       int ch = this._inputData.readUnsignedByte();
/* 2546 */       int digit = CharTypes.charToHex(ch);
/* 2547 */       if (digit < 0) {
/* 2548 */         _reportUnexpectedChar(ch, "expected a hex-digit for character escape sequence");
/*      */       }
/* 2550 */       value = value << 4 | digit;
/*      */     } 
/* 2552 */     return (char)value;
/*      */   }
/*      */ 
/*      */   
/*      */   protected int _decodeCharForError(int firstByte) throws IOException {
/* 2557 */     int c = firstByte & 0xFF;
/* 2558 */     if (c > 127) {
/*      */       int needed;
/*      */ 
/*      */       
/* 2562 */       if ((c & 0xE0) == 192) {
/* 2563 */         c &= 0x1F;
/* 2564 */         needed = 1;
/* 2565 */       } else if ((c & 0xF0) == 224) {
/* 2566 */         c &= 0xF;
/* 2567 */         needed = 2;
/* 2568 */       } else if ((c & 0xF8) == 240) {
/*      */         
/* 2570 */         c &= 0x7;
/* 2571 */         needed = 3;
/*      */       } else {
/* 2573 */         _reportInvalidInitial(c & 0xFF);
/* 2574 */         needed = 1;
/*      */       } 
/*      */       
/* 2577 */       int d = this._inputData.readUnsignedByte();
/* 2578 */       if ((d & 0xC0) != 128) {
/* 2579 */         _reportInvalidOther(d & 0xFF);
/*      */       }
/* 2581 */       c = c << 6 | d & 0x3F;
/*      */       
/* 2583 */       if (needed > 1) {
/* 2584 */         d = this._inputData.readUnsignedByte();
/* 2585 */         if ((d & 0xC0) != 128) {
/* 2586 */           _reportInvalidOther(d & 0xFF);
/*      */         }
/* 2588 */         c = c << 6 | d & 0x3F;
/* 2589 */         if (needed > 2) {
/* 2590 */           d = this._inputData.readUnsignedByte();
/* 2591 */           if ((d & 0xC0) != 128) {
/* 2592 */             _reportInvalidOther(d & 0xFF);
/*      */           }
/* 2594 */           c = c << 6 | d & 0x3F;
/*      */         } 
/*      */       } 
/*      */     } 
/* 2598 */     return c;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _decodeUtf8_2(int c) throws IOException {
/* 2609 */     int d = this._inputData.readUnsignedByte();
/* 2610 */     if ((d & 0xC0) != 128) {
/* 2611 */       _reportInvalidOther(d & 0xFF);
/*      */     }
/* 2613 */     return (c & 0x1F) << 6 | d & 0x3F;
/*      */   }
/*      */ 
/*      */   
/*      */   private final int _decodeUtf8_3(int c1) throws IOException {
/* 2618 */     c1 &= 0xF;
/* 2619 */     int d = this._inputData.readUnsignedByte();
/* 2620 */     if ((d & 0xC0) != 128) {
/* 2621 */       _reportInvalidOther(d & 0xFF);
/*      */     }
/* 2623 */     int c = c1 << 6 | d & 0x3F;
/* 2624 */     d = this._inputData.readUnsignedByte();
/* 2625 */     if ((d & 0xC0) != 128) {
/* 2626 */       _reportInvalidOther(d & 0xFF);
/*      */     }
/* 2628 */     c = c << 6 | d & 0x3F;
/* 2629 */     return c;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _decodeUtf8_4(int c) throws IOException {
/* 2638 */     int d = this._inputData.readUnsignedByte();
/* 2639 */     if ((d & 0xC0) != 128) {
/* 2640 */       _reportInvalidOther(d & 0xFF);
/*      */     }
/* 2642 */     c = (c & 0x7) << 6 | d & 0x3F;
/* 2643 */     d = this._inputData.readUnsignedByte();
/* 2644 */     if ((d & 0xC0) != 128) {
/* 2645 */       _reportInvalidOther(d & 0xFF);
/*      */     }
/* 2647 */     c = c << 6 | d & 0x3F;
/* 2648 */     d = this._inputData.readUnsignedByte();
/* 2649 */     if ((d & 0xC0) != 128) {
/* 2650 */       _reportInvalidOther(d & 0xFF);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2656 */     return (c << 6 | d & 0x3F) - 65536;
/*      */   }
/*      */ 
/*      */   
/*      */   private final void _skipUtf8_2() throws IOException {
/* 2661 */     int c = this._inputData.readUnsignedByte();
/* 2662 */     if ((c & 0xC0) != 128) {
/* 2663 */       _reportInvalidOther(c & 0xFF);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _skipUtf8_3() throws IOException {
/* 2673 */     int c = this._inputData.readUnsignedByte();
/* 2674 */     if ((c & 0xC0) != 128) {
/* 2675 */       _reportInvalidOther(c & 0xFF);
/*      */     }
/* 2677 */     c = this._inputData.readUnsignedByte();
/* 2678 */     if ((c & 0xC0) != 128) {
/* 2679 */       _reportInvalidOther(c & 0xFF);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private final void _skipUtf8_4() throws IOException {
/* 2685 */     int d = this._inputData.readUnsignedByte();
/* 2686 */     if ((d & 0xC0) != 128) {
/* 2687 */       _reportInvalidOther(d & 0xFF);
/*      */     }
/* 2689 */     d = this._inputData.readUnsignedByte();
/* 2690 */     if ((d & 0xC0) != 128) {
/* 2691 */       _reportInvalidOther(d & 0xFF);
/*      */     }
/* 2693 */     d = this._inputData.readUnsignedByte();
/* 2694 */     if ((d & 0xC0) != 128) {
/* 2695 */       _reportInvalidOther(d & 0xFF);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _reportInvalidToken(int ch, String matchedPart) throws IOException {
/* 2707 */     _reportInvalidToken(ch, matchedPart, _validJsonTokenList());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _reportInvalidToken(int ch, String matchedPart, String msg) throws IOException {
/* 2713 */     StringBuilder sb = new StringBuilder(matchedPart);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/* 2720 */       char c = (char)_decodeCharForError(ch);
/* 2721 */       if (!Character.isJavaIdentifierPart(c)) {
/*      */         break;
/*      */       }
/* 2724 */       sb.append(c);
/* 2725 */       ch = this._inputData.readUnsignedByte();
/*      */     } 
/* 2727 */     _reportError("Unrecognized token '" + sb.toString() + "': was expecting " + msg);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _reportInvalidChar(int c) throws JsonParseException {
/* 2734 */     if (c < 32) {
/* 2735 */       _throwInvalidSpace(c);
/*      */     }
/* 2737 */     _reportInvalidInitial(c);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _reportInvalidInitial(int mask) throws JsonParseException {
/* 2743 */     _reportError("Invalid UTF-8 start byte 0x" + Integer.toHexString(mask));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void _reportInvalidOther(int mask) throws JsonParseException {
/* 2749 */     _reportError("Invalid UTF-8 middle byte 0x" + Integer.toHexString(mask));
/*      */   }
/*      */ 
/*      */   
/*      */   private static int[] _growArrayBy(int[] arr, int more) {
/* 2754 */     if (arr == null) {
/* 2755 */       return new int[more];
/*      */     }
/* 2757 */     return Arrays.copyOf(arr, arr.length + more);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final byte[] _decodeBase64(Base64Variant b64variant) throws IOException {
/* 2773 */     ByteArrayBuilder builder = _getByteArrayBuilder();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/* 2780 */       int ch = this._inputData.readUnsignedByte();
/* 2781 */       if (ch > 32) {
/* 2782 */         int bits = b64variant.decodeBase64Char(ch);
/* 2783 */         if (bits < 0) {
/* 2784 */           if (ch == 34) {
/* 2785 */             return builder.toByteArray();
/*      */           }
/* 2787 */           bits = _decodeBase64Escape(b64variant, ch, 0);
/* 2788 */           if (bits < 0) {
/*      */             continue;
/*      */           }
/*      */         } 
/* 2792 */         int decodedData = bits;
/*      */ 
/*      */         
/* 2795 */         ch = this._inputData.readUnsignedByte();
/* 2796 */         bits = b64variant.decodeBase64Char(ch);
/* 2797 */         if (bits < 0) {
/* 2798 */           bits = _decodeBase64Escape(b64variant, ch, 1);
/*      */         }
/* 2800 */         decodedData = decodedData << 6 | bits;
/*      */         
/* 2802 */         ch = this._inputData.readUnsignedByte();
/* 2803 */         bits = b64variant.decodeBase64Char(ch);
/*      */ 
/*      */         
/* 2806 */         if (bits < 0) {
/* 2807 */           if (bits != -2) {
/*      */             
/* 2809 */             if (ch == 34) {
/* 2810 */               decodedData >>= 4;
/* 2811 */               builder.append(decodedData);
/* 2812 */               if (b64variant.usesPadding()) {
/* 2813 */                 _handleBase64MissingPadding(b64variant);
/*      */               }
/* 2815 */               return builder.toByteArray();
/*      */             } 
/* 2817 */             bits = _decodeBase64Escape(b64variant, ch, 2);
/*      */           } 
/* 2819 */           if (bits == -2) {
/* 2820 */             ch = this._inputData.readUnsignedByte();
/* 2821 */             if (!b64variant.usesPaddingChar(ch) && (
/* 2822 */               ch != 92 || 
/* 2823 */               _decodeBase64Escape(b64variant, ch, 3) != -2)) {
/* 2824 */               throw reportInvalidBase64Char(b64variant, ch, 3, "expected padding character '" + b64variant.getPaddingChar() + "'");
/*      */             }
/*      */ 
/*      */             
/* 2828 */             decodedData >>= 4;
/* 2829 */             builder.append(decodedData);
/*      */             
/*      */             continue;
/*      */           } 
/*      */         } 
/* 2834 */         decodedData = decodedData << 6 | bits;
/*      */         
/* 2836 */         ch = this._inputData.readUnsignedByte();
/* 2837 */         bits = b64variant.decodeBase64Char(ch);
/* 2838 */         if (bits < 0) {
/* 2839 */           if (bits != -2) {
/*      */             
/* 2841 */             if (ch == 34) {
/* 2842 */               decodedData >>= 2;
/* 2843 */               builder.appendTwoBytes(decodedData);
/* 2844 */               if (b64variant.usesPadding()) {
/* 2845 */                 _handleBase64MissingPadding(b64variant);
/*      */               }
/* 2847 */               return builder.toByteArray();
/*      */             } 
/* 2849 */             bits = _decodeBase64Escape(b64variant, ch, 3);
/*      */           } 
/* 2851 */           if (bits == -2) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 2858 */             decodedData >>= 2;
/* 2859 */             builder.appendTwoBytes(decodedData);
/*      */             
/*      */             continue;
/*      */           } 
/*      */         } 
/* 2864 */         decodedData = decodedData << 6 | bits;
/* 2865 */         builder.appendThreeBytes(decodedData);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonLocation getTokenLocation() {
/* 2887 */     return new JsonLocation(_getSourceReference(), -1L, -1L, this._tokenInputRow, -1);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonLocation getCurrentLocation() {
/* 2893 */     int col = -1;
/* 2894 */     return new JsonLocation(_getSourceReference(), -1L, -1L, this._currInputRow, -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void _closeScope(int i) throws JsonParseException {
/* 2905 */     if (i == 93) {
/* 2906 */       if (!this._parsingContext.inArray()) {
/* 2907 */         _reportMismatchedEndMarker(i, '}');
/*      */       }
/* 2909 */       this._parsingContext = this._parsingContext.clearAndGetParent();
/* 2910 */       this._currToken = JsonToken.END_ARRAY;
/*      */     } 
/* 2912 */     if (i == 125) {
/* 2913 */       if (!this._parsingContext.inObject()) {
/* 2914 */         _reportMismatchedEndMarker(i, ']');
/*      */       }
/* 2916 */       this._parsingContext = this._parsingContext.clearAndGetParent();
/* 2917 */       this._currToken = JsonToken.END_OBJECT;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int pad(int q, int bytes) {
/* 2925 */     return (bytes == 4) ? q : (q | -1 << bytes << 3);
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-core-2.12.4.jar!\com\fasterxml\jackson\core\json\UTF8DataInputJsonParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */