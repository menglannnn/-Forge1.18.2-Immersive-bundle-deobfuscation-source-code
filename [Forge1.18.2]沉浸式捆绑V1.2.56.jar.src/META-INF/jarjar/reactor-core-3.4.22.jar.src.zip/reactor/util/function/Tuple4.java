/*     */ package reactor.util.function;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.function.Function;
/*     */ import reactor.util.annotation.NonNull;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Tuple4<T1, T2, T3, T4>
/*     */   extends Tuple3<T1, T2, T3>
/*     */ {
/*     */   private static final long serialVersionUID = -4898704078143033129L;
/*     */   @NonNull
/*     */   final T4 t4;
/*     */   
/*     */   Tuple4(T1 t1, T2 t2, T3 t3, T4 t4) {
/*  42 */     super(t1, t2, t3);
/*  43 */     this.t4 = Objects.requireNonNull(t4, "t4");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T4 getT4() {
/*  52 */     return this.t4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <R> Tuple4<R, T2, T3, T4> mapT1(Function<T1, R> mapper) {
/*  64 */     return new Tuple4((T1)mapper.apply(this.t1), this.t2, this.t3, this.t4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <R> Tuple4<T1, R, T3, T4> mapT2(Function<T2, R> mapper) {
/*  76 */     return new Tuple4(this.t1, (T2)mapper.apply(this.t2), this.t3, this.t4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <R> Tuple4<T1, T2, R, T4> mapT3(Function<T3, R> mapper) {
/*  88 */     return new Tuple4(this.t1, this.t2, (T3)mapper.apply(this.t3), this.t4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <R> Tuple4<T1, T2, T3, R> mapT4(Function<T4, R> mapper) {
/* 100 */     return new Tuple4(this.t1, this.t2, this.t3, (T4)mapper.apply(this.t4));
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object get(int index) {
/* 106 */     switch (index) {
/*     */       case 0:
/* 108 */         return this.t1;
/*     */       case 1:
/* 110 */         return this.t2;
/*     */       case 2:
/* 112 */         return this.t3;
/*     */       case 3:
/* 114 */         return this.t4;
/*     */     } 
/* 116 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] toArray() {
/* 122 */     return new Object[] { this.t1, this.t2, this.t3, this.t4 };
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object o) {
/* 127 */     if (this == o) return true; 
/* 128 */     if (!(o instanceof Tuple4)) return false; 
/* 129 */     if (!super.equals(o)) return false;
/*     */ 
/*     */     
/* 132 */     Tuple4 tuple4 = (Tuple4)o;
/*     */     
/* 134 */     return this.t4.equals(tuple4.t4);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 140 */     int result = super.hashCode();
/* 141 */     result = 31 * result + this.t4.hashCode();
/* 142 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/* 147 */     return 4;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reacto\\util\function\Tuple4.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */