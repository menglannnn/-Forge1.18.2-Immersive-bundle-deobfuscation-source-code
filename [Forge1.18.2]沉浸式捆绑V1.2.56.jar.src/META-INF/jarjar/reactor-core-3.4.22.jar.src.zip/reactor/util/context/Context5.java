/*     */ package reactor.util.context;
/*     */ 
/*     */ import java.util.AbstractMap;
/*     */ import java.util.Map;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Objects;
/*     */ import java.util.function.BiConsumer;
/*     */ import java.util.stream.Stream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class Context5
/*     */   implements CoreContext
/*     */ {
/*     */   final Object key1;
/*     */   final Object value1;
/*     */   final Object key2;
/*     */   final Object value2;
/*     */   final Object key3;
/*     */   final Object value3;
/*     */   final Object key4;
/*     */   final Object value4;
/*     */   final Object key5;
/*     */   final Object value5;
/*     */   
/*     */   Context5(Object key1, Object value1, Object key2, Object value2, Object key3, Object value3, Object key4, Object value4, Object key5, Object value5) {
/*  45 */     Context4.checkKeys(new Object[] { key1, key2, key3, key4, key5 });
/*  46 */     this.key1 = Objects.requireNonNull(key1, "key1");
/*  47 */     this.value1 = Objects.requireNonNull(value1, "value1");
/*  48 */     this.key2 = Objects.requireNonNull(key2, "key2");
/*  49 */     this.value2 = Objects.requireNonNull(value2, "value2");
/*  50 */     this.key3 = Objects.requireNonNull(key3, "key3");
/*  51 */     this.value3 = Objects.requireNonNull(value3, "value3");
/*  52 */     this.key4 = Objects.requireNonNull(key4, "key4");
/*  53 */     this.value4 = Objects.requireNonNull(value4, "value4");
/*  54 */     this.key5 = Objects.requireNonNull(key5, "key5");
/*  55 */     this.value5 = Objects.requireNonNull(value5, "value5");
/*     */   }
/*     */ 
/*     */   
/*     */   public Context put(Object key, Object value) {
/*  60 */     Objects.requireNonNull(key, "key");
/*  61 */     Objects.requireNonNull(value, "value");
/*     */     
/*  63 */     if (this.key1.equals(key)) {
/*  64 */       return new Context5(key, value, this.key2, this.value2, this.key3, this.value3, this.key4, this.value4, this.key5, this.value5);
/*     */     }
/*     */     
/*  67 */     if (this.key2.equals(key)) {
/*  68 */       return new Context5(this.key1, this.value1, key, value, this.key3, this.value3, this.key4, this.value4, this.key5, this.value5);
/*     */     }
/*     */     
/*  71 */     if (this.key3.equals(key)) {
/*  72 */       return new Context5(this.key1, this.value1, this.key2, this.value2, key, value, this.key4, this.value4, this.key5, this.value5);
/*     */     }
/*     */     
/*  75 */     if (this.key4.equals(key)) {
/*  76 */       return new Context5(this.key1, this.value1, this.key2, this.value2, this.key3, this.value3, key, value, this.key5, this.value5);
/*     */     }
/*     */     
/*  79 */     if (this.key5.equals(key)) {
/*  80 */       return new Context5(this.key1, this.value1, this.key2, this.value2, this.key3, this.value3, this.key4, this.value4, key, value);
/*     */     }
/*     */     
/*  83 */     return new ContextN(this.key1, this.value1, this.key2, this.value2, this.key3, this.value3, this.key4, this.value4, this.key5, this.value5, key, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public Context delete(Object key) {
/*  88 */     Objects.requireNonNull(key, "key");
/*     */     
/*  90 */     if (this.key1.equals(key)) {
/*  91 */       return new Context4(this.key2, this.value2, this.key3, this.value3, this.key4, this.value4, this.key5, this.value5);
/*     */     }
/*     */     
/*  94 */     if (this.key2.equals(key)) {
/*  95 */       return new Context4(this.key1, this.value1, this.key3, this.value3, this.key4, this.value4, this.key5, this.value5);
/*     */     }
/*     */     
/*  98 */     if (this.key3.equals(key)) {
/*  99 */       return new Context4(this.key1, this.value1, this.key2, this.value2, this.key4, this.value4, this.key5, this.value5);
/*     */     }
/*     */     
/* 102 */     if (this.key4.equals(key)) {
/* 103 */       return new Context4(this.key1, this.value1, this.key2, this.value2, this.key3, this.value3, this.key5, this.value5);
/*     */     }
/*     */     
/* 106 */     if (this.key5.equals(key)) {
/* 107 */       return new Context4(this.key1, this.value1, this.key2, this.value2, this.key3, this.value3, this.key4, this.value4);
/*     */     }
/*     */     
/* 110 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasKey(Object key) {
/* 115 */     return (this.key1.equals(key) || this.key2.equals(key) || this.key3.equals(key) || this.key4
/* 116 */       .equals(key) || this.key5.equals(key));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T get(Object key) {
/* 122 */     if (this.key1.equals(key)) {
/* 123 */       return (T)this.value1;
/*     */     }
/* 125 */     if (this.key2.equals(key)) {
/* 126 */       return (T)this.value2;
/*     */     }
/* 128 */     if (this.key3.equals(key)) {
/* 129 */       return (T)this.value3;
/*     */     }
/* 131 */     if (this.key4.equals(key)) {
/* 132 */       return (T)this.value4;
/*     */     }
/* 134 */     if (this.key5.equals(key)) {
/* 135 */       return (T)this.value5;
/*     */     }
/* 137 */     throw new NoSuchElementException("Context does not contain key: " + key);
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/* 142 */     return 5;
/*     */   }
/*     */ 
/*     */   
/*     */   public Stream<Map.Entry<Object, Object>> stream() {
/* 147 */     return Stream.of((Map.Entry<Object, Object>[])new Map.Entry[] { new AbstractMap.SimpleImmutableEntry<>(this.key1, this.value1), new AbstractMap.SimpleImmutableEntry<>(this.key2, this.value2), new AbstractMap.SimpleImmutableEntry<>(this.key3, this.value3), new AbstractMap.SimpleImmutableEntry<>(this.key4, this.value4), new AbstractMap.SimpleImmutableEntry<>(this.key5, this.value5) });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void forEach(BiConsumer<Object, Object> action) {
/* 157 */     action.accept(this.key1, this.value1);
/* 158 */     action.accept(this.key2, this.value2);
/* 159 */     action.accept(this.key3, this.value3);
/* 160 */     action.accept(this.key4, this.value4);
/* 161 */     action.accept(this.key5, this.value5);
/*     */   }
/*     */ 
/*     */   
/*     */   public Context putAllInto(Context base) {
/* 166 */     return base
/* 167 */       .put(this.key1, this.value1)
/* 168 */       .put(this.key2, this.value2)
/* 169 */       .put(this.key3, this.value3)
/* 170 */       .put(this.key4, this.value4)
/* 171 */       .put(this.key5, this.value5);
/*     */   }
/*     */ 
/*     */   
/*     */   public void unsafePutAllInto(ContextN other) {
/* 176 */     other.accept(this.key1, this.value1);
/* 177 */     other.accept(this.key2, this.value2);
/* 178 */     other.accept(this.key3, this.value3);
/* 179 */     other.accept(this.key4, this.value4);
/* 180 */     other.accept(this.key5, this.value5);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 185 */     return "Context5{" + this.key1 + '=' + this.value1 + ", " + this.key2 + '=' + this.value2 + ", " + this.key3 + '=' + this.value3 + ", " + this.key4 + '=' + this.value4 + ", " + this.key5 + '=' + this.value5 + '}';
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reacto\\util\context\Context5.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */