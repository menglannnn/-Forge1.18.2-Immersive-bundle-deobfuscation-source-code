/*     */ package reactor.util.context;
/*     */ 
/*     */ import java.util.AbstractMap;
/*     */ import java.util.Map;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Objects;
/*     */ import java.util.function.BiConsumer;
/*     */ import java.util.stream.Stream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class Context4
/*     */   implements CoreContext
/*     */ {
/*     */   final Object key1;
/*     */   final Object value1;
/*     */   final Object key2;
/*     */   final Object value2;
/*     */   final Object key3;
/*     */   final Object value3;
/*     */   final Object key4;
/*     */   final Object value4;
/*     */   
/*     */   static void checkKeys(Object... keys) {
/*  38 */     int size = keys.length;
/*     */     
/*  40 */     for (int i = 0; i < size - 1; i++) {
/*  41 */       Object key = Objects.requireNonNull(keys[i], "key" + (i + 1));
/*  42 */       for (int j = i + 1; j < size; j++) {
/*  43 */         Object otherKey = keys[j];
/*  44 */         if (key.equals(otherKey)) {
/*  45 */           throw new IllegalArgumentException("Key #" + (i + 1) + " (" + key + ") is duplicated");
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/*  50 */     if (size != 0) {
/*  51 */       Objects.requireNonNull(keys[size - 1], "key" + size);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Context4(Object key1, Object value1, Object key2, Object value2, Object key3, Object value3, Object key4, Object value4) {
/*  69 */     checkKeys(new Object[] { key1, key2, key3, key4 });
/*  70 */     this.key1 = Objects.requireNonNull(key1, "key1");
/*  71 */     this.value1 = Objects.requireNonNull(value1, "value1");
/*  72 */     this.key2 = Objects.requireNonNull(key2, "key2");
/*  73 */     this.value2 = Objects.requireNonNull(value2, "value2");
/*  74 */     this.key3 = Objects.requireNonNull(key3, "key3");
/*  75 */     this.value3 = Objects.requireNonNull(value3, "value3");
/*  76 */     this.key4 = Objects.requireNonNull(key4, "key4");
/*  77 */     this.value4 = Objects.requireNonNull(value4, "value4");
/*     */   }
/*     */ 
/*     */   
/*     */   public Context put(Object key, Object value) {
/*  82 */     Objects.requireNonNull(key, "key");
/*  83 */     Objects.requireNonNull(value, "value");
/*     */     
/*  85 */     if (this.key1.equals(key)) {
/*  86 */       return new Context4(key, value, this.key2, this.value2, this.key3, this.value3, this.key4, this.value4);
/*     */     }
/*     */     
/*  89 */     if (this.key2.equals(key)) {
/*  90 */       return new Context4(this.key1, this.value1, key, value, this.key3, this.value3, this.key4, this.value4);
/*     */     }
/*     */     
/*  93 */     if (this.key3.equals(key)) {
/*  94 */       return new Context4(this.key1, this.value1, this.key2, this.value2, key, value, this.key4, this.value4);
/*     */     }
/*     */     
/*  97 */     if (this.key4.equals(key)) {
/*  98 */       return new Context4(this.key1, this.value1, this.key2, this.value2, this.key3, this.value3, key, value);
/*     */     }
/*     */     
/* 101 */     return new Context5(this.key1, this.value1, this.key2, this.value2, this.key3, this.value3, this.key4, this.value4, key, value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Context delete(Object key) {
/* 107 */     Objects.requireNonNull(key, "key");
/*     */     
/* 109 */     if (this.key1.equals(key)) {
/* 110 */       return new Context3(this.key2, this.value2, this.key3, this.value3, this.key4, this.value4);
/*     */     }
/*     */     
/* 113 */     if (this.key2.equals(key)) {
/* 114 */       return new Context3(this.key1, this.value1, this.key3, this.value3, this.key4, this.value4);
/*     */     }
/*     */     
/* 117 */     if (this.key3.equals(key)) {
/* 118 */       return new Context3(this.key1, this.value1, this.key2, this.value2, this.key4, this.value4);
/*     */     }
/*     */     
/* 121 */     if (this.key4.equals(key)) {
/* 122 */       return new Context3(this.key1, this.value1, this.key2, this.value2, this.key3, this.value3);
/*     */     }
/*     */     
/* 125 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasKey(Object key) {
/* 130 */     return (this.key1.equals(key) || this.key2.equals(key) || this.key3.equals(key) || this.key4.equals(key));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T get(Object key) {
/* 136 */     if (this.key1.equals(key)) {
/* 137 */       return (T)this.value1;
/*     */     }
/* 139 */     if (this.key2.equals(key)) {
/* 140 */       return (T)this.value2;
/*     */     }
/* 142 */     if (this.key3.equals(key)) {
/* 143 */       return (T)this.value3;
/*     */     }
/* 145 */     if (this.key4.equals(key)) {
/* 146 */       return (T)this.value4;
/*     */     }
/* 148 */     throw new NoSuchElementException("Context does not contain key: " + key);
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/* 153 */     return 4;
/*     */   }
/*     */ 
/*     */   
/*     */   public Stream<Map.Entry<Object, Object>> stream() {
/* 158 */     return Stream.of((Map.Entry<Object, Object>[])new Map.Entry[] { new AbstractMap.SimpleImmutableEntry<>(this.key1, this.value1), new AbstractMap.SimpleImmutableEntry<>(this.key2, this.value2), new AbstractMap.SimpleImmutableEntry<>(this.key3, this.value3), new AbstractMap.SimpleImmutableEntry<>(this.key4, this.value4) });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void forEach(BiConsumer<Object, Object> action) {
/* 167 */     action.accept(this.key1, this.value1);
/* 168 */     action.accept(this.key2, this.value2);
/* 169 */     action.accept(this.key3, this.value3);
/* 170 */     action.accept(this.key4, this.value4);
/*     */   }
/*     */ 
/*     */   
/*     */   public Context putAllInto(Context base) {
/* 175 */     return base
/* 176 */       .put(this.key1, this.value1)
/* 177 */       .put(this.key2, this.value2)
/* 178 */       .put(this.key3, this.value3)
/* 179 */       .put(this.key4, this.value4);
/*     */   }
/*     */ 
/*     */   
/*     */   public void unsafePutAllInto(ContextN other) {
/* 184 */     other.accept(this.key1, this.value1);
/* 185 */     other.accept(this.key2, this.value2);
/* 186 */     other.accept(this.key3, this.value3);
/* 187 */     other.accept(this.key4, this.value4);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 192 */     return "Context4{" + this.key1 + '=' + this.value1 + ", " + this.key2 + '=' + this.value2 + ", " + this.key3 + '=' + this.value3 + ", " + this.key4 + '=' + this.value4 + '}';
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reacto\\util\context\Context4.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */