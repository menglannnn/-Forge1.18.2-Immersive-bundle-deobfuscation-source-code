/*     */ package reactor.util.context;
/*     */ 
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Objects;
/*     */ import java.util.function.BiConsumer;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Function;
/*     */ import java.util.stream.Stream;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ContextN
/*     */   extends LinkedHashMap<Object, Object>
/*     */   implements CoreContext, BiConsumer<Object, Object>, Consumer<Map.Entry<Object, Object>>
/*     */ {
/*     */   ContextN(Object key1, Object value1, Object key2, Object value2, Object key3, Object value3, Object key4, Object value4, Object key5, Object value5, Object key6, Object value6) {
/*  38 */     super(6, 1.0F);
/*     */     
/*  40 */     accept(key1, value1);
/*  41 */     accept(key2, value2);
/*  42 */     accept(key3, value3);
/*  43 */     accept(key4, value4);
/*  44 */     accept(key5, value5);
/*  45 */     accept(key6, value6);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ContextN(Map<Object, Object> originalToCopy) {
/*  54 */     super(Objects.<Map<?, ?>>requireNonNull(originalToCopy, "originalToCopy"));
/*     */   }
/*     */   
/*     */   ContextN(int initialCapacity) {
/*  58 */     super(initialCapacity, 1.0F);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void accept(Object key, Object value) {
/*  65 */     super.put(Objects.requireNonNull(key, "key"), 
/*  66 */         Objects.requireNonNull(value, "value"));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void accept(Map.Entry<Object, Object> entry) {
/*  72 */     accept(entry.getKey(), entry.getValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Context put(Object key, Object value) {
/*  84 */     ContextN newContext = new ContextN(this);
/*  85 */     newContext.accept(key, value);
/*  86 */     return newContext;
/*     */   }
/*     */ 
/*     */   
/*     */   public Context delete(Object key) {
/*  91 */     Objects.requireNonNull(key, "key");
/*  92 */     if (!hasKey(key)) {
/*  93 */       return this;
/*     */     }
/*     */     
/*  96 */     int s = size() - 1;
/*  97 */     if (s == 5) {
/*     */       
/*  99 */       Map.Entry[] arrayOfEntry = new Map.Entry[s];
/* 100 */       int idx = 0;
/* 101 */       for (Map.Entry<Object, Object> entry : entrySet()) {
/* 102 */         if (!entry.getKey().equals(key)) {
/* 103 */           arrayOfEntry[idx] = entry;
/* 104 */           idx++;
/*     */         } 
/*     */       } 
/* 107 */       return new Context5(arrayOfEntry[0]
/* 108 */           .getKey(), arrayOfEntry[0].getValue(), arrayOfEntry[1]
/* 109 */           .getKey(), arrayOfEntry[1].getValue(), arrayOfEntry[2]
/* 110 */           .getKey(), arrayOfEntry[2].getValue(), arrayOfEntry[3]
/* 111 */           .getKey(), arrayOfEntry[3].getValue(), arrayOfEntry[4]
/* 112 */           .getKey(), arrayOfEntry[4].getValue());
/*     */     } 
/*     */     
/* 115 */     ContextN newInstance = new ContextN(this);
/* 116 */     newInstance.remove(key);
/* 117 */     return newInstance;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasKey(Object key) {
/* 122 */     return containsKey(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object get(Object key) {
/* 127 */     Object o = super.get(key);
/* 128 */     if (o != null) {
/* 129 */       return o;
/*     */     }
/* 131 */     throw new NoSuchElementException("Context does not contain key: " + key);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object getOrDefault(Object key, @Nullable Object defaultValue) {
/* 137 */     Object o = super.get(key);
/* 138 */     if (o != null) {
/* 139 */       return o;
/*     */     }
/* 141 */     return defaultValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public Stream<Map.Entry<Object, Object>> stream() {
/* 146 */     return entrySet().stream().map(java.util.AbstractMap.SimpleImmutableEntry::new);
/*     */   }
/*     */ 
/*     */   
/*     */   public Context putAllInto(Context base) {
/* 151 */     if (base instanceof ContextN) {
/* 152 */       ContextN newContext = new ContextN(base.size() + size());
/* 153 */       newContext.putAll((Map<?, ?>)base);
/* 154 */       newContext.putAll(this);
/* 155 */       return newContext;
/*     */     } 
/*     */     
/* 158 */     Context[] holder = { base };
/* 159 */     forEach((k, v) -> holder[0] = holder[0].put(k, v));
/* 160 */     return holder[0];
/*     */   }
/*     */ 
/*     */   
/*     */   public void unsafePutAllInto(ContextN other) {
/* 165 */     other.putAll(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void putAll(Map<?, ?> m) {
/* 179 */     super.putAll(m);
/*     */   }
/*     */ 
/*     */   
/*     */   public Context putAll(ContextView other) {
/* 184 */     if (other.isEmpty()) return this;
/*     */ 
/*     */ 
/*     */     
/* 188 */     ContextN newContext = new ContextN(this);
/* 189 */     if (other instanceof CoreContext) {
/* 190 */       CoreContext coreContext = (CoreContext)other;
/* 191 */       coreContext.unsafePutAllInto(newContext);
/*     */     }
/*     */     else {
/*     */       
/* 195 */       other.stream().sequential().forEach(newContext);
/*     */     } 
/*     */     
/* 198 */     return newContext;
/*     */   }
/*     */ 
/*     */   
/*     */   public Context putAllMap(Map<?, ?> from) {
/* 203 */     if (from.isEmpty()) {
/* 204 */       return this;
/*     */     }
/*     */     
/* 207 */     ContextN newContext = new ContextN(this);
/* 208 */     from.forEach(newContext);
/* 209 */     return newContext;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 214 */     return "ContextN" + super.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reacto\\util\context\ContextN.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */