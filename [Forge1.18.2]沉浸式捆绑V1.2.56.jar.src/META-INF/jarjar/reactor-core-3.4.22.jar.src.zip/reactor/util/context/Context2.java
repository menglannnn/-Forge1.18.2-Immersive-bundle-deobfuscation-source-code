/*     */ package reactor.util.context;
/*     */ 
/*     */ import java.util.AbstractMap;
/*     */ import java.util.Map;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Objects;
/*     */ import java.util.function.BiConsumer;
/*     */ import java.util.stream.Stream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class Context2
/*     */   implements CoreContext
/*     */ {
/*     */   final Object key1;
/*     */   final Object value1;
/*     */   final Object key2;
/*     */   final Object value2;
/*     */   
/*     */   Context2(Object key1, Object value1, Object key2, Object value2) {
/*  34 */     if (Objects.<T>requireNonNull((T)key1, "key1").equals(key2)) {
/*  35 */       throw new IllegalArgumentException("Key #1 (" + key1 + ") is duplicated");
/*     */     }
/*  37 */     this.key1 = key1;
/*  38 */     this.value1 = Objects.requireNonNull(value1, "value1");
/*  39 */     this.key2 = Objects.requireNonNull(key2, "key2");
/*  40 */     this.value2 = Objects.requireNonNull(value2, "value2");
/*     */   }
/*     */ 
/*     */   
/*     */   public Context put(Object key, Object value) {
/*  45 */     Objects.requireNonNull(key, "key");
/*  46 */     Objects.requireNonNull(value, "value");
/*     */     
/*  48 */     if (this.key1.equals(key)) {
/*  49 */       return new Context2(key, value, this.key2, this.value2);
/*     */     }
/*     */     
/*  52 */     if (this.key2.equals(key)) {
/*  53 */       return new Context2(this.key1, this.value1, key, value);
/*     */     }
/*     */     
/*  56 */     return new Context3(this.key1, this.value1, this.key2, this.value2, key, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public Context delete(Object key) {
/*  61 */     Objects.requireNonNull(key, "key");
/*     */     
/*  63 */     if (this.key1.equals(key)) {
/*  64 */       return new Context1(this.key2, this.value2);
/*     */     }
/*     */     
/*  67 */     if (this.key2.equals(key)) {
/*  68 */       return new Context1(this.key1, this.value1);
/*     */     }
/*     */     
/*  71 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasKey(Object key) {
/*  76 */     return (this.key1.equals(key) || this.key2.equals(key));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T get(Object key) {
/*  82 */     if (this.key1.equals(key)) {
/*  83 */       return (T)this.value1;
/*     */     }
/*  85 */     if (this.key2.equals(key)) {
/*  86 */       return (T)this.value2;
/*     */     }
/*  88 */     throw new NoSuchElementException("Context does not contain key: " + key);
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/*  93 */     return 2;
/*     */   }
/*     */ 
/*     */   
/*     */   public Stream<Map.Entry<Object, Object>> stream() {
/*  98 */     return Stream.of((Map.Entry<Object, Object>[])new Map.Entry[] { new AbstractMap.SimpleImmutableEntry<>(this.key1, this.value1), new AbstractMap.SimpleImmutableEntry<>(this.key2, this.value2) });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void forEach(BiConsumer<Object, Object> action) {
/* 105 */     action.accept(this.key1, this.value1);
/* 106 */     action.accept(this.key2, this.value2);
/*     */   }
/*     */ 
/*     */   
/*     */   public Context putAllInto(Context base) {
/* 111 */     return base
/* 112 */       .put(this.key1, this.value1)
/* 113 */       .put(this.key2, this.value2);
/*     */   }
/*     */ 
/*     */   
/*     */   public void unsafePutAllInto(ContextN other) {
/* 118 */     other.accept(this.key1, this.value1);
/* 119 */     other.accept(this.key2, this.value2);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 124 */     return "Context2{" + this.key1 + '=' + this.value1 + ", " + this.key2 + '=' + this.value2 + '}';
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reacto\\util\context\Context2.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */