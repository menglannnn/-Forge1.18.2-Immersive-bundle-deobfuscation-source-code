/*     */ package reactor.util.retry;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.util.function.Function;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.scheduler.Schedulers;
/*     */ import reactor.util.context.Context;
/*     */ import reactor.util.context.ContextView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Retry
/*     */ {
/*     */   public final ContextView retryContext;
/*     */   
/*     */   public Retry() {
/*  55 */     this((ContextView)Context.empty());
/*     */   }
/*     */   
/*     */   protected Retry(ContextView retryContext) {
/*  59 */     this.retryContext = retryContext;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ContextView retryContext() {
/*  96 */     return this.retryContext;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static interface RetrySignal
/*     */   {
/*     */     long totalRetries();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     long totalRetriesInARow();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Throwable failure();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     default ContextView retryContextView() {
/* 139 */       return (ContextView)Context.empty();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     default RetrySignal copy() {
/* 151 */       return new ImmutableRetrySignal(totalRetries(), totalRetriesInARow(), failure(), retryContextView());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RetryBackoffSpec backoff(long maxAttempts, Duration minBackoff) {
/* 168 */     return new RetryBackoffSpec((ContextView)Context.empty(), maxAttempts, t -> true, false, minBackoff, RetrySpec.MAX_BACKOFF, 0.5D, Schedulers::parallel, RetrySpec.NO_OP_CONSUMER, RetrySpec.NO_OP_CONSUMER, RetrySpec.NO_OP_BIFUNCTION, RetrySpec.NO_OP_BIFUNCTION, RetryBackoffSpec.BACKOFF_EXCEPTION_GENERATOR);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RetryBackoffSpec fixedDelay(long maxAttempts, Duration fixedDelay) {
/* 190 */     return new RetryBackoffSpec((ContextView)Context.empty(), maxAttempts, t -> true, false, fixedDelay, fixedDelay, 0.0D, Schedulers::parallel, RetrySpec.NO_OP_CONSUMER, RetrySpec.NO_OP_CONSUMER, RetrySpec.NO_OP_BIFUNCTION, RetrySpec.NO_OP_BIFUNCTION, RetryBackoffSpec.BACKOFF_EXCEPTION_GENERATOR);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RetrySpec max(long max) {
/* 205 */     return new RetrySpec((ContextView)Context.empty(), max, t -> true, false, RetrySpec.NO_OP_CONSUMER, RetrySpec.NO_OP_CONSUMER, RetrySpec.NO_OP_BIFUNCTION, RetrySpec.NO_OP_BIFUNCTION, RetrySpec.RETRY_EXCEPTION_GENERATOR);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RetrySpec maxInARow(long maxInARow) {
/* 222 */     return new RetrySpec((ContextView)Context.empty(), maxInARow, t -> true, true, RetrySpec.NO_OP_CONSUMER, RetrySpec.NO_OP_CONSUMER, RetrySpec.NO_OP_BIFUNCTION, RetrySpec.NO_OP_BIFUNCTION, RetrySpec.RETRY_EXCEPTION_GENERATOR);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RetrySpec indefinitely() {
/* 233 */     return new RetrySpec((ContextView)Context.empty(), Long.MAX_VALUE, t -> true, false, RetrySpec.NO_OP_CONSUMER, RetrySpec.NO_OP_CONSUMER, RetrySpec.NO_OP_BIFUNCTION, RetrySpec.NO_OP_BIFUNCTION, RetrySpec.RETRY_EXCEPTION_GENERATOR);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Retry from(final Function<Flux<RetrySignal>, ? extends Publisher<?>> function) {
/* 244 */     return new Retry((ContextView)Context.empty())
/*     */       {
/*     */         public Publisher<?> generateCompanion(Flux<Retry.RetrySignal> retrySignalCompanion) {
/* 247 */           return function.apply(retrySignalCompanion);
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Retry withThrowable(final Function<Flux<Throwable>, ? extends Publisher<?>> function) {
/* 260 */     return new Retry((ContextView)Context.empty())
/*     */       {
/*     */         public Publisher<?> generateCompanion(Flux<Retry.RetrySignal> retrySignals) {
/* 263 */           return function.apply(retrySignals.map(Retry.RetrySignal::failure));
/*     */         }
/*     */       };
/*     */   }
/*     */   
/*     */   public abstract Publisher<?> generateCompanion(Flux<RetrySignal> paramFlux);
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reacto\\util\retry\Retry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */