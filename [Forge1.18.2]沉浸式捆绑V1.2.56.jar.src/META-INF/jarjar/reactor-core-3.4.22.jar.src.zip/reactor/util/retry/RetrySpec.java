/*     */ package reactor.util.retry;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.util.Objects;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Predicate;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.context.ContextView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RetrySpec
/*     */   extends Retry
/*     */ {
/*  54 */   static final Duration MAX_BACKOFF = Duration.ofMillis(Long.MAX_VALUE);
/*     */   static {
/*  56 */     NO_OP_BIFUNCTION = ((rs, m) -> m);
/*     */ 
/*     */ 
/*     */     
/*  60 */     RETRY_EXCEPTION_GENERATOR = ((builder, rs) -> Exceptions.retryExhausted("Retries exhausted: " + (builder.isTransientErrors ? (rs.totalRetriesInARow() + "/" + builder.maxAttempts + " in a row (" + rs.totalRetries() + " total)") : (rs.totalRetries() + "/" + builder.maxAttempts)), rs.failure()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final Consumer<Retry.RetrySignal> NO_OP_CONSUMER = rs -> {
/*     */     
/*     */     };
/*     */ 
/*     */ 
/*     */   
/*     */   static final BiFunction<Retry.RetrySignal, Mono<Void>, Mono<Void>> NO_OP_BIFUNCTION;
/*     */ 
/*     */ 
/*     */   
/*     */   static final BiFunction<RetrySpec, Retry.RetrySignal, Throwable> RETRY_EXCEPTION_GENERATOR;
/*     */ 
/*     */ 
/*     */   
/*     */   public final long maxAttempts;
/*     */ 
/*     */   
/*     */   public final Predicate<Throwable> errorFilter;
/*     */ 
/*     */   
/*     */   public final boolean isTransientErrors;
/*     */ 
/*     */   
/*     */   final Consumer<Retry.RetrySignal> doPreRetry;
/*     */ 
/*     */   
/*     */   final Consumer<Retry.RetrySignal> doPostRetry;
/*     */ 
/*     */   
/*     */   final BiFunction<Retry.RetrySignal, Mono<Void>, Mono<Void>> asyncPreRetry;
/*     */ 
/*     */   
/*     */   final BiFunction<Retry.RetrySignal, Mono<Void>, Mono<Void>> asyncPostRetry;
/*     */ 
/*     */   
/*     */   final BiFunction<RetrySpec, Retry.RetrySignal, Throwable> retryExhaustedGenerator;
/*     */ 
/*     */ 
/*     */   
/*     */   RetrySpec(ContextView retryContext, long max, Predicate<? super Throwable> aThrowablePredicate, boolean isTransientErrors, Consumer<Retry.RetrySignal> doPreRetry, Consumer<Retry.RetrySignal> doPostRetry, BiFunction<Retry.RetrySignal, Mono<Void>, Mono<Void>> asyncPreRetry, BiFunction<Retry.RetrySignal, Mono<Void>, Mono<Void>> asyncPostRetry, BiFunction<RetrySpec, Retry.RetrySignal, Throwable> retryExhaustedGenerator) {
/* 106 */     super(retryContext);
/* 107 */     this.maxAttempts = max;
/* 108 */     this.errorFilter = aThrowablePredicate::test;
/* 109 */     this.isTransientErrors = isTransientErrors;
/* 110 */     this.doPreRetry = doPreRetry;
/* 111 */     this.doPostRetry = doPostRetry;
/* 112 */     this.asyncPreRetry = asyncPreRetry;
/* 113 */     this.asyncPostRetry = asyncPostRetry;
/* 114 */     this.retryExhaustedGenerator = retryExhaustedGenerator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RetrySpec withRetryContext(ContextView retryContext) {
/* 124 */     return new RetrySpec(retryContext, this.maxAttempts, this.errorFilter, this.isTransientErrors, this.doPreRetry, this.doPostRetry, this.asyncPreRetry, this.asyncPostRetry, this.retryExhaustedGenerator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RetrySpec maxAttempts(long maxAttempts) {
/* 145 */     return new RetrySpec(this.retryContext, maxAttempts, this.errorFilter, this.isTransientErrors, this.doPreRetry, this.doPostRetry, this.asyncPreRetry, this.asyncPostRetry, this.retryExhaustedGenerator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RetrySpec filter(Predicate<? super Throwable> errorFilter) {
/* 166 */     return new RetrySpec(this.retryContext, this.maxAttempts, 
/*     */ 
/*     */         
/* 169 */         Objects.<Predicate<? super Throwable>>requireNonNull(errorFilter, "errorFilter"), this.isTransientErrors, this.doPreRetry, this.doPostRetry, this.asyncPreRetry, this.asyncPostRetry, this.retryExhaustedGenerator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RetrySpec modifyErrorFilter(Function<Predicate<Throwable>, Predicate<? super Throwable>> predicateAdjuster) {
/* 199 */     Objects.requireNonNull(predicateAdjuster, "predicateAdjuster");
/* 200 */     Predicate<? super Throwable> newPredicate = Objects.<Predicate<? super Throwable>>requireNonNull(predicateAdjuster.apply(this.errorFilter), "predicateAdjuster must return a new predicate");
/*     */     
/* 202 */     return new RetrySpec(this.retryContext, this.maxAttempts, newPredicate, this.isTransientErrors, this.doPreRetry, this.doPostRetry, this.asyncPreRetry, this.asyncPostRetry, this.retryExhaustedGenerator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RetrySpec doBeforeRetry(Consumer<Retry.RetrySignal> doBeforeRetry) {
/* 225 */     return new RetrySpec(this.retryContext, this.maxAttempts, this.errorFilter, this.isTransientErrors, this.doPreRetry
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 230 */         .andThen(doBeforeRetry), this.doPostRetry, this.asyncPreRetry, this.asyncPostRetry, this.retryExhaustedGenerator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RetrySpec doAfterRetry(Consumer<Retry.RetrySignal> doAfterRetry) {
/* 247 */     return new RetrySpec(this.retryContext, this.maxAttempts, this.errorFilter, this.isTransientErrors, this.doPreRetry, this.doPostRetry
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 253 */         .andThen(doAfterRetry), this.asyncPreRetry, this.asyncPostRetry, this.retryExhaustedGenerator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RetrySpec doBeforeRetryAsync(Function<Retry.RetrySignal, Mono<Void>> doAsyncBeforeRetry) {
/* 268 */     return new RetrySpec(this.retryContext, this.maxAttempts, this.errorFilter, this.isTransientErrors, this.doPreRetry, this.doPostRetry, (rs, m) -> ((Mono)this.asyncPreRetry.apply(rs, m)).then(doAsyncBeforeRetry.apply(rs)), this.asyncPostRetry, this.retryExhaustedGenerator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RetrySpec doAfterRetryAsync(Function<Retry.RetrySignal, Mono<Void>> doAsyncAfterRetry) {
/* 289 */     return new RetrySpec(this.retryContext, this.maxAttempts, this.errorFilter, this.isTransientErrors, this.doPreRetry, this.doPostRetry, this.asyncPreRetry, (rs, m) -> ((Mono)this.asyncPostRetry.apply(rs, m)).then(doAsyncAfterRetry.apply(rs)), this.retryExhaustedGenerator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RetrySpec onRetryExhaustedThrow(BiFunction<RetrySpec, Retry.RetrySignal, Throwable> retryExhaustedGenerator) {
/* 312 */     return new RetrySpec(this.retryContext, this.maxAttempts, this.errorFilter, this.isTransientErrors, this.doPreRetry, this.doPostRetry, this.asyncPreRetry, this.asyncPostRetry, 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 321 */         Objects.<BiFunction<RetrySpec, Retry.RetrySignal, Throwable>>requireNonNull(retryExhaustedGenerator, "retryExhaustedGenerator"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RetrySpec transientErrors(boolean isTransientErrors) {
/* 338 */     return new RetrySpec(this.retryContext, this.maxAttempts, this.errorFilter, isTransientErrors, this.doPreRetry, this.doPostRetry, this.asyncPreRetry, this.asyncPostRetry, this.retryExhaustedGenerator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Flux<Long> generateCompanion(Flux<Retry.RetrySignal> flux) {
/* 356 */     return flux.concatMap(retryWhenState -> {
/*     */           Retry.RetrySignal copy = retryWhenState.copy();
/*     */           Throwable currentFailure = copy.failure();
/*     */           long iteration = this.isTransientErrors ? copy.totalRetriesInARow() : copy.totalRetries();
/*     */           return (Publisher)((currentFailure == null) ? Mono.error(new IllegalStateException("RetryWhenState#failure() not expected to be null")) : (!this.errorFilter.test(currentFailure) ? Mono.error(currentFailure) : ((iteration >= this.maxAttempts) ? Mono.error(this.retryExhaustedGenerator.apply(this, copy)) : applyHooks(copy, Mono.just(Long.valueOf(iteration)), this.doPreRetry, this.doPostRetry, this.asyncPreRetry, this.asyncPostRetry))));
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T> Mono<T> applyHooks(Retry.RetrySignal copyOfSignal, Mono<T> originalCompanion, Consumer<Retry.RetrySignal> doPreRetry, Consumer<Retry.RetrySignal> doPostRetry, BiFunction<Retry.RetrySignal, Mono<Void>, Mono<Void>> asyncPreRetry, BiFunction<Retry.RetrySignal, Mono<Void>, Mono<Void>> asyncPostRetry) {
/*     */     Mono<Void> postRetrySyncMono;
/* 387 */     if (doPreRetry != NO_OP_CONSUMER) {
/*     */       try {
/* 389 */         doPreRetry.accept(copyOfSignal);
/*     */       }
/* 391 */       catch (Throwable e) {
/* 392 */         return Mono.error(e);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 397 */     if (doPostRetry != NO_OP_CONSUMER) {
/* 398 */       postRetrySyncMono = Mono.fromRunnable(() -> doPostRetry.accept(copyOfSignal));
/*     */     } else {
/*     */       
/* 401 */       postRetrySyncMono = Mono.empty();
/*     */     } 
/*     */     
/* 404 */     Mono<Void> preRetryMono = (asyncPreRetry == NO_OP_BIFUNCTION) ? Mono.empty() : asyncPreRetry.apply(copyOfSignal, Mono.empty());
/* 405 */     Mono<Void> postRetryMono = (asyncPostRetry != NO_OP_BIFUNCTION) ? asyncPostRetry.apply(copyOfSignal, postRetrySyncMono) : postRetrySyncMono;
/*     */     
/* 407 */     return preRetryMono.then(originalCompanion).flatMap(postRetryMono::thenReturn);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reacto\\util\retry\RetrySpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */