/*     */ package reactor.util.retry;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.ThreadLocalRandom;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Predicate;
/*     */ import java.util.function.Supplier;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.core.scheduler.Scheduler;
/*     */ import reactor.core.scheduler.Schedulers;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.ContextView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RetryBackoffSpec
/*     */   extends Retry
/*     */ {
/*     */   static final BiFunction<RetryBackoffSpec, Retry.RetrySignal, Throwable> BACKOFF_EXCEPTION_GENERATOR;
/*     */   public final Duration minBackoff;
/*     */   public final Duration maxBackoff;
/*     */   public final double jitterFactor;
/*     */   public final Supplier<Scheduler> backoffSchedulerSupplier;
/*     */   public final long maxAttempts;
/*     */   public final Predicate<Throwable> errorFilter;
/*     */   public final boolean isTransientErrors;
/*     */   final Consumer<Retry.RetrySignal> syncPreRetry;
/*     */   final Consumer<Retry.RetrySignal> syncPostRetry;
/*     */   final BiFunction<Retry.RetrySignal, Mono<Void>, Mono<Void>> asyncPreRetry;
/*     */   final BiFunction<Retry.RetrySignal, Mono<Void>, Mono<Void>> asyncPostRetry;
/*     */   final BiFunction<RetryBackoffSpec, Retry.RetrySignal, Throwable> retryExhaustedGenerator;
/*     */   
/*     */   static {
/*  66 */     BACKOFF_EXCEPTION_GENERATOR = ((builder, rs) -> Exceptions.retryExhausted("Retries exhausted: " + (builder.isTransientErrors ? (rs.totalRetriesInARow() + "/" + builder.maxAttempts + " in a row (" + rs.totalRetries() + " total)") : (rs.totalRetries() + "/" + builder.maxAttempts)), rs.failure()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   RetryBackoffSpec(ContextView retryContext, long max, Predicate<? super Throwable> aThrowablePredicate, boolean isTransientErrors, Duration minBackoff, Duration maxBackoff, double jitterFactor, Supplier<Scheduler> backoffSchedulerSupplier, Consumer<Retry.RetrySignal> doPreRetry, Consumer<Retry.RetrySignal> doPostRetry, BiFunction<Retry.RetrySignal, Mono<Void>, Mono<Void>> asyncPreRetry, BiFunction<Retry.RetrySignal, Mono<Void>, Mono<Void>> asyncPostRetry, BiFunction<RetryBackoffSpec, Retry.RetrySignal, Throwable> retryExhaustedGenerator) {
/* 139 */     super(retryContext);
/* 140 */     this.maxAttempts = max;
/* 141 */     this.errorFilter = aThrowablePredicate::test;
/* 142 */     this.isTransientErrors = isTransientErrors;
/* 143 */     this.minBackoff = minBackoff;
/* 144 */     this.maxBackoff = maxBackoff;
/* 145 */     this.jitterFactor = jitterFactor;
/* 146 */     this.backoffSchedulerSupplier = backoffSchedulerSupplier;
/* 147 */     this.syncPreRetry = doPreRetry;
/* 148 */     this.syncPostRetry = doPostRetry;
/* 149 */     this.asyncPreRetry = asyncPreRetry;
/* 150 */     this.asyncPostRetry = asyncPostRetry;
/* 151 */     this.retryExhaustedGenerator = retryExhaustedGenerator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RetryBackoffSpec withRetryContext(ContextView retryContext) {
/* 161 */     return new RetryBackoffSpec(retryContext, this.maxAttempts, this.errorFilter, this.isTransientErrors, this.minBackoff, this.maxBackoff, this.jitterFactor, this.backoffSchedulerSupplier, this.syncPreRetry, this.syncPostRetry, this.asyncPreRetry, this.asyncPostRetry, this.retryExhaustedGenerator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RetryBackoffSpec maxAttempts(long maxAttempts) {
/* 186 */     return new RetryBackoffSpec(this.retryContext, maxAttempts, this.errorFilter, this.isTransientErrors, this.minBackoff, this.maxBackoff, this.jitterFactor, this.backoffSchedulerSupplier, this.syncPreRetry, this.syncPostRetry, this.asyncPreRetry, this.asyncPostRetry, this.retryExhaustedGenerator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RetryBackoffSpec filter(Predicate<? super Throwable> errorFilter) {
/* 211 */     return new RetryBackoffSpec(this.retryContext, this.maxAttempts, 
/*     */ 
/*     */         
/* 214 */         Objects.<Predicate<? super Throwable>>requireNonNull(errorFilter, "errorFilter"), this.isTransientErrors, this.minBackoff, this.maxBackoff, this.jitterFactor, this.backoffSchedulerSupplier, this.syncPreRetry, this.syncPostRetry, this.asyncPreRetry, this.asyncPostRetry, this.retryExhaustedGenerator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RetryBackoffSpec modifyErrorFilter(Function<Predicate<Throwable>, Predicate<? super Throwable>> predicateAdjuster) {
/* 248 */     Objects.requireNonNull(predicateAdjuster, "predicateAdjuster");
/* 249 */     Predicate<? super Throwable> newPredicate = Objects.<Predicate<? super Throwable>>requireNonNull(predicateAdjuster.apply(this.errorFilter), "predicateAdjuster must return a new predicate");
/*     */     
/* 251 */     return new RetryBackoffSpec(this.retryContext, this.maxAttempts, newPredicate, this.isTransientErrors, this.minBackoff, this.maxBackoff, this.jitterFactor, this.backoffSchedulerSupplier, this.syncPreRetry, this.syncPostRetry, this.asyncPreRetry, this.asyncPostRetry, this.retryExhaustedGenerator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RetryBackoffSpec doBeforeRetry(Consumer<Retry.RetrySignal> doBeforeRetry) {
/* 278 */     return new RetryBackoffSpec(this.retryContext, this.maxAttempts, this.errorFilter, this.isTransientErrors, this.minBackoff, this.maxBackoff, this.jitterFactor, this.backoffSchedulerSupplier, this.syncPreRetry
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 287 */         .andThen(doBeforeRetry), this.syncPostRetry, this.asyncPreRetry, this.asyncPostRetry, this.retryExhaustedGenerator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RetryBackoffSpec doAfterRetry(Consumer<Retry.RetrySignal> doAfterRetry) {
/* 304 */     return new RetryBackoffSpec(this.retryContext, this.maxAttempts, this.errorFilter, this.isTransientErrors, this.minBackoff, this.maxBackoff, this.jitterFactor, this.backoffSchedulerSupplier, this.syncPreRetry, this.syncPostRetry
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 314 */         .andThen(doAfterRetry), this.asyncPreRetry, this.asyncPostRetry, this.retryExhaustedGenerator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RetryBackoffSpec doBeforeRetryAsync(Function<Retry.RetrySignal, Mono<Void>> doAsyncBeforeRetry) {
/* 329 */     return new RetryBackoffSpec(this.retryContext, this.maxAttempts, this.errorFilter, this.isTransientErrors, this.minBackoff, this.maxBackoff, this.jitterFactor, this.backoffSchedulerSupplier, this.syncPreRetry, this.syncPostRetry, (rs, m) -> ((Mono)this.asyncPreRetry.apply(rs, m)).then(doAsyncBeforeRetry.apply(rs)), this.asyncPostRetry, this.retryExhaustedGenerator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RetryBackoffSpec doAfterRetryAsync(Function<Retry.RetrySignal, Mono<Void>> doAsyncAfterRetry) {
/* 354 */     return new RetryBackoffSpec(this.retryContext, this.maxAttempts, this.errorFilter, this.isTransientErrors, this.minBackoff, this.maxBackoff, this.jitterFactor, this.backoffSchedulerSupplier, this.syncPreRetry, this.syncPostRetry, this.asyncPreRetry, (rs, m) -> ((Mono)this.asyncPostRetry.apply(rs, m)).then(doAsyncAfterRetry.apply(rs)), this.retryExhaustedGenerator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RetryBackoffSpec onRetryExhaustedThrow(BiFunction<RetryBackoffSpec, Retry.RetrySignal, Throwable> retryExhaustedGenerator) {
/* 384 */     return new RetryBackoffSpec(this.retryContext, this.maxAttempts, this.errorFilter, this.isTransientErrors, this.minBackoff, this.maxBackoff, this.jitterFactor, this.backoffSchedulerSupplier, this.syncPreRetry, this.syncPostRetry, this.asyncPreRetry, this.asyncPostRetry, 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 397 */         Objects.<BiFunction<RetryBackoffSpec, Retry.RetrySignal, Throwable>>requireNonNull(retryExhaustedGenerator, "retryExhaustedGenerator"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RetryBackoffSpec transientErrors(boolean isTransientErrors) {
/* 414 */     return new RetryBackoffSpec(this.retryContext, this.maxAttempts, this.errorFilter, isTransientErrors, this.minBackoff, this.maxBackoff, this.jitterFactor, this.backoffSchedulerSupplier, this.syncPreRetry, this.syncPostRetry, this.asyncPreRetry, this.asyncPostRetry, this.retryExhaustedGenerator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RetryBackoffSpec minBackoff(Duration minBackoff) {
/* 439 */     return new RetryBackoffSpec(this.retryContext, this.maxAttempts, this.errorFilter, this.isTransientErrors, minBackoff, this.maxBackoff, this.jitterFactor, this.backoffSchedulerSupplier, this.syncPreRetry, this.syncPostRetry, this.asyncPreRetry, this.asyncPostRetry, this.retryExhaustedGenerator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RetryBackoffSpec maxBackoff(Duration maxBackoff) {
/* 464 */     return new RetryBackoffSpec(this.retryContext, this.maxAttempts, this.errorFilter, this.isTransientErrors, this.minBackoff, maxBackoff, this.jitterFactor, this.backoffSchedulerSupplier, this.syncPreRetry, this.syncPostRetry, this.asyncPreRetry, this.asyncPostRetry, this.retryExhaustedGenerator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RetryBackoffSpec jitter(double jitterFactor) {
/* 490 */     return new RetryBackoffSpec(this.retryContext, this.maxAttempts, this.errorFilter, this.isTransientErrors, this.minBackoff, this.maxBackoff, jitterFactor, this.backoffSchedulerSupplier, this.syncPreRetry, this.syncPostRetry, this.asyncPreRetry, this.asyncPostRetry, this.retryExhaustedGenerator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RetryBackoffSpec scheduler(@Nullable Scheduler backoffScheduler) {
/* 515 */     return new RetryBackoffSpec(this.retryContext, this.maxAttempts, this.errorFilter, this.isTransientErrors, this.minBackoff, this.maxBackoff, this.jitterFactor, (backoffScheduler == null) ? Schedulers::parallel : (() -> backoffScheduler), this.syncPreRetry, this.syncPostRetry, this.asyncPreRetry, this.asyncPostRetry, this.retryExhaustedGenerator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void validateArguments() {
/* 536 */     if (this.jitterFactor < 0.0D || this.jitterFactor > 1.0D) throw new IllegalArgumentException("jitterFactor must be between 0 and 1 (default 0.5)");
/*     */   
/*     */   }
/*     */   
/*     */   public Flux<Long> generateCompanion(Flux<Retry.RetrySignal> t) {
/* 541 */     validateArguments();
/* 542 */     return t.concatMap(retryWhenState -> {
/*     */           Duration nextBackoff;
/*     */           
/*     */           long jitterOffset;
/*     */           
/*     */           long jitter;
/*     */           
/*     */           Retry.RetrySignal copy = retryWhenState.copy();
/*     */           
/*     */           Throwable currentFailure = copy.failure();
/*     */           long iteration = this.isTransientErrors ? copy.totalRetriesInARow() : copy.totalRetries();
/*     */           if (currentFailure == null) {
/*     */             return (Publisher)Mono.error(new IllegalStateException("Retry.RetrySignal#failure() not expected to be null"));
/*     */           }
/*     */           if (!this.errorFilter.test(currentFailure)) {
/*     */             return (Publisher)Mono.error(currentFailure);
/*     */           }
/*     */           if (iteration >= this.maxAttempts) {
/*     */             return (Publisher)Mono.error(this.retryExhaustedGenerator.apply(this, copy));
/*     */           }
/*     */           try {
/*     */             nextBackoff = this.minBackoff.multipliedBy((long)Math.pow(2.0D, iteration));
/*     */             if (nextBackoff.compareTo(this.maxBackoff) > 0) {
/*     */               nextBackoff = this.maxBackoff;
/*     */             }
/* 567 */           } catch (ArithmeticException overflow) {
/*     */             nextBackoff = this.maxBackoff;
/*     */           } 
/*     */ 
/*     */ 
/*     */           
/*     */           if (nextBackoff.isZero()) {
/*     */             return (Publisher)RetrySpec.applyHooks(copy, Mono.just(Long.valueOf(iteration)), this.syncPreRetry, this.syncPostRetry, this.asyncPreRetry, this.asyncPostRetry);
/*     */           }
/*     */ 
/*     */ 
/*     */           
/*     */           ThreadLocalRandom random = ThreadLocalRandom.current();
/*     */ 
/*     */ 
/*     */           
/*     */           try {
/*     */             jitterOffset = nextBackoff.multipliedBy((long)(100.0D * this.jitterFactor)).dividedBy(100L).toMillis();
/* 585 */           } catch (ArithmeticException ae) {
/*     */             jitterOffset = Math.round(9.223372036854776E18D * this.jitterFactor);
/*     */           } 
/*     */           long lowBound = Math.max(this.minBackoff.minus(nextBackoff).toMillis(), -jitterOffset);
/*     */           long highBound = Math.min(this.maxBackoff.minus(nextBackoff).toMillis(), jitterOffset);
/*     */           if (highBound == lowBound) {
/*     */             if (highBound == 0L) {
/*     */               jitter = 0L;
/*     */             } else {
/*     */               jitter = random.nextLong(highBound);
/*     */             } 
/*     */           } else {
/*     */             jitter = random.nextLong(lowBound, highBound);
/*     */           } 
/*     */           Duration effectiveBackoff = nextBackoff.plusMillis(jitter);
/*     */           return (Publisher)RetrySpec.applyHooks(copy, Mono.delay(effectiveBackoff, this.backoffSchedulerSupplier.get()), this.syncPreRetry, this.syncPostRetry, this.asyncPreRetry, this.asyncPostRetry);
/*     */         });
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reacto\\util\retry\RetryBackoffSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */