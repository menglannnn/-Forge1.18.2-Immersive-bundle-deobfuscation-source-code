/*     */ package reactor.util;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.util.HashMap;
/*     */ import java.util.function.Function;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import java.util.regex.Matcher;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Loggers
/*     */ {
/*     */   public static final String FALLBACK_PROPERTY = "reactor.logging.fallback";
/*     */   private static Function<String, ? extends Logger> LOGGER_FACTORY;
/*     */   
/*     */   static {
/*  53 */     resetLoggerFactory();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void resetLoggerFactory() {
/*     */     try {
/*  69 */       useSl4jLoggers();
/*     */     }
/*  71 */     catch (Throwable t) {
/*  72 */       if (isFallbackToJdk()) {
/*  73 */         useJdkLoggers();
/*     */       } else {
/*     */         
/*  76 */         useConsoleLoggers();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean isFallbackToJdk() {
/*  89 */     return "JDK".equalsIgnoreCase(System.getProperty("reactor.logging.fallback"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void useConsoleLoggers() {
/* 103 */     String name = Loggers.class.getName();
/* 104 */     Function<String, Logger> loggerFactory = new ConsoleLoggerFactory(false);
/* 105 */     LOGGER_FACTORY = loggerFactory;
/* 106 */     ((Logger)loggerFactory.apply(name)).debug("Using Console logging");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void useVerboseConsoleLoggers() {
/* 119 */     String name = Loggers.class.getName();
/* 120 */     Function<String, Logger> loggerFactory = new ConsoleLoggerFactory(true);
/* 121 */     LOGGER_FACTORY = loggerFactory;
/* 122 */     ((Logger)loggerFactory.apply(name)).debug("Using Verbose Console logging");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void useCustomLoggers(Function<String, ? extends Logger> loggerFactory) {
/* 136 */     String name = Loggers.class.getName();
/* 137 */     LOGGER_FACTORY = loggerFactory;
/* 138 */     ((Logger)loggerFactory.apply(name)).debug("Using custom logging");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void useJdkLoggers() {
/* 149 */     String name = Loggers.class.getName();
/* 150 */     Function<String, Logger> loggerFactory = new JdkLoggerFactory();
/* 151 */     LOGGER_FACTORY = loggerFactory;
/* 152 */     ((Logger)loggerFactory.apply(name)).debug("Using JDK logging framework");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void useSl4jLoggers() {
/* 164 */     String name = Loggers.class.getName();
/* 165 */     Function<String, Logger> loggerFactory = new Slf4JLoggerFactory();
/* 166 */     LOGGER_FACTORY = loggerFactory;
/* 167 */     ((Logger)loggerFactory.apply(name)).debug("Using Slf4j logging framework");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Logger getLogger(String name) {
/* 182 */     return LOGGER_FACTORY.apply(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Logger getLogger(Class<?> cls) {
/* 194 */     return LOGGER_FACTORY.apply(cls.getName());
/*     */   }
/*     */   
/*     */   private static class Slf4JLoggerFactory implements Function<String, Logger> {
/*     */     private Slf4JLoggerFactory() {}
/*     */     
/*     */     public Logger apply(String name) {
/* 201 */       return new Loggers.Slf4JLogger(LoggerFactory.getLogger(name));
/*     */     }
/*     */   }
/*     */   
/*     */   private static class Slf4JLogger
/*     */     implements Logger {
/*     */     private final Logger logger;
/*     */     
/*     */     public Slf4JLogger(Logger logger) {
/* 210 */       this.logger = logger;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getName() {
/* 215 */       return this.logger.getName();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isTraceEnabled() {
/* 220 */       return this.logger.isTraceEnabled();
/*     */     }
/*     */ 
/*     */     
/*     */     public void trace(String msg) {
/* 225 */       this.logger.trace(msg);
/*     */     }
/*     */ 
/*     */     
/*     */     public void trace(String format, Object... arguments) {
/* 230 */       this.logger.trace(format, arguments);
/*     */     }
/*     */ 
/*     */     
/*     */     public void trace(String msg, Throwable t) {
/* 235 */       this.logger.trace(msg, t);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isDebugEnabled() {
/* 240 */       return this.logger.isDebugEnabled();
/*     */     }
/*     */ 
/*     */     
/*     */     public void debug(String msg) {
/* 245 */       this.logger.debug(msg);
/*     */     }
/*     */ 
/*     */     
/*     */     public void debug(String format, Object... arguments) {
/* 250 */       this.logger.debug(format, arguments);
/*     */     }
/*     */ 
/*     */     
/*     */     public void debug(String msg, Throwable t) {
/* 255 */       this.logger.debug(msg, t);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isInfoEnabled() {
/* 260 */       return this.logger.isInfoEnabled();
/*     */     }
/*     */ 
/*     */     
/*     */     public void info(String msg) {
/* 265 */       this.logger.info(msg);
/*     */     }
/*     */ 
/*     */     
/*     */     public void info(String format, Object... arguments) {
/* 270 */       this.logger.info(format, arguments);
/*     */     }
/*     */ 
/*     */     
/*     */     public void info(String msg, Throwable t) {
/* 275 */       this.logger.info(msg, t);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isWarnEnabled() {
/* 280 */       return this.logger.isWarnEnabled();
/*     */     }
/*     */ 
/*     */     
/*     */     public void warn(String msg) {
/* 285 */       this.logger.warn(msg);
/*     */     }
/*     */ 
/*     */     
/*     */     public void warn(String format, Object... arguments) {
/* 290 */       this.logger.warn(format, arguments);
/*     */     }
/*     */ 
/*     */     
/*     */     public void warn(String msg, Throwable t) {
/* 295 */       this.logger.warn(msg, t);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isErrorEnabled() {
/* 300 */       return this.logger.isErrorEnabled();
/*     */     }
/*     */ 
/*     */     
/*     */     public void error(String msg) {
/* 305 */       this.logger.error(msg);
/*     */     }
/*     */ 
/*     */     
/*     */     public void error(String format, Object... arguments) {
/* 310 */       this.logger.error(format, arguments);
/*     */     }
/*     */ 
/*     */     
/*     */     public void error(String msg, Throwable t) {
/* 315 */       this.logger.error(msg, t);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class JdkLogger
/*     */     implements Logger
/*     */   {
/*     */     private final Logger logger;
/*     */ 
/*     */     
/*     */     public JdkLogger(Logger logger) {
/* 327 */       this.logger = logger;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getName() {
/* 332 */       return this.logger.getName();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isTraceEnabled() {
/* 337 */       return this.logger.isLoggable(Level.FINEST);
/*     */     }
/*     */ 
/*     */     
/*     */     public void trace(String msg) {
/* 342 */       this.logger.log(Level.FINEST, msg);
/*     */     }
/*     */ 
/*     */     
/*     */     public void trace(String format, Object... arguments) {
/* 347 */       this.logger.log(Level.FINEST, format(format, arguments));
/*     */     }
/*     */ 
/*     */     
/*     */     public void trace(String msg, Throwable t) {
/* 352 */       this.logger.log(Level.FINEST, msg, t);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isDebugEnabled() {
/* 357 */       return this.logger.isLoggable(Level.FINE);
/*     */     }
/*     */ 
/*     */     
/*     */     public void debug(String msg) {
/* 362 */       this.logger.log(Level.FINE, msg);
/*     */     }
/*     */ 
/*     */     
/*     */     public void debug(String format, Object... arguments) {
/* 367 */       this.logger.log(Level.FINE, format(format, arguments));
/*     */     }
/*     */ 
/*     */     
/*     */     public void debug(String msg, Throwable t) {
/* 372 */       this.logger.log(Level.FINE, msg, t);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isInfoEnabled() {
/* 377 */       return this.logger.isLoggable(Level.INFO);
/*     */     }
/*     */ 
/*     */     
/*     */     public void info(String msg) {
/* 382 */       this.logger.log(Level.INFO, msg);
/*     */     }
/*     */ 
/*     */     
/*     */     public void info(String format, Object... arguments) {
/* 387 */       this.logger.log(Level.INFO, format(format, arguments));
/*     */     }
/*     */ 
/*     */     
/*     */     public void info(String msg, Throwable t) {
/* 392 */       this.logger.log(Level.INFO, msg, t);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isWarnEnabled() {
/* 397 */       return this.logger.isLoggable(Level.WARNING);
/*     */     }
/*     */ 
/*     */     
/*     */     public void warn(String msg) {
/* 402 */       this.logger.log(Level.WARNING, msg);
/*     */     }
/*     */ 
/*     */     
/*     */     public void warn(String format, Object... arguments) {
/* 407 */       this.logger.log(Level.WARNING, format(format, arguments));
/*     */     }
/*     */ 
/*     */     
/*     */     public void warn(String msg, Throwable t) {
/* 412 */       this.logger.log(Level.WARNING, msg, t);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isErrorEnabled() {
/* 417 */       return this.logger.isLoggable(Level.SEVERE);
/*     */     }
/*     */ 
/*     */     
/*     */     public void error(String msg) {
/* 422 */       this.logger.log(Level.SEVERE, msg);
/*     */     }
/*     */ 
/*     */     
/*     */     public void error(String format, Object... arguments) {
/* 427 */       this.logger.log(Level.SEVERE, format(format, arguments));
/*     */     }
/*     */ 
/*     */     
/*     */     public void error(String msg, Throwable t) {
/* 432 */       this.logger.log(Level.SEVERE, msg, t);
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     final String format(@Nullable String from, @Nullable Object... arguments) {
/* 437 */       if (from != null) {
/* 438 */         String computed = from;
/* 439 */         if (arguments != null && arguments.length != 0) {
/* 440 */           for (Object argument : arguments) {
/* 441 */             computed = computed.replaceFirst("\\{\\}", Matcher.quoteReplacement(String.valueOf(argument)));
/*     */           }
/*     */         }
/* 444 */         return computed;
/*     */       } 
/* 446 */       return null;
/*     */     }
/*     */   }
/*     */   
/*     */   private static class JdkLoggerFactory implements Function<String, Logger> {
/*     */     private JdkLoggerFactory() {}
/*     */     
/*     */     public Logger apply(String name) {
/* 454 */       return new Loggers.JdkLogger(Logger.getLogger(name));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class ConsoleLogger
/*     */     implements Logger
/*     */   {
/*     */     private final String name;
/*     */     
/*     */     private final PrintStream err;
/*     */     
/*     */     private final PrintStream log;
/*     */     private final boolean verbose;
/*     */     
/*     */     ConsoleLogger(String name, PrintStream log, PrintStream err, boolean verbose) {
/* 470 */       this.name = name;
/* 471 */       this.log = log;
/* 472 */       this.err = err;
/* 473 */       this.verbose = verbose;
/*     */     }
/*     */     
/*     */     ConsoleLogger(String name, boolean verbose) {
/* 477 */       this(name, System.out, System.err, verbose);
/*     */     }
/*     */ 
/*     */     
/*     */     public String getName() {
/* 482 */       return this.name;
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     final String format(@Nullable String from, @Nullable Object... arguments) {
/* 487 */       if (from != null) {
/* 488 */         String computed = from;
/* 489 */         if (arguments != null && arguments.length != 0) {
/* 490 */           for (Object argument : arguments) {
/* 491 */             computed = computed.replaceFirst("\\{\\}", Matcher.quoteReplacement(String.valueOf(argument)));
/*     */           }
/*     */         }
/* 494 */         return computed;
/*     */       } 
/* 496 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isTraceEnabled() {
/* 501 */       return this.verbose;
/*     */     }
/*     */ 
/*     */     
/*     */     public synchronized void trace(String msg) {
/* 506 */       if (!this.verbose) {
/*     */         return;
/*     */       }
/* 509 */       this.log.format("[TRACE] (%s) %s\n", new Object[] { Thread.currentThread().getName(), msg });
/*     */     }
/*     */ 
/*     */     
/*     */     public synchronized void trace(String format, Object... arguments) {
/* 514 */       if (!this.verbose) {
/*     */         return;
/*     */       }
/* 517 */       this.log.format("[TRACE] (%s) %s\n", new Object[] { Thread.currentThread().getName(), format(format, arguments) });
/*     */     }
/*     */     
/*     */     public synchronized void trace(String msg, Throwable t) {
/* 521 */       if (!this.verbose) {
/*     */         return;
/*     */       }
/* 524 */       this.log.format("[TRACE] (%s) %s - %s\n", new Object[] { Thread.currentThread().getName(), msg, t });
/* 525 */       t.printStackTrace(this.log);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isDebugEnabled() {
/* 530 */       return this.verbose;
/*     */     }
/*     */ 
/*     */     
/*     */     public synchronized void debug(String msg) {
/* 535 */       if (!this.verbose) {
/*     */         return;
/*     */       }
/* 538 */       this.log.format("[DEBUG] (%s) %s\n", new Object[] { Thread.currentThread().getName(), msg });
/*     */     }
/*     */ 
/*     */     
/*     */     public synchronized void debug(String format, Object... arguments) {
/* 543 */       if (!this.verbose) {
/*     */         return;
/*     */       }
/* 546 */       this.log.format("[DEBUG] (%s) %s\n", new Object[] { Thread.currentThread().getName(), format(format, arguments) });
/*     */     }
/*     */ 
/*     */     
/*     */     public synchronized void debug(String msg, Throwable t) {
/* 551 */       if (!this.verbose) {
/*     */         return;
/*     */       }
/* 554 */       this.log.format("[DEBUG] (%s) %s - %s\n", new Object[] { Thread.currentThread().getName(), msg, t });
/* 555 */       t.printStackTrace(this.log);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isInfoEnabled() {
/* 560 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     public synchronized void info(String msg) {
/* 565 */       this.log.format("[ INFO] (%s) %s\n", new Object[] { Thread.currentThread().getName(), msg });
/*     */     }
/*     */ 
/*     */     
/*     */     public synchronized void info(String format, Object... arguments) {
/* 570 */       this.log.format("[ INFO] (%s) %s\n", new Object[] { Thread.currentThread().getName(), format(format, arguments) });
/*     */     }
/*     */ 
/*     */     
/*     */     public synchronized void info(String msg, Throwable t) {
/* 575 */       this.log.format("[ INFO] (%s) %s - %s\n", new Object[] { Thread.currentThread().getName(), msg, t });
/* 576 */       t.printStackTrace(this.log);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isWarnEnabled() {
/* 581 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     public synchronized void warn(String msg) {
/* 586 */       this.err.format("[ WARN] (%s) %s\n", new Object[] { Thread.currentThread().getName(), msg });
/*     */     }
/*     */ 
/*     */     
/*     */     public synchronized void warn(String format, Object... arguments) {
/* 591 */       this.err.format("[ WARN] (%s) %s\n", new Object[] { Thread.currentThread().getName(), format(format, arguments) });
/*     */     }
/*     */ 
/*     */     
/*     */     public synchronized void warn(String msg, Throwable t) {
/* 596 */       this.err.format("[ WARN] (%s) %s - %s\n", new Object[] { Thread.currentThread().getName(), msg, t });
/* 597 */       t.printStackTrace(this.err);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isErrorEnabled() {
/* 602 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     public synchronized void error(String msg) {
/* 607 */       this.err.format("[ERROR] (%s) %s\n", new Object[] { Thread.currentThread().getName(), msg });
/*     */     }
/*     */ 
/*     */     
/*     */     public synchronized void error(String format, Object... arguments) {
/* 612 */       this.err.format("[ERROR] (%s) %s\n", new Object[] { Thread.currentThread().getName(), format(format, arguments) });
/*     */     }
/*     */ 
/*     */     
/*     */     public synchronized void error(String msg, Throwable t) {
/* 617 */       this.err.format("[ERROR] (%s) %s - %s\n", new Object[] { Thread.currentThread().getName(), msg, t });
/* 618 */       t.printStackTrace(this.err);
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class ConsoleLoggerFactory
/*     */     implements Function<String, Logger> {
/* 624 */     private static final HashMap<String, Logger> consoleLoggers = new HashMap<>();
/*     */     
/*     */     final boolean verbose;
/*     */     
/*     */     private ConsoleLoggerFactory(boolean verbose) {
/* 629 */       this.verbose = verbose;
/*     */     }
/*     */ 
/*     */     
/*     */     public Logger apply(String name) {
/* 634 */       return consoleLoggers.computeIfAbsent(name, n -> new Loggers.ConsoleLogger(n, this.verbose));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reacto\\util\Loggers.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */