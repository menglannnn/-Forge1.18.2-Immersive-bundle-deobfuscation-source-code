/*     */ package reactor.util.concurrent;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.Objects;
/*     */ import java.util.Queue;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class SpscArrayQueue<T>
/*     */   extends SpscArrayQueueP3<T>
/*     */   implements Queue<T>
/*     */ {
/*     */   private static final long serialVersionUID = 494623116936946976L;
/*     */   
/*     */   SpscArrayQueue(int capacity) {
/*  46 */     super(Queues.ceilingNextPowerOfTwo(capacity));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean offer(T e) {
/*  51 */     Objects.requireNonNull(e, "e");
/*  52 */     long pi = this.producerIndex;
/*  53 */     int offset = (int)pi & this.mask;
/*  54 */     if (get(offset) != null) {
/*  55 */       return false;
/*     */     }
/*  57 */     lazySet(offset, e);
/*  58 */     PRODUCER_INDEX.lazySet(this, pi + 1L);
/*  59 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public T poll() {
/*  65 */     long ci = this.consumerIndex;
/*  66 */     int offset = (int)ci & this.mask;
/*     */     
/*  68 */     T v = get(offset);
/*  69 */     if (v != null) {
/*  70 */       lazySet(offset, null);
/*  71 */       CONSUMER_INDEX.lazySet(this, ci + 1L);
/*     */     } 
/*  73 */     return v;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public T peek() {
/*  79 */     int offset = (int)this.consumerIndex & this.mask;
/*  80 */     return get(offset);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/*  85 */     return (this.producerIndex == this.consumerIndex);
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/*  90 */     while (poll() != null && !isEmpty());
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/*  95 */     long ci = this.consumerIndex;
/*     */     while (true) {
/*  97 */       long pi = this.producerIndex;
/*  98 */       long ci2 = this.consumerIndex;
/*  99 */       if (ci == ci2) {
/* 100 */         return (int)(pi - ci);
/*     */       }
/* 102 */       ci = ci2;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean contains(Object o) {
/* 108 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<T> iterator() {
/* 113 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object[] toArray() {
/* 118 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public <R> R[] toArray(R[] a) {
/* 123 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean remove(Object o) {
/* 128 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsAll(Collection<?> c) {
/* 133 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean addAll(Collection<? extends T> c) {
/* 138 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean removeAll(Collection<?> c) {
/* 143 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean retainAll(Collection<?> c) {
/* 148 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean add(T e) {
/* 153 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public T remove() {
/* 158 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public T element() {
/* 163 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reacto\\util\concurrent\SpscArrayQueue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */