/*     */ package reactor.util.concurrent;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Objects;
/*     */ import java.util.Queue;
/*     */ import java.util.concurrent.BlockingQueue;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ import java.util.function.Supplier;
/*     */ import reactor.core.publisher.Hooks;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Queues
/*     */ {
/*     */   public static final int CAPACITY_UNSURE = -2147483648;
/*     */   
/*     */   public static final int capacity(Queue q) {
/*  54 */     if (q instanceof ZeroQueue) {
/*  55 */       return 0;
/*     */     }
/*  57 */     if (q instanceof OneQueue) {
/*  58 */       return 1;
/*     */     }
/*  60 */     if (q instanceof SpscLinkedArrayQueue) {
/*  61 */       return Integer.MAX_VALUE;
/*     */     }
/*  63 */     if (q instanceof SpscArrayQueue) {
/*  64 */       return ((SpscArrayQueue)q).length();
/*     */     }
/*  66 */     if (q instanceof MpscLinkedQueue) {
/*  67 */       return Integer.MAX_VALUE;
/*     */     }
/*  69 */     if (q instanceof BlockingQueue) {
/*  70 */       return ((BlockingQueue)q).remainingCapacity();
/*     */     }
/*  72 */     if (q instanceof java.util.concurrent.ConcurrentLinkedQueue) {
/*  73 */       return Integer.MAX_VALUE;
/*     */     }
/*     */     
/*  76 */     return Integer.MIN_VALUE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  84 */   public static final int XS_BUFFER_SIZE = Math.max(8, 
/*  85 */       Integer.parseInt(System.getProperty("reactor.bufferSize.x", "32")));
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  90 */   public static final int SMALL_BUFFER_SIZE = Math.max(16, 
/*  91 */       Integer.parseInt(System.getProperty("reactor.bufferSize.small", "256")));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int ceilingNextPowerOfTwo(int x) {
/* 102 */     return 1 << 32 - Integer.numberOfLeadingZeros(x - 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Supplier<Queue<T>> get(int batchSize) {
/* 113 */     if (batchSize == Integer.MAX_VALUE) {
/* 114 */       return SMALL_UNBOUNDED;
/*     */     }
/* 116 */     if (batchSize == XS_BUFFER_SIZE) {
/* 117 */       return XS_SUPPLIER;
/*     */     }
/* 119 */     if (batchSize == SMALL_BUFFER_SIZE) {
/* 120 */       return SMALL_SUPPLIER;
/*     */     }
/* 122 */     if (batchSize == 1) {
/* 123 */       return ONE_SUPPLIER;
/*     */     }
/* 125 */     if (batchSize == 0) {
/* 126 */       return ZERO_SUPPLIER;
/*     */     }
/*     */     
/* 129 */     int adjustedBatchSize = Math.max(8, batchSize);
/* 130 */     if (adjustedBatchSize > 10000000) {
/* 131 */       return SMALL_UNBOUNDED;
/*     */     }
/*     */     
/* 134 */     return () -> Hooks.wrapQueue(new SpscArrayQueue(adjustedBatchSize));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isPowerOfTwo(int x) {
/* 144 */     return (Integer.bitCount(x) == 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Supplier<Queue<T>> empty() {
/* 157 */     return ZERO_SUPPLIER;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Supplier<Queue<T>> one() {
/* 167 */     return ONE_SUPPLIER;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Supplier<Queue<T>> small() {
/* 177 */     return SMALL_SUPPLIER;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Supplier<Queue<T>> unbounded() {
/* 187 */     return SMALL_UNBOUNDED;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Supplier<Queue<T>> unbounded(int linkSize) {
/* 199 */     if (linkSize == XS_BUFFER_SIZE) {
/* 200 */       return XS_UNBOUNDED;
/*     */     }
/* 202 */     if (linkSize == Integer.MAX_VALUE || linkSize == SMALL_BUFFER_SIZE) {
/* 203 */       return unbounded();
/*     */     }
/* 205 */     return () -> Hooks.wrapQueue(new SpscLinkedArrayQueue(linkSize));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Supplier<Queue<T>> xs() {
/* 215 */     return XS_SUPPLIER;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Supplier<Queue<T>> unboundedMultiproducer() {
/* 226 */     return () -> Hooks.wrapQueue(new MpscLinkedQueue());
/*     */   }
/*     */ 
/*     */   
/*     */   static final class OneQueue<T>
/*     */     extends AtomicReference<T>
/*     */     implements Queue<T>
/*     */   {
/*     */     private static final long serialVersionUID = -6079491923525372331L;
/*     */     
/*     */     public boolean add(T t) {
/* 237 */       while (!offer(t));
/*     */       
/* 239 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean addAll(Collection<? extends T> c) {
/* 244 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public void clear() {
/* 249 */       set(null);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean contains(Object o) {
/* 254 */       return Objects.equals(get(), o);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean containsAll(Collection<?> c) {
/* 259 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public T element() {
/* 264 */       return get();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isEmpty() {
/* 269 */       return (get() == null);
/*     */     }
/*     */ 
/*     */     
/*     */     public Iterator<T> iterator() {
/* 274 */       return new Queues.QueueIterator<>(this);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean offer(T t) {
/* 279 */       if (get() != null) {
/* 280 */         return false;
/*     */       }
/* 282 */       lazySet(t);
/* 283 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public T peek() {
/* 289 */       return get();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public T poll() {
/* 295 */       T v = get();
/* 296 */       if (v != null) {
/* 297 */         lazySet(null);
/*     */       }
/* 299 */       return v;
/*     */     }
/*     */ 
/*     */     
/*     */     public T remove() {
/* 304 */       return getAndSet(null);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean remove(Object o) {
/* 309 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean removeAll(Collection<?> c) {
/* 314 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean retainAll(Collection<?> c) {
/* 319 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 324 */       return (get() == null) ? 0 : 1;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object[] toArray() {
/* 329 */       T t = get();
/* 330 */       if (t == null) {
/* 331 */         return new Object[0];
/*     */       }
/* 333 */       return new Object[] { t };
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public <T1> T1[] toArray(T1[] a) {
/* 339 */       int size = size();
/* 340 */       if (a.length < size) {
/* 341 */         a = (T1[])Array.newInstance(a
/* 342 */             .getClass().getComponentType(), size);
/*     */       }
/* 344 */       if (size == 1) {
/* 345 */         a[0] = (T1)get();
/*     */       }
/* 347 */       if (a.length > size) {
/* 348 */         a[size] = null;
/*     */       }
/* 350 */       return a;
/*     */     }
/*     */   }
/*     */   
/*     */   static final class ZeroQueue<T>
/*     */     implements Queue<T>, Serializable
/*     */   {
/*     */     private static final long serialVersionUID = -8876883675795156827L;
/*     */     
/*     */     public boolean add(T t) {
/* 360 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean addAll(Collection<? extends T> c) {
/* 365 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void clear() {}
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean contains(Object o) {
/* 375 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean containsAll(Collection<?> c) {
/* 380 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public T element() {
/* 385 */       throw new NoSuchElementException("immutable empty queue");
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isEmpty() {
/* 390 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     public Iterator<T> iterator() {
/* 395 */       return Collections.emptyIterator();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean offer(T t) {
/* 400 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public T peek() {
/* 406 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public T poll() {
/* 412 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public T remove() {
/* 417 */       throw new NoSuchElementException("immutable empty queue");
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean remove(Object o) {
/* 422 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean removeAll(Collection<?> c) {
/* 427 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean retainAll(Collection<?> c) {
/* 432 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 437 */       return 0;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object[] toArray() {
/* 442 */       return new Object[0];
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public <T1> T1[] toArray(T1[] a) {
/* 448 */       if (a.length > 0) {
/* 449 */         a[0] = null;
/*     */       }
/* 451 */       return a;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class QueueIterator<T>
/*     */     implements Iterator<T>
/*     */   {
/*     */     final Queue<T> queue;
/*     */     
/*     */     public QueueIterator(Queue<T> queue) {
/* 462 */       this.queue = queue;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/* 467 */       return !this.queue.isEmpty();
/*     */     }
/*     */ 
/*     */     
/*     */     public T next() {
/* 472 */       return this.queue.poll();
/*     */     }
/*     */ 
/*     */     
/*     */     public void remove() {
/* 477 */       this.queue.remove();
/*     */     }
/*     */   }
/*     */   static final Supplier ZERO_SUPPLIER = () -> Hooks.wrapQueue(new ZeroQueue());
/*     */   static final Supplier ONE_SUPPLIER = () -> Hooks.wrapQueue(new OneQueue());
/*     */   static final Supplier XS_SUPPLIER = () -> Hooks.wrapQueue(new SpscArrayQueue(XS_BUFFER_SIZE));
/*     */   static final Supplier SMALL_SUPPLIER = () -> Hooks.wrapQueue(new SpscArrayQueue(SMALL_BUFFER_SIZE));
/*     */   static final Supplier SMALL_UNBOUNDED = () -> Hooks.wrapQueue(new SpscLinkedArrayQueue(SMALL_BUFFER_SIZE));
/*     */   static final Supplier XS_UNBOUNDED = () -> Hooks.wrapQueue(new SpscLinkedArrayQueue(XS_BUFFER_SIZE));
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reacto\\util\concurrent\Queues.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */