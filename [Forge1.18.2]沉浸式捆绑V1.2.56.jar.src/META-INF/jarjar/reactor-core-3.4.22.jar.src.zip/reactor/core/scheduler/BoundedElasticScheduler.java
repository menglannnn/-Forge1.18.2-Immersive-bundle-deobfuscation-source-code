/*     */ package reactor.core.scheduler;
/*     */ 
/*     */ import java.time.Clock;
/*     */ import java.time.Instant;
/*     */ import java.time.ZoneId;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Deque;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.ConcurrentLinkedDeque;
/*     */ import java.util.concurrent.ExecutionException;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.concurrent.ScheduledExecutorService;
/*     */ import java.util.concurrent.ScheduledFuture;
/*     */ import java.util.concurrent.ScheduledThreadPoolExecutor;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.TimeoutException;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.stream.Stream;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.Disposables;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.Loggers;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class BoundedElasticScheduler
/*     */   implements Scheduler, Scannable
/*     */ {
/*  69 */   static final Logger LOGGER = Loggers.getLogger(BoundedElasticScheduler.class);
/*     */   
/*     */   static final int DEFAULT_TTL_SECONDS = 60;
/*     */   
/*  73 */   static final AtomicLong EVICTOR_COUNTER = new AtomicLong();
/*     */   static {
/*  75 */     EVICTOR_FACTORY = (r -> {
/*     */         Thread t = new Thread(r, "boundedElastic-evictor-" + EVICTOR_COUNTER.incrementAndGet());
/*     */         t.setDaemon(true);
/*     */         return t;
/*     */       });
/*     */   }
/*     */ 
/*     */   
/*     */   static final ThreadFactory EVICTOR_FACTORY;
/*     */   
/*  85 */   static final BoundedServices SHUTDOWN = new BoundedServices(); static {
/*  86 */     SHUTDOWN.dispose();
/*  87 */     ScheduledExecutorService s = Executors.newSingleThreadScheduledExecutor();
/*  88 */     s.shutdownNow();
/*  89 */     CREATING = new BoundedState(SHUTDOWN, s)
/*     */       {
/*     */         public String toString() {
/*  92 */           return "CREATING BoundedState";
/*     */         }
/*     */       };
/*  95 */     CREATING.markCount = -1;
/*  96 */     CREATING.idleSinceTimestamp = -1L;
/*     */   }
/*     */ 
/*     */   
/*     */   static final BoundedState CREATING;
/*     */   
/*     */   final int maxThreads;
/*     */   final int maxTaskQueuedPerThread;
/*     */   final Clock clock;
/*     */   final ThreadFactory factory;
/*     */   final long ttlMillis;
/*     */   volatile BoundedServices boundedServices;
/* 108 */   static final AtomicReferenceFieldUpdater<BoundedElasticScheduler, BoundedServices> BOUNDED_SERVICES = AtomicReferenceFieldUpdater.newUpdater(BoundedElasticScheduler.class, BoundedServices.class, "boundedServices");
/*     */   
/*     */   volatile ScheduledExecutorService evictor;
/*     */   
/* 112 */   static final AtomicReferenceFieldUpdater<BoundedElasticScheduler, ScheduledExecutorService> EVICTOR = AtomicReferenceFieldUpdater.newUpdater(BoundedElasticScheduler.class, ScheduledExecutorService.class, "evictor");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   BoundedElasticScheduler(int maxThreads, int maxTaskQueuedPerThread, ThreadFactory threadFactory, long ttlMillis, Clock clock) {
/* 120 */     if (ttlMillis <= 0L) {
/* 121 */       throw new IllegalArgumentException("TTL must be strictly positive, was " + ttlMillis + "ms");
/*     */     }
/* 123 */     if (maxThreads <= 0) {
/* 124 */       throw new IllegalArgumentException("maxThreads must be strictly positive, was " + maxThreads);
/*     */     }
/* 126 */     if (maxTaskQueuedPerThread <= 0) {
/* 127 */       throw new IllegalArgumentException("maxTaskQueuedPerThread must be strictly positive, was " + maxTaskQueuedPerThread);
/*     */     }
/* 129 */     this.maxThreads = maxThreads;
/* 130 */     this.maxTaskQueuedPerThread = maxTaskQueuedPerThread;
/* 131 */     this.factory = threadFactory;
/* 132 */     this.clock = Objects.<Clock>requireNonNull(clock, "A Clock must be provided");
/* 133 */     this.ttlMillis = ttlMillis;
/*     */     
/* 135 */     this.boundedServices = SHUTDOWN;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   BoundedElasticScheduler(int maxThreads, int maxTaskQueuedPerThread, ThreadFactory factory, int ttlSeconds) {
/* 149 */     this(maxThreads, maxTaskQueuedPerThread, factory, ttlSeconds * 1000L, 
/* 150 */         Clock.tickSeconds(BoundedServices.ZONE_UTC));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   BoundedScheduledExecutorService createBoundedExecutorService() {
/* 158 */     return new BoundedScheduledExecutorService(this.maxTaskQueuedPerThread, this.factory);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDisposed() {
/* 163 */     return (BOUNDED_SERVICES.get(this) == SHUTDOWN);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void start() {
/*     */     // Byte code:
/*     */     //   0: getstatic reactor/core/scheduler/BoundedElasticScheduler.BOUNDED_SERVICES : Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;
/*     */     //   3: aload_0
/*     */     //   4: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   7: checkcast reactor/core/scheduler/BoundedElasticScheduler$BoundedServices
/*     */     //   10: astore_1
/*     */     //   11: aload_1
/*     */     //   12: getstatic reactor/core/scheduler/BoundedElasticScheduler.SHUTDOWN : Lreactor/core/scheduler/BoundedElasticScheduler$BoundedServices;
/*     */     //   15: if_acmpeq -> 19
/*     */     //   18: return
/*     */     //   19: new reactor/core/scheduler/BoundedElasticScheduler$BoundedServices
/*     */     //   22: dup
/*     */     //   23: aload_0
/*     */     //   24: invokespecial <init> : (Lreactor/core/scheduler/BoundedElasticScheduler;)V
/*     */     //   27: astore_2
/*     */     //   28: getstatic reactor/core/scheduler/BoundedElasticScheduler.BOUNDED_SERVICES : Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;
/*     */     //   31: aload_0
/*     */     //   32: aload_1
/*     */     //   33: aload_2
/*     */     //   34: invokevirtual compareAndSet : (Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Z
/*     */     //   37: ifeq -> 115
/*     */     //   40: iconst_1
/*     */     //   41: getstatic reactor/core/scheduler/BoundedElasticScheduler.EVICTOR_FACTORY : Ljava/util/concurrent/ThreadFactory;
/*     */     //   44: invokestatic newScheduledThreadPool : (ILjava/util/concurrent/ThreadFactory;)Ljava/util/concurrent/ScheduledExecutorService;
/*     */     //   47: astore_3
/*     */     //   48: getstatic reactor/core/scheduler/BoundedElasticScheduler.EVICTOR : Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;
/*     */     //   51: aload_0
/*     */     //   52: aconst_null
/*     */     //   53: aload_3
/*     */     //   54: invokevirtual compareAndSet : (Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Z
/*     */     //   57: ifeq -> 107
/*     */     //   60: aload_3
/*     */     //   61: aload_2
/*     */     //   62: dup
/*     */     //   63: invokevirtual getClass : ()Ljava/lang/Class;
/*     */     //   66: pop
/*     */     //   67: <illegal opcode> run : (Lreactor/core/scheduler/BoundedElasticScheduler$BoundedServices;)Ljava/lang/Runnable;
/*     */     //   72: aload_0
/*     */     //   73: getfield ttlMillis : J
/*     */     //   76: aload_0
/*     */     //   77: getfield ttlMillis : J
/*     */     //   80: getstatic java/util/concurrent/TimeUnit.MILLISECONDS : Ljava/util/concurrent/TimeUnit;
/*     */     //   83: invokeinterface scheduleAtFixedRate : (Ljava/lang/Runnable;JJLjava/util/concurrent/TimeUnit;)Ljava/util/concurrent/ScheduledFuture;
/*     */     //   88: pop
/*     */     //   89: goto -> 114
/*     */     //   92: astore #4
/*     */     //   94: aload_0
/*     */     //   95: invokevirtual isDisposed : ()Z
/*     */     //   98: ifne -> 104
/*     */     //   101: aload #4
/*     */     //   103: athrow
/*     */     //   104: goto -> 114
/*     */     //   107: aload_3
/*     */     //   108: invokeinterface shutdownNow : ()Ljava/util/List;
/*     */     //   113: pop
/*     */     //   114: return
/*     */     //   115: goto -> 0
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #169	-> 0
/*     */     //   #170	-> 11
/*     */     //   #171	-> 18
/*     */     //   #173	-> 19
/*     */     //   #174	-> 28
/*     */     //   #175	-> 40
/*     */     //   #176	-> 48
/*     */     //   #178	-> 60
/*     */     //   #185	-> 89
/*     */     //   #180	-> 92
/*     */     //   #182	-> 94
/*     */     //   #183	-> 101
/*     */     //   #185	-> 104
/*     */     //   #188	-> 107
/*     */     //   #190	-> 114
/*     */     //   #192	-> 115
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   94	10	4	ree	Ljava/util/concurrent/RejectedExecutionException;
/*     */     //   48	67	3	e	Ljava/util/concurrent/ScheduledExecutorService;
/*     */     //   11	104	1	services	Lreactor/core/scheduler/BoundedElasticScheduler$BoundedServices;
/*     */     //   28	87	2	newServices	Lreactor/core/scheduler/BoundedElasticScheduler$BoundedServices;
/*     */     //   0	118	0	this	Lreactor/core/scheduler/BoundedElasticScheduler;
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   60	89	92	java/util/concurrent/RejectedExecutionException
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 197 */     BoundedServices services = BOUNDED_SERVICES.get(this);
/* 198 */     if (services != SHUTDOWN && BOUNDED_SERVICES.compareAndSet(this, services, SHUTDOWN)) {
/* 199 */       ScheduledExecutorService e = EVICTOR.getAndSet(this, null);
/* 200 */       if (e != null) {
/* 201 */         e.shutdownNow();
/*     */       }
/* 203 */       services.dispose();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Disposable schedule(Runnable task) {
/* 210 */     BoundedState picked = ((BoundedServices)BOUNDED_SERVICES.get(this)).pick();
/* 211 */     return Schedulers.directSchedule(picked.executor, task, picked, 0L, TimeUnit.MILLISECONDS);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Disposable schedule(Runnable task, long delay, TimeUnit unit) {
/* 217 */     BoundedState picked = ((BoundedServices)BOUNDED_SERVICES.get(this)).pick();
/* 218 */     return Schedulers.directSchedule(picked.executor, task, picked, delay, unit);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Disposable schedulePeriodically(Runnable task, long initialDelay, long period, TimeUnit unit) {
/* 226 */     BoundedState picked = ((BoundedServices)BOUNDED_SERVICES.get(this)).pick();
/* 227 */     Disposable scheduledTask = Schedulers.directSchedulePeriodically(picked.executor, task, initialDelay, period, unit);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 234 */     return (Disposable)Disposables.composite(new Disposable[] { scheduledTask, picked });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 240 */     StringBuilder ts = (new StringBuilder("boundedElastic")).append('(');
/* 241 */     if (this.factory instanceof ReactorThreadFactory) {
/* 242 */       ts.append('"').append(((ReactorThreadFactory)this.factory).get()).append("\",");
/*     */     }
/* 244 */     ts.append("maxThreads=").append(this.maxThreads)
/* 245 */       .append(",maxTaskQueuedPerThread=").append((this.maxTaskQueuedPerThread == Integer.MAX_VALUE) ? "unbounded" : Integer.valueOf(this.maxTaskQueuedPerThread))
/* 246 */       .append(",ttl=");
/* 247 */     if (this.ttlMillis < 1000L) {
/* 248 */       ts.append(this.ttlMillis).append("ms)");
/*     */     } else {
/*     */       
/* 251 */       ts.append(this.ttlMillis / 1000L).append("s)");
/*     */     } 
/* 253 */     return ts.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int estimateSize() {
/* 260 */     return ((BoundedServices)BOUNDED_SERVICES.get(this)).get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int estimateBusy() {
/* 267 */     return ((BoundedServices)BOUNDED_SERVICES.get((T)this)).busyArray.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int estimateIdle() {
/* 274 */     return ((BoundedServices)BOUNDED_SERVICES.get((T)this)).idleQueue.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int estimateRemainingTaskCapacity() {
/* 283 */     BoundedState[] busyArray = ((BoundedServices)BOUNDED_SERVICES.get((T)this)).busyArray;
/* 284 */     int totalTaskCapacity = this.maxTaskQueuedPerThread * this.maxThreads;
/* 285 */     for (BoundedState state : busyArray) {
/* 286 */       int stateQueueSize = state.estimateQueueSize();
/* 287 */       if (stateQueueSize >= 0) {
/* 288 */         totalTaskCapacity -= stateQueueSize;
/*     */       } else {
/*     */         
/* 291 */         return -1;
/*     */       } 
/*     */     } 
/* 294 */     return totalTaskCapacity;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/* 299 */     if (key == Scannable.Attr.TERMINATED || key == Scannable.Attr.CANCELLED) return Boolean.valueOf(isDisposed()); 
/* 300 */     if (key == Scannable.Attr.BUFFERED) return Integer.valueOf(estimateSize()); 
/* 301 */     if (key == Scannable.Attr.CAPACITY) return Integer.valueOf(this.maxThreads); 
/* 302 */     if (key == Scannable.Attr.NAME) return toString();
/*     */     
/* 304 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Stream<? extends Scannable> inners() {
/* 309 */     BoundedServices services = BOUNDED_SERVICES.get(this);
/* 310 */     return Stream.<Scannable>concat(Stream.of((Scannable[])services.busyArray), services.idleQueue.stream())
/* 311 */       .filter(obj -> (obj != null && obj != CREATING));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Scheduler.Worker createWorker() {
/* 317 */     BoundedState picked = ((BoundedServices)BOUNDED_SERVICES.get(this)).pick();
/* 318 */     ExecutorServiceWorker worker = new ExecutorServiceWorker(picked.executor);
/* 319 */     worker.disposables.add(picked);
/* 320 */     return worker;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class BoundedServices
/*     */     extends AtomicInteger
/*     */     implements Disposable
/*     */   {
/*     */     static final int DISPOSED = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 338 */     static final ZoneId ZONE_UTC = ZoneId.of("UTC");
/*     */     
/*     */     final BoundedElasticScheduler parent;
/*     */     
/*     */     final Clock clock;
/*     */     
/*     */     final Deque<BoundedElasticScheduler.BoundedState> idleQueue;
/*     */     
/*     */     volatile BoundedElasticScheduler.BoundedState[] busyArray;
/*     */     
/* 348 */     static final AtomicReferenceFieldUpdater<BoundedServices, BoundedElasticScheduler.BoundedState[]> BUSY_ARRAY = (AtomicReferenceFieldUpdater)AtomicReferenceFieldUpdater.newUpdater(BoundedServices.class, (Class)BoundedElasticScheduler.BoundedState[].class, "busyArray");
/*     */     
/* 350 */     static final BoundedElasticScheduler.BoundedState[] ALL_IDLE = new BoundedElasticScheduler.BoundedState[0];
/* 351 */     static final BoundedElasticScheduler.BoundedState[] ALL_SHUTDOWN = new BoundedElasticScheduler.BoundedState[0];
/*     */ 
/*     */     
/*     */     private BoundedServices() {
/* 355 */       this.parent = null;
/* 356 */       this.clock = Clock.fixed(Instant.EPOCH, ZONE_UTC);
/* 357 */       this.idleQueue = new ConcurrentLinkedDeque<>();
/* 358 */       this.busyArray = ALL_SHUTDOWN;
/*     */     }
/*     */     
/*     */     BoundedServices(BoundedElasticScheduler parent) {
/* 362 */       this.parent = parent;
/* 363 */       this.clock = parent.clock;
/* 364 */       this.idleQueue = new ConcurrentLinkedDeque<>();
/* 365 */       this.busyArray = ALL_IDLE;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void eviction() {
/* 373 */       long evictionTimestamp = this.parent.clock.millis();
/* 374 */       List<BoundedElasticScheduler.BoundedState> idleCandidates = new ArrayList<>(this.idleQueue);
/* 375 */       for (BoundedElasticScheduler.BoundedState candidate : idleCandidates) {
/* 376 */         if (candidate.tryEvict(evictionTimestamp, this.parent.ttlMillis)) {
/* 377 */           this.idleQueue.remove(candidate);
/* 378 */           decrementAndGet();
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     boolean setBusy(BoundedElasticScheduler.BoundedState bs) {
/*     */       while (true) {
/* 389 */         BoundedElasticScheduler.BoundedState[] previous = this.busyArray;
/*     */         
/* 391 */         if (previous == ALL_SHUTDOWN) {
/* 392 */           return false;
/*     */         }
/*     */         
/* 395 */         int len = previous.length;
/* 396 */         BoundedElasticScheduler.BoundedState[] replacement = new BoundedElasticScheduler.BoundedState[len + 1];
/* 397 */         System.arraycopy(previous, 0, replacement, 0, len);
/* 398 */         replacement[len] = bs;
/*     */         
/* 400 */         if (BUSY_ARRAY.compareAndSet(this, previous, replacement))
/* 401 */           return true; 
/*     */       } 
/*     */     }
/*     */     
/*     */     void setIdle(BoundedElasticScheduler.BoundedState boundedState) {
/*     */       BoundedElasticScheduler.BoundedState[] arr, replacement;
/*     */       do {
/* 408 */         arr = this.busyArray;
/* 409 */         int len = arr.length;
/*     */         
/* 411 */         if (len == 0) {
/*     */           return;
/*     */         }
/*     */ 
/*     */         
/* 416 */         replacement = null;
/* 417 */         if (len == 1) {
/* 418 */           if (arr[0] == boundedState) {
/* 419 */             replacement = ALL_IDLE;
/*     */           }
/*     */         } else {
/*     */           
/* 423 */           for (int i = 0; i < len; i++) {
/* 424 */             BoundedElasticScheduler.BoundedState state = arr[i];
/* 425 */             if (state == boundedState) {
/* 426 */               replacement = new BoundedElasticScheduler.BoundedState[len - 1];
/* 427 */               System.arraycopy(arr, 0, replacement, 0, i);
/* 428 */               System.arraycopy(arr, i + 1, replacement, i, len - i - 1);
/*     */               break;
/*     */             } 
/*     */           } 
/*     */         } 
/* 433 */         if (replacement == null) {
/*     */           return;
/*     */         }
/*     */       }
/* 437 */       while (!BUSY_ARRAY.compareAndSet(this, arr, replacement));
/*     */ 
/*     */       
/* 440 */       this.idleQueue.add(boundedState);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     BoundedElasticScheduler.BoundedState pick() {
/*     */       while (true) {
/* 455 */         int a = get();
/* 456 */         if (a == -1 || this.busyArray == ALL_SHUTDOWN) {
/* 457 */           return BoundedElasticScheduler.CREATING;
/*     */         }
/*     */         
/* 460 */         if (!this.idleQueue.isEmpty()) {
/*     */           
/* 462 */           BoundedElasticScheduler.BoundedState bs = this.idleQueue.pollLast();
/* 463 */           if (bs != null && bs.markPicked()) {
/* 464 */             setBusy(bs);
/* 465 */             return bs;
/*     */           } 
/*     */           continue;
/*     */         } 
/* 469 */         if (a < this.parent.maxThreads) {
/*     */           
/* 471 */           if (compareAndSet(a, a + 1)) {
/* 472 */             ScheduledExecutorService scheduledExecutorService = Schedulers.decorateExecutorService(this.parent, this.parent.createBoundedExecutorService());
/* 473 */             BoundedElasticScheduler.BoundedState newState = new BoundedElasticScheduler.BoundedState(this, scheduledExecutorService);
/* 474 */             if (newState.markPicked()) {
/* 475 */               setBusy(newState);
/* 476 */               return newState;
/*     */             } 
/*     */           } 
/*     */           
/*     */           continue;
/*     */         } 
/* 482 */         BoundedElasticScheduler.BoundedState s = choseOneBusy();
/* 483 */         if (s != null && s.markPicked()) {
/* 484 */           return s;
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     private BoundedElasticScheduler.BoundedState choseOneBusy() {
/* 493 */       BoundedElasticScheduler.BoundedState[] arr = this.busyArray;
/* 494 */       int len = arr.length;
/* 495 */       if (len == 0) {
/* 496 */         return null;
/*     */       }
/* 498 */       if (len == 1) {
/* 499 */         return arr[0];
/*     */       }
/*     */       
/* 502 */       BoundedElasticScheduler.BoundedState choice = arr[0];
/* 503 */       int leastBusy = Integer.MAX_VALUE;
/*     */       
/* 505 */       for (int i = 0; i < arr.length; i++) {
/* 506 */         BoundedElasticScheduler.BoundedState state = arr[i];
/* 507 */         int busy = state.markCount;
/* 508 */         if (busy < leastBusy) {
/* 509 */           leastBusy = busy;
/* 510 */           choice = state;
/*     */         } 
/*     */       } 
/* 513 */       return choice;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isDisposed() {
/* 518 */       return (get() == -1);
/*     */     }
/*     */ 
/*     */     
/*     */     public void dispose() {
/* 523 */       set(-1);
/* 524 */       this.idleQueue.forEach(BoundedElasticScheduler.BoundedState::shutdown);
/* 525 */       BoundedElasticScheduler.BoundedState[] arr = BUSY_ARRAY.getAndSet(this, ALL_SHUTDOWN);
/* 526 */       for (int i = 0; i < arr.length; i++) {
/* 527 */         arr[i].shutdown();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class BoundedState
/*     */     implements Disposable, Scannable
/*     */   {
/*     */     static final int EVICTED = -1;
/*     */ 
/*     */     
/*     */     final BoundedElasticScheduler.BoundedServices parent;
/*     */ 
/*     */     
/*     */     final ScheduledExecutorService executor;
/*     */ 
/*     */     
/* 547 */     long idleSinceTimestamp = -1L;
/*     */     
/*     */     volatile int markCount;
/* 550 */     static final AtomicIntegerFieldUpdater<BoundedState> MARK_COUNT = AtomicIntegerFieldUpdater.newUpdater(BoundedState.class, "markCount");
/*     */     
/*     */     BoundedState(BoundedElasticScheduler.BoundedServices parent, ScheduledExecutorService executor) {
/* 553 */       this.parent = parent;
/* 554 */       this.executor = executor;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     int estimateQueueSize() {
/* 561 */       if (this.executor instanceof ScheduledThreadPoolExecutor) {
/* 562 */         return ((ScheduledThreadPoolExecutor)this.executor).getQueue().size();
/*     */       }
/* 564 */       return -1;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     boolean markPicked() {
/*     */       while (true) {
/* 575 */         int i = MARK_COUNT.get(this);
/* 576 */         if (i == -1) {
/* 577 */           return false;
/*     */         }
/* 579 */         if (MARK_COUNT.compareAndSet(this, i, i + 1)) {
/* 580 */           return true;
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     boolean tryEvict(long evictionTimestamp, long ttlMillis) {
/* 596 */       long idleSince = this.idleSinceTimestamp;
/* 597 */       if (idleSince < 0L) return false; 
/* 598 */       long elapsed = evictionTimestamp - idleSince;
/* 599 */       if (elapsed >= ttlMillis && 
/* 600 */         MARK_COUNT.compareAndSet(this, 0, -1)) {
/* 601 */         this.executor.shutdownNow();
/* 602 */         return true;
/*     */       } 
/*     */       
/* 605 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void release() {
/* 618 */       int picked = MARK_COUNT.decrementAndGet(this);
/* 619 */       if (picked < 0) {
/*     */         return;
/*     */       }
/*     */ 
/*     */       
/* 624 */       if (picked == 0) {
/*     */         
/* 626 */         this.idleSinceTimestamp = this.parent.clock.millis();
/* 627 */         this.parent.setIdle(this);
/*     */       }
/*     */       else {
/*     */         
/* 631 */         this.idleSinceTimestamp = -1L;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void shutdown() {
/* 642 */       this.idleSinceTimestamp = -1L;
/* 643 */       MARK_COUNT.set(this, -1);
/* 644 */       this.executor.shutdownNow();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void dispose() {
/* 652 */       release();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isDisposed() {
/* 662 */       return (MARK_COUNT.get(this) <= 0);
/*     */     }
/*     */ 
/*     */     
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 667 */       return Schedulers.scanExecutor(this.executor, key);
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 672 */       return "BoundedState@" + System.identityHashCode(this) + "{ backing=" + MARK_COUNT.get(this) + ", idleSince=" + this.idleSinceTimestamp + ", executor=" + this.executor + '}';
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class BoundedScheduledExecutorService
/*     */     extends ScheduledThreadPoolExecutor
/*     */     implements Scannable
/*     */   {
/*     */     final int queueCapacity;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     BoundedScheduledExecutorService(int queueCapacity, ThreadFactory factory) {
/* 697 */       super(1, factory);
/* 698 */       setMaximumPoolSize(1);
/* 699 */       setRemoveOnCancelPolicy(true);
/* 700 */       if (queueCapacity < 1) {
/* 701 */         throw new IllegalArgumentException("was expecting a non-zero positive queue capacity");
/*     */       }
/*     */       
/* 704 */       this.queueCapacity = queueCapacity;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 709 */       if (Scannable.Attr.TERMINATED == key) return Boolean.valueOf(isTerminated()); 
/* 710 */       if (Scannable.Attr.BUFFERED == key) return Integer.valueOf(getQueue().size()); 
/* 711 */       if (Scannable.Attr.CAPACITY == key) return Integer.valueOf(this.queueCapacity); 
/* 712 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 717 */       int queued = getQueue().size();
/* 718 */       long completed = getCompletedTaskCount();
/* 719 */       String state = (getActiveCount() > 0) ? "ACTIVE" : "IDLE";
/* 720 */       if (this.queueCapacity == Integer.MAX_VALUE) {
/* 721 */         return "BoundedScheduledExecutorService{" + state + ", queued=" + queued + "/unbounded, completed=" + completed + '}';
/*     */       }
/* 723 */       return "BoundedScheduledExecutorService{" + state + ", queued=" + queued + "/" + this.queueCapacity + ", completed=" + completed + '}';
/*     */     }
/*     */     
/*     */     void ensureQueueCapacity(int taskCount) {
/* 727 */       if (this.queueCapacity == Integer.MAX_VALUE) {
/*     */         return;
/*     */       }
/* 730 */       int queueSize = getQueue().size();
/* 731 */       if (queueSize + taskCount > this.queueCapacity) {
/* 732 */         throw Exceptions.failWithRejected("Task capacity of bounded elastic scheduler reached while scheduling " + taskCount + " tasks (" + (queueSize + taskCount) + "/" + this.queueCapacity + ")");
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public synchronized ScheduledFuture<?> schedule(Runnable command, long delay, TimeUnit unit) {
/* 744 */       ensureQueueCapacity(1);
/* 745 */       return super.schedule(command, delay, unit);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public synchronized <V> ScheduledFuture<V> schedule(Callable<V> callable, long delay, TimeUnit unit) {
/* 756 */       ensureQueueCapacity(1);
/* 757 */       return super.schedule(callable, delay, unit);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public synchronized ScheduledFuture<?> scheduleAtFixedRate(Runnable command, long initialDelay, long period, TimeUnit unit) {
/* 769 */       ensureQueueCapacity(1);
/* 770 */       return super.scheduleAtFixedRate(command, initialDelay, period, unit);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ScheduledFuture<?> scheduleWithFixedDelay(Runnable command, long initialDelay, long delay, TimeUnit unit) {
/* 782 */       ensureQueueCapacity(1);
/* 783 */       return super.scheduleWithFixedDelay(command, initialDelay, delay, unit);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void shutdown() {
/* 791 */       super.shutdown();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public List<Runnable> shutdownNow() {
/* 799 */       return super.shutdownNow();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isShutdown() {
/* 807 */       return super.isShutdown();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isTerminated() {
/* 815 */       return super.isTerminated();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean awaitTermination(long timeout, TimeUnit unit) throws InterruptedException {
/* 824 */       return super.awaitTermination(timeout, unit);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public synchronized <T> Future<T> submit(Callable<T> task) {
/* 832 */       ensureQueueCapacity(1);
/* 833 */       return super.submit(task);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public synchronized <T> Future<T> submit(Runnable task, T result) {
/* 841 */       ensureQueueCapacity(1);
/* 842 */       return super.submit(task, result);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public synchronized Future<?> submit(Runnable task) {
/* 850 */       ensureQueueCapacity(1);
/* 851 */       return super.submit(task);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public synchronized <T> List<Future<T>> invokeAll(Collection<? extends Callable<T>> tasks) throws InterruptedException {
/* 861 */       ensureQueueCapacity(tasks.size());
/* 862 */       return super.invokeAll(tasks);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public synchronized <T> List<Future<T>> invokeAll(Collection<? extends Callable<T>> tasks, long timeout, TimeUnit unit) throws InterruptedException {
/* 874 */       ensureQueueCapacity(tasks.size());
/* 875 */       return super.invokeAll(tasks, timeout, unit);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public synchronized <T> T invokeAny(Collection<? extends Callable<T>> tasks) throws InterruptedException, ExecutionException {
/* 884 */       ensureQueueCapacity(tasks.size());
/* 885 */       return super.invokeAny(tasks);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public synchronized <T> T invokeAny(Collection<? extends Callable<T>> tasks, long timeout, TimeUnit unit) throws InterruptedException, ExecutionException, TimeoutException {
/* 897 */       ensureQueueCapacity(tasks.size());
/* 898 */       return super.invokeAny(tasks, timeout, unit);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public synchronized void execute(Runnable command) {
/* 906 */       ensureQueueCapacity(1);
/* 907 */       super.submit(command);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\scheduler\BoundedElasticScheduler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */