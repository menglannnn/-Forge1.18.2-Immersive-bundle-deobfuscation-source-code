/*     */ package reactor.core.scheduler;
/*     */ 
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.ScheduledExecutorService;
/*     */ import java.util.concurrent.ScheduledThreadPoolExecutor;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.stream.Stream;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.Scannable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ParallelScheduler
/*     */   implements Scheduler, Supplier<ScheduledExecutorService>, Scannable
/*     */ {
/*  43 */   static final AtomicLong COUNTER = new AtomicLong();
/*     */   
/*     */   final int n;
/*     */   
/*     */   final ThreadFactory factory;
/*     */   
/*     */   volatile ScheduledExecutorService[] executors;
/*     */   
/*  51 */   static final AtomicReferenceFieldUpdater<ParallelScheduler, ScheduledExecutorService[]> EXECUTORS = (AtomicReferenceFieldUpdater)AtomicReferenceFieldUpdater.newUpdater(ParallelScheduler.class, (Class)ScheduledExecutorService[].class, "executors");
/*     */   
/*  53 */   static final ScheduledExecutorService[] SHUTDOWN = new ScheduledExecutorService[0];
/*     */ 
/*     */ 
/*     */   
/*  57 */   static final ScheduledExecutorService TERMINATED = Executors.newSingleThreadScheduledExecutor(); static {
/*  58 */     TERMINATED.shutdownNow();
/*     */   }
/*     */   
/*     */   int roundRobin;
/*     */   
/*     */   ParallelScheduler(int n, ThreadFactory factory) {
/*  64 */     if (n <= 0) {
/*  65 */       throw new IllegalArgumentException("n > 0 required but it was " + n);
/*     */     }
/*  67 */     this.n = n;
/*  68 */     this.factory = factory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ScheduledExecutorService get() {
/*  77 */     ScheduledThreadPoolExecutor poolExecutor = new ScheduledThreadPoolExecutor(1, this.factory);
/*  78 */     poolExecutor.setMaximumPoolSize(1);
/*  79 */     poolExecutor.setRemoveOnCancelPolicy(true);
/*  80 */     return poolExecutor;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDisposed() {
/*  85 */     return (this.executors == SHUTDOWN);
/*     */   }
/*     */ 
/*     */   
/*     */   public void start() {
/*  90 */     ScheduledExecutorService[] a, b = null;
/*     */     do {
/*  92 */       a = this.executors;
/*  93 */       if (a != SHUTDOWN && a != null) {
/*  94 */         if (b != null) {
/*  95 */           for (ScheduledExecutorService exec : b) {
/*  96 */             exec.shutdownNow();
/*     */           }
/*     */         }
/*     */         
/*     */         return;
/*     */       } 
/* 102 */       if (b != null)
/* 103 */         continue;  b = new ScheduledExecutorService[this.n];
/* 104 */       for (int i = 0; i < this.n; i++) {
/* 105 */         b[i] = Schedulers.decorateExecutorService(this, get());
/*     */       
/*     */       }
/*     */     }
/* 109 */     while (!EXECUTORS.compareAndSet(this, a, b));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 117 */     ScheduledExecutorService[] a = this.executors;
/* 118 */     if (a != SHUTDOWN) {
/* 119 */       a = EXECUTORS.getAndSet(this, SHUTDOWN);
/* 120 */       if (a != SHUTDOWN && a != null) {
/* 121 */         for (ScheduledExecutorService exec : a) {
/* 122 */           exec.shutdownNow();
/*     */         }
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   ScheduledExecutorService pick() {
/* 129 */     ScheduledExecutorService[] a = this.executors;
/* 130 */     if (a == null) {
/* 131 */       start();
/* 132 */       a = this.executors;
/* 133 */       if (a == null) {
/* 134 */         throw new IllegalStateException("executors uninitialized after implicit start()");
/*     */       }
/*     */     } 
/* 137 */     if (a != SHUTDOWN) {
/*     */       
/* 139 */       int idx = this.roundRobin;
/* 140 */       if (idx == this.n) {
/* 141 */         idx = 0;
/* 142 */         this.roundRobin = 1;
/*     */       } else {
/* 144 */         this.roundRobin = idx + 1;
/*     */       } 
/* 146 */       return a[idx];
/*     */     } 
/* 148 */     return TERMINATED;
/*     */   }
/*     */ 
/*     */   
/*     */   public Disposable schedule(Runnable task) {
/* 153 */     return Schedulers.directSchedule(pick(), task, null, 0L, TimeUnit.MILLISECONDS);
/*     */   }
/*     */ 
/*     */   
/*     */   public Disposable schedule(Runnable task, long delay, TimeUnit unit) {
/* 158 */     return Schedulers.directSchedule(pick(), task, null, delay, unit);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Disposable schedulePeriodically(Runnable task, long initialDelay, long period, TimeUnit unit) {
/* 166 */     return Schedulers.directSchedulePeriodically(pick(), task, initialDelay, period, unit);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 176 */     StringBuilder ts = (new StringBuilder("parallel")).append('(').append(this.n);
/* 177 */     if (this.factory instanceof ReactorThreadFactory) {
/* 178 */       ts.append(",\"").append(((ReactorThreadFactory)this.factory).get()).append('"');
/*     */     }
/* 180 */     ts.append(')');
/* 181 */     return ts.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/* 186 */     if (key == Scannable.Attr.TERMINATED || key == Scannable.Attr.CANCELLED) return Boolean.valueOf(isDisposed()); 
/* 187 */     if (key == Scannable.Attr.CAPACITY || key == Scannable.Attr.BUFFERED) return Integer.valueOf(this.n); 
/* 188 */     if (key == Scannable.Attr.NAME) return toString();
/*     */     
/* 190 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Stream<? extends Scannable> inners() {
/* 195 */     return Stream.<ScheduledExecutorService>of(this.executors)
/* 196 */       .map(exec -> ());
/*     */   }
/*     */ 
/*     */   
/*     */   public Scheduler.Worker createWorker() {
/* 201 */     return new ExecutorServiceWorker(pick());
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\scheduler\ParallelScheduler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */