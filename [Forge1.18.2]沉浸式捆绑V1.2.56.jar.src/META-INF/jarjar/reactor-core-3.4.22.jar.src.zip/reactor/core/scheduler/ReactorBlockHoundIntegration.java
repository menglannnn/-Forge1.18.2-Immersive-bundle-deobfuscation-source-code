/*    */ package reactor.core.scheduler;
/*    */ 
/*    */ import java.util.concurrent.ScheduledThreadPoolExecutor;
/*    */ import java.util.concurrent.ThreadPoolExecutor;
/*    */ import java.util.function.Predicate;
/*    */ import reactor.blockhound.BlockHound;
/*    */ import reactor.blockhound.integration.BlockHoundIntegration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ReactorBlockHoundIntegration
/*    */   implements BlockHoundIntegration
/*    */ {
/*    */   public void applyTo(BlockHound.Builder builder) {
/* 37 */     builder.nonBlockingThreadPredicate(current -> current.or(NonBlocking.class::isInstance));
/*    */     
/* 39 */     builder.allowBlockingCallsInside(ScheduledThreadPoolExecutor.class.getName() + "$DelayedWorkQueue", "offer");
/* 40 */     builder.allowBlockingCallsInside(ScheduledThreadPoolExecutor.class.getName() + "$DelayedWorkQueue", "take");
/* 41 */     builder.allowBlockingCallsInside(BoundedElasticScheduler.class.getName() + "$BoundedScheduledExecutorService", "ensureQueueCapacity");
/*    */ 
/*    */     
/* 44 */     builder.allowBlockingCallsInside(SchedulerTask.class.getName(), "dispose");
/*    */     
/* 46 */     builder.allowBlockingCallsInside(ThreadPoolExecutor.class.getName(), "processWorkerExit");
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\scheduler\ReactorBlockHoundIntegration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */