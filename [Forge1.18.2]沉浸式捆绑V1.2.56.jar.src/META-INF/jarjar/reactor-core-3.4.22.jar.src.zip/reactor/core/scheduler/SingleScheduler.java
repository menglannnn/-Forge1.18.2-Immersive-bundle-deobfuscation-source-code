/*     */ package reactor.core.scheduler;
/*     */ 
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.ScheduledExecutorService;
/*     */ import java.util.concurrent.ScheduledThreadPoolExecutor;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.function.Supplier;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.Scannable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class SingleScheduler
/*     */   implements Scheduler, Supplier<ScheduledExecutorService>, Scannable
/*     */ {
/*  39 */   static final AtomicLong COUNTER = new AtomicLong();
/*     */   
/*     */   final ThreadFactory factory;
/*     */   
/*     */   volatile ScheduledExecutorService executor;
/*     */   
/*  45 */   static final AtomicReferenceFieldUpdater<SingleScheduler, ScheduledExecutorService> EXECUTORS = AtomicReferenceFieldUpdater.newUpdater(SingleScheduler.class, ScheduledExecutorService.class, "executor");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  52 */   static final ScheduledExecutorService TERMINATED = Executors.newSingleThreadScheduledExecutor(); static {
/*  53 */     TERMINATED.shutdownNow();
/*     */   }
/*     */   
/*     */   SingleScheduler(ThreadFactory factory) {
/*  57 */     this.factory = factory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ScheduledExecutorService get() {
/*  66 */     ScheduledThreadPoolExecutor e = (ScheduledThreadPoolExecutor)Executors.newScheduledThreadPool(1, this.factory);
/*  67 */     e.setRemoveOnCancelPolicy(true);
/*  68 */     e.setMaximumPoolSize(1);
/*  69 */     return e;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDisposed() {
/*  74 */     return (this.executor == TERMINATED);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void start() {
/*  80 */     ScheduledExecutorService a, b = null;
/*     */     do {
/*  82 */       a = this.executor;
/*  83 */       if (a != TERMINATED && a != null) {
/*  84 */         if (b != null) {
/*  85 */           b.shutdownNow();
/*     */         }
/*     */         
/*     */         return;
/*     */       } 
/*  90 */       if (b != null)
/*  91 */         continue;  b = Schedulers.decorateExecutorService(this, get());
/*     */     
/*     */     }
/*  94 */     while (!EXECUTORS.compareAndSet(this, a, b));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 102 */     ScheduledExecutorService a = this.executor;
/* 103 */     if (a != TERMINATED) {
/* 104 */       a = EXECUTORS.getAndSet(this, TERMINATED);
/* 105 */       if (a != TERMINATED && a != null) {
/* 106 */         a.shutdownNow();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Disposable schedule(Runnable task) {
/* 113 */     return Schedulers.directSchedule(this.executor, task, null, 0L, TimeUnit.MILLISECONDS);
/*     */   }
/*     */ 
/*     */   
/*     */   public Disposable schedule(Runnable task, long delay, TimeUnit unit) {
/* 118 */     return Schedulers.directSchedule(this.executor, task, null, delay, unit);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Disposable schedulePeriodically(Runnable task, long initialDelay, long period, TimeUnit unit) {
/* 126 */     return Schedulers.directSchedulePeriodically(this.executor, task, initialDelay, period, unit);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 136 */     StringBuilder ts = (new StringBuilder("single")).append('(');
/* 137 */     if (this.factory instanceof ReactorThreadFactory) {
/* 138 */       ts.append('"').append(((ReactorThreadFactory)this.factory).get()).append('"');
/*     */     }
/* 140 */     return ts.append(')').toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/* 145 */     if (key == Scannable.Attr.TERMINATED || key == Scannable.Attr.CANCELLED) return Boolean.valueOf(isDisposed()); 
/* 146 */     if (key == Scannable.Attr.NAME) return toString(); 
/* 147 */     if (key == Scannable.Attr.CAPACITY || key == Scannable.Attr.BUFFERED) return Integer.valueOf(1);
/*     */     
/* 149 */     return Schedulers.scanExecutor(this.executor, key);
/*     */   }
/*     */ 
/*     */   
/*     */   public Scheduler.Worker createWorker() {
/* 154 */     return new ExecutorServiceWorker(this.executor);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\scheduler\SingleScheduler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */