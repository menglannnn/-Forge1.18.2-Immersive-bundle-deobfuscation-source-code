/*     */ package reactor.core.scheduler;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.Queue;
/*     */ import java.util.concurrent.ConcurrentLinkedQueue;
/*     */ import java.util.concurrent.Executor;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.Disposables;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Scannable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ExecutorScheduler
/*     */   implements Scheduler, Scannable
/*     */ {
/*     */   final Executor executor;
/*     */   final boolean trampoline;
/*     */   volatile boolean terminated;
/*     */   
/*     */   ExecutorScheduler(Executor executor, boolean trampoline) {
/*  50 */     this.executor = executor;
/*  51 */     this.trampoline = trampoline;
/*     */   }
/*     */ 
/*     */   
/*     */   public Disposable schedule(Runnable task) {
/*  56 */     if (this.terminated) {
/*  57 */       throw Exceptions.failWithRejected();
/*     */     }
/*  59 */     Objects.requireNonNull(task, "task");
/*  60 */     ExecutorPlainRunnable r = new ExecutorPlainRunnable(task);
/*     */ 
/*     */     
/*     */     try {
/*  64 */       this.executor.execute(r);
/*     */     }
/*  66 */     catch (Throwable ex) {
/*  67 */       if (this.executor instanceof ExecutorService && ((ExecutorService)this.executor).isShutdown()) {
/*  68 */         this.terminated = true;
/*     */       }
/*  70 */       Schedulers.handleError(ex);
/*  71 */       throw Exceptions.failWithRejected(ex);
/*     */     } 
/*  73 */     return r;
/*     */   }
/*     */ 
/*     */   
/*     */   public void dispose() {
/*  78 */     this.terminated = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDisposed() {
/*  83 */     return this.terminated;
/*     */   }
/*     */ 
/*     */   
/*     */   public Scheduler.Worker createWorker() {
/*  88 */     return this.trampoline ? new ExecutorSchedulerTrampolineWorker(this.executor) : new ExecutorSchedulerWorker(this.executor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  95 */     StringBuilder ts = (new StringBuilder("fromExecutor")).append('(').append(this.executor);
/*  96 */     if (this.trampoline) ts.append(",trampolining"); 
/*  97 */     ts.append(')');
/*     */     
/*  99 */     return ts.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/* 104 */     if (key == Scannable.Attr.TERMINATED || key == Scannable.Attr.CANCELLED) return Boolean.valueOf(isDisposed()); 
/* 105 */     if (key == Scannable.Attr.NAME) return toString();
/*     */     
/* 107 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class ExecutorPlainRunnable
/*     */     extends AtomicBoolean
/*     */     implements Runnable, Disposable
/*     */   {
/*     */     private static final long serialVersionUID = 5116223460201378097L;
/*     */ 
/*     */     
/*     */     final Runnable task;
/*     */ 
/*     */ 
/*     */     
/*     */     ExecutorPlainRunnable(Runnable task) {
/* 125 */       this.task = task;
/*     */     }
/*     */ 
/*     */     
/*     */     public void run() {
/* 130 */       if (!get()) {
/*     */         try {
/* 132 */           this.task.run();
/*     */         }
/* 134 */         catch (Throwable ex) {
/* 135 */           Schedulers.handleError(ex);
/*     */         } finally {
/*     */           
/* 138 */           lazySet(true);
/*     */         } 
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isDisposed() {
/* 145 */       return get();
/*     */     }
/*     */ 
/*     */     
/*     */     public void dispose() {
/* 150 */       set(true);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static interface WorkerDelete
/*     */   {
/*     */     void delete(ExecutorScheduler.ExecutorTrackedRunnable param1ExecutorTrackedRunnable);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static final class ExecutorTrackedRunnable
/*     */     extends AtomicBoolean
/*     */     implements Runnable, Disposable
/*     */   {
/*     */     private static final long serialVersionUID = 3503344795919906192L;
/*     */ 
/*     */     
/*     */     final Runnable task;
/*     */ 
/*     */     
/*     */     final ExecutorScheduler.WorkerDelete parent;
/*     */ 
/*     */     
/*     */     final boolean callRemoveOnFinish;
/*     */ 
/*     */     
/*     */     ExecutorTrackedRunnable(Runnable task, ExecutorScheduler.WorkerDelete parent, boolean callRemoveOnFinish) {
/* 180 */       this.task = task;
/* 181 */       this.parent = parent;
/* 182 */       this.callRemoveOnFinish = callRemoveOnFinish;
/*     */     }
/*     */ 
/*     */     
/*     */     public void run() {
/* 187 */       if (!get()) {
/*     */         try {
/* 189 */           this.task.run();
/*     */         }
/* 191 */         catch (Throwable ex) {
/* 192 */           Schedulers.handleError(ex);
/*     */         } finally {
/*     */           
/* 195 */           if (this.callRemoveOnFinish) {
/* 196 */             dispose();
/*     */           } else {
/*     */             
/* 199 */             lazySet(true);
/*     */           } 
/*     */         } 
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void dispose() {
/* 207 */       if (compareAndSet(false, true)) {
/* 208 */         this.parent.delete(this);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isDisposed() {
/* 214 */       return get();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class ExecutorSchedulerWorker
/*     */     implements Scheduler.Worker, WorkerDelete, Scannable
/*     */   {
/*     */     final Executor executor;
/*     */     
/*     */     final Disposable.Composite tasks;
/*     */ 
/*     */     
/*     */     ExecutorSchedulerWorker(Executor executor) {
/* 228 */       this.executor = executor;
/* 229 */       this.tasks = Disposables.composite();
/*     */     }
/*     */ 
/*     */     
/*     */     public Disposable schedule(Runnable task) {
/* 234 */       Objects.requireNonNull(task, "task");
/*     */       
/* 236 */       ExecutorScheduler.ExecutorTrackedRunnable r = new ExecutorScheduler.ExecutorTrackedRunnable(task, this, true);
/* 237 */       if (!this.tasks.add(r)) {
/* 238 */         throw Exceptions.failWithRejected();
/*     */       }
/*     */       
/*     */       try {
/* 242 */         this.executor.execute(r);
/*     */       }
/* 244 */       catch (Throwable ex) {
/* 245 */         this.tasks.remove(r);
/* 246 */         Schedulers.handleError(ex);
/* 247 */         throw Exceptions.failWithRejected(ex);
/*     */       } 
/*     */       
/* 250 */       return r;
/*     */     }
/*     */ 
/*     */     
/*     */     public void dispose() {
/* 255 */       this.tasks.dispose();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isDisposed() {
/* 260 */       return this.tasks.isDisposed();
/*     */     }
/*     */ 
/*     */     
/*     */     public void delete(ExecutorScheduler.ExecutorTrackedRunnable r) {
/* 265 */       this.tasks.remove(r);
/*     */     }
/*     */ 
/*     */     
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 270 */       if (key == Scannable.Attr.TERMINATED || key == Scannable.Attr.CANCELLED) return Boolean.valueOf(isDisposed()); 
/* 271 */       if (key == Scannable.Attr.BUFFERED) return Integer.valueOf(this.tasks.size()); 
/* 272 */       if (key == Scannable.Attr.PARENT) return (this.executor instanceof Scannable) ? this.executor : null; 
/* 273 */       if (key == Scannable.Attr.NAME) {
/*     */         
/* 275 */         if (this.executor instanceof SingleWorkerScheduler) return this.executor + ".worker"; 
/* 276 */         return "fromExecutor(" + this.executor + ").worker";
/*     */       } 
/*     */       
/* 279 */       return Schedulers.scanExecutor(this.executor, key);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static final class ExecutorSchedulerTrampolineWorker
/*     */     implements Scheduler.Worker, WorkerDelete, Runnable, Scannable
/*     */   {
/*     */     final Executor executor;
/*     */ 
/*     */     
/*     */     final Queue<ExecutorScheduler.ExecutorTrackedRunnable> queue;
/*     */     
/*     */     volatile boolean terminated;
/*     */     
/*     */     volatile int wip;
/*     */     
/* 297 */     static final AtomicIntegerFieldUpdater<ExecutorSchedulerTrampolineWorker> WIP = AtomicIntegerFieldUpdater.newUpdater(ExecutorSchedulerTrampolineWorker.class, "wip");
/*     */ 
/*     */     
/*     */     ExecutorSchedulerTrampolineWorker(Executor executor) {
/* 301 */       this.executor = executor;
/* 302 */       this.queue = new ConcurrentLinkedQueue<>();
/*     */     }
/*     */ 
/*     */     
/*     */     public Disposable schedule(Runnable task) {
/* 307 */       Objects.requireNonNull(task, "task");
/* 308 */       if (this.terminated) {
/* 309 */         throw Exceptions.failWithRejected();
/*     */       }
/*     */       
/* 312 */       ExecutorScheduler.ExecutorTrackedRunnable r = new ExecutorScheduler.ExecutorTrackedRunnable(task, this, false);
/* 313 */       synchronized (this) {
/* 314 */         if (this.terminated) {
/* 315 */           throw Exceptions.failWithRejected();
/*     */         }
/* 317 */         this.queue.offer(r);
/*     */       } 
/*     */       
/* 320 */       if (WIP.getAndIncrement(this) == 0) {
/*     */         try {
/* 322 */           this.executor.execute(this);
/*     */         }
/* 324 */         catch (Throwable ex) {
/* 325 */           r.dispose();
/* 326 */           Schedulers.handleError(ex);
/* 327 */           throw Exceptions.failWithRejected(ex);
/*     */         } 
/*     */       }
/*     */       
/* 331 */       return r;
/*     */     }
/*     */ 
/*     */     
/*     */     public void dispose() {
/* 336 */       if (this.terminated) {
/*     */         return;
/*     */       }
/* 339 */       this.terminated = true;
/* 340 */       Queue<ExecutorScheduler.ExecutorTrackedRunnable> q = this.queue;
/*     */       
/*     */       ExecutorScheduler.ExecutorTrackedRunnable r;
/*     */       
/* 344 */       while ((r = q.poll()) != null && !q.isEmpty()) {
/* 345 */         r.dispose();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isDisposed() {
/* 351 */       return this.terminated;
/*     */     }
/*     */ 
/*     */     
/*     */     public void delete(ExecutorScheduler.ExecutorTrackedRunnable r) {
/* 356 */       synchronized (this) {
/* 357 */         if (!this.terminated) {
/* 358 */           this.queue.remove(r);
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*     */     public void run() {
/*     */       int e;
/* 365 */       Queue<ExecutorScheduler.ExecutorTrackedRunnable> q = this.queue;
/*     */ 
/*     */       
/*     */       do {
/* 369 */         e = 0;
/* 370 */         int r = this.wip;
/*     */         
/* 372 */         while (e != r) {
/* 373 */           if (this.terminated) {
/*     */             return;
/*     */           }
/* 376 */           ExecutorScheduler.ExecutorTrackedRunnable task = q.poll();
/*     */           
/* 378 */           if (task == null) {
/*     */             break;
/*     */           }
/*     */           
/* 382 */           task.run();
/*     */           
/* 384 */           e++;
/*     */         } 
/*     */         
/* 387 */         if (e == r && this.terminated) {
/*     */           return;
/*     */         }
/*     */       }
/* 391 */       while (WIP.addAndGet(this, -e) != 0);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 399 */       if (key == Scannable.Attr.TERMINATED || key == Scannable.Attr.CANCELLED) return Boolean.valueOf(isDisposed()); 
/* 400 */       if (key == Scannable.Attr.PARENT) return (this.executor instanceof Scannable) ? this.executor : null; 
/* 401 */       if (key == Scannable.Attr.NAME) return "fromExecutor(" + this.executor + ",trampolining).worker"; 
/* 402 */       if (key == Scannable.Attr.BUFFERED || key == Scannable.Attr.LARGE_BUFFERED) return Integer.valueOf(this.queue.size());
/*     */       
/* 404 */       return Schedulers.scanExecutor(this.executor, key);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\scheduler\ExecutorScheduler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */