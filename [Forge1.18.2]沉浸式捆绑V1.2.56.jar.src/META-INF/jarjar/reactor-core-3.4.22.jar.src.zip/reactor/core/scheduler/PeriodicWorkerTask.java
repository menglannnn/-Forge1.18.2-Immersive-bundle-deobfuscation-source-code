/*     */ package reactor.core.scheduler;
/*     */ 
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.concurrent.FutureTask;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class PeriodicWorkerTask
/*     */   implements Runnable, Disposable, Callable<Void>
/*     */ {
/*     */   final Runnable task;
/*  34 */   static final Disposable.Composite DISPOSED = new EmptyCompositeDisposable();
/*     */   
/*  36 */   static final Future<Void> CANCELLED = new FutureTask<>(() -> null);
/*     */   
/*     */   volatile Future<?> future;
/*     */   
/*  40 */   static final AtomicReferenceFieldUpdater<PeriodicWorkerTask, Future> FUTURE = AtomicReferenceFieldUpdater.newUpdater(PeriodicWorkerTask.class, Future.class, "future");
/*     */   
/*     */   volatile Disposable.Composite parent;
/*     */   
/*  44 */   static final AtomicReferenceFieldUpdater<PeriodicWorkerTask, Disposable.Composite> PARENT = AtomicReferenceFieldUpdater.newUpdater(PeriodicWorkerTask.class, Disposable.Composite.class, "parent");
/*     */   
/*     */   Thread thread;
/*     */   
/*     */   PeriodicWorkerTask(Runnable task, Disposable.Composite parent) {
/*  49 */     this.task = task;
/*  50 */     PARENT.lazySet(this, parent);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Void call() {
/*  56 */     this.thread = Thread.currentThread();
/*     */     try {
/*     */       try {
/*  59 */         this.task.run();
/*     */       }
/*  61 */       catch (Throwable ex) {
/*  62 */         Schedulers.handleError(ex);
/*     */       } 
/*     */     } finally {
/*     */       
/*  66 */       this.thread = null;
/*     */     } 
/*  68 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void run() {
/*  73 */     call();
/*     */   }
/*     */   void setFuture(Future<?> f) {
/*     */     Future<?> o;
/*     */     do {
/*  78 */       o = this.future;
/*  79 */       if (o == CANCELLED) {
/*  80 */         f.cancel((this.thread != Thread.currentThread()));
/*     */         return;
/*     */       } 
/*  83 */     } while (!FUTURE.compareAndSet(this, o, f));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDisposed() {
/*  91 */     return (this.future == CANCELLED);
/*     */   }
/*     */ 
/*     */   
/*     */   public void dispose() {
/*     */     while (true) {
/*  97 */       Future<?> f = this.future;
/*  98 */       if (f == CANCELLED) {
/*     */         break;
/*     */       }
/* 101 */       if (FUTURE.compareAndSet(this, f, CANCELLED)) {
/* 102 */         if (f != null) {
/* 103 */           f.cancel((this.thread != Thread.currentThread()));
/*     */         }
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/*     */     while (true) {
/* 110 */       Disposable.Composite o = this.parent;
/* 111 */       if (o == DISPOSED || o == null) {
/*     */         return;
/*     */       }
/* 114 */       if (PARENT.compareAndSet(this, o, DISPOSED)) {
/* 115 */         o.remove(this);
/*     */         return;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\scheduler\PeriodicWorkerTask.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */