/*     */ package reactor.core.scheduler;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.ExecutionException;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.concurrent.ScheduledExecutorService;
/*     */ import java.util.concurrent.ScheduledFuture;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.TimeoutException;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.function.Supplier;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.NonNull;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class DelegateServiceScheduler
/*     */   implements Scheduler, Scannable
/*     */ {
/*     */   final String executorName;
/*     */   final ScheduledExecutorService original;
/*     */   @Nullable
/*     */   volatile ScheduledExecutorService executor;
/*  54 */   static final AtomicReferenceFieldUpdater<DelegateServiceScheduler, ScheduledExecutorService> EXECUTOR = AtomicReferenceFieldUpdater.newUpdater(DelegateServiceScheduler.class, ScheduledExecutorService.class, "executor");
/*     */   
/*     */   DelegateServiceScheduler(String executorName, ExecutorService executorService) {
/*  57 */     this.executorName = executorName;
/*  58 */     this.original = convert(executorService);
/*  59 */     this.executor = null;
/*     */   }
/*     */   
/*     */   ScheduledExecutorService getOrCreate() {
/*  63 */     ScheduledExecutorService e = this.executor;
/*  64 */     if (e == null) {
/*  65 */       start();
/*  66 */       e = this.executor;
/*  67 */       if (e == null) {
/*  68 */         throw new IllegalStateException("executor is null after implicit start()");
/*     */       }
/*     */     } 
/*  71 */     return e;
/*     */   }
/*     */ 
/*     */   
/*     */   public Scheduler.Worker createWorker() {
/*  76 */     return new ExecutorServiceWorker(getOrCreate());
/*     */   }
/*     */ 
/*     */   
/*     */   public Disposable schedule(Runnable task) {
/*  81 */     return Schedulers.directSchedule(getOrCreate(), task, null, 0L, TimeUnit.MILLISECONDS);
/*     */   }
/*     */ 
/*     */   
/*     */   public Disposable schedule(Runnable task, long delay, TimeUnit unit) {
/*  86 */     return Schedulers.directSchedule(getOrCreate(), task, null, delay, unit);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Disposable schedulePeriodically(Runnable task, long initialDelay, long period, TimeUnit unit) {
/*  94 */     return Schedulers.directSchedulePeriodically(getOrCreate(), task, initialDelay, period, unit);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void start() {
/* 103 */     EXECUTOR.compareAndSet(this, null, Schedulers.decorateExecutorService(this, this.original));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDisposed() {
/* 108 */     ScheduledExecutorService e = this.executor;
/* 109 */     return (e != null && e.isShutdown());
/*     */   }
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 114 */     ScheduledExecutorService e = this.executor;
/* 115 */     if (e != null) {
/* 116 */       e.shutdownNow();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static ScheduledExecutorService convert(ExecutorService executor) {
/* 122 */     if (executor instanceof ScheduledExecutorService) {
/* 123 */       return (ScheduledExecutorService)executor;
/*     */     }
/* 125 */     return new UnsupportedScheduledExecutorService(executor);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/* 130 */     if (key == Scannable.Attr.TERMINATED || key == Scannable.Attr.CANCELLED) return Boolean.valueOf(isDisposed()); 
/* 131 */     if (key == Scannable.Attr.NAME) return toString();
/*     */     
/* 133 */     ScheduledExecutorService e = this.executor;
/* 134 */     if (e != null) {
/* 135 */       return Schedulers.scanExecutor(e, key);
/*     */     }
/* 137 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 142 */     return "fromExecutorService(" + this.executorName + ')';
/*     */   }
/*     */   
/*     */   static final class UnsupportedScheduledExecutorService
/*     */     implements ScheduledExecutorService, Supplier<ExecutorService>
/*     */   {
/*     */     final ExecutorService exec;
/*     */     
/*     */     UnsupportedScheduledExecutorService(ExecutorService exec) {
/* 151 */       this.exec = exec;
/*     */     }
/*     */ 
/*     */     
/*     */     public ExecutorService get() {
/* 156 */       return this.exec;
/*     */     }
/*     */ 
/*     */     
/*     */     public void shutdown() {
/* 161 */       this.exec.shutdown();
/*     */     }
/*     */ 
/*     */     
/*     */     @NonNull
/*     */     public List<Runnable> shutdownNow() {
/* 167 */       return this.exec.shutdownNow();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isShutdown() {
/* 172 */       return this.exec.isShutdown();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isTerminated() {
/* 177 */       return this.exec.isTerminated();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean awaitTermination(long timeout, @NonNull TimeUnit unit) throws InterruptedException {
/* 183 */       return this.exec.awaitTermination(timeout, unit);
/*     */     }
/*     */ 
/*     */     
/*     */     @NonNull
/*     */     public <T> Future<T> submit(@NonNull Callable<T> task) {
/* 189 */       return this.exec.submit(task);
/*     */     }
/*     */ 
/*     */     
/*     */     @NonNull
/*     */     public <T> Future<T> submit(@NonNull Runnable task, T result) {
/* 195 */       return this.exec.submit(task, result);
/*     */     }
/*     */ 
/*     */     
/*     */     @NonNull
/*     */     public Future<?> submit(@NonNull Runnable task) {
/* 201 */       return this.exec.submit(task);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     @NonNull
/*     */     public <T> List<Future<T>> invokeAll(@NonNull Collection<? extends Callable<T>> tasks) throws InterruptedException {
/* 208 */       return this.exec.invokeAll(tasks);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @NonNull
/*     */     public <T> List<Future<T>> invokeAll(@NonNull Collection<? extends Callable<T>> tasks, long timeout, @NonNull TimeUnit unit) throws InterruptedException {
/* 216 */       return this.exec.invokeAll(tasks, timeout, unit);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     @NonNull
/*     */     public <T> T invokeAny(@NonNull Collection<? extends Callable<T>> tasks) throws InterruptedException, ExecutionException {
/* 223 */       return this.exec.invokeAny(tasks);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public <T> T invokeAny(@NonNull Collection<? extends Callable<T>> tasks, long timeout, @NonNull TimeUnit unit) throws InterruptedException, ExecutionException, TimeoutException {
/* 231 */       return this.exec.invokeAny(tasks, timeout, unit);
/*     */     }
/*     */ 
/*     */     
/*     */     public void execute(@NonNull Runnable command) {
/* 236 */       this.exec.execute(command);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @NonNull
/*     */     public ScheduledFuture<?> schedule(@NonNull Runnable command, long delay, @NonNull TimeUnit unit) {
/* 244 */       throw Exceptions.failWithRejectedNotTimeCapable();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @NonNull
/*     */     public <V> ScheduledFuture<V> schedule(@NonNull Callable<V> callable, long delay, @NonNull TimeUnit unit) {
/* 252 */       throw Exceptions.failWithRejectedNotTimeCapable();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @NonNull
/*     */     public ScheduledFuture<?> scheduleAtFixedRate(@NonNull Runnable command, long initialDelay, long period, @NonNull TimeUnit unit) {
/* 261 */       throw Exceptions.failWithRejectedNotTimeCapable();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @NonNull
/*     */     public ScheduledFuture<?> scheduleWithFixedDelay(@NonNull Runnable command, long initialDelay, long delay, @NonNull TimeUnit unit) {
/* 270 */       throw Exceptions.failWithRejectedNotTimeCapable();
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 275 */       return this.exec.toString();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\scheduler\DelegateServiceScheduler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */