/*    */ package reactor.core.scheduler;
/*    */ 
/*    */ import java.util.concurrent.ThreadFactory;
/*    */ import java.util.concurrent.atomic.AtomicLong;
/*    */ import java.util.function.BiConsumer;
/*    */ import java.util.function.Supplier;
/*    */ import reactor.util.annotation.NonNull;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ReactorThreadFactory
/*    */   implements ThreadFactory, Supplier<String>, Thread.UncaughtExceptionHandler
/*    */ {
/*    */   private final String name;
/*    */   private final AtomicLong counterReference;
/*    */   private final boolean daemon;
/*    */   private final boolean rejectBlocking;
/*    */   @Nullable
/*    */   private final BiConsumer<Thread, Throwable> uncaughtExceptionHandler;
/*    */   
/*    */   ReactorThreadFactory(String name, AtomicLong counterReference, boolean daemon, boolean rejectBlocking, @Nullable BiConsumer<Thread, Throwable> uncaughtExceptionHandler) {
/* 50 */     this.name = name;
/* 51 */     this.counterReference = counterReference;
/* 52 */     this.daemon = daemon;
/* 53 */     this.rejectBlocking = rejectBlocking;
/* 54 */     this.uncaughtExceptionHandler = uncaughtExceptionHandler;
/*    */   }
/*    */ 
/*    */   
/*    */   public final Thread newThread(@NonNull Runnable runnable) {
/* 59 */     String newThreadName = this.name + "-" + this.counterReference.incrementAndGet();
/* 60 */     Thread t = this.rejectBlocking ? new NonBlockingThread(runnable, newThreadName) : new Thread(runnable, newThreadName);
/*    */ 
/*    */     
/* 63 */     if (this.daemon) {
/* 64 */       t.setDaemon(true);
/*    */     }
/* 66 */     if (this.uncaughtExceptionHandler != null) {
/* 67 */       t.setUncaughtExceptionHandler(this);
/*    */     }
/* 69 */     return t;
/*    */   }
/*    */ 
/*    */   
/*    */   public void uncaughtException(Thread t, Throwable e) {
/* 74 */     if (this.uncaughtExceptionHandler == null) {
/*    */       return;
/*    */     }
/*    */     
/* 78 */     this.uncaughtExceptionHandler.accept(t, e);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final String get() {
/* 89 */     return this.name;
/*    */   }
/*    */   
/*    */   static final class NonBlockingThread
/*    */     extends Thread implements NonBlocking {
/*    */     public NonBlockingThread(Runnable target, String name) {
/* 95 */       super(target, name);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\scheduler\ReactorThreadFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */