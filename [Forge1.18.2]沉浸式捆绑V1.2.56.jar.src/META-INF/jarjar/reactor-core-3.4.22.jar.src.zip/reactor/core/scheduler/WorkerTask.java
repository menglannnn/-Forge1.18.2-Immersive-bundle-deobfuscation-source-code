/*     */ package reactor.core.scheduler;
/*     */ 
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.concurrent.FutureTask;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class WorkerTask
/*     */   implements Runnable, Disposable, Callable<Void>
/*     */ {
/*     */   final Runnable task;
/*  42 */   static final Disposable.Composite DISPOSED = new EmptyCompositeDisposable();
/*     */   
/*  44 */   static final Disposable.Composite DONE = new EmptyCompositeDisposable();
/*     */ 
/*     */ 
/*     */   
/*  48 */   static final Future<Void> FINISHED = new FutureTask<>(() -> null);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  53 */   static final Future<Void> SYNC_CANCELLED = new FutureTask<>(() -> null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  59 */   static final Future<Void> ASYNC_CANCELLED = new FutureTask<>(() -> null);
/*     */   
/*     */   volatile Future<?> future;
/*     */   
/*  63 */   static final AtomicReferenceFieldUpdater<WorkerTask, Future> FUTURE = AtomicReferenceFieldUpdater.newUpdater(WorkerTask.class, Future.class, "future");
/*     */   
/*     */   volatile Disposable.Composite parent;
/*     */   
/*  67 */   static final AtomicReferenceFieldUpdater<WorkerTask, Disposable.Composite> PARENT = AtomicReferenceFieldUpdater.newUpdater(WorkerTask.class, Disposable.Composite.class, "parent");
/*     */   
/*     */   volatile Thread thread;
/*     */   
/*  71 */   static final AtomicReferenceFieldUpdater<WorkerTask, Thread> THREAD = AtomicReferenceFieldUpdater.newUpdater(WorkerTask.class, Thread.class, "thread");
/*     */   
/*     */   WorkerTask(Runnable task, Disposable.Composite parent) {
/*  74 */     this.task = task;
/*  75 */     PARENT.lazySet(this, parent);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Void call() {
/*  81 */     THREAD.lazySet(this, Thread.currentThread());
/*     */     try {
/*     */       try {
/*  84 */         this.task.run();
/*     */       }
/*  86 */       catch (Throwable ex) {
/*  87 */         Schedulers.handleError(ex);
/*     */       } 
/*     */     } finally {
/*     */       Future<?> f;
/*  91 */       THREAD.lazySet(this, null);
/*  92 */       Disposable.Composite o = this.parent;
/*     */       
/*  94 */       if (o != DISPOSED && PARENT.compareAndSet(this, o, DONE) && o != null) {
/*  95 */         o.remove(this);
/*     */       }
/*     */ 
/*     */       
/*     */       do {
/* 100 */         f = this.future;
/* 101 */       } while (f != SYNC_CANCELLED && f != ASYNC_CANCELLED && !FUTURE.compareAndSet(this, f, FINISHED));
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 106 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void run() {
/* 111 */     call();
/*     */   }
/*     */   void setFuture(Future<?> f) {
/*     */     Future<?> o;
/*     */     do {
/* 116 */       o = this.future;
/* 117 */       if (o == FINISHED) {
/*     */         return;
/*     */       }
/* 120 */       if (o == SYNC_CANCELLED) {
/* 121 */         f.cancel(false);
/*     */         return;
/*     */       } 
/* 124 */       if (o == ASYNC_CANCELLED) {
/* 125 */         f.cancel(true);
/*     */         return;
/*     */       } 
/* 128 */     } while (!FUTURE.compareAndSet(this, o, f));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDisposed() {
/* 136 */     Disposable.Composite o = PARENT.get(this);
/* 137 */     return (o == DISPOSED || o == DONE);
/*     */   }
/*     */ 
/*     */   
/*     */   public void dispose() {
/*     */     while (true) {
/* 143 */       Future<?> f = this.future;
/* 144 */       if (f == FINISHED || f == SYNC_CANCELLED || f == ASYNC_CANCELLED) {
/*     */         break;
/*     */       }
/* 147 */       boolean async = (this.thread != Thread.currentThread());
/* 148 */       if (FUTURE.compareAndSet(this, f, async ? ASYNC_CANCELLED : SYNC_CANCELLED)) {
/* 149 */         if (f != null) {
/* 150 */           f.cancel(async);
/*     */         }
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/*     */     while (true) {
/* 157 */       Disposable.Composite o = this.parent;
/* 158 */       if (o == DONE || o == DISPOSED || o == null) {
/*     */         return;
/*     */       }
/* 161 */       if (PARENT.compareAndSet(this, o, DISPOSED)) {
/* 162 */         o.remove(this);
/*     */         return;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\scheduler\WorkerTask.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */