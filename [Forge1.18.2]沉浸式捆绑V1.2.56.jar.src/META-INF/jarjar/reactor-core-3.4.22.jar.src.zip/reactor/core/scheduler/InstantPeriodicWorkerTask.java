/*     */ package reactor.core.scheduler;
/*     */ 
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.concurrent.FutureTask;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class InstantPeriodicWorkerTask
/*     */   implements Disposable, Callable<Void>
/*     */ {
/*     */   final Runnable task;
/*     */   final ExecutorService executor;
/*  37 */   static final Disposable.Composite DISPOSED = new EmptyCompositeDisposable();
/*     */   
/*  39 */   static final Future<Void> CANCELLED = new FutureTask<>(() -> null);
/*     */   
/*     */   volatile Future<?> rest;
/*     */   
/*  43 */   static final AtomicReferenceFieldUpdater<InstantPeriodicWorkerTask, Future> REST = AtomicReferenceFieldUpdater.newUpdater(InstantPeriodicWorkerTask.class, Future.class, "rest");
/*     */   
/*     */   volatile Future<?> first;
/*     */   
/*  47 */   static final AtomicReferenceFieldUpdater<InstantPeriodicWorkerTask, Future> FIRST = AtomicReferenceFieldUpdater.newUpdater(InstantPeriodicWorkerTask.class, Future.class, "first");
/*     */   
/*     */   volatile Disposable.Composite parent;
/*     */   
/*  51 */   static final AtomicReferenceFieldUpdater<InstantPeriodicWorkerTask, Disposable.Composite> PARENT = AtomicReferenceFieldUpdater.newUpdater(InstantPeriodicWorkerTask.class, Disposable.Composite.class, "parent");
/*     */   
/*     */   Thread thread;
/*     */   
/*     */   InstantPeriodicWorkerTask(Runnable task, ExecutorService executor) {
/*  56 */     this.task = task;
/*  57 */     this.executor = executor;
/*     */   }
/*     */   
/*     */   InstantPeriodicWorkerTask(Runnable task, ExecutorService executor, Disposable.Composite parent) {
/*  61 */     this.task = task;
/*  62 */     this.executor = executor;
/*  63 */     PARENT.lazySet(this, parent);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Void call() {
/*  69 */     this.thread = Thread.currentThread();
/*     */     try {
/*     */       try {
/*  72 */         this.task.run();
/*  73 */         setRest(this.executor.submit(this));
/*     */       }
/*  75 */       catch (Throwable ex) {
/*  76 */         Schedulers.handleError(ex);
/*     */       } 
/*     */     } finally {
/*     */       
/*  80 */       this.thread = null;
/*     */     } 
/*  82 */     return null;
/*     */   }
/*     */   void setRest(Future<?> f) {
/*     */     Future<?> o;
/*     */     do {
/*  87 */       o = this.rest;
/*  88 */       if (o == CANCELLED) {
/*  89 */         f.cancel((this.thread != Thread.currentThread()));
/*     */         return;
/*     */       } 
/*  92 */     } while (!REST.compareAndSet(this, o, f));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void setFirst(Future<?> f) {
/*     */     Future<?> o;
/*     */     do {
/* 100 */       o = this.first;
/* 101 */       if (o == CANCELLED) {
/* 102 */         f.cancel((this.thread != Thread.currentThread()));
/*     */         return;
/*     */       } 
/* 105 */     } while (!FIRST.compareAndSet(this, o, f));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDisposed() {
/* 113 */     return (this.rest == CANCELLED);
/*     */   }
/*     */ 
/*     */   
/*     */   public void dispose() {
/*     */     while (true) {
/* 119 */       Future<?> f = this.first;
/* 120 */       if (f == CANCELLED) {
/*     */         break;
/*     */       }
/* 123 */       if (FIRST.compareAndSet(this, f, CANCELLED)) {
/* 124 */         if (f != null) {
/* 125 */           f.cancel((this.thread != Thread.currentThread()));
/*     */         }
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/*     */     while (true) {
/* 132 */       Future<?> f = this.rest;
/* 133 */       if (f == CANCELLED) {
/*     */         break;
/*     */       }
/* 136 */       if (REST.compareAndSet(this, f, CANCELLED)) {
/* 137 */         if (f != null) {
/* 138 */           f.cancel((this.thread != Thread.currentThread()));
/*     */         }
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/*     */     while (true) {
/* 145 */       Disposable.Composite o = this.parent;
/* 146 */       if (o == DISPOSED || o == null) {
/*     */         return;
/*     */       }
/* 149 */       if (PARENT.compareAndSet(this, o, DISPOSED)) {
/* 150 */         o.remove(this);
/*     */         return;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\scheduler\InstantPeriodicWorkerTask.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */