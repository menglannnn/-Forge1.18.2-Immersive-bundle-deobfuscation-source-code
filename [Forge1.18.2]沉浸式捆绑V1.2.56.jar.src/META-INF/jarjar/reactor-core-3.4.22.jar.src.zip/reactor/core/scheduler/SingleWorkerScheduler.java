/*    */ package reactor.core.scheduler;
/*    */ 
/*    */ import java.util.concurrent.Executor;
/*    */ import java.util.concurrent.TimeUnit;
/*    */ import reactor.core.Disposable;
/*    */ import reactor.core.Scannable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class SingleWorkerScheduler
/*    */   implements Scheduler, Executor, Scannable
/*    */ {
/*    */   final Scheduler.Worker main;
/*    */   
/*    */   SingleWorkerScheduler(Scheduler actual) {
/* 38 */     this.main = actual.createWorker();
/*    */   }
/*    */ 
/*    */   
/*    */   public void dispose() {
/* 43 */     this.main.dispose();
/*    */   }
/*    */ 
/*    */   
/*    */   public Disposable schedule(Runnable task) {
/* 48 */     return this.main.schedule(task);
/*    */   }
/*    */ 
/*    */   
/*    */   public Disposable schedule(Runnable task, long delay, TimeUnit unit) {
/* 53 */     return this.main.schedule(task, delay, unit);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Disposable schedulePeriodically(Runnable task, long initialDelay, long period, TimeUnit unit) {
/* 59 */     return this.main.schedulePeriodically(task, initialDelay, period, unit);
/*    */   }
/*    */ 
/*    */   
/*    */   public void execute(Runnable command) {
/* 64 */     this.main.schedule(command);
/*    */   }
/*    */ 
/*    */   
/*    */   public Scheduler.Worker createWorker() {
/* 69 */     return new ExecutorScheduler.ExecutorSchedulerWorker(this);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isDisposed() {
/* 74 */     return this.main.isDisposed();
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 79 */     Scannable mainScannable = Scannable.from(this.main);
/* 80 */     if (mainScannable.isScanAvailable()) {
/* 81 */       return "singleWorker(" + mainScannable.scanUnsafe(Scannable.Attr.NAME) + ")";
/*    */     }
/* 83 */     return "singleWorker(" + this.main.toString() + ")";
/*    */   }
/*    */ 
/*    */   
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 88 */     if (key == Scannable.Attr.TERMINATED || key == Scannable.Attr.CANCELLED) return Boolean.valueOf(isDisposed()); 
/* 89 */     if (key == Scannable.Attr.PARENT) return this.main; 
/* 90 */     if (key == Scannable.Attr.NAME) return toString();
/*    */     
/* 92 */     return Scannable.from(this.main).scanUnsafe(key);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\scheduler\SingleWorkerScheduler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */