/*    */ package reactor.core.scheduler;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import reactor.core.Disposable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class EmptyCompositeDisposable
/*    */   implements Disposable.Composite
/*    */ {
/*    */   public boolean add(Disposable d) {
/* 27 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean addAll(Collection<? extends Disposable> ds) {
/* 32 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean remove(Disposable d) {
/* 37 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public int size() {
/* 42 */     return 0;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void dispose() {}
/*    */ 
/*    */   
/*    */   public boolean isDisposed() {
/* 51 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\scheduler\EmptyCompositeDisposable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */