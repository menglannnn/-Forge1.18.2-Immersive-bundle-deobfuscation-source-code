/*     */ package reactor.core.scheduler;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Deque;
/*     */ import java.util.List;
/*     */ import java.util.Queue;
/*     */ import java.util.concurrent.ConcurrentLinkedDeque;
/*     */ import java.util.concurrent.ConcurrentLinkedQueue;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.ScheduledExecutorService;
/*     */ import java.util.concurrent.ScheduledThreadPoolExecutor;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ import java.util.stream.Stream;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.Disposables;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ElasticScheduler
/*     */   implements Scheduler, Scannable
/*     */ {
/*     */   static final ThreadFactory EVICTOR_FACTORY;
/*  57 */   static final AtomicLong COUNTER = new AtomicLong();
/*     */   static {
/*  59 */     EVICTOR_FACTORY = (r -> {
/*     */         Thread t = new Thread(r, "elastic-evictor-" + COUNTER.incrementAndGet());
/*     */         t.setDaemon(true);
/*     */         return t;
/*     */       });
/*     */   }
/*  65 */   static final CachedService SHUTDOWN = new CachedService(null);
/*     */ 
/*     */   
/*     */   static final int DEFAULT_TTL_SECONDS = 60;
/*     */   
/*     */   final ThreadFactory factory;
/*     */   
/*     */   final int ttlSeconds;
/*     */   
/*     */   final Deque<ScheduledExecutorServiceExpiry> cache;
/*     */   
/*     */   final Queue<CachedService> all;
/*     */   
/*     */   ScheduledExecutorService evictor;
/*     */   
/*     */   volatile boolean shutdown;
/*     */ 
/*     */   
/*     */   ElasticScheduler(ThreadFactory factory, int ttlSeconds) {
/*  84 */     if (ttlSeconds < 0) {
/*  85 */       throw new IllegalArgumentException("ttlSeconds must be positive, was: " + ttlSeconds);
/*     */     }
/*  87 */     this.ttlSeconds = ttlSeconds;
/*  88 */     this.factory = factory;
/*  89 */     this.cache = new ConcurrentLinkedDeque<>();
/*  90 */     this.all = new ConcurrentLinkedQueue<>();
/*     */     
/*  92 */     this.shutdown = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ScheduledExecutorService createUndecoratedService() {
/* 100 */     ScheduledThreadPoolExecutor poolExecutor = new ScheduledThreadPoolExecutor(1, this.factory);
/* 101 */     poolExecutor.setMaximumPoolSize(1);
/* 102 */     poolExecutor.setRemoveOnCancelPolicy(true);
/* 103 */     return poolExecutor;
/*     */   }
/*     */ 
/*     */   
/*     */   public void start() {
/* 108 */     if (!this.shutdown) {
/*     */       return;
/*     */     }
/* 111 */     this.evictor = Executors.newScheduledThreadPool(1, EVICTOR_FACTORY);
/* 112 */     this.evictor.scheduleAtFixedRate(this::eviction, this.ttlSeconds, this.ttlSeconds, TimeUnit.SECONDS);
/*     */ 
/*     */ 
/*     */     
/* 116 */     this.shutdown = false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDisposed() {
/* 121 */     return this.shutdown;
/*     */   }
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 126 */     if (this.shutdown) {
/*     */       return;
/*     */     }
/* 129 */     this.shutdown = true;
/*     */     
/* 131 */     this.evictor.shutdownNow();
/*     */     
/* 133 */     this.cache.clear();
/*     */     
/*     */     CachedService cached;
/*     */     
/* 137 */     while ((cached = this.all.poll()) != null) {
/* 138 */       cached.exec.shutdownNow();
/*     */     }
/*     */   }
/*     */   
/*     */   CachedService pick() {
/* 143 */     if (this.shutdown) {
/* 144 */       return SHUTDOWN;
/*     */     }
/*     */     
/* 147 */     ScheduledExecutorServiceExpiry e = this.cache.pollLast();
/* 148 */     if (e != null) {
/* 149 */       return e.cached;
/*     */     }
/*     */     
/* 152 */     CachedService result = new CachedService(this);
/* 153 */     this.all.offer(result);
/* 154 */     if (this.shutdown) {
/* 155 */       this.all.remove(result);
/* 156 */       return SHUTDOWN;
/*     */     } 
/* 158 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public Disposable schedule(Runnable task) {
/* 163 */     CachedService cached = pick();
/*     */     
/* 165 */     return Schedulers.directSchedule(cached.exec, task, cached, 0L, TimeUnit.MILLISECONDS);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Disposable schedule(Runnable task, long delay, TimeUnit unit) {
/* 174 */     CachedService cached = pick();
/*     */     
/* 176 */     return Schedulers.directSchedule(cached.exec, task, cached, delay, unit);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Disposable schedulePeriodically(Runnable task, long initialDelay, long period, TimeUnit unit) {
/* 185 */     CachedService cached = pick();
/*     */     
/* 187 */     return (Disposable)Disposables.composite(new Disposable[] { Schedulers.directSchedulePeriodically(cached.exec, task, initialDelay, period, unit), cached });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 197 */     StringBuilder ts = (new StringBuilder("elastic")).append('(');
/* 198 */     if (this.factory instanceof ReactorThreadFactory) {
/* 199 */       ts.append('"').append(((ReactorThreadFactory)this.factory).get()).append('"');
/*     */     }
/* 201 */     ts.append(')');
/* 202 */     return ts.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/* 207 */     if (key == Scannable.Attr.TERMINATED || key == Scannable.Attr.CANCELLED) return Boolean.valueOf(isDisposed()); 
/* 208 */     if (key == Scannable.Attr.CAPACITY) return Integer.valueOf(2147483647); 
/* 209 */     if (key == Scannable.Attr.BUFFERED) return Integer.valueOf(this.cache.size()); 
/* 210 */     if (key == Scannable.Attr.NAME) return toString();
/*     */     
/* 212 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Stream<? extends Scannable> inners() {
/* 217 */     return this.cache.stream()
/* 218 */       .map(cached -> cached.cached);
/*     */   }
/*     */ 
/*     */   
/*     */   public Scheduler.Worker createWorker() {
/* 223 */     return new ElasticWorker(pick());
/*     */   }
/*     */   
/*     */   void eviction() {
/* 227 */     long now = System.currentTimeMillis();
/*     */     
/* 229 */     List<ScheduledExecutorServiceExpiry> list = new ArrayList<>(this.cache);
/* 230 */     for (ScheduledExecutorServiceExpiry e : list) {
/* 231 */       if (e.expireMillis < now && 
/* 232 */         this.cache.remove(e)) {
/* 233 */         e.cached.exec.shutdownNow();
/* 234 */         this.all.remove(e.cached);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   static final class CachedService
/*     */     implements Disposable, Scannable
/*     */   {
/*     */     final ElasticScheduler parent;
/*     */     final ScheduledExecutorService exec;
/*     */     
/*     */     CachedService(@Nullable ElasticScheduler parent) {
/* 246 */       this.parent = parent;
/* 247 */       if (parent != null) {
/* 248 */         this.exec = Schedulers.decorateExecutorService(parent, parent.createUndecoratedService());
/*     */       } else {
/*     */         
/* 251 */         this.exec = Executors.newSingleThreadScheduledExecutor();
/* 252 */         this.exec.shutdownNow();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void dispose() {
/* 258 */       if (this.exec != null && 
/* 259 */         this != ElasticScheduler.SHUTDOWN && !this.parent.shutdown) {
/*     */ 
/*     */         
/* 262 */         ElasticScheduler.ScheduledExecutorServiceExpiry e = new ElasticScheduler.ScheduledExecutorServiceExpiry(this, System.currentTimeMillis() + this.parent.ttlSeconds * 1000L);
/* 263 */         this.parent.cache.offerLast(e);
/* 264 */         if (this.parent.shutdown && 
/* 265 */           this.parent.cache.remove(e)) {
/* 266 */           this.exec.shutdownNow();
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 275 */       if (key == Scannable.Attr.NAME) return this.parent.scanUnsafe(key); 
/* 276 */       if (key == Scannable.Attr.PARENT) return this.parent; 
/* 277 */       if (key == Scannable.Attr.TERMINATED || key == Scannable.Attr.CANCELLED) return Boolean.valueOf(isDisposed()); 
/* 278 */       if (key == Scannable.Attr.CAPACITY) {
/*     */         
/* 280 */         Integer capacity = (Integer)Schedulers.scanExecutor(this.exec, key);
/* 281 */         if (capacity == null || capacity.intValue() == -1) return Integer.valueOf(1); 
/*     */       } 
/* 283 */       return Schedulers.scanExecutor(this.exec, key);
/*     */     }
/*     */   }
/*     */   
/*     */   static final class ScheduledExecutorServiceExpiry
/*     */   {
/*     */     final ElasticScheduler.CachedService cached;
/*     */     final long expireMillis;
/*     */     
/*     */     ScheduledExecutorServiceExpiry(ElasticScheduler.CachedService cached, long expireMillis) {
/* 293 */       this.cached = cached;
/* 294 */       this.expireMillis = expireMillis;
/*     */     }
/*     */   }
/*     */   
/*     */   static final class ElasticWorker
/*     */     extends AtomicBoolean
/*     */     implements Scheduler.Worker, Scannable {
/*     */     final ElasticScheduler.CachedService cached;
/*     */     final Disposable.Composite tasks;
/*     */     
/*     */     ElasticWorker(ElasticScheduler.CachedService cached) {
/* 305 */       this.cached = cached;
/* 306 */       this.tasks = Disposables.composite();
/*     */     }
/*     */ 
/*     */     
/*     */     public Disposable schedule(Runnable task) {
/* 311 */       return Schedulers.workerSchedule(this.cached.exec, this.tasks, task, 0L, TimeUnit.MILLISECONDS);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Disposable schedule(Runnable task, long delay, TimeUnit unit) {
/* 320 */       return Schedulers.workerSchedule(this.cached.exec, this.tasks, task, delay, unit);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Disposable schedulePeriodically(Runnable task, long initialDelay, long period, TimeUnit unit) {
/* 328 */       return Schedulers.workerSchedulePeriodically(this.cached.exec, this.tasks, task, initialDelay, period, unit);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void dispose() {
/* 338 */       if (compareAndSet(false, true)) {
/* 339 */         this.tasks.dispose();
/* 340 */         this.cached.dispose();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isDisposed() {
/* 346 */       return this.tasks.isDisposed();
/*     */     }
/*     */ 
/*     */     
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 351 */       if (key == Scannable.Attr.TERMINATED || key == Scannable.Attr.CANCELLED) return Boolean.valueOf(isDisposed()); 
/* 352 */       if (key == Scannable.Attr.NAME) return this.cached.scanUnsafe(key) + ".worker"; 
/* 353 */       if (key == Scannable.Attr.PARENT) return this.cached.parent;
/*     */       
/* 355 */       return this.cached.scanUnsafe(key);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\scheduler\ElasticScheduler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */