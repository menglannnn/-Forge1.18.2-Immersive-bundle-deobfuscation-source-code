/*     */ package reactor.core.scheduler;
/*     */ 
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.Disposables;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Scannable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ImmediateScheduler
/*     */   implements Scheduler, Scannable
/*     */ {
/*  37 */   private static final ImmediateScheduler INSTANCE = new ImmediateScheduler(); static {
/*  38 */     INSTANCE.start();
/*     */   }
/*     */   
/*     */   public static Scheduler instance() {
/*  42 */     return INSTANCE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  48 */   static final Disposable FINISHED = Disposables.disposed();
/*     */ 
/*     */   
/*     */   public Disposable schedule(Runnable task) {
/*  52 */     task.run();
/*  53 */     return FINISHED;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispose() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  64 */     if (key == Scannable.Attr.TERMINATED || key == Scannable.Attr.CANCELLED) return Boolean.valueOf(isDisposed()); 
/*  65 */     if (key == Scannable.Attr.NAME) return "immediate";
/*     */     
/*  67 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Scheduler.Worker createWorker() {
/*  72 */     return new ImmediateSchedulerWorker();
/*     */   }
/*     */   
/*     */   static final class ImmediateSchedulerWorker
/*     */     implements Scheduler.Worker, Scannable
/*     */   {
/*     */     volatile boolean shutdown;
/*     */     
/*     */     public Disposable schedule(Runnable task) {
/*  81 */       if (this.shutdown) {
/*  82 */         throw Exceptions.failWithRejected();
/*     */       }
/*  84 */       task.run();
/*  85 */       return ImmediateScheduler.FINISHED;
/*     */     }
/*     */ 
/*     */     
/*     */     public void dispose() {
/*  90 */       this.shutdown = true;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isDisposed() {
/*  95 */       return this.shutdown;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 100 */       if (key == Scannable.Attr.TERMINATED || key == Scannable.Attr.CANCELLED) return Boolean.valueOf(this.shutdown); 
/* 101 */       if (key == Scannable.Attr.NAME) return "immediate.worker";
/*     */       
/* 103 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\scheduler\ImmediateScheduler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */