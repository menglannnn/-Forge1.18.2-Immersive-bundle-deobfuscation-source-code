/*      */ package reactor.core.scheduler;
/*      */ 
/*      */ import java.util.Collection;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.Map;
/*      */ import java.util.Objects;
/*      */ import java.util.Optional;
/*      */ import java.util.concurrent.Executor;
/*      */ import java.util.concurrent.ExecutorService;
/*      */ import java.util.concurrent.Future;
/*      */ import java.util.concurrent.RejectedExecutionException;
/*      */ import java.util.concurrent.ScheduledExecutorService;
/*      */ import java.util.concurrent.ThreadFactory;
/*      */ import java.util.concurrent.ThreadPoolExecutor;
/*      */ import java.util.concurrent.TimeUnit;
/*      */ import java.util.concurrent.atomic.AtomicReference;
/*      */ import java.util.function.BiConsumer;
/*      */ import java.util.function.BiFunction;
/*      */ import java.util.function.Function;
/*      */ import java.util.function.Supplier;
/*      */ import reactor.core.Disposable;
/*      */ import reactor.core.Exceptions;
/*      */ import reactor.core.Scannable;
/*      */ import reactor.util.Logger;
/*      */ import reactor.util.Loggers;
/*      */ import reactor.util.Metrics;
/*      */ import reactor.util.annotation.Nullable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class Schedulers
/*      */ {
/*   80 */   public static final int DEFAULT_POOL_SIZE = ((Integer)Optional.<String>ofNullable(System.getProperty("reactor.schedulers.defaultPoolSize"))
/*   81 */     .map(Integer::parseInt)
/*   82 */     .orElseGet(() -> Integer.valueOf(Runtime.getRuntime().availableProcessors()))).intValue();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   93 */   public static final int DEFAULT_BOUNDED_ELASTIC_SIZE = ((Integer)Optional.<String>ofNullable(System.getProperty("reactor.schedulers.defaultBoundedElasticSize"))
/*   94 */     .map(Integer::parseInt)
/*   95 */     .orElseGet(() -> Integer.valueOf(10 * Runtime.getRuntime().availableProcessors()))).intValue();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  105 */   public static final int DEFAULT_BOUNDED_ELASTIC_QUEUESIZE = ((Integer)Optional.<String>ofNullable(System.getProperty("reactor.schedulers.defaultBoundedElasticQueueSize"))
/*  106 */     .map(Integer::parseInt)
/*  107 */     .orElse(Integer.valueOf(100000))).intValue();
/*      */   
/*      */   static final String ELASTIC = "elastic";
/*      */   
/*      */   static final String BOUNDED_ELASTIC = "boundedElastic";
/*      */   
/*      */   static final String PARALLEL = "parallel";
/*      */   
/*      */   static final String SINGLE = "single";
/*      */   
/*      */   static final String IMMEDIATE = "immediate";
/*      */   static final String FROM_EXECUTOR = "fromExecutor";
/*      */   static final String FROM_EXECUTOR_SERVICE = "fromExecutorService";
/*      */   
/*      */   public static Scheduler fromExecutor(Executor executor) {
/*  122 */     return fromExecutor(executor, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Scheduler fromExecutor(Executor executor, boolean trampoline) {
/*  140 */     if (!trampoline && executor instanceof ExecutorService) {
/*  141 */       return fromExecutorService((ExecutorService)executor);
/*      */     }
/*  143 */     ExecutorScheduler scheduler = new ExecutorScheduler(executor, trampoline);
/*  144 */     scheduler.start();
/*  145 */     return scheduler;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Scheduler fromExecutorService(ExecutorService executorService) {
/*  160 */     String executorServiceHashcode = Integer.toHexString(System.identityHashCode(executorService));
/*  161 */     return fromExecutorService(executorService, "anonymousExecutor@" + executorServiceHashcode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Scheduler fromExecutorService(ExecutorService executorService, String executorName) {
/*  173 */     DelegateServiceScheduler scheduler = new DelegateServiceScheduler(executorName, executorService);
/*  174 */     scheduler.start();
/*  175 */     return scheduler;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static Scheduler elastic() {
/*  196 */     return cache(CACHED_ELASTIC, "elastic", ELASTIC_SUPPLIER);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Scheduler boundedElastic() {
/*  233 */     return cache(CACHED_BOUNDED_ELASTIC, "boundedElastic", BOUNDED_ELASTIC_SUPPLIER);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Scheduler parallel() {
/*  251 */     return cache(CACHED_PARALLEL, "parallel", PARALLEL_SUPPLIER);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Scheduler immediate() {
/*  265 */     return ImmediateScheduler.instance();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static Scheduler newElastic(String name) {
/*  288 */     return newElastic(name, 60);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static Scheduler newElastic(String name, int ttlSeconds) {
/*  309 */     return newElastic(name, ttlSeconds, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static Scheduler newElastic(String name, int ttlSeconds, boolean daemon) {
/*  332 */     return newElastic(ttlSeconds, new ReactorThreadFactory(name, ElasticScheduler.COUNTER, daemon, false, Schedulers::defaultUncaughtException));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static Scheduler newElastic(int ttlSeconds, ThreadFactory threadFactory) {
/*  355 */     Scheduler fromFactory = factory.newElastic(ttlSeconds, threadFactory);
/*  356 */     fromFactory.start();
/*  357 */     return fromFactory;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Scheduler newBoundedElastic(int threadCap, int queuedTaskCap, String name) {
/*  393 */     return newBoundedElastic(threadCap, queuedTaskCap, name, 60, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Scheduler newBoundedElastic(int threadCap, int queuedTaskCap, String name, int ttlSeconds) {
/*  429 */     return newBoundedElastic(threadCap, queuedTaskCap, name, ttlSeconds, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Scheduler newBoundedElastic(int threadCap, int queuedTaskCap, String name, int ttlSeconds, boolean daemon) {
/*  467 */     return newBoundedElastic(threadCap, queuedTaskCap, new ReactorThreadFactory(name, ElasticScheduler.COUNTER, daemon, false, Schedulers::defaultUncaughtException), ttlSeconds);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Scheduler newBoundedElastic(int threadCap, int queuedTaskCap, ThreadFactory threadFactory, int ttlSeconds) {
/*  507 */     Scheduler fromFactory = factory.newBoundedElastic(threadCap, queuedTaskCap, threadFactory, ttlSeconds);
/*      */ 
/*      */ 
/*      */     
/*  511 */     fromFactory.start();
/*  512 */     return fromFactory;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Scheduler newParallel(String name) {
/*  526 */     return newParallel(name, DEFAULT_POOL_SIZE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Scheduler newParallel(String name, int parallelism) {
/*  541 */     return newParallel(name, parallelism, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Scheduler newParallel(String name, int parallelism, boolean daemon) {
/*  558 */     return newParallel(parallelism, new ReactorThreadFactory(name, ParallelScheduler.COUNTER, daemon, true, Schedulers::defaultUncaughtException));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Scheduler newParallel(int parallelism, ThreadFactory threadFactory) {
/*  575 */     Scheduler fromFactory = factory.newParallel(parallelism, threadFactory);
/*  576 */     fromFactory.start();
/*  577 */     return fromFactory;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Scheduler newSingle(String name) {
/*  590 */     return newSingle(name, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Scheduler newSingle(String name, boolean daemon) {
/*  605 */     return newSingle(new ReactorThreadFactory(name, SingleScheduler.COUNTER, daemon, true, Schedulers::defaultUncaughtException));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Scheduler newSingle(ThreadFactory threadFactory) {
/*  619 */     Scheduler fromFactory = factory.newSingle(threadFactory);
/*  620 */     fromFactory.start();
/*  621 */     return fromFactory;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void onHandleError(BiConsumer<Thread, ? super Throwable> subHook) {
/*  638 */     Objects.requireNonNull(subHook, "onHandleError");
/*  639 */     if (LOGGER.isDebugEnabled()) {
/*  640 */       LOGGER.debug("Hooking onHandleError anonymous part");
/*      */     }
/*  642 */     synchronized (LOGGER) {
/*  643 */       onHandleErrorHooks.put(Schedulers.class.getName() + ".ON_HANDLE_ERROR_ANONYMOUS_PART", subHook);
/*  644 */       onHandleErrorHook = createOrAppendHandleError(onHandleErrorHooks.values());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void onHandleError(String key, BiConsumer<Thread, ? super Throwable> subHook) {
/*  664 */     Objects.requireNonNull(key, "key");
/*  665 */     Objects.requireNonNull(subHook, "onHandleError");
/*  666 */     if (LOGGER.isDebugEnabled()) {
/*  667 */       LOGGER.debug("Hooking onHandleError part with key {}", new Object[] { key });
/*      */     }
/*  669 */     synchronized (LOGGER) {
/*  670 */       onHandleErrorHooks.put(key, subHook);
/*  671 */       onHandleErrorHook = createOrAppendHandleError(onHandleErrorHooks.values());
/*      */     } 
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   private static BiConsumer<Thread, ? super Throwable> createOrAppendHandleError(Collection<BiConsumer<Thread, Throwable>> subHooks) {
/*  677 */     BiConsumer<Thread, Throwable> composite = null;
/*  678 */     for (BiConsumer<Thread, Throwable> value : subHooks) {
/*  679 */       if (composite != null) {
/*  680 */         composite = composite.andThen(value);
/*      */         continue;
/*      */       } 
/*  683 */       composite = value;
/*      */     } 
/*      */     
/*  686 */     return composite;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isInNonBlockingThread() {
/*  697 */     return Thread.currentThread() instanceof NonBlocking;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isNonBlockingThread(Thread t) {
/*  708 */     return t instanceof NonBlocking;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void enableMetrics() {
/*  726 */     if (Metrics.isInstrumentationAvailable()) {
/*  727 */       addExecutorServiceDecorator("reactor.metrics.decorator", new SchedulerMetricDecorator());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void disableMetrics() {
/*  736 */     removeExecutorServiceDecorator("reactor.metrics.decorator");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void resetFactory() {
/*  743 */     setFactory(DEFAULT);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Snapshot setFactoryWithSnapshot(Factory newFactory) {
/*  764 */     Snapshot snapshot = new Snapshot(CACHED_ELASTIC.getAndSet(null), CACHED_BOUNDED_ELASTIC.getAndSet(null), CACHED_PARALLEL.getAndSet(null), CACHED_SINGLE.getAndSet(null), factory);
/*      */     
/*  766 */     setFactory(newFactory);
/*  767 */     return snapshot;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void resetFrom(@Nullable Snapshot snapshot) {
/*  777 */     if (snapshot == null) {
/*  778 */       resetFactory();
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/*  783 */     CachedScheduler oldElastic = CACHED_ELASTIC.getAndSet(snapshot.oldElasticScheduler);
/*  784 */     CachedScheduler oldBoundedElastic = CACHED_BOUNDED_ELASTIC.getAndSet(snapshot.oldBoundedElasticScheduler);
/*  785 */     CachedScheduler oldParallel = CACHED_PARALLEL.getAndSet(snapshot.oldParallelScheduler);
/*  786 */     CachedScheduler oldSingle = CACHED_SINGLE.getAndSet(snapshot.oldSingleScheduler);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  791 */     factory = snapshot.oldFactory;
/*      */ 
/*      */     
/*  794 */     if (oldElastic != null) oldElastic._dispose(); 
/*  795 */     if (oldBoundedElastic != null) oldBoundedElastic._dispose(); 
/*  796 */     if (oldParallel != null) oldParallel._dispose(); 
/*  797 */     if (oldSingle != null) oldSingle._dispose();
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void resetOnHandleError() {
/*  808 */     if (LOGGER.isDebugEnabled()) {
/*  809 */       LOGGER.debug("Reset to factory defaults: onHandleError");
/*      */     }
/*  811 */     synchronized (LOGGER) {
/*  812 */       onHandleErrorHooks.clear();
/*  813 */       onHandleErrorHook = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void resetOnHandleError(String key) {
/*  822 */     if (LOGGER.isDebugEnabled()) {
/*  823 */       LOGGER.debug("Remove onHandleError sub-hook {}", new Object[] { key });
/*      */     }
/*  825 */     synchronized (LOGGER) {
/*      */ 
/*      */       
/*  828 */       if (onHandleErrorHooks.remove(key) != null) {
/*  829 */         onHandleErrorHook = createOrAppendHandleError(onHandleErrorHooks.values());
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setFactory(Factory factoryInstance) {
/*  846 */     Objects.requireNonNull(factoryInstance, "factoryInstance");
/*  847 */     shutdownNow();
/*  848 */     factory = factoryInstance;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean addExecutorServiceDecorator(String key, BiFunction<Scheduler, ScheduledExecutorService, ScheduledExecutorService> decorator) {
/*  868 */     synchronized (DECORATORS) {
/*  869 */       return (DECORATORS.putIfAbsent(key, decorator) == null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setExecutorServiceDecorator(String key, BiFunction<Scheduler, ScheduledExecutorService, ScheduledExecutorService> decorator) {
/*  888 */     synchronized (DECORATORS) {
/*  889 */       DECORATORS.put(key, decorator);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BiFunction<Scheduler, ScheduledExecutorService, ScheduledExecutorService> removeExecutorServiceDecorator(String key) {
/*      */     BiFunction<Scheduler, ScheduledExecutorService, ScheduledExecutorService> removed;
/*  907 */     synchronized (DECORATORS) {
/*  908 */       removed = DECORATORS.remove(key);
/*      */     } 
/*  910 */     if (removed instanceof Disposable) {
/*  911 */       ((Disposable)removed).dispose();
/*      */     }
/*  913 */     return removed;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ScheduledExecutorService decorateExecutorService(Scheduler owner, ScheduledExecutorService original) {
/*  934 */     synchronized (DECORATORS) {
/*  935 */       for (BiFunction<Scheduler, ScheduledExecutorService, ScheduledExecutorService> decorator : DECORATORS.values()) {
/*  936 */         original = decorator.apply(owner, original);
/*      */       }
/*      */     } 
/*      */     
/*  940 */     return original;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void onScheduleHook(String key, Function<Runnable, Runnable> decorator) {
/*  957 */     synchronized (onScheduleHooks) {
/*  958 */       onScheduleHooks.put(key, decorator);
/*  959 */       Function<Runnable, Runnable> newHook = null;
/*  960 */       for (Function<Runnable, Runnable> function : onScheduleHooks.values()) {
/*  961 */         if (newHook == null) {
/*  962 */           newHook = function;
/*      */           continue;
/*      */         } 
/*  965 */         newHook = newHook.andThen(function);
/*      */       } 
/*      */       
/*  968 */       onScheduleHook = newHook;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void resetOnScheduleHook(String key) {
/*  981 */     synchronized (onScheduleHooks) {
/*  982 */       onScheduleHooks.remove(key);
/*  983 */       if (onScheduleHooks.isEmpty()) {
/*  984 */         onScheduleHook = Function.identity();
/*      */       } else {
/*      */         
/*  987 */         Function<Runnable, Runnable> newHook = null;
/*  988 */         for (Function<Runnable, Runnable> function : onScheduleHooks.values()) {
/*  989 */           if (newHook == null) {
/*  990 */             newHook = function;
/*      */             continue;
/*      */           } 
/*  993 */           newHook = newHook.andThen(function);
/*      */         } 
/*      */         
/*  996 */         onScheduleHook = newHook;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void resetOnScheduleHooks() {
/* 1008 */     synchronized (onScheduleHooks) {
/* 1009 */       onScheduleHooks.clear();
/* 1010 */       onScheduleHook = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Runnable onSchedule(Runnable runnable) {
/* 1021 */     Function<Runnable, Runnable> hook = onScheduleHook;
/* 1022 */     if (hook != null) {
/* 1023 */       return hook.apply(runnable);
/*      */     }
/*      */     
/* 1026 */     return runnable;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void shutdownNow() {
/* 1034 */     CachedScheduler oldElastic = CACHED_ELASTIC.getAndSet(null);
/* 1035 */     CachedScheduler oldBoundedElastic = CACHED_BOUNDED_ELASTIC.getAndSet(null);
/* 1036 */     CachedScheduler oldParallel = CACHED_PARALLEL.getAndSet(null);
/* 1037 */     CachedScheduler oldSingle = CACHED_SINGLE.getAndSet(null);
/*      */     
/* 1039 */     if (oldElastic != null) oldElastic._dispose(); 
/* 1040 */     if (oldBoundedElastic != null) oldBoundedElastic._dispose(); 
/* 1041 */     if (oldParallel != null) oldParallel._dispose(); 
/* 1042 */     if (oldSingle != null) oldSingle._dispose();
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Scheduler single() {
/* 1060 */     return cache(CACHED_SINGLE, "single", SINGLE_SUPPLIER);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Scheduler single(Scheduler original) {
/* 1079 */     return new SingleWorkerScheduler(original);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static interface Factory
/*      */   {
/*      */     @Deprecated
/*      */     default Scheduler newElastic(int ttlSeconds, ThreadFactory threadFactory) {
/* 1102 */       return new ElasticScheduler(threadFactory, ttlSeconds);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     default Scheduler newBoundedElastic(int threadCap, int queuedTaskCap, ThreadFactory threadFactory, int ttlSeconds) {
/* 1121 */       return new BoundedElasticScheduler(threadCap, queuedTaskCap, threadFactory, ttlSeconds);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     default Scheduler newParallel(int parallelism, ThreadFactory threadFactory) {
/* 1136 */       return new ParallelScheduler(parallelism, threadFactory);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     default Scheduler newSingle(ThreadFactory threadFactory) {
/* 1149 */       return new SingleScheduler(threadFactory);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static final class Snapshot
/*      */     implements Disposable
/*      */   {
/*      */     @Nullable
/*      */     final Schedulers.CachedScheduler oldElasticScheduler;
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     final Schedulers.CachedScheduler oldBoundedElasticScheduler;
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     final Schedulers.CachedScheduler oldParallelScheduler;
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     final Schedulers.CachedScheduler oldSingleScheduler;
/*      */     
/*      */     final Schedulers.Factory oldFactory;
/*      */ 
/*      */     
/*      */     private Snapshot(@Nullable Schedulers.CachedScheduler oldElasticScheduler, @Nullable Schedulers.CachedScheduler oldBoundedElasticScheduler, @Nullable Schedulers.CachedScheduler oldParallelScheduler, @Nullable Schedulers.CachedScheduler oldSingleScheduler, Schedulers.Factory factory) {
/* 1177 */       this.oldElasticScheduler = oldElasticScheduler;
/* 1178 */       this.oldBoundedElasticScheduler = oldBoundedElasticScheduler;
/* 1179 */       this.oldParallelScheduler = oldParallelScheduler;
/* 1180 */       this.oldSingleScheduler = oldSingleScheduler;
/* 1181 */       this.oldFactory = factory;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isDisposed() {
/* 1186 */       return ((this.oldElasticScheduler == null || this.oldElasticScheduler
/* 1187 */         .isDisposed()) && (this.oldBoundedElasticScheduler == null || this.oldBoundedElasticScheduler
/* 1188 */         .isDisposed()) && (this.oldParallelScheduler == null || this.oldParallelScheduler
/* 1189 */         .isDisposed()) && (this.oldSingleScheduler == null || this.oldSingleScheduler
/* 1190 */         .isDisposed()));
/*      */     }
/*      */ 
/*      */     
/*      */     public void dispose() {
/* 1195 */       if (this.oldElasticScheduler != null) this.oldElasticScheduler._dispose(); 
/* 1196 */       if (this.oldBoundedElasticScheduler != null) this.oldBoundedElasticScheduler._dispose(); 
/* 1197 */       if (this.oldParallelScheduler != null) this.oldParallelScheduler._dispose(); 
/* 1198 */       if (this.oldSingleScheduler != null) this.oldSingleScheduler._dispose();
/*      */     
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1213 */   static AtomicReference<CachedScheduler> CACHED_ELASTIC = new AtomicReference<>();
/* 1214 */   static AtomicReference<CachedScheduler> CACHED_BOUNDED_ELASTIC = new AtomicReference<>();
/* 1215 */   static AtomicReference<CachedScheduler> CACHED_PARALLEL = new AtomicReference<>();
/* 1216 */   static AtomicReference<CachedScheduler> CACHED_SINGLE = new AtomicReference<>();
/*      */ 
/*      */   
/*      */   static final Supplier<Scheduler> ELASTIC_SUPPLIER = () -> newElastic("elastic", 60, true);
/*      */ 
/*      */   
/*      */   static final Supplier<Scheduler> BOUNDED_ELASTIC_SUPPLIER = () -> newBoundedElastic(DEFAULT_BOUNDED_ELASTIC_SIZE, DEFAULT_BOUNDED_ELASTIC_QUEUESIZE, "boundedElastic", 60, true);
/*      */ 
/*      */   
/*      */   static final Supplier<Scheduler> PARALLEL_SUPPLIER = () -> newParallel("parallel", DEFAULT_POOL_SIZE, true);
/*      */ 
/*      */   
/*      */   static final Supplier<Scheduler> SINGLE_SUPPLIER = () -> newSingle("single", true);
/*      */   
/* 1230 */   static final Factory DEFAULT = new Factory() {
/*      */     
/*      */     };
/* 1233 */   static final Map<String, BiFunction<Scheduler, ScheduledExecutorService, ScheduledExecutorService>> DECORATORS = new LinkedHashMap<>();
/*      */   
/* 1235 */   static volatile Factory factory = DEFAULT;
/*      */   
/* 1237 */   private static final LinkedHashMap<String, BiConsumer<Thread, Throwable>> onHandleErrorHooks = new LinkedHashMap<>(1);
/*      */   
/*      */   @Nullable
/*      */   static BiConsumer<Thread, ? super Throwable> onHandleErrorHook;
/*      */   
/* 1242 */   private static final LinkedHashMap<String, Function<Runnable, Runnable>> onScheduleHooks = new LinkedHashMap<>(1);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private static Function<Runnable, Runnable> onScheduleHook;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static CachedScheduler cache(AtomicReference<CachedScheduler> reference, String key, Supplier<Scheduler> supplier) {
/* 1260 */     CachedScheduler s = reference.get();
/* 1261 */     if (s != null) {
/* 1262 */       return s;
/*      */     }
/* 1264 */     s = new CachedScheduler(key, supplier.get());
/* 1265 */     if (reference.compareAndSet(null, s)) {
/* 1266 */       return s;
/*      */     }
/*      */ 
/*      */     
/* 1270 */     s._dispose();
/* 1271 */     return reference.get();
/*      */   }
/*      */   
/* 1274 */   static final Logger LOGGER = Loggers.getLogger(Schedulers.class);
/*      */   
/*      */   static final void defaultUncaughtException(Thread t, Throwable e) {
/* 1277 */     LOGGER.error("Scheduler worker in group " + t.getThreadGroup().getName() + " failed with an uncaught exception", e);
/*      */   }
/*      */ 
/*      */   
/*      */   static void handleError(Throwable ex) {
/* 1282 */     Thread thread = Thread.currentThread();
/* 1283 */     Throwable t = Exceptions.unwrap(ex);
/* 1284 */     Thread.UncaughtExceptionHandler x = thread.getUncaughtExceptionHandler();
/* 1285 */     if (x != null) {
/* 1286 */       x.uncaughtException(thread, t);
/*      */     } else {
/*      */       
/* 1289 */       LOGGER.error("Scheduler worker failed with an uncaught exception", t);
/*      */     } 
/* 1291 */     BiConsumer<Thread, ? super Throwable> hook = onHandleErrorHook;
/* 1292 */     if (hook != null)
/* 1293 */       hook.accept(thread, t); 
/*      */   }
/*      */   
/*      */   static class CachedScheduler
/*      */     implements Scheduler, Supplier<Scheduler>, Scannable
/*      */   {
/*      */     final Scheduler cached;
/*      */     final String stringRepresentation;
/*      */     
/*      */     CachedScheduler(String key, Scheduler cached) {
/* 1303 */       this.cached = cached;
/* 1304 */       this.stringRepresentation = "Schedulers." + key + "()";
/*      */     }
/*      */ 
/*      */     
/*      */     public Disposable schedule(Runnable task) {
/* 1309 */       return this.cached.schedule(task);
/*      */     }
/*      */ 
/*      */     
/*      */     public Disposable schedule(Runnable task, long delay, TimeUnit unit) {
/* 1314 */       return this.cached.schedule(task, delay, unit);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Disposable schedulePeriodically(Runnable task, long initialDelay, long period, TimeUnit unit) {
/* 1322 */       return this.cached.schedulePeriodically(task, initialDelay, period, unit);
/*      */     }
/*      */ 
/*      */     
/*      */     public Scheduler.Worker createWorker() {
/* 1327 */       return this.cached.createWorker();
/*      */     }
/*      */ 
/*      */     
/*      */     public long now(TimeUnit unit) {
/* 1332 */       return this.cached.now(unit);
/*      */     }
/*      */ 
/*      */     
/*      */     public void start() {
/* 1337 */       this.cached.start();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void dispose() {}
/*      */ 
/*      */     
/*      */     public boolean isDisposed() {
/* 1346 */       return this.cached.isDisposed();
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/* 1351 */       return this.stringRepresentation;
/*      */     }
/*      */ 
/*      */     
/*      */     public Object scanUnsafe(Scannable.Attr key) {
/* 1356 */       if (Scannable.Attr.NAME == key) return this.stringRepresentation; 
/* 1357 */       return Scannable.from(this.cached).scanUnsafe(key);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Scheduler get() {
/* 1368 */       return this.cached;
/*      */     }
/*      */     
/*      */     void _dispose() {
/* 1372 */       this.cached.dispose();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static Disposable directSchedule(ScheduledExecutorService exec, Runnable task, @Nullable Disposable parent, long delay, TimeUnit unit) {
/*      */     Future<?> f;
/* 1381 */     task = onSchedule(task);
/* 1382 */     SchedulerTask sr = new SchedulerTask(task, parent);
/*      */     
/* 1384 */     if (delay <= 0L) {
/* 1385 */       f = exec.submit(sr);
/*      */     } else {
/*      */       
/* 1388 */       f = exec.schedule(sr, delay, unit);
/*      */     } 
/* 1390 */     sr.setFuture(f);
/*      */     
/* 1392 */     return sr;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static Disposable directSchedulePeriodically(ScheduledExecutorService exec, Runnable task, long initialDelay, long period, TimeUnit unit) {
/* 1400 */     task = onSchedule(task);
/*      */     
/* 1402 */     if (period <= 0L) {
/* 1403 */       Future<?> future; InstantPeriodicWorkerTask isr = new InstantPeriodicWorkerTask(task, exec);
/*      */ 
/*      */       
/* 1406 */       if (initialDelay <= 0L) {
/* 1407 */         future = exec.submit(isr);
/*      */       } else {
/*      */         
/* 1410 */         future = exec.schedule(isr, initialDelay, unit);
/*      */       } 
/* 1412 */       isr.setFirst(future);
/*      */       
/* 1414 */       return isr;
/*      */     } 
/*      */     
/* 1417 */     PeriodicSchedulerTask sr = new PeriodicSchedulerTask(task);
/* 1418 */     Future<?> f = exec.scheduleAtFixedRate(sr, initialDelay, period, unit);
/* 1419 */     sr.setFuture(f);
/*      */     
/* 1421 */     return sr;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static Disposable workerSchedule(ScheduledExecutorService exec, Disposable.Composite tasks, Runnable task, long delay, TimeUnit unit) {
/* 1430 */     task = onSchedule(task);
/*      */     
/* 1432 */     WorkerTask sr = new WorkerTask(task, tasks);
/* 1433 */     if (!tasks.add(sr)) {
/* 1434 */       throw Exceptions.failWithRejected();
/*      */     }
/*      */     
/*      */     try {
/*      */       Future<?> f;
/* 1439 */       if (delay <= 0L) {
/* 1440 */         f = exec.submit(sr);
/*      */       } else {
/*      */         
/* 1443 */         f = exec.schedule(sr, delay, unit);
/*      */       } 
/* 1445 */       sr.setFuture(f);
/*      */     }
/* 1447 */     catch (RejectedExecutionException ex) {
/* 1448 */       sr.dispose();
/*      */       
/* 1450 */       throw ex;
/*      */     } 
/*      */     
/* 1453 */     return sr;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static Disposable workerSchedulePeriodically(ScheduledExecutorService exec, Disposable.Composite tasks, Runnable task, long initialDelay, long period, TimeUnit unit) {
/* 1462 */     task = onSchedule(task);
/*      */     
/* 1464 */     if (period <= 0L) {
/* 1465 */       InstantPeriodicWorkerTask isr = new InstantPeriodicWorkerTask(task, exec, tasks);
/*      */       
/* 1467 */       if (!tasks.add(isr)) {
/* 1468 */         throw Exceptions.failWithRejected();
/*      */       }
/*      */       try {
/*      */         Future<?> f;
/* 1472 */         if (initialDelay <= 0L) {
/* 1473 */           f = exec.submit(isr);
/*      */         } else {
/*      */           
/* 1476 */           f = exec.schedule(isr, initialDelay, unit);
/*      */         } 
/* 1478 */         isr.setFirst(f);
/*      */       }
/* 1480 */       catch (RejectedExecutionException ex) {
/* 1481 */         isr.dispose();
/*      */         
/* 1483 */         throw ex;
/*      */       }
/* 1485 */       catch (IllegalArgumentException|NullPointerException ex) {
/* 1486 */         isr.dispose();
/*      */         
/* 1488 */         throw new RejectedExecutionException(ex);
/*      */       } 
/*      */       
/* 1491 */       return isr;
/*      */     } 
/*      */     
/* 1494 */     PeriodicWorkerTask sr = new PeriodicWorkerTask(task, tasks);
/* 1495 */     if (!tasks.add(sr)) {
/* 1496 */       throw Exceptions.failWithRejected();
/*      */     }
/*      */     
/*      */     try {
/* 1500 */       Future<?> f = exec.scheduleAtFixedRate(sr, initialDelay, period, unit);
/* 1501 */       sr.setFuture(f);
/*      */     }
/* 1503 */     catch (RejectedExecutionException ex) {
/* 1504 */       sr.dispose();
/*      */       
/* 1506 */       throw ex;
/*      */     }
/* 1508 */     catch (IllegalArgumentException|NullPointerException ex) {
/* 1509 */       sr.dispose();
/*      */       
/* 1511 */       throw new RejectedExecutionException(ex);
/*      */     } 
/*      */     
/* 1514 */     return sr;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   static final Object scanExecutor(Executor executor, Scannable.Attr key) {
/* 1533 */     if (executor instanceof DelegateServiceScheduler.UnsupportedScheduledExecutorService) {
/* 1534 */       executor = ((DelegateServiceScheduler.UnsupportedScheduledExecutorService)executor).get();
/*      */     }
/* 1536 */     if (executor instanceof Scannable) {
/* 1537 */       return ((Scannable)executor).scanUnsafe(key);
/*      */     }
/*      */     
/* 1540 */     if (executor instanceof ExecutorService) {
/* 1541 */       ExecutorService service = (ExecutorService)executor;
/* 1542 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(service.isTerminated()); 
/* 1543 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(service.isShutdown());
/*      */     
/*      */     } 
/* 1546 */     if (executor instanceof ThreadPoolExecutor) {
/* 1547 */       ThreadPoolExecutor poolExecutor = (ThreadPoolExecutor)executor;
/* 1548 */       if (key == Scannable.Attr.CAPACITY) return Integer.valueOf(poolExecutor.getMaximumPoolSize()); 
/* 1549 */       if (key == Scannable.Attr.BUFFERED) return Integer.valueOf(Long.valueOf(poolExecutor.getTaskCount() - poolExecutor.getCompletedTaskCount()).intValue()); 
/* 1550 */       if (key == Scannable.Attr.LARGE_BUFFERED) return Long.valueOf(poolExecutor.getTaskCount() - poolExecutor.getCompletedTaskCount());
/*      */     
/*      */     } 
/* 1553 */     return null;
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\scheduler\Schedulers.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */