/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.Objects;
/*     */ import java.util.Queue;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Supplier;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxFlattenIterable<T, R>
/*     */   extends InternalFluxOperator<T, R>
/*     */   implements Fuseable
/*     */ {
/*     */   final Function<? super T, ? extends Iterable<? extends R>> mapper;
/*     */   final int prefetch;
/*     */   final Supplier<Queue<T>> queueSupplier;
/*     */   
/*     */   FluxFlattenIterable(Flux<? extends T> source, Function<? super T, ? extends Iterable<? extends R>> mapper, int prefetch, Supplier<Queue<T>> queueSupplier) {
/*  58 */     super(source);
/*  59 */     if (prefetch <= 0) {
/*  60 */       throw new IllegalArgumentException("prefetch > 0 required but it was " + prefetch);
/*     */     }
/*  62 */     this.mapper = Objects.<Function<? super T, ? extends Iterable<? extends R>>>requireNonNull(mapper, "mapper");
/*  63 */     this.prefetch = prefetch;
/*  64 */     this.queueSupplier = Objects.<Supplier<Queue<T>>>requireNonNull(queueSupplier, "queueSupplier");
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPrefetch() {
/*  69 */     return this.prefetch;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super R> actual) throws Exception {
/*  76 */     if (this.source instanceof Callable) {
/*  77 */       Iterator<? extends R> it; boolean knownToBeFinite; T v = ((Callable)this.source).call();
/*     */       
/*  79 */       if (v == null) {
/*  80 */         Operators.complete((Subscriber<?>)actual);
/*  81 */         return null;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/*  87 */         Iterable<? extends R> iter = this.mapper.apply(v);
/*  88 */         it = iter.iterator();
/*  89 */         knownToBeFinite = FluxIterable.checkFinite(iter);
/*     */       }
/*  91 */       catch (Throwable ex) {
/*  92 */         Context ctx = actual.currentContext();
/*  93 */         Throwable e_ = Operators.onNextError(v, ex, ctx);
/*  94 */         Operators.onDiscard(v, ctx);
/*  95 */         if (e_ != null) {
/*  96 */           Operators.error((Subscriber<?>)actual, e_);
/*     */         } else {
/*     */           
/*  99 */           Operators.complete((Subscriber<?>)actual);
/*     */         } 
/* 101 */         return null;
/*     */       } 
/*     */ 
/*     */       
/* 105 */       FluxIterable.subscribe(actual, it, knownToBeFinite);
/* 106 */       return null;
/*     */     } 
/* 108 */     return new FlattenIterableSubscriber<>(actual, this.mapper, this.prefetch, this.queueSupplier);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/* 116 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 117 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class FlattenIterableSubscriber<T, R>
/*     */     implements InnerOperator<T, R>, Fuseable.QueueSubscription<R>
/*     */   {
/*     */     final CoreSubscriber<? super R> actual;
/*     */     
/*     */     final Function<? super T, ? extends Iterable<? extends R>> mapper;
/*     */     
/*     */     final int prefetch;
/*     */     
/*     */     final int limit;
/*     */     
/*     */     final Supplier<Queue<T>> queueSupplier;
/*     */     
/*     */     volatile int wip;
/*     */     
/* 136 */     static final AtomicIntegerFieldUpdater<FlattenIterableSubscriber> WIP = AtomicIntegerFieldUpdater.newUpdater(FlattenIterableSubscriber.class, "wip");
/*     */ 
/*     */     
/*     */     volatile long requested;
/*     */ 
/*     */     
/* 142 */     static final AtomicLongFieldUpdater<FlattenIterableSubscriber> REQUESTED = AtomicLongFieldUpdater.newUpdater(FlattenIterableSubscriber.class, "requested");
/*     */ 
/*     */     
/*     */     Subscription s;
/*     */ 
/*     */     
/*     */     Queue<T> queue;
/*     */ 
/*     */     
/*     */     volatile boolean done;
/*     */     
/*     */     volatile boolean cancelled;
/*     */     
/*     */     volatile Throwable error;
/*     */     
/* 157 */     static final AtomicReferenceFieldUpdater<FlattenIterableSubscriber, Throwable> ERROR = AtomicReferenceFieldUpdater.newUpdater(FlattenIterableSubscriber.class, Throwable.class, "error");
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     Iterator<? extends R> current;
/*     */ 
/*     */     
/*     */     boolean currentKnownToBeFinite;
/*     */ 
/*     */     
/*     */     int consumed;
/*     */     
/*     */     int fusionMode;
/*     */ 
/*     */     
/*     */     FlattenIterableSubscriber(CoreSubscriber<? super R> actual, Function<? super T, ? extends Iterable<? extends R>> mapper, int prefetch, Supplier<Queue<T>> queueSupplier) {
/* 173 */       this.actual = actual;
/* 174 */       this.mapper = mapper;
/* 175 */       this.prefetch = prefetch;
/* 176 */       this.queueSupplier = queueSupplier;
/* 177 */       this.limit = Operators.unboundedOrLimit(prefetch);
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 183 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 184 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 185 */       if (key == Scannable.Attr.ERROR) return this.error; 
/* 186 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf(this.requested); 
/* 187 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(this.cancelled); 
/* 188 */       if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(this.prefetch); 
/* 189 */       if (key == Scannable.Attr.BUFFERED) return Integer.valueOf((this.queue != null) ? this.queue.size() : 0); 
/* 190 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 192 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super R> actual() {
/* 197 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 202 */       if (Operators.validate(this.s, s)) {
/* 203 */         this.s = s;
/*     */         
/* 205 */         if (s instanceof Fuseable.QueueSubscription) {
/* 206 */           Fuseable.QueueSubscription<T> qs = (Fuseable.QueueSubscription<T>)s;
/*     */ 
/*     */           
/* 209 */           int m = qs.requestFusion(3);
/*     */           
/* 211 */           if (m == 1) {
/* 212 */             this.fusionMode = m;
/* 213 */             this.queue = (Queue<T>)qs;
/* 214 */             this.done = true;
/*     */             
/* 216 */             this.actual.onSubscribe(this);
/*     */             
/*     */             return;
/*     */           } 
/* 220 */           if (m == 2) {
/* 221 */             this.fusionMode = m;
/* 222 */             this.queue = (Queue<T>)qs;
/*     */             
/* 224 */             this.actual.onSubscribe(this);
/*     */             
/* 226 */             s.request(Operators.unboundedOrPrefetch(this.prefetch));
/*     */             
/*     */             return;
/*     */           } 
/*     */         } 
/* 231 */         this.queue = this.queueSupplier.get();
/*     */         
/* 233 */         this.actual.onSubscribe(this);
/*     */         
/* 235 */         s.request(Operators.unboundedOrPrefetch(this.prefetch));
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 241 */       if (this.fusionMode != 2 && 
/* 242 */         !this.queue.offer(t)) {
/* 243 */         Context ctx = this.actual.currentContext();
/* 244 */         onError(Operators.onOperatorError(this.s, Exceptions.failWithOverflow("Queue is full: Reactive Streams source doesn't respect backpressure"), ctx));
/*     */         
/* 246 */         Operators.onDiscard(t, ctx);
/*     */         
/*     */         return;
/*     */       } 
/* 250 */       drain(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 255 */       if (Exceptions.addThrowable(ERROR, this, t)) {
/* 256 */         this.done = true;
/* 257 */         drain(null);
/*     */       } else {
/*     */         
/* 260 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 266 */       this.done = true;
/* 267 */       drain(null);
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 272 */       if (Operators.validate(n)) {
/* 273 */         Operators.addCap(REQUESTED, this, n);
/* 274 */         drain(null);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 280 */       if (!this.cancelled) {
/* 281 */         this.cancelled = true;
/*     */         
/* 283 */         this.s.cancel();
/*     */         
/* 285 */         if (WIP.getAndIncrement(this) == 0) {
/* 286 */           Context context = this.actual.currentContext();
/* 287 */           Operators.onDiscardQueueWithClear(this.queue, context, null);
/* 288 */           Operators.onDiscardMultiple(this.current, this.currentKnownToBeFinite, context);
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     final void resetCurrent() {
/* 295 */       this.current = null;
/* 296 */       this.currentKnownToBeFinite = false;
/*     */     }
/*     */     
/*     */     void drainAsync() {
/* 300 */       CoreSubscriber<? super R> coreSubscriber = this.actual;
/* 301 */       Queue<T> q = this.queue;
/*     */       
/* 303 */       int missed = 1;
/* 304 */       Iterator<? extends R> it = this.current;
/* 305 */       boolean itFinite = this.currentKnownToBeFinite;
/*     */ 
/*     */       
/*     */       while (true) {
/* 309 */         if (it == null) {
/*     */           T t;
/* 311 */           if (this.cancelled) {
/* 312 */             Operators.onDiscardQueueWithClear(q, this.actual.currentContext(), null);
/*     */             
/*     */             return;
/*     */           } 
/* 316 */           Throwable ex = this.error;
/* 317 */           if (ex != null) {
/* 318 */             ex = Exceptions.terminate(ERROR, this);
/* 319 */             resetCurrent();
/* 320 */             Operators.onDiscardQueueWithClear(q, this.actual.currentContext(), null);
/* 321 */             coreSubscriber.onError(ex);
/*     */             
/*     */             return;
/*     */           } 
/* 325 */           boolean d = this.done;
/*     */ 
/*     */ 
/*     */           
/*     */           try {
/* 330 */             t = q.poll();
/* 331 */           } catch (Throwable pollEx) {
/* 332 */             resetCurrent();
/* 333 */             Operators.onDiscardQueueWithClear(q, this.actual.currentContext(), null);
/* 334 */             coreSubscriber.onError(pollEx);
/*     */             
/*     */             return;
/*     */           } 
/* 338 */           boolean empty = (t == null);
/*     */           
/* 340 */           if (d && empty) {
/* 341 */             coreSubscriber.onComplete();
/*     */             
/*     */             return;
/*     */           } 
/* 345 */           if (!empty) {
/*     */             boolean b;
/*     */ 
/*     */ 
/*     */             
/*     */             try {
/* 351 */               Iterable<? extends R> iterable = this.mapper.apply(t);
/* 352 */               it = iterable.iterator();
/* 353 */               itFinite = FluxIterable.checkFinite(iterable);
/*     */               
/* 355 */               b = it.hasNext();
/*     */             }
/* 357 */             catch (Throwable exc) {
/* 358 */               it = null;
/* 359 */               itFinite = false;
/* 360 */               Context ctx = this.actual.currentContext();
/* 361 */               Throwable e_ = Operators.onNextError(t, exc, ctx, this.s);
/* 362 */               Operators.onDiscard(t, ctx);
/* 363 */               if (e_ != null) {
/* 364 */                 onError(e_);
/*     */               }
/*     */               
/*     */               continue;
/*     */             } 
/* 369 */             if (!b) {
/* 370 */               it = null;
/* 371 */               itFinite = false;
/* 372 */               int c = this.consumed + 1;
/* 373 */               if (c == this.limit) {
/* 374 */                 this.consumed = 0;
/* 375 */                 this.s.request(c);
/*     */                 continue;
/*     */               } 
/* 378 */               this.consumed = c;
/*     */               
/*     */               continue;
/*     */             } 
/*     */           } 
/*     */         } 
/*     */         
/* 385 */         if (it != null) {
/* 386 */           long r = this.requested;
/* 387 */           long l1 = 0L;
/*     */           
/* 389 */           while (l1 != r) {
/* 390 */             R v; boolean b; if (this.cancelled) {
/* 391 */               resetCurrent();
/* 392 */               Context context = this.actual.currentContext();
/* 393 */               Operators.onDiscardQueueWithClear(q, context, null);
/* 394 */               Operators.onDiscardMultiple(it, itFinite, context);
/*     */               
/*     */               return;
/*     */             } 
/* 398 */             Throwable ex = this.error;
/* 399 */             if (ex != null) {
/* 400 */               Throwable throwable = Exceptions.terminate(ERROR, this);
/* 401 */               resetCurrent();
/* 402 */               Context context = this.actual.currentContext();
/* 403 */               Operators.onDiscardQueueWithClear(q, context, null);
/* 404 */               Operators.onDiscardMultiple(it, itFinite, context);
/* 405 */               coreSubscriber.onError(throwable);
/*     */ 
/*     */               
/*     */               return;
/*     */             } 
/*     */             
/*     */             try {
/* 412 */               v = Objects.requireNonNull(it.next(), "iterator returned null");
/*     */             
/*     */             }
/* 415 */             catch (Throwable exc) {
/* 416 */               onError(Operators.onOperatorError(this.s, exc, this.actual
/* 417 */                     .currentContext()));
/*     */               
/*     */               continue;
/*     */             } 
/* 421 */             coreSubscriber.onNext(v);
/*     */             
/* 423 */             if (this.cancelled) {
/* 424 */               resetCurrent();
/* 425 */               Context context = this.actual.currentContext();
/* 426 */               Operators.onDiscardQueueWithClear(q, context, null);
/* 427 */               Operators.onDiscardMultiple(it, itFinite, context);
/*     */               
/*     */               return;
/*     */             } 
/* 431 */             l1 = l1 + 1L;
/*     */ 
/*     */ 
/*     */             
/*     */             try {
/* 436 */               b = it.hasNext();
/*     */             }
/* 438 */             catch (Throwable exc) {
/* 439 */               onError(Operators.onOperatorError(this.s, exc, this.actual
/* 440 */                     .currentContext()));
/*     */               
/*     */               continue;
/*     */             } 
/* 444 */             if (!b) {
/* 445 */               int c = this.consumed + 1;
/* 446 */               if (c == this.limit) {
/* 447 */                 this.consumed = 0;
/* 448 */                 this.s.request(c);
/*     */               } else {
/*     */                 
/* 451 */                 this.consumed = c;
/*     */               } 
/* 453 */               it = null;
/* 454 */               itFinite = false;
/* 455 */               resetCurrent();
/*     */               
/*     */               break;
/*     */             } 
/*     */           } 
/* 460 */           if (l1 == r) {
/* 461 */             if (this.cancelled) {
/* 462 */               resetCurrent();
/* 463 */               Context context = this.actual.currentContext();
/* 464 */               Operators.onDiscardQueueWithClear(q, context, null);
/* 465 */               Operators.onDiscardMultiple(it, itFinite, context);
/*     */               
/*     */               return;
/*     */             } 
/* 469 */             Throwable ex = this.error;
/* 470 */             if (ex != null) {
/* 471 */               ex = Exceptions.terminate(ERROR, this);
/* 472 */               resetCurrent();
/* 473 */               Context context = this.actual.currentContext();
/* 474 */               Operators.onDiscardQueueWithClear(q, context, null);
/* 475 */               Operators.onDiscardMultiple(it, itFinite, context);
/* 476 */               coreSubscriber.onError(ex);
/*     */               
/*     */               return;
/*     */             } 
/* 480 */             boolean d = this.done;
/* 481 */             boolean empty = (q.isEmpty() && it == null);
/*     */             
/* 483 */             if (d && empty) {
/* 484 */               resetCurrent();
/* 485 */               coreSubscriber.onComplete();
/*     */               
/*     */               return;
/*     */             } 
/*     */           } 
/* 490 */           if (l1 != 0L && 
/* 491 */             r != Long.MAX_VALUE) {
/* 492 */             REQUESTED.addAndGet(this, -l1);
/*     */           }
/*     */ 
/*     */           
/* 496 */           if (it == null) {
/*     */             continue;
/*     */           }
/*     */         } 
/*     */         
/* 501 */         this.current = it;
/* 502 */         this.currentKnownToBeFinite = itFinite;
/* 503 */         missed = WIP.addAndGet(this, -missed);
/* 504 */         if (missed == 0) {
/*     */           break;
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*     */     void drainSync() {
/* 511 */       CoreSubscriber<? super R> coreSubscriber = this.actual;
/*     */       
/* 513 */       int missed = 1;
/* 514 */       Iterator<? extends R> it = this.current;
/* 515 */       boolean itFinite = this.currentKnownToBeFinite;
/*     */       
/*     */       while (true) {
/* 518 */         if (it == null) {
/*     */           T t;
/* 520 */           if (this.cancelled) {
/* 521 */             Operators.onDiscardQueueWithClear(this.queue, this.actual.currentContext(), null);
/*     */             
/*     */             return;
/*     */           } 
/* 525 */           boolean d = this.done;
/*     */ 
/*     */           
/* 528 */           Queue<T> q = this.queue;
/*     */           
/*     */           try {
/* 531 */             t = q.poll();
/* 532 */           } catch (Throwable pollEx) {
/* 533 */             resetCurrent();
/* 534 */             Operators.onDiscardQueueWithClear(q, this.actual.currentContext(), null);
/* 535 */             coreSubscriber.onError(pollEx);
/*     */             
/*     */             return;
/*     */           } 
/* 539 */           boolean empty = (t == null);
/*     */           
/* 541 */           if (d && empty) {
/* 542 */             coreSubscriber.onComplete();
/*     */             
/*     */             return;
/*     */           } 
/* 546 */           if (!empty) {
/*     */             boolean b;
/*     */ 
/*     */ 
/*     */             
/*     */             try {
/* 552 */               Iterable<? extends R> iterable = this.mapper.apply(t);
/* 553 */               it = iterable.iterator();
/* 554 */               itFinite = FluxIterable.checkFinite(iterable);
/*     */               
/* 556 */               b = it.hasNext();
/*     */             }
/* 558 */             catch (Throwable exc) {
/* 559 */               resetCurrent();
/* 560 */               Context ctx = this.actual.currentContext();
/* 561 */               Throwable e_ = Operators.onNextError(t, exc, ctx, this.s);
/*     */ 
/*     */               
/* 564 */               Operators.onDiscard(t, ctx);
/* 565 */               if (e_ != null) {
/* 566 */                 coreSubscriber.onError(e_);
/*     */                 
/*     */                 return;
/*     */               } 
/*     */               continue;
/*     */             } 
/* 572 */             if (!b) {
/* 573 */               it = null;
/* 574 */               itFinite = false;
/*     */               
/*     */               continue;
/*     */             } 
/*     */           } 
/*     */         } 
/* 580 */         if (it != null) {
/* 581 */           long r = this.requested;
/* 582 */           long e = 0L;
/*     */           
/* 584 */           while (e != r) {
/* 585 */             R v; boolean b; if (this.cancelled) {
/* 586 */               resetCurrent();
/* 587 */               Context context = this.actual.currentContext();
/* 588 */               Operators.onDiscardQueueWithClear(this.queue, context, null);
/* 589 */               Operators.onDiscardMultiple(it, itFinite, context);
/*     */ 
/*     */               
/*     */               return;
/*     */             } 
/*     */             
/*     */             try {
/* 596 */               v = Objects.requireNonNull(it.next(), "iterator returned null");
/*     */             }
/* 598 */             catch (Throwable exc) {
/* 599 */               Throwable throwable1; resetCurrent();
/* 600 */               coreSubscriber.onError(Operators.onOperatorError(this.s, throwable1, this.actual.currentContext()));
/*     */               
/*     */               return;
/*     */             } 
/* 604 */             coreSubscriber.onNext(v);
/*     */             
/* 606 */             if (this.cancelled) {
/* 607 */               resetCurrent();
/* 608 */               Context context = this.actual.currentContext();
/* 609 */               Operators.onDiscardQueueWithClear(this.queue, context, null);
/* 610 */               Operators.onDiscardMultiple(it, itFinite, context);
/*     */               
/*     */               return;
/*     */             } 
/* 614 */             e++;
/*     */ 
/*     */ 
/*     */             
/*     */             try {
/* 619 */               b = it.hasNext();
/*     */             }
/* 621 */             catch (Throwable exc) {
/* 622 */               resetCurrent();
/* 623 */               coreSubscriber.onError(Operators.onOperatorError(this.s, exc, this.actual.currentContext()));
/*     */               
/*     */               return;
/*     */             } 
/* 627 */             if (!b) {
/* 628 */               it = null;
/* 629 */               itFinite = false;
/* 630 */               resetCurrent();
/*     */               
/*     */               break;
/*     */             } 
/*     */           } 
/* 635 */           if (e == r) {
/* 636 */             if (this.cancelled) {
/* 637 */               resetCurrent();
/* 638 */               Context context = this.actual.currentContext();
/* 639 */               Operators.onDiscardQueueWithClear(this.queue, context, null);
/* 640 */               Operators.onDiscardMultiple(it, itFinite, context);
/*     */               
/*     */               return;
/*     */             } 
/* 644 */             boolean d = this.done;
/* 645 */             boolean empty = (this.queue.isEmpty() && it == null);
/*     */             
/* 647 */             if (d && empty) {
/* 648 */               resetCurrent();
/* 649 */               coreSubscriber.onComplete();
/*     */               
/*     */               return;
/*     */             } 
/*     */           } 
/* 654 */           if (e != 0L && 
/* 655 */             r != Long.MAX_VALUE) {
/* 656 */             REQUESTED.addAndGet(this, -e);
/*     */           }
/*     */ 
/*     */           
/* 660 */           if (it == null) {
/*     */             continue;
/*     */           }
/*     */         } 
/*     */         
/* 665 */         this.current = it;
/* 666 */         this.currentKnownToBeFinite = itFinite;
/* 667 */         missed = WIP.addAndGet(this, -missed);
/* 668 */         if (missed == 0) {
/*     */           break;
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*     */     void drain(@Nullable T dataSignal) {
/* 675 */       if (WIP.getAndIncrement(this) != 0) {
/* 676 */         if (dataSignal != null && this.cancelled) {
/* 677 */           Operators.onDiscard(dataSignal, this.actual.currentContext());
/*     */         }
/*     */         
/*     */         return;
/*     */       } 
/* 682 */       if (this.fusionMode == 1) {
/* 683 */         drainSync();
/*     */       } else {
/*     */         
/* 686 */         drainAsync();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void clear() {
/* 692 */       Context context = this.actual.currentContext();
/* 693 */       Operators.onDiscardMultiple(this.current, this.currentKnownToBeFinite, context);
/* 694 */       resetCurrent();
/* 695 */       Operators.onDiscardQueueWithClear(this.queue, context, null);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isEmpty() {
/* 700 */       Iterator<? extends R> it = this.current;
/* 701 */       if (it != null) {
/* 702 */         return !it.hasNext();
/*     */       }
/* 704 */       return this.queue.isEmpty();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public R poll() {
/* 710 */       Iterator<? extends R> it = this.current;
/*     */       
/*     */       label23: while (true) {
/* 713 */         while (it == null) {
/* 714 */           boolean itFinite; T v = this.queue.poll();
/* 715 */           if (v == null) {
/* 716 */             return null;
/*     */           }
/*     */ 
/*     */           
/*     */           try {
/* 721 */             Iterable<? extends R> iterable = this.mapper.apply(v);
/* 722 */             it = iterable.iterator();
/* 723 */             itFinite = FluxIterable.checkFinite(iterable);
/*     */           }
/* 725 */           catch (Throwable error) {
/* 726 */             Operators.onDiscard(v, this.actual.currentContext());
/* 727 */             throw error;
/*     */           } 
/*     */           
/* 730 */           if (!it.hasNext()) {
/*     */             continue;
/*     */           }
/* 733 */           this.current = it;
/* 734 */           this.currentKnownToBeFinite = itFinite; break label23;
/*     */         } 
/* 736 */         if (!it.hasNext()) {
/* 737 */           it = null; continue;
/*     */         } 
/*     */         break;
/*     */       } 
/* 741 */       R r = Objects.requireNonNull(it.next(), "iterator returned null");
/*     */       
/* 743 */       if (!it.hasNext()) {
/* 744 */         resetCurrent();
/*     */       }
/*     */       
/* 747 */       return r;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int requestFusion(int requestedMode) {
/* 753 */       if ((requestedMode & 0x1) != 0 && this.fusionMode == 1) {
/* 754 */         return 1;
/*     */       }
/* 756 */       return 0;
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 761 */       return this.queue.size();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\FluxFlattenIterable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */