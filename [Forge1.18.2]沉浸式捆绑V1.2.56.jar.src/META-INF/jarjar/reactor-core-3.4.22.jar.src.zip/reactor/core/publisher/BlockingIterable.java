/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Objects;
/*     */ import java.util.Queue;
/*     */ import java.util.Spliterator;
/*     */ import java.util.Spliterators;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.concurrent.locks.Condition;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.stream.Stream;
/*     */ import java.util.stream.StreamSupport;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CorePublisher;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.core.scheduler.Schedulers;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class BlockingIterable<T>
/*     */   implements Iterable<T>, Scannable
/*     */ {
/*     */   final CorePublisher<? extends T> source;
/*     */   final int batchSize;
/*     */   final Supplier<Queue<T>> queueSupplier;
/*     */   
/*     */   BlockingIterable(CorePublisher<? extends T> source, int batchSize, Supplier<Queue<T>> queueSupplier) {
/*  60 */     if (batchSize <= 0) {
/*  61 */       throw new IllegalArgumentException("batchSize > 0 required but it was " + batchSize);
/*     */     }
/*  63 */     this.source = Objects.<CorePublisher<? extends T>>requireNonNull(source, "source");
/*  64 */     this.batchSize = batchSize;
/*  65 */     this.queueSupplier = Objects.<Supplier<Queue<T>>>requireNonNull(queueSupplier, "queueSupplier");
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  71 */     if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(Math.min(2147483647, this.batchSize)); 
/*  72 */     if (key == Scannable.Attr.PARENT) return this.source; 
/*  73 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */     
/*  75 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<T> iterator() {
/*  80 */     SubscriberIterator<T> it = createIterator();
/*     */     
/*  82 */     this.source.subscribe(it);
/*     */     
/*  84 */     return it;
/*     */   }
/*     */ 
/*     */   
/*     */   public Spliterator<T> spliterator() {
/*  89 */     return stream().spliterator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Stream<T> stream() {
/*  97 */     SubscriberIterator<T> it = createIterator();
/*  98 */     this.source.subscribe(it);
/*     */     
/* 100 */     Spliterator<T> sp = Spliterators.spliteratorUnknownSize(it, 0);
/*     */     
/* 102 */     return StreamSupport.<T>stream(sp, false)
/* 103 */       .onClose(it);
/*     */   }
/*     */ 
/*     */   
/*     */   SubscriberIterator<T> createIterator() {
/*     */     Queue<T> q;
/*     */     try {
/* 110 */       q = Objects.<Queue<T>>requireNonNull(this.queueSupplier.get(), "The queueSupplier returned a null queue");
/*     */     
/*     */     }
/* 113 */     catch (Throwable e) {
/* 114 */       throw Exceptions.propagate(e);
/*     */     } 
/*     */     
/* 117 */     return new SubscriberIterator<>(q, this.batchSize);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class SubscriberIterator<T>
/*     */     implements InnerConsumer<T>, Iterator<T>, Runnable
/*     */   {
/*     */     final Queue<T> queue;
/*     */     
/*     */     final int batchSize;
/*     */     
/*     */     final int limit;
/*     */     
/*     */     final Lock lock;
/*     */     
/*     */     final Condition condition;
/*     */     
/*     */     long produced;
/*     */     
/*     */     volatile Subscription s;
/*     */     
/* 138 */     static final AtomicReferenceFieldUpdater<SubscriberIterator, Subscription> S = AtomicReferenceFieldUpdater.newUpdater(SubscriberIterator.class, Subscription.class, "s");
/*     */     
/*     */     volatile boolean done;
/*     */     
/*     */     Throwable error;
/*     */ 
/*     */     
/*     */     SubscriberIterator(Queue<T> queue, int batchSize) {
/* 146 */       this.queue = queue;
/* 147 */       this.batchSize = batchSize;
/* 148 */       this.limit = Operators.unboundedOrLimit(batchSize);
/* 149 */       this.lock = new ReentrantLock();
/* 150 */       this.condition = this.lock.newCondition();
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/* 155 */       return Context.empty();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/* 160 */       if (Schedulers.isInNonBlockingThread()) {
/* 161 */         throw new IllegalStateException("Iterating over a toIterable() / toStream() is blocking, which is not supported in thread " + Thread.currentThread().getName());
/*     */       }
/*     */       while (true) {
/* 164 */         boolean d = this.done;
/* 165 */         boolean empty = this.queue.isEmpty();
/* 166 */         if (d) {
/* 167 */           Throwable e = this.error;
/* 168 */           if (e != null) {
/* 169 */             throw Exceptions.propagate(e);
/*     */           }
/* 171 */           if (empty) {
/* 172 */             return false;
/*     */           }
/*     */         } 
/* 175 */         if (empty) {
/* 176 */           this.lock.lock();
/*     */           try {
/* 178 */             while (!this.done && this.queue.isEmpty()) {
/* 179 */               this.condition.await();
/*     */             }
/*     */           }
/* 182 */           catch (InterruptedException ex) {
/* 183 */             run();
/* 184 */             throw Exceptions.propagate(ex);
/*     */           } finally {
/*     */             
/* 187 */             this.lock.unlock();
/*     */           }  continue;
/*     */         }  break;
/*     */       } 
/* 191 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public T next() {
/* 199 */       if (hasNext()) {
/* 200 */         T v = this.queue.poll();
/*     */         
/* 202 */         if (v == null) {
/* 203 */           run();
/*     */           
/* 205 */           throw new IllegalStateException("Queue is empty: Expected one element to be available from the Reactive Streams source.");
/*     */         } 
/*     */         
/* 208 */         long p = this.produced + 1L;
/* 209 */         if (p == this.limit) {
/* 210 */           this.produced = 0L;
/* 211 */           this.s.request(p);
/*     */         } else {
/*     */           
/* 214 */           this.produced = p;
/*     */         } 
/*     */         
/* 217 */         return v;
/*     */       } 
/* 219 */       throw new NoSuchElementException();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 224 */       if (Operators.setOnce(S, this, s)) {
/* 225 */         s.request(Operators.unboundedOrPrefetch(this.batchSize));
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 231 */       if (!this.queue.offer(t)) {
/* 232 */         Operators.terminate(S, this);
/*     */         
/* 234 */         onError(Operators.onOperatorError(null, 
/* 235 */               Exceptions.failWithOverflow("Queue is full: Reactive Streams source doesn't respect backpressure"), t, 
/* 236 */               currentContext()));
/*     */       } else {
/*     */         
/* 239 */         signalConsumer();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 245 */       this.error = t;
/* 246 */       this.done = true;
/* 247 */       signalConsumer();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 252 */       this.done = true;
/* 253 */       signalConsumer();
/*     */     }
/*     */     
/*     */     void signalConsumer() {
/* 257 */       this.lock.lock();
/*     */       try {
/* 259 */         this.condition.signalAll();
/*     */       } finally {
/*     */         
/* 262 */         this.lock.unlock();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void run() {
/* 268 */       Operators.terminate(S, this);
/* 269 */       signalConsumer();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 275 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 276 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 277 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf((this.s == Operators.cancelledSubscription())); 
/* 278 */       if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(this.batchSize); 
/* 279 */       if (key == Scannable.Attr.ERROR) return this.error; 
/* 280 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 282 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\BlockingIterable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */