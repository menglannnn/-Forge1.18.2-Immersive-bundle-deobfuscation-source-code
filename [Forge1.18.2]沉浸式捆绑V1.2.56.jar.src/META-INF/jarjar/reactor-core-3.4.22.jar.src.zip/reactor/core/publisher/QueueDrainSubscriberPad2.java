package reactor.core.publisher;

class QueueDrainSubscriberPad2 extends QueueDrainSubscriberWip {
  volatile long p1a;
  
  volatile long p2a;
  
  volatile long p3a;
  
  volatile long p4a;
  
  volatile long p5a;
  
  volatile long p6a;
  
  volatile long p7a;
  
  volatile long p8a;
  
  volatile long p9a;
  
  volatile long p10a;
  
  volatile long p11a;
  
  volatile long p12a;
  
  volatile long p13a;
  
  volatile long p14a;
  
  volatile long p15a;
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\QueueDrainSubscriberPad2.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */