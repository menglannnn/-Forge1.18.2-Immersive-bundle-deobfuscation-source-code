/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.util.Set;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Fuseable;
/*    */ import reactor.core.Scannable;
/*    */ import reactor.util.annotation.Nullable;
/*    */ import reactor.util.function.Tuple2;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MonoNameFuseable<T>
/*    */   extends InternalMonoOperator<T, T>
/*    */   implements Fuseable
/*    */ {
/*    */   final String name;
/*    */   final Set<Tuple2<String, String>> tags;
/*    */   
/*    */   MonoNameFuseable(Mono<? extends T> source, @Nullable String name, @Nullable Set<Tuple2<String, String>> tags) {
/* 45 */     super(source);
/* 46 */     this.name = name;
/* 47 */     this.tags = tags;
/*    */   }
/*    */ 
/*    */   
/*    */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/* 52 */     return actual;
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 58 */     if (key == Scannable.Attr.NAME) {
/* 59 */       return this.name;
/*    */     }
/*    */     
/* 62 */     if (key == Scannable.Attr.TAGS && this.tags != null) {
/* 63 */       return this.tags.stream();
/*    */     }
/*    */     
/* 66 */     if (key == Scannable.Attr.RUN_STYLE) {
/* 67 */       return Scannable.Attr.RunStyle.SYNC;
/*    */     }
/*    */     
/* 70 */     return super.scanUnsafe(key);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\MonoNameFuseable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */