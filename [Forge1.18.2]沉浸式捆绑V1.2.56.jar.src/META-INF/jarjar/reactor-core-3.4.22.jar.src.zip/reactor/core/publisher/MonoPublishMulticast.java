/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.function.Function;
/*     */ import java.util.stream.Stream;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MonoPublishMulticast<T, R>
/*     */   extends InternalMonoOperator<T, R>
/*     */   implements Fuseable
/*     */ {
/*     */   final Function<? super Mono<T>, ? extends Mono<? extends R>> transform;
/*     */   
/*     */   MonoPublishMulticast(Mono<? extends T> source, Function<? super Mono<T>, ? extends Mono<? extends R>> transform) {
/*  48 */     super(source);
/*  49 */     this.transform = Objects.<Function<? super Mono<T>, ? extends Mono<? extends R>>>requireNonNull(transform, "transform");
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super R> actual) {
/*  54 */     MonoPublishMulticaster<T> multicast = new MonoPublishMulticaster<>(actual.currentContext());
/*     */     
/*  56 */     Mono<? extends R> out = Objects.<Mono<? extends R>>requireNonNull(this.transform.apply(fromDirect((Publisher)multicast)), "The transform returned a null Mono");
/*     */ 
/*     */     
/*  59 */     if (out instanceof Fuseable) {
/*  60 */       out.subscribe(new FluxPublishMulticast.CancelFuseableMulticaster<>(actual, multicast));
/*     */     } else {
/*     */       
/*  63 */       out.subscribe(new FluxPublishMulticast.CancelMulticaster<>(actual, multicast));
/*     */     } 
/*     */     
/*  66 */     return multicast;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  71 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  72 */     return super.scanUnsafe(key);
/*     */   }
/*     */   
/*     */   static final class MonoPublishMulticaster<T>
/*     */     extends Mono<T>
/*     */     implements InnerConsumer<T>, FluxPublishMulticast.PublishMulticasterParent
/*     */   {
/*     */     volatile Subscription s;
/*  80 */     static final AtomicReferenceFieldUpdater<MonoPublishMulticaster, Subscription> S = AtomicReferenceFieldUpdater.newUpdater(MonoPublishMulticaster.class, Subscription.class, "s");
/*     */ 
/*     */     
/*     */     volatile int wip;
/*     */ 
/*     */     
/*  86 */     static final AtomicIntegerFieldUpdater<MonoPublishMulticaster> WIP = AtomicIntegerFieldUpdater.newUpdater(MonoPublishMulticaster.class, "wip");
/*     */ 
/*     */     
/*     */     volatile MonoPublishMulticast.PublishMulticastInner<T>[] subscribers;
/*     */     
/*  91 */     static final AtomicReferenceFieldUpdater<MonoPublishMulticaster, MonoPublishMulticast.PublishMulticastInner[]> SUBSCRIBERS = (AtomicReferenceFieldUpdater)AtomicReferenceFieldUpdater.newUpdater(MonoPublishMulticaster.class, (Class)MonoPublishMulticast.PublishMulticastInner[].class, "subscribers");
/*     */ 
/*     */     
/*  94 */     static final MonoPublishMulticast.PublishMulticastInner[] EMPTY = new MonoPublishMulticast.PublishMulticastInner[0];
/*     */ 
/*     */     
/*  97 */     static final MonoPublishMulticast.PublishMulticastInner[] TERMINATED = new MonoPublishMulticast.PublishMulticastInner[0];
/*     */     
/*     */     volatile boolean done;
/*     */     
/*     */     @Nullable
/*     */     T value;
/*     */     
/*     */     Throwable error;
/*     */     
/*     */     volatile boolean connected;
/*     */     
/*     */     final Context context;
/*     */     
/*     */     MonoPublishMulticaster(Context ctx) {
/* 111 */       SUBSCRIBERS.lazySet(this, EMPTY);
/* 112 */       this.context = ctx;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 118 */       if (key == Scannable.Attr.PARENT) {
/* 119 */         return this.s;
/*     */       }
/* 121 */       if (key == Scannable.Attr.ERROR) {
/* 122 */         return this.error;
/*     */       }
/* 124 */       if (key == Scannable.Attr.CANCELLED) {
/* 125 */         return Boolean.valueOf((this.s == Operators.cancelledSubscription()));
/*     */       }
/* 127 */       if (key == Scannable.Attr.TERMINATED) {
/* 128 */         return Boolean.valueOf(this.done);
/*     */       }
/* 130 */       if (key == Scannable.Attr.PREFETCH) {
/* 131 */         return Integer.valueOf(1);
/*     */       }
/* 133 */       if (key == Scannable.Attr.BUFFERED) {
/* 134 */         return Integer.valueOf((this.value != null) ? 1 : 0);
/*     */       }
/* 136 */       if (key == Scannable.Attr.RUN_STYLE) {
/* 137 */         return Scannable.Attr.RunStyle.SYNC;
/*     */       }
/*     */       
/* 140 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public Stream<? extends Scannable> inners() {
/* 145 */       return Stream.of((Scannable[])this.subscribers);
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/* 150 */       return this.context;
/*     */     }
/*     */ 
/*     */     
/*     */     public void subscribe(CoreSubscriber<? super T> actual) {
/* 155 */       MonoPublishMulticast.PublishMulticastInner<T> pcs = new MonoPublishMulticast.PublishMulticastInner<>(this, actual);
/* 156 */       actual.onSubscribe(pcs);
/*     */       
/* 158 */       if (add(pcs)) {
/* 159 */         if (pcs.cancelled == 1) {
/* 160 */           remove(pcs);
/*     */           return;
/*     */         } 
/* 163 */         drain();
/*     */       } else {
/*     */         
/* 166 */         Throwable ex = this.error;
/* 167 */         if (ex != null) {
/* 168 */           actual.onError(ex);
/*     */         } else {
/*     */           
/* 171 */           actual.onComplete();
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 178 */       if (Operators.setOnce(S, this, s)) {
/* 179 */         this.connected = true;
/* 180 */         s.request(Long.MAX_VALUE);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 186 */       if (this.done) {
/* 187 */         Operators.onNextDropped(t, this.context);
/*     */         
/*     */         return;
/*     */       } 
/* 191 */       this.value = t;
/* 192 */       this.done = true;
/* 193 */       drain();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 198 */       if (this.done) {
/* 199 */         Operators.onErrorDropped(t, this.context);
/*     */         return;
/*     */       } 
/* 202 */       this.error = t;
/* 203 */       this.done = true;
/* 204 */       drain();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 209 */       this.done = true;
/* 210 */       drain();
/*     */     }
/*     */     
/*     */     void drain() {
/* 214 */       if (WIP.getAndIncrement(this) != 0) {
/*     */         return;
/*     */       }
/*     */       
/* 218 */       int missed = 1;
/*     */       
/*     */       do {
/* 221 */         if (this.connected) {
/* 222 */           if (this.s == Operators.cancelledSubscription()) {
/* 223 */             this.value = null;
/*     */             
/*     */             return;
/*     */           } 
/* 227 */           T v = this.value;
/*     */           
/* 229 */           MonoPublishMulticast.PublishMulticastInner<T>[] a = this.subscribers;
/* 230 */           int n = a.length;
/*     */           
/* 232 */           if (n != 0) {
/* 233 */             if (this.s == Operators.cancelledSubscription()) {
/* 234 */               this.value = null;
/*     */               
/*     */               return;
/*     */             } 
/*     */             
/* 239 */             MonoPublishMulticast.PublishMulticastInner[] arrayOfPublishMulticastInner2 = SUBSCRIBERS.getAndSet(this, TERMINATED);
/* 240 */             MonoPublishMulticast.PublishMulticastInner[] arrayOfPublishMulticastInner1 = arrayOfPublishMulticastInner2;
/* 241 */             n = arrayOfPublishMulticastInner1.length;
/* 242 */             Throwable ex = this.error;
/* 243 */             if (ex != null) {
/* 244 */               for (int i = 0; i < n; i++) {
/* 245 */                 (arrayOfPublishMulticastInner1[i]).actual.onError(ex);
/*     */               }
/*     */             }
/* 248 */             else if (v == null) {
/* 249 */               for (int i = 0; i < n; i++) {
/* 250 */                 (arrayOfPublishMulticastInner1[i]).actual.onComplete();
/*     */               }
/*     */             } else {
/*     */               
/* 254 */               for (int i = 0; i < n; i++) {
/* 255 */                 (arrayOfPublishMulticastInner1[i]).actual.onNext(v);
/* 256 */                 (arrayOfPublishMulticastInner1[i]).actual.onComplete();
/*     */               } 
/* 258 */               this.value = null;
/*     */             } 
/*     */             
/*     */             return;
/*     */           } 
/*     */         } 
/* 264 */         missed = WIP.addAndGet(this, -missed);
/* 265 */       } while (missed != 0);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     boolean add(MonoPublishMulticast.PublishMulticastInner<T> s) {
/*     */       while (true) {
/* 273 */         MonoPublishMulticast.PublishMulticastInner<T>[] a = this.subscribers;
/*     */         
/* 275 */         if (a == TERMINATED) {
/* 276 */           return false;
/*     */         }
/*     */         
/* 279 */         int n = a.length;
/*     */ 
/*     */         
/* 282 */         MonoPublishMulticast.PublishMulticastInner[] arrayOfPublishMulticastInner = new MonoPublishMulticast.PublishMulticastInner[n + 1];
/* 283 */         System.arraycopy(a, 0, arrayOfPublishMulticastInner, 0, n);
/* 284 */         arrayOfPublishMulticastInner[n] = s;
/* 285 */         if (SUBSCRIBERS.compareAndSet(this, a, arrayOfPublishMulticastInner))
/* 286 */           return true; 
/*     */       } 
/*     */     }
/*     */     
/*     */     void remove(MonoPublishMulticast.PublishMulticastInner<T> s) {
/*     */       MonoPublishMulticast.PublishMulticastInner<T>[] a;
/*     */       MonoPublishMulticast.PublishMulticastInner[] arrayOfPublishMulticastInner;
/*     */       do {
/* 294 */         a = this.subscribers;
/*     */         
/* 296 */         if (a == TERMINATED || a == EMPTY) {
/*     */           return;
/*     */         }
/*     */         
/* 300 */         int n = a.length;
/* 301 */         int j = -1;
/*     */         
/* 303 */         for (int i = 0; i < n; i++) {
/* 304 */           if (a[i] == s) {
/* 305 */             j = i;
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/* 310 */         if (j < 0) {
/*     */           return;
/*     */         }
/*     */ 
/*     */         
/* 315 */         if (n == 1) {
/* 316 */           arrayOfPublishMulticastInner = EMPTY;
/*     */         } else {
/*     */           
/* 319 */           arrayOfPublishMulticastInner = new MonoPublishMulticast.PublishMulticastInner[n - 1];
/* 320 */           System.arraycopy(a, 0, arrayOfPublishMulticastInner, 0, j);
/* 321 */           System.arraycopy(a, j + 1, arrayOfPublishMulticastInner, j, n - j - 1);
/*     */         } 
/* 323 */       } while (!SUBSCRIBERS.compareAndSet(this, a, arrayOfPublishMulticastInner));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void terminate() {
/* 331 */       Operators.terminate(S, this);
/* 332 */       if (WIP.getAndIncrement(this) == 0 && 
/* 333 */         this.connected) {
/* 334 */         this.value = null;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class PublishMulticastInner<T>
/*     */     implements InnerProducer<T>
/*     */   {
/*     */     final MonoPublishMulticast.MonoPublishMulticaster<T> parent;
/*     */     
/*     */     final CoreSubscriber<? super T> actual;
/*     */     volatile int cancelled;
/* 347 */     static final AtomicIntegerFieldUpdater<PublishMulticastInner> CANCELLED = AtomicIntegerFieldUpdater.newUpdater(PublishMulticastInner.class, "cancelled");
/*     */ 
/*     */     
/*     */     PublishMulticastInner(MonoPublishMulticast.MonoPublishMulticaster<T> parent, CoreSubscriber<? super T> actual) {
/* 351 */       this.parent = parent;
/* 352 */       this.actual = actual;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 358 */       if (key == Scannable.Attr.PARENT) {
/* 359 */         return this.parent;
/*     */       }
/* 361 */       if (key == Scannable.Attr.CANCELLED) {
/* 362 */         return Boolean.valueOf((this.cancelled == 1));
/*     */       }
/* 364 */       if (key == Scannable.Attr.RUN_STYLE) {
/* 365 */         return Scannable.Attr.RunStyle.SYNC;
/*     */       }
/*     */       
/* 368 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 373 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 378 */       if (Operators.validate(n)) {
/* 379 */         this.parent.drain();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 385 */       if (CANCELLED.compareAndSet(this, 0, 1)) {
/* 386 */         this.parent.remove(this);
/* 387 */         this.parent.drain();
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\MonoPublishMulticast.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */