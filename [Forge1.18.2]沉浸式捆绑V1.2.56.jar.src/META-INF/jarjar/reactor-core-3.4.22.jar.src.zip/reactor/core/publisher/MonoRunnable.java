/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.time.Duration;
/*    */ import java.util.Objects;
/*    */ import java.util.concurrent.Callable;
/*    */ import java.util.concurrent.atomic.AtomicBoolean;
/*    */ import org.reactivestreams.Subscription;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Scannable;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MonoRunnable<T>
/*    */   extends Mono<T>
/*    */   implements Callable<Void>, SourceProducer<T>
/*    */ {
/*    */   final Runnable run;
/*    */   
/*    */   MonoRunnable(Runnable run) {
/* 37 */     this.run = Objects.<Runnable>requireNonNull(run, "run");
/*    */   }
/*    */ 
/*    */   
/*    */   public void subscribe(CoreSubscriber<? super T> actual) {
/* 42 */     MonoRunnableEagerSubscription s = new MonoRunnableEagerSubscription();
/* 43 */     actual.onSubscribe(s);
/* 44 */     if (s.isCancelled()) {
/*    */       return;
/*    */     }
/*    */     
/*    */     try {
/* 49 */       this.run.run();
/* 50 */       actual.onComplete();
/* 51 */     } catch (Throwable ex) {
/* 52 */       actual.onError(Operators.onOperatorError(ex, actual.currentContext()));
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public T block(Duration m) {
/* 59 */     this.run.run();
/* 60 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public T block() {
/* 66 */     this.run.run();
/* 67 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public Void call() throws Exception {
/* 73 */     this.run.run();
/* 74 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 79 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 80 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   static final class MonoRunnableEagerSubscription
/*    */     extends AtomicBoolean
/*    */     implements Subscription
/*    */   {
/*    */     public void request(long n) {}
/*    */ 
/*    */     
/*    */     public void cancel() {
/* 92 */       set(true);
/*    */     }
/*    */     
/*    */     public boolean isCancelled() {
/* 96 */       return get();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\MonoRunnable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */