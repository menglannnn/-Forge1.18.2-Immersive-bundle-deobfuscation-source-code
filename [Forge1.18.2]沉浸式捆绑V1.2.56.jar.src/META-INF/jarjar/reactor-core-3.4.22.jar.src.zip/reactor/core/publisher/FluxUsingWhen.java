/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.Function;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.Loggers;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxUsingWhen<T, S>
/*     */   extends Flux<T>
/*     */   implements SourceProducer<T>
/*     */ {
/*     */   final Publisher<S> resourceSupplier;
/*     */   final Function<? super S, ? extends Publisher<? extends T>> resourceClosure;
/*     */   final Function<? super S, ? extends Publisher<?>> asyncComplete;
/*     */   final BiFunction<? super S, ? super Throwable, ? extends Publisher<?>> asyncError;
/*     */   @Nullable
/*     */   final Function<? super S, ? extends Publisher<?>> asyncCancel;
/*     */   
/*     */   FluxUsingWhen(Publisher<S> resourceSupplier, Function<? super S, ? extends Publisher<? extends T>> resourceClosure, Function<? super S, ? extends Publisher<?>> asyncComplete, BiFunction<? super S, ? super Throwable, ? extends Publisher<?>> asyncError, @Nullable Function<? super S, ? extends Publisher<?>> asyncCancel) {
/*  68 */     this.resourceSupplier = Objects.<Publisher<S>>requireNonNull(resourceSupplier, "resourceSupplier");
/*  69 */     this.resourceClosure = Objects.<Function<? super S, ? extends Publisher<? extends T>>>requireNonNull(resourceClosure, "resourceClosure");
/*  70 */     this.asyncComplete = Objects.<Function<? super S, ? extends Publisher<?>>>requireNonNull(asyncComplete, "asyncComplete");
/*  71 */     this.asyncError = Objects.<BiFunction<? super S, ? super Throwable, ? extends Publisher<?>>>requireNonNull(asyncError, "asyncError");
/*  72 */     this.asyncCancel = asyncCancel;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super T> actual) {
/*  78 */     if (this.resourceSupplier instanceof Callable) {
/*     */       try {
/*  80 */         Callable<S> resourceCallable = (Callable<S>)this.resourceSupplier;
/*  81 */         S resource = resourceCallable.call();
/*  82 */         if (resource == null) {
/*  83 */           Operators.complete((Subscriber<?>)actual);
/*     */         } else {
/*     */           
/*  86 */           Publisher<? extends T> p = deriveFluxFromResource(resource, this.resourceClosure);
/*  87 */           UsingWhenSubscriber<? super T, S> subscriber = prepareSubscriberForResource(resource, actual, this.asyncComplete, this.asyncError, this.asyncCancel, null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*  94 */           p.subscribe((Subscriber)subscriber);
/*     */         }
/*     */       
/*  97 */       } catch (Throwable e) {
/*  98 */         Operators.error((Subscriber<?>)actual, e);
/*     */       } 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 104 */     this.resourceSupplier.subscribe((Subscriber)new ResourceSubscriber<>(actual, this.resourceClosure, this.asyncComplete, this.asyncError, this.asyncCancel, this.resourceSupplier instanceof Mono));
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/* 109 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 110 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static <RESOURCE, T> Publisher<? extends T> deriveFluxFromResource(RESOURCE resource, Function<? super RESOURCE, ? extends Publisher<? extends T>> resourceClosure) {
/*     */     Flux<?> flux;
/*     */     try {
/* 120 */       Publisher<? extends T> p = Objects.<Publisher<? extends T>>requireNonNull(resourceClosure.apply(resource), "The resourceClosure function returned a null value");
/*     */     
/*     */     }
/* 123 */     catch (Throwable e) {
/* 124 */       flux = Flux.error(e);
/*     */     } 
/*     */     
/* 127 */     return (Publisher)flux;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static <RESOURCE, T> UsingWhenSubscriber<? super T, RESOURCE> prepareSubscriberForResource(RESOURCE resource, CoreSubscriber<? super T> actual, Function<? super RESOURCE, ? extends Publisher<?>> asyncComplete, BiFunction<? super RESOURCE, ? super Throwable, ? extends Publisher<?>> asyncError, @Nullable Function<? super RESOURCE, ? extends Publisher<?>> asyncCancel, @Nullable Operators.DeferredSubscription arbiter) {
/* 137 */     if (actual instanceof Fuseable.ConditionalSubscriber) {
/*     */       
/* 139 */       Fuseable.ConditionalSubscriber<? super T> conditionalActual = (Fuseable.ConditionalSubscriber<? super T>)actual;
/* 140 */       return new UsingWhenConditionalSubscriber<>(conditionalActual, resource, asyncComplete, asyncError, asyncCancel, arbiter);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 148 */     return new UsingWhenSubscriber<>(actual, resource, asyncComplete, asyncError, asyncCancel, arbiter);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static class ResourceSubscriber<S, T>
/*     */     extends Operators.DeferredSubscription
/*     */     implements InnerConsumer<S>
/*     */   {
/*     */     final CoreSubscriber<? super T> actual;
/*     */ 
/*     */     
/*     */     final Function<? super S, ? extends Publisher<? extends T>> resourceClosure;
/*     */     
/*     */     final Function<? super S, ? extends Publisher<?>> asyncComplete;
/*     */     
/*     */     final BiFunction<? super S, ? super Throwable, ? extends Publisher<?>> asyncError;
/*     */     
/*     */     @Nullable
/*     */     final Function<? super S, ? extends Publisher<?>> asyncCancel;
/*     */     
/*     */     final boolean isMonoSource;
/*     */     
/*     */     Subscription resourceSubscription;
/*     */     
/*     */     boolean resourceProvided;
/*     */ 
/*     */     
/*     */     ResourceSubscriber(CoreSubscriber<? super T> actual, Function<? super S, ? extends Publisher<? extends T>> resourceClosure, Function<? super S, ? extends Publisher<?>> asyncComplete, BiFunction<? super S, ? super Throwable, ? extends Publisher<?>> asyncError, @Nullable Function<? super S, ? extends Publisher<?>> asyncCancel, boolean isMonoSource) {
/* 177 */       this.actual = Objects.<CoreSubscriber<? super T>>requireNonNull(actual, "actual");
/* 178 */       this.resourceClosure = Objects.<Function<? super S, ? extends Publisher<? extends T>>>requireNonNull(resourceClosure, "resourceClosure");
/* 179 */       this.asyncComplete = Objects.<Function<? super S, ? extends Publisher<?>>>requireNonNull(asyncComplete, "asyncComplete");
/* 180 */       this.asyncError = Objects.<BiFunction<? super S, ? super Throwable, ? extends Publisher<?>>>requireNonNull(asyncError, "asyncError");
/* 181 */       this.asyncCancel = asyncCancel;
/* 182 */       this.isMonoSource = isMonoSource;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(S resource) {
/* 187 */       if (this.resourceProvided) {
/* 188 */         Operators.onNextDropped(resource, this.actual.currentContext());
/*     */         return;
/*     */       } 
/* 191 */       this.resourceProvided = true;
/*     */       
/* 193 */       Publisher<? extends T> p = FluxUsingWhen.deriveFluxFromResource((RESOURCE)resource, this.resourceClosure);
/*     */       
/* 195 */       p.subscribe((Subscriber)FluxUsingWhen.prepareSubscriberForResource((RESOURCE)resource, this.actual, this.asyncComplete, this.asyncError, this.asyncCancel, this));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 202 */       if (!this.isMonoSource) {
/* 203 */         this.resourceSubscription.cancel();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/* 209 */       return this.actual.currentContext();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable throwable) {
/* 214 */       if (this.resourceProvided) {
/* 215 */         Operators.onErrorDropped(throwable, this.actual.currentContext());
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/* 220 */       this.actual.onError(throwable);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 225 */       if (this.resourceProvided) {
/*     */         return;
/*     */       }
/*     */ 
/*     */       
/* 230 */       this.actual.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 235 */       if (Operators.validate(this.resourceSubscription, s)) {
/* 236 */         this.resourceSubscription = s;
/* 237 */         this.actual.onSubscribe(this);
/* 238 */         s.request(Long.MAX_VALUE);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 244 */       if (!this.resourceProvided) {
/* 245 */         this.resourceSubscription.cancel();
/*     */       }
/*     */       
/* 248 */       super.cancel();
/*     */     }
/*     */ 
/*     */     
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 253 */       if (key == Scannable.Attr.PARENT) return this.resourceSubscription; 
/* 254 */       if (key == Scannable.Attr.ACTUAL) return this.actual; 
/* 255 */       if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(2147483647); 
/* 256 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.resourceProvided); 
/* 257 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 259 */       return null;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static class UsingWhenSubscriber<T, S>
/*     */     implements UsingWhenParent<T>
/*     */   {
/*     */     final CoreSubscriber<? super T> actual;
/*     */     
/*     */     final S resource;
/*     */     
/*     */     final Function<? super S, ? extends Publisher<?>> asyncComplete;
/*     */     final BiFunction<? super S, ? super Throwable, ? extends Publisher<?>> asyncError;
/*     */     @Nullable
/*     */     final Function<? super S, ? extends Publisher<?>> asyncCancel;
/*     */     @Nullable
/*     */     final Operators.DeferredSubscription arbiter;
/*     */     volatile int callbackApplied;
/* 278 */     static final AtomicIntegerFieldUpdater<UsingWhenSubscriber> CALLBACK_APPLIED = AtomicIntegerFieldUpdater.newUpdater(UsingWhenSubscriber.class, "callbackApplied");
/*     */ 
/*     */ 
/*     */     
/*     */     Throwable error;
/*     */ 
/*     */ 
/*     */     
/*     */     Subscription s;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     UsingWhenSubscriber(CoreSubscriber<? super T> actual, S resource, Function<? super S, ? extends Publisher<?>> asyncComplete, BiFunction<? super S, ? super Throwable, ? extends Publisher<?>> asyncError, @Nullable Function<? super S, ? extends Publisher<?>> asyncCancel, @Nullable Operators.DeferredSubscription arbiter) {
/* 292 */       this.actual = actual;
/* 293 */       this.resource = resource;
/* 294 */       this.asyncComplete = asyncComplete;
/* 295 */       this.asyncError = asyncError;
/* 296 */       this.asyncCancel = asyncCancel;
/* 297 */       this.arbiter = arbiter;
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 302 */       return this.actual;
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 307 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf((this.error != null)); 
/* 308 */       if (key == Scannable.Attr.ERROR) return (this.error == Exceptions.TERMINATED) ? null : this.error; 
/* 309 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf((this.callbackApplied == 3)); 
/* 310 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 311 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 313 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long l) {
/* 318 */       if (Operators.validate(l)) {
/* 319 */         this.s.request(l);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 325 */       if (CALLBACK_APPLIED.compareAndSet(this, 0, 3)) {
/* 326 */         this.s.cancel();
/*     */         try {
/* 328 */           if (this.asyncCancel != null) {
/* 329 */             Flux.from(this.asyncCancel.apply(this.resource))
/* 330 */               .subscribe(new FluxUsingWhen.CancelInner(this));
/*     */           } else {
/*     */             
/* 333 */             Flux.from(this.asyncComplete.apply(this.resource))
/* 334 */               .subscribe(new FluxUsingWhen.CancelInner(this));
/*     */           }
/*     */         
/* 337 */         } catch (Throwable error) {
/* 338 */           Loggers.getLogger(FluxUsingWhen.class).warn("Error generating async resource cleanup during onCancel", error);
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 345 */       this.actual.onNext(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 350 */       if (CALLBACK_APPLIED.compareAndSet(this, 0, 2)) {
/*     */         Publisher<?> p;
/*     */         
/*     */         try {
/* 354 */           p = Objects.<Publisher>requireNonNull(this.asyncError.apply(this.resource, t), "The asyncError returned a null Publisher");
/*     */         
/*     */         }
/* 357 */         catch (Throwable e) {
/* 358 */           Throwable _e = Operators.onOperatorError(e, this.actual.currentContext());
/* 359 */           _e = Exceptions.addSuppressed(_e, t);
/* 360 */           this.actual.onError(_e);
/*     */           
/*     */           return;
/*     */         } 
/* 364 */         p.subscribe((Subscriber)new FluxUsingWhen.RollbackInner(this, t));
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 370 */       if (CALLBACK_APPLIED.compareAndSet(this, 0, 1)) {
/*     */         Publisher<?> p;
/*     */         
/*     */         try {
/* 374 */           p = Objects.<Publisher>requireNonNull(this.asyncComplete.apply(this.resource), "The asyncComplete returned a null Publisher");
/*     */         
/*     */         }
/* 377 */         catch (Throwable e) {
/* 378 */           Throwable _e = Operators.onOperatorError(e, this.actual.currentContext());
/*     */           
/* 380 */           deferredError(_e);
/*     */           
/*     */           return;
/*     */         } 
/* 384 */         p.subscribe((Subscriber)new FluxUsingWhen.CommitInner(this));
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void deferredComplete() {
/* 391 */       this.error = Exceptions.TERMINATED;
/* 392 */       this.actual.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     public void deferredError(Throwable error) {
/* 397 */       this.error = error;
/* 398 */       this.actual.onError(error);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 403 */       if (Operators.validate(this.s, s)) {
/* 404 */         this.s = s;
/* 405 */         if (this.arbiter == null) {
/* 406 */           this.actual.onSubscribe(this);
/*     */         } else {
/*     */           
/* 409 */           this.arbiter.set(this);
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class UsingWhenConditionalSubscriber<T, S>
/*     */     extends UsingWhenSubscriber<T, S>
/*     */     implements Fuseable.ConditionalSubscriber<T>
/*     */   {
/*     */     final Fuseable.ConditionalSubscriber<? super T> actual;
/*     */ 
/*     */ 
/*     */     
/*     */     UsingWhenConditionalSubscriber(Fuseable.ConditionalSubscriber<? super T> actual, S resource, Function<? super S, ? extends Publisher<?>> asyncComplete, BiFunction<? super S, ? super Throwable, ? extends Publisher<?>> asyncError, @Nullable Function<? super S, ? extends Publisher<?>> asyncCancel, @Nullable Operators.DeferredSubscription arbiter) {
/* 427 */       super((CoreSubscriber<? super T>)actual, resource, asyncComplete, asyncError, asyncCancel, arbiter);
/* 428 */       this.actual = actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean tryOnNext(T t) {
/* 433 */       return this.actual.tryOnNext(t);
/*     */     }
/*     */   }
/*     */   
/*     */   static final class RollbackInner
/*     */     implements InnerConsumer<Object>
/*     */   {
/*     */     final FluxUsingWhen.UsingWhenParent parent;
/*     */     final Throwable rollbackCause;
/*     */     boolean done;
/*     */     
/*     */     RollbackInner(FluxUsingWhen.UsingWhenParent ts, Throwable rollbackCause) {
/* 445 */       this.parent = ts;
/* 446 */       this.rollbackCause = rollbackCause;
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/* 451 */       return this.parent.currentContext();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 456 */       ((Subscription)Objects.<Subscription>requireNonNull(s, "Subscription cannot be null"))
/* 457 */         .request(Long.MAX_VALUE);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onNext(Object o) {}
/*     */ 
/*     */ 
/*     */     
/*     */     public void onError(Throwable e) {
/* 467 */       this.done = true;
/* 468 */       RuntimeException rollbackError = new RuntimeException("Async resource cleanup failed after onError", e);
/* 469 */       this.parent.deferredError(Exceptions.addSuppressed(rollbackError, this.rollbackCause));
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 474 */       this.done = true;
/* 475 */       this.parent.deferredError(this.rollbackCause);
/*     */     }
/*     */ 
/*     */     
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 480 */       if (key == Scannable.Attr.PARENT) return this.parent; 
/* 481 */       if (key == Scannable.Attr.ACTUAL) return this.parent.actual(); 
/* 482 */       if (key == Scannable.Attr.ERROR) return this.rollbackCause; 
/* 483 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 484 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 486 */       return null;
/*     */     }
/*     */   }
/*     */   
/*     */   static final class CommitInner
/*     */     implements InnerConsumer<Object>
/*     */   {
/*     */     final FluxUsingWhen.UsingWhenParent parent;
/*     */     boolean done;
/*     */     
/*     */     CommitInner(FluxUsingWhen.UsingWhenParent ts) {
/* 497 */       this.parent = ts;
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/* 502 */       return this.parent.currentContext();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 507 */       ((Subscription)Objects.<Subscription>requireNonNull(s, "Subscription cannot be null"))
/* 508 */         .request(Long.MAX_VALUE);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onNext(Object o) {}
/*     */ 
/*     */ 
/*     */     
/*     */     public void onError(Throwable e) {
/* 518 */       this.done = true;
/* 519 */       Throwable e_ = Operators.onOperatorError(e, this.parent.currentContext());
/* 520 */       Throwable commitError = new RuntimeException("Async resource cleanup failed after onComplete", e_);
/* 521 */       this.parent.deferredError(commitError);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 526 */       this.done = true;
/* 527 */       this.parent.deferredComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 532 */       if (key == Scannable.Attr.PARENT) return this.parent; 
/* 533 */       if (key == Scannable.Attr.ACTUAL) return this.parent.actual(); 
/* 534 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 535 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 537 */       return null;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class CancelInner
/*     */     implements InnerConsumer<Object>
/*     */   {
/*     */     final FluxUsingWhen.UsingWhenParent parent;
/*     */ 
/*     */     
/*     */     CancelInner(FluxUsingWhen.UsingWhenParent ts) {
/* 549 */       this.parent = ts;
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/* 554 */       return this.parent.currentContext();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 559 */       ((Subscription)Objects.<Subscription>requireNonNull(s, "Subscription cannot be null"))
/* 560 */         .request(Long.MAX_VALUE);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onNext(Object o) {}
/*     */ 
/*     */ 
/*     */     
/*     */     public void onError(Throwable e) {
/* 570 */       Loggers.getLogger(FluxUsingWhen.class).warn("Async resource cleanup failed after cancel", e);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onComplete() {}
/*     */ 
/*     */ 
/*     */     
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 580 */       if (key == Scannable.Attr.PARENT) return this.parent; 
/* 581 */       if (key == Scannable.Attr.ACTUAL) return this.parent.actual(); 
/* 582 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 584 */       return null;
/*     */     }
/*     */   }
/*     */   
/*     */   private static interface UsingWhenParent<T> extends InnerOperator<T, T> {
/*     */     void deferredComplete();
/*     */     
/*     */     void deferredError(Throwable param1Throwable);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\FluxUsingWhen.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */