/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import reactor.core.Scannable;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class MonoOperator<I, O>
/*    */   extends Mono<O>
/*    */   implements Scannable
/*    */ {
/*    */   protected final Mono<? extends I> source;
/*    */   
/*    */   protected MonoOperator(Mono<? extends I> source) {
/* 46 */     this.source = Objects.<Mono<? extends I>>requireNonNull(source);
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 52 */     if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(2147483647); 
/* 53 */     if (key == Scannable.Attr.PARENT) return this.source; 
/* 54 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\MonoOperator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */