/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.function.Tuple2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxIterable<T>
/*     */   extends Flux<T>
/*     */   implements Fuseable, SourceProducer<T>
/*     */ {
/*     */   final Iterable<? extends T> iterable;
/*     */   @Nullable
/*     */   private final Runnable onClose;
/*     */   
/*     */   static <T> boolean checkFinite(Iterable<T> iterable) {
/*  57 */     return (iterable instanceof Collection || iterable.spliterator().hasCharacteristics(64));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   FluxIterable(Iterable<? extends T> iterable, @Nullable Runnable onClose) {
/*  65 */     this.iterable = Objects.<Iterable<? extends T>>requireNonNull(iterable, "iterable");
/*  66 */     this.onClose = onClose;
/*     */   }
/*     */   
/*     */   FluxIterable(Iterable<? extends T> iterable) {
/*  70 */     this(iterable, null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super T> actual) {
/*     */     boolean knownToBeFinite;
/*     */     Iterator<? extends T> it;
/*     */     try {
/*  79 */       knownToBeFinite = checkFinite(this.iterable);
/*  80 */       it = this.iterable.iterator();
/*     */     }
/*  82 */     catch (Throwable e) {
/*  83 */       Operators.error((Subscriber<?>)actual, Operators.onOperatorError(e, actual.currentContext()));
/*     */       
/*     */       return;
/*     */     } 
/*  87 */     subscribe(actual, it, knownToBeFinite, this.onClose);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  92 */     if (key == Scannable.Attr.BUFFERED) {
/*  93 */       if (this.iterable instanceof Collection) return Integer.valueOf(((Collection)this.iterable).size()); 
/*  94 */       if (this.iterable instanceof Tuple2) return Integer.valueOf(((Tuple2)this.iterable).size()); 
/*     */     } 
/*  96 */     if (key == Scannable.Attr.RUN_STYLE) {
/*  97 */       return Scannable.Attr.RunStyle.SYNC;
/*     */     }
/*  99 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T> void subscribe(CoreSubscriber<? super T> s, Iterator<? extends T> it, boolean knownToBeFinite) {
/* 109 */     subscribe(s, it, knownToBeFinite, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T> void subscribe(CoreSubscriber<? super T> s, Iterator<? extends T> it, boolean knownToBeFinite, @Nullable Runnable onClose) {
/*     */     boolean b;
/* 125 */     if (it == null) {
/* 126 */       Operators.error((Subscriber<?>)s, new NullPointerException("The iterator is null"));
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*     */     try {
/* 133 */       b = it.hasNext();
/*     */     }
/* 135 */     catch (Throwable e) {
/* 136 */       Operators.error((Subscriber<?>)s, Operators.onOperatorError(e, s.currentContext()));
/* 137 */       if (onClose != null) {
/*     */         try {
/* 139 */           onClose.run();
/*     */         }
/* 141 */         catch (Throwable t) {
/* 142 */           Operators.onErrorDropped(t, s.currentContext());
/*     */         } 
/*     */       }
/*     */       return;
/*     */     } 
/* 147 */     if (!b) {
/* 148 */       Operators.complete((Subscriber<?>)s);
/* 149 */       if (onClose != null) {
/*     */         try {
/* 151 */           onClose.run();
/*     */         }
/* 153 */         catch (Throwable t) {
/* 154 */           Operators.onErrorDropped(t, s.currentContext());
/*     */         } 
/*     */       }
/*     */       
/*     */       return;
/*     */     } 
/* 160 */     if (s instanceof Fuseable.ConditionalSubscriber) {
/* 161 */       s.onSubscribe(new IterableSubscriptionConditional<>((Fuseable.ConditionalSubscriber<? super T>)s, it, knownToBeFinite, onClose));
/*     */     }
/*     */     else {
/*     */       
/* 165 */       s.onSubscribe(new IterableSubscription<>(s, it, knownToBeFinite, onClose));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   static final class IterableSubscription<T>
/*     */     implements InnerProducer<T>, Fuseable.SynchronousSubscription<T>
/*     */   {
/*     */     final CoreSubscriber<? super T> actual;
/*     */     
/*     */     final Iterator<? extends T> iterator;
/*     */     
/*     */     final boolean knownToBeFinite;
/*     */     
/*     */     final Runnable onClose;
/*     */     
/*     */     volatile boolean cancelled;
/*     */     volatile long requested;
/* 183 */     static final AtomicLongFieldUpdater<IterableSubscription> REQUESTED = AtomicLongFieldUpdater.newUpdater(IterableSubscription.class, "requested");
/*     */ 
/*     */ 
/*     */     
/*     */     int state;
/*     */ 
/*     */ 
/*     */     
/*     */     static final int STATE_HAS_NEXT_NO_VALUE = 0;
/*     */ 
/*     */     
/*     */     static final int STATE_HAS_NEXT_HAS_VALUE = 1;
/*     */ 
/*     */     
/*     */     static final int STATE_NO_NEXT = 2;
/*     */ 
/*     */     
/*     */     static final int STATE_CALL_HAS_NEXT = 3;
/*     */ 
/*     */     
/*     */     T current;
/*     */ 
/*     */     
/*     */     Throwable hasNextFailure;
/*     */ 
/*     */ 
/*     */     
/*     */     IterableSubscription(CoreSubscriber<? super T> actual, Iterator<? extends T> iterator, boolean knownToBeFinite, @Nullable Runnable onClose) {
/* 211 */       this.actual = actual;
/* 212 */       this.iterator = iterator;
/* 213 */       this.knownToBeFinite = knownToBeFinite;
/* 214 */       this.onClose = onClose;
/*     */     }
/*     */ 
/*     */     
/*     */     IterableSubscription(CoreSubscriber<? super T> actual, Iterator<? extends T> iterator, boolean knownToBeFinite) {
/* 219 */       this(actual, iterator, knownToBeFinite, null);
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 224 */       if (Operators.validate(n) && 
/* 225 */         Operators.addCap(REQUESTED, this, n) == 0L) {
/* 226 */         if (n == Long.MAX_VALUE) {
/* 227 */           fastPath();
/*     */         } else {
/*     */           
/* 230 */           slowPath(n);
/*     */         } 
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     private void onCloseWithDropError() {
/* 237 */       if (this.onClose != null) {
/*     */         try {
/* 239 */           this.onClose.run();
/*     */         }
/* 241 */         catch (Throwable t) {
/* 242 */           Operators.onErrorDropped(t, this.actual.currentContext());
/*     */         } 
/*     */       }
/*     */     }
/*     */     
/*     */     void slowPath(long n) {
/* 248 */       Iterator<? extends T> a = this.iterator;
/* 249 */       CoreSubscriber<? super T> coreSubscriber = this.actual;
/*     */       
/* 251 */       long e = 0L;
/*     */ 
/*     */       
/*     */       while (true) {
/* 255 */         while (e != n) {
/*     */           T t;
/*     */           boolean b;
/*     */           try {
/* 259 */             t = Objects.requireNonNull(a.next(), "The iterator returned a null value");
/*     */           
/*     */           }
/* 262 */           catch (Throwable ex) {
/* 263 */             coreSubscriber.onError(ex);
/* 264 */             onCloseWithDropError();
/*     */             
/*     */             return;
/*     */           } 
/* 268 */           if (this.cancelled) {
/*     */             return;
/*     */           }
/*     */           
/* 272 */           coreSubscriber.onNext(t);
/*     */           
/* 274 */           if (this.cancelled) {
/*     */             return;
/*     */           }
/*     */ 
/*     */ 
/*     */           
/*     */           try {
/* 281 */             b = a.hasNext();
/*     */           }
/* 283 */           catch (Throwable ex) {
/* 284 */             coreSubscriber.onError(ex);
/* 285 */             onCloseWithDropError();
/*     */             
/*     */             return;
/*     */           } 
/* 289 */           if (this.cancelled) {
/*     */             return;
/*     */           }
/*     */           
/* 293 */           if (!b) {
/* 294 */             coreSubscriber.onComplete();
/* 295 */             onCloseWithDropError();
/*     */             
/*     */             return;
/*     */           } 
/* 299 */           e++;
/*     */         } 
/*     */         
/* 302 */         n = this.requested;
/*     */         
/* 304 */         if (n == e) {
/* 305 */           n = REQUESTED.addAndGet(this, -e);
/* 306 */           if (n == 0L) {
/*     */             return;
/*     */           }
/* 309 */           e = 0L;
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     void fastPath() {
/* 315 */       Iterator<? extends T> a = this.iterator;
/* 316 */       CoreSubscriber<? super T> coreSubscriber = this.actual;
/*     */       while (true) {
/*     */         T t;
/*     */         boolean b;
/* 320 */         if (this.cancelled) {
/*     */           return;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         try {
/* 327 */           t = Objects.requireNonNull(a.next(), "The iterator returned a null value");
/*     */         
/*     */         }
/* 330 */         catch (Exception ex) {
/* 331 */           coreSubscriber.onError(ex);
/* 332 */           onCloseWithDropError();
/*     */           
/*     */           return;
/*     */         } 
/* 336 */         if (this.cancelled) {
/*     */           return;
/*     */         }
/*     */         
/* 340 */         coreSubscriber.onNext(t);
/*     */         
/* 342 */         if (this.cancelled) {
/*     */           return;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         try {
/* 349 */           b = a.hasNext();
/*     */         }
/* 351 */         catch (Exception ex) {
/* 352 */           coreSubscriber.onError(ex);
/* 353 */           onCloseWithDropError();
/*     */           
/*     */           return;
/*     */         } 
/* 357 */         if (this.cancelled) {
/*     */           return;
/*     */         }
/*     */         
/* 361 */         if (!b) {
/* 362 */           coreSubscriber.onComplete();
/* 363 */           onCloseWithDropError();
/*     */           return;
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 371 */       onCloseWithDropError();
/* 372 */       this.cancelled = true;
/* 373 */       Operators.onDiscardMultiple(this.iterator, this.knownToBeFinite, this.actual.currentContext());
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 378 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 384 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(this.cancelled); 
/* 385 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf(this.requested); 
/* 386 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf((this.state == 2)); 
/* 387 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 389 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public void clear() {
/* 394 */       Operators.onDiscardMultiple(this.iterator, this.knownToBeFinite, this.actual.currentContext());
/* 395 */       this.state = 2;
/*     */     }
/*     */     
/*     */     public boolean isEmpty() {
/*     */       boolean hasNext;
/* 400 */       int s = this.state;
/* 401 */       if (s == 2) {
/* 402 */         return true;
/*     */       }
/* 404 */       if (this.cancelled && !this.knownToBeFinite) {
/* 405 */         return true;
/*     */       }
/* 407 */       if (s == 1 || s == 0) {
/* 408 */         return false;
/*     */       }
/*     */ 
/*     */       
/*     */       try {
/* 413 */         hasNext = this.iterator.hasNext();
/*     */       }
/* 415 */       catch (Throwable t) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 420 */         this.state = 0;
/* 421 */         this.hasNextFailure = t;
/* 422 */         return false;
/*     */       } 
/*     */       
/* 425 */       if (hasNext) {
/* 426 */         this.state = 0;
/* 427 */         return false;
/*     */       } 
/* 429 */       this.state = 2;
/* 430 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public T poll() {
/* 437 */       if (this.hasNextFailure != null) {
/* 438 */         this.state = 2;
/* 439 */         throw Exceptions.propagate(this.hasNextFailure);
/*     */       } 
/* 441 */       if (!isEmpty()) {
/*     */         T c;
/* 443 */         if (this.state == 0) {
/* 444 */           c = this.iterator.next();
/*     */         } else {
/*     */           
/* 447 */           c = this.current;
/* 448 */           this.current = null;
/*     */         } 
/* 450 */         this.state = 3;
/* 451 */         if (c == null) {
/* 452 */           onCloseWithDropError();
/* 453 */           throw new NullPointerException("iterator returned a null value");
/*     */         } 
/* 455 */         return c;
/*     */       } 
/* 457 */       onCloseWithDropError();
/* 458 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 463 */       if (this.state == 2) {
/* 464 */         return 0;
/*     */       }
/* 466 */       return 1;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class IterableSubscriptionConditional<T>
/*     */     implements InnerProducer<T>, Fuseable.SynchronousSubscription<T>
/*     */   {
/*     */     final Fuseable.ConditionalSubscriber<? super T> actual;
/*     */     
/*     */     final Iterator<? extends T> iterator;
/*     */     
/*     */     final boolean knownToBeFinite;
/*     */     
/*     */     final Runnable onClose;
/*     */     
/*     */     volatile boolean cancelled;
/*     */     volatile long requested;
/* 484 */     static final AtomicLongFieldUpdater<IterableSubscriptionConditional> REQUESTED = AtomicLongFieldUpdater.newUpdater(IterableSubscriptionConditional.class, "requested");
/*     */ 
/*     */ 
/*     */     
/*     */     int state;
/*     */ 
/*     */ 
/*     */     
/*     */     static final int STATE_HAS_NEXT_NO_VALUE = 0;
/*     */ 
/*     */ 
/*     */     
/*     */     static final int STATE_HAS_NEXT_HAS_VALUE = 1;
/*     */ 
/*     */     
/*     */     static final int STATE_NO_NEXT = 2;
/*     */ 
/*     */     
/*     */     static final int STATE_CALL_HAS_NEXT = 3;
/*     */ 
/*     */     
/*     */     T current;
/*     */ 
/*     */     
/*     */     Throwable hasNextFailure;
/*     */ 
/*     */ 
/*     */     
/*     */     IterableSubscriptionConditional(Fuseable.ConditionalSubscriber<? super T> actual, Iterator<? extends T> iterator, boolean knownToBeFinite, @Nullable Runnable onClose) {
/* 513 */       this.actual = actual;
/* 514 */       this.iterator = iterator;
/* 515 */       this.knownToBeFinite = knownToBeFinite;
/* 516 */       this.onClose = onClose;
/*     */     }
/*     */ 
/*     */     
/*     */     IterableSubscriptionConditional(Fuseable.ConditionalSubscriber<? super T> actual, Iterator<? extends T> iterator, boolean knownToBeFinite) {
/* 521 */       this(actual, iterator, knownToBeFinite, null);
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 526 */       if (Operators.validate(n) && 
/* 527 */         Operators.addCap(REQUESTED, this, n) == 0L) {
/* 528 */         if (n == Long.MAX_VALUE) {
/* 529 */           fastPath();
/*     */         } else {
/*     */           
/* 532 */           slowPath(n);
/*     */         } 
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     private void onCloseWithDropError() {
/* 539 */       if (this.onClose != null) {
/*     */         try {
/* 541 */           this.onClose.run();
/*     */         }
/* 543 */         catch (Throwable t) {
/* 544 */           Operators.onErrorDropped(t, this.actual.currentContext());
/*     */         } 
/*     */       }
/*     */     }
/*     */     
/*     */     void slowPath(long n) {
/* 550 */       Iterator<? extends T> a = this.iterator;
/* 551 */       Fuseable.ConditionalSubscriber<? super T> s = this.actual;
/*     */       
/* 553 */       long e = 0L;
/*     */ 
/*     */       
/*     */       while (true) {
/* 557 */         while (e != n) {
/*     */           T t;
/*     */           boolean b;
/*     */           try {
/* 561 */             t = Objects.requireNonNull(a.next(), "The iterator returned a null value");
/*     */           
/*     */           }
/* 564 */           catch (Throwable ex) {
/* 565 */             s.onError(ex);
/* 566 */             onCloseWithDropError();
/*     */             
/*     */             return;
/*     */           } 
/* 570 */           if (this.cancelled) {
/*     */             return;
/*     */           }
/*     */           
/* 574 */           boolean consumed = s.tryOnNext(t);
/*     */           
/* 576 */           if (this.cancelled) {
/*     */             return;
/*     */           }
/*     */ 
/*     */ 
/*     */           
/*     */           try {
/* 583 */             b = a.hasNext();
/*     */           }
/* 585 */           catch (Throwable ex) {
/* 586 */             s.onError(ex);
/* 587 */             onCloseWithDropError();
/*     */             
/*     */             return;
/*     */           } 
/* 591 */           if (this.cancelled) {
/*     */             return;
/*     */           }
/*     */           
/* 595 */           if (!b) {
/* 596 */             s.onComplete();
/* 597 */             onCloseWithDropError();
/*     */             
/*     */             return;
/*     */           } 
/* 601 */           if (consumed) {
/* 602 */             e++;
/*     */           }
/*     */         } 
/*     */         
/* 606 */         n = this.requested;
/*     */         
/* 608 */         if (n == e) {
/* 609 */           n = REQUESTED.addAndGet(this, -e);
/* 610 */           if (n == 0L) {
/*     */             return;
/*     */           }
/* 613 */           e = 0L;
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     void fastPath() {
/* 619 */       Iterator<? extends T> a = this.iterator;
/* 620 */       Fuseable.ConditionalSubscriber<? super T> s = this.actual;
/*     */       while (true) {
/*     */         T t;
/*     */         boolean b;
/* 624 */         if (this.cancelled) {
/*     */           return;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         try {
/* 631 */           t = Objects.requireNonNull(a.next(), "The iterator returned a null value");
/*     */         
/*     */         }
/* 634 */         catch (Exception ex) {
/* 635 */           s.onError(ex);
/* 636 */           onCloseWithDropError();
/*     */           
/*     */           return;
/*     */         } 
/* 640 */         if (this.cancelled) {
/*     */           return;
/*     */         }
/*     */         
/* 644 */         s.tryOnNext(t);
/*     */         
/* 646 */         if (this.cancelled) {
/*     */           return;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         try {
/* 653 */           b = a.hasNext();
/*     */         }
/* 655 */         catch (Exception ex) {
/* 656 */           s.onError(ex);
/* 657 */           onCloseWithDropError();
/*     */           
/*     */           return;
/*     */         } 
/* 661 */         if (this.cancelled) {
/*     */           return;
/*     */         }
/*     */         
/* 665 */         if (!b) {
/* 666 */           s.onComplete();
/* 667 */           onCloseWithDropError();
/*     */           return;
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 675 */       onCloseWithDropError();
/* 676 */       this.cancelled = true;
/* 677 */       Operators.onDiscardMultiple(this.iterator, this.knownToBeFinite, this.actual.currentContext());
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 682 */       return (CoreSubscriber<? super T>)this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 688 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(this.cancelled); 
/* 689 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf(this.requested); 
/* 690 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf((this.state == 2)); 
/* 691 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 693 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public void clear() {
/* 698 */       Operators.onDiscardMultiple(this.iterator, this.knownToBeFinite, this.actual.currentContext());
/* 699 */       this.state = 2;
/*     */     }
/*     */     
/*     */     public boolean isEmpty() {
/*     */       boolean hasNext;
/* 704 */       int s = this.state;
/* 705 */       if (s == 2) {
/* 706 */         return true;
/*     */       }
/* 708 */       if (this.cancelled && !this.knownToBeFinite) {
/* 709 */         return true;
/*     */       }
/* 711 */       if (s == 1 || s == 0) {
/* 712 */         return false;
/*     */       }
/*     */ 
/*     */       
/*     */       try {
/* 717 */         hasNext = this.iterator.hasNext();
/*     */       }
/* 719 */       catch (Throwable t) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 724 */         this.state = 0;
/* 725 */         this.hasNextFailure = t;
/* 726 */         return false;
/*     */       } 
/*     */       
/* 729 */       if (hasNext) {
/* 730 */         this.state = 0;
/* 731 */         return false;
/*     */       } 
/* 733 */       this.state = 2;
/* 734 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public T poll() {
/* 741 */       if (this.hasNextFailure != null) {
/* 742 */         this.state = 2;
/* 743 */         throw Exceptions.propagate(this.hasNextFailure);
/*     */       } 
/* 745 */       if (!isEmpty()) {
/*     */         T c;
/* 747 */         if (this.state == 0) {
/* 748 */           c = this.iterator.next();
/*     */         } else {
/*     */           
/* 751 */           c = this.current;
/* 752 */           this.current = null;
/*     */         } 
/* 754 */         this.state = 3;
/* 755 */         return c;
/*     */       } 
/* 757 */       onCloseWithDropError();
/* 758 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 763 */       if (this.state == 2) {
/* 764 */         return 0;
/*     */       }
/* 766 */       return 1;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\FluxIterable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */