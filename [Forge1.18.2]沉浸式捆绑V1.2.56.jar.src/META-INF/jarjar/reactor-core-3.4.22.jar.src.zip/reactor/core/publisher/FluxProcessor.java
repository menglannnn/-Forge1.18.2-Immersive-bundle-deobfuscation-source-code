/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.CancellationException;
/*     */ import java.util.stream.Stream;
/*     */ import org.reactivestreams.Processor;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public abstract class FluxProcessor<IN, OUT>
/*     */   extends Flux<OUT>
/*     */   implements Processor<IN, OUT>, CoreSubscriber<IN>, Scannable, Disposable, ContextHolder
/*     */ {
/*     */   @Deprecated
/*     */   public static <T> FluxProcessor<Publisher<? extends T>, T> switchOnNext() {
/*  65 */     UnicastProcessor<Publisher<? extends T>> emitter = UnicastProcessor.create();
/*  66 */     FluxProcessor<Publisher<? extends T>, T> p = wrap((Subscriber<Publisher<? extends T>>)emitter, (Publisher<T>)switchOnNext((Publisher<? extends Publisher<? extends OUT>>)emitter));
/*  67 */     return p;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <IN, OUT> FluxProcessor<IN, OUT> wrap(Subscriber<IN> upstream, Publisher<OUT> downstream) {
/*  82 */     return new DelegateProcessor<>(downstream, upstream);
/*     */   }
/*     */ 
/*     */   
/*     */   public void dispose() {
/*  87 */     onError(new CancellationException("Disposed"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long downstreamCount() {
/*  96 */     return inners().count();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getBufferSize() {
/* 105 */     return Integer.MAX_VALUE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Throwable getError() {
/* 115 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasDownstreams() {
/* 124 */     return (downstreamCount() != 0L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean hasCompleted() {
/* 133 */     return (isTerminated() && getError() == null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean hasError() {
/* 142 */     return (isTerminated() && getError() != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public Stream<? extends Scannable> inners() {
/* 147 */     return Stream.empty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isTerminated() {
/* 156 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSerialized() {
/* 165 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/* 171 */     if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(isTerminated()); 
/* 172 */     if (key == Scannable.Attr.ERROR) return getError(); 
/* 173 */     if (key == Scannable.Attr.CAPACITY) return Integer.valueOf(getBufferSize());
/*     */     
/* 175 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Context currentContext() {
/* 180 */     return Context.empty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final FluxProcessor<IN, OUT> serialize() {
/* 193 */     return new DelegateProcessor<>((Publisher)this, (Subscriber<IN>)Operators.serialize(this));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public final FluxSink<IN> sink() {
/* 216 */     return sink(FluxSink.OverflowStrategy.IGNORE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public final FluxSink<IN> sink(FluxSink.OverflowStrategy strategy) {
/* 243 */     Objects.requireNonNull(strategy, "strategy");
/* 244 */     if (getBufferSize() == Integer.MAX_VALUE) {
/* 245 */       strategy = FluxSink.OverflowStrategy.IGNORE;
/*     */     }
/*     */     
/* 248 */     FluxCreate.BaseSink<IN> s = FluxCreate.createSink(this, strategy);
/* 249 */     onSubscribe(s);
/*     */     
/* 251 */     if (s.isCancelled() || (
/* 252 */       isSerialized() && getBufferSize() == Integer.MAX_VALUE)) {
/* 253 */       return s;
/*     */     }
/* 255 */     if (serializeAlways()) {
/* 256 */       return new FluxCreate.SerializedFluxSink<>(s);
/*     */     }
/* 258 */     return new FluxCreate.SerializeOnRequestSink<>(s);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean serializeAlways() {
/* 268 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isIdentityProcessor() {
/* 277 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\FluxProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */