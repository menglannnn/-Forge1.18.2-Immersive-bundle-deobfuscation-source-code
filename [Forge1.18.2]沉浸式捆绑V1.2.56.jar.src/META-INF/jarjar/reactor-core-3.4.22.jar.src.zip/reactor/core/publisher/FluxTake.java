/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxTake<T>
/*     */   extends InternalFluxOperator<T, T>
/*     */ {
/*     */   final long n;
/*     */   
/*     */   FluxTake(Flux<? extends T> source, long n) {
/*  42 */     super(source);
/*  43 */     if (n < 0L) {
/*  44 */       throw new IllegalArgumentException("n >= 0 required but it was " + n);
/*     */     }
/*  46 */     this.n = n;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/*  52 */     if (actual instanceof Fuseable.ConditionalSubscriber) {
/*  53 */       return new TakeConditionalSubscriber<>((Fuseable.ConditionalSubscriber<? super T>)actual, this.n);
/*     */     }
/*     */     
/*  56 */     return new TakeSubscriber<>(actual, this.n);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPrefetch() {
/*  62 */     return Integer.MAX_VALUE;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  67 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  68 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class TakeSubscriber<T>
/*     */     implements InnerOperator<T, T>
/*     */   {
/*     */     final CoreSubscriber<? super T> actual;
/*     */     
/*     */     final long n;
/*     */     
/*     */     long remaining;
/*     */     
/*     */     Subscription s;
/*     */     
/*     */     boolean done;
/*     */     
/*     */     volatile int wip;
/*     */     
/*  87 */     static final AtomicIntegerFieldUpdater<TakeSubscriber> WIP = AtomicIntegerFieldUpdater.newUpdater(TakeSubscriber.class, "wip");
/*     */     
/*     */     public TakeSubscriber(CoreSubscriber<? super T> actual, long n) {
/*  90 */       this.actual = actual;
/*  91 */       this.n = n;
/*  92 */       this.remaining = n;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/*  97 */       if (Operators.validate(this.s, s)) {
/*  98 */         if (this.n == 0L) {
/*  99 */           s.cancel();
/* 100 */           this.done = true;
/* 101 */           Operators.complete((Subscriber<?>)this.actual);
/*     */         } else {
/*     */           
/* 104 */           this.s = s;
/* 105 */           this.actual.onSubscribe(this);
/*     */         } 
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 112 */       if (this.done) {
/* 113 */         Operators.onNextDropped(t, this.actual.currentContext());
/*     */         
/*     */         return;
/*     */       } 
/* 117 */       long r = this.remaining;
/*     */       
/* 119 */       if (r == 0L) {
/* 120 */         this.s.cancel();
/* 121 */         onComplete();
/*     */         
/*     */         return;
/*     */       } 
/* 125 */       this.remaining = --r;
/* 126 */       boolean stop = (r == 0L);
/*     */       
/* 128 */       this.actual.onNext(t);
/*     */       
/* 130 */       if (stop) {
/* 131 */         this.s.cancel();
/*     */         
/* 133 */         onComplete();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 139 */       if (this.done) {
/* 140 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*     */         return;
/*     */       } 
/* 143 */       this.done = true;
/* 144 */       this.actual.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 149 */       if (this.done) {
/*     */         return;
/*     */       }
/* 152 */       this.done = true;
/* 153 */       this.actual.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 158 */       if (this.wip == 0 && WIP.compareAndSet(this, 0, 1)) {
/* 159 */         if (n >= this.n) {
/* 160 */           this.s.request(Long.MAX_VALUE);
/*     */         } else {
/* 162 */           this.s.request(n);
/*     */         } 
/*     */         
/*     */         return;
/*     */       } 
/* 167 */       this.s.request(n);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 172 */       this.s.cancel();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 178 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 179 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 180 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 182 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 187 */       return this.actual;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class TakeConditionalSubscriber<T>
/*     */     implements Fuseable.ConditionalSubscriber<T>, InnerOperator<T, T>
/*     */   {
/*     */     final Fuseable.ConditionalSubscriber<? super T> actual;
/*     */     
/*     */     final long n;
/*     */     
/*     */     long remaining;
/*     */     
/*     */     Subscription s;
/*     */     
/*     */     boolean done;
/*     */     
/*     */     volatile int wip;
/*     */     
/* 207 */     static final AtomicIntegerFieldUpdater<TakeConditionalSubscriber> WIP = AtomicIntegerFieldUpdater.newUpdater(TakeConditionalSubscriber.class, "wip");
/*     */ 
/*     */ 
/*     */     
/*     */     TakeConditionalSubscriber(Fuseable.ConditionalSubscriber<? super T> actual, long n) {
/* 212 */       this.actual = actual;
/* 213 */       this.n = n;
/* 214 */       this.remaining = n;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 219 */       if (Operators.validate(this.s, s)) {
/* 220 */         if (this.n == 0L) {
/* 221 */           s.cancel();
/* 222 */           this.done = true;
/* 223 */           Operators.complete((Subscriber<?>)this.actual);
/*     */         } else {
/*     */           
/* 226 */           this.s = s;
/* 227 */           this.actual.onSubscribe(this);
/*     */         } 
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 234 */       if (this.done) {
/* 235 */         Operators.onNextDropped(t, this.actual.currentContext());
/*     */         
/*     */         return;
/*     */       } 
/* 239 */       long r = this.remaining;
/*     */       
/* 241 */       if (r == 0L) {
/* 242 */         this.s.cancel();
/* 243 */         onComplete();
/*     */         
/*     */         return;
/*     */       } 
/* 247 */       this.remaining = --r;
/* 248 */       boolean stop = (r == 0L);
/*     */       
/* 250 */       this.actual.onNext(t);
/*     */       
/* 252 */       if (stop) {
/* 253 */         this.s.cancel();
/*     */         
/* 255 */         onComplete();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean tryOnNext(T t) {
/* 261 */       if (this.done) {
/* 262 */         Operators.onNextDropped(t, this.actual.currentContext());
/* 263 */         return true;
/*     */       } 
/*     */       
/* 266 */       long r = this.remaining;
/*     */       
/* 268 */       if (r == 0L) {
/* 269 */         this.s.cancel();
/* 270 */         onComplete();
/* 271 */         return true;
/*     */       } 
/*     */       
/* 274 */       this.remaining = --r;
/* 275 */       boolean stop = (r == 0L);
/*     */       
/* 277 */       boolean b = this.actual.tryOnNext(t);
/*     */       
/* 279 */       if (stop) {
/* 280 */         this.s.cancel();
/*     */         
/* 282 */         onComplete();
/*     */       } 
/* 284 */       return b;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 289 */       if (this.done) {
/* 290 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*     */         return;
/*     */       } 
/* 293 */       this.done = true;
/* 294 */       this.actual.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 299 */       if (this.done) {
/*     */         return;
/*     */       }
/* 302 */       this.done = true;
/* 303 */       this.actual.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 308 */       if (this.wip == 0 && WIP.compareAndSet(this, 0, 1)) {
/* 309 */         if (n >= this.n) {
/* 310 */           this.s.request(Long.MAX_VALUE);
/*     */         } else {
/*     */           
/* 313 */           this.s.request(n);
/*     */         } 
/*     */         
/*     */         return;
/*     */       } 
/* 318 */       this.s.request(n);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 323 */       this.s.cancel();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 329 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 330 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 331 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 333 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 338 */       return (CoreSubscriber<? super T>)this.actual;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class TakeFuseableSubscriber<T>
/*     */     implements Fuseable.QueueSubscription<T>, InnerOperator<T, T>
/*     */   {
/*     */     final CoreSubscriber<? super T> actual;
/*     */     
/*     */     final long n;
/*     */     
/*     */     long remaining;
/*     */     
/*     */     Fuseable.QueueSubscription<T> qs;
/*     */     
/*     */     boolean done;
/*     */     
/*     */     volatile int wip;
/*     */     
/* 358 */     static final AtomicIntegerFieldUpdater<TakeFuseableSubscriber> WIP = AtomicIntegerFieldUpdater.newUpdater(TakeFuseableSubscriber.class, "wip");
/*     */     
/*     */     int inputMode;
/*     */     
/*     */     TakeFuseableSubscriber(CoreSubscriber<? super T> actual, long n) {
/* 363 */       this.actual = actual;
/* 364 */       this.n = n;
/* 365 */       this.remaining = n;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 371 */       if (Operators.validate((Subscription)this.qs, s)) {
/* 372 */         if (this.n == 0L) {
/* 373 */           s.cancel();
/* 374 */           this.done = true;
/* 375 */           Operators.complete((Subscriber<?>)this.actual);
/*     */         } else {
/*     */           
/* 378 */           this.qs = (Fuseable.QueueSubscription<T>)s;
/* 379 */           this.actual.onSubscribe(this);
/*     */         } 
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 387 */       if (this.inputMode == 2) {
/* 388 */         this.actual.onNext(null);
/*     */         return;
/*     */       } 
/* 391 */       if (this.done) {
/* 392 */         Operators.onNextDropped(t, this.actual.currentContext());
/*     */         
/*     */         return;
/*     */       } 
/* 396 */       long r = this.remaining;
/*     */       
/* 398 */       if (r == 0L) {
/* 399 */         this.qs.cancel();
/* 400 */         onComplete();
/*     */         
/*     */         return;
/*     */       } 
/* 404 */       this.remaining = --r;
/* 405 */       boolean stop = (r == 0L);
/*     */       
/* 407 */       this.actual.onNext(t);
/*     */       
/* 409 */       if (stop) {
/* 410 */         this.qs.cancel();
/*     */         
/* 412 */         onComplete();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 418 */       if (this.done) {
/* 419 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*     */         return;
/*     */       } 
/* 422 */       this.done = true;
/* 423 */       this.actual.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 428 */       if (this.done) {
/*     */         return;
/*     */       }
/* 431 */       this.done = true;
/* 432 */       this.actual.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 437 */       if (this.wip == 0 && WIP.compareAndSet(this, 0, 1)) {
/* 438 */         if (n >= this.n) {
/* 439 */           this.qs.request(Long.MAX_VALUE);
/*     */         } else {
/*     */           
/* 442 */           this.qs.request(n);
/*     */         } 
/*     */         
/*     */         return;
/*     */       } 
/* 447 */       this.qs.request(n);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 452 */       this.qs.cancel();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 458 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 459 */       if (key == Scannable.Attr.PARENT) return this.qs; 
/* 460 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 462 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 467 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public int requestFusion(int requestedMode) {
/* 472 */       int m = this.qs.requestFusion(requestedMode);
/* 473 */       this.inputMode = m;
/* 474 */       return m;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public T poll() {
/* 480 */       if (this.done) {
/* 481 */         return null;
/*     */       }
/* 483 */       long r = this.remaining;
/* 484 */       T v = (T)this.qs.poll();
/* 485 */       if (r == 0L) {
/* 486 */         this.done = true;
/* 487 */         if (this.inputMode == 2) {
/* 488 */           this.qs.cancel();
/* 489 */           this.actual.onComplete();
/*     */         } 
/* 491 */         return null;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 496 */       this.remaining = --r;
/* 497 */       if (v != null && r == 0L && 
/* 498 */         !this.done) {
/* 499 */         this.done = true;
/* 500 */         if (this.inputMode == 2) {
/* 501 */           this.qs.cancel();
/* 502 */           this.actual.onComplete();
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 508 */       return v;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isEmpty() {
/* 513 */       return (this.remaining == 0L || this.qs.isEmpty());
/*     */     }
/*     */ 
/*     */     
/*     */     public void clear() {
/* 518 */       this.qs.clear();
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 523 */       return this.qs.size();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\FluxTake.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */