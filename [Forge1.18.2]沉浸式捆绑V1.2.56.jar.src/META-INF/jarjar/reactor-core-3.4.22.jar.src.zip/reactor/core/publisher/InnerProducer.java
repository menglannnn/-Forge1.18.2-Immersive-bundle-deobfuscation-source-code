/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import org.reactivestreams.Subscription;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Scannable;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ interface InnerProducer<O>
/*    */   extends Scannable, Subscription
/*    */ {
/*    */   CoreSubscriber<? super O> actual();
/*    */   
/*    */   @Nullable
/*    */   default Object scanUnsafe(Scannable.Attr key) {
/* 43 */     if (key == Scannable.Attr.ACTUAL) {
/* 44 */       return actual();
/*    */     }
/* 46 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\InnerProducer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */