package reactor.core.publisher;

class QueueDrainSubscriberPad0 {
  volatile long p1;
  
  volatile long p2;
  
  volatile long p3;
  
  volatile long p4;
  
  volatile long p5;
  
  volatile long p6;
  
  volatile long p7;
  
  volatile long p8;
  
  volatile long p9;
  
  volatile long p10;
  
  volatile long p11;
  
  volatile long p12;
  
  volatile long p13;
  
  volatile long p14;
  
  volatile long p15;
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\QueueDrainSubscriberPad0.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */