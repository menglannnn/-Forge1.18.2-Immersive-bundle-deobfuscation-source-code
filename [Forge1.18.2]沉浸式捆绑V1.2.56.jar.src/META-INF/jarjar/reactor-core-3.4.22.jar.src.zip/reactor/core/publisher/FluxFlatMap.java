/*      */ package reactor.core.publisher;
/*      */ 
/*      */ import java.util.Objects;
/*      */ import java.util.Queue;
/*      */ import java.util.concurrent.Callable;
/*      */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*      */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*      */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*      */ import java.util.function.Function;
/*      */ import java.util.function.Supplier;
/*      */ import java.util.stream.Stream;
/*      */ import org.reactivestreams.Publisher;
/*      */ import org.reactivestreams.Subscriber;
/*      */ import org.reactivestreams.Subscription;
/*      */ import reactor.core.CoreSubscriber;
/*      */ import reactor.core.Exceptions;
/*      */ import reactor.core.Fuseable;
/*      */ import reactor.core.Scannable;
/*      */ import reactor.util.annotation.Nullable;
/*      */ import reactor.util.context.Context;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ final class FluxFlatMap<T, R>
/*      */   extends InternalFluxOperator<T, R>
/*      */ {
/*      */   final Function<? super T, ? extends Publisher<? extends R>> mapper;
/*      */   final boolean delayError;
/*      */   final int maxConcurrency;
/*      */   final Supplier<? extends Queue<R>> mainQueueSupplier;
/*      */   final int prefetch;
/*      */   final Supplier<? extends Queue<R>> innerQueueSupplier;
/*      */   
/*      */   FluxFlatMap(Flux<? extends T> source, Function<? super T, ? extends Publisher<? extends R>> mapper, boolean delayError, int maxConcurrency, Supplier<? extends Queue<R>> mainQueueSupplier, int prefetch, Supplier<? extends Queue<R>> innerQueueSupplier) {
/*   69 */     super(source);
/*   70 */     if (prefetch <= 0) {
/*   71 */       throw new IllegalArgumentException("prefetch > 0 required but it was " + prefetch);
/*      */     }
/*   73 */     if (maxConcurrency <= 0) {
/*   74 */       throw new IllegalArgumentException("maxConcurrency > 0 required but it was " + maxConcurrency);
/*      */     }
/*   76 */     this.mapper = Objects.<Function<? super T, ? extends Publisher<? extends R>>>requireNonNull(mapper, "mapper");
/*   77 */     this.delayError = delayError;
/*   78 */     this.prefetch = prefetch;
/*   79 */     this.maxConcurrency = maxConcurrency;
/*   80 */     this
/*   81 */       .mainQueueSupplier = Objects.<Supplier<? extends Queue<R>>>requireNonNull(mainQueueSupplier, "mainQueueSupplier");
/*   82 */     this
/*   83 */       .innerQueueSupplier = Objects.<Supplier<? extends Queue<R>>>requireNonNull(innerQueueSupplier, "innerQueueSupplier");
/*      */   }
/*      */ 
/*      */   
/*      */   public int getPrefetch() {
/*   88 */     return this.prefetch;
/*      */   }
/*      */ 
/*      */   
/*      */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super R> actual) {
/*   93 */     if (trySubscribeScalarMap((Publisher<? extends T>)this.source, actual, this.mapper, false, true)) {
/*   94 */       return null;
/*      */     }
/*      */     
/*   97 */     return new FlatMapMain<>(actual, this.mapper, this.delayError, this.maxConcurrency, this.mainQueueSupplier, this.prefetch, this.innerQueueSupplier);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static <T, R> boolean trySubscribeScalarMap(Publisher<? extends T> source, CoreSubscriber<? super R> s, Function<? super T, ? extends Publisher<? extends R>> mapper, boolean fuseableExpected, boolean errorContinueExpected) {
/*  123 */     if (source instanceof Callable) {
/*      */       T t;
/*      */       Publisher<? extends R> p;
/*      */       try {
/*  127 */         t = ((Callable)source).call();
/*      */       }
/*  129 */       catch (Throwable e) {
/*  130 */         Context ctx = s.currentContext();
/*      */ 
/*      */         
/*  133 */         Throwable e_ = errorContinueExpected ? Operators.onNextError(null, e, ctx) : Operators.onOperatorError(e, ctx);
/*  134 */         if (e_ != null) {
/*  135 */           Operators.error((Subscriber<?>)s, e_);
/*      */         }
/*      */         else {
/*      */           
/*  139 */           Operators.complete((Subscriber<?>)s);
/*      */         } 
/*  141 */         return true;
/*      */       } 
/*      */       
/*  144 */       if (t == null) {
/*  145 */         Operators.complete((Subscriber<?>)s);
/*  146 */         return true;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/*  152 */         p = Objects.<Publisher<? extends R>>requireNonNull(mapper.apply(t), "The mapper returned a null Publisher");
/*      */       
/*      */       }
/*  155 */       catch (Throwable e) {
/*  156 */         Context ctx = s.currentContext();
/*      */ 
/*      */         
/*  159 */         Throwable e_ = errorContinueExpected ? Operators.<T>onNextError(t, e, ctx) : Operators.onOperatorError(null, e, t, ctx);
/*  160 */         if (e_ != null) {
/*  161 */           Operators.error((Subscriber<?>)s, e_);
/*      */         }
/*      */         else {
/*      */           
/*  165 */           Operators.complete((Subscriber<?>)s);
/*      */         } 
/*  167 */         return true;
/*      */       } 
/*      */       
/*  170 */       if (p instanceof Callable) {
/*      */         R v;
/*      */         
/*      */         try {
/*  174 */           v = ((Callable)p).call();
/*      */         }
/*  176 */         catch (Throwable e) {
/*  177 */           Context ctx = s.currentContext();
/*      */ 
/*      */           
/*  180 */           Throwable e_ = errorContinueExpected ? Operators.<T>onNextError(t, e, ctx) : Operators.onOperatorError(null, e, t, ctx);
/*  181 */           if (e_ != null) {
/*  182 */             Operators.error((Subscriber<?>)s, e_);
/*      */           }
/*      */           else {
/*      */             
/*  186 */             Operators.complete((Subscriber<?>)s);
/*      */           } 
/*  188 */           return true;
/*      */         } 
/*      */         
/*  191 */         if (v != null) {
/*  192 */           s.onSubscribe(Operators.scalarSubscription(s, v));
/*      */         } else {
/*      */           
/*  195 */           Operators.complete((Subscriber<?>)s);
/*      */         }
/*      */       
/*      */       }
/*  199 */       else if (!fuseableExpected || p instanceof Fuseable) {
/*  200 */         p.subscribe((Subscriber)s);
/*      */       } else {
/*      */         
/*  203 */         p.subscribe((Subscriber)new FluxHide.SuppressFuseableSubscriber<>(s));
/*      */       } 
/*      */ 
/*      */       
/*  207 */       return true;
/*      */     } 
/*      */     
/*  210 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public Object scanUnsafe(Scannable.Attr key) {
/*  215 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  216 */     return super.scanUnsafe(key);
/*      */   }
/*      */ 
/*      */   
/*      */   static final class FlatMapMain<T, R>
/*      */     extends FlatMapTracker<FlatMapInner<R>>
/*      */     implements InnerOperator<T, R>
/*      */   {
/*      */     final boolean delayError;
/*      */     
/*      */     final int maxConcurrency;
/*      */     
/*      */     final int prefetch;
/*      */     final int limit;
/*      */     final Function<? super T, ? extends Publisher<? extends R>> mapper;
/*      */     final Supplier<? extends Queue<R>> mainQueueSupplier;
/*      */     final Supplier<? extends Queue<R>> innerQueueSupplier;
/*      */     final CoreSubscriber<? super R> actual;
/*      */     volatile Queue<R> scalarQueue;
/*      */     volatile Throwable error;
/*  236 */     static final AtomicReferenceFieldUpdater<FlatMapMain, Throwable> ERROR = AtomicReferenceFieldUpdater.newUpdater(FlatMapMain.class, Throwable.class, "error");
/*      */ 
/*      */     
/*      */     volatile boolean done;
/*      */ 
/*      */     
/*      */     volatile boolean cancelled;
/*      */ 
/*      */     
/*      */     Subscription s;
/*      */     
/*      */     volatile long requested;
/*      */     
/*  249 */     static final AtomicLongFieldUpdater<FlatMapMain> REQUESTED = AtomicLongFieldUpdater.newUpdater(FlatMapMain.class, "requested");
/*      */ 
/*      */     
/*      */     volatile int wip;
/*      */     
/*  254 */     static final AtomicIntegerFieldUpdater<FlatMapMain> WIP = AtomicIntegerFieldUpdater.newUpdater(FlatMapMain.class, "wip");
/*      */ 
/*      */     
/*  257 */     static final FluxFlatMap.FlatMapInner[] EMPTY = new FluxFlatMap.FlatMapInner[0];
/*      */ 
/*      */     
/*  260 */     static final FluxFlatMap.FlatMapInner[] TERMINATED = new FluxFlatMap.FlatMapInner[0];
/*      */ 
/*      */ 
/*      */     
/*      */     int lastIndex;
/*      */ 
/*      */ 
/*      */     
/*      */     int produced;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     FlatMapMain(CoreSubscriber<? super R> actual, Function<? super T, ? extends Publisher<? extends R>> mapper, boolean delayError, int maxConcurrency, Supplier<? extends Queue<R>> mainQueueSupplier, int prefetch, Supplier<? extends Queue<R>> innerQueueSupplier) {
/*  274 */       this.actual = actual;
/*  275 */       this.mapper = mapper;
/*  276 */       this.delayError = delayError;
/*  277 */       this.maxConcurrency = maxConcurrency;
/*  278 */       this.mainQueueSupplier = mainQueueSupplier;
/*  279 */       this.prefetch = prefetch;
/*  280 */       this.innerQueueSupplier = innerQueueSupplier;
/*  281 */       this.limit = Operators.unboundedOrLimit(maxConcurrency);
/*      */     }
/*      */ 
/*      */     
/*      */     public final CoreSubscriber<? super R> actual() {
/*  286 */       return this.actual;
/*      */     }
/*      */ 
/*      */     
/*      */     public Stream<? extends Scannable> inners() {
/*  291 */       return Stream.<Scannable>of((Scannable[])this.array).filter(Objects::nonNull);
/*      */     }
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     public Object scanUnsafe(Scannable.Attr key) {
/*  297 */       if (key == Scannable.Attr.PARENT) return this.s; 
/*  298 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(this.cancelled); 
/*  299 */       if (key == Scannable.Attr.ERROR) return this.error; 
/*  300 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf((this.done && (this.scalarQueue == null || this.scalarQueue.isEmpty()))); 
/*  301 */       if (key == Scannable.Attr.DELAY_ERROR) return Boolean.valueOf(this.delayError); 
/*  302 */       if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(this.maxConcurrency); 
/*  303 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf(this.requested); 
/*  304 */       if (key == Scannable.Attr.LARGE_BUFFERED) return Long.valueOf(((this.scalarQueue != null) ? this.scalarQueue.size() : 0L) + this.size); 
/*  305 */       if (key == Scannable.Attr.BUFFERED) {
/*  306 */         long realBuffered = ((this.scalarQueue != null) ? this.scalarQueue.size() : 0L) + this.size;
/*  307 */         if (realBuffered <= 2147483647L) return Integer.valueOf((int)realBuffered); 
/*  308 */         return Integer.valueOf(-2147483648);
/*      */       } 
/*  310 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*      */       
/*  312 */       return super.scanUnsafe(key);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     FluxFlatMap.FlatMapInner<R>[] empty() {
/*  318 */       return (FluxFlatMap.FlatMapInner<R>[])EMPTY;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     FluxFlatMap.FlatMapInner<R>[] terminated() {
/*  324 */       return (FluxFlatMap.FlatMapInner<R>[])TERMINATED;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     FluxFlatMap.FlatMapInner<R>[] newArray(int size) {
/*  330 */       return (FluxFlatMap.FlatMapInner<R>[])new FluxFlatMap.FlatMapInner[size];
/*      */     }
/*      */ 
/*      */     
/*      */     void setIndex(FluxFlatMap.FlatMapInner<R> entry, int index) {
/*  335 */       entry.index = index;
/*      */     }
/*      */ 
/*      */     
/*      */     void unsubscribeEntry(FluxFlatMap.FlatMapInner<R> entry) {
/*  340 */       entry.cancel();
/*      */     }
/*      */ 
/*      */     
/*      */     public void request(long n) {
/*  345 */       if (Operators.validate(n)) {
/*  346 */         Operators.addCap(REQUESTED, this, n);
/*  347 */         drain((R)null);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void cancel() {
/*  353 */       if (!this.cancelled) {
/*  354 */         this.cancelled = true;
/*      */         
/*  356 */         if (WIP.getAndIncrement(this) == 0) {
/*  357 */           Operators.onDiscardQueueWithClear(this.scalarQueue, this.actual.currentContext(), null);
/*  358 */           this.scalarQueue = null;
/*  359 */           this.s.cancel();
/*  360 */           unsubscribe();
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void onSubscribe(Subscription s) {
/*  367 */       if (Operators.validate(this.s, s)) {
/*  368 */         this.s = s;
/*      */         
/*  370 */         this.actual.onSubscribe(this);
/*  371 */         s.request(Operators.unboundedOrPrefetch(this.maxConcurrency));
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void onNext(T t) {
/*      */       Publisher<? extends R> p;
/*  378 */       if (this.done) {
/*  379 */         Operators.onNextDropped(t, this.actual.currentContext());
/*      */ 
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/*      */       try {
/*  386 */         p = Objects.<Publisher<? extends R>>requireNonNull(this.mapper.apply(t), "The mapper returned a null Publisher");
/*      */       
/*      */       }
/*  389 */       catch (Throwable e) {
/*  390 */         Context ctx = this.actual.currentContext();
/*  391 */         Throwable e_ = Operators.onNextError(t, e, ctx, this.s);
/*  392 */         Operators.onDiscard(t, ctx);
/*  393 */         if (e_ != null) {
/*  394 */           onError(e_);
/*      */         } else {
/*      */           
/*  397 */           tryEmitScalar((R)null);
/*      */         } 
/*      */         
/*      */         return;
/*      */       } 
/*  402 */       if (p instanceof Callable) {
/*      */         R v;
/*      */         try {
/*  405 */           v = ((Callable)p).call();
/*      */         }
/*  407 */         catch (Throwable e) {
/*  408 */           Context ctx = this.actual.currentContext();
/*      */           
/*  410 */           Throwable e_ = Operators.onNextError(t, e, ctx);
/*  411 */           if (e_ == null) {
/*  412 */             tryEmitScalar((R)null);
/*      */           }
/*  414 */           else if (!this.delayError || !Exceptions.addThrowable(ERROR, this, e_)) {
/*      */             
/*  416 */             onError(Operators.onOperatorError(this.s, e_, t, ctx));
/*      */           } 
/*  418 */           Operators.onDiscard(t, ctx);
/*      */           return;
/*      */         } 
/*  421 */         tryEmitScalar(v);
/*      */       } else {
/*      */         
/*  424 */         FluxFlatMap.FlatMapInner<R> inner = new FluxFlatMap.FlatMapInner<>(this, this.prefetch);
/*  425 */         if (add(inner)) {
/*  426 */           p.subscribe((Subscriber)inner);
/*      */         } else {
/*  428 */           Operators.onDiscard(t, this.actual.currentContext());
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     Queue<R> getOrCreateScalarQueue() {
/*  435 */       Queue<R> q = this.scalarQueue;
/*  436 */       if (q == null) {
/*  437 */         q = this.mainQueueSupplier.get();
/*  438 */         this.scalarQueue = q;
/*      */       } 
/*  440 */       return q;
/*      */     }
/*      */ 
/*      */     
/*      */     public void onError(Throwable t) {
/*  445 */       if (this.done) {
/*  446 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*      */         return;
/*      */       } 
/*  449 */       if (Exceptions.addThrowable(ERROR, this, t)) {
/*  450 */         this.done = true;
/*  451 */         drain((R)null);
/*      */       } else {
/*      */         
/*  454 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void onComplete() {
/*  460 */       if (this.done) {
/*      */         return;
/*      */       }
/*      */       
/*  464 */       this.done = true;
/*  465 */       drain((R)null);
/*      */     }
/*      */     
/*      */     void tryEmitScalar(@Nullable R v) {
/*  469 */       if (v == null) {
/*  470 */         if (this.maxConcurrency != Integer.MAX_VALUE) {
/*  471 */           int p = this.produced + 1;
/*  472 */           if (p == this.limit) {
/*  473 */             this.produced = 0;
/*  474 */             this.s.request(p);
/*      */           } else {
/*      */             
/*  477 */             this.produced = p;
/*      */           } 
/*      */         } 
/*      */         
/*      */         return;
/*      */       } 
/*  483 */       if (this.wip == 0 && WIP.compareAndSet(this, 0, 1)) {
/*  484 */         long r = this.requested;
/*      */         
/*  486 */         Queue<R> q = this.scalarQueue;
/*  487 */         if (r != 0L && (q == null || q.isEmpty())) {
/*  488 */           this.actual.onNext(v);
/*      */           
/*  490 */           if (r != Long.MAX_VALUE) {
/*  491 */             REQUESTED.decrementAndGet(this);
/*      */           }
/*      */           
/*  494 */           if (this.maxConcurrency != Integer.MAX_VALUE) {
/*  495 */             int p = this.produced + 1;
/*  496 */             if (p == this.limit) {
/*  497 */               this.produced = 0;
/*  498 */               this.s.request(p);
/*      */             } else {
/*      */               
/*  501 */               this.produced = p;
/*      */             } 
/*      */           } 
/*      */         } else {
/*      */           
/*  506 */           if (q == null) {
/*  507 */             q = getOrCreateScalarQueue();
/*      */           }
/*      */           
/*  510 */           if (!q.offer(v) && failOverflow(v, this.s)) {
/*  511 */             this.done = true;
/*  512 */             drainLoop();
/*      */             return;
/*      */           } 
/*      */         } 
/*  516 */         if (WIP.decrementAndGet(this) == 0) {
/*  517 */           if (this.cancelled) {
/*  518 */             Operators.onDiscard(v, this.actual.currentContext());
/*      */           }
/*      */           
/*      */           return;
/*      */         } 
/*  523 */         drainLoop();
/*      */       
/*      */       }
/*      */       else {
/*      */         
/*  528 */         Queue<R> q = getOrCreateScalarQueue();
/*      */         
/*  530 */         if (!q.offer(v) && failOverflow(v, this.s)) {
/*  531 */           this.done = true;
/*      */         }
/*  533 */         drain(v);
/*      */       } 
/*      */     }
/*      */     
/*      */     void tryEmit(FluxFlatMap.FlatMapInner<R> inner, R v) {
/*  538 */       if (this.wip == 0 && WIP.compareAndSet(this, 0, 1)) {
/*  539 */         long r = this.requested;
/*      */         
/*  541 */         Queue<R> q = inner.queue;
/*  542 */         if (r != 0L && (q == null || q.isEmpty())) {
/*  543 */           this.actual.onNext(v);
/*      */           
/*  545 */           if (r != Long.MAX_VALUE) {
/*  546 */             REQUESTED.decrementAndGet(this);
/*      */           }
/*      */           
/*  549 */           inner.request(1L);
/*      */         } else {
/*      */           
/*  552 */           if (q == null) {
/*  553 */             q = getOrCreateInnerQueue(inner);
/*      */           }
/*      */           
/*  556 */           if (!q.offer(v) && failOverflow(v, inner)) {
/*  557 */             inner.done = true;
/*  558 */             drainLoop();
/*      */             return;
/*      */           } 
/*      */         } 
/*  562 */         if (WIP.decrementAndGet(this) == 0) {
/*  563 */           if (this.cancelled) {
/*  564 */             Operators.onDiscard(v, this.actual.currentContext());
/*      */           }
/*      */           
/*      */           return;
/*      */         } 
/*  569 */         drainLoop();
/*      */       } else {
/*      */         
/*  572 */         Queue<R> q = getOrCreateInnerQueue(inner);
/*      */         
/*  574 */         if (!q.offer(v) && failOverflow(v, inner)) {
/*  575 */           inner.done = true;
/*      */         }
/*  577 */         drain(v);
/*      */       } 
/*      */     }
/*      */     
/*      */     void drain(@Nullable R dataSignal) {
/*  582 */       if (WIP.getAndIncrement(this) != 0) {
/*  583 */         if (dataSignal != null && this.cancelled) {
/*  584 */           Operators.onDiscard(dataSignal, this.actual.currentContext());
/*      */         }
/*      */         return;
/*      */       } 
/*  588 */       drainLoop();
/*      */     }
/*      */     
/*      */     void drainLoop() {
/*  592 */       int missed = 1;
/*      */       
/*  594 */       CoreSubscriber<? super R> coreSubscriber = this.actual;
/*      */ 
/*      */       
/*      */       while (true) {
/*  598 */         boolean d = this.done;
/*      */         
/*  600 */         FluxFlatMap.FlatMapInner[] arrayOfFlatMapInner = (FluxFlatMap.FlatMapInner[])get();
/*      */         
/*  602 */         int n = arrayOfFlatMapInner.length;
/*      */         
/*  604 */         Queue<R> sq = this.scalarQueue;
/*      */         
/*  606 */         boolean noSources = isEmpty();
/*      */         
/*  608 */         if (checkTerminated(d, (noSources && (sq == null || sq.isEmpty())), (Subscriber<?>)coreSubscriber, (R)null)) {
/*      */           return;
/*      */         }
/*      */         
/*  612 */         boolean again = false;
/*      */         
/*  614 */         long r = this.requested;
/*  615 */         long e = 0L;
/*  616 */         long replenishMain = 0L;
/*      */         
/*  618 */         if (r != 0L && sq != null) {
/*      */           
/*  620 */           while (e != r) {
/*  621 */             d = this.done;
/*      */             
/*  623 */             R v = sq.poll();
/*      */             
/*  625 */             boolean empty = (v == null);
/*      */             
/*  627 */             if (checkTerminated(d, false, (Subscriber<?>)coreSubscriber, v)) {
/*      */               return;
/*      */             }
/*      */             
/*  631 */             if (empty) {
/*      */               break;
/*      */             }
/*      */             
/*  635 */             coreSubscriber.onNext(v);
/*      */             
/*  637 */             e++;
/*      */           } 
/*      */           
/*  640 */           if (e != 0L) {
/*  641 */             replenishMain += e;
/*  642 */             if (r != Long.MAX_VALUE) {
/*  643 */               r = REQUESTED.addAndGet(this, -e);
/*      */             }
/*  645 */             e = 0L;
/*  646 */             again = true;
/*      */           } 
/*      */         } 
/*  649 */         if (r != 0L && !noSources) {
/*      */           
/*  651 */           int j = this.lastIndex;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  657 */           for (int i = 0; i < n; i++) {
/*  658 */             if (this.cancelled) {
/*  659 */               Operators.onDiscardQueueWithClear(this.scalarQueue, this.actual.currentContext(), null);
/*  660 */               this.scalarQueue = null;
/*  661 */               this.s.cancel();
/*  662 */               unsubscribe();
/*      */               
/*      */               return;
/*      */             } 
/*  666 */             FluxFlatMap.FlatMapInner<R> inner = arrayOfFlatMapInner[j];
/*  667 */             if (inner != null) {
/*  668 */               d = inner.done;
/*  669 */               Queue<R> q = inner.queue;
/*  670 */               if (d && q == null) {
/*  671 */                 remove(inner.index);
/*  672 */                 again = true;
/*  673 */                 replenishMain++;
/*      */               }
/*  675 */               else if (q != null) {
/*  676 */                 while (e != r) {
/*  677 */                   R v; d = inner.done;
/*      */ 
/*      */ 
/*      */                   
/*      */                   try {
/*  682 */                     v = q.poll();
/*      */                   }
/*  684 */                   catch (Throwable ex) {
/*  685 */                     ex = Operators.onOperatorError(inner, ex, this.actual
/*  686 */                         .currentContext());
/*  687 */                     if (!Exceptions.addThrowable(ERROR, this, ex)) {
/*  688 */                       Operators.onErrorDropped(ex, this.actual
/*  689 */                           .currentContext());
/*      */                     }
/*  691 */                     v = null;
/*  692 */                     d = true;
/*      */                   } 
/*      */                   
/*  695 */                   boolean empty = (v == null);
/*      */                   
/*  697 */                   if (checkTerminated(d, false, (Subscriber<?>)coreSubscriber, v)) {
/*      */                     return;
/*      */                   }
/*      */                   
/*  701 */                   if (d && empty) {
/*  702 */                     remove(inner.index);
/*  703 */                     again = true;
/*  704 */                     replenishMain++;
/*      */                     
/*      */                     break;
/*      */                   } 
/*  708 */                   if (empty) {
/*      */                     break;
/*      */                   }
/*      */                   
/*  712 */                   coreSubscriber.onNext(v);
/*      */                   
/*  714 */                   e++;
/*      */                 } 
/*      */                 
/*  717 */                 if (e == r) {
/*  718 */                   d = inner.done;
/*  719 */                   boolean empty = q.isEmpty();
/*  720 */                   if (d && empty) {
/*  721 */                     remove(inner.index);
/*  722 */                     again = true;
/*  723 */                     replenishMain++;
/*      */                   } 
/*      */                 } 
/*      */                 
/*  727 */                 if (e != 0L) {
/*  728 */                   if (!inner.done) {
/*  729 */                     inner.request(e);
/*      */                   }
/*  731 */                   if (r != Long.MAX_VALUE) {
/*  732 */                     r = REQUESTED.addAndGet(this, -e);
/*  733 */                     if (r == 0L) {
/*      */                       break;
/*      */                     }
/*      */                   } 
/*  737 */                   e = 0L;
/*      */                 } 
/*      */               } 
/*      */             } 
/*      */             
/*  742 */             if (r == 0L) {
/*      */               break;
/*      */             }
/*      */             
/*  746 */             if (++j == n) {
/*  747 */               j = 0;
/*      */             }
/*      */           } 
/*      */           
/*  751 */           this.lastIndex = j;
/*      */         } 
/*      */         
/*  754 */         if (r == 0L && !noSources) {
/*  755 */           arrayOfFlatMapInner = (FluxFlatMap.FlatMapInner[])get();
/*  756 */           n = arrayOfFlatMapInner.length;
/*      */           
/*  758 */           for (int i = 0; i < n; i++) {
/*  759 */             if (this.cancelled) {
/*  760 */               Operators.onDiscardQueueWithClear(this.scalarQueue, this.actual.currentContext(), null);
/*  761 */               this.scalarQueue = null;
/*  762 */               this.s.cancel();
/*  763 */               unsubscribe();
/*      */               
/*      */               return;
/*      */             } 
/*  767 */             FluxFlatMap.FlatMapInner<R> inner = arrayOfFlatMapInner[i];
/*  768 */             if (inner != null) {
/*      */ 
/*      */ 
/*      */               
/*  772 */               d = inner.done;
/*  773 */               Queue<R> q = inner.queue;
/*  774 */               boolean empty = (q == null || q.isEmpty());
/*      */ 
/*      */               
/*  777 */               if (!empty) {
/*      */                 break;
/*      */               }
/*      */               
/*  781 */               if (d && empty) {
/*  782 */                 remove(inner.index);
/*  783 */                 again = true;
/*  784 */                 replenishMain++;
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*  789 */         if (replenishMain != 0L && !this.done && !this.cancelled) {
/*  790 */           this.s.request(replenishMain);
/*      */         }
/*      */         
/*  793 */         if (again) {
/*      */           continue;
/*      */         }
/*      */         
/*  797 */         missed = WIP.addAndGet(this, -missed);
/*  798 */         if (missed == 0) {
/*      */           break;
/*      */         }
/*      */       } 
/*      */     }
/*      */     
/*      */     boolean checkTerminated(boolean d, boolean empty, Subscriber<?> a, @Nullable R value) {
/*  805 */       if (this.cancelled) {
/*  806 */         Context ctx = this.actual.currentContext();
/*  807 */         Operators.onDiscard(value, ctx);
/*  808 */         Operators.onDiscardQueueWithClear(this.scalarQueue, ctx, null);
/*  809 */         this.scalarQueue = null;
/*  810 */         this.s.cancel();
/*  811 */         unsubscribe();
/*      */         
/*  813 */         return true;
/*      */       } 
/*      */       
/*  816 */       if (this.delayError) {
/*  817 */         if (d && empty) {
/*  818 */           Throwable e = this.error;
/*  819 */           if (e != null && e != Exceptions.TERMINATED) {
/*  820 */             e = Exceptions.terminate(ERROR, this);
/*  821 */             a.onError(e);
/*      */           } else {
/*      */             
/*  824 */             a.onComplete();
/*      */           } 
/*      */           
/*  827 */           return true;
/*      */         }
/*      */       
/*      */       }
/*  831 */       else if (d) {
/*  832 */         Throwable e = this.error;
/*  833 */         if (e != null && e != Exceptions.TERMINATED) {
/*  834 */           e = Exceptions.terminate(ERROR, this);
/*  835 */           Context ctx = this.actual.currentContext();
/*  836 */           Operators.onDiscard(value, ctx);
/*  837 */           Operators.onDiscardQueueWithClear(this.scalarQueue, ctx, null);
/*  838 */           this.scalarQueue = null;
/*  839 */           this.s.cancel();
/*  840 */           unsubscribe();
/*      */           
/*  842 */           a.onError(e);
/*  843 */           return true;
/*      */         } 
/*  845 */         if (empty) {
/*  846 */           a.onComplete();
/*  847 */           return true;
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  852 */       return false;
/*      */     }
/*      */     
/*      */     void innerError(FluxFlatMap.FlatMapInner<R> inner, Throwable e) {
/*  856 */       e = Operators.onNextInnerError(e, currentContext(), this.s);
/*  857 */       if (e != null) {
/*  858 */         if (Exceptions.addThrowable(ERROR, this, e)) {
/*  859 */           if (!this.delayError) {
/*  860 */             this.done = true;
/*      */           }
/*  862 */           inner.done = true;
/*  863 */           drain((R)null);
/*      */         } else {
/*      */           
/*  866 */           inner.done = true;
/*  867 */           Operators.onErrorDropped(e, this.actual.currentContext());
/*      */         } 
/*      */       } else {
/*      */         
/*  871 */         inner.done = true;
/*  872 */         drain((R)null);
/*      */       } 
/*      */     }
/*      */     
/*      */     boolean failOverflow(R v, Subscription toCancel) {
/*  877 */       Throwable e = Operators.onOperatorError(toCancel, 
/*  878 */           Exceptions.failWithOverflow("Queue is full: Reactive Streams source doesn't respect backpressure"), v, this.actual
/*  879 */           .currentContext());
/*      */       
/*  881 */       Operators.onDiscard(v, this.actual.currentContext());
/*      */       
/*  883 */       if (!Exceptions.addThrowable(ERROR, this, e)) {
/*  884 */         Operators.onErrorDropped(e, this.actual.currentContext());
/*  885 */         return false;
/*      */       } 
/*  887 */       return true;
/*      */     }
/*      */     
/*      */     void innerComplete(FluxFlatMap.FlatMapInner<R> inner) {
/*  891 */       if (WIP.getAndIncrement(this) != 0) {
/*      */         return;
/*      */       }
/*  894 */       drainLoop();
/*      */     }
/*      */     
/*      */     Queue<R> getOrCreateInnerQueue(FluxFlatMap.FlatMapInner<R> inner) {
/*  898 */       Queue<R> q = inner.queue;
/*  899 */       if (q == null) {
/*  900 */         q = this.innerQueueSupplier.get();
/*  901 */         inner.queue = q;
/*      */       } 
/*  903 */       return q;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static final class FlatMapInner<R>
/*      */     implements InnerConsumer<R>, Subscription
/*      */   {
/*      */     final FluxFlatMap.FlatMapMain<?, R> parent;
/*      */     
/*      */     final int prefetch;
/*      */     
/*      */     final int limit;
/*      */     
/*      */     volatile Subscription s;
/*      */     
/*  920 */     static final AtomicReferenceFieldUpdater<FlatMapInner, Subscription> S = AtomicReferenceFieldUpdater.newUpdater(FlatMapInner.class, Subscription.class, "s");
/*      */ 
/*      */     
/*      */     long produced;
/*      */ 
/*      */     
/*      */     volatile Queue<R> queue;
/*      */ 
/*      */     
/*      */     volatile boolean done;
/*      */ 
/*      */     
/*      */     int sourceMode;
/*      */     
/*      */     int index;
/*      */ 
/*      */     
/*      */     FlatMapInner(FluxFlatMap.FlatMapMain<?, R> parent, int prefetch) {
/*  938 */       this.parent = parent;
/*  939 */       this.prefetch = prefetch;
/*      */       
/*  941 */       this.limit = Operators.unboundedOrLimit(prefetch);
/*      */     }
/*      */ 
/*      */     
/*      */     public void onSubscribe(Subscription s) {
/*  946 */       if (Operators.setOnce(S, this, s)) {
/*  947 */         if (s instanceof Fuseable.QueueSubscription) {
/*  948 */           Fuseable.QueueSubscription<R> f = (Fuseable.QueueSubscription<R>)s;
/*      */           
/*  950 */           int m = f.requestFusion(7);
/*  951 */           if (m == 1) {
/*  952 */             this.sourceMode = 1;
/*  953 */             this.queue = (Queue<R>)f;
/*  954 */             this.done = true;
/*  955 */             this.parent.drain((R)null);
/*      */             return;
/*      */           } 
/*  958 */           if (m == 2) {
/*  959 */             this.sourceMode = 2;
/*  960 */             this.queue = (Queue<R>)f;
/*      */           } 
/*      */         } 
/*      */         
/*  964 */         s.request(Operators.unboundedOrPrefetch(this.prefetch));
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void onNext(R t) {
/*  970 */       if (this.sourceMode == 2) {
/*  971 */         this.parent.drain(t);
/*      */       } else {
/*      */         
/*  974 */         if (this.done) {
/*  975 */           Operators.onNextDropped(t, this.parent.currentContext());
/*      */           
/*      */           return;
/*      */         } 
/*  979 */         if (this.s == Operators.cancelledSubscription()) {
/*  980 */           Operators.onDiscard(t, this.parent.currentContext());
/*      */           
/*      */           return;
/*      */         } 
/*  984 */         this.parent.tryEmit(this, t);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void onError(Throwable t) {
/*  990 */       this.parent.innerError(this, t);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void onComplete() {
/*  996 */       this.done = true;
/*  997 */       this.parent.innerComplete(this);
/*      */     }
/*      */ 
/*      */     
/*      */     public void request(long n) {
/* 1002 */       if (this.sourceMode == 1) {
/*      */         return;
/*      */       }
/* 1005 */       long p = this.produced + n;
/* 1006 */       if (p >= this.limit) {
/* 1007 */         this.produced = 0L;
/* 1008 */         this.s.request(p);
/*      */       } else {
/*      */         
/* 1011 */         this.produced = p;
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public Context currentContext() {
/* 1017 */       return this.parent.currentContext();
/*      */     }
/*      */ 
/*      */     
/*      */     public void cancel() {
/* 1022 */       Operators.terminate(S, this);
/* 1023 */       Operators.onDiscardQueueWithClear(this.queue, this.parent.currentContext(), null);
/*      */     }
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     public Object scanUnsafe(Scannable.Attr key) {
/* 1029 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 1030 */       if (key == Scannable.Attr.ACTUAL) return this.parent; 
/* 1031 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf((this.done && (this.queue == null || this.queue.isEmpty()))); 
/* 1032 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf((this.s == Operators.cancelledSubscription())); 
/* 1033 */       if (key == Scannable.Attr.BUFFERED) return Integer.valueOf((this.queue == null) ? 0 : this.queue.size()); 
/* 1034 */       if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(this.prefetch); 
/* 1035 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*      */       
/* 1037 */       return null;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\FluxFlatMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */