/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.util.function.Function;
/*    */ import kotlin.Deprecated;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.ReplaceWith;
/*    */ import kotlin.TypeCastException;
/*    */ import kotlin.collections.ArraysKt;
/*    */ import kotlin.jvm.JvmName;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.reactivestreams.Publisher;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 1, 18}, bv = {1, 0, 3}, k = 2, d1 = {"\000*\n\000\n\002\030\002\n\002\030\002\n\000\n\002\020\021\n\002\030\002\n\002\b\005\n\002\030\002\n\000\n\002\020\034\n\000\n\002\020 \n\000\032/\020\000\032\b\022\004\022\0020\0020\0012\032\020\003\032\016\022\n\b\001\022\006\022\002\b\0030\0050\004\"\006\022\002\b\0030\005H\007¢\006\002\020\006\032M\020\007\032\b\022\004\022\002H\b0\001\"\004\b\000\020\b2\032\020\t\032\016\022\n\b\001\022\006\022\002\b\0030\0010\004\"\006\022\002\b\0030\0012\026\020\n\032\022\022\b\022\006\022\002\b\0030\004\022\004\022\002H\b0\013H\007¢\006\002\020\f\032\034\020\000\032\b\022\004\022\0020\0020\001*\f\022\b\022\006\022\002\b\0030\0050\rH\007\032G\020\007\032\b\022\004\022\002H\b0\001\"\004\b\000\020\016\"\004\b\001\020\b*\016\022\n\022\b\022\004\022\002H\0160\0010\r2\032\b\004\020\n\032\024\022\n\022\b\022\004\022\002H\0160\017\022\004\022\002H\b0\013H\b¨\006\020"}, d2 = {"whenComplete", "Lreactor/core/publisher/Mono;", "Ljava/lang/Void;", "sources", "", "Lorg/reactivestreams/Publisher;", "([Lorg/reactivestreams/Publisher;)Lreactor/core/publisher/Mono;", "zip", "R", "monos", "combinator", "Lkotlin/Function1;", "([Lreactor/core/publisher/Mono;Lkotlin/jvm/functions/Function1;)Lreactor/core/publisher/Mono;", "", "T", "", "reactor-core"})
/*    */ @JvmName(name = "MonoWhenFunctionsKt")
/*    */ public final class MonoWhenFunctionsKt
/*    */ {
/*    */   @Deprecated(message = "To be removed in 3.3.0.RELEASE, replaced by module reactor-kotlin-extensions", replaceWith = @ReplaceWith(imports = {"reactor.kotlin.core.publisher.whenComplete"}, expression = "whenComplete()"))
/*    */   @NotNull
/*    */   public static final Mono<Void> whenComplete(@NotNull Iterable<? extends Publisher<?>> $this$whenComplete) {
/* 34 */     Intrinsics.checkParameterIsNotNull($this$whenComplete, "$this$whenComplete"); Intrinsics.checkExpressionValueIsNotNull(Mono.when($this$whenComplete), "Mono.`when`(this)"); return Mono.when($this$whenComplete);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Deprecated(message = "To be removed in 3.3.0.RELEASE, replaced by module reactor-kotlin-extensions", replaceWith = @ReplaceWith(imports = {"reactor.kotlin.core.publisher.zip"}, expression = "zip(combinator)"))
/*    */   @NotNull
/*    */   public static final <T, R> Mono<R> zip(@NotNull Iterable<? extends Mono<?>> $this$zip, @NotNull Function1 combinator) {
/* 49 */     int $i$f$zip = 0; Intrinsics.checkParameterIsNotNull($this$zip, "$this$zip"); Intrinsics.checkParameterIsNotNull(combinator, "combinator"); Intrinsics.checkExpressionValueIsNotNull(Mono.zip($this$zip, new MonoWhenFunctionsKt$zip$1<>(combinator)), "Mono.zip(this) { combina…it.asList() as List<T>) }"); return (Mono)Mono.zip($this$zip, new MonoWhenFunctionsKt$zip$1<>(combinator)); } @Metadata(mv = {1, 1, 18}, bv = {1, 0, 3}, k = 3, d1 = {"\000\020\n\002\b\004\n\002\020\021\n\002\020\000\n\002\b\003\020\000\032\002H\001\"\004\b\000\020\002\"\004\b\001\020\0012,\020\003\032(\022\f\022\n \006*\004\030\0010\0050\005 \006*\024\022\016\b\001\022\n \006*\004\030\0010\0050\005\030\0010\0040\004H\n¢\006\004\b\007\020\b"}, d2 = {"<anonymous>", "R", "T", "it", "", "", "kotlin.jvm.PlatformType", "apply", "([Ljava/lang/Object;)Ljava/lang/Object;"}) public static final class MonoWhenFunctionsKt$zip$1<T, R> implements Function { public final R apply(Object[] it) { Intrinsics.checkExpressionValueIsNotNull(it, "it"); if (ArraysKt.asList(it) == null) throw new TypeCastException("null cannot be cast to non-null type kotlin.collections.List<T>");  return (R)this.$combinator.invoke(ArraysKt.asList(it)); }
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     public MonoWhenFunctionsKt$zip$1(Function1 param1Function1) {} }
/*    */ 
/*    */ 
/*    */   
/*    */   @Deprecated(message = "To be removed in 3.3.0.RELEASE, replaced by module reactor-kotlin-extensions", replaceWith = @ReplaceWith(imports = {"reactor.kotlin.core.publisher.whenComplete"}, expression = "whenComplete(*sources)"))
/*    */   @NotNull
/*    */   public static final Mono<Void> whenComplete(@NotNull Publisher... sources) {
/* 61 */     Intrinsics.checkParameterIsNotNull(sources, "sources"); Intrinsics.checkExpressionValueIsNotNull(MonoBridges.when((Publisher<?>[])sources), "MonoBridges.`when`(sources)"); return MonoBridges.when((Publisher<?>[])sources);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Deprecated(message = "To be removed in 3.3.0.RELEASE, replaced by module reactor-kotlin-extensions", replaceWith = @ReplaceWith(imports = {"reactor.kotlin.core.publisher.zip"}, expression = "zip(*monos, combinator)"))
/*    */   @NotNull
/*    */   public static final <R> Mono<R> zip(@NotNull Mono[] monos, @NotNull Function1 combinator) {
/* 73 */     Intrinsics.checkParameterIsNotNull(monos, "monos"); Intrinsics.checkParameterIsNotNull(combinator, "combinator"); Function1 function1 = combinator; Intrinsics.checkExpressionValueIsNotNull(MonoBridges.zip(new MonoWhenFunctionsKt$sam$java_util_function_Function$0(function1), (Mono<?>[])monos), "MonoBridges.zip(combinator, monos)"); return (Mono)MonoBridges.zip(new MonoWhenFunctionsKt$sam$java_util_function_Function$0(function1), (Mono<?>[])monos);
/*    */   }
/*    */   
/*    */   @Metadata(mv = {1, 1, 18}, bv = {1, 0, 3}, k = 3)
/*    */   final class MonoWhenFunctionsKt$sam$java_util_function_Function$0 implements Function {
/*    */     MonoWhenFunctionsKt$sam$java_util_function_Function$0(MonoWhenFunctionsKt this$0) {
/*    */       this.function = (Function1)this$0;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\MonoWhenFunctionsKt.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */