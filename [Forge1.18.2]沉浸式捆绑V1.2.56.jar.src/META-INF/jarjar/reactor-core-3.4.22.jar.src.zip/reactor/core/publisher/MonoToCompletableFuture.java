/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.util.concurrent.CompletableFuture;
/*    */ import java.util.concurrent.atomic.AtomicReference;
/*    */ import org.reactivestreams.Subscription;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.util.context.Context;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MonoToCompletableFuture<T>
/*    */   extends CompletableFuture<T>
/*    */   implements CoreSubscriber<T>
/*    */ {
/* 31 */   final AtomicReference<Subscription> ref = new AtomicReference<>();
/*    */   final boolean cancelSourceOnNext;
/*    */   
/*    */   MonoToCompletableFuture(boolean sourceCanEmitMoreThanOnce) {
/* 35 */     this.cancelSourceOnNext = sourceCanEmitMoreThanOnce;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean cancel(boolean mayInterruptIfRunning) {
/* 40 */     boolean cancelled = super.cancel(mayInterruptIfRunning);
/* 41 */     if (cancelled) {
/* 42 */       Subscription s = this.ref.getAndSet(null);
/* 43 */       if (s != null) {
/* 44 */         s.cancel();
/*    */       }
/*    */     } 
/* 47 */     return cancelled;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onSubscribe(Subscription s) {
/* 52 */     if (Operators.validate(this.ref.getAndSet(s), s)) {
/* 53 */       s.request(Long.MAX_VALUE);
/*    */     } else {
/*    */       
/* 56 */       s.cancel();
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void onNext(T t) {
/* 62 */     Subscription s = this.ref.getAndSet(null);
/* 63 */     if (s != null) {
/* 64 */       complete(t);
/* 65 */       if (this.cancelSourceOnNext) {
/* 66 */         s.cancel();
/*    */       }
/*    */     } else {
/*    */       
/* 70 */       Operators.onNextDropped(t, currentContext());
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void onError(Throwable t) {
/* 76 */     if (this.ref.getAndSet(null) != null) {
/* 77 */       completeExceptionally(t);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public void onComplete() {
/* 83 */     if (this.ref.getAndSet(null) != null) {
/* 84 */       complete(null);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public Context currentContext() {
/* 90 */     return Context.empty();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\MonoToCompletableFuture.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */