/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.stream.Stream;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxSample<T, U>
/*     */   extends InternalFluxOperator<T, T>
/*     */ {
/*     */   final Publisher<U> other;
/*     */   
/*     */   FluxSample(Flux<? extends T> source, Publisher<U> other) {
/*  54 */     super(source);
/*  55 */     this.other = Objects.<Publisher<U>>requireNonNull(other, "other");
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPrefetch() {
/*  60 */     return Integer.MAX_VALUE;
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/*  65 */     CoreSubscriber<T> serial = Operators.serialize(actual);
/*     */     
/*  67 */     SampleMainSubscriber<T> main = new SampleMainSubscriber<>(serial);
/*     */     
/*  69 */     actual.onSubscribe(main);
/*     */     
/*  71 */     this.other.subscribe((Subscriber)new SampleOther<>(main));
/*  72 */     return main;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  77 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  78 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class SampleMainSubscriber<T>
/*     */     implements InnerOperator<T, T>
/*     */   {
/*     */     final CoreSubscriber<? super T> actual;
/*     */     
/*     */     final Context ctx;
/*     */     
/*     */     volatile T value;
/*  90 */     static final AtomicReferenceFieldUpdater<SampleMainSubscriber, Object> VALUE = AtomicReferenceFieldUpdater.newUpdater(SampleMainSubscriber.class, Object.class, "value");
/*     */ 
/*     */     
/*     */     volatile Subscription main;
/*     */ 
/*     */     
/*  96 */     static final AtomicReferenceFieldUpdater<SampleMainSubscriber, Subscription> MAIN = AtomicReferenceFieldUpdater.newUpdater(SampleMainSubscriber.class, Subscription.class, "main");
/*     */ 
/*     */     
/*     */     volatile Subscription other;
/*     */ 
/*     */     
/* 102 */     static final AtomicReferenceFieldUpdater<SampleMainSubscriber, Subscription> OTHER = AtomicReferenceFieldUpdater.newUpdater(SampleMainSubscriber.class, Subscription.class, "other");
/*     */ 
/*     */     
/*     */     volatile long requested;
/*     */     
/* 107 */     static final AtomicLongFieldUpdater<SampleMainSubscriber> REQUESTED = AtomicLongFieldUpdater.newUpdater(SampleMainSubscriber.class, "requested");
/*     */     
/*     */     SampleMainSubscriber(CoreSubscriber<? super T> actual) {
/* 110 */       this.actual = actual;
/* 111 */       this.ctx = actual.currentContext();
/*     */     }
/*     */ 
/*     */     
/*     */     public final CoreSubscriber<? super T> actual() {
/* 116 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public Stream<? extends Scannable> inners() {
/* 121 */       return Stream.of(Scannable.from(this.other));
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 127 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf(this.requested); 
/* 128 */       if (key == Scannable.Attr.PARENT) return this.main; 
/* 129 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf((this.main == Operators.cancelledSubscription())); 
/* 130 */       if (key == Scannable.Attr.BUFFERED) return Integer.valueOf((this.value != null) ? 1 : 0); 
/* 131 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 133 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 138 */       if (!MAIN.compareAndSet(this, null, s)) {
/* 139 */         s.cancel();
/* 140 */         if (this.main != Operators.cancelledSubscription()) {
/* 141 */           Operators.reportSubscriptionSet();
/*     */         }
/*     */         return;
/*     */       } 
/* 145 */       s.request(Long.MAX_VALUE);
/*     */     }
/*     */     
/*     */     void cancelMain() {
/* 149 */       Subscription s = this.main;
/* 150 */       if (s != Operators.cancelledSubscription()) {
/* 151 */         s = MAIN.getAndSet(this, Operators.cancelledSubscription());
/* 152 */         if (s != null && s != Operators.cancelledSubscription()) {
/* 153 */           s.cancel();
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*     */     void cancelOther() {
/* 159 */       Subscription s = this.other;
/* 160 */       if (s != Operators.cancelledSubscription()) {
/* 161 */         s = OTHER.getAndSet(this, Operators.cancelledSubscription());
/* 162 */         if (s != null && s != Operators.cancelledSubscription()) {
/* 163 */           s.cancel();
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*     */     void setOther(Subscription s) {
/* 169 */       if (!OTHER.compareAndSet(this, null, s)) {
/* 170 */         s.cancel();
/* 171 */         if (this.other != Operators.cancelledSubscription()) {
/* 172 */           Operators.reportSubscriptionSet();
/*     */         }
/*     */         return;
/*     */       } 
/* 176 */       s.request(Long.MAX_VALUE);
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 181 */       if (Operators.validate(n)) {
/* 182 */         Operators.addCap(REQUESTED, this, n);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 188 */       cancelMain();
/* 189 */       cancelOther();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 194 */       Object old = VALUE.getAndSet(this, t);
/* 195 */       if (old != null) {
/* 196 */         Operators.onDiscard(old, this.ctx);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 202 */       cancelOther();
/*     */       
/* 204 */       this.actual.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 209 */       cancelOther();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 214 */       T v = this.value;
/* 215 */       if (v != null) {
/* 216 */         this.actual.onNext(this.value);
/*     */       }
/*     */       
/* 219 */       this.actual.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     T getAndNullValue() {
/* 225 */       return (T)VALUE.getAndSet(this, null);
/*     */     }
/*     */     
/*     */     void decrement() {
/* 229 */       REQUESTED.decrementAndGet(this);
/*     */     }
/*     */   }
/*     */   
/*     */   static final class SampleOther<T, U> implements InnerConsumer<U> {
/*     */     final FluxSample.SampleMainSubscriber<T> main;
/*     */     
/*     */     SampleOther(FluxSample.SampleMainSubscriber<T> main) {
/* 237 */       this.main = main;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 243 */       if (key == Scannable.Attr.PARENT) return this.main.other; 
/* 244 */       if (key == Scannable.Attr.ACTUAL) return this.main; 
/* 245 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf((this.main.other == Operators.cancelledSubscription())); 
/* 246 */       if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(2147483647); 
/* 247 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 249 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/* 254 */       return this.main.currentContext();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 259 */       this.main.setOther(s);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(U t) {
/* 264 */       FluxSample.SampleMainSubscriber<T> m = this.main;
/*     */       
/* 266 */       T v = m.getAndNullValue();
/*     */       
/* 268 */       if (v != null) {
/* 269 */         if (m.requested != 0L) {
/* 270 */           m.actual.onNext(v);
/*     */           
/* 272 */           if (m.requested != Long.MAX_VALUE) {
/* 273 */             m.decrement();
/*     */           }
/*     */           
/*     */           return;
/*     */         } 
/* 278 */         m.cancel();
/* 279 */         m.actual.onError(Exceptions.failWithOverflow("Can't signal value due to lack of requests"));
/* 280 */         Operators.onDiscard(v, m.ctx);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 286 */       FluxSample.SampleMainSubscriber<T> m = this.main;
/*     */       
/* 288 */       m.cancelMain();
/*     */       
/* 290 */       m.actual.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 295 */       FluxSample.SampleMainSubscriber<T> m = this.main;
/*     */       
/* 297 */       m.cancelMain();
/*     */       
/* 299 */       m.actual.onComplete();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\FluxSample.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */