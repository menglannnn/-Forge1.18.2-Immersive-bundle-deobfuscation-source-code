/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MonoIgnoreElements<T>
/*     */   extends MonoFromFluxOperator<T, T>
/*     */ {
/*     */   MonoIgnoreElements(Flux<? extends T> source) {
/*  33 */     super(source);
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/*  38 */     return new IgnoreElementsSubscriber<>(actual);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  43 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  44 */     return super.scanUnsafe(key);
/*     */   }
/*     */   
/*     */   static final class IgnoreElementsSubscriber<T>
/*     */     implements InnerOperator<T, T> {
/*     */     final CoreSubscriber<? super T> actual;
/*     */     Subscription s;
/*     */     
/*     */     IgnoreElementsSubscriber(CoreSubscriber<? super T> actual) {
/*  53 */       this.actual = actual;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/*  59 */       if (key == Scannable.Attr.PARENT) return this.s; 
/*  60 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/*  62 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/*  67 */       if (Operators.validate(this.s, s)) {
/*  68 */         this.s = s;
/*     */         
/*  70 */         this.actual.onSubscribe(this);
/*     */         
/*  72 */         s.request(Long.MAX_VALUE);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/*  79 */       Operators.onDiscard(t, this.actual.currentContext());
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/*  84 */       this.actual.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/*  89 */       this.actual.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/*  94 */       return this.actual;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void request(long n) {}
/*     */ 
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 104 */       this.s.cancel();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\MonoIgnoreElements.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */