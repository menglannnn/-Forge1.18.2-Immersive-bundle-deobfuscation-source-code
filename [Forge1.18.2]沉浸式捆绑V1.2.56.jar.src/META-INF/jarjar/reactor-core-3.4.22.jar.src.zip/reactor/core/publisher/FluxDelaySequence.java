/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.core.scheduler.Scheduler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxDelaySequence<T>
/*     */   extends InternalFluxOperator<T, T>
/*     */ {
/*     */   final Duration delay;
/*     */   final Scheduler scheduler;
/*     */   
/*     */   FluxDelaySequence(Flux<T> source, Duration delay, Scheduler scheduler) {
/*  37 */     super(source);
/*  38 */     this.delay = delay;
/*  39 */     this.scheduler = scheduler;
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/*  44 */     Scheduler.Worker w = this.scheduler.createWorker();
/*     */     
/*  46 */     return new DelaySubscriber<>(actual, this.delay, w);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  51 */     if (key == Scannable.Attr.RUN_ON) return this.scheduler; 
/*  52 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.ASYNC;
/*     */     
/*  54 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class DelaySubscriber<T>
/*     */     implements InnerOperator<T, T>
/*     */   {
/*     */     final CoreSubscriber<? super T> actual;
/*     */     
/*     */     final long delay;
/*     */     
/*     */     final TimeUnit timeUnit;
/*     */     final Scheduler.Worker w;
/*     */     Subscription s;
/*     */     volatile boolean done;
/*     */     volatile long delayed;
/*  70 */     static final AtomicLongFieldUpdater<DelaySubscriber> DELAYED = AtomicLongFieldUpdater.newUpdater(DelaySubscriber.class, "delayed");
/*     */ 
/*     */ 
/*     */     
/*     */     DelaySubscriber(CoreSubscriber<? super T> actual, Duration delay, Scheduler.Worker w) {
/*  75 */       this.actual = Operators.serialize(actual);
/*  76 */       this.w = w;
/*  77 */       this.delay = delay.toNanos();
/*  78 */       this.timeUnit = TimeUnit.NANOSECONDS;
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/*  83 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/*  88 */       if (Operators.validate(this.s, s)) {
/*  89 */         this.s = s;
/*  90 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/*  96 */       if (this.done || this.delayed < 0L) {
/*  97 */         Operators.onNextDropped(t, currentContext());
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/* 103 */       DELAYED.incrementAndGet(this);
/* 104 */       this.w.schedule(() -> delayedNext((T)t), this.delay, this.timeUnit);
/*     */     }
/*     */ 
/*     */     
/*     */     private void delayedNext(T t) {
/* 109 */       DELAYED.decrementAndGet(this);
/* 110 */       this.actual.onNext(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 115 */       if (this.done) {
/* 116 */         Operators.onErrorDropped(t, currentContext());
/*     */         return;
/*     */       } 
/* 119 */       this.done = true;
/*     */ 
/*     */       
/* 122 */       if (DELAYED.compareAndSet(this, 0L, -1L)) {
/* 123 */         this.actual.onError(t);
/*     */       } else {
/*     */         
/* 126 */         this.w.schedule(new OnError(t), this.delay, this.timeUnit);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 132 */       if (this.done) {
/*     */         return;
/*     */       }
/* 135 */       this.done = true;
/*     */ 
/*     */       
/* 138 */       if (DELAYED.compareAndSet(this, 0L, -1L)) {
/* 139 */         this.actual.onComplete();
/*     */       } else {
/*     */         
/* 142 */         this.w.schedule(new OnComplete(), this.delay, this.timeUnit);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 148 */       this.s.request(n);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 153 */       this.s.cancel();
/* 154 */       this.w.dispose();
/*     */     }
/*     */ 
/*     */     
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 159 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 160 */       if (key == Scannable.Attr.RUN_ON) return this.w; 
/* 161 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 162 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf((this.w.isDisposed() && !this.done)); 
/* 163 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.ASYNC;
/*     */       
/* 165 */       return super.scanUnsafe(key);
/*     */     }
/*     */     
/*     */     final class OnError implements Runnable {
/*     */       private final Throwable t;
/*     */       
/*     */       OnError(Throwable t) {
/* 172 */         this.t = t;
/*     */       }
/*     */ 
/*     */       
/*     */       public void run() {
/*     */         try {
/* 178 */           FluxDelaySequence.DelaySubscriber.this.actual.onError(this.t);
/*     */         } finally {
/* 180 */           FluxDelaySequence.DelaySubscriber.this.w.dispose();
/*     */         } 
/*     */       }
/*     */     }
/*     */     
/*     */     final class OnComplete
/*     */       implements Runnable {
/*     */       public void run() {
/*     */         try {
/* 189 */           FluxDelaySequence.DelaySubscriber.this.actual.onComplete();
/*     */         } finally {
/* 191 */           FluxDelaySequence.DelaySubscriber.this.w.dispose();
/*     */         } 
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\FluxDelaySequence.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */