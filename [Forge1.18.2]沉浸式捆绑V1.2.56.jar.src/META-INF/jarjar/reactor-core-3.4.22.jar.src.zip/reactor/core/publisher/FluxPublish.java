/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.Queue;
/*     */ import java.util.concurrent.CancellationException;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.stream.Stream;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxPublish<T>
/*     */   extends ConnectableFlux<T>
/*     */   implements Scannable
/*     */ {
/*     */   final Flux<? extends T> source;
/*     */   final int prefetch;
/*     */   final Supplier<? extends Queue<T>> queueSupplier;
/*     */   volatile PublishSubscriber<T> connection;
/*  63 */   static final AtomicReferenceFieldUpdater<FluxPublish, PublishSubscriber> CONNECTION = AtomicReferenceFieldUpdater.newUpdater(FluxPublish.class, PublishSubscriber.class, "connection");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   FluxPublish(Flux<? extends T> source, int prefetch, Supplier<? extends Queue<T>> queueSupplier) {
/*  70 */     if (prefetch <= 0) {
/*  71 */       throw new IllegalArgumentException("bufferSize > 0 required but it was " + prefetch);
/*     */     }
/*  73 */     this.source = Objects.<Flux<? extends T>>requireNonNull(source, "source");
/*  74 */     this.prefetch = prefetch;
/*  75 */     this.queueSupplier = Objects.<Supplier<? extends Queue<T>>>requireNonNull(queueSupplier, "queueSupplier");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void connect(Consumer<? super Disposable> cancelSupport) {
/*     */     PublishSubscriber<T> s;
/*     */     while (true) {
/*  83 */       s = this.connection;
/*  84 */       if (s == null || s.isTerminated()) {
/*  85 */         PublishSubscriber<T> u = new PublishSubscriber<>(this.prefetch, this);
/*     */         
/*  87 */         if (!CONNECTION.compareAndSet(this, s, u)) {
/*     */           continue;
/*     */         }
/*     */         
/*  91 */         s = u;
/*     */       }  break;
/*     */     } 
/*  94 */     boolean doConnect = s.tryConnect();
/*     */ 
/*     */ 
/*     */     
/*  98 */     cancelSupport.accept(s);
/*  99 */     if (doConnect) {
/* 100 */       this.source.subscribe(s);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super T> actual) {
/* 106 */     PublishInner<T> inner = new PublishInner<>(actual);
/* 107 */     actual.onSubscribe(inner);
/*     */     
/* 109 */     while (!inner.isCancelled()) {
/*     */ 
/*     */ 
/*     */       
/* 113 */       PublishSubscriber<T> c = this.connection;
/* 114 */       if (c == null || c.isTerminated()) {
/* 115 */         PublishSubscriber<T> u = new PublishSubscriber<>(this.prefetch, this);
/* 116 */         if (!CONNECTION.compareAndSet(this, c, u)) {
/*     */           continue;
/*     */         }
/*     */         
/* 120 */         c = u;
/*     */       } 
/*     */       
/* 123 */       if (c.add(inner)) {
/* 124 */         if (inner.isCancelled()) {
/* 125 */           c.remove(inner);
/*     */         } else {
/*     */           
/* 128 */           inner.parent = c;
/*     */         } 
/* 130 */         c.drain();
/*     */         break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPrefetch() {
/* 138 */     return this.prefetch;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/* 144 */     if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(getPrefetch()); 
/* 145 */     if (key == Scannable.Attr.PARENT) return this.source; 
/* 146 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */     
/* 148 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   static final class PublishSubscriber<T>
/*     */     implements InnerConsumer<T>, Disposable
/*     */   {
/*     */     final int prefetch;
/*     */     
/*     */     final FluxPublish<T> parent;
/*     */     
/*     */     volatile Subscription s;
/*     */     
/* 161 */     static final AtomicReferenceFieldUpdater<PublishSubscriber, Subscription> S = AtomicReferenceFieldUpdater.newUpdater(PublishSubscriber.class, Subscription.class, "s");
/*     */ 
/*     */ 
/*     */     
/*     */     volatile FluxPublish.PubSubInner<T>[] subscribers;
/*     */ 
/*     */ 
/*     */     
/* 169 */     static final AtomicReferenceFieldUpdater<PublishSubscriber, FluxPublish.PubSubInner[]> SUBSCRIBERS = (AtomicReferenceFieldUpdater)AtomicReferenceFieldUpdater.newUpdater(PublishSubscriber.class, (Class)FluxPublish.PubSubInner[].class, "subscribers");
/*     */ 
/*     */ 
/*     */     
/*     */     volatile int wip;
/*     */ 
/*     */     
/* 176 */     static final AtomicIntegerFieldUpdater<PublishSubscriber> WIP = AtomicIntegerFieldUpdater.newUpdater(PublishSubscriber.class, "wip");
/*     */ 
/*     */     
/*     */     volatile int connected;
/*     */     
/* 181 */     static final AtomicIntegerFieldUpdater<PublishSubscriber> CONNECTED = AtomicIntegerFieldUpdater.newUpdater(PublishSubscriber.class, "connected");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 187 */     static final FluxPublish.PubSubInner[] INIT = (FluxPublish.PubSubInner[])new FluxPublish.PublishInner[0];
/*     */     
/* 189 */     static final FluxPublish.PubSubInner[] CANCELLED = (FluxPublish.PubSubInner[])new FluxPublish.PublishInner[0];
/*     */     
/* 191 */     static final FluxPublish.PubSubInner[] TERMINATED = (FluxPublish.PubSubInner[])new FluxPublish.PublishInner[0];
/*     */ 
/*     */     
/*     */     volatile Queue<T> queue;
/*     */ 
/*     */     
/*     */     int sourceMode;
/*     */     
/*     */     volatile boolean done;
/*     */     
/*     */     volatile Throwable error;
/*     */     
/* 203 */     static final AtomicReferenceFieldUpdater<PublishSubscriber, Throwable> ERROR = AtomicReferenceFieldUpdater.newUpdater(PublishSubscriber.class, Throwable.class, "error");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     PublishSubscriber(int prefetch, FluxPublish<T> parent) {
/* 209 */       this.prefetch = prefetch;
/* 210 */       this.parent = parent;
/* 211 */       SUBSCRIBERS.lazySet(this, INIT);
/*     */     }
/*     */     
/*     */     boolean isTerminated() {
/* 215 */       return (this.subscribers == TERMINATED);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 220 */       if (Operators.setOnce(S, this, s)) {
/* 221 */         if (s instanceof Fuseable.QueueSubscription) {
/* 222 */           Fuseable.QueueSubscription<T> f = (Fuseable.QueueSubscription<T>)s;
/*     */ 
/*     */           
/* 225 */           int m = f.requestFusion(7);
/* 226 */           if (m == 1) {
/* 227 */             this.sourceMode = m;
/* 228 */             this.queue = (Queue<T>)f;
/* 229 */             drain();
/*     */             return;
/*     */           } 
/* 232 */           if (m == 2) {
/* 233 */             this.sourceMode = m;
/* 234 */             this.queue = (Queue<T>)f;
/* 235 */             s.request(Operators.unboundedOrPrefetch(this.prefetch));
/*     */             
/*     */             return;
/*     */           } 
/*     */         } 
/* 240 */         this.queue = this.parent.queueSupplier.get();
/*     */         
/* 242 */         s.request(Operators.unboundedOrPrefetch(this.prefetch));
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 248 */       if (this.done) {
/* 249 */         if (t != null) {
/* 250 */           Operators.onNextDropped(t, currentContext());
/*     */         }
/*     */         return;
/*     */       } 
/* 254 */       if (this.sourceMode == 2) {
/* 255 */         drain();
/*     */         
/*     */         return;
/*     */       } 
/* 259 */       if (!this.queue.offer(t)) {
/* 260 */         Throwable ex = Operators.onOperatorError(this.s, 
/* 261 */             Exceptions.failWithOverflow("Queue is full: Reactive Streams source doesn't respect backpressure"), t, currentContext());
/* 262 */         if (!Exceptions.addThrowable(ERROR, this, ex)) {
/* 263 */           Operators.onErrorDroppedMulticast(ex, (InnerProducer<?>[])this.subscribers);
/*     */           return;
/*     */         } 
/* 266 */         this.done = true;
/*     */       } 
/* 268 */       drain();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 273 */       if (this.done) {
/* 274 */         Operators.onErrorDroppedMulticast(t, (InnerProducer<?>[])this.subscribers);
/*     */         return;
/*     */       } 
/* 277 */       if (Exceptions.addThrowable(ERROR, this, t)) {
/* 278 */         this.done = true;
/* 279 */         drain();
/*     */       } else {
/*     */         
/* 282 */         Operators.onErrorDroppedMulticast(t, (InnerProducer<?>[])this.subscribers);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 288 */       if (this.done) {
/*     */         return;
/*     */       }
/* 291 */       this.done = true;
/* 292 */       drain();
/*     */     }
/*     */ 
/*     */     
/*     */     public void dispose() {
/* 297 */       if (SUBSCRIBERS.get(this) == TERMINATED) {
/*     */         return;
/*     */       }
/* 300 */       if (FluxPublish.CONNECTION.compareAndSet(this.parent, this, null)) {
/* 301 */         Operators.terminate(S, this);
/* 302 */         if (WIP.getAndIncrement(this) != 0) {
/*     */           return;
/*     */         }
/* 305 */         disconnectAction();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     void disconnectAction() {
/* 311 */       FluxPublish.PubSubInner[] arrayOfPubSubInner = SUBSCRIBERS.getAndSet(this, CANCELLED);
/* 312 */       if (arrayOfPubSubInner.length > 0) {
/* 313 */         this.queue.clear();
/* 314 */         CancellationException ex = new CancellationException("Disconnected");
/*     */         
/* 316 */         for (FluxPublish.PubSubInner<T> inner : arrayOfPubSubInner) {
/* 317 */           inner.actual.onError(ex);
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*     */     boolean add(FluxPublish.PublishInner<T> inner) {
/*     */       while (true) {
/* 324 */         FluxPublish.PubSubInner<T>[] a = this.subscribers;
/* 325 */         if (a == TERMINATED) {
/* 326 */           return false;
/*     */         }
/* 328 */         int n = a.length;
/* 329 */         FluxPublish.PubSubInner[] arrayOfPubSubInner = new FluxPublish.PubSubInner[n + 1];
/* 330 */         System.arraycopy(a, 0, arrayOfPubSubInner, 0, n);
/* 331 */         arrayOfPubSubInner[n] = inner;
/* 332 */         if (SUBSCRIBERS.compareAndSet(this, a, arrayOfPubSubInner))
/* 333 */           return true; 
/*     */       } 
/*     */     }
/*     */     
/*     */     public void remove(FluxPublish.PubSubInner<T> inner) {
/*     */       FluxPublish.PubSubInner<T>[] a;
/*     */       FluxPublish.PubSubInner[] arrayOfPubSubInner;
/*     */       do {
/* 341 */         a = this.subscribers;
/* 342 */         if (a == TERMINATED || a == CANCELLED) {
/*     */           return;
/*     */         }
/* 345 */         int n = a.length;
/* 346 */         int j = -1;
/* 347 */         for (int i = 0; i < n; i++) {
/* 348 */           if (a[i] == inner) {
/* 349 */             j = i;
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/* 354 */         if (j < 0) {
/*     */           return;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 360 */         if (n == 1) {
/* 361 */           arrayOfPubSubInner = CANCELLED;
/*     */         } else {
/*     */           
/* 364 */           arrayOfPubSubInner = new FluxPublish.PubSubInner[n - 1];
/* 365 */           System.arraycopy(a, 0, arrayOfPubSubInner, 0, j);
/* 366 */           System.arraycopy(a, j + 1, arrayOfPubSubInner, j, n - j - 1);
/*     */         } 
/* 368 */       } while (!SUBSCRIBERS.compareAndSet(this, a, arrayOfPubSubInner));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     FluxPublish.PubSubInner<T>[] terminate() {
/* 378 */       return (FluxPublish.PubSubInner<T>[])SUBSCRIBERS.getAndSet(this, TERMINATED);
/*     */     }
/*     */     
/*     */     boolean tryConnect() {
/* 382 */       return (this.connected == 0 && CONNECTED.compareAndSet(this, 0, 1));
/*     */     }
/*     */     
/*     */     final void drain() {
/* 386 */       if (WIP.getAndIncrement(this) != 0) {
/*     */         return;
/*     */       }
/*     */       
/* 390 */       int missed = 1;
/*     */ 
/*     */       
/*     */       while (true) {
/* 394 */         boolean d = this.done;
/*     */         
/* 396 */         Queue<T> q = this.queue;
/*     */         
/* 398 */         boolean empty = (q == null || q.isEmpty());
/*     */         
/* 400 */         if (checkTerminated(d, empty)) {
/*     */           return;
/*     */         }
/*     */         
/* 404 */         FluxPublish.PubSubInner<T>[] a = this.subscribers;
/*     */         
/* 406 */         if (a != CANCELLED && !empty) {
/* 407 */           long maxRequested = Long.MAX_VALUE;
/*     */           
/* 409 */           int len = a.length;
/* 410 */           int cancel = 0;
/*     */           
/* 412 */           for (FluxPublish.PubSubInner<T> inner : a) {
/* 413 */             long r = inner.requested;
/* 414 */             if (r >= 0L) {
/* 415 */               maxRequested = Math.min(maxRequested, r);
/*     */             } else {
/*     */               
/* 418 */               cancel++;
/*     */             } 
/*     */           } 
/*     */           
/* 422 */           if (len == cancel) {
/*     */             T v;
/*     */             
/*     */             try {
/* 426 */               v = q.poll();
/*     */             }
/* 428 */             catch (Throwable ex) {
/* 429 */               Exceptions.addThrowable(ERROR, this, 
/*     */                   
/* 431 */                   Operators.onOperatorError(this.s, ex, currentContext()));
/* 432 */               d = true;
/* 433 */               v = null;
/*     */             } 
/* 435 */             if (checkTerminated(d, (v == null))) {
/*     */               return;
/*     */             }
/* 438 */             if (this.sourceMode != 1) {
/* 439 */               this.s.request(1L);
/*     */             }
/*     */             
/*     */             continue;
/*     */           } 
/* 444 */           int e = 0;
/*     */           
/* 446 */           while (e < maxRequested && cancel != Integer.MIN_VALUE) {
/* 447 */             T v; d = this.done;
/*     */ 
/*     */             
/*     */             try {
/* 451 */               v = q.poll();
/*     */             }
/* 453 */             catch (Throwable ex) {
/* 454 */               Exceptions.addThrowable(ERROR, this, 
/*     */                   
/* 456 */                   Operators.onOperatorError(this.s, ex, currentContext()));
/* 457 */               d = true;
/* 458 */               v = null;
/*     */             } 
/*     */             
/* 461 */             empty = (v == null);
/*     */             
/* 463 */             if (checkTerminated(d, empty)) {
/*     */               return;
/*     */             }
/*     */             
/* 467 */             if (empty) {
/*     */               
/* 469 */               if (this.sourceMode == 1) {
/* 470 */                 this.done = true;
/* 471 */                 checkTerminated(true, true);
/*     */               } 
/*     */               
/*     */               break;
/*     */             } 
/* 476 */             for (FluxPublish.PubSubInner<T> inner : a) {
/* 477 */               inner.actual.onNext(v);
/* 478 */               if (Operators.producedCancellable(FluxPublish.PubSubInner.REQUESTED, inner, 1L) == Long.MIN_VALUE)
/*     */               {
/*     */                 
/* 481 */                 cancel = Integer.MIN_VALUE;
/*     */               }
/*     */             } 
/*     */             
/* 485 */             e++;
/*     */           } 
/*     */           
/* 488 */           if (e != 0 && this.sourceMode != 1) {
/* 489 */             this.s.request(e);
/*     */           }
/*     */           
/* 492 */           if (maxRequested != 0L && !empty) {
/*     */             continue;
/*     */           }
/*     */         }
/* 496 */         else if (this.sourceMode == 1) {
/* 497 */           this.done = true;
/* 498 */           if (checkTerminated(true, empty)) {
/*     */             break;
/*     */           }
/*     */         } 
/*     */         
/* 503 */         missed = WIP.addAndGet(this, -missed);
/* 504 */         if (missed == 0) {
/*     */           break;
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*     */     boolean checkTerminated(boolean d, boolean empty) {
/* 511 */       if (this.s == Operators.cancelledSubscription()) {
/* 512 */         disconnectAction();
/* 513 */         return true;
/*     */       } 
/* 515 */       if (d) {
/* 516 */         Throwable e = this.error;
/* 517 */         if (e != null && e != Exceptions.TERMINATED) {
/* 518 */           FluxPublish.CONNECTION.compareAndSet(this.parent, this, null);
/* 519 */           e = Exceptions.terminate(ERROR, this);
/* 520 */           this.queue.clear();
/* 521 */           for (FluxPublish.PubSubInner<T> inner : terminate()) {
/* 522 */             inner.actual.onError(e);
/*     */           }
/* 524 */           return true;
/*     */         } 
/* 526 */         if (empty) {
/* 527 */           FluxPublish.CONNECTION.compareAndSet(this.parent, this, null);
/* 528 */           for (FluxPublish.PubSubInner<T> inner : terminate()) {
/* 529 */             inner.actual.onComplete();
/*     */           }
/* 531 */           return true;
/*     */         } 
/*     */       } 
/* 534 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public Stream<? extends Scannable> inners() {
/* 539 */       return Stream.of((Scannable[])this.subscribers);
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/* 544 */       return Operators.multiSubscribersContext((InnerProducer<?>[])this.subscribers);
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 550 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 551 */       if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(this.prefetch); 
/* 552 */       if (key == Scannable.Attr.ERROR) return this.error; 
/* 553 */       if (key == Scannable.Attr.BUFFERED) return Integer.valueOf((this.queue != null) ? this.queue.size() : 0); 
/* 554 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(isTerminated()); 
/* 555 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf((this.s == Operators.cancelledSubscription())); 
/* 556 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 558 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isDisposed() {
/* 563 */       return (this.s == Operators.cancelledSubscription() || this.done);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static abstract class PubSubInner<T>
/*     */     implements InnerProducer<T>
/*     */   {
/*     */     final CoreSubscriber<? super T> actual;
/*     */     
/*     */     volatile long requested;
/*     */     
/* 575 */     static final AtomicLongFieldUpdater<PubSubInner> REQUESTED = AtomicLongFieldUpdater.newUpdater(PubSubInner.class, "requested");
/*     */     
/*     */     PubSubInner(CoreSubscriber<? super T> actual) {
/* 578 */       this.actual = actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public final void request(long n) {
/* 583 */       if (Operators.validate(n)) {
/* 584 */         Operators.addCapCancellable(REQUESTED, this, n);
/* 585 */         drainParent();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public final void cancel() {
/* 591 */       long r = this.requested;
/* 592 */       if (r != Long.MIN_VALUE) {
/* 593 */         r = REQUESTED.getAndSet(this, Long.MIN_VALUE);
/* 594 */         if (r != Long.MIN_VALUE) {
/* 595 */           removeAndDrainParent();
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*     */     final boolean isCancelled() {
/* 601 */       return (this.requested == Long.MIN_VALUE);
/*     */     }
/*     */ 
/*     */     
/*     */     public final CoreSubscriber<? super T> actual() {
/* 606 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 612 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(isCancelled()); 
/* 613 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf(isCancelled() ? 0L : this.requested); 
/* 614 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 616 */       return super.scanUnsafe(key);
/*     */     }
/*     */     
/*     */     abstract void drainParent();
/*     */     
/*     */     abstract void removeAndDrainParent(); }
/*     */   
/*     */   static final class PublishInner<T> extends PubSubInner<T> {
/*     */     FluxPublish.PublishSubscriber<T> parent;
/*     */     
/*     */     PublishInner(CoreSubscriber<? super T> actual) {
/* 627 */       super(actual);
/*     */     }
/*     */ 
/*     */     
/*     */     void drainParent() {
/* 632 */       FluxPublish.PublishSubscriber<T> p = this.parent;
/* 633 */       if (p != null) {
/* 634 */         p.drain();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     void removeAndDrainParent() {
/* 640 */       FluxPublish.PublishSubscriber<T> p = this.parent;
/* 641 */       if (p != null) {
/* 642 */         p.remove(this);
/* 643 */         p.drain();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 650 */       if (key == Scannable.Attr.PARENT) return this.parent; 
/* 651 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf((this.parent != null && this.parent.isTerminated())); 
/* 652 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 654 */       return super.scanUnsafe(key);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\FluxPublish.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */