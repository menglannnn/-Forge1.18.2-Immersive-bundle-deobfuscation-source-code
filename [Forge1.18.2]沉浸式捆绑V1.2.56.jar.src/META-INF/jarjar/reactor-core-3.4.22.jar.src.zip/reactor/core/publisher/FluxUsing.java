/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Function;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxUsing<T, S>
/*     */   extends Flux<T>
/*     */   implements Fuseable, SourceProducer<T>
/*     */ {
/*     */   final Callable<S> resourceSupplier;
/*     */   final Function<? super S, ? extends Publisher<? extends T>> sourceFactory;
/*     */   final Consumer<? super S> resourceCleanup;
/*     */   final boolean eager;
/*     */   
/*     */   FluxUsing(Callable<S> resourceSupplier, Function<? super S, ? extends Publisher<? extends T>> sourceFactory, Consumer<? super S> resourceCleanup, boolean eager) {
/*  62 */     this
/*  63 */       .resourceSupplier = Objects.<Callable<S>>requireNonNull(resourceSupplier, "resourceSupplier");
/*  64 */     this.sourceFactory = Objects.<Function<? super S, ? extends Publisher<? extends T>>>requireNonNull(sourceFactory, "sourceFactory");
/*  65 */     this.resourceCleanup = Objects.<Consumer<? super S>>requireNonNull(resourceCleanup, "resourceCleanup");
/*  66 */     this.eager = eager;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super T> actual) {
/*     */     S resource;
/*     */     Publisher<? extends T> p;
/*     */     try {
/*  75 */       resource = this.resourceSupplier.call();
/*     */     }
/*  77 */     catch (Throwable e) {
/*  78 */       Operators.error((Subscriber<?>)actual, Operators.onOperatorError(e, actual.currentContext()));
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*     */     try {
/*  85 */       p = Objects.<Publisher<? extends T>>requireNonNull(this.sourceFactory.apply(resource), "The sourceFactory returned a null value");
/*     */     
/*     */     }
/*  88 */     catch (Throwable e) {
/*  89 */       Throwable _e = Operators.onOperatorError(e, actual.currentContext());
/*     */       try {
/*  91 */         this.resourceCleanup.accept(resource);
/*     */       }
/*  93 */       catch (Throwable ex) {
/*  94 */         _e = Exceptions.addSuppressed(ex, _e);
/*     */       } 
/*     */       
/*  97 */       Operators.error((Subscriber<?>)actual, _e);
/*     */       
/*     */       return;
/*     */     } 
/* 101 */     if (p instanceof Fuseable) {
/* 102 */       from(p).subscribe(new UsingFuseableSubscriber<>(actual, this.resourceCleanup, resource, this.eager));
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 107 */     else if (actual instanceof Fuseable.ConditionalSubscriber) {
/* 108 */       from(p).subscribe(new UsingConditionalSubscriber<>((Fuseable.ConditionalSubscriber)actual, this.resourceCleanup, resource, this.eager));
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 114 */       from(p).subscribe(new UsingSubscriber<>(actual, this.resourceCleanup, resource, this.eager));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/* 121 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 122 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   static final class UsingSubscriber<T, S>
/*     */     implements InnerOperator<T, T>, Fuseable.QueueSubscription<T>
/*     */   {
/*     */     final CoreSubscriber<? super T> actual;
/*     */     
/*     */     final Consumer<? super S> resourceCleanup;
/*     */     
/*     */     final S resource;
/*     */     
/*     */     final boolean eager;
/*     */     
/*     */     Subscription s;
/*     */     
/*     */     volatile int wip;
/*     */     
/* 141 */     static final AtomicIntegerFieldUpdater<UsingSubscriber> WIP = AtomicIntegerFieldUpdater.newUpdater(UsingSubscriber.class, "wip");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     UsingSubscriber(CoreSubscriber<? super T> actual, Consumer<? super S> resourceCleanup, S resource, boolean eager) {
/* 147 */       this.actual = actual;
/* 148 */       this.resourceCleanup = resourceCleanup;
/* 149 */       this.resource = resource;
/* 150 */       this.eager = eager;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 156 */       if (key == Scannable.Attr.TERMINATED || key == Scannable.Attr.CANCELLED) return Boolean.valueOf((this.wip == 1)); 
/* 157 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 158 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 160 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 165 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 170 */       this.s.request(n);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 175 */       if (WIP.compareAndSet(this, 0, 1)) {
/* 176 */         this.s.cancel();
/*     */         
/* 178 */         cleanup();
/*     */       } 
/*     */     }
/*     */     
/*     */     void cleanup() {
/*     */       try {
/* 184 */         this.resourceCleanup.accept(this.resource);
/*     */       }
/* 186 */       catch (Throwable e) {
/* 187 */         Operators.onErrorDropped(e, this.actual.currentContext());
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 193 */       if (Operators.validate(this.s, s)) {
/* 194 */         this.s = s;
/*     */         
/* 196 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 202 */       this.actual.onNext(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 207 */       if (this.eager && WIP.compareAndSet(this, 0, 1)) {
/*     */         try {
/* 209 */           this.resourceCleanup.accept(this.resource);
/*     */         }
/* 211 */         catch (Throwable e) {
/* 212 */           Throwable _e = Operators.onOperatorError(e, this.actual.currentContext());
/* 213 */           t = Exceptions.addSuppressed(_e, t);
/*     */         } 
/*     */       }
/*     */       
/* 217 */       this.actual.onError(t);
/*     */       
/* 219 */       if (!this.eager && WIP.compareAndSet(this, 0, 1)) {
/* 220 */         cleanup();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 226 */       if (this.eager && WIP.compareAndSet(this, 0, 1)) {
/*     */         try {
/* 228 */           this.resourceCleanup.accept(this.resource);
/*     */         }
/* 230 */         catch (Throwable e) {
/* 231 */           this.actual.onError(Operators.onOperatorError(e, this.actual.currentContext()));
/*     */           
/*     */           return;
/*     */         } 
/*     */       }
/* 236 */       this.actual.onComplete();
/*     */       
/* 238 */       if (!this.eager && WIP.compareAndSet(this, 0, 1)) {
/* 239 */         cleanup();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public int requestFusion(int requestedMode) {
/* 245 */       return 0;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void clear() {}
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isEmpty() {
/* 256 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public T poll() {
/* 262 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 267 */       return 0;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class UsingFuseableSubscriber<T, S>
/*     */     implements InnerOperator<T, T>, Fuseable.QueueSubscription<T>
/*     */   {
/*     */     final CoreSubscriber<? super T> actual;
/*     */     
/*     */     final Consumer<? super S> resourceCleanup;
/*     */     
/*     */     final S resource;
/*     */     
/*     */     final boolean eager;
/*     */     
/*     */     Fuseable.QueueSubscription<T> s;
/*     */     
/*     */     volatile int wip;
/*     */     
/* 287 */     static final AtomicIntegerFieldUpdater<UsingFuseableSubscriber> WIP = AtomicIntegerFieldUpdater.newUpdater(UsingFuseableSubscriber.class, "wip");
/*     */ 
/*     */ 
/*     */     
/*     */     int mode;
/*     */ 
/*     */ 
/*     */     
/*     */     UsingFuseableSubscriber(CoreSubscriber<? super T> actual, Consumer<? super S> resourceCleanup, S resource, boolean eager) {
/* 296 */       this.actual = actual;
/* 297 */       this.resourceCleanup = resourceCleanup;
/* 298 */       this.resource = resource;
/* 299 */       this.eager = eager;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 305 */       if (key == Scannable.Attr.TERMINATED || key == Scannable.Attr.CANCELLED)
/* 306 */         return Boolean.valueOf((this.wip == 1)); 
/* 307 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 308 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 310 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 315 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 320 */       this.s.request(n);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 325 */       if (WIP.compareAndSet(this, 0, 1)) {
/* 326 */         this.s.cancel();
/*     */         
/* 328 */         cleanup();
/*     */       } 
/*     */     }
/*     */     
/*     */     void cleanup() {
/*     */       try {
/* 334 */         this.resourceCleanup.accept(this.resource);
/*     */       }
/* 336 */       catch (Throwable e) {
/* 337 */         Operators.onErrorDropped(e, this.actual.currentContext());
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 344 */       if (Operators.validate((Subscription)this.s, s)) {
/* 345 */         this.s = (Fuseable.QueueSubscription<T>)s;
/*     */         
/* 347 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 353 */       this.actual.onNext(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 358 */       if (this.eager && WIP.compareAndSet(this, 0, 1)) {
/*     */         try {
/* 360 */           this.resourceCleanup.accept(this.resource);
/*     */         }
/* 362 */         catch (Throwable e) {
/* 363 */           Throwable _e = Operators.onOperatorError(e, this.actual.currentContext());
/* 364 */           t = Exceptions.addSuppressed(_e, t);
/*     */         } 
/*     */       }
/*     */       
/* 368 */       this.actual.onError(t);
/*     */       
/* 370 */       if (!this.eager && WIP.compareAndSet(this, 0, 1)) {
/* 371 */         cleanup();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 377 */       if (this.eager && WIP.compareAndSet(this, 0, 1)) {
/*     */         try {
/* 379 */           this.resourceCleanup.accept(this.resource);
/*     */         }
/* 381 */         catch (Throwable e) {
/* 382 */           this.actual.onError(Operators.onOperatorError(e, this.actual.currentContext()));
/*     */           
/*     */           return;
/*     */         } 
/*     */       }
/* 387 */       this.actual.onComplete();
/*     */       
/* 389 */       if (!this.eager && WIP.compareAndSet(this, 0, 1)) {
/* 390 */         cleanup();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void clear() {
/* 396 */       this.s.clear();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isEmpty() {
/* 401 */       return this.s.isEmpty();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public T poll() {
/* 407 */       T v = (T)this.s.poll();
/*     */       
/* 409 */       if (v == null && this.mode == 1 && 
/* 410 */         WIP.compareAndSet(this, 0, 1)) {
/* 411 */         this.resourceCleanup.accept(this.resource);
/*     */       }
/*     */       
/* 414 */       return v;
/*     */     }
/*     */ 
/*     */     
/*     */     public int requestFusion(int requestedMode) {
/* 419 */       int m = this.s.requestFusion(requestedMode);
/* 420 */       this.mode = m;
/* 421 */       return m;
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 426 */       return this.s.size();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static final class UsingConditionalSubscriber<T, S>
/*     */     implements Fuseable.ConditionalSubscriber<T>, InnerOperator<T, T>, Fuseable.QueueSubscription<T>
/*     */   {
/*     */     final Fuseable.ConditionalSubscriber<? super T> actual;
/*     */     
/*     */     final Consumer<? super S> resourceCleanup;
/*     */     
/*     */     final S resource;
/*     */     
/*     */     final boolean eager;
/*     */     
/*     */     Subscription s;
/*     */     
/*     */     volatile int wip;
/*     */     
/* 447 */     static final AtomicIntegerFieldUpdater<UsingConditionalSubscriber> WIP = AtomicIntegerFieldUpdater.newUpdater(UsingConditionalSubscriber.class, "wip");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     UsingConditionalSubscriber(Fuseable.ConditionalSubscriber<? super T> actual, Consumer<? super S> resourceCleanup, S resource, boolean eager) {
/* 454 */       this.actual = actual;
/* 455 */       this.resourceCleanup = resourceCleanup;
/* 456 */       this.resource = resource;
/* 457 */       this.eager = eager;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 463 */       if (key == Scannable.Attr.TERMINATED || key == Scannable.Attr.CANCELLED)
/* 464 */         return Boolean.valueOf((this.wip == 1)); 
/* 465 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 466 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 468 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 473 */       return (CoreSubscriber<? super T>)this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 478 */       this.s.request(n);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 483 */       if (WIP.compareAndSet(this, 0, 1)) {
/* 484 */         this.s.cancel();
/*     */         
/* 486 */         cleanup();
/*     */       } 
/*     */     }
/*     */     
/*     */     void cleanup() {
/*     */       try {
/* 492 */         this.resourceCleanup.accept(this.resource);
/*     */       }
/* 494 */       catch (Throwable e) {
/* 495 */         Operators.onErrorDropped(e, this.actual.currentContext());
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 501 */       if (Operators.validate(this.s, s)) {
/* 502 */         this.s = s;
/*     */         
/* 504 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 510 */       this.actual.onNext(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean tryOnNext(T t) {
/* 515 */       return this.actual.tryOnNext(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 520 */       if (this.eager && WIP.compareAndSet(this, 0, 1)) {
/*     */         try {
/* 522 */           this.resourceCleanup.accept(this.resource);
/*     */         }
/* 524 */         catch (Throwable e) {
/* 525 */           Throwable _e = Operators.onOperatorError(e, this.actual.currentContext());
/* 526 */           t = Exceptions.addSuppressed(_e, t);
/*     */         } 
/*     */       }
/*     */       
/* 530 */       this.actual.onError(t);
/*     */       
/* 532 */       if (!this.eager && WIP.compareAndSet(this, 0, 1)) {
/* 533 */         cleanup();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 539 */       if (this.eager && WIP.compareAndSet(this, 0, 1)) {
/*     */         try {
/* 541 */           this.resourceCleanup.accept(this.resource);
/*     */         }
/* 543 */         catch (Throwable e) {
/* 544 */           this.actual.onError(Operators.onOperatorError(e, this.actual.currentContext()));
/*     */           
/*     */           return;
/*     */         } 
/*     */       }
/* 549 */       this.actual.onComplete();
/*     */       
/* 551 */       if (!this.eager && WIP.compareAndSet(this, 0, 1)) {
/* 552 */         cleanup();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public int requestFusion(int requestedMode) {
/* 558 */       return 0;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void clear() {}
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isEmpty() {
/* 569 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public T poll() {
/* 575 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 580 */       return 0;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\FluxUsing.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */