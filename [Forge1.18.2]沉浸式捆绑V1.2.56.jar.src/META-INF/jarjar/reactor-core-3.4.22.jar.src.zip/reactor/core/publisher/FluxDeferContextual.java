/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import java.util.function.Function;
/*    */ import org.reactivestreams.Publisher;
/*    */ import org.reactivestreams.Subscriber;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Scannable;
/*    */ import reactor.util.context.Context;
/*    */ import reactor.util.context.ContextView;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class FluxDeferContextual<T>
/*    */   extends Flux<T>
/*    */   implements SourceProducer<T>
/*    */ {
/*    */   final Function<ContextView, ? extends Publisher<? extends T>> contextualPublisherFactory;
/*    */   
/*    */   FluxDeferContextual(Function<ContextView, ? extends Publisher<? extends T>> contextualPublisherFactory) {
/* 40 */     this.contextualPublisherFactory = Objects.<Function<ContextView, ? extends Publisher<? extends T>>>requireNonNull(contextualPublisherFactory, "contextualPublisherFactory");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void subscribe(CoreSubscriber<? super T> actual) {
/*    */     Publisher<? extends T> p;
/* 47 */     Context ctx = actual.currentContext();
/*    */     try {
/* 49 */       p = Objects.<Publisher<? extends T>>requireNonNull(this.contextualPublisherFactory.apply(ctx.readOnly()), "The Publisher returned by the contextualPublisherFactory is null");
/*    */     
/*    */     }
/* 52 */     catch (Throwable e) {
/* 53 */       Operators.error((Subscriber<?>)actual, Operators.onOperatorError(e, ctx));
/*    */       
/*    */       return;
/*    */     } 
/* 57 */     from(p).subscribe(actual);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 63 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 64 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\FluxDeferContextual.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */