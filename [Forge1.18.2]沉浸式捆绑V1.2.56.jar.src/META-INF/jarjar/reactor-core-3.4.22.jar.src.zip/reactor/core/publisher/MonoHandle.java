/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import java.util.function.BiConsumer;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Scannable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MonoHandle<T, R>
/*    */   extends InternalMonoOperator<T, R>
/*    */ {
/*    */   final BiConsumer<? super T, SynchronousSink<R>> handler;
/*    */   
/*    */   MonoHandle(Mono<? extends T> source, BiConsumer<? super T, SynchronousSink<R>> handler) {
/* 38 */     super(source);
/* 39 */     this.handler = Objects.<BiConsumer<? super T, SynchronousSink<R>>>requireNonNull(handler, "handler");
/*    */   }
/*    */ 
/*    */   
/*    */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super R> actual) {
/* 44 */     return new FluxHandle.HandleSubscriber<>(actual, this.handler);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 49 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 50 */     return super.scanUnsafe(key);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\MonoHandle.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */