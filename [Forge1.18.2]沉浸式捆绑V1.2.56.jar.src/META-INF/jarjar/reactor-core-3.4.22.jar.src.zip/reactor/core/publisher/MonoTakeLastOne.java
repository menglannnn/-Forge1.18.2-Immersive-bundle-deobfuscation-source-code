/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Objects;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MonoTakeLastOne<T>
/*     */   extends MonoFromFluxOperator<T, T>
/*     */   implements Fuseable
/*     */ {
/*     */   final T defaultValue;
/*     */   
/*     */   MonoTakeLastOne(Flux<? extends T> source) {
/*  38 */     super(source);
/*  39 */     this.defaultValue = null;
/*     */   }
/*     */   
/*     */   MonoTakeLastOne(Flux<? extends T> source, T defaultValue) {
/*  43 */     super(source);
/*  44 */     this.defaultValue = Objects.requireNonNull(defaultValue, "defaultValue");
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/*  49 */     return new TakeLastOneSubscriber<>(actual, this.defaultValue, true);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  54 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  55 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class TakeLastOneSubscriber<T>
/*     */     extends Operators.MonoSubscriber<T, T>
/*     */   {
/*     */     final boolean mustEmit;
/*     */     
/*     */     final T defaultValue;
/*     */     Subscription s;
/*     */     
/*     */     TakeLastOneSubscriber(CoreSubscriber<? super T> actual, @Nullable T defaultValue, boolean mustEmit) {
/*  68 */       super(actual);
/*  69 */       this.defaultValue = defaultValue;
/*  70 */       this.mustEmit = mustEmit;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/*  75 */       if (Operators.validate(this.s, s)) {
/*  76 */         this.s = s;
/*     */         
/*  78 */         this.actual.onSubscribe(this);
/*     */         
/*  80 */         s.request(Long.MAX_VALUE);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/*  88 */       if (key == Scannable.Attr.PARENT) return this.s; 
/*  89 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/*  91 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/*  96 */       T old = this.value;
/*  97 */       setValue(t);
/*  98 */       Operators.onDiscard(old, this.actual.currentContext());
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 103 */       T v = this.value;
/* 104 */       if (v == null) {
/* 105 */         if (this.mustEmit) {
/* 106 */           if (this.defaultValue != null) {
/* 107 */             complete(this.defaultValue);
/*     */           } else {
/*     */             
/* 110 */             this.actual.onError(Operators.onOperatorError(new NoSuchElementException("Flux#last() didn't observe any onNext signal"), this.actual
/*     */                   
/* 112 */                   .currentContext()));
/*     */           } 
/*     */         } else {
/*     */           
/* 116 */           this.actual.onComplete();
/*     */         } 
/*     */         return;
/*     */       } 
/* 120 */       complete(v);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 125 */       super.cancel();
/* 126 */       this.s.cancel();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\MonoTakeLastOne.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */