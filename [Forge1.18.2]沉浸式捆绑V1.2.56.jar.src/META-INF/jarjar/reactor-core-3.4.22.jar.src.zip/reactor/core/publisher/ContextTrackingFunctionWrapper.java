/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.util.function.Function;
/*    */ import org.reactivestreams.Publisher;
/*    */ import org.reactivestreams.Subscriber;
/*    */ import reactor.core.CorePublisher;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.util.context.Context;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ContextTrackingFunctionWrapper<T, V>
/*    */   implements Function<Publisher<T>, CorePublisher<V>>
/*    */ {
/*    */   static final String CONTEXT_MARKER_PREFIX = "reactor.core.context.marker.";
/*    */   final Function<? super Publisher<T>, ? extends Publisher<V>> transformer;
/*    */   final String marker;
/*    */   
/*    */   ContextTrackingFunctionWrapper(Function<? super Publisher<T>, ? extends Publisher<V>> transformer) {
/* 42 */     this(transformer, transformer.toString());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   ContextTrackingFunctionWrapper(Function<? super Publisher<T>, ? extends Publisher<V>> transformer, String marker) {
/* 49 */     this.transformer = transformer;
/* 50 */     this.marker = marker;
/*    */   }
/*    */ 
/*    */   
/*    */   public CorePublisher<V> apply(Publisher<T> source) {
/* 55 */     final String key = "reactor.core.context.marker." + System.identityHashCode(source);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 67 */     source = Operators.<T, T>liftPublisher((p, actual) -> { Context ctx = actual.currentContext(); if (!ctx.hasKey(key)) throw new IllegalStateException("Context loss after applying " + this.marker);  Context newContext = ctx.delete(key); return new FluxContextWrite.ContextWriteSubscriber(actual, newContext); }).apply(source);
/*    */     
/* 69 */     final Publisher<V> result = this.transformer.apply(source);
/*    */ 
/*    */     
/* 72 */     return new CorePublisher<V>()
/*    */       {
/*    */         public void subscribe(CoreSubscriber<? super V> actual) {
/* 75 */           Context ctx = actual.currentContext().put(key, Boolean.valueOf(true));
/* 76 */           CoreSubscriber<V> subscriber = new FluxContextWrite.ContextWriteSubscriber<>(actual, ctx);
/*    */           
/* 78 */           if (result instanceof CorePublisher) {
/* 79 */             ((CorePublisher)result).subscribe(subscriber);
/*    */           } else {
/*    */             
/* 82 */             result.subscribe((Subscriber)subscriber);
/*    */           } 
/*    */         }
/*    */ 
/*    */         
/*    */         public void subscribe(Subscriber<? super V> subscriber) {
/* 88 */           subscribe(Operators.toCoreSubscriber(subscriber));
/*    */         }
/*    */       };
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\ContextTrackingFunctionWrapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */