/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import reactor.util.context.Context;
/*    */ import reactor.util.context.ContextView;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface SynchronousSink<T>
/*    */ {
/*    */   void complete();
/*    */   
/*    */   @Deprecated
/*    */   Context currentContext();
/*    */   
/*    */   default ContextView contextView() {
/* 69 */     return (ContextView)currentContext();
/*    */   }
/*    */   
/*    */   void error(Throwable paramThrowable);
/*    */   
/*    */   void next(T paramT);
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\SynchronousSink.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */