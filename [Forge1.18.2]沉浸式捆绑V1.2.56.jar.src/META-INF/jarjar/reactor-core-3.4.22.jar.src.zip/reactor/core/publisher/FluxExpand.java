/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.Deque;
/*     */ import java.util.Objects;
/*     */ import java.util.Queue;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.function.Function;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CorePublisher;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.concurrent.Queues;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxExpand<T>
/*     */   extends InternalFluxOperator<T, T>
/*     */ {
/*     */   final boolean breadthFirst;
/*     */   final Function<? super T, ? extends Publisher<? extends T>> expander;
/*     */   final int capacityHint;
/*     */   
/*     */   FluxExpand(Flux<T> source, Function<? super T, ? extends Publisher<? extends T>> expander, boolean breadthFirst, int capacityHint) {
/*  58 */     super(source);
/*  59 */     this.expander = expander;
/*  60 */     this.breadthFirst = breadthFirst;
/*  61 */     this.capacityHint = capacityHint;
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> s) {
/*  66 */     if (this.breadthFirst) {
/*  67 */       ExpandBreathSubscriber<T> parent = new ExpandBreathSubscriber<>(s, this.expander, this.capacityHint);
/*     */       
/*  69 */       parent.queue.offer(this.source);
/*  70 */       s.onSubscribe(parent);
/*  71 */       parent.drainQueue();
/*     */     } else {
/*     */       
/*  74 */       ExpandDepthSubscription<T> parent = new ExpandDepthSubscription<>(s, this.expander, this.capacityHint);
/*     */       
/*  76 */       parent.source = this.source;
/*  77 */       s.onSubscribe(parent);
/*     */     } 
/*  79 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  84 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  85 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class ExpandBreathSubscriber<T>
/*     */     extends Operators.MultiSubscriptionSubscriber<T, T>
/*     */   {
/*     */     final Function<? super T, ? extends Publisher<? extends T>> expander;
/*     */     
/*     */     final Queue<Publisher<? extends T>> queue;
/*     */     
/*     */     volatile boolean active;
/*     */     volatile int wip;
/*  98 */     static final AtomicIntegerFieldUpdater<ExpandBreathSubscriber> WIP = AtomicIntegerFieldUpdater.newUpdater(ExpandBreathSubscriber.class, "wip");
/*     */ 
/*     */     
/*     */     long produced;
/*     */ 
/*     */     
/*     */     ExpandBreathSubscriber(CoreSubscriber<? super T> actual, Function<? super T, ? extends Publisher<? extends T>> expander, int capacityHint) {
/* 105 */       super(actual);
/* 106 */       this.expander = expander;
/* 107 */       this.queue = Queues.unbounded(capacityHint).get();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 112 */       set(s);
/*     */     }
/*     */     
/*     */     public void onNext(T t) {
/*     */       Publisher<? extends T> p;
/* 117 */       this.produced++;
/* 118 */       this.actual.onNext(t);
/*     */ 
/*     */       
/*     */       try {
/* 122 */         p = Objects.<Publisher<? extends T>>requireNonNull(this.expander.apply(t), "The expander returned a null Publisher");
/*     */       
/*     */       }
/* 125 */       catch (Throwable ex) {
/* 126 */         Exceptions.throwIfFatal(ex);
/* 127 */         super.cancel();
/* 128 */         this.actual.onError(ex);
/* 129 */         drainQueue();
/*     */         
/*     */         return;
/*     */       } 
/* 133 */       this.queue.offer(p);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 138 */       set(Operators.cancelledSubscription());
/* 139 */       super.cancel();
/* 140 */       this.actual.onError(t);
/* 141 */       drainQueue();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 146 */       this.active = false;
/* 147 */       drainQueue();
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 152 */       super.cancel();
/* 153 */       drainQueue();
/*     */     }
/*     */     
/*     */     void drainQueue() {
/* 157 */       if (WIP.getAndIncrement(this) == 0) {
/*     */         do {
/* 159 */           Queue<Publisher<? extends T>> q = this.queue;
/* 160 */           if (isCancelled()) {
/* 161 */             q.clear();
/*     */           
/*     */           }
/* 164 */           else if (!this.active) {
/* 165 */             if (q.isEmpty()) {
/* 166 */               set(Operators.cancelledSubscription());
/* 167 */               super.cancel();
/* 168 */               this.actual.onComplete();
/*     */             } else {
/*     */               
/* 171 */               Publisher<? extends T> p = q.poll();
/* 172 */               long c = this.produced;
/* 173 */               if (c != 0L) {
/* 174 */                 this.produced = 0L;
/* 175 */                 produced(c);
/*     */               } 
/*     */               
/* 178 */               this.active = true;
/* 179 */               p.subscribe((Subscriber)this);
/*     */             }
/*     */           
/*     */           }
/*     */         
/* 184 */         } while (WIP.decrementAndGet(this) != 0);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 191 */       if (key == Scannable.Attr.BUFFERED) return Integer.valueOf((this.queue != null) ? this.queue.size() : 0); 
/* 192 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 194 */       return super.scanUnsafe(key);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class ExpandDepthSubscription<T>
/*     */     implements InnerProducer<T>
/*     */   {
/*     */     final CoreSubscriber<? super T> actual;
/*     */     final Function<? super T, ? extends Publisher<? extends T>> expander;
/*     */     volatile Throwable error;
/* 205 */     static final AtomicReferenceFieldUpdater<ExpandDepthSubscription, Throwable> ERROR = AtomicReferenceFieldUpdater.newUpdater(ExpandDepthSubscription.class, Throwable.class, "error");
/*     */     
/*     */     volatile int active;
/*     */     
/* 209 */     static final AtomicIntegerFieldUpdater<ExpandDepthSubscription> ACTIVE = AtomicIntegerFieldUpdater.newUpdater(ExpandDepthSubscription.class, "active");
/*     */     
/*     */     volatile long requested;
/*     */     
/* 213 */     static final AtomicLongFieldUpdater<ExpandDepthSubscription> REQUESTED = AtomicLongFieldUpdater.newUpdater(ExpandDepthSubscription.class, "requested");
/*     */     
/*     */     volatile Object current;
/*     */     
/* 217 */     static final AtomicReferenceFieldUpdater<ExpandDepthSubscription, Object> CURRENT = AtomicReferenceFieldUpdater.newUpdater(ExpandDepthSubscription.class, Object.class, "current");
/*     */     
/*     */     volatile int wip;
/*     */     
/* 221 */     static final AtomicIntegerFieldUpdater<ExpandDepthSubscription> WIP = AtomicIntegerFieldUpdater.newUpdater(ExpandDepthSubscription.class, "wip");
/*     */     
/*     */     Deque<FluxExpand.ExpandDepthSubscriber<T>> subscriptionStack;
/*     */     
/*     */     volatile boolean cancelled;
/*     */     
/*     */     CorePublisher<? extends T> source;
/*     */     
/*     */     long consumed;
/*     */ 
/*     */     
/*     */     ExpandDepthSubscription(CoreSubscriber<? super T> actual, Function<? super T, ? extends Publisher<? extends T>> expander, int capacityHint) {
/* 233 */       this.actual = actual;
/* 234 */       this.expander = expander;
/* 235 */       this.subscriptionStack = new ArrayDeque<>(capacityHint);
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 240 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 245 */       if (Operators.validate(n)) {
/* 246 */         Operators.addCap(REQUESTED, this, n);
/* 247 */         drainQueue();
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 254 */       if (!this.cancelled) {
/* 255 */         Deque<FluxExpand.ExpandDepthSubscriber<T>> q; this.cancelled = true;
/*     */         
/* 257 */         synchronized (this) {
/* 258 */           q = this.subscriptionStack;
/* 259 */           this.subscriptionStack = null;
/*     */         } 
/*     */         
/* 262 */         if (q != null) {
/* 263 */           while (!q.isEmpty()) {
/* 264 */             ((FluxExpand.ExpandDepthSubscriber)q.poll()).dispose();
/*     */           }
/*     */         }
/*     */         
/* 268 */         Object o = CURRENT.getAndSet(this, this);
/* 269 */         if (o != this && o != null) {
/* 270 */           ((FluxExpand.ExpandDepthSubscriber)o).dispose();
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     FluxExpand.ExpandDepthSubscriber<T> pop() {
/* 277 */       synchronized (this) {
/* 278 */         Deque<FluxExpand.ExpandDepthSubscriber<T>> q = this.subscriptionStack;
/* 279 */         return (q != null) ? q.pollFirst() : null;
/*     */       } 
/*     */     }
/*     */     
/*     */     boolean push(FluxExpand.ExpandDepthSubscriber<T> subscriber) {
/* 284 */       synchronized (this) {
/* 285 */         Deque<FluxExpand.ExpandDepthSubscriber<T>> q = this.subscriptionStack;
/* 286 */         if (q != null) {
/* 287 */           q.offerFirst(subscriber);
/* 288 */           return true;
/*     */         } 
/* 290 */         return false;
/*     */       } 
/*     */     }
/*     */     
/*     */     boolean setCurrent(FluxExpand.ExpandDepthSubscriber<T> inner) {
/*     */       while (true) {
/* 296 */         Object o = CURRENT.get(this);
/* 297 */         if (o == this) {
/* 298 */           inner.dispose();
/* 299 */           return false;
/*     */         } 
/* 301 */         if (CURRENT.compareAndSet(this, o, inner)) {
/* 302 */           return true;
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*     */     void drainQueue() {
/* 308 */       if (WIP.getAndIncrement(this) != 0) {
/*     */         return;
/*     */       }
/*     */       
/* 312 */       int missed = 1;
/* 313 */       CoreSubscriber<? super T> coreSubscriber = this.actual;
/* 314 */       long e = this.consumed;
/*     */       
/*     */       while (true) {
/* 317 */         Object o = this.current;
/* 318 */         if (this.cancelled || o == this) {
/* 319 */           this.source = null;
/*     */           
/*     */           return;
/*     */         } 
/*     */         
/* 324 */         FluxExpand.ExpandDepthSubscriber<T> curr = (FluxExpand.ExpandDepthSubscriber<T>)o;
/* 325 */         CorePublisher<? extends T> corePublisher = this.source;
/*     */         
/* 327 */         if (curr == null && corePublisher != null) {
/* 328 */           this.source = null;
/* 329 */           ACTIVE.getAndIncrement(this);
/*     */           
/* 331 */           FluxExpand.ExpandDepthSubscriber<T> eds = new FluxExpand.ExpandDepthSubscriber<>(this);
/* 332 */           if (setCurrent(eds)) {
/* 333 */             corePublisher.subscribe((Subscriber)eds);
/*     */           } else {
/*     */             
/*     */             return;
/*     */           } 
/*     */         } else {
/* 339 */           if (curr == null) {
/*     */             return;
/*     */           }
/*     */           
/* 343 */           boolean currentDone = curr.done;
/* 344 */           T v = curr.value;
/*     */           
/* 346 */           boolean newSource = false;
/* 347 */           if (v != null && e != this.requested) {
/* 348 */             curr.value = null;
/* 349 */             coreSubscriber.onNext(v);
/* 350 */             e++;
/*     */             
/*     */             try {
/* 353 */               Publisher publisher = Objects.<Publisher>requireNonNull(this.expander.apply(v), "The expander returned a null Publisher");
/*     */             
/*     */             }
/* 356 */             catch (Throwable ex) {
/* 357 */               Exceptions.throwIfFatal(ex);
/* 358 */               corePublisher = null;
/* 359 */               curr.dispose();
/* 360 */               curr.done = true;
/* 361 */               currentDone = true;
/* 362 */               v = null;
/* 363 */               Exceptions.addThrowable(ERROR, this, ex);
/*     */             } 
/*     */             
/* 366 */             if (corePublisher != null && 
/* 367 */               push(curr)) {
/* 368 */               ACTIVE.getAndIncrement(this);
/* 369 */               curr = new FluxExpand.ExpandDepthSubscriber<>(this);
/* 370 */               if (setCurrent(curr)) {
/* 371 */                 corePublisher.subscribe((Subscriber)curr);
/* 372 */                 newSource = true;
/*     */               } else {
/*     */                 return;
/*     */               } 
/*     */             } 
/*     */           } 
/*     */ 
/*     */ 
/*     */           
/* 381 */           if (!newSource && 
/* 382 */             currentDone && v == null) {
/* 383 */             if (ACTIVE.decrementAndGet(this) == 0) {
/* 384 */               Throwable ex = Exceptions.terminate(ERROR, this);
/* 385 */               if (ex != null) {
/* 386 */                 coreSubscriber.onError(ex);
/*     */               } else {
/*     */                 
/* 389 */                 coreSubscriber.onComplete();
/*     */               } 
/*     */               return;
/*     */             } 
/* 393 */             curr = pop();
/* 394 */             if (curr != null && setCurrent(curr)) {
/* 395 */               curr.requestOne();
/*     */               
/*     */               continue;
/*     */             } 
/*     */             
/*     */             return;
/*     */           } 
/*     */         } 
/*     */         
/* 404 */         int w = this.wip;
/* 405 */         if (missed == w) {
/* 406 */           this.consumed = e;
/* 407 */           missed = WIP.addAndGet(this, -missed);
/* 408 */           if (missed == 0) {
/*     */             break;
/*     */           }
/*     */           continue;
/*     */         } 
/* 413 */         missed = w;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     void innerNext() {
/* 419 */       drainQueue();
/*     */     }
/*     */     
/*     */     void innerError(FluxExpand.ExpandDepthSubscriber inner, Throwable t) {
/* 423 */       Exceptions.addThrowable(ERROR, this, t);
/* 424 */       inner.done = true;
/* 425 */       drainQueue();
/*     */     }
/*     */     
/*     */     void innerComplete(FluxExpand.ExpandDepthSubscriber inner) {
/* 429 */       inner.done = true;
/* 430 */       drainQueue();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 436 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(this.cancelled); 
/* 437 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf(this.requested); 
/* 438 */       if (key == Scannable.Attr.ERROR) return this.error;
/*     */       
/* 440 */       return super.scanUnsafe(key);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class ExpandDepthSubscriber<T>
/*     */     implements InnerConsumer<T>
/*     */   {
/*     */     FluxExpand.ExpandDepthSubscription<T> parent;
/*     */     
/*     */     volatile boolean done;
/*     */     volatile T value;
/*     */     volatile Subscription s;
/* 453 */     static final AtomicReferenceFieldUpdater<ExpandDepthSubscriber, Subscription> S = AtomicReferenceFieldUpdater.newUpdater(ExpandDepthSubscriber.class, Subscription.class, "s");
/*     */     
/*     */     ExpandDepthSubscriber(FluxExpand.ExpandDepthSubscription<T> parent) {
/* 456 */       this.parent = parent;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 461 */       if (Operators.setOnce(S, this, s)) {
/* 462 */         s.request(1L);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 468 */       if (this.s != Operators.cancelledSubscription()) {
/* 469 */         this.value = t;
/* 470 */         this.parent.innerNext();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 476 */       if (this.s != Operators.cancelledSubscription()) {
/* 477 */         this.parent.innerError(this, t);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 483 */       if (this.s != Operators.cancelledSubscription()) {
/* 484 */         this.parent.innerComplete(this);
/*     */       }
/*     */     }
/*     */     
/*     */     void requestOne() {
/* 489 */       this.s.request(1L);
/*     */     }
/*     */     
/*     */     void dispose() {
/* 493 */       Operators.terminate(S, this);
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 499 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 500 */       if (key == Scannable.Attr.ACTUAL) return this.parent.actual; 
/* 501 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 502 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 504 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/* 509 */       return this.parent.actual().currentContext();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\FluxExpand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */