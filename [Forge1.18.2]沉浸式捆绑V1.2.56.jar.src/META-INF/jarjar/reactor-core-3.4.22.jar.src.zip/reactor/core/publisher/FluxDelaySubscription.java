/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.function.Consumer;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxDelaySubscription<T, U>
/*     */   extends InternalFluxOperator<T, T>
/*     */   implements Consumer<FluxDelaySubscription.DelaySubscriptionOtherSubscriber<T, U>>
/*     */ {
/*     */   final Publisher<U> other;
/*     */   
/*     */   FluxDelaySubscription(Flux<? extends T> source, Publisher<U> other) {
/*  42 */     super(source);
/*  43 */     this.other = Objects.<Publisher<U>>requireNonNull(other, "other");
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPrefetch() {
/*  48 */     return Integer.MAX_VALUE;
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/*  53 */     this.other.subscribe((Subscriber)new DelaySubscriptionOtherSubscriber<>(actual, this));
/*  54 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void accept(DelaySubscriptionOtherSubscriber<T, U> s) {
/*  59 */     this.source.subscribe(new DelaySubscriptionMainSubscriber<>(s.actual, s));
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  64 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  65 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class DelaySubscriptionOtherSubscriber<T, U>
/*     */     extends Operators.DeferredSubscription
/*     */     implements InnerOperator<U, T>
/*     */   {
/*     */     final Consumer<DelaySubscriptionOtherSubscriber<T, U>> source;
/*     */     
/*     */     final CoreSubscriber<? super T> actual;
/*     */     
/*     */     Subscription s;
/*     */     boolean done;
/*     */     
/*     */     DelaySubscriptionOtherSubscriber(CoreSubscriber<? super T> actual, Consumer<DelaySubscriptionOtherSubscriber<T, U>> source) {
/*  81 */       this.actual = actual;
/*  82 */       this.source = source;
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/*  87 */       return this.actual.currentContext();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/*  93 */       if (key == Scannable.Attr.PARENT) return this.s; 
/*  94 */       if (key == Scannable.Attr.ACTUAL) return this.actual; 
/*  95 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/*  96 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/*  98 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 103 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 108 */       this.s.cancel();
/* 109 */       super.cancel();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 114 */       if (Operators.validate(this.s, s)) {
/* 115 */         this.s = s;
/*     */         
/* 117 */         this.actual.onSubscribe(this);
/*     */         
/* 119 */         s.request(Long.MAX_VALUE);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(U t) {
/* 125 */       if (this.done) {
/*     */         return;
/*     */       }
/* 128 */       this.done = true;
/* 129 */       this.s.cancel();
/*     */       
/* 131 */       this.source.accept(this);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 136 */       if (this.done) {
/* 137 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*     */         return;
/*     */       } 
/* 140 */       this.done = true;
/* 141 */       this.actual.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 146 */       if (this.done) {
/*     */         return;
/*     */       }
/* 149 */       this.done = true;
/*     */       
/* 151 */       this.source.accept(this);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class DelaySubscriptionMainSubscriber<T>
/*     */     implements InnerConsumer<T>
/*     */   {
/*     */     final CoreSubscriber<? super T> actual;
/*     */     
/*     */     final FluxDelaySubscription.DelaySubscriptionOtherSubscriber<?, ?> arbiter;
/*     */     
/*     */     DelaySubscriptionMainSubscriber(CoreSubscriber<? super T> actual, FluxDelaySubscription.DelaySubscriptionOtherSubscriber<?, ?> arbiter) {
/* 164 */       this.actual = actual;
/* 165 */       this.arbiter = arbiter;
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/* 170 */       return this.arbiter.currentContext();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 176 */       if (key == Scannable.Attr.ACTUAL) return this.actual; 
/* 177 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 179 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 184 */       this.arbiter.set(s);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 189 */       this.actual.onNext(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 194 */       this.actual.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 199 */       this.actual.onComplete();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\FluxDelaySubscription.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */