/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class StrictSubscriber<T>
/*     */   implements Scannable, CoreSubscriber<T>, Subscription
/*     */ {
/*     */   final Subscriber<? super T> actual;
/*     */   volatile Subscription s;
/*  41 */   static final AtomicReferenceFieldUpdater<StrictSubscriber, Subscription> S = AtomicReferenceFieldUpdater.newUpdater(StrictSubscriber.class, Subscription.class, "s");
/*     */ 
/*     */ 
/*     */   
/*     */   volatile long requested;
/*     */ 
/*     */   
/*  48 */   static final AtomicLongFieldUpdater<StrictSubscriber> REQUESTED = AtomicLongFieldUpdater.newUpdater(StrictSubscriber.class, "requested");
/*     */ 
/*     */   
/*     */   volatile int wip;
/*     */   
/*  53 */   static final AtomicIntegerFieldUpdater<StrictSubscriber> WIP = AtomicIntegerFieldUpdater.newUpdater(StrictSubscriber.class, "wip");
/*     */ 
/*     */   
/*     */   volatile Throwable error;
/*     */   
/*  58 */   static final AtomicReferenceFieldUpdater<StrictSubscriber, Throwable> ERROR = AtomicReferenceFieldUpdater.newUpdater(StrictSubscriber.class, Throwable.class, "error");
/*     */ 
/*     */   
/*     */   volatile boolean done;
/*     */ 
/*     */   
/*     */   StrictSubscriber(Subscriber<? super T> actual) {
/*  65 */     this.actual = actual;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onSubscribe(Subscription s) {
/*  70 */     if (Operators.validate(this.s, s)) {
/*     */       
/*  72 */       this.actual.onSubscribe(this);
/*     */       
/*  74 */       if (Operators.setOnce(S, this, s)) {
/*  75 */         long r = REQUESTED.getAndSet(this, 0L);
/*  76 */         if (r != 0L) {
/*  77 */           s.request(r);
/*     */         }
/*     */       } 
/*     */     } else {
/*     */       
/*  82 */       onError(new IllegalStateException("§2.12 violated: onSubscribe must be called at most once"));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void onNext(T t) {
/*  88 */     if (WIP.get(this) == 0 && WIP.compareAndSet(this, 0, 1)) {
/*  89 */       this.actual.onNext(t);
/*  90 */       if (WIP.decrementAndGet(this) != 0) {
/*  91 */         Throwable ex = Exceptions.terminate(ERROR, this);
/*  92 */         if (ex != null) {
/*  93 */           this.actual.onError(ex);
/*     */         } else {
/*  95 */           this.actual.onComplete();
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void onError(Throwable t) {
/* 103 */     this.done = true;
/* 104 */     if (Exceptions.addThrowable(ERROR, this, t)) {
/* 105 */       if (WIP.getAndIncrement(this) == 0) {
/* 106 */         this.actual.onError(Exceptions.terminate(ERROR, this));
/*     */       }
/*     */     } else {
/*     */       
/* 110 */       Operators.onErrorDropped(t, Context.empty());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void onComplete() {
/* 116 */     this.done = true;
/* 117 */     if (WIP.getAndIncrement(this) == 0) {
/* 118 */       Throwable ex = Exceptions.terminate(ERROR, this);
/* 119 */       if (ex != null) {
/* 120 */         this.actual.onError(ex);
/*     */       } else {
/*     */         
/* 123 */         this.actual.onComplete();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void request(long n) {
/* 130 */     if (n <= 0L) {
/* 131 */       cancel();
/* 132 */       onError(new IllegalArgumentException("§3.9 violated: positive request amount required but it was " + n));
/*     */       
/*     */       return;
/*     */     } 
/* 136 */     Subscription a = this.s;
/* 137 */     if (a != null) {
/* 138 */       a.request(n);
/*     */     } else {
/*     */       
/* 141 */       Operators.addCap(REQUESTED, this, n);
/* 142 */       a = this.s;
/* 143 */       if (a != null) {
/* 144 */         long r = REQUESTED.getAndSet(this, 0L);
/* 145 */         if (r != 0L) {
/* 146 */           a.request(n);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void cancel() {
/* 154 */     if (!this.done) {
/* 155 */       Operators.terminate(S, this);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/* 162 */     if (key == Scannable.Attr.PARENT) {
/* 163 */       return this.s;
/*     */     }
/* 165 */     if (key == Scannable.Attr.CANCELLED) {
/* 166 */       return Boolean.valueOf((this.s == Operators.cancelledSubscription()));
/*     */     }
/* 168 */     if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) {
/* 169 */       return Long.valueOf(this.requested);
/*     */     }
/* 171 */     if (key == Scannable.Attr.ACTUAL) {
/* 172 */       return this.actual;
/*     */     }
/*     */     
/* 175 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Context currentContext() {
/* 180 */     return Context.empty();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\StrictSubscriber.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */