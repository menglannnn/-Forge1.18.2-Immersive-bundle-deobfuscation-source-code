/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.function.BiConsumer;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ import reactor.util.context.ContextView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxHandle<T, R>
/*     */   extends InternalFluxOperator<T, R>
/*     */ {
/*     */   final BiConsumer<? super T, SynchronousSink<R>> handler;
/*     */   
/*     */   FluxHandle(Flux<? extends T> source, BiConsumer<? super T, SynchronousSink<R>> handler) {
/*  41 */     super(source);
/*  42 */     this.handler = Objects.<BiConsumer<? super T, SynchronousSink<R>>>requireNonNull(handler, "handler");
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super R> actual) {
/*  47 */     if (actual instanceof Fuseable.ConditionalSubscriber) {
/*     */       
/*  49 */       Fuseable.ConditionalSubscriber<? super R> cs = (Fuseable.ConditionalSubscriber<? super R>)actual;
/*  50 */       return new HandleConditionalSubscriber<>(cs, this.handler);
/*     */     } 
/*  52 */     return new HandleSubscriber<>(actual, this.handler);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  57 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  58 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class HandleSubscriber<T, R>
/*     */     implements InnerOperator<T, R>, Fuseable.ConditionalSubscriber<T>, SynchronousSink<R>
/*     */   {
/*     */     final CoreSubscriber<? super R> actual;
/*     */     
/*     */     final BiConsumer<? super T, SynchronousSink<R>> handler;
/*     */     
/*     */     boolean done;
/*     */     
/*     */     boolean stop;
/*     */     
/*     */     Throwable error;
/*     */     R data;
/*     */     Subscription s;
/*     */     
/*     */     HandleSubscriber(CoreSubscriber<? super R> actual, BiConsumer<? super T, SynchronousSink<R>> handler) {
/*  78 */       this.actual = actual;
/*  79 */       this.handler = handler;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/*  84 */       if (Operators.validate(this.s, s)) {
/*  85 */         this.s = s;
/*     */         
/*  87 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     public Context currentContext() {
/*  94 */       return this.actual.currentContext();
/*     */     }
/*     */ 
/*     */     
/*     */     public ContextView contextView() {
/*  99 */       return (ContextView)this.actual.currentContext();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 104 */       if (this.done) {
/* 105 */         Operators.onNextDropped(t, this.actual.currentContext());
/*     */         
/*     */         return;
/*     */       } 
/*     */       try {
/* 110 */         this.handler.accept(t, this);
/*     */       }
/* 112 */       catch (Throwable e) {
/* 113 */         Throwable e_ = Operators.onNextError(t, e, this.actual.currentContext(), this.s);
/* 114 */         if (e_ != null) {
/* 115 */           onError(e_);
/*     */         } else {
/*     */           
/* 118 */           reset();
/* 119 */           this.s.request(1L);
/*     */         } 
/*     */         return;
/*     */       } 
/* 123 */       R v = this.data;
/* 124 */       this.data = null;
/* 125 */       if (v != null) {
/* 126 */         this.actual.onNext(v);
/*     */       }
/* 128 */       if (this.stop) {
/* 129 */         if (this.error != null) {
/* 130 */           Throwable e_ = Operators.onNextError(t, this.error, this.actual.currentContext(), this.s);
/* 131 */           if (e_ != null) {
/* 132 */             onError(e_);
/*     */           } else {
/*     */             
/* 135 */             reset();
/* 136 */             this.s.request(1L);
/*     */           } 
/*     */         } else {
/*     */           
/* 140 */           this.s.cancel();
/* 141 */           onComplete();
/*     */         }
/*     */       
/* 144 */       } else if (v == null) {
/* 145 */         this.s.request(1L);
/*     */       } 
/*     */     }
/*     */     
/*     */     private void reset() {
/* 150 */       this.done = false;
/* 151 */       this.stop = false;
/* 152 */       this.error = null;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean tryOnNext(T t) {
/* 157 */       if (this.done) {
/* 158 */         Operators.onNextDropped(t, this.actual.currentContext());
/* 159 */         return false;
/*     */       } 
/*     */       
/*     */       try {
/* 163 */         this.handler.accept(t, this);
/*     */       }
/* 165 */       catch (Throwable e) {
/* 166 */         Throwable e_ = Operators.onNextError(t, e, this.actual.currentContext(), this.s);
/* 167 */         if (e_ != null) {
/* 168 */           onError(e_);
/* 169 */           return true;
/*     */         } 
/*     */         
/* 172 */         reset();
/* 173 */         return false;
/*     */       } 
/*     */       
/* 176 */       R v = this.data;
/* 177 */       this.data = null;
/* 178 */       if (v != null) {
/* 179 */         this.actual.onNext(v);
/*     */       }
/* 181 */       if (this.stop) {
/* 182 */         if (this.error != null) {
/* 183 */           Throwable e_ = Operators.onNextError(t, this.error, this.actual.currentContext(), this.s);
/* 184 */           if (e_ != null) {
/* 185 */             onError(e_);
/*     */           } else {
/*     */             
/* 188 */             reset();
/* 189 */             return false;
/*     */           } 
/*     */         } else {
/*     */           
/* 193 */           this.s.cancel();
/* 194 */           onComplete();
/*     */         } 
/* 196 */         return true;
/*     */       } 
/* 198 */       return (v != null);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 203 */       if (this.done) {
/* 204 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*     */         
/*     */         return;
/*     */       } 
/* 208 */       this.done = true;
/*     */       
/* 210 */       this.actual.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 215 */       if (this.done) {
/*     */         return;
/*     */       }
/* 218 */       this.done = true;
/*     */       
/* 220 */       this.actual.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     public void complete() {
/* 225 */       if (this.stop) {
/* 226 */         throw new IllegalStateException("Cannot complete after a complete or error");
/*     */       }
/* 228 */       this.stop = true;
/*     */     }
/*     */ 
/*     */     
/*     */     public void error(Throwable e) {
/* 233 */       if (this.stop) {
/* 234 */         throw new IllegalStateException("Cannot error after a complete or error");
/*     */       }
/* 236 */       this.error = Objects.<Throwable>requireNonNull(e, "error");
/* 237 */       this.stop = true;
/*     */     }
/*     */ 
/*     */     
/*     */     public void next(R o) {
/* 242 */       if (this.data != null) {
/* 243 */         throw new IllegalStateException("Cannot emit more than one data");
/*     */       }
/* 245 */       if (this.stop) {
/* 246 */         throw new IllegalStateException("Cannot emit after a complete or error");
/*     */       }
/* 248 */       this.data = Objects.requireNonNull(o, "data");
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 254 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 255 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 256 */       if (key == Scannable.Attr.ERROR) return this.error; 
/* 257 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 259 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super R> actual() {
/* 264 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 269 */       this.s.request(n);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 274 */       this.s.cancel();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class HandleConditionalSubscriber<T, R>
/*     */     implements Fuseable.ConditionalSubscriber<T>, InnerOperator<T, R>, SynchronousSink<R>
/*     */   {
/*     */     final Fuseable.ConditionalSubscriber<? super R> actual;
/*     */     
/*     */     final BiConsumer<? super T, SynchronousSink<R>> handler;
/*     */     boolean done;
/*     */     boolean stop;
/*     */     Throwable error;
/*     */     R data;
/*     */     Subscription s;
/*     */     
/*     */     HandleConditionalSubscriber(Fuseable.ConditionalSubscriber<? super R> actual, BiConsumer<? super T, SynchronousSink<R>> handler) {
/* 292 */       this.actual = actual;
/* 293 */       this.handler = handler;
/*     */     }
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     public Context currentContext() {
/* 299 */       return this.actual.currentContext();
/*     */     }
/*     */ 
/*     */     
/*     */     public ContextView contextView() {
/* 304 */       return (ContextView)this.actual.currentContext();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 309 */       if (Operators.validate(this.s, s)) {
/* 310 */         this.s = s;
/*     */         
/* 312 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 318 */       if (this.done) {
/* 319 */         Operators.onNextDropped(t, this.actual.currentContext());
/*     */         
/*     */         return;
/*     */       } 
/*     */       try {
/* 324 */         this.handler.accept(t, this);
/*     */       }
/* 326 */       catch (Throwable e) {
/* 327 */         Throwable e_ = Operators.onNextError(t, e, this.actual.currentContext(), this.s);
/* 328 */         if (e_ != null) {
/* 329 */           onError(e_);
/*     */         } else {
/*     */           
/* 332 */           this.error = null;
/* 333 */           this.s.request(1L);
/*     */         } 
/*     */         return;
/*     */       } 
/* 337 */       R v = this.data;
/* 338 */       this.data = null;
/* 339 */       if (v != null) {
/* 340 */         this.actual.onNext(v);
/*     */       }
/* 342 */       if (this.stop) {
/* 343 */         this.done = true;
/* 344 */         if (this.error != null) {
/* 345 */           Throwable e_ = Operators.onNextError(t, this.error, this.actual.currentContext(), this.s);
/* 346 */           if (e_ != null) {
/* 347 */             this.actual.onError(e_);
/*     */           } else {
/*     */             
/* 350 */             reset();
/* 351 */             this.s.request(1L);
/*     */           } 
/*     */         } else {
/*     */           
/* 355 */           this.s.cancel();
/* 356 */           this.actual.onComplete();
/*     */         }
/*     */       
/* 359 */       } else if (v == null) {
/* 360 */         this.s.request(1L);
/*     */       } 
/*     */     }
/*     */     
/*     */     private void reset() {
/* 365 */       this.done = false;
/* 366 */       this.stop = false;
/* 367 */       this.error = null;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean tryOnNext(T t) {
/* 372 */       if (this.done) {
/* 373 */         Operators.onNextDropped(t, this.actual.currentContext());
/* 374 */         return false;
/*     */       } 
/*     */       
/*     */       try {
/* 378 */         this.handler.accept(t, this);
/*     */       }
/* 380 */       catch (Throwable e) {
/* 381 */         Throwable e_ = Operators.onNextError(t, e, this.actual.currentContext(), this.s);
/* 382 */         if (e_ != null) {
/* 383 */           onError(e_);
/* 384 */           return true;
/*     */         } 
/*     */         
/* 387 */         reset();
/* 388 */         return false;
/*     */       } 
/*     */       
/* 391 */       R v = this.data;
/* 392 */       boolean emit = false;
/* 393 */       this.data = null;
/* 394 */       if (v != null) {
/* 395 */         emit = this.actual.tryOnNext(v);
/*     */       }
/* 397 */       if (this.stop) {
/* 398 */         this.done = true;
/* 399 */         if (this.error != null) {
/* 400 */           Throwable e_ = Operators.onNextError(t, this.error, this.actual.currentContext(), this.s);
/* 401 */           if (e_ != null) {
/* 402 */             this.actual.onError(e_);
/*     */           } else {
/*     */             
/* 405 */             reset();
/* 406 */             return false;
/*     */           } 
/*     */         } else {
/*     */           
/* 410 */           this.s.cancel();
/* 411 */           this.actual.onComplete();
/*     */         } 
/* 413 */         return true;
/*     */       } 
/* 415 */       return emit;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 420 */       if (this.done) {
/* 421 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*     */         
/*     */         return;
/*     */       } 
/* 425 */       this.done = true;
/*     */       
/* 427 */       this.actual.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 432 */       if (this.done) {
/*     */         return;
/*     */       }
/* 435 */       this.done = true;
/*     */       
/* 437 */       this.actual.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super R> actual() {
/* 442 */       return (CoreSubscriber<? super R>)this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void complete() {
/* 447 */       if (this.stop) {
/* 448 */         throw new IllegalStateException("Cannot complete after a complete or error");
/*     */       }
/* 450 */       this.stop = true;
/*     */     }
/*     */ 
/*     */     
/*     */     public void error(Throwable e) {
/* 455 */       if (this.stop) {
/* 456 */         throw new IllegalStateException("Cannot error after a complete or error");
/*     */       }
/* 458 */       this.error = Objects.<Throwable>requireNonNull(e, "error");
/* 459 */       this.stop = true;
/*     */     }
/*     */ 
/*     */     
/*     */     public void next(R o) {
/* 464 */       if (this.data != null) {
/* 465 */         throw new IllegalStateException("Cannot emit more than one data");
/*     */       }
/* 467 */       if (this.stop) {
/* 468 */         throw new IllegalStateException("Cannot emit after a complete or error");
/*     */       }
/* 470 */       this.data = Objects.requireNonNull(o, "data");
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 475 */       this.s.request(n);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 480 */       this.s.cancel();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 486 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 487 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 488 */       if (key == Scannable.Attr.ERROR) return this.error; 
/* 489 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 491 */       return super.scanUnsafe(key);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\FluxHandle.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */