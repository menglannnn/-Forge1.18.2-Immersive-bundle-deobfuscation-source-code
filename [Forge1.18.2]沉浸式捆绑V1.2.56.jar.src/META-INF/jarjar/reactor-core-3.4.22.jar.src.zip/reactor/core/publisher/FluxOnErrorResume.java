/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.function.Function;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Scannable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxOnErrorResume<T>
/*     */   extends InternalFluxOperator<T, T>
/*     */ {
/*     */   final Function<? super Throwable, ? extends Publisher<? extends T>> nextFactory;
/*     */   
/*     */   FluxOnErrorResume(Flux<? extends T> source, Function<? super Throwable, ? extends Publisher<? extends T>> nextFactory) {
/*  41 */     super(source);
/*  42 */     this.nextFactory = Objects.<Function<? super Throwable, ? extends Publisher<? extends T>>>requireNonNull(nextFactory, "nextFactory");
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/*  47 */     return new ResumeSubscriber<>(actual, this.nextFactory);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  52 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  53 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class ResumeSubscriber<T>
/*     */     extends Operators.MultiSubscriptionSubscriber<T, T>
/*     */   {
/*     */     final Function<? super Throwable, ? extends Publisher<? extends T>> nextFactory;
/*     */     
/*     */     boolean second;
/*     */     
/*     */     ResumeSubscriber(CoreSubscriber<? super T> actual, Function<? super Throwable, ? extends Publisher<? extends T>> nextFactory) {
/*  65 */       super(actual);
/*  66 */       this.nextFactory = nextFactory;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/*  71 */       if (!this.second) {
/*  72 */         this.actual.onSubscribe(this);
/*     */       }
/*  74 */       set(s);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/*  79 */       this.actual.onNext(t);
/*     */       
/*  81 */       if (!this.second) {
/*  82 */         producedOne();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/*  88 */       if (!this.second) {
/*  89 */         Publisher<? extends T> p; this.second = true;
/*     */ 
/*     */ 
/*     */         
/*     */         try {
/*  94 */           p = Objects.<Publisher<? extends T>>requireNonNull(this.nextFactory.apply(t), "The nextFactory returned a null Publisher");
/*     */         
/*     */         }
/*  97 */         catch (Throwable e) {
/*  98 */           Throwable _e = Operators.onOperatorError(e, this.actual.currentContext());
/*  99 */           _e = Exceptions.addSuppressed(_e, t);
/* 100 */           this.actual.onError(_e);
/*     */           return;
/*     */         } 
/* 103 */         p.subscribe((Subscriber)this);
/*     */       } else {
/*     */         
/* 106 */         this.actual.onError(t);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 112 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 113 */       return super.scanUnsafe(key);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\FluxOnErrorResume.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */