/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.time.Duration;
/*    */ import org.reactivestreams.Publisher;
/*    */ import org.reactivestreams.Subscriber;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Fuseable;
/*    */ import reactor.core.Scannable;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MonoEmpty
/*    */   extends Mono<Object>
/*    */   implements Fuseable.ScalarCallable<Object>, SourceProducer<Object>
/*    */ {
/* 38 */   static final Publisher<Object> INSTANCE = new MonoEmpty();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void subscribe(CoreSubscriber<? super Object> actual) {
/* 46 */     Operators.complete((Subscriber<?>)actual);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static <T> Mono<T> instance() {
/* 57 */     return (Mono)INSTANCE;
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public Object call() throws Exception {
/* 63 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public Object block(Duration m) {
/* 69 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public Object block() {
/* 75 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 80 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 81 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\MonoEmpty.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */