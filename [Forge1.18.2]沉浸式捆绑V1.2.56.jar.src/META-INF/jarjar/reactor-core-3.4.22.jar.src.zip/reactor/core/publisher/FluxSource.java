/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import org.reactivestreams.Publisher;
/*    */ import org.reactivestreams.Subscriber;
/*    */ import reactor.core.CorePublisher;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Scannable;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class FluxSource<I>
/*    */   extends Flux<I>
/*    */   implements SourceProducer<I>, OptimizableOperator<I, I>
/*    */ {
/*    */   final Publisher<? extends I> source;
/*    */   @Nullable
/*    */   final OptimizableOperator<?, I> optimizableOperator;
/*    */   
/*    */   FluxSource(Publisher<? extends I> source) {
/* 48 */     this.source = Objects.<Publisher<? extends I>>requireNonNull(source);
/* 49 */     if (source instanceof OptimizableOperator) {
/*    */       
/* 51 */       OptimizableOperator<?, I> optimSource = (OptimizableOperator)source;
/* 52 */       this.optimizableOperator = optimSource;
/*    */     } else {
/*    */       
/* 55 */       this.optimizableOperator = null;
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void subscribe(CoreSubscriber<? super I> actual) {
/* 67 */     this.source.subscribe((Subscriber)actual);
/*    */   }
/*    */ 
/*    */   
/*    */   public final CorePublisher<? extends I> source() {
/* 72 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public final OptimizableOperator<?, ? extends I> nextOptimizableSource() {
/* 77 */     return this.optimizableOperator;
/*    */   }
/*    */ 
/*    */   
/*    */   public CoreSubscriber<? super I> subscribeOrReturn(CoreSubscriber<? super I> actual) {
/* 82 */     return actual;
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 88 */     if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(getPrefetch()); 
/* 89 */     if (key == Scannable.Attr.PARENT) return this.source; 
/* 90 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.from(this.source).scanUnsafe(key); 
/* 91 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\FluxSource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */