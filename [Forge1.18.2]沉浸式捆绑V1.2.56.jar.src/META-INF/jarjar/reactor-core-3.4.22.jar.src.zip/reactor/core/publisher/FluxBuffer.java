/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.Collection;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*     */ import java.util.function.BooleanSupplier;
/*     */ import java.util.function.Supplier;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxBuffer<T, C extends Collection<? super T>>
/*     */   extends InternalFluxOperator<T, C>
/*     */ {
/*     */   final int size;
/*     */   final int skip;
/*     */   final Supplier<C> bufferSupplier;
/*     */   
/*     */   FluxBuffer(Flux<? extends T> source, int size, Supplier<C> bufferSupplier) {
/*  49 */     this(source, size, size, bufferSupplier);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   FluxBuffer(Flux<? extends T> source, int size, int skip, Supplier<C> bufferSupplier) {
/*  56 */     super(source);
/*  57 */     if (size <= 0) {
/*  58 */       throw new IllegalArgumentException("size > 0 required but it was " + size);
/*     */     }
/*     */     
/*  61 */     if (skip <= 0) {
/*  62 */       throw new IllegalArgumentException("skip > 0 required but it was " + skip);
/*     */     }
/*     */     
/*  65 */     this.size = size;
/*  66 */     this.skip = skip;
/*  67 */     this.bufferSupplier = Objects.<Supplier<C>>requireNonNull(bufferSupplier, "bufferSupplier");
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super C> actual) {
/*  72 */     if (this.size == this.skip) {
/*  73 */       return new BufferExactSubscriber<>(actual, this.size, this.bufferSupplier);
/*     */     }
/*  75 */     if (this.skip > this.size) {
/*  76 */       return new BufferSkipSubscriber<>(actual, this.size, this.skip, this.bufferSupplier);
/*     */     }
/*     */     
/*  79 */     return new BufferOverlappingSubscriber<>(actual, this.size, this.skip, this.bufferSupplier);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  85 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  86 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class BufferExactSubscriber<T, C extends Collection<? super T>>
/*     */     implements InnerOperator<T, C>
/*     */   {
/*     */     final CoreSubscriber<? super C> actual;
/*     */     
/*     */     final Supplier<C> bufferSupplier;
/*     */     
/*     */     final int size;
/*     */     
/*     */     C buffer;
/*     */     
/*     */     Subscription s;
/*     */     
/*     */     boolean done;
/*     */ 
/*     */     
/*     */     BufferExactSubscriber(CoreSubscriber<? super C> actual, int size, Supplier<C> bufferSupplier) {
/* 107 */       this.actual = actual;
/* 108 */       this.size = size;
/* 109 */       this.bufferSupplier = bufferSupplier;
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 114 */       if (Operators.validate(n)) {
/* 115 */         this.s.request(Operators.multiplyCap(n, this.size));
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 121 */       this.s.cancel();
/* 122 */       Operators.onDiscardMultiple((Collection<?>)this.buffer, this.actual.currentContext());
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 127 */       if (Operators.validate(this.s, s)) {
/* 128 */         this.s = s;
/*     */         
/* 130 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */     
/*     */     public void onNext(T t) {
/*     */       Collection<T> collection;
/* 136 */       if (this.done) {
/* 137 */         Operators.onNextDropped(t, this.actual.currentContext());
/*     */         
/*     */         return;
/*     */       } 
/* 141 */       C b = this.buffer;
/* 142 */       if (b == null) {
/*     */         try {
/* 144 */           collection = Objects.<Collection>requireNonNull((Collection)this.bufferSupplier.get(), "The bufferSupplier returned a null buffer");
/*     */         
/*     */         }
/* 147 */         catch (Throwable e) {
/* 148 */           Context ctx = this.actual.currentContext();
/* 149 */           onError(Operators.onOperatorError(this.s, e, t, ctx));
/* 150 */           Operators.onDiscard(t, ctx);
/*     */           return;
/*     */         } 
/* 153 */         this.buffer = (C)collection;
/*     */       } 
/*     */       
/* 156 */       collection.add(t);
/*     */       
/* 158 */       if (collection.size() == this.size) {
/* 159 */         this.buffer = null;
/* 160 */         this.actual.onNext(collection);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 166 */       if (this.done) {
/* 167 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*     */         return;
/*     */       } 
/* 170 */       this.done = true;
/* 171 */       this.actual.onError(t);
/* 172 */       Operators.onDiscardMultiple((Collection<?>)this.buffer, this.actual.currentContext());
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 177 */       if (this.done) {
/*     */         return;
/*     */       }
/* 180 */       this.done = true;
/*     */       
/* 182 */       C b = this.buffer;
/*     */       
/* 184 */       if (b != null && !b.isEmpty()) {
/* 185 */         this.actual.onNext(b);
/*     */       }
/* 187 */       this.actual.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super C> actual() {
/* 192 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 198 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 199 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 200 */       if (key == Scannable.Attr.BUFFERED) {
/* 201 */         C b = this.buffer;
/* 202 */         return Integer.valueOf((b != null) ? b.size() : 0);
/*     */       } 
/* 204 */       if (key == Scannable.Attr.CAPACITY) return Integer.valueOf(this.size); 
/* 205 */       if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(this.size); 
/* 206 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 208 */       return super.scanUnsafe(key);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class BufferSkipSubscriber<T, C extends Collection<? super T>>
/*     */     implements InnerOperator<T, C>
/*     */   {
/*     */     final CoreSubscriber<? super C> actual;
/*     */     
/*     */     final Context ctx;
/*     */     
/*     */     final Supplier<C> bufferSupplier;
/*     */     
/*     */     final int size;
/*     */     
/*     */     final int skip;
/*     */     
/*     */     C buffer;
/*     */     
/*     */     Subscription s;
/*     */     
/*     */     boolean done;
/*     */     
/*     */     long index;
/*     */     
/*     */     volatile int wip;
/* 235 */     static final AtomicIntegerFieldUpdater<BufferSkipSubscriber> WIP = AtomicIntegerFieldUpdater.newUpdater(BufferSkipSubscriber.class, "wip");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     BufferSkipSubscriber(CoreSubscriber<? super C> actual, int size, int skip, Supplier<C> bufferSupplier) {
/* 241 */       this.actual = actual;
/* 242 */       this.ctx = actual.currentContext();
/* 243 */       this.size = size;
/* 244 */       this.skip = skip;
/* 245 */       this.bufferSupplier = bufferSupplier;
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 250 */       if (!Operators.validate(n)) {
/*     */         return;
/*     */       }
/*     */       
/* 254 */       if (this.wip == 0 && WIP.compareAndSet(this, 0, 1)) {
/*     */         
/* 256 */         long u = Operators.multiplyCap(n, this.size);
/*     */         
/* 258 */         long v = Operators.multiplyCap((this.skip - this.size), n - 1L);
/*     */         
/* 260 */         this.s.request(Operators.addCap(u, v));
/*     */       }
/*     */       else {
/*     */         
/* 264 */         this.s.request(Operators.multiplyCap(this.skip, n));
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 270 */       this.s.cancel();
/* 271 */       Operators.onDiscardMultiple((Collection<?>)this.buffer, this.ctx);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 276 */       if (Operators.validate(this.s, s)) {
/* 277 */         this.s = s;
/*     */         
/* 279 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */     
/*     */     public void onNext(T t) {
/*     */       Collection<T> collection;
/* 285 */       if (this.done) {
/* 286 */         Operators.onNextDropped(t, this.ctx);
/*     */         
/*     */         return;
/*     */       } 
/* 290 */       C b = this.buffer;
/*     */       
/* 292 */       long i = this.index;
/*     */       
/* 294 */       if (i % this.skip == 0L) {
/*     */         try {
/* 296 */           collection = Objects.<Collection>requireNonNull((Collection)this.bufferSupplier.get(), "The bufferSupplier returned a null buffer");
/*     */         
/*     */         }
/* 299 */         catch (Throwable e) {
/* 300 */           onError(Operators.onOperatorError(this.s, e, t, this.ctx));
/* 301 */           Operators.onDiscard(t, this.ctx);
/*     */           
/*     */           return;
/*     */         } 
/* 305 */         this.buffer = (C)collection;
/*     */       } 
/*     */       
/* 308 */       if (collection != null) {
/* 309 */         collection.add(t);
/* 310 */         if (collection.size() == this.size) {
/* 311 */           this.buffer = null;
/* 312 */           this.actual.onNext(collection);
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/* 317 */         Operators.onDiscard(t, this.ctx);
/*     */       } 
/*     */       
/* 320 */       this.index = i + 1L;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 325 */       if (this.done) {
/* 326 */         Operators.onErrorDropped(t, this.ctx);
/*     */         
/*     */         return;
/*     */       } 
/* 330 */       this.done = true;
/* 331 */       C b = this.buffer;
/* 332 */       this.buffer = null;
/*     */       
/* 334 */       this.actual.onError(t);
/* 335 */       Operators.onDiscardMultiple((Collection<?>)b, this.ctx);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 340 */       if (this.done) {
/*     */         return;
/*     */       }
/*     */       
/* 344 */       this.done = true;
/* 345 */       C b = this.buffer;
/* 346 */       this.buffer = null;
/*     */       
/* 348 */       if (b != null) {
/* 349 */         this.actual.onNext(b);
/*     */       }
/*     */       
/* 352 */       this.actual.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super C> actual() {
/* 357 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 363 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 364 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 365 */       if (key == Scannable.Attr.CAPACITY) return Integer.valueOf(this.size); 
/* 366 */       if (key == Scannable.Attr.BUFFERED) {
/* 367 */         C b = this.buffer;
/* 368 */         return Integer.valueOf((b != null) ? b.size() : 0);
/*     */       } 
/* 370 */       if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(this.size); 
/* 371 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 373 */       return super.scanUnsafe(key);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class BufferOverlappingSubscriber<T, C extends Collection<? super T>>
/*     */     extends ArrayDeque<C>
/*     */     implements BooleanSupplier, InnerOperator<T, C>
/*     */   {
/*     */     final CoreSubscriber<? super C> actual;
/*     */     
/*     */     final Supplier<C> bufferSupplier;
/*     */     
/*     */     final int size;
/*     */     
/*     */     final int skip;
/*     */     
/*     */     Subscription s;
/*     */     
/*     */     boolean done;
/*     */     
/*     */     long index;
/*     */     
/*     */     volatile boolean cancelled;
/*     */     
/*     */     long produced;
/*     */     
/*     */     volatile int once;
/*     */     
/* 402 */     static final AtomicIntegerFieldUpdater<BufferOverlappingSubscriber> ONCE = AtomicIntegerFieldUpdater.newUpdater(BufferOverlappingSubscriber.class, "once");
/*     */ 
/*     */     
/*     */     volatile long requested;
/*     */ 
/*     */     
/* 408 */     static final AtomicLongFieldUpdater<BufferOverlappingSubscriber> REQUESTED = AtomicLongFieldUpdater.newUpdater(BufferOverlappingSubscriber.class, "requested");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     BufferOverlappingSubscriber(CoreSubscriber<? super C> actual, int size, int skip, Supplier<C> bufferSupplier) {
/* 415 */       this.actual = actual;
/* 416 */       this.size = size;
/* 417 */       this.skip = skip;
/* 418 */       this.bufferSupplier = bufferSupplier;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean getAsBoolean() {
/* 423 */       return this.cancelled;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 429 */       if (!Operators.validate(n)) {
/*     */         return;
/*     */       }
/*     */       
/* 433 */       if (DrainUtils.postCompleteRequest(n, (Subscriber<? super C>)this.actual, this, REQUESTED, this, this)) {
/*     */         return;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 442 */       if (this.once == 0 && ONCE.compareAndSet(this, 0, 1)) {
/*     */         
/* 444 */         long u = Operators.multiplyCap(this.skip, n - 1L);
/*     */ 
/*     */         
/* 447 */         long r = Operators.addCap(this.size, u);
/* 448 */         this.s.request(r);
/*     */       }
/*     */       else {
/*     */         
/* 452 */         long r = Operators.multiplyCap(this.skip, n);
/* 453 */         this.s.request(r);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 459 */       this.cancelled = true;
/* 460 */       this.s.cancel();
/* 461 */       clear();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 466 */       if (Operators.validate(this.s, s)) {
/* 467 */         this.s = s;
/*     */         
/* 469 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 475 */       if (this.done) {
/* 476 */         Operators.onNextDropped(t, this.actual.currentContext());
/*     */         
/*     */         return;
/*     */       } 
/* 480 */       long i = this.index;
/*     */       
/* 482 */       if (i % this.skip == 0L) {
/*     */         Collection collection1;
/*     */         
/*     */         try {
/* 486 */           collection1 = Objects.<Collection>requireNonNull((Collection)this.bufferSupplier.get(), "The bufferSupplier returned a null buffer");
/*     */         
/*     */         }
/* 489 */         catch (Throwable e) {
/* 490 */           Context ctx = this.actual.currentContext();
/* 491 */           onError(Operators.onOperatorError(this.s, e, t, ctx));
/* 492 */           Operators.onDiscard(t, ctx);
/*     */           
/*     */           return;
/*     */         } 
/* 496 */         offer((C)collection1);
/*     */       } 
/*     */       
/* 499 */       Collection<T> collection = (Collection)peek();
/*     */       
/* 501 */       if (collection != null && collection.size() + 1 == this.size) {
/* 502 */         poll();
/*     */         
/* 504 */         collection.add(t);
/*     */         
/* 506 */         this.actual.onNext(collection);
/*     */         
/* 508 */         this.produced++;
/*     */       } 
/*     */       
/* 511 */       for (Collection<T> collection1 : this) {
/* 512 */         collection1.add(t);
/*     */       }
/*     */       
/* 515 */       this.index = i + 1L;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 520 */       if (this.done) {
/* 521 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*     */         
/*     */         return;
/*     */       } 
/* 525 */       this.done = true;
/* 526 */       clear();
/*     */       
/* 528 */       this.actual.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void clear() {
/* 533 */       Context ctx = this.actual.currentContext();
/* 534 */       for (Collection<?> collection : this) {
/* 535 */         Operators.onDiscardMultiple(collection, ctx);
/*     */       }
/* 537 */       super.clear();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 542 */       if (this.done) {
/*     */         return;
/*     */       }
/*     */       
/* 546 */       this.done = true;
/* 547 */       long p = this.produced;
/* 548 */       if (p != 0L) {
/* 549 */         Operators.produced(REQUESTED, this, p);
/*     */       }
/* 551 */       DrainUtils.postComplete(this.actual, this, REQUESTED, this, this);
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super C> actual() {
/* 556 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 562 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 563 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 564 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(this.cancelled); 
/* 565 */       if (key == Scannable.Attr.CAPACITY) return Integer.valueOf(size() * this.size); 
/* 566 */       if (key == Scannable.Attr.BUFFERED) return Integer.valueOf(stream().mapToInt(Collection::size).sum()); 
/* 567 */       if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(2147483647); 
/* 568 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf(this.requested); 
/* 569 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 571 */       return super.scanUnsafe(key);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\FluxBuffer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */