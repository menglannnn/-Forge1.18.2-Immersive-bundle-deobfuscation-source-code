/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.RejectedExecutionException;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*     */ import java.util.function.Supplier;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.core.scheduler.Scheduler;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxBufferTimeout<T, C extends Collection<? super T>>
/*     */   extends InternalFluxOperator<T, C>
/*     */ {
/*     */   final int batchSize;
/*     */   final Supplier<C> bufferSupplier;
/*     */   final Scheduler timer;
/*     */   final long timespan;
/*     */   final TimeUnit unit;
/*     */   
/*     */   FluxBufferTimeout(Flux<T> source, int maxSize, long timespan, TimeUnit unit, Scheduler timer, Supplier<C> bufferSupplier) {
/*  53 */     super(source);
/*  54 */     if (timespan <= 0L) {
/*  55 */       throw new IllegalArgumentException("Timeout period must be strictly positive");
/*     */     }
/*  57 */     if (maxSize <= 0) {
/*  58 */       throw new IllegalArgumentException("maxSize must be strictly positive");
/*     */     }
/*  60 */     this.timer = Objects.<Scheduler>requireNonNull(timer, "Timer");
/*  61 */     this.timespan = timespan;
/*  62 */     this.unit = Objects.<TimeUnit>requireNonNull(unit, "unit");
/*  63 */     this.batchSize = maxSize;
/*  64 */     this.bufferSupplier = Objects.<Supplier<C>>requireNonNull(bufferSupplier, "bufferSupplier");
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super C> actual) {
/*  69 */     return new BufferTimeoutSubscriber<>(
/*  70 */         Operators.serialize(actual), this.batchSize, this.timespan, this.unit, this.timer
/*     */ 
/*     */ 
/*     */         
/*  74 */         .createWorker(), this.bufferSupplier);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  81 */     if (key == Scannable.Attr.RUN_ON) return this.timer; 
/*  82 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.ASYNC;
/*     */     
/*  84 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class BufferTimeoutSubscriber<T, C extends Collection<? super T>>
/*     */     implements InnerOperator<T, C>
/*     */   {
/*     */     final CoreSubscriber<? super C> actual;
/*     */     
/*     */     static final int NOT_TERMINATED = 0;
/*     */     
/*     */     static final int TERMINATED_WITH_SUCCESS = 1;
/*     */     
/*     */     static final int TERMINATED_WITH_ERROR = 2;
/*     */     static final int TERMINATED_WITH_CANCEL = 3;
/*     */     final int batchSize;
/*     */     final long timespan;
/*     */     final TimeUnit unit;
/*     */     final Scheduler.Worker timer;
/*     */     final Runnable flushTask;
/*     */     protected Subscription subscription;
/* 105 */     volatile int terminated = 0;
/*     */ 
/*     */ 
/*     */     
/* 109 */     static final AtomicIntegerFieldUpdater<BufferTimeoutSubscriber> TERMINATED = AtomicIntegerFieldUpdater.newUpdater(BufferTimeoutSubscriber.class, "terminated");
/*     */ 
/*     */ 
/*     */     
/*     */     volatile long requested;
/*     */ 
/*     */     
/* 116 */     static final AtomicLongFieldUpdater<BufferTimeoutSubscriber> REQUESTED = AtomicLongFieldUpdater.newUpdater(BufferTimeoutSubscriber.class, "requested");
/*     */ 
/*     */     
/*     */     volatile long outstanding;
/*     */ 
/*     */     
/* 122 */     static final AtomicLongFieldUpdater<BufferTimeoutSubscriber> OUTSTANDING = AtomicLongFieldUpdater.newUpdater(BufferTimeoutSubscriber.class, "outstanding");
/*     */     
/* 124 */     volatile int index = 0;
/*     */ 
/*     */     
/* 127 */     static final AtomicIntegerFieldUpdater<BufferTimeoutSubscriber> INDEX = AtomicIntegerFieldUpdater.newUpdater(BufferTimeoutSubscriber.class, "index");
/*     */ 
/*     */ 
/*     */     
/*     */     volatile Disposable timespanRegistration;
/*     */ 
/*     */     
/*     */     final Supplier<C> bufferSupplier;
/*     */ 
/*     */     
/*     */     volatile C values;
/*     */ 
/*     */ 
/*     */     
/*     */     BufferTimeoutSubscriber(CoreSubscriber<? super C> actual, int maxSize, long timespan, TimeUnit unit, Scheduler.Worker timer, Supplier<C> bufferSupplier) {
/* 142 */       this.actual = actual;
/* 143 */       this.timespan = timespan;
/* 144 */       this.unit = unit;
/* 145 */       this.timer = timer;
/* 146 */       this.flushTask = (() -> {
/*     */           if (this.terminated == 0) {
/*     */             int index;
/*     */             
/*     */             do {
/*     */               index = this.index;
/*     */               
/*     */               if (index == 0) {
/*     */                 return;
/*     */               }
/*     */             } while (!INDEX.compareAndSet(this, index, 0));
/*     */             
/*     */             flushCallback(null);
/*     */           } 
/*     */         });
/*     */       
/* 162 */       this.batchSize = maxSize;
/* 163 */       this.bufferSupplier = bufferSupplier;
/*     */     }
/*     */     
/*     */     protected void doOnSubscribe() {
/* 167 */       this.values = this.bufferSupplier.get();
/*     */     }
/*     */     
/*     */     void nextCallback(T value) {
/* 171 */       synchronized (this) {
/* 172 */         Collection<T> collection; if (OUTSTANDING.decrementAndGet(this) < 0L) {
/*     */           
/* 174 */           this.actual.onError(Exceptions.failWithOverflow("Unrequested element received"));
/* 175 */           Context ctx = this.actual.currentContext();
/* 176 */           Operators.onDiscard(value, ctx);
/* 177 */           Operators.onDiscardMultiple((Collection<?>)this.values, ctx);
/*     */           
/*     */           return;
/*     */         } 
/* 181 */         C v = this.values;
/* 182 */         if (v == null) {
/* 183 */           collection = Objects.<Collection>requireNonNull((Collection)this.bufferSupplier.get(), "The bufferSupplier returned a null buffer");
/*     */           
/* 185 */           this.values = (C)collection;
/*     */         } 
/* 187 */         collection.add(value);
/*     */       } 
/*     */     }
/*     */     
/*     */     void flushCallback(@Nullable T ev) {
/*     */       C v;
/* 193 */       boolean flush = false;
/* 194 */       synchronized (this) {
/* 195 */         v = this.values;
/* 196 */         if (v != null && !v.isEmpty()) {
/* 197 */           this.values = this.bufferSupplier.get();
/* 198 */           flush = true;
/*     */         } 
/*     */       } 
/*     */       
/* 202 */       if (flush) {
/* 203 */         long r = this.requested;
/* 204 */         if (r != 0L) {
/* 205 */           if (r != Long.MAX_VALUE) {
/*     */             
/*     */             do {
/* 208 */               long next = r - 1L;
/* 209 */               if (REQUESTED.compareAndSet(this, r, next)) {
/* 210 */                 this.actual.onNext(v);
/*     */                 
/*     */                 return;
/*     */               } 
/* 214 */               r = this.requested;
/* 215 */             } while (r > 0L);
/*     */           
/*     */           }
/*     */           else {
/*     */ 
/*     */             
/* 221 */             this.actual.onNext(v);
/*     */             
/*     */             return;
/*     */           } 
/*     */         }
/* 226 */         cancel();
/* 227 */         this.actual.onError(Exceptions.failWithOverflow("Could not emit buffer due to lack of requests"));
/*     */         
/* 229 */         Operators.onDiscardMultiple((Collection<?>)v, this.actual.currentContext());
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 236 */       if (key == Scannable.Attr.PARENT) return this.subscription; 
/* 237 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf((this.terminated == 3)); 
/* 238 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf((this.terminated == 2 || this.terminated == 1)); 
/* 239 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf(this.requested); 
/* 240 */       if (key == Scannable.Attr.CAPACITY) return Integer.valueOf(this.batchSize); 
/* 241 */       if (key == Scannable.Attr.BUFFERED) return Integer.valueOf(this.batchSize - this.index); 
/* 242 */       if (key == Scannable.Attr.RUN_ON) return this.timer; 
/* 243 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.ASYNC;
/*     */       
/* 245 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T value) {
/*     */       int index;
/*     */       do {
/* 252 */         index = this.index + 1;
/* 253 */       } while (!INDEX.compareAndSet(this, index - 1, index));
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 258 */       if (index == 1) {
/*     */         try {
/* 260 */           this.timespanRegistration = this.timer.schedule(this.flushTask, this.timespan, this.unit);
/*     */         }
/* 262 */         catch (RejectedExecutionException ree) {
/* 263 */           Context ctx = this.actual.currentContext();
/* 264 */           onError(Operators.onRejectedExecution(ree, this.subscription, null, value, ctx));
/* 265 */           Operators.onDiscard(value, ctx);
/*     */           
/*     */           return;
/*     */         } 
/*     */       }
/* 270 */       nextCallback(value);
/*     */       
/* 272 */       if (this.index % this.batchSize == 0) {
/* 273 */         this.index = 0;
/* 274 */         if (this.timespanRegistration != null) {
/* 275 */           this.timespanRegistration.dispose();
/* 276 */           this.timespanRegistration = null;
/*     */         } 
/* 278 */         flushCallback(value);
/*     */       } 
/*     */     }
/*     */     
/*     */     void checkedComplete() {
/*     */       try {
/* 284 */         flushCallback(null);
/*     */       } finally {
/*     */         
/* 287 */         this.actual.onComplete();
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     final boolean isCompleted() {
/* 295 */       return (this.terminated == 1);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     final boolean isFailed() {
/* 302 */       return (this.terminated == 2);
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 307 */       if (Operators.validate(n)) {
/* 308 */         Operators.addCap(REQUESTED, this, n);
/* 309 */         if (this.terminated != 0) {
/*     */           return;
/*     */         }
/* 312 */         if (this.batchSize == Integer.MAX_VALUE || n == Long.MAX_VALUE) {
/* 313 */           requestMore(Long.MAX_VALUE);
/*     */         } else {
/*     */           
/* 316 */           long requestLimit = Operators.multiplyCap(this.requested, this.batchSize);
/* 317 */           if (requestLimit > this.outstanding) {
/* 318 */             requestMore(requestLimit - this.outstanding);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     final void requestMore(long n) {
/* 325 */       Subscription s = this.subscription;
/* 326 */       if (s != null) {
/* 327 */         Operators.addCap(OUTSTANDING, this, n);
/* 328 */         s.request(n);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super C> actual() {
/* 334 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 339 */       if (TERMINATED.compareAndSet(this, 0, 1)) {
/* 340 */         this.timer.dispose();
/* 341 */         checkedComplete();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable throwable) {
/* 347 */       if (TERMINATED.compareAndSet(this, 0, 2)) {
/* 348 */         this.timer.dispose();
/* 349 */         Context ctx = this.actual.currentContext();
/* 350 */         synchronized (this) {
/* 351 */           C v = this.values;
/* 352 */           if (v != null) {
/* 353 */             Operators.onDiscardMultiple((Collection<?>)v, ctx);
/* 354 */             v.clear();
/* 355 */             this.values = null;
/*     */           } 
/*     */         } 
/* 358 */         this.actual.onError(throwable);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 364 */       if (Operators.validate(this.subscription, s)) {
/* 365 */         this.subscription = s;
/* 366 */         doOnSubscribe();
/* 367 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 373 */       if (TERMINATED.compareAndSet(this, 0, 3)) {
/* 374 */         this.timer.dispose();
/* 375 */         Subscription s = this.subscription;
/* 376 */         if (s != null) {
/* 377 */           this.subscription = null;
/* 378 */           s.cancel();
/*     */         } 
/* 380 */         C v = this.values;
/* 381 */         if (v != null) {
/* 382 */           Operators.onDiscardMultiple((Collection<?>)v, this.actual.currentContext());
/* 383 */           v.clear();
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\FluxBufferTimeout.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */