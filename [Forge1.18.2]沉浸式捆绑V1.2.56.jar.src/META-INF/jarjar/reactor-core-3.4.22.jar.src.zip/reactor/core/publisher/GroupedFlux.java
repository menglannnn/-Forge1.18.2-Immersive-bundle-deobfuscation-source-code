package reactor.core.publisher;

import reactor.util.annotation.NonNull;

public abstract class GroupedFlux<K, V> extends Flux<V> {
  @NonNull
  public abstract K key();
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\GroupedFlux.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */