/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.function.Consumer;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class LambdaMonoSubscriber<T>
/*     */   implements InnerConsumer<T>, Disposable
/*     */ {
/*     */   final Consumer<? super T> consumer;
/*     */   final Consumer<? super Throwable> errorConsumer;
/*     */   final Runnable completeConsumer;
/*     */   final Consumer<? super Subscription> subscriptionConsumer;
/*     */   final Context initialContext;
/*     */   volatile Subscription subscription;
/*  47 */   static final AtomicReferenceFieldUpdater<LambdaMonoSubscriber, Subscription> S = AtomicReferenceFieldUpdater.newUpdater(LambdaMonoSubscriber.class, Subscription.class, "subscription");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   LambdaMonoSubscriber(@Nullable Consumer<? super T> consumer, @Nullable Consumer<? super Throwable> errorConsumer, @Nullable Runnable completeConsumer, @Nullable Consumer<? super Subscription> subscriptionConsumer, @Nullable Context initialContext) {
/*  72 */     this.consumer = consumer;
/*  73 */     this.errorConsumer = errorConsumer;
/*  74 */     this.completeConsumer = completeConsumer;
/*  75 */     this.subscriptionConsumer = subscriptionConsumer;
/*  76 */     this.initialContext = (initialContext == null) ? Context.empty() : initialContext;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   LambdaMonoSubscriber(@Nullable Consumer<? super T> consumer, @Nullable Consumer<? super Throwable> errorConsumer, @Nullable Runnable completeConsumer, @Nullable Consumer<? super Subscription> subscriptionConsumer) {
/*  97 */     this(consumer, errorConsumer, completeConsumer, subscriptionConsumer, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public Context currentContext() {
/* 102 */     return this.initialContext;
/*     */   }
/*     */ 
/*     */   
/*     */   public final void onSubscribe(Subscription s) {
/* 107 */     if (Operators.validate(this.subscription, s)) {
/* 108 */       this.subscription = s;
/*     */       
/* 110 */       if (this.subscriptionConsumer != null) {
/*     */         try {
/* 112 */           this.subscriptionConsumer.accept(s);
/*     */         }
/* 114 */         catch (Throwable t) {
/* 115 */           Exceptions.throwIfFatal(t);
/* 116 */           s.cancel();
/* 117 */           onError(t);
/*     */         } 
/*     */       } else {
/*     */         
/* 121 */         s.request(Long.MAX_VALUE);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final void onComplete() {
/* 129 */     Subscription s = S.getAndSet(this, Operators.cancelledSubscription());
/* 130 */     if (s == Operators.cancelledSubscription()) {
/*     */       return;
/*     */     }
/* 133 */     if (this.completeConsumer != null) {
/*     */       try {
/* 135 */         this.completeConsumer.run();
/*     */       }
/* 137 */       catch (Throwable t) {
/* 138 */         Operators.onErrorDropped(t, this.initialContext);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public final void onError(Throwable t) {
/* 145 */     Subscription s = S.getAndSet(this, Operators.cancelledSubscription());
/* 146 */     if (s == Operators.cancelledSubscription()) {
/* 147 */       Operators.onErrorDropped(t, this.initialContext);
/*     */       return;
/*     */     } 
/* 150 */     doError(t);
/*     */   }
/*     */   
/*     */   void doError(Throwable t) {
/* 154 */     if (this.errorConsumer != null) {
/* 155 */       this.errorConsumer.accept(t);
/*     */     } else {
/*     */       
/* 158 */       Operators.onErrorDropped(Exceptions.errorCallbackNotImplemented(t), this.initialContext);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public final void onNext(T x) {
/* 164 */     Subscription s = S.getAndSet(this, Operators.cancelledSubscription());
/* 165 */     if (s == Operators.cancelledSubscription()) {
/* 166 */       Operators.onNextDropped(x, this.initialContext);
/*     */       return;
/*     */     } 
/* 169 */     if (this.consumer != null) {
/*     */       try {
/* 171 */         this.consumer.accept(x);
/*     */       }
/* 173 */       catch (Throwable t) {
/* 174 */         Exceptions.throwIfFatal(t);
/* 175 */         s.cancel();
/* 176 */         doError(t);
/*     */       } 
/*     */     }
/* 179 */     if (this.completeConsumer != null) {
/*     */       try {
/* 181 */         this.completeConsumer.run();
/*     */       }
/* 183 */       catch (Throwable t) {
/* 184 */         Operators.onErrorDropped(t, this.initialContext);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/* 192 */     if (key == Scannable.Attr.PARENT) {
/* 193 */       return this.subscription;
/*     */     }
/* 195 */     if (key == Scannable.Attr.PREFETCH) {
/* 196 */       return Integer.valueOf(2147483647);
/*     */     }
/* 198 */     if (key == Scannable.Attr.TERMINATED || key == Scannable.Attr.CANCELLED) {
/* 199 */       return Boolean.valueOf(isDisposed());
/*     */     }
/* 201 */     if (key == Scannable.Attr.RUN_STYLE) {
/* 202 */       return Scannable.Attr.RunStyle.SYNC;
/*     */     }
/*     */     
/* 205 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDisposed() {
/* 210 */     return (this.subscription == Operators.cancelledSubscription());
/*     */   }
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 215 */     Subscription s = S.getAndSet(this, Operators.cancelledSubscription());
/* 216 */     if (s != null && s != Operators.cancelledSubscription())
/* 217 */       s.cancel(); 
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\LambdaMonoSubscriber.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */