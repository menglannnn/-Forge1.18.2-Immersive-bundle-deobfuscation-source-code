/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.function.BiPredicate;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Supplier;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxDistinct<T, K, C>
/*     */   extends InternalFluxOperator<T, T>
/*     */ {
/*     */   final Function<? super T, ? extends K> keyExtractor;
/*     */   final Supplier<C> collectionSupplier;
/*     */   final BiPredicate<C, K> distinctPredicate;
/*     */   final Consumer<C> cleanupCallback;
/*     */   
/*     */   FluxDistinct(Flux<? extends T> source, Function<? super T, ? extends K> keyExtractor, Supplier<C> collectionSupplier, BiPredicate<C, K> distinctPredicate, Consumer<C> cleanupCallback) {
/*  55 */     super(source);
/*  56 */     this.keyExtractor = Objects.<Function<? super T, ? extends K>>requireNonNull(keyExtractor, "keyExtractor");
/*  57 */     this.collectionSupplier = Objects.<Supplier<C>>requireNonNull(collectionSupplier, "collectionSupplier");
/*  58 */     this.distinctPredicate = Objects.<BiPredicate<C, K>>requireNonNull(distinctPredicate, "distinctPredicate");
/*  59 */     this.cleanupCallback = Objects.<Consumer<C>>requireNonNull(cleanupCallback, "cleanupCallback");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/*  65 */     C collection = Objects.requireNonNull(this.collectionSupplier.get(), "The collectionSupplier returned a null collection");
/*     */ 
/*     */     
/*  68 */     if (actual instanceof Fuseable.ConditionalSubscriber) {
/*  69 */       return new DistinctConditionalSubscriber<>((Fuseable.ConditionalSubscriber<? super T>)actual, collection, this.keyExtractor, this.distinctPredicate, this.cleanupCallback);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  75 */     return new DistinctSubscriber<>(actual, collection, this.keyExtractor, this.distinctPredicate, this.cleanupCallback);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  82 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  83 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static final class DistinctSubscriber<T, K, C>
/*     */     implements Fuseable.ConditionalSubscriber<T>, InnerOperator<T, T>
/*     */   {
/*     */     final CoreSubscriber<? super T> actual;
/*     */     
/*     */     final Context ctx;
/*     */     
/*     */     final C collection;
/*     */     
/*     */     final Function<? super T, ? extends K> keyExtractor;
/*     */     
/*     */     final BiPredicate<C, K> distinctPredicate;
/*     */     
/*     */     final Consumer<C> cleanupCallback;
/*     */     
/*     */     Subscription s;
/*     */     
/*     */     boolean done;
/*     */ 
/*     */     
/*     */     DistinctSubscriber(CoreSubscriber<? super T> actual, C collection, Function<? super T, ? extends K> keyExtractor, BiPredicate<C, K> distinctPredicate, Consumer<C> cleanupCallback) {
/* 109 */       this.actual = actual;
/* 110 */       this.ctx = actual.currentContext();
/* 111 */       this.collection = collection;
/* 112 */       this.keyExtractor = keyExtractor;
/* 113 */       this.distinctPredicate = distinctPredicate;
/* 114 */       this.cleanupCallback = cleanupCallback;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 119 */       if (Operators.validate(this.s, s)) {
/* 120 */         this.s = s;
/*     */         
/* 122 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 128 */       if (!tryOnNext(t))
/* 129 */         this.s.request(1L); 
/*     */     }
/*     */     
/*     */     public boolean tryOnNext(T t) {
/*     */       K k;
/*     */       boolean b;
/* 135 */       if (this.done) {
/* 136 */         Operators.onNextDropped(t, this.ctx);
/* 137 */         return true;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 143 */         k = Objects.requireNonNull(this.keyExtractor.apply(t), "The distinct extractor returned a null value.");
/*     */       
/*     */       }
/* 146 */       catch (Throwable e) {
/* 147 */         onError(Operators.onOperatorError(this.s, e, t, this.ctx));
/* 148 */         Operators.onDiscard(t, this.ctx);
/* 149 */         return true;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 155 */         b = this.distinctPredicate.test(this.collection, k);
/*     */       }
/* 157 */       catch (Throwable e) {
/* 158 */         onError(Operators.onOperatorError(this.s, e, t, this.ctx));
/* 159 */         Operators.onDiscard(t, this.ctx);
/* 160 */         return true;
/*     */       } 
/*     */       
/* 163 */       if (b) {
/* 164 */         this.actual.onNext(t);
/* 165 */         return true;
/*     */       } 
/* 167 */       Operators.onDiscard(t, this.ctx);
/* 168 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 173 */       if (this.done) {
/* 174 */         Operators.onErrorDropped(t, this.ctx);
/*     */         return;
/*     */       } 
/* 177 */       this.done = true;
/* 178 */       this.cleanupCallback.accept(this.collection);
/*     */       
/* 180 */       this.actual.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 185 */       if (this.done) {
/*     */         return;
/*     */       }
/* 188 */       this.done = true;
/* 189 */       this.cleanupCallback.accept(this.collection);
/*     */       
/* 191 */       this.actual.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 196 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 201 */       this.s.request(n);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 206 */       this.s.cancel();
/* 207 */       if (this.collection != null) {
/* 208 */         this.cleanupCallback.accept(this.collection);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 214 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 215 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 216 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 218 */       return super.scanUnsafe(key);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class DistinctConditionalSubscriber<T, K, C>
/*     */     implements Fuseable.ConditionalSubscriber<T>, InnerOperator<T, T>
/*     */   {
/*     */     final Fuseable.ConditionalSubscriber<? super T> actual;
/*     */     
/*     */     final Context ctx;
/*     */     
/*     */     final C collection;
/*     */     
/*     */     final Function<? super T, ? extends K> keyExtractor;
/*     */     
/*     */     final BiPredicate<C, K> distinctPredicate;
/*     */     
/*     */     final Consumer<C> cleanupCallback;
/*     */     
/*     */     Subscription s;
/*     */     
/*     */     boolean done;
/*     */ 
/*     */     
/*     */     DistinctConditionalSubscriber(Fuseable.ConditionalSubscriber<? super T> actual, C collection, Function<? super T, ? extends K> keyExtractor, BiPredicate<C, K> distinctPredicate, Consumer<C> cleanupCallback) {
/* 244 */       this.actual = actual;
/* 245 */       this.ctx = actual.currentContext();
/* 246 */       this.collection = collection;
/* 247 */       this.keyExtractor = keyExtractor;
/* 248 */       this.distinctPredicate = distinctPredicate;
/* 249 */       this.cleanupCallback = cleanupCallback;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 254 */       if (Operators.validate(this.s, s)) {
/* 255 */         this.s = s;
/*     */         
/* 257 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */     public void onNext(T t) {
/*     */       K k;
/*     */       boolean b;
/* 263 */       if (this.done) {
/* 264 */         Operators.onNextDropped(t, this.ctx);
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/*     */       try {
/* 271 */         k = Objects.requireNonNull(this.keyExtractor.apply(t), "The distinct extractor returned a null value.");
/*     */       
/*     */       }
/* 274 */       catch (Throwable e) {
/* 275 */         onError(Operators.onOperatorError(this.s, e, t, this.ctx));
/* 276 */         Operators.onDiscard(t, this.ctx);
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/*     */       try {
/* 283 */         b = this.distinctPredicate.test(this.collection, k);
/*     */       }
/* 285 */       catch (Throwable e) {
/* 286 */         onError(Operators.onOperatorError(this.s, e, t, this.ctx));
/* 287 */         Operators.onDiscard(t, this.ctx);
/*     */         
/*     */         return;
/*     */       } 
/* 291 */       if (b) {
/* 292 */         this.actual.onNext(t);
/*     */       } else {
/*     */         
/* 295 */         Operators.onDiscard(t, this.ctx);
/* 296 */         this.s.request(1L);
/*     */       } 
/*     */     }
/*     */     public boolean tryOnNext(T t) {
/*     */       K k;
/*     */       boolean b;
/* 302 */       if (this.done) {
/* 303 */         Operators.onNextDropped(t, this.ctx);
/* 304 */         return true;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 310 */         k = Objects.requireNonNull(this.keyExtractor.apply(t), "The distinct extractor returned a null value.");
/*     */       
/*     */       }
/* 313 */       catch (Throwable e) {
/* 314 */         onError(Operators.onOperatorError(this.s, e, t, this.ctx));
/* 315 */         Operators.onDiscard(t, this.ctx);
/* 316 */         return true;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 322 */         b = this.distinctPredicate.test(this.collection, k);
/*     */       }
/* 324 */       catch (Throwable e) {
/* 325 */         onError(Operators.onOperatorError(this.s, e, t, this.ctx));
/* 326 */         Operators.onDiscard(t, this.ctx);
/* 327 */         return true;
/*     */       } 
/*     */       
/* 330 */       if (b) {
/* 331 */         return this.actual.tryOnNext(t);
/*     */       }
/*     */       
/* 334 */       Operators.onDiscard(t, this.ctx);
/* 335 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 341 */       if (this.done) {
/* 342 */         Operators.onErrorDropped(t, this.ctx);
/*     */         return;
/*     */       } 
/* 345 */       this.done = true;
/* 346 */       this.cleanupCallback.accept(this.collection);
/*     */       
/* 348 */       this.actual.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 353 */       if (this.done) {
/*     */         return;
/*     */       }
/* 356 */       this.done = true;
/* 357 */       this.cleanupCallback.accept(this.collection);
/*     */       
/* 359 */       this.actual.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 364 */       return (CoreSubscriber<? super T>)this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 369 */       this.s.request(n);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 374 */       this.s.cancel();
/* 375 */       if (this.collection != null) {
/* 376 */         this.cleanupCallback.accept(this.collection);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 383 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 384 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 385 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 387 */       return super.scanUnsafe(key);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class DistinctFuseableSubscriber<T, K, C>
/*     */     implements Fuseable.ConditionalSubscriber<T>, InnerOperator<T, T>, Fuseable.QueueSubscription<T>
/*     */   {
/*     */     final CoreSubscriber<? super T> actual;
/*     */     
/*     */     final Context ctx;
/*     */     
/*     */     final C collection;
/*     */     
/*     */     final Function<? super T, ? extends K> keyExtractor;
/*     */     
/*     */     final BiPredicate<C, K> distinctPredicate;
/*     */     
/*     */     final Consumer<C> cleanupCallback;
/*     */     
/*     */     Fuseable.QueueSubscription<T> qs;
/*     */     
/*     */     boolean done;
/*     */     
/*     */     int sourceMode;
/*     */     
/*     */     DistinctFuseableSubscriber(CoreSubscriber<? super T> actual, C collection, Function<? super T, ? extends K> keyExtractor, BiPredicate<C, K> predicate, Consumer<C> callback) {
/* 414 */       this.actual = actual;
/* 415 */       this.ctx = actual.currentContext();
/* 416 */       this.collection = collection;
/* 417 */       this.keyExtractor = keyExtractor;
/* 418 */       this.distinctPredicate = predicate;
/* 419 */       this.cleanupCallback = callback;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 425 */       if (Operators.validate((Subscription)this.qs, s)) {
/* 426 */         this.qs = (Fuseable.QueueSubscription<T>)s;
/*     */         
/* 428 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 434 */       if (!tryOnNext(t))
/* 435 */         this.qs.request(1L); 
/*     */     }
/*     */     
/*     */     public boolean tryOnNext(T t) {
/*     */       K k;
/*     */       boolean b;
/* 441 */       if (this.sourceMode == 2) {
/* 442 */         this.actual.onNext(null);
/* 443 */         return true;
/*     */       } 
/* 445 */       if (this.done) {
/* 446 */         Operators.onNextDropped(t, this.ctx);
/* 447 */         return true;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 453 */         k = Objects.requireNonNull(this.keyExtractor.apply(t), "The distinct extractor returned a null value.");
/*     */       
/*     */       }
/* 456 */       catch (Throwable e) {
/* 457 */         onError(Operators.onOperatorError((Subscription)this.qs, e, t, this.ctx));
/* 458 */         Operators.onDiscard(t, this.ctx);
/* 459 */         return true;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 465 */         b = this.distinctPredicate.test(this.collection, k);
/*     */       }
/* 467 */       catch (Throwable e) {
/* 468 */         onError(Operators.onOperatorError((Subscription)this.qs, e, t, this.ctx));
/* 469 */         Operators.onDiscard(t, this.ctx);
/* 470 */         return true;
/*     */       } 
/*     */       
/* 473 */       if (b) {
/* 474 */         this.actual.onNext(t);
/* 475 */         return true;
/*     */       } 
/* 477 */       Operators.onDiscard(t, this.ctx);
/* 478 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 483 */       if (this.done) {
/* 484 */         Operators.onErrorDropped(t, this.ctx);
/*     */         return;
/*     */       } 
/* 487 */       this.done = true;
/* 488 */       this.cleanupCallback.accept(this.collection);
/*     */       
/* 490 */       this.actual.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 495 */       if (this.done) {
/*     */         return;
/*     */       }
/* 498 */       this.done = true;
/* 499 */       this.cleanupCallback.accept(this.collection);
/*     */       
/* 501 */       this.actual.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 506 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 511 */       this.qs.request(n);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 516 */       this.qs.cancel();
/* 517 */       if (this.collection != null) {
/* 518 */         this.cleanupCallback.accept(this.collection);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public int requestFusion(int requestedMode) {
/* 524 */       int m = this.qs.requestFusion(requestedMode);
/* 525 */       this.sourceMode = m;
/* 526 */       return m;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 531 */       if (key == Scannable.Attr.PARENT) return this.qs; 
/* 532 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 533 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 535 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public T poll() {
/* 541 */       if (this.sourceMode == 2) {
/* 542 */         long dropped = 0L;
/*     */         while (true) {
/* 544 */           T v = (T)this.qs.poll();
/* 545 */           if (v == null) {
/* 546 */             return null;
/*     */           }
/*     */           try {
/* 549 */             K r = Objects.requireNonNull(this.keyExtractor.apply(v), "The keyExtractor returned a null collection");
/*     */ 
/*     */             
/* 552 */             if (this.distinctPredicate.test(this.collection, r)) {
/* 553 */               if (dropped != 0L) {
/* 554 */                 request(dropped);
/*     */               }
/* 556 */               return v;
/*     */             } 
/* 558 */             Operators.onDiscard(v, this.ctx);
/* 559 */             dropped++;
/*     */           }
/* 561 */           catch (Throwable error) {
/* 562 */             Operators.onDiscard(v, this.ctx);
/* 563 */             throw error;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/*     */       while (true) {
/* 569 */         T v = (T)this.qs.poll();
/* 570 */         if (v == null) {
/* 571 */           return null;
/*     */         }
/*     */         try {
/* 574 */           K r = Objects.requireNonNull(this.keyExtractor.apply(v), "The keyExtractor returned a null collection");
/*     */ 
/*     */           
/* 577 */           if (this.distinctPredicate.test(this.collection, r)) {
/* 578 */             return v;
/*     */           }
/*     */           
/* 581 */           Operators.onDiscard(v, this.ctx);
/*     */         
/*     */         }
/* 584 */         catch (Throwable error) {
/* 585 */           Operators.onDiscard(v, this.ctx);
/* 586 */           throw error;
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isEmpty() {
/* 594 */       return this.qs.isEmpty();
/*     */     }
/*     */ 
/*     */     
/*     */     public void clear() {
/* 599 */       this.qs.clear();
/* 600 */       this.cleanupCallback.accept(this.collection);
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 605 */       return this.qs.size();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\FluxDistinct.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */