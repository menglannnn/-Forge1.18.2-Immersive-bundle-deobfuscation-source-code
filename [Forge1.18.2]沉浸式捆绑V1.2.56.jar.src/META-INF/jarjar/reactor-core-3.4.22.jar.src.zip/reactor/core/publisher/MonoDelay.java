/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.RejectedExecutionException;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.core.scheduler.Scheduler;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MonoDelay
/*     */   extends Mono<Long>
/*     */   implements Scannable, SourceProducer<Long>
/*     */ {
/*     */   final Scheduler timedScheduler;
/*     */   final long delay;
/*     */   final TimeUnit unit;
/*     */   static final String CONTEXT_OPT_OUT_NOBACKPRESSURE = "reactor.core.publisher.MonoDelay.failOnBackpressure";
/*     */   
/*     */   MonoDelay(long delay, TimeUnit unit, Scheduler timedScheduler) {
/*  46 */     this.delay = delay;
/*  47 */     this.unit = Objects.<TimeUnit>requireNonNull(unit, "unit");
/*  48 */     this.timedScheduler = Objects.<Scheduler>requireNonNull(timedScheduler, "timedScheduler");
/*     */   }
/*     */ 
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super Long> actual) {
/*  53 */     boolean failOnBackpressure = (actual.currentContext().getOrDefault("reactor.core.publisher.MonoDelay.failOnBackpressure", Boolean.valueOf(false)) == Boolean.TRUE);
/*     */     
/*  55 */     MonoDelayRunnable r = new MonoDelayRunnable(actual, failOnBackpressure);
/*     */     
/*  57 */     actual.onSubscribe(r);
/*     */     
/*     */     try {
/*  60 */       r.setCancel(this.timedScheduler.schedule(r, this.delay, this.unit));
/*     */     }
/*  62 */     catch (RejectedExecutionException ree) {
/*  63 */       if (!MonoDelayRunnable.wasCancelled(r.state)) {
/*  64 */         actual.onError(Operators.onRejectedExecution(ree, r, null, null, actual
/*  65 */               .currentContext()));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  72 */     if (key == Scannable.Attr.RUN_ON) return this.timedScheduler; 
/*  73 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.ASYNC;
/*     */     
/*  75 */     return null;
/*     */   }
/*     */   
/*     */   static final class MonoDelayRunnable
/*     */     implements Runnable, InnerProducer<Long>
/*     */   {
/*     */     final CoreSubscriber<? super Long> actual;
/*     */     final boolean failOnBackpressure;
/*     */     Disposable cancel;
/*     */     volatile int state;
/*  85 */     static final AtomicIntegerFieldUpdater<MonoDelayRunnable> STATE = AtomicIntegerFieldUpdater.newUpdater(MonoDelayRunnable.class, "state");
/*     */     
/*     */     static final byte FLAG_CANCELLED = 64;
/*     */     
/*     */     static final byte FLAG_REQUESTED = 32;
/*     */     
/*     */     static final byte FLAG_REQUESTED_EARLY = 16;
/*     */     
/*     */     static final byte FLAG_CANCEL_SET = 1;
/*     */     
/*     */     static final byte FLAG_DELAY_DONE = 2;
/*     */     
/*     */     static final byte FLAG_PROPAGATED = 4;
/*     */ 
/*     */     
/*     */     MonoDelayRunnable(CoreSubscriber<? super Long> actual, boolean failOnBackpressure) {
/* 101 */       this.actual = actual;
/* 102 */       this.failOnBackpressure = failOnBackpressure;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     static int markCancelFutureSet(MonoDelayRunnable instance) {
/*     */       while (true) {
/* 112 */         int state = instance.state;
/* 113 */         if (wasCancelled(state) || wasCancelFutureSet(state)) {
/* 114 */           return state;
/*     */         }
/*     */         
/* 117 */         if (STATE.compareAndSet(instance, state, state | 0x1)) {
/* 118 */           return state;
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     static boolean wasCancelFutureSet(int state) {
/* 127 */       return ((state & 0x1) == 1);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     static int markCancelled(MonoDelayRunnable instance) {
/*     */       while (true) {
/* 136 */         int state = instance.state;
/* 137 */         if (wasCancelled(state) || wasPropagated(state)) {
/* 138 */           return state;
/*     */         }
/*     */         
/* 141 */         if (STATE.compareAndSet(instance, state, state | 0x40)) {
/* 142 */           return state;
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     static boolean wasCancelled(int state) {
/* 151 */       return ((state & 0x40) == 64);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     static int markDelayDone(MonoDelayRunnable instance) {
/*     */       while (true) {
/* 161 */         int state = instance.state;
/* 162 */         if (wasCancelled(state) || wasDelayDone(state)) {
/* 163 */           return state;
/*     */         }
/*     */         
/* 166 */         if (STATE.compareAndSet(instance, state, state | 0x2)) {
/* 167 */           return state;
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     static boolean wasDelayDone(int state) {
/* 176 */       return ((state & 0x2) == 2);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     static int markRequested(MonoDelayRunnable instance) {
/*     */       while (true) {
/* 187 */         int state = instance.state;
/* 188 */         if (wasCancelled(state) || wasRequested(state)) {
/* 189 */           return state;
/*     */         }
/* 191 */         int newFlag = 32;
/* 192 */         if (!wasDelayDone(state)) {
/* 193 */           newFlag |= 0x10;
/*     */         }
/*     */         
/* 196 */         if (STATE.compareAndSet(instance, state, state | newFlag)) {
/* 197 */           return state;
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     static boolean wasRequested(int state) {
/* 206 */       return ((state & 0x20) == 32);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     static int markPropagated(MonoDelayRunnable instance) {
/*     */       while (true) {
/* 215 */         int state = instance.state;
/* 216 */         if (wasCancelled(state)) {
/* 217 */           return state;
/*     */         }
/*     */         
/* 220 */         if (STATE.compareAndSet(instance, state, state | 0x4)) {
/* 221 */           return state;
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     static boolean wasPropagated(int state) {
/* 230 */       return ((state & 0x4) == 4);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super Long> actual() {
/* 236 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 242 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf((wasDelayDone(this.state) && wasRequested(this.state))); 
/* 243 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf(wasRequested(this.state) ? 1L : 0L); 
/* 244 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(wasCancelled(this.state)); 
/* 245 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.ASYNC;
/*     */       
/* 247 */       return super.scanUnsafe(key);
/*     */     }
/*     */     
/*     */     void setCancel(Disposable cancel) {
/* 251 */       Disposable c = this.cancel;
/* 252 */       this.cancel = cancel;
/* 253 */       int previousState = markCancelFutureSet(this);
/* 254 */       if (wasCancelFutureSet(previousState)) {
/* 255 */         if (c != null) {
/* 256 */           c.dispose();
/*     */         }
/*     */         return;
/*     */       } 
/* 260 */       if (wasCancelled(previousState)) {
/* 261 */         cancel.dispose();
/*     */       }
/*     */     }
/*     */     
/*     */     private void propagateDelay() {
/* 266 */       int previousState = markPropagated(this);
/* 267 */       if (wasCancelled(previousState)) {
/*     */         return;
/*     */       }
/*     */       try {
/* 271 */         this.actual.onNext(Long.valueOf(0L));
/* 272 */         this.actual.onComplete();
/*     */       }
/* 274 */       catch (Throwable t) {
/* 275 */         this.actual.onError(Operators.onOperatorError(t, this.actual.currentContext()));
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void run() {
/* 281 */       int previousState = markDelayDone(this);
/* 282 */       if (wasCancelled(previousState) || wasDelayDone(previousState)) {
/*     */         return;
/*     */       }
/* 285 */       if (wasRequested(previousState)) {
/* 286 */         propagateDelay();
/*     */       }
/* 288 */       else if (this.failOnBackpressure) {
/* 289 */         this.actual.onError(Exceptions.failWithOverflow("Could not emit value due to lack of requests"));
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 295 */       int previousState = markCancelled(this);
/* 296 */       if (wasCancelled(previousState) || wasPropagated(previousState)) {
/*     */         return;
/*     */       }
/*     */       
/* 300 */       if (wasCancelFutureSet(previousState)) {
/* 301 */         this.cancel.dispose();
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 308 */       if (Operators.validate(n)) {
/* 309 */         int previousState = markRequested(this);
/* 310 */         if (wasCancelled(previousState) || wasRequested(previousState)) {
/*     */           return;
/*     */         }
/* 313 */         if (wasDelayDone(previousState) && !this.failOnBackpressure)
/* 314 */           propagateDelay(); 
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\MonoDelay.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */