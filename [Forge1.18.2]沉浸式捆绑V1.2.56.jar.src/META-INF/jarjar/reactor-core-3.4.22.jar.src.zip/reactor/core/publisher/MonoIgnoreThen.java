/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MonoIgnoreThen<T>
/*     */   extends Mono<T>
/*     */   implements Scannable
/*     */ {
/*     */   final Publisher<?>[] ignore;
/*     */   final Mono<T> last;
/*     */   
/*     */   MonoIgnoreThen(Publisher<?>[] ignore, Mono<T> last) {
/*  43 */     this.ignore = (Publisher<?>[])Objects.requireNonNull(ignore, "ignore");
/*  44 */     this.last = Objects.<Mono<T>>requireNonNull(last, "last");
/*     */   }
/*     */ 
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super T> actual) {
/*  49 */     ThenIgnoreMain<T> manager = new ThenIgnoreMain<>(actual, this.ignore, this.last);
/*  50 */     actual.onSubscribe(manager);
/*  51 */     manager.subscribeNext();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   <U> MonoIgnoreThen<U> shift(Mono<U> newLast) {
/*  61 */     Objects.requireNonNull(newLast, "newLast");
/*  62 */     Publisher<?>[] a = this.ignore;
/*  63 */     int n = a.length;
/*  64 */     Publisher[] arrayOfPublisher = new Publisher[n + 1];
/*  65 */     System.arraycopy(a, 0, arrayOfPublisher, 0, n);
/*  66 */     arrayOfPublisher[n] = (Publisher)this.last;
/*     */     
/*  68 */     return new MonoIgnoreThen((Publisher<?>[])arrayOfPublisher, newLast);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  73 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  74 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   static final class ThenIgnoreMain<T>
/*     */     implements InnerOperator<T, T>
/*     */   {
/*     */     final Publisher<?>[] ignoreMonos;
/*     */     
/*     */     final Mono<T> lastMono;
/*     */     
/*     */     final CoreSubscriber<? super T> actual;
/*     */     
/*     */     T value;
/*     */     int index;
/*     */     Subscription activeSubscription;
/*     */     boolean done;
/*     */     volatile int state;
/*  92 */     private static final AtomicIntegerFieldUpdater<ThenIgnoreMain> STATE = AtomicIntegerFieldUpdater.newUpdater(ThenIgnoreMain.class, "state");
/*     */     
/*     */     static final int HAS_REQUEST = 2;
/*     */     
/*     */     static final int HAS_SUBSCRIPTION = 4;
/*     */     
/*     */     static final int HAS_VALUE = 8;
/*     */     static final int HAS_COMPLETION = 16;
/*     */     static final int CANCELLED = 128;
/*     */     
/*     */     ThenIgnoreMain(CoreSubscriber<? super T> subscriber, Publisher<?>[] ignoreMonos, Mono<T> lastMono) {
/* 103 */       this.actual = subscriber;
/* 104 */       this.ignoreMonos = ignoreMonos;
/* 105 */       this.lastMono = lastMono;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 111 */       if (key == Scannable.Attr.PARENT) return this.activeSubscription; 
/* 112 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(isCancelled(this.state)); 
/* 113 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 115 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 120 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 125 */       if (Operators.validate(this.activeSubscription, s)) {
/* 126 */         this.activeSubscription = s;
/*     */         
/* 128 */         int previousState = markHasSubscription();
/* 129 */         if (isCancelled(previousState)) {
/* 130 */           s.cancel();
/*     */           
/*     */           return;
/*     */         } 
/* 134 */         s.request(Long.MAX_VALUE);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 140 */       int previousState = markCancelled();
/*     */       
/* 142 */       if (hasSubscription(previousState)) {
/* 143 */         this.activeSubscription.cancel();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 149 */       if (Operators.validate(n)) {
/*     */         while (true) {
/* 151 */           int state = this.state;
/* 152 */           if (isCancelled(state)) {
/*     */             return;
/*     */           }
/* 155 */           if (hasRequest(state)) {
/*     */             return;
/*     */           }
/* 158 */           if (STATE.compareAndSet(this, state, state | 0x2)) {
/* 159 */             if (hasValue(state)) {
/* 160 */               CoreSubscriber<? super T> actual = this.actual;
/* 161 */               T v = this.value;
/*     */               
/* 163 */               actual.onNext(v);
/* 164 */               actual.onComplete();
/*     */             } 
/*     */             return;
/*     */           } 
/*     */         } 
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 174 */       if (this.done) {
/* 175 */         Operators.onDiscard(t, currentContext());
/*     */         
/*     */         return;
/*     */       } 
/* 179 */       if (this.index != this.ignoreMonos.length) {
/*     */         
/* 181 */         Operators.onDiscard(t, currentContext());
/*     */         
/*     */         return;
/*     */       } 
/* 185 */       this.done = true;
/*     */       
/* 187 */       complete(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 192 */       if (this.done) {
/*     */         return;
/*     */       }
/*     */       
/* 196 */       if (this.index != this.ignoreMonos.length) {
/* 197 */         int previousState = markUnsubscribed();
/* 198 */         if (isCancelled(previousState)) {
/*     */           return;
/*     */         }
/* 201 */         this.activeSubscription = null;
/* 202 */         this.index++;
/* 203 */         subscribeNext();
/*     */         
/*     */         return;
/*     */       } 
/* 207 */       this.done = true;
/*     */       
/* 209 */       this.actual.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     void subscribeNext() {
/* 214 */       Publisher<?> m, a[] = this.ignoreMonos;
/*     */       
/*     */       while (true) {
/* 217 */         int i = this.index;
/*     */         
/* 219 */         if (i == a.length) {
/* 220 */           Mono<T> mono = this.lastMono;
/* 221 */           if (mono instanceof Callable) {
/* 222 */             T v; if (isCancelled(this.state)) {
/*     */               return;
/*     */             }
/*     */ 
/*     */             
/*     */             try {
/* 228 */               v = ((Callable<T>)mono).call();
/*     */             }
/* 230 */             catch (Throwable ex) {
/* 231 */               onError(Operators.onOperatorError(ex, currentContext()));
/*     */               
/*     */               return;
/*     */             } 
/* 235 */             if (v != null) {
/* 236 */               onNext(v);
/*     */             }
/* 238 */             onComplete();
/*     */           } else {
/* 240 */             mono.subscribe(this);
/*     */           } 
/*     */           return;
/*     */         } 
/* 244 */         m = a[i];
/*     */         
/* 246 */         if (m instanceof Callable) {
/* 247 */           if (isCancelled(this.state)) {
/*     */             return;
/*     */           }
/*     */           
/*     */           try {
/* 252 */             Operators.onDiscard(((Callable)m).call(), currentContext());
/*     */           }
/* 254 */           catch (Throwable ex) {
/* 255 */             T v; onError(Operators.onOperatorError((Throwable)v, currentContext()));
/*     */             
/*     */             return;
/*     */           } 
/* 259 */           this.index = i + 1; continue;
/*     */         } 
/*     */         break;
/*     */       } 
/* 263 */       m.subscribe((Subscriber)this);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 271 */       if (this.done) {
/* 272 */         Operators.onErrorDropped(t, actual().currentContext());
/*     */         
/*     */         return;
/*     */       } 
/* 276 */       this.done = true;
/*     */       
/* 278 */       this.actual.onError(t);
/*     */     }
/*     */     final void complete(T value) {
/*     */       int s;
/*     */       do {
/* 283 */         s = this.state;
/* 284 */         if (isCancelled(s)) {
/* 285 */           Operators.onDiscard(value, this.actual.currentContext());
/*     */           
/*     */           return;
/*     */         } 
/* 289 */         if (hasRequest(s) && STATE.compareAndSet(this, s, s | 0x18)) {
/* 290 */           CoreSubscriber<? super T> actual = this.actual;
/*     */           
/* 292 */           actual.onNext(value);
/* 293 */           actual.onComplete();
/*     */           
/*     */           return;
/*     */         } 
/* 297 */         this.value = value;
/* 298 */       } while (!STATE.compareAndSet(this, s, s | 0x18));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     final int markHasSubscription() {
/*     */       while (true) {
/* 306 */         int state = this.state;
/*     */         
/* 308 */         if (state == 128) {
/* 309 */           return state;
/*     */         }
/*     */         
/* 312 */         if ((state & 0x4) == 4) {
/* 313 */           return state;
/*     */         }
/*     */         
/* 316 */         if (STATE.compareAndSet(this, state, state | 0x4)) {
/* 317 */           return state;
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*     */     final int markUnsubscribed() {
/*     */       while (true) {
/* 324 */         int state = this.state;
/*     */         
/* 326 */         if (isCancelled(state)) {
/* 327 */           return state;
/*     */         }
/*     */         
/* 330 */         if (!hasSubscription(state)) {
/* 331 */           return state;
/*     */         }
/*     */         
/* 334 */         if (STATE.compareAndSet(this, state, state & 0xFFFFFFFB)) {
/* 335 */           return state;
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*     */     final int markCancelled() {
/*     */       while (true) {
/* 342 */         int state = this.state;
/*     */         
/* 344 */         if (state == 128) {
/* 345 */           return state;
/*     */         }
/*     */         
/* 348 */         if (STATE.compareAndSet(this, state, 128)) {
/* 349 */           return state;
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*     */     static boolean isCancelled(int s) {
/* 355 */       return (s == 128);
/*     */     }
/*     */     
/*     */     static boolean hasSubscription(int s) {
/* 359 */       return ((s & 0x4) == 4);
/*     */     }
/*     */     
/*     */     static boolean hasRequest(int s) {
/* 363 */       return ((s & 0x2) == 2);
/*     */     }
/*     */     
/*     */     static boolean hasValue(int s) {
/* 367 */       return ((s & 0x8) == 8);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\MonoIgnoreThen.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */