/*      */ package reactor.core.publisher;
/*      */ 
/*      */ import java.util.Objects;
/*      */ import java.util.concurrent.CancellationException;
/*      */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*      */ import java.util.function.BiFunction;
/*      */ import org.reactivestreams.Publisher;
/*      */ import org.reactivestreams.Subscriber;
/*      */ import org.reactivestreams.Subscription;
/*      */ import reactor.core.CoreSubscriber;
/*      */ import reactor.core.Exceptions;
/*      */ import reactor.core.Fuseable;
/*      */ import reactor.core.Scannable;
/*      */ import reactor.util.annotation.Nullable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ final class FluxSwitchOnFirst<T, R>
/*      */   extends InternalFluxOperator<T, R>
/*      */ {
/*      */   final BiFunction<Signal<? extends T>, Flux<T>, Publisher<? extends R>> transformer;
/*      */   final boolean cancelSourceOnComplete;
/*      */   static final int HAS_FIRST_VALUE_RECEIVED_FLAG = 1;
/*      */   static final int HAS_INBOUND_SUBSCRIBED_ONCE_FLAG = 2;
/*      */   static final int HAS_INBOUND_SUBSCRIBER_SET_FLAG = 4;
/*      */   static final int HAS_INBOUND_REQUESTED_ONCE_FLAG = 8;
/*      */   static final int HAS_FIRST_VALUE_SENT_FLAG = 16;
/*      */   static final int HAS_INBOUND_CANCELLED_FLAG = 32;
/*      */   static final int HAS_INBOUND_CLOSED_PREMATURELY_FLAG = 64;
/*      */   static final int HAS_INBOUND_TERMINATED_FLAG = 128;
/*      */   static final int HAS_OUTBOUND_SUBSCRIBED_FLAG = 256;
/*      */   static final int HAS_OUTBOUND_CANCELLED_FLAG = 512;
/*      */   static final int HAS_OUTBOUND_TERMINATED_FLAG = 1024;
/*      */   
/*      */   FluxSwitchOnFirst(Flux<? extends T> source, BiFunction<Signal<? extends T>, Flux<T>, Publisher<? extends R>> transformer, boolean cancelSourceOnComplete) {
/*   44 */     super(source);
/*   45 */     this.transformer = Objects.<BiFunction<Signal<? extends T>, Flux<T>, Publisher<? extends R>>>requireNonNull(transformer, "transformer");
/*   46 */     this.cancelSourceOnComplete = cancelSourceOnComplete;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getPrefetch() {
/*   51 */     return 1;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super R> actual) {
/*   57 */     if (actual instanceof Fuseable.ConditionalSubscriber) {
/*   58 */       return new SwitchOnFirstConditionalMain<>((Fuseable.ConditionalSubscriber<? super R>)actual, this.transformer, this.cancelSourceOnComplete, null);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*   63 */     return new SwitchOnFirstMain<>(actual, this.transformer, this.cancelSourceOnComplete);
/*      */   }
/*      */ 
/*      */   
/*      */   public Object scanUnsafe(Scannable.Attr key) {
/*   68 */     if (key == Scannable.Attr.RUN_STYLE) {
/*   69 */       return Scannable.Attr.RunStyle.SYNC;
/*      */     }
/*   71 */     return super.scanUnsafe(key);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static <T, R> long markFirstValueReceived(AbstractSwitchOnFirstMain<T, R> instance) {
/*      */     while (true) {
/*  106 */       int state = instance.state;
/*      */       
/*  108 */       if (hasInboundCancelled(state) || hasInboundClosedPrematurely(state)) {
/*  109 */         return state;
/*      */       }
/*      */       
/*  112 */       int nextState = state | 0x1;
/*  113 */       if (AbstractSwitchOnFirstMain.STATE.compareAndSet(instance, state, nextState)) {
/*  114 */         if (instance.logger != null) {
/*  115 */           instance.logger.log(instance.toString(), "mfvr", state, nextState);
/*      */         }
/*  117 */         return state;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static <T, R> long markInboundSubscribedOnce(AbstractSwitchOnFirstMain<T, R> instance) {
/*      */     while (true) {
/*  130 */       int state = instance.state;
/*      */       
/*  132 */       if (hasInboundSubscribedOnce(state)) {
/*  133 */         return state;
/*      */       }
/*      */       
/*  136 */       int nextState = state | 0x2;
/*  137 */       if (AbstractSwitchOnFirstMain.STATE.compareAndSet(instance, state, nextState)) {
/*  138 */         if (instance.logger != null) {
/*  139 */           instance.logger.log(instance.toString(), "miso", state, nextState);
/*      */         }
/*  141 */         return state;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static <T, R> long markInboundSubscriberSet(AbstractSwitchOnFirstMain<T, R> instance) {
/*      */     while (true) {
/*  154 */       int state = instance.state;
/*      */       
/*  156 */       if (hasInboundCancelled(state) || hasInboundClosedPrematurely(state)) {
/*  157 */         return state;
/*      */       }
/*      */       
/*  160 */       int nextState = state | 0x4;
/*  161 */       if (AbstractSwitchOnFirstMain.STATE.compareAndSet(instance, state, nextState)) {
/*  162 */         if (instance.logger != null) {
/*  163 */           instance.logger.log(instance.toString(), "miss", state, nextState);
/*      */         }
/*  165 */         return state;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static <T, R> long markInboundRequestedOnce(AbstractSwitchOnFirstMain<T, R> instance) {
/*      */     while (true) {
/*  178 */       int state = instance.state;
/*      */       
/*  180 */       if (hasInboundCancelled(state) || hasInboundClosedPrematurely(state)) {
/*  181 */         return state;
/*      */       }
/*      */       
/*  184 */       int nextState = state | 0x8;
/*  185 */       if (AbstractSwitchOnFirstMain.STATE.compareAndSet(instance, state, nextState)) {
/*  186 */         if (instance.logger != null) {
/*  187 */           instance.logger.log(instance.toString(), "miro", state, nextState);
/*      */         }
/*  189 */         return state;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static <T, R> long markFirstValueSent(AbstractSwitchOnFirstMain<T, R> instance) {
/*      */     while (true) {
/*  202 */       int state = instance.state;
/*      */       
/*  204 */       if (hasInboundCancelled(state) || hasInboundClosedPrematurely(state)) {
/*  205 */         return state;
/*      */       }
/*      */       
/*  208 */       int nextState = state | 0x10;
/*  209 */       if (AbstractSwitchOnFirstMain.STATE.compareAndSet(instance, state, nextState)) {
/*  210 */         if (instance.logger != null) {
/*  211 */           instance.logger.log(instance.toString(), "mfvs", state, nextState);
/*      */         }
/*  213 */         return state;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static <T, R> long markInboundTerminated(AbstractSwitchOnFirstMain<T, R> instance) {
/*      */     while (true) {
/*  226 */       int state = instance.state;
/*      */       
/*  228 */       if (hasInboundCancelled(state) || hasInboundClosedPrematurely(state)) {
/*  229 */         return state;
/*      */       }
/*      */       
/*  232 */       int nextState = state | 0x80;
/*  233 */       if (AbstractSwitchOnFirstMain.STATE.compareAndSet(instance, state, nextState)) {
/*  234 */         if (instance.logger != null) {
/*  235 */           instance.logger.log(instance.toString(), "mitd", state, nextState);
/*      */         }
/*  237 */         return state;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static <T, R> long markInboundCancelled(AbstractSwitchOnFirstMain<T, R> instance) {
/*      */     while (true) {
/*  250 */       int state = instance.state;
/*      */       
/*  252 */       if (hasInboundCancelled(state)) {
/*  253 */         return state;
/*      */       }
/*      */       
/*  256 */       int nextState = state | 0x20;
/*  257 */       if (AbstractSwitchOnFirstMain.STATE.compareAndSet(instance, state, nextState)) {
/*  258 */         if (instance.logger != null) {
/*  259 */           instance.logger.log(instance.toString(), "micd", state, nextState);
/*      */         }
/*  261 */         return state;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static <T, R> long markInboundClosedPrematurely(AbstractSwitchOnFirstMain<T, R> instance) {
/*      */     while (true) {
/*  274 */       int state = instance.state;
/*      */       
/*  276 */       if (hasInboundTerminated(state) || hasInboundCancelled(state)) {
/*  277 */         return state;
/*      */       }
/*      */       
/*  280 */       int nextState = state | 0x40;
/*  281 */       if (AbstractSwitchOnFirstMain.STATE.compareAndSet(instance, state, nextState)) {
/*  282 */         if (instance.logger != null) {
/*  283 */           instance.logger.log(instance.toString(), "micp", state, nextState);
/*      */         }
/*  285 */         return state;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static <T, R> long markInboundCancelledAndOutboundTerminated(AbstractSwitchOnFirstMain<T, R> instance) {
/*      */     while (true) {
/*  303 */       int state = instance.state;
/*      */       
/*  305 */       if (hasInboundCancelled(state) || hasOutboundCancelled(state)) {
/*  306 */         return state;
/*      */       }
/*      */       
/*  309 */       int nextState = state | 0x20 | 0x400;
/*      */       
/*  311 */       if (AbstractSwitchOnFirstMain.STATE.compareAndSet(instance, state, nextState)) {
/*  312 */         if (instance.logger != null) {
/*  313 */           instance.logger.log(instance.toString(), "icot", state, nextState);
/*      */         }
/*  315 */         return state;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static <T, R> long markOutboundSubscribed(AbstractSwitchOnFirstMain<T, R> instance) {
/*      */     while (true) {
/*  328 */       int state = instance.state;
/*      */       
/*  330 */       if (hasOutboundCancelled(state)) {
/*  331 */         return state;
/*      */       }
/*      */       
/*  334 */       int nextState = state | 0x100;
/*  335 */       if (AbstractSwitchOnFirstMain.STATE.compareAndSet(instance, state, nextState)) {
/*  336 */         if (instance.logger != null) {
/*  337 */           instance.logger.log(instance.toString(), "mosd", state, nextState);
/*      */         }
/*  339 */         return state;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static <T, R> long markOutboundTerminated(AbstractSwitchOnFirstMain<T, R> instance) {
/*      */     while (true) {
/*  353 */       int state = instance.state;
/*      */       
/*  355 */       if (hasOutboundCancelled(state) || hasOutboundTerminated(state)) {
/*  356 */         return state;
/*      */       }
/*      */       
/*  359 */       int nextState = state | 0x400;
/*  360 */       if (AbstractSwitchOnFirstMain.STATE.compareAndSet(instance, state, nextState)) {
/*  361 */         if (instance.logger != null) {
/*  362 */           instance.logger.log(instance.toString(), "motd", state, nextState);
/*      */         }
/*  364 */         return state;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static <T, R> long markOutboundCancelled(AbstractSwitchOnFirstMain<T, R> instance) {
/*      */     while (true) {
/*  377 */       int state = instance.state;
/*      */       
/*  379 */       if (hasOutboundTerminated(state) || hasOutboundCancelled(state)) {
/*  380 */         return state;
/*      */       }
/*      */       
/*  383 */       int nextState = state | 0x200;
/*  384 */       if (AbstractSwitchOnFirstMain.STATE.compareAndSet(instance, state, nextState)) {
/*  385 */         if (instance.logger != null) {
/*  386 */           instance.logger.log(instance.toString(), "mocd", state, nextState);
/*      */         }
/*  388 */         return state;
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   static boolean hasInboundCancelled(long state) {
/*  394 */     return ((state & 0x20L) == 32L);
/*      */   }
/*      */   
/*      */   static boolean hasInboundClosedPrematurely(long state) {
/*  398 */     return ((state & 0x40L) == 64L);
/*      */   }
/*      */   
/*      */   static boolean hasInboundTerminated(long state) {
/*  402 */     return ((state & 0x80L) == 128L);
/*      */   }
/*      */   
/*      */   static boolean hasFirstValueReceived(long state) {
/*  406 */     return ((state & 0x1L) == 1L);
/*      */   }
/*      */   
/*      */   static boolean hasFirstValueSent(long state) {
/*  410 */     return ((state & 0x10L) == 16L);
/*      */   }
/*      */   
/*      */   static boolean hasInboundSubscribedOnce(long state) {
/*  414 */     return ((state & 0x2L) == 2L);
/*      */   }
/*      */   
/*      */   static boolean hasInboundSubscriberSet(long state) {
/*  418 */     return ((state & 0x4L) == 4L);
/*      */   }
/*      */   
/*      */   static boolean hasInboundRequestedOnce(long state) {
/*  422 */     return ((state & 0x8L) == 8L);
/*      */   }
/*      */   
/*      */   static boolean hasOutboundSubscribed(long state) {
/*  426 */     return ((state & 0x100L) == 256L);
/*      */   }
/*      */   
/*      */   static boolean hasOutboundCancelled(long state) {
/*  430 */     return ((state & 0x200L) == 512L);
/*      */   }
/*      */   
/*      */   static boolean hasOutboundTerminated(long state) {
/*  434 */     return ((state & 0x400L) == 1024L);
/*      */   }
/*      */ 
/*      */   
/*      */   static abstract class AbstractSwitchOnFirstMain<T, R>
/*      */     extends Flux<T>
/*      */     implements InnerOperator<T, R>
/*      */   {
/*      */     @Nullable
/*      */     final StateLogger logger;
/*      */     
/*      */     final FluxSwitchOnFirst.SwitchOnFirstControlSubscriber<? super R> outboundSubscriber;
/*      */     
/*      */     final BiFunction<Signal<? extends T>, Flux<T>, Publisher<? extends R>> transformer;
/*      */     
/*      */     Subscription s;
/*      */     
/*      */     boolean isInboundRequestedOnce;
/*      */     
/*      */     boolean isFirstOnNextReceivedOnce;
/*      */     
/*      */     T firstValue;
/*      */     
/*      */     Throwable throwable;
/*      */     boolean done;
/*      */     CoreSubscriber<? super T> inboundSubscriber;
/*      */     volatile int state;
/*  461 */     static final AtomicIntegerFieldUpdater<AbstractSwitchOnFirstMain> STATE = AtomicIntegerFieldUpdater.newUpdater(AbstractSwitchOnFirstMain.class, "state");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     AbstractSwitchOnFirstMain(CoreSubscriber<? super R> outboundSubscriber, BiFunction<Signal<? extends T>, Flux<T>, Publisher<? extends R>> transformer, boolean cancelSourceOnComplete, @Nullable StateLogger logger) {
/*  468 */       this.outboundSubscriber = (outboundSubscriber instanceof Fuseable.ConditionalSubscriber) ? new FluxSwitchOnFirst.SwitchOnFirstConditionalControlSubscriber<>(this, (Fuseable.ConditionalSubscriber<? super R>)outboundSubscriber, cancelSourceOnComplete) : new FluxSwitchOnFirst.SwitchOnFirstControlSubscriber<>(this, outboundSubscriber, cancelSourceOnComplete);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  474 */       this.transformer = transformer;
/*  475 */       this.logger = logger;
/*      */     }
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     public final Object scanUnsafe(Scannable.Attr key) {
/*  481 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf((FluxSwitchOnFirst.hasInboundCancelled(this.state) || FluxSwitchOnFirst.hasInboundClosedPrematurely(this.state))); 
/*  482 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf((FluxSwitchOnFirst.hasInboundTerminated(this.state) || FluxSwitchOnFirst.hasInboundClosedPrematurely(this.state))); 
/*  483 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*      */       
/*  485 */       return super.scanUnsafe(key);
/*      */     }
/*      */ 
/*      */     
/*      */     public final CoreSubscriber<? super R> actual() {
/*  490 */       return this.outboundSubscriber;
/*      */     }
/*      */ 
/*      */     
/*      */     public final void onSubscribe(Subscription s) {
/*  495 */       if (Operators.validate(this.s, s)) {
/*  496 */         this.s = s;
/*  497 */         this.outboundSubscriber.sendSubscription();
/*  498 */         if (!FluxSwitchOnFirst.hasInboundCancelled(this.state)) {
/*  499 */           s.request(1L);
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public final void onNext(T t) {
/*  506 */       if (this.done) {
/*  507 */         Operators.onNextDropped(t, currentContext());
/*      */         
/*      */         return;
/*      */       } 
/*  511 */       if (!this.isFirstOnNextReceivedOnce) {
/*  512 */         Publisher<? extends R> outboundPublisher; this.isFirstOnNextReceivedOnce = true;
/*  513 */         this.firstValue = t;
/*      */         
/*  515 */         long previousState = FluxSwitchOnFirst.markFirstValueReceived(this);
/*  516 */         if (FluxSwitchOnFirst.hasInboundCancelled(previousState) || FluxSwitchOnFirst.hasInboundClosedPrematurely(previousState)) {
/*  517 */           this.firstValue = null;
/*  518 */           Operators.onDiscard(t, this.outboundSubscriber.currentContext());
/*      */           
/*      */           return;
/*      */         } 
/*      */         
/*  523 */         FluxSwitchOnFirst.SwitchOnFirstControlSubscriber<? super R> o = this.outboundSubscriber;
/*      */         
/*      */         try {
/*  526 */           Signal<T> signal = Signal.next(t, o.currentContext());
/*  527 */           outboundPublisher = Objects.<Publisher<? extends R>>requireNonNull(this.transformer.apply(signal, this), "The transformer returned a null value");
/*      */         }
/*  529 */         catch (Throwable e) {
/*  530 */           this.done = true;
/*      */           
/*  532 */           previousState = FluxSwitchOnFirst.markInboundCancelledAndOutboundTerminated(this);
/*  533 */           if (FluxSwitchOnFirst.hasInboundCancelled(previousState) || FluxSwitchOnFirst.hasOutboundCancelled(previousState)) {
/*  534 */             Operators.onErrorDropped(e, o.currentContext());
/*      */             
/*      */             return;
/*      */           } 
/*  538 */           this.firstValue = null;
/*  539 */           Operators.onDiscard(t, o.currentContext());
/*      */           
/*  541 */           o.errorDirectly(Operators.onOperatorError(this.s, e, t, o.currentContext()));
/*      */           
/*      */           return;
/*      */         } 
/*  545 */         outboundPublisher.subscribe((Subscriber)o);
/*      */         
/*      */         return;
/*      */       } 
/*  549 */       synchronized (this) {
/*  550 */         this.inboundSubscriber.onNext(t);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public final void onError(Throwable t) {
/*  556 */       if (this.done) {
/*  557 */         Operators.onErrorDropped(t, this.outboundSubscriber.currentContext());
/*      */         
/*      */         return;
/*      */       } 
/*  561 */       this.done = true;
/*  562 */       this.throwable = t;
/*      */       
/*  564 */       long previousState = FluxSwitchOnFirst.markInboundTerminated(this);
/*  565 */       if (FluxSwitchOnFirst.hasInboundCancelled(previousState) || FluxSwitchOnFirst.hasInboundTerminated(previousState) || FluxSwitchOnFirst.hasInboundClosedPrematurely(previousState)) {
/*  566 */         Operators.onErrorDropped(t, this.outboundSubscriber.currentContext());
/*      */         
/*      */         return;
/*      */       } 
/*  570 */       if (FluxSwitchOnFirst.hasFirstValueSent(previousState)) {
/*  571 */         synchronized (this) {
/*  572 */           this.inboundSubscriber.onError(t);
/*      */         } 
/*      */         
/*      */         return;
/*      */       } 
/*  577 */       if (!FluxSwitchOnFirst.hasFirstValueReceived(previousState)) {
/*      */         Publisher<? extends R> result;
/*  579 */         CoreSubscriber<? super R> o = this.outboundSubscriber;
/*      */         try {
/*  581 */           Signal<T> signal = Signal.error(t, o.currentContext());
/*  582 */           result = Objects.<Publisher<? extends R>>requireNonNull(this.transformer.apply(signal, this), "The transformer returned a null value");
/*      */         }
/*  584 */         catch (Throwable e) {
/*  585 */           o.onError(Exceptions.addSuppressed(t, e));
/*      */           
/*      */           return;
/*      */         } 
/*  589 */         result.subscribe((Subscriber)o);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public final void onComplete() {
/*  595 */       if (this.done) {
/*      */         return;
/*      */       }
/*      */       
/*  599 */       this.done = true;
/*      */       
/*  601 */       long previousState = FluxSwitchOnFirst.markInboundTerminated(this);
/*  602 */       if (FluxSwitchOnFirst.hasInboundCancelled(previousState) || FluxSwitchOnFirst.hasInboundTerminated(previousState) || FluxSwitchOnFirst.hasInboundClosedPrematurely(previousState)) {
/*      */         return;
/*      */       }
/*      */       
/*  606 */       if (FluxSwitchOnFirst.hasFirstValueSent(previousState)) {
/*  607 */         synchronized (this) {
/*  608 */           this.inboundSubscriber.onComplete();
/*      */         } 
/*      */         
/*      */         return;
/*      */       } 
/*  613 */       if (!FluxSwitchOnFirst.hasFirstValueReceived(previousState)) {
/*      */         Publisher<? extends R> result;
/*  615 */         CoreSubscriber<? super R> o = this.outboundSubscriber;
/*      */         
/*      */         try {
/*  618 */           Signal<T> signal = Signal.complete(o.currentContext());
/*  619 */           result = Objects.<Publisher<? extends R>>requireNonNull(this.transformer.apply(signal, this), "The transformer returned a null value");
/*      */         }
/*  621 */         catch (Throwable e) {
/*  622 */           o.onError(e);
/*      */           
/*      */           return;
/*      */         } 
/*  626 */         result.subscribe((Subscriber)o);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public final void cancel() {
/*  632 */       long previousState = FluxSwitchOnFirst.markInboundCancelled(this);
/*  633 */       if (FluxSwitchOnFirst.hasInboundCancelled(previousState) || FluxSwitchOnFirst.hasInboundTerminated(previousState) || FluxSwitchOnFirst.hasInboundClosedPrematurely(previousState)) {
/*      */         return;
/*      */       }
/*      */       
/*  637 */       this.s.cancel();
/*      */       
/*  639 */       if (FluxSwitchOnFirst.hasFirstValueReceived(previousState) && !FluxSwitchOnFirst.hasInboundRequestedOnce(previousState)) {
/*  640 */         T f = this.firstValue;
/*  641 */         this.firstValue = null;
/*  642 */         Operators.onDiscard(f, currentContext());
/*      */       } 
/*      */     }
/*      */     
/*      */     final void cancelAndError() {
/*  647 */       long previousState = FluxSwitchOnFirst.markInboundClosedPrematurely(this);
/*  648 */       if (FluxSwitchOnFirst.hasInboundCancelled(previousState) || FluxSwitchOnFirst.hasInboundTerminated(previousState)) {
/*      */         return;
/*      */       }
/*      */       
/*  652 */       this.s.cancel();
/*      */       
/*  654 */       if (FluxSwitchOnFirst.hasFirstValueReceived(previousState) && !FluxSwitchOnFirst.hasFirstValueSent(previousState)) {
/*  655 */         if (!FluxSwitchOnFirst.hasInboundRequestedOnce(previousState)) {
/*  656 */           T f = this.firstValue;
/*  657 */           this.firstValue = null;
/*  658 */           Operators.onDiscard(f, currentContext());
/*      */           
/*  660 */           if (FluxSwitchOnFirst.hasInboundSubscriberSet(previousState)) {
/*  661 */             this.inboundSubscriber.onError(new CancellationException("FluxSwitchOnFirst has already been cancelled"));
/*      */           }
/*      */         } 
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/*  668 */       if (FluxSwitchOnFirst.hasInboundSubscriberSet(previousState)) {
/*  669 */         synchronized (this) {
/*  670 */           this.inboundSubscriber.onError(new CancellationException("FluxSwitchOnFirst has already been cancelled"));
/*      */         } 
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*      */     public final void request(long n) {
/*  677 */       if (Operators.validate(n)) {
/*      */ 
/*      */         
/*  680 */         if (!this.isInboundRequestedOnce) {
/*  681 */           this.isInboundRequestedOnce = true;
/*      */           
/*  683 */           if (this.isFirstOnNextReceivedOnce) {
/*  684 */             long previousState = FluxSwitchOnFirst.markInboundRequestedOnce(this);
/*  685 */             if (FluxSwitchOnFirst.hasInboundCancelled(previousState) || FluxSwitchOnFirst.hasInboundClosedPrematurely(previousState)) {
/*      */               return;
/*      */             }
/*      */             
/*  689 */             T first = this.firstValue;
/*  690 */             this.firstValue = null;
/*      */             
/*  692 */             boolean wasDelivered = sendFirst(first);
/*  693 */             if (wasDelivered && 
/*  694 */               n != Long.MAX_VALUE) {
/*  695 */               if (--n > 0L) {
/*  696 */                 this.s.request(n);
/*      */               }
/*      */               
/*      */               return;
/*      */             } 
/*      */           } 
/*      */         } 
/*      */         
/*  704 */         this.s.request(n);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public final void subscribe(CoreSubscriber<? super T> inboundSubscriber) {
/*  710 */       long previousState = FluxSwitchOnFirst.markInboundSubscribedOnce(this);
/*  711 */       if (FluxSwitchOnFirst.hasInboundSubscribedOnce(previousState)) {
/*  712 */         Operators.error((Subscriber<?>)inboundSubscriber, new IllegalStateException("FluxSwitchOnFirst allows only one Subscriber"));
/*      */         
/*      */         return;
/*      */       } 
/*  716 */       if (FluxSwitchOnFirst.hasInboundClosedPrematurely(previousState)) {
/*  717 */         Operators.error((Subscriber<?>)inboundSubscriber, new CancellationException("FluxSwitchOnFirst has already been cancelled"));
/*      */         
/*      */         return;
/*      */       } 
/*  721 */       if (!FluxSwitchOnFirst.hasFirstValueReceived(previousState)) {
/*  722 */         Throwable t = this.throwable;
/*  723 */         if (t != null) {
/*  724 */           Operators.error((Subscriber<?>)inboundSubscriber, t);
/*      */         } else {
/*      */           
/*  727 */           Operators.complete((Subscriber<?>)inboundSubscriber);
/*      */         } 
/*      */         
/*      */         return;
/*      */       } 
/*  732 */       this.inboundSubscriber = convert(inboundSubscriber);
/*      */       
/*  734 */       inboundSubscriber.onSubscribe(this);
/*      */       
/*  736 */       previousState = FluxSwitchOnFirst.markInboundSubscriberSet(this);
/*  737 */       if (FluxSwitchOnFirst.hasInboundClosedPrematurely(previousState) && (
/*  738 */         !FluxSwitchOnFirst.hasInboundRequestedOnce(previousState) || FluxSwitchOnFirst.hasFirstValueSent(previousState)) && 
/*  739 */         !FluxSwitchOnFirst.hasInboundCancelled(previousState)) {
/*  740 */         inboundSubscriber.onError(new CancellationException("FluxSwitchOnFirst has already been cancelled"));
/*      */       }
/*      */     }
/*      */     
/*      */     abstract CoreSubscriber<? super T> convert(CoreSubscriber<? super T> param1CoreSubscriber);
/*      */     
/*      */     final boolean sendFirst(T firstValue) {
/*  747 */       CoreSubscriber<? super T> a = this.inboundSubscriber;
/*      */       
/*  749 */       boolean sent = tryDirectSend(a, firstValue);
/*      */       
/*  751 */       long previousState = FluxSwitchOnFirst.markFirstValueSent(this);
/*  752 */       if (FluxSwitchOnFirst.hasInboundCancelled(previousState)) {
/*  753 */         return sent;
/*      */       }
/*      */       
/*  756 */       if (FluxSwitchOnFirst.hasInboundClosedPrematurely(previousState)) {
/*  757 */         a.onError(new CancellationException("FluxSwitchOnFirst has already been cancelled"));
/*  758 */         return sent;
/*      */       } 
/*      */       
/*  761 */       if (FluxSwitchOnFirst.hasInboundTerminated(previousState)) {
/*  762 */         Throwable t = this.throwable;
/*  763 */         if (t != null) {
/*  764 */           a.onError(t);
/*      */         } else {
/*      */           
/*  767 */           a.onComplete();
/*      */         } 
/*      */       } 
/*      */       
/*  771 */       return sent;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     abstract boolean tryDirectSend(CoreSubscriber<? super T> param1CoreSubscriber, T param1T);
/*      */   }
/*      */ 
/*      */   
/*      */   static final class SwitchOnFirstMain<T, R>
/*      */     extends AbstractSwitchOnFirstMain<T, R>
/*      */   {
/*      */     SwitchOnFirstMain(CoreSubscriber<? super R> outer, BiFunction<Signal<? extends T>, Flux<T>, Publisher<? extends R>> transformer, boolean cancelSourceOnComplete) {
/*  784 */       super(outer, transformer, cancelSourceOnComplete, (StateLogger)null);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     SwitchOnFirstMain(CoreSubscriber<? super R> outer, BiFunction<Signal<? extends T>, Flux<T>, Publisher<? extends R>> transformer, boolean cancelSourceOnComplete, @Nullable StateLogger logger) {
/*  791 */       super(outer, transformer, cancelSourceOnComplete, logger);
/*      */     }
/*      */ 
/*      */     
/*      */     CoreSubscriber<? super T> convert(CoreSubscriber<? super T> inboundSubscriber) {
/*  796 */       return inboundSubscriber;
/*      */     }
/*      */ 
/*      */     
/*      */     boolean tryDirectSend(CoreSubscriber<? super T> actual, T t) {
/*  801 */       actual.onNext(t);
/*  802 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static final class SwitchOnFirstConditionalMain<T, R>
/*      */     extends AbstractSwitchOnFirstMain<T, R>
/*      */     implements Fuseable.ConditionalSubscriber<T>
/*      */   {
/*      */     SwitchOnFirstConditionalMain(Fuseable.ConditionalSubscriber<? super R> outer, BiFunction<Signal<? extends T>, Flux<T>, Publisher<? extends R>> transformer, boolean cancelSourceOnComplete) {
/*  813 */       super((CoreSubscriber<? super R>)outer, transformer, cancelSourceOnComplete, (StateLogger)null);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     SwitchOnFirstConditionalMain(Fuseable.ConditionalSubscriber<? super R> outer, BiFunction<Signal<? extends T>, Flux<T>, Publisher<? extends R>> transformer, boolean cancelSourceOnComplete, @Nullable StateLogger logger) {
/*  820 */       super((CoreSubscriber<? super R>)outer, transformer, cancelSourceOnComplete, logger);
/*      */     }
/*      */ 
/*      */     
/*      */     CoreSubscriber<? super T> convert(CoreSubscriber<? super T> inboundSubscriber) {
/*  825 */       return (CoreSubscriber<? super T>)Operators.toConditionalSubscriber(inboundSubscriber);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean tryOnNext(T t) {
/*  831 */       if (this.done) {
/*  832 */         Operators.onNextDropped(t, currentContext());
/*  833 */         return false;
/*      */       } 
/*      */       
/*  836 */       if (!this.isFirstOnNextReceivedOnce) {
/*  837 */         Publisher<? extends R> result; this.isFirstOnNextReceivedOnce = true;
/*  838 */         this.firstValue = t;
/*      */         
/*  840 */         long previousState = FluxSwitchOnFirst.markFirstValueReceived(this);
/*  841 */         if (FluxSwitchOnFirst.hasInboundCancelled(previousState)) {
/*  842 */           this.firstValue = null;
/*  843 */           Operators.onDiscard(t, this.outboundSubscriber.currentContext());
/*  844 */           return true;
/*      */         } 
/*      */ 
/*      */         
/*  848 */         FluxSwitchOnFirst.SwitchOnFirstControlSubscriber<? super R> o = this.outboundSubscriber;
/*      */         
/*      */         try {
/*  851 */           Signal<T> signal = Signal.next(t, o.currentContext());
/*  852 */           result = Objects.<Publisher<? extends R>>requireNonNull(this.transformer.apply(signal, this), "The transformer returned a null value");
/*      */         
/*      */         }
/*  855 */         catch (Throwable e) {
/*  856 */           this.done = true;
/*      */           
/*  858 */           previousState = FluxSwitchOnFirst.markInboundCancelledAndOutboundTerminated(this);
/*  859 */           if (FluxSwitchOnFirst.hasInboundCancelled(previousState) || FluxSwitchOnFirst.hasOutboundCancelled(previousState)) {
/*  860 */             Operators.onErrorDropped(e, o.currentContext());
/*  861 */             return true;
/*      */           } 
/*      */           
/*  864 */           this.firstValue = null;
/*  865 */           Operators.onDiscard(t, o.currentContext());
/*      */           
/*  867 */           o.errorDirectly(Operators.onOperatorError(this.s, e, t, o.currentContext()));
/*  868 */           return true;
/*      */         } 
/*      */         
/*  871 */         result.subscribe((Subscriber)o);
/*  872 */         return true;
/*      */       } 
/*      */       
/*  875 */       synchronized (this) {
/*  876 */         return ((Fuseable.ConditionalSubscriber)this.inboundSubscriber).tryOnNext(t);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     boolean tryDirectSend(CoreSubscriber<? super T> actual, T t) {
/*  883 */       return ((Fuseable.ConditionalSubscriber)actual).tryOnNext(t);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   static class SwitchOnFirstControlSubscriber<T>
/*      */     extends Operators.DeferredSubscription
/*      */     implements InnerOperator<T, T>, CoreSubscriber<T>
/*      */   {
/*      */     final FluxSwitchOnFirst.AbstractSwitchOnFirstMain<?, T> parent;
/*      */     
/*      */     final CoreSubscriber<? super T> delegate;
/*      */     final boolean cancelSourceOnComplete;
/*      */     boolean done;
/*      */     
/*      */     SwitchOnFirstControlSubscriber(FluxSwitchOnFirst.AbstractSwitchOnFirstMain<?, T> parent, CoreSubscriber<? super T> delegate, boolean cancelSourceOnComplete) {
/*  899 */       this.parent = parent;
/*  900 */       this.delegate = delegate;
/*  901 */       this.cancelSourceOnComplete = cancelSourceOnComplete;
/*      */     }
/*      */     
/*      */     final void sendSubscription() {
/*  905 */       this.delegate.onSubscribe(this);
/*      */     }
/*      */ 
/*      */     
/*      */     public final void onSubscribe(Subscription s) {
/*  910 */       if (set(s)) {
/*  911 */         long previousState = FluxSwitchOnFirst.markOutboundSubscribed(this.parent);
/*      */         
/*  913 */         if (FluxSwitchOnFirst.hasOutboundCancelled(previousState)) {
/*  914 */           s.cancel();
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public final CoreSubscriber<? super T> actual() {
/*  921 */       return this.delegate;
/*      */     }
/*      */ 
/*      */     
/*      */     public final void onNext(T t) {
/*  926 */       if (this.done) {
/*  927 */         Operators.onNextDropped(t, currentContext());
/*      */         
/*      */         return;
/*      */       } 
/*  931 */       this.delegate.onNext(t);
/*      */     }
/*      */ 
/*      */     
/*      */     public final void onError(Throwable throwable) {
/*  936 */       if (this.done) {
/*  937 */         Operators.onErrorDropped(throwable, currentContext());
/*      */         
/*      */         return;
/*      */       } 
/*  941 */       this.done = true;
/*      */       
/*  943 */       FluxSwitchOnFirst.AbstractSwitchOnFirstMain<?, T> parent = this.parent;
/*  944 */       long previousState = FluxSwitchOnFirst.markOutboundTerminated(parent);
/*      */       
/*  946 */       if (FluxSwitchOnFirst.hasOutboundCancelled(previousState) || FluxSwitchOnFirst.hasOutboundTerminated(previousState)) {
/*  947 */         Operators.onErrorDropped(throwable, this.delegate.currentContext());
/*      */         
/*      */         return;
/*      */       } 
/*  951 */       if (!FluxSwitchOnFirst.hasInboundCancelled(previousState) && !FluxSwitchOnFirst.hasInboundTerminated(previousState)) {
/*  952 */         parent.cancelAndError();
/*      */       }
/*      */       
/*  955 */       this.delegate.onError(throwable);
/*      */     }
/*      */     
/*      */     final void errorDirectly(Throwable t) {
/*  959 */       this.done = true;
/*      */       
/*  961 */       this.delegate.onError(t);
/*      */     }
/*      */ 
/*      */     
/*      */     public final void onComplete() {
/*  966 */       if (this.done) {
/*      */         return;
/*      */       }
/*      */       
/*  970 */       this.done = true;
/*      */       
/*  972 */       FluxSwitchOnFirst.AbstractSwitchOnFirstMain<?, T> parent = this.parent;
/*  973 */       long previousState = FluxSwitchOnFirst.markOutboundTerminated(parent);
/*      */       
/*  975 */       if (this.cancelSourceOnComplete && !FluxSwitchOnFirst.hasInboundCancelled(previousState) && !FluxSwitchOnFirst.hasInboundTerminated(previousState)) {
/*  976 */         parent.cancelAndError();
/*      */       }
/*      */       
/*  979 */       this.delegate.onComplete();
/*      */     }
/*      */ 
/*      */     
/*      */     public final void cancel() {
/*  984 */       Operators.DeferredSubscription.REQUESTED.lazySet(this, -2L);
/*      */       
/*  986 */       long previousState = FluxSwitchOnFirst.markOutboundCancelled(this.parent);
/*  987 */       if (FluxSwitchOnFirst.hasOutboundCancelled(previousState) || FluxSwitchOnFirst.hasOutboundTerminated(previousState)) {
/*      */         return;
/*      */       }
/*      */ 
/*      */       
/*  992 */       boolean shouldCancelInbound = (!FluxSwitchOnFirst.hasInboundTerminated(previousState) && !FluxSwitchOnFirst.hasInboundCancelled(previousState));
/*      */       
/*  994 */       if (!FluxSwitchOnFirst.hasOutboundSubscribed(previousState)) {
/*  995 */         if (shouldCancelInbound) {
/*  996 */           this.parent.cancel();
/*      */         }
/*      */         
/*      */         return;
/*      */       } 
/* 1001 */       this.s.cancel();
/*      */       
/* 1003 */       if (shouldCancelInbound) {
/* 1004 */         this.parent.cancelAndError();
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*      */     public final Object scanUnsafe(Scannable.Attr key) {
/* 1010 */       if (key == Scannable.Attr.PARENT) return this.parent; 
/* 1011 */       if (key == Scannable.Attr.ACTUAL) return this.delegate; 
/* 1012 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 1013 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(FluxSwitchOnFirst.hasOutboundCancelled(this.parent.state)); 
/* 1014 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(FluxSwitchOnFirst.hasOutboundTerminated(this.parent.state));
/*      */       
/* 1016 */       return null;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   static final class SwitchOnFirstConditionalControlSubscriber<T>
/*      */     extends SwitchOnFirstControlSubscriber<T>
/*      */     implements InnerOperator<T, T>, Fuseable.ConditionalSubscriber<T>
/*      */   {
/*      */     final Fuseable.ConditionalSubscriber<? super T> delegate;
/*      */ 
/*      */     
/*      */     SwitchOnFirstConditionalControlSubscriber(FluxSwitchOnFirst.AbstractSwitchOnFirstMain<?, T> parent, Fuseable.ConditionalSubscriber<? super T> delegate, boolean cancelSourceOnComplete) {
/* 1029 */       super(parent, (CoreSubscriber<? super T>)delegate, cancelSourceOnComplete);
/* 1030 */       this.delegate = delegate;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean tryOnNext(T t) {
/* 1035 */       if (this.done) {
/* 1036 */         Operators.onNextDropped(t, currentContext());
/* 1037 */         return true;
/*      */       } 
/*      */       
/* 1040 */       return this.delegate.tryOnNext(t);
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\FluxSwitchOnFirst.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */