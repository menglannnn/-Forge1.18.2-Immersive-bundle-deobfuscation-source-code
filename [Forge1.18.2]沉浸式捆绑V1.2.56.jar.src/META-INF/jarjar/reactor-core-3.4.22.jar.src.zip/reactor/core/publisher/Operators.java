/*      */ package reactor.core.publisher;
/*      */ 
/*      */ import java.util.Collection;
/*      */ import java.util.Iterator;
/*      */ import java.util.Objects;
/*      */ import java.util.Queue;
/*      */ import java.util.concurrent.RejectedExecutionException;
/*      */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*      */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*      */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*      */ import java.util.function.BiFunction;
/*      */ import java.util.function.Consumer;
/*      */ import java.util.function.Function;
/*      */ import java.util.function.Predicate;
/*      */ import java.util.stream.Stream;
/*      */ import org.reactivestreams.Publisher;
/*      */ import org.reactivestreams.Subscriber;
/*      */ import org.reactivestreams.Subscription;
/*      */ import reactor.core.CorePublisher;
/*      */ import reactor.core.CoreSubscriber;
/*      */ import reactor.core.Exceptions;
/*      */ import reactor.core.Fuseable;
/*      */ import reactor.core.Scannable;
/*      */ import reactor.util.Logger;
/*      */ import reactor.util.Loggers;
/*      */ import reactor.util.annotation.Nullable;
/*      */ import reactor.util.context.Context;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class Operators
/*      */ {
/*      */   public static long addCap(long a, long b) {
/*   71 */     long res = a + b;
/*   72 */     if (res < 0L) {
/*   73 */       return Long.MAX_VALUE;
/*      */     }
/*   75 */     return res;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> long addCap(AtomicLongFieldUpdater<T> updater, T instance, long toAdd) {
/*      */     while (true) {
/*   91 */       long r = updater.get(instance);
/*   92 */       if (r == Long.MAX_VALUE) {
/*   93 */         return Long.MAX_VALUE;
/*      */       }
/*   95 */       long u = addCap(r, toAdd);
/*   96 */       if (updater.compareAndSet(instance, r, u)) {
/*   97 */         return r;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public static <T> Fuseable.QueueSubscription<T> as(Subscription s) {
/*  110 */     if (s instanceof Fuseable.QueueSubscription) {
/*  111 */       return (Fuseable.QueueSubscription<T>)s;
/*      */     }
/*  113 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Subscription cancelledSubscription() {
/*  127 */     return CancelledSubscription.INSTANCE;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void complete(Subscriber<?> s) {
/*  136 */     s.onSubscribe((Subscription)EmptySubscription.INSTANCE);
/*  137 */     s.onComplete();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> CoreSubscriber<T> drainSubscriber() {
/*  149 */     return DrainSubscriber.INSTANCE;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> CoreSubscriber<T> emptySubscriber() {
/*  161 */     return (CoreSubscriber)EMPTY_SUBSCRIBER;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Subscription emptySubscription() {
/*  175 */     return (Subscription)EmptySubscription.INSTANCE;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean canAppearAfterOnSubscribe(Subscription subscription) {
/*  186 */     return (subscription == EmptySubscription.FROM_SUBSCRIBE_INSTANCE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void error(Subscriber<?> s, Throwable e) {
/*  197 */     s.onSubscribe((Subscription)EmptySubscription.INSTANCE);
/*  198 */     s.onError(e);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void reportThrowInSubscribe(CoreSubscriber<?> subscriber, Throwable e) {
/*      */     try {
/*  226 */       subscriber.onSubscribe((Subscription)EmptySubscription.FROM_SUBSCRIBE_INSTANCE);
/*      */     }
/*  228 */     catch (Throwable onSubscribeError) {
/*  229 */       Exceptions.throwIfFatal(onSubscribeError);
/*  230 */       e.addSuppressed(onSubscribeError);
/*      */     } 
/*  232 */     subscriber.onError(onOperatorError(e, subscriber.currentContext()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <I, O> Function<? super Publisher<I>, ? extends Publisher<O>> lift(BiFunction<Scannable, ? super CoreSubscriber<? super O>, ? extends CoreSubscriber<? super I>> lifter) {
/*  260 */     return LiftFunction.liftScannable(null, lifter);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <O> Function<? super Publisher<O>, ? extends Publisher<O>> lift(Predicate<Scannable> filter, BiFunction<Scannable, ? super CoreSubscriber<? super O>, ? extends CoreSubscriber<? super O>> lifter) {
/*  296 */     return LiftFunction.liftScannable(filter, lifter);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <I, O> Function<? super Publisher<I>, ? extends Publisher<O>> liftPublisher(BiFunction<Publisher, ? super CoreSubscriber<? super O>, ? extends CoreSubscriber<? super I>> lifter) {
/*  320 */     return LiftFunction.liftPublisher(null, lifter);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <O> Function<? super Publisher<O>, ? extends Publisher<O>> liftPublisher(Predicate<Publisher> filter, BiFunction<Publisher, ? super CoreSubscriber<? super O>, ? extends CoreSubscriber<? super O>> lifter) {
/*  351 */     return LiftFunction.liftPublisher(filter, lifter);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long multiplyCap(long a, long b) {
/*  363 */     long u = a * b;
/*  364 */     if ((a | b) >>> 31L != 0L && 
/*  365 */       u / a != b) {
/*  366 */       return Long.MAX_VALUE;
/*      */     }
/*      */     
/*  369 */     return u;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final <R> Function<Context, Context> discardLocalAdapter(Class<R> type, Consumer<? super R> discardHook) {
/*  384 */     Objects.requireNonNull(type, "onDiscard must be based on a type");
/*  385 */     Objects.requireNonNull(discardHook, "onDiscard must be provided a discardHook Consumer");
/*      */     
/*  387 */     Consumer<Object> safeConsumer = obj -> {
/*      */         if (type.isInstance(obj)) {
/*      */           discardHook.accept(type.cast(obj));
/*      */         }
/*      */       };
/*      */     
/*  393 */     return ctx -> {
/*      */         Consumer<Object> consumer = (Consumer<Object>)ctx.getOrDefault("reactor.onDiscard.local", null);
/*      */         return (consumer == null) ? ctx.put("reactor.onDiscard.local", safeConsumer) : ctx.put("reactor.onDiscard.local", safeConsumer.andThen(consumer));
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final Context enableOnDiscard(@Nullable Context target, Consumer<?> discardConsumer) {
/*  414 */     Objects.requireNonNull(discardConsumer, "discardConsumer must be provided");
/*  415 */     if (target == null) {
/*  416 */       return Context.of("reactor.onDiscard.local", discardConsumer);
/*      */     }
/*  418 */     return target.put("reactor.onDiscard.local", discardConsumer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> void onDiscard(@Nullable T element, Context context) {
/*  438 */     Consumer<Object> hook = (Consumer<Object>)context.getOrDefault("reactor.onDiscard.local", null);
/*  439 */     if (element != null && hook != null) {
/*      */       try {
/*  441 */         hook.accept(element);
/*      */       }
/*  443 */       catch (Throwable t) {
/*  444 */         log.warn("Error in discard hook", t);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> void onDiscardQueueWithClear(@Nullable Queue<T> queue, Context context, @Nullable Function<T, Stream<?>> extract) {
/*  468 */     if (queue == null) {
/*      */       return;
/*      */     }
/*      */     
/*  472 */     Consumer<Object> hook = (Consumer<Object>)context.getOrDefault("reactor.onDiscard.local", null);
/*  473 */     if (hook == null) {
/*  474 */       queue.clear();
/*      */       
/*      */       return;
/*      */     } 
/*      */     try {
/*      */       while (true) {
/*  480 */         T toDiscard = queue.poll();
/*  481 */         if (toDiscard == null) {
/*      */           break;
/*      */         }
/*      */         
/*  485 */         if (extract != null) {
/*      */           try {
/*  487 */             ((Stream)extract.apply(toDiscard))
/*  488 */               .forEach(elementToDiscard -> {
/*      */                   
/*      */                   try {
/*      */                     hook.accept(elementToDiscard);
/*  492 */                   } catch (Throwable t) {
/*      */                     
/*      */                     log.warn("Error while discarding item extracted from a queue element, continuing with next item", t);
/*      */                   } 
/*      */                 });
/*  497 */           } catch (Throwable t) {
/*  498 */             log.warn("Error while extracting items to discard from queue element, continuing with next queue element", t);
/*      */           } 
/*      */           continue;
/*      */         } 
/*      */         try {
/*  503 */           hook.accept(toDiscard);
/*      */         }
/*  505 */         catch (Throwable t) {
/*  506 */           log.warn("Error while discarding a queue element, continuing with next queue element", t);
/*      */         }
/*      */       
/*      */       }
/*      */     
/*  511 */     } catch (Throwable t) {
/*  512 */       log.warn("Cannot further apply discard hook while discarding and clearing a queue", t);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void onDiscardMultiple(Stream<?> multiple, Context context) {
/*  529 */     Consumer<Object> hook = (Consumer<Object>)context.getOrDefault("reactor.onDiscard.local", null);
/*  530 */     if (hook != null) {
/*      */       try {
/*  532 */         multiple.filter(Objects::nonNull)
/*  533 */           .forEach(v -> {
/*      */               
/*      */               try {
/*      */                 hook.accept(v);
/*  537 */               } catch (Throwable t) {
/*      */                 
/*      */                 log.warn("Error while discarding a stream element, continuing with next element", t);
/*      */               } 
/*      */             });
/*  542 */       } catch (Throwable t) {
/*  543 */         log.warn("Error while discarding stream, stopping", t);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void onDiscardMultiple(@Nullable Collection<?> multiple, Context context) {
/*  560 */     if (multiple == null)
/*  561 */       return;  Consumer<Object> hook = (Consumer<Object>)context.getOrDefault("reactor.onDiscard.local", null);
/*  562 */     if (hook != null) {
/*      */       try {
/*  564 */         if (multiple.isEmpty()) {
/*      */           return;
/*      */         }
/*  567 */         for (Object o : multiple) {
/*  568 */           if (o != null) {
/*      */             try {
/*  570 */               hook.accept(o);
/*      */             }
/*  572 */             catch (Throwable t) {
/*  573 */               log.warn("Error while discarding element from a Collection, continuing with next element", t);
/*      */             }
/*      */           
/*      */           }
/*      */         } 
/*  578 */       } catch (Throwable t) {
/*  579 */         log.warn("Error while discarding collection, stopping", t);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void onDiscardMultiple(@Nullable Iterator<?> multiple, boolean knownToBeFinite, Context context) {
/*  598 */     if (multiple == null)
/*  599 */       return;  if (!knownToBeFinite)
/*      */       return; 
/*  601 */     Consumer<Object> hook = (Consumer<Object>)context.getOrDefault("reactor.onDiscard.local", null);
/*  602 */     if (hook != null) {
/*      */       try {
/*  604 */         multiple.forEachRemaining(o -> {
/*      */               
/*      */               if (o != null) {
/*      */                 try {
/*      */                   hook.accept(o);
/*  609 */                 } catch (Throwable t) {
/*      */                   
/*      */                   log.warn("Error while discarding element from an Iterator, continuing with next element", t);
/*      */                 } 
/*      */               }
/*      */             });
/*  615 */       } catch (Throwable t) {
/*  616 */         log.warn("Error while discarding Iterator, stopping", t);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void onErrorDropped(Throwable e, Context context) {
/*  631 */     Consumer<? super Throwable> hook = (Consumer<? super Throwable>)context.getOrDefault("reactor.onErrorDropped.local", null);
/*  632 */     if (hook == null) {
/*  633 */       hook = Hooks.onErrorDroppedHook;
/*      */     }
/*  635 */     if (hook == null) {
/*  636 */       log.error("Operator called default onErrorDropped", e);
/*      */       return;
/*      */     } 
/*  639 */     hook.accept(e);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> void onNextDropped(T t, Context context) {
/*  653 */     Objects.requireNonNull(t, "onNext");
/*  654 */     Objects.requireNonNull(context, "context");
/*  655 */     Consumer<Object> hook = (Consumer<Object>)context.getOrDefault("reactor.onNextDropped.local", null);
/*  656 */     if (hook == null) {
/*  657 */       hook = Hooks.onNextDroppedHook;
/*      */     }
/*  659 */     if (hook != null) {
/*  660 */       hook.accept(t);
/*      */     }
/*  662 */     else if (log.isDebugEnabled()) {
/*  663 */       log.debug("onNextDropped: " + t);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Throwable onOperatorError(Throwable error, Context context) {
/*  679 */     return onOperatorError(null, error, context);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Throwable onOperatorError(@Nullable Subscription subscription, Throwable error, Context context) {
/*  697 */     return onOperatorError(subscription, error, null, context);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Throwable onOperatorError(@Nullable Subscription subscription, Throwable error, @Nullable Object dataSignal, Context context) {
/*  719 */     Exceptions.throwIfFatal(error);
/*  720 */     if (subscription != null) {
/*  721 */       subscription.cancel();
/*      */     }
/*      */     
/*  724 */     Throwable t = Exceptions.unwrap(error);
/*      */     
/*  726 */     BiFunction<? super Throwable, Object, ? extends Throwable> hook = (BiFunction<? super Throwable, Object, ? extends Throwable>)context.getOrDefault("reactor.onOperatorError.local", null);
/*  727 */     if (hook == null) {
/*  728 */       hook = Hooks.onOperatorErrorHook;
/*      */     }
/*  730 */     if (hook == null) {
/*  731 */       if (dataSignal != null && 
/*  732 */         dataSignal != t && dataSignal instanceof Throwable) {
/*  733 */         t = Exceptions.addSuppressed(t, (Throwable)dataSignal);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  739 */       return t;
/*      */     } 
/*  741 */     return hook.apply(error, dataSignal);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static RuntimeException onRejectedExecution(Throwable original, Context context) {
/*  757 */     return onRejectedExecution(original, null, null, null, context);
/*      */   }
/*      */   
/*      */   static final OnNextFailureStrategy onNextErrorStrategy(Context context) {
/*  761 */     OnNextFailureStrategy strategy = null;
/*      */     
/*  763 */     BiFunction<? super Throwable, Object, ? extends Throwable> fn = (BiFunction<? super Throwable, Object, ? extends Throwable>)context.getOrDefault("reactor.onNextError.localStrategy", null);
/*      */     
/*  765 */     if (fn instanceof OnNextFailureStrategy) {
/*  766 */       strategy = (OnNextFailureStrategy)fn;
/*  767 */     } else if (fn != null) {
/*  768 */       strategy = new OnNextFailureStrategy.LambdaOnNextErrorStrategy(fn);
/*      */     } 
/*      */     
/*  771 */     if (strategy == null) strategy = Hooks.onNextErrorHook; 
/*  772 */     if (strategy == null) strategy = OnNextFailureStrategy.STOP; 
/*  773 */     return strategy;
/*      */   }
/*      */   
/*      */   public static final BiFunction<? super Throwable, Object, ? extends Throwable> onNextErrorFunction(Context context) {
/*  777 */     return onNextErrorStrategy(context);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public static <T> Throwable onNextError(@Nullable T value, Throwable error, Context context, Subscription subscriptionForCancel) {
/*  820 */     error = unwrapOnNextError(error);
/*  821 */     OnNextFailureStrategy strategy = onNextErrorStrategy(context);
/*  822 */     if (strategy.test(error, value)) {
/*      */       
/*  824 */       Throwable t = strategy.process(error, value, context);
/*  825 */       if (t != null) {
/*  826 */         subscriptionForCancel.cancel();
/*      */       }
/*  828 */       return t;
/*      */     } 
/*      */ 
/*      */     
/*  832 */     return onOperatorError(subscriptionForCancel, error, value, context);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public static <T> Throwable onNextError(@Nullable T value, Throwable error, Context context) {
/*  854 */     error = unwrapOnNextError(error);
/*  855 */     OnNextFailureStrategy strategy = onNextErrorStrategy(context);
/*  856 */     if (strategy.test(error, value))
/*      */     {
/*  858 */       return strategy.process(error, value, context);
/*      */     }
/*      */     
/*  861 */     return onOperatorError(null, error, value, context);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Throwable onNextInnerError(Throwable error, Context context, @Nullable Subscription subscriptionForCancel) {
/*  879 */     error = unwrapOnNextError(error);
/*  880 */     OnNextFailureStrategy strategy = onNextErrorStrategy(context);
/*  881 */     if (strategy.test(error, (Object)null)) {
/*      */       
/*  883 */       Throwable t = strategy.process(error, null, context);
/*  884 */       if (t != null && subscriptionForCancel != null) {
/*  885 */         subscriptionForCancel.cancel();
/*      */       }
/*  887 */       return t;
/*      */     } 
/*      */     
/*  890 */     return error;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public static <T> RuntimeException onNextPollError(@Nullable T value, Throwable error, Context context) {
/*  918 */     error = unwrapOnNextError(error);
/*  919 */     OnNextFailureStrategy strategy = onNextErrorStrategy(context);
/*  920 */     if (strategy.test(error, value)) {
/*      */       
/*  922 */       Throwable throwable = strategy.process(error, value, context);
/*  923 */       if (throwable != null) return Exceptions.propagate(throwable); 
/*  924 */       return null;
/*      */     } 
/*      */     
/*  927 */     Throwable t = onOperatorError(null, error, value, context);
/*  928 */     return Exceptions.propagate(t);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> CorePublisher<T> onLastAssembly(CorePublisher<T> source) {
/*  942 */     Function<Publisher, Publisher> hook = Hooks.onLastOperatorHook;
/*  943 */     if (hook == null) {
/*  944 */       return source;
/*      */     }
/*      */     
/*  947 */     Publisher<T> publisher = Objects.<Publisher<T>>requireNonNull(hook.apply(source), "LastOperator hook returned null");
/*      */     
/*  949 */     if (publisher instanceof CorePublisher) {
/*  950 */       return (CorePublisher<T>)publisher;
/*      */     }
/*      */     
/*  953 */     return new CorePublisherAdapter<>(publisher);
/*      */   }
/*      */ 
/*      */   
/*      */   private static Throwable unwrapOnNextError(Throwable error) {
/*  958 */     return Exceptions.isBubbling(error) ? error : Exceptions.unwrap(error);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static RuntimeException onRejectedExecution(Throwable original, @Nullable Subscription subscription, @Nullable Throwable suppressed, @Nullable Object dataSignal, Context context) {
/*  982 */     if (context.hasKey("reactor.onRejectedExecution.local")) {
/*  983 */       context = context.put("reactor.onOperatorError.local", context.get("reactor.onRejectedExecution.local"));
/*      */     }
/*      */ 
/*      */     
/*  987 */     RejectedExecutionException ree = Exceptions.failWithRejected(original);
/*  988 */     if (suppressed != null) {
/*  989 */       ree.addSuppressed(suppressed);
/*      */     }
/*  991 */     if (dataSignal != null) {
/*  992 */       return Exceptions.propagate(onOperatorError(subscription, ree, dataSignal, context));
/*      */     }
/*      */     
/*  995 */     return Exceptions.propagate(onOperatorError(subscription, ree, context));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> long produced(AtomicLongFieldUpdater<T> updater, T instance, long toSub) {
/*      */     long r;
/*      */     long u;
/*      */     do {
/* 1012 */       r = updater.get(instance);
/* 1013 */       if (r == 0L || r == Long.MAX_VALUE) {
/* 1014 */         return r;
/*      */       }
/* 1016 */       u = subOrZero(r, toSub);
/* 1017 */     } while (!updater.compareAndSet(instance, r, u));
/*      */     
/* 1019 */     return u;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <F> boolean replace(AtomicReferenceFieldUpdater<F, Subscription> field, F instance, Subscription s) {
/*      */     while (true) {
/* 1038 */       Subscription a = field.get(instance);
/* 1039 */       if (a == CancelledSubscription.INSTANCE) {
/* 1040 */         s.cancel();
/* 1041 */         return false;
/*      */       } 
/* 1043 */       if (field.compareAndSet(instance, a, s)) {
/* 1044 */         return true;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void reportBadRequest(long n) {
/* 1057 */     if (log.isDebugEnabled()) {
/* 1058 */       log.debug("Negative request", 
/* 1059 */           Exceptions.nullOrNegativeRequestException(n));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void reportMoreProduced() {
/* 1070 */     if (log.isDebugEnabled()) {
/* 1071 */       log.debug("More data produced than requested", 
/* 1072 */           Exceptions.failWithOverflow());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void reportSubscriptionSet() {
/* 1082 */     if (log.isDebugEnabled()) {
/* 1083 */       log.debug("Duplicate Subscription has been detected", 
/* 1084 */           Exceptions.duplicateOnSubscribeException());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Subscription scalarSubscription(CoreSubscriber<? super T> subscriber, T value) {
/* 1099 */     return new ScalarSubscription<>(subscriber, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Subscription scalarSubscription(CoreSubscriber<? super T> subscriber, T value, String stepName) {
/* 1115 */     return new ScalarSubscription<>(subscriber, value, stepName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> CoreSubscriber<T> serialize(CoreSubscriber<? super T> subscriber) {
/* 1132 */     return new SerializedSubscriber<>(subscriber);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <F> boolean set(AtomicReferenceFieldUpdater<F, Subscription> field, F instance, Subscription s) {
/*      */     while (true) {
/* 1153 */       Subscription a = field.get(instance);
/* 1154 */       if (a == CancelledSubscription.INSTANCE) {
/* 1155 */         s.cancel();
/* 1156 */         return false;
/*      */       } 
/* 1158 */       if (field.compareAndSet(instance, a, s)) {
/* 1159 */         if (a != null) {
/* 1160 */           a.cancel();
/*      */         }
/* 1162 */         return true;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <F> boolean setOnce(AtomicReferenceFieldUpdater<F, Subscription> field, F instance, Subscription s) {
/* 1181 */     Objects.requireNonNull(s, "subscription");
/* 1182 */     Subscription a = field.get(instance);
/* 1183 */     if (a == CancelledSubscription.INSTANCE) {
/* 1184 */       s.cancel();
/* 1185 */       return false;
/*      */     } 
/* 1187 */     if (a != null) {
/* 1188 */       s.cancel();
/* 1189 */       reportSubscriptionSet();
/* 1190 */       return false;
/*      */     } 
/*      */     
/* 1193 */     if (field.compareAndSet(instance, null, s)) {
/* 1194 */       return true;
/*      */     }
/*      */     
/* 1197 */     a = field.get(instance);
/*      */     
/* 1199 */     if (a == CancelledSubscription.INSTANCE) {
/* 1200 */       s.cancel();
/* 1201 */       return false;
/*      */     } 
/*      */     
/* 1204 */     s.cancel();
/* 1205 */     reportSubscriptionSet();
/* 1206 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long subOrZero(long a, long b) {
/* 1217 */     long res = a - b;
/* 1218 */     if (res < 0L) {
/* 1219 */       return 0L;
/*      */     }
/* 1221 */     return res;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <F> boolean terminate(AtomicReferenceFieldUpdater<F, Subscription> field, F instance) {
/* 1236 */     Subscription a = field.get(instance);
/* 1237 */     if (a != CancelledSubscription.INSTANCE) {
/* 1238 */       a = field.getAndSet(instance, CancelledSubscription.INSTANCE);
/* 1239 */       if (a != null && a != CancelledSubscription.INSTANCE) {
/* 1240 */         a.cancel();
/* 1241 */         return true;
/*      */       } 
/*      */     } 
/* 1244 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean validate(@Nullable Subscription current, Subscription next) {
/* 1256 */     Objects.requireNonNull(next, "Subscription cannot be null");
/* 1257 */     if (current != null) {
/* 1258 */       next.cancel();
/*      */       
/* 1260 */       return false;
/*      */     } 
/*      */     
/* 1263 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean validate(long n) {
/* 1272 */     if (n <= 0L) {
/* 1273 */       reportBadRequest(n);
/* 1274 */       return false;
/*      */     } 
/* 1276 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> CoreSubscriber<? super T> toCoreSubscriber(Subscriber<? super T> actual) {
/*      */     CoreSubscriber<? super T> _actual;
/* 1292 */     Objects.requireNonNull(actual, "actual");
/*      */ 
/*      */ 
/*      */     
/* 1296 */     if (actual instanceof CoreSubscriber) {
/* 1297 */       _actual = (CoreSubscriber<? super T>)actual;
/*      */     } else {
/*      */       
/* 1300 */       _actual = new StrictSubscriber<>(actual);
/*      */     } 
/*      */     
/* 1303 */     return _actual;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Fuseable.ConditionalSubscriber<? super T> toConditionalSubscriber(CoreSubscriber<? super T> actual) {
/*      */     Fuseable.ConditionalSubscriber<? super T> _actual;
/* 1320 */     Objects.requireNonNull(actual, "actual");
/*      */ 
/*      */ 
/*      */     
/* 1324 */     if (actual instanceof Fuseable.ConditionalSubscriber) {
/* 1325 */       _actual = (Fuseable.ConditionalSubscriber<? super T>)actual;
/*      */     } else {
/*      */       
/* 1328 */       _actual = new ConditionalSubscriberAdapter<>(actual);
/*      */     } 
/*      */     
/* 1331 */     return _actual;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static Context multiSubscribersContext(InnerProducer<?>[] multicastInners) {
/* 1337 */     if (multicastInners.length > 0) {
/* 1338 */       return multicastInners[0].actual().currentContext();
/*      */     }
/* 1340 */     return Context.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static <T> long addCapCancellable(AtomicLongFieldUpdater<T> updater, T instance, long n) {
/*      */     while (true) {
/* 1358 */       long r = updater.get(instance);
/* 1359 */       if (r == Long.MIN_VALUE || r == Long.MAX_VALUE) {
/* 1360 */         return r;
/*      */       }
/* 1362 */       long u = addCap(r, n);
/* 1363 */       if (updater.compareAndSet(instance, r, u)) {
/* 1364 */         return r;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void onErrorDroppedMulticast(Throwable e, InnerProducer<?>[] multicastInners) {
/* 1380 */     onErrorDropped(e, multiSubscribersContext(multicastInners));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static <T> void onNextDroppedMulticast(T t, InnerProducer<?>[] multicastInners) {
/* 1398 */     onNextDropped(t, multiSubscribersContext(multicastInners));
/*      */   }
/*      */   
/*      */   static <T> long producedCancellable(AtomicLongFieldUpdater<T> updater, T instance, long n) {
/*      */     while (true) {
/* 1403 */       long current = updater.get(instance);
/* 1404 */       if (current == Long.MIN_VALUE) {
/* 1405 */         return Long.MIN_VALUE;
/*      */       }
/* 1407 */       if (current == Long.MAX_VALUE) {
/* 1408 */         return Long.MAX_VALUE;
/*      */       }
/* 1410 */       long update = current - n;
/* 1411 */       if (update < 0L) {
/* 1412 */         reportBadRequest(update);
/* 1413 */         update = 0L;
/*      */       } 
/* 1415 */       if (updater.compareAndSet(instance, current, update)) {
/* 1416 */         return update;
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   static long unboundedOrPrefetch(int prefetch) {
/* 1422 */     return (prefetch == Integer.MAX_VALUE) ? Long.MAX_VALUE : prefetch;
/*      */   }
/*      */   
/*      */   static int unboundedOrLimit(int prefetch) {
/* 1426 */     return (prefetch == Integer.MAX_VALUE) ? Integer.MAX_VALUE : (prefetch - (prefetch >> 2));
/*      */   }
/*      */   
/*      */   static int unboundedOrLimit(int prefetch, int lowTide) {
/* 1430 */     if (lowTide <= 0) {
/* 1431 */       return prefetch;
/*      */     }
/* 1433 */     if (lowTide >= prefetch) {
/* 1434 */       return unboundedOrLimit(prefetch);
/*      */     }
/* 1436 */     return (prefetch == Integer.MAX_VALUE) ? Integer.MAX_VALUE : lowTide;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static final class CorePublisherAdapter<T>
/*      */     implements CorePublisher<T>, OptimizableOperator<T, T>
/*      */   {
/*      */     final Publisher<T> publisher;
/*      */     
/*      */     @Nullable
/*      */     final OptimizableOperator<?, T> optimizableOperator;
/*      */ 
/*      */     
/*      */     CorePublisherAdapter(Publisher<T> publisher) {
/* 1451 */       this.publisher = publisher;
/* 1452 */       if (publisher instanceof OptimizableOperator) {
/*      */         
/* 1454 */         OptimizableOperator<?, T> optimSource = (OptimizableOperator)publisher;
/* 1455 */         this.optimizableOperator = optimSource;
/*      */       } else {
/*      */         
/* 1458 */         this.optimizableOperator = null;
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void subscribe(CoreSubscriber<? super T> subscriber) {
/* 1464 */       this.publisher.subscribe((Subscriber)subscriber);
/*      */     }
/*      */ 
/*      */     
/*      */     public void subscribe(Subscriber<? super T> s) {
/* 1469 */       this.publisher.subscribe(s);
/*      */     }
/*      */ 
/*      */     
/*      */     public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/* 1474 */       return actual;
/*      */     }
/*      */ 
/*      */     
/*      */     public final CorePublisher<? extends T> source() {
/* 1479 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public final OptimizableOperator<?, ? extends T> nextOptimizableSource() {
/* 1484 */       return this.optimizableOperator;
/*      */     }
/*      */   }
/*      */   
/* 1488 */   static final Fuseable.ConditionalSubscriber<?> EMPTY_SUBSCRIBER = new Fuseable.ConditionalSubscriber<Object>()
/*      */     {
/*      */       public void onSubscribe(Subscription s) {
/* 1491 */         Throwable e = new IllegalStateException("onSubscribe should not be used");
/* 1492 */         Operators.log.error("Unexpected call to Operators.emptySubscriber()", e);
/*      */       }
/*      */ 
/*      */       
/*      */       public void onNext(Object o) {
/* 1497 */         Throwable e = new IllegalStateException("onNext should not be used, got " + o);
/* 1498 */         Operators.log.error("Unexpected call to Operators.emptySubscriber()", e);
/*      */       }
/*      */ 
/*      */       
/*      */       public boolean tryOnNext(Object o) {
/* 1503 */         Throwable e = new IllegalStateException("tryOnNext should not be used, got " + o);
/* 1504 */         Operators.log.error("Unexpected call to Operators.emptySubscriber()", e);
/* 1505 */         return false;
/*      */       }
/*      */ 
/*      */       
/*      */       public void onError(Throwable t) {
/* 1510 */         Throwable e = new IllegalStateException("onError should not be used", t);
/* 1511 */         Operators.log.error("Unexpected call to Operators.emptySubscriber()", e);
/*      */       }
/*      */ 
/*      */       
/*      */       public void onComplete() {
/* 1516 */         Throwable e = new IllegalStateException("onComplete should not be used");
/* 1517 */         Operators.log.error("Unexpected call to Operators.emptySubscriber()", e);
/*      */       }
/*      */ 
/*      */       
/*      */       public Context currentContext() {
/* 1522 */         return Context.empty();
/*      */       }
/*      */     };
/*      */   
/*      */   static final class CancelledSubscription
/*      */     implements Subscription, Scannable {
/* 1528 */     static final CancelledSubscription INSTANCE = new CancelledSubscription();
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     public Object scanUnsafe(Scannable.Attr key) {
/* 1533 */       if (key == Scannable.Attr.CANCELLED) {
/* 1534 */         return Boolean.valueOf(true);
/*      */       }
/* 1536 */       return null;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void cancel() {}
/*      */ 
/*      */ 
/*      */     
/*      */     public void request(long n) {}
/*      */ 
/*      */ 
/*      */     
/*      */     public String stepName() {
/* 1551 */       return "cancelledSubscription";
/*      */     }
/*      */   }
/*      */   
/*      */   static final class EmptySubscription implements Fuseable.QueueSubscription<Object>, Scannable {
/* 1556 */     static final EmptySubscription INSTANCE = new EmptySubscription();
/* 1557 */     static final EmptySubscription FROM_SUBSCRIBE_INSTANCE = new EmptySubscription();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void cancel() {}
/*      */ 
/*      */ 
/*      */     
/*      */     public void clear() {}
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isEmpty() {
/* 1571 */       return true;
/*      */     }
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     public Object poll() {
/* 1577 */       return null;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void request(long n) {}
/*      */ 
/*      */ 
/*      */     
/*      */     public int requestFusion(int requestedMode) {
/* 1587 */       return 0;
/*      */     }
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     public Object scanUnsafe(Scannable.Attr key) {
/* 1593 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(true); 
/* 1594 */       return null;
/*      */     }
/*      */ 
/*      */     
/*      */     public int size() {
/* 1599 */       return 0;
/*      */     }
/*      */ 
/*      */     
/*      */     public String stepName() {
/* 1604 */       return "emptySubscription";
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public static class DeferredSubscription
/*      */     implements Subscription, Scannable
/*      */   {
/*      */     static final int STATE_CANCELLED = -2;
/*      */     
/*      */     static final int STATE_SUBSCRIBED = -1;
/*      */     
/*      */     Subscription s;
/*      */     
/*      */     volatile long requested;
/*      */ 
/*      */     
/*      */     protected boolean isCancelled() {
/* 1622 */       return (this.requested == -2L);
/*      */     }
/*      */ 
/*      */     
/*      */     public void cancel() {
/* 1627 */       long state = REQUESTED.getAndSet(this, -2L);
/* 1628 */       if (state == -2L) {
/*      */         return;
/*      */       }
/*      */       
/* 1632 */       if (state == -1L) {
/* 1633 */         this.s.cancel();
/*      */       }
/*      */     }
/*      */     
/*      */     protected void terminate() {
/* 1638 */       REQUESTED.getAndSet(this, -2L);
/*      */     }
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     public Object scanUnsafe(Scannable.Attr key) {
/* 1644 */       long requested = this.requested;
/* 1645 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 1646 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf((requested < 0L) ? 0L : requested); 
/* 1647 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(isCancelled());
/*      */       
/* 1649 */       return null;
/*      */     }
/*      */ 
/*      */     
/*      */     public void request(long n) {
/* 1654 */       long r = this.requested;
/*      */       
/* 1656 */       if (r > -1L) {
/*      */         do
/*      */         {
/* 1659 */           if (r == Long.MAX_VALUE) {
/*      */             return;
/*      */           }
/* 1662 */           long u = Operators.addCap(r, n);
/* 1663 */           if (REQUESTED.compareAndSet(this, r, u)) {
/*      */             return;
/*      */           }
/*      */           
/* 1667 */           r = this.requested;
/*      */         }
/* 1669 */         while (r >= 0L);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1676 */       if (r == -2L) {
/*      */         return;
/*      */       }
/*      */       
/* 1680 */       this.s.request(n);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final boolean set(Subscription s) {
/* 1690 */       Objects.requireNonNull(s, "s");
/* 1691 */       long state = this.requested;
/* 1692 */       Subscription a = this.s;
/* 1693 */       if (state == -2L) {
/* 1694 */         s.cancel();
/* 1695 */         return false;
/*      */       } 
/* 1697 */       if (a != null) {
/* 1698 */         s.cancel();
/* 1699 */         Operators.reportSubscriptionSet();
/* 1700 */         return false;
/*      */       } 
/*      */ 
/*      */       
/* 1704 */       long accumulated = 0L;
/*      */       while (true) {
/* 1706 */         long r = this.requested;
/*      */         
/* 1708 */         if (r == -2L || r == -1L) {
/* 1709 */           s.cancel();
/* 1710 */           return false;
/*      */         } 
/*      */         
/* 1713 */         this.s = s;
/*      */         
/* 1715 */         long toRequest = r - accumulated;
/* 1716 */         if (toRequest > 0L) {
/* 1717 */           s.request(toRequest);
/*      */         }
/* 1719 */         accumulated += toRequest;
/*      */         
/* 1721 */         if (REQUESTED.compareAndSet(this, r, -1L)) {
/* 1722 */           return true;
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/* 1728 */     static final AtomicLongFieldUpdater<DeferredSubscription> REQUESTED = AtomicLongFieldUpdater.newUpdater(DeferredSubscription.class, "requested");
/*      */   }
/*      */ 
/*      */   
/*      */   public static class MonoSubscriber<I, O>
/*      */     implements InnerOperator<I, O>, Fuseable, Fuseable.QueueSubscription<O>
/*      */   {
/*      */     protected final CoreSubscriber<? super O> actual;
/*      */     
/*      */     @Nullable
/*      */     protected O value;
/*      */     
/*      */     volatile int state;
/*      */     
/*      */     static final int NO_REQUEST_NO_VALUE = 0;
/*      */     
/*      */     static final int NO_REQUEST_HAS_VALUE = 1;
/*      */     
/*      */     static final int HAS_REQUEST_NO_VALUE = 2;
/*      */     
/*      */     static final int HAS_REQUEST_HAS_VALUE = 3;
/*      */     
/*      */     static final int CANCELLED = 4;
/*      */     static final int FUSED_ASYNC_EMPTY = 8;
/*      */     static final int FUSED_ASYNC_READY = 16;
/*      */     static final int FUSED_ASYNC_CONSUMED = 32;
/*      */     
/*      */     public MonoSubscriber(CoreSubscriber<? super O> actual) {
/* 1756 */       this.actual = actual;
/*      */     }
/*      */ 
/*      */     
/*      */     public void cancel() {
/* 1761 */       O v = this.value;
/* 1762 */       this.value = null;
/* 1763 */       STATE.set(this, 4);
/* 1764 */       discard(v);
/*      */     }
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     public Object scanUnsafe(Scannable.Attr key) {
/* 1770 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(isCancelled()); 
/* 1771 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf((this.state == 3 || this.state == 1)); 
/* 1772 */       if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(2147483647);
/*      */       
/* 1774 */       return super.scanUnsafe(key);
/*      */     }
/*      */ 
/*      */     
/*      */     public final void clear() {
/* 1779 */       STATE.lazySet(this, 32);
/* 1780 */       this.value = null;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final void complete(@Nullable O v) {
/*      */       int state;
/*      */       do {
/* 1792 */         state = this.state;
/* 1793 */         if (state == 8) {
/* 1794 */           setValue(v);
/*      */           
/* 1796 */           if (STATE.compareAndSet(this, 8, 16)) {
/* 1797 */             CoreSubscriber<? super O> coreSubscriber = this.actual;
/* 1798 */             coreSubscriber.onNext(null);
/* 1799 */             coreSubscriber.onComplete();
/*      */             
/*      */             return;
/*      */           } 
/* 1803 */           state = this.state;
/*      */         } 
/*      */ 
/*      */         
/* 1807 */         if ((state & 0xFFFFFFFD) != 0) {
/* 1808 */           this.value = null;
/* 1809 */           discard(v);
/*      */           
/*      */           return;
/*      */         } 
/* 1813 */         if (state == 2 && STATE.compareAndSet(this, 2, 3)) {
/* 1814 */           this.value = null;
/* 1815 */           CoreSubscriber<? super O> coreSubscriber = this.actual;
/* 1816 */           coreSubscriber.onNext(v);
/* 1817 */           coreSubscriber.onComplete();
/*      */           return;
/*      */         } 
/* 1820 */         setValue(v);
/* 1821 */       } while (state != 0 || !STATE.compareAndSet(this, 0, 1));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected void discard(@Nullable O v) {
/* 1835 */       Operators.onDiscard(v, this.actual.currentContext());
/*      */     }
/*      */ 
/*      */     
/*      */     public final CoreSubscriber<? super O> actual() {
/* 1840 */       return this.actual;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final boolean isCancelled() {
/* 1848 */       return (this.state == 4);
/*      */     }
/*      */ 
/*      */     
/*      */     public final boolean isEmpty() {
/* 1853 */       return (this.state != 16);
/*      */     }
/*      */ 
/*      */     
/*      */     public void onComplete() {
/* 1858 */       this.actual.onComplete();
/*      */     }
/*      */ 
/*      */     
/*      */     public void onError(Throwable t) {
/* 1863 */       this.actual.onError(t);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void onNext(I t) {
/* 1869 */       setValue((O)t);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void onSubscribe(Subscription s) {}
/*      */ 
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     public final O poll() {
/* 1880 */       if (STATE.compareAndSet(this, 16, 32)) {
/* 1881 */         O v = this.value;
/* 1882 */         this.value = null;
/* 1883 */         return v;
/*      */       } 
/* 1885 */       return null;
/*      */     }
/*      */ 
/*      */     
/*      */     public void request(long n) {
/* 1890 */       if (Operators.validate(n)) {
/*      */         do {
/* 1892 */           int s = this.state;
/* 1893 */           if (s == 4) {
/*      */             return;
/*      */           }
/*      */ 
/*      */           
/* 1898 */           if ((s & 0xFFFFFFFE) != 0) {
/*      */             return;
/*      */           }
/* 1901 */           if (s == 1 && STATE.compareAndSet(this, 1, 3)) {
/* 1902 */             O v = this.value;
/* 1903 */             if (v != null) {
/* 1904 */               this.value = null;
/* 1905 */               CoreSubscriber<? super O> coreSubscriber = this.actual;
/* 1906 */               coreSubscriber.onNext(v);
/* 1907 */               coreSubscriber.onComplete();
/*      */             } 
/*      */             return;
/*      */           } 
/* 1911 */         } while (!STATE.compareAndSet(this, 0, 2));
/*      */         return;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int requestFusion(int mode) {
/* 1920 */       if ((mode & 0x2) != 0) {
/* 1921 */         STATE.lazySet(this, 8);
/* 1922 */         return 2;
/*      */       } 
/* 1924 */       return 0;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void setValue(@Nullable O value) {
/* 1935 */       if (STATE.get(this) == 4) {
/* 1936 */         discard(value);
/*      */         return;
/*      */       } 
/* 1939 */       this.value = value;
/*      */     }
/*      */ 
/*      */     
/*      */     public int size() {
/* 1944 */       return isEmpty() ? 0 : 1;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1981 */     static final AtomicIntegerFieldUpdater<MonoSubscriber> STATE = AtomicIntegerFieldUpdater.newUpdater(MonoSubscriber.class, "state");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static abstract class MultiSubscriptionSubscriber<I, O>
/*      */     implements InnerOperator<I, O>
/*      */   {
/*      */     final CoreSubscriber<? super O> actual;
/*      */ 
/*      */     
/*      */     protected boolean unbounded;
/*      */ 
/*      */     
/*      */     Subscription subscription;
/*      */ 
/*      */     
/*      */     long requested;
/*      */ 
/*      */     
/*      */     volatile Subscription missedSubscription;
/*      */ 
/*      */     
/*      */     volatile long missedRequested;
/*      */ 
/*      */     
/*      */     volatile long missedProduced;
/*      */ 
/*      */     
/*      */     volatile int wip;
/*      */ 
/*      */     
/*      */     volatile boolean cancelled;
/*      */ 
/*      */ 
/*      */     
/*      */     public MultiSubscriptionSubscriber(CoreSubscriber<? super O> actual) {
/* 2019 */       this.actual = actual;
/*      */     }
/*      */ 
/*      */     
/*      */     public CoreSubscriber<? super O> actual() {
/* 2024 */       return this.actual;
/*      */     }
/*      */ 
/*      */     
/*      */     public void cancel() {
/* 2029 */       if (!this.cancelled) {
/* 2030 */         this.cancelled = true;
/*      */         
/* 2032 */         drain();
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     public Object scanUnsafe(Scannable.Attr key) {
/* 2039 */       if (key == Scannable.Attr.PARENT)
/* 2040 */         return (this.missedSubscription != null) ? this.missedSubscription : this.subscription; 
/* 2041 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(isCancelled()); 
/* 2042 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) {
/* 2043 */         return Long.valueOf(Operators.addCap(this.requested, this.missedRequested));
/*      */       }
/* 2045 */       return super.scanUnsafe(key);
/*      */     }
/*      */     
/*      */     public final boolean isUnbounded() {
/* 2049 */       return this.unbounded;
/*      */     }
/*      */     
/*      */     final boolean isCancelled() {
/* 2053 */       return this.cancelled;
/*      */     }
/*      */ 
/*      */     
/*      */     public void onComplete() {
/* 2058 */       this.actual.onComplete();
/*      */     }
/*      */ 
/*      */     
/*      */     public void onError(Throwable t) {
/* 2063 */       this.actual.onError(t);
/*      */     }
/*      */ 
/*      */     
/*      */     public void onSubscribe(Subscription s) {
/* 2068 */       set(s);
/*      */     }
/*      */     
/*      */     public final void produced(long n) {
/* 2072 */       if (this.unbounded) {
/*      */         return;
/*      */       }
/* 2075 */       if (this.wip == 0 && WIP.compareAndSet(this, 0, 1)) {
/* 2076 */         long r = this.requested;
/*      */         
/* 2078 */         if (r != Long.MAX_VALUE) {
/* 2079 */           long u = r - n;
/* 2080 */           if (u < 0L) {
/* 2081 */             Operators.reportMoreProduced();
/* 2082 */             u = 0L;
/*      */           } 
/* 2084 */           this.requested = u;
/*      */         } else {
/* 2086 */           this.unbounded = true;
/*      */         } 
/*      */         
/* 2089 */         if (WIP.decrementAndGet(this) == 0) {
/*      */           return;
/*      */         }
/*      */         
/* 2093 */         drainLoop();
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/* 2098 */       Operators.addCap(MISSED_PRODUCED, this, n);
/*      */       
/* 2100 */       drain();
/*      */     }
/*      */     
/*      */     final void producedOne() {
/* 2104 */       if (this.unbounded) {
/*      */         return;
/*      */       }
/* 2107 */       if (this.wip == 0 && WIP.compareAndSet(this, 0, 1)) {
/* 2108 */         long r = this.requested;
/*      */         
/* 2110 */         if (r != Long.MAX_VALUE) {
/* 2111 */           r--;
/* 2112 */           if (r < 0L) {
/* 2113 */             Operators.reportMoreProduced();
/* 2114 */             r = 0L;
/*      */           } 
/* 2116 */           this.requested = r;
/*      */         } else {
/* 2118 */           this.unbounded = true;
/*      */         } 
/*      */         
/* 2121 */         if (WIP.decrementAndGet(this) == 0) {
/*      */           return;
/*      */         }
/*      */         
/* 2125 */         drainLoop();
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/* 2130 */       Operators.addCap(MISSED_PRODUCED, this, 1L);
/*      */       
/* 2132 */       drain();
/*      */     }
/*      */ 
/*      */     
/*      */     public final void request(long n) {
/* 2137 */       if (Operators.validate(n)) {
/* 2138 */         if (this.unbounded) {
/*      */           return;
/*      */         }
/* 2141 */         if (this.wip == 0 && WIP.compareAndSet(this, 0, 1)) {
/* 2142 */           long r = this.requested;
/*      */           
/* 2144 */           if (r != Long.MAX_VALUE) {
/* 2145 */             r = Operators.addCap(r, n);
/* 2146 */             this.requested = r;
/* 2147 */             if (r == Long.MAX_VALUE) {
/* 2148 */               this.unbounded = true;
/*      */             }
/*      */           } 
/* 2151 */           Subscription a = this.subscription;
/*      */           
/* 2153 */           if (WIP.decrementAndGet(this) != 0) {
/* 2154 */             drainLoop();
/*      */           }
/*      */           
/* 2157 */           if (a != null) {
/* 2158 */             a.request(n);
/*      */           }
/*      */           
/*      */           return;
/*      */         } 
/*      */         
/* 2164 */         Operators.addCap(MISSED_REQUESTED, this, n);
/*      */         
/* 2166 */         drain();
/*      */       } 
/*      */     }
/*      */     
/*      */     public final void set(Subscription s) {
/* 2171 */       if (this.cancelled) {
/* 2172 */         s.cancel();
/*      */         
/*      */         return;
/*      */       } 
/* 2176 */       Objects.requireNonNull(s);
/*      */       
/* 2178 */       if (this.wip == 0 && WIP.compareAndSet(this, 0, 1)) {
/* 2179 */         Subscription subscription = this.subscription;
/*      */         
/* 2181 */         if (subscription != null && shouldCancelCurrent()) {
/* 2182 */           subscription.cancel();
/*      */         }
/*      */         
/* 2185 */         this.subscription = s;
/*      */         
/* 2187 */         long r = this.requested;
/*      */         
/* 2189 */         if (WIP.decrementAndGet(this) != 0) {
/* 2190 */           drainLoop();
/*      */         }
/*      */         
/* 2193 */         if (r != 0L) {
/* 2194 */           s.request(r);
/*      */         }
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/* 2200 */       Subscription a = MISSED_SUBSCRIPTION.getAndSet(this, s);
/* 2201 */       if (a != null && shouldCancelCurrent()) {
/* 2202 */         a.cancel();
/*      */       }
/* 2204 */       drain();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected boolean shouldCancelCurrent() {
/* 2213 */       return false;
/*      */     }
/*      */     
/*      */     final void drain() {
/* 2217 */       if (WIP.getAndIncrement(this) != 0) {
/*      */         return;
/*      */       }
/* 2220 */       drainLoop();
/*      */     }
/*      */     
/*      */     final void drainLoop() {
/* 2224 */       int missed = 1;
/*      */       
/* 2226 */       long requestAmount = 0L;
/* 2227 */       long alreadyInRequestAmount = 0L;
/* 2228 */       Subscription requestTarget = null;
/*      */ 
/*      */       
/*      */       while (true) {
/* 2232 */         Subscription ms = this.missedSubscription;
/*      */         
/* 2234 */         if (ms != null) {
/* 2235 */           ms = MISSED_SUBSCRIPTION.getAndSet(this, null);
/*      */         }
/*      */         
/* 2238 */         long mr = this.missedRequested;
/* 2239 */         if (mr != 0L) {
/* 2240 */           mr = MISSED_REQUESTED.getAndSet(this, 0L);
/*      */         }
/*      */         
/* 2243 */         long mp = this.missedProduced;
/* 2244 */         if (mp != 0L) {
/* 2245 */           mp = MISSED_PRODUCED.getAndSet(this, 0L);
/*      */         }
/*      */         
/* 2248 */         Subscription a = this.subscription;
/*      */         
/* 2250 */         if (this.cancelled) {
/* 2251 */           if (a != null) {
/* 2252 */             a.cancel();
/* 2253 */             this.subscription = null;
/*      */           } 
/* 2255 */           if (ms != null) {
/* 2256 */             ms.cancel();
/*      */           }
/*      */         } else {
/* 2259 */           long r = this.requested;
/* 2260 */           if (r != Long.MAX_VALUE) {
/* 2261 */             long u = Operators.addCap(r, mr);
/*      */             
/* 2263 */             if (u != Long.MAX_VALUE) {
/* 2264 */               long v = u - mp;
/* 2265 */               if (v < 0L) {
/* 2266 */                 Operators.reportMoreProduced();
/* 2267 */                 v = 0L;
/*      */               } 
/* 2269 */               r = v;
/*      */             } else {
/* 2271 */               r = u;
/*      */             } 
/* 2273 */             this.requested = r;
/*      */           } 
/*      */           
/* 2276 */           if (ms != null) {
/* 2277 */             if (a != null && shouldCancelCurrent()) {
/* 2278 */               a.cancel();
/*      */             }
/* 2280 */             this.subscription = ms;
/* 2281 */             if (r != 0L) {
/* 2282 */               requestAmount = Operators.addCap(requestAmount, r - alreadyInRequestAmount);
/* 2283 */               requestTarget = ms;
/*      */             } 
/* 2285 */           } else if (mr != 0L && a != null) {
/* 2286 */             requestAmount = Operators.addCap(requestAmount, mr);
/* 2287 */             alreadyInRequestAmount += mr;
/* 2288 */             requestTarget = a;
/*      */           } 
/*      */         } 
/*      */         
/* 2292 */         missed = WIP.addAndGet(this, -missed);
/* 2293 */         if (missed == 0) {
/* 2294 */           if (requestAmount != 0L) {
/* 2295 */             requestTarget.request(requestAmount);
/*      */           }
/*      */           return;
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 2304 */     static final AtomicReferenceFieldUpdater<MultiSubscriptionSubscriber, Subscription> MISSED_SUBSCRIPTION = AtomicReferenceFieldUpdater.newUpdater(MultiSubscriptionSubscriber.class, Subscription.class, "missedSubscription");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2310 */     static final AtomicLongFieldUpdater<MultiSubscriptionSubscriber> MISSED_REQUESTED = AtomicLongFieldUpdater.newUpdater(MultiSubscriptionSubscriber.class, "missedRequested");
/*      */ 
/*      */     
/* 2313 */     static final AtomicLongFieldUpdater<MultiSubscriptionSubscriber> MISSED_PRODUCED = AtomicLongFieldUpdater.newUpdater(MultiSubscriptionSubscriber.class, "missedProduced");
/*      */ 
/*      */     
/* 2316 */     static final AtomicIntegerFieldUpdater<MultiSubscriptionSubscriber> WIP = AtomicIntegerFieldUpdater.newUpdater(MultiSubscriptionSubscriber.class, "wip");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static final class ScalarSubscription<T>
/*      */     implements Fuseable.SynchronousSubscription<T>, InnerProducer<T>
/*      */   {
/*      */     final CoreSubscriber<? super T> actual;
/*      */ 
/*      */     
/*      */     final T value;
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     final String stepName;
/*      */ 
/*      */     
/*      */     volatile int once;
/*      */ 
/*      */     
/*      */     ScalarSubscription(CoreSubscriber<? super T> actual, T value) {
/* 2338 */       this(actual, value, null);
/*      */     }
/*      */     
/*      */     ScalarSubscription(CoreSubscriber<? super T> actual, T value, String stepName) {
/* 2342 */       this.value = Objects.requireNonNull(value, "value");
/* 2343 */       this.actual = Objects.<CoreSubscriber<? super T>>requireNonNull(actual, "actual");
/* 2344 */       this.stepName = stepName;
/*      */     }
/*      */ 
/*      */     
/*      */     public void cancel() {
/* 2349 */       if (this.once == 0) {
/* 2350 */         Operators.onDiscard(this.value, this.actual.currentContext());
/*      */       }
/* 2352 */       ONCE.lazySet(this, 2);
/*      */     }
/*      */ 
/*      */     
/*      */     public void clear() {
/* 2357 */       if (this.once == 0) {
/* 2358 */         Operators.onDiscard(this.value, this.actual.currentContext());
/*      */       }
/* 2360 */       ONCE.lazySet(this, 1);
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isEmpty() {
/* 2365 */       return (this.once != 0);
/*      */     }
/*      */ 
/*      */     
/*      */     public CoreSubscriber<? super T> actual() {
/* 2370 */       return this.actual;
/*      */     }
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     public T poll() {
/* 2376 */       if (this.once == 0) {
/* 2377 */         ONCE.lazySet(this, 1);
/* 2378 */         return this.value;
/*      */       } 
/* 2380 */       return null;
/*      */     }
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     public Object scanUnsafe(Scannable.Attr key) {
/* 2386 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf((this.once == 1)); 
/* 2387 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf((this.once == 2)); 
/* 2388 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*      */       
/* 2390 */       return super.scanUnsafe(key);
/*      */     }
/*      */ 
/*      */     
/*      */     public void request(long n) {
/* 2395 */       if (Operators.validate(n) && 
/* 2396 */         ONCE.compareAndSet(this, 0, 1)) {
/* 2397 */         CoreSubscriber<? super T> coreSubscriber = this.actual;
/* 2398 */         coreSubscriber.onNext(this.value);
/* 2399 */         if (this.once != 2) {
/* 2400 */           coreSubscriber.onComplete();
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public int requestFusion(int requestedMode) {
/* 2408 */       if ((requestedMode & 0x1) != 0) {
/* 2409 */         return 1;
/*      */       }
/* 2411 */       return 0;
/*      */     }
/*      */ 
/*      */     
/*      */     public int size() {
/* 2416 */       return isEmpty() ? 0 : 1;
/*      */     }
/*      */ 
/*      */     
/*      */     public String stepName() {
/* 2421 */       return (this.stepName != null) ? this.stepName : ("scalarSubscription(" + this.value + ")");
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 2426 */     static final AtomicIntegerFieldUpdater<ScalarSubscription> ONCE = AtomicIntegerFieldUpdater.newUpdater(ScalarSubscription.class, "once");
/*      */   }
/*      */   
/*      */   static final class DrainSubscriber<T>
/*      */     implements CoreSubscriber<T> {
/* 2431 */     static final DrainSubscriber INSTANCE = new DrainSubscriber();
/*      */ 
/*      */     
/*      */     public void onSubscribe(Subscription s) {
/* 2435 */       s.request(Long.MAX_VALUE);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void onNext(Object o) {}
/*      */ 
/*      */ 
/*      */     
/*      */     public void onError(Throwable t) {
/* 2445 */       Operators.onErrorDropped(Exceptions.errorCallbackNotImplemented(t), Context.empty());
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void onComplete() {}
/*      */ 
/*      */ 
/*      */     
/*      */     public Context currentContext() {
/* 2455 */       return Context.empty();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final class ConditionalSubscriberAdapter<T>
/*      */     implements Fuseable.ConditionalSubscriber<T>
/*      */   {
/*      */     final CoreSubscriber<T> delegate;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     ConditionalSubscriberAdapter(CoreSubscriber<T> delegate) {
/* 2471 */       this.delegate = delegate;
/*      */     }
/*      */ 
/*      */     
/*      */     public Context currentContext() {
/* 2476 */       return this.delegate.currentContext();
/*      */     }
/*      */ 
/*      */     
/*      */     public void onSubscribe(Subscription s) {
/* 2481 */       this.delegate.onSubscribe(s);
/*      */     }
/*      */ 
/*      */     
/*      */     public void onNext(T t) {
/* 2486 */       this.delegate.onNext(t);
/*      */     }
/*      */ 
/*      */     
/*      */     public void onError(Throwable t) {
/* 2491 */       this.delegate.onError(t);
/*      */     }
/*      */ 
/*      */     
/*      */     public void onComplete() {
/* 2496 */       this.delegate.onComplete();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean tryOnNext(T t) {
/* 2501 */       this.delegate.onNext(t);
/* 2502 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   static final class LiftFunction<I, O>
/*      */     implements Function<Publisher<I>, Publisher<O>>
/*      */   {
/*      */     final Predicate<Publisher> filter;
/*      */     
/*      */     final String name;
/*      */     
/*      */     final BiFunction<Publisher, ? super CoreSubscriber<? super O>, ? extends CoreSubscriber<? super I>> lifter;
/*      */ 
/*      */     
/*      */     static final <I, O> LiftFunction<I, O> liftScannable(@Nullable Predicate<Scannable> filter, BiFunction<Scannable, ? super CoreSubscriber<? super O>, ? extends CoreSubscriber<? super I>> lifter) {
/* 2518 */       Objects.requireNonNull(lifter, "lifter");
/*      */       
/* 2520 */       Predicate<Publisher> effectiveFilter = null;
/* 2521 */       if (filter != null) {
/* 2522 */         effectiveFilter = (pub -> filter.test(Scannable.from(pub)));
/*      */       }
/*      */ 
/*      */       
/* 2526 */       BiFunction<Publisher, ? super CoreSubscriber<? super O>, ? extends CoreSubscriber<? super I>> effectiveLifter = (pub, sub) -> (CoreSubscriber)lifter.apply(Scannable.from(pub), sub);
/*      */       
/* 2528 */       return new LiftFunction<>(effectiveFilter, effectiveLifter, lifter.toString());
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     static final <I, O> LiftFunction<I, O> liftPublisher(@Nullable Predicate<Publisher> filter, BiFunction<Publisher, ? super CoreSubscriber<? super O>, ? extends CoreSubscriber<? super I>> lifter) {
/* 2534 */       Objects.requireNonNull(lifter, "lifter");
/* 2535 */       return new LiftFunction<>(filter, lifter, lifter.toString());
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private LiftFunction(@Nullable Predicate<Publisher> filter, BiFunction<Publisher, ? super CoreSubscriber<? super O>, ? extends CoreSubscriber<? super I>> lifter, String name) {
/* 2541 */       this.filter = filter;
/* 2542 */       this.lifter = Objects.<BiFunction<Publisher, ? super CoreSubscriber<? super O>, ? extends CoreSubscriber<? super I>>>requireNonNull(lifter, "lifter");
/* 2543 */       this.name = Objects.<String>requireNonNull(name, "name");
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Publisher<O> apply(Publisher<I> publisher) {
/* 2549 */       if (this.filter != null && !this.filter.test(publisher)) {
/* 2550 */         return publisher;
/*      */       }
/*      */       
/* 2553 */       if (publisher instanceof Fuseable) {
/* 2554 */         if (publisher instanceof Mono) {
/* 2555 */           return (Publisher)new MonoLiftFuseable<>(publisher, this);
/*      */         }
/* 2557 */         if (publisher instanceof ParallelFlux) {
/* 2558 */           return (Publisher)new ParallelLiftFuseable<>((ParallelFlux<I>)publisher, this);
/*      */         }
/* 2560 */         if (publisher instanceof ConnectableFlux) {
/* 2561 */           return (Publisher)new ConnectableLiftFuseable<>((ConnectableFlux<I>)publisher, this);
/*      */         }
/* 2563 */         if (publisher instanceof GroupedFlux) {
/* 2564 */           return (Publisher)new GroupedLiftFuseable<>((GroupedFlux)publisher, this);
/*      */         }
/* 2566 */         return (Publisher)new FluxLiftFuseable<>(publisher, this);
/*      */       } 
/*      */       
/* 2569 */       if (publisher instanceof Mono) {
/* 2570 */         return (Publisher)new MonoLift<>(publisher, this);
/*      */       }
/* 2572 */       if (publisher instanceof ParallelFlux) {
/* 2573 */         return (Publisher)new ParallelLift<>((ParallelFlux<I>)publisher, this);
/*      */       }
/* 2575 */       if (publisher instanceof ConnectableFlux) {
/* 2576 */         return (Publisher)new ConnectableLift<>((ConnectableFlux<I>)publisher, this);
/*      */       }
/* 2578 */       if (publisher instanceof GroupedFlux) {
/* 2579 */         return (Publisher)new GroupedLift<>((GroupedFlux)publisher, this);
/*      */       }
/* 2581 */       return (Publisher)new FluxLift<>(publisher, this);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static class MonoInnerProducerBase<O>
/*      */     implements InnerProducer<O>
/*      */   {
/*      */     private final CoreSubscriber<? super O> actual;
/*      */ 
/*      */     
/*      */     private O value;
/*      */ 
/*      */     
/*      */     private volatile int state;
/*      */ 
/*      */     
/* 2599 */     private static final AtomicIntegerFieldUpdater<MonoInnerProducerBase> STATE = AtomicIntegerFieldUpdater.newUpdater(MonoInnerProducerBase.class, "state"); private static final int HAS_VALUE = 1; private static final int HAS_REQUEST = 2;
/*      */     
/*      */     public MonoInnerProducerBase(CoreSubscriber<? super O> actual) {
/* 2602 */       this.actual = actual;
/*      */     }
/*      */     private static final int HAS_COMPLETED = 4; private static final int CANCELLED = 128;
/*      */     
/*      */     @Nullable
/*      */     public Object scanUnsafe(Scannable.Attr key) {
/* 2608 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(isCancelled()); 
/* 2609 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(hasCompleted(this.state)); 
/* 2610 */       if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(2147483647); 
/* 2611 */       return super.scanUnsafe(key);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final void complete(O v) {
/*      */       int s;
/*      */       do {
/* 2623 */         s = this.state;
/* 2624 */         if (isCancelled(s)) {
/* 2625 */           discard(v);
/*      */           
/*      */           return;
/*      */         } 
/* 2629 */         if (hasRequest(s) && STATE.compareAndSet(this, s, s | 0x5)) {
/* 2630 */           this.value = null;
/*      */           
/* 2632 */           doOnComplete(v);
/*      */           
/* 2634 */           this.actual.onNext(v);
/* 2635 */           this.actual.onComplete();
/*      */           
/*      */           return;
/*      */         } 
/* 2639 */         this.value = v;
/* 2640 */       } while (!STATE.compareAndSet(this, s, s | 0x5));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final void complete() {
/*      */       while (true) {
/* 2653 */         int s = this.state;
/* 2654 */         if (isCancelled(s)) {
/*      */           return;
/*      */         }
/* 2657 */         if (STATE.compareAndSet(this, s, s | 0x4)) {
/* 2658 */           if (hasValue(s) && hasRequest(s)) {
/* 2659 */             O v = this.value;
/* 2660 */             this.value = null;
/*      */             
/* 2662 */             doOnComplete(v);
/*      */             
/* 2664 */             this.actual.onNext(v);
/* 2665 */             this.actual.onComplete();
/*      */             return;
/*      */           } 
/* 2668 */           if (!hasValue(s)) {
/* 2669 */             this.actual.onComplete();
/*      */             return;
/*      */           } 
/* 2672 */           if (!hasRequest(s)) {
/*      */             break;
/*      */           }
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected void doOnComplete(O v) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected final void discard(@Nullable O v) {
/* 2697 */       Operators.onDiscard(v, this.actual.currentContext());
/*      */     }
/*      */     
/*      */     protected final void discardTheValue() {
/* 2701 */       discard(this.value);
/* 2702 */       this.value = null;
/*      */     }
/*      */ 
/*      */     
/*      */     public final CoreSubscriber<? super O> actual() {
/* 2707 */       return this.actual;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final boolean isCancelled() {
/* 2715 */       return (this.state == 128);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void request(long n) {
/* 2721 */       if (Operators.validate(n)) {
/*      */         while (true) {
/* 2723 */           int s = this.state;
/* 2724 */           if (isCancelled(s)) {
/*      */             return;
/*      */           }
/* 2727 */           if (hasRequest(s)) {
/*      */             return;
/*      */           }
/* 2730 */           if (STATE.compareAndSet(this, s, s | 0x2)) {
/* 2731 */             doOnRequest(n);
/* 2732 */             if (hasValue(s) && hasCompleted(s)) {
/* 2733 */               O v = this.value;
/* 2734 */               this.value = null;
/*      */               
/* 2736 */               doOnComplete(v);
/*      */               
/* 2738 */               this.actual.onNext(v);
/* 2739 */               this.actual.onComplete();
/*      */             } 
/*      */             return;
/*      */           } 
/*      */         } 
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected void doOnRequest(long n) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected final void setValue(@Nullable O value) {
/*      */       int s;
/* 2763 */       this.value = value;
/*      */       do {
/* 2765 */         s = this.state;
/* 2766 */         if (isCancelled(s)) {
/* 2767 */           discardTheValue();
/*      */           return;
/*      */         } 
/* 2770 */       } while (!STATE.compareAndSet(this, s, s | 0x1));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final void cancel() {
/* 2778 */       int previous = STATE.getAndSet(this, 128);
/*      */       
/* 2780 */       if (isCancelled(previous)) {
/*      */         return;
/*      */       }
/*      */       
/* 2784 */       doOnCancel();
/*      */       
/* 2786 */       if (hasValue(previous) && (previous & 0x6) != 6)
/*      */       {
/*      */         
/* 2789 */         discardTheValue();
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected void doOnCancel() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static boolean isCancelled(int s) {
/* 2809 */       return (s == 128);
/*      */     }
/*      */     
/*      */     private static boolean hasRequest(int s) {
/* 2813 */       return ((s & 0x2) == 2);
/*      */     }
/*      */     
/*      */     private static boolean hasValue(int s) {
/* 2817 */       return ((s & 0x1) == 1);
/*      */     }
/*      */     
/*      */     private static boolean hasCompleted(int s) {
/* 2821 */       return ((s & 0x4) == 4);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/* 2827 */   static final Logger log = Loggers.getLogger(Operators.class);
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\Operators.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */