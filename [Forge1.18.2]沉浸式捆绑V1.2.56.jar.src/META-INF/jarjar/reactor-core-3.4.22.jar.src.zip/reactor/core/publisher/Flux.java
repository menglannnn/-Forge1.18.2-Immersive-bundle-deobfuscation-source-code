/*       */ package reactor.core.publisher;
/*       */ 
/*       */ import java.time.Duration;
/*       */ import java.util.ArrayList;
/*       */ import java.util.Collection;
/*       */ import java.util.Comparator;
/*       */ import java.util.HashMap;
/*       */ import java.util.List;
/*       */ import java.util.Map;
/*       */ import java.util.NoSuchElementException;
/*       */ import java.util.Objects;
/*       */ import java.util.Queue;
/*       */ import java.util.Set;
/*       */ import java.util.concurrent.Callable;
/*       */ import java.util.concurrent.TimeUnit;
/*       */ import java.util.function.BiConsumer;
/*       */ import java.util.function.BiFunction;
/*       */ import java.util.function.BiPredicate;
/*       */ import java.util.function.BooleanSupplier;
/*       */ import java.util.function.Consumer;
/*       */ import java.util.function.Function;
/*       */ import java.util.function.LongConsumer;
/*       */ import java.util.function.Predicate;
/*       */ import java.util.function.Supplier;
/*       */ import java.util.logging.Level;
/*       */ import java.util.stream.Collector;
/*       */ import java.util.stream.Stream;
/*       */ import org.reactivestreams.Publisher;
/*       */ import org.reactivestreams.Subscriber;
/*       */ import org.reactivestreams.Subscription;
/*       */ import reactor.core.CorePublisher;
/*       */ import reactor.core.CoreSubscriber;
/*       */ import reactor.core.Disposable;
/*       */ import reactor.core.Exceptions;
/*       */ import reactor.core.Fuseable;
/*       */ import reactor.core.scheduler.Scheduler;
/*       */ import reactor.core.scheduler.Schedulers;
/*       */ import reactor.util.Logger;
/*       */ import reactor.util.Metrics;
/*       */ import reactor.util.annotation.Nullable;
/*       */ import reactor.util.concurrent.Queues;
/*       */ import reactor.util.context.Context;
/*       */ import reactor.util.context.ContextView;
/*       */ import reactor.util.function.Tuple2;
/*       */ import reactor.util.function.Tuple3;
/*       */ import reactor.util.function.Tuple4;
/*       */ import reactor.util.function.Tuple5;
/*       */ import reactor.util.function.Tuple6;
/*       */ import reactor.util.function.Tuple7;
/*       */ import reactor.util.function.Tuple8;
/*       */ import reactor.util.function.Tuples;
/*       */ import reactor.util.retry.Retry;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ public abstract class Flux<T>
/*       */   implements CorePublisher<T>
/*       */ {
/*       */   @SafeVarargs
/*       */   public static <T, V> Flux<V> combineLatest(Function<Object[], V> combinator, Publisher<? extends T>... sources) {
/*   145 */     return combineLatest(combinator, Queues.XS_BUFFER_SIZE, sources);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @SafeVarargs
/*       */   public static <T, V> Flux<V> combineLatest(Function<Object[], V> combinator, int prefetch, Publisher<? extends T>... sources) {
/*   170 */     if (sources.length == 0) {
/*   171 */       return empty();
/*       */     }
/*       */     
/*   174 */     if (sources.length == 1) {
/*   175 */       Publisher<? extends T> source = sources[0];
/*   176 */       if (source instanceof Fuseable) {
/*   177 */         return onAssembly(new FluxMapFuseable<>(from(source), v -> combinator.apply(new Object[] { v })));
/*       */       }
/*       */       
/*   180 */       return onAssembly(new FluxMap<>(from(source), v -> combinator.apply(new Object[] { v })));
/*       */     } 
/*       */ 
/*       */     
/*   184 */     return onAssembly(new FluxCombineLatest<>(sources, combinator, 
/*   185 */           Queues.get(prefetch), prefetch));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T1, T2, V> Flux<V> combineLatest(Publisher<? extends T1> source1, Publisher<? extends T2> source2, BiFunction<? super T1, ? super T2, ? extends V> combinator) {
/*   212 */     return combineLatest(tuple -> combinator.apply(tuple[0], tuple[1]), (Publisher<?>[])new Publisher[] { source1, source2 });
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T1, T2, T3, V> Flux<V> combineLatest(Publisher<? extends T1> source1, Publisher<? extends T2> source2, Publisher<? extends T3> source3, Function<Object[], V> combinator) {
/*   241 */     return combineLatest(combinator, (Publisher<?>[])new Publisher[] { source1, source2, source3 });
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T1, T2, T3, T4, V> Flux<V> combineLatest(Publisher<? extends T1> source1, Publisher<? extends T2> source2, Publisher<? extends T3> source3, Publisher<? extends T4> source4, Function<Object[], V> combinator) {
/*   273 */     return combineLatest(combinator, (Publisher<?>[])new Publisher[] { source1, source2, source3, source4 });
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T1, T2, T3, T4, T5, V> Flux<V> combineLatest(Publisher<? extends T1> source1, Publisher<? extends T2> source2, Publisher<? extends T3> source3, Publisher<? extends T4> source4, Publisher<? extends T5> source5, Function<Object[], V> combinator) {
/*   308 */     return combineLatest(combinator, (Publisher<?>[])new Publisher[] { source1, source2, source3, source4, source5 });
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T1, T2, T3, T4, T5, T6, V> Flux<V> combineLatest(Publisher<? extends T1> source1, Publisher<? extends T2> source2, Publisher<? extends T3> source3, Publisher<? extends T4> source4, Publisher<? extends T5> source5, Publisher<? extends T6> source6, Function<Object[], V> combinator) {
/*   346 */     return combineLatest(combinator, (Publisher<?>[])new Publisher[] { source1, source2, source3, source4, source5, source6 });
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T, V> Flux<V> combineLatest(Iterable<? extends Publisher<? extends T>> sources, Function<Object[], V> combinator) {
/*   370 */     return combineLatest(sources, Queues.XS_BUFFER_SIZE, combinator);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T, V> Flux<V> combineLatest(Iterable<? extends Publisher<? extends T>> sources, int prefetch, Function<Object[], V> combinator) {
/*   397 */     return onAssembly(new FluxCombineLatest<>(sources, combinator, 
/*       */           
/*   399 */           Queues.get(prefetch), prefetch));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T> Flux<T> concat(Iterable<? extends Publisher<? extends T>> sources) {
/*   419 */     return onAssembly(new FluxConcatIterable<>(sources));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @SafeVarargs
/*       */   public final Flux<T> concatWithValues(T... values) {
/*   433 */     return concatWith((Publisher<? extends T>)fromArray(values));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T> Flux<T> concat(Publisher<? extends Publisher<? extends T>> sources) {
/*   455 */     return concat(sources, Queues.XS_BUFFER_SIZE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T> Flux<T> concat(Publisher<? extends Publisher<? extends T>> sources, int prefetch) {
/*   478 */     return from(sources).concatMap(identityFunction(), prefetch);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @SafeVarargs
/*       */   public static <T> Flux<T> concat(Publisher<? extends T>... sources) {
/*   499 */     return onAssembly(new FluxConcatArray<>(false, sources));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T> Flux<T> concatDelayError(Publisher<? extends Publisher<? extends T>> sources) {
/*   522 */     return concatDelayError(sources, Queues.XS_BUFFER_SIZE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T> Flux<T> concatDelayError(Publisher<? extends Publisher<? extends T>> sources, int prefetch) {
/*   545 */     return from(sources).concatMapDelayError(identityFunction(), prefetch);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T> Flux<T> concatDelayError(Publisher<? extends Publisher<? extends T>> sources, boolean delayUntilEnd, int prefetch) {
/*   575 */     return from(sources).concatMapDelayError(identityFunction(), delayUntilEnd, prefetch);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @SafeVarargs
/*       */   public static <T> Flux<T> concatDelayError(Publisher<? extends T>... sources) {
/*   599 */     return onAssembly(new FluxConcatArray<>(true, sources));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T> Flux<T> create(Consumer<? super FluxSink<T>> emitter) {
/*   643 */     return create(emitter, FluxSink.OverflowStrategy.BUFFER);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T> Flux<T> create(Consumer<? super FluxSink<T>> emitter, FluxSink.OverflowStrategy backpressure) {
/*   691 */     return onAssembly(new FluxCreate<>(emitter, backpressure, FluxCreate.CreateMode.PUSH_PULL));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T> Flux<T> push(Consumer<? super FluxSink<T>> emitter) {
/*   735 */     return push(emitter, FluxSink.OverflowStrategy.BUFFER);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T> Flux<T> push(Consumer<? super FluxSink<T>> emitter, FluxSink.OverflowStrategy backpressure) {
/*   783 */     return onAssembly(new FluxCreate<>(emitter, backpressure, FluxCreate.CreateMode.PUSH_ONLY));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T> Flux<T> defer(Supplier<? extends Publisher<T>> supplier) {
/*   803 */     return onAssembly(new FluxDefer<>(supplier));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @Deprecated
/*       */   public static <T> Flux<T> deferWithContext(Function<Context, ? extends Publisher<T>> contextualPublisherFactory) {
/*   825 */     return deferContextual(view -> (Publisher)contextualPublisherFactory.apply(Context.of(view)));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T> Flux<T> deferContextual(Function<ContextView, ? extends Publisher<T>> contextualPublisherFactory) {
/*   845 */     return onAssembly(new FluxDeferContextual<>(contextualPublisherFactory));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T> Flux<T> empty() {
/*   858 */     return FluxEmpty.instance();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T> Flux<T> error(Throwable error) {
/*   873 */     return error(error, false);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T> Flux<T> error(Supplier<? extends Throwable> errorSupplier) {
/*   889 */     return onAssembly(new FluxErrorSupplied<>(errorSupplier));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <O> Flux<O> error(Throwable throwable, boolean whenRequested) {
/*   906 */     if (whenRequested) {
/*   907 */       return onAssembly(new FluxErrorOnRequest<>(throwable));
/*       */     }
/*       */     
/*   910 */     return onAssembly(new FluxError<>(throwable));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @SafeVarargs
/*       */   @Deprecated
/*       */   public static <I> Flux<I> first(Publisher<? extends I>... sources) {
/*   931 */     return firstWithSignal(sources);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @Deprecated
/*       */   public static <I> Flux<I> first(Iterable<? extends Publisher<? extends I>> sources) {
/*   950 */     return firstWithSignal(sources);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @SafeVarargs
/*       */   public static <I> Flux<I> firstWithSignal(Publisher<? extends I>... sources) {
/*   968 */     return onAssembly(new FluxFirstWithSignal<>(sources));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <I> Flux<I> firstWithSignal(Iterable<? extends Publisher<? extends I>> sources) {
/*   985 */     return onAssembly(new FluxFirstWithSignal<>(sources));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <I> Flux<I> firstWithValue(Iterable<? extends Publisher<? extends I>> sources) {
/*  1018 */     return onAssembly(new FluxFirstWithValue<>(sources));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @SafeVarargs
/*       */   public static <I> Flux<I> firstWithValue(Publisher<? extends I> first, Publisher<? extends I>... others) {
/*  1055 */     if (first instanceof FluxFirstWithValue) {
/*       */       
/*  1057 */       FluxFirstWithValue<I> orPublisher = (FluxFirstWithValue)first;
/*       */       
/*  1059 */       FluxFirstWithValue<I> result = orPublisher.firstValuedAdditionalSources(others);
/*  1060 */       if (result != null) {
/*  1061 */         return result;
/*       */       }
/*       */     } 
/*  1064 */     return onAssembly(new FluxFirstWithValue<>(first, others));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T> Flux<T> from(Publisher<? extends T> source) {
/*  1082 */     if (source instanceof Flux) {
/*       */       
/*  1084 */       Flux<T> casted = (Flux)source;
/*  1085 */       return casted;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/*  1090 */     return onAssembly(wrap(source));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T> Flux<T> fromArray(T[] array) {
/*  1104 */     if (array.length == 0) {
/*  1105 */       return empty();
/*       */     }
/*  1107 */     if (array.length == 1) {
/*  1108 */       return just(array[0]);
/*       */     }
/*  1110 */     return onAssembly(new FluxArray<>(array));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T> Flux<T> fromIterable(Iterable<? extends T> it) {
/*  1136 */     return onAssembly(new FluxIterable<>(it));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T> Flux<T> fromStream(Stream<? extends T> s) {
/*  1158 */     Objects.requireNonNull(s, "Stream s must be provided");
/*  1159 */     return onAssembly(new FluxStream<>(() -> s));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T> Flux<T> fromStream(Supplier<Stream<? extends T>> streamSupplier) {
/*  1181 */     return onAssembly(new FluxStream<>(streamSupplier));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T> Flux<T> generate(Consumer<SynchronousSink<T>> generator) {
/*  1197 */     Objects.requireNonNull(generator, "generator");
/*  1198 */     return onAssembly(new FluxGenerate<>(generator));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T, S> Flux<T> generate(Callable<S> stateSupplier, BiFunction<S, SynchronousSink<T>, S> generator) {
/*  1216 */     return onAssembly(new FluxGenerate<>(stateSupplier, generator));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T, S> Flux<T> generate(Callable<S> stateSupplier, BiFunction<S, SynchronousSink<T>, S> generator, Consumer<? super S> stateConsumer) {
/*  1239 */     return onAssembly(new FluxGenerate<>(stateSupplier, generator, stateConsumer));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static Flux<Long> interval(Duration period) {
/*  1258 */     return interval(period, Schedulers.parallel());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static Flux<Long> interval(Duration delay, Duration period) {
/*  1279 */     return interval(delay, period, Schedulers.parallel());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static Flux<Long> interval(Duration period, Scheduler timer) {
/*  1298 */     return interval(period, period, timer);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static Flux<Long> interval(Duration delay, Duration period, Scheduler timer) {
/*  1318 */     return onAssembly(new FluxInterval(delay.toNanos(), period.toNanos(), TimeUnit.NANOSECONDS, timer));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @SafeVarargs
/*       */   public static <T> Flux<T> just(T... data) {
/*  1333 */     return fromArray(data);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T> Flux<T> just(T data) {
/*  1347 */     return onAssembly(new FluxJust<>(data));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T> Flux<T> merge(Publisher<? extends Publisher<? extends T>> source) {
/*  1369 */     return merge(source, Queues.SMALL_BUFFER_SIZE, Queues.XS_BUFFER_SIZE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T> Flux<T> merge(Publisher<? extends Publisher<? extends T>> source, int concurrency) {
/*  1394 */     return merge(source, concurrency, Queues.XS_BUFFER_SIZE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T> Flux<T> merge(Publisher<? extends Publisher<? extends T>> source, int concurrency, int prefetch) {
/*  1418 */     return onAssembly(new FluxFlatMap<>(
/*  1419 */           from(source), 
/*  1420 */           (Function)identityFunction(), false, concurrency, 
/*       */ 
/*       */           
/*  1423 */           Queues.get(concurrency), prefetch, 
/*       */           
/*  1425 */           Queues.get(prefetch)));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <I> Flux<I> merge(Iterable<? extends Publisher<? extends I>> sources) {
/*  1447 */     return merge((Publisher<? extends Publisher<? extends I>>)fromIterable(sources));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @SafeVarargs
/*       */   public static <I> Flux<I> merge(Publisher<? extends I>... sources) {
/*  1469 */     return merge(Queues.XS_BUFFER_SIZE, sources);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @SafeVarargs
/*       */   public static <I> Flux<I> merge(int prefetch, Publisher<? extends I>... sources) {
/*  1492 */     return merge(prefetch, false, sources);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @SafeVarargs
/*       */   public static <I> Flux<I> mergeDelayError(int prefetch, Publisher<? extends I>... sources) {
/*  1516 */     return merge(prefetch, true, sources);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @SafeVarargs
/*       */   public static <I extends Comparable<? super I>> Flux<I> mergeComparing(Publisher<? extends I>... sources) {
/*  1535 */     return mergeComparing(Queues.SMALL_BUFFER_SIZE, Comparator.naturalOrder(), sources);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @SafeVarargs
/*       */   public static <T> Flux<T> mergeComparing(Comparator<? super T> comparator, Publisher<? extends T>... sources) {
/*  1557 */     return mergeComparing(Queues.SMALL_BUFFER_SIZE, comparator, sources);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @SafeVarargs
/*       */   public static <T> Flux<T> mergeComparing(int prefetch, Comparator<? super T> comparator, Publisher<? extends T>... sources) {
/*  1581 */     if (sources.length == 0) {
/*  1582 */       return empty();
/*       */     }
/*  1584 */     if (sources.length == 1) {
/*  1585 */       return from(sources[0]);
/*       */     }
/*  1587 */     return onAssembly(new FluxMergeComparing<>(prefetch, comparator, false, sources));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @SafeVarargs
/*       */   public static <T> Flux<T> mergeComparingDelayError(int prefetch, Comparator<? super T> comparator, Publisher<? extends T>... sources) {
/*  1613 */     if (sources.length == 0) {
/*  1614 */       return empty();
/*       */     }
/*  1616 */     if (sources.length == 1) {
/*  1617 */       return from(sources[0]);
/*       */     }
/*  1619 */     return onAssembly(new FluxMergeComparing<>(prefetch, comparator, true, sources));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @SafeVarargs
/*       */   @Deprecated
/*       */   public static <I extends Comparable<? super I>> Flux<I> mergeOrdered(Publisher<? extends I>... sources) {
/*  1645 */     return mergeOrdered(Queues.SMALL_BUFFER_SIZE, Comparator.naturalOrder(), sources);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @SafeVarargs
/*       */   @Deprecated
/*       */   public static <T> Flux<T> mergeOrdered(Comparator<? super T> comparator, Publisher<? extends T>... sources) {
/*  1673 */     return mergeOrdered(Queues.SMALL_BUFFER_SIZE, comparator, sources);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @SafeVarargs
/*       */   @Deprecated
/*       */   public static <T> Flux<T> mergeOrdered(int prefetch, Comparator<? super T> comparator, Publisher<? extends T>... sources) {
/*  1703 */     if (sources.length == 0) {
/*  1704 */       return empty();
/*       */     }
/*  1706 */     if (sources.length == 1) {
/*  1707 */       return from(sources[0]);
/*       */     }
/*  1709 */     return onAssembly(new FluxMergeComparing<>(prefetch, comparator, true, sources));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T> Flux<T> mergeSequential(Publisher<? extends Publisher<? extends T>> sources) {
/*  1726 */     return mergeSequential(sources, false, Queues.SMALL_BUFFER_SIZE, Queues.XS_BUFFER_SIZE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T> Flux<T> mergeSequential(Publisher<? extends Publisher<? extends T>> sources, int maxConcurrency, int prefetch) {
/*  1747 */     return mergeSequential(sources, false, maxConcurrency, prefetch);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T> Flux<T> mergeSequentialDelayError(Publisher<? extends Publisher<? extends T>> sources, int maxConcurrency, int prefetch) {
/*  1768 */     return mergeSequential(sources, true, maxConcurrency, prefetch);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @SafeVarargs
/*       */   public static <I> Flux<I> mergeSequential(Publisher<? extends I>... sources) {
/*  1785 */     return mergeSequential(Queues.XS_BUFFER_SIZE, false, sources);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @SafeVarargs
/*       */   public static <I> Flux<I> mergeSequential(int prefetch, Publisher<? extends I>... sources) {
/*  1803 */     return mergeSequential(prefetch, false, sources);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @SafeVarargs
/*       */   public static <I> Flux<I> mergeSequentialDelayError(int prefetch, Publisher<? extends I>... sources) {
/*  1823 */     return mergeSequential(prefetch, true, sources);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <I> Flux<I> mergeSequential(Iterable<? extends Publisher<? extends I>> sources) {
/*  1839 */     return mergeSequential(sources, false, Queues.SMALL_BUFFER_SIZE, Queues.XS_BUFFER_SIZE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <I> Flux<I> mergeSequential(Iterable<? extends Publisher<? extends I>> sources, int maxConcurrency, int prefetch) {
/*  1860 */     return mergeSequential(sources, false, maxConcurrency, prefetch);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <I> Flux<I> mergeSequentialDelayError(Iterable<? extends Publisher<? extends I>> sources, int maxConcurrency, int prefetch) {
/*  1882 */     return mergeSequential(sources, true, maxConcurrency, prefetch);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T> Flux<T> never() {
/*  1895 */     return FluxNever.instance();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static Flux<Integer> range(int start, int count) {
/*  1911 */     if (count == 1) {
/*  1912 */       return just(Integer.valueOf(start));
/*       */     }
/*  1914 */     if (count == 0) {
/*  1915 */       return empty();
/*       */     }
/*  1917 */     return onAssembly(new FluxRange(start, count));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T> Flux<T> switchOnNext(Publisher<? extends Publisher<? extends T>> mergedPublishers) {
/*  1936 */     return switchOnNext(mergedPublishers, Queues.XS_BUFFER_SIZE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @Deprecated
/*       */   public static <T> Flux<T> switchOnNext(Publisher<? extends Publisher<? extends T>> mergedPublishers, int prefetch) {
/*  1961 */     if (prefetch == 0) {
/*  1962 */       return onAssembly(new FluxSwitchMapNoPrefetch<>(from(mergedPublishers), 
/*  1963 */             (Function)identityFunction()));
/*       */     }
/*  1965 */     return onAssembly(new FluxSwitchMap<>(from(mergedPublishers), 
/*  1966 */           (Function)identityFunction(), 
/*  1967 */           Queues.unbounded(prefetch), prefetch));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T, D> Flux<T> using(Callable<? extends D> resourceSupplier, Function<? super D, ? extends Publisher<? extends T>> sourceSupplier, Consumer<? super D> resourceCleanup) {
/*  1995 */     return using(resourceSupplier, sourceSupplier, resourceCleanup, true);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T, D> Flux<T> using(Callable<? extends D> resourceSupplier, Function<? super D, ? extends Publisher<? extends T>> sourceSupplier, Consumer<? super D> resourceCleanup, boolean eager) {
/*  2024 */     return onAssembly(new FluxUsing<>(resourceSupplier, sourceSupplier, resourceCleanup, eager));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T, D> Flux<T> usingWhen(Publisher<D> resourceSupplier, Function<? super D, ? extends Publisher<? extends T>> resourceClosure, Function<? super D, ? extends Publisher<?>> asyncCleanup) {
/*  2062 */     return usingWhen(resourceSupplier, resourceClosure, asyncCleanup, (resource, error) -> (Publisher)asyncCleanup.apply(resource), asyncCleanup);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T, D> Flux<T> usingWhen(Publisher<D> resourceSupplier, Function<? super D, ? extends Publisher<? extends T>> resourceClosure, Function<? super D, ? extends Publisher<?>> asyncComplete, BiFunction<? super D, ? super Throwable, ? extends Publisher<?>> asyncError, Function<? super D, ? extends Publisher<?>> asyncCancel) {
/*  2121 */     return onAssembly(new FluxUsingWhen<>(resourceSupplier, resourceClosure, asyncComplete, asyncError, asyncCancel));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T1, T2, O> Flux<O> zip(Publisher<? extends T1> source1, Publisher<? extends T2> source2, BiFunction<? super T1, ? super T2, ? extends O> combinator) {
/*  2148 */     return onAssembly(new FluxZip<>(source1, source2, combinator, 
/*       */ 
/*       */           
/*  2151 */           Queues.xs(), Queues.XS_BUFFER_SIZE));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T1, T2> Flux<Tuple2<T1, T2>> zip(Publisher<? extends T1> source1, Publisher<? extends T2> source2) {
/*  2172 */     return zip(source1, source2, (BiFunction)tuple2Function());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T1, T2, T3> Flux<Tuple3<T1, T2, T3>> zip(Publisher<? extends T1> source1, Publisher<? extends T2> source2, Publisher<? extends T3> source3) {
/*  2196 */     return zip(Tuples.fn3(), (Publisher<?>[])new Publisher[] { source1, source2, source3 });
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T1, T2, T3, T4> Flux<Tuple4<T1, T2, T3, T4>> zip(Publisher<? extends T1> source1, Publisher<? extends T2> source2, Publisher<? extends T3> source3, Publisher<? extends T4> source4) {
/*  2223 */     return zip(Tuples.fn4(), (Publisher<?>[])new Publisher[] { source1, source2, source3, source4 });
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T1, T2, T3, T4, T5> Flux<Tuple5<T1, T2, T3, T4, T5>> zip(Publisher<? extends T1> source1, Publisher<? extends T2> source2, Publisher<? extends T3> source3, Publisher<? extends T4> source4, Publisher<? extends T5> source5) {
/*  2253 */     return zip(Tuples.fn5(), (Publisher<?>[])new Publisher[] { source1, source2, source3, source4, source5 });
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T1, T2, T3, T4, T5, T6> Flux<Tuple6<T1, T2, T3, T4, T5, T6>> zip(Publisher<? extends T1> source1, Publisher<? extends T2> source2, Publisher<? extends T3> source3, Publisher<? extends T4> source4, Publisher<? extends T5> source5, Publisher<? extends T6> source6) {
/*  2286 */     return zip(Tuples.fn6(), (Publisher<?>[])new Publisher[] { source1, source2, source3, source4, source5, source6 });
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T1, T2, T3, T4, T5, T6, T7> Flux<Tuple7<T1, T2, T3, T4, T5, T6, T7>> zip(Publisher<? extends T1> source1, Publisher<? extends T2> source2, Publisher<? extends T3> source3, Publisher<? extends T4> source4, Publisher<? extends T5> source5, Publisher<? extends T6> source6, Publisher<? extends T7> source7) {
/*  2322 */     return zip(Tuples.fn7(), (Publisher<?>[])new Publisher[] { source1, source2, source3, source4, source5, source6, source7 });
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T1, T2, T3, T4, T5, T6, T7, T8> Flux<Tuple8<T1, T2, T3, T4, T5, T6, T7, T8>> zip(Publisher<? extends T1> source1, Publisher<? extends T2> source2, Publisher<? extends T3> source3, Publisher<? extends T4> source4, Publisher<? extends T5> source5, Publisher<? extends T6> source6, Publisher<? extends T7> source7, Publisher<? extends T8> source8) {
/*  2361 */     return zip(Tuples.fn8(), (Publisher<?>[])new Publisher[] { source1, source2, source3, source4, source5, source6, source7, source8 });
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <O> Flux<O> zip(Iterable<? extends Publisher<?>> sources, Function<? super Object[], ? extends O> combinator) {
/*  2387 */     return zip(sources, Queues.XS_BUFFER_SIZE, combinator);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <O> Flux<O> zip(Iterable<? extends Publisher<?>> sources, int prefetch, Function<? super Object[], ? extends O> combinator) {
/*  2415 */     return onAssembly(new FluxZip<>(sources, combinator, 
/*       */           
/*  2417 */           Queues.get(prefetch), prefetch));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @SafeVarargs
/*       */   public static <I, O> Flux<O> zip(Function<? super Object[], ? extends O> combinator, Publisher<? extends I>... sources) {
/*  2442 */     return zip(combinator, Queues.XS_BUFFER_SIZE, sources);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @SafeVarargs
/*       */   public static <I, O> Flux<O> zip(Function<? super Object[], ? extends O> combinator, int prefetch, Publisher<? extends I>... sources) {
/*  2469 */     if (sources.length == 0) {
/*  2470 */       return empty();
/*       */     }
/*  2472 */     if (sources.length == 1) {
/*  2473 */       Publisher<? extends I> source = sources[0];
/*  2474 */       if (source instanceof Fuseable) {
/*  2475 */         return onAssembly(new FluxMapFuseable<>(from(source), v -> combinator.apply(new Object[] { v })));
/*       */       }
/*       */       
/*  2478 */       return onAssembly(new FluxMap<>(from(source), v -> combinator.apply(new Object[] { v })));
/*       */     } 
/*       */ 
/*       */     
/*  2482 */     return onAssembly(new FluxZip<>(sources, combinator, 
/*       */           
/*  2484 */           Queues.get(prefetch), prefetch));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <TUPLE extends Tuple2, V> Flux<V> zip(Publisher<? extends Publisher<?>> sources, final Function<? super TUPLE, ? extends V> combinator) {
/*  2514 */     return onAssembly((new FluxBuffer<>(from(sources), 2147483647, (Supplier)listSupplier()))
/*  2515 */         .flatMap(new Function<List<? extends Publisher<?>>, Publisher<V>>()
/*       */           {
/*       */             public Publisher<V> apply(List<? extends Publisher<?>> publishers) {
/*  2518 */               return (Publisher)Flux.zip(Tuples.fnAny(combinator), (Publisher<?>[])publishers
/*  2519 */                   .<Publisher>toArray(
/*  2520 */                     new Publisher[publishers.size()]));
/*       */             }
/*       */           }));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Mono<Boolean> all(Predicate<? super T> predicate) {
/*  2542 */     return Mono.onAssembly(new MonoAll<>(this, predicate));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Mono<Boolean> any(Predicate<? super T> predicate) {
/*  2561 */     return Mono.onAssembly(new MonoAny<>(this, predicate));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <P> P as(Function<? super Flux<T>, P> transformer) {
/*  2578 */     return transformer.apply(this);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @Nullable
/*       */   public final T blockFirst() {
/*  2598 */     BlockingFirstSubscriber<T> subscriber = new BlockingFirstSubscriber<>();
/*  2599 */     subscribe((Subscriber<? super T>)subscriber);
/*  2600 */     return subscriber.blockingGet();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @Nullable
/*       */   public final T blockFirst(Duration timeout) {
/*  2621 */     BlockingFirstSubscriber<T> subscriber = new BlockingFirstSubscriber<>();
/*  2622 */     subscribe((Subscriber<? super T>)subscriber);
/*  2623 */     return subscriber.blockingGet(timeout.toNanos(), TimeUnit.NANOSECONDS);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @Nullable
/*       */   public final T blockLast() {
/*  2643 */     BlockingLastSubscriber<T> subscriber = new BlockingLastSubscriber<>();
/*  2644 */     subscribe((Subscriber<? super T>)subscriber);
/*  2645 */     return subscriber.blockingGet();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @Nullable
/*       */   public final T blockLast(Duration timeout) {
/*  2667 */     BlockingLastSubscriber<T> subscriber = new BlockingLastSubscriber<>();
/*  2668 */     subscribe((Subscriber<? super T>)subscriber);
/*  2669 */     return subscriber.blockingGet(timeout.toNanos(), TimeUnit.NANOSECONDS);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<List<T>> buffer() {
/*  2684 */     return buffer(2147483647);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<List<T>> buffer(int maxSize) {
/*  2701 */     return buffer(maxSize, listSupplier());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <C extends Collection<? super T>> Flux<C> buffer(int maxSize, Supplier<C> bufferSupplier) {
/*  2721 */     return onAssembly(new FluxBuffer<>(this, maxSize, bufferSupplier));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<List<T>> buffer(int maxSize, int skip) {
/*  2753 */     return buffer(maxSize, skip, listSupplier());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <C extends Collection<? super T>> Flux<C> buffer(int maxSize, int skip, Supplier<C> bufferSupplier) {
/*  2789 */     return onAssembly(new FluxBuffer<>(this, maxSize, skip, bufferSupplier));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<List<T>> buffer(Publisher<?> other) {
/*  2805 */     return buffer(other, listSupplier());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <C extends Collection<? super T>> Flux<C> buffer(Publisher<?> other, Supplier<C> bufferSupplier) {
/*  2825 */     return onAssembly(new FluxBufferBoundary<>(this, other, bufferSupplier));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<List<T>> buffer(Duration bufferingTimespan) {
/*  2841 */     return buffer(bufferingTimespan, Schedulers.parallel());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<List<T>> buffer(Duration bufferingTimespan, Duration openBufferEvery) {
/*  2871 */     return buffer(bufferingTimespan, openBufferEvery, Schedulers.parallel());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<List<T>> buffer(Duration bufferingTimespan, Scheduler timer) {
/*  2888 */     return buffer((Publisher<?>)interval(bufferingTimespan, timer));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<List<T>> buffer(Duration bufferingTimespan, Duration openBufferEvery, Scheduler timer) {
/*  2920 */     if (bufferingTimespan.equals(openBufferEvery)) {
/*  2921 */       return buffer(bufferingTimespan, timer);
/*       */     }
/*  2923 */     return bufferWhen((Publisher<Long>)interval(Duration.ZERO, openBufferEvery, timer), aLong -> Mono.delay(bufferingTimespan, timer));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<List<T>> bufferTimeout(int maxSize, Duration maxTime) {
/*  2942 */     return bufferTimeout(maxSize, maxTime, listSupplier());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <C extends Collection<? super T>> Flux<C> bufferTimeout(int maxSize, Duration maxTime, Supplier<C> bufferSupplier) {
/*  2962 */     return bufferTimeout(maxSize, maxTime, Schedulers.parallel(), bufferSupplier);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<List<T>> bufferTimeout(int maxSize, Duration maxTime, Scheduler timer) {
/*  2982 */     return bufferTimeout(maxSize, maxTime, timer, listSupplier());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <C extends Collection<? super T>> Flux<C> bufferTimeout(int maxSize, Duration maxTime, Scheduler timer, Supplier<C> bufferSupplier) {
/*  3004 */     return onAssembly(new FluxBufferTimeout<>(this, maxSize, maxTime.toNanos(), TimeUnit.NANOSECONDS, timer, bufferSupplier));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<List<T>> bufferUntil(Predicate<? super T> predicate) {
/*  3026 */     return onAssembly(new FluxBufferPredicate<>(this, predicate, 
/*  3027 */           listSupplier(), FluxBufferPredicate.Mode.UNTIL));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<List<T>> bufferUntil(Predicate<? super T> predicate, boolean cutBefore) {
/*  3052 */     return onAssembly(new FluxBufferPredicate<>(this, predicate, listSupplier(), cutBefore ? FluxBufferPredicate.Mode.UNTIL_CUT_BEFORE : FluxBufferPredicate.Mode.UNTIL));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <V> Flux<List<T>> bufferUntilChanged() {
/*  3069 */     return bufferUntilChanged(identityFunction());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <V> Flux<List<T>> bufferUntilChanged(Function<? super T, ? extends V> keySelector) {
/*  3086 */     return bufferUntilChanged(keySelector, equalPredicate());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <V> Flux<List<T>> bufferUntilChanged(Function<? super T, ? extends V> keySelector, BiPredicate<? super V, ? super V> keyComparator) {
/*  3105 */     return defer(() -> bufferUntil(new FluxBufferPredicate.ChangedPredicate<>(keySelector, keyComparator), true));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<List<T>> bufferWhile(Predicate<? super T> predicate) {
/*  3130 */     return onAssembly(new FluxBufferPredicate<>(this, predicate, 
/*  3131 */           listSupplier(), FluxBufferPredicate.Mode.WHILE));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <U, V> Flux<List<T>> bufferWhen(Publisher<U> bucketOpening, Function<? super U, ? extends Publisher<V>> closeSelector) {
/*  3162 */     return bufferWhen(bucketOpening, closeSelector, listSupplier());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <U, V, C extends Collection<? super T>> Flux<C> bufferWhen(Publisher<U> bucketOpening, Function<? super U, ? extends Publisher<V>> closeSelector, Supplier<C> bufferSupplier) {
/*  3193 */     return onAssembly(new FluxBufferWhen<>(this, bucketOpening, closeSelector, bufferSupplier, 
/*  3194 */           Queues.unbounded(Queues.XS_BUFFER_SIZE)));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> cache() {
/*  3207 */     return cache(2147483647);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> cache(int history) {
/*  3226 */     return replay(history).autoConnect();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> cache(Duration ttl) {
/*  3243 */     return cache(ttl, Schedulers.parallel());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> cache(Duration ttl, Scheduler timer) {
/*  3261 */     return cache(2147483647, ttl, timer);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> cache(int history, Duration ttl) {
/*  3280 */     return cache(history, ttl, Schedulers.parallel());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> cache(int history, Duration ttl, Scheduler timer) {
/*  3301 */     return replay(history, ttl, timer).autoConnect();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <E> Flux<E> cast(Class<E> clazz) {
/*  3316 */     Objects.requireNonNull(clazz, "clazz");
/*  3317 */     return map(clazz::cast);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> cancelOn(Scheduler scheduler) {
/*  3333 */     return onAssembly(new FluxCancelOn<>(this, scheduler));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> checkpoint() {
/*  3352 */     return checkpoint(null, true);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> checkpoint(String description) {
/*  3377 */     return checkpoint(Objects.<String>requireNonNull(description), false);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> checkpoint(@Nullable String description, boolean forceStackTrace) {
/*       */     FluxOnAssembly.AssemblySnapshot stacktrace;
/*  3413 */     if (!forceStackTrace) {
/*  3414 */       stacktrace = new FluxOnAssembly.CheckpointLightSnapshot(description);
/*       */     } else {
/*       */       
/*  3417 */       stacktrace = new FluxOnAssembly.CheckpointHeavySnapshot(description, Traces.callSiteSupplierFactory.get());
/*       */     } 
/*       */     
/*  3420 */     return new FluxOnAssembly<>(this, stacktrace);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <E> Mono<E> collect(Supplier<E> containerSupplier, BiConsumer<E, ? super T> collector) {
/*  3445 */     return Mono.onAssembly(new MonoCollect<>(this, containerSupplier, collector));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <R, A> Mono<R> collect(Collector<? super T, A, ? extends R> collector) {
/*  3472 */     return Mono.onAssembly(new MonoStreamCollector<>(this, collector));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Mono<List<T>> collectList() {
/*  3489 */     if (this instanceof Callable) {
/*  3490 */       if (this instanceof Fuseable.ScalarCallable) {
/*       */         T v;
/*  3492 */         Fuseable.ScalarCallable<T> scalarCallable = (Fuseable.ScalarCallable<T>)this;
/*       */ 
/*       */         
/*       */         try {
/*  3496 */           v = (T)scalarCallable.call();
/*       */         }
/*  3498 */         catch (Exception e) {
/*  3499 */           return Mono.error(Exceptions.unwrap(e));
/*       */         } 
/*  3501 */         return Mono.onAssembly(new MonoCallable<>(() -> {
/*       */                 List<T> list = listSupplier().get();
/*       */                 
/*       */                 if (v != null) {
/*       */                   list.add((T)v);
/*       */                 }
/*       */                 
/*       */                 return list;
/*       */               }));
/*       */       } 
/*  3511 */       Callable<T> thiz = (Callable<T>)this;
/*  3512 */       return Mono.onAssembly(new MonoCallable<>(() -> {
/*       */               List<T> list = listSupplier().get();
/*       */               T u = thiz.call();
/*       */               if (u != null) {
/*       */                 list.add(u);
/*       */               }
/*       */               return list;
/*       */             }));
/*       */     } 
/*  3521 */     return Mono.onAssembly(new MonoCollectList<>(this));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <K> Mono<Map<K, T>> collectMap(Function<? super T, ? extends K> keyExtractor) {
/*  3545 */     return collectMap(keyExtractor, (Function)identityFunction());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <K, V> Mono<Map<K, V>> collectMap(Function<? super T, ? extends K> keyExtractor, Function<? super T, ? extends V> valueExtractor) {
/*  3574 */     return collectMap(keyExtractor, valueExtractor, () -> new HashMap<>());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <K, V> Mono<Map<K, V>> collectMap(Function<? super T, ? extends K> keyExtractor, Function<? super T, ? extends V> valueExtractor, Supplier<Map<K, V>> mapSupplier) {
/*  3606 */     Objects.requireNonNull(keyExtractor, "Key extractor is null");
/*  3607 */     Objects.requireNonNull(valueExtractor, "Value extractor is null");
/*  3608 */     Objects.requireNonNull(mapSupplier, "Map supplier is null");
/*  3609 */     return collect(mapSupplier, (m, d) -> m.put(keyExtractor.apply(d), valueExtractor.apply(d)));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <K> Mono<Map<K, Collection<T>>> collectMultimap(Function<? super T, ? extends K> keyExtractor) {
/*  3633 */     return collectMultimap(keyExtractor, (Function)identityFunction());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <K, V> Mono<Map<K, Collection<V>>> collectMultimap(Function<? super T, ? extends K> keyExtractor, Function<? super T, ? extends V> valueExtractor) {
/*  3661 */     return collectMultimap(keyExtractor, valueExtractor, () -> new HashMap<>());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <K, V> Mono<Map<K, Collection<V>>> collectMultimap(Function<? super T, ? extends K> keyExtractor, Function<? super T, ? extends V> valueExtractor, Supplier<Map<K, Collection<V>>> mapSupplier) {
/*  3694 */     Objects.requireNonNull(keyExtractor, "Key extractor is null");
/*  3695 */     Objects.requireNonNull(valueExtractor, "Value extractor is null");
/*  3696 */     Objects.requireNonNull(mapSupplier, "Map supplier is null");
/*  3697 */     return collect(mapSupplier, (m, d) -> {
/*       */           K key = keyExtractor.apply(d);
/*       */           Collection<V> values = m.computeIfAbsent(key, ());
/*       */           values.add(valueExtractor.apply(d));
/*       */         });
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Mono<List<T>> collectSortedList() {
/*  3718 */     return collectSortedList(null);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Mono<List<T>> collectSortedList(@Nullable Comparator<? super T> comparator) {
/*  3738 */     return collectList().doOnNext(list -> list.sort(comparator));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <V> Flux<V> concatMap(Function<? super T, ? extends Publisher<? extends V>> mapper) {
/*  3776 */     return concatMap(mapper, Queues.XS_BUFFER_SIZE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <V> Flux<V> concatMap(Function<? super T, ? extends Publisher<? extends V>> mapper, int prefetch) {
/*  3813 */     if (prefetch == 0) {
/*  3814 */       return onAssembly(new FluxConcatMapNoPrefetch<>(this, mapper, FluxConcatMap.ErrorMode.IMMEDIATE));
/*       */     }
/*  3816 */     return onAssembly(new FluxConcatMap<>(this, mapper, Queues.get(prefetch), prefetch, FluxConcatMap.ErrorMode.IMMEDIATE));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <V> Flux<V> concatMapDelayError(Function<? super T, ? extends Publisher<? extends V>> mapper) {
/*  3854 */     return concatMapDelayError(mapper, Queues.XS_BUFFER_SIZE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <V> Flux<V> concatMapDelayError(Function<? super T, ? extends Publisher<? extends V>> mapper, int prefetch) {
/*  3894 */     return concatMapDelayError(mapper, true, prefetch);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <V> Flux<V> concatMapDelayError(Function<? super T, ? extends Publisher<? extends V>> mapper, boolean delayUntilEnd, int prefetch) {
/*  3935 */     FluxConcatMap.ErrorMode errorMode = delayUntilEnd ? FluxConcatMap.ErrorMode.END : FluxConcatMap.ErrorMode.BOUNDARY;
/*  3936 */     if (prefetch == 0) {
/*  3937 */       return onAssembly(new FluxConcatMapNoPrefetch<>(this, mapper, errorMode));
/*       */     }
/*  3939 */     return onAssembly(new FluxConcatMap<>(this, mapper, Queues.get(prefetch), prefetch, errorMode));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <R> Flux<R> concatMapIterable(Function<? super T, ? extends Iterable<? extends R>> mapper) {
/*  3978 */     return concatMapIterable(mapper, Queues.XS_BUFFER_SIZE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <R> Flux<R> concatMapIterable(Function<? super T, ? extends Iterable<? extends R>> mapper, int prefetch) {
/*  4020 */     return onAssembly(new FluxFlattenIterable<>(this, mapper, prefetch, 
/*  4021 */           Queues.get(prefetch)));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> concatWith(Publisher<? extends T> other) {
/*  4034 */     if (this instanceof FluxConcatArray) {
/*       */       
/*  4036 */       FluxConcatArray<T> fluxConcatArray = (FluxConcatArray<T>)this;
/*       */       
/*  4038 */       return fluxConcatArray.concatAdditionalSourceLast(other);
/*       */     } 
/*  4040 */     return concat((Publisher<? extends T>[])new Publisher[] { (Publisher)this, other });
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> contextWrite(ContextView contextToAppend) {
/*  4062 */     return contextWrite(c -> c.putAll(contextToAppend));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> contextWrite(Function<Context, Context> contextModifier) {
/*  4086 */     return onAssembly(new FluxContextWrite<>(this, contextModifier));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Mono<Long> count() {
/*  4099 */     return Mono.onAssembly(new MonoCount<>(this));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> defaultIfEmpty(T defaultV) {
/*  4112 */     return onAssembly(new FluxDefaultIfEmpty<>(this, defaultV));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> delayElements(Duration delay) {
/*  4129 */     return delayElements(delay, Schedulers.parallel());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> delayElements(Duration delay, Scheduler timer) {
/*  4145 */     return delayUntil(d -> Mono.delay(delay, timer));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> delaySequence(Duration delay) {
/*  4176 */     return delaySequence(delay, Schedulers.parallel());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> delaySequence(Duration delay, Scheduler timer) {
/*  4208 */     return onAssembly(new FluxDelaySequence<>(this, delay, timer));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> delayUntil(Function<? super T, ? extends Publisher<?>> triggerProvider) {
/*  4231 */     return concatMap(v -> Mono.<Object>just(v).delayUntil(triggerProvider));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> delaySubscription(Duration delay) {
/*  4248 */     return delaySubscription(delay, Schedulers.parallel());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> delaySubscription(Duration delay, Scheduler timer) {
/*  4264 */     return delaySubscription((Publisher<Long>)Mono.delay(delay, timer));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <U> Flux<T> delaySubscription(Publisher<U> subscriptionDelay) {
/*  4281 */     return onAssembly(new FluxDelaySubscription<>(this, subscriptionDelay));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <X> Flux<X> dematerialize() {
/*  4301 */     Flux<T> flux = this;
/*  4302 */     return onAssembly(new FluxDematerialize<>((Flux)flux));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> distinct() {
/*  4324 */     return distinct(identityFunction());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <V> Flux<T> distinct(Function<? super T, ? extends V> keySelector) {
/*  4345 */     return distinct(keySelector, (Supplier)hashSetSupplier());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <V, C extends Collection<? super V>> Flux<T> distinct(Function<? super T, ? extends V> keySelector, Supplier<C> distinctCollectionSupplier) {
/*  4373 */     return distinct(keySelector, distinctCollectionSupplier, Collection::add, Collection::clear);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <V, C> Flux<T> distinct(Function<? super T, ? extends V> keySelector, Supplier<C> distinctStoreSupplier, BiPredicate<C, V> distinctPredicate, Consumer<C> cleanup) {
/*  4409 */     if (this instanceof Fuseable) {
/*  4410 */       return onAssembly(new FluxDistinctFuseable<>(this, keySelector, distinctStoreSupplier, distinctPredicate, cleanup));
/*       */     }
/*       */     
/*  4413 */     return onAssembly(new FluxDistinct<>(this, keySelector, distinctStoreSupplier, distinctPredicate, cleanup));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> distinctUntilChanged() {
/*  4437 */     return distinctUntilChanged(identityFunction());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <V> Flux<T> distinctUntilChanged(Function<? super T, ? extends V> keySelector) {
/*  4458 */     return distinctUntilChanged(keySelector, equalPredicate());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <V> Flux<T> distinctUntilChanged(Function<? super T, ? extends V> keySelector, BiPredicate<? super V, ? super V> keyComparator) {
/*  4482 */     return onAssembly(new FluxDistinctUntilChanged<>(this, keySelector, keyComparator));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> doAfterTerminate(Runnable afterTerminate) {
/*  4499 */     Objects.requireNonNull(afterTerminate, "afterTerminate");
/*  4500 */     return doOnSignal(this, null, null, null, null, afterTerminate, null, null);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> doOnCancel(Runnable onCancel) {
/*  4516 */     Objects.requireNonNull(onCancel, "onCancel");
/*  4517 */     return doOnSignal(this, null, null, null, null, null, null, onCancel);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> doOnComplete(Runnable onComplete) {
/*  4533 */     Objects.requireNonNull(onComplete, "onComplete");
/*  4534 */     return doOnSignal(this, null, null, null, onComplete, null, null, null);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <R> Flux<T> doOnDiscard(Class<R> type, Consumer<? super R> discardHook) {
/*  4562 */     return subscriberContext(Operators.discardLocalAdapter(type, discardHook));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> doOnEach(Consumer<? super Signal<T>> signalConsumer) {
/*  4588 */     if (this instanceof Fuseable) {
/*  4589 */       return onAssembly(new FluxDoOnEachFuseable<>(this, signalConsumer));
/*       */     }
/*  4591 */     return onAssembly(new FluxDoOnEach<>(this, signalConsumer));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> doOnError(Consumer<? super Throwable> onError) {
/*  4607 */     Objects.requireNonNull(onError, "onError");
/*  4608 */     return doOnSignal(this, null, null, onError, null, null, null, null);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <E extends Throwable> Flux<T> doOnError(Class<E> exceptionType, Consumer<? super E> onError) {
/*  4628 */     Objects.requireNonNull(exceptionType, "type");
/*       */     
/*  4630 */     Consumer<Throwable> handler = (Consumer)onError;
/*  4631 */     return doOnError(exceptionType::isInstance, handler);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> doOnError(Predicate<? super Throwable> predicate, Consumer<? super Throwable> onError) {
/*  4650 */     Objects.requireNonNull(predicate, "predicate");
/*  4651 */     return doOnError(t -> {
/*       */           if (predicate.test(t)) {
/*       */             onError.accept(t);
/*       */           }
/*       */         });
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> doOnNext(Consumer<? super T> onNext) {
/*  4677 */     Objects.requireNonNull(onNext, "onNext");
/*  4678 */     return doOnSignal(this, null, onNext, null, null, null, null, null);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> doOnRequest(LongConsumer consumer) {
/*  4699 */     Objects.requireNonNull(consumer, "consumer");
/*  4700 */     return doOnSignal(this, null, null, null, null, null, consumer, null);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> doOnSubscribe(Consumer<? super Subscription> onSubscribe) {
/*  4723 */     Objects.requireNonNull(onSubscribe, "onSubscribe");
/*  4724 */     return doOnSignal(this, onSubscribe, null, null, null, null, null, null);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> doOnTerminate(Runnable onTerminate) {
/*  4741 */     Objects.requireNonNull(onTerminate, "onTerminate");
/*  4742 */     return doOnSignal(this, null, null, e -> onTerminate.run(), onTerminate, null, null, null);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> doFirst(Runnable onFirst) {
/*  4785 */     Objects.requireNonNull(onFirst, "onFirst");
/*  4786 */     if (this instanceof Fuseable) {
/*  4787 */       return onAssembly(new FluxDoFirstFuseable<>(this, onFirst));
/*       */     }
/*  4789 */     return onAssembly(new FluxDoFirst<>(this, onFirst));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> doFinally(Consumer<SignalType> onFinally) {
/*  4811 */     Objects.requireNonNull(onFinally, "onFinally");
/*  4812 */     return onAssembly(new FluxDoFinally<>(this, onFinally));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<Tuple2<Long, T>> elapsed() {
/*  4829 */     return elapsed(Schedulers.parallel());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<Tuple2<Long, T>> elapsed(Scheduler scheduler) {
/*  4847 */     Objects.requireNonNull(scheduler, "scheduler");
/*  4848 */     return onAssembly(new FluxElapsed<>(this, scheduler));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Mono<T> elementAt(int index) {
/*  4865 */     return Mono.onAssembly(new MonoElementAt<>(this, index));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Mono<T> elementAt(int index, T defaultValue) {
/*  4883 */     return Mono.onAssembly(new MonoElementAt<>(this, index, defaultValue));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> expandDeep(Function<? super T, ? extends Publisher<? extends T>> expander, int capacityHint) {
/*  4923 */     return onAssembly(new FluxExpand<>(this, expander, false, capacityHint));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> expandDeep(Function<? super T, ? extends Publisher<? extends T>> expander) {
/*  4960 */     return expandDeep(expander, Queues.SMALL_BUFFER_SIZE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> expand(Function<? super T, ? extends Publisher<? extends T>> expander, int capacityHint) {
/*  5000 */     return onAssembly(new FluxExpand<>(this, expander, true, capacityHint));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> expand(Function<? super T, ? extends Publisher<? extends T>> expander) {
/*  5037 */     return expand(expander, Queues.SMALL_BUFFER_SIZE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> filter(Predicate<? super T> p) {
/*  5060 */     if (this instanceof Fuseable) {
/*  5061 */       return onAssembly(new FluxFilterFuseable<>(this, p));
/*       */     }
/*  5063 */     return onAssembly(new FluxFilter<>(this, p));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> filterWhen(Function<? super T, ? extends Publisher<Boolean>> asyncPredicate) {
/*  5088 */     return filterWhen(asyncPredicate, Queues.SMALL_BUFFER_SIZE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> filterWhen(Function<? super T, ? extends Publisher<Boolean>> asyncPredicate, int bufferSize) {
/*  5119 */     return onAssembly(new FluxFilterWhen<>(this, asyncPredicate, bufferSize));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <R> Flux<R> flatMap(Function<? super T, ? extends Publisher<? extends R>> mapper) {
/*  5156 */     return flatMap(mapper, Queues.SMALL_BUFFER_SIZE, Queues.XS_BUFFER_SIZE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <V> Flux<V> flatMap(Function<? super T, ? extends Publisher<? extends V>> mapper, int concurrency) {
/*  5200 */     return flatMap(mapper, concurrency, Queues.XS_BUFFER_SIZE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <V> Flux<V> flatMap(Function<? super T, ? extends Publisher<? extends V>> mapper, int concurrency, int prefetch) {
/*  5247 */     return flatMap(mapper, false, concurrency, prefetch);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <V> Flux<V> flatMapDelayError(Function<? super T, ? extends Publisher<? extends V>> mapper, int concurrency, int prefetch) {
/*  5292 */     return flatMap(mapper, true, concurrency, prefetch);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <R> Flux<R> flatMap(@Nullable Function<? super T, ? extends Publisher<? extends R>> mapperOnNext, @Nullable Function<? super Throwable, ? extends Publisher<? extends R>> mapperOnError, @Nullable Supplier<? extends Publisher<? extends R>> mapperOnComplete) {
/*  5330 */     return onAssembly(new FluxFlatMap<>(new FluxMapSignal<>(this, mapperOnNext, mapperOnError, mapperOnComplete), 
/*       */           
/*  5332 */           (Function)identityFunction(), false, Queues.XS_BUFFER_SIZE, 
/*       */           
/*  5334 */           Queues.xs(), Queues.XS_BUFFER_SIZE, 
/*  5335 */           Queues.xs()));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <R> Flux<R> flatMapIterable(Function<? super T, ? extends Iterable<? extends R>> mapper) {
/*  5376 */     return flatMapIterable(mapper, Queues.SMALL_BUFFER_SIZE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <R> Flux<R> flatMapIterable(Function<? super T, ? extends Iterable<? extends R>> mapper, int prefetch) {
/*  5418 */     return onAssembly(new FluxFlattenIterable<>(this, mapper, prefetch, 
/*  5419 */           Queues.get(prefetch)));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <R> Flux<R> flatMapSequential(Function<? super T, ? extends Publisher<? extends R>> mapper) {
/*  5456 */     return flatMapSequential(mapper, Queues.SMALL_BUFFER_SIZE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <R> Flux<R> flatMapSequential(Function<? super T, ? extends Publisher<? extends R>> mapper, int maxConcurrency) {
/*  5497 */     return flatMapSequential(mapper, maxConcurrency, Queues.XS_BUFFER_SIZE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <R> Flux<R> flatMapSequential(Function<? super T, ? extends Publisher<? extends R>> mapper, int maxConcurrency, int prefetch) {
/*  5541 */     return flatMapSequential(mapper, false, maxConcurrency, prefetch);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <R> Flux<R> flatMapSequentialDelayError(Function<? super T, ? extends Publisher<? extends R>> mapper, int maxConcurrency, int prefetch) {
/*  5586 */     return flatMapSequential(mapper, true, maxConcurrency, prefetch);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public int getPrefetch() {
/*  5594 */     return -1;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <K> Flux<GroupedFlux<K, T>> groupBy(Function<? super T, ? extends K> keyMapper) {
/*  5625 */     return groupBy(keyMapper, (Function)identityFunction());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <K> Flux<GroupedFlux<K, T>> groupBy(Function<? super T, ? extends K> keyMapper, int prefetch) {
/*  5657 */     return groupBy(keyMapper, (Function)identityFunction(), prefetch);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <K, V> Flux<GroupedFlux<K, V>> groupBy(Function<? super T, ? extends K> keyMapper, Function<? super T, ? extends V> valueMapper) {
/*  5693 */     return groupBy(keyMapper, valueMapper, Queues.SMALL_BUFFER_SIZE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <K, V> Flux<GroupedFlux<K, V>> groupBy(Function<? super T, ? extends K> keyMapper, Function<? super T, ? extends V> valueMapper, int prefetch) {
/*  5731 */     return onAssembly(new FluxGroupBy<>(this, keyMapper, valueMapper, 
/*  5732 */           Queues.unbounded(prefetch), 
/*  5733 */           Queues.unbounded(prefetch), prefetch));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <TRight, TLeftEnd, TRightEnd, R> Flux<R> groupJoin(Publisher<? extends TRight> other, Function<? super T, ? extends Publisher<TLeftEnd>> leftEnd, Function<? super TRight, ? extends Publisher<TRightEnd>> rightEnd, BiFunction<? super T, ? super Flux<TRight>, ? extends R> resultSelector) {
/*  5773 */     return onAssembly(new FluxGroupJoin<>(this, other, leftEnd, rightEnd, resultSelector, 
/*       */           
/*  5775 */           Queues.unbounded(Queues.XS_BUFFER_SIZE), 
/*  5776 */           Queues.unbounded(Queues.XS_BUFFER_SIZE)));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <R> Flux<R> handle(BiConsumer<? super T, SynchronousSink<R>> handler) {
/*  5796 */     if (this instanceof Fuseable) {
/*  5797 */       return onAssembly(new FluxHandleFuseable<>(this, handler));
/*       */     }
/*  5799 */     return onAssembly(new FluxHandle<>(this, handler));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Mono<Boolean> hasElement(T value) {
/*  5819 */     Objects.requireNonNull(value, "value");
/*  5820 */     return any(t -> Objects.equals(value, t));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Mono<Boolean> hasElements() {
/*  5835 */     return Mono.onAssembly(new MonoHasElements<>(this));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public Flux<T> hide() {
/*  5846 */     return new FluxHide<>(this);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<Tuple2<Long, T>> index() {
/*  5859 */     return index((BiFunction)tuple2Function());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <I> Flux<I> index(BiFunction<? super Long, ? super T, ? extends I> indexMapper) {
/*  5879 */     if (this instanceof Fuseable) {
/*  5880 */       return onAssembly(new FluxIndexFuseable<>(this, indexMapper));
/*       */     }
/*  5882 */     return onAssembly(new FluxIndex<>(this, indexMapper));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Mono<T> ignoreElements() {
/*  5897 */     return Mono.onAssembly(new MonoIgnoreElements<>(this));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <TRight, TLeftEnd, TRightEnd, R> Flux<R> join(Publisher<? extends TRight> other, Function<? super T, ? extends Publisher<TLeftEnd>> leftEnd, Function<? super TRight, ? extends Publisher<TRightEnd>> rightEnd, BiFunction<? super T, ? super TRight, ? extends R> resultSelector) {
/*  5935 */     return onAssembly(new FluxJoin<>(this, other, leftEnd, rightEnd, resultSelector));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Mono<T> last() {
/*  5952 */     if (this instanceof Callable) {
/*       */       
/*  5954 */       Callable<T> thiz = (Callable<T>)this;
/*  5955 */       Mono<T> callableMono = wrapToMono(thiz);
/*  5956 */       if (callableMono == Mono.empty()) {
/*  5957 */         return Mono.onAssembly(new MonoError<>(new NoSuchElementException("Flux#last() didn't observe any onNext signal from Callable flux")));
/*       */       }
/*  5959 */       return Mono.onAssembly(callableMono);
/*       */     } 
/*  5961 */     return Mono.onAssembly(new MonoTakeLastOne<>(this));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Mono<T> last(T defaultValue) {
/*  5979 */     if (this instanceof Callable) {
/*       */       
/*  5981 */       Callable<T> thiz = (Callable<T>)this;
/*  5982 */       if (thiz instanceof Fuseable.ScalarCallable) {
/*       */         T v;
/*  5984 */         Fuseable.ScalarCallable<T> c = (Fuseable.ScalarCallable<T>)thiz;
/*       */         
/*       */         try {
/*  5987 */           v = (T)c.call();
/*       */         }
/*  5989 */         catch (Exception e) {
/*  5990 */           return Mono.error(Exceptions.unwrap(e));
/*       */         } 
/*  5992 */         if (v == null) {
/*  5993 */           return Mono.just(defaultValue);
/*       */         }
/*  5995 */         return Mono.just(v);
/*       */       } 
/*  5997 */       Mono.onAssembly(new MonoCallable(thiz));
/*       */     } 
/*  5999 */     return Mono.onAssembly(new MonoTakeLastOne<>(this, defaultValue));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> limitRate(int prefetchRate) {
/*  6031 */     return onAssembly(publishOn(Schedulers.immediate(), prefetchRate));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> limitRate(int highTide, int lowTide) {
/*  6073 */     return onAssembly(publishOn(Schedulers.immediate(), true, highTide, lowTide));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @Deprecated
/*       */   public final Flux<T> limitRequest(long n) {
/*  6105 */     return take(n, true);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> log() {
/*  6121 */     return log(null, Level.INFO, new SignalType[0]);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> log(String category) {
/*  6138 */     return log(category, Level.INFO, new SignalType[0]);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> log(@Nullable String category, Level level, SignalType... options) {
/*  6164 */     return log(category, level, false, options);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> log(@Nullable String category, Level level, boolean showOperatorLine, SignalType... options) {
/*  6194 */     SignalLogger<T> log = new SignalLogger<>(this, category, level, showOperatorLine, options);
/*       */ 
/*       */     
/*  6197 */     if (this instanceof Fuseable) {
/*  6198 */       return onAssembly(new FluxLogFuseable<>(this, log));
/*       */     }
/*  6200 */     return onAssembly(new FluxLog<>(this, log));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> log(Logger logger) {
/*  6214 */     return log(logger, Level.INFO, false, new SignalType[0]);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> log(Logger logger, Level level, boolean showOperatorLine, SignalType... options) {
/*  6241 */     SignalLogger<T> log = new SignalLogger<>(this, "IGNORED", level, showOperatorLine, s -> logger, options);
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  6246 */     if (this instanceof Fuseable) {
/*  6247 */       return onAssembly(new FluxLogFuseable<>(this, log));
/*       */     }
/*  6249 */     return onAssembly(new FluxLog<>(this, log));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <V> Flux<V> map(Function<? super T, ? extends V> mapper) {
/*  6270 */     if (this instanceof Fuseable) {
/*  6271 */       return onAssembly(new FluxMapFuseable<>(this, mapper));
/*       */     }
/*  6273 */     return onAssembly(new FluxMap<>(this, mapper));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <V> Flux<V> mapNotNull(Function<? super T, ? extends V> mapper) {
/*  6297 */     return handle((t, sink) -> {
/*       */           V v = mapper.apply(t);
/*       */           if (v != null) {
/*       */             sink.next(v);
/*       */           }
/*       */         });
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<Signal<T>> materialize() {
/*  6319 */     return onAssembly(new FluxMaterialize<>(this));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @Deprecated
/*       */   public final Flux<T> mergeOrderedWith(Publisher<? extends T> other, Comparator<? super T> otherComparator) {
/*  6353 */     if (this instanceof FluxMergeComparing) {
/*  6354 */       FluxMergeComparing<T> fluxMerge = (FluxMergeComparing<T>)this;
/*  6355 */       return fluxMerge.mergeAdditionalSource(other, otherComparator);
/*       */     } 
/*  6357 */     return mergeOrdered(otherComparator, (Publisher<? extends T>[])new Publisher[] { (Publisher)this, other });
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> mergeComparingWith(Publisher<? extends T> other, Comparator<? super T> otherComparator) {
/*  6388 */     if (this instanceof FluxMergeComparing) {
/*  6389 */       FluxMergeComparing<T> fluxMerge = (FluxMergeComparing<T>)this;
/*  6390 */       return fluxMerge.mergeAdditionalSource(other, otherComparator);
/*       */     } 
/*  6392 */     return mergeComparing(otherComparator, (Publisher<? extends T>[])new Publisher[] { (Publisher)this, other });
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> mergeWith(Publisher<? extends T> other) {
/*  6412 */     if (this instanceof FluxMerge) {
/*  6413 */       FluxMerge<T> fluxMerge = (FluxMerge<T>)this;
/*  6414 */       return fluxMerge.mergeAdditionalSource(other, Queues::get);
/*       */     } 
/*  6416 */     return merge((Publisher<? extends T>[])new Publisher[] { (Publisher)this, other });
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> metrics() {
/*  6440 */     if (!Metrics.isInstrumentationAvailable()) {
/*  6441 */       return this;
/*       */     }
/*       */     
/*  6444 */     if (this instanceof Fuseable) {
/*  6445 */       return onAssembly(new FluxMetricsFuseable<>(this));
/*       */     }
/*  6447 */     return onAssembly(new FluxMetrics<>(this));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> name(String name) {
/*  6464 */     return FluxName.createOrAppend(this, name);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Mono<T> next() {
/*  6476 */     if (this instanceof Callable) {
/*       */       
/*  6478 */       Callable<T> m = (Callable<T>)this;
/*  6479 */       return Mono.onAssembly(wrapToMono(m));
/*       */     } 
/*  6481 */     return Mono.onAssembly(new MonoNext<>(this));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <U> Flux<U> ofType(Class<U> clazz) {
/*  6497 */     Objects.requireNonNull(clazz, "clazz");
/*  6498 */     return filter(o -> clazz.isAssignableFrom(o.getClass())).cast(clazz);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> onBackpressureBuffer() {
/*  6515 */     return onAssembly(new FluxOnBackpressureBuffer<>(this, Queues.SMALL_BUFFER_SIZE, true, null));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> onBackpressureBuffer(int maxSize) {
/*  6539 */     return onAssembly(new FluxOnBackpressureBuffer<>(this, maxSize, false, null));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> onBackpressureBuffer(int maxSize, Consumer<? super T> onOverflow) {
/*  6567 */     Objects.requireNonNull(onOverflow, "onOverflow");
/*  6568 */     return onAssembly(new FluxOnBackpressureBuffer<>(this, maxSize, false, onOverflow));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> onBackpressureBuffer(int maxSize, BufferOverflowStrategy bufferOverflowStrategy) {
/*  6594 */     Objects.requireNonNull(bufferOverflowStrategy, "bufferOverflowStrategy");
/*  6595 */     return onAssembly(new FluxOnBackpressureBufferStrategy<>(this, maxSize, null, bufferOverflowStrategy));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> onBackpressureBuffer(int maxSize, Consumer<? super T> onBufferOverflow, BufferOverflowStrategy bufferOverflowStrategy) {
/*  6630 */     Objects.requireNonNull(onBufferOverflow, "onBufferOverflow");
/*  6631 */     Objects.requireNonNull(bufferOverflowStrategy, "bufferOverflowStrategy");
/*  6632 */     return onAssembly(new FluxOnBackpressureBufferStrategy<>(this, maxSize, onBufferOverflow, bufferOverflowStrategy));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> onBackpressureBuffer(Duration ttl, int maxSize, Consumer<? super T> onBufferEviction) {
/*  6660 */     return onBackpressureBuffer(ttl, maxSize, onBufferEviction, Schedulers.parallel());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> onBackpressureBuffer(Duration ttl, int maxSize, Consumer<? super T> onBufferEviction, Scheduler scheduler) {
/*  6687 */     Objects.requireNonNull(ttl, "ttl");
/*  6688 */     Objects.requireNonNull(onBufferEviction, "onBufferEviction");
/*  6689 */     return onAssembly(new FluxOnBackpressureBufferTimeout<>(this, ttl, scheduler, maxSize, onBufferEviction));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> onBackpressureDrop() {
/*  6704 */     return onAssembly(new FluxOnBackpressureDrop<>(this));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> onBackpressureDrop(Consumer<? super T> onDropped) {
/*  6722 */     return onAssembly(new FluxOnBackpressureDrop<>(this, onDropped));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> onBackpressureError() {
/*  6739 */     return onBackpressureDrop(t -> {
/*       */           throw Exceptions.failWithOverflow();
/*       */         });
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> onBackpressureLatest() {
/*  6755 */     return onAssembly(new FluxOnBackpressureLatest<>(this));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> onErrorContinue(BiConsumer<Throwable, Object> errorConsumer) {
/*  6790 */     BiConsumer<Throwable, Object> genericConsumer = errorConsumer;
/*  6791 */     return subscriberContext(Context.of("reactor.onNextError.localStrategy", 
/*       */           
/*  6793 */           OnNextFailureStrategy.resume(genericConsumer)));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <E extends Throwable> Flux<T> onErrorContinue(Class<E> type, BiConsumer<Throwable, Object> errorConsumer) {
/*  6831 */     return onErrorContinue(type::isInstance, errorConsumer);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <E extends Throwable> Flux<T> onErrorContinue(Predicate<E> errorPredicate, BiConsumer<Throwable, Object> errorConsumer) {
/*  6873 */     Predicate<Throwable> genericPredicate = errorPredicate;
/*  6874 */     BiConsumer<Throwable, Object> genericErrorConsumer = errorConsumer;
/*  6875 */     return subscriberContext(Context.of("reactor.onNextError.localStrategy", 
/*       */           
/*  6877 */           OnNextFailureStrategy.resumeIf(genericPredicate, genericErrorConsumer)));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> onErrorStop() {
/*  6892 */     return subscriberContext(Context.of("reactor.onNextError.localStrategy", 
/*       */           
/*  6894 */           OnNextFailureStrategy.stop()));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> onErrorMap(Function<? super Throwable, ? extends Throwable> mapper) {
/*  6908 */     return onErrorResume(e -> Mono.error(mapper.apply(e)));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <E extends Throwable> Flux<T> onErrorMap(Class<E> type, Function<? super E, ? extends Throwable> mapper) {
/*  6926 */     Function<Throwable, Throwable> handler = (Function)mapper;
/*  6927 */     return onErrorMap(type::isInstance, handler);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> onErrorMap(Predicate<? super Throwable> predicate, Function<? super Throwable, ? extends Throwable> mapper) {
/*  6943 */     return onErrorResume(predicate, e -> Mono.error(mapper.apply(e)));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> onErrorResume(Function<? super Throwable, ? extends Publisher<? extends T>> fallback) {
/*  6958 */     return onAssembly(new FluxOnErrorResume<>(this, fallback));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <E extends Throwable> Flux<T> onErrorResume(Class<E> type, Function<? super E, ? extends Publisher<? extends T>> fallback) {
/*  6975 */     Objects.requireNonNull(type, "type");
/*       */     
/*  6977 */     Function<? super E, ? extends Publisher<? extends T>> function = fallback;
/*       */     
/*  6979 */     return onErrorResume(type::isInstance, function);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> onErrorResume(Predicate<? super Throwable> predicate, Function<? super Throwable, ? extends Publisher<? extends T>> fallback) {
/*  6995 */     Objects.requireNonNull(predicate, "predicate");
/*  6996 */     return onErrorResume(e -> predicate.test(e) ? fallback.apply(e) : (Publisher)error(e));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> onErrorReturn(T fallbackValue) {
/*  7009 */     return onErrorResume(t -> just(fallbackValue));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <E extends Throwable> Flux<T> onErrorReturn(Class<E> type, T fallbackValue) {
/*  7026 */     return onErrorResume(type, t -> just(fallbackValue));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> onErrorReturn(Predicate<? super Throwable> predicate, T fallbackValue) {
/*  7041 */     return onErrorResume(predicate, t -> just(fallbackValue));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> onTerminateDetach() {
/*  7053 */     return new FluxDetach<>(this);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> or(Publisher<? extends T> other) {
/*  7071 */     if (this instanceof FluxFirstWithSignal) {
/*  7072 */       FluxFirstWithSignal<T> orPublisher = (FluxFirstWithSignal<T>)this;
/*       */       
/*  7074 */       FluxFirstWithSignal<T> result = orPublisher.orAdditionalSource(other);
/*  7075 */       if (result != null) {
/*  7076 */         return result;
/*       */       }
/*       */     } 
/*  7079 */     return firstWithSignal((Publisher<? extends T>[])new Publisher[] { (Publisher)this, other });
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final ParallelFlux<T> parallel() {
/*  7093 */     return parallel(Schedulers.DEFAULT_POOL_SIZE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final ParallelFlux<T> parallel(int parallelism) {
/*  7110 */     return parallel(parallelism, Queues.SMALL_BUFFER_SIZE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final ParallelFlux<T> parallel(int parallelism, int prefetch) {
/*  7129 */     return ParallelFlux.from((Publisher<? extends T>)this, parallelism, prefetch, 
/*       */ 
/*       */         
/*  7132 */         Queues.get(prefetch));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final ConnectableFlux<T> publish() {
/*  7150 */     return publish(Queues.SMALL_BUFFER_SIZE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final ConnectableFlux<T> publish(int prefetch) {
/*  7169 */     return onAssembly(new FluxPublish<>(this, prefetch, 
/*  7170 */           Queues.get(prefetch)));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <R> Flux<R> publish(Function<? super Flux<T>, ? extends Publisher<? extends R>> transform) {
/*  7185 */     return publish(transform, Queues.SMALL_BUFFER_SIZE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <R> Flux<R> publish(Function<? super Flux<T>, ? extends Publisher<? extends R>> transform, int prefetch) {
/*  7201 */     return onAssembly(new FluxPublishMulticast<>(this, transform, prefetch, 
/*  7202 */           Queues.get(prefetch)));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @Deprecated
/*       */   public final Mono<T> publishNext() {
/*  7220 */     return shareNext();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> publishOn(Scheduler scheduler) {
/*  7244 */     return publishOn(scheduler, Queues.SMALL_BUFFER_SIZE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> publishOn(Scheduler scheduler, int prefetch) {
/*  7269 */     return publishOn(scheduler, true, prefetch);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> publishOn(Scheduler scheduler, boolean delayError, int prefetch) {
/*  7295 */     return publishOn(scheduler, delayError, prefetch, prefetch);
/*       */   }
/*       */   
/*       */   final Flux<T> publishOn(Scheduler scheduler, boolean delayError, int prefetch, int lowTide) {
/*  7299 */     if (this instanceof Callable) {
/*  7300 */       if (this instanceof Fuseable.ScalarCallable) {
/*       */         
/*  7302 */         Fuseable.ScalarCallable<T> s = (Fuseable.ScalarCallable<T>)this;
/*       */         try {
/*  7304 */           return onAssembly(new FluxSubscribeOnValue<>((T)s.call(), scheduler));
/*       */         }
/*  7306 */         catch (Exception exception) {}
/*       */       } 
/*       */ 
/*       */ 
/*       */       
/*  7311 */       Callable<T> c = (Callable<T>)this;
/*  7312 */       return onAssembly(new FluxSubscribeOnCallable<>(c, scheduler));
/*       */     } 
/*       */     
/*  7315 */     return onAssembly(new FluxPublishOn<>(this, scheduler, delayError, prefetch, lowTide, Queues.get(prefetch)));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Mono<T> reduce(BiFunction<T, T, T> aggregator) {
/*  7336 */     if (this instanceof Callable) {
/*       */       
/*  7338 */       Callable<T> thiz = (Callable<T>)this;
/*  7339 */       return Mono.onAssembly(wrapToMono(thiz));
/*       */     } 
/*  7341 */     return Mono.onAssembly(new MonoReduce<>(this, aggregator));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <A> Mono<A> reduce(A initial, BiFunction<A, ? super T, A> accumulator) {
/*  7364 */     return reduceWith(() -> initial, accumulator);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <A> Mono<A> reduceWith(Supplier<A> initial, BiFunction<A, ? super T, A> accumulator) {
/*  7387 */     return Mono.onAssembly(new MonoReduceSeed<>(this, initial, accumulator));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> repeat() {
/*  7400 */     return repeat(ALWAYS_BOOLEAN_SUPPLIER);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> repeat(BooleanSupplier predicate) {
/*  7414 */     return onAssembly(new FluxRepeatPredicate<>(this, predicate));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> repeat(long numRepeat) {
/*  7430 */     if (numRepeat == 0L) {
/*  7431 */       return this;
/*       */     }
/*  7433 */     return onAssembly(new FluxRepeat<>(this, numRepeat));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> repeat(long numRepeat, BooleanSupplier predicate) {
/*  7450 */     if (numRepeat < 0L) {
/*  7451 */       throw new IllegalArgumentException("numRepeat >= 0 required");
/*       */     }
/*  7453 */     if (numRepeat == 0L) {
/*  7454 */       return this;
/*       */     }
/*  7456 */     return defer(() -> repeat(countingBooleanSupplier(predicate, numRepeat)));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> repeatWhen(Function<Flux<Long>, ? extends Publisher<?>> repeatFactory) {
/*  7494 */     return onAssembly(new FluxRepeatWhen<>(this, repeatFactory));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final ConnectableFlux<T> replay() {
/*  7507 */     return replay(2147483647);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final ConnectableFlux<T> replay(int history) {
/*  7529 */     if (history == 0)
/*       */     {
/*  7531 */       return onAssembly(new FluxPublish<>(this, Queues.SMALL_BUFFER_SIZE, Queues.get(Queues.SMALL_BUFFER_SIZE)));
/*       */     }
/*  7533 */     return onAssembly(new FluxReplay<>(this, history, 0L, null));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final ConnectableFlux<T> replay(Duration ttl) {
/*  7552 */     return replay(2147483647, ttl);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final ConnectableFlux<T> replay(int history, Duration ttl) {
/*  7572 */     return replay(history, ttl, Schedulers.parallel());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final ConnectableFlux<T> replay(Duration ttl, Scheduler timer) {
/*  7591 */     return replay(2147483647, ttl, timer);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final ConnectableFlux<T> replay(int history, Duration ttl, Scheduler timer) {
/*  7611 */     Objects.requireNonNull(timer, "timer");
/*  7612 */     if (history == 0)
/*       */     {
/*  7614 */       return onAssembly(new FluxPublish<>(this, Queues.SMALL_BUFFER_SIZE, Queues.get(Queues.SMALL_BUFFER_SIZE)));
/*       */     }
/*  7616 */     return onAssembly(new FluxReplay<>(this, history, ttl.toNanos(), timer));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> retry() {
/*  7627 */     return retry(Long.MAX_VALUE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> retry(long numRetries) {
/*  7644 */     return onAssembly(new FluxRetry<>(this, numRetries));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> retryWhen(Retry retrySpec) {
/*  7700 */     return onAssembly(new FluxRetryWhen<>(this, retrySpec));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> sample(Duration timespan) {
/*  7720 */     return sample((Publisher<Long>)interval(timespan));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <U> Flux<T> sample(Publisher<U> sampler) {
/*  7748 */     return onAssembly(new FluxSample<>(this, sampler));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> sampleFirst(Duration timespan) {
/*  7765 */     return sampleFirst(t -> Mono.delay(timespan));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <U> Flux<T> sampleFirst(Function<? super T, ? extends Publisher<U>> samplerFactory) {
/*  7783 */     return onAssembly(new FluxSampleFirst<>(this, samplerFactory));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <U> Flux<T> sampleTimeout(Function<? super T, ? extends Publisher<U>> throttlerFactory) {
/*  7807 */     return sampleTimeout(throttlerFactory, Queues.XS_BUFFER_SIZE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <U> Flux<T> sampleTimeout(Function<? super T, ? extends Publisher<U>> throttlerFactory, int maxConcurrency) {
/*  7836 */     return onAssembly(new FluxSampleTimeout<>(this, throttlerFactory, 
/*  7837 */           Queues.get(maxConcurrency)));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> scan(BiFunction<T, T, T> accumulator) {
/*  7864 */     return onAssembly(new FluxScan<>(this, accumulator));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <A> Flux<A> scan(A initial, BiFunction<A, ? super T, A> accumulator) {
/*  7891 */     Objects.requireNonNull(initial, "seed");
/*  7892 */     return scanWith(() -> initial, accumulator);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <A> Flux<A> scanWith(Supplier<A> initial, BiFunction<A, ? super T, A> accumulator) {
/*  7922 */     return onAssembly(new FluxScanSeed<>(this, initial, accumulator));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> share() {
/*  7937 */     return onAssembly(new FluxRefCount<>(new FluxPublish<>(this, Queues.SMALL_BUFFER_SIZE, 
/*  7938 */             Queues.small()), 1));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Mono<T> shareNext() {
/*  7953 */     NextProcessor<T> nextProcessor = new NextProcessor<>(this);
/*  7954 */     return Mono.onAssembly(nextProcessor);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Mono<T> single() {
/*  7968 */     if (this instanceof Callable) {
/*  7969 */       if (this instanceof Fuseable.ScalarCallable) {
/*       */         T v;
/*  7971 */         Fuseable.ScalarCallable<T> scalarCallable = (Fuseable.ScalarCallable<T>)this;
/*       */ 
/*       */         
/*       */         try {
/*  7975 */           v = (T)scalarCallable.call();
/*       */         }
/*  7977 */         catch (Exception e) {
/*  7978 */           return Mono.error(Exceptions.unwrap(e));
/*       */         } 
/*  7980 */         if (v == null) {
/*  7981 */           return Mono.error(new NoSuchElementException("Source was a (constant) empty"));
/*       */         }
/*  7983 */         return Mono.just(v);
/*       */       } 
/*       */       
/*  7986 */       Callable<T> thiz = (Callable<T>)this;
/*  7987 */       return Mono.onAssembly(new MonoSingleCallable<>(thiz));
/*       */     } 
/*  7989 */     return Mono.onAssembly(new MonoSingle<>(this));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Mono<T> single(T defaultValue) {
/*  8006 */     if (this instanceof Callable) {
/*  8007 */       if (this instanceof Fuseable.ScalarCallable) {
/*       */         T v;
/*  8009 */         Fuseable.ScalarCallable<T> scalarCallable = (Fuseable.ScalarCallable<T>)this;
/*       */ 
/*       */         
/*       */         try {
/*  8013 */           v = (T)scalarCallable.call();
/*       */         }
/*  8015 */         catch (Exception e) {
/*  8016 */           return Mono.error(Exceptions.unwrap(e));
/*       */         } 
/*  8018 */         if (v == null) {
/*  8019 */           return Mono.just(defaultValue);
/*       */         }
/*  8021 */         return Mono.just(v);
/*       */       } 
/*       */       
/*  8024 */       Callable<T> thiz = (Callable<T>)this;
/*  8025 */       return Mono.onAssembly(new MonoSingleCallable<>(thiz, defaultValue));
/*       */     } 
/*  8027 */     return Mono.onAssembly(new MonoSingle<>(this, defaultValue, false));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Mono<T> singleOrEmpty() {
/*  8040 */     if (this instanceof Callable) {
/*       */       
/*  8042 */       Callable<T> thiz = (Callable<T>)this;
/*  8043 */       return Mono.onAssembly(wrapToMono(thiz));
/*       */     } 
/*  8045 */     return Mono.onAssembly(new MonoSingle<>(this, null, true));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> skip(long skipped) {
/*  8063 */     if (skipped == 0L) {
/*  8064 */       return this;
/*       */     }
/*       */     
/*  8067 */     return onAssembly(new FluxSkip<>(this, skipped));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> skip(Duration timespan) {
/*  8084 */     return skip(timespan, Schedulers.parallel());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> skip(Duration timespan, Scheduler timer) {
/*  8102 */     if (!timespan.isZero()) {
/*  8103 */       return skipUntilOther((Publisher<?>)Mono.delay(timespan, timer));
/*       */     }
/*       */     
/*  8106 */     return this;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> skipLast(int n) {
/*  8125 */     if (n == 0) {
/*  8126 */       return this;
/*       */     }
/*  8128 */     return onAssembly(new FluxSkipLast<>(this, n));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> skipUntil(Predicate<? super T> untilPredicate) {
/*  8145 */     return onAssembly(new FluxSkipUntil<>(this, untilPredicate));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> skipUntilOther(Publisher<?> other) {
/*  8163 */     return onAssembly(new FluxSkipUntilOther<>(this, other));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> skipWhile(Predicate<? super T> skipPredicate) {
/*  8179 */     return onAssembly(new FluxSkipWhile<>(this, skipPredicate));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> sort() {
/*  8198 */     return collectSortedList().flatMapIterable((Function)identityFunction());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> sort(Comparator<? super T> sortFunction) {
/*  8216 */     return collectSortedList(sortFunction).flatMapIterable((Function)identityFunction());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> startWith(Iterable<? extends T> iterable) {
/*  8230 */     return startWith((Publisher<? extends T>)fromIterable(iterable));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @SafeVarargs
/*       */   public final Flux<T> startWith(T... values) {
/*  8245 */     return startWith((Publisher<? extends T>)just(values));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> startWith(Publisher<? extends T> publisher) {
/*  8259 */     if (this instanceof FluxConcatArray) {
/*  8260 */       FluxConcatArray<T> fluxConcatArray = (FluxConcatArray<T>)this;
/*  8261 */       return fluxConcatArray.concatAdditionalSourceFirst(publisher);
/*       */     } 
/*  8263 */     return concat((Publisher<? extends T>[])new Publisher[] { publisher, (Publisher)this });
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Disposable subscribe() {
/*  8278 */     return subscribe(null, null, null);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Disposable subscribe(Consumer<? super T> consumer) {
/*  8302 */     Objects.requireNonNull(consumer, "consumer");
/*  8303 */     return subscribe(consumer, null, null);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Disposable subscribe(@Nullable Consumer<? super T> consumer, Consumer<? super Throwable> errorConsumer) {
/*  8329 */     Objects.requireNonNull(errorConsumer, "errorConsumer");
/*  8330 */     return subscribe(consumer, errorConsumer, null);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Disposable subscribe(@Nullable Consumer<? super T> consumer, @Nullable Consumer<? super Throwable> errorConsumer, @Nullable Runnable completeConsumer) {
/*  8360 */     return subscribe(consumer, errorConsumer, completeConsumer, (Context)null);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @Deprecated
/*       */   public final Disposable subscribe(@Nullable Consumer<? super T> consumer, @Nullable Consumer<? super Throwable> errorConsumer, @Nullable Runnable completeConsumer, @Nullable Consumer<? super Subscription> subscriptionConsumer) {
/*  8399 */     return subscribeWith(new LambdaSubscriber<>(consumer, errorConsumer, completeConsumer, subscriptionConsumer, null));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Disposable subscribe(@Nullable Consumer<? super T> consumer, @Nullable Consumer<? super Throwable> errorConsumer, @Nullable Runnable completeConsumer, @Nullable Context initialContext) {
/*  8436 */     return subscribeWith(new LambdaSubscriber<>(consumer, errorConsumer, completeConsumer, null, initialContext));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final void subscribe(Subscriber<? super T> actual) {
/*  8445 */     CorePublisher<T> publisher = Operators.onLastAssembly(this);
/*  8446 */     CoreSubscriber<? super T> subscriber = Operators.toCoreSubscriber(actual);
/*       */     
/*       */     try {
/*  8449 */       if (publisher instanceof OptimizableOperator) {
/*  8450 */         OptimizableOperator<T, T> operator = (OptimizableOperator)publisher;
/*       */         while (true) {
/*  8452 */           subscriber = operator.subscribeOrReturn(subscriber);
/*  8453 */           if (subscriber == null) {
/*       */             return;
/*       */           }
/*       */           
/*  8457 */           OptimizableOperator<?, ? extends T> newSource = operator.nextOptimizableSource();
/*  8458 */           if (newSource == null) {
/*  8459 */             publisher = (CorePublisher)operator.source();
/*       */             break;
/*       */           } 
/*  8462 */           OptimizableOperator<?, ? extends T> optimizableOperator1 = newSource;
/*       */         } 
/*       */       } 
/*       */       
/*  8466 */       publisher.subscribe(subscriber);
/*       */     }
/*  8468 */     catch (Throwable e) {
/*  8469 */       Operators.reportThrowInSubscribe(subscriber, e);
/*       */       return;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @Deprecated
/*       */   public final Flux<T> subscriberContext(Context mergeContext) {
/*  8508 */     return subscriberContext(c -> c.putAll(mergeContext.readOnly()));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @Deprecated
/*       */   public final Flux<T> subscriberContext(Function<Context, Context> doOnContext) {
/*  8532 */     return contextWrite(doOnContext);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> subscribeOn(Scheduler scheduler) {
/*  8567 */     return subscribeOn(scheduler, true);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> subscribeOn(Scheduler scheduler, boolean requestOnSeparateThread) {
/*  8606 */     if (this instanceof Callable) {
/*  8607 */       if (this instanceof Fuseable.ScalarCallable) {
/*       */         try {
/*  8609 */           T value = (T)((Fuseable.ScalarCallable)this).call();
/*  8610 */           return onAssembly(new FluxSubscribeOnValue<>(value, scheduler));
/*       */         }
/*  8612 */         catch (Exception exception) {}
/*       */       }
/*       */ 
/*       */ 
/*       */       
/*  8617 */       Callable<T> c = (Callable<T>)this;
/*  8618 */       return onAssembly(new FluxSubscribeOnCallable<>(c, scheduler));
/*       */     } 
/*  8620 */     return onAssembly(new FluxSubscribeOn<>(this, scheduler, requestOnSeparateThread));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <E extends Subscriber<? super T>> E subscribeWith(E subscriber) {
/*  8639 */     subscribe((Subscriber<? super T>)subscriber);
/*  8640 */     return subscriber;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <V> Flux<V> switchOnFirst(BiFunction<Signal<? extends T>, Flux<T>, Publisher<? extends V>> transformer) {
/*  8688 */     return switchOnFirst(transformer, true);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <V> Flux<V> switchOnFirst(BiFunction<Signal<? extends T>, Flux<T>, Publisher<? extends V>> transformer, boolean cancelSourceOnComplete) {
/*  8737 */     return onAssembly(new FluxSwitchOnFirst<>(this, transformer, cancelSourceOnComplete));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> switchIfEmpty(Publisher<? extends T> alternate) {
/*  8750 */     return onAssembly(new FluxSwitchIfEmpty<>(this, alternate));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <V> Flux<V> switchMap(Function<? super T, Publisher<? extends V>> fn) {
/*  8769 */     return switchMap(fn, Queues.XS_BUFFER_SIZE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @Deprecated
/*       */   public final <V> Flux<V> switchMap(Function<? super T, Publisher<? extends V>> fn, int prefetch) {
/*  8794 */     if (prefetch == 0) {
/*  8795 */       return onAssembly(new FluxSwitchMapNoPrefetch<>(this, fn));
/*       */     }
/*  8797 */     return onAssembly(new FluxSwitchMap<>(this, fn, Queues.unbounded(prefetch), prefetch));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> tag(String key, String value) {
/*  8818 */     return FluxName.createOrAppend(this, key, value);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> take(long n) {
/*  8843 */     return take(n, false);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> take(long n, boolean limitRequest) {
/*  8879 */     if (limitRequest) {
/*  8880 */       return onAssembly(new FluxLimitRequest<>(this, n));
/*       */     }
/*  8882 */     if (this instanceof Fuseable) {
/*  8883 */       return onAssembly(new FluxTakeFuseable<>(this, n));
/*       */     }
/*  8885 */     return onAssembly(new FluxTake<>(this, n));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> take(Duration timespan) {
/*  8903 */     return take(timespan, Schedulers.parallel());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> take(Duration timespan, Scheduler timer) {
/*  8923 */     if (!timespan.isZero()) {
/*  8924 */       return takeUntilOther((Publisher<?>)Mono.delay(timespan, timer));
/*       */     }
/*       */     
/*  8927 */     return take(0L);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> takeLast(int n) {
/*  8943 */     if (n == 1) {
/*  8944 */       return onAssembly(new FluxTakeLastOne<>(this));
/*       */     }
/*  8946 */     return onAssembly(new FluxTakeLast<>(this, n));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> takeUntil(Predicate<? super T> predicate) {
/*  8963 */     return onAssembly(new FluxTakeUntil<>(this, predicate));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> takeUntilOther(Publisher<?> other) {
/*  8978 */     return onAssembly(new FluxTakeUntilOther<>(this, other));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> takeWhile(Predicate<? super T> continuePredicate) {
/*  8995 */     return onAssembly(new FluxTakeWhile<>(this, continuePredicate));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Mono<Void> then() {
/*  9011 */     Mono<Void> then = new MonoIgnoreElements<>((Flux)this);
/*  9012 */     return Mono.onAssembly(then);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <V> Mono<V> then(Mono<V> other) {
/*  9033 */     return Mono.onAssembly(new MonoIgnoreThen<>((Publisher<?>[])new Publisher[] { (Publisher)this }, other));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Mono<Void> thenEmpty(Publisher<Void> other) {
/*  9050 */     return then(Mono.fromDirect(other));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <V> Flux<V> thenMany(Publisher<V> other) {
/*  9070 */     if (this instanceof FluxConcatArray) {
/*       */       
/*  9072 */       FluxConcatArray<T> fluxConcatArray = (FluxConcatArray<T>)this;
/*  9073 */       return fluxConcatArray.concatAdditionalIgnoredLast(other);
/*       */     } 
/*       */ 
/*       */     
/*  9077 */     Flux<V> concat = concat((Publisher<? extends V>[])new Publisher[] { (Publisher)ignoreElements(), other });
/*  9078 */     return concat;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<Timed<T>> timed() {
/*  9107 */     return timed(Schedulers.parallel());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<Timed<T>> timed(Scheduler clock) {
/*  9136 */     return onAssembly(new FluxTimed<>(this, clock));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> timeout(Duration timeout) {
/*  9151 */     return timeout(timeout, (Publisher<? extends T>)null, Schedulers.parallel());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> timeout(Duration timeout, @Nullable Publisher<? extends T> fallback) {
/*  9169 */     return timeout(timeout, fallback, Schedulers.parallel());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> timeout(Duration timeout, Scheduler timer) {
/*  9186 */     return timeout(timeout, (Publisher<? extends T>)null, timer);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> timeout(Duration timeout, @Nullable Publisher<? extends T> fallback, Scheduler timer) {
/*  9208 */     Mono<Long> _timer = Mono.delay(timeout, timer).onErrorReturn(Long.valueOf(0L));
/*  9209 */     Function<T, Publisher<Long>> rest = o -> _timer;
/*       */     
/*  9211 */     if (fallback == null) {
/*  9212 */       return timeout((Publisher<Long>)_timer, rest, timeout.toMillis() + "ms");
/*       */     }
/*  9214 */     return timeout((Publisher<Long>)_timer, rest, fallback);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <U> Flux<T> timeout(Publisher<U> firstTimeout) {
/*  9234 */     return timeout(firstTimeout, t -> never());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <U, V> Flux<T> timeout(Publisher<U> firstTimeout, Function<? super T, ? extends Publisher<V>> nextTimeoutFactory) {
/*  9258 */     return timeout(firstTimeout, nextTimeoutFactory, "first signal from a Publisher");
/*       */   }
/*       */ 
/*       */ 
/*       */   
/*       */   private final <U, V> Flux<T> timeout(Publisher<U> firstTimeout, Function<? super T, ? extends Publisher<V>> nextTimeoutFactory, String timeoutDescription) {
/*  9264 */     return onAssembly(new FluxTimeout<>(this, firstTimeout, nextTimeoutFactory, timeoutDescription));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <U, V> Flux<T> timeout(Publisher<U> firstTimeout, Function<? super T, ? extends Publisher<V>> nextTimeoutFactory, Publisher<? extends T> fallback) {
/*  9289 */     return onAssembly(new FluxTimeout<>(this, firstTimeout, nextTimeoutFactory, fallback));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<Tuple2<Long, T>> timestamp() {
/*  9306 */     return timestamp(Schedulers.parallel());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<Tuple2<Long, T>> timestamp(Scheduler scheduler) {
/*  9328 */     Objects.requireNonNull(scheduler, "scheduler");
/*  9329 */     return map(d -> Tuples.of(Long.valueOf(scheduler.now(TimeUnit.MILLISECONDS)), d));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Iterable<T> toIterable() {
/*  9346 */     return toIterable(Queues.SMALL_BUFFER_SIZE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Iterable<T> toIterable(int batchSize) {
/*  9364 */     return toIterable(batchSize, null);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Iterable<T> toIterable(int batchSize, @Nullable Supplier<Queue<T>> queueProvider) {
/*       */     Supplier<Queue<T>> provider;
/*  9388 */     if (queueProvider == null) {
/*  9389 */       provider = Queues.get(batchSize);
/*       */     } else {
/*       */       
/*  9392 */       provider = (() -> Hooks.wrapQueue(queueProvider.get()));
/*       */     } 
/*  9394 */     return new BlockingIterable<>(this, batchSize, provider);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Stream<T> toStream() {
/*  9411 */     return toStream(Queues.SMALL_BUFFER_SIZE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Stream<T> toStream(int batchSize) {
/*  9431 */     Supplier<Queue<T>> provider = Queues.get(batchSize);
/*  9432 */     return (new BlockingIterable<>(this, batchSize, provider)).stream();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <V> Flux<V> transform(Function<? super Flux<T>, ? extends Publisher<V>> transformer) {
/*  9456 */     if (Hooks.DETECT_CONTEXT_LOSS) {
/*  9457 */       transformer = (Function)new ContextTrackingFunctionWrapper<>((Function)transformer);
/*       */     }
/*  9459 */     return onAssembly(from(transformer.apply(this)));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <V> Flux<V> transformDeferred(Function<? super Flux<T>, ? extends Publisher<V>> transformer) {
/*  9481 */     return defer(() -> {
/*       */           if (Hooks.DETECT_CONTEXT_LOSS) {
/*       */             ContextTrackingFunctionWrapper<T, V> wrapper = new ContextTrackingFunctionWrapper<>(transformer);
/*       */             return (Publisher)wrapper.apply((Publisher<T>)this);
/*       */           } 
/*       */           return transformer.apply(this);
/*       */         });
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <V> Flux<V> transformDeferredContextual(BiFunction<? super Flux<T>, ? super ContextView, ? extends Publisher<V>> transformer) {
/*  9515 */     return deferContextual(ctxView -> {
/*       */           if (Hooks.DETECT_CONTEXT_LOSS) {
/*       */             ContextTrackingFunctionWrapper<T, V> wrapper = new ContextTrackingFunctionWrapper<>((), transformer.toString());
/*       */             return (Publisher)wrapper.apply((Publisher<T>)this);
/*       */           } 
/*       */           return transformer.apply(this, ctxView);
/*       */         });
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<Flux<T>> window(int maxSize) {
/*  9551 */     return onAssembly(new FluxWindow<>(this, maxSize, Queues.get(maxSize)));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<Flux<T>> window(int maxSize, int skip) {
/*  9588 */     return onAssembly(new FluxWindow<>(this, maxSize, skip, 
/*       */ 
/*       */           
/*  9591 */           Queues.unbounded(Queues.XS_BUFFER_SIZE), 
/*  9592 */           Queues.unbounded(Queues.XS_BUFFER_SIZE)));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<Flux<T>> window(Publisher<?> boundary) {
/*  9617 */     return onAssembly(new FluxWindowBoundary<>(this, boundary, 
/*  9618 */           Queues.unbounded(Queues.XS_BUFFER_SIZE)));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<Flux<T>> window(Duration windowingTimespan) {
/*  9644 */     return window(windowingTimespan, Schedulers.parallel());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<Flux<T>> window(Duration windowingTimespan, Duration openWindowEvery) {
/*  9686 */     return window(windowingTimespan, openWindowEvery, Schedulers.parallel());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<Flux<T>> window(Duration windowingTimespan, Scheduler timer) {
/*  9712 */     return window((Publisher<?>)interval(windowingTimespan, timer));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<Flux<T>> window(Duration windowingTimespan, Duration openWindowEvery, Scheduler timer) {
/*  9754 */     if (openWindowEvery.equals(windowingTimespan)) {
/*  9755 */       return window(windowingTimespan);
/*       */     }
/*  9757 */     return windowWhen((Publisher<Long>)interval(Duration.ZERO, openWindowEvery, timer), aLong -> Mono.delay(windowingTimespan, timer));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<Flux<T>> windowTimeout(int maxSize, Duration maxTime) {
/*  9786 */     return windowTimeout(maxSize, maxTime, Schedulers.parallel());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<Flux<T>> windowTimeout(int maxSize, Duration maxTime, boolean fairBackpressure) {
/*  9817 */     return windowTimeout(maxSize, maxTime, Schedulers.parallel(), fairBackpressure);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<Flux<T>> windowTimeout(int maxSize, Duration maxTime, Scheduler timer) {
/*  9847 */     return windowTimeout(maxSize, maxTime, timer, false);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<Flux<T>> windowTimeout(int maxSize, Duration maxTime, Scheduler timer, boolean fairBackpressure) {
/*  9879 */     return onAssembly(new FluxWindowTimeout<>(this, maxSize, maxTime.toNanos(), TimeUnit.NANOSECONDS, timer, fairBackpressure));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<Flux<T>> windowUntil(Predicate<T> boundaryTrigger) {
/*  9912 */     return windowUntil(boundaryTrigger, false);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<Flux<T>> windowUntil(Predicate<T> boundaryTrigger, boolean cutBefore) {
/*  9950 */     return windowUntil(boundaryTrigger, cutBefore, Queues.SMALL_BUFFER_SIZE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<Flux<T>> windowUntil(Predicate<T> boundaryTrigger, boolean cutBefore, int prefetch) {
/*  9990 */     return onAssembly(new FluxWindowPredicate<>(this, 
/*  9991 */           Queues.unbounded(prefetch), 
/*  9992 */           Queues.unbounded(prefetch), prefetch, boundaryTrigger, cutBefore ? FluxBufferPredicate.Mode.UNTIL_CUT_BEFORE : FluxBufferPredicate.Mode.UNTIL));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <V> Flux<Flux<T>> windowUntilChanged() {
/* 10020 */     return windowUntilChanged(identityFunction());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <V> Flux<Flux<T>> windowUntilChanged(Function<? super T, ? super V> keySelector) {
/* 10047 */     return windowUntilChanged((Function)keySelector, equalPredicate());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <V> Flux<Flux<T>> windowUntilChanged(Function<? super T, ? extends V> keySelector, BiPredicate<? super V, ? super V> keyComparator) {
/* 10077 */     return defer(() -> windowUntil(new FluxBufferPredicate.ChangedPredicate<>(keySelector, keyComparator), true));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<Flux<T>> windowWhile(Predicate<T> inclusionPredicate) {
/* 10111 */     return windowWhile(inclusionPredicate, Queues.SMALL_BUFFER_SIZE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<Flux<T>> windowWhile(Predicate<T> inclusionPredicate, int prefetch) {
/* 10145 */     return onAssembly(new FluxWindowPredicate<>(this, 
/* 10146 */           Queues.unbounded(prefetch), 
/* 10147 */           Queues.unbounded(prefetch), prefetch, inclusionPredicate, FluxBufferPredicate.Mode.WHILE));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <U, V> Flux<Flux<T>> windowWhen(Publisher<U> bucketOpening, Function<? super U, ? extends Publisher<V>> closeSelector) {
/* 10187 */     return onAssembly(new FluxWindowWhen<>(this, bucketOpening, closeSelector, 
/*       */ 
/*       */           
/* 10190 */           Queues.unbounded(Queues.XS_BUFFER_SIZE)));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <U, R> Flux<R> withLatestFrom(Publisher<? extends U> other, BiFunction<? super T, ? super U, ? extends R> resultSelector) {
/* 10216 */     return onAssembly(new FluxWithLatestFrom<>(this, other, resultSelector));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <T2> Flux<Tuple2<T, T2>> zipWith(Publisher<? extends T2> source2) {
/* 10235 */     return zipWith(source2, (BiFunction)tuple2Function());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <T2, V> Flux<V> zipWith(Publisher<? extends T2> source2, BiFunction<? super T, ? super T2, ? extends V> combinator) {
/* 10258 */     if (this instanceof FluxZip) {
/*       */       
/* 10260 */       FluxZip<T, V> o = (FluxZip)this;
/* 10261 */       Flux<V> result = o.zipAdditionalSource(source2, combinator);
/* 10262 */       if (result != null) {
/* 10263 */         return result;
/*       */       }
/*       */     } 
/* 10266 */     return zip((Publisher<? extends T>)this, source2, combinator);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <T2, V> Flux<V> zipWith(Publisher<? extends T2> source2, int prefetch, BiFunction<? super T, ? super T2, ? extends V> combinator) {
/* 10292 */     return zip(objects -> combinator.apply(objects[0], objects[1]), prefetch, (Publisher<?>[])new Publisher[] { (Publisher)this, source2 });
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <T2> Flux<Tuple2<T, T2>> zipWith(Publisher<? extends T2> source2, int prefetch) {
/* 10315 */     return zipWith(source2, prefetch, (BiFunction)tuple2Function());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <T2> Flux<Tuple2<T, T2>> zipWithIterable(Iterable<? extends T2> iterable) {
/* 10333 */     return zipWithIterable(iterable, (BiFunction)tuple2Function());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <T2, V> Flux<V> zipWithIterable(Iterable<? extends T2> iterable, BiFunction<? super T, ? super T2, ? extends V> zipper) {
/* 10355 */     return onAssembly(new FluxZipIterable<>(this, iterable, zipper));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   protected static <T> Flux<T> onAssembly(Flux<T> source) {
/* 10371 */     Function<Publisher, Publisher> hook = Hooks.onEachOperatorHook;
/* 10372 */     if (hook != null) {
/* 10373 */       source = (Flux<T>)hook.apply(source);
/*       */     }
/* 10375 */     if (Hooks.GLOBAL_TRACE) {
/* 10376 */       FluxOnAssembly.AssemblySnapshot stacktrace = new FluxOnAssembly.AssemblySnapshot(null, Traces.callSiteSupplierFactory.get());
/* 10377 */       source = (Flux<T>)Hooks.addAssemblyInfo(source, stacktrace);
/*       */     } 
/* 10379 */     return source;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   protected static <T> ConnectableFlux<T> onAssembly(ConnectableFlux<T> source) {
/* 10395 */     Function<Publisher, Publisher> hook = Hooks.onEachOperatorHook;
/* 10396 */     if (hook != null) {
/* 10397 */       source = (ConnectableFlux<T>)hook.apply(source);
/*       */     }
/* 10399 */     if (Hooks.GLOBAL_TRACE) {
/* 10400 */       FluxOnAssembly.AssemblySnapshot stacktrace = new FluxOnAssembly.AssemblySnapshot(null, Traces.callSiteSupplierFactory.get());
/* 10401 */       source = (ConnectableFlux<T>)Hooks.addAssemblyInfo(source, stacktrace);
/*       */     } 
/* 10403 */     return source;
/*       */   }
/*       */ 
/*       */   
/*       */   public String toString() {
/* 10408 */     return getClass().getSimpleName();
/*       */   }
/*       */ 
/*       */ 
/*       */   
/*       */   final <V> Flux<V> flatMap(Function<? super T, ? extends Publisher<? extends V>> mapper, boolean delayError, int concurrency, int prefetch) {
/* 10414 */     return onAssembly(new FluxFlatMap<>(this, mapper, delayError, concurrency, 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/* 10419 */           Queues.get(concurrency), prefetch, 
/*       */           
/* 10421 */           Queues.get(prefetch)));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   final <R> Flux<R> flatMapSequential(Function<? super T, ? extends Publisher<? extends R>> mapper, boolean delayError, int maxConcurrency, int prefetch) {
/* 10428 */     return onAssembly(new FluxMergeSequential<>(this, mapper, maxConcurrency, prefetch, delayError ? FluxConcatMap.ErrorMode.END : FluxConcatMap.ErrorMode.IMMEDIATE));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static <T> Flux<T> doOnSignal(Flux<T> source, @Nullable Consumer<? super Subscription> onSubscribe, @Nullable Consumer<? super T> onNext, @Nullable Consumer<? super Throwable> onError, @Nullable Runnable onComplete, @Nullable Runnable onAfterTerminate, @Nullable LongConsumer onRequest, @Nullable Runnable onCancel) {
/* 10442 */     if (source instanceof Fuseable) {
/* 10443 */       return onAssembly(new FluxPeekFuseable<>(source, onSubscribe, onNext, onError, onComplete, onAfterTerminate, onRequest, onCancel));
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/* 10452 */     return onAssembly(new FluxPeek<>(source, onSubscribe, onNext, onError, onComplete, onAfterTerminate, onRequest, onCancel));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static <T> Mono<T> wrapToMono(Callable<T> supplier) {
/* 10471 */     if (supplier instanceof Fuseable.ScalarCallable) {
/* 10472 */       T v; Fuseable.ScalarCallable<T> scalarCallable = (Fuseable.ScalarCallable<T>)supplier;
/*       */ 
/*       */       
/*       */       try {
/* 10476 */         v = (T)scalarCallable.call();
/*       */       }
/* 10478 */       catch (Exception e) {
/* 10479 */         return new MonoError<>(Exceptions.unwrap(e));
/*       */       } 
/* 10481 */       if (v == null) {
/* 10482 */         return MonoEmpty.instance();
/*       */       }
/* 10484 */       return new MonoJust<>(v);
/*       */     } 
/* 10486 */     return new MonoCallable<>(supplier);
/*       */   }
/*       */   
/*       */   @SafeVarargs
/*       */   static <I> Flux<I> merge(int prefetch, boolean delayError, Publisher<? extends I>... sources) {
/* 10491 */     if (sources.length == 0) {
/* 10492 */       return empty();
/*       */     }
/* 10494 */     if (sources.length == 1) {
/* 10495 */       return from(sources[0]);
/*       */     }
/* 10497 */     return onAssembly(new FluxMerge<>(sources, delayError, sources.length, 
/*       */ 
/*       */           
/* 10500 */           Queues.get(sources.length), prefetch, 
/*       */           
/* 10502 */           Queues.get(prefetch)));
/*       */   }
/*       */ 
/*       */   
/*       */   @SafeVarargs
/*       */   static <I> Flux<I> mergeSequential(int prefetch, boolean delayError, Publisher<? extends I>... sources) {
/* 10508 */     if (sources.length == 0) {
/* 10509 */       return empty();
/*       */     }
/* 10511 */     if (sources.length == 1) {
/* 10512 */       return from(sources[0]);
/*       */     }
/* 10514 */     return onAssembly(new FluxMergeSequential<>(new FluxArray((Object[])sources), 
/* 10515 */           (Function)identityFunction(), sources.length, prefetch, delayError ? FluxConcatMap.ErrorMode.END : FluxConcatMap.ErrorMode.IMMEDIATE));
/*       */   }
/*       */ 
/*       */ 
/*       */   
/*       */   static <T> Flux<T> mergeSequential(Publisher<? extends Publisher<? extends T>> sources, boolean delayError, int maxConcurrency, int prefetch) {
/* 10521 */     return onAssembly(new FluxMergeSequential<>(from(sources), 
/* 10522 */           (Function)identityFunction(), maxConcurrency, prefetch, delayError ? FluxConcatMap.ErrorMode.END : FluxConcatMap.ErrorMode.IMMEDIATE));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static <I> Flux<I> mergeSequential(Iterable<? extends Publisher<? extends I>> sources, boolean delayError, int maxConcurrency, int prefetch) {
/* 10529 */     return onAssembly(new FluxMergeSequential<>(new FluxIterable(sources), 
/* 10530 */           (Function)identityFunction(), maxConcurrency, prefetch, delayError ? FluxConcatMap.ErrorMode.END : FluxConcatMap.ErrorMode.IMMEDIATE));
/*       */   }
/*       */ 
/*       */ 
/*       */   
/*       */   static BooleanSupplier countingBooleanSupplier(final BooleanSupplier predicate, final long max) {
/* 10536 */     if (max <= 0L) {
/* 10537 */       return predicate;
/*       */     }
/* 10539 */     return new BooleanSupplier()
/*       */       {
/*       */         long n;
/*       */         
/*       */         public boolean getAsBoolean() {
/* 10544 */           return (this.n++ < max && predicate.getAsBoolean());
/*       */         }
/*       */       };
/*       */   }
/*       */   
/*       */   static <O> Predicate<O> countingPredicate(final Predicate<O> predicate, final long max) {
/* 10550 */     if (max == 0L) {
/* 10551 */       return predicate;
/*       */     }
/* 10553 */     return new Predicate<O>()
/*       */       {
/*       */         long n;
/*       */         
/*       */         public boolean test(O o) {
/* 10558 */           return (this.n++ < max && predicate.test(o));
/*       */         }
/*       */       };
/*       */   }
/*       */ 
/*       */   
/*       */   static <O> Supplier<Set<O>> hashSetSupplier() {
/* 10565 */     return SET_SUPPLIER;
/*       */   }
/*       */ 
/*       */   
/*       */   static <O> Supplier<List<O>> listSupplier() {
/* 10570 */     return LIST_SUPPLIER;
/*       */   }
/*       */ 
/*       */   
/*       */   static <U, V> BiPredicate<U, V> equalPredicate() {
/* 10575 */     return OBJECT_EQUAL;
/*       */   }
/*       */ 
/*       */   
/*       */   static <T> Function<T, T> identityFunction() {
/* 10580 */     return IDENTITY_FUNCTION;
/*       */   }
/*       */ 
/*       */   
/*       */   static <A, B> BiFunction<A, B, Tuple2<A, B>> tuple2Function() {
/* 10585 */     return TUPLE2_BIFUNCTION;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static <I> Flux<I> wrap(Publisher<? extends I> source) {
/* 10598 */     if (source instanceof Flux) {
/* 10599 */       return (Flux)source;
/*       */     }
/*       */ 
/*       */     
/* 10603 */     if (source instanceof Fuseable.ScalarCallable) {
/*       */       
/*       */       try {
/* 10606 */         I t = (I)((Fuseable.ScalarCallable)source).call();
/* 10607 */         if (t != null) {
/* 10608 */           return new FluxJust<>(t);
/*       */         }
/* 10610 */         return FluxEmpty.instance();
/*       */       }
/* 10612 */       catch (Exception e) {
/* 10613 */         return new FluxError<>(Exceptions.unwrap(e));
/*       */       } 
/*       */     }
/*       */     
/* 10617 */     if (source instanceof Mono) {
/* 10618 */       if (source instanceof Fuseable) {
/* 10619 */         return new FluxSourceMonoFuseable<>((Mono<? extends I>)source);
/*       */       }
/* 10621 */       return new FluxSourceMono<>((Mono<? extends I>)source);
/*       */     } 
/* 10623 */     if (source instanceof Fuseable) {
/* 10624 */       return new FluxSourceFuseable<>(source);
/*       */     }
/* 10626 */     return new FluxSource<>(source);
/*       */   }
/*       */ 
/*       */   
/* 10630 */   static final BiFunction TUPLE2_BIFUNCTION = Tuples::of;
/*       */   
/* 10632 */   static final Supplier LIST_SUPPLIER = ArrayList::new;
/*       */   
/* 10634 */   static final Supplier SET_SUPPLIER = java.util.HashSet::new;
/*       */   static final BooleanSupplier ALWAYS_BOOLEAN_SUPPLIER = () -> true;
/* 10636 */   static final BiPredicate OBJECT_EQUAL = Object::equals;
/*       */   
/* 10638 */   static final Function IDENTITY_FUNCTION = Function.identity();
/*       */   
/*       */   public abstract void subscribe(CoreSubscriber<? super T> paramCoreSubscriber);
/*       */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\Flux.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */