/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.Queue;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.IntFunction;
/*     */ import java.util.function.Supplier;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Scannable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxMerge<T>
/*     */   extends Flux<T>
/*     */   implements SourceProducer<T>
/*     */ {
/*     */   final Publisher<? extends T>[] sources;
/*     */   final boolean delayError;
/*     */   final int maxConcurrency;
/*     */   final Supplier<? extends Queue<T>> mainQueueSupplier;
/*     */   final int prefetch;
/*     */   final Supplier<? extends Queue<T>> innerQueueSupplier;
/*     */   
/*     */   FluxMerge(Publisher<? extends T>[] sources, boolean delayError, int maxConcurrency, Supplier<? extends Queue<T>> mainQueueSupplier, int prefetch, Supplier<? extends Queue<T>> innerQueueSupplier) {
/*  50 */     if (prefetch <= 0) {
/*  51 */       throw new IllegalArgumentException("prefetch > 0 required but it was " + prefetch);
/*     */     }
/*  53 */     if (maxConcurrency <= 0) {
/*  54 */       throw new IllegalArgumentException("maxConcurrency > 0 required but it was " + maxConcurrency);
/*     */     }
/*  56 */     this.sources = Objects.<Publisher<? extends T>[]>requireNonNull(sources, "sources");
/*  57 */     this.delayError = delayError;
/*  58 */     this.maxConcurrency = maxConcurrency;
/*  59 */     this.prefetch = prefetch;
/*  60 */     this.mainQueueSupplier = Objects.<Supplier<? extends Queue<T>>>requireNonNull(mainQueueSupplier, "mainQueueSupplier");
/*  61 */     this.innerQueueSupplier = Objects.<Supplier<? extends Queue<T>>>requireNonNull(innerQueueSupplier, "innerQueueSupplier");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super T> actual) {
/*  67 */     FluxFlatMap.FlatMapMain<Publisher<? extends T>, T> merger = new FluxFlatMap.FlatMapMain<>(actual, (Function)identityFunction(), this.delayError, this.maxConcurrency, this.mainQueueSupplier, this.prefetch, this.innerQueueSupplier);
/*     */ 
/*     */     
/*  70 */     merger.onSubscribe(new FluxArray.ArraySubscription<>(merger, this.sources));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   FluxMerge<T> mergeAdditionalSource(Publisher<? extends T> source, IntFunction<Supplier<? extends Queue<T>>> newQueueSupplier) {
/*     */     Supplier<? extends Queue<T>> newMainQueue;
/*  84 */     int n = this.sources.length;
/*     */     
/*  86 */     Publisher[] arrayOfPublisher = new Publisher[n + 1];
/*  87 */     System.arraycopy(this.sources, 0, arrayOfPublisher, 0, n);
/*  88 */     arrayOfPublisher[n] = source;
/*     */ 
/*     */ 
/*     */     
/*  92 */     int mc = this.maxConcurrency;
/*  93 */     if (mc != Integer.MAX_VALUE) {
/*  94 */       mc++;
/*  95 */       newMainQueue = newQueueSupplier.apply(mc);
/*     */     } else {
/*  97 */       newMainQueue = this.mainQueueSupplier;
/*     */     } 
/*     */     
/* 100 */     return new FluxMerge((Publisher<? extends T>[])arrayOfPublisher, this.delayError, mc, newMainQueue, this.prefetch, this.innerQueueSupplier);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/* 105 */     if (key == Scannable.Attr.DELAY_ERROR) return Boolean.valueOf(this.delayError); 
/* 106 */     if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(this.prefetch); 
/* 107 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */     
/* 109 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\FluxMerge.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */