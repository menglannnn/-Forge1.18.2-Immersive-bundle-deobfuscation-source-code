/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.Supplier;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ParallelReduceSeed<T, R>
/*     */   extends ParallelFlux<R>
/*     */   implements Scannable, Fuseable
/*     */ {
/*     */   final ParallelFlux<? extends T> source;
/*     */   final Supplier<R> initialSupplier;
/*     */   final BiFunction<R, ? super T, R> reducer;
/*     */   
/*     */   ParallelReduceSeed(ParallelFlux<? extends T> source, Supplier<R> initialSupplier, BiFunction<R, ? super T, R> reducer) {
/*  48 */     this.source = source;
/*  49 */     this.initialSupplier = initialSupplier;
/*  50 */     this.reducer = reducer;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  56 */     if (key == Scannable.Attr.PARENT) return this.source; 
/*  57 */     if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(getPrefetch()); 
/*  58 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */     
/*  60 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPrefetch() {
/*  65 */     return Integer.MAX_VALUE;
/*     */   }
/*     */ 
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super R>[] subscribers) {
/*  70 */     if (!validate((Subscriber<?>[])subscribers)) {
/*     */       return;
/*     */     }
/*     */     
/*  74 */     int n = subscribers.length;
/*  75 */     CoreSubscriber[] arrayOfCoreSubscriber = new CoreSubscriber[n];
/*     */     
/*  77 */     for (int i = 0; i < n; i++) {
/*     */       R initialValue;
/*     */ 
/*     */       
/*     */       try {
/*  82 */         initialValue = Objects.requireNonNull(this.initialSupplier.get(), "The initialSupplier returned a null value");
/*     */       
/*     */       }
/*  85 */       catch (Throwable ex) {
/*  86 */         reportError((Subscriber<?>[])subscribers, Operators.onOperatorError(ex, subscribers[i]
/*  87 */               .currentContext()));
/*     */         return;
/*     */       } 
/*  90 */       arrayOfCoreSubscriber[i] = new ParallelReduceSeedSubscriber<>(subscribers[i], initialValue, this.reducer);
/*     */     } 
/*     */ 
/*     */     
/*  94 */     this.source.subscribe((CoreSubscriber<? super T>[])arrayOfCoreSubscriber);
/*     */   }
/*     */   
/*     */   void reportError(Subscriber<?>[] subscribers, Throwable ex) {
/*  98 */     for (Subscriber<?> s : subscribers) {
/*  99 */       Operators.error(s, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public int parallelism() {
/* 105 */     return this.source.parallelism();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static final class ParallelReduceSeedSubscriber<T, R>
/*     */     extends Operators.MonoSubscriber<T, R>
/*     */   {
/*     */     final BiFunction<R, ? super T, R> reducer;
/*     */     
/*     */     R accumulator;
/*     */     
/*     */     Subscription s;
/*     */     
/*     */     boolean done;
/*     */ 
/*     */     
/*     */     ParallelReduceSeedSubscriber(CoreSubscriber<? super R> subscriber, R initialValue, BiFunction<R, ? super T, R> reducer) {
/* 123 */       super(subscriber);
/* 124 */       this.accumulator = initialValue;
/* 125 */       this.reducer = reducer;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 130 */       if (Operators.validate(this.s, s)) {
/* 131 */         this.s = s;
/*     */         
/* 133 */         this.actual.onSubscribe(this);
/*     */         
/* 135 */         s.request(Long.MAX_VALUE);
/*     */       } 
/*     */     }
/*     */     
/*     */     public void onNext(T t) {
/*     */       R v;
/* 141 */       if (this.done) {
/* 142 */         Operators.onNextDropped(t, this.actual.currentContext());
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/*     */       try {
/* 149 */         v = Objects.requireNonNull(this.reducer.apply(this.accumulator, t), "The reducer returned a null value");
/*     */       }
/* 151 */       catch (Throwable ex) {
/* 152 */         onError(Operators.onOperatorError(this, ex, t, this.actual.currentContext()));
/*     */         
/*     */         return;
/*     */       } 
/* 156 */       this.accumulator = v;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 161 */       if (this.done) {
/* 162 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*     */         return;
/*     */       } 
/* 165 */       this.done = true;
/* 166 */       this.accumulator = null;
/* 167 */       this.actual.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 172 */       if (this.done) {
/*     */         return;
/*     */       }
/* 175 */       this.done = true;
/*     */       
/* 177 */       R a = this.accumulator;
/* 178 */       this.accumulator = null;
/* 179 */       complete(a);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 184 */       super.cancel();
/* 185 */       this.s.cancel();
/*     */     }
/*     */ 
/*     */     
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 190 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 191 */       return super.scanUnsafe(key);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\ParallelReduceSeed.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */