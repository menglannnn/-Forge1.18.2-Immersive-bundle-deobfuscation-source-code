/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Comparator;
/*     */ import java.util.Objects;
/*     */ import java.util.Queue;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.concurrent.Queues;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxMergeComparing<T>
/*     */   extends Flux<T>
/*     */   implements SourceProducer<T>
/*     */ {
/*     */   final int prefetch;
/*     */   final Comparator<? super T> valueComparator;
/*     */   final Publisher<? extends T>[] sources;
/*     */   final boolean delayError;
/*     */   
/*     */   @SafeVarargs
/*     */   FluxMergeComparing(int prefetch, Comparator<? super T> valueComparator, boolean delayError, Publisher<? extends T>... sources) {
/*  56 */     if (prefetch <= 0) {
/*  57 */       throw new IllegalArgumentException("prefetch > 0 required but it was " + prefetch);
/*     */     }
/*  59 */     this.sources = Objects.<Publisher<? extends T>[]>requireNonNull(sources, "sources must be non-null");
/*     */     
/*  61 */     for (int i = 0; i < sources.length; i++) {
/*  62 */       Publisher<? extends T> source = sources[i];
/*  63 */       if (source == null) {
/*  64 */         throw new NullPointerException("sources[" + i + "] is null");
/*     */       }
/*     */     } 
/*     */     
/*  68 */     this.prefetch = prefetch;
/*  69 */     this.valueComparator = valueComparator;
/*  70 */     this.delayError = delayError;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   FluxMergeComparing<T> mergeAdditionalSource(Publisher<? extends T> source, Comparator<? super T> otherComparator) {
/*  84 */     int n = this.sources.length;
/*     */     
/*  86 */     Publisher[] arrayOfPublisher = new Publisher[n + 1];
/*  87 */     System.arraycopy(this.sources, 0, arrayOfPublisher, 0, n);
/*  88 */     arrayOfPublisher[n] = source;
/*     */     
/*  90 */     if (!this.valueComparator.equals(otherComparator)) {
/*     */       
/*  92 */       Comparator<? super T> comparator = this.valueComparator;
/*  93 */       Comparator<T> newComparator = (Comparator)comparator.thenComparing(otherComparator);
/*  94 */       return new FluxMergeComparing(this.prefetch, newComparator, this.delayError, (Publisher<? extends T>[])arrayOfPublisher);
/*     */     } 
/*  96 */     return new FluxMergeComparing(this.prefetch, this.valueComparator, this.delayError, (Publisher<? extends T>[])arrayOfPublisher);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPrefetch() {
/* 101 */     return this.prefetch;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/* 107 */     if (key == Scannable.Attr.PARENT) return (this.sources.length > 0) ? this.sources[0] : null; 
/* 108 */     if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(this.prefetch); 
/* 109 */     if (key == Scannable.Attr.DELAY_ERROR) return Boolean.valueOf(this.delayError); 
/* 110 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */     
/* 112 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super T> actual) {
/* 117 */     MergeOrderedMainProducer<T> main = new MergeOrderedMainProducer<>(actual, this.valueComparator, this.prefetch, this.sources.length, this.delayError);
/* 118 */     actual.onSubscribe(main);
/* 119 */     main.subscribe(this.sources);
/*     */   }
/*     */   
/*     */   static final class MergeOrderedMainProducer<T>
/*     */     implements InnerProducer<T>
/*     */   {
/* 125 */     static final Object DONE = new Object();
/*     */     
/*     */     final CoreSubscriber<? super T> actual;
/*     */     
/*     */     final FluxMergeComparing.MergeOrderedInnerSubscriber<T>[] subscribers;
/*     */     
/*     */     final Comparator<? super T> comparator;
/*     */     
/*     */     final Object[] values;
/*     */     final boolean delayError;
/*     */     boolean done;
/*     */     volatile Throwable error;
/* 137 */     static final AtomicReferenceFieldUpdater<MergeOrderedMainProducer, Throwable> ERROR = AtomicReferenceFieldUpdater.newUpdater(MergeOrderedMainProducer.class, Throwable.class, "error");
/*     */     
/*     */     volatile int cancelled;
/*     */     
/* 141 */     static final AtomicIntegerFieldUpdater<MergeOrderedMainProducer> CANCELLED = AtomicIntegerFieldUpdater.newUpdater(MergeOrderedMainProducer.class, "cancelled");
/*     */     
/*     */     volatile long requested;
/*     */     
/* 145 */     static final AtomicLongFieldUpdater<MergeOrderedMainProducer> REQUESTED = AtomicLongFieldUpdater.newUpdater(MergeOrderedMainProducer.class, "requested");
/*     */     
/*     */     volatile long emitted;
/*     */     
/* 149 */     static final AtomicLongFieldUpdater<MergeOrderedMainProducer> EMITTED = AtomicLongFieldUpdater.newUpdater(MergeOrderedMainProducer.class, "emitted");
/*     */ 
/*     */     
/*     */     volatile int wip;
/*     */     
/* 154 */     static final AtomicIntegerFieldUpdater<MergeOrderedMainProducer> WIP = AtomicIntegerFieldUpdater.newUpdater(MergeOrderedMainProducer.class, "wip");
/*     */ 
/*     */     
/*     */     MergeOrderedMainProducer(CoreSubscriber<? super T> actual, Comparator<? super T> comparator, int prefetch, int n, boolean delayError) {
/* 158 */       this.actual = actual;
/* 159 */       this.comparator = comparator;
/* 160 */       this.delayError = delayError;
/*     */ 
/*     */       
/* 163 */       FluxMergeComparing.MergeOrderedInnerSubscriber[] arrayOfMergeOrderedInnerSubscriber = new FluxMergeComparing.MergeOrderedInnerSubscriber[n];
/*     */       
/* 165 */       this.subscribers = (FluxMergeComparing.MergeOrderedInnerSubscriber<T>[])arrayOfMergeOrderedInnerSubscriber;
/*     */       
/* 167 */       for (int i = 0; i < n; i++) {
/* 168 */         this.subscribers[i] = new FluxMergeComparing.MergeOrderedInnerSubscriber<>(this, prefetch);
/*     */       }
/* 170 */       this.values = new Object[n];
/*     */     }
/*     */     
/*     */     void subscribe(Publisher<? extends T>[] sources) {
/* 174 */       if (sources.length != this.subscribers.length) {
/* 175 */         throw new IllegalArgumentException("must subscribe with " + this.subscribers.length + " sources");
/*     */       }
/* 177 */       for (int i = 0; i < sources.length; i++) {
/* 178 */         Objects.requireNonNull(sources[i], "subscribed with a null source: sources[" + i + "]");
/* 179 */         sources[i].subscribe((Subscriber)this.subscribers[i]);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 185 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 190 */       Operators.addCap(REQUESTED, this, n);
/* 191 */       drain();
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 196 */       if (CANCELLED.compareAndSet(this, 0, 1)) {
/* 197 */         for (FluxMergeComparing.MergeOrderedInnerSubscriber<T> subscriber : this.subscribers) {
/* 198 */           subscriber.cancel();
/*     */         }
/*     */         
/* 201 */         if (WIP.getAndIncrement(this) == 0) {
/* 202 */           discardData();
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*     */     void onInnerError(FluxMergeComparing.MergeOrderedInnerSubscriber<T> inner, Throwable ex) {
/* 208 */       Throwable e = Operators.onNextInnerError(ex, actual().currentContext(), this);
/* 209 */       if (e != null) {
/* 210 */         if (Exceptions.addThrowable(ERROR, this, e)) {
/* 211 */           if (!this.delayError) {
/* 212 */             this.done = true;
/*     */           }
/* 214 */           inner.done = true;
/* 215 */           drain();
/*     */         } else {
/*     */           
/* 218 */           inner.done = true;
/* 219 */           Operators.onErrorDropped(e, this.actual.currentContext());
/*     */         } 
/*     */       } else {
/*     */         
/* 223 */         inner.done = true;
/* 224 */         drain();
/*     */       } 
/*     */     }
/*     */     
/*     */     void drain() {
/* 229 */       if (WIP.getAndIncrement(this) != 0) {
/*     */         return;
/*     */       }
/*     */       
/* 233 */       int missed = 1;
/* 234 */       CoreSubscriber<? super T> actual = this.actual;
/* 235 */       Comparator<? super T> comparator = this.comparator;
/*     */       
/* 237 */       FluxMergeComparing.MergeOrderedInnerSubscriber<T>[] subscribers = this.subscribers;
/* 238 */       int n = subscribers.length;
/*     */       
/* 240 */       Object[] values = this.values;
/*     */       
/* 242 */       long e = this.emitted;
/*     */       
/*     */       do {
/* 245 */         long r = this.requested;
/*     */         
/*     */         while (true) {
/* 248 */           boolean d = this.done;
/* 249 */           if (this.cancelled != 0) {
/* 250 */             Arrays.fill(values, (Object)null);
/*     */             
/* 252 */             for (FluxMergeComparing.MergeOrderedInnerSubscriber<T> inner : subscribers) {
/* 253 */               inner.queue.clear();
/*     */             }
/*     */             
/*     */             return;
/*     */           } 
/* 258 */           int innerDoneCount = 0;
/* 259 */           int nonEmpty = 0;
/* 260 */           for (int i = 0; i < n; i++) {
/* 261 */             Object o = values[i];
/* 262 */             if (o == DONE) {
/* 263 */               innerDoneCount++;
/* 264 */               nonEmpty++;
/*     */             }
/* 266 */             else if (o == null) {
/* 267 */               boolean innerDone = (subscribers[i]).done;
/* 268 */               o = (subscribers[i]).queue.poll();
/* 269 */               if (o != null) {
/* 270 */                 values[i] = o;
/* 271 */                 nonEmpty++;
/*     */               }
/* 273 */               else if (innerDone) {
/* 274 */                 values[i] = DONE;
/* 275 */                 innerDoneCount++;
/* 276 */                 nonEmpty++;
/*     */               } 
/*     */             } else {
/*     */               
/* 280 */               nonEmpty++;
/*     */             } 
/*     */           } 
/*     */           
/* 284 */           if (checkTerminated((d || innerDoneCount == n), (Subscriber<?>)actual)) {
/*     */             return;
/*     */           }
/*     */           
/* 288 */           if (nonEmpty != n || e >= r) {
/*     */             break;
/*     */           }
/*     */           
/* 292 */           T min = null;
/* 293 */           int minIndex = -1;
/*     */           
/* 295 */           int j = 0;
/* 296 */           for (Object o : values) {
/* 297 */             if (o != DONE) {
/*     */               boolean smaller;
/*     */               
/*     */               try {
/* 301 */                 T t = (T)o;
/* 302 */                 smaller = (min == null || comparator.compare(min, t) > 0);
/* 303 */               } catch (Throwable ex) {
/* 304 */                 Exceptions.addThrowable(ERROR, this, ex);
/* 305 */                 cancel();
/* 306 */                 actual.onError(Exceptions.terminate(ERROR, this));
/*     */                 return;
/*     */               } 
/* 309 */               if (smaller) {
/*     */                 
/* 311 */                 T t = (T)o;
/* 312 */                 min = t;
/* 313 */                 minIndex = j;
/*     */               } 
/*     */             } 
/* 316 */             j++;
/*     */           } 
/*     */           
/* 319 */           values[minIndex] = null;
/*     */           
/* 321 */           actual.onNext(min);
/*     */           
/* 323 */           e++;
/* 324 */           subscribers[minIndex].request(1L);
/*     */         } 
/*     */         
/* 327 */         this.emitted = e;
/* 328 */         missed = WIP.addAndGet(this, -missed);
/* 329 */       } while (missed != 0);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     boolean checkTerminated(boolean d, Subscriber<?> a) {
/* 336 */       if (this.cancelled != 0) {
/* 337 */         discardData();
/* 338 */         return true;
/*     */       } 
/*     */       
/* 341 */       if (!d) {
/* 342 */         return false;
/*     */       }
/*     */       
/* 345 */       if (this.delayError) {
/* 346 */         Throwable e = this.error;
/* 347 */         if (e != null && e != Exceptions.TERMINATED) {
/* 348 */           e = Exceptions.terminate(ERROR, this);
/* 349 */           a.onError(e);
/*     */         } else {
/*     */           
/* 352 */           a.onComplete();
/*     */         } 
/*     */       } else {
/*     */         
/* 356 */         Throwable e = this.error;
/* 357 */         if (e != null && e != Exceptions.TERMINATED) {
/* 358 */           e = Exceptions.terminate(ERROR, this);
/* 359 */           cancel();
/* 360 */           discardData();
/* 361 */           a.onError(e);
/*     */         } else {
/*     */           
/* 364 */           a.onComplete();
/*     */         } 
/*     */       } 
/* 367 */       return true;
/*     */     }
/*     */     
/*     */     private void discardData() {
/* 371 */       Context ctx = actual().currentContext();
/* 372 */       for (Object v : this.values) {
/* 373 */         if (v != DONE) {
/* 374 */           Operators.onDiscard(v, ctx);
/*     */         }
/*     */       } 
/* 377 */       Arrays.fill(this.values, (Object)null);
/* 378 */       for (FluxMergeComparing.MergeOrderedInnerSubscriber<T> subscriber : this.subscribers) {
/* 379 */         Operators.onDiscardQueueWithClear(subscriber.queue, ctx, null);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 385 */       if (key == Scannable.Attr.ACTUAL) return this.actual; 
/* 386 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf((this.cancelled > 0)); 
/* 387 */       if (key == Scannable.Attr.ERROR) return this.error; 
/* 388 */       if (key == Scannable.Attr.DELAY_ERROR) return Boolean.valueOf(this.delayError); 
/* 389 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf(this.requested - this.emitted); 
/* 390 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 392 */       return null;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class MergeOrderedInnerSubscriber<T>
/*     */     implements InnerOperator<T, T>
/*     */   {
/*     */     final FluxMergeComparing.MergeOrderedMainProducer<T> parent;
/*     */     
/*     */     final int prefetch;
/*     */     
/*     */     final int limit;
/*     */     
/*     */     final Queue<T> queue;
/*     */     int consumed;
/*     */     volatile boolean done;
/*     */     volatile Subscription s;
/* 410 */     static final AtomicReferenceFieldUpdater<MergeOrderedInnerSubscriber, Subscription> S = AtomicReferenceFieldUpdater.newUpdater(MergeOrderedInnerSubscriber.class, Subscription.class, "s");
/*     */     
/*     */     MergeOrderedInnerSubscriber(FluxMergeComparing.MergeOrderedMainProducer<T> parent, int prefetch) {
/* 413 */       this.parent = parent;
/* 414 */       this.prefetch = prefetch;
/* 415 */       this.limit = prefetch - (prefetch >> 2);
/* 416 */       this.queue = Queues.get(prefetch).get();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 421 */       if (Operators.setOnce(S, this, s)) {
/* 422 */         s.request(this.prefetch);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T item) {
/* 428 */       if (this.parent.done || this.done) {
/* 429 */         Operators.onNextDropped(item, actual().currentContext());
/*     */         return;
/*     */       } 
/* 432 */       this.queue.offer(item);
/* 433 */       this.parent.drain();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable throwable) {
/* 438 */       this.parent.onInnerError(this, throwable);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 443 */       this.done = true;
/* 444 */       this.parent.drain();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 452 */       int c = this.consumed + 1;
/* 453 */       if (c == this.limit) {
/* 454 */         this.consumed = 0;
/* 455 */         Subscription sub = this.s;
/* 456 */         if (sub != this) {
/* 457 */           sub.request(c);
/*     */         }
/*     */       } else {
/*     */         
/* 461 */         this.consumed = c;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 467 */       Subscription sub = S.getAndSet(this, this);
/* 468 */       if (sub != null && sub != this) {
/* 469 */         sub.cancel();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 475 */       return this.parent.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 481 */       if (key == Scannable.Attr.ACTUAL) return this.parent; 
/* 482 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 483 */       if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(this.prefetch); 
/* 484 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 485 */       if (key == Scannable.Attr.BUFFERED) return Integer.valueOf(this.queue.size()); 
/* 486 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 488 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\FluxMergeComparing.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */