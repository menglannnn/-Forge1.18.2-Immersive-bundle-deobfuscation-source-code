/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Objects;
/*     */ import java.util.function.BiConsumer;
/*     */ import java.util.function.Function;
/*     */ import java.util.stream.Collector;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MonoStreamCollector<T, A, R>
/*     */   extends MonoFromFluxOperator<T, R>
/*     */   implements Fuseable
/*     */ {
/*     */   final Collector<? super T, A, ? extends R> collector;
/*     */   
/*     */   MonoStreamCollector(Flux<? extends T> source, Collector<? super T, A, ? extends R> collector) {
/*  48 */     super(source);
/*  49 */     this.collector = Objects.<Collector<? super T, A, ? extends R>>requireNonNull(collector, "collector");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super R> actual) {
/*  55 */     A container = this.collector.supplier().get();
/*     */     
/*  57 */     BiConsumer<? super A, ? super T> accumulator = this.collector.accumulator();
/*     */     
/*  59 */     Function<? super A, ? extends R> finisher = this.collector.finisher();
/*     */     
/*  61 */     return new StreamCollectorSubscriber<>(actual, container, accumulator, finisher);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  66 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  67 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static final class StreamCollectorSubscriber<T, A, R>
/*     */     extends Operators.MonoSubscriber<T, R>
/*     */   {
/*     */     final BiConsumer<? super A, ? super T> accumulator;
/*     */     
/*     */     final Function<? super A, ? extends R> finisher;
/*     */     
/*     */     A container;
/*     */     
/*     */     Subscription s;
/*     */     
/*     */     boolean done;
/*     */ 
/*     */     
/*     */     StreamCollectorSubscriber(CoreSubscriber<? super R> actual, A container, BiConsumer<? super A, ? super T> accumulator, Function<? super A, ? extends R> finisher) {
/*  87 */       super(actual);
/*  88 */       this.container = container;
/*  89 */       this.accumulator = accumulator;
/*  90 */       this.finisher = finisher;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/*  96 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/*  97 */       if (key == Scannable.Attr.PARENT) return this.s; 
/*  98 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 100 */       return super.scanUnsafe(key);
/*     */     }
/*     */     
/*     */     protected void discardIntermediateContainer(A a) {
/* 104 */       Context ctx = this.actual.currentContext();
/* 105 */       if (a instanceof Collection) {
/* 106 */         Operators.onDiscardMultiple((Collection)a, ctx);
/*     */       } else {
/*     */         
/* 109 */         Operators.onDiscard(a, ctx);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 116 */       if (Operators.validate(this.s, s)) {
/* 117 */         this.s = s;
/*     */         
/* 119 */         this.actual.onSubscribe(this);
/*     */         
/* 121 */         s.request(Long.MAX_VALUE);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 127 */       if (this.done) {
/* 128 */         Operators.onNextDropped(t, this.actual.currentContext());
/*     */         return;
/*     */       } 
/*     */       try {
/* 132 */         this.accumulator.accept(this.container, t);
/*     */       }
/* 134 */       catch (Throwable ex) {
/* 135 */         Context ctx = this.actual.currentContext();
/* 136 */         Operators.onDiscard(t, ctx);
/* 137 */         onError(Operators.onOperatorError(this.s, ex, t, ctx));
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 143 */       if (this.done) {
/* 144 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*     */         return;
/*     */       } 
/* 147 */       this.done = true;
/* 148 */       discardIntermediateContainer(this.container);
/* 149 */       this.container = null;
/* 150 */       this.actual.onError(t);
/*     */     }
/*     */     
/*     */     public void onComplete() {
/*     */       R r;
/* 155 */       if (this.done) {
/*     */         return;
/*     */       }
/* 158 */       this.done = true;
/*     */       
/* 160 */       A a = this.container;
/* 161 */       this.container = null;
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 166 */         r = this.finisher.apply(a);
/*     */       }
/* 168 */       catch (Throwable ex) {
/* 169 */         discardIntermediateContainer(a);
/* 170 */         this.actual.onError(Operators.onOperatorError(ex, this.actual.currentContext()));
/*     */         
/*     */         return;
/*     */       } 
/* 174 */       if (r == null) {
/* 175 */         this.actual.onError(Operators.onOperatorError(new NullPointerException("Collector returned null"), this.actual.currentContext()));
/*     */         return;
/*     */       } 
/* 178 */       complete(r);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 183 */       super.cancel();
/* 184 */       this.s.cancel();
/* 185 */       discardIntermediateContainer(this.container);
/* 186 */       this.container = null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\MonoStreamCollector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */