/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Objects;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MonoSingle<T>
/*     */   extends MonoFromFluxOperator<T, T>
/*     */ {
/*     */   final T defaultValue;
/*     */   final boolean completeOnEmpty;
/*     */   
/*     */   MonoSingle(Flux<? extends T> source) {
/*  41 */     super(source);
/*  42 */     this.defaultValue = null;
/*  43 */     this.completeOnEmpty = false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   MonoSingle(Flux<? extends T> source, @Nullable T defaultValue, boolean completeOnEmpty) {
/*  49 */     super(source);
/*  50 */     this
/*  51 */       .defaultValue = completeOnEmpty ? defaultValue : Objects.<T>requireNonNull(defaultValue, "defaultValue");
/*  52 */     this.completeOnEmpty = completeOnEmpty;
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/*  57 */     return new SingleSubscriber<>(actual, this.defaultValue, this.completeOnEmpty);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  62 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  63 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class SingleSubscriber<T>
/*     */     extends Operators.MonoInnerProducerBase<T>
/*     */     implements InnerConsumer<T>
/*     */   {
/*     */     @Nullable
/*     */     final T defaultValue;
/*     */     
/*     */     final boolean completeOnEmpty;
/*     */     Subscription s;
/*     */     int count;
/*     */     boolean done;
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/*  81 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/*  82 */       if (key == Scannable.Attr.PARENT) return this.s; 
/*  83 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/*  85 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/*  90 */       return actual().currentContext();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     SingleSubscriber(CoreSubscriber<? super T> actual, @Nullable T defaultValue, boolean completeOnEmpty) {
/*  96 */       super(actual);
/*  97 */       this.defaultValue = defaultValue;
/*  98 */       this.completeOnEmpty = completeOnEmpty;
/*     */     }
/*     */ 
/*     */     
/*     */     public void doOnRequest(long n) {
/* 103 */       this.s.request(Long.MAX_VALUE);
/*     */     }
/*     */ 
/*     */     
/*     */     public void doOnCancel() {
/* 108 */       this.s.cancel();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 113 */       if (Operators.validate(this.s, s)) {
/* 114 */         this.s = s;
/* 115 */         actual().onSubscribe(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 121 */       if (isCancelled()) {
/*     */         
/* 123 */         discard(t);
/*     */         return;
/*     */       } 
/* 126 */       if (this.done) {
/* 127 */         Operators.onNextDropped(t, actual().currentContext());
/*     */         return;
/*     */       } 
/* 130 */       if (++this.count > 1) {
/* 131 */         discard(t);
/*     */         
/* 133 */         cancel();
/* 134 */         onError(new IndexOutOfBoundsException("Source emitted more than one item"));
/*     */       } else {
/*     */         
/* 137 */         setValue(t);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 143 */       if (this.done) {
/* 144 */         Operators.onErrorDropped(t, actual().currentContext());
/*     */         return;
/*     */       } 
/* 147 */       this.done = true;
/* 148 */       discardTheValue();
/*     */       
/* 150 */       actual().onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 155 */       if (this.done) {
/*     */         return;
/*     */       }
/* 158 */       this.done = true;
/*     */       
/* 160 */       int c = this.count;
/* 161 */       if (c == 0) {
/*     */         
/* 163 */         if (this.completeOnEmpty) {
/* 164 */           actual().onComplete();
/*     */           
/*     */           return;
/*     */         } 
/* 168 */         T t = this.defaultValue;
/*     */         
/* 170 */         if (t != null) {
/* 171 */           complete(t);
/*     */         } else {
/*     */           
/* 174 */           actual().onError(Operators.onOperatorError(this, new NoSuchElementException("Source was empty"), 
/*     */                 
/* 176 */                 actual().currentContext()));
/*     */         }
/*     */       
/* 179 */       } else if (c == 1) {
/* 180 */         complete();
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\MonoSingle.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */