/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import java.util.stream.Stream;
/*    */ import reactor.core.Scannable;
/*    */ import reactor.util.context.Context;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SinkEmptySerialized<T>
/*    */   extends SinksSpecs.AbstractSerializedSink
/*    */   implements InternalEmptySink<T>, ContextHolder
/*    */ {
/*    */   final Sinks.Empty<T> sink;
/*    */   final ContextHolder contextHolder;
/*    */   
/*    */   SinkEmptySerialized(Sinks.Empty<T> sink, ContextHolder contextHolder) {
/* 34 */     this.sink = sink;
/* 35 */     this.contextHolder = contextHolder;
/*    */   }
/*    */ 
/*    */   
/*    */   public final Sinks.EmitResult tryEmitEmpty() {
/* 40 */     Thread currentThread = Thread.currentThread();
/* 41 */     if (!tryAcquire(currentThread)) {
/* 42 */       return Sinks.EmitResult.FAIL_NON_SERIALIZED;
/*    */     }
/*    */     
/*    */     try {
/* 46 */       return this.sink.tryEmitEmpty();
/*    */     } finally {
/*    */       
/* 49 */       if (WIP.decrementAndGet(this) == 0) {
/* 50 */         LOCKED_AT.compareAndSet(this, currentThread, null);
/*    */       }
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public final Sinks.EmitResult tryEmitError(Throwable t) {
/* 57 */     Objects.requireNonNull(t, "t is null in sink.error(t)");
/*    */     
/* 59 */     Thread currentThread = Thread.currentThread();
/* 60 */     if (!tryAcquire(currentThread)) {
/* 61 */       return Sinks.EmitResult.FAIL_NON_SERIALIZED;
/*    */     }
/*    */     
/*    */     try {
/* 65 */       return this.sink.tryEmitError(t);
/*    */     } finally {
/*    */       
/* 68 */       if (WIP.decrementAndGet(this) == 0) {
/* 69 */         LOCKED_AT.compareAndSet(this, currentThread, null);
/*    */       }
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public int currentSubscriberCount() {
/* 76 */     return this.sink.currentSubscriberCount();
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<T> asMono() {
/* 81 */     return this.sink.asMono();
/*    */   }
/*    */ 
/*    */   
/*    */   public Stream<? extends Scannable> inners() {
/* 86 */     return this.sink.inners();
/*    */   }
/*    */ 
/*    */   
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 91 */     return this.sink.scanUnsafe(key);
/*    */   }
/*    */ 
/*    */   
/*    */   public Context currentContext() {
/* 96 */     return this.contextHolder.currentContext();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\SinkEmptySerialized.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */