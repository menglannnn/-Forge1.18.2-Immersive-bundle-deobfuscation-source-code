/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.function.BiConsumer;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.LongConsumer;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ParallelDoOnEach<T>
/*     */   extends ParallelFlux<T>
/*     */   implements Scannable
/*     */ {
/*     */   final ParallelFlux<T> source;
/*     */   final BiConsumer<Context, ? super T> onNext;
/*     */   final BiConsumer<Context, ? super Throwable> onError;
/*     */   final Consumer<Context> onComplete;
/*     */   
/*     */   ParallelDoOnEach(ParallelFlux<T> source, @Nullable BiConsumer<Context, ? super T> onNext, @Nullable BiConsumer<Context, ? super Throwable> onError, @Nullable Consumer<Context> onComplete) {
/*  49 */     this.source = source;
/*     */     
/*  51 */     this.onNext = onNext;
/*  52 */     this.onError = onError;
/*  53 */     this.onComplete = onComplete;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super T>[] subscribers) {
/*  59 */     if (!validate((Subscriber<?>[])subscribers)) {
/*     */       return;
/*     */     }
/*     */     
/*  63 */     int n = subscribers.length;
/*     */     
/*  65 */     CoreSubscriber[] arrayOfCoreSubscriber = new CoreSubscriber[n];
/*     */     
/*  67 */     boolean conditional = subscribers[0] instanceof Fuseable.ConditionalSubscriber;
/*     */     
/*  69 */     for (int i = 0; i < n; i++) {
/*  70 */       CoreSubscriber<? super T> subscriber = subscribers[i];
/*  71 */       SignalPeek<T> signalPeek = new DoOnEachSignalPeek(subscriber.currentContext());
/*     */       
/*  73 */       if (conditional) {
/*  74 */         arrayOfCoreSubscriber[i] = new FluxPeekFuseable.PeekConditionalSubscriber<>((Fuseable.ConditionalSubscriber<? super T>)subscriber, signalPeek);
/*     */       }
/*     */       else {
/*     */         
/*  78 */         arrayOfCoreSubscriber[i] = new FluxPeek.PeekSubscriber<>(subscriber, signalPeek);
/*     */       } 
/*     */     } 
/*     */     
/*  82 */     this.source.subscribe((CoreSubscriber<? super T>[])arrayOfCoreSubscriber);
/*     */   }
/*     */ 
/*     */   
/*     */   public int parallelism() {
/*  87 */     return this.source.parallelism();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPrefetch() {
/*  92 */     return this.source.getPrefetch();
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  98 */     if (key == Scannable.Attr.PARENT) return this.source; 
/*  99 */     if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(getPrefetch()); 
/* 100 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */     
/* 102 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private class DoOnEachSignalPeek
/*     */     implements SignalPeek<T>
/*     */   {
/*     */     Consumer<? super T> onNextCall;
/*     */     Consumer<? super Throwable> onErrorCall;
/*     */     Runnable onCompleteCall;
/*     */     
/*     */     public DoOnEachSignalPeek(Context ctx) {
/* 114 */       this.onNextCall = (ParallelDoOnEach.this.onNext != null) ? (v -> ParallelDoOnEach.this.onNext.accept(ctx, v)) : null;
/* 115 */       this.onErrorCall = (ParallelDoOnEach.this.onError != null) ? (e -> ParallelDoOnEach.this.onError.accept(ctx, e)) : null;
/* 116 */       this.onCompleteCall = (ParallelDoOnEach.this.onComplete != null) ? (() -> ParallelDoOnEach.this.onComplete.accept(ctx)) : null;
/*     */     }
/*     */ 
/*     */     
/*     */     public Consumer<? super Subscription> onSubscribeCall() {
/* 121 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public Consumer<? super T> onNextCall() {
/* 126 */       return this.onNextCall;
/*     */     }
/*     */ 
/*     */     
/*     */     public Consumer<? super Throwable> onErrorCall() {
/* 131 */       return this.onErrorCall;
/*     */     }
/*     */ 
/*     */     
/*     */     public Runnable onCompleteCall() {
/* 136 */       return this.onCompleteCall;
/*     */     }
/*     */ 
/*     */     
/*     */     public Runnable onAfterTerminateCall() {
/* 141 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public LongConsumer onRequestCall() {
/* 146 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public Runnable onCancelCall() {
/* 151 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 156 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\ParallelDoOnEach.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */