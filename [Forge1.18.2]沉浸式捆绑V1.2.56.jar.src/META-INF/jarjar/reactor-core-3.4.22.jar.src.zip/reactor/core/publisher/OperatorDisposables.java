/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.function.Consumer;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.Disposables;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class OperatorDisposables
/*     */ {
/*  40 */   static final Disposable DISPOSED = Disposables.disposed();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> boolean set(AtomicReferenceFieldUpdater<T, Disposable> updater, T holder, @Nullable Disposable newValue) {
/*     */     while (true) {
/*  52 */       Disposable current = updater.get(holder);
/*  53 */       if (current == DISPOSED) {
/*  54 */         if (newValue != null) {
/*  55 */           newValue.dispose();
/*     */         }
/*  57 */         return false;
/*     */       } 
/*  59 */       if (updater.compareAndSet(holder, current, newValue)) {
/*  60 */         if (current != null) {
/*  61 */           current.dispose();
/*     */         }
/*  63 */         return true;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> boolean setOnce(AtomicReferenceFieldUpdater<T, Disposable> updater, T holder, Disposable newValue, Consumer<RuntimeException> errorCallback) {
/*  82 */     Objects.requireNonNull(newValue, "newValue is null");
/*  83 */     if (!updater.compareAndSet(holder, null, newValue)) {
/*  84 */       newValue.dispose();
/*  85 */       if (updater.get(holder) != DISPOSED) {
/*  86 */         errorCallback.accept(new IllegalStateException("Disposable already pushed"));
/*     */       }
/*  88 */       return false;
/*     */     } 
/*  90 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> boolean replace(AtomicReferenceFieldUpdater<T, Disposable> updater, T holder, @Nullable Disposable newValue) {
/*     */     while (true) {
/* 105 */       Disposable current = updater.get(holder);
/* 106 */       if (current == DISPOSED) {
/* 107 */         if (newValue != null) {
/* 108 */           newValue.dispose();
/*     */         }
/* 110 */         return false;
/*     */       } 
/* 112 */       if (updater.compareAndSet(holder, current, newValue)) {
/* 113 */         return true;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> boolean dispose(AtomicReferenceFieldUpdater<T, Disposable> updater, T holder) {
/* 126 */     Disposable current = updater.get(holder);
/* 127 */     Disposable d = DISPOSED;
/* 128 */     if (current != d) {
/* 129 */       current = updater.getAndSet(holder, d);
/* 130 */       if (current != d) {
/* 131 */         if (current != null) {
/* 132 */           current.dispose();
/*     */         }
/* 134 */         return true;
/*     */       } 
/*     */     } 
/* 137 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean validate(@Nullable Disposable current, Disposable next, Consumer<RuntimeException> errorCallback) {
/* 151 */     if (next == null) {
/* 152 */       errorCallback.accept(new NullPointerException("next is null"));
/* 153 */       return false;
/*     */     } 
/* 155 */     if (current != null) {
/* 156 */       next.dispose();
/* 157 */       errorCallback.accept(new IllegalStateException("Disposable already pushed"));
/* 158 */       return false;
/*     */     } 
/* 160 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> boolean trySet(AtomicReferenceFieldUpdater<T, Disposable> updater, T holder, Disposable newValue) {
/* 173 */     if (!updater.compareAndSet(holder, null, newValue)) {
/* 174 */       if (updater.get(holder) == DISPOSED) {
/* 175 */         newValue.dispose();
/*     */       }
/* 177 */       return false;
/*     */     } 
/* 179 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isDisposed(Disposable d) {
/* 189 */     return (d == DISPOSED);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\OperatorDisposables.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */