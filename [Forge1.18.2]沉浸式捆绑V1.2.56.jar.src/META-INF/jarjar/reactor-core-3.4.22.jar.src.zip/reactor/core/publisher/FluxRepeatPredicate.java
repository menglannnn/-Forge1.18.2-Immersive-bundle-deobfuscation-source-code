/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.function.BooleanSupplier;
/*     */ import reactor.core.CorePublisher;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Scannable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxRepeatPredicate<T>
/*     */   extends InternalFluxOperator<T, T>
/*     */ {
/*     */   final BooleanSupplier predicate;
/*     */   
/*     */   FluxRepeatPredicate(Flux<? extends T> source, BooleanSupplier predicate) {
/*  38 */     super(source);
/*  39 */     this.predicate = Objects.<BooleanSupplier>requireNonNull(predicate, "predicate");
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/*  44 */     RepeatPredicateSubscriber<T> parent = new RepeatPredicateSubscriber<>(this.source, actual, this.predicate);
/*     */ 
/*     */     
/*  47 */     actual.onSubscribe(parent);
/*     */     
/*  49 */     if (!parent.isCancelled()) {
/*  50 */       parent.resubscribe();
/*     */     }
/*  52 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  57 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  58 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class RepeatPredicateSubscriber<T>
/*     */     extends Operators.MultiSubscriptionSubscriber<T, T>
/*     */   {
/*     */     final CorePublisher<? extends T> source;
/*     */     
/*     */     final BooleanSupplier predicate;
/*     */     
/*     */     volatile int wip;
/*     */     
/*  71 */     static final AtomicIntegerFieldUpdater<RepeatPredicateSubscriber> WIP = AtomicIntegerFieldUpdater.newUpdater(RepeatPredicateSubscriber.class, "wip");
/*     */     
/*     */     long produced;
/*     */ 
/*     */     
/*     */     RepeatPredicateSubscriber(CorePublisher<? extends T> source, CoreSubscriber<? super T> actual, BooleanSupplier predicate) {
/*  77 */       super(actual);
/*  78 */       this.source = source;
/*  79 */       this.predicate = predicate;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/*  84 */       this.produced++;
/*     */       
/*  86 */       this.actual.onNext(t);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onComplete() {
/*     */       boolean b;
/*     */       try {
/*  94 */         b = this.predicate.getAsBoolean();
/*  95 */       } catch (Throwable e) {
/*  96 */         this.actual.onError(Operators.onOperatorError(e, this.actual.currentContext()));
/*     */         
/*     */         return;
/*     */       } 
/* 100 */       if (b) {
/* 101 */         resubscribe();
/*     */       } else {
/* 103 */         this.actual.onComplete();
/*     */       } 
/*     */     }
/*     */     
/*     */     void resubscribe() {
/* 108 */       if (WIP.getAndIncrement(this) == 0) {
/*     */         do {
/* 110 */           if (isCancelled()) {
/*     */             return;
/*     */           }
/*     */           
/* 114 */           long c = this.produced;
/* 115 */           if (c != 0L) {
/* 116 */             this.produced = 0L;
/* 117 */             produced(c);
/*     */           } 
/*     */           
/* 120 */           this.source.subscribe(this);
/*     */         }
/* 122 */         while (WIP.decrementAndGet(this) != 0);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 128 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 129 */       return super.scanUnsafe(key);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\FluxRepeatPredicate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */