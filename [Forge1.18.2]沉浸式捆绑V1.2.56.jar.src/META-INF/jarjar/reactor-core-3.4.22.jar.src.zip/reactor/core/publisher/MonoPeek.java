/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.LongConsumer;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MonoPeek<T>
/*     */   extends InternalMonoOperator<T, T>
/*     */   implements SignalPeek<T>
/*     */ {
/*     */   final Consumer<? super Subscription> onSubscribeCall;
/*     */   final Consumer<? super T> onNextCall;
/*     */   final LongConsumer onRequestCall;
/*     */   final Runnable onCancelCall;
/*     */   
/*     */   MonoPeek(Mono<? extends T> source, @Nullable Consumer<? super Subscription> onSubscribeCall, @Nullable Consumer<? super T> onNextCall, @Nullable LongConsumer onRequestCall, @Nullable Runnable onCancelCall) {
/*  49 */     super(source);
/*  50 */     this.onSubscribeCall = onSubscribeCall;
/*  51 */     this.onNextCall = onNextCall;
/*  52 */     this.onRequestCall = onRequestCall;
/*  53 */     this.onCancelCall = onCancelCall;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/*  59 */     if (actual instanceof Fuseable.ConditionalSubscriber) {
/*  60 */       return new FluxPeekFuseable.PeekConditionalSubscriber<>((Fuseable.ConditionalSubscriber<? super T>)actual, this);
/*     */     }
/*     */     
/*  63 */     return new FluxPeek.PeekSubscriber<>(actual, this);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Consumer<? super Subscription> onSubscribeCall() {
/*  69 */     return this.onSubscribeCall;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Consumer<? super T> onNextCall() {
/*  75 */     return this.onNextCall;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Consumer<? super Throwable> onErrorCall() {
/*  81 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Runnable onCompleteCall() {
/*  87 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Runnable onAfterTerminateCall() {
/*  93 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public LongConsumer onRequestCall() {
/*  99 */     return this.onRequestCall;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Runnable onCancelCall() {
/* 105 */     return this.onCancelCall;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/* 110 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 111 */     return super.scanUnsafe(key);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\MonoPeek.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */