/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.function.Tuple2;
/*     */ import reactor.util.function.Tuples;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxName<T>
/*     */   extends InternalFluxOperator<T, T>
/*     */ {
/*     */   final String name;
/*     */   final Set<Tuple2<String, String>> tags;
/*     */   
/*     */   static <T> Flux<T> createOrAppend(Flux<T> source, String name) {
/*  49 */     Objects.requireNonNull(name, "name");
/*     */     
/*  51 */     if (source instanceof FluxName) {
/*  52 */       FluxName<T> s = (FluxName<T>)source;
/*  53 */       return new FluxName<>(s.source, name, s.tags);
/*     */     } 
/*  55 */     if (source instanceof FluxNameFuseable) {
/*  56 */       FluxNameFuseable<T> s = (FluxNameFuseable<T>)source;
/*  57 */       return new FluxNameFuseable<>(s.source, name, s.tags);
/*     */     } 
/*  59 */     if (source instanceof reactor.core.Fuseable) {
/*  60 */       return new FluxNameFuseable<>(source, name, null);
/*     */     }
/*  62 */     return new FluxName<>(source, name, null);
/*     */   }
/*     */ 
/*     */   
/*     */   static <T> Flux<T> createOrAppend(Flux<T> source, String tagName, String tagValue) {
/*  67 */     Objects.requireNonNull(tagName, "tagName");
/*  68 */     Objects.requireNonNull(tagValue, "tagValue");
/*     */     
/*  70 */     Set<Tuple2<String, String>> tags = Collections.singleton(Tuples.of(tagName, tagValue));
/*     */     
/*  72 */     if (source instanceof FluxName) {
/*  73 */       FluxName<T> s = (FluxName<T>)source;
/*  74 */       if (s.tags != null) {
/*  75 */         tags = new HashSet<>(tags);
/*  76 */         tags.addAll(s.tags);
/*     */       } 
/*  78 */       return new FluxName<>(s.source, s.name, tags);
/*     */     } 
/*  80 */     if (source instanceof FluxNameFuseable) {
/*  81 */       FluxNameFuseable<T> s = (FluxNameFuseable<T>)source;
/*  82 */       if (s.tags != null) {
/*  83 */         tags = new HashSet<>(tags);
/*  84 */         tags.addAll(s.tags);
/*     */       } 
/*  86 */       return new FluxNameFuseable<>(s.source, s.name, tags);
/*     */     } 
/*  88 */     if (source instanceof reactor.core.Fuseable) {
/*  89 */       return new FluxNameFuseable<>(source, null, tags);
/*     */     }
/*  91 */     return new FluxName<>(source, null, tags);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   FluxName(Flux<? extends T> source, @Nullable String name, @Nullable Set<Tuple2<String, String>> tags) {
/*  97 */     super(source);
/*  98 */     this.name = name;
/*  99 */     this.tags = tags;
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/* 104 */     return actual;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/* 110 */     if (key == Scannable.Attr.NAME) {
/* 111 */       return this.name;
/*     */     }
/*     */     
/* 114 */     if (key == Scannable.Attr.TAGS && this.tags != null) {
/* 115 */       return this.tags.stream();
/*     */     }
/*     */     
/* 118 */     if (key == Scannable.Attr.RUN_STYLE) {
/* 119 */       return Scannable.Attr.RunStyle.SYNC;
/*     */     }
/*     */     
/* 122 */     return super.scanUnsafe(key);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\FluxName.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */