/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import org.reactivestreams.Subscriber;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Exceptions;
/*    */ import reactor.core.Fuseable;
/*    */ import reactor.core.Scannable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class FluxError<T>
/*    */   extends Flux<T>
/*    */   implements Fuseable.ScalarCallable, SourceProducer<T>
/*    */ {
/*    */   final Throwable error;
/*    */   
/*    */   FluxError(Throwable error) {
/* 38 */     this.error = Objects.<Throwable>requireNonNull(error);
/*    */   }
/*    */ 
/*    */   
/*    */   public void subscribe(CoreSubscriber<? super T> actual) {
/* 43 */     Operators.error((Subscriber<?>)actual, this.error);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object call() throws Exception {
/* 48 */     if (this.error instanceof Exception) {
/* 49 */       throw (Exception)this.error;
/*    */     }
/* 51 */     throw Exceptions.propagate(this.error);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 56 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 57 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\FluxError.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */