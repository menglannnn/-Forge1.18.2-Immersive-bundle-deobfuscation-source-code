/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.stream.Stream;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ParallelMergeSort<T>
/*     */   extends Flux<T>
/*     */   implements Scannable
/*     */ {
/*     */   final ParallelFlux<List<T>> source;
/*     */   final Comparator<? super T> comparator;
/*     */   
/*     */   ParallelMergeSort(ParallelFlux<List<T>> source, Comparator<? super T> comparator) {
/*  50 */     this.source = source;
/*  51 */     this.comparator = comparator;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPrefetch() {
/*  56 */     return Integer.MAX_VALUE;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super T> actual) {
/*  62 */     MergeSortMain<T> parent = new MergeSortMain<>(actual, this.source.parallelism(), this.comparator);
/*  63 */     actual.onSubscribe(parent);
/*     */     
/*  65 */     this.source.subscribe((CoreSubscriber[])parent.subscribers);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  71 */     if (key == Scannable.Attr.PARENT) return this.source; 
/*  72 */     if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(getPrefetch()); 
/*  73 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */     
/*  75 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   static final class MergeSortMain<T>
/*     */     implements InnerProducer<T>
/*     */   {
/*     */     final ParallelMergeSort.MergeSortInner<T>[] subscribers;
/*     */     
/*     */     final List<T>[] lists;
/*     */     
/*     */     final int[] indexes;
/*     */     
/*     */     final Comparator<? super T> comparator;
/*     */     
/*     */     final CoreSubscriber<? super T> actual;
/*     */     
/*     */     volatile int wip;
/*  93 */     static final AtomicIntegerFieldUpdater<MergeSortMain> WIP = AtomicIntegerFieldUpdater.newUpdater(MergeSortMain.class, "wip");
/*     */ 
/*     */     
/*     */     volatile long requested;
/*     */     
/*  98 */     static final AtomicLongFieldUpdater<MergeSortMain> REQUESTED = AtomicLongFieldUpdater.newUpdater(MergeSortMain.class, "requested");
/*     */ 
/*     */     
/*     */     volatile boolean cancelled;
/*     */ 
/*     */     
/*     */     volatile int remaining;
/*     */     
/* 106 */     static final AtomicIntegerFieldUpdater<MergeSortMain> REMAINING = AtomicIntegerFieldUpdater.newUpdater(MergeSortMain.class, "remaining");
/*     */ 
/*     */ 
/*     */     
/*     */     volatile Throwable error;
/*     */ 
/*     */     
/* 113 */     static final AtomicReferenceFieldUpdater<MergeSortMain, Throwable> ERROR = AtomicReferenceFieldUpdater.newUpdater(MergeSortMain.class, Throwable.class, "error");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     MergeSortMain(CoreSubscriber<? super T> actual, int n, Comparator<? super T> comparator) {
/* 121 */       this.comparator = comparator;
/* 122 */       this.actual = actual;
/* 123 */       ParallelMergeSort.MergeSortInner[] arrayOfMergeSortInner = new ParallelMergeSort.MergeSortInner[n];
/*     */       
/* 125 */       for (int i = 0; i < n; i++) {
/* 126 */         arrayOfMergeSortInner[i] = new ParallelMergeSort.MergeSortInner<>(this, i);
/*     */       }
/* 128 */       this.subscribers = (ParallelMergeSort.MergeSortInner<T>[])arrayOfMergeSortInner;
/* 129 */       this.lists = (List<T>[])new List[n];
/* 130 */       this.indexes = new int[n];
/* 131 */       REMAINING.lazySet(this, n);
/*     */     }
/*     */ 
/*     */     
/*     */     public final CoreSubscriber<? super T> actual() {
/* 136 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 142 */       if (key == Scannable.Attr.ERROR) return this.error; 
/* 143 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf(this.requested); 
/* 144 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(this.cancelled); 
/* 145 */       if (key == Scannable.Attr.BUFFERED) return Integer.valueOf(this.subscribers.length - this.remaining); 
/* 146 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 148 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public Stream<? extends Scannable> inners() {
/* 153 */       return Stream.of((Scannable[])this.subscribers);
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 158 */       if (Operators.validate(n)) {
/* 159 */         Operators.addCap(REQUESTED, this, n);
/* 160 */         if (this.remaining == 0) {
/* 161 */           drain();
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 168 */       if (!this.cancelled) {
/* 169 */         this.cancelled = true;
/* 170 */         cancelAll();
/* 171 */         if (WIP.getAndIncrement(this) == 0) {
/* 172 */           Arrays.fill((Object[])this.lists, (Object)null);
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*     */     void cancelAll() {
/* 178 */       for (ParallelMergeSort.MergeSortInner<T> s : this.subscribers) {
/* 179 */         s.cancel();
/*     */       }
/*     */     }
/*     */     
/*     */     void innerNext(List<T> value, int index) {
/* 184 */       this.lists[index] = value;
/* 185 */       if (REMAINING.decrementAndGet(this) == 0) {
/* 186 */         drain();
/*     */       }
/*     */     }
/*     */     
/*     */     void innerError(Throwable ex) {
/* 191 */       if (ERROR.compareAndSet(this, null, ex)) {
/* 192 */         cancelAll();
/* 193 */         drain();
/*     */       }
/* 195 */       else if (this.error != ex) {
/* 196 */         Operators.onErrorDropped(ex, this.actual.currentContext());
/*     */       } 
/*     */     }
/*     */     
/*     */     void drain() {
/* 201 */       if (WIP.getAndIncrement(this) != 0) {
/*     */         return;
/*     */       }
/*     */       
/* 205 */       int missed = 1;
/* 206 */       CoreSubscriber<? super T> coreSubscriber = this.actual;
/* 207 */       List<T>[] lists = this.lists;
/* 208 */       int[] indexes = this.indexes;
/* 209 */       int n = indexes.length;
/*     */ 
/*     */       
/*     */       while (true) {
/* 213 */         long r = this.requested;
/* 214 */         long e = 0L;
/*     */         
/* 216 */         while (e != r) {
/* 217 */           if (this.cancelled) {
/* 218 */             Arrays.fill((Object[])lists, (Object)null);
/*     */             
/*     */             return;
/*     */           } 
/* 222 */           Throwable ex = this.error;
/* 223 */           if (ex != null) {
/* 224 */             cancelAll();
/* 225 */             Arrays.fill((Object[])lists, (Object)null);
/* 226 */             coreSubscriber.onError(ex);
/*     */             
/*     */             return;
/*     */           } 
/* 230 */           T min = null;
/* 231 */           int minIndex = -1;
/*     */           
/* 233 */           for (int i = 0; i < n; i++) {
/* 234 */             List<T> list = lists[i];
/* 235 */             int index = indexes[i];
/*     */             
/* 237 */             if (list.size() != index) {
/* 238 */               if (min == null) {
/* 239 */                 min = list.get(index);
/* 240 */                 minIndex = i;
/*     */               } else {
/*     */                 
/* 243 */                 T b = list.get(index);
/* 244 */                 if (this.comparator.compare(min, b) > 0) {
/* 245 */                   min = b;
/* 246 */                   minIndex = i;
/*     */                 } 
/*     */               } 
/*     */             }
/*     */           } 
/*     */           
/* 252 */           if (min == null) {
/* 253 */             Arrays.fill((Object[])lists, (Object)null);
/* 254 */             coreSubscriber.onComplete();
/*     */             
/*     */             return;
/*     */           } 
/* 258 */           coreSubscriber.onNext(min);
/*     */           
/* 260 */           indexes[minIndex] = indexes[minIndex] + 1;
/*     */           
/* 262 */           e++;
/*     */         } 
/*     */         
/* 265 */         if (e == r) {
/* 266 */           if (this.cancelled) {
/* 267 */             Arrays.fill((Object[])lists, (Object)null);
/*     */             
/*     */             return;
/*     */           } 
/* 271 */           Throwable ex = this.error;
/* 272 */           if (ex != null) {
/* 273 */             cancelAll();
/* 274 */             Arrays.fill((Object[])lists, (Object)null);
/* 275 */             coreSubscriber.onError(ex);
/*     */             
/*     */             return;
/*     */           } 
/* 279 */           boolean empty = true;
/*     */           
/* 281 */           for (int i = 0; i < n; i++) {
/* 282 */             if (indexes[i] != lists[i].size()) {
/* 283 */               empty = false;
/*     */               
/*     */               break;
/*     */             } 
/*     */           } 
/* 288 */           if (empty) {
/* 289 */             Arrays.fill((Object[])lists, (Object)null);
/* 290 */             coreSubscriber.onComplete();
/*     */             
/*     */             return;
/*     */           } 
/*     */         } 
/* 295 */         if (e != 0L && r != Long.MAX_VALUE) {
/* 296 */           REQUESTED.addAndGet(this, -e);
/*     */         }
/*     */         
/* 299 */         int w = this.wip;
/* 300 */         if (w == missed) {
/* 301 */           missed = WIP.addAndGet(this, -missed);
/* 302 */           if (missed == 0) {
/*     */             break;
/*     */           }
/*     */           continue;
/*     */         } 
/* 307 */         missed = w;
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static final class MergeSortInner<T>
/*     */     implements InnerConsumer<List<T>>
/*     */   {
/*     */     final ParallelMergeSort.MergeSortMain<T> parent;
/*     */     
/*     */     final int index;
/*     */     
/*     */     volatile Subscription s;
/*     */     
/* 323 */     static final AtomicReferenceFieldUpdater<MergeSortInner, Subscription> S = AtomicReferenceFieldUpdater.newUpdater(MergeSortInner.class, Subscription.class, "s");
/*     */ 
/*     */ 
/*     */     
/*     */     MergeSortInner(ParallelMergeSort.MergeSortMain<T> parent, int index) {
/* 328 */       this.parent = parent;
/* 329 */       this.index = index;
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/* 334 */       return this.parent.actual.currentContext();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 340 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf((this.s == Operators.cancelledSubscription())); 
/* 341 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 342 */       if (key == Scannable.Attr.ACTUAL) return this.parent; 
/* 343 */       if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(2147483647); 
/* 344 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 346 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 351 */       if (Operators.setOnce(S, this, s)) {
/* 352 */         s.request(Long.MAX_VALUE);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(List<T> t) {
/* 358 */       this.parent.innerNext(t, this.index);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 363 */       this.parent.innerError(t);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onComplete() {}
/*     */ 
/*     */     
/*     */     void cancel() {
/* 372 */       Operators.terminate(S, this);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\ParallelMergeSort.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */