/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Objects;
/*     */ import java.util.function.BiConsumer;
/*     */ import java.util.function.Supplier;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MonoCollect<T, R>
/*     */   extends MonoFromFluxOperator<T, R>
/*     */   implements Fuseable
/*     */ {
/*     */   final Supplier<R> supplier;
/*     */   final BiConsumer<? super R, ? super T> action;
/*     */   
/*     */   MonoCollect(Flux<? extends T> source, Supplier<R> supplier, BiConsumer<? super R, ? super T> action) {
/*  51 */     super(source);
/*  52 */     this.supplier = Objects.<Supplier<R>>requireNonNull(supplier, "supplier");
/*  53 */     this.action = Objects.<BiConsumer<? super R, ? super T>>requireNonNull(action);
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super R> actual) {
/*  58 */     R container = Objects.requireNonNull(this.supplier.get(), "The supplier returned a null container");
/*     */ 
/*     */     
/*  61 */     return new CollectSubscriber<>(actual, this.action, container);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  66 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  67 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class CollectSubscriber<T, R>
/*     */     extends Operators.MonoSubscriber<T, R>
/*     */   {
/*     */     final BiConsumer<? super R, ? super T> action;
/*     */     
/*     */     R container;
/*     */     
/*     */     Subscription s;
/*     */     
/*     */     boolean done;
/*     */     
/*     */     CollectSubscriber(CoreSubscriber<? super R> actual, BiConsumer<? super R, ? super T> action, R container) {
/*  83 */       super(actual);
/*  84 */       this.action = action;
/*  85 */       this.container = container;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/*  91 */       if (key == Scannable.Attr.PARENT) return this.s; 
/*  92 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/*  93 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  94 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/*  99 */       if (Operators.validate(this.s, s)) {
/* 100 */         this.s = s;
/*     */         
/* 102 */         this.actual.onSubscribe(this);
/*     */         
/* 104 */         s.request(Long.MAX_VALUE);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 110 */       if (this.done) {
/* 111 */         Operators.onNextDropped(t, this.actual.currentContext());
/*     */         
/*     */         return;
/*     */       } 
/* 115 */       synchronized (this) {
/* 116 */         R c = this.container;
/* 117 */         if (c != null) {
/*     */           try {
/* 119 */             this.action.accept(c, t);
/*     */           }
/* 121 */           catch (Throwable e) {
/* 122 */             Context ctx = this.actual.currentContext();
/* 123 */             Operators.onDiscard(t, ctx);
/* 124 */             onError(Operators.onOperatorError(this, e, t, ctx));
/*     */           } 
/*     */           return;
/*     */         } 
/*     */       } 
/* 129 */       Operators.onDiscard(t, this.actual.currentContext());
/*     */     }
/*     */     
/*     */     public void onError(Throwable t) {
/*     */       R c;
/* 134 */       if (this.done) {
/* 135 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*     */         return;
/*     */       } 
/* 138 */       this.done = true;
/*     */       
/* 140 */       synchronized (this) {
/* 141 */         c = this.container;
/* 142 */         this.container = null;
/*     */       } 
/* 144 */       discard(c);
/* 145 */       this.actual.onError(t);
/*     */     }
/*     */     
/*     */     public void onComplete() {
/*     */       R c;
/* 150 */       if (this.done) {
/*     */         return;
/*     */       }
/* 153 */       this.done = true;
/*     */       
/* 155 */       synchronized (this) {
/* 156 */         c = this.container;
/* 157 */         this.container = null;
/*     */       } 
/* 159 */       if (c != null) {
/* 160 */         complete(c);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     protected void discard(R v) {
/* 166 */       if (v instanceof Collection) {
/* 167 */         Collection<?> c = (Collection)v;
/* 168 */         Operators.onDiscardMultiple(c, this.actual.currentContext());
/*     */       } else {
/*     */         
/* 171 */         super.discard(v);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void cancel() {
/*     */       R c;
/* 179 */       int state = STATE.getAndSet(this, 4);
/* 180 */       if (state != 4) {
/* 181 */         this.s.cancel();
/*     */       }
/* 183 */       if (state <= 2) {
/* 184 */         synchronized (this) {
/* 185 */           c = this.container;
/* 186 */           this.value = null;
/* 187 */           this.container = null;
/*     */         } 
/*     */       } else {
/*     */         
/* 191 */         c = null;
/*     */       } 
/* 193 */       if (c != null)
/* 194 */         discard(c); 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\MonoCollect.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */