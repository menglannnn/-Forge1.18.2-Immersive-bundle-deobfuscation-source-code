/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.LongConsumer;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxPeek<T>
/*     */   extends InternalFluxOperator<T, T>
/*     */   implements SignalPeek<T>
/*     */ {
/*     */   final Consumer<? super Subscription> onSubscribeCall;
/*     */   final Consumer<? super T> onNextCall;
/*     */   final Consumer<? super Throwable> onErrorCall;
/*     */   final Runnable onCompleteCall;
/*     */   final Runnable onAfterTerminateCall;
/*     */   final LongConsumer onRequestCall;
/*     */   final Runnable onCancelCall;
/*     */   
/*     */   FluxPeek(Flux<? extends T> source, @Nullable Consumer<? super Subscription> onSubscribeCall, @Nullable Consumer<? super T> onNextCall, @Nullable Consumer<? super Throwable> onErrorCall, @Nullable Runnable onCompleteCall, @Nullable Runnable onAfterTerminateCall, @Nullable LongConsumer onRequestCall, @Nullable Runnable onCancelCall) {
/*  67 */     super(source);
/*  68 */     this.onSubscribeCall = onSubscribeCall;
/*  69 */     this.onNextCall = onNextCall;
/*  70 */     this.onErrorCall = onErrorCall;
/*  71 */     this.onCompleteCall = onCompleteCall;
/*  72 */     this.onAfterTerminateCall = onAfterTerminateCall;
/*  73 */     this.onRequestCall = onRequestCall;
/*  74 */     this.onCancelCall = onCancelCall;
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/*  79 */     if (actual instanceof Fuseable.ConditionalSubscriber) {
/*     */       
/*  81 */       Fuseable.ConditionalSubscriber<T> s2 = (Fuseable.ConditionalSubscriber)actual;
/*  82 */       return new FluxPeekFuseable.PeekConditionalSubscriber<>(s2, this);
/*     */     } 
/*  84 */     return new PeekSubscriber<>(actual, this);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  89 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  90 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class PeekSubscriber<T>
/*     */     implements InnerOperator<T, T>
/*     */   {
/*     */     final CoreSubscriber<? super T> actual;
/*     */     
/*     */     final SignalPeek<T> parent;
/*     */     Subscription s;
/*     */     boolean done;
/*     */     
/*     */     PeekSubscriber(CoreSubscriber<? super T> actual, SignalPeek<T> parent) {
/* 104 */       this.actual = actual;
/* 105 */       this.parent = parent;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 111 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 112 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 113 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 115 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/* 120 */       Context c = this.actual.currentContext();
/* 121 */       if (!c.isEmpty() && this.parent.onCurrentContextCall() != null) {
/* 122 */         this.parent.onCurrentContextCall().accept(c);
/*     */       }
/* 124 */       return c;
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 129 */       LongConsumer requestHook = this.parent.onRequestCall();
/* 130 */       if (requestHook != null) {
/*     */         try {
/* 132 */           requestHook.accept(n);
/*     */         }
/* 134 */         catch (Throwable e) {
/* 135 */           Operators.onOperatorError(e, this.actual.currentContext());
/*     */         } 
/*     */       }
/* 138 */       this.s.request(n);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 143 */       Runnable cancelHook = this.parent.onCancelCall();
/* 144 */       if (cancelHook != null) {
/*     */         try {
/* 146 */           cancelHook.run();
/*     */         }
/* 148 */         catch (Throwable e) {
/* 149 */           onError(Operators.onOperatorError(this.s, e, this.actual.currentContext()));
/*     */           return;
/*     */         } 
/*     */       }
/* 153 */       this.s.cancel();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 158 */       if (Operators.validate(this.s, s)) {
/* 159 */         Consumer<? super Subscription> subscribeHook = this.parent.onSubscribeCall();
/* 160 */         if (subscribeHook != null) {
/*     */           try {
/* 162 */             subscribeHook.accept(s);
/*     */           }
/* 164 */           catch (Throwable e) {
/* 165 */             Operators.error((Subscriber<?>)this.actual, Operators.onOperatorError(s, e, this.actual
/* 166 */                   .currentContext()));
/*     */             return;
/*     */           } 
/*     */         }
/* 170 */         this.s = s;
/* 171 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 177 */       if (this.done) {
/* 178 */         Operators.onNextDropped(t, this.actual.currentContext());
/*     */         
/*     */         return;
/*     */       } 
/* 182 */       Consumer<? super T> nextHook = this.parent.onNextCall();
/* 183 */       if (nextHook != null) {
/*     */         try {
/* 185 */           nextHook.accept(t);
/*     */         }
/* 187 */         catch (Throwable e) {
/* 188 */           Throwable e_ = Operators.onNextError(t, e, this.actual.currentContext(), this.s);
/* 189 */           if (e_ == null) {
/* 190 */             request(1L);
/*     */             
/*     */             return;
/*     */           } 
/* 194 */           onError(e_);
/*     */           
/*     */           return;
/*     */         } 
/*     */       }
/*     */       
/* 200 */       this.actual.onNext(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 205 */       if (this.done) {
/* 206 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*     */         return;
/*     */       } 
/* 209 */       this.done = true;
/* 210 */       Consumer<? super Throwable> errorHook = this.parent.onErrorCall();
/* 211 */       if (errorHook != null) {
/*     */         try {
/* 213 */           errorHook.accept(t);
/*     */         }
/* 215 */         catch (Throwable e) {
/*     */           
/* 217 */           t = Operators.onOperatorError(null, e, t, this.actual.currentContext());
/*     */         } 
/*     */       }
/*     */       
/*     */       try {
/* 222 */         this.actual.onError(t);
/*     */       }
/* 224 */       catch (UnsupportedOperationException use) {
/* 225 */         if (errorHook == null || (
/* 226 */           !Exceptions.isErrorCallbackNotImplemented(use) && use.getCause() != t)) {
/* 227 */           throw use;
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 232 */       Runnable afterTerminateHook = this.parent.onAfterTerminateCall();
/* 233 */       if (afterTerminateHook != null) {
/*     */         try {
/* 235 */           afterTerminateHook.run();
/*     */         }
/* 237 */         catch (Throwable e) {
/* 238 */           FluxPeek.afterErrorWithFailure(this.parent, e, t, this.actual.currentContext());
/*     */         } 
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 245 */       if (this.done) {
/*     */         return;
/*     */       }
/* 248 */       Runnable completeHook = this.parent.onCompleteCall();
/* 249 */       if (completeHook != null) {
/*     */         try {
/* 251 */           completeHook.run();
/*     */         }
/* 253 */         catch (Throwable e) {
/* 254 */           onError(Operators.onOperatorError(this.s, e, this.actual.currentContext()));
/*     */           return;
/*     */         } 
/*     */       }
/* 258 */       this.done = true;
/*     */       
/* 260 */       this.actual.onComplete();
/*     */       
/* 262 */       Runnable afterTerminateHook = this.parent.onAfterTerminateCall();
/* 263 */       if (afterTerminateHook != null) {
/*     */         try {
/* 265 */           afterTerminateHook.run();
/*     */         }
/* 267 */         catch (Throwable e) {
/* 268 */           FluxPeek.afterCompleteWithFailure(this.parent, e, this.actual.currentContext());
/*     */         } 
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 275 */       return this.actual;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Consumer<? super Subscription> onSubscribeCall() {
/* 283 */     return this.onSubscribeCall;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Consumer<? super T> onNextCall() {
/* 289 */     return this.onNextCall;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Consumer<? super Throwable> onErrorCall() {
/* 295 */     return this.onErrorCall;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Runnable onCompleteCall() {
/* 301 */     return this.onCompleteCall;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Runnable onAfterTerminateCall() {
/* 307 */     return this.onAfterTerminateCall;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public LongConsumer onRequestCall() {
/* 313 */     return this.onRequestCall;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Runnable onCancelCall() {
/* 319 */     return this.onCancelCall;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T> void afterCompleteWithFailure(SignalPeek<T> parent, Throwable callbackFailure, Context context) {
/* 340 */     Exceptions.throwIfFatal(callbackFailure);
/* 341 */     Throwable _e = Operators.onOperatorError(callbackFailure, context);
/* 342 */     Operators.onErrorDropped(_e, context);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T> void afterErrorWithFailure(SignalPeek<T> parent, Throwable callbackFailure, Throwable originalError, Context context) {
/* 364 */     Exceptions.throwIfFatal(callbackFailure);
/* 365 */     Throwable _e = Operators.onOperatorError(null, callbackFailure, originalError, context);
/* 366 */     Operators.onErrorDropped(_e, context);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\FluxPeek.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */