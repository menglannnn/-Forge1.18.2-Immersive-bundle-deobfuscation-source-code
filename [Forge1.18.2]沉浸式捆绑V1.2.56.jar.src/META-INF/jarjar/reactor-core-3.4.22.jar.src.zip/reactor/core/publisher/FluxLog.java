/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Fuseable;
/*    */ import reactor.core.Scannable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class FluxLog<T>
/*    */   extends InternalFluxOperator<T, T>
/*    */ {
/*    */   final SignalPeek<T> log;
/*    */   
/*    */   FluxLog(Flux<? extends T> source, SignalPeek<T> log) {
/* 39 */     super(source);
/* 40 */     this.log = log;
/*    */   }
/*    */ 
/*    */   
/*    */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/* 45 */     if (actual instanceof Fuseable.ConditionalSubscriber) {
/*    */       
/* 47 */       Fuseable.ConditionalSubscriber<T> s2 = (Fuseable.ConditionalSubscriber)actual;
/* 48 */       return new FluxPeekFuseable.PeekConditionalSubscriber<>(s2, this.log);
/*    */     } 
/* 50 */     return new FluxPeek.PeekSubscriber<>(actual, this.log);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 55 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 56 */     return super.scanUnsafe(key);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\FluxLog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */