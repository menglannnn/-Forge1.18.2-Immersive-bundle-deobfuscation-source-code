/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxConcatArray<T>
/*     */   extends Flux<T>
/*     */   implements SourceProducer<T>
/*     */ {
/*  37 */   static final Object WORKING = new Object();
/*  38 */   static final Object DONE = new Object();
/*     */   
/*     */   final Publisher<? extends T>[] array;
/*     */   
/*     */   final boolean delayError;
/*     */   
/*     */   @SafeVarargs
/*     */   FluxConcatArray(boolean delayError, Publisher<? extends T>... array) {
/*  46 */     this.array = Objects.<Publisher<? extends T>[]>requireNonNull(array, "array");
/*  47 */     this.delayError = delayError;
/*     */   }
/*     */ 
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super T> actual) {
/*  52 */     Publisher<? extends T>[] a = this.array;
/*     */     
/*  54 */     if (a.length == 0) {
/*  55 */       Operators.complete((Subscriber<?>)actual);
/*     */       return;
/*     */     } 
/*  58 */     if (a.length == 1) {
/*  59 */       Publisher<? extends T> p = a[0];
/*     */       
/*  61 */       if (p == null) {
/*  62 */         Operators.error((Subscriber<?>)actual, new NullPointerException("The single source Publisher is null"));
/*     */       } else {
/*  64 */         p.subscribe((Subscriber)actual);
/*     */       } 
/*     */       
/*     */       return;
/*     */     } 
/*  69 */     if (this.delayError) {
/*  70 */       ConcatArrayDelayErrorSubscriber<T> concatArrayDelayErrorSubscriber = new ConcatArrayDelayErrorSubscriber<>(actual, a);
/*     */ 
/*     */       
/*  73 */       concatArrayDelayErrorSubscriber.onComplete();
/*     */       return;
/*     */     } 
/*  76 */     ConcatArraySubscriber<T> parent = new ConcatArraySubscriber<>(actual, a);
/*     */     
/*  78 */     parent.onComplete();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  84 */     if (key == Scannable.Attr.DELAY_ERROR) return Boolean.valueOf(this.delayError); 
/*  85 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  86 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   FluxConcatArray<T> concatAdditionalSourceLast(Publisher<? extends T> source) {
/*  99 */     int n = this.array.length;
/*     */     
/* 101 */     Publisher[] arrayOfPublisher = new Publisher[n + 1];
/* 102 */     System.arraycopy(this.array, 0, arrayOfPublisher, 0, n);
/* 103 */     arrayOfPublisher[n] = source;
/*     */     
/* 105 */     return new FluxConcatArray(this.delayError, (Publisher<? extends T>[])arrayOfPublisher);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   <V> FluxConcatArray<V> concatAdditionalIgnoredLast(Publisher<? extends V> source) {
/* 120 */     int n = this.array.length;
/* 121 */     Publisher[] arrayOfPublisher = new Publisher[n + 1];
/*     */     
/* 123 */     System.arraycopy(this.array, 0, arrayOfPublisher, 0, n);
/* 124 */     arrayOfPublisher[n - 1] = Mono.ignoreElements(arrayOfPublisher[n - 1]);
/* 125 */     arrayOfPublisher[n] = source;
/*     */     
/* 127 */     return new FluxConcatArray(this.delayError, (Publisher<? extends T>[])arrayOfPublisher);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   FluxConcatArray<T> concatAdditionalSourceFirst(Publisher<? extends T> source) {
/* 140 */     int n = this.array.length;
/*     */     
/* 142 */     Publisher[] arrayOfPublisher = new Publisher[n + 1];
/* 143 */     System.arraycopy(this.array, 0, arrayOfPublisher, 1, n);
/* 144 */     arrayOfPublisher[0] = source;
/*     */     
/* 146 */     return new FluxConcatArray(this.delayError, (Publisher<? extends T>[])arrayOfPublisher);
/*     */   }
/*     */ 
/*     */   
/*     */   static interface SubscriptionAware
/*     */   {
/*     */     Subscription upstream();
/*     */   }
/*     */   
/*     */   static final class ConcatArraySubscriber<T>
/*     */     extends ThreadLocal<Object>
/*     */     implements InnerOperator<T, T>, SubscriptionAware
/*     */   {
/*     */     final CoreSubscriber<? super T> actual;
/*     */     final Publisher<? extends T>[] sources;
/*     */     int index;
/*     */     long produced;
/*     */     Subscription s;
/*     */     volatile long requested;
/* 165 */     static final AtomicLongFieldUpdater<ConcatArraySubscriber> REQUESTED = AtomicLongFieldUpdater.newUpdater(ConcatArraySubscriber.class, "requested");
/*     */     
/*     */     volatile boolean cancelled;
/*     */     
/*     */     ConcatArraySubscriber(CoreSubscriber<? super T> actual, Publisher<? extends T>[] sources) {
/* 170 */       this.actual = actual;
/* 171 */       this.sources = sources;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 176 */       if (this.cancelled) {
/* 177 */         remove();
/* 178 */         s.cancel();
/*     */         
/*     */         return;
/*     */       } 
/* 182 */       Subscription previousSubscription = this.s;
/*     */       
/* 184 */       this.s = s;
/*     */       
/* 186 */       if (previousSubscription == null) {
/* 187 */         this.actual.onSubscribe(this);
/*     */         
/*     */         return;
/*     */       } 
/* 191 */       long actualRequested = FluxConcatArray.activateAndGetRequested(REQUESTED, this);
/* 192 */       if (actualRequested > 0L) {
/* 193 */         s.request(actualRequested);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 199 */       this.produced++;
/*     */       
/* 201 */       this.actual.onNext(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 206 */       remove();
/* 207 */       this.actual.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 212 */       if (get() == FluxConcatArray.WORKING) {
/* 213 */         set(FluxConcatArray.DONE);
/*     */         
/*     */         return;
/*     */       } 
/* 217 */       Publisher<? extends T>[] a = this.sources;
/*     */       
/*     */       while (true) {
/* 220 */         set(FluxConcatArray.WORKING);
/*     */         
/* 222 */         int i = this.index;
/* 223 */         if (i == a.length) {
/* 224 */           remove();
/*     */           
/* 226 */           if (this.cancelled) {
/*     */             return;
/*     */           }
/*     */           
/* 230 */           this.actual.onComplete();
/*     */           
/*     */           return;
/*     */         } 
/* 234 */         Publisher<? extends T> p = a[i];
/*     */         
/* 236 */         if (p == null) {
/* 237 */           remove();
/*     */           
/* 239 */           if (this.cancelled) {
/*     */             return;
/*     */           }
/*     */           
/* 243 */           this.actual.onError(new NullPointerException("Source Publisher at index " + i + " is null"));
/*     */           
/*     */           return;
/*     */         } 
/* 247 */         long c = this.produced;
/* 248 */         if (c != 0L) {
/* 249 */           this.produced = 0L;
/* 250 */           FluxConcatArray.deactivateAndProduce(c, REQUESTED, this);
/*     */         } 
/*     */         
/* 253 */         this.index = ++i;
/*     */         
/* 255 */         if (this.cancelled) {
/*     */           return;
/*     */         }
/* 258 */         p.subscribe((Subscriber)this);
/*     */         
/* 260 */         Object state = get();
/* 261 */         if (state != FluxConcatArray.DONE) {
/* 262 */           remove();
/*     */           return;
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 270 */       Subscription subscription = FluxConcatArray.addCapAndGetSubscription(n, REQUESTED, this);
/*     */       
/* 272 */       if (subscription == null) {
/*     */         return;
/*     */       }
/*     */       
/* 276 */       subscription.request(n);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 281 */       remove();
/*     */       
/* 283 */       this.cancelled = true;
/*     */       
/* 285 */       if ((this.requested & Long.MIN_VALUE) != Long.MIN_VALUE) {
/* 286 */         this.s.cancel();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public Subscription upstream() {
/* 292 */       return this.s;
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 297 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 302 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 303 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 304 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(this.cancelled); 
/* 305 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf(this.requested);
/*     */       
/* 307 */       return super.scanUnsafe(key);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class ConcatArrayDelayErrorSubscriber<T>
/*     */     extends ThreadLocal<Object>
/*     */     implements InnerOperator<T, T>, SubscriptionAware
/*     */   {
/*     */     final CoreSubscriber<? super T> actual;
/*     */     
/*     */     final Publisher<? extends T>[] sources;
/*     */     int index;
/*     */     long produced;
/*     */     Subscription s;
/*     */     volatile long requested;
/* 323 */     static final AtomicLongFieldUpdater<ConcatArrayDelayErrorSubscriber> REQUESTED = AtomicLongFieldUpdater.newUpdater(ConcatArrayDelayErrorSubscriber.class, "requested");
/*     */ 
/*     */     
/*     */     volatile Throwable error;
/*     */     
/* 328 */     static final AtomicReferenceFieldUpdater<ConcatArrayDelayErrorSubscriber, Throwable> ERROR = AtomicReferenceFieldUpdater.newUpdater(ConcatArrayDelayErrorSubscriber.class, Throwable.class, "error");
/*     */     
/*     */     volatile boolean cancelled;
/*     */     
/*     */     ConcatArrayDelayErrorSubscriber(CoreSubscriber<? super T> actual, Publisher<? extends T>[] sources) {
/* 333 */       this.actual = actual;
/* 334 */       this.sources = sources;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 339 */       if (this.cancelled) {
/* 340 */         remove();
/* 341 */         s.cancel();
/*     */         
/*     */         return;
/*     */       } 
/* 345 */       Subscription previousSubscription = this.s;
/*     */       
/* 347 */       this.s = s;
/*     */       
/* 349 */       if (previousSubscription == null) {
/* 350 */         this.actual.onSubscribe(this);
/*     */         
/*     */         return;
/*     */       } 
/* 354 */       long actualRequested = FluxConcatArray.activateAndGetRequested(REQUESTED, this);
/* 355 */       if (actualRequested > 0L) {
/* 356 */         s.request(actualRequested);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 362 */       this.produced++;
/*     */       
/* 364 */       this.actual.onNext(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 369 */       if (!Exceptions.addThrowable(ERROR, this, t)) {
/* 370 */         remove();
/* 371 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*     */         
/*     */         return;
/*     */       } 
/* 375 */       onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 380 */       if (get() == FluxConcatArray.WORKING) {
/* 381 */         set(FluxConcatArray.DONE);
/*     */         
/*     */         return;
/*     */       } 
/* 385 */       Publisher<? extends T>[] a = this.sources;
/*     */       
/*     */       while (true) {
/* 388 */         set(FluxConcatArray.WORKING);
/*     */         
/* 390 */         int i = this.index;
/* 391 */         if (i == a.length) {
/* 392 */           remove();
/*     */           
/* 394 */           Throwable e = Exceptions.terminate(ERROR, this);
/* 395 */           if (e == Exceptions.TERMINATED) {
/*     */             return;
/*     */           }
/*     */           
/* 399 */           if (e != null) {
/* 400 */             this.actual.onError(e);
/*     */           } else {
/* 402 */             this.actual.onComplete();
/*     */           } 
/*     */           
/*     */           return;
/*     */         } 
/* 407 */         Publisher<? extends T> p = a[i];
/*     */         
/* 409 */         if (p == null) {
/* 410 */           remove();
/*     */           
/* 412 */           if (this.cancelled) {
/*     */             return;
/*     */           }
/*     */           
/* 416 */           NullPointerException npe = new NullPointerException("Source Publisher at index " + i + " is null");
/* 417 */           if (!Exceptions.addThrowable(ERROR, this, npe)) {
/* 418 */             Operators.onErrorDropped(npe, this.actual.currentContext());
/*     */             
/*     */             return;
/*     */           } 
/* 422 */           Throwable throwable = Exceptions.terminate(ERROR, this);
/* 423 */           if (throwable == Exceptions.TERMINATED) {
/*     */             return;
/*     */           }
/*     */           
/* 427 */           this.actual.onError(throwable);
/*     */           
/*     */           return;
/*     */         } 
/* 431 */         long c = this.produced;
/* 432 */         if (c != 0L) {
/* 433 */           this.produced = 0L;
/* 434 */           FluxConcatArray.deactivateAndProduce(c, REQUESTED, this);
/*     */         } 
/*     */         
/* 437 */         this.index = ++i;
/*     */         
/* 439 */         if (this.cancelled) {
/*     */           return;
/*     */         }
/*     */         
/* 443 */         p.subscribe((Subscriber)this);
/*     */         
/* 445 */         Object state = get();
/* 446 */         if (state != FluxConcatArray.DONE) {
/* 447 */           remove();
/*     */           return;
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 455 */       Subscription subscription = FluxConcatArray.addCapAndGetSubscription(n, REQUESTED, this);
/*     */       
/* 457 */       if (subscription == null) {
/*     */         return;
/*     */       }
/*     */       
/* 461 */       subscription.request(n);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 466 */       remove();
/*     */       
/* 468 */       this.cancelled = true;
/*     */       
/* 470 */       if ((this.requested & Long.MIN_VALUE) != Long.MIN_VALUE) {
/* 471 */         this.s.cancel();
/*     */       }
/*     */       
/* 474 */       Throwable throwable = Exceptions.terminate(ERROR, this);
/* 475 */       if (throwable != null) {
/* 476 */         Operators.onErrorDropped(throwable, this.actual.currentContext());
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public Subscription upstream() {
/* 482 */       return this.s;
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 487 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 493 */       if (key == Scannable.Attr.DELAY_ERROR) return Boolean.valueOf(true); 
/* 494 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf((this.error == Exceptions.TERMINATED)); 
/* 495 */       if (key == Scannable.Attr.ERROR) return (this.error != Exceptions.TERMINATED) ? this.error : null; 
/* 496 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 497 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 498 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(this.cancelled); 
/* 499 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf(this.requested);
/*     */       
/* 501 */       return super.scanUnsafe(key);
/*     */     }
/*     */   }
/*     */   
/*     */   static <T> long activateAndGetRequested(AtomicLongFieldUpdater<T> updater, T instance) {
/*     */     while (true) {
/* 507 */       long deactivatedRequested = updater.get(instance);
/* 508 */       long actualRequested = deactivatedRequested & Long.MAX_VALUE;
/*     */       
/* 510 */       if (updater.compareAndSet(instance, deactivatedRequested, actualRequested))
/* 511 */         return actualRequested; 
/*     */     } 
/*     */   }
/*     */   static <T> void deactivateAndProduce(long produced, AtomicLongFieldUpdater<T> updater, T instance) {
/*     */     long actualRequested;
/*     */     long deactivatedRequested;
/*     */     do {
/* 518 */       actualRequested = updater.get(instance);
/* 519 */       deactivatedRequested = (actualRequested == Long.MAX_VALUE) ? -1L : (actualRequested - produced | Long.MIN_VALUE);
/*     */ 
/*     */     
/*     */     }
/* 523 */     while (!updater.compareAndSet(instance, actualRequested, deactivatedRequested));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   static <T extends SubscriptionAware> Subscription addCapAndGetSubscription(long n, AtomicLongFieldUpdater<T> updater, T instance) {
/*     */     while (true) {
/* 532 */       long state = updater.get(instance);
/* 533 */       Subscription s = instance.upstream();
/* 534 */       long actualRequested = state & Long.MAX_VALUE;
/* 535 */       long status = state & Long.MIN_VALUE;
/*     */       
/* 537 */       if (actualRequested == Long.MAX_VALUE) {
/* 538 */         return (status == Long.MIN_VALUE) ? null : s;
/*     */       }
/*     */       
/* 541 */       if (updater.compareAndSet(instance, state, Operators.addCap(actualRequested, n) | status))
/* 542 */         return (status == Long.MIN_VALUE) ? null : s; 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\FluxConcatArray.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */