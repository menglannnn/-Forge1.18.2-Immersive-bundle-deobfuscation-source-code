/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import reactor.core.CorePublisher;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Scannable;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class InternalFluxOperator<I, O>
/*    */   extends FluxOperator<I, O>
/*    */   implements Scannable, OptimizableOperator<O, I>
/*    */ {
/*    */   @Nullable
/*    */   final OptimizableOperator<?, I> optimizableOperator;
/*    */   
/*    */   protected InternalFluxOperator(Flux<? extends I> source) {
/* 38 */     super(source);
/* 39 */     if (source instanceof OptimizableOperator) {
/*    */       
/* 41 */       OptimizableOperator<?, I> optimSource = (OptimizableOperator)source;
/* 42 */       this.optimizableOperator = optimSource;
/*    */     } else {
/*    */       
/* 45 */       this.optimizableOperator = null;
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public final void subscribe(CoreSubscriber<? super O> subscriber) {
/* 52 */     OptimizableOperator<I, O> operator = this;
/*    */     try {
/*    */       while (true) {
/* 55 */         subscriber = operator.subscribeOrReturn(subscriber);
/* 56 */         if (subscriber == null) {
/*    */           return;
/*    */         }
/*    */         
/* 60 */         OptimizableOperator<?, ? extends O> newSource = operator.nextOptimizableSource();
/* 61 */         if (newSource == null) {
/* 62 */           operator.source().subscribe(subscriber);
/*    */           return;
/*    */         } 
/* 65 */         OptimizableOperator<?, ? extends O> optimizableOperator1 = newSource;
/*    */       }
/*    */     
/* 68 */     } catch (Throwable e) {
/* 69 */       Operators.reportThrowInSubscribe(subscriber, e);
/*    */       return;
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public abstract CoreSubscriber<? super I> subscribeOrReturn(CoreSubscriber<? super O> paramCoreSubscriber) throws Throwable;
/*    */   
/*    */   public final CorePublisher<? extends I> source() {
/* 79 */     return this.source;
/*    */   }
/*    */ 
/*    */   
/*    */   public final OptimizableOperator<?, ? extends I> nextOptimizableSource() {
/* 84 */     return this.optimizableOperator;
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 90 */     if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(getPrefetch()); 
/* 91 */     if (key == Scannable.Attr.PARENT) return this.source; 
/* 92 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\InternalFluxOperator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */