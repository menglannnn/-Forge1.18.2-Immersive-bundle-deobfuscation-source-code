/*      */ package reactor.core.publisher;
/*      */ 
/*      */ import java.util.Objects;
/*      */ import java.util.Queue;
/*      */ import java.util.concurrent.RejectedExecutionException;
/*      */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*      */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*      */ import java.util.function.Supplier;
/*      */ import org.reactivestreams.Subscriber;
/*      */ import org.reactivestreams.Subscription;
/*      */ import reactor.core.CoreSubscriber;
/*      */ import reactor.core.Exceptions;
/*      */ import reactor.core.Fuseable;
/*      */ import reactor.core.Scannable;
/*      */ import reactor.core.scheduler.Scheduler;
/*      */ import reactor.util.annotation.Nullable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ final class FluxPublishOn<T>
/*      */   extends InternalFluxOperator<T, T>
/*      */   implements Fuseable
/*      */ {
/*      */   final Scheduler scheduler;
/*      */   final boolean delayError;
/*      */   final Supplier<? extends Queue<T>> queueSupplier;
/*      */   final int prefetch;
/*      */   final int lowTide;
/*      */   
/*      */   FluxPublishOn(Flux<? extends T> source, Scheduler scheduler, boolean delayError, int prefetch, int lowTide, Supplier<? extends Queue<T>> queueSupplier) {
/*   60 */     super(source);
/*   61 */     if (prefetch <= 0) {
/*   62 */       throw new IllegalArgumentException("prefetch > 0 required but it was " + prefetch);
/*      */     }
/*   64 */     this.scheduler = Objects.<Scheduler>requireNonNull(scheduler, "scheduler");
/*   65 */     this.delayError = delayError;
/*   66 */     this.prefetch = prefetch;
/*   67 */     this.lowTide = lowTide;
/*   68 */     this.queueSupplier = Objects.<Supplier<? extends Queue<T>>>requireNonNull(queueSupplier, "queueSupplier");
/*      */   }
/*      */ 
/*      */   
/*      */   public Object scanUnsafe(Scannable.Attr key) {
/*   73 */     if (key == Scannable.Attr.RUN_ON) return this.scheduler; 
/*   74 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.ASYNC;
/*      */     
/*   76 */     return super.scanUnsafe(key);
/*      */   }
/*      */ 
/*      */   
/*      */   public int getPrefetch() {
/*   81 */     return this.prefetch;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/*   87 */     Scheduler.Worker worker = Objects.<Scheduler.Worker>requireNonNull(this.scheduler.createWorker(), "The scheduler returned a null worker");
/*      */ 
/*      */     
/*   90 */     if (actual instanceof Fuseable.ConditionalSubscriber) {
/*   91 */       Fuseable.ConditionalSubscriber<? super T> cs = (Fuseable.ConditionalSubscriber<? super T>)actual;
/*   92 */       this.source.subscribe(new PublishOnConditionalSubscriber<>(cs, this.scheduler, worker, this.delayError, this.prefetch, this.lowTide, this.queueSupplier));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*   99 */       return null;
/*      */     } 
/*  101 */     return new PublishOnSubscriber<>(actual, this.scheduler, worker, this.delayError, this.prefetch, this.lowTide, this.queueSupplier);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static final class PublishOnSubscriber<T>
/*      */     implements Fuseable.QueueSubscription<T>, Runnable, InnerOperator<T, T>
/*      */   {
/*      */     final CoreSubscriber<? super T> actual;
/*      */ 
/*      */     
/*      */     final Scheduler scheduler;
/*      */ 
/*      */     
/*      */     final Scheduler.Worker worker;
/*      */ 
/*      */     
/*      */     final boolean delayError;
/*      */ 
/*      */     
/*      */     final int prefetch;
/*      */ 
/*      */     
/*      */     final int limit;
/*      */     
/*      */     final Supplier<? extends Queue<T>> queueSupplier;
/*      */     
/*      */     Subscription s;
/*      */     
/*      */     Queue<T> queue;
/*      */     
/*      */     volatile boolean cancelled;
/*      */     
/*      */     volatile boolean done;
/*      */     
/*      */     Throwable error;
/*      */     
/*      */     volatile int wip;
/*      */     
/*  140 */     static final AtomicIntegerFieldUpdater<PublishOnSubscriber> WIP = AtomicIntegerFieldUpdater.newUpdater(PublishOnSubscriber.class, "wip");
/*      */ 
/*      */     
/*      */     volatile int discardGuard;
/*      */     
/*  145 */     static final AtomicIntegerFieldUpdater<PublishOnSubscriber> DISCARD_GUARD = AtomicIntegerFieldUpdater.newUpdater(PublishOnSubscriber.class, "discardGuard");
/*      */ 
/*      */     
/*      */     volatile long requested;
/*      */     
/*  150 */     static final AtomicLongFieldUpdater<PublishOnSubscriber> REQUESTED = AtomicLongFieldUpdater.newUpdater(PublishOnSubscriber.class, "requested");
/*      */ 
/*      */ 
/*      */     
/*      */     int sourceMode;
/*      */ 
/*      */     
/*      */     long produced;
/*      */ 
/*      */     
/*      */     boolean outputFused;
/*      */ 
/*      */ 
/*      */     
/*      */     PublishOnSubscriber(CoreSubscriber<? super T> actual, Scheduler scheduler, Scheduler.Worker worker, boolean delayError, int prefetch, int lowTide, Supplier<? extends Queue<T>> queueSupplier) {
/*  165 */       this.actual = actual;
/*  166 */       this.worker = worker;
/*  167 */       this.scheduler = scheduler;
/*  168 */       this.delayError = delayError;
/*  169 */       this.prefetch = prefetch;
/*  170 */       this.queueSupplier = queueSupplier;
/*  171 */       this.limit = Operators.unboundedOrLimit(prefetch, lowTide);
/*      */     }
/*      */ 
/*      */     
/*      */     public void onSubscribe(Subscription s) {
/*  176 */       if (Operators.validate(this.s, s)) {
/*  177 */         this.s = s;
/*      */         
/*  179 */         if (s instanceof Fuseable.QueueSubscription) {
/*  180 */           Fuseable.QueueSubscription<T> f = (Fuseable.QueueSubscription<T>)s;
/*      */ 
/*      */           
/*  183 */           int m = f.requestFusion(7);
/*      */           
/*  185 */           if (m == 1) {
/*  186 */             this.sourceMode = 1;
/*  187 */             this.queue = (Queue<T>)f;
/*  188 */             this.done = true;
/*      */             
/*  190 */             this.actual.onSubscribe(this);
/*      */             return;
/*      */           } 
/*  193 */           if (m == 2) {
/*  194 */             this.sourceMode = 2;
/*  195 */             this.queue = (Queue<T>)f;
/*      */             
/*  197 */             this.actual.onSubscribe(this);
/*      */             
/*  199 */             s.request(Operators.unboundedOrPrefetch(this.prefetch));
/*      */             
/*      */             return;
/*      */           } 
/*      */         } 
/*      */         
/*  205 */         this.queue = this.queueSupplier.get();
/*      */         
/*  207 */         this.actual.onSubscribe(this);
/*      */         
/*  209 */         s.request(Operators.unboundedOrPrefetch(this.prefetch));
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void onNext(T t) {
/*  215 */       if (this.sourceMode == 2) {
/*  216 */         trySchedule(this, null, null);
/*      */         
/*      */         return;
/*      */       } 
/*  220 */       if (this.done) {
/*  221 */         Operators.onNextDropped(t, this.actual.currentContext());
/*      */         
/*      */         return;
/*      */       } 
/*  225 */       if (this.cancelled) {
/*  226 */         Operators.onDiscard(t, this.actual.currentContext());
/*      */         
/*      */         return;
/*      */       } 
/*  230 */       if (!this.queue.offer(t)) {
/*  231 */         Operators.onDiscard(t, this.actual.currentContext());
/*  232 */         this.error = Operators.onOperatorError(this.s, 
/*  233 */             Exceptions.failWithOverflow("Queue is full: Reactive Streams source doesn't respect backpressure"), t, this.actual
/*  234 */             .currentContext());
/*  235 */         this.done = true;
/*      */       } 
/*  237 */       trySchedule(this, null, t);
/*      */     }
/*      */ 
/*      */     
/*      */     public void onError(Throwable t) {
/*  242 */       if (this.done) {
/*  243 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*      */         return;
/*      */       } 
/*  246 */       this.error = t;
/*  247 */       this.done = true;
/*  248 */       trySchedule(null, t, null);
/*      */     }
/*      */ 
/*      */     
/*      */     public void onComplete() {
/*  253 */       if (this.done) {
/*      */         return;
/*      */       }
/*  256 */       this.done = true;
/*      */       
/*  258 */       trySchedule(null, null, null);
/*      */     }
/*      */ 
/*      */     
/*      */     public void request(long n) {
/*  263 */       if (Operators.validate(n)) {
/*  264 */         Operators.addCap(REQUESTED, this, n);
/*      */         
/*  266 */         trySchedule(this, null, null);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void cancel() {
/*  272 */       if (this.cancelled) {
/*      */         return;
/*      */       }
/*      */       
/*  276 */       this.cancelled = true;
/*  277 */       this.s.cancel();
/*  278 */       this.worker.dispose();
/*      */       
/*  280 */       if (WIP.getAndIncrement(this) == 0) {
/*  281 */         if (this.sourceMode == 2) {
/*      */           
/*  283 */           this.queue.clear();
/*      */         }
/*  285 */         else if (!this.outputFused) {
/*      */ 
/*      */           
/*  288 */           Operators.onDiscardQueueWithClear(this.queue, this.actual.currentContext(), null);
/*      */         } 
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void trySchedule(@Nullable Subscription subscription, @Nullable Throwable suppressed, @Nullable Object dataSignal) {
/*  297 */       if (WIP.getAndIncrement(this) != 0) {
/*  298 */         if (this.cancelled) {
/*  299 */           if (this.sourceMode == 2) {
/*      */             
/*  301 */             this.queue.clear();
/*      */           }
/*      */           else {
/*      */             
/*  305 */             Operators.onDiscard(dataSignal, this.actual.currentContext());
/*      */           } 
/*      */         }
/*      */         
/*      */         return;
/*      */       } 
/*      */       try {
/*  312 */         this.worker.schedule(this);
/*      */       }
/*  314 */       catch (RejectedExecutionException ree) {
/*  315 */         if (this.sourceMode == 2) {
/*      */           
/*  317 */           this.queue.clear();
/*  318 */         } else if (this.outputFused) {
/*      */ 
/*      */           
/*  321 */           clear();
/*      */         }
/*      */         else {
/*      */           
/*  325 */           Operators.onDiscardQueueWithClear(this.queue, this.actual.currentContext(), null);
/*      */         } 
/*  327 */         this.actual.onError(Operators.onRejectedExecution(ree, subscription, suppressed, dataSignal, this.actual
/*  328 */               .currentContext()));
/*      */       } 
/*      */     }
/*      */     
/*      */     void runSync() {
/*  333 */       int missed = 1;
/*      */       
/*  335 */       CoreSubscriber<? super T> coreSubscriber = this.actual;
/*  336 */       Queue<T> q = this.queue;
/*      */       
/*  338 */       long e = this.produced;
/*      */ 
/*      */       
/*      */       while (true) {
/*  342 */         long r = this.requested;
/*      */         
/*  344 */         while (e != r) {
/*      */           T v;
/*      */           
/*      */           try {
/*  348 */             v = q.poll();
/*      */           }
/*  350 */           catch (Throwable ex) {
/*  351 */             doError((Subscriber<?>)coreSubscriber, Operators.onOperatorError(this.s, ex, this.actual
/*  352 */                   .currentContext()));
/*      */             
/*      */             return;
/*      */           } 
/*  356 */           if (this.cancelled) {
/*  357 */             Operators.onDiscard(v, this.actual.currentContext());
/*  358 */             Operators.onDiscardQueueWithClear(q, this.actual.currentContext(), null);
/*      */             return;
/*      */           } 
/*  361 */           if (v == null) {
/*  362 */             doComplete((Subscriber<?>)coreSubscriber);
/*      */             
/*      */             return;
/*      */           } 
/*  366 */           coreSubscriber.onNext(v);
/*      */           
/*  368 */           e++;
/*      */         } 
/*      */         
/*  371 */         if (this.cancelled) {
/*  372 */           Operators.onDiscardQueueWithClear(q, this.actual.currentContext(), null);
/*      */           
/*      */           return;
/*      */         } 
/*  376 */         if (q.isEmpty()) {
/*  377 */           doComplete((Subscriber<?>)coreSubscriber);
/*      */           
/*      */           return;
/*      */         } 
/*  381 */         int w = this.wip;
/*  382 */         if (missed == w) {
/*  383 */           this.produced = e;
/*  384 */           missed = WIP.addAndGet(this, -missed);
/*  385 */           if (missed == 0) {
/*      */             break;
/*      */           }
/*      */           continue;
/*      */         } 
/*  390 */         missed = w;
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     void runAsync() {
/*  396 */       int missed = 1;
/*      */       
/*  398 */       CoreSubscriber<? super T> coreSubscriber = this.actual;
/*  399 */       Queue<T> q = this.queue;
/*      */       
/*  401 */       long e = this.produced;
/*      */ 
/*      */       
/*      */       while (true) {
/*  405 */         long r = this.requested;
/*      */         
/*  407 */         while (e != r) {
/*  408 */           T v; boolean d = this.done;
/*      */ 
/*      */           
/*      */           try {
/*  412 */             v = q.poll();
/*      */           }
/*  414 */           catch (Throwable ex) {
/*  415 */             Exceptions.throwIfFatal(ex);
/*  416 */             this.s.cancel();
/*  417 */             if (this.sourceMode == 2) {
/*      */               
/*  419 */               this.queue.clear();
/*      */             }
/*      */             else {
/*      */               
/*  423 */               Operators.onDiscardQueueWithClear(this.queue, this.actual.currentContext(), null);
/*      */             } 
/*      */             
/*  426 */             doError((Subscriber<?>)coreSubscriber, Operators.onOperatorError(ex, this.actual.currentContext()));
/*      */             
/*      */             return;
/*      */           } 
/*  430 */           boolean empty = (v == null);
/*      */           
/*  432 */           if (checkTerminated(d, empty, (Subscriber<?>)coreSubscriber, v)) {
/*      */             return;
/*      */           }
/*      */           
/*  436 */           if (empty) {
/*      */             break;
/*      */           }
/*      */           
/*  440 */           coreSubscriber.onNext(v);
/*      */           
/*  442 */           e++;
/*  443 */           if (e == this.limit) {
/*  444 */             if (r != Long.MAX_VALUE) {
/*  445 */               r = REQUESTED.addAndGet(this, -e);
/*      */             }
/*  447 */             this.s.request(e);
/*  448 */             e = 0L;
/*      */           } 
/*      */         } 
/*      */         
/*  452 */         if (e == r && checkTerminated(this.done, q.isEmpty(), (Subscriber<?>)coreSubscriber, null)) {
/*      */           return;
/*      */         }
/*      */         
/*  456 */         int w = this.wip;
/*  457 */         if (missed == w) {
/*  458 */           this.produced = e;
/*  459 */           missed = WIP.addAndGet(this, -missed);
/*  460 */           if (missed == 0) {
/*      */             break;
/*      */           }
/*      */           continue;
/*      */         } 
/*  465 */         missed = w;
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     void runBackfused() {
/*  471 */       int missed = 1;
/*      */ 
/*      */       
/*      */       do {
/*  475 */         if (this.cancelled) {
/*      */ 
/*      */           
/*  478 */           clear();
/*      */           
/*      */           return;
/*      */         } 
/*  482 */         boolean d = this.done;
/*      */         
/*  484 */         this.actual.onNext(null);
/*      */         
/*  486 */         if (d) {
/*  487 */           Throwable e = this.error;
/*  488 */           if (e != null) {
/*  489 */             doError((Subscriber<?>)this.actual, e);
/*      */           } else {
/*      */             
/*  492 */             doComplete((Subscriber<?>)this.actual);
/*      */           } 
/*      */           
/*      */           return;
/*      */         } 
/*  497 */         missed = WIP.addAndGet(this, -missed);
/*  498 */       } while (missed != 0);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void doComplete(Subscriber<?> a) {
/*  505 */       a.onComplete();
/*  506 */       this.worker.dispose();
/*      */     }
/*      */     
/*      */     void doError(Subscriber<?> a, Throwable e) {
/*      */       try {
/*  511 */         a.onError(e);
/*      */       } finally {
/*      */         
/*  514 */         this.worker.dispose();
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void run() {
/*  520 */       if (this.outputFused) {
/*  521 */         runBackfused();
/*      */       }
/*  523 */       else if (this.sourceMode == 1) {
/*  524 */         runSync();
/*      */       } else {
/*      */         
/*  527 */         runAsync();
/*      */       } 
/*      */     }
/*      */     
/*      */     boolean checkTerminated(boolean d, boolean empty, Subscriber<?> a, @Nullable T v) {
/*  532 */       if (this.cancelled) {
/*  533 */         Operators.onDiscard(v, this.actual.currentContext());
/*  534 */         if (this.sourceMode == 2) {
/*      */           
/*  536 */           this.queue.clear();
/*      */         }
/*      */         else {
/*      */           
/*  540 */           Operators.onDiscardQueueWithClear(this.queue, this.actual.currentContext(), null);
/*      */         } 
/*  542 */         return true;
/*      */       } 
/*  544 */       if (d) {
/*  545 */         if (this.delayError) {
/*  546 */           if (empty) {
/*  547 */             Throwable e = this.error;
/*  548 */             if (e != null) {
/*  549 */               doError(a, e);
/*      */             } else {
/*      */               
/*  552 */               doComplete(a);
/*      */             } 
/*  554 */             return true;
/*      */           } 
/*      */         } else {
/*      */           
/*  558 */           Throwable e = this.error;
/*  559 */           if (e != null) {
/*  560 */             Operators.onDiscard(v, this.actual.currentContext());
/*  561 */             if (this.sourceMode == 2) {
/*      */               
/*  563 */               this.queue.clear();
/*      */             }
/*      */             else {
/*      */               
/*  567 */               Operators.onDiscardQueueWithClear(this.queue, this.actual.currentContext(), null);
/*      */             } 
/*  569 */             doError(a, e);
/*  570 */             return true;
/*      */           } 
/*  572 */           if (empty) {
/*  573 */             doComplete(a);
/*  574 */             return true;
/*      */           } 
/*      */         } 
/*      */       }
/*      */       
/*  579 */       return false;
/*      */     }
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     public Object scanUnsafe(Scannable.Attr key) {
/*  585 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf(this.requested); 
/*  586 */       if (key == Scannable.Attr.PARENT) return this.s; 
/*  587 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(this.cancelled); 
/*  588 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/*  589 */       if (key == Scannable.Attr.BUFFERED) return Integer.valueOf((this.queue != null) ? this.queue.size() : 0); 
/*  590 */       if (key == Scannable.Attr.ERROR) return this.error; 
/*  591 */       if (key == Scannable.Attr.DELAY_ERROR) return Boolean.valueOf(this.delayError); 
/*  592 */       if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(this.prefetch); 
/*  593 */       if (key == Scannable.Attr.RUN_ON) return this.worker; 
/*  594 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.ASYNC;
/*      */       
/*  596 */       return super.scanUnsafe(key);
/*      */     }
/*      */ 
/*      */     
/*      */     public CoreSubscriber<? super T> actual() {
/*  601 */       return this.actual;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void clear() {
/*  609 */       if (DISCARD_GUARD.getAndIncrement(this) != 0) {
/*      */         return;
/*      */       }
/*      */       
/*  613 */       int missed = 1;
/*      */       
/*      */       while (true) {
/*  616 */         Operators.onDiscardQueueWithClear(this.queue, this.actual.currentContext(), null);
/*      */         
/*  618 */         int dg = this.discardGuard;
/*  619 */         if (missed == dg) {
/*  620 */           missed = DISCARD_GUARD.addAndGet(this, -missed);
/*  621 */           if (missed == 0) {
/*      */             break;
/*      */           }
/*      */           continue;
/*      */         } 
/*  626 */         missed = dg;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isEmpty() {
/*  633 */       return this.queue.isEmpty();
/*      */     }
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     public T poll() {
/*  639 */       T v = this.queue.poll();
/*  640 */       if (v != null && this.sourceMode != 1) {
/*  641 */         long p = this.produced + 1L;
/*  642 */         if (p == this.limit) {
/*  643 */           this.produced = 0L;
/*  644 */           this.s.request(p);
/*      */         } else {
/*      */           
/*  647 */           this.produced = p;
/*      */         } 
/*      */       } 
/*  650 */       return v;
/*      */     }
/*      */ 
/*      */     
/*      */     public int requestFusion(int requestedMode) {
/*  655 */       if ((requestedMode & 0x2) != 0) {
/*  656 */         this.outputFused = true;
/*  657 */         return 2;
/*      */       } 
/*  659 */       return 0;
/*      */     }
/*      */ 
/*      */     
/*      */     public int size() {
/*  664 */       return this.queue.size();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   static final class PublishOnConditionalSubscriber<T>
/*      */     implements Fuseable.QueueSubscription<T>, Runnable, InnerOperator<T, T>
/*      */   {
/*      */     final Fuseable.ConditionalSubscriber<? super T> actual;
/*      */     
/*      */     final Scheduler.Worker worker;
/*      */     
/*      */     final Scheduler scheduler;
/*      */     
/*      */     final boolean delayError;
/*      */     
/*      */     final int prefetch;
/*      */     
/*      */     final int limit;
/*      */     
/*      */     final Supplier<? extends Queue<T>> queueSupplier;
/*      */     
/*      */     Subscription s;
/*      */     
/*      */     Queue<T> queue;
/*      */     
/*      */     volatile boolean cancelled;
/*      */     
/*      */     volatile boolean done;
/*      */     
/*      */     Throwable error;
/*      */     
/*      */     volatile int wip;
/*      */     
/*  698 */     static final AtomicIntegerFieldUpdater<PublishOnConditionalSubscriber> WIP = AtomicIntegerFieldUpdater.newUpdater(PublishOnConditionalSubscriber.class, "wip");
/*      */ 
/*      */     
/*      */     volatile int discardGuard;
/*      */ 
/*      */     
/*  704 */     static final AtomicIntegerFieldUpdater<PublishOnConditionalSubscriber> DISCARD_GUARD = AtomicIntegerFieldUpdater.newUpdater(PublishOnConditionalSubscriber.class, "discardGuard");
/*      */ 
/*      */     
/*      */     volatile long requested;
/*      */ 
/*      */     
/*  710 */     static final AtomicLongFieldUpdater<PublishOnConditionalSubscriber> REQUESTED = AtomicLongFieldUpdater.newUpdater(PublishOnConditionalSubscriber.class, "requested");
/*      */ 
/*      */ 
/*      */     
/*      */     int sourceMode;
/*      */ 
/*      */     
/*      */     long produced;
/*      */ 
/*      */     
/*      */     long consumed;
/*      */ 
/*      */     
/*      */     boolean outputFused;
/*      */ 
/*      */ 
/*      */     
/*      */     PublishOnConditionalSubscriber(Fuseable.ConditionalSubscriber<? super T> actual, Scheduler scheduler, Scheduler.Worker worker, boolean delayError, int prefetch, int lowTide, Supplier<? extends Queue<T>> queueSupplier) {
/*  728 */       this.actual = actual;
/*  729 */       this.worker = worker;
/*  730 */       this.scheduler = scheduler;
/*  731 */       this.delayError = delayError;
/*  732 */       this.prefetch = prefetch;
/*  733 */       this.queueSupplier = queueSupplier;
/*  734 */       this.limit = Operators.unboundedOrLimit(prefetch, lowTide);
/*      */     }
/*      */ 
/*      */     
/*      */     public void onSubscribe(Subscription s) {
/*  739 */       if (Operators.validate(this.s, s)) {
/*  740 */         this.s = s;
/*      */         
/*  742 */         if (s instanceof Fuseable.QueueSubscription) {
/*  743 */           Fuseable.QueueSubscription<T> f = (Fuseable.QueueSubscription<T>)s;
/*      */ 
/*      */           
/*  746 */           int m = f.requestFusion(7);
/*      */           
/*  748 */           if (m == 1) {
/*  749 */             this.sourceMode = 1;
/*  750 */             this.queue = (Queue<T>)f;
/*  751 */             this.done = true;
/*      */             
/*  753 */             this.actual.onSubscribe(this);
/*      */             return;
/*      */           } 
/*  756 */           if (m == 2) {
/*  757 */             this.sourceMode = 2;
/*  758 */             this.queue = (Queue<T>)f;
/*      */             
/*  760 */             this.actual.onSubscribe(this);
/*      */             
/*  762 */             s.request(Operators.unboundedOrPrefetch(this.prefetch));
/*      */             
/*      */             return;
/*      */           } 
/*      */         } 
/*      */         
/*  768 */         this.queue = this.queueSupplier.get();
/*      */         
/*  770 */         this.actual.onSubscribe(this);
/*      */         
/*  772 */         s.request(Operators.unboundedOrPrefetch(this.prefetch));
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void onNext(T t) {
/*  778 */       if (this.sourceMode == 2) {
/*  779 */         trySchedule(this, null, null);
/*      */         
/*      */         return;
/*      */       } 
/*  783 */       if (this.done) {
/*  784 */         Operators.onNextDropped(t, this.actual.currentContext());
/*      */         
/*      */         return;
/*      */       } 
/*  788 */       if (this.cancelled) {
/*  789 */         Operators.onDiscard(t, this.actual.currentContext());
/*      */         
/*      */         return;
/*      */       } 
/*  793 */       if (!this.queue.offer(t)) {
/*  794 */         Operators.onDiscard(t, this.actual.currentContext());
/*  795 */         this.error = Operators.onOperatorError(this.s, Exceptions.failWithOverflow("Queue is full: Reactive Streams source doesn't respect backpressure"), t, this.actual
/*  796 */             .currentContext());
/*  797 */         this.done = true;
/*      */       } 
/*  799 */       trySchedule(this, null, t);
/*      */     }
/*      */ 
/*      */     
/*      */     public void onError(Throwable t) {
/*  804 */       if (this.done) {
/*  805 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*      */         return;
/*      */       } 
/*  808 */       this.error = t;
/*  809 */       this.done = true;
/*  810 */       trySchedule(null, t, null);
/*      */     }
/*      */ 
/*      */     
/*      */     public void onComplete() {
/*  815 */       if (this.done) {
/*      */         return;
/*      */       }
/*  818 */       this.done = true;
/*  819 */       trySchedule(null, null, null);
/*      */     }
/*      */ 
/*      */     
/*      */     public void request(long n) {
/*  824 */       if (Operators.validate(n)) {
/*  825 */         Operators.addCap(REQUESTED, this, n);
/*  826 */         trySchedule(this, null, null);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void cancel() {
/*  832 */       if (this.cancelled) {
/*      */         return;
/*      */       }
/*      */       
/*  836 */       this.cancelled = true;
/*  837 */       this.s.cancel();
/*  838 */       this.worker.dispose();
/*      */       
/*  840 */       if (WIP.getAndIncrement(this) == 0) {
/*  841 */         if (this.sourceMode == 2) {
/*      */           
/*  843 */           this.queue.clear();
/*      */         }
/*  845 */         else if (!this.outputFused) {
/*      */ 
/*      */           
/*  848 */           Operators.onDiscardQueueWithClear(this.queue, this.actual.currentContext(), null);
/*      */         } 
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void trySchedule(@Nullable Subscription subscription, @Nullable Throwable suppressed, @Nullable Object dataSignal) {
/*  857 */       if (WIP.getAndIncrement(this) != 0) {
/*  858 */         if (this.cancelled) {
/*  859 */           if (this.sourceMode == 2) {
/*      */             
/*  861 */             this.queue.clear();
/*      */           }
/*      */           else {
/*      */             
/*  865 */             Operators.onDiscard(dataSignal, this.actual.currentContext());
/*      */           } 
/*      */         }
/*      */         
/*      */         return;
/*      */       } 
/*      */       try {
/*  872 */         this.worker.schedule(this);
/*      */       }
/*  874 */       catch (RejectedExecutionException ree) {
/*  875 */         if (this.sourceMode == 2) {
/*      */           
/*  877 */           this.queue.clear();
/*  878 */         } else if (this.outputFused) {
/*      */ 
/*      */           
/*  881 */           clear();
/*      */         }
/*      */         else {
/*      */           
/*  885 */           Operators.onDiscardQueueWithClear(this.queue, this.actual.currentContext(), null);
/*      */         } 
/*  887 */         this.actual.onError(Operators.onRejectedExecution(ree, subscription, suppressed, dataSignal, this.actual
/*  888 */               .currentContext()));
/*      */       } 
/*      */     }
/*      */     
/*      */     void runSync() {
/*  893 */       int missed = 1;
/*      */       
/*  895 */       Fuseable.ConditionalSubscriber<? super T> a = this.actual;
/*  896 */       Queue<T> q = this.queue;
/*      */       
/*  898 */       long e = this.produced;
/*      */ 
/*      */       
/*      */       while (true) {
/*  902 */         long r = this.requested;
/*      */         
/*  904 */         while (e != r) {
/*      */           T v;
/*      */           try {
/*  907 */             v = q.poll();
/*      */           }
/*  909 */           catch (Throwable ex) {
/*  910 */             doError((Subscriber<?>)a, Operators.onOperatorError(this.s, ex, this.actual
/*  911 */                   .currentContext()));
/*      */             
/*      */             return;
/*      */           } 
/*  915 */           if (this.cancelled) {
/*  916 */             Operators.onDiscard(v, this.actual.currentContext());
/*  917 */             Operators.onDiscardQueueWithClear(q, this.actual.currentContext(), null);
/*      */             return;
/*      */           } 
/*  920 */           if (v == null) {
/*  921 */             doComplete((Subscriber<?>)a);
/*      */             
/*      */             return;
/*      */           } 
/*  925 */           if (a.tryOnNext(v)) {
/*  926 */             e++;
/*      */           }
/*      */         } 
/*      */         
/*  930 */         if (this.cancelled) {
/*  931 */           Operators.onDiscardQueueWithClear(q, this.actual.currentContext(), null);
/*      */           
/*      */           return;
/*      */         } 
/*  935 */         if (q.isEmpty()) {
/*  936 */           doComplete((Subscriber<?>)a);
/*      */           
/*      */           return;
/*      */         } 
/*  940 */         int w = this.wip;
/*  941 */         if (missed == w) {
/*  942 */           this.produced = e;
/*  943 */           missed = WIP.addAndGet(this, -missed);
/*  944 */           if (missed == 0) {
/*      */             break;
/*      */           }
/*      */           continue;
/*      */         } 
/*  949 */         missed = w;
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     void runAsync() {
/*  955 */       int missed = 1;
/*      */       
/*  957 */       Fuseable.ConditionalSubscriber<? super T> a = this.actual;
/*  958 */       Queue<T> q = this.queue;
/*      */       
/*  960 */       long emitted = this.produced;
/*  961 */       long polled = this.consumed;
/*      */ 
/*      */       
/*      */       while (true) {
/*  965 */         long r = this.requested;
/*      */         
/*  967 */         while (emitted != r) {
/*  968 */           T v; boolean d = this.done;
/*      */           
/*      */           try {
/*  971 */             v = q.poll();
/*      */           }
/*  973 */           catch (Throwable ex) {
/*  974 */             Exceptions.throwIfFatal(ex);
/*  975 */             this.s.cancel();
/*      */             
/*  977 */             q.clear();
/*      */             
/*  979 */             doError((Subscriber<?>)a, Operators.onOperatorError(ex, this.actual.currentContext()));
/*      */             return;
/*      */           } 
/*  982 */           boolean empty = (v == null);
/*      */           
/*  984 */           if (checkTerminated(d, empty, (Subscriber<?>)a, v)) {
/*      */             return;
/*      */           }
/*      */           
/*  988 */           if (empty) {
/*      */             break;
/*      */           }
/*      */           
/*  992 */           if (a.tryOnNext(v)) {
/*  993 */             emitted++;
/*      */           }
/*      */           
/*  996 */           polled++;
/*      */           
/*  998 */           if (polled == this.limit) {
/*  999 */             this.s.request(polled);
/* 1000 */             polled = 0L;
/*      */           } 
/*      */         } 
/*      */         
/* 1004 */         if (emitted == r && checkTerminated(this.done, q.isEmpty(), (Subscriber<?>)a, null)) {
/*      */           return;
/*      */         }
/*      */         
/* 1008 */         int w = this.wip;
/* 1009 */         if (missed == w) {
/* 1010 */           this.produced = emitted;
/* 1011 */           this.consumed = polled;
/* 1012 */           missed = WIP.addAndGet(this, -missed);
/* 1013 */           if (missed == 0) {
/*      */             break;
/*      */           }
/*      */           continue;
/*      */         } 
/* 1018 */         missed = w;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     void runBackfused() {
/* 1025 */       int missed = 1;
/*      */ 
/*      */       
/*      */       do {
/* 1029 */         if (this.cancelled) {
/*      */ 
/*      */           
/* 1032 */           clear();
/*      */           
/*      */           return;
/*      */         } 
/* 1036 */         boolean d = this.done;
/*      */         
/* 1038 */         this.actual.onNext(null);
/*      */         
/* 1040 */         if (d) {
/* 1041 */           Throwable e = this.error;
/* 1042 */           if (e != null) {
/* 1043 */             doError((Subscriber<?>)this.actual, e);
/*      */           } else {
/*      */             
/* 1046 */             doComplete((Subscriber<?>)this.actual);
/*      */           } 
/*      */           
/*      */           return;
/*      */         } 
/* 1051 */         missed = WIP.addAndGet(this, -missed);
/* 1052 */       } while (missed != 0);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void run() {
/* 1060 */       if (this.outputFused) {
/* 1061 */         runBackfused();
/*      */       }
/* 1063 */       else if (this.sourceMode == 1) {
/* 1064 */         runSync();
/*      */       } else {
/*      */         
/* 1067 */         runAsync();
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public CoreSubscriber<? super T> actual() {
/* 1073 */       return (CoreSubscriber<? super T>)this.actual;
/*      */     }
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     public Object scanUnsafe(Scannable.Attr key) {
/* 1079 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf(this.requested); 
/* 1080 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 1081 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(this.cancelled); 
/* 1082 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 1083 */       if (key == Scannable.Attr.BUFFERED) return Integer.valueOf((this.queue != null) ? this.queue.size() : 0); 
/* 1084 */       if (key == Scannable.Attr.ERROR) return this.error; 
/* 1085 */       if (key == Scannable.Attr.DELAY_ERROR) return Boolean.valueOf(this.delayError); 
/* 1086 */       if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(this.prefetch); 
/* 1087 */       if (key == Scannable.Attr.RUN_ON) return this.worker; 
/* 1088 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.ASYNC;
/*      */       
/* 1090 */       return super.scanUnsafe(key);
/*      */     }
/*      */     
/*      */     void doComplete(Subscriber<?> a) {
/* 1094 */       a.onComplete();
/* 1095 */       this.worker.dispose();
/*      */     }
/*      */     
/*      */     void doError(Subscriber<?> a, Throwable e) {
/*      */       try {
/* 1100 */         a.onError(e);
/*      */       } finally {
/*      */         
/* 1103 */         this.worker.dispose();
/*      */       } 
/*      */     }
/*      */     
/*      */     boolean checkTerminated(boolean d, boolean empty, Subscriber<?> a, @Nullable T v) {
/* 1108 */       if (this.cancelled) {
/* 1109 */         Operators.onDiscard(v, this.actual.currentContext());
/* 1110 */         if (this.sourceMode == 2) {
/*      */           
/* 1112 */           this.queue.clear();
/*      */         }
/*      */         else {
/*      */           
/* 1116 */           Operators.onDiscardQueueWithClear(this.queue, this.actual.currentContext(), null);
/*      */         } 
/* 1118 */         return true;
/*      */       } 
/* 1120 */       if (d) {
/* 1121 */         if (this.delayError) {
/* 1122 */           if (empty) {
/* 1123 */             Throwable e = this.error;
/* 1124 */             if (e != null) {
/* 1125 */               doError(a, e);
/*      */             } else {
/*      */               
/* 1128 */               doComplete(a);
/*      */             } 
/* 1130 */             return true;
/*      */           } 
/*      */         } else {
/*      */           
/* 1134 */           Throwable e = this.error;
/* 1135 */           if (e != null) {
/* 1136 */             Operators.onDiscard(v, this.actual.currentContext());
/* 1137 */             if (this.sourceMode == 2) {
/*      */               
/* 1139 */               this.queue.clear();
/*      */             }
/*      */             else {
/*      */               
/* 1143 */               Operators.onDiscardQueueWithClear(this.queue, this.actual.currentContext(), null);
/*      */             } 
/* 1145 */             doError(a, e);
/* 1146 */             return true;
/*      */           } 
/* 1148 */           if (empty) {
/* 1149 */             doComplete(a);
/* 1150 */             return true;
/*      */           } 
/*      */         } 
/*      */       }
/*      */       
/* 1155 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void clear() {
/* 1163 */       if (DISCARD_GUARD.getAndIncrement(this) != 0) {
/*      */         return;
/*      */       }
/*      */       
/* 1167 */       int missed = 1;
/*      */       
/*      */       while (true) {
/* 1170 */         Operators.onDiscardQueueWithClear(this.queue, this.actual.currentContext(), null);
/*      */         
/* 1172 */         int dg = this.discardGuard;
/* 1173 */         if (missed == dg) {
/* 1174 */           missed = DISCARD_GUARD.addAndGet(this, -missed);
/* 1175 */           if (missed == 0) {
/*      */             break;
/*      */           }
/*      */           continue;
/*      */         } 
/* 1180 */         missed = dg;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isEmpty() {
/* 1187 */       return this.queue.isEmpty();
/*      */     }
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     public T poll() {
/* 1193 */       T v = this.queue.poll();
/* 1194 */       if (v != null && this.sourceMode != 1) {
/* 1195 */         long p = this.consumed + 1L;
/* 1196 */         if (p == this.limit) {
/* 1197 */           this.consumed = 0L;
/* 1198 */           this.s.request(p);
/*      */         } else {
/*      */           
/* 1201 */           this.consumed = p;
/*      */         } 
/*      */       } 
/* 1204 */       return v;
/*      */     }
/*      */ 
/*      */     
/*      */     public int requestFusion(int requestedMode) {
/* 1209 */       if ((requestedMode & 0x2) != 0) {
/* 1210 */         this.outputFused = true;
/* 1211 */         return 2;
/*      */       } 
/* 1213 */       return 0;
/*      */     }
/*      */ 
/*      */     
/*      */     public int size() {
/* 1218 */       return this.queue.size();
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\FluxPublishOn.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */