/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.Objects;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MonoFirstWithSignal<T>
/*     */   extends Mono<T>
/*     */   implements SourceProducer<T>
/*     */ {
/*     */   final Mono<? extends T>[] array;
/*     */   final Iterable<? extends Mono<? extends T>> iterable;
/*     */   
/*     */   @SafeVarargs
/*     */   MonoFirstWithSignal(Mono<? extends T>... array) {
/*  42 */     this.array = Objects.<Mono<? extends T>[]>requireNonNull(array, "array");
/*  43 */     this.iterable = null;
/*     */   }
/*     */   
/*     */   MonoFirstWithSignal(Iterable<? extends Mono<? extends T>> iterable) {
/*  47 */     this.array = null;
/*  48 */     this.iterable = Objects.<Iterable<? extends Mono<? extends T>>>requireNonNull(iterable);
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   Mono<T> orAdditionalSource(Mono<? extends T> other) {
/*  53 */     if (this.array != null) {
/*  54 */       int n = this.array.length;
/*  55 */       Mono[] arrayOfMono = new Mono[n + 1];
/*  56 */       System.arraycopy(this.array, 0, arrayOfMono, 0, n);
/*  57 */       arrayOfMono[n] = other;
/*     */       
/*  59 */       return new MonoFirstWithSignal((Mono<? extends T>[])arrayOfMono);
/*     */     } 
/*  61 */     return null;
/*     */   }
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super T> actual) {
/*     */     Publisher[] arrayOfPublisher;
/*     */     int n;
/*  67 */     Mono<? extends T>[] arrayOfMono = this.array;
/*     */     
/*  69 */     if (arrayOfMono == null) {
/*  70 */       Iterator<? extends Publisher<? extends T>> it; n = 0;
/*  71 */       arrayOfPublisher = new Publisher[8];
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/*  76 */         it = Objects.<Iterator<? extends Publisher<? extends T>>>requireNonNull((Iterator)this.iterable.iterator(), "The iterator returned is null");
/*     */       }
/*  78 */       catch (Throwable e) {
/*  79 */         Operators.error((Subscriber<?>)actual, Operators.onOperatorError(e, actual
/*  80 */               .currentContext()));
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/*     */       while (true) {
/*     */         boolean b;
/*     */         Publisher<? extends T> p;
/*     */         try {
/*  89 */           b = it.hasNext();
/*     */         }
/*  91 */         catch (Throwable e) {
/*  92 */           Operators.error((Subscriber<?>)actual, Operators.onOperatorError(e, actual
/*  93 */                 .currentContext()));
/*     */           
/*     */           return;
/*     */         } 
/*  97 */         if (!b) {
/*     */           break;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         try {
/* 104 */           p = Objects.<Publisher<? extends T>>requireNonNull(it.next(), "The Publisher returned by the iterator is null");
/*     */         
/*     */         }
/* 107 */         catch (Throwable e) {
/* 108 */           Operators.error((Subscriber<?>)actual, Operators.onOperatorError(e, actual
/* 109 */                 .currentContext()));
/*     */           
/*     */           return;
/*     */         } 
/* 113 */         if (n == arrayOfPublisher.length) {
/* 114 */           Publisher[] arrayOfPublisher1 = new Publisher[n + (n >> 2)];
/* 115 */           System.arraycopy(arrayOfPublisher, 0, arrayOfPublisher1, 0, n);
/* 116 */           arrayOfPublisher = arrayOfPublisher1;
/*     */         } 
/* 118 */         arrayOfPublisher[n++] = p;
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 123 */       n = arrayOfPublisher.length;
/*     */     } 
/*     */     
/* 126 */     if (n == 0) {
/* 127 */       Operators.complete((Subscriber<?>)actual);
/*     */       return;
/*     */     } 
/* 130 */     if (n == 1) {
/* 131 */       Publisher<? extends T> p = arrayOfPublisher[0];
/*     */       
/* 133 */       if (p == null) {
/* 134 */         Operators.error((Subscriber<?>)actual, 
/* 135 */             Operators.onOperatorError(new NullPointerException("The single source Publisher is null"), actual
/* 136 */               .currentContext()));
/*     */       } else {
/*     */         
/* 139 */         p.subscribe((Subscriber)actual);
/*     */       } 
/*     */       
/*     */       return;
/*     */     } 
/* 144 */     FluxFirstWithSignal.RaceCoordinator<T> coordinator = new FluxFirstWithSignal.RaceCoordinator<>(n);
/*     */ 
/*     */     
/* 147 */     coordinator.subscribe((Publisher<? extends T>[])arrayOfPublisher, n, actual);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/* 152 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 153 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\MonoFirstWithSignal.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */