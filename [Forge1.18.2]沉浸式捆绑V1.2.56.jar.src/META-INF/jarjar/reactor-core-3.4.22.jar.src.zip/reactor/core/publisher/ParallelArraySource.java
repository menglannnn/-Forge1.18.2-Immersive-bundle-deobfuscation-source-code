/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import org.reactivestreams.Publisher;
/*    */ import org.reactivestreams.Subscriber;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Scannable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class ParallelArraySource<T>
/*    */   extends ParallelFlux<T>
/*    */   implements SourceProducer<T>
/*    */ {
/*    */   final Publisher<T>[] sources;
/*    */   
/*    */   ParallelArraySource(Publisher<T>[] sources) {
/* 33 */     if (sources == null || sources.length == 0) {
/* 34 */       throw new IllegalArgumentException("Zero publishers not supported");
/*    */     }
/* 36 */     this.sources = sources;
/*    */   }
/*    */ 
/*    */   
/*    */   public int parallelism() {
/* 41 */     return this.sources.length;
/*    */   }
/*    */ 
/*    */   
/*    */   public void subscribe(CoreSubscriber<? super T>[] subscribers) {
/* 46 */     if (!validate((Subscriber<?>[])subscribers)) {
/*    */       return;
/*    */     }
/*    */     
/* 50 */     int n = subscribers.length;
/*    */     
/* 52 */     for (int i = 0; i < n; i++) {
/* 53 */       Flux.<T>from(this.sources[i]).subscribe(subscribers[i]);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 59 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 60 */     return super.scanUnsafe(key);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\ParallelArraySource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */