/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.util.stream.Stream;
/*    */ import reactor.core.Scannable;
/*    */ import reactor.util.context.Context;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SinkOneSerialized<T>
/*    */   extends SinkEmptySerialized<T>
/*    */   implements InternalOneSink<T>, ContextHolder
/*    */ {
/*    */   final Sinks.One<T> sinkOne;
/*    */   
/*    */   public SinkOneSerialized(Sinks.One<T> sinkOne, ContextHolder contextHolder) {
/* 26 */     super(sinkOne, contextHolder);
/* 27 */     this.sinkOne = sinkOne;
/*    */   }
/*    */ 
/*    */   
/*    */   public Sinks.EmitResult tryEmitValue(T t) {
/* 32 */     Thread currentThread = Thread.currentThread();
/* 33 */     if (!tryAcquire(currentThread)) {
/* 34 */       return Sinks.EmitResult.FAIL_NON_SERIALIZED;
/*    */     }
/*    */     
/*    */     try {
/* 38 */       return this.sinkOne.tryEmitValue(t);
/*    */     } finally {
/*    */       
/* 41 */       if (WIP.decrementAndGet(this) == 0)
/* 42 */         LOCKED_AT.compareAndSet(this, currentThread, null); 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\SinkOneSerialized.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */