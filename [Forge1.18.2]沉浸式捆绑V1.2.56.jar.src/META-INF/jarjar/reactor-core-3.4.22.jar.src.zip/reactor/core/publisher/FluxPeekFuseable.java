/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.LongConsumer;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxPeekFuseable<T>
/*     */   extends InternalFluxOperator<T, T>
/*     */   implements Fuseable, SignalPeek<T>
/*     */ {
/*     */   final Consumer<? super Subscription> onSubscribeCall;
/*     */   final Consumer<? super T> onNextCall;
/*     */   final Consumer<? super Throwable> onErrorCall;
/*     */   final Runnable onCompleteCall;
/*     */   final Runnable onAfterTerminateCall;
/*     */   final LongConsumer onRequestCall;
/*     */   final Runnable onCancelCall;
/*     */   
/*     */   FluxPeekFuseable(Flux<? extends T> source, @Nullable Consumer<? super Subscription> onSubscribeCall, @Nullable Consumer<? super T> onNextCall, @Nullable Consumer<? super Throwable> onErrorCall, @Nullable Runnable onCompleteCall, @Nullable Runnable onAfterTerminateCall, @Nullable LongConsumer onRequestCall, @Nullable Runnable onCancelCall) {
/*  68 */     super(source);
/*     */     
/*  70 */     this.onSubscribeCall = onSubscribeCall;
/*  71 */     this.onNextCall = onNextCall;
/*  72 */     this.onErrorCall = onErrorCall;
/*  73 */     this.onCompleteCall = onCompleteCall;
/*  74 */     this.onAfterTerminateCall = onAfterTerminateCall;
/*  75 */     this.onRequestCall = onRequestCall;
/*  76 */     this.onCancelCall = onCancelCall;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/*  82 */     if (actual instanceof Fuseable.ConditionalSubscriber) {
/*  83 */       return new PeekFuseableConditionalSubscriber<>((Fuseable.ConditionalSubscriber<? super T>)actual, this);
/*     */     }
/*  85 */     return new PeekFuseableSubscriber<>(actual, this);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  90 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  91 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class PeekFuseableSubscriber<T>
/*     */     implements InnerOperator<T, T>, Fuseable.QueueSubscription<T>
/*     */   {
/*     */     final CoreSubscriber<? super T> actual;
/*     */     
/*     */     final SignalPeek<T> parent;
/*     */     
/*     */     Fuseable.QueueSubscription<T> s;
/*     */     
/*     */     int sourceMode;
/*     */     
/*     */     volatile boolean done;
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 110 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 111 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 112 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 114 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     PeekFuseableSubscriber(CoreSubscriber<? super T> actual, SignalPeek<T> parent) {
/* 119 */       this.actual = actual;
/* 120 */       this.parent = parent;
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/* 125 */       Context c = this.actual.currentContext();
/* 126 */       Consumer<? super Context> contextHook = this.parent.onCurrentContextCall();
/* 127 */       if (!c.isEmpty() && contextHook != null) {
/* 128 */         contextHook.accept(c);
/*     */       }
/* 130 */       return c;
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 135 */       LongConsumer requestHook = this.parent.onRequestCall();
/* 136 */       if (requestHook != null) {
/*     */         try {
/* 138 */           requestHook.accept(n);
/*     */         }
/* 140 */         catch (Throwable e) {
/* 141 */           Operators.onOperatorError(e, this.actual.currentContext());
/*     */         } 
/*     */       }
/* 144 */       this.s.request(n);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 149 */       Runnable cancelHook = this.parent.onCancelCall();
/* 150 */       if (cancelHook != null) {
/*     */         try {
/* 152 */           cancelHook.run();
/*     */         }
/* 154 */         catch (Throwable e) {
/* 155 */           onError(Operators.onOperatorError((Subscription)this.s, e, this.actual.currentContext()));
/*     */           return;
/*     */         } 
/*     */       }
/* 159 */       this.s.cancel();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 165 */       if (Operators.validate((Subscription)this.s, s)) {
/* 166 */         Consumer<? super Subscription> subscribeHook = this.parent.onSubscribeCall();
/* 167 */         if (subscribeHook != null) {
/*     */           try {
/* 169 */             subscribeHook.accept(s);
/*     */           }
/* 171 */           catch (Throwable e) {
/* 172 */             Operators.error((Subscriber<?>)this.actual, Operators.onOperatorError(s, e, this.actual
/* 173 */                   .currentContext()));
/*     */             return;
/*     */           } 
/*     */         }
/* 177 */         this.s = (Fuseable.QueueSubscription<T>)s;
/* 178 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 184 */       if (this.sourceMode == 2) {
/* 185 */         this.actual.onNext(null);
/*     */       } else {
/*     */         
/* 188 */         if (this.done) {
/* 189 */           Operators.onNextDropped(t, this.actual.currentContext());
/*     */           
/*     */           return;
/*     */         } 
/* 193 */         Consumer<? super T> nextHook = this.parent.onNextCall();
/* 194 */         if (nextHook != null) {
/*     */           try {
/* 196 */             nextHook.accept(t);
/*     */           }
/* 198 */           catch (Throwable e) {
/* 199 */             Throwable e_ = Operators.onNextError(t, e, this.actual.currentContext(), (Subscription)this.s);
/* 200 */             if (e_ == null) {
/* 201 */               request(1L);
/*     */               
/*     */               return;
/*     */             } 
/* 205 */             onError(e_);
/*     */             
/*     */             return;
/*     */           } 
/*     */         }
/* 210 */         this.actual.onNext(t);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 216 */       if (this.done) {
/* 217 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*     */         return;
/*     */       } 
/* 220 */       this.done = true;
/* 221 */       Consumer<? super Throwable> errorHook = this.parent.onErrorCall();
/* 222 */       if (errorHook != null) {
/* 223 */         Exceptions.throwIfFatal(t);
/*     */         try {
/* 225 */           errorHook.accept(t);
/*     */         }
/* 227 */         catch (Throwable e) {
/*     */           
/* 229 */           t = Operators.onOperatorError(null, e, t, this.actual.currentContext());
/*     */         } 
/*     */       } 
/*     */       
/*     */       try {
/* 234 */         this.actual.onError(t);
/*     */       }
/* 236 */       catch (UnsupportedOperationException use) {
/* 237 */         if (errorHook == null || (
/* 238 */           !Exceptions.isErrorCallbackNotImplemented(use) && use.getCause() != t)) {
/* 239 */           throw use;
/*     */         }
/*     */       } 
/*     */       
/* 243 */       Runnable afterTerminateHook = this.parent.onAfterTerminateCall();
/* 244 */       if (afterTerminateHook != null) {
/*     */         try {
/* 246 */           afterTerminateHook.run();
/*     */         }
/* 248 */         catch (Throwable e) {
/* 249 */           FluxPeek.afterErrorWithFailure(this.parent, e, t, this.actual.currentContext());
/*     */         } 
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 256 */       if (this.done) {
/*     */         return;
/*     */       }
/*     */       
/* 260 */       if (this.sourceMode == 2) {
/* 261 */         this.done = true;
/* 262 */         this.actual.onComplete();
/*     */       } else {
/*     */         
/* 265 */         Runnable completeHook = this.parent.onCompleteCall();
/* 266 */         if (completeHook != null) {
/*     */           try {
/* 268 */             completeHook.run();
/*     */           }
/* 270 */           catch (Throwable e) {
/* 271 */             onError(Operators.onOperatorError((Subscription)this.s, e, this.actual.currentContext()));
/*     */             return;
/*     */           } 
/*     */         }
/* 275 */         this.done = true;
/*     */         
/* 277 */         this.actual.onComplete();
/*     */         
/* 279 */         Runnable afterTerminateHook = this.parent.onAfterTerminateCall();
/* 280 */         if (afterTerminateHook != null) {
/*     */           try {
/* 282 */             afterTerminateHook.run();
/*     */           }
/* 284 */           catch (Throwable e) {
/* 285 */             FluxPeek.afterCompleteWithFailure(this.parent, e, this.actual.currentContext());
/*     */           } 
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 293 */       return this.actual;
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     public T poll() {
/*     */       T v;
/* 299 */       boolean d = this.done;
/*     */       
/*     */       try {
/* 302 */         v = (T)this.s.poll();
/*     */       }
/* 304 */       catch (Throwable e) {
/* 305 */         Consumer<? super Throwable> errorHook = this.parent.onErrorCall();
/* 306 */         if (errorHook != null) {
/*     */           try {
/* 308 */             errorHook.accept(e);
/*     */           }
/* 310 */           catch (Throwable errorCallbackError) {
/* 311 */             throw Exceptions.propagate(Operators.onOperatorError(this.s, errorCallbackError, e, this.actual
/* 312 */                   .currentContext()));
/*     */           } 
/*     */         }
/* 315 */         Runnable afterTerminateHook = this.parent.onAfterTerminateCall();
/* 316 */         if (afterTerminateHook != null) {
/*     */           try {
/* 318 */             afterTerminateHook.run();
/*     */           }
/* 320 */           catch (Throwable afterTerminateCallbackError) {
/* 321 */             throw Exceptions.propagate(Operators.onOperatorError(this.s, afterTerminateCallbackError, e, this.actual
/* 322 */                   .currentContext()));
/*     */           } 
/*     */         }
/* 325 */         throw Exceptions.propagate(Operators.onOperatorError(this.s, e, this.actual
/* 326 */               .currentContext()));
/*     */       } 
/*     */       
/* 329 */       Consumer<? super T> nextHook = this.parent.onNextCall();
/* 330 */       if (v != null && nextHook != null) {
/*     */         try {
/* 332 */           nextHook.accept(v);
/*     */         }
/* 334 */         catch (Throwable e) {
/* 335 */           Throwable e_ = Operators.onNextError(v, e, this.actual.currentContext(), (Subscription)this.s);
/* 336 */           if (e_ == null) {
/* 337 */             return poll();
/*     */           }
/*     */           
/* 340 */           throw Exceptions.propagate(e_);
/*     */         } 
/*     */       }
/*     */       
/* 344 */       if (v == null && (d || this.sourceMode == 1)) {
/* 345 */         Runnable call = this.parent.onCompleteCall();
/* 346 */         if (call != null) {
/* 347 */           call.run();
/*     */         }
/* 349 */         call = this.parent.onAfterTerminateCall();
/* 350 */         if (call != null) {
/* 351 */           call.run();
/*     */         }
/*     */       } 
/* 354 */       return v;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isEmpty() {
/* 359 */       return this.s.isEmpty();
/*     */     }
/*     */ 
/*     */     
/*     */     public void clear() {
/* 364 */       this.s.clear();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int requestFusion(int requestedMode) {
/* 370 */       if ((requestedMode & 0x4) != 0) {
/* 371 */         return 0;
/*     */       }
/*     */       
/* 374 */       int m = this.s.requestFusion(requestedMode);
/*     */       
/* 376 */       this.sourceMode = m;
/* 377 */       return m;
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 382 */       return this.s.size();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class PeekFuseableConditionalSubscriber<T>
/*     */     implements Fuseable.ConditionalSubscriber<T>, InnerOperator<T, T>, Fuseable.QueueSubscription<T>
/*     */   {
/*     */     final Fuseable.ConditionalSubscriber<? super T> actual;
/*     */     
/*     */     final SignalPeek<T> parent;
/*     */     
/*     */     Fuseable.QueueSubscription<T> s;
/*     */     
/*     */     int sourceMode;
/*     */     
/*     */     volatile boolean done;
/*     */ 
/*     */     
/*     */     PeekFuseableConditionalSubscriber(Fuseable.ConditionalSubscriber<? super T> actual, SignalPeek<T> parent) {
/* 402 */       this.actual = actual;
/* 403 */       this.parent = parent;
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/* 408 */       Context c = this.actual.currentContext();
/* 409 */       Consumer<? super Context> contextHook = this.parent.onCurrentContextCall();
/* 410 */       if (!c.isEmpty() && contextHook != null) {
/* 411 */         contextHook.accept(c);
/*     */       }
/* 413 */       return c;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 419 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 420 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 421 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 423 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 428 */       LongConsumer requestHook = this.parent.onRequestCall();
/* 429 */       if (requestHook != null) {
/*     */         try {
/* 431 */           requestHook.accept(n);
/*     */         }
/* 433 */         catch (Throwable e) {
/* 434 */           Operators.onOperatorError(e, this.actual.currentContext());
/*     */         } 
/*     */       }
/* 437 */       this.s.request(n);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 442 */       Runnable cancelHook = this.parent.onCancelCall();
/* 443 */       if (cancelHook != null) {
/*     */         try {
/* 445 */           cancelHook.run();
/*     */         }
/* 447 */         catch (Throwable e) {
/* 448 */           onError(Operators.onOperatorError((Subscription)this.s, e, this.actual.currentContext()));
/*     */           return;
/*     */         } 
/*     */       }
/* 452 */       this.s.cancel();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 458 */       if (Operators.validate((Subscription)this.s, s)) {
/* 459 */         Consumer<? super Subscription> subscribeHook = this.parent.onSubscribeCall();
/* 460 */         if (subscribeHook != null) {
/*     */           try {
/* 462 */             subscribeHook.accept(s);
/*     */           }
/* 464 */           catch (Throwable e) {
/* 465 */             Operators.error((Subscriber<?>)this.actual, Operators.onOperatorError(s, e, this.actual
/* 466 */                   .currentContext()));
/*     */             return;
/*     */           } 
/*     */         }
/* 470 */         this.s = (Fuseable.QueueSubscription<T>)s;
/* 471 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 477 */       if (this.sourceMode == 2) {
/* 478 */         this.actual.onNext(null);
/*     */       } else {
/*     */         
/* 481 */         if (this.done) {
/* 482 */           Operators.onNextDropped(t, this.actual.currentContext());
/*     */           
/*     */           return;
/*     */         } 
/* 486 */         Consumer<? super T> nextHook = this.parent.onNextCall();
/* 487 */         if (nextHook != null) {
/*     */           try {
/* 489 */             nextHook.accept(t);
/*     */           }
/* 491 */           catch (Throwable e) {
/* 492 */             Throwable e_ = Operators.onNextError(t, e, this.actual.currentContext(), (Subscription)this.s);
/* 493 */             if (e_ == null) {
/* 494 */               request(1L);
/*     */               
/*     */               return;
/*     */             } 
/* 498 */             onError(e_);
/*     */             
/*     */             return;
/*     */           } 
/*     */         }
/* 503 */         this.actual.onNext(t);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean tryOnNext(T t) {
/* 509 */       if (this.done) {
/* 510 */         Operators.onNextDropped(t, this.actual.currentContext());
/* 511 */         return false;
/*     */       } 
/*     */       
/* 514 */       Consumer<? super T> nextHook = this.parent.onNextCall();
/* 515 */       if (nextHook != null) {
/*     */         try {
/* 517 */           nextHook.accept(t);
/*     */         }
/* 519 */         catch (Throwable e) {
/* 520 */           Throwable e_ = Operators.onNextError(t, e, this.actual.currentContext(), (Subscription)this.s);
/* 521 */           if (e_ == null) {
/* 522 */             return false;
/*     */           }
/*     */           
/* 525 */           onError(e_);
/* 526 */           return true;
/*     */         } 
/*     */       }
/*     */       
/* 530 */       return this.actual.tryOnNext(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 535 */       if (this.done) {
/* 536 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*     */         return;
/*     */       } 
/* 539 */       this.done = true;
/* 540 */       Consumer<? super Throwable> errorHook = this.parent.onErrorCall();
/* 541 */       if (errorHook != null) {
/* 542 */         Exceptions.throwIfFatal(t);
/*     */         try {
/* 544 */           errorHook.accept(t);
/*     */         }
/* 546 */         catch (Throwable e) {
/*     */           
/* 548 */           t = Operators.onOperatorError(null, e, t, this.actual.currentContext());
/*     */         } 
/*     */       } 
/*     */       
/*     */       try {
/* 553 */         this.actual.onError(t);
/*     */       }
/* 555 */       catch (UnsupportedOperationException use) {
/* 556 */         if (errorHook == null || (
/* 557 */           !Exceptions.isErrorCallbackNotImplemented(use) && use.getCause() != t)) {
/* 558 */           throw use;
/*     */         }
/*     */       } 
/*     */       
/* 562 */       Runnable afterTerminateHook = this.parent.onAfterTerminateCall();
/* 563 */       if (afterTerminateHook != null) {
/*     */         try {
/* 565 */           afterTerminateHook.run();
/*     */         }
/* 567 */         catch (Throwable e) {
/* 568 */           FluxPeek.afterErrorWithFailure(this.parent, e, t, this.actual.currentContext());
/*     */         } 
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 575 */       if (this.done) {
/*     */         return;
/*     */       }
/*     */       
/* 579 */       if (this.sourceMode == 2) {
/* 580 */         this.done = true;
/* 581 */         this.actual.onComplete();
/*     */       } else {
/*     */         
/* 584 */         Runnable completeHook = this.parent.onCompleteCall();
/* 585 */         if (completeHook != null) {
/*     */           try {
/* 587 */             completeHook.run();
/*     */           }
/* 589 */           catch (Throwable e) {
/* 590 */             onError(Operators.onOperatorError((Subscription)this.s, e, this.actual.currentContext()));
/*     */             return;
/*     */           } 
/*     */         }
/* 594 */         this.done = true;
/* 595 */         this.actual.onComplete();
/*     */         
/* 597 */         Runnable afterTerminateHook = this.parent.onAfterTerminateCall();
/* 598 */         if (afterTerminateHook != null) {
/*     */           try {
/* 600 */             afterTerminateHook.run();
/*     */           }
/* 602 */           catch (Throwable e) {
/* 603 */             FluxPeek.afterCompleteWithFailure(this.parent, e, this.actual.currentContext());
/*     */           } 
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 611 */       return (CoreSubscriber<? super T>)this.actual;
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     public T poll() {
/*     */       T v;
/* 617 */       boolean d = this.done;
/*     */       
/*     */       try {
/* 620 */         v = (T)this.s.poll();
/*     */       }
/* 622 */       catch (Throwable e) {
/* 623 */         Consumer<? super Throwable> errorHook = this.parent.onErrorCall();
/* 624 */         if (errorHook != null) {
/*     */           try {
/* 626 */             errorHook.accept(e);
/*     */           }
/* 628 */           catch (Throwable errorCallbackError) {
/* 629 */             throw Exceptions.propagate(Operators.onOperatorError(this.s, errorCallbackError, e, this.actual
/* 630 */                   .currentContext()));
/*     */           } 
/*     */         }
/* 633 */         Runnable afterTerminateHook = this.parent.onAfterTerminateCall();
/* 634 */         if (afterTerminateHook != null) {
/*     */           try {
/* 636 */             afterTerminateHook.run();
/*     */           }
/* 638 */           catch (Throwable afterTerminateCallbackError) {
/* 639 */             throw Exceptions.propagate(Operators.onOperatorError(this.s, afterTerminateCallbackError, e, this.actual
/* 640 */                   .currentContext()));
/*     */           } 
/*     */         }
/* 643 */         throw Exceptions.propagate(Operators.onOperatorError(this.s, e, this.actual
/* 644 */               .currentContext()));
/*     */       } 
/*     */       
/* 647 */       Consumer<? super T> nextHook = this.parent.onNextCall();
/* 648 */       if (v != null && nextHook != null) {
/*     */         try {
/* 650 */           nextHook.accept(v);
/*     */         }
/* 652 */         catch (Throwable e) {
/* 653 */           Throwable e_ = Operators.onNextError(v, e, this.actual.currentContext(), (Subscription)this.s);
/* 654 */           if (e_ == null) {
/* 655 */             return poll();
/*     */           }
/*     */           
/* 658 */           throw Exceptions.propagate(e_);
/*     */         } 
/*     */       }
/*     */       
/* 662 */       if (v == null && (d || this.sourceMode == 1)) {
/* 663 */         Runnable call = this.parent.onCompleteCall();
/* 664 */         if (call != null) {
/* 665 */           call.run();
/*     */         }
/* 667 */         call = this.parent.onAfterTerminateCall();
/* 668 */         if (call != null) {
/* 669 */           call.run();
/*     */         }
/*     */       } 
/* 672 */       return v;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isEmpty() {
/* 677 */       return this.s.isEmpty();
/*     */     }
/*     */ 
/*     */     
/*     */     public void clear() {
/* 682 */       this.s.clear();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int requestFusion(int requestedMode) {
/* 688 */       if ((requestedMode & 0x4) != 0) {
/* 689 */         return 0;
/*     */       }
/*     */       
/* 692 */       int m = this.s.requestFusion(requestedMode);
/*     */       
/* 694 */       this.sourceMode = m;
/* 695 */       return m;
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 700 */       return this.s.size();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Consumer<? super Subscription> onSubscribeCall() {
/* 707 */     return this.onSubscribeCall;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Consumer<? super T> onNextCall() {
/* 713 */     return this.onNextCall;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Consumer<? super Throwable> onErrorCall() {
/* 719 */     return this.onErrorCall;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Runnable onCompleteCall() {
/* 725 */     return this.onCompleteCall;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Runnable onAfterTerminateCall() {
/* 731 */     return this.onAfterTerminateCall;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public LongConsumer onRequestCall() {
/* 737 */     return this.onRequestCall;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Runnable onCancelCall() {
/* 743 */     return this.onCancelCall;
/*     */   }
/*     */ 
/*     */   
/*     */   static final class PeekConditionalSubscriber<T>
/*     */     implements Fuseable.ConditionalSubscriber<T>, InnerOperator<T, T>
/*     */   {
/*     */     final Fuseable.ConditionalSubscriber<? super T> actual;
/*     */     
/*     */     final SignalPeek<T> parent;
/*     */     
/*     */     Subscription s;
/*     */     
/*     */     boolean done;
/*     */     
/*     */     PeekConditionalSubscriber(Fuseable.ConditionalSubscriber<? super T> actual, SignalPeek<T> parent) {
/* 759 */       this.actual = actual;
/* 760 */       this.parent = parent;
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/* 765 */       Context c = this.actual.currentContext();
/* 766 */       if (!c.isEmpty() && this.parent.onCurrentContextCall() != null) {
/* 767 */         this.parent.onCurrentContextCall().accept(c);
/*     */       }
/* 769 */       return c;
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 774 */       LongConsumer requestHook = this.parent.onRequestCall();
/* 775 */       if (requestHook != null) {
/*     */         try {
/* 777 */           requestHook.accept(n);
/*     */         }
/* 779 */         catch (Throwable e) {
/* 780 */           Operators.onOperatorError(e, this.actual.currentContext());
/*     */         } 
/*     */       }
/* 783 */       this.s.request(n);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 788 */       Runnable cancelHook = this.parent.onCancelCall();
/* 789 */       if (cancelHook != null) {
/*     */         try {
/* 791 */           cancelHook.run();
/*     */         }
/* 793 */         catch (Throwable e) {
/* 794 */           onError(Operators.onOperatorError(this.s, e, this.actual.currentContext()));
/*     */           return;
/*     */         } 
/*     */       }
/* 798 */       this.s.cancel();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 803 */       if (Operators.validate(this.s, s)) {
/* 804 */         Consumer<? super Subscription> subscribeHook = this.parent.onSubscribeCall();
/* 805 */         if (subscribeHook != null) {
/*     */           try {
/* 807 */             subscribeHook.accept(s);
/*     */           }
/* 809 */           catch (Throwable e) {
/* 810 */             Operators.error((Subscriber<?>)this.actual, Operators.onOperatorError(s, e, this.actual
/* 811 */                   .currentContext()));
/*     */             return;
/*     */           } 
/*     */         }
/* 815 */         this.s = s;
/* 816 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 823 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 824 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 825 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 827 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 832 */       if (this.done) {
/* 833 */         Operators.onNextDropped(t, this.actual.currentContext());
/*     */         
/*     */         return;
/*     */       } 
/* 837 */       Consumer<? super T> nextHook = this.parent.onNextCall();
/* 838 */       if (nextHook != null) {
/*     */         try {
/* 840 */           nextHook.accept(t);
/*     */         }
/* 842 */         catch (Throwable e) {
/* 843 */           Throwable e_ = Operators.onNextError(t, e, this.actual.currentContext(), this.s);
/* 844 */           if (e_ == null) {
/* 845 */             request(1L);
/*     */             
/*     */             return;
/*     */           } 
/* 849 */           onError(e_);
/*     */           
/*     */           return;
/*     */         } 
/*     */       }
/* 854 */       this.actual.onNext(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean tryOnNext(T t) {
/* 859 */       if (this.done) {
/* 860 */         Operators.onNextDropped(t, this.actual.currentContext());
/* 861 */         return false;
/*     */       } 
/*     */       
/* 864 */       Consumer<? super T> nextHook = this.parent.onNextCall();
/* 865 */       if (nextHook != null) {
/*     */         try {
/* 867 */           nextHook.accept(t);
/*     */         }
/* 869 */         catch (Throwable e) {
/* 870 */           Throwable e_ = Operators.onNextError(t, e, this.actual.currentContext(), this.s);
/* 871 */           if (e_ == null) {
/* 872 */             return false;
/*     */           }
/*     */           
/* 875 */           onError(e_);
/* 876 */           return true;
/*     */         } 
/*     */       }
/*     */       
/* 880 */       return this.actual.tryOnNext(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 885 */       if (this.done) {
/* 886 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*     */         return;
/*     */       } 
/* 889 */       this.done = true;
/* 890 */       Consumer<? super Throwable> errorHook = this.parent.onErrorCall();
/* 891 */       if (errorHook != null) {
/* 892 */         Exceptions.throwIfFatal(t);
/*     */         try {
/* 894 */           errorHook.accept(t);
/*     */         }
/* 896 */         catch (Throwable e) {
/*     */           
/* 898 */           t = Operators.onOperatorError(null, e, t, this.actual.currentContext());
/*     */         } 
/*     */       } 
/*     */       
/*     */       try {
/* 903 */         this.actual.onError(t);
/*     */       }
/* 905 */       catch (UnsupportedOperationException use) {
/* 906 */         if (errorHook == null || (
/* 907 */           !Exceptions.isErrorCallbackNotImplemented(use) && use.getCause() != t)) {
/* 908 */           throw use;
/*     */         }
/*     */       } 
/*     */       
/* 912 */       Runnable afterTerminateHook = this.parent.onAfterTerminateCall();
/* 913 */       if (afterTerminateHook != null) {
/*     */         try {
/* 915 */           afterTerminateHook.run();
/*     */         }
/* 917 */         catch (Throwable e) {
/* 918 */           FluxPeek.afterErrorWithFailure(this.parent, e, t, this.actual.currentContext());
/*     */         } 
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 925 */       if (this.done) {
/*     */         return;
/*     */       }
/* 928 */       Runnable completeHook = this.parent.onCompleteCall();
/* 929 */       if (completeHook != null) {
/*     */         try {
/* 931 */           completeHook.run();
/*     */         }
/* 933 */         catch (Throwable e) {
/* 934 */           onError(Operators.onOperatorError(this.s, e, this.actual.currentContext()));
/*     */           return;
/*     */         } 
/*     */       }
/* 938 */       this.done = true;
/*     */       
/* 940 */       this.actual.onComplete();
/*     */       
/* 942 */       Runnable afterTerminateHook = this.parent.onAfterTerminateCall();
/* 943 */       if (afterTerminateHook != null) {
/*     */         try {
/* 945 */           afterTerminateHook.run();
/*     */         }
/* 947 */         catch (Throwable e) {
/* 948 */           FluxPeek.afterCompleteWithFailure(this.parent, e, this.actual.currentContext());
/*     */         } 
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 955 */       return (CoreSubscriber<? super T>)this.actual;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\FluxPeekFuseable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */