/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Queue;
/*     */ import java.util.function.Supplier;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.core.scheduler.Scheduler;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ParallelRunOn<T>
/*     */   extends ParallelFlux<T>
/*     */   implements Scannable
/*     */ {
/*     */   final ParallelFlux<? extends T> source;
/*     */   final Scheduler scheduler;
/*     */   final int prefetch;
/*     */   final Supplier<Queue<T>> queueSupplier;
/*     */   
/*     */   ParallelRunOn(ParallelFlux<? extends T> parent, Scheduler scheduler, int prefetch, Supplier<Queue<T>> queueSupplier) {
/*  45 */     if (prefetch <= 0) {
/*  46 */       throw new IllegalArgumentException("prefetch > 0 required but it was " + prefetch);
/*     */     }
/*  48 */     this.source = parent;
/*  49 */     this.scheduler = scheduler;
/*  50 */     this.prefetch = prefetch;
/*  51 */     this.queueSupplier = queueSupplier;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  57 */     if (key == Scannable.Attr.PARENT) return this.source; 
/*  58 */     if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(getPrefetch()); 
/*  59 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.ASYNC;
/*     */     
/*  61 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super T>[] subscribers) {
/*  67 */     if (!validate((Subscriber<?>[])subscribers)) {
/*     */       return;
/*     */     }
/*     */     
/*  71 */     int n = subscribers.length;
/*     */ 
/*     */     
/*  74 */     CoreSubscriber[] arrayOfCoreSubscriber = new CoreSubscriber[n];
/*     */     
/*  76 */     boolean conditional = subscribers[0] instanceof Fuseable.ConditionalSubscriber;
/*     */     
/*  78 */     for (int i = 0; i < n; i++) {
/*  79 */       Scheduler.Worker w = this.scheduler.createWorker();
/*     */       
/*  81 */       if (conditional) {
/*  82 */         arrayOfCoreSubscriber[i] = new FluxPublishOn.PublishOnConditionalSubscriber<>((Fuseable.ConditionalSubscriber<? super T>)subscribers[i], this.scheduler, w, true, this.prefetch, this.prefetch, this.queueSupplier);
/*     */       
/*     */       }
/*     */       else {
/*     */ 
/*     */         
/*  88 */         arrayOfCoreSubscriber[i] = new FluxPublishOn.PublishOnSubscriber<>(subscribers[i], this.scheduler, w, true, this.prefetch, this.prefetch, this.queueSupplier);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  94 */     this.source.subscribe((CoreSubscriber<? super T>[])arrayOfCoreSubscriber);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPrefetch() {
/*  99 */     return this.prefetch;
/*     */   }
/*     */ 
/*     */   
/*     */   public int parallelism() {
/* 104 */     return this.source.parallelism();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\ParallelRunOn.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */