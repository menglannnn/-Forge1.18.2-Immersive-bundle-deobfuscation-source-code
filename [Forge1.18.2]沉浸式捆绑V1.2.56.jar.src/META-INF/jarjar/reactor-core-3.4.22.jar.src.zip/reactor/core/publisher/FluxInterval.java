/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.RejectedExecutionException;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.core.scheduler.Scheduler;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxInterval
/*     */   extends Flux<Long>
/*     */   implements SourceProducer<Long>
/*     */ {
/*     */   final Scheduler timedScheduler;
/*     */   final long initialDelay;
/*     */   final long period;
/*     */   final TimeUnit unit;
/*     */   
/*     */   FluxInterval(long initialDelay, long period, TimeUnit unit, Scheduler timedScheduler) {
/*  51 */     if (period < 0L) {
/*  52 */       throw new IllegalArgumentException("period >= 0 required but it was " + period);
/*     */     }
/*  54 */     this.initialDelay = initialDelay;
/*  55 */     this.period = period;
/*  56 */     this.unit = Objects.<TimeUnit>requireNonNull(unit, "unit");
/*  57 */     this.timedScheduler = Objects.<Scheduler>requireNonNull(timedScheduler, "timedScheduler");
/*     */   }
/*     */ 
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super Long> actual) {
/*  62 */     Scheduler.Worker w = this.timedScheduler.createWorker();
/*     */     
/*  64 */     IntervalRunnable r = new IntervalRunnable(actual, w);
/*     */     
/*  66 */     actual.onSubscribe(r);
/*     */     
/*     */     try {
/*  69 */       w.schedulePeriodically(r, this.initialDelay, this.period, this.unit);
/*     */     }
/*  71 */     catch (RejectedExecutionException ree) {
/*  72 */       if (!r.cancelled) {
/*  73 */         actual.onError(Operators.onRejectedExecution(ree, r, null, null, actual
/*  74 */               .currentContext()));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  81 */     if (key == Scannable.Attr.RUN_ON) return this.timedScheduler; 
/*  82 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.ASYNC;
/*     */     
/*  84 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   static final class IntervalRunnable
/*     */     implements Runnable, Subscription, InnerProducer<Long>
/*     */   {
/*     */     final CoreSubscriber<? super Long> actual;
/*     */     
/*     */     final Scheduler.Worker worker;
/*     */     volatile long requested;
/*  95 */     static final AtomicLongFieldUpdater<IntervalRunnable> REQUESTED = AtomicLongFieldUpdater.newUpdater(IntervalRunnable.class, "requested");
/*     */     
/*     */     long count;
/*     */     
/*     */     volatile boolean cancelled;
/*     */     
/*     */     IntervalRunnable(CoreSubscriber<? super Long> actual, Scheduler.Worker worker) {
/* 102 */       this.actual = actual;
/* 103 */       this.worker = worker;
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super Long> actual() {
/* 108 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 114 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(this.cancelled); 
/* 115 */       if (key == Scannable.Attr.RUN_ON) return this.worker; 
/* 116 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.ASYNC;
/*     */       
/* 118 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public void run() {
/* 123 */       if (!this.cancelled) {
/* 124 */         if (this.requested != 0L) {
/* 125 */           this.actual.onNext(Long.valueOf(this.count++));
/* 126 */           if (this.requested != Long.MAX_VALUE) {
/* 127 */             REQUESTED.decrementAndGet(this);
/*     */           }
/*     */         } else {
/* 130 */           cancel();
/*     */           
/* 132 */           this.actual.onError(Exceptions.failWithOverflow("Could not emit tick " + this.count + " due to lack of requests (interval doesn't support small downstream requests that replenish slower than the ticks)"));
/*     */         } 
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 140 */       if (Operators.validate(n)) {
/* 141 */         Operators.addCap(REQUESTED, this, n);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 147 */       if (!this.cancelled) {
/* 148 */         this.cancelled = true;
/* 149 */         this.worker.dispose();
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\FluxInterval.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */