/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*    */ import java.util.function.Consumer;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Disposable;
/*    */ import reactor.core.Fuseable;
/*    */ import reactor.core.Scannable;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class FluxAutoConnectFuseable<T>
/*    */   extends Flux<T>
/*    */   implements Scannable, Fuseable
/*    */ {
/*    */   final ConnectableFlux<? extends T> source;
/*    */   final Consumer<? super Disposable> cancelSupport;
/*    */   volatile int remaining;
/* 46 */   static final AtomicIntegerFieldUpdater<FluxAutoConnectFuseable> REMAINING = AtomicIntegerFieldUpdater.newUpdater(FluxAutoConnectFuseable.class, "remaining");
/*    */ 
/*    */ 
/*    */   
/*    */   FluxAutoConnectFuseable(ConnectableFlux<? extends T> source, int n, Consumer<? super Disposable> cancelSupport) {
/* 51 */     if (n <= 0) {
/* 52 */       throw new IllegalArgumentException("n > required but it was " + n);
/*    */     }
/* 54 */     this.source = Objects.<ConnectableFlux<? extends T>>requireNonNull(source, "source");
/* 55 */     this.cancelSupport = Objects.<Consumer<? super Disposable>>requireNonNull(cancelSupport, "cancelSupport");
/* 56 */     REMAINING.lazySet(this, n);
/*    */   }
/*    */ 
/*    */   
/*    */   public void subscribe(CoreSubscriber<? super T> actual) {
/* 61 */     this.source.subscribe(actual);
/* 62 */     if (this.remaining > 0 && REMAINING.decrementAndGet(this) == 0) {
/* 63 */       this.source.connect(this.cancelSupport);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public int getPrefetch() {
/* 69 */     return this.source.getPrefetch();
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 75 */     if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(getPrefetch()); 
/* 76 */     if (key == Scannable.Attr.PARENT) return this.source; 
/* 77 */     if (key == Scannable.Attr.CAPACITY) return Integer.valueOf(this.remaining); 
/* 78 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*    */     
/* 80 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\FluxAutoConnectFuseable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */