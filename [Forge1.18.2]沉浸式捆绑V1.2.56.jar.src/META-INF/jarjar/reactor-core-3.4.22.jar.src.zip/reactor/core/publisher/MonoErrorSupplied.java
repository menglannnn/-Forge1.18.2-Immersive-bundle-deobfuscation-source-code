/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.time.Duration;
/*    */ import java.util.Objects;
/*    */ import java.util.function.Supplier;
/*    */ import org.reactivestreams.Subscriber;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Exceptions;
/*    */ import reactor.core.Fuseable;
/*    */ import reactor.core.Scannable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MonoErrorSupplied<T>
/*    */   extends Mono<T>
/*    */   implements Fuseable.ScalarCallable<T>, SourceProducer<T>
/*    */ {
/*    */   final Supplier<? extends Throwable> errorSupplier;
/*    */   
/*    */   MonoErrorSupplied(Supplier<? extends Throwable> errorSupplier) {
/* 38 */     this.errorSupplier = Objects.<Supplier<? extends Throwable>>requireNonNull(errorSupplier, "errorSupplier");
/*    */   }
/*    */ 
/*    */   
/*    */   public T block(Duration m) {
/* 43 */     Throwable error = Objects.<Throwable>requireNonNull(this.errorSupplier.get(), "the errorSupplier returned null");
/* 44 */     throw Exceptions.propagate(error);
/*    */   }
/*    */ 
/*    */   
/*    */   public T block() {
/* 49 */     Throwable error = Objects.<Throwable>requireNonNull(this.errorSupplier.get(), "the errorSupplier returned null");
/* 50 */     throw Exceptions.propagate(error);
/*    */   }
/*    */ 
/*    */   
/*    */   public void subscribe(CoreSubscriber<? super T> actual) {
/* 55 */     Throwable error = Objects.<Throwable>requireNonNull(this.errorSupplier.get(), "the errorSupplier returned null");
/* 56 */     Operators.error((Subscriber<?>)actual, error);
/*    */   }
/*    */ 
/*    */   
/*    */   public T call() throws Exception {
/* 61 */     Throwable error = Objects.<Throwable>requireNonNull(this.errorSupplier.get(), "the errorSupplier returned null");
/* 62 */     if (error instanceof Exception) {
/* 63 */       throw (Exception)error;
/*    */     }
/* 65 */     throw Exceptions.propagate(error);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 70 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 71 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\MonoErrorSupplied.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */