/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.function.LongConsumer;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.util.context.Context;
/*     */ import reactor.util.context.ContextView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface FluxSink<T>
/*     */ {
/*     */   FluxSink<T> next(T paramT);
/*     */   
/*     */   void complete();
/*     */   
/*     */   void error(Throwable paramThrowable);
/*     */   
/*     */   @Deprecated
/*     */   Context currentContext();
/*     */   
/*     */   default ContextView contextView() {
/*  87 */     return (ContextView)currentContext();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   long requestedFromDownstream();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isCancelled();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   FluxSink<T> onRequest(LongConsumer paramLongConsumer);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   FluxSink<T> onCancel(Disposable paramDisposable);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   FluxSink<T> onDispose(Disposable paramDisposable);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum OverflowStrategy
/*     */   {
/* 165 */     IGNORE,
/*     */ 
/*     */ 
/*     */     
/* 169 */     ERROR,
/*     */ 
/*     */ 
/*     */     
/* 173 */     DROP,
/*     */ 
/*     */ 
/*     */     
/* 177 */     LATEST,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 183 */     BUFFER;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\FluxSink.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */