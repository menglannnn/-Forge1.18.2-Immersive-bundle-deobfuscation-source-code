/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.stream.Stream;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxTakeUntilOther<T, U>
/*     */   extends InternalFluxOperator<T, T>
/*     */ {
/*     */   final Publisher<U> other;
/*     */   
/*     */   FluxTakeUntilOther(Flux<? extends T> source, Publisher<U> other) {
/*  42 */     super(source);
/*  43 */     this.other = Objects.<Publisher<U>>requireNonNull(other, "other");
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPrefetch() {
/*  48 */     return Integer.MAX_VALUE;
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/*  53 */     TakeUntilMainSubscriber<T> mainSubscriber = new TakeUntilMainSubscriber<>(actual);
/*     */     
/*  55 */     TakeUntilOtherSubscriber<U> otherSubscriber = new TakeUntilOtherSubscriber<>(mainSubscriber);
/*     */     
/*  57 */     this.other.subscribe((Subscriber)otherSubscriber);
/*     */     
/*  59 */     return mainSubscriber;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  64 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  65 */     return super.scanUnsafe(key);
/*     */   }
/*     */   
/*     */   static final class TakeUntilOtherSubscriber<U>
/*     */     implements InnerConsumer<U> {
/*     */     final FluxTakeUntilOther.TakeUntilMainSubscriber<?> main;
/*     */     boolean once;
/*     */     
/*     */     TakeUntilOtherSubscriber(FluxTakeUntilOther.TakeUntilMainSubscriber<?> main) {
/*  74 */       this.main = main;
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/*  79 */       return this.main.currentContext();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/*  85 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf((this.main.other == Operators.cancelledSubscription())); 
/*  86 */       if (key == Scannable.Attr.PARENT) return this.main.other; 
/*  87 */       if (key == Scannable.Attr.ACTUAL) return this.main; 
/*  88 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/*  90 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/*  95 */       this.main.setOther(s);
/*     */       
/*  97 */       s.request(Long.MAX_VALUE);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(U t) {
/* 102 */       onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 107 */       if (this.once) {
/*     */         return;
/*     */       }
/* 110 */       this.once = true;
/* 111 */       this.main.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 116 */       if (this.once) {
/*     */         return;
/*     */       }
/* 119 */       this.once = true;
/* 120 */       this.main.onComplete();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class TakeUntilMainSubscriber<T>
/*     */     implements InnerOperator<T, T>
/*     */   {
/*     */     final CoreSubscriber<? super T> actual;
/*     */     
/*     */     volatile Subscription main;
/*     */     
/* 132 */     static final AtomicReferenceFieldUpdater<TakeUntilMainSubscriber, Subscription> MAIN = AtomicReferenceFieldUpdater.newUpdater(TakeUntilMainSubscriber.class, Subscription.class, "main");
/*     */ 
/*     */     
/*     */     volatile Subscription other;
/*     */     
/* 137 */     static final AtomicReferenceFieldUpdater<TakeUntilMainSubscriber, Subscription> OTHER = AtomicReferenceFieldUpdater.newUpdater(TakeUntilMainSubscriber.class, Subscription.class, "other");
/*     */     
/*     */     TakeUntilMainSubscriber(CoreSubscriber<? super T> actual) {
/* 140 */       this.actual = Operators.serialize(actual);
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 146 */       if (key == Scannable.Attr.PARENT) return this.main; 
/* 147 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf((this.main == Operators.cancelledSubscription())); 
/* 148 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 150 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public final CoreSubscriber<? super T> actual() {
/* 155 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public Stream<? extends Scannable> inners() {
/* 160 */       return Stream.of(Scannable.from(this.other));
/*     */     }
/*     */     
/*     */     void setOther(Subscription s) {
/* 164 */       if (!OTHER.compareAndSet(this, null, s)) {
/* 165 */         s.cancel();
/* 166 */         if (this.other != Operators.cancelledSubscription()) {
/* 167 */           Operators.reportSubscriptionSet();
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 174 */       this.main.request(n);
/*     */     }
/*     */     
/*     */     void cancelMain() {
/* 178 */       Subscription s = this.main;
/* 179 */       if (s != Operators.cancelledSubscription()) {
/* 180 */         s = MAIN.getAndSet(this, Operators.cancelledSubscription());
/* 181 */         if (s != null && s != Operators.cancelledSubscription()) {
/* 182 */           s.cancel();
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*     */     void cancelOther() {
/* 188 */       Subscription s = this.other;
/* 189 */       if (s != Operators.cancelledSubscription()) {
/* 190 */         s = OTHER.getAndSet(this, Operators.cancelledSubscription());
/* 191 */         if (s != null && s != Operators.cancelledSubscription()) {
/* 192 */           s.cancel();
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 199 */       cancelMain();
/* 200 */       cancelOther();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 205 */       if (!MAIN.compareAndSet(this, null, s)) {
/* 206 */         s.cancel();
/* 207 */         if (this.main != Operators.cancelledSubscription()) {
/* 208 */           Operators.reportSubscriptionSet();
/*     */         }
/*     */       } else {
/* 211 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 217 */       this.actual.onNext(t);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 223 */       if (this.main == null && 
/* 224 */         MAIN.compareAndSet(this, null, Operators.cancelledSubscription())) {
/* 225 */         Operators.error((Subscriber<?>)this.actual, t);
/*     */         
/*     */         return;
/*     */       } 
/* 229 */       cancel();
/*     */       
/* 231 */       this.actual.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 236 */       if (this.main == null && 
/* 237 */         MAIN.compareAndSet(this, null, Operators.cancelledSubscription())) {
/* 238 */         cancelOther();
/* 239 */         Operators.complete((Subscriber<?>)this.actual);
/*     */         
/*     */         return;
/*     */       } 
/* 243 */       cancel();
/*     */       
/* 245 */       this.actual.onComplete();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\FluxTakeUntilOther.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */