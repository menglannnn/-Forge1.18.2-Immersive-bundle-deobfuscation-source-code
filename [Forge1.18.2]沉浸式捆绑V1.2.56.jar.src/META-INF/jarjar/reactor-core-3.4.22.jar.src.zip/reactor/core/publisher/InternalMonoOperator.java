/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import reactor.core.CorePublisher;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Scannable;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class InternalMonoOperator<I, O>
/*    */   extends MonoOperator<I, O>
/*    */   implements Scannable, OptimizableOperator<O, I>
/*    */ {
/*    */   @Nullable
/*    */   final OptimizableOperator<?, I> optimizableOperator;
/*    */   
/*    */   protected InternalMonoOperator(Mono<? extends I> source) {
/* 40 */     super(source);
/* 41 */     if (source instanceof OptimizableOperator) {
/*    */       
/* 43 */       OptimizableOperator<?, I> optimSource = (OptimizableOperator)source;
/* 44 */       this.optimizableOperator = optimSource;
/*    */     } else {
/*    */       
/* 47 */       this.optimizableOperator = null;
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public final void subscribe(CoreSubscriber<? super O> subscriber) {
/* 54 */     OptimizableOperator<I, O> operator = this;
/*    */     try {
/*    */       while (true) {
/* 57 */         subscriber = operator.subscribeOrReturn(subscriber);
/* 58 */         if (subscriber == null) {
/*    */           return;
/*    */         }
/*    */         
/* 62 */         OptimizableOperator<?, ? extends O> newSource = operator.nextOptimizableSource();
/* 63 */         if (newSource == null) {
/* 64 */           operator.source().subscribe(subscriber);
/*    */           return;
/*    */         } 
/* 67 */         OptimizableOperator<?, ? extends O> optimizableOperator1 = newSource;
/*    */       }
/*    */     
/* 70 */     } catch (Throwable e) {
/* 71 */       Operators.reportThrowInSubscribe(subscriber, e);
/*    */       return;
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public abstract CoreSubscriber<? super I> subscribeOrReturn(CoreSubscriber<? super O> paramCoreSubscriber) throws Throwable;
/*    */   
/*    */   public final CorePublisher<? extends I> source() {
/* 81 */     return this.source;
/*    */   }
/*    */ 
/*    */   
/*    */   public final OptimizableOperator<?, ? extends I> nextOptimizableSource() {
/* 86 */     return this.optimizableOperator;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\InternalMonoOperator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */