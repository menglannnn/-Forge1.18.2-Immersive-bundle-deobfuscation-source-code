/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.util.concurrent.CancellationException;
/*     */ import java.util.stream.Stream;
/*     */ import org.reactivestreams.Processor;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public abstract class MonoProcessor<O>
/*     */   extends Mono<O>
/*     */   implements Processor<O, O>, CoreSubscriber<O>, Disposable, Subscription, Scannable
/*     */ {
/*     */   @Deprecated
/*     */   public static <T> MonoProcessor<T> create() {
/*  69 */     return new NextProcessor<>(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void cancel() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public boolean isCancelled() {
/*  89 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void request(long n) {
/*  99 */     Operators.validate(n);
/*     */   }
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 104 */     onError(new CancellationException("Disposed"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public O block() {
/* 116 */     return block((Duration)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public O block(@Nullable Duration timeout) {
/* 131 */     return peek();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Throwable getError() {
/* 141 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isError() {
/* 150 */     return (getError() != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isSuccess() {
/* 159 */     return (isTerminated() && !isError());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isTerminated() {
/* 169 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDisposed() {
/* 174 */     return (isTerminated() || isCancelled());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   @Deprecated
/*     */   public O peek() {
/* 189 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Context currentContext() {
/* 197 */     InnerProducer[] arrayOfInnerProducer = (InnerProducer[])inners().filter(InnerProducer.class::isInstance).map(InnerProducer.class::cast).toArray(x$0 -> new InnerProducer[x$0]);
/*     */     
/* 199 */     return Operators.multiSubscribersContext((InnerProducer<?>[])arrayOfInnerProducer);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/* 206 */     boolean t = isTerminated();
/*     */     
/* 208 */     if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(t); 
/* 209 */     if (key == Scannable.Attr.ERROR) return getError(); 
/* 210 */     if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(2147483647); 
/* 211 */     if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(isCancelled()); 
/* 212 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */     
/* 214 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long downstreamCount() {
/* 223 */     return inners().count();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean hasDownstreams() {
/* 232 */     return (downstreamCount() != 0L);
/*     */   }
/*     */ 
/*     */   
/*     */   public Stream<? extends Scannable> inners() {
/* 237 */     return Stream.empty();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\MonoProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */