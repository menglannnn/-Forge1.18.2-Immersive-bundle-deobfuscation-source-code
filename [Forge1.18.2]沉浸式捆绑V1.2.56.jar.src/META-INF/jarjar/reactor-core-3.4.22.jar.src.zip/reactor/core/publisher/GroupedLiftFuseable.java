/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Fuseable;
/*    */ import reactor.core.Scannable;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class GroupedLiftFuseable<K, I, O>
/*    */   extends GroupedFlux<K, O>
/*    */   implements Scannable, Fuseable
/*    */ {
/*    */   final Operators.LiftFunction<I, O> liftFunction;
/*    */   final GroupedFlux<K, I> source;
/*    */   
/*    */   GroupedLiftFuseable(GroupedFlux<K, I> p, Operators.LiftFunction<I, O> liftFunction) {
/* 38 */     this.source = Objects.<GroupedFlux<K, I>>requireNonNull(p, "source");
/* 39 */     this.liftFunction = liftFunction;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getPrefetch() {
/* 44 */     return this.source.getPrefetch();
/*    */   }
/*    */ 
/*    */   
/*    */   public K key() {
/* 49 */     return this.source.key();
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 55 */     if (key == Scannable.Attr.PARENT) {
/* 56 */       return this.source;
/*    */     }
/* 58 */     if (key == Scannable.Attr.PREFETCH) {
/* 59 */       return Integer.valueOf(getPrefetch());
/*    */     }
/* 61 */     if (key == Scannable.Attr.RUN_STYLE) {
/* 62 */       return Scannable.from(this.source).scanUnsafe(key);
/*    */     }
/* 64 */     if (key == Scannable.Attr.LIFTER) {
/* 65 */       return this.liftFunction.name;
/*    */     }
/*    */     
/* 68 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public String stepName() {
/* 73 */     if (this.source instanceof Scannable) {
/* 74 */       return Scannable.from(this.source).stepName();
/*    */     }
/* 76 */     return super.stepName();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void subscribe(CoreSubscriber<? super O> actual) {
/* 82 */     CoreSubscriber<? super I> input = this.liftFunction.lifter.apply(this.source, actual);
/*    */     
/* 84 */     Objects.requireNonNull(input, "Lifted subscriber MUST NOT be null");
/*    */     
/* 86 */     if (actual instanceof Fuseable.QueueSubscription && !(input instanceof Fuseable.QueueSubscription))
/*    */     {
/*    */       
/* 89 */       input = new FluxHide.SuppressFuseableSubscriber<>(input);
/*    */     }
/*    */     
/* 92 */     this.source.subscribe(input);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\GroupedLiftFuseable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */