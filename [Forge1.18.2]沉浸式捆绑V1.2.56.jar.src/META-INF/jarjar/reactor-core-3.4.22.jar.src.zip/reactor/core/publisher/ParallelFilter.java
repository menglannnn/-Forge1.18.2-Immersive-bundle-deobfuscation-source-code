/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.util.function.Predicate;
/*    */ import org.reactivestreams.Subscriber;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Fuseable;
/*    */ import reactor.core.Scannable;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class ParallelFilter<T>
/*    */   extends ParallelFlux<T>
/*    */   implements Scannable
/*    */ {
/*    */   final ParallelFlux<T> source;
/*    */   final Predicate<? super T> predicate;
/*    */   
/*    */   ParallelFilter(ParallelFlux<T> source, Predicate<? super T> predicate) {
/* 38 */     this.source = source;
/* 39 */     this.predicate = predicate;
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 45 */     if (key == Scannable.Attr.PARENT) return this.source; 
/* 46 */     if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(getPrefetch()); 
/* 47 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*    */     
/* 49 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void subscribe(CoreSubscriber<? super T>[] subscribers) {
/* 55 */     if (!validate((Subscriber<?>[])subscribers)) {
/*    */       return;
/*    */     }
/*    */     
/* 59 */     int n = subscribers.length;
/*    */     
/* 61 */     CoreSubscriber[] arrayOfCoreSubscriber = new CoreSubscriber[n];
/*    */     
/* 63 */     boolean conditional = subscribers[0] instanceof Fuseable.ConditionalSubscriber;
/*    */     
/* 65 */     for (int i = 0; i < n; i++) {
/* 66 */       if (conditional) {
/* 67 */         arrayOfCoreSubscriber[i] = new FluxFilter.FilterConditionalSubscriber<>((Fuseable.ConditionalSubscriber<? super T>)subscribers[i], this.predicate);
/*    */       }
/*    */       else {
/*    */         
/* 71 */         arrayOfCoreSubscriber[i] = new FluxFilter.FilterSubscriber<>(subscribers[i], this.predicate);
/*    */       } 
/*    */     } 
/*    */     
/* 75 */     this.source.subscribe((CoreSubscriber<? super T>[])arrayOfCoreSubscriber);
/*    */   }
/*    */ 
/*    */   
/*    */   public int parallelism() {
/* 80 */     return this.source.parallelism();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\ParallelFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */