/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.function.BiFunction;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ParallelMergeReduce<T>
/*     */   extends Mono<T>
/*     */   implements Scannable, Fuseable
/*     */ {
/*     */   final ParallelFlux<? extends T> source;
/*     */   final BiFunction<T, T, T> reducer;
/*     */   
/*     */   ParallelMergeReduce(ParallelFlux<? extends T> source, BiFunction<T, T, T> reducer) {
/*  45 */     this.source = source;
/*  46 */     this.reducer = reducer;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  52 */     if (key == Scannable.Attr.PARENT) return this.source; 
/*  53 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */     
/*  55 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super T> actual) {
/*  61 */     MergeReduceMain<T> parent = new MergeReduceMain<>(actual, this.source.parallelism(), this.reducer);
/*  62 */     actual.onSubscribe(parent);
/*     */     
/*  64 */     this.source.subscribe((CoreSubscriber<? super T>[])parent.subscribers);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class MergeReduceMain<T>
/*     */     extends Operators.MonoSubscriber<T, T>
/*     */   {
/*     */     final ParallelMergeReduce.MergeReduceInner<T>[] subscribers;
/*     */     
/*     */     final BiFunction<T, T, T> reducer;
/*     */     
/*     */     volatile ParallelMergeReduce.SlotPair<T> current;
/*     */     
/*  77 */     static final AtomicReferenceFieldUpdater<MergeReduceMain, ParallelMergeReduce.SlotPair> CURRENT = AtomicReferenceFieldUpdater.newUpdater(MergeReduceMain.class, ParallelMergeReduce.SlotPair.class, "current");
/*     */ 
/*     */ 
/*     */     
/*     */     volatile int remaining;
/*     */ 
/*     */ 
/*     */     
/*  85 */     static final AtomicIntegerFieldUpdater<MergeReduceMain> REMAINING = AtomicIntegerFieldUpdater.newUpdater(MergeReduceMain.class, "remaining");
/*     */ 
/*     */ 
/*     */     
/*     */     volatile Throwable error;
/*     */ 
/*     */     
/*  92 */     static final AtomicReferenceFieldUpdater<MergeReduceMain, Throwable> ERROR = AtomicReferenceFieldUpdater.newUpdater(MergeReduceMain.class, Throwable.class, "error");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     MergeReduceMain(CoreSubscriber<? super T> subscriber, int n, BiFunction<T, T, T> reducer) {
/* 100 */       super(subscriber);
/* 101 */       ParallelMergeReduce.MergeReduceInner[] arrayOfMergeReduceInner = new ParallelMergeReduce.MergeReduceInner[n];
/*     */       
/* 103 */       for (int i = 0; i < n; i++) {
/* 104 */         arrayOfMergeReduceInner[i] = new ParallelMergeReduce.MergeReduceInner<>(this, reducer);
/*     */       }
/* 106 */       this.subscribers = (ParallelMergeReduce.MergeReduceInner<T>[])arrayOfMergeReduceInner;
/* 107 */       this.reducer = reducer;
/* 108 */       REMAINING.lazySet(this, n);
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 114 */       if (key == Scannable.Attr.ERROR) return this.error; 
/* 115 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf((REMAINING.get(this) == 0)); 
/* 116 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 118 */       return super.scanUnsafe(key);
/*     */     } @Nullable
/*     */     ParallelMergeReduce.SlotPair<T> addValue(T value) {
/*     */       ParallelMergeReduce.SlotPair<T> curr;
/*     */       int c;
/*     */       while (true) {
/* 124 */         curr = this.current;
/*     */         
/* 126 */         if (curr == null) {
/* 127 */           curr = new ParallelMergeReduce.SlotPair<>();
/* 128 */           if (!CURRENT.compareAndSet(this, null, curr)) {
/*     */             continue;
/*     */           }
/*     */         } 
/*     */         
/* 133 */         c = curr.tryAcquireSlot();
/* 134 */         if (c < 0) {
/* 135 */           CURRENT.compareAndSet(this, curr, null); continue;
/*     */         }  break;
/*     */       } 
/* 138 */       if (c == 0) {
/* 139 */         curr.first = value;
/*     */       } else {
/*     */         
/* 142 */         curr.second = value;
/*     */       } 
/*     */       
/* 145 */       if (curr.releaseSlot()) {
/* 146 */         CURRENT.compareAndSet(this, curr, null);
/* 147 */         return curr;
/*     */       } 
/* 149 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 155 */       for (ParallelMergeReduce.MergeReduceInner<T> inner : this.subscribers) {
/* 156 */         inner.cancel();
/*     */       }
/* 158 */       super.cancel();
/*     */     }
/*     */     
/*     */     void innerError(Throwable ex) {
/* 162 */       if (ERROR.compareAndSet(this, null, ex)) {
/* 163 */         cancel();
/* 164 */         this.actual.onError(ex);
/*     */       }
/* 166 */       else if (this.error != ex) {
/* 167 */         Operators.onErrorDropped(ex, this.actual.currentContext());
/*     */       } 
/*     */     }
/*     */     
/*     */     void innerComplete(@Nullable T value) {
/* 172 */       if (value != null) {
/*     */         while (true) {
/* 174 */           ParallelMergeReduce.SlotPair<T> sp = addValue(value);
/*     */           
/* 176 */           if (sp != null) {
/*     */             
/*     */             try {
/* 179 */               value = Objects.requireNonNull(this.reducer.apply(sp.first, sp.second), "The reducer returned a null value");
/*     */             
/*     */             }
/* 182 */             catch (Throwable ex) {
/* 183 */               innerError(Operators.onOperatorError(this, ex, this.actual
/* 184 */                     .currentContext()));
/*     */               
/*     */               return;
/*     */             } 
/*     */             
/*     */             continue;
/*     */           } 
/*     */           break;
/*     */         } 
/*     */       }
/* 194 */       if (REMAINING.decrementAndGet(this) == 0) {
/* 195 */         ParallelMergeReduce.SlotPair<T> sp = this.current;
/* 196 */         CURRENT.lazySet(this, null);
/*     */         
/* 198 */         if (sp != null) {
/* 199 */           complete(sp.first);
/*     */         } else {
/*     */           
/* 202 */           this.actual.onComplete();
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class MergeReduceInner<T>
/*     */     implements InnerConsumer<T>
/*     */   {
/*     */     final ParallelMergeReduce.MergeReduceMain<T> parent;
/*     */     
/*     */     final BiFunction<T, T, T> reducer;
/*     */     
/*     */     volatile Subscription s;
/* 217 */     static final AtomicReferenceFieldUpdater<MergeReduceInner, Subscription> S = AtomicReferenceFieldUpdater.newUpdater(MergeReduceInner.class, Subscription.class, "s");
/*     */ 
/*     */     
/*     */     T value;
/*     */ 
/*     */     
/*     */     boolean done;
/*     */ 
/*     */ 
/*     */     
/*     */     MergeReduceInner(ParallelMergeReduce.MergeReduceMain<T> parent, BiFunction<T, T, T> reducer) {
/* 228 */       this.parent = parent;
/* 229 */       this.reducer = reducer;
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/* 234 */       return this.parent.currentContext();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 240 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf((this.s == Operators.cancelledSubscription())); 
/* 241 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 242 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 243 */       if (key == Scannable.Attr.ACTUAL) return this.parent; 
/* 244 */       if (key == Scannable.Attr.BUFFERED) return Integer.valueOf((this.value != null) ? 1 : 0); 
/* 245 */       if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(2147483647); 
/* 246 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 248 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 253 */       if (Operators.setOnce(S, this, s)) {
/* 254 */         s.request(Long.MAX_VALUE);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 260 */       if (this.done) {
/* 261 */         Operators.onNextDropped(t, currentContext());
/*     */         return;
/*     */       } 
/* 264 */       T v = this.value;
/*     */       
/* 266 */       if (v == null) {
/* 267 */         this.value = t;
/*     */       } else {
/*     */ 
/*     */         
/*     */         try {
/* 272 */           v = Objects.requireNonNull(this.reducer.apply(v, t), "The reducer returned a null value");
/*     */         }
/* 274 */         catch (Throwable ex) {
/* 275 */           onError(Operators.onOperatorError(this.s, ex, t, currentContext()));
/*     */           
/*     */           return;
/*     */         } 
/* 279 */         this.value = v;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 285 */       if (this.done) {
/* 286 */         Operators.onErrorDropped(t, this.parent.currentContext());
/*     */         return;
/*     */       } 
/* 289 */       this.done = true;
/* 290 */       this.parent.innerError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 295 */       if (this.done) {
/*     */         return;
/*     */       }
/* 298 */       this.done = true;
/* 299 */       this.parent.innerComplete(this.value);
/*     */     }
/*     */     
/*     */     void cancel() {
/* 303 */       Operators.terminate(S, this);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class SlotPair<T>
/*     */   {
/*     */     T first;
/*     */     
/*     */     T second;
/*     */     
/*     */     volatile int acquireIndex;
/*     */     
/* 316 */     static final AtomicIntegerFieldUpdater<SlotPair> ACQ = AtomicIntegerFieldUpdater.newUpdater(SlotPair.class, "acquireIndex");
/*     */ 
/*     */     
/*     */     volatile int releaseIndex;
/*     */     
/* 321 */     static final AtomicIntegerFieldUpdater<SlotPair> REL = AtomicIntegerFieldUpdater.newUpdater(SlotPair.class, "releaseIndex");
/*     */     
/*     */     int tryAcquireSlot() {
/*     */       while (true) {
/* 325 */         int acquired = this.acquireIndex;
/* 326 */         if (acquired >= 2) {
/* 327 */           return -1;
/*     */         }
/*     */         
/* 330 */         if (ACQ.compareAndSet(this, acquired, acquired + 1)) {
/* 331 */           return acquired;
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*     */     boolean releaseSlot() {
/* 337 */       return (REL.incrementAndGet(this) == 2);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\ParallelMergeReduce.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */