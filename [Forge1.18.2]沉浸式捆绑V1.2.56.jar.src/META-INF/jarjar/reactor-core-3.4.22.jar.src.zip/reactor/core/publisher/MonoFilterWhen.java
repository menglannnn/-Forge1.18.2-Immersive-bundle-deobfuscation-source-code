/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.function.Function;
/*     */ import java.util.stream.Stream;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MonoFilterWhen<T>
/*     */   extends InternalMonoOperator<T, T>
/*     */ {
/*     */   final Function<? super T, ? extends Publisher<Boolean>> asyncPredicate;
/*     */   
/*     */   MonoFilterWhen(Mono<T> source, Function<? super T, ? extends Publisher<Boolean>> asyncPredicate) {
/*  53 */     super(source);
/*  54 */     this.asyncPredicate = asyncPredicate;
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/*  59 */     return new MonoFilterWhenMain<>(actual, this.asyncPredicate);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  64 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  65 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class MonoFilterWhenMain<T>
/*     */     extends Operators.MonoSubscriber<T, T>
/*     */   {
/*     */     final Function<? super T, ? extends Publisher<Boolean>> asyncPredicate;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     boolean sourceValued;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Subscription upstream;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     volatile MonoFilterWhen.FilterWhenInner asyncFilter;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  96 */     static final AtomicReferenceFieldUpdater<MonoFilterWhenMain, MonoFilterWhen.FilterWhenInner> ASYNC_FILTER = AtomicReferenceFieldUpdater.newUpdater(MonoFilterWhenMain.class, MonoFilterWhen.FilterWhenInner.class, "asyncFilter");
/*     */ 
/*     */     
/*  99 */     static final MonoFilterWhen.FilterWhenInner INNER_CANCELLED = new MonoFilterWhen.FilterWhenInner(null, false);
/*     */ 
/*     */     
/*     */     MonoFilterWhenMain(CoreSubscriber<? super T> actual, Function<? super T, ? extends Publisher<Boolean>> asyncPredicate) {
/* 103 */       super(actual);
/* 104 */       this.asyncPredicate = asyncPredicate;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 109 */       if (Operators.validate(this.upstream, s)) {
/* 110 */         this.upstream = s;
/* 111 */         this.actual.onSubscribe(this);
/* 112 */         s.request(Long.MAX_VALUE);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/*     */       Publisher<Boolean> p;
/* 120 */       this.sourceValued = true;
/* 121 */       setValue(t);
/*     */ 
/*     */       
/*     */       try {
/* 125 */         p = Objects.<Publisher<Boolean>>requireNonNull(this.asyncPredicate.apply(t), "The asyncPredicate returned a null value");
/*     */       
/*     */       }
/* 128 */       catch (Throwable ex) {
/* 129 */         Exceptions.throwIfFatal(ex);
/* 130 */         onError(ex);
/* 131 */         Operators.onDiscard(t, this.actual.currentContext());
/*     */         
/*     */         return;
/*     */       } 
/* 135 */       if (p instanceof Callable) {
/*     */         Boolean u;
/*     */         
/*     */         try {
/* 139 */           u = ((Callable<Boolean>)p).call();
/*     */         }
/* 141 */         catch (Throwable ex) {
/* 142 */           Exceptions.throwIfFatal(ex);
/* 143 */           onError(ex);
/* 144 */           Operators.onDiscard(t, this.actual.currentContext());
/*     */           
/*     */           return;
/*     */         } 
/* 148 */         if (u != null && u.booleanValue()) {
/* 149 */           complete(t);
/*     */         } else {
/*     */           
/* 152 */           this.actual.onComplete();
/* 153 */           Operators.onDiscard(t, this.actual.currentContext());
/*     */         } 
/*     */       } else {
/*     */         
/* 157 */         MonoFilterWhen.FilterWhenInner inner = new MonoFilterWhen.FilterWhenInner(this, !(p instanceof Mono));
/* 158 */         if (ASYNC_FILTER.compareAndSet(this, null, inner)) {
/* 159 */           p.subscribe((Subscriber)inner);
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 166 */       if (!this.sourceValued)
/*     */       {
/* 168 */         super.onComplete();
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 182 */       if (this.state != 4) {
/* 183 */         super.cancel();
/* 184 */         this.upstream.cancel();
/* 185 */         cancelInner();
/*     */       } 
/*     */     }
/*     */     
/*     */     void cancelInner() {
/* 190 */       MonoFilterWhen.FilterWhenInner a = this.asyncFilter;
/* 191 */       if (a != INNER_CANCELLED) {
/* 192 */         a = ASYNC_FILTER.getAndSet(this, INNER_CANCELLED);
/* 193 */         if (a != null && a != INNER_CANCELLED) {
/* 194 */           a.cancel();
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*     */     void innerResult(@Nullable Boolean item) {
/* 200 */       if (item != null && item.booleanValue()) {
/*     */         
/* 202 */         complete(this.value);
/*     */       } else {
/*     */         
/* 205 */         super.onComplete();
/* 206 */         discard(this.value);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void innerError(Throwable ex) {
/* 214 */       onError(ex);
/* 215 */       discard(this.value);
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 221 */       if (key == Scannable.Attr.PARENT) return this.upstream; 
/* 222 */       if (key == Scannable.Attr.TERMINATED) return (this.asyncFilter != null) ? this.asyncFilter
/* 223 */           .scanUnsafe(Scannable.Attr.TERMINATED) : super
/* 224 */           .scanUnsafe(Scannable.Attr.TERMINATED); 
/* 225 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */ 
/*     */       
/* 228 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public Stream<? extends Scannable> inners() {
/* 233 */       MonoFilterWhen.FilterWhenInner c = this.asyncFilter;
/* 234 */       return (c == null) ? Stream.<Scannable>empty() : Stream.<Scannable>of(c);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class FilterWhenInner
/*     */     implements InnerConsumer<Boolean>
/*     */   {
/*     */     final MonoFilterWhen.MonoFilterWhenMain<?> main;
/*     */     
/*     */     final boolean cancelOnNext;
/*     */     
/*     */     boolean done;
/*     */     
/*     */     volatile Subscription sub;
/* 249 */     static final AtomicReferenceFieldUpdater<FilterWhenInner, Subscription> SUB = AtomicReferenceFieldUpdater.newUpdater(FilterWhenInner.class, Subscription.class, "sub");
/*     */     
/*     */     FilterWhenInner(MonoFilterWhen.MonoFilterWhenMain<?> main, boolean cancelOnNext) {
/* 252 */       this.main = main;
/* 253 */       this.cancelOnNext = cancelOnNext;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 258 */       if (Operators.setOnce(SUB, this, s)) {
/* 259 */         s.request(Long.MAX_VALUE);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(Boolean t) {
/* 265 */       if (!this.done) {
/* 266 */         if (this.cancelOnNext) {
/* 267 */           this.sub.cancel();
/*     */         }
/* 269 */         this.done = true;
/* 270 */         this.main.innerResult(t);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 276 */       if (!this.done) {
/* 277 */         this.done = true;
/* 278 */         this.main.innerError(t);
/*     */       } else {
/* 280 */         Operators.onErrorDropped(t, this.main.currentContext());
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/* 286 */       return this.main.currentContext();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 291 */       if (!this.done) {
/*     */         
/* 293 */         this.done = true;
/* 294 */         this.main.innerResult((Boolean)null);
/*     */       } 
/*     */     }
/*     */     
/*     */     void cancel() {
/* 299 */       Operators.terminate(SUB, this);
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 305 */       if (key == Scannable.Attr.PARENT) return this.sub; 
/* 306 */       if (key == Scannable.Attr.ACTUAL) return this.main; 
/* 307 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf((this.sub == Operators.cancelledSubscription())); 
/* 308 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 309 */       if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(2147483647); 
/* 310 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf(this.done ? 0L : 1L); 
/* 311 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 313 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\MonoFilterWhen.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */