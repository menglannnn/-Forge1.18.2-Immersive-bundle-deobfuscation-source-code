/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxLimitRequest<T>
/*     */   extends InternalFluxOperator<T, T>
/*     */ {
/*     */   final long cap;
/*     */   
/*     */   FluxLimitRequest(Flux<T> flux, long cap) {
/*  35 */     super(flux);
/*  36 */     if (cap < 0L) {
/*  37 */       throw new IllegalArgumentException("cap >= 0 required but it was " + cap);
/*     */     }
/*  39 */     this.cap = cap;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/*  45 */     if (this.cap == 0L) {
/*  46 */       Operators.complete((Subscriber<?>)actual);
/*  47 */       return null;
/*     */     } 
/*  49 */     return new FluxLimitRequestSubscriber<>(actual, this.cap);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPrefetch() {
/*  54 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  59 */     if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf(this.cap); 
/*  60 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */ 
/*     */     
/*  63 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static class FluxLimitRequestSubscriber<T>
/*     */     implements InnerOperator<T, T>
/*     */   {
/*     */     final CoreSubscriber<? super T> actual;
/*     */     
/*     */     Subscription parent;
/*     */     long toProduce;
/*     */     boolean done;
/*     */     volatile long requestRemaining;
/*  76 */     static final AtomicLongFieldUpdater<FluxLimitRequestSubscriber> REQUEST_REMAINING = AtomicLongFieldUpdater.newUpdater(FluxLimitRequestSubscriber.class, "requestRemaining");
/*     */ 
/*     */     
/*     */     FluxLimitRequestSubscriber(CoreSubscriber<? super T> actual, long cap) {
/*  80 */       this.actual = actual;
/*  81 */       this.toProduce = cap;
/*  82 */       this.requestRemaining = cap;
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/*  87 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/*  92 */       if (this.done) {
/*  93 */         Operators.onNextDropped(t, this.actual.currentContext());
/*     */         return;
/*     */       } 
/*  96 */       long r = this.toProduce;
/*     */       
/*  98 */       this.toProduce = --r;
/*  99 */       this.actual.onNext(t);
/*     */       
/* 101 */       if (r > 0L && r == 0L) {
/* 102 */         this.done = true;
/* 103 */         this.parent.cancel();
/* 104 */         this.actual.onComplete();
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onError(Throwable throwable) {
/* 111 */       if (this.done) {
/* 112 */         Operators.onErrorDropped(throwable, currentContext());
/*     */         return;
/*     */       } 
/* 115 */       this.done = true;
/* 116 */       this.actual.onError(throwable);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 121 */       if (this.done) {
/*     */         return;
/*     */       }
/* 124 */       this.done = true;
/* 125 */       this.actual.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 130 */       if (Operators.validate(this.parent, s)) {
/* 131 */         this.parent = s;
/* 132 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long l) {
/*     */       while (true) {
/* 139 */         long newRequest, r = this.requestRemaining;
/*     */         
/* 141 */         if (r <= l) {
/* 142 */           newRequest = r;
/*     */         } else {
/* 144 */           newRequest = l;
/*     */         } 
/* 146 */         long u = r - newRequest;
/* 147 */         if (REQUEST_REMAINING.compareAndSet(this, r, u)) {
/* 148 */           if (newRequest != 0L) {
/* 149 */             this.parent.request(newRequest);
/*     */           }
/*     */           return;
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 158 */       this.parent.cancel();
/*     */     }
/*     */ 
/*     */     
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 163 */       if (key == Scannable.Attr.PARENT) return this.parent; 
/* 164 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 165 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */ 
/*     */       
/* 168 */       return super.scanUnsafe(key);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\FluxLimitRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */