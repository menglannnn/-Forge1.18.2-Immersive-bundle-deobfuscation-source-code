/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import io.micrometer.core.instrument.Clock;
/*     */ import io.micrometer.core.instrument.Counter;
/*     */ import io.micrometer.core.instrument.DistributionSummary;
/*     */ import io.micrometer.core.instrument.MeterRegistry;
/*     */ import io.micrometer.core.instrument.Tag;
/*     */ import io.micrometer.core.instrument.Tags;
/*     */ import io.micrometer.core.instrument.Timer;
/*     */ import java.util.LinkedList;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.BinaryOperator;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.Loggers;
/*     */ import reactor.util.Metrics;
/*     */ import reactor.util.function.Tuple2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxMetrics<T>
/*     */   extends InternalFluxOperator<T, T>
/*     */ {
/*     */   final String name;
/*     */   final Tags tags;
/*     */   final MeterRegistry registryCandidate;
/*     */   static final String REACTOR_DEFAULT_NAME = "reactor";
/*     */   static final String METER_MALFORMED = ".malformed.source";
/*     */   static final String METER_SUBSCRIBED = ".subscribed";
/*     */   static final String METER_FLOW_DURATION = ".flow.duration";
/*     */   static final String METER_ON_NEXT_DELAY = ".onNext.delay";
/*     */   static final String METER_REQUESTED = ".requested";
/*     */   static final String TAG_KEY_EXCEPTION = "exception";
/*     */   
/*     */   FluxMetrics(Flux<? extends T> flux) {
/*  59 */     super(flux);
/*     */     
/*  61 */     this.name = resolveName((Publisher<?>)flux);
/*  62 */     this.tags = resolveTags((Publisher<?>)flux, DEFAULT_TAGS_FLUX);
/*     */     
/*  64 */     this.registryCandidate = Metrics.MicrometerConfiguration.getRegistry();
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/*  69 */     return new MetricsSubscriber<>(actual, this.registryCandidate, Clock.SYSTEM, this.name, this.tags);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  74 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  75 */     return super.scanUnsafe(key);
/*     */   }
/*     */   
/*     */   static class MetricsSubscriber<T>
/*     */     implements InnerOperator<T, T>
/*     */   {
/*     */     final CoreSubscriber<? super T> actual;
/*     */     final Clock clock;
/*     */     final String sequenceName;
/*     */     final Tags commonTags;
/*     */     final MeterRegistry registry;
/*     */     final DistributionSummary requestedCounter;
/*     */     final Timer onNextIntervalTimer;
/*     */     Timer.Sample subscribeToTerminateSample;
/*  89 */     long lastNextEventNanos = -1L;
/*     */ 
/*     */     
/*     */     boolean done;
/*     */     
/*     */     Subscription s;
/*     */ 
/*     */     
/*     */     MetricsSubscriber(CoreSubscriber<? super T> actual, MeterRegistry registry, Clock clock, String sequenceName, Tags commonTags) {
/*  98 */       this.actual = actual;
/*  99 */       this.clock = clock;
/* 100 */       this.sequenceName = sequenceName;
/* 101 */       this.commonTags = commonTags;
/* 102 */       this.registry = registry;
/*     */ 
/*     */       
/* 105 */       this
/*     */ 
/*     */ 
/*     */         
/* 109 */         .onNextIntervalTimer = Timer.builder(sequenceName + ".onNext.delay").tags((Iterable)commonTags).description("Measures delays between onNext signals (or between onSubscribe and first onNext)").register(registry);
/*     */       
/* 111 */       if (!"reactor".equals(sequenceName)) {
/* 112 */         this
/*     */ 
/*     */ 
/*     */           
/* 116 */           .requestedCounter = DistributionSummary.builder(sequenceName + ".requested").tags((Iterable)commonTags).description("Counts the amount requested to a named Flux by all subscribers, until at least one requests an unbounded amount").register(registry);
/*     */       } else {
/*     */         
/* 119 */         this.requestedCounter = null;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public final CoreSubscriber<? super T> actual() {
/* 125 */       return this.actual;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final void cancel() {
/* 132 */       FluxMetrics.recordCancel(this.sequenceName, this.commonTags, this.registry, this.subscribeToTerminateSample);
/*     */       
/* 134 */       this.s.cancel();
/*     */     }
/*     */ 
/*     */     
/*     */     public final void onComplete() {
/* 139 */       if (this.done) {
/*     */         return;
/*     */       }
/* 142 */       this.done = true;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 147 */       if (this.onNextIntervalTimer.count() == 0L) {
/* 148 */         FluxMetrics.recordOnCompleteEmpty(this.sequenceName, this.commonTags, this.registry, this.subscribeToTerminateSample);
/*     */       } else {
/* 150 */         FluxMetrics.recordOnComplete(this.sequenceName, this.commonTags, this.registry, this.subscribeToTerminateSample);
/*     */       } 
/*     */       
/* 153 */       this.actual.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     public final void onError(Throwable e) {
/* 158 */       if (this.done) {
/* 159 */         FluxMetrics.recordMalformed(this.sequenceName, this.commonTags, this.registry);
/* 160 */         Operators.onErrorDropped(e, this.actual.currentContext());
/*     */         return;
/*     */       } 
/* 163 */       this.done = true;
/*     */ 
/*     */       
/* 166 */       FluxMetrics.recordOnError(this.sequenceName, this.commonTags, this.registry, this.subscribeToTerminateSample, e);
/* 167 */       this.actual.onError(e);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 172 */       if (this.done) {
/* 173 */         FluxMetrics.recordMalformed(this.sequenceName, this.commonTags, this.registry);
/* 174 */         Operators.onNextDropped(t, this.actual.currentContext());
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/* 179 */       long last = this.lastNextEventNanos;
/* 180 */       this.lastNextEventNanos = this.clock.monotonicTime();
/* 181 */       this.onNextIntervalTimer.record(this.lastNextEventNanos - last, TimeUnit.NANOSECONDS);
/*     */       
/* 183 */       this.actual.onNext(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 188 */       if (Operators.validate(this.s, s)) {
/* 189 */         FluxMetrics.recordOnSubscribe(this.sequenceName, this.commonTags, this.registry);
/* 190 */         this.subscribeToTerminateSample = Timer.start(this.clock);
/* 191 */         this.lastNextEventNanos = this.clock.monotonicTime();
/* 192 */         this.s = s;
/* 193 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public final void request(long l) {
/* 200 */       if (Operators.validate(l)) {
/* 201 */         if (this.requestedCounter != null) {
/* 202 */           this.requestedCounter.record(l);
/*     */         }
/* 204 */         this.s.request(l);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 210 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 211 */       return super.scanUnsafe(key);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 249 */   static final Tags DEFAULT_TAGS_FLUX = Tags.of("type", "Flux");
/* 250 */   static final Tags DEFAULT_TAGS_MONO = Tags.of("type", "Mono");
/*     */ 
/*     */   
/* 253 */   static final Tag TAG_ON_ERROR = Tag.of("status", "error");
/* 254 */   static final Tags TAG_ON_COMPLETE = Tags.of(new String[] { "status", "completed", "exception", "" });
/* 255 */   static final Tags TAG_ON_COMPLETE_EMPTY = Tags.of(new String[] { "status", "completedEmpty", "exception", "" });
/* 256 */   static final Tags TAG_CANCEL = Tags.of(new String[] { "status", "cancelled", "exception", "" });
/*     */   static final BiFunction<Tags, Tuple2<String, String>, Tags> TAG_ACCUMULATOR;
/* 258 */   static final Logger log = Loggers.getLogger(FluxMetrics.class);
/*     */   static {
/* 260 */     TAG_ACCUMULATOR = ((prev, tuple) -> prev.and(new Tag[] { Tag.of((String)tuple.getT1(), (String)tuple.getT2()) }));
/*     */   }
/* 262 */   static final BinaryOperator<Tags> TAG_COMBINER = Tags::and;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String resolveName(Publisher<?> source) {
/* 273 */     Scannable scannable = Scannable.from(source);
/* 274 */     if (scannable.isScanAvailable()) {
/* 275 */       String nameOrDefault = scannable.name();
/* 276 */       if (scannable.stepName()
/* 277 */         .equals(nameOrDefault)) {
/* 278 */         return "reactor";
/*     */       }
/*     */       
/* 281 */       return nameOrDefault;
/*     */     } 
/*     */ 
/*     */     
/* 285 */     log.warn("Attempting to activate metrics but the upstream is not Scannable. You might want to use `name()` (and optionally `tags()`) right before `metrics()`");
/* 286 */     return "reactor";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Tags resolveTags(Publisher<?> source, Tags tags) {
/* 299 */     Scannable scannable = Scannable.from(source);
/*     */     
/* 301 */     if (scannable.isScanAvailable()) {
/* 302 */       LinkedList<Tuple2<String, String>> scannableTags = new LinkedList<>();
/* 303 */       scannable.tags().forEach(scannableTags::push);
/* 304 */       return scannableTags.stream()
/*     */ 
/*     */ 
/*     */         
/* 308 */         .<Tags>reduce(tags, TAG_ACCUMULATOR, TAG_COMBINER);
/*     */     } 
/*     */     
/* 311 */     return tags;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void recordCancel(String name, Tags commonTags, MeterRegistry registry, Timer.Sample flowDuration) {
/* 325 */     Timer timer = Timer.builder(name + ".flow.duration").tags((Iterable)commonTags.and((Iterable)TAG_CANCEL)).description("Times the duration elapsed between a subscription and the cancellation of the sequence").register(registry);
/*     */     
/* 327 */     flowDuration.stop(timer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void recordMalformed(String name, Tags commonTags, MeterRegistry registry) {
/* 337 */     registry.counter(name + ".malformed.source", (Iterable)commonTags)
/* 338 */       .increment();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void recordOnError(String name, Tags commonTags, MeterRegistry registry, Timer.Sample flowDuration, Throwable e) {
/* 355 */     Timer timer = Timer.builder(name + ".flow.duration").tags((Iterable)commonTags.and(new Tag[] { TAG_ON_ERROR })).tag("exception", e.getClass().getName()).description("Times the duration elapsed between a subscription and the onError termination of the sequence, with the exception name as a tag.").register(registry);
/*     */     
/* 357 */     flowDuration.stop(timer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void recordOnComplete(String name, Tags commonTags, MeterRegistry registry, Timer.Sample flowDuration) {
/* 371 */     Timer timer = Timer.builder(name + ".flow.duration").tags((Iterable)commonTags.and((Iterable)TAG_ON_COMPLETE)).description("Times the duration elapsed between a subscription and the onComplete termination of a sequence that did emit some elements").register(registry);
/*     */     
/* 373 */     flowDuration.stop(timer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void recordOnCompleteEmpty(String name, Tags commonTags, MeterRegistry registry, Timer.Sample flowDuration) {
/* 387 */     Timer timer = Timer.builder(name + ".flow.duration").tags((Iterable)commonTags.and((Iterable)TAG_ON_COMPLETE_EMPTY)).description("Times the duration elapsed between a subscription and the onComplete termination of a sequence that didn't emit any element").register(registry);
/*     */     
/* 389 */     flowDuration.stop(timer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void recordOnSubscribe(String name, Tags commonTags, MeterRegistry registry) {
/* 399 */     Counter.builder(name + ".subscribed")
/* 400 */       .tags((Iterable)commonTags)
/* 401 */       .description("Counts how many Reactor sequences have been subscribed to")
/* 402 */       .register(registry)
/* 403 */       .increment();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\FluxMetrics.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */