/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import java.util.function.Function;
/*    */ import org.reactivestreams.Publisher;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Scannable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MonoOnErrorResume<T>
/*    */   extends InternalMonoOperator<T, T>
/*    */ {
/*    */   final Function<? super Throwable, ? extends Publisher<? extends T>> nextFactory;
/*    */   
/*    */   MonoOnErrorResume(Mono<? extends T> source, Function<? super Throwable, ? extends Mono<? extends T>> nextFactory) {
/* 39 */     super(source);
/* 40 */     this.nextFactory = (Function<? super Throwable, ? extends Publisher<? extends T>>)Objects.requireNonNull(nextFactory, "nextFactory");
/*    */   }
/*    */ 
/*    */   
/*    */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/* 45 */     return new FluxOnErrorResume.ResumeSubscriber<>(actual, this.nextFactory);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 50 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 51 */     return super.scanUnsafe(key);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\MonoOnErrorResume.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */