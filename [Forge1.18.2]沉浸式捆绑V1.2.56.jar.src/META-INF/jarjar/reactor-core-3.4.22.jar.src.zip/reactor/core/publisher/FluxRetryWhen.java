/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.stream.Stream;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CorePublisher;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ import reactor.util.context.ContextView;
/*     */ import reactor.util.retry.Retry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxRetryWhen<T>
/*     */   extends InternalFluxOperator<T, T>
/*     */ {
/*     */   final Retry whenSourceFactory;
/*     */   
/*     */   FluxRetryWhen(Flux<? extends T> source, Retry whenSourceFactory) {
/*  49 */     super(source);
/*  50 */     this.whenSourceFactory = Objects.<Retry>requireNonNull(whenSourceFactory, "whenSourceFactory");
/*     */   }
/*     */ 
/*     */   
/*     */   static <T> void subscribe(CoreSubscriber<? super T> s, Retry whenSourceFactory, CorePublisher<? extends T> source) {
/*     */     Publisher<?> p;
/*  56 */     RetryWhenOtherSubscriber other = new RetryWhenOtherSubscriber();
/*     */     
/*  58 */     CoreSubscriber<T> serial = Operators.serialize(s);
/*     */ 
/*     */     
/*  61 */     RetryWhenMainSubscriber<T> main = new RetryWhenMainSubscriber<>(serial, other.completionSignal, source, whenSourceFactory.retryContext());
/*     */     
/*  63 */     other.main = main;
/*  64 */     serial.onSubscribe(main);
/*     */ 
/*     */     
/*     */     try {
/*  68 */       p = Objects.<Publisher>requireNonNull(whenSourceFactory.generateCompanion(other), "The whenSourceFactory returned a null Publisher");
/*     */     }
/*  70 */     catch (Throwable e) {
/*  71 */       s.onError(Operators.onOperatorError(e, s.currentContext()));
/*     */       return;
/*     */     } 
/*  74 */     p.subscribe((Subscriber)other);
/*     */     
/*  76 */     if (!main.cancelled) {
/*  77 */       source.subscribe(main);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/*  83 */     subscribe(actual, this.whenSourceFactory, this.source);
/*  84 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  89 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  90 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class RetryWhenMainSubscriber<T>
/*     */     extends Operators.MultiSubscriptionSubscriber<T, T>
/*     */     implements Retry.RetrySignal
/*     */   {
/*     */     final Operators.DeferredSubscription otherArbiter;
/*     */     
/*     */     final Sinks.Many<Retry.RetrySignal> signaller;
/*     */     final CorePublisher<? extends T> source;
/* 102 */     long totalFailureIndex = 0L;
/* 103 */     long subsequentFailureIndex = 0L; @Nullable
/* 104 */     Throwable lastFailure = null;
/*     */     
/*     */     final ContextView retryContext;
/*     */     
/*     */     Context context;
/*     */     
/*     */     volatile int wip;
/*     */     
/* 112 */     static final AtomicIntegerFieldUpdater<RetryWhenMainSubscriber> WIP = AtomicIntegerFieldUpdater.newUpdater(RetryWhenMainSubscriber.class, "wip");
/*     */ 
/*     */     
/*     */     long produced;
/*     */ 
/*     */ 
/*     */     
/*     */     RetryWhenMainSubscriber(CoreSubscriber<? super T> actual, Sinks.Many<Retry.RetrySignal> signaller, CorePublisher<? extends T> source, ContextView retryContext) {
/* 120 */       super(actual);
/* 121 */       this.signaller = signaller;
/* 122 */       this.source = source;
/* 123 */       this.otherArbiter = new Operators.DeferredSubscription();
/* 124 */       this.context = actual.currentContext();
/* 125 */       this.retryContext = retryContext;
/*     */     }
/*     */ 
/*     */     
/*     */     public long totalRetries() {
/* 130 */       return this.totalFailureIndex - 1L;
/*     */     }
/*     */ 
/*     */     
/*     */     public long totalRetriesInARow() {
/* 135 */       return this.subsequentFailureIndex - 1L;
/*     */     }
/*     */ 
/*     */     
/*     */     public Throwable failure() {
/* 140 */       assert this.lastFailure != null;
/* 141 */       return this.lastFailure;
/*     */     }
/*     */ 
/*     */     
/*     */     public ContextView retryContextView() {
/* 146 */       return this.retryContext;
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/* 151 */       return this.context;
/*     */     }
/*     */ 
/*     */     
/*     */     public Stream<? extends Scannable> inners() {
/* 156 */       return Stream.of(new Scannable[] { Scannable.from(this.signaller), this.otherArbiter });
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 161 */       if (!this.cancelled) {
/* 162 */         this.otherArbiter.cancel();
/* 163 */         super.cancel();
/*     */       } 
/*     */     }
/*     */     
/*     */     void swap(Subscription w) {
/* 168 */       this.otherArbiter.set(w);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 173 */       this.subsequentFailureIndex = 0L;
/* 174 */       this.actual.onNext(t);
/*     */       
/* 176 */       this.produced++;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 181 */       this.totalFailureIndex++;
/* 182 */       this.subsequentFailureIndex++;
/* 183 */       this.lastFailure = t;
/* 184 */       long p = this.produced;
/* 185 */       if (p != 0L) {
/* 186 */         this.produced = 0L;
/* 187 */         produced(p);
/*     */       } 
/*     */       
/* 190 */       this.signaller.emitNext(this, Sinks.EmitFailureHandler.FAIL_FAST);
/*     */       
/* 192 */       this.otherArbiter.request(1L);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 197 */       this.lastFailure = null;
/* 198 */       this.otherArbiter.cancel();
/*     */       
/* 200 */       this.actual.onComplete();
/*     */     }
/*     */     
/*     */     void resubscribe(Object trigger) {
/* 204 */       if (WIP.getAndIncrement(this) == 0) {
/*     */         do {
/* 206 */           if (this.cancelled) {
/*     */             return;
/*     */           }
/*     */ 
/*     */ 
/*     */           
/* 212 */           if (trigger instanceof ContextView) {
/* 213 */             this.context = this.context.putAll((ContextView)trigger);
/*     */           }
/*     */           
/* 216 */           this.source.subscribe(this);
/*     */         }
/* 218 */         while (WIP.decrementAndGet(this) != 0);
/*     */       }
/*     */     }
/*     */     
/*     */     void whenError(Throwable e) {
/* 223 */       super.cancel();
/*     */       
/* 225 */       this.actual.onError(e);
/*     */     }
/*     */     
/*     */     void whenComplete() {
/* 229 */       super.cancel();
/*     */       
/* 231 */       this.actual.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 236 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 237 */       return super.scanUnsafe(key);
/*     */     }
/*     */   }
/*     */   
/*     */   static final class RetryWhenOtherSubscriber
/*     */     extends Flux<Retry.RetrySignal>
/*     */     implements InnerConsumer<Object>, OptimizableOperator<Retry.RetrySignal, Retry.RetrySignal> {
/*     */     FluxRetryWhen.RetryWhenMainSubscriber<?> main;
/* 245 */     final Sinks.Many<Retry.RetrySignal> completionSignal = Sinks.many().multicast().onBackpressureBuffer();
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/* 249 */       return this.main.currentContext();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 255 */       if (key == Scannable.Attr.PARENT) return this.main.otherArbiter; 
/* 256 */       if (key == Scannable.Attr.ACTUAL) return this.main; 
/* 257 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 259 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 264 */       this.main.swap(s);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(Object t) {
/* 269 */       this.main.resubscribe(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 274 */       this.main.whenError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 279 */       this.main.whenComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     public void subscribe(CoreSubscriber<? super Retry.RetrySignal> actual) {
/* 284 */       this.completionSignal.asFlux().subscribe(actual);
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super Retry.RetrySignal> subscribeOrReturn(CoreSubscriber<? super Retry.RetrySignal> actual) {
/* 289 */       return actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public CorePublisher<Retry.RetrySignal> source() {
/* 294 */       return this.completionSignal.asFlux();
/*     */     }
/*     */ 
/*     */     
/*     */     public OptimizableOperator<?, ? extends Retry.RetrySignal> nextOptimizableSource() {
/* 299 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\FluxRetryWhen.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */