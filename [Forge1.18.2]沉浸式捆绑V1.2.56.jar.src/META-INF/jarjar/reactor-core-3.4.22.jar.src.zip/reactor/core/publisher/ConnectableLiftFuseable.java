/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import java.util.function.Consumer;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Disposable;
/*    */ import reactor.core.Fuseable;
/*    */ import reactor.core.Scannable;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class ConnectableLiftFuseable<I, O>
/*    */   extends InternalConnectableFluxOperator<I, O>
/*    */   implements Scannable, Fuseable
/*    */ {
/*    */   final Operators.LiftFunction<I, O> liftFunction;
/*    */   
/*    */   ConnectableLiftFuseable(ConnectableFlux<I> p, Operators.LiftFunction<I, O> liftFunction) {
/* 38 */     super(Objects.<ConnectableFlux<I>>requireNonNull(p, "source"));
/* 39 */     this.liftFunction = liftFunction;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getPrefetch() {
/* 44 */     return this.source.getPrefetch();
/*    */   }
/*    */ 
/*    */   
/*    */   public void connect(Consumer<? super Disposable> cancelSupport) {
/* 49 */     this.source.connect(cancelSupport);
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 55 */     if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(this.source.getPrefetch()); 
/* 56 */     if (key == Scannable.Attr.PARENT) return this.source; 
/* 57 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.from(this.source).scanUnsafe(key); 
/* 58 */     if (key == Scannable.Attr.LIFTER) return this.liftFunction.name; 
/* 59 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public String stepName() {
/* 64 */     if (this.source instanceof Scannable) {
/* 65 */       return Scannable.from(this.source).stepName();
/*    */     }
/* 67 */     return super.stepName();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public final CoreSubscriber<? super I> subscribeOrReturn(CoreSubscriber<? super O> actual) {
/* 73 */     CoreSubscriber<? super I> input = this.liftFunction.lifter.apply(this.source, actual);
/*    */     
/* 75 */     Objects.requireNonNull(input, "Lifted subscriber MUST NOT be null");
/*    */     
/* 77 */     if (actual instanceof Fuseable.QueueSubscription && !(input instanceof Fuseable.QueueSubscription))
/*    */     {
/*    */       
/* 80 */       input = new FluxHide.SuppressFuseableSubscriber<>(input);
/*    */     }
/*    */     
/* 83 */     return input;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\ConnectableLiftFuseable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */