package reactor.core.publisher;

class QueueDrainSubscriberPad4 extends QueueDrainSubscriberPad3 {
  volatile long q1;
  
  volatile long q2;
  
  volatile long q3;
  
  volatile long q4;
  
  volatile long q5;
  
  volatile long q6;
  
  volatile long q7;
  
  volatile long q8;
  
  volatile long q9;
  
  volatile long q10;
  
  volatile long q11;
  
  volatile long q12;
  
  volatile long q13;
  
  volatile long q14;
  
  volatile long q15;
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\QueueDrainSubscriberPad4.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */