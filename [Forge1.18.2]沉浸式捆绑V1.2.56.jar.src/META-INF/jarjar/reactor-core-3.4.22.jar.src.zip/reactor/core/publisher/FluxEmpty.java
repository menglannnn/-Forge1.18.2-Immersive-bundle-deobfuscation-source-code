/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import org.reactivestreams.Subscriber;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Fuseable;
/*    */ import reactor.core.Scannable;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class FluxEmpty
/*    */   extends Flux<Object>
/*    */   implements Fuseable.ScalarCallable<Object>, SourceProducer<Object>
/*    */ {
/* 34 */   private static final Flux<Object> INSTANCE = new FluxEmpty();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void subscribe(CoreSubscriber<? super Object> actual) {
/* 42 */     Operators.complete((Subscriber<?>)actual);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 47 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 48 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static <T> Flux<T> instance() {
/* 59 */     return (Flux)INSTANCE;
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public Object call() throws Exception {
/* 65 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\FluxEmpty.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */