/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import java.util.function.Supplier;
/*    */ import org.reactivestreams.Subscriber;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Scannable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MonoDefer<T>
/*    */   extends Mono<T>
/*    */   implements SourceProducer<T>
/*    */ {
/*    */   final Supplier<? extends Mono<? extends T>> supplier;
/*    */   
/*    */   MonoDefer(Supplier<? extends Mono<? extends T>> supplier) {
/* 36 */     this.supplier = Objects.<Supplier<? extends Mono<? extends T>>>requireNonNull(supplier, "supplier");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void subscribe(CoreSubscriber<? super T> actual) {
/*    */     Mono<? extends T> p;
/*    */     try {
/* 44 */       p = Objects.<Mono<? extends T>>requireNonNull(this.supplier.get(), "The Mono returned by the supplier is null");
/*    */     
/*    */     }
/* 47 */     catch (Throwable e) {
/* 48 */       Operators.error((Subscriber<?>)actual, Operators.onOperatorError(e, actual.currentContext()));
/*    */       
/*    */       return;
/*    */     } 
/* 52 */     p.subscribe(actual);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 57 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 58 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\MonoDefer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */