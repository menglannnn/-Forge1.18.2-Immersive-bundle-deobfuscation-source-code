/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import org.reactivestreams.Publisher;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Fuseable;
/*    */ import reactor.core.Scannable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MonoOnAssembly<T>
/*    */   extends InternalMonoOperator<T, T>
/*    */   implements Fuseable, AssemblyOp
/*    */ {
/*    */   final FluxOnAssembly.AssemblySnapshot stacktrace;
/*    */   
/*    */   MonoOnAssembly(Mono<? extends T> source, FluxOnAssembly.AssemblySnapshot stacktrace) {
/* 47 */     super(source);
/* 48 */     this.stacktrace = stacktrace;
/*    */   }
/*    */ 
/*    */   
/*    */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/* 53 */     if (actual instanceof Fuseable.ConditionalSubscriber) {
/* 54 */       Fuseable.ConditionalSubscriber<? super T> cs = (Fuseable.ConditionalSubscriber<? super T>)actual;
/*    */       
/* 56 */       return new FluxOnAssembly.OnAssemblyConditionalSubscriber<>(cs, this.stacktrace, (Publisher<?>)this.source, (Publisher<?>)this);
/*    */     } 
/*    */     
/* 59 */     return new FluxOnAssembly.OnAssemblySubscriber<>(actual, this.stacktrace, (Publisher<?>)this.source, (Publisher<?>)this);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 65 */     if (key == Scannable.Attr.ACTUAL_METADATA) return Boolean.valueOf(!this.stacktrace.isCheckpoint); 
/* 66 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*    */     
/* 68 */     return super.scanUnsafe(key);
/*    */   }
/*    */ 
/*    */   
/*    */   public String stepName() {
/* 73 */     return this.stacktrace.operatorAssemblyInformation();
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 78 */     return this.stacktrace.operatorAssemblyInformation();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\MonoOnAssembly.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */