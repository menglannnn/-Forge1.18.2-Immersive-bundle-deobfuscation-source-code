/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Queue;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*     */ import java.util.function.Consumer;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.concurrent.Queues;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxOnBackpressureBuffer<O>
/*     */   extends InternalFluxOperator<O, O>
/*     */   implements Fuseable
/*     */ {
/*     */   final Consumer<? super O> onOverflow;
/*     */   final int bufferSize;
/*     */   final boolean unbounded;
/*     */   
/*     */   FluxOnBackpressureBuffer(Flux<? extends O> source, int bufferSize, boolean unbounded, @Nullable Consumer<? super O> onOverflow) {
/*  47 */     super(source);
/*  48 */     if (bufferSize < 1) {
/*  49 */       throw new IllegalArgumentException("Buffer Size must be strictly positive");
/*     */     }
/*  51 */     this.bufferSize = bufferSize;
/*  52 */     this.unbounded = unbounded;
/*  53 */     this.onOverflow = onOverflow;
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super O> subscribeOrReturn(CoreSubscriber<? super O> actual) {
/*  58 */     return new BackpressureBufferSubscriber<>(actual, this.bufferSize, this.unbounded, this.onOverflow);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  66 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  67 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPrefetch() {
/*  72 */     return Integer.MAX_VALUE;
/*     */   }
/*     */ 
/*     */   
/*     */   static final class BackpressureBufferSubscriber<T>
/*     */     implements Fuseable.QueueSubscription<T>, InnerOperator<T, T>
/*     */   {
/*     */     final CoreSubscriber<? super T> actual;
/*     */     
/*     */     final Context ctx;
/*     */     
/*     */     final Queue<T> queue;
/*     */     
/*     */     final int capacityOrSkip;
/*     */     
/*     */     final Consumer<? super T> onOverflow;
/*     */     
/*     */     Subscription s;
/*     */     
/*     */     volatile boolean cancelled;
/*     */     volatile boolean enabledFusion;
/*     */     volatile boolean done;
/*     */     Throwable error;
/*     */     volatile int wip;
/*  96 */     static final AtomicIntegerFieldUpdater<BackpressureBufferSubscriber> WIP = AtomicIntegerFieldUpdater.newUpdater(BackpressureBufferSubscriber.class, "wip");
/*     */ 
/*     */     
/*     */     volatile int discardGuard;
/*     */ 
/*     */     
/* 102 */     static final AtomicIntegerFieldUpdater<BackpressureBufferSubscriber> DISCARD_GUARD = AtomicIntegerFieldUpdater.newUpdater(BackpressureBufferSubscriber.class, "discardGuard");
/*     */ 
/*     */     
/*     */     volatile long requested;
/*     */ 
/*     */     
/* 108 */     static final AtomicLongFieldUpdater<BackpressureBufferSubscriber> REQUESTED = AtomicLongFieldUpdater.newUpdater(BackpressureBufferSubscriber.class, "requested");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     BackpressureBufferSubscriber(CoreSubscriber<? super T> actual, int bufferSize, boolean unbounded, @Nullable Consumer<? super T> onOverflow) {
/*     */       Queue<T> q;
/* 115 */       this.actual = actual;
/* 116 */       this.ctx = actual.currentContext();
/* 117 */       this.onOverflow = onOverflow;
/*     */ 
/*     */ 
/*     */       
/* 121 */       if (unbounded) {
/* 122 */         q = Queues.unbounded(bufferSize).get();
/*     */       } else {
/*     */         
/* 125 */         q = Queues.get(bufferSize).get();
/*     */       } 
/*     */       
/* 128 */       if (!unbounded && Queues.capacity(q) > bufferSize) {
/* 129 */         this.capacityOrSkip = bufferSize;
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 134 */         this.capacityOrSkip = Integer.MAX_VALUE;
/*     */       } 
/*     */       
/* 137 */       this.queue = q;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 143 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 144 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf(this.requested); 
/* 145 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf((this.done && this.queue.isEmpty())); 
/* 146 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(this.cancelled); 
/* 147 */       if (key == Scannable.Attr.BUFFERED) return Integer.valueOf(this.queue.size()); 
/* 148 */       if (key == Scannable.Attr.ERROR) return this.error; 
/* 149 */       if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(2147483647); 
/* 150 */       if (key == Scannable.Attr.DELAY_ERROR) return Boolean.valueOf(true); 
/* 151 */       if (key == Scannable.Attr.CAPACITY) return Integer.valueOf((this.capacityOrSkip == Integer.MAX_VALUE) ? Queues.capacity(this.queue) : this.capacityOrSkip); 
/* 152 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 154 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 159 */       if (Operators.validate(this.s, s)) {
/* 160 */         this.s = s;
/* 161 */         this.actual.onSubscribe(this);
/* 162 */         s.request(Long.MAX_VALUE);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 168 */       if (this.done) {
/* 169 */         Operators.onNextDropped(t, this.ctx);
/*     */         return;
/*     */       } 
/* 172 */       if (this.cancelled) {
/* 173 */         Operators.onDiscard(t, this.ctx);
/*     */       }
/*     */       
/* 176 */       if ((this.capacityOrSkip != Integer.MAX_VALUE && this.queue.size() >= this.capacityOrSkip) || !this.queue.offer(t)) {
/* 177 */         Throwable ex = Operators.onOperatorError(this.s, Exceptions.failWithOverflow(), t, this.ctx);
/* 178 */         if (this.onOverflow != null) {
/*     */           try {
/* 180 */             this.onOverflow.accept(t);
/*     */           }
/* 182 */           catch (Throwable e) {
/* 183 */             Exceptions.throwIfFatal(e);
/* 184 */             ex.initCause(e);
/*     */           } 
/*     */         }
/* 187 */         Operators.onDiscard(t, this.ctx);
/* 188 */         onError(ex);
/*     */         return;
/*     */       } 
/* 191 */       drain(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 196 */       if (this.done) {
/* 197 */         Operators.onErrorDropped(t, this.ctx);
/*     */         return;
/*     */       } 
/* 200 */       this.error = t;
/* 201 */       this.done = true;
/* 202 */       drain(null);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 207 */       if (this.done) {
/*     */         return;
/*     */       }
/* 210 */       this.done = true;
/* 211 */       drain(null);
/*     */     }
/*     */     
/*     */     void drain(@Nullable T dataSignal) {
/* 215 */       if (WIP.getAndIncrement(this) != 0) {
/* 216 */         if (dataSignal != null && this.cancelled) {
/* 217 */           Operators.onDiscard(dataSignal, this.actual.currentContext());
/*     */         }
/*     */         
/*     */         return;
/*     */       } 
/* 222 */       int missed = 1;
/*     */       
/*     */       do {
/* 225 */         CoreSubscriber<? super T> coreSubscriber = this.actual;
/* 226 */         if (coreSubscriber != null) {
/*     */           
/* 228 */           if (this.enabledFusion) {
/* 229 */             drainFused((Subscriber<? super T>)coreSubscriber);
/*     */           } else {
/*     */             
/* 232 */             drainRegular((Subscriber<? super T>)coreSubscriber);
/*     */           } 
/*     */           
/*     */           return;
/*     */         } 
/* 237 */         missed = WIP.addAndGet(this, -missed);
/* 238 */       } while (missed != 0);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void drainRegular(Subscriber<? super T> a) {
/* 245 */       int missed = 1;
/*     */       
/* 247 */       Queue<T> q = this.queue;
/*     */ 
/*     */       
/*     */       do {
/* 251 */         long r = this.requested;
/* 252 */         long e = 0L;
/*     */         
/* 254 */         while (r != e) {
/* 255 */           boolean d = this.done;
/*     */           
/* 257 */           T t = q.poll();
/* 258 */           boolean empty = (t == null);
/*     */           
/* 260 */           if (checkTerminated(d, empty, a, t)) {
/*     */             return;
/*     */           }
/*     */           
/* 264 */           if (empty) {
/*     */             break;
/*     */           }
/*     */           
/* 268 */           a.onNext(t);
/*     */           
/* 270 */           e++;
/*     */         } 
/*     */         
/* 273 */         if (r == e && 
/* 274 */           checkTerminated(this.done, q.isEmpty(), a, null)) {
/*     */           return;
/*     */         }
/*     */ 
/*     */         
/* 279 */         if (e != 0L && r != Long.MAX_VALUE) {
/* 280 */           REQUESTED.addAndGet(this, -e);
/*     */         }
/*     */         
/* 283 */         missed = WIP.addAndGet(this, -missed);
/* 284 */       } while (missed != 0);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void drainFused(Subscriber<? super T> a) {
/* 291 */       int missed = 1;
/*     */       
/* 293 */       Queue<T> q = this.queue;
/*     */ 
/*     */       
/*     */       do {
/* 297 */         if (this.cancelled) {
/*     */ 
/*     */           
/* 300 */           clear();
/*     */           
/*     */           return;
/*     */         } 
/* 304 */         boolean d = this.done;
/*     */         
/* 306 */         a.onNext(null);
/*     */         
/* 308 */         if (d) {
/* 309 */           Throwable ex = this.error;
/* 310 */           if (ex != null) {
/* 311 */             a.onError(ex);
/*     */           } else {
/*     */             
/* 314 */             a.onComplete();
/*     */           } 
/*     */           
/*     */           return;
/*     */         } 
/* 319 */         missed = WIP.addAndGet(this, -missed);
/* 320 */       } while (missed != 0);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 328 */       if (Operators.validate(n)) {
/* 329 */         Operators.addCap(REQUESTED, this, n);
/* 330 */         drain(null);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 336 */       if (!this.cancelled) {
/* 337 */         this.cancelled = true;
/*     */         
/* 339 */         this.s.cancel();
/*     */         
/* 341 */         if (WIP.getAndIncrement(this) == 0 && 
/* 342 */           !this.enabledFusion)
/*     */         {
/*     */           
/* 345 */           Operators.onDiscardQueueWithClear(this.queue, this.ctx, null);
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public T poll() {
/* 354 */       return this.queue.poll();
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 359 */       return this.queue.size();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isEmpty() {
/* 364 */       return this.queue.isEmpty();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void clear() {
/* 372 */       if (DISCARD_GUARD.getAndIncrement(this) != 0) {
/*     */         return;
/*     */       }
/*     */       
/* 376 */       int missed = 1;
/*     */       
/*     */       while (true) {
/* 379 */         Operators.onDiscardQueueWithClear(this.queue, this.ctx, null);
/*     */         
/* 381 */         int dg = this.discardGuard;
/* 382 */         if (missed == dg) {
/* 383 */           missed = DISCARD_GUARD.addAndGet(this, -missed);
/* 384 */           if (missed == 0) {
/*     */             break;
/*     */           }
/*     */           continue;
/*     */         } 
/* 389 */         missed = dg;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int requestFusion(int requestedMode) {
/* 396 */       if ((requestedMode & 0x2) != 0) {
/* 397 */         this.enabledFusion = true;
/* 398 */         return 2;
/*     */       } 
/* 400 */       return 0;
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 405 */       return this.actual;
/*     */     }
/*     */     
/*     */     boolean checkTerminated(boolean d, boolean empty, Subscriber<? super T> a, @Nullable T v) {
/* 409 */       if (this.cancelled) {
/* 410 */         this.s.cancel();
/* 411 */         Operators.onDiscard(v, this.ctx);
/* 412 */         Operators.onDiscardQueueWithClear(this.queue, this.ctx, null);
/* 413 */         return true;
/*     */       } 
/* 415 */       if (d)
/*     */       {
/* 417 */         if (empty) {
/* 418 */           Throwable e = this.error;
/* 419 */           if (e != null) {
/* 420 */             a.onError(e);
/*     */           } else {
/*     */             
/* 423 */             a.onComplete();
/*     */           } 
/* 425 */           return true;
/*     */         } 
/*     */       }
/* 428 */       return false;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\FluxOnBackpressureBuffer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */