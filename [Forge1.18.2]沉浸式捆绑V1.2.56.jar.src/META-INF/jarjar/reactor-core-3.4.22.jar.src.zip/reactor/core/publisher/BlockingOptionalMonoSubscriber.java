/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Optional;
/*     */ import java.util.concurrent.CountDownLatch;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.core.scheduler.Schedulers;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class BlockingOptionalMonoSubscriber<T>
/*     */   extends CountDownLatch
/*     */   implements InnerConsumer<T>, Disposable
/*     */ {
/*     */   T value;
/*     */   Throwable error;
/*     */   Subscription s;
/*     */   volatile boolean cancelled;
/*     */   
/*     */   BlockingOptionalMonoSubscriber() {
/*  49 */     super(1);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onNext(T t) {
/*  54 */     if (this.value == null) {
/*  55 */       this.value = t;
/*  56 */       countDown();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void onError(Throwable t) {
/*  62 */     if (this.value == null) {
/*  63 */       this.error = t;
/*     */     }
/*  65 */     countDown();
/*     */   }
/*     */ 
/*     */   
/*     */   public final void onSubscribe(Subscription s) {
/*  70 */     this.s = s;
/*  71 */     if (!this.cancelled) {
/*  72 */       s.request(Long.MAX_VALUE);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public final void onComplete() {
/*  78 */     countDown();
/*     */   }
/*     */ 
/*     */   
/*     */   public Context currentContext() {
/*  83 */     return Context.empty();
/*     */   }
/*     */ 
/*     */   
/*     */   public final void dispose() {
/*  88 */     this.cancelled = true;
/*  89 */     Subscription s = this.s;
/*  90 */     if (s != null) {
/*  91 */       this.s = null;
/*  92 */       s.cancel();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final Optional<T> blockingGet() {
/* 103 */     if (Schedulers.isInNonBlockingThread()) {
/* 104 */       throw new IllegalStateException("blockOptional() is blocking, which is not supported in thread " + Thread.currentThread().getName());
/*     */     }
/* 106 */     if (getCount() != 0L) {
/*     */       try {
/* 108 */         await();
/*     */       }
/* 110 */       catch (InterruptedException ex) {
/* 111 */         dispose();
/* 112 */         RuntimeException re = Exceptions.propagate(ex);
/*     */         
/* 114 */         re.addSuppressed(new Exception("#blockOptional() has been interrupted"));
/* 115 */         throw re;
/*     */       } 
/*     */     }
/*     */     
/* 119 */     Throwable e = this.error;
/* 120 */     if (e != null) {
/* 121 */       RuntimeException re = Exceptions.propagate(e);
/*     */       
/* 123 */       re.addSuppressed(new Exception("#block terminated with an error"));
/* 124 */       throw re;
/*     */     } 
/* 126 */     return Optional.ofNullable(this.value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final Optional<T> blockingGet(long timeout, TimeUnit unit) {
/* 139 */     if (Schedulers.isInNonBlockingThread()) {
/* 140 */       throw new IllegalStateException("blockOptional() is blocking, which is not supported in thread " + Thread.currentThread().getName());
/*     */     }
/* 142 */     if (getCount() != 0L) {
/*     */       try {
/* 144 */         if (!await(timeout, unit)) {
/* 145 */           dispose();
/* 146 */           throw new IllegalStateException("Timeout on blocking read for " + timeout + " " + unit);
/*     */         }
/*     */       
/* 149 */       } catch (InterruptedException ex) {
/* 150 */         dispose();
/* 151 */         RuntimeException re = Exceptions.propagate(ex);
/*     */         
/* 153 */         re.addSuppressed(new Exception("#blockOptional(timeout) has been interrupted"));
/* 154 */         throw re;
/*     */       } 
/*     */     }
/*     */     
/* 158 */     Throwable e = this.error;
/* 159 */     if (e != null) {
/* 160 */       RuntimeException re = Exceptions.propagate(e);
/*     */       
/* 162 */       re.addSuppressed(new Exception("#block terminated with an error"));
/* 163 */       throw re;
/*     */     } 
/* 165 */     return Optional.ofNullable(this.value);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/* 171 */     if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf((getCount() == 0L)); 
/* 172 */     if (key == Scannable.Attr.PARENT) return this.s; 
/* 173 */     if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(this.cancelled); 
/* 174 */     if (key == Scannable.Attr.ERROR) return this.error; 
/* 175 */     if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(2147483647); 
/* 176 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */     
/* 178 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDisposed() {
/* 183 */     return (this.cancelled || getCount() == 0L);
/*     */   }
/*     */ 
/*     */   
/*     */   public String stepName() {
/* 188 */     return "blockOptional";
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\BlockingOptionalMonoSubscriber.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */