/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import java.util.function.Consumer;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Fuseable;
/*    */ import reactor.core.Scannable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MonoDoOnEachFuseable<T>
/*    */   extends InternalMonoOperator<T, T>
/*    */   implements Fuseable
/*    */ {
/*    */   final Consumer<? super Signal<T>> onSignal;
/*    */   
/*    */   MonoDoOnEachFuseable(Mono<? extends T> source, Consumer<? super Signal<T>> onSignal) {
/* 38 */     super(source);
/* 39 */     this.onSignal = Objects.<Consumer<? super Signal<T>>>requireNonNull(onSignal, "onSignal");
/*    */   }
/*    */ 
/*    */   
/*    */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/* 44 */     return FluxDoOnEach.createSubscriber(actual, this.onSignal, true, true);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 49 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 50 */     return super.scanUnsafe(key);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\MonoDoOnEachFuseable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */