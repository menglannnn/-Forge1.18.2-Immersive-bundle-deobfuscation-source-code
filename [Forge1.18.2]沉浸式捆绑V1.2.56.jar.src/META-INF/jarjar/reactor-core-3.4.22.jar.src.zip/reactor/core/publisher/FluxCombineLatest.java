/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.Objects;
/*     */ import java.util.Queue;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.stream.Stream;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxCombineLatest<T, R>
/*     */   extends Flux<R>
/*     */   implements Fuseable, SourceProducer<R>
/*     */ {
/*     */   final Publisher<? extends T>[] array;
/*     */   final Iterable<? extends Publisher<? extends T>> iterable;
/*     */   final Function<Object[], R> combiner;
/*     */   final Supplier<? extends Queue<SourceAndArray>> queueSupplier;
/*     */   final int prefetch;
/*     */   
/*     */   FluxCombineLatest(Publisher<? extends T>[] array, Function<Object[], R> combiner, Supplier<? extends Queue<SourceAndArray>> queueSupplier, int prefetch) {
/*  61 */     if (prefetch <= 0) {
/*  62 */       throw new IllegalArgumentException("prefetch > 0 required but it was " + prefetch);
/*     */     }
/*     */     
/*  65 */     this.array = Objects.<Publisher<? extends T>[]>requireNonNull(array, "array");
/*  66 */     this.iterable = null;
/*  67 */     this.combiner = Objects.<Function<Object[], R>>requireNonNull(combiner, "combiner");
/*  68 */     this.queueSupplier = Objects.<Supplier<? extends Queue<SourceAndArray>>>requireNonNull(queueSupplier, "queueSupplier");
/*  69 */     this.prefetch = prefetch;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   FluxCombineLatest(Iterable<? extends Publisher<? extends T>> iterable, Function<Object[], R> combiner, Supplier<? extends Queue<SourceAndArray>> queueSupplier, int prefetch) {
/*  75 */     if (prefetch < 0) {
/*  76 */       throw new IllegalArgumentException("prefetch > 0 required but it was " + prefetch);
/*     */     }
/*     */     
/*  79 */     this.array = null;
/*  80 */     this.iterable = Objects.<Iterable<? extends Publisher<? extends T>>>requireNonNull(iterable, "iterable");
/*  81 */     this.combiner = Objects.<Function<Object[], R>>requireNonNull(combiner, "combiner");
/*  82 */     this.queueSupplier = Objects.<Supplier<? extends Queue<SourceAndArray>>>requireNonNull(queueSupplier, "queueSupplier");
/*  83 */     this.prefetch = prefetch;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPrefetch() {
/*  88 */     return this.prefetch;
/*     */   }
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super R> actual) {
/*     */     Publisher[] arrayOfPublisher;
/*     */     int n;
/*  94 */     Publisher<? extends T>[] a = this.array;
/*     */     
/*  96 */     if (a == null) {
/*  97 */       Iterator<? extends Publisher<? extends T>> it; n = 0;
/*  98 */       arrayOfPublisher = new Publisher[8];
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 103 */         it = Objects.<Iterator<? extends Publisher<? extends T>>>requireNonNull(this.iterable.iterator(), "The iterator returned is null");
/*     */       }
/* 105 */       catch (Throwable e) {
/* 106 */         Operators.error((Subscriber<?>)actual, Operators.onOperatorError(e, actual
/* 107 */               .currentContext()));
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/*     */       while (true) {
/*     */         boolean b;
/*     */         Publisher<? extends T> p;
/*     */         try {
/* 116 */           b = it.hasNext();
/*     */         }
/* 118 */         catch (Throwable e) {
/* 119 */           Operators.error((Subscriber<?>)actual, Operators.onOperatorError(e, actual
/* 120 */                 .currentContext()));
/*     */           
/*     */           return;
/*     */         } 
/* 124 */         if (!b) {
/*     */           break;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         try {
/* 131 */           p = Objects.<Publisher<? extends T>>requireNonNull(it.next(), "The Publisher returned by the iterator is null");
/*     */         
/*     */         }
/* 134 */         catch (Throwable e) {
/* 135 */           Operators.error((Subscriber<?>)actual, Operators.onOperatorError(e, actual
/* 136 */                 .currentContext()));
/*     */           
/*     */           return;
/*     */         } 
/* 140 */         if (n == arrayOfPublisher.length) {
/* 141 */           Publisher[] arrayOfPublisher1 = new Publisher[n + (n >> 2)];
/* 142 */           System.arraycopy(arrayOfPublisher, 0, arrayOfPublisher1, 0, n);
/* 143 */           arrayOfPublisher = arrayOfPublisher1;
/*     */         } 
/* 145 */         arrayOfPublisher[n++] = p;
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 150 */       n = arrayOfPublisher.length;
/*     */     } 
/*     */     
/* 153 */     if (n == 0) {
/* 154 */       Operators.complete((Subscriber<?>)actual);
/*     */       return;
/*     */     } 
/* 157 */     if (n == 1) {
/* 158 */       Function<T, R> f = t -> this.combiner.apply(new Object[] { t });
/* 159 */       if (arrayOfPublisher[0] instanceof Fuseable) {
/* 160 */         (new FluxMapFuseable<>(from(arrayOfPublisher[0]), f)).subscribe(actual);
/*     */         return;
/*     */       } 
/* 163 */       if (!(actual instanceof Fuseable.QueueSubscription)) {
/* 164 */         (new FluxMap<>(from(arrayOfPublisher[0]), f)).subscribe(actual);
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/* 169 */     Queue<SourceAndArray> queue = this.queueSupplier.get();
/*     */     
/* 171 */     CombineLatestCoordinator<T, R> coordinator = new CombineLatestCoordinator<>(actual, this.combiner, n, queue, this.prefetch);
/*     */ 
/*     */     
/* 174 */     actual.onSubscribe(coordinator);
/*     */     
/* 176 */     coordinator.subscribe((Publisher<? extends T>[])arrayOfPublisher, n);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/* 181 */     if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(this.prefetch); 
/* 182 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 183 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   static final class CombineLatestCoordinator<T, R>
/*     */     implements Fuseable.QueueSubscription<R>, InnerProducer<R>
/*     */   {
/*     */     final Function<Object[], R> combiner;
/*     */     
/*     */     final FluxCombineLatest.CombineLatestInner<T>[] subscribers;
/*     */     
/*     */     final Queue<FluxCombineLatest.SourceAndArray> queue;
/*     */     
/*     */     final Object[] latest;
/*     */     
/*     */     final CoreSubscriber<? super R> actual;
/*     */     
/*     */     boolean outputFused;
/*     */     
/*     */     int nonEmptySources;
/*     */     
/*     */     int completedSources;
/*     */     volatile boolean cancelled;
/*     */     volatile long requested;
/* 207 */     static final AtomicLongFieldUpdater<CombineLatestCoordinator> REQUESTED = AtomicLongFieldUpdater.newUpdater(CombineLatestCoordinator.class, "requested");
/*     */ 
/*     */     
/*     */     volatile int wip;
/*     */ 
/*     */     
/* 213 */     static final AtomicIntegerFieldUpdater<CombineLatestCoordinator> WIP = AtomicIntegerFieldUpdater.newUpdater(CombineLatestCoordinator.class, "wip");
/*     */ 
/*     */ 
/*     */     
/*     */     volatile boolean done;
/*     */ 
/*     */     
/*     */     volatile Throwable error;
/*     */ 
/*     */     
/* 223 */     static final AtomicReferenceFieldUpdater<CombineLatestCoordinator, Throwable> ERROR = AtomicReferenceFieldUpdater.newUpdater(CombineLatestCoordinator.class, Throwable.class, "error");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     CombineLatestCoordinator(CoreSubscriber<? super R> actual, Function<Object[], R> combiner, int n, Queue<FluxCombineLatest.SourceAndArray> queue, int prefetch) {
/* 231 */       this.actual = actual;
/* 232 */       this.combiner = combiner;
/* 233 */       FluxCombineLatest.CombineLatestInner[] arrayOfCombineLatestInner = new FluxCombineLatest.CombineLatestInner[n];
/*     */       
/* 235 */       for (int i = 0; i < n; i++) {
/* 236 */         arrayOfCombineLatestInner[i] = new FluxCombineLatest.CombineLatestInner<>(this, i, prefetch);
/*     */       }
/* 238 */       this.subscribers = (FluxCombineLatest.CombineLatestInner<T>[])arrayOfCombineLatestInner;
/* 239 */       this.latest = new Object[n];
/* 240 */       this.queue = queue;
/*     */     }
/*     */ 
/*     */     
/*     */     public final CoreSubscriber<? super R> actual() {
/* 245 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 250 */       if (Operators.validate(n)) {
/* 251 */         Operators.addCap(REQUESTED, this, n);
/* 252 */         drain();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 258 */       if (this.cancelled) {
/*     */         return;
/*     */       }
/* 261 */       this.cancelled = true;
/* 262 */       cancelAll();
/*     */       
/* 264 */       if (WIP.getAndIncrement(this) == 0) {
/* 265 */         clear();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public Stream<? extends Scannable> inners() {
/* 271 */       return Stream.of((Scannable[])this.subscribers);
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 277 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 278 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(this.cancelled); 
/* 279 */       if (key == Scannable.Attr.ERROR) return this.error; 
/* 280 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf(this.requested);
/*     */       
/* 282 */       return super.scanUnsafe(key);
/*     */     }
/*     */     
/*     */     void subscribe(Publisher<? extends T>[] sources, int n) {
/* 286 */       FluxCombineLatest.CombineLatestInner<T>[] a = this.subscribers;
/*     */       
/* 288 */       for (int i = 0; i < n; i++) {
/* 289 */         if (this.done || this.cancelled) {
/*     */           return;
/*     */         }
/* 292 */         sources[i].subscribe((Subscriber)a[i]);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     void innerValue(int index, T value) {
/*     */       boolean replenishInsteadOfDrain;
/* 300 */       synchronized (this) {
/* 301 */         Object[] os = this.latest;
/*     */         
/* 303 */         int localNonEmptySources = this.nonEmptySources;
/*     */         
/* 305 */         if (os[index] == null)
/*     */         {
/* 307 */           this.nonEmptySources = ++localNonEmptySources;
/*     */         }
/*     */         
/* 310 */         os[index] = value;
/*     */         
/* 312 */         if (os.length == localNonEmptySources) {
/*     */           
/* 314 */           FluxCombineLatest.SourceAndArray sa = new FluxCombineLatest.SourceAndArray(this.subscribers[index], (Object[])os.clone());
/*     */           
/* 316 */           if (!this.queue.offer(sa)) {
/* 317 */             innerError(Operators.onOperatorError(this, Exceptions.failWithOverflow("Queue is full: Reactive Streams source doesn't respect backpressure"), this.actual.currentContext()));
/*     */             
/*     */             return;
/*     */           } 
/* 321 */           replenishInsteadOfDrain = false;
/*     */         } else {
/*     */           
/* 324 */           replenishInsteadOfDrain = true;
/*     */         } 
/*     */       } 
/*     */       
/* 328 */       if (replenishInsteadOfDrain) {
/* 329 */         this.subscribers[index].requestOne();
/*     */       } else {
/*     */         
/* 332 */         drain();
/*     */       } 
/*     */     }
/*     */     
/*     */     void innerComplete(int index) {
/* 337 */       synchronized (this) {
/* 338 */         Object[] os = this.latest;
/*     */         
/* 340 */         if (os[index] != null) {
/* 341 */           int localCompletedSources = this.completedSources + 1;
/*     */           
/* 343 */           if (localCompletedSources == os.length) {
/* 344 */             this.done = true;
/*     */           } else {
/*     */             
/* 347 */             this.completedSources = localCompletedSources;
/*     */             
/*     */             return;
/*     */           } 
/*     */         } else {
/* 352 */           this.done = true;
/*     */         } 
/*     */       } 
/* 355 */       drain();
/*     */     }
/*     */ 
/*     */     
/*     */     void innerError(Throwable e) {
/* 360 */       if (Exceptions.addThrowable(ERROR, this, e)) {
/* 361 */         this.done = true;
/* 362 */         drain();
/*     */       } else {
/*     */         
/* 365 */         discardQueue(this.queue);
/* 366 */         Operators.onErrorDropped(e, this.actual.currentContext());
/*     */       } 
/*     */     }
/*     */     
/*     */     void drainOutput() {
/* 371 */       CoreSubscriber<? super R> a = this.actual;
/* 372 */       Queue<FluxCombineLatest.SourceAndArray> q = this.queue;
/*     */       
/* 374 */       int missed = 1;
/*     */ 
/*     */       
/*     */       do {
/* 378 */         if (this.cancelled) {
/* 379 */           discardQueue(q);
/*     */           
/*     */           return;
/*     */         } 
/* 383 */         Throwable ex = this.error;
/* 384 */         if (ex != null) {
/* 385 */           discardQueue(q);
/* 386 */           a.onError(ex);
/*     */           
/*     */           return;
/*     */         } 
/* 390 */         boolean d = this.done;
/*     */         
/* 392 */         boolean empty = q.isEmpty();
/*     */         
/* 394 */         if (!empty) {
/* 395 */           a.onNext(null);
/*     */         }
/*     */         
/* 398 */         if (d && empty) {
/* 399 */           a.onComplete();
/*     */           
/*     */           return;
/*     */         } 
/* 403 */         missed = WIP.addAndGet(this, -missed);
/* 404 */       } while (missed != 0);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void drainAsync() {
/* 411 */       Queue<FluxCombineLatest.SourceAndArray> q = this.queue;
/*     */       
/* 413 */       int missed = 1;
/*     */ 
/*     */       
/*     */       do {
/* 417 */         long r = this.requested;
/* 418 */         long e = 0L;
/*     */         
/* 420 */         while (e != r) {
/* 421 */           R w; boolean d = this.done;
/*     */           
/* 423 */           FluxCombineLatest.SourceAndArray v = q.poll();
/*     */           
/* 425 */           boolean empty = (v == null);
/*     */           
/* 427 */           if (checkTerminated(d, empty, q)) {
/*     */             return;
/*     */           }
/*     */           
/* 431 */           if (empty) {
/*     */             break;
/*     */           }
/*     */ 
/*     */ 
/*     */           
/*     */           try {
/* 438 */             w = Objects.requireNonNull(this.combiner.apply(v.array), "Combiner returned null");
/*     */           }
/* 440 */           catch (Throwable ex) {
/* 441 */             Context ctx = this.actual.currentContext();
/* 442 */             Operators.onDiscardMultiple(Stream.of(v.array), ctx);
/*     */             
/* 444 */             ex = Operators.onOperatorError(this, ex, v.array, ctx);
/* 445 */             Exceptions.addThrowable(ERROR, this, ex);
/*     */             
/* 447 */             ex = Exceptions.terminate(ERROR, this);
/* 448 */             this.actual.onError(ex);
/*     */             
/*     */             return;
/*     */           } 
/* 452 */           this.actual.onNext(w);
/*     */           
/* 454 */           v.source.requestOne();
/*     */           
/* 456 */           e++;
/*     */         } 
/*     */         
/* 459 */         if (e == r && 
/* 460 */           checkTerminated(this.done, q.isEmpty(), q)) {
/*     */           return;
/*     */         }
/*     */ 
/*     */         
/* 465 */         if (e != 0L && r != Long.MAX_VALUE) {
/* 466 */           REQUESTED.addAndGet(this, -e);
/*     */         }
/*     */         
/* 469 */         missed = WIP.addAndGet(this, -missed);
/* 470 */       } while (missed != 0);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void drain() {
/* 477 */       if (WIP.getAndIncrement(this) != 0) {
/*     */         return;
/*     */       }
/*     */       
/* 481 */       if (this.outputFused) {
/* 482 */         drainOutput();
/*     */       } else {
/*     */         
/* 485 */         drainAsync();
/*     */       } 
/*     */     }
/*     */     
/*     */     boolean checkTerminated(boolean d, boolean empty, Queue<FluxCombineLatest.SourceAndArray> q) {
/* 490 */       if (this.cancelled) {
/* 491 */         cancelAll();
/* 492 */         discardQueue(q);
/* 493 */         return true;
/*     */       } 
/*     */       
/* 496 */       if (d) {
/* 497 */         Throwable e = Exceptions.terminate(ERROR, this);
/*     */         
/* 499 */         if (e != null && e != Exceptions.TERMINATED) {
/* 500 */           cancelAll();
/* 501 */           discardQueue(q);
/* 502 */           this.actual.onError(e);
/* 503 */           return true;
/*     */         } 
/* 505 */         if (empty) {
/* 506 */           cancelAll();
/*     */           
/* 508 */           this.actual.onComplete();
/* 509 */           return true;
/*     */         } 
/*     */       } 
/* 512 */       return false;
/*     */     }
/*     */     
/*     */     void cancelAll() {
/* 516 */       for (FluxCombineLatest.CombineLatestInner<T> inner : this.subscribers) {
/* 517 */         inner.cancel();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public int requestFusion(int requestedMode) {
/* 523 */       if ((requestedMode & 0x4) != 0) {
/* 524 */         return 0;
/*     */       }
/* 526 */       int m = requestedMode & 0x2;
/* 527 */       this.outputFused = (m != 0);
/* 528 */       return m;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public R poll() {
/* 534 */       FluxCombineLatest.SourceAndArray e = this.queue.poll();
/* 535 */       if (e == null) {
/* 536 */         return null;
/*     */       }
/* 538 */       R r = this.combiner.apply(e.array);
/* 539 */       e.source.requestOne();
/* 540 */       return r;
/*     */     }
/*     */     
/*     */     private void discardQueue(Queue<FluxCombineLatest.SourceAndArray> q) {
/* 544 */       Operators.onDiscardQueueWithClear(q, this.actual.currentContext(), FluxCombineLatest.SourceAndArray::toStream);
/*     */     }
/*     */ 
/*     */     
/*     */     public void clear() {
/* 549 */       discardQueue(this.queue);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isEmpty() {
/* 554 */       return this.queue.isEmpty();
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 559 */       return this.queue.size();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class CombineLatestInner<T>
/*     */     implements InnerConsumer<T>
/*     */   {
/*     */     final FluxCombineLatest.CombineLatestCoordinator<T, ?> parent;
/*     */     
/*     */     final int index;
/*     */     
/*     */     final int prefetch;
/*     */     
/*     */     final int limit;
/*     */     
/*     */     volatile Subscription s;
/*     */     
/* 577 */     static final AtomicReferenceFieldUpdater<CombineLatestInner, Subscription> S = AtomicReferenceFieldUpdater.newUpdater(CombineLatestInner.class, Subscription.class, "s");
/*     */ 
/*     */ 
/*     */     
/*     */     int produced;
/*     */ 
/*     */ 
/*     */     
/*     */     CombineLatestInner(FluxCombineLatest.CombineLatestCoordinator<T, ?> parent, int index, int prefetch) {
/* 586 */       this.parent = parent;
/* 587 */       this.index = index;
/* 588 */       this.prefetch = prefetch;
/* 589 */       this.limit = Operators.unboundedOrLimit(prefetch);
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/* 594 */       return this.parent.actual.currentContext();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 599 */       if (Operators.setOnce(S, this, s)) {
/* 600 */         s.request(Operators.unboundedOrPrefetch(this.prefetch));
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 606 */       this.parent.innerValue(this.index, t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 611 */       this.parent.innerError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 616 */       this.parent.innerComplete(this.index);
/*     */     }
/*     */     
/*     */     public void cancel() {
/* 620 */       Operators.terminate(S, this);
/*     */     }
/*     */     
/*     */     void requestOne() {
/* 624 */       int p = this.produced + 1;
/* 625 */       if (p == this.limit) {
/* 626 */         this.produced = 0;
/* 627 */         this.s.request(p);
/*     */       } else {
/*     */         
/* 630 */         this.produced = p;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 637 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 638 */       if (key == Scannable.Attr.ACTUAL) return this.parent; 
/* 639 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf((this.s == Operators.cancelledSubscription())); 
/* 640 */       if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(this.prefetch); 
/* 641 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 643 */       return null;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class SourceAndArray
/*     */   {
/*     */     final FluxCombineLatest.CombineLatestInner<?> source;
/*     */     
/*     */     final Object[] array;
/*     */ 
/*     */     
/*     */     SourceAndArray(FluxCombineLatest.CombineLatestInner<?> source, Object[] array) {
/* 656 */       this.source = source;
/* 657 */       this.array = array;
/*     */     }
/*     */     
/*     */     final Stream<?> toStream() {
/* 661 */       return Stream.of(this.array);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\FluxCombineLatest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */