/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.LongConsumer;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.Disposables;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ import reactor.util.context.ContextView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MonoCreate<T>
/*     */   extends Mono<T>
/*     */   implements SourceProducer<T>
/*     */ {
/*  42 */   static final Disposable TERMINATED = OperatorDisposables.DISPOSED;
/*  43 */   static final Disposable CANCELLED = Disposables.disposed();
/*     */   
/*     */   final Consumer<MonoSink<T>> callback;
/*     */   
/*     */   MonoCreate(Consumer<MonoSink<T>> callback) {
/*  48 */     this.callback = callback;
/*     */   }
/*     */ 
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super T> actual) {
/*  53 */     DefaultMonoSink<T> emitter = new DefaultMonoSink<>(actual);
/*     */     
/*  55 */     actual.onSubscribe(emitter);
/*     */     
/*     */     try {
/*  58 */       this.callback.accept(emitter);
/*     */     }
/*  60 */     catch (Throwable ex) {
/*  61 */       emitter.error(Operators.onOperatorError(ex, actual.currentContext()));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  67 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.ASYNC; 
/*  68 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   static final class DefaultMonoSink<T>
/*     */     extends AtomicBoolean
/*     */     implements MonoSink<T>, InnerProducer<T>
/*     */   {
/*     */     final CoreSubscriber<? super T> actual;
/*     */     
/*     */     volatile Disposable disposable;
/*  79 */     static final AtomicReferenceFieldUpdater<DefaultMonoSink, Disposable> DISPOSABLE = AtomicReferenceFieldUpdater.newUpdater(DefaultMonoSink.class, Disposable.class, "disposable");
/*     */ 
/*     */ 
/*     */     
/*     */     volatile int state;
/*     */ 
/*     */     
/*  86 */     static final AtomicIntegerFieldUpdater<DefaultMonoSink> STATE = AtomicIntegerFieldUpdater.newUpdater(DefaultMonoSink.class, "state");
/*     */ 
/*     */     
/*     */     volatile LongConsumer requestConsumer;
/*     */ 
/*     */     
/*  92 */     static final AtomicReferenceFieldUpdater<DefaultMonoSink, LongConsumer> REQUEST_CONSUMER = AtomicReferenceFieldUpdater.newUpdater(DefaultMonoSink.class, LongConsumer.class, "requestConsumer");
/*     */     
/*     */     T value;
/*     */     
/*     */     static final int NO_REQUEST_HAS_VALUE = 1;
/*     */     
/*     */     static final int HAS_REQUEST_NO_VALUE = 2;
/*     */     
/*     */     static final int HAS_REQUEST_HAS_VALUE = 3;
/*     */     
/*     */     DefaultMonoSink(CoreSubscriber<? super T> actual) {
/* 103 */       this.actual = actual;
/*     */     }
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     public Context currentContext() {
/* 109 */       return this.actual.currentContext();
/*     */     }
/*     */ 
/*     */     
/*     */     public ContextView contextView() {
/* 114 */       return (ContextView)this.actual.currentContext();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 120 */       if (key == Scannable.Attr.TERMINATED) {
/* 121 */         return Boolean.valueOf((this.state == 3 || this.state == 1 || this.disposable == MonoCreate.TERMINATED));
/*     */       }
/* 123 */       if (key == Scannable.Attr.CANCELLED) {
/* 124 */         return Boolean.valueOf((this.disposable == MonoCreate.CANCELLED));
/*     */       }
/* 126 */       if (key == Scannable.Attr.RUN_STYLE) {
/* 127 */         return Scannable.Attr.RunStyle.ASYNC;
/*     */       }
/*     */       
/* 130 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public void success() {
/* 135 */       if (isDisposed()) {
/*     */         return;
/*     */       }
/* 138 */       if (STATE.getAndSet(this, 3) != 3) {
/*     */         try {
/* 140 */           this.actual.onComplete();
/*     */         } finally {
/*     */           
/* 143 */           disposeResource(false);
/*     */         } 
/*     */       }
/*     */     }
/*     */     
/*     */     public void success(@Nullable T value) {
/*     */       int s;
/* 150 */       if (value == null) {
/* 151 */         success();
/*     */         return;
/*     */       } 
/* 154 */       Disposable d = this.disposable;
/* 155 */       if (d == MonoCreate.CANCELLED) {
/* 156 */         Operators.onDiscard(value, this.actual.currentContext());
/*     */         return;
/*     */       } 
/* 159 */       if (d == MonoCreate.TERMINATED) {
/* 160 */         Operators.onNextDropped(value, this.actual.currentContext());
/*     */         return;
/*     */       } 
/*     */       do {
/* 164 */         s = this.state;
/* 165 */         if (s == 3 || s == 1) {
/* 166 */           Operators.onNextDropped(value, this.actual.currentContext());
/*     */           return;
/*     */         } 
/* 169 */         if (s == 2) {
/* 170 */           if (STATE.compareAndSet(this, s, 3)) {
/*     */             try {
/* 172 */               this.actual.onNext(value);
/* 173 */               this.actual.onComplete();
/*     */             }
/* 175 */             catch (Throwable t) {
/* 176 */               this.actual.onError(t);
/*     */             } finally {
/*     */               
/* 179 */               disposeResource(false);
/*     */             } 
/*     */           } else {
/* 182 */             Operators.onNextDropped(value, this.actual.currentContext());
/*     */           } 
/*     */           return;
/*     */         } 
/* 186 */         this.value = value;
/* 187 */       } while (!STATE.compareAndSet(this, s, 1));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void error(Throwable e) {
/* 195 */       if (isDisposed()) {
/* 196 */         Operators.onOperatorError(e, this.actual.currentContext());
/*     */         return;
/*     */       } 
/* 199 */       if (STATE.getAndSet(this, 3) != 3) {
/*     */         try {
/* 201 */           this.actual.onError(e);
/*     */         } finally {
/*     */           
/* 204 */           disposeResource(false);
/*     */         } 
/*     */       } else {
/*     */         
/* 208 */         Operators.onOperatorError(e, this.actual.currentContext());
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public MonoSink<T> onRequest(LongConsumer consumer) {
/* 214 */       Objects.requireNonNull(consumer, "onRequest");
/* 215 */       if (!REQUEST_CONSUMER.compareAndSet(this, null, consumer)) {
/* 216 */         throw new IllegalStateException("A consumer has already been assigned to consume requests");
/*     */       }
/*     */       
/* 219 */       int s = this.state;
/* 220 */       if (s == 2 || s == 3) {
/* 221 */         consumer.accept(Long.MAX_VALUE);
/*     */       }
/* 223 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 228 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public MonoSink<T> onCancel(Disposable d) {
/* 233 */       Objects.requireNonNull(d, "onCancel");
/* 234 */       FluxCreate.SinkDisposable sd = new FluxCreate.SinkDisposable(null, d);
/* 235 */       if (!DISPOSABLE.compareAndSet(this, null, sd)) {
/* 236 */         Disposable c = this.disposable;
/* 237 */         if (c == MonoCreate.CANCELLED) {
/* 238 */           d.dispose();
/*     */         }
/* 240 */         else if (c instanceof FluxCreate.SinkDisposable) {
/* 241 */           FluxCreate.SinkDisposable current = (FluxCreate.SinkDisposable)c;
/* 242 */           if (current.onCancel == null) {
/* 243 */             current.onCancel = d;
/*     */           } else {
/*     */             
/* 246 */             d.dispose();
/*     */           } 
/*     */         } 
/*     */       } 
/* 250 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public MonoSink<T> onDispose(Disposable d) {
/* 255 */       Objects.requireNonNull(d, "onDispose");
/* 256 */       FluxCreate.SinkDisposable sd = new FluxCreate.SinkDisposable(d, null);
/* 257 */       if (!DISPOSABLE.compareAndSet(this, null, sd)) {
/* 258 */         Disposable c = this.disposable;
/* 259 */         if (isDisposed()) {
/* 260 */           d.dispose();
/*     */         }
/* 262 */         else if (c instanceof FluxCreate.SinkDisposable) {
/* 263 */           FluxCreate.SinkDisposable current = (FluxCreate.SinkDisposable)c;
/* 264 */           if (current.disposable == null) {
/* 265 */             current.disposable = d;
/*     */           } else {
/*     */             
/* 268 */             d.dispose();
/*     */           } 
/*     */         } 
/*     */       } 
/* 272 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 277 */       if (Operators.validate(n)) {
/* 278 */         int s; LongConsumer consumer = this.requestConsumer;
/* 279 */         if (consumer != null) {
/* 280 */           consumer.accept(n);
/*     */         }
/*     */         do {
/* 283 */           s = this.state;
/* 284 */           if (s == 2 || s == 3) {
/*     */             return;
/*     */           }
/* 287 */           if (s == 1) {
/* 288 */             if (STATE.compareAndSet(this, s, 3)) {
/*     */               try {
/* 290 */                 this.actual.onNext(this.value);
/* 291 */                 this.actual.onComplete();
/*     */               } finally {
/*     */                 
/* 294 */                 disposeResource(false);
/*     */               } 
/*     */             }
/*     */             return;
/*     */           } 
/* 299 */         } while (!STATE.compareAndSet(this, s, 2));
/*     */         return;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 308 */       if (STATE.getAndSet(this, 3) != 3) {
/* 309 */         T old = this.value;
/* 310 */         this.value = null;
/* 311 */         Operators.onDiscard(old, this.actual.currentContext());
/* 312 */         disposeResource(true);
/*     */       } 
/*     */     }
/*     */     
/*     */     void disposeResource(boolean isCancel) {
/* 317 */       Disposable target = isCancel ? MonoCreate.CANCELLED : MonoCreate.TERMINATED;
/* 318 */       Disposable d = this.disposable;
/* 319 */       if (d != MonoCreate.TERMINATED && d != MonoCreate.CANCELLED) {
/* 320 */         d = DISPOSABLE.getAndSet(this, target);
/* 321 */         if (d != null && d != MonoCreate.TERMINATED && d != MonoCreate.CANCELLED) {
/* 322 */           if (isCancel && d instanceof FluxCreate.SinkDisposable) {
/* 323 */             ((FluxCreate.SinkDisposable)d).cancel();
/*     */           }
/* 325 */           d.dispose();
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 332 */       return "MonoSink";
/*     */     }
/*     */     
/*     */     boolean isDisposed() {
/* 336 */       Disposable d = this.disposable;
/* 337 */       return (d == MonoCreate.CANCELLED || d == MonoCreate.TERMINATED);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\MonoCreate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */