/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.function.Function;
/*     */ import java.util.stream.Stream;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CorePublisher;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MonoDelayUntil<T>
/*     */   extends Mono<T>
/*     */   implements Scannable, OptimizableOperator<T, T>
/*     */ {
/*     */   final Mono<T> source;
/*     */   Function<? super T, ? extends Publisher<?>>[] otherGenerators;
/*     */   @Nullable
/*     */   final OptimizableOperator<?, T> optimizableOperator;
/*     */   
/*     */   MonoDelayUntil(Mono<T> monoSource, Function<? super T, ? extends Publisher<?>> triggerGenerator) {
/*  58 */     this.source = Objects.<Mono<T>>requireNonNull(monoSource, "monoSource");
/*  59 */     this.otherGenerators = (Function<? super T, ? extends Publisher<?>>[])new Function[] { Objects.<Function>requireNonNull(triggerGenerator, "triggerGenerator") };
/*  60 */     this.optimizableOperator = (this.source instanceof OptimizableOperator) ? (OptimizableOperator)this.source : null;
/*     */   }
/*     */ 
/*     */   
/*     */   MonoDelayUntil(Mono<T> monoSource, Function<? super T, ? extends Publisher<?>>[] triggerGenerators) {
/*  65 */     this.source = Objects.<Mono<T>>requireNonNull(monoSource, "monoSource");
/*  66 */     this.otherGenerators = triggerGenerators;
/*  67 */     if (this.source instanceof OptimizableOperator) {
/*     */       
/*  69 */       OptimizableOperator<?, T> optimSource = (OptimizableOperator)this.source;
/*  70 */       this.optimizableOperator = optimSource;
/*     */     } else {
/*     */       
/*  73 */       this.optimizableOperator = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MonoDelayUntil<T> copyWithNewTriggerGenerator(boolean delayError, Function<? super T, ? extends Publisher<?>> triggerGenerator) {
/*  86 */     Objects.requireNonNull(triggerGenerator, "triggerGenerator");
/*  87 */     Function<? super T, ? extends Publisher<?>>[] oldTriggers = this.otherGenerators;
/*  88 */     Function[] arrayOfFunction = new Function[oldTriggers.length + 1];
/*  89 */     System.arraycopy(oldTriggers, 0, arrayOfFunction, 0, oldTriggers.length);
/*  90 */     arrayOfFunction[oldTriggers.length] = triggerGenerator;
/*  91 */     return new MonoDelayUntil(this.source, (Function<? super T, ? extends Publisher<?>>[])arrayOfFunction);
/*     */   }
/*     */ 
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super T> actual) {
/*     */     try {
/*  97 */       this.source.subscribe(subscribeOrReturn(actual));
/*     */     }
/*  99 */     catch (Throwable e) {
/* 100 */       Operators.error((Subscriber<?>)actual, Operators.onOperatorError(e, actual.currentContext()));
/*     */       return;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public final CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) throws Throwable {
/* 107 */     DelayUntilCoordinator<T> parent = new DelayUntilCoordinator<>(actual, this.otherGenerators);
/* 108 */     actual.onSubscribe(parent);
/*     */     
/* 110 */     return parent;
/*     */   }
/*     */ 
/*     */   
/*     */   public final CorePublisher<? extends T> source() {
/* 115 */     return this.source;
/*     */   }
/*     */ 
/*     */   
/*     */   public final OptimizableOperator<?, ? extends T> nextOptimizableSource() {
/* 120 */     return this.optimizableOperator;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/* 125 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 126 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   static final class DelayUntilCoordinator<T>
/*     */     implements InnerOperator<T, T>
/*     */   {
/*     */     final Function<? super T, ? extends Publisher<?>>[] otherGenerators;
/*     */     
/*     */     final CoreSubscriber<? super T> actual;
/*     */     
/*     */     int index;
/*     */     
/*     */     T value;
/*     */     
/*     */     boolean done;
/*     */     Subscription s;
/*     */     MonoDelayUntil.DelayUntilTrigger<?> triggerSubscriber;
/*     */     volatile Throwable error;
/* 145 */     static final AtomicReferenceFieldUpdater<DelayUntilCoordinator, Throwable> ERROR = AtomicReferenceFieldUpdater.newUpdater(DelayUntilCoordinator.class, Throwable.class, "error");
/*     */ 
/*     */     
/*     */     volatile int state;
/*     */     
/* 150 */     static final AtomicIntegerFieldUpdater<DelayUntilCoordinator> STATE = AtomicIntegerFieldUpdater.newUpdater(DelayUntilCoordinator.class, "state");
/*     */     
/*     */     static final int HAS_SUBSCRIPTION = 1;
/*     */     
/*     */     static final int HAS_INNER = 2;
/*     */     static final int HAS_REQUEST = 4;
/*     */     static final int HAS_VALUE = 8;
/*     */     static final int TERMINATED = -2147483648;
/*     */     
/*     */     DelayUntilCoordinator(CoreSubscriber<? super T> subscriber, Function<? super T, ? extends Publisher<?>>[] otherGenerators) {
/* 160 */       this.actual = subscriber;
/* 161 */       this.otherGenerators = otherGenerators;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 166 */       if (Operators.validate(this.s, s)) {
/* 167 */         this.s = s;
/*     */         
/* 169 */         int previousState = markHasSubscription();
/* 170 */         if (MonoDelayUntil.isTerminated(previousState)) {
/* 171 */           s.cancel();
/*     */           
/*     */           return;
/*     */         } 
/* 175 */         s.request(Long.MAX_VALUE);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 181 */       if (this.done) {
/* 182 */         Operators.onDiscard(t, this.actual.currentContext());
/*     */         
/*     */         return;
/*     */       } 
/* 186 */       this.value = t;
/* 187 */       subscribeNextTrigger();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 192 */       if (this.done) {
/* 193 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*     */         
/*     */         return;
/*     */       } 
/* 197 */       this.done = true;
/*     */       
/* 199 */       if (this.value == null) {
/* 200 */         this.actual.onError(t);
/*     */         
/*     */         return;
/*     */       } 
/* 204 */       if (!Exceptions.addThrowable(ERROR, this, t)) {
/* 205 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*     */         
/*     */         return;
/*     */       } 
/* 209 */       int previousState = markTerminated();
/* 210 */       if (MonoDelayUntil.isTerminated(previousState)) {
/*     */         return;
/*     */       }
/*     */       
/* 214 */       if (MonoDelayUntil.hasInner(previousState)) {
/* 215 */         Operators.onDiscard(this.value, this.actual.currentContext());
/* 216 */         this.triggerSubscriber.cancel();
/*     */       } 
/*     */       
/* 219 */       Throwable e = Exceptions.terminate(ERROR, this);
/*     */       
/* 221 */       this.actual.onError(e);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 226 */       if (this.done) {
/*     */         return;
/*     */       }
/*     */       
/* 230 */       if (this.value == null) {
/* 231 */         this.done = true;
/* 232 */         this.actual.onComplete();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 238 */       if (Operators.validate(n)) {
/* 239 */         int previousState = markHasRequest();
/*     */         
/* 241 */         if (MonoDelayUntil.isTerminated(previousState)) {
/*     */           return;
/*     */         }
/*     */         
/* 245 */         if (MonoDelayUntil.hasRequest(previousState)) {
/*     */           return;
/*     */         }
/*     */         
/* 249 */         if (MonoDelayUntil.hasValue(previousState)) {
/* 250 */           this.done = true;
/* 251 */           CoreSubscriber<? super T> actual = this.actual;
/* 252 */           T v = this.value;
/*     */           
/* 254 */           actual.onNext(v);
/* 255 */           actual.onComplete();
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 262 */       int previousState = markTerminated();
/*     */       
/* 264 */       if (MonoDelayUntil.isTerminated(previousState)) {
/*     */         return;
/*     */       }
/*     */       
/* 268 */       Throwable t = Exceptions.terminate(ERROR, this);
/* 269 */       if (t != null) {
/* 270 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*     */       }
/*     */       
/* 273 */       if (MonoDelayUntil.hasSubscription(previousState)) {
/* 274 */         this.s.cancel();
/*     */       }
/*     */       
/* 277 */       if (MonoDelayUntil.hasInner(previousState)) {
/* 278 */         Operators.onDiscard(this.value, this.actual.currentContext());
/*     */         
/* 280 */         this.triggerSubscriber.cancel();
/*     */       } 
/*     */     }
/*     */     
/*     */     void subscribeNextTrigger() {
/*     */       Publisher<?> p;
/* 286 */       Function<? super T, ? extends Publisher<?>> generator = this.otherGenerators[this.index];
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 292 */         p = generator.apply(this.value);
/* 293 */         Objects.requireNonNull(p, "mapper returned null value");
/*     */       }
/* 295 */       catch (Throwable t) {
/* 296 */         onError(t);
/*     */         
/*     */         return;
/*     */       } 
/* 300 */       MonoDelayUntil.DelayUntilTrigger<?> triggerSubscriber = this.triggerSubscriber;
/* 301 */       if (triggerSubscriber == null) {
/* 302 */         triggerSubscriber = new MonoDelayUntil.DelayUntilTrigger(this);
/* 303 */         this.triggerSubscriber = triggerSubscriber;
/*     */       } 
/*     */       
/* 306 */       p.subscribe((Subscriber)triggerSubscriber);
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 311 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 317 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf((MonoDelayUntil.isTerminated(this.state) && !this.done)); 
/* 318 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf((MonoDelayUntil.isTerminated(this.state) && this.done)); 
/* 319 */       if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(2147483647); 
/* 320 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 322 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public Stream<? extends Scannable> inners() {
/* 327 */       MonoDelayUntil.DelayUntilTrigger<?> subscriber = this.triggerSubscriber;
/* 328 */       return (subscriber == null) ? Stream.<Scannable>empty() : Stream.<Scannable>of(subscriber);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     int markHasSubscription() {
/*     */       while (true) {
/* 339 */         int state = this.state;
/*     */         
/* 341 */         if (MonoDelayUntil.isTerminated(state)) {
/* 342 */           return Integer.MIN_VALUE;
/*     */         }
/*     */         
/* 345 */         if (STATE.compareAndSet(this, state, state | 0x1)) {
/* 346 */           return state;
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     int markHasRequest() {
/*     */       while (true) {
/* 359 */         int nextState, state = this.state;
/* 360 */         if (MonoDelayUntil.isTerminated(state)) {
/* 361 */           return Integer.MIN_VALUE;
/*     */         }
/*     */         
/* 364 */         if (MonoDelayUntil.hasRequest(state)) {
/* 365 */           return state;
/*     */         }
/*     */ 
/*     */         
/* 369 */         if (MonoDelayUntil.hasValue(state)) {
/* 370 */           nextState = Integer.MIN_VALUE;
/*     */         } else {
/*     */           
/* 373 */           nextState = state | 0x4;
/*     */         } 
/*     */         
/* 376 */         if (STATE.compareAndSet(this, state, nextState)) {
/* 377 */           return state;
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     int markTerminated() {
/*     */       while (true) {
/* 389 */         int state = this.state;
/*     */         
/* 391 */         if (MonoDelayUntil.isTerminated(state)) {
/* 392 */           return Integer.MIN_VALUE;
/*     */         }
/*     */         
/* 395 */         if (STATE.compareAndSet(this, state, -2147483648)) {
/* 396 */           return state;
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void complete() {
/*     */       int s;
/*     */       do {
/* 408 */         s = this.state;
/*     */         
/* 410 */         if (MonoDelayUntil.isTerminated(s)) {
/*     */           return;
/*     */         }
/*     */         
/* 414 */         if (MonoDelayUntil.hasRequest(s) && STATE.compareAndSet(this, s, -2147483648)) {
/* 415 */           CoreSubscriber<? super T> actual = this.actual;
/* 416 */           T v = this.value;
/*     */           
/* 418 */           actual.onNext(v);
/* 419 */           actual.onComplete();
/*     */ 
/*     */           
/*     */           return;
/*     */         } 
/* 424 */       } while (!STATE.compareAndSet(this, s, s | 0x8));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class DelayUntilTrigger<T>
/*     */     implements InnerConsumer<T>
/*     */   {
/*     */     final MonoDelayUntil.DelayUntilCoordinator<?> parent;
/*     */     
/*     */     Subscription s;
/*     */     
/*     */     boolean done;
/*     */     Throwable error;
/*     */     
/*     */     DelayUntilTrigger(MonoDelayUntil.DelayUntilCoordinator<?> parent) {
/* 440 */       this.parent = parent;
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/* 445 */       return this.parent.currentContext();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 451 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf((MonoDelayUntil.isTerminated(this.parent.state) && !this.done)); 
/* 452 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 453 */       if (key == Scannable.Attr.ACTUAL) return this.parent; 
/* 454 */       if (key == Scannable.Attr.ERROR) return this.error; 
/* 455 */       if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(2147483647); 
/* 456 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 458 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 463 */       if (Operators.validate(this.s, s)) {
/* 464 */         this.s = s;
/*     */         
/* 466 */         int previousState = markInnerActive();
/* 467 */         if (MonoDelayUntil.isTerminated(previousState)) {
/* 468 */           s.cancel();
/*     */           
/* 470 */           MonoDelayUntil.DelayUntilCoordinator<?> parent = this.parent;
/* 471 */           Operators.onDiscard(parent.value, parent.currentContext());
/*     */           
/*     */           return;
/*     */         } 
/*     */         
/* 476 */         s.request(Long.MAX_VALUE);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 483 */       Operators.onDiscard(t, this.parent.currentContext());
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 488 */       if (this.done) {
/* 489 */         Operators.onErrorDropped(t, this.parent.currentContext());
/*     */         
/*     */         return;
/*     */       } 
/* 493 */       MonoDelayUntil.DelayUntilCoordinator<?> parent = this.parent;
/*     */       
/* 495 */       this.done = true;
/* 496 */       parent.done = true;
/*     */       
/* 498 */       if (!Exceptions.addThrowable(MonoDelayUntil.DelayUntilCoordinator.ERROR, parent, t)) {
/* 499 */         Operators.onErrorDropped(t, parent.currentContext());
/*     */         
/*     */         return;
/*     */       } 
/* 503 */       int previousState = parent.markTerminated();
/* 504 */       if (MonoDelayUntil.isTerminated(previousState)) {
/*     */         return;
/*     */       }
/*     */       
/* 508 */       Operators.onDiscard(parent.value, parent.currentContext());
/*     */       
/* 510 */       parent.s.cancel();
/*     */       
/* 512 */       Throwable e = Exceptions.terminate(MonoDelayUntil.DelayUntilCoordinator.ERROR, parent);
/*     */       
/* 514 */       parent.actual.onError(e);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 519 */       if (this.done) {
/*     */         return;
/*     */       }
/*     */       
/* 523 */       this.done = true;
/*     */       
/* 525 */       MonoDelayUntil.DelayUntilCoordinator<?> parent = this.parent;
/* 526 */       int nextIndex = parent.index + 1;
/*     */       
/* 528 */       parent.index = nextIndex;
/*     */       
/* 530 */       if (nextIndex == parent.otherGenerators.length) {
/* 531 */         parent.complete();
/*     */         
/*     */         return;
/*     */       } 
/* 535 */       int previousState = markInnerInactive();
/* 536 */       if (MonoDelayUntil.isTerminated(previousState)) {
/*     */         return;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 543 */       this.done = false;
/* 544 */       this.s = null;
/*     */       
/* 546 */       parent.subscribeNextTrigger();
/*     */     }
/*     */     
/*     */     void cancel() {
/* 550 */       this.s.cancel();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     int markInnerActive() {
/* 560 */       MonoDelayUntil.DelayUntilCoordinator<?> parent = this.parent;
/*     */       while (true) {
/* 562 */         int state = parent.state;
/*     */         
/* 564 */         if (MonoDelayUntil.isTerminated(state)) {
/* 565 */           return Integer.MIN_VALUE;
/*     */         }
/*     */         
/* 568 */         if (MonoDelayUntil.hasInner(state)) {
/* 569 */           return state;
/*     */         }
/*     */         
/* 572 */         if (MonoDelayUntil.DelayUntilCoordinator.STATE.compareAndSet(parent, state, state | 0x2)) {
/* 573 */           return state;
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     int markInnerInactive() {
/* 584 */       MonoDelayUntil.DelayUntilCoordinator<?> parent = this.parent;
/*     */       while (true) {
/* 586 */         int state = parent.state;
/*     */         
/* 588 */         if (MonoDelayUntil.isTerminated(state)) {
/* 589 */           return Integer.MIN_VALUE;
/*     */         }
/*     */         
/* 592 */         if (!MonoDelayUntil.hasInner(state)) {
/* 593 */           return state;
/*     */         }
/*     */         
/* 596 */         if (MonoDelayUntil.DelayUntilCoordinator.STATE.compareAndSet(parent, state, state & 0xFFFFFFFD)) {
/* 597 */           return state;
/*     */         }
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean isTerminated(int state) {
/* 607 */     return (state == Integer.MIN_VALUE);
/*     */   }
/*     */   
/*     */   static boolean hasValue(int state) {
/* 611 */     return ((state & 0x8) == 8);
/*     */   }
/*     */   
/*     */   static boolean hasInner(int state) {
/* 615 */     return ((state & 0x2) == 2);
/*     */   }
/*     */   
/*     */   static boolean hasRequest(int state) {
/* 619 */     return ((state & 0x4) == 4);
/*     */   }
/*     */   
/*     */   static boolean hasSubscription(int state) {
/* 623 */     return ((state & 0x1) == 1);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\MonoDelayUntil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */