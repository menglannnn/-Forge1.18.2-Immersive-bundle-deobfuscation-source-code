/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.function.Function;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxMap<T, R>
/*     */   extends InternalFluxOperator<T, R>
/*     */ {
/*     */   final Function<? super T, ? extends R> mapper;
/*     */   
/*     */   FluxMap(Flux<? extends T> source, Function<? super T, ? extends R> mapper) {
/*  50 */     super(source);
/*  51 */     this.mapper = Objects.<Function<? super T, ? extends R>>requireNonNull(mapper, "mapper");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super R> actual) {
/*  57 */     if (actual instanceof Fuseable.ConditionalSubscriber) {
/*  58 */       Fuseable.ConditionalSubscriber<? super R> cs = (Fuseable.ConditionalSubscriber<? super R>)actual;
/*     */       
/*  60 */       return new MapConditionalSubscriber<>(cs, this.mapper);
/*     */     } 
/*  62 */     return new MapSubscriber<>(actual, this.mapper);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  67 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  68 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class MapSubscriber<T, R>
/*     */     implements InnerOperator<T, R>
/*     */   {
/*     */     final CoreSubscriber<? super R> actual;
/*     */     
/*     */     final Function<? super T, ? extends R> mapper;
/*     */     
/*     */     boolean done;
/*     */     Subscription s;
/*     */     
/*     */     MapSubscriber(CoreSubscriber<? super R> actual, Function<? super T, ? extends R> mapper) {
/*  83 */       this.actual = actual;
/*  84 */       this.mapper = mapper;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/*  89 */       if (Operators.validate(this.s, s)) {
/*  90 */         this.s = s;
/*     */         
/*  92 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */     
/*     */     public void onNext(T t) {
/*     */       R v;
/*  98 */       if (this.done) {
/*  99 */         Operators.onNextDropped(t, this.actual.currentContext());
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/*     */       try {
/* 106 */         v = this.mapper.apply(t);
/* 107 */         if (v == null) {
/* 108 */           throw new NullPointerException("The mapper [" + this.mapper.getClass().getName() + "] returned a null value.");
/*     */         }
/*     */       }
/* 111 */       catch (Throwable e) {
/* 112 */         Throwable e_ = Operators.onNextError(t, e, this.actual.currentContext(), this.s);
/* 113 */         if (e_ != null) {
/* 114 */           onError(e_);
/*     */         } else {
/*     */           
/* 117 */           this.s.request(1L);
/*     */         } 
/*     */         
/*     */         return;
/*     */       } 
/* 122 */       this.actual.onNext(v);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 127 */       if (this.done) {
/* 128 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*     */         
/*     */         return;
/*     */       } 
/* 132 */       this.done = true;
/*     */       
/* 134 */       this.actual.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 139 */       if (this.done) {
/*     */         return;
/*     */       }
/* 142 */       this.done = true;
/*     */       
/* 144 */       this.actual.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 150 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 151 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 152 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 154 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super R> actual() {
/* 159 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 164 */       this.s.request(n);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 169 */       this.s.cancel();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class MapConditionalSubscriber<T, R>
/*     */     implements Fuseable.ConditionalSubscriber<T>, InnerOperator<T, R>
/*     */   {
/*     */     final Fuseable.ConditionalSubscriber<? super R> actual;
/*     */     
/*     */     final Function<? super T, ? extends R> mapper;
/*     */     
/*     */     boolean done;
/*     */     Subscription s;
/*     */     
/*     */     MapConditionalSubscriber(Fuseable.ConditionalSubscriber<? super R> actual, Function<? super T, ? extends R> mapper) {
/* 185 */       this.actual = actual;
/* 186 */       this.mapper = mapper;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 191 */       if (Operators.validate(this.s, s)) {
/* 192 */         this.s = s;
/*     */         
/* 194 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */     
/*     */     public void onNext(T t) {
/*     */       R v;
/* 200 */       if (this.done) {
/* 201 */         Operators.onNextDropped(t, this.actual.currentContext());
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/*     */       try {
/* 208 */         v = this.mapper.apply(t);
/* 209 */         if (v == null) {
/* 210 */           throw new NullPointerException("The mapper [" + this.mapper.getClass().getName() + "] returned a null value.");
/*     */         }
/*     */       }
/* 213 */       catch (Throwable e) {
/* 214 */         Throwable e_ = Operators.onNextError(t, e, this.actual.currentContext(), this.s);
/* 215 */         if (e_ != null) {
/* 216 */           onError(e_);
/*     */         } else {
/*     */           
/* 219 */           this.s.request(1L);
/*     */         } 
/*     */         
/*     */         return;
/*     */       } 
/* 224 */       this.actual.onNext(v);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean tryOnNext(T t) {
/* 229 */       if (this.done) {
/* 230 */         Operators.onNextDropped(t, this.actual.currentContext());
/* 231 */         return true;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 237 */         R v = this.mapper.apply(t);
/* 238 */         if (v == null) {
/* 239 */           throw new NullPointerException("The mapper [" + this.mapper.getClass().getName() + "] returned a null value.");
/*     */         }
/* 241 */         return this.actual.tryOnNext(v);
/*     */       }
/* 243 */       catch (Throwable e) {
/* 244 */         Throwable e_ = Operators.onNextError(t, e, this.actual.currentContext(), this.s);
/* 245 */         if (e_ != null) {
/* 246 */           this.done = true;
/* 247 */           this.actual.onError(e_);
/* 248 */           return true;
/*     */         } 
/*     */         
/* 251 */         return false;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 258 */       if (this.done) {
/* 259 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*     */         
/*     */         return;
/*     */       } 
/* 263 */       this.done = true;
/*     */       
/* 265 */       this.actual.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 270 */       if (this.done) {
/*     */         return;
/*     */       }
/* 273 */       this.done = true;
/*     */       
/* 275 */       this.actual.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 281 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 282 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 283 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 285 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super R> actual() {
/* 290 */       return (CoreSubscriber<? super R>)this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 295 */       this.s.request(n);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 300 */       this.s.cancel();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\FluxMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */