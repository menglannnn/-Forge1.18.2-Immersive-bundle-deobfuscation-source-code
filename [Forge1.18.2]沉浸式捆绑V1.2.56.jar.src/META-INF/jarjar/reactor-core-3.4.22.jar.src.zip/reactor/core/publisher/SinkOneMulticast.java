/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.util.Objects;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class SinkOneMulticast<O>
/*     */   extends SinkEmptyMulticast<O>
/*     */   implements InternalOneSink<O>
/*     */ {
/*     */   @Nullable
/*     */   O value;
/*     */   
/*     */   public Sinks.EmitResult tryEmitEmpty() {
/*  33 */     return tryEmitValue((O)null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Sinks.EmitResult tryEmitError(Throwable cause) {
/*  39 */     Objects.requireNonNull(cause, "onError cannot be null");
/*     */     
/*  41 */     SinkEmptyMulticast.Inner[] arrayOfInner = SUBSCRIBERS.getAndSet(this, TERMINATED);
/*  42 */     if (arrayOfInner == TERMINATED) {
/*  43 */       return Sinks.EmitResult.FAIL_TERMINATED;
/*     */     }
/*     */     
/*  46 */     this.error = cause;
/*  47 */     this.value = null;
/*     */     
/*  49 */     for (SinkEmptyMulticast.Inner<O> as : arrayOfInner) {
/*  50 */       as.error(cause);
/*     */     }
/*  52 */     return Sinks.EmitResult.OK;
/*     */   }
/*     */ 
/*     */   
/*     */   public Sinks.EmitResult tryEmitValue(@Nullable O value) {
/*  57 */     SinkEmptyMulticast.Inner[] arrayOfInner = SUBSCRIBERS.getAndSet(this, TERMINATED);
/*  58 */     if (arrayOfInner == TERMINATED) {
/*  59 */       return Sinks.EmitResult.FAIL_TERMINATED;
/*     */     }
/*     */     
/*  62 */     this.value = value;
/*  63 */     if (value == null) {
/*  64 */       for (SinkEmptyMulticast.Inner<O> as : arrayOfInner) {
/*  65 */         as.complete();
/*     */       }
/*     */     } else {
/*     */       
/*  69 */       for (SinkEmptyMulticast.Inner<O> as : arrayOfInner) {
/*  70 */         as.complete(value);
/*     */       }
/*     */     } 
/*  73 */     return Sinks.EmitResult.OK;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  78 */     if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf((this.subscribers == TERMINATED)); 
/*  79 */     if (key == Scannable.Attr.ERROR) return this.error; 
/*  80 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */     
/*  82 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super O> actual) {
/*  87 */     NextInner<O> as = new NextInner<>(actual, this);
/*  88 */     actual.onSubscribe(as);
/*  89 */     if (add(as)) {
/*  90 */       if (as.isCancelled()) {
/*  91 */         remove(as);
/*     */       }
/*     */     } else {
/*     */       
/*  95 */       Throwable ex = this.error;
/*  96 */       if (ex != null) {
/*  97 */         actual.onError(ex);
/*     */       } else {
/*     */         
/* 100 */         O v = this.value;
/* 101 */         if (v != null) {
/* 102 */           as.complete(v);
/*     */         } else {
/*     */           
/* 105 */           as.complete();
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public O block(Duration timeout) {
/* 114 */     if (timeout.isNegative()) {
/* 115 */       return super.block(Duration.ZERO);
/*     */     }
/* 117 */     return super.block(timeout);
/*     */   }
/*     */   
/*     */   static final class NextInner<T>
/*     */     extends Operators.MonoInnerProducerBase<T> implements SinkEmptyMulticast.Inner<T> {
/*     */     final SinkOneMulticast<T> parent;
/*     */     
/*     */     NextInner(CoreSubscriber<? super T> actual, SinkOneMulticast<T> parent) {
/* 125 */       super(actual);
/* 126 */       this.parent = parent;
/*     */     }
/*     */ 
/*     */     
/*     */     protected void doOnCancel() {
/* 131 */       this.parent.remove(this);
/*     */     }
/*     */ 
/*     */     
/*     */     public void error(Throwable t) {
/* 136 */       if (!isCancelled()) {
/* 137 */         actual().onError(t);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 143 */       if (key == Scannable.Attr.RUN_STYLE) {
/* 144 */         return Scannable.Attr.RunStyle.SYNC;
/*     */       }
/* 146 */       return super.scanUnsafe(key);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\SinkOneMulticast.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */