/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import org.reactivestreams.Publisher;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Fuseable;
/*    */ import reactor.core.Scannable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class FluxLiftFuseable<I, O>
/*    */   extends InternalFluxOperator<I, O>
/*    */   implements Fuseable
/*    */ {
/*    */   final Operators.LiftFunction<I, O> liftFunction;
/*    */   
/*    */   FluxLiftFuseable(Publisher<I> p, Operators.LiftFunction<I, O> liftFunction) {
/* 36 */     super(Flux.from(p));
/* 37 */     this.liftFunction = liftFunction;
/*    */   }
/*    */ 
/*    */   
/*    */   public String stepName() {
/* 42 */     if (this.source instanceof Scannable) {
/* 43 */       return Scannable.from(this.source).stepName();
/*    */     }
/* 45 */     return super.stepName();
/*    */   }
/*    */ 
/*    */   
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 50 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.from(this.source).scanUnsafe(key); 
/* 51 */     if (key == Scannable.Attr.LIFTER) return this.liftFunction.name; 
/* 52 */     return super.scanUnsafe(key);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public CoreSubscriber<? super I> subscribeOrReturn(CoreSubscriber<? super O> actual) {
/* 58 */     CoreSubscriber<? super I> input = this.liftFunction.lifter.apply(this.source, actual);
/*    */     
/* 60 */     Objects.requireNonNull(input, "Lifted subscriber MUST NOT be null");
/*    */     
/* 62 */     if (actual instanceof Fuseable.QueueSubscription && !(input instanceof Fuseable.QueueSubscription))
/*    */     {
/*    */       
/* 65 */       input = new FluxHide.SuppressFuseableSubscriber<>(input);
/*    */     }
/*    */     
/* 68 */     return input;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\FluxLiftFuseable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */