/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import java.util.function.Function;
/*    */ import org.reactivestreams.Publisher;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Scannable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MonoTimeout<T, U, V>
/*    */   extends InternalMonoOperator<T, T>
/*    */ {
/*    */   final Publisher<U> firstTimeout;
/*    */   final Publisher<? extends T> other;
/*    */   final String timeoutDescription;
/*    */   static final Function NEVER = e -> Flux.never();
/*    */   
/*    */   MonoTimeout(Mono<? extends T> source, Publisher<U> firstTimeout, String timeoutDescription) {
/* 50 */     super(source);
/* 51 */     this.firstTimeout = Objects.<Publisher<U>>requireNonNull(firstTimeout, "firstTimeout");
/* 52 */     this.other = null;
/* 53 */     this.timeoutDescription = timeoutDescription;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   MonoTimeout(Mono<? extends T> source, Publisher<U> firstTimeout, Publisher<? extends T> other) {
/* 59 */     super(source);
/* 60 */     this.firstTimeout = Objects.<Publisher<U>>requireNonNull(firstTimeout, "firstTimeout");
/* 61 */     this.other = Objects.<Publisher<? extends T>>requireNonNull(other, "other");
/* 62 */     this.timeoutDescription = null;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/* 68 */     return new FluxTimeout.TimeoutMainSubscriber<>(
/* 69 */         Operators.serialize(actual), this.firstTimeout, NEVER, this.other, 
/*    */ 
/*    */ 
/*    */         
/* 73 */         FluxTimeout.addNameToTimeoutDescription((Publisher<?>)this.source, this.timeoutDescription));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 79 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 80 */     return super.scanUnsafe(key);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\MonoTimeout.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */