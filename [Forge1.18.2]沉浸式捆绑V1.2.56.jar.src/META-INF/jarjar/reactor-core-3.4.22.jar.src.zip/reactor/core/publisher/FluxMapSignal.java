/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.AbstractQueue;
/*     */ import java.util.Iterator;
/*     */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*     */ import java.util.function.BooleanSupplier;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Supplier;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxMapSignal<T, R>
/*     */   extends InternalFluxOperator<T, R>
/*     */ {
/*     */   final Function<? super T, ? extends R> mapperNext;
/*     */   final Function<? super Throwable, ? extends R> mapperError;
/*     */   final Supplier<? extends R> mapperComplete;
/*     */   
/*     */   FluxMapSignal(Flux<? extends T> source, @Nullable Function<? super T, ? extends R> mapperNext, @Nullable Function<? super Throwable, ? extends R> mapperError, @Nullable Supplier<? extends R> mapperComplete) {
/*  58 */     super(source);
/*  59 */     if (mapperNext == null && mapperError == null && mapperComplete == null) {
/*  60 */       throw new IllegalArgumentException("Map Signal needs at least one valid mapper");
/*     */     }
/*     */     
/*  63 */     this.mapperNext = mapperNext;
/*  64 */     this.mapperError = mapperError;
/*  65 */     this.mapperComplete = mapperComplete;
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super R> actual) {
/*  70 */     return new FluxMapSignalSubscriber<>(actual, this.mapperNext, this.mapperError, this.mapperComplete);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  78 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  79 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class FluxMapSignalSubscriber<T, R>
/*     */     extends AbstractQueue<R>
/*     */     implements InnerOperator<T, R>, BooleanSupplier
/*     */   {
/*     */     final CoreSubscriber<? super R> actual;
/*     */     
/*     */     final Function<? super T, ? extends R> mapperNext;
/*     */     
/*     */     final Function<? super Throwable, ? extends R> mapperError;
/*     */     
/*     */     final Supplier<? extends R> mapperComplete;
/*     */     
/*     */     boolean done;
/*     */     
/*     */     Subscription s;
/*     */     
/*     */     R value;
/*     */     volatile long requested;
/* 101 */     static final AtomicLongFieldUpdater<FluxMapSignalSubscriber> REQUESTED = AtomicLongFieldUpdater.newUpdater(FluxMapSignalSubscriber.class, "requested");
/*     */ 
/*     */     
/*     */     volatile boolean cancelled;
/*     */ 
/*     */     
/*     */     long produced;
/*     */ 
/*     */     
/*     */     FluxMapSignalSubscriber(CoreSubscriber<? super R> actual, @Nullable Function<? super T, ? extends R> mapperNext, @Nullable Function<? super Throwable, ? extends R> mapperError, @Nullable Supplier<? extends R> mapperComplete) {
/* 111 */       this.actual = actual;
/* 112 */       this.mapperNext = mapperNext;
/* 113 */       this.mapperError = mapperError;
/* 114 */       this.mapperComplete = mapperComplete;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 119 */       if (Operators.validate(this.s, s)) {
/* 120 */         this.s = s;
/*     */         
/* 122 */         this.actual.onSubscribe(this);
/*     */         
/* 124 */         if (this.mapperNext == null) {
/* 125 */           s.request(Long.MAX_VALUE);
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*     */     public void onNext(T t) {
/*     */       R v;
/* 132 */       if (this.done) {
/* 133 */         Operators.onNextDropped(t, this.actual.currentContext());
/*     */         
/*     */         return;
/*     */       } 
/* 137 */       if (this.mapperNext == null) {
/*     */         return;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 144 */         v = this.mapperNext.apply(t);
/* 145 */         if (v == null) {
/* 146 */           throw new NullPointerException("The mapper [" + this.mapperNext.getClass().getName() + "] returned a null value.");
/*     */         }
/*     */       }
/* 149 */       catch (Throwable e) {
/* 150 */         this.done = true;
/* 151 */         this.actual.onError(Operators.onOperatorError(this.s, e, t, this.actual.currentContext()));
/*     */         
/*     */         return;
/*     */       } 
/* 155 */       this.produced++;
/* 156 */       this.actual.onNext(v);
/*     */     }
/*     */     
/*     */     public void onError(Throwable t) {
/*     */       R v;
/* 161 */       if (this.done) {
/* 162 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*     */         
/*     */         return;
/*     */       } 
/* 166 */       this.done = true;
/*     */       
/* 168 */       if (this.mapperError == null) {
/* 169 */         this.actual.onError(t);
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/*     */       try {
/* 176 */         v = this.mapperError.apply(t);
/* 177 */         if (v == null) {
/* 178 */           throw new NullPointerException("The mapper [" + this.mapperError.getClass().getName() + "] returned a null value.");
/*     */         }
/*     */       }
/* 181 */       catch (Throwable e) {
/* 182 */         this.done = true;
/* 183 */         this.actual.onError(Operators.onOperatorError(this.s, e, t, this.actual.currentContext()));
/*     */         
/*     */         return;
/*     */       } 
/* 187 */       this.value = v;
/* 188 */       long p = this.produced;
/* 189 */       if (p != 0L) {
/* 190 */         Operators.addCap(REQUESTED, this, -p);
/*     */       }
/* 192 */       DrainUtils.postComplete(this.actual, this, REQUESTED, this, this);
/*     */     }
/*     */     
/*     */     public void onComplete() {
/*     */       R v;
/* 197 */       if (this.done) {
/*     */         return;
/*     */       }
/* 200 */       this.done = true;
/*     */       
/* 202 */       if (this.mapperComplete == null) {
/* 203 */         this.actual.onComplete();
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/*     */       try {
/* 210 */         v = this.mapperComplete.get();
/* 211 */         if (v == null) {
/* 212 */           throw new NullPointerException("The mapper [" + this.mapperComplete.getClass().getName() + "] returned a null value.");
/*     */         }
/*     */       }
/* 215 */       catch (Throwable e) {
/* 216 */         this.done = true;
/* 217 */         this.actual.onError(Operators.onOperatorError(this.s, e, this.actual.currentContext()));
/*     */         
/*     */         return;
/*     */       } 
/* 221 */       this.value = v;
/* 222 */       long p = this.produced;
/* 223 */       if (p != 0L) {
/* 224 */         Operators.addCap(REQUESTED, this, -p);
/*     */       }
/* 226 */       DrainUtils.postComplete(this.actual, this, REQUESTED, this, this);
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super R> actual() {
/* 231 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 236 */       if (Operators.validate(n) && 
/* 237 */         !DrainUtils.postCompleteRequest(n, (Subscriber<? super R>)this.actual, this, REQUESTED, this, this)) {
/* 238 */         this.s.request(n);
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean offer(R e) {
/* 245 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public R poll() {
/* 251 */       R v = this.value;
/* 252 */       if (v != null) {
/* 253 */         this.value = null;
/* 254 */         return v;
/*     */       } 
/* 256 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 262 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 263 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 264 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(getAsBoolean()); 
/* 265 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf(this.requested); 
/* 266 */       if (key == Scannable.Attr.BUFFERED) return Integer.valueOf(size()); 
/* 267 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 269 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public R peek() {
/* 275 */       return this.value;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean getAsBoolean() {
/* 280 */       return this.cancelled;
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 285 */       this.cancelled = true;
/* 286 */       this.s.cancel();
/*     */     }
/*     */ 
/*     */     
/*     */     public Iterator<R> iterator() {
/* 291 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 296 */       return (this.value == null) ? 0 : 1;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\FluxMapSignal.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */