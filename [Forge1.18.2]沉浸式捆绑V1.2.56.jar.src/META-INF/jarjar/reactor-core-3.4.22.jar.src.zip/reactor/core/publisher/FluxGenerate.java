/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.Consumer;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ import reactor.util.context.ContextView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxGenerate<T, S>
/*     */   extends Flux<T>
/*     */   implements Fuseable, SourceProducer<T>
/*     */ {
/*     */   static final Callable EMPTY_CALLABLE = () -> null;
/*     */   final Callable<S> stateSupplier;
/*     */   final BiFunction<S, SynchronousSink<T>, S> generator;
/*     */   final Consumer<? super S> stateConsumer;
/*     */   
/*     */   FluxGenerate(Consumer<SynchronousSink<T>> generator) {
/*  57 */     this(EMPTY_CALLABLE, (state, sink) -> {
/*     */           generator.accept(sink);
/*     */           return null;
/*     */         });
/*     */   }
/*     */   
/*     */   FluxGenerate(Callable<S> stateSupplier, BiFunction<S, SynchronousSink<T>, S> generator) {
/*  64 */     this(stateSupplier, generator, s -> {
/*     */         
/*     */         });
/*     */   }
/*     */   
/*     */   FluxGenerate(Callable<S> stateSupplier, BiFunction<S, SynchronousSink<T>, S> generator, Consumer<? super S> stateConsumer) {
/*  70 */     this.stateSupplier = Objects.<Callable<S>>requireNonNull(stateSupplier, "stateSupplier");
/*  71 */     this.generator = Objects.<BiFunction<S, SynchronousSink<T>, S>>requireNonNull(generator, "generator");
/*  72 */     this.stateConsumer = Objects.<Consumer<? super S>>requireNonNull(stateConsumer, "stateConsumer");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super T> actual) {
/*     */     S state;
/*     */     try {
/*  80 */       state = this.stateSupplier.call();
/*  81 */     } catch (Throwable e) {
/*  82 */       Operators.error((Subscriber<?>)actual, Operators.onOperatorError(e, actual.currentContext()));
/*     */       return;
/*     */     } 
/*  85 */     actual.onSubscribe(new GenerateSubscription<>(actual, state, this.generator, this.stateConsumer));
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  90 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  91 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static final class GenerateSubscription<T, S>
/*     */     implements Fuseable.QueueSubscription<T>, InnerProducer<T>, SynchronousSink<T>
/*     */   {
/*     */     final CoreSubscriber<? super T> actual;
/*     */     
/*     */     final BiFunction<S, SynchronousSink<T>, S> generator;
/*     */     
/*     */     final Consumer<? super S> stateConsumer;
/*     */     
/*     */     volatile boolean cancelled;
/*     */     
/*     */     S state;
/*     */     
/*     */     boolean terminate;
/*     */     
/*     */     boolean hasValue;
/*     */     
/*     */     boolean outputFused;
/*     */     
/*     */     T generatedValue;
/*     */     
/*     */     Throwable generatedError;
/*     */     
/*     */     volatile long requested;
/*     */     
/* 121 */     static final AtomicLongFieldUpdater<GenerateSubscription> REQUESTED = AtomicLongFieldUpdater.newUpdater(GenerateSubscription.class, "requested");
/*     */ 
/*     */     
/*     */     GenerateSubscription(CoreSubscriber<? super T> actual, S state, BiFunction<S, SynchronousSink<T>, S> generator, Consumer<? super S> stateConsumer) {
/* 125 */       this.actual = actual;
/* 126 */       this.state = state;
/* 127 */       this.generator = generator;
/* 128 */       this.stateConsumer = stateConsumer;
/*     */     }
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     public Context currentContext() {
/* 134 */       return this.actual.currentContext();
/*     */     }
/*     */ 
/*     */     
/*     */     public ContextView contextView() {
/* 139 */       return (ContextView)this.actual.currentContext();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 145 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.terminate); 
/* 146 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf(this.requested); 
/* 147 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(this.cancelled); 
/* 148 */       if (key == Scannable.Attr.ERROR) return this.generatedError; 
/* 149 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 151 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 156 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void next(T t) {
/* 161 */       if (this.terminate) {
/* 162 */         Operators.onNextDropped(t, this.actual.currentContext());
/*     */         return;
/*     */       } 
/* 165 */       if (this.hasValue) {
/* 166 */         error(new IllegalStateException("More than one call to onNext"));
/*     */         
/*     */         return;
/*     */       } 
/* 170 */       if (t == null) {
/* 171 */         error(new NullPointerException("The generator produced a null value"));
/*     */         return;
/*     */       } 
/* 174 */       this.hasValue = true;
/* 175 */       if (this.outputFused) {
/* 176 */         this.generatedValue = t;
/*     */       } else {
/* 178 */         this.actual.onNext(t);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void error(Throwable e) {
/* 184 */       if (this.terminate) {
/*     */         return;
/*     */       }
/* 187 */       this.terminate = true;
/* 188 */       if (this.outputFused) {
/* 189 */         this.generatedError = e;
/*     */       } else {
/* 191 */         this.actual.onError(e);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void complete() {
/* 197 */       if (this.terminate) {
/*     */         return;
/*     */       }
/* 200 */       this.terminate = true;
/* 201 */       if (!this.outputFused) {
/* 202 */         this.actual.onComplete();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 208 */       if (Operators.validate(n) && 
/* 209 */         Operators.addCap(REQUESTED, this, n) == 0L) {
/* 210 */         if (n == Long.MAX_VALUE) {
/* 211 */           fastPath();
/*     */         } else {
/* 213 */           slowPath(n);
/*     */         } 
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     void fastPath() {
/* 220 */       S s = this.state;
/*     */       
/* 222 */       BiFunction<S, SynchronousSink<T>, S> g = this.generator;
/*     */ 
/*     */       
/*     */       while (true) {
/* 226 */         if (this.cancelled) {
/* 227 */           cleanup(s);
/*     */           
/*     */           return;
/*     */         } 
/*     */         try {
/* 232 */           s = g.apply(s, this);
/* 233 */         } catch (Throwable e) {
/* 234 */           cleanup(s);
/*     */           
/* 236 */           this.actual.onError(Operators.onOperatorError(e, this.actual.currentContext()));
/*     */           return;
/*     */         } 
/* 239 */         if (this.terminate || this.cancelled) {
/* 240 */           cleanup(s);
/*     */           return;
/*     */         } 
/* 243 */         if (!this.hasValue) {
/* 244 */           cleanup(s);
/*     */           
/* 246 */           this.actual.onError(new IllegalStateException("The generator didn't call any of the SynchronousSink method"));
/*     */           
/*     */           return;
/*     */         } 
/*     */         
/* 251 */         this.hasValue = false;
/*     */       } 
/*     */     }
/*     */     
/*     */     void slowPath(long n) {
/* 256 */       S s = this.state;
/*     */       
/* 258 */       long e = 0L;
/*     */       
/* 260 */       BiFunction<S, SynchronousSink<T>, S> g = this.generator;
/*     */       
/*     */       while (true) {
/* 263 */         while (e != n) {
/*     */           
/* 265 */           if (this.cancelled) {
/* 266 */             cleanup(s);
/*     */             
/*     */             return;
/*     */           } 
/*     */           try {
/* 271 */             s = g.apply(s, this);
/* 272 */           } catch (Throwable ex) {
/* 273 */             cleanup(s);
/*     */             
/* 275 */             this.actual.onError(ex);
/*     */             return;
/*     */           } 
/* 278 */           if (this.terminate || this.cancelled) {
/* 279 */             cleanup(s);
/*     */             return;
/*     */           } 
/* 282 */           if (!this.hasValue) {
/* 283 */             cleanup(s);
/*     */             
/* 285 */             this.actual.onError(new IllegalStateException("The generator didn't call any of the SynchronousSink method"));
/*     */             
/*     */             return;
/*     */           } 
/*     */           
/* 290 */           e++;
/* 291 */           this.hasValue = false;
/*     */         } 
/*     */         
/* 294 */         n = this.requested;
/*     */         
/* 296 */         if (n == e) {
/* 297 */           this.state = s;
/* 298 */           n = REQUESTED.addAndGet(this, -e);
/* 299 */           e = 0L;
/* 300 */           if (n == 0L) {
/*     */             break;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 309 */       if (!this.cancelled) {
/* 310 */         this.cancelled = true;
/*     */         
/* 312 */         if (REQUESTED.getAndIncrement(this) == 0L) {
/* 313 */           cleanup(this.state);
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*     */     void cleanup(S s) {
/*     */       try {
/* 320 */         this.state = null;
/*     */         
/* 322 */         this.stateConsumer.accept(s);
/* 323 */       } catch (Throwable e) {
/* 324 */         Operators.onErrorDropped(e, this.actual.currentContext());
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public int requestFusion(int requestedMode) {
/* 330 */       if ((requestedMode & 0x1) != 0 && (requestedMode & 0x4) == 0) {
/* 331 */         this.outputFused = true;
/* 332 */         return 1;
/*     */       } 
/* 334 */       return 0;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public T poll() {
/* 340 */       S s = this.state;
/*     */       
/* 342 */       if (this.terminate) {
/* 343 */         cleanup(s);
/*     */         
/* 345 */         Throwable e = this.generatedError;
/* 346 */         if (e != null) {
/*     */           
/* 348 */           this.generatedError = null;
/* 349 */           throw Exceptions.propagate(e);
/*     */         } 
/*     */         
/* 352 */         return null;
/*     */       } 
/*     */ 
/*     */       
/*     */       try {
/* 357 */         s = this.generator.apply(s, this);
/* 358 */       } catch (Throwable ex) {
/* 359 */         cleanup(s);
/* 360 */         throw ex;
/*     */       } 
/*     */       
/* 363 */       if (!this.hasValue) {
/* 364 */         cleanup(s);
/*     */         
/* 366 */         if (!this.terminate) {
/* 367 */           throw new IllegalStateException("The generator didn't call any of the SynchronousSink method");
/*     */         }
/*     */         
/* 370 */         Throwable e = this.generatedError;
/* 371 */         if (e != null) {
/*     */           
/* 373 */           this.generatedError = null;
/* 374 */           throw Exceptions.propagate(e);
/*     */         } 
/*     */         
/* 377 */         return null;
/*     */       } 
/*     */       
/* 380 */       T v = this.generatedValue;
/* 381 */       this.generatedValue = null;
/* 382 */       this.hasValue = false;
/*     */       
/* 384 */       this.state = s;
/* 385 */       return v;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isEmpty() {
/* 390 */       return this.terminate;
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 395 */       return isEmpty() ? 0 : -1;
/*     */     }
/*     */ 
/*     */     
/*     */     public void clear() {
/* 400 */       this.generatedError = null;
/* 401 */       this.generatedValue = null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\FluxGenerate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */