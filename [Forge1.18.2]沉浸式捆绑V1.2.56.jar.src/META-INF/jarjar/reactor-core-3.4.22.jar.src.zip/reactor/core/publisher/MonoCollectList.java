/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MonoCollectList<T>
/*     */   extends MonoFromFluxOperator<T, List<T>>
/*     */   implements Fuseable
/*     */ {
/*     */   MonoCollectList(Flux<? extends T> source) {
/*  36 */     super(source);
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super List<T>> actual) {
/*  41 */     return new MonoCollectListSubscriber<>(actual);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  46 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  47 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class MonoCollectListSubscriber<T>
/*     */     extends Operators.MonoSubscriber<T, List<T>>
/*     */   {
/*     */     List<T> list;
/*     */     Subscription s;
/*     */     boolean done;
/*     */     
/*     */     MonoCollectListSubscriber(CoreSubscriber<? super List<T>> actual) {
/*  59 */       super(actual);
/*     */       
/*  61 */       this.list = new ArrayList<>();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/*  67 */       if (key == Scannable.Attr.PARENT) return this.s; 
/*  68 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/*  69 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  70 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/*  75 */       if (Operators.validate(this.s, s)) {
/*  76 */         this.s = s;
/*     */         
/*  78 */         this.actual.onSubscribe(this);
/*     */         
/*  80 */         s.request(Long.MAX_VALUE);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/*  86 */       if (this.done) {
/*  87 */         Operators.onNextDropped(t, this.actual.currentContext());
/*     */         
/*     */         return;
/*     */       } 
/*  91 */       synchronized (this) {
/*  92 */         List<T> l = this.list;
/*  93 */         if (l != null) {
/*  94 */           l.add(t);
/*     */           return;
/*     */         } 
/*     */       } 
/*  98 */       Operators.onDiscard(t, this.actual.currentContext());
/*     */     }
/*     */     
/*     */     public void onError(Throwable t) {
/*     */       List<T> l;
/* 103 */       if (this.done) {
/* 104 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*     */         return;
/*     */       } 
/* 107 */       this.done = true;
/*     */       
/* 109 */       synchronized (this) {
/* 110 */         l = this.list;
/* 111 */         this.list = null;
/*     */       } 
/* 113 */       discard(l);
/* 114 */       this.actual.onError(t);
/*     */     }
/*     */     
/*     */     public void onComplete() {
/*     */       List<T> l;
/* 119 */       if (this.done) {
/*     */         return;
/*     */       }
/* 122 */       this.done = true;
/*     */       
/* 124 */       synchronized (this) {
/* 125 */         l = this.list;
/* 126 */         this.list = null;
/*     */       } 
/* 128 */       if (l != null) {
/* 129 */         complete(l);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     protected void discard(List<T> v) {
/* 135 */       Operators.onDiscardMultiple(v, this.actual.currentContext());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void cancel() {
/*     */       List<T> l;
/* 142 */       int state = STATE.getAndSet(this, 4);
/* 143 */       if (state != 4) {
/* 144 */         this.s.cancel();
/*     */       }
/* 146 */       synchronized (this) {
/* 147 */         if (state <= 2) {
/* 148 */           l = this.list;
/* 149 */           this.value = null;
/* 150 */           this.list = null;
/*     */         } else {
/*     */           
/* 153 */           l = null;
/*     */         } 
/*     */       } 
/* 156 */       if (l != null)
/* 157 */         discard(l); 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\MonoCollectList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */