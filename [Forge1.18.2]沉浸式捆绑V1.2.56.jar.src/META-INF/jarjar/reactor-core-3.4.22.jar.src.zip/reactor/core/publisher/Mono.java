/*      */ package reactor.core.publisher;
/*      */ 
/*      */ import java.time.Duration;
/*      */ import java.util.NoSuchElementException;
/*      */ import java.util.Objects;
/*      */ import java.util.Optional;
/*      */ import java.util.concurrent.Callable;
/*      */ import java.util.concurrent.CompletableFuture;
/*      */ import java.util.concurrent.CompletionStage;
/*      */ import java.util.concurrent.TimeUnit;
/*      */ import java.util.function.BiConsumer;
/*      */ import java.util.function.BiFunction;
/*      */ import java.util.function.BiPredicate;
/*      */ import java.util.function.BooleanSupplier;
/*      */ import java.util.function.Consumer;
/*      */ import java.util.function.Function;
/*      */ import java.util.function.LongConsumer;
/*      */ import java.util.function.Predicate;
/*      */ import java.util.function.Supplier;
/*      */ import java.util.logging.Level;
/*      */ import org.reactivestreams.Publisher;
/*      */ import org.reactivestreams.Subscriber;
/*      */ import org.reactivestreams.Subscription;
/*      */ import reactor.core.CorePublisher;
/*      */ import reactor.core.CoreSubscriber;
/*      */ import reactor.core.Disposable;
/*      */ import reactor.core.Exceptions;
/*      */ import reactor.core.Fuseable;
/*      */ import reactor.core.scheduler.Scheduler;
/*      */ import reactor.core.scheduler.Schedulers;
/*      */ import reactor.util.Logger;
/*      */ import reactor.util.Metrics;
/*      */ import reactor.util.annotation.Nullable;
/*      */ import reactor.util.concurrent.Queues;
/*      */ import reactor.util.context.Context;
/*      */ import reactor.util.context.ContextView;
/*      */ import reactor.util.function.Tuple2;
/*      */ import reactor.util.function.Tuple3;
/*      */ import reactor.util.function.Tuple4;
/*      */ import reactor.util.function.Tuple5;
/*      */ import reactor.util.function.Tuple6;
/*      */ import reactor.util.function.Tuple7;
/*      */ import reactor.util.function.Tuple8;
/*      */ import reactor.util.function.Tuples;
/*      */ import reactor.util.retry.Retry;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class Mono<T>
/*      */   implements CorePublisher<T>
/*      */ {
/*      */   public static <T> Mono<T> create(Consumer<MonoSink<T>> callback) {
/*  199 */     return onAssembly(new MonoCreate<>(callback));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Mono<T> defer(Supplier<? extends Mono<? extends T>> supplier) {
/*  215 */     return onAssembly(new MonoDefer<>(supplier));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static <T> Mono<T> deferWithContext(Function<Context, ? extends Mono<? extends T>> contextualMonoFactory) {
/*  234 */     return deferContextual(view -> (Mono)contextualMonoFactory.apply(Context.of(view)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Mono<T> deferContextual(Function<ContextView, ? extends Mono<? extends T>> contextualMonoFactory) {
/*  251 */     return onAssembly(new MonoDeferContextual<>(contextualMonoFactory));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Mono<Long> delay(Duration duration) {
/*  268 */     return delay(duration, Schedulers.parallel());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Mono<Long> delay(Duration duration, Scheduler timer) {
/*  285 */     return onAssembly(new MonoDelay(duration.toNanos(), TimeUnit.NANOSECONDS, timer));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Mono<T> empty() {
/*  299 */     return MonoEmpty.instance();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Mono<T> error(Throwable error) {
/*  314 */     return onAssembly(new MonoError<>(error));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Mono<T> error(Supplier<? extends Throwable> errorSupplier) {
/*  330 */     return onAssembly(new MonoErrorSupplied<>(errorSupplier));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @SafeVarargs
/*      */   @Deprecated
/*      */   public static <T> Mono<T> first(Mono<? extends T>... monos) {
/*  349 */     return firstWithSignal(monos);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static <T> Mono<T> first(Iterable<? extends Mono<? extends T>> monos) {
/*  367 */     return firstWithSignal(monos);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @SafeVarargs
/*      */   public static <T> Mono<T> firstWithSignal(Mono<? extends T>... monos) {
/*  384 */     return onAssembly(new MonoFirstWithSignal<>(monos));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Mono<T> firstWithSignal(Iterable<? extends Mono<? extends T>> monos) {
/*  400 */     return onAssembly(new MonoFirstWithSignal<>(monos));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Mono<T> firstWithValue(Iterable<? extends Mono<? extends T>> monos) {
/*  433 */     return onAssembly(new MonoFirstWithValue<>(monos));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @SafeVarargs
/*      */   public static <T> Mono<T> firstWithValue(Mono<? extends T> first, Mono<? extends T>... others) {
/*  470 */     if (first instanceof MonoFirstWithValue) {
/*      */       
/*  472 */       MonoFirstWithValue<T> a = (MonoFirstWithValue)first;
/*  473 */       Mono<T> result = a.firstValuedAdditionalSources(others);
/*  474 */       if (result != null) {
/*  475 */         return result;
/*      */       }
/*      */     } 
/*  478 */     return onAssembly(new MonoFirstWithValue<>(first, others));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Mono<T> from(Publisher<? extends T> source) {
/*  499 */     if (source instanceof Mono) {
/*      */       
/*  501 */       Mono<T> casted = (Mono)source;
/*  502 */       return casted;
/*      */     } 
/*  504 */     if (source instanceof FluxSourceMono || source instanceof FluxSourceMonoFuseable) {
/*      */ 
/*      */       
/*  507 */       FluxFromMonoOperator<T, T> wrapper = (FluxFromMonoOperator)source;
/*      */       
/*  509 */       return (Mono)wrapper.source;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  514 */     Publisher<? extends T> publisher = source;
/*  515 */     return onAssembly(wrap((Publisher)publisher, true));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Mono<T> fromCallable(Callable<? extends T> supplier) {
/*  531 */     return onAssembly(new MonoCallable<>(supplier));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Mono<T> fromCompletionStage(CompletionStage<? extends T> completionStage) {
/*  551 */     return onAssembly(new MonoCompletionStage<>(completionStage));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Mono<T> fromCompletionStage(Supplier<? extends CompletionStage<? extends T>> stageSupplier) {
/*  572 */     return defer(() -> onAssembly(new MonoCompletionStage(stageSupplier.get())));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <I> Mono<I> fromDirect(Publisher<? extends I> source) {
/*  594 */     if (source instanceof Mono) {
/*      */       
/*  596 */       Mono<I> m = (Mono)source;
/*  597 */       return m;
/*      */     } 
/*  599 */     if (source instanceof FluxSourceMono || source instanceof FluxSourceMonoFuseable) {
/*      */ 
/*      */       
/*  602 */       FluxFromMonoOperator<I, I> wrapper = (FluxFromMonoOperator)source;
/*      */       
/*  604 */       return (Mono)wrapper.source;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  609 */     Publisher<? extends I> publisher = source;
/*  610 */     return onAssembly(wrap((Publisher)publisher, false));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Mono<T> fromFuture(CompletableFuture<? extends T> future) {
/*  630 */     return onAssembly(new MonoCompletionStage<>(future));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Mono<T> fromFuture(Supplier<? extends CompletableFuture<? extends T>> futureSupplier) {
/*  651 */     return defer(() -> onAssembly(new MonoCompletionStage(futureSupplier.get())));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Mono<T> fromRunnable(Runnable runnable) {
/*  667 */     return onAssembly(new MonoRunnable<>(runnable));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Mono<T> fromSupplier(Supplier<? extends T> supplier) {
/*  683 */     return onAssembly(new MonoSupplier<>(supplier));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Mono<T> ignoreElements(Publisher<T> source) {
/*  703 */     return onAssembly(new MonoIgnorePublisher<>(source));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Mono<T> just(T data) {
/*  719 */     return onAssembly(new MonoJust<>(data));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Mono<T> justOrEmpty(@Nullable Optional<? extends T> data) {
/*  735 */     return (data != null && data.isPresent()) ? just(data.get()) : empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Mono<T> justOrEmpty(@Nullable T data) {
/*  751 */     return (data != null) ? just(data) : empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Mono<T> never() {
/*  766 */     return MonoNever.instance();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Mono<Boolean> sequenceEqual(Publisher<? extends T> source1, Publisher<? extends T> source2) {
/*  781 */     return sequenceEqual(source1, source2, equalsBiPredicate(), Queues.SMALL_BUFFER_SIZE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Mono<Boolean> sequenceEqual(Publisher<? extends T> source1, Publisher<? extends T> source2, BiPredicate<? super T, ? super T> isEqual) {
/*  800 */     return sequenceEqual(source1, source2, isEqual, Queues.SMALL_BUFFER_SIZE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Mono<Boolean> sequenceEqual(Publisher<? extends T> source1, Publisher<? extends T> source2, BiPredicate<? super T, ? super T> isEqual, int prefetch) {
/*  821 */     return onAssembly(new MonoSequenceEqual<>(source1, source2, isEqual, prefetch));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static Mono<Context> subscriberContext() {
/*  836 */     return onAssembly(MonoCurrentContext.INSTANCE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T, D> Mono<T> using(Callable<? extends D> resourceSupplier, Function<? super D, ? extends Mono<? extends T>> sourceSupplier, Consumer<? super D> resourceCleanup, boolean eager) {
/*  867 */     return onAssembly(new MonoUsing<>(resourceSupplier, sourceSupplier, resourceCleanup, eager));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T, D> Mono<T> using(Callable<? extends D> resourceSupplier, Function<? super D, ? extends Mono<? extends T>> sourceSupplier, Consumer<? super D> resourceCleanup) {
/*  893 */     return using(resourceSupplier, sourceSupplier, resourceCleanup, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T, D> Mono<T> usingWhen(Publisher<D> resourceSupplier, Function<? super D, ? extends Mono<? extends T>> resourceClosure, Function<? super D, ? extends Publisher<?>> asyncCleanup) {
/*  943 */     return usingWhen(resourceSupplier, resourceClosure, asyncCleanup, (res, error) -> (Publisher)asyncCleanup.apply(res), asyncCleanup);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T, D> Mono<T> usingWhen(Publisher<D> resourceSupplier, Function<? super D, ? extends Mono<? extends T>> resourceClosure, Function<? super D, ? extends Publisher<?>> asyncComplete, BiFunction<? super D, ? super Throwable, ? extends Publisher<?>> asyncError, Function<? super D, ? extends Publisher<?>> asyncCancel) {
/* 1006 */     return onAssembly(new MonoUsingWhen<>(resourceSupplier, resourceClosure, asyncComplete, asyncError, asyncCancel));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Mono<Void> when(Publisher<?>... sources) {
/* 1022 */     if (sources.length == 0) {
/* 1023 */       return empty();
/*      */     }
/* 1025 */     if (sources.length == 1) {
/* 1026 */       return empty(sources[0]);
/*      */     }
/* 1028 */     return onAssembly(new MonoWhen(false, sources));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Mono<Void> when(Iterable<? extends Publisher<?>> sources) {
/* 1047 */     return onAssembly(new MonoWhen(false, sources));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Mono<Void> whenDelayError(Iterable<? extends Publisher<?>> sources) {
/* 1065 */     return onAssembly(new MonoWhen(true, sources));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Mono<Void> whenDelayError(Publisher<?>... sources) {
/* 1081 */     if (sources.length == 0) {
/* 1082 */       return empty();
/*      */     }
/* 1084 */     if (sources.length == 1) {
/* 1085 */       return empty(sources[0]);
/*      */     }
/* 1087 */     return onAssembly(new MonoWhen(true, sources));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T1, T2> Mono<Tuple2<T1, T2>> zip(Mono<? extends T1> p1, Mono<? extends T2> p2) {
/* 1107 */     return zip(p1, p2, (BiFunction)Flux.tuple2Function());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T1, T2, O> Mono<O> zip(Mono<? extends T1> p1, Mono<? extends T2> p2, BiFunction<? super T1, ? super T2, ? extends O> combinator) {
/* 1131 */     return onAssembly(new MonoZip<>(false, (Publisher<? extends T1>)p1, (Publisher)p2, combinator));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T1, T2, T3> Mono<Tuple3<T1, T2, T3>> zip(Mono<? extends T1> p1, Mono<? extends T2> p2, Mono<? extends T3> p3) {
/* 1154 */     return onAssembly(new MonoZip<>(false, a -> Tuples.fromArray((Object[])a), (Publisher<?>[])new Publisher[] { (Publisher)p1, (Publisher)p2, (Publisher)p3 }));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T1, T2, T3, T4> Mono<Tuple4<T1, T2, T3, T4>> zip(Mono<? extends T1> p1, Mono<? extends T2> p2, Mono<? extends T3> p3, Mono<? extends T4> p4) {
/* 1182 */     return onAssembly(new MonoZip<>(false, a -> Tuples.fromArray((Object[])a), (Publisher<?>[])new Publisher[] { (Publisher)p1, (Publisher)p2, (Publisher)p3, (Publisher)p4 }));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T1, T2, T3, T4, T5> Mono<Tuple5<T1, T2, T3, T4, T5>> zip(Mono<? extends T1> p1, Mono<? extends T2> p2, Mono<? extends T3> p3, Mono<? extends T4> p4, Mono<? extends T5> p5) {
/* 1213 */     return onAssembly(new MonoZip<>(false, a -> Tuples.fromArray((Object[])a), (Publisher<?>[])new Publisher[] { (Publisher)p1, (Publisher)p2, (Publisher)p3, (Publisher)p4, (Publisher)p5 }));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T1, T2, T3, T4, T5, T6> Mono<Tuple6<T1, T2, T3, T4, T5, T6>> zip(Mono<? extends T1> p1, Mono<? extends T2> p2, Mono<? extends T3> p3, Mono<? extends T4> p4, Mono<? extends T5> p5, Mono<? extends T6> p6) {
/* 1247 */     return onAssembly(new MonoZip<>(false, a -> Tuples.fromArray((Object[])a), (Publisher<?>[])new Publisher[] { (Publisher)p1, (Publisher)p2, (Publisher)p3, (Publisher)p4, (Publisher)p5, (Publisher)p6 }));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T1, T2, T3, T4, T5, T6, T7> Mono<Tuple7<T1, T2, T3, T4, T5, T6, T7>> zip(Mono<? extends T1> p1, Mono<? extends T2> p2, Mono<? extends T3> p3, Mono<? extends T4> p4, Mono<? extends T5> p5, Mono<? extends T6> p6, Mono<? extends T7> p7) {
/* 1284 */     return onAssembly(new MonoZip<>(false, a -> Tuples.fromArray((Object[])a), (Publisher<?>[])new Publisher[] { (Publisher)p1, (Publisher)p2, (Publisher)p3, (Publisher)p4, (Publisher)p5, (Publisher)p6, (Publisher)p7 }));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T1, T2, T3, T4, T5, T6, T7, T8> Mono<Tuple8<T1, T2, T3, T4, T5, T6, T7, T8>> zip(Mono<? extends T1> p1, Mono<? extends T2> p2, Mono<? extends T3> p3, Mono<? extends T4> p4, Mono<? extends T5> p5, Mono<? extends T6> p6, Mono<? extends T7> p7, Mono<? extends T8> p8) {
/* 1324 */     return onAssembly(new MonoZip<>(false, a -> Tuples.fromArray((Object[])a), (Publisher<?>[])new Publisher[] { (Publisher)p1, (Publisher)p2, (Publisher)p3, (Publisher)p4, (Publisher)p5, (Publisher)p6, (Publisher)p7, (Publisher)p8 }));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <R> Mono<R> zip(Iterable<? extends Mono<?>> monos, Function<? super Object[], ? extends R> combinator) {
/* 1345 */     return onAssembly(new MonoZip<>(false, combinator, (Iterable)monos));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <R> Mono<R> zip(Function<? super Object[], ? extends R> combinator, Mono<?>... monos) {
/* 1364 */     if (monos.length == 0) {
/* 1365 */       return empty();
/*      */     }
/* 1367 */     if (monos.length == 1) {
/* 1368 */       return monos[0].map(d -> combinator.apply(new Object[] { d }));
/*      */     }
/* 1370 */     return onAssembly(new MonoZip<>(false, combinator, (Publisher<?>[])monos));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T1, T2> Mono<Tuple2<T1, T2>> zipDelayError(Mono<? extends T1> p1, Mono<? extends T2> p2) {
/* 1392 */     return onAssembly(new MonoZip<>(true, a -> Tuples.fromArray((Object[])a), (Publisher<?>[])new Publisher[] { (Publisher)p1, (Publisher)p2 }));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T1, T2, T3> Mono<Tuple3<T1, T2, T3>> zipDelayError(Mono<? extends T1> p1, Mono<? extends T2> p2, Mono<? extends T3> p3) {
/* 1416 */     return onAssembly(new MonoZip<>(true, a -> Tuples.fromArray((Object[])a), (Publisher<?>[])new Publisher[] { (Publisher)p1, (Publisher)p2, (Publisher)p3 }));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T1, T2, T3, T4> Mono<Tuple4<T1, T2, T3, T4>> zipDelayError(Mono<? extends T1> p1, Mono<? extends T2> p2, Mono<? extends T3> p3, Mono<? extends T4> p4) {
/* 1445 */     return onAssembly(new MonoZip<>(true, a -> Tuples.fromArray((Object[])a), (Publisher<?>[])new Publisher[] { (Publisher)p1, (Publisher)p2, (Publisher)p3, (Publisher)p4 }));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T1, T2, T3, T4, T5> Mono<Tuple5<T1, T2, T3, T4, T5>> zipDelayError(Mono<? extends T1> p1, Mono<? extends T2> p2, Mono<? extends T3> p3, Mono<? extends T4> p4, Mono<? extends T5> p5) {
/* 1476 */     return onAssembly(new MonoZip<>(true, a -> Tuples.fromArray((Object[])a), (Publisher<?>[])new Publisher[] { (Publisher)p1, (Publisher)p2, (Publisher)p3, (Publisher)p4, (Publisher)p5 }));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T1, T2, T3, T4, T5, T6> Mono<Tuple6<T1, T2, T3, T4, T5, T6>> zipDelayError(Mono<? extends T1> p1, Mono<? extends T2> p2, Mono<? extends T3> p3, Mono<? extends T4> p4, Mono<? extends T5> p5, Mono<? extends T6> p6) {
/* 1511 */     return onAssembly(new MonoZip<>(true, a -> Tuples.fromArray((Object[])a), (Publisher<?>[])new Publisher[] { (Publisher)p1, (Publisher)p2, (Publisher)p3, (Publisher)p4, (Publisher)p5, (Publisher)p6 }));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T1, T2, T3, T4, T5, T6, T7> Mono<Tuple7<T1, T2, T3, T4, T5, T6, T7>> zipDelayError(Mono<? extends T1> p1, Mono<? extends T2> p2, Mono<? extends T3> p3, Mono<? extends T4> p4, Mono<? extends T5> p5, Mono<? extends T6> p6, Mono<? extends T7> p7) {
/* 1549 */     return onAssembly(new MonoZip<>(true, a -> Tuples.fromArray((Object[])a), (Publisher<?>[])new Publisher[] { (Publisher)p1, (Publisher)p2, (Publisher)p3, (Publisher)p4, (Publisher)p5, (Publisher)p6, (Publisher)p7 }));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T1, T2, T3, T4, T5, T6, T7, T8> Mono<Tuple8<T1, T2, T3, T4, T5, T6, T7, T8>> zipDelayError(Mono<? extends T1> p1, Mono<? extends T2> p2, Mono<? extends T3> p3, Mono<? extends T4> p4, Mono<? extends T5> p5, Mono<? extends T6> p6, Mono<? extends T7> p7, Mono<? extends T8> p8) {
/* 1590 */     return onAssembly(new MonoZip<>(true, a -> Tuples.fromArray((Object[])a), (Publisher<?>[])new Publisher[] { (Publisher)p1, (Publisher)p2, (Publisher)p3, (Publisher)p4, (Publisher)p5, (Publisher)p6, (Publisher)p7, (Publisher)p8 }));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <R> Mono<R> zipDelayError(Iterable<? extends Mono<?>> monos, Function<? super Object[], ? extends R> combinator) {
/* 1611 */     return onAssembly(new MonoZip<>(true, combinator, (Iterable)monos));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <R> Mono<R> zipDelayError(Function<? super Object[], ? extends R> combinator, Mono<?>... monos) {
/* 1634 */     if (monos.length == 0) {
/* 1635 */       return empty();
/*      */     }
/* 1637 */     if (monos.length == 1) {
/* 1638 */       return monos[0].map(d -> combinator.apply(new Object[] { d }));
/*      */     }
/* 1640 */     return onAssembly(new MonoZip<>(true, combinator, (Publisher<?>[])monos));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <P> P as(Function<? super Mono<T>, P> transformer) {
/* 1662 */     return transformer.apply(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<Void> and(Publisher<?> other) {
/* 1678 */     if (this instanceof MonoWhen) {
/* 1679 */       MonoWhen o = (MonoWhen)this;
/* 1680 */       Mono<Void> result = o.whenAdditionalSource(other);
/* 1681 */       if (result != null) {
/* 1682 */         return result;
/*      */       }
/*      */     } 
/*      */     
/* 1686 */     return when((Publisher<?>[])new Publisher[] { (Publisher)this, other });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public T block() {
/* 1705 */     BlockingMonoSubscriber<T> subscriber = new BlockingMonoSubscriber<>();
/* 1706 */     subscribe((Subscriber<? super T>)subscriber);
/* 1707 */     return subscriber.blockingGet();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public T block(Duration timeout) {
/* 1729 */     BlockingMonoSubscriber<T> subscriber = new BlockingMonoSubscriber<>();
/* 1730 */     subscribe((Subscriber<? super T>)subscriber);
/* 1731 */     return subscriber.blockingGet(timeout.toNanos(), TimeUnit.NANOSECONDS);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Optional<T> blockOptional() {
/* 1750 */     BlockingOptionalMonoSubscriber<T> subscriber = new BlockingOptionalMonoSubscriber<>();
/* 1751 */     subscribe((Subscriber<? super T>)subscriber);
/* 1752 */     return subscriber.blockingGet();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Optional<T> blockOptional(Duration timeout) {
/* 1775 */     BlockingOptionalMonoSubscriber<T> subscriber = new BlockingOptionalMonoSubscriber<>();
/* 1776 */     subscribe((Subscriber<? super T>)subscriber);
/* 1777 */     return subscriber.blockingGet(timeout.toNanos(), TimeUnit.NANOSECONDS);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <E> Mono<E> cast(Class<E> clazz) {
/* 1792 */     Objects.requireNonNull(clazz, "clazz");
/* 1793 */     return map(clazz::cast);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> cache() {
/* 1811 */     return onAssembly(new MonoCacheTime<>(this));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> cache(Duration ttl) {
/* 1831 */     return cache(ttl, Schedulers.parallel());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> cache(Duration ttl, Scheduler timer) {
/* 1854 */     return onAssembly(new MonoCacheTime<>(this, ttl, timer));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> cache(Function<? super T, Duration> ttlForValue, Function<Throwable, Duration> ttlForError, Supplier<Duration> ttlForEmpty) {
/* 1890 */     return cache(ttlForValue, ttlForError, ttlForEmpty, Schedulers.parallel());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> cache(Function<? super T, Duration> ttlForValue, Function<Throwable, Duration> ttlForError, Supplier<Duration> ttlForEmpty, Scheduler timer) {
/* 1928 */     return onAssembly(new MonoCacheTime<>(this, ttlForValue, ttlForError, ttlForEmpty, timer));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> cacheInvalidateIf(Predicate<? super T> invalidationPredicate) {
/* 2016 */     return onAssembly(new MonoCacheInvalidateIf<>(this, invalidationPredicate));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> cacheInvalidateWhen(Function<? super T, Mono<Void>> invalidationTriggerGenerator) {
/* 2078 */     return onAssembly(new MonoCacheInvalidateWhen<>(this, invalidationTriggerGenerator, null));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> cacheInvalidateWhen(Function<? super T, Mono<Void>> invalidationTriggerGenerator, Consumer<? super T> onInvalidate) {
/* 2142 */     return onAssembly(new MonoCacheInvalidateWhen<>(this, invalidationTriggerGenerator, onInvalidate));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> cancelOn(Scheduler scheduler) {
/* 2158 */     return onAssembly(new MonoCancelOn<>(this, scheduler));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> checkpoint() {
/* 2177 */     return checkpoint(null, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> checkpoint(String description) {
/* 2202 */     return checkpoint(Objects.<String>requireNonNull(description), false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> checkpoint(@Nullable String description, boolean forceStackTrace) {
/*      */     FluxOnAssembly.AssemblySnapshot stacktrace;
/* 2238 */     if (!forceStackTrace) {
/* 2239 */       stacktrace = new FluxOnAssembly.CheckpointLightSnapshot(description);
/*      */     } else {
/*      */       
/* 2242 */       stacktrace = new FluxOnAssembly.CheckpointHeavySnapshot(description, Traces.callSiteSupplierFactory.get());
/*      */     } 
/*      */     
/* 2245 */     return new MonoOnAssembly<>(this, stacktrace);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Flux<T> concatWith(Publisher<? extends T> other) {
/* 2259 */     return Flux.concat((Publisher<? extends T>[])new Publisher[] { (Publisher)this, other });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> contextWrite(ContextView contextToAppend) {
/* 2281 */     return contextWrite(c -> c.putAll(contextToAppend));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> contextWrite(Function<Context, Context> contextModifier) {
/* 2305 */     return onAssembly(new MonoContextWrite<>(this, contextModifier));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> defaultIfEmpty(T defaultV) {
/* 2321 */     if (this instanceof Fuseable.ScalarCallable) {
/*      */       try {
/* 2323 */         T v = block();
/* 2324 */         if (v == null) {
/* 2325 */           return just(defaultV);
/*      */         }
/*      */       }
/* 2328 */       catch (Throwable throwable) {}
/*      */ 
/*      */       
/* 2331 */       return this;
/*      */     } 
/* 2333 */     return onAssembly(new MonoDefaultIfEmpty<>(this, defaultV));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> delayElement(Duration delay) {
/* 2352 */     return delayElement(delay, Schedulers.parallel());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> delayElement(Duration delay, Scheduler timer) {
/* 2372 */     return onAssembly(new MonoDelayElement<>(this, delay.toNanos(), TimeUnit.NANOSECONDS, timer));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> delayUntil(Function<? super T, ? extends Publisher<?>> triggerProvider) {
/* 2396 */     Objects.requireNonNull(triggerProvider, "triggerProvider required");
/* 2397 */     if (this instanceof MonoDelayUntil) {
/* 2398 */       return ((MonoDelayUntil<T>)this).copyWithNewTriggerGenerator(false, triggerProvider);
/*      */     }
/* 2400 */     return onAssembly(new MonoDelayUntil<>(this, triggerProvider));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> delaySubscription(Duration delay) {
/* 2416 */     return delaySubscription(delay, Schedulers.parallel());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> delaySubscription(Duration delay, Scheduler timer) {
/* 2433 */     return delaySubscription((Publisher<Long>)delay(delay, timer));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <U> Mono<T> delaySubscription(Publisher<U> subscriptionDelay) {
/* 2451 */     return onAssembly(new MonoDelaySubscription<>(this, subscriptionDelay));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <X> Mono<X> dematerialize() {
/* 2470 */     Mono<T> mono = this;
/* 2471 */     return onAssembly(new MonoDematerialize<>((Mono)mono));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public final Mono<T> doAfterSuccessOrError(BiConsumer<? super T, Throwable> afterSuccessOrError) {
/* 2495 */     return doOnTerminalSignal(this, null, null, afterSuccessOrError);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> doAfterTerminate(Runnable afterTerminate) {
/* 2511 */     Objects.requireNonNull(afterTerminate, "afterTerminate");
/* 2512 */     return onAssembly(new MonoPeekTerminal<>(this, null, null, (s, e) -> afterTerminate.run()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> doFirst(Runnable onFirst) {
/* 2548 */     Objects.requireNonNull(onFirst, "onFirst");
/* 2549 */     if (this instanceof Fuseable) {
/* 2550 */       return onAssembly(new MonoDoFirstFuseable<>(this, onFirst));
/*      */     }
/* 2552 */     return onAssembly(new MonoDoFirst<>(this, onFirst));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> doFinally(Consumer<SignalType> onFinally) {
/* 2575 */     Objects.requireNonNull(onFinally, "onFinally");
/* 2576 */     return onAssembly(new MonoDoFinally<>(this, onFinally));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> doOnCancel(Runnable onCancel) {
/* 2592 */     Objects.requireNonNull(onCancel, "onCancel");
/* 2593 */     return doOnSignal(this, null, null, null, onCancel);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <R> Mono<T> doOnDiscard(Class<R> type, Consumer<? super R> discardHook) {
/* 2621 */     return subscriberContext(Operators.discardLocalAdapter(type, discardHook));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> doOnNext(Consumer<? super T> onNext) {
/* 2638 */     Objects.requireNonNull(onNext, "onNext");
/* 2639 */     return doOnSignal(this, null, onNext, null, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> doOnSuccess(Consumer<? super T> onSuccess) {
/* 2663 */     Objects.requireNonNull(onSuccess, "onSuccess");
/* 2664 */     return doOnTerminalSignal(this, onSuccess, null, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> doOnEach(Consumer<? super Signal<T>> signalConsumer) {
/* 2689 */     Objects.requireNonNull(signalConsumer, "signalConsumer");
/* 2690 */     if (this instanceof Fuseable) {
/* 2691 */       return onAssembly(new MonoDoOnEachFuseable<>(this, signalConsumer));
/*      */     }
/* 2693 */     return onAssembly(new MonoDoOnEach<>(this, signalConsumer));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> doOnError(Consumer<? super Throwable> onError) {
/* 2711 */     Objects.requireNonNull(onError, "onError");
/* 2712 */     return doOnTerminalSignal(this, null, onError, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <E extends Throwable> Mono<T> doOnError(Class<E> exceptionType, Consumer<? super E> onError) {
/* 2733 */     Objects.requireNonNull(exceptionType, "type");
/* 2734 */     Objects.requireNonNull(onError, "onError");
/* 2735 */     return doOnTerminalSignal(this, null, error -> { if (exceptionType.isInstance(error)) onError.accept(exceptionType.cast(error));  }null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> doOnError(Predicate<? super Throwable> predicate, Consumer<? super Throwable> onError) {
/* 2758 */     Objects.requireNonNull(predicate, "predicate");
/* 2759 */     Objects.requireNonNull(onError, "onError");
/* 2760 */     return doOnTerminalSignal(this, null, error -> { if (predicate.test(error)) onError.accept(error);  }null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> doOnRequest(LongConsumer consumer) {
/* 2783 */     Objects.requireNonNull(consumer, "consumer");
/* 2784 */     return doOnSignal(this, null, null, consumer, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> doOnSubscribe(Consumer<? super Subscription> onSubscribe) {
/* 2807 */     Objects.requireNonNull(onSubscribe, "onSubscribe");
/* 2808 */     return doOnSignal(this, onSubscribe, null, null, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public final Mono<T> doOnSuccessOrError(BiConsumer<? super T, Throwable> onSuccessOrError) {
/* 2833 */     Objects.requireNonNull(onSuccessOrError, "onSuccessOrError");
/* 2834 */     return doOnTerminalSignal(this, v -> onSuccessOrError.accept(v, null), e -> onSuccessOrError.accept(null, e), null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> doOnTerminate(Runnable onTerminate) {
/* 2853 */     Objects.requireNonNull(onTerminate, "onTerminate");
/* 2854 */     return doOnTerminalSignal(this, ignoreValue -> onTerminate.run(), ignoreError -> onTerminate.run(), null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<Tuple2<Long, T>> elapsed() {
/* 2869 */     return elapsed(Schedulers.parallel());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<Tuple2<Long, T>> elapsed(Scheduler scheduler) {
/* 2885 */     Objects.requireNonNull(scheduler, "scheduler");
/* 2886 */     return onAssembly(new MonoElapsed<>(this, scheduler));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Flux<T> expandDeep(Function<? super T, ? extends Publisher<? extends T>> expander, int capacityHint) {
/* 2926 */     return Flux.onAssembly(new MonoExpand<>(this, expander, false, capacityHint));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Flux<T> expandDeep(Function<? super T, ? extends Publisher<? extends T>> expander) {
/* 2963 */     return expandDeep(expander, Queues.SMALL_BUFFER_SIZE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Flux<T> expand(Function<? super T, ? extends Publisher<? extends T>> expander, int capacityHint) {
/* 3003 */     return Flux.onAssembly(new MonoExpand<>(this, expander, true, capacityHint));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Flux<T> expand(Function<? super T, ? extends Publisher<? extends T>> expander) {
/* 3040 */     return expand(expander, Queues.SMALL_BUFFER_SIZE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> filter(Predicate<? super T> tester) {
/* 3058 */     if (this instanceof Fuseable) {
/* 3059 */       return onAssembly(new MonoFilterFuseable<>(this, tester));
/*      */     }
/* 3061 */     return onAssembly(new MonoFilter<>(this, tester));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> filterWhen(Function<? super T, ? extends Publisher<Boolean>> asyncPredicate) {
/* 3085 */     return onAssembly(new MonoFilterWhen<>(this, asyncPredicate));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <R> Mono<R> flatMap(Function<? super T, ? extends Mono<? extends R>> transformer) {
/* 3102 */     return onAssembly(new MonoFlatMap<>(this, transformer));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <R> Flux<R> flatMapMany(Function<? super T, ? extends Publisher<? extends R>> mapper) {
/* 3119 */     return Flux.onAssembly(new MonoFlatMapMany<>(this, mapper));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <R> Flux<R> flatMapMany(Function<? super T, ? extends Publisher<? extends R>> mapperOnNext, Function<? super Throwable, ? extends Publisher<? extends R>> mapperOnError, Supplier<? extends Publisher<? extends R>> mapperOnComplete) {
/* 3141 */     return flux().flatMap(mapperOnNext, mapperOnError, mapperOnComplete);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <R> Flux<R> flatMapIterable(Function<? super T, ? extends Iterable<? extends R>> mapper) {
/* 3170 */     return Flux.onAssembly(new MonoFlattenIterable<>(this, mapper, 2147483647, 
/* 3171 */           Queues.one()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Flux<T> flux() {
/* 3180 */     if (this instanceof Callable && !(this instanceof Fuseable.ScalarCallable)) {
/* 3181 */       Callable<T> thiz = (Callable<T>)this;
/* 3182 */       return Flux.onAssembly(new FluxCallable<>(thiz));
/*      */     } 
/* 3184 */     return Flux.from((Publisher<? extends T>)this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<Boolean> hasElement() {
/* 3197 */     return onAssembly(new MonoHasElement<>(this));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <R> Mono<R> handle(BiConsumer<? super T, SynchronousSink<R>> handler) {
/* 3212 */     if (this instanceof Fuseable) {
/* 3213 */       return onAssembly(new MonoHandleFuseable<>(this, handler));
/*      */     }
/* 3215 */     return onAssembly(new MonoHandle<>(this, handler));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> hide() {
/* 3227 */     return onAssembly(new MonoHide<>(this));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> ignoreElement() {
/* 3242 */     return onAssembly(new MonoIgnoreElement<>(this));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> log() {
/* 3261 */     return log(null, Level.INFO, new SignalType[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> log(@Nullable String category) {
/* 3278 */     return log(category, Level.INFO, new SignalType[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> log(@Nullable String category, Level level, SignalType... options) {
/* 3304 */     return log(category, level, false, options);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> log(@Nullable String category, Level level, boolean showOperatorLine, SignalType... options) {
/* 3336 */     SignalLogger<T> log = new SignalLogger<>(this, category, level, showOperatorLine, options);
/*      */ 
/*      */     
/* 3339 */     if (this instanceof Fuseable) {
/* 3340 */       return onAssembly(new MonoLogFuseable<>(this, log));
/*      */     }
/* 3342 */     return onAssembly(new MonoLog<>(this, log));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> log(Logger logger) {
/* 3357 */     return log(logger, Level.INFO, false, new SignalType[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> log(Logger logger, Level level, boolean showOperatorLine, SignalType... options) {
/* 3384 */     SignalLogger<T> log = new SignalLogger<>(this, "IGNORED", level, showOperatorLine, s -> logger, options);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3389 */     if (this instanceof Fuseable) {
/* 3390 */       return onAssembly(new MonoLogFuseable<>(this, log));
/*      */     }
/* 3392 */     return onAssembly(new MonoLog<>(this, log));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <R> Mono<R> map(Function<? super T, ? extends R> mapper) {
/* 3407 */     if (this instanceof Fuseable) {
/* 3408 */       return onAssembly(new MonoMapFuseable<>(this, mapper));
/*      */     }
/* 3410 */     return onAssembly(new MonoMap<>(this, mapper));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <R> Mono<R> mapNotNull(Function<? super T, ? extends R> mapper) {
/* 3428 */     return handle((t, sink) -> {
/*      */           R r = mapper.apply(t);
/*      */           if (r != null) {
/*      */             sink.next(r);
/*      */           }
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<Signal<T>> materialize() {
/* 3449 */     return onAssembly(new MonoMaterialize<>(this));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Flux<T> mergeWith(Publisher<? extends T> other) {
/* 3464 */     return Flux.merge((Publisher<? extends T>[])new Publisher[] { (Publisher)this, other });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> metrics() {
/* 3489 */     if (!Metrics.isInstrumentationAvailable()) {
/* 3490 */       return this;
/*      */     }
/*      */     
/* 3493 */     if (this instanceof Fuseable) {
/* 3494 */       return onAssembly(new MonoMetricsFuseable<>(this));
/*      */     }
/* 3496 */     return onAssembly(new MonoMetrics<>(this));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> name(String name) {
/* 3513 */     return MonoName.createOrAppend(this, name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> or(Mono<? extends T> other) {
/* 3528 */     if (this instanceof MonoFirstWithSignal) {
/* 3529 */       MonoFirstWithSignal<T> a = (MonoFirstWithSignal<T>)this;
/* 3530 */       Mono<T> result = a.orAdditionalSource(other);
/* 3531 */       if (result != null) {
/* 3532 */         return result;
/*      */       }
/*      */     } 
/* 3535 */     return firstWithSignal((Mono<? extends T>[])new Mono[] { this, other });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <U> Mono<U> ofType(Class<U> clazz) {
/* 3551 */     Objects.requireNonNull(clazz, "clazz");
/* 3552 */     return filter(o -> clazz.isAssignableFrom(o.getClass())).cast(clazz);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> onErrorContinue(BiConsumer<Throwable, Object> errorConsumer) {
/* 3590 */     BiConsumer<Throwable, Object> genericConsumer = errorConsumer;
/* 3591 */     return subscriberContext(Context.of("reactor.onNextError.localStrategy", 
/*      */           
/* 3593 */           OnNextFailureStrategy.resume(genericConsumer)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <E extends Throwable> Mono<T> onErrorContinue(Class<E> type, BiConsumer<Throwable, Object> errorConsumer) {
/* 3634 */     return onErrorContinue(type::isInstance, errorConsumer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <E extends Throwable> Mono<T> onErrorContinue(Predicate<E> errorPredicate, BiConsumer<Throwable, Object> errorConsumer) {
/* 3679 */     Predicate<Throwable> genericPredicate = errorPredicate;
/* 3680 */     BiConsumer<Throwable, Object> genericErrorConsumer = errorConsumer;
/* 3681 */     return subscriberContext(Context.of("reactor.onNextError.localStrategy", 
/*      */           
/* 3683 */           OnNextFailureStrategy.resumeIf(genericPredicate, genericErrorConsumer)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> onErrorStop() {
/* 3698 */     return subscriberContext(Context.of("reactor.onNextError.localStrategy", 
/*      */           
/* 3700 */           OnNextFailureStrategy.stop()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> onErrorMap(Predicate<? super Throwable> predicate, Function<? super Throwable, ? extends Throwable> mapper) {
/* 3716 */     return onErrorResume(predicate, e -> error(mapper.apply(e)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> onErrorMap(Function<? super Throwable, ? extends Throwable> mapper) {
/* 3730 */     return onErrorResume(e -> error(mapper.apply(e)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <E extends Throwable> Mono<T> onErrorMap(Class<E> type, Function<? super E, ? extends Throwable> mapper) {
/* 3748 */     Function<Throwable, Throwable> handler = (Function)mapper;
/* 3749 */     return onErrorMap(type::isInstance, handler);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> onErrorResume(Function<? super Throwable, ? extends Mono<? extends T>> fallback) {
/* 3767 */     return onAssembly(new MonoOnErrorResume<>(this, fallback));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <E extends Throwable> Mono<T> onErrorResume(Class<E> type, Function<? super E, ? extends Mono<? extends T>> fallback) {
/* 3785 */     Objects.requireNonNull(type, "type");
/*      */     
/* 3787 */     Function<? super E, ? extends Mono<? extends T>> function = fallback;
/*      */     
/* 3789 */     return onErrorResume(type::isInstance, function);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> onErrorResume(Predicate<? super Throwable> predicate, Function<? super Throwable, ? extends Mono<? extends T>> fallback) {
/* 3805 */     Objects.requireNonNull(predicate, "predicate");
/* 3806 */     return onErrorResume(e -> predicate.test(e) ? fallback.apply(e) : error(e));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> onErrorReturn(T fallback) {
/* 3820 */     return onErrorResume(throwable -> just(fallback));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <E extends Throwable> Mono<T> onErrorReturn(Class<E> type, T fallbackValue) {
/* 3836 */     return onErrorResume(type, throwable -> just(fallbackValue));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> onErrorReturn(Predicate<? super Throwable> predicate, T fallbackValue) {
/* 3851 */     return onErrorResume(predicate, throwable -> just(fallbackValue));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> onTerminateDetach() {
/* 3863 */     return new MonoDetach<>(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <R> Mono<R> publish(Function<? super Mono<T>, ? extends Mono<? extends R>> transform) {
/* 3878 */     return onAssembly(new MonoPublishMulticast<>(this, transform));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> publishOn(Scheduler scheduler) {
/* 3901 */     if (this instanceof Callable) {
/* 3902 */       if (this instanceof Fuseable.ScalarCallable) {
/*      */         try {
/* 3904 */           T value = block();
/* 3905 */           return onAssembly(new MonoSubscribeOnValue<>(value, scheduler));
/*      */         }
/* 3907 */         catch (Throwable throwable) {}
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 3912 */       Callable<T> c = (Callable<T>)this;
/* 3913 */       return onAssembly(new MonoSubscribeOnCallable<>(c, scheduler));
/*      */     } 
/* 3915 */     return onAssembly(new MonoPublishOn<>(this, scheduler));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Flux<T> repeat() {
/* 3928 */     return repeat(Flux.ALWAYS_BOOLEAN_SUPPLIER);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Flux<T> repeat(BooleanSupplier predicate) {
/* 3943 */     return Flux.onAssembly(new MonoRepeatPredicate<>(this, predicate));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Flux<T> repeat(long numRepeat) {
/* 3958 */     if (numRepeat == 0L) {
/* 3959 */       return flux();
/*      */     }
/* 3961 */     return Flux.onAssembly(new MonoRepeat<>(this, numRepeat));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Flux<T> repeat(long numRepeat, BooleanSupplier predicate) {
/* 3978 */     if (numRepeat < 0L) {
/* 3979 */       throw new IllegalArgumentException("numRepeat >= 0 required");
/*      */     }
/* 3981 */     if (numRepeat == 0L) {
/* 3982 */       return flux();
/*      */     }
/* 3984 */     return Flux.defer(() -> repeat(Flux.countingBooleanSupplier(predicate, numRepeat)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Flux<T> repeatWhen(Function<Flux<Long>, ? extends Publisher<?>> repeatFactory) {
/* 4009 */     return Flux.onAssembly(new MonoRepeatWhen<>(this, repeatFactory));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> repeatWhenEmpty(Function<Flux<Long>, ? extends Publisher<?>> repeatFactory) {
/* 4029 */     return repeatWhenEmpty(2147483647, repeatFactory);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> repeatWhenEmpty(int maxRepeat, Function<Flux<Long>, ? extends Publisher<?>> repeatFactory) {
/* 4052 */     return defer(() -> repeatWhen(()).next());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> retry() {
/* 4073 */     return retry(Long.MAX_VALUE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> retry(long numRetries) {
/* 4089 */     return onAssembly(new MonoRetry<>(this, numRetries));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> retryWhen(Retry retrySpec) {
/* 4144 */     return onAssembly(new MonoRetryWhen<>(this, retrySpec));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> share() {
/* 4159 */     if (this instanceof Fuseable.ScalarCallable) {
/* 4160 */       return this;
/*      */     }
/*      */     
/* 4163 */     if (this instanceof NextProcessor && ((NextProcessor)this).isRefCounted) {
/* 4164 */       return this;
/*      */     }
/* 4166 */     return new NextProcessor<>(this, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> single() {
/* 4181 */     if (this instanceof Callable) {
/* 4182 */       if (this instanceof Fuseable.ScalarCallable) {
/*      */         T v;
/* 4184 */         Fuseable.ScalarCallable<T> scalarCallable = (Fuseable.ScalarCallable<T>)this;
/*      */ 
/*      */         
/*      */         try {
/* 4188 */           v = (T)scalarCallable.call();
/*      */         }
/* 4190 */         catch (Exception e) {
/* 4191 */           return error(Exceptions.unwrap(e));
/*      */         } 
/* 4193 */         if (v == null) {
/* 4194 */           return error(new NoSuchElementException("Source was a (constant) empty"));
/*      */         }
/* 4196 */         return just(v);
/*      */       } 
/*      */       
/* 4199 */       Callable<T> thiz = (Callable<T>)this;
/* 4200 */       return onAssembly(new MonoSingleCallable<>(thiz));
/*      */     } 
/* 4202 */     return onAssembly(new MonoSingleMono<>(this));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Disposable subscribe() {
/* 4217 */     if (this instanceof NextProcessor) {
/* 4218 */       NextProcessor<T> s = (NextProcessor<T>)this;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4223 */       if (s.source != null && !s.isRefCounted) {
/* 4224 */         s.subscribe(new LambdaMonoSubscriber<>(null, null, null, null, null));
/* 4225 */         s.connect();
/* 4226 */         return s;
/*      */       } 
/*      */     } 
/* 4229 */     return subscribeWith(new LambdaMonoSubscriber(null, null, null, null, null));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Disposable subscribe(Consumer<? super T> consumer) {
/* 4250 */     Objects.requireNonNull(consumer, "consumer");
/* 4251 */     return subscribe(consumer, null, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Disposable subscribe(@Nullable Consumer<? super T> consumer, Consumer<? super Throwable> errorConsumer) {
/* 4275 */     Objects.requireNonNull(errorConsumer, "errorConsumer");
/* 4276 */     return subscribe(consumer, errorConsumer, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Disposable subscribe(@Nullable Consumer<? super T> consumer, @Nullable Consumer<? super Throwable> errorConsumer, @Nullable Runnable completeConsumer) {
/* 4304 */     return subscribe(consumer, errorConsumer, completeConsumer, (Context)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Disposable subscribe(@Nullable Consumer<? super T> consumer, @Nullable Consumer<? super Throwable> errorConsumer, @Nullable Runnable completeConsumer, @Nullable Consumer<? super Subscription> subscriptionConsumer) {
/* 4337 */     return subscribeWith(new LambdaMonoSubscriber<>(consumer, errorConsumer, completeConsumer, subscriptionConsumer, null));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Disposable subscribe(@Nullable Consumer<? super T> consumer, @Nullable Consumer<? super Throwable> errorConsumer, @Nullable Runnable completeConsumer, @Nullable Context initialContext) {
/* 4368 */     return subscribeWith(new LambdaMonoSubscriber<>(consumer, errorConsumer, completeConsumer, null, initialContext));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void subscribe(Subscriber<? super T> actual) {
/* 4375 */     CorePublisher<T> publisher = Operators.onLastAssembly(this);
/* 4376 */     CoreSubscriber<? super T> subscriber = Operators.toCoreSubscriber(actual);
/*      */     
/*      */     try {
/* 4379 */       if (publisher instanceof OptimizableOperator) {
/* 4380 */         OptimizableOperator<T, T> operator = (OptimizableOperator)publisher;
/*      */         while (true) {
/* 4382 */           subscriber = operator.subscribeOrReturn(subscriber);
/* 4383 */           if (subscriber == null) {
/*      */             return;
/*      */           }
/*      */ 
/*      */           
/* 4388 */           OptimizableOperator<?, ? extends T> newSource = operator.nextOptimizableSource();
/* 4389 */           if (newSource == null) {
/* 4390 */             publisher = (CorePublisher)operator.source();
/*      */             break;
/*      */           } 
/* 4393 */           OptimizableOperator<?, ? extends T> optimizableOperator1 = newSource;
/*      */         } 
/*      */       } 
/*      */       
/* 4397 */       publisher.subscribe(subscriber);
/*      */     }
/* 4399 */     catch (Throwable e) {
/* 4400 */       Operators.reportThrowInSubscribe(subscriber, e);
/*      */       return;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public final Mono<T> subscriberContext(Context mergeContext) {
/* 4439 */     return subscriberContext(c -> c.putAll(mergeContext.readOnly()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public final Mono<T> subscriberContext(Function<Context, Context> doOnContext) {
/* 4463 */     return new MonoContextWrite<>(this, doOnContext);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> subscribeOn(Scheduler scheduler) {
/* 4484 */     if (this instanceof Callable) {
/* 4485 */       if (this instanceof Fuseable.ScalarCallable) {
/*      */         try {
/* 4487 */           T value = block();
/* 4488 */           return onAssembly(new MonoSubscribeOnValue<>(value, scheduler));
/*      */         }
/* 4490 */         catch (Throwable throwable) {}
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 4495 */       Callable<T> c = (Callable<T>)this;
/* 4496 */       return onAssembly(new MonoSubscribeOnCallable<>(c, scheduler));
/*      */     } 
/*      */     
/* 4499 */     return onAssembly(new MonoSubscribeOn<>(this, scheduler));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <E extends Subscriber<? super T>> E subscribeWith(E subscriber) {
/* 4512 */     subscribe((Subscriber<? super T>)subscriber);
/* 4513 */     return subscriber;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> switchIfEmpty(Mono<? extends T> alternate) {
/* 4528 */     return onAssembly(new MonoSwitchIfEmpty<>(this, alternate));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> tag(String key, String value) {
/* 4549 */     return MonoName.createOrAppend(this, key, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> take(Duration duration) {
/* 4566 */     return take(duration, Schedulers.parallel());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> take(Duration duration, Scheduler timer) {
/* 4585 */     return takeUntilOther((Publisher<?>)delay(duration, timer));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> takeUntilOther(Publisher<?> other) {
/* 4603 */     return onAssembly(new MonoTakeUntilOther<>(this, other));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<Void> then() {
/* 4618 */     return empty((Publisher<T>)this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <V> Mono<V> then(Mono<V> other) {
/* 4639 */     if (this instanceof MonoIgnoreThen) {
/* 4640 */       MonoIgnoreThen<T> a = (MonoIgnoreThen<T>)this;
/* 4641 */       return a.shift(other);
/*      */     } 
/* 4643 */     return onAssembly(new MonoIgnoreThen<>((Publisher<?>[])new Publisher[] { (Publisher)this }, other));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <V> Mono<V> thenReturn(V value) {
/* 4659 */     return then(just(value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<Void> thenEmpty(Publisher<Void> other) {
/* 4676 */     return then(fromDirect(other));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <V> Flux<V> thenMany(Publisher<V> other) {
/* 4698 */     Flux<V> concat = Flux.concat((Publisher<? extends V>[])new Publisher[] { (Publisher)ignoreElement(), other });
/* 4699 */     return Flux.onAssembly(concat);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<Timed<T>> timed() {
/* 4728 */     return timed(Schedulers.parallel());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<Timed<T>> timed(Scheduler clock) {
/* 4756 */     return onAssembly(new MonoTimed<>(this, clock));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> timeout(Duration timeout) {
/* 4771 */     return timeout(timeout, Schedulers.parallel());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> timeout(Duration timeout, Mono<? extends T> fallback) {
/* 4789 */     return timeout(timeout, fallback, Schedulers.parallel());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> timeout(Duration timeout, Scheduler timer) {
/* 4805 */     return timeout(timeout, null, timer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> timeout(Duration timeout, @Nullable Mono<? extends T> fallback, Scheduler timer) {
/* 4825 */     Mono<Long> _timer = delay(timeout, timer).onErrorReturn(Long.valueOf(0L));
/*      */     
/* 4827 */     if (fallback == null) {
/* 4828 */       return onAssembly(new MonoTimeout<>(this, (Publisher<Long>)_timer, timeout.toMillis() + "ms"));
/*      */     }
/* 4830 */     return onAssembly(new MonoTimeout<>(this, (Publisher<Long>)_timer, (Publisher<? extends T>)fallback));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <U> Mono<T> timeout(Publisher<U> firstTimeout) {
/* 4847 */     return onAssembly(new MonoTimeout<>(this, firstTimeout, "first signal from a Publisher"));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <U> Mono<T> timeout(Publisher<U> firstTimeout, Mono<? extends T> fallback) {
/* 4867 */     return onAssembly(new MonoTimeout<>(this, firstTimeout, (Publisher<? extends T>)fallback));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<Tuple2<Long, T>> timestamp() {
/* 4882 */     return timestamp(Schedulers.parallel());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<Tuple2<Long, T>> timestamp(Scheduler scheduler) {
/* 4903 */     Objects.requireNonNull(scheduler, "scheduler");
/* 4904 */     return map(d -> Tuples.of(Long.valueOf(scheduler.now(TimeUnit.MILLISECONDS)), d));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final CompletableFuture<T> toFuture() {
/* 4917 */     return subscribeWith(new MonoToCompletableFuture<>(false));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public final MonoProcessor<T> toProcessor() {
/* 4930 */     if (this instanceof MonoProcessor) {
/* 4931 */       return (MonoProcessor<T>)this;
/*      */     }
/*      */     
/* 4934 */     NextProcessor<T> result = new NextProcessor<>(this);
/* 4935 */     result.connect();
/* 4936 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <V> Mono<V> transform(Function<? super Mono<T>, ? extends Publisher<V>> transformer) {
/* 4962 */     if (Hooks.DETECT_CONTEXT_LOSS) {
/* 4963 */       transformer = (Function)new ContextTrackingFunctionWrapper<>((Function)transformer);
/*      */     }
/* 4965 */     return onAssembly(from(transformer.apply(this)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <V> Mono<V> transformDeferred(Function<? super Mono<T>, ? extends Publisher<V>> transformer) {
/* 4989 */     return defer(() -> Hooks.DETECT_CONTEXT_LOSS ? from((Publisher)(new ContextTrackingFunctionWrapper<>(transformer)).apply((Publisher<T>)this)) : from(transformer.apply(this)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <V> Mono<V> transformDeferredContextual(BiFunction<? super Mono<T>, ? super ContextView, ? extends Publisher<V>> transformer) {
/* 5023 */     return deferContextual(ctxView -> {
/*      */           if (Hooks.DETECT_CONTEXT_LOSS) {
/*      */             ContextTrackingFunctionWrapper<T, V> wrapper = new ContextTrackingFunctionWrapper<>((), transformer.toString());
/*      */             return wrap((Publisher<?>)wrapper.apply((Publisher<T>)this), true);
/*      */           } 
/*      */           return from(transformer.apply(this, ctxView));
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <T2> Mono<Tuple2<T, T2>> zipWhen(Function<T, Mono<? extends T2>> rightGenerator) {
/* 5048 */     return zipWhen(rightGenerator, Tuples::of);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <T2, O> Mono<O> zipWhen(Function<T, Mono<? extends T2>> rightGenerator, BiFunction<T, T2, O> combinator) {
/* 5068 */     Objects.requireNonNull(rightGenerator, "rightGenerator function is mandatory to get the right-hand side Mono");
/* 5069 */     Objects.requireNonNull(combinator, "combinator function is mandatory to combine results from both Monos");
/* 5070 */     return flatMap(t -> ((Mono)rightGenerator.apply(t)).map(()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <T2> Mono<Tuple2<T, T2>> zipWith(Mono<? extends T2> other) {
/* 5088 */     return zipWith(other, (BiFunction)Flux.tuple2Function());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <T2, O> Mono<O> zipWith(Mono<? extends T2> other, BiFunction<? super T, ? super T2, ? extends O> combinator) {
/* 5111 */     if (this instanceof MonoZip) {
/* 5112 */       MonoZip<T, O> o = (MonoZip)this;
/* 5113 */       Mono<O> result = o.zipAdditionalSource((Publisher)other, combinator);
/* 5114 */       if (result != null) {
/* 5115 */         return result;
/*      */       }
/*      */     } 
/*      */     
/* 5119 */     return zip(this, other, combinator);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static <T> Mono<T> onAssembly(Mono<T> source) {
/* 5135 */     Function<Publisher, Publisher> hook = Hooks.onEachOperatorHook;
/* 5136 */     if (hook != null) {
/* 5137 */       source = (Mono<T>)hook.apply(source);
/*      */     }
/* 5139 */     if (Hooks.GLOBAL_TRACE) {
/* 5140 */       FluxOnAssembly.AssemblySnapshot stacktrace = new FluxOnAssembly.AssemblySnapshot(null, Traces.callSiteSupplierFactory.get());
/* 5141 */       source = (Mono<T>)Hooks.addAssemblyInfo(source, stacktrace);
/*      */     } 
/* 5143 */     return source;
/*      */   }
/*      */ 
/*      */   
/*      */   public String toString() {
/* 5148 */     return getClass().getSimpleName();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static <T> Mono<Void> empty(Publisher<T> source) {
/* 5154 */     Mono<Void> then = ignoreElements((Publisher)source);
/* 5155 */     return then;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static <T> Mono<T> doOnSignal(Mono<T> source, @Nullable Consumer<? super Subscription> onSubscribe, @Nullable Consumer<? super T> onNext, @Nullable LongConsumer onRequest, @Nullable Runnable onCancel) {
/* 5163 */     if (source instanceof Fuseable) {
/* 5164 */       return onAssembly(new MonoPeekFuseable<>(source, onSubscribe, onNext, onRequest, onCancel));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5170 */     return onAssembly(new MonoPeek<>(source, onSubscribe, onNext, onRequest, onCancel));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static <T> Mono<T> doOnTerminalSignal(Mono<T> source, @Nullable Consumer<? super T> onSuccess, @Nullable Consumer<? super Throwable> onError, @Nullable BiConsumer<? super T, Throwable> onAfterTerminate) {
/* 5181 */     return onAssembly(new MonoPeekTerminal<>(source, onSuccess, onError, onAfterTerminate));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static <T> Mono<T> wrap(Publisher<T> source, boolean enforceMonoContract) {
/* 5199 */     if (source instanceof Mono) {
/* 5200 */       return (Mono<T>)source;
/*      */     }
/* 5202 */     if (source instanceof FluxSourceMono || source instanceof FluxSourceMonoFuseable) {
/*      */ 
/*      */       
/* 5205 */       Mono<T> extracted = ((FluxFromMonoOperator)source).source;
/* 5206 */       return extracted;
/*      */     } 
/*      */ 
/*      */     
/* 5210 */     if (enforceMonoContract) {
/* 5211 */       if (source instanceof Flux && source instanceof Callable) {
/* 5212 */         Callable<T> m = (Callable<T>)source;
/* 5213 */         return Flux.wrapToMono(m);
/*      */       } 
/* 5215 */       if (source instanceof Flux) {
/* 5216 */         return new MonoNext<>((Flux<? extends T>)source);
/*      */       }
/* 5218 */       return new MonoFromPublisher<>(source);
/*      */     } 
/*      */ 
/*      */     
/* 5222 */     if (source instanceof Flux && source instanceof Fuseable) {
/* 5223 */       return new MonoSourceFluxFuseable<>((Flux<? extends T>)source);
/*      */     }
/* 5225 */     if (source instanceof Flux) {
/* 5226 */       return new MonoSourceFlux<>((Flux<? extends T>)source);
/*      */     }
/* 5228 */     if (source instanceof Fuseable) {
/* 5229 */       return new MonoSourceFuseable<>(source);
/*      */     }
/* 5231 */     return new MonoSource<>(source);
/*      */   }
/*      */ 
/*      */   
/*      */   static <T> BiPredicate<? super T, ? super T> equalsBiPredicate() {
/* 5236 */     return EQUALS_BIPREDICATE;
/*      */   }
/* 5238 */   static final BiPredicate EQUALS_BIPREDICATE = Object::equals;
/*      */   
/*      */   public abstract void subscribe(CoreSubscriber<? super T> paramCoreSubscriber);
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\Mono.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */