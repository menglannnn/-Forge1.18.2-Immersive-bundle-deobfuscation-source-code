/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.time.Duration;
/*    */ import java.util.Objects;
/*    */ import org.reactivestreams.Subscriber;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Exceptions;
/*    */ import reactor.core.Fuseable;
/*    */ import reactor.core.Scannable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MonoError<T>
/*    */   extends Mono<T>
/*    */   implements Fuseable.ScalarCallable, SourceProducer<T>
/*    */ {
/*    */   final Throwable error;
/*    */   
/*    */   MonoError(Throwable error) {
/* 38 */     this.error = Objects.<Throwable>requireNonNull(error, "error");
/*    */   }
/*    */ 
/*    */   
/*    */   public T block(Duration m) {
/* 43 */     throw Exceptions.propagate(this.error);
/*    */   }
/*    */ 
/*    */   
/*    */   public T block() {
/* 48 */     throw Exceptions.propagate(this.error);
/*    */   }
/*    */ 
/*    */   
/*    */   public void subscribe(CoreSubscriber<? super T> actual) {
/* 53 */     Operators.error((Subscriber<?>)actual, this.error);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object call() throws Exception {
/* 58 */     if (this.error instanceof Exception) {
/* 59 */       throw (Exception)this.error;
/*    */     }
/* 61 */     throw Exceptions.propagate(this.error);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 66 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 67 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\MonoError.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */