/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.function.Predicate;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MonoAny<T>
/*     */   extends MonoFromFluxOperator<T, Boolean>
/*     */   implements Fuseable
/*     */ {
/*     */   final Predicate<? super T> predicate;
/*     */   
/*     */   MonoAny(Flux<? extends T> source, Predicate<? super T> predicate) {
/*  43 */     super(source);
/*  44 */     this.predicate = Objects.<Predicate<? super T>>requireNonNull(predicate, "predicate");
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super Boolean> actual) {
/*  49 */     return new AnySubscriber<>(actual, this.predicate);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  54 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  55 */     return super.scanUnsafe(key);
/*     */   }
/*     */   
/*     */   static final class AnySubscriber<T>
/*     */     extends Operators.MonoSubscriber<T, Boolean>
/*     */   {
/*     */     final Predicate<? super T> predicate;
/*     */     Subscription s;
/*     */     boolean done;
/*     */     
/*     */     AnySubscriber(CoreSubscriber<? super Boolean> actual, Predicate<? super T> predicate) {
/*  66 */       super(actual);
/*  67 */       this.predicate = predicate;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/*  73 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/*  74 */       if (key == Scannable.Attr.PARENT) return this.s; 
/*  75 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/*  77 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/*  82 */       this.s.cancel();
/*  83 */       super.cancel();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/*  88 */       if (Operators.validate(this.s, s)) {
/*  89 */         this.s = s;
/*     */         
/*  91 */         this.actual.onSubscribe(this);
/*     */         
/*  93 */         s.request(Long.MAX_VALUE);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/*     */       boolean b;
/* 100 */       if (this.done) {
/*     */         return;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 107 */         b = this.predicate.test(t);
/* 108 */       } catch (Throwable e) {
/* 109 */         this.done = true;
/* 110 */         this.actual.onError(Operators.onOperatorError(this.s, e, t, this.actual.currentContext()));
/*     */         return;
/*     */       } 
/* 113 */       if (b) {
/* 114 */         this.done = true;
/* 115 */         this.s.cancel();
/*     */         
/* 117 */         complete(Boolean.valueOf(true));
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 123 */       if (this.done) {
/* 124 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*     */         return;
/*     */       } 
/* 127 */       this.done = true;
/*     */       
/* 129 */       this.actual.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 134 */       if (this.done) {
/*     */         return;
/*     */       }
/* 137 */       this.done = true;
/* 138 */       complete(Boolean.valueOf(false));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\MonoAny.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */