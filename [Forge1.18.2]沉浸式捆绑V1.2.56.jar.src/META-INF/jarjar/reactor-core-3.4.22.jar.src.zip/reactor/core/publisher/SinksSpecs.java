/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.util.Queue;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.scheduler.Scheduler;
/*     */ import reactor.util.concurrent.Queues;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class SinksSpecs
/*     */ {
/*  33 */   static final Sinks.RootSpec UNSAFE_ROOT_SPEC = new UnsafeSpecImpl();
/*  34 */   static final DefaultSinksSpecs DEFAULT_SINKS = new DefaultSinksSpecs();
/*     */ 
/*     */   
/*     */   static abstract class AbstractSerializedSink
/*     */   {
/*     */     volatile int wip;
/*  40 */     static final AtomicIntegerFieldUpdater<AbstractSerializedSink> WIP = AtomicIntegerFieldUpdater.newUpdater(AbstractSerializedSink.class, "wip");
/*     */     
/*     */     volatile Thread lockedAt;
/*     */     
/*  44 */     static final AtomicReferenceFieldUpdater<AbstractSerializedSink, Thread> LOCKED_AT = AtomicReferenceFieldUpdater.newUpdater(AbstractSerializedSink.class, Thread.class, "lockedAt");
/*     */     
/*     */     boolean tryAcquire(Thread currentThread) {
/*  47 */       if (WIP.get(this) == 0 && WIP.compareAndSet(this, 0, 1)) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  53 */         LOCKED_AT.lazySet(this, currentThread);
/*     */       } else {
/*     */         
/*  56 */         if (LOCKED_AT.get(this) != currentThread) {
/*  57 */           return false;
/*     */         }
/*  59 */         WIP.incrementAndGet(this);
/*     */       } 
/*  61 */       return true;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class UnsafeSpecImpl
/*     */     implements Sinks.RootSpec, Sinks.ManySpec, Sinks.ManyWithUpstreamUnsafeSpec, Sinks.MulticastSpec, Sinks.MulticastReplaySpec
/*     */   {
/*  72 */     final Sinks.UnicastSpec unicastSpec = new SinksSpecs.UnicastSpecImpl(false);
/*     */ 
/*     */ 
/*     */     
/*     */     public <T> Sinks.Empty<T> empty() {
/*  77 */       return new SinkEmptyMulticast<>();
/*     */     }
/*     */ 
/*     */     
/*     */     public <T> Sinks.One<T> one() {
/*  82 */       return new SinkOneMulticast<>();
/*     */     }
/*     */ 
/*     */     
/*     */     public Sinks.ManySpec many() {
/*  87 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public Sinks.UnicastSpec unicast() {
/*  92 */       return this.unicastSpec;
/*     */     }
/*     */ 
/*     */     
/*     */     public Sinks.MulticastSpec multicast() {
/*  97 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public Sinks.MulticastReplaySpec replay() {
/* 102 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public Sinks.ManyWithUpstreamUnsafeSpec manyWithUpstream() {
/* 107 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public <T> Sinks.Many<T> onBackpressureBuffer() {
/* 112 */       return new EmitterProcessor<>(true, Queues.SMALL_BUFFER_SIZE);
/*     */     }
/*     */ 
/*     */     
/*     */     public <T> Sinks.Many<T> onBackpressureBuffer(int bufferSize) {
/* 117 */       return new EmitterProcessor<>(true, bufferSize);
/*     */     }
/*     */ 
/*     */     
/*     */     public <T> Sinks.Many<T> onBackpressureBuffer(int bufferSize, boolean autoCancel) {
/* 122 */       return new EmitterProcessor<>(autoCancel, bufferSize);
/*     */     }
/*     */ 
/*     */     
/*     */     public <T> Sinks.Many<T> directAllOrNothing() {
/* 127 */       return new SinkManyBestEffort<>(true);
/*     */     }
/*     */ 
/*     */     
/*     */     public <T> Sinks.Many<T> directBestEffort() {
/* 132 */       return new SinkManyBestEffort<>(false);
/*     */     }
/*     */ 
/*     */     
/*     */     public <T> Sinks.Many<T> all() {
/* 137 */       return ReplayProcessor.create();
/*     */     }
/*     */ 
/*     */     
/*     */     public <T> Sinks.Many<T> all(int batchSize) {
/* 142 */       return ReplayProcessor.create(batchSize);
/*     */     }
/*     */ 
/*     */     
/*     */     public <T> Sinks.Many<T> latest() {
/* 147 */       return ReplayProcessor.cacheLast();
/*     */     }
/*     */ 
/*     */     
/*     */     public <T> Sinks.Many<T> latestOrDefault(T value) {
/* 152 */       return ReplayProcessor.cacheLastOrDefault(value);
/*     */     }
/*     */ 
/*     */     
/*     */     public <T> Sinks.Many<T> limit(int historySize) {
/* 157 */       return ReplayProcessor.create(historySize);
/*     */     }
/*     */ 
/*     */     
/*     */     public <T> Sinks.Many<T> limit(Duration maxAge) {
/* 162 */       return ReplayProcessor.createTimeout(maxAge);
/*     */     }
/*     */ 
/*     */     
/*     */     public <T> Sinks.Many<T> limit(Duration maxAge, Scheduler scheduler) {
/* 167 */       return ReplayProcessor.createTimeout(maxAge, scheduler);
/*     */     }
/*     */ 
/*     */     
/*     */     public <T> Sinks.Many<T> limit(int historySize, Duration maxAge) {
/* 172 */       return ReplayProcessor.createSizeAndTimeout(historySize, maxAge);
/*     */     }
/*     */ 
/*     */     
/*     */     public <T> Sinks.Many<T> limit(int historySize, Duration maxAge, Scheduler scheduler) {
/* 177 */       return ReplayProcessor.createSizeAndTimeout(historySize, maxAge, scheduler);
/*     */     }
/*     */ 
/*     */     
/*     */     public <T> Sinks.ManyWithUpstream<T> multicastOnBackpressureBuffer() {
/* 182 */       return new EmitterProcessor<>(true, Queues.SMALL_BUFFER_SIZE);
/*     */     }
/*     */ 
/*     */     
/*     */     public <T> Sinks.ManyWithUpstream<T> multicastOnBackpressureBuffer(int bufferSize, boolean autoCancel) {
/* 187 */       return new EmitterProcessor<>(autoCancel, bufferSize);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class DefaultSinksSpecs
/*     */     implements Sinks.ManySpec, Sinks.MulticastSpec, Sinks.MulticastReplaySpec
/*     */   {
/* 198 */     final Sinks.UnicastSpec unicastSpec = new SinksSpecs.UnicastSpecImpl(true);
/*     */ 
/*     */     
/*     */     <T, EMPTY extends Sinks.Empty<T> & ContextHolder> Sinks.Empty<T> wrapEmpty(EMPTY original) {
/* 202 */       return new SinkEmptySerialized<>((Sinks.Empty<T>)original, (ContextHolder)original);
/*     */     }
/*     */     
/*     */     <T, ONE extends Sinks.One<T> & ContextHolder> Sinks.One<T> wrapOne(ONE original) {
/* 206 */       return new SinkOneSerialized<>((Sinks.One<T>)original, (ContextHolder)original);
/*     */     }
/*     */     
/*     */     <T, MANY extends Sinks.Many<T> & ContextHolder> Sinks.Many<T> wrapMany(MANY original) {
/* 210 */       return new SinkManySerialized<>((Sinks.Many<T>)original, (ContextHolder)original);
/*     */     }
/*     */     
/*     */     Sinks.ManySpec many() {
/* 214 */       return this;
/*     */     }
/*     */     
/*     */     <T> Sinks.Empty<T> empty() {
/* 218 */       return wrapEmpty(new SinkEmptyMulticast<>());
/*     */     }
/*     */     
/*     */     <T> Sinks.One<T> one() {
/* 222 */       return wrapOne(new SinkOneMulticast<>());
/*     */     }
/*     */ 
/*     */     
/*     */     public Sinks.UnicastSpec unicast() {
/* 227 */       return this.unicastSpec;
/*     */     }
/*     */ 
/*     */     
/*     */     public Sinks.MulticastSpec multicast() {
/* 232 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public Sinks.MulticastReplaySpec replay() {
/* 237 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public <T> Sinks.Many<T> onBackpressureBuffer() {
/* 243 */       EmitterProcessor<T> original = EmitterProcessor.create();
/* 244 */       return wrapMany(original);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public <T> Sinks.Many<T> onBackpressureBuffer(int bufferSize) {
/* 250 */       EmitterProcessor<T> original = EmitterProcessor.create(bufferSize);
/* 251 */       return wrapMany(original);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public <T> Sinks.Many<T> onBackpressureBuffer(int bufferSize, boolean autoCancel) {
/* 257 */       EmitterProcessor<T> original = EmitterProcessor.create(bufferSize, autoCancel);
/* 258 */       return wrapMany(original);
/*     */     }
/*     */ 
/*     */     
/*     */     public <T> Sinks.Many<T> directAllOrNothing() {
/* 263 */       SinkManyBestEffort<T> original = SinkManyBestEffort.createAllOrNothing();
/* 264 */       return wrapMany(original);
/*     */     }
/*     */ 
/*     */     
/*     */     public <T> Sinks.Many<T> directBestEffort() {
/* 269 */       SinkManyBestEffort<T> original = SinkManyBestEffort.createBestEffort();
/* 270 */       return wrapMany(original);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public <T> Sinks.Many<T> all() {
/* 277 */       ReplayProcessor<T> original = ReplayProcessor.create();
/* 278 */       return wrapMany(original);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public <T> Sinks.Many<T> all(int batchSize) {
/* 284 */       ReplayProcessor<T> original = ReplayProcessor.create(batchSize, true);
/* 285 */       return wrapMany(original);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public <T> Sinks.Many<T> latest() {
/* 291 */       ReplayProcessor<T> original = ReplayProcessor.cacheLast();
/* 292 */       return wrapMany(original);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public <T> Sinks.Many<T> latestOrDefault(T value) {
/* 298 */       ReplayProcessor<T> original = ReplayProcessor.cacheLastOrDefault(value);
/* 299 */       return wrapMany(original);
/*     */     }
/*     */ 
/*     */     
/*     */     public <T> Sinks.Many<T> limit(int historySize) {
/* 304 */       if (historySize <= 0) {
/* 305 */         throw new IllegalArgumentException("historySize must be > 0");
/*     */       }
/*     */       
/* 308 */       ReplayProcessor<T> original = ReplayProcessor.create(historySize);
/* 309 */       return wrapMany(original);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public <T> Sinks.Many<T> limit(Duration maxAge) {
/* 315 */       ReplayProcessor<T> original = ReplayProcessor.createTimeout(maxAge);
/* 316 */       return wrapMany(original);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public <T> Sinks.Many<T> limit(Duration maxAge, Scheduler scheduler) {
/* 322 */       ReplayProcessor<T> original = ReplayProcessor.createTimeout(maxAge, scheduler);
/* 323 */       return wrapMany(original);
/*     */     }
/*     */ 
/*     */     
/*     */     public <T> Sinks.Many<T> limit(int historySize, Duration maxAge) {
/* 328 */       if (historySize <= 0) {
/* 329 */         throw new IllegalArgumentException("historySize must be > 0");
/*     */       }
/*     */       
/* 332 */       ReplayProcessor<T> original = ReplayProcessor.createSizeAndTimeout(historySize, maxAge);
/* 333 */       return wrapMany(original);
/*     */     }
/*     */ 
/*     */     
/*     */     public <T> Sinks.Many<T> limit(int historySize, Duration maxAge, Scheduler scheduler) {
/* 338 */       if (historySize <= 0) {
/* 339 */         throw new IllegalArgumentException("historySize must be > 0");
/*     */       }
/*     */       
/* 342 */       ReplayProcessor<T> original = ReplayProcessor.createSizeAndTimeout(historySize, maxAge, scheduler);
/* 343 */       return wrapMany(original);
/*     */     }
/*     */   }
/*     */   
/*     */   static final class UnicastSpecImpl
/*     */     implements Sinks.UnicastSpec {
/*     */     final boolean serialized;
/*     */     
/*     */     UnicastSpecImpl(boolean serialized) {
/* 352 */       this.serialized = serialized;
/*     */     }
/*     */     
/*     */     <T, MANY extends Sinks.Many<T> & ContextHolder> Sinks.Many<T> wrapMany(MANY original) {
/* 356 */       if (this.serialized) {
/* 357 */         return new SinkManySerialized<>((Sinks.Many<T>)original, (ContextHolder)original);
/*     */       }
/* 359 */       return (Sinks.Many<T>)original;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public <T> Sinks.Many<T> onBackpressureBuffer() {
/* 365 */       UnicastProcessor<T> original = UnicastProcessor.create();
/* 366 */       return wrapMany(original);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public <T> Sinks.Many<T> onBackpressureBuffer(Queue<T> queue) {
/* 372 */       UnicastProcessor<T> original = UnicastProcessor.create(queue);
/* 373 */       return wrapMany(original);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public <T> Sinks.Many<T> onBackpressureBuffer(Queue<T> queue, Disposable endCallback) {
/* 379 */       UnicastProcessor<T> original = UnicastProcessor.create(queue, endCallback);
/* 380 */       return wrapMany(original);
/*     */     }
/*     */ 
/*     */     
/*     */     public <T> Sinks.Many<T> onBackpressureError() {
/* 385 */       UnicastManySinkNoBackpressure<T> original = UnicastManySinkNoBackpressure.create();
/* 386 */       return wrapMany(original);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\SinksSpecs.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */