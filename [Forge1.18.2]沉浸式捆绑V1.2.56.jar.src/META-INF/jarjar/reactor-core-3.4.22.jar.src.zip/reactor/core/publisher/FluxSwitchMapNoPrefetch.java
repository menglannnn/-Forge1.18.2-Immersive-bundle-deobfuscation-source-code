/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.StringJoiner;
/*     */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.function.Function;
/*     */ import java.util.stream.Stream;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxSwitchMapNoPrefetch<T, R>
/*     */   extends InternalFluxOperator<T, R>
/*     */ {
/*     */   final Function<? super T, ? extends Publisher<? extends R>> mapper;
/*     */   
/*     */   FluxSwitchMapNoPrefetch(Flux<? extends T> source, Function<? super T, ? extends Publisher<? extends R>> mapper) {
/*  49 */     super(source);
/*  50 */     this.mapper = Objects.<Function<? super T, ? extends Publisher<? extends R>>>requireNonNull(mapper, "mapper");
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPrefetch() {
/*  55 */     return Integer.MAX_VALUE;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super R> actual) {
/*  61 */     if (FluxFlatMap.trySubscribeScalarMap((Publisher<? extends T>)this.source, actual, this.mapper, false, false)) {
/*  62 */       return null;
/*     */     }
/*     */     
/*  65 */     return new SwitchMapMain<>(actual, this.mapper);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  70 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  71 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class SwitchMapMain<T, R>
/*     */     implements InnerOperator<T, R>
/*     */   {
/*     */     @Nullable
/*     */     final StateLogger logger;
/*     */     
/*     */     final Function<? super T, ? extends Publisher<? extends R>> mapper;
/*     */     
/*     */     final CoreSubscriber<? super R> actual;
/*     */     
/*     */     Subscription s;
/*     */     
/*     */     boolean done;
/*     */     
/*     */     FluxSwitchMapNoPrefetch.SwitchMapInner<T, R> inner;
/*     */     volatile Throwable throwable;
/*  91 */     static final AtomicReferenceFieldUpdater<SwitchMapMain, Throwable> THROWABLE = AtomicReferenceFieldUpdater.newUpdater(SwitchMapMain.class, Throwable.class, "throwable");
/*     */ 
/*     */     
/*     */     volatile long requested;
/*     */     
/*  96 */     static final AtomicLongFieldUpdater<SwitchMapMain> REQUESTED = AtomicLongFieldUpdater.newUpdater(SwitchMapMain.class, "requested");
/*     */ 
/*     */     
/*     */     volatile long state;
/*     */     
/* 101 */     static final AtomicLongFieldUpdater<SwitchMapMain> STATE = AtomicLongFieldUpdater.newUpdater(SwitchMapMain.class, "state");
/*     */ 
/*     */     
/*     */     SwitchMapMain(CoreSubscriber<? super R> actual, Function<? super T, ? extends Publisher<? extends R>> mapper) {
/* 105 */       this(actual, mapper, null);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     SwitchMapMain(CoreSubscriber<? super R> actual, Function<? super T, ? extends Publisher<? extends R>> mapper, @Nullable StateLogger logger) {
/* 111 */       this.actual = actual;
/* 112 */       this.mapper = mapper;
/* 113 */       this.logger = logger;
/*     */     }
/*     */ 
/*     */     
/*     */     public final CoreSubscriber<? super R> actual() {
/* 118 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 124 */       long state = this.state;
/* 125 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf((!this.done && state == FluxSwitchMapNoPrefetch.TERMINATED)); 
/* 126 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 127 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 128 */       if (key == Scannable.Attr.ERROR) return this.throwable; 
/* 129 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf(this.requested); 
/* 130 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 132 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public Stream<? extends Scannable> inners() {
/* 137 */       return Stream.of(this.inner);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 142 */       if (Operators.validate(this.s, s)) {
/* 143 */         this.s = s;
/*     */         
/* 145 */         this.actual.onSubscribe(this);
/*     */         
/* 147 */         s.request(Long.MAX_VALUE);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 153 */       if (this.done) {
/* 154 */         Operators.onNextDropped(t, this.actual.currentContext());
/*     */         
/*     */         return;
/*     */       } 
/* 158 */       FluxSwitchMapNoPrefetch.SwitchMapInner<T, R> si = this.inner;
/* 159 */       boolean hasInner = (si != null);
/*     */       
/* 161 */       if (!hasInner) {
/* 162 */         FluxSwitchMapNoPrefetch.SwitchMapInner<T, R> switchMapInner = new FluxSwitchMapNoPrefetch.SwitchMapInner<>(this, this.actual, 0, this.logger);
/* 163 */         this.inner = switchMapInner;
/* 164 */         subscribeInner(t, switchMapInner, 0);
/*     */         
/*     */         return;
/*     */       } 
/* 168 */       int nextIndex = si.index + 1;
/* 169 */       FluxSwitchMapNoPrefetch.SwitchMapInner<T, R> nsi = new FluxSwitchMapNoPrefetch.SwitchMapInner<>(this, this.actual, nextIndex, this.logger);
/*     */       
/* 171 */       this.inner = nsi;
/* 172 */       si.nextInner = nsi;
/* 173 */       si.nextElement = t;
/*     */       
/* 175 */       long state = FluxSwitchMapNoPrefetch.incrementIndex(this);
/* 176 */       if (state == FluxSwitchMapNoPrefetch.TERMINATED) {
/* 177 */         Operators.onDiscard(t, this.actual.currentContext());
/*     */         
/*     */         return;
/*     */       } 
/* 181 */       if (FluxSwitchMapNoPrefetch.isInnerSubscribed(state)) {
/* 182 */         si.cancelFromParent();
/*     */         
/* 184 */         if (!FluxSwitchMapNoPrefetch.isWip(state)) {
/* 185 */           long produced = si.produced;
/* 186 */           if (produced > 0L) {
/* 187 */             si.produced = 0L;
/* 188 */             if (this.requested != Long.MAX_VALUE) {
/* 189 */               si.requested = 0L;
/* 190 */               REQUESTED.addAndGet(this, -produced);
/*     */             } 
/*     */           } 
/* 193 */           subscribeInner(t, nsi, nextIndex);
/*     */         } 
/*     */       } 
/*     */     }
/*     */     void subscribeInner(T nextElement, FluxSwitchMapNoPrefetch.SwitchMapInner<T, R> nextInner, int nextIndex) {
/*     */       Publisher<? extends R> p;
/* 199 */       CoreSubscriber<? super R> actual = this.actual;
/* 200 */       Context context = actual.currentContext();
/*     */       
/* 202 */       while (nextInner.index != nextIndex) {
/* 203 */         Operators.onDiscard(nextElement, context);
/* 204 */         nextElement = nextInner.nextElement;
/* 205 */         nextInner = nextInner.nextInner;
/*     */       } 
/*     */ 
/*     */       
/*     */       try {
/* 210 */         p = Objects.<Publisher<? extends R>>requireNonNull(this.mapper.apply(nextElement), "The mapper returned a null publisher");
/*     */       
/*     */       }
/* 213 */       catch (Throwable e) {
/* 214 */         onError(Operators.onOperatorError(this.s, e, nextElement, context));
/*     */         
/*     */         return;
/*     */       } 
/* 218 */       p.subscribe((Subscriber)nextInner);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 223 */       if (this.done) {
/* 224 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*     */         
/*     */         return;
/*     */       } 
/* 228 */       this.done = true;
/*     */       
/* 230 */       if (!Exceptions.addThrowable(THROWABLE, this, t)) {
/* 231 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*     */         
/*     */         return;
/*     */       } 
/* 235 */       long state = FluxSwitchMapNoPrefetch.setTerminated(this);
/* 236 */       if (state == FluxSwitchMapNoPrefetch.TERMINATED) {
/*     */         return;
/*     */       }
/*     */       
/* 240 */       FluxSwitchMapNoPrefetch.SwitchMapInner<T, R> inner = this.inner;
/* 241 */       if (inner != null && FluxSwitchMapNoPrefetch.isInnerSubscribed(state)) {
/* 242 */         inner.cancelFromParent();
/*     */       }
/*     */ 
/*     */       
/* 246 */       this.actual.onError(Exceptions.terminate(THROWABLE, this));
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 251 */       if (this.done) {
/*     */         return;
/*     */       }
/*     */       
/* 255 */       this.done = true;
/*     */       
/* 257 */       long state = FluxSwitchMapNoPrefetch.setMainCompleted(this);
/* 258 */       if (state == FluxSwitchMapNoPrefetch.TERMINATED) {
/*     */         return;
/*     */       }
/*     */       
/* 262 */       FluxSwitchMapNoPrefetch.SwitchMapInner<T, R> inner = this.inner;
/* 263 */       if (inner == null || FluxSwitchMapNoPrefetch.hasInnerCompleted(state)) {
/* 264 */         this.actual.onComplete();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 270 */       if (Operators.validate(n)) {
/* 271 */         long previousRequested = Operators.addCap(REQUESTED, this, n);
/* 272 */         long state = FluxSwitchMapNoPrefetch.addRequest(this, previousRequested);
/*     */         
/* 274 */         if (state == FluxSwitchMapNoPrefetch.TERMINATED) {
/*     */           return;
/*     */         }
/*     */         
/* 278 */         if (FluxSwitchMapNoPrefetch.hasRequest(state) == 1 && FluxSwitchMapNoPrefetch.isInnerSubscribed(state) && !FluxSwitchMapNoPrefetch.hasInnerCompleted(state)) {
/* 279 */           FluxSwitchMapNoPrefetch.SwitchMapInner<T, R> inner = this.inner;
/* 280 */           if (inner.index == FluxSwitchMapNoPrefetch.index(state)) {
/* 281 */             inner.request(n);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 289 */       long state = FluxSwitchMapNoPrefetch.setTerminated(this);
/* 290 */       if (state == FluxSwitchMapNoPrefetch.TERMINATED) {
/*     */         return;
/*     */       }
/*     */       
/* 294 */       FluxSwitchMapNoPrefetch.SwitchMapInner<T, R> inner = this.inner;
/* 295 */       if (inner != null && FluxSwitchMapNoPrefetch.isInnerSubscribed(state) && !FluxSwitchMapNoPrefetch.hasInnerCompleted(state) && inner.index == FluxSwitchMapNoPrefetch.index(state)) {
/* 296 */         inner.cancelFromParent();
/*     */       }
/*     */       
/* 299 */       if (!FluxSwitchMapNoPrefetch.hasMainCompleted(state)) {
/* 300 */         this.s.cancel();
/*     */ 
/*     */         
/* 303 */         Throwable e = Exceptions.terminate(THROWABLE, this);
/* 304 */         if (e != null) {
/* 305 */           Operators.onErrorDropped(e, this.actual.currentContext());
/*     */         }
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class SwitchMapInner<T, R>
/*     */     implements InnerConsumer<R>
/*     */   {
/*     */     @Nullable
/*     */     final StateLogger logger;
/*     */     
/*     */     final FluxSwitchMapNoPrefetch.SwitchMapMain<T, R> parent;
/*     */     
/*     */     final CoreSubscriber<? super R> actual;
/*     */     final int index;
/*     */     Subscription s;
/*     */     long produced;
/*     */     long requested;
/*     */     boolean done;
/*     */     T nextElement;
/*     */     SwitchMapInner<T, R> nextInner;
/*     */     
/*     */     SwitchMapInner(FluxSwitchMapNoPrefetch.SwitchMapMain<T, R> parent, CoreSubscriber<? super R> actual, int index, @Nullable StateLogger logger) {
/* 330 */       this.parent = parent;
/* 331 */       this.actual = actual;
/* 332 */       this.index = index;
/* 333 */       this.logger = logger;
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/* 338 */       return this.parent.currentContext();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 344 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(isCancelledByParent()); 
/* 345 */       if (key == Scannable.Attr.PARENT) return this.parent; 
/* 346 */       if (key == Scannable.Attr.ACTUAL) return this.actual; 
/* 347 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 349 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 354 */       if (Operators.validate(this.s, s)) {
/* 355 */         this.s = s;
/*     */         
/* 357 */         int expectedIndex = this.index;
/* 358 */         FluxSwitchMapNoPrefetch.SwitchMapMain<T, R> parent = this.parent;
/* 359 */         long state = FluxSwitchMapNoPrefetch.setInnerSubscribed(parent, expectedIndex);
/*     */         
/* 361 */         if (state == FluxSwitchMapNoPrefetch.TERMINATED) {
/* 362 */           s.cancel();
/*     */           
/*     */           return;
/*     */         } 
/* 366 */         int actualIndex = FluxSwitchMapNoPrefetch.index(state);
/* 367 */         if (expectedIndex != actualIndex) {
/* 368 */           s.cancel();
/* 369 */           parent.subscribeInner(this.nextElement, this.nextInner, actualIndex);
/*     */           
/*     */           return;
/*     */         } 
/* 373 */         if (FluxSwitchMapNoPrefetch.hasRequest(state) > 0) {
/* 374 */           long requested = parent.requested;
/* 375 */           this.requested = requested;
/*     */           
/* 377 */           s.request(requested);
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(R t) {
/* 384 */       if (this.done) {
/* 385 */         Operators.onNextDropped(t, this.actual.currentContext());
/*     */         
/*     */         return;
/*     */       } 
/* 389 */       FluxSwitchMapNoPrefetch.SwitchMapMain<T, R> parent = this.parent;
/* 390 */       Subscription s = this.s;
/* 391 */       int expectedIndex = this.index;
/*     */       
/* 393 */       long requested = this.requested;
/* 394 */       long state = FluxSwitchMapNoPrefetch.setWip(parent, expectedIndex);
/*     */       
/* 396 */       if (state == FluxSwitchMapNoPrefetch.TERMINATED) {
/* 397 */         Operators.onDiscard(t, this.actual.currentContext());
/*     */         
/*     */         return;
/*     */       } 
/* 401 */       int actualIndex = FluxSwitchMapNoPrefetch.index(state);
/* 402 */       if (actualIndex != expectedIndex) {
/* 403 */         Operators.onDiscard(t, this.actual.currentContext());
/*     */         
/*     */         return;
/*     */       } 
/* 407 */       this.actual.onNext(t);
/*     */       
/* 409 */       long produced = 0L;
/* 410 */       boolean isDemandFulfilled = false;
/* 411 */       int expectedHasRequest = FluxSwitchMapNoPrefetch.hasRequest(state);
/*     */       
/* 413 */       if (requested != Long.MAX_VALUE) {
/* 414 */         produced = this.produced + 1L;
/* 415 */         this.produced = produced;
/*     */         
/* 417 */         if (expectedHasRequest > 1) {
/* 418 */           long actualRequested = parent.requested;
/* 419 */           long toRequestInAddition = actualRequested - requested;
/* 420 */           if (toRequestInAddition > 0L) {
/* 421 */             requested = actualRequested;
/* 422 */             this.requested = requested;
/*     */ 
/*     */ 
/*     */             
/* 426 */             this.produced = produced = 0L;
/* 427 */             s.request(Long.MAX_VALUE);
/*     */ 
/*     */             
/* 430 */             s.request(toRequestInAddition);
/*     */           } 
/*     */         } 
/*     */ 
/*     */         
/* 435 */         isDemandFulfilled = (produced == requested);
/* 436 */         if (isDemandFulfilled) {
/* 437 */           this.produced = 0L;
/* 438 */           requested = FluxSwitchMapNoPrefetch.SwitchMapMain.REQUESTED.addAndGet(parent, -produced);
/* 439 */           this.requested = requested;
/*     */           
/* 441 */           produced = 0L;
/* 442 */           isDemandFulfilled = (requested == 0L);
/* 443 */           if (!isDemandFulfilled) {
/* 444 */             s.request(requested);
/*     */           }
/*     */         } 
/*     */       } 
/*     */       
/*     */       while (true) {
/* 450 */         state = FluxSwitchMapNoPrefetch.unsetWip(parent, expectedIndex, isDemandFulfilled, expectedHasRequest);
/*     */         
/* 452 */         if (state == FluxSwitchMapNoPrefetch.TERMINATED) {
/*     */           return;
/*     */         }
/*     */         
/* 456 */         actualIndex = FluxSwitchMapNoPrefetch.index(state);
/* 457 */         if (expectedIndex != actualIndex) {
/* 458 */           if (produced > 0L) {
/* 459 */             this.produced = 0L;
/* 460 */             this.requested = 0L;
/*     */             
/* 462 */             FluxSwitchMapNoPrefetch.SwitchMapMain.REQUESTED.addAndGet(parent, -produced);
/*     */           } 
/* 464 */           parent.subscribeInner(this.nextElement, this.nextInner, actualIndex);
/*     */           
/*     */           return;
/*     */         } 
/* 468 */         int actualHasRequest = FluxSwitchMapNoPrefetch.hasRequest(state);
/* 469 */         if (isDemandFulfilled && expectedHasRequest < actualHasRequest) {
/* 470 */           expectedHasRequest = actualHasRequest;
/*     */           
/* 472 */           long currentRequest = parent.requested;
/* 473 */           long toRequestInAddition = currentRequest - requested;
/* 474 */           if (toRequestInAddition > 0L) {
/* 475 */             requested = currentRequest;
/* 476 */             this.requested = requested;
/*     */             
/* 478 */             isDemandFulfilled = false;
/* 479 */             s.request((requested == Long.MAX_VALUE) ? Long.MAX_VALUE : toRequestInAddition);
/*     */           } 
/*     */           continue;
/*     */         } 
/*     */         break;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 491 */       if (this.done) {
/* 492 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*     */         
/*     */         return;
/*     */       } 
/* 496 */       this.done = true;
/*     */       
/* 498 */       FluxSwitchMapNoPrefetch.SwitchMapMain<T, R> parent = this.parent;
/*     */ 
/*     */       
/* 501 */       if (!Exceptions.addThrowable(FluxSwitchMapNoPrefetch.SwitchMapMain.THROWABLE, parent, t)) {
/* 502 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*     */         
/*     */         return;
/*     */       } 
/* 506 */       long state = FluxSwitchMapNoPrefetch.setTerminated(parent);
/* 507 */       if (state == FluxSwitchMapNoPrefetch.TERMINATED) {
/*     */         return;
/*     */       }
/*     */       
/* 511 */       if (!FluxSwitchMapNoPrefetch.hasMainCompleted(state)) {
/* 512 */         parent.s.cancel();
/*     */       }
/*     */ 
/*     */       
/* 516 */       this.actual.onError(Exceptions.terminate(FluxSwitchMapNoPrefetch.SwitchMapMain.THROWABLE, parent));
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 521 */       if (this.done) {
/*     */         return;
/*     */       }
/*     */       
/* 525 */       this.done = true;
/*     */       
/* 527 */       FluxSwitchMapNoPrefetch.SwitchMapMain<T, R> parent = this.parent;
/* 528 */       int expectedIndex = this.index;
/*     */       
/* 530 */       long state = FluxSwitchMapNoPrefetch.setWip(parent, expectedIndex);
/* 531 */       if (state == FluxSwitchMapNoPrefetch.TERMINATED) {
/*     */         return;
/*     */       }
/*     */       
/* 535 */       int actualIndex = FluxSwitchMapNoPrefetch.index(state);
/* 536 */       if (actualIndex != expectedIndex) {
/*     */         return;
/*     */       }
/*     */       
/* 540 */       long produced = this.produced;
/* 541 */       if (produced > 0L) {
/* 542 */         this.produced = 0L;
/* 543 */         this.requested = 0L;
/* 544 */         FluxSwitchMapNoPrefetch.SwitchMapMain.REQUESTED.addAndGet(parent, -produced);
/*     */       } 
/*     */       
/* 547 */       if (FluxSwitchMapNoPrefetch.hasMainCompleted(state)) {
/* 548 */         this.actual.onComplete();
/*     */         
/*     */         return;
/*     */       } 
/* 552 */       state = FluxSwitchMapNoPrefetch.setInnerCompleted(parent);
/* 553 */       if (state == FluxSwitchMapNoPrefetch.TERMINATED) {
/*     */         return;
/*     */       }
/*     */       
/* 557 */       actualIndex = FluxSwitchMapNoPrefetch.index(state);
/* 558 */       if (expectedIndex != actualIndex) {
/* 559 */         parent.subscribeInner(this.nextElement, this.nextInner, actualIndex);
/* 560 */       } else if (FluxSwitchMapNoPrefetch.hasMainCompleted(state)) {
/* 561 */         this.actual.onComplete();
/*     */       } 
/*     */     }
/*     */     
/*     */     void request(long n) {
/* 566 */       long requested = this.requested;
/* 567 */       this.requested = Operators.addCap(requested, n);
/*     */       
/* 569 */       this.s.request(n);
/*     */     }
/*     */     
/*     */     boolean isCancelledByParent() {
/* 573 */       long state = this.parent.state;
/* 574 */       return ((this.index != FluxSwitchMapNoPrefetch.index(state) && !this.done) || (!this.parent.done && state == FluxSwitchMapNoPrefetch.TERMINATED));
/*     */     }
/*     */     
/*     */     void cancelFromParent() {
/* 578 */       this.s.cancel();
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 583 */       return (new StringJoiner(", ", SwitchMapInner.class
/* 584 */           .getSimpleName() + "[", "]"))
/* 585 */         .add("index=" + this.index)
/* 586 */         .toString();
/*     */     }
/*     */   }
/*     */   
/* 590 */   static int INDEX_OFFSET = 32;
/* 591 */   static int HAS_REQUEST_OFFSET = 4;
/* 592 */   static long TERMINATED = -1L;
/*     */   
/* 594 */   static long INNER_WIP_MASK = 1L;
/*     */   
/* 596 */   static long INNER_SUBSCRIBED_MASK = 2L;
/*     */   
/* 598 */   static long INNER_COMPLETED_MASK = 4L;
/*     */   
/* 600 */   static long COMPLETED_MASK = 8L;
/*     */   
/* 602 */   static long HAS_REQUEST_MASK = 4294967280L;
/*     */   
/* 604 */   static int MAX_HAS_REQUEST = 268435455;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static long setTerminated(SwitchMapMain<?, ?> instance) {
/*     */     while (true) {
/* 613 */       long state = instance.state;
/*     */ 
/*     */       
/* 616 */       if (state == TERMINATED) {
/* 617 */         return TERMINATED;
/*     */       }
/*     */       
/* 620 */       if (SwitchMapMain.STATE.compareAndSet(instance, state, TERMINATED)) {
/* 621 */         if (instance.logger != null) {
/* 622 */           instance.logger.log(instance.toString(), "std", state, TERMINATED);
/*     */         }
/* 624 */         return state;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static long setMainCompleted(SwitchMapMain<?, ?> instance) {
/*     */     while (true) {
/* 638 */       long state = instance.state;
/*     */ 
/*     */       
/* 641 */       if (state == TERMINATED) {
/* 642 */         return TERMINATED;
/*     */       }
/*     */       
/* 645 */       if ((state & COMPLETED_MASK) == COMPLETED_MASK) {
/* 646 */         return state;
/*     */       }
/*     */       
/* 649 */       long nextState = state | COMPLETED_MASK;
/* 650 */       if (SwitchMapMain.STATE.compareAndSet(instance, state, nextState)) {
/* 651 */         if (instance.logger != null) {
/* 652 */           instance.logger.log(instance.toString(), "smc", state, nextState);
/*     */         }
/* 654 */         return state;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static long addRequest(SwitchMapMain<?, ?> instance, long previousRequested) {
/*     */     while (true) {
/* 681 */       long state = instance.state;
/*     */ 
/*     */       
/* 684 */       if (state == TERMINATED) {
/* 685 */         return TERMINATED;
/*     */       }
/*     */       
/* 688 */       int hasRequest = hasRequest(state);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 693 */       if (hasRequest == 0 && previousRequested > 0L) {
/* 694 */         return state;
/*     */       }
/*     */       
/* 697 */       long nextState = state(index(state), 
/* 698 */           isWip(state), hasRequest + 1, 
/*     */           
/* 700 */           isInnerSubscribed(state), 
/* 701 */           hasMainCompleted(state), 
/* 702 */           hasInnerCompleted(state));
/* 703 */       if (SwitchMapMain.STATE.compareAndSet(instance, state, nextState)) {
/* 704 */         if (instance.logger != null) {
/* 705 */           instance.logger.log(instance.toString(), "adr", state, nextState);
/*     */         }
/* 707 */         return nextState;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static long incrementIndex(SwitchMapMain<?, ?> instance) {
/* 720 */     long state = instance.state;
/*     */ 
/*     */     
/* 723 */     if (state == TERMINATED) {
/* 724 */       return TERMINATED;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 729 */     int nextIndex = nextIndex(state);
/*     */     
/*     */     while (true) {
/* 732 */       long nextState = state(nextIndex, 
/* 733 */           isWip(state), 
/* 734 */           hasRequest(state), false, false, false);
/*     */ 
/*     */ 
/*     */       
/* 738 */       if (SwitchMapMain.STATE.compareAndSet(instance, state, nextState)) {
/* 739 */         if (instance.logger != null) {
/* 740 */           instance.logger.log(instance.toString(), "ini", state, nextState);
/*     */         }
/* 742 */         return state;
/*     */       } 
/*     */       
/* 745 */       state = instance.state;
/*     */ 
/*     */       
/* 748 */       if (state == TERMINATED) {
/* 749 */         return TERMINATED;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static long setInnerSubscribed(SwitchMapMain<?, ?> instance, int expectedIndex) {
/*     */     long state;
/*     */     long nextState;
/*     */     do {
/* 765 */       state = instance.state;
/*     */ 
/*     */       
/* 768 */       if (state == TERMINATED) {
/* 769 */         return TERMINATED;
/*     */       }
/*     */       
/* 772 */       int actualIndex = index(state);
/*     */       
/* 774 */       if (expectedIndex != actualIndex) {
/* 775 */         return state;
/*     */       }
/*     */       
/* 778 */       nextState = state(expectedIndex, false, 
/*     */           
/* 780 */           hasRequest(state), true, 
/*     */           
/* 782 */           hasMainCompleted(state), false);
/*     */     }
/* 784 */     while (!SwitchMapMain.STATE.compareAndSet(instance, state, nextState));
/*     */ 
/*     */     
/* 787 */     if (instance.logger != null) {
/* 788 */       instance.logger.log(instance.toString(), "sns", state, nextState);
/*     */     }
/*     */     
/* 791 */     return state;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static long setWip(SwitchMapMain<?, ?> instance, int expectedIndex) {
/*     */     while (true) {
/* 807 */       long state = instance.state;
/*     */ 
/*     */       
/* 810 */       if (state == TERMINATED) {
/* 811 */         return TERMINATED;
/*     */       }
/*     */       
/* 814 */       int actualIndex = index(state);
/*     */       
/* 816 */       if (expectedIndex != actualIndex) {
/* 817 */         return state;
/*     */       }
/*     */       
/* 820 */       long nextState = state(expectedIndex, true, 
/*     */           
/* 822 */           hasRequest(state), true, 
/*     */           
/* 824 */           hasMainCompleted(state), false);
/*     */       
/* 826 */       if (SwitchMapMain.STATE.compareAndSet(instance, state, nextState)) {
/* 827 */         if (instance.logger != null) {
/* 828 */           instance.logger.log(instance.toString(), "swp", state, nextState);
/*     */         }
/* 830 */         return state;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static long unsetWip(SwitchMapMain<?, ?> instance, int expectedIndex, boolean isDemandFulfilled, int expectedRequest) {
/*     */     while (true) {
/* 849 */       long state = instance.state;
/*     */ 
/*     */       
/* 852 */       if (state == TERMINATED) {
/* 853 */         return TERMINATED;
/*     */       }
/*     */       
/* 856 */       int actualIndex = index(state);
/* 857 */       int actualRequest = hasRequest(state);
/* 858 */       boolean sameIndex = (expectedIndex == actualIndex);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 863 */       if (isDemandFulfilled && expectedRequest < actualRequest && sameIndex) {
/* 864 */         return state;
/*     */       }
/*     */       
/* 867 */       long nextState = state(actualIndex, false, (isDemandFulfilled && expectedRequest == actualRequest) ? 0 : actualRequest, 
/*     */ 
/*     */ 
/*     */           
/* 871 */           isInnerSubscribed(state), 
/* 872 */           hasMainCompleted(state), false);
/*     */       
/* 874 */       if (SwitchMapMain.STATE.compareAndSet(instance, state, nextState)) {
/* 875 */         if (instance.logger != null) {
/* 876 */           instance.logger.log(instance.toString(), "uwp", state, nextState);
/*     */         }
/* 878 */         return state;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static long setInnerCompleted(SwitchMapMain<?, ?> instance) {
/*     */     while (true) {
/* 892 */       long state = instance.state;
/*     */ 
/*     */       
/* 895 */       if (state == TERMINATED) {
/* 896 */         return TERMINATED;
/*     */       }
/*     */       
/* 899 */       boolean isInnerSubscribed = isInnerSubscribed(state);
/* 900 */       long nextState = state(index(state), false, 
/*     */           
/* 902 */           hasRequest(state), isInnerSubscribed, 
/*     */           
/* 904 */           hasMainCompleted(state), isInnerSubscribed);
/*     */       
/* 906 */       if (SwitchMapMain.STATE.compareAndSet(instance, state, nextState)) {
/* 907 */         if (instance.logger != null) {
/* 908 */           instance.logger.log(instance.toString(), "sic", state, nextState);
/*     */         }
/* 910 */         return state;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static long state(int index, boolean wip, int hasRequest, boolean innerSubscribed, boolean mainCompleted, boolean innerCompleted) {
/* 922 */     return index << INDEX_OFFSET | (wip ? INNER_WIP_MASK : 0L) | 
/*     */       
/* 924 */       Math.max(Math.min(hasRequest, MAX_HAS_REQUEST), 0) << HAS_REQUEST_OFFSET | (innerSubscribed ? INNER_SUBSCRIBED_MASK : 0L) | (mainCompleted ? COMPLETED_MASK : 0L) | (innerCompleted ? INNER_COMPLETED_MASK : 0L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean isInnerSubscribed(long state) {
/* 931 */     return ((state & INNER_SUBSCRIBED_MASK) == INNER_SUBSCRIBED_MASK);
/*     */   }
/*     */   
/*     */   static boolean hasMainCompleted(long state) {
/* 935 */     return ((state & COMPLETED_MASK) == COMPLETED_MASK);
/*     */   }
/*     */   
/*     */   static boolean hasInnerCompleted(long state) {
/* 939 */     return ((state & INNER_COMPLETED_MASK) == INNER_COMPLETED_MASK);
/*     */   }
/*     */   
/*     */   static int hasRequest(long state) {
/* 943 */     return (int)(state & HAS_REQUEST_MASK) >> HAS_REQUEST_OFFSET;
/*     */   }
/*     */   
/*     */   static int index(long state) {
/* 947 */     return (int)(state >>> INDEX_OFFSET);
/*     */   }
/*     */   
/*     */   static int nextIndex(long state) {
/* 951 */     return (int)(state >>> INDEX_OFFSET) + 1;
/*     */   }
/*     */   
/*     */   static boolean isWip(long state) {
/* 955 */     return ((state & INNER_WIP_MASK) == INNER_WIP_MASK);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\FluxSwitchMapNoPrefetch.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */