/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.stream.Stream;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SinkEmptyMulticast<T>
/*     */   extends Mono<T>
/*     */   implements InternalEmptySink<T>
/*     */ {
/*     */   volatile Inner<T>[] subscribers;
/*  36 */   static final AtomicReferenceFieldUpdater<SinkEmptyMulticast, Inner[]> SUBSCRIBERS = (AtomicReferenceFieldUpdater)AtomicReferenceFieldUpdater.newUpdater(SinkEmptyMulticast.class, (Class)Inner[].class, "subscribers");
/*     */ 
/*     */   
/*  39 */   static final Inner[] EMPTY = new Inner[0];
/*     */ 
/*     */   
/*  42 */   static final Inner[] TERMINATED = new Inner[0];
/*     */   
/*     */   @Nullable
/*     */   Throwable error;
/*     */   
/*     */   SinkEmptyMulticast() {
/*  48 */     SUBSCRIBERS.lazySet(this, EMPTY);
/*     */   }
/*     */ 
/*     */   
/*     */   public int currentSubscriberCount() {
/*  53 */     return this.subscribers.length;
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<T> asMono() {
/*  58 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Sinks.EmitResult tryEmitEmpty() {
/*  63 */     Inner[] arrayOfInner = SUBSCRIBERS.getAndSet(this, TERMINATED);
/*     */     
/*  65 */     if (arrayOfInner == TERMINATED) {
/*  66 */       return Sinks.EmitResult.FAIL_TERMINATED;
/*     */     }
/*     */     
/*  69 */     for (Inner<?> as : arrayOfInner) {
/*  70 */       as.complete();
/*     */     }
/*  72 */     return Sinks.EmitResult.OK;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Sinks.EmitResult tryEmitError(Throwable cause) {
/*  78 */     Objects.requireNonNull(cause, "onError cannot be null");
/*     */     
/*  80 */     Inner[] arrayOfInner = SUBSCRIBERS.getAndSet(this, TERMINATED);
/*  81 */     if (arrayOfInner == TERMINATED) {
/*  82 */       return Sinks.EmitResult.FAIL_TERMINATED;
/*     */     }
/*     */     
/*  85 */     this.error = cause;
/*     */     
/*  87 */     for (Inner<T> as : arrayOfInner) {
/*  88 */       as.error(cause);
/*     */     }
/*  90 */     return Sinks.EmitResult.OK;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  95 */     if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf((this.subscribers == TERMINATED)); 
/*  96 */     if (key == Scannable.Attr.ERROR) return this.error; 
/*  97 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */     
/*  99 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Context currentContext() {
/* 104 */     return Operators.multiSubscribersContext((InnerProducer<?>[])this.subscribers);
/*     */   }
/*     */   
/*     */   boolean add(Inner<T> ps) {
/*     */     while (true) {
/* 109 */       Inner<T>[] a = this.subscribers;
/*     */       
/* 111 */       if (a == TERMINATED) {
/* 112 */         return false;
/*     */       }
/*     */       
/* 115 */       int n = a.length;
/* 116 */       Inner[] arrayOfInner = new Inner[n + 1];
/* 117 */       System.arraycopy(a, 0, arrayOfInner, 0, n);
/* 118 */       arrayOfInner[n] = ps;
/*     */       
/* 120 */       if (SUBSCRIBERS.compareAndSet(this, a, arrayOfInner))
/* 121 */         return true; 
/*     */     } 
/*     */   }
/*     */   
/*     */   void remove(Inner<T> ps) {
/*     */     Inner<T>[] a;
/*     */     Inner[] arrayOfInner;
/*     */     do {
/* 129 */       a = this.subscribers;
/* 130 */       int n = a.length;
/* 131 */       if (n == 0) {
/*     */         return;
/*     */       }
/*     */       
/* 135 */       int j = -1;
/* 136 */       for (int i = 0; i < n; i++) {
/* 137 */         if (a[i] == ps) {
/* 138 */           j = i;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/* 143 */       if (j < 0) {
/*     */         return;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 149 */       if (n == 1) {
/* 150 */         arrayOfInner = EMPTY;
/*     */       } else {
/*     */         
/* 153 */         arrayOfInner = new Inner[n - 1];
/* 154 */         System.arraycopy(a, 0, arrayOfInner, 0, j);
/* 155 */         System.arraycopy(a, j + 1, arrayOfInner, j, n - j - 1);
/*     */       } 
/* 157 */     } while (!SUBSCRIBERS.compareAndSet(this, a, arrayOfInner));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super T> actual) {
/* 166 */     Inner<T> as = new VoidInner<>(actual, this);
/* 167 */     actual.onSubscribe(as);
/* 168 */     if (add(as)) {
/* 169 */       if (as.isCancelled()) {
/* 170 */         remove(as);
/*     */       }
/*     */     } else {
/*     */       
/* 174 */       Throwable ex = this.error;
/* 175 */       if (ex != null) {
/* 176 */         actual.onError(ex);
/*     */       } else {
/*     */         
/* 179 */         as.complete();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Stream<? extends Scannable> inners() {
/* 186 */     return Stream.of((Scannable[])this.subscribers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class VoidInner<T>
/*     */     extends AtomicBoolean
/*     */     implements Inner<T>
/*     */   {
/*     */     final SinkEmptyMulticast<T> parent;
/*     */ 
/*     */ 
/*     */     
/*     */     final CoreSubscriber<? super T> actual;
/*     */ 
/*     */ 
/*     */     
/*     */     VoidInner(CoreSubscriber<? super T> actual, SinkEmptyMulticast<T> parent) {
/* 205 */       this.actual = actual;
/* 206 */       this.parent = parent;
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 211 */       if (getAndSet(true)) {
/*     */         return;
/*     */       }
/*     */       
/* 215 */       this.parent.remove(this);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isCancelled() {
/* 220 */       return get();
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long l) {
/* 225 */       Operators.validate(l);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void complete(T value) {}
/*     */ 
/*     */ 
/*     */     
/*     */     public void complete() {
/* 235 */       if (get()) {
/*     */         return;
/*     */       }
/* 238 */       this.actual.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     public void error(Throwable t) {
/* 243 */       if (get()) {
/* 244 */         Operators.onOperatorError(t, this.actual.currentContext());
/*     */         return;
/*     */       } 
/* 247 */       this.actual.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 252 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 257 */       if (key == Scannable.Attr.PARENT) {
/* 258 */         return this.parent;
/*     */       }
/* 260 */       if (key == Scannable.Attr.CANCELLED) {
/* 261 */         return Boolean.valueOf(get());
/*     */       }
/* 263 */       if (key == Scannable.Attr.RUN_STYLE) {
/* 264 */         return Scannable.Attr.RunStyle.SYNC;
/*     */       }
/* 266 */       return super.scanUnsafe(key);
/*     */     }
/*     */   }
/*     */   
/*     */   static interface Inner<T> extends InnerProducer<T> {
/*     */     void error(Throwable param1Throwable);
/*     */     
/*     */     void complete(T param1T);
/*     */     
/*     */     void complete();
/*     */     
/*     */     boolean isCancelled();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\SinkEmptyMulticast.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */