/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.Queue;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.stream.Stream;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxSampleTimeout<T, U>
/*     */   extends InternalFluxOperator<T, T>
/*     */ {
/*     */   final Function<? super T, ? extends Publisher<U>> throttler;
/*     */   final Supplier<Queue<Object>> queueSupplier;
/*     */   
/*     */   FluxSampleTimeout(Flux<? extends T> source, Function<? super T, ? extends Publisher<U>> throttler, Supplier<Queue<Object>> queueSupplier) {
/*  55 */     super(source);
/*  56 */     this.throttler = Objects.<Function<? super T, ? extends Publisher<U>>>requireNonNull(throttler, "throttler");
/*  57 */     this.queueSupplier = Objects.<Supplier<Queue<Object>>>requireNonNull(queueSupplier, "queueSupplier");
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPrefetch() {
/*  62 */     return Integer.MAX_VALUE;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/*  68 */     Queue<SampleTimeoutOther<T, U>> q = (Queue<SampleTimeoutOther<T, U>>)this.queueSupplier.get();
/*     */     
/*  70 */     SampleTimeoutMain<T, U> main = new SampleTimeoutMain<>(actual, this.throttler, q);
/*     */     
/*  72 */     actual.onSubscribe(main);
/*     */     
/*  74 */     return main;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  79 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  80 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class SampleTimeoutMain<T, U>
/*     */     implements InnerOperator<T, T>
/*     */   {
/*     */     final Function<? super T, ? extends Publisher<U>> throttler;
/*     */     
/*     */     final Queue<FluxSampleTimeout.SampleTimeoutOther<T, U>> queue;
/*     */     
/*     */     final CoreSubscriber<? super T> actual;
/*     */     final Context ctx;
/*     */     volatile Subscription s;
/*  94 */     static final AtomicReferenceFieldUpdater<SampleTimeoutMain, Subscription> S = AtomicReferenceFieldUpdater.newUpdater(SampleTimeoutMain.class, Subscription.class, "s");
/*     */ 
/*     */ 
/*     */     
/*     */     volatile Subscription other;
/*     */ 
/*     */     
/* 101 */     static final AtomicReferenceFieldUpdater<SampleTimeoutMain, Subscription> OTHER = AtomicReferenceFieldUpdater.newUpdater(SampleTimeoutMain.class, Subscription.class, "other");
/*     */ 
/*     */ 
/*     */     
/*     */     volatile long requested;
/*     */ 
/*     */     
/* 108 */     static final AtomicLongFieldUpdater<SampleTimeoutMain> REQUESTED = AtomicLongFieldUpdater.newUpdater(SampleTimeoutMain.class, "requested");
/*     */ 
/*     */     
/*     */     volatile int wip;
/*     */     
/* 113 */     static final AtomicIntegerFieldUpdater<SampleTimeoutMain> WIP = AtomicIntegerFieldUpdater.newUpdater(SampleTimeoutMain.class, "wip");
/*     */ 
/*     */     
/*     */     volatile Throwable error;
/*     */     
/* 118 */     static final AtomicReferenceFieldUpdater<SampleTimeoutMain, Throwable> ERROR = AtomicReferenceFieldUpdater.newUpdater(SampleTimeoutMain.class, Throwable.class, "error");
/*     */ 
/*     */     
/*     */     volatile boolean done;
/*     */ 
/*     */     
/*     */     volatile boolean cancelled;
/*     */ 
/*     */     
/*     */     volatile long index;
/*     */     
/* 129 */     static final AtomicLongFieldUpdater<SampleTimeoutMain> INDEX = AtomicLongFieldUpdater.newUpdater(SampleTimeoutMain.class, "index");
/*     */ 
/*     */ 
/*     */     
/*     */     SampleTimeoutMain(CoreSubscriber<? super T> actual, Function<? super T, ? extends Publisher<U>> throttler, Queue<FluxSampleTimeout.SampleTimeoutOther<T, U>> queue) {
/* 134 */       this.actual = actual;
/* 135 */       this.ctx = actual.currentContext();
/* 136 */       this.throttler = throttler;
/* 137 */       this.queue = queue;
/*     */     }
/*     */ 
/*     */     
/*     */     public Stream<? extends Scannable> inners() {
/* 142 */       return Stream.of(Scannable.from(this.other));
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 148 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 149 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(this.cancelled); 
/* 150 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 151 */       if (key == Scannable.Attr.ERROR) return this.error; 
/* 152 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf(this.requested); 
/* 153 */       if (key == Scannable.Attr.BUFFERED) return Integer.valueOf(this.queue.size()); 
/* 154 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 156 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public final CoreSubscriber<? super T> actual() {
/* 161 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 166 */       if (Operators.validate(n)) {
/* 167 */         Operators.addCap(REQUESTED, this, n);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 173 */       if (!this.cancelled) {
/* 174 */         this.cancelled = true;
/* 175 */         Operators.terminate(S, this);
/* 176 */         Operators.terminate(OTHER, this);
/* 177 */         Operators.onDiscardQueueWithClear(this.queue, this.ctx, FluxSampleTimeout.SampleTimeoutOther::toStream);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 183 */       if (Operators.setOnce(S, this, s)) {
/* 184 */         s.request(Long.MAX_VALUE);
/*     */       }
/*     */     }
/*     */     
/*     */     public void onNext(T t) {
/*     */       Publisher<U> p;
/* 190 */       long idx = INDEX.incrementAndGet(this);
/*     */       
/* 192 */       if (!Operators.set(OTHER, this, Operators.emptySubscription())) {
/*     */         return;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 199 */         p = Objects.<Publisher<U>>requireNonNull(this.throttler.apply(t), "throttler returned a null publisher");
/*     */       
/*     */       }
/* 202 */       catch (Throwable e) {
/* 203 */         onError(Operators.onOperatorError(this.s, e, t, this.ctx));
/*     */         
/*     */         return;
/*     */       } 
/* 207 */       FluxSampleTimeout.SampleTimeoutOther<T, U> os = new FluxSampleTimeout.SampleTimeoutOther<>(this, t, idx);
/*     */       
/* 209 */       if (Operators.replace(OTHER, this, os)) {
/* 210 */         p.subscribe((Subscriber)os);
/*     */       }
/*     */     }
/*     */     
/*     */     void error(Throwable t) {
/* 215 */       if (Exceptions.addThrowable(ERROR, this, t)) {
/* 216 */         this.done = true;
/* 217 */         drain();
/*     */       } else {
/*     */         
/* 220 */         Operators.onErrorDropped(t, this.ctx);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 226 */       Operators.terminate(OTHER, this);
/*     */       
/* 228 */       error(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 233 */       Subscription o = this.other;
/* 234 */       if (o instanceof FluxSampleTimeout.SampleTimeoutOther) {
/* 235 */         FluxSampleTimeout.SampleTimeoutOther<?, ?> os = (FluxSampleTimeout.SampleTimeoutOther<?, ?>)o;
/* 236 */         os.cancel();
/* 237 */         os.onComplete();
/*     */       } 
/* 239 */       this.done = true;
/* 240 */       drain();
/*     */     }
/*     */     
/*     */     void otherNext(FluxSampleTimeout.SampleTimeoutOther<T, U> other) {
/* 244 */       this.queue.offer(other);
/* 245 */       drain();
/*     */     }
/*     */     
/*     */     void otherError(long idx, Throwable e) {
/* 249 */       if (idx == this.index) {
/* 250 */         Operators.terminate(S, this);
/*     */         
/* 252 */         error(e);
/*     */       } else {
/*     */         
/* 255 */         Operators.onErrorDropped(e, this.ctx);
/*     */       } 
/*     */     }
/*     */     
/*     */     void drain() {
/* 260 */       if (WIP.getAndIncrement(this) != 0) {
/*     */         return;
/*     */       }
/*     */       
/* 264 */       CoreSubscriber<? super T> coreSubscriber = this.actual;
/* 265 */       Queue<FluxSampleTimeout.SampleTimeoutOther<T, U>> q = this.queue;
/*     */       
/* 267 */       int missed = 1;
/*     */ 
/*     */ 
/*     */       
/*     */       while (true) {
/* 272 */         boolean d = this.done;
/*     */         
/* 274 */         FluxSampleTimeout.SampleTimeoutOther<T, U> o = q.poll();
/*     */         
/* 276 */         boolean empty = (o == null);
/*     */         
/* 278 */         if (checkTerminated(d, empty, (Subscriber<?>)coreSubscriber, q)) {
/*     */           return;
/*     */         }
/*     */         
/* 282 */         if (empty) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 310 */           missed = WIP.addAndGet(this, -missed);
/* 311 */           if (missed == 0)
/*     */             break;  continue;
/*     */         }  if (o.index == this.index) { long r = this.requested; if (r != 0L) {
/*     */             coreSubscriber.onNext(o.value); if (r != Long.MAX_VALUE)
/*     */               REQUESTED.decrementAndGet(this);  continue;
/*     */           }  cancel(); Operators.onDiscardQueueWithClear(q, this.ctx, FluxSampleTimeout.SampleTimeoutOther::toStream); Throwable e = Exceptions.failWithOverflow("Could not emit value due to lack of requests"); Exceptions.addThrowable(ERROR, this, e); e = Exceptions.terminate(ERROR, this); coreSubscriber.onError(e); return; }
/*     */       
/* 318 */       }  } boolean checkTerminated(boolean d, boolean empty, Subscriber<?> a, Queue<FluxSampleTimeout.SampleTimeoutOther<T, U>> q) { if (this.cancelled) {
/* 319 */         Operators.onDiscardQueueWithClear(q, this.ctx, FluxSampleTimeout.SampleTimeoutOther::toStream);
/* 320 */         return true;
/*     */       } 
/* 322 */       if (d) {
/* 323 */         Throwable e = Exceptions.terminate(ERROR, this);
/* 324 */         if (e != null && e != Exceptions.TERMINATED) {
/* 325 */           cancel();
/*     */           
/* 327 */           Operators.onDiscardQueueWithClear(q, this.ctx, FluxSampleTimeout.SampleTimeoutOther::toStream);
/*     */           
/* 329 */           a.onError(e);
/* 330 */           return true;
/*     */         } 
/* 332 */         if (empty) {
/*     */           
/* 334 */           a.onComplete();
/* 335 */           return true;
/*     */         } 
/*     */       } 
/* 338 */       return false; }
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   static final class SampleTimeoutOther<T, U>
/*     */     extends Operators.DeferredSubscription
/*     */     implements InnerConsumer<U>
/*     */   {
/*     */     final FluxSampleTimeout.SampleTimeoutMain<T, U> main;
/*     */     
/*     */     final T value;
/*     */     
/*     */     final long index;
/*     */     
/*     */     volatile int once;
/* 354 */     static final AtomicIntegerFieldUpdater<SampleTimeoutOther> ONCE = AtomicIntegerFieldUpdater.newUpdater(SampleTimeoutOther.class, "once");
/*     */     
/*     */     SampleTimeoutOther(FluxSampleTimeout.SampleTimeoutMain<T, U> main, T value, long index) {
/* 357 */       this.main = main;
/* 358 */       this.value = value;
/* 359 */       this.index = index;
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/* 364 */       return this.main.currentContext();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 370 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf((this.once == 1)); 
/* 371 */       if (key == Scannable.Attr.ACTUAL) return this.main; 
/* 372 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 374 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 379 */       if (set(s)) {
/* 380 */         s.request(Long.MAX_VALUE);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(U t) {
/* 386 */       if (ONCE.compareAndSet(this, 0, 1)) {
/* 387 */         cancel();
/*     */         
/* 389 */         this.main.otherNext(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 395 */       if (ONCE.compareAndSet(this, 0, 1)) {
/* 396 */         this.main.otherError(this.index, t);
/*     */       } else {
/*     */         
/* 399 */         Operators.onErrorDropped(t, this.main.currentContext());
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 405 */       if (ONCE.compareAndSet(this, 0, 1)) {
/* 406 */         this.main.otherNext(this);
/*     */       }
/*     */     }
/*     */     
/*     */     final Stream<T> toStream() {
/* 411 */       return Stream.of(this.value);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\FluxSampleTimeout.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */