/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.RejectedExecutionException;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.Disposables;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.core.scheduler.Scheduler;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxSubscribeOnValue<T>
/*     */   extends Flux<T>
/*     */   implements Fuseable, Scannable
/*     */ {
/*     */   final T value;
/*     */   final Scheduler scheduler;
/*     */   
/*     */   FluxSubscribeOnValue(@Nullable T value, Scheduler scheduler) {
/*  47 */     this.value = value;
/*  48 */     this.scheduler = Objects.<Scheduler>requireNonNull(scheduler, "scheduler");
/*     */   }
/*     */ 
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super T> actual) {
/*  53 */     T v = this.value;
/*  54 */     if (v == null) {
/*  55 */       ScheduledEmpty parent = new ScheduledEmpty((Subscriber<?>)actual);
/*  56 */       actual.onSubscribe((Subscription)parent);
/*     */       try {
/*  58 */         parent.setFuture(this.scheduler.schedule(parent));
/*     */       }
/*  60 */       catch (RejectedExecutionException ree) {
/*  61 */         if (parent.future != OperatorDisposables.DISPOSED) {
/*  62 */           actual.onError(Operators.onRejectedExecution(ree, actual
/*  63 */                 .currentContext()));
/*     */         }
/*     */       } 
/*     */     } else {
/*     */       
/*  68 */       actual.onSubscribe(new ScheduledScalar<>(actual, v, this.scheduler));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  74 */     if (key == Scannable.Attr.RUN_ON) return this.scheduler; 
/*  75 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.ASYNC;
/*     */     
/*  77 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   static final class ScheduledScalar<T>
/*     */     implements Fuseable.QueueSubscription<T>, InnerProducer<T>, Runnable
/*     */   {
/*     */     final CoreSubscriber<? super T> actual;
/*     */     
/*     */     final T value;
/*     */     
/*     */     final Scheduler scheduler;
/*     */     
/*     */     volatile int once;
/*     */     
/*  92 */     static final AtomicIntegerFieldUpdater<ScheduledScalar> ONCE = AtomicIntegerFieldUpdater.newUpdater(ScheduledScalar.class, "once");
/*     */ 
/*     */     
/*     */     volatile Disposable future;
/*     */     
/*  97 */     static final AtomicReferenceFieldUpdater<ScheduledScalar, Disposable> FUTURE = AtomicReferenceFieldUpdater.newUpdater(ScheduledScalar.class, Disposable.class, "future");
/*     */ 
/*     */ 
/*     */     
/* 101 */     static final Disposable FINISHED = Disposables.disposed();
/*     */     
/*     */     int fusionState;
/*     */     
/*     */     static final int NO_VALUE = 1;
/*     */     static final int HAS_VALUE = 2;
/*     */     static final int COMPLETE = 3;
/*     */     
/*     */     ScheduledScalar(CoreSubscriber<? super T> actual, T value, Scheduler scheduler) {
/* 110 */       this.actual = actual;
/* 111 */       this.value = value;
/* 112 */       this.scheduler = scheduler;
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 117 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 123 */       if (key == Scannable.Attr.CANCELLED) {
/* 124 */         return Boolean.valueOf((this.future == OperatorDisposables.DISPOSED));
/*     */       }
/* 126 */       if (key == Scannable.Attr.TERMINATED) {
/* 127 */         return Boolean.valueOf((this.future == FINISHED));
/*     */       }
/* 129 */       if (key == Scannable.Attr.BUFFERED) {
/* 130 */         return Integer.valueOf(1);
/*     */       }
/* 132 */       if (key == Scannable.Attr.RUN_ON) return this.scheduler; 
/* 133 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.ASYNC;
/*     */       
/* 135 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 140 */       if (Operators.validate(n) && 
/* 141 */         ONCE.compareAndSet(this, 0, 1)) {
/*     */         try {
/* 143 */           Disposable f = this.scheduler.schedule(this);
/* 144 */           if (!FUTURE.compareAndSet(this, null, f) && this.future != FINISHED && this.future != OperatorDisposables.DISPOSED)
/*     */           {
/*     */             
/* 147 */             f.dispose();
/*     */           }
/*     */         }
/* 150 */         catch (RejectedExecutionException ree) {
/* 151 */           if (this.future != FINISHED && this.future != OperatorDisposables.DISPOSED) {
/* 152 */             this.actual.onError(Operators.onRejectedExecution(ree, this, null, this.value, this.actual
/*     */ 
/*     */                   
/* 155 */                   .currentContext()));
/*     */           }
/*     */         } 
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 164 */       ONCE.lazySet(this, 1);
/* 165 */       Disposable f = this.future;
/* 166 */       if (f != OperatorDisposables.DISPOSED && this.future != FINISHED) {
/* 167 */         f = FUTURE.getAndSet(this, OperatorDisposables.DISPOSED);
/* 168 */         if (f != null && f != OperatorDisposables.DISPOSED && f != FINISHED) {
/* 169 */           f.dispose();
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void run() {
/*     */       try {
/* 177 */         if (this.fusionState == 1) {
/* 178 */           this.fusionState = 2;
/*     */         }
/* 180 */         this.actual.onNext(this.value);
/* 181 */         this.actual.onComplete();
/*     */       } finally {
/*     */         
/* 184 */         FUTURE.lazySet(this, FINISHED);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public int requestFusion(int requestedMode) {
/* 190 */       if ((requestedMode & 0x2) != 0) {
/* 191 */         this.fusionState = 1;
/* 192 */         return 2;
/*     */       } 
/* 194 */       return 0;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public T poll() {
/* 200 */       if (this.fusionState == 2) {
/* 201 */         this.fusionState = 3;
/* 202 */         return this.value;
/*     */       } 
/* 204 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isEmpty() {
/* 209 */       return (this.fusionState != 2);
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 214 */       return isEmpty() ? 0 : 1;
/*     */     }
/*     */ 
/*     */     
/*     */     public void clear() {
/* 219 */       this.fusionState = 3;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class ScheduledEmpty
/*     */     implements Fuseable.QueueSubscription<Void>, Runnable
/*     */   {
/*     */     final Subscriber<?> actual;
/*     */     volatile Disposable future;
/* 229 */     static final AtomicReferenceFieldUpdater<ScheduledEmpty, Disposable> FUTURE = AtomicReferenceFieldUpdater.newUpdater(ScheduledEmpty.class, Disposable.class, "future");
/*     */ 
/*     */ 
/*     */     
/* 233 */     static final Disposable FINISHED = Disposables.disposed();
/*     */     
/*     */     ScheduledEmpty(Subscriber<?> actual) {
/* 236 */       this.actual = actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 241 */       Operators.validate(n);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 246 */       Disposable f = this.future;
/* 247 */       if (f != OperatorDisposables.DISPOSED && f != FINISHED) {
/* 248 */         f = FUTURE.getAndSet(this, OperatorDisposables.DISPOSED);
/* 249 */         if (f != null && f != OperatorDisposables.DISPOSED && f != FINISHED) {
/* 250 */           f.dispose();
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void run() {
/*     */       try {
/* 258 */         this.actual.onComplete();
/*     */       } finally {
/*     */         
/* 261 */         FUTURE.lazySet(this, FINISHED);
/*     */       } 
/*     */     }
/*     */     
/*     */     void setFuture(Disposable f) {
/* 266 */       if (!FUTURE.compareAndSet(this, null, f)) {
/* 267 */         Disposable a = this.future;
/* 268 */         if (a != FINISHED && a != OperatorDisposables.DISPOSED) {
/* 269 */           f.dispose();
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public int requestFusion(int requestedMode) {
/* 276 */       return requestedMode & 0x2;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Void poll() {
/* 282 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isEmpty() {
/* 287 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 292 */       return 0;
/*     */     }
/*     */     
/*     */     public void clear() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\FluxSubscribeOnValue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */