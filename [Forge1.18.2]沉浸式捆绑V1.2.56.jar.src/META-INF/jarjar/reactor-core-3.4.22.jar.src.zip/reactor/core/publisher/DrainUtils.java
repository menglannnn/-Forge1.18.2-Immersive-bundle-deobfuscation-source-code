/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Queue;
/*     */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*     */ import java.util.function.BooleanSupplier;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class DrainUtils
/*     */ {
/*     */   static final long COMPLETED_MASK = -9223372036854775808L;
/*     */   static final long REQUESTED_MASK = 9223372036854775807L;
/*     */   
/*     */   static <T, F> boolean postCompleteRequest(long n, Subscriber<? super T> actual, Queue<T> queue, AtomicLongFieldUpdater<F> field, F instance, BooleanSupplier isCancelled) {
/*     */     long r;
/*     */     long u;
/*     */     do {
/*  59 */       r = field.get(instance);
/*     */ 
/*     */       
/*  62 */       long r0 = r & Long.MAX_VALUE;
/*     */ 
/*     */       
/*  65 */       u = r & Long.MIN_VALUE | Operators.addCap(r0, n);
/*     */     }
/*  67 */     while (!field.compareAndSet(instance, r, u));
/*     */     
/*  69 */     if (r == Long.MIN_VALUE) {
/*     */       
/*  71 */       postCompleteDrain(n | Long.MIN_VALUE, actual, queue, field, instance, isCancelled);
/*     */       
/*  73 */       return true;
/*     */     } 
/*     */     
/*  76 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T, F> boolean postCompleteDrain(long n, Subscriber<? super T> actual, Queue<T> queue, AtomicLongFieldUpdater<F> field, F instance, BooleanSupplier isCancelled) {
/* 120 */     long e = n & Long.MIN_VALUE;
/*     */ 
/*     */     
/*     */     while (true) {
/* 124 */       while (e != n) {
/* 125 */         if (isCancelled.getAsBoolean()) {
/* 126 */           return true;
/*     */         }
/*     */         
/* 129 */         T t = queue.poll();
/*     */         
/* 131 */         if (t == null) {
/* 132 */           actual.onComplete();
/* 133 */           return true;
/*     */         } 
/*     */         
/* 136 */         actual.onNext(t);
/* 137 */         e++;
/*     */       } 
/*     */       
/* 140 */       if (isCancelled.getAsBoolean()) {
/* 141 */         return true;
/*     */       }
/*     */       
/* 144 */       if (queue.isEmpty()) {
/* 145 */         actual.onComplete();
/* 146 */         return true;
/*     */       } 
/*     */       
/* 149 */       n = field.get(instance);
/*     */       
/* 151 */       if (n == e) {
/*     */         
/* 153 */         n = field.addAndGet(instance, -(e & Long.MAX_VALUE));
/*     */         
/* 155 */         if ((n & Long.MAX_VALUE) == 0L) {
/* 156 */           return false;
/*     */         }
/*     */         
/* 159 */         e = n & Long.MIN_VALUE;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T, F> void postComplete(CoreSubscriber<? super T> actual, Queue<T> queue, AtomicLongFieldUpdater<F> field, F instance, BooleanSupplier isCancelled) {
/*     */     long r;
/*     */     long u;
/* 182 */     if (queue.isEmpty()) {
/* 183 */       actual.onComplete();
/*     */       
/*     */       return;
/*     */     } 
/* 187 */     if (postCompleteDrain(field.get(instance), (Subscriber<? super T>)actual, queue, field, instance, isCancelled)) {
/*     */       return;
/*     */     }
/*     */     
/*     */     do {
/* 192 */       r = field.get(instance);
/*     */       
/* 194 */       if ((r & Long.MIN_VALUE) != 0L) {
/*     */         return;
/*     */       }
/*     */       
/* 198 */       u = r | Long.MIN_VALUE;
/*     */     }
/* 200 */     while (!field.compareAndSet(instance, r, u));
/*     */     
/* 202 */     if (r != 0L) {
/* 203 */       postCompleteDrain(u, (Subscriber<? super T>)actual, queue, field, instance, isCancelled);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T, F> boolean postCompleteRequestDelayError(long n, Subscriber<? super T> actual, Queue<T> queue, AtomicLongFieldUpdater<F> field, F instance, BooleanSupplier isCancelled, Throwable error) {
/*     */     long r;
/*     */     long u;
/*     */     do {
/* 233 */       r = field.get(instance);
/*     */ 
/*     */       
/* 236 */       long r0 = r & Long.MAX_VALUE;
/*     */ 
/*     */       
/* 239 */       u = r & Long.MIN_VALUE | Operators.addCap(r0, n);
/*     */     }
/* 241 */     while (!field.compareAndSet(instance, r, u));
/*     */     
/* 243 */     if (r == Long.MIN_VALUE) {
/*     */       
/* 245 */       postCompleteDrainDelayError(n | Long.MIN_VALUE, actual, queue, field, instance, isCancelled, error);
/*     */       
/* 247 */       return true;
/*     */     } 
/*     */     
/* 250 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T, F> boolean postCompleteDrainDelayError(long n, Subscriber<? super T> actual, Queue<T> queue, AtomicLongFieldUpdater<F> field, F instance, BooleanSupplier isCancelled, @Nullable Throwable error) {
/* 277 */     long e = n & Long.MIN_VALUE;
/*     */ 
/*     */     
/*     */     while (true) {
/* 281 */       while (e != n) {
/* 282 */         if (isCancelled.getAsBoolean()) {
/* 283 */           return true;
/*     */         }
/*     */         
/* 286 */         T t = queue.poll();
/*     */         
/* 288 */         if (t == null) {
/* 289 */           if (error == null) {
/* 290 */             actual.onComplete();
/*     */           } else {
/* 292 */             actual.onError(error);
/*     */           } 
/* 294 */           return true;
/*     */         } 
/*     */         
/* 297 */         actual.onNext(t);
/* 298 */         e++;
/*     */       } 
/*     */       
/* 301 */       if (isCancelled.getAsBoolean()) {
/* 302 */         return true;
/*     */       }
/*     */       
/* 305 */       if (queue.isEmpty()) {
/* 306 */         if (error == null) {
/* 307 */           actual.onComplete();
/*     */         } else {
/* 309 */           actual.onError(error);
/*     */         } 
/* 311 */         return true;
/*     */       } 
/*     */       
/* 314 */       n = field.get(instance);
/*     */       
/* 316 */       if (n == e) {
/*     */         
/* 318 */         n = field.addAndGet(instance, -(e & Long.MAX_VALUE));
/*     */         
/* 320 */         if ((n & Long.MAX_VALUE) == 0L) {
/* 321 */           return false;
/*     */         }
/*     */         
/* 324 */         e = n & Long.MIN_VALUE;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T, F> void postCompleteDelayError(CoreSubscriber<? super T> actual, Queue<T> queue, AtomicLongFieldUpdater<F> field, F instance, BooleanSupplier isCancelled, @Nullable Throwable error) {
/*     */     long r;
/*     */     long u;
/* 349 */     if (queue.isEmpty()) {
/* 350 */       if (error == null) {
/* 351 */         actual.onComplete();
/*     */       } else {
/* 353 */         actual.onError(error);
/*     */       } 
/*     */       
/*     */       return;
/*     */     } 
/* 358 */     if (postCompleteDrainDelayError(field.get(instance), (Subscriber<? super T>)actual, queue, field, instance, isCancelled, error)) {
/*     */       return;
/*     */     }
/*     */     
/*     */     do {
/* 363 */       r = field.get(instance);
/*     */       
/* 365 */       if ((r & Long.MIN_VALUE) != 0L) {
/*     */         return;
/*     */       }
/*     */       
/* 369 */       u = r | Long.MIN_VALUE;
/*     */     }
/* 371 */     while (!field.compareAndSet(instance, r, u));
/*     */     
/* 373 */     if (r != 0L)
/* 374 */       postCompleteDrainDelayError(u, (Subscriber<? super T>)actual, queue, field, instance, isCancelled, error); 
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\DrainUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */