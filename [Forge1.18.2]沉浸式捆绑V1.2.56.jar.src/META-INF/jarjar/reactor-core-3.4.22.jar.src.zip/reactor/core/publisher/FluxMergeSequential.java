/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.Queue;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.stream.Stream;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.concurrent.Queues;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxMergeSequential<T, R>
/*     */   extends InternalFluxOperator<T, R>
/*     */ {
/*     */   final FluxConcatMap.ErrorMode errorMode;
/*     */   final Function<? super T, ? extends Publisher<? extends R>> mapper;
/*     */   final int maxConcurrency;
/*     */   final int prefetch;
/*     */   final Supplier<Queue<MergeSequentialInner<R>>> queueSupplier;
/*     */   
/*     */   FluxMergeSequential(Flux<? extends T> source, Function<? super T, ? extends Publisher<? extends R>> mapper, int maxConcurrency, int prefetch, FluxConcatMap.ErrorMode errorMode) {
/*  64 */     this(source, mapper, maxConcurrency, prefetch, errorMode, 
/*  65 */         Queues.get(Math.max(prefetch, maxConcurrency)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   FluxMergeSequential(Flux<? extends T> source, Function<? super T, ? extends Publisher<? extends R>> mapper, int maxConcurrency, int prefetch, FluxConcatMap.ErrorMode errorMode, Supplier<Queue<MergeSequentialInner<R>>> queueSupplier) {
/*  73 */     super(source);
/*  74 */     if (prefetch <= 0) {
/*  75 */       throw new IllegalArgumentException("prefetch > 0 required but it was " + prefetch);
/*     */     }
/*  77 */     if (maxConcurrency <= 0) {
/*  78 */       throw new IllegalArgumentException("maxConcurrency > 0 required but it was " + maxConcurrency);
/*     */     }
/*  80 */     this.mapper = Objects.<Function<? super T, ? extends Publisher<? extends R>>>requireNonNull(mapper, "mapper");
/*  81 */     this.maxConcurrency = maxConcurrency;
/*  82 */     this.prefetch = prefetch;
/*  83 */     this.errorMode = errorMode;
/*  84 */     this.queueSupplier = queueSupplier;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super R> actual) {
/*  90 */     if (FluxFlatMap.trySubscribeScalarMap((Publisher<? extends T>)this.source, actual, this.mapper, false, false)) {
/*  91 */       return null;
/*     */     }
/*     */     
/*  94 */     return new MergeSequentialMain<>(actual, this.mapper, this.maxConcurrency, this.prefetch, this.errorMode, this.queueSupplier);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/* 104 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 105 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static final class MergeSequentialMain<T, R>
/*     */     implements InnerOperator<T, R>
/*     */   {
/*     */     final Function<? super T, ? extends Publisher<? extends R>> mapper;
/*     */ 
/*     */     
/*     */     final int maxConcurrency;
/*     */ 
/*     */     
/*     */     final int prefetch;
/*     */ 
/*     */     
/*     */     final Queue<FluxMergeSequential.MergeSequentialInner<R>> subscribers;
/*     */ 
/*     */     
/*     */     final FluxConcatMap.ErrorMode errorMode;
/*     */     
/*     */     final CoreSubscriber<? super R> actual;
/*     */     
/*     */     Subscription s;
/*     */     
/*     */     volatile boolean done;
/*     */     
/*     */     volatile boolean cancelled;
/*     */     
/*     */     volatile Throwable error;
/*     */     
/* 137 */     static final AtomicReferenceFieldUpdater<MergeSequentialMain, Throwable> ERROR = AtomicReferenceFieldUpdater.newUpdater(MergeSequentialMain.class, Throwable.class, "error");
/*     */ 
/*     */ 
/*     */     
/*     */     FluxMergeSequential.MergeSequentialInner<R> current;
/*     */ 
/*     */     
/*     */     volatile int wip;
/*     */ 
/*     */     
/* 147 */     static final AtomicIntegerFieldUpdater<MergeSequentialMain> WIP = AtomicIntegerFieldUpdater.newUpdater(MergeSequentialMain.class, "wip");
/*     */ 
/*     */     
/*     */     volatile long requested;
/*     */     
/* 152 */     static final AtomicLongFieldUpdater<MergeSequentialMain> REQUESTED = AtomicLongFieldUpdater.newUpdater(MergeSequentialMain.class, "requested");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     MergeSequentialMain(CoreSubscriber<? super R> actual, Function<? super T, ? extends Publisher<? extends R>> mapper, int maxConcurrency, int prefetch, FluxConcatMap.ErrorMode errorMode, Supplier<Queue<FluxMergeSequential.MergeSequentialInner<R>>> queueSupplier) {
/* 158 */       this.actual = actual;
/* 159 */       this.mapper = mapper;
/* 160 */       this.maxConcurrency = maxConcurrency;
/* 161 */       this.prefetch = prefetch;
/* 162 */       this.errorMode = errorMode;
/* 163 */       this.subscribers = queueSupplier.get();
/*     */     }
/*     */ 
/*     */     
/*     */     public final CoreSubscriber<? super R> actual() {
/* 168 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public Stream<? extends Scannable> inners() {
/* 173 */       return Stream.of(this.subscribers.peek());
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 179 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 180 */       if (key == Scannable.Attr.ERROR) return this.error; 
/* 181 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf((this.done && this.subscribers.isEmpty())); 
/* 182 */       if (key == Scannable.Attr.DELAY_ERROR) return Boolean.valueOf((this.errorMode != FluxConcatMap.ErrorMode.IMMEDIATE)); 
/* 183 */       if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(this.maxConcurrency); 
/* 184 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf(this.requested); 
/* 185 */       if (key == Scannable.Attr.BUFFERED) return Integer.valueOf(this.subscribers.size()); 
/* 186 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 188 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 193 */       if (Operators.validate(this.s, s)) {
/* 194 */         this.s = s;
/*     */         
/* 196 */         this.actual.onSubscribe(this);
/*     */         
/* 198 */         s.request((this.maxConcurrency == Integer.MAX_VALUE) ? Long.MAX_VALUE : this.maxConcurrency);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/*     */       Publisher<? extends R> publisher;
/*     */       try {
/* 208 */         publisher = Objects.<Publisher<? extends R>>requireNonNull(this.mapper.apply(t), "publisher");
/*     */       }
/* 210 */       catch (Throwable ex) {
/* 211 */         onError(Operators.onOperatorError(this.s, ex, t, this.actual.currentContext()));
/*     */         
/*     */         return;
/*     */       } 
/* 215 */       FluxMergeSequential.MergeSequentialInner<R> inner = new FluxMergeSequential.MergeSequentialInner<>(this, this.prefetch);
/*     */       
/* 217 */       if (this.cancelled) {
/*     */         return;
/*     */       }
/*     */       
/* 221 */       if (!this.subscribers.offer(inner)) {
/* 222 */         int badSize = this.subscribers.size();
/* 223 */         inner.cancel();
/* 224 */         drainAndCancel();
/* 225 */         onError(Operators.onOperatorError(this.s, new IllegalStateException("Too many subscribers for fluxMergeSequential on item: " + t + "; subscribers: " + badSize), t, this.actual
/*     */ 
/*     */ 
/*     */               
/* 229 */               .currentContext()));
/*     */         
/*     */         return;
/*     */       } 
/* 233 */       if (this.cancelled) {
/*     */         return;
/*     */       }
/*     */       
/* 237 */       publisher.subscribe((Subscriber)inner);
/*     */       
/* 239 */       if (this.cancelled) {
/* 240 */         inner.cancel();
/* 241 */         drainAndCancel();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 247 */       if (Exceptions.addThrowable(ERROR, this, t)) {
/* 248 */         this.done = true;
/* 249 */         drain();
/*     */       } else {
/*     */         
/* 252 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 258 */       this.done = true;
/* 259 */       drain();
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 264 */       if (this.cancelled) {
/*     */         return;
/*     */       }
/* 267 */       this.cancelled = true;
/* 268 */       this.s.cancel();
/*     */       
/* 270 */       drainAndCancel();
/*     */     }
/*     */     
/*     */     void drainAndCancel() {
/* 274 */       if (WIP.getAndIncrement(this) == 0) {
/*     */         do {
/* 276 */           cancelAll();
/*     */         }
/* 278 */         while (WIP.decrementAndGet(this) != 0);
/*     */       }
/*     */     }
/*     */     
/*     */     void cancelAll() {
/* 283 */       FluxMergeSequential.MergeSequentialInner<R> c = this.current;
/* 284 */       if (c != null) {
/* 285 */         c.cancel();
/*     */       }
/*     */       
/*     */       FluxMergeSequential.MergeSequentialInner<R> inner;
/* 289 */       while ((inner = this.subscribers.poll()) != null) {
/* 290 */         inner.cancel();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 296 */       if (Operators.validate(n)) {
/* 297 */         Operators.addCap(REQUESTED, this, n);
/* 298 */         drain();
/*     */       } 
/*     */     }
/*     */     
/*     */     void innerNext(FluxMergeSequential.MergeSequentialInner<R> inner, R value) {
/* 303 */       if (inner.queue().offer(value)) {
/* 304 */         drain();
/*     */       } else {
/*     */         
/* 307 */         inner.cancel();
/* 308 */         onError(Operators.onOperatorError(null, Exceptions.failWithOverflow("Queue is full: Reactive Streams source doesn't respect backpressure"), value, this.actual
/* 309 */               .currentContext()));
/*     */       } 
/*     */     }
/*     */     
/*     */     void innerError(FluxMergeSequential.MergeSequentialInner<R> inner, Throwable e) {
/* 314 */       if (Exceptions.addThrowable(ERROR, this, e)) {
/* 315 */         inner.setDone();
/* 316 */         if (this.errorMode != FluxConcatMap.ErrorMode.END) {
/* 317 */           this.s.cancel();
/*     */         }
/* 319 */         drain();
/*     */       } else {
/*     */         
/* 322 */         Operators.onErrorDropped(e, this.actual.currentContext());
/*     */       } 
/*     */     }
/*     */     
/*     */     void innerComplete(FluxMergeSequential.MergeSequentialInner<R> inner) {
/* 327 */       inner.setDone();
/* 328 */       drain();
/*     */     }
/*     */     
/*     */     void drain() {
/* 332 */       if (WIP.getAndIncrement(this) != 0) {
/*     */         return;
/*     */       }
/*     */       
/* 336 */       int missed = 1;
/* 337 */       FluxMergeSequential.MergeSequentialInner<R> inner = this.current;
/* 338 */       CoreSubscriber<? super R> coreSubscriber = this.actual;
/* 339 */       FluxConcatMap.ErrorMode em = this.errorMode;
/*     */       
/*     */       while (true) {
/* 342 */         long r = this.requested;
/* 343 */         long e = 0L;
/*     */         
/* 345 */         if (inner == null) {
/*     */           
/* 347 */           if (em != FluxConcatMap.ErrorMode.END) {
/* 348 */             Throwable ex = this.error;
/* 349 */             if (ex != null) {
/* 350 */               cancelAll();
/*     */               
/* 352 */               coreSubscriber.onError(ex);
/*     */               
/*     */               return;
/*     */             } 
/*     */           } 
/* 357 */           boolean outerDone = this.done;
/*     */           
/* 359 */           inner = this.subscribers.poll();
/*     */           
/* 361 */           if (outerDone && inner == null) {
/* 362 */             Throwable ex = this.error;
/* 363 */             if (ex != null) {
/* 364 */               coreSubscriber.onError(ex);
/*     */             } else {
/*     */               
/* 367 */               coreSubscriber.onComplete();
/*     */             } 
/*     */             
/*     */             return;
/*     */           } 
/* 372 */           if (inner != null) {
/* 373 */             this.current = inner;
/*     */           }
/*     */         } 
/*     */         
/* 377 */         boolean continueNextSource = false;
/*     */         
/* 379 */         if (inner != null) {
/* 380 */           Queue<R> q = inner.queue();
/*     */           
/* 382 */           if (q != null) {
/* 383 */             while (e != r) {
/* 384 */               R v; if (this.cancelled) {
/* 385 */                 cancelAll();
/*     */                 
/*     */                 return;
/*     */               } 
/* 389 */               if (em == FluxConcatMap.ErrorMode.IMMEDIATE) {
/* 390 */                 Throwable ex = this.error;
/* 391 */                 if (ex != null) {
/* 392 */                   this.current = null;
/* 393 */                   inner.cancel();
/* 394 */                   cancelAll();
/*     */                   
/* 396 */                   coreSubscriber.onError(ex);
/*     */                   
/*     */                   return;
/*     */                 } 
/*     */               } 
/* 401 */               boolean d = inner.isDone();
/*     */ 
/*     */ 
/*     */               
/*     */               try {
/* 406 */                 v = q.poll();
/*     */               }
/* 408 */               catch (Throwable ex) {
/* 409 */                 this.current = null;
/* 410 */                 inner.cancel();
/* 411 */                 ex = Operators.onOperatorError(ex, this.actual
/* 412 */                     .currentContext());
/* 413 */                 cancelAll();
/* 414 */                 coreSubscriber.onError(ex);
/*     */                 
/*     */                 return;
/*     */               } 
/* 418 */               boolean empty = (v == null);
/*     */               
/* 420 */               if (d && empty) {
/* 421 */                 inner = null;
/* 422 */                 this.current = null;
/* 423 */                 this.s.request(1L);
/* 424 */                 continueNextSource = true;
/*     */                 
/*     */                 break;
/*     */               } 
/* 428 */               if (empty) {
/*     */                 break;
/*     */               }
/*     */               
/* 432 */               coreSubscriber.onNext(v);
/*     */               
/* 434 */               e++;
/*     */               
/* 436 */               inner.requestOne();
/*     */             } 
/*     */             
/* 439 */             if (e == r) {
/* 440 */               if (this.cancelled) {
/* 441 */                 cancelAll();
/*     */                 
/*     */                 return;
/*     */               } 
/* 445 */               if (em == FluxConcatMap.ErrorMode.IMMEDIATE) {
/* 446 */                 Throwable ex = this.error;
/* 447 */                 if (ex != null) {
/* 448 */                   this.current = null;
/* 449 */                   inner.cancel();
/* 450 */                   cancelAll();
/*     */                   
/* 452 */                   coreSubscriber.onError(ex);
/*     */                   
/*     */                   return;
/*     */                 } 
/*     */               } 
/* 457 */               boolean d = inner.isDone();
/*     */               
/* 459 */               boolean empty = q.isEmpty();
/*     */               
/* 461 */               if (d && empty) {
/* 462 */                 inner = null;
/* 463 */                 this.current = null;
/* 464 */                 this.s.request(1L);
/* 465 */                 continueNextSource = true;
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */         
/* 471 */         if (e != 0L && r != Long.MAX_VALUE) {
/* 472 */           REQUESTED.addAndGet(this, -e);
/*     */         }
/*     */         
/* 475 */         if (continueNextSource) {
/*     */           continue;
/*     */         }
/*     */         
/* 479 */         missed = WIP.addAndGet(this, -missed);
/* 480 */         if (missed == 0) {
/*     */           break;
/*     */         }
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static final class MergeSequentialInner<R>
/*     */     implements InnerConsumer<R>
/*     */   {
/*     */     final FluxMergeSequential.MergeSequentialMain<?, R> parent;
/*     */ 
/*     */     
/*     */     final int prefetch;
/*     */ 
/*     */     
/*     */     final int limit;
/*     */ 
/*     */     
/*     */     volatile Queue<R> queue;
/*     */ 
/*     */     
/*     */     volatile Subscription subscription;
/*     */     
/* 506 */     static final AtomicReferenceFieldUpdater<MergeSequentialInner, Subscription> SUBSCRIPTION = AtomicReferenceFieldUpdater.newUpdater(MergeSequentialInner.class, Subscription.class, "subscription");
/*     */     
/*     */     volatile boolean done;
/*     */     
/*     */     long produced;
/*     */     
/*     */     int fusionMode;
/*     */ 
/*     */     
/*     */     MergeSequentialInner(FluxMergeSequential.MergeSequentialMain<?, R> parent, int prefetch) {
/* 516 */       this.parent = parent;
/* 517 */       this.prefetch = prefetch;
/* 518 */       this.limit = Operators.unboundedOrLimit(prefetch);
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/* 523 */       return this.parent.currentContext();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 529 */       if (key == Scannable.Attr.PARENT) return this.subscription; 
/* 530 */       if (key == Scannable.Attr.ACTUAL) return this.parent; 
/* 531 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf((this.done && (this.queue == null || this.queue.isEmpty()))); 
/* 532 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf((this.subscription == Operators.cancelledSubscription())); 
/* 533 */       if (key == Scannable.Attr.BUFFERED) return Integer.valueOf((this.queue == null) ? 0 : this.queue.size()); 
/* 534 */       if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(this.prefetch); 
/* 535 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 537 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 542 */       if (Operators.setOnce(SUBSCRIPTION, this, s)) {
/* 543 */         if (s instanceof Fuseable.QueueSubscription) {
/*     */           
/* 545 */           Fuseable.QueueSubscription<R> qs = (Fuseable.QueueSubscription<R>)s;
/*     */           
/* 547 */           int m = qs.requestFusion(7);
/* 548 */           if (m == 1) {
/* 549 */             this.fusionMode = m;
/* 550 */             this.queue = (Queue<R>)qs;
/* 551 */             this.done = true;
/* 552 */             this.parent.innerComplete(this);
/*     */             return;
/*     */           } 
/* 555 */           if (m == 2) {
/* 556 */             this.fusionMode = m;
/* 557 */             this.queue = (Queue<R>)qs;
/* 558 */             s.request(Operators.unboundedOrPrefetch(this.prefetch));
/*     */             
/*     */             return;
/*     */           } 
/*     */         } 
/* 563 */         this.queue = Queues.get(this.prefetch).get();
/* 564 */         s.request(Operators.unboundedOrPrefetch(this.prefetch));
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(R t) {
/* 570 */       if (this.fusionMode == 0) {
/* 571 */         this.parent.innerNext(this, t);
/*     */       } else {
/* 573 */         this.parent.drain();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 579 */       this.parent.innerError(this, t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 584 */       this.parent.innerComplete(this);
/*     */     }
/*     */     
/*     */     void requestOne() {
/* 588 */       if (this.fusionMode != 1) {
/* 589 */         long p = this.produced + 1L;
/* 590 */         if (p == this.limit) {
/* 591 */           this.produced = 0L;
/* 592 */           this.subscription.request(p);
/*     */         } else {
/* 594 */           this.produced = p;
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     void cancel() {
/* 601 */       Operators.set(SUBSCRIPTION, this, Operators.cancelledSubscription());
/*     */     }
/*     */     
/*     */     boolean isDone() {
/* 605 */       return this.done;
/*     */     }
/*     */     
/*     */     void setDone() {
/* 609 */       this.done = true;
/*     */     }
/*     */     
/*     */     Queue<R> queue() {
/* 613 */       return this.queue;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\FluxMergeSequential.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */