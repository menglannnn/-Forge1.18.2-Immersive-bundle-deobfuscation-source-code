/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Queue;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.BiPredicate;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.stream.Stream;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.Disposables;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.concurrent.Queues;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxGroupJoin<TLeft, TRight, TLeftEnd, TRightEnd, R>
/*     */   extends InternalFluxOperator<TLeft, R>
/*     */ {
/*     */   final Publisher<? extends TRight> other;
/*     */   final Function<? super TLeft, ? extends Publisher<TLeftEnd>> leftEnd;
/*     */   final Function<? super TRight, ? extends Publisher<TRightEnd>> rightEnd;
/*     */   final BiFunction<? super TLeft, ? super Flux<TRight>, ? extends R> resultSelector;
/*     */   final Supplier<? extends Queue<TRight>> processorQueueSupplier;
/*     */   
/*     */   FluxGroupJoin(Flux<TLeft> source, Publisher<? extends TRight> other, Function<? super TLeft, ? extends Publisher<TLeftEnd>> leftEnd, Function<? super TRight, ? extends Publisher<TRightEnd>> rightEnd, BiFunction<? super TLeft, ? super Flux<TRight>, ? extends R> resultSelector, Supplier<? extends Queue<Object>> queueSupplier, Supplier<? extends Queue<TRight>> processorQueueSupplier) {
/*  83 */     super(source);
/*  84 */     this.other = Objects.<Publisher<? extends TRight>>requireNonNull(other, "other");
/*  85 */     this.leftEnd = Objects.<Function<? super TLeft, ? extends Publisher<TLeftEnd>>>requireNonNull(leftEnd, "leftEnd");
/*  86 */     this.rightEnd = Objects.<Function<? super TRight, ? extends Publisher<TRightEnd>>>requireNonNull(rightEnd, "rightEnd");
/*  87 */     this.processorQueueSupplier = Objects.<Supplier<? extends Queue<TRight>>>requireNonNull(processorQueueSupplier, "processorQueueSupplier");
/*  88 */     this.resultSelector = Objects.<BiFunction<? super TLeft, ? super Flux<TRight>, ? extends R>>requireNonNull(resultSelector, "resultSelector");
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super TLeft> subscribeOrReturn(CoreSubscriber<? super R> actual) {
/*  93 */     GroupJoinSubscription<TLeft, TRight, TLeftEnd, TRightEnd, R> parent = new GroupJoinSubscription<>(actual, this.leftEnd, this.rightEnd, this.resultSelector, this.processorQueueSupplier);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 100 */     actual.onSubscribe(parent);
/*     */     
/* 102 */     LeftRightSubscriber left = new LeftRightSubscriber(parent, true);
/* 103 */     parent.cancellations.add(left);
/* 104 */     LeftRightSubscriber right = new LeftRightSubscriber(parent, false);
/* 105 */     parent.cancellations.add(right);
/*     */     
/* 107 */     this.source.subscribe(left);
/* 108 */     this.other.subscribe((Subscriber)right);
/* 109 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/* 114 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 115 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static interface JoinSupport<T>
/*     */     extends InnerProducer<T>
/*     */   {
/*     */     void innerError(Throwable param1Throwable);
/*     */ 
/*     */     
/*     */     void innerComplete(FluxGroupJoin.LeftRightSubscriber param1LeftRightSubscriber);
/*     */ 
/*     */     
/*     */     void innerValue(boolean param1Boolean, Object param1Object);
/*     */ 
/*     */     
/*     */     void innerClose(boolean param1Boolean, FluxGroupJoin.LeftRightEndSubscriber param1LeftRightEndSubscriber);
/*     */ 
/*     */     
/*     */     void innerCloseError(Throwable param1Throwable);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class GroupJoinSubscription<TLeft, TRight, TLeftEnd, TRightEnd, R>
/*     */     implements JoinSupport<R>
/*     */   {
/*     */     final Queue<Object> queue;
/*     */     
/*     */     final BiPredicate<Object, Object> queueBiOffer;
/*     */     
/*     */     final Disposable.Composite cancellations;
/*     */     
/*     */     final Map<Integer, Sinks.Many<TRight>> lefts;
/*     */     
/*     */     final Map<Integer, TRight> rights;
/*     */     
/*     */     final Function<? super TLeft, ? extends Publisher<TLeftEnd>> leftEnd;
/*     */     
/*     */     final Function<? super TRight, ? extends Publisher<TRightEnd>> rightEnd;
/*     */     final BiFunction<? super TLeft, ? super Flux<TRight>, ? extends R> resultSelector;
/*     */     final Supplier<? extends Queue<TRight>> processorQueueSupplier;
/*     */     final CoreSubscriber<? super R> actual;
/*     */     int leftIndex;
/*     */     int rightIndex;
/*     */     volatile int wip;
/* 160 */     static final AtomicIntegerFieldUpdater<GroupJoinSubscription> WIP = AtomicIntegerFieldUpdater.newUpdater(GroupJoinSubscription.class, "wip");
/*     */ 
/*     */     
/*     */     volatile int active;
/*     */     
/* 165 */     static final AtomicIntegerFieldUpdater<GroupJoinSubscription> ACTIVE = AtomicIntegerFieldUpdater.newUpdater(GroupJoinSubscription.class, "active");
/*     */ 
/*     */     
/*     */     volatile long requested;
/*     */ 
/*     */     
/* 171 */     static final AtomicLongFieldUpdater<GroupJoinSubscription> REQUESTED = AtomicLongFieldUpdater.newUpdater(GroupJoinSubscription.class, "requested");
/*     */ 
/*     */     
/*     */     volatile Throwable error;
/*     */ 
/*     */     
/* 177 */     static final AtomicReferenceFieldUpdater<GroupJoinSubscription, Throwable> ERROR = AtomicReferenceFieldUpdater.newUpdater(GroupJoinSubscription.class, Throwable.class, "error");
/*     */ 
/*     */ 
/*     */     
/* 181 */     static final Integer LEFT_VALUE = Integer.valueOf(1);
/*     */     
/* 183 */     static final Integer RIGHT_VALUE = Integer.valueOf(2);
/*     */     
/* 185 */     static final Integer LEFT_CLOSE = Integer.valueOf(3);
/*     */     
/* 187 */     static final Integer RIGHT_CLOSE = Integer.valueOf(4);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     GroupJoinSubscription(CoreSubscriber<? super R> actual, Function<? super TLeft, ? extends Publisher<TLeftEnd>> leftEnd, Function<? super TRight, ? extends Publisher<TRightEnd>> rightEnd, BiFunction<? super TLeft, ? super Flux<TRight>, ? extends R> resultSelector, Supplier<? extends Queue<TRight>> processorQueueSupplier) {
/* 195 */       this.actual = actual;
/* 196 */       this.cancellations = Disposables.composite();
/* 197 */       this.processorQueueSupplier = processorQueueSupplier;
/* 198 */       this.queue = Queues.unboundedMultiproducer().get();
/* 199 */       this.queueBiOffer = (BiPredicate)this.queue;
/* 200 */       this.lefts = new LinkedHashMap<>();
/* 201 */       this.rights = new LinkedHashMap<>();
/* 202 */       this.leftEnd = leftEnd;
/* 203 */       this.rightEnd = rightEnd;
/* 204 */       this.resultSelector = resultSelector;
/* 205 */       ACTIVE.lazySet(this, 2);
/*     */     }
/*     */ 
/*     */     
/*     */     public final CoreSubscriber<? super R> actual() {
/* 210 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public Stream<? extends Scannable> inners() {
/* 215 */       return Stream.concat(this.lefts
/* 216 */           .values().stream().map(Scannable::from), 
/* 217 */           Scannable.from(this.cancellations).inners());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 224 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf(this.requested); 
/* 225 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(this.cancellations.isDisposed()); 
/* 226 */       if (key == Scannable.Attr.BUFFERED) return Integer.valueOf(this.queue.size() / 2); 
/* 227 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf((this.active == 0)); 
/* 228 */       if (key == Scannable.Attr.ERROR) return this.error;
/*     */       
/* 230 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 235 */       if (Operators.validate(n)) {
/* 236 */         Operators.addCap(REQUESTED, this, n);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 242 */       if (this.cancellations.isDisposed()) {
/*     */         return;
/*     */       }
/* 245 */       this.cancellations.dispose();
/* 246 */       if (WIP.getAndIncrement(this) == 0) {
/* 247 */         this.queue.clear();
/*     */       }
/*     */     }
/*     */     
/*     */     void errorAll(Subscriber<?> a) {
/* 252 */       Throwable ex = Exceptions.terminate(ERROR, this);
/*     */       
/* 254 */       for (Sinks.Many<TRight> up : this.lefts.values()) {
/* 255 */         up.emitError(ex, Sinks.EmitFailureHandler.FAIL_FAST);
/*     */       }
/*     */       
/* 258 */       this.lefts.clear();
/* 259 */       this.rights.clear();
/*     */       
/* 261 */       a.onError(ex);
/*     */     }
/*     */     
/*     */     void drain() {
/* 265 */       if (WIP.getAndIncrement(this) != 0) {
/*     */         return;
/*     */       }
/*     */       
/* 269 */       int missed = 1;
/* 270 */       Queue<Object> q = this.queue;
/* 271 */       CoreSubscriber<? super R> coreSubscriber = this.actual;
/*     */ 
/*     */       
/*     */       while (true) {
/* 275 */         if (this.cancellations.isDisposed()) {
/* 276 */           q.clear();
/*     */           
/*     */           return;
/*     */         } 
/* 280 */         Throwable ex = this.error;
/* 281 */         if (ex != null) {
/* 282 */           q.clear();
/* 283 */           this.cancellations.dispose();
/* 284 */           errorAll((Subscriber<?>)coreSubscriber);
/*     */           
/*     */           return;
/*     */         } 
/* 288 */         boolean d = (this.active == 0);
/*     */         
/* 290 */         Integer mode = (Integer)q.poll();
/*     */         
/* 292 */         boolean empty = (mode == null);
/*     */         
/* 294 */         if (d && empty) {
/* 295 */           for (Sinks.Many<?> up : this.lefts.values()) {
/* 296 */             up.emitComplete(Sinks.EmitFailureHandler.FAIL_FAST);
/*     */           }
/*     */           
/* 299 */           this.lefts.clear();
/* 300 */           this.rights.clear();
/* 301 */           this.cancellations.dispose();
/*     */           
/* 303 */           coreSubscriber.onComplete();
/*     */           
/*     */           return;
/*     */         } 
/* 307 */         if (empty)
/*     */         
/*     */         { 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 438 */           missed = WIP.addAndGet(this, -missed);
/* 439 */           if (missed == 0)
/*     */             break;  continue; }  Object val = q.poll(); if (mode == LEFT_VALUE) { Publisher<TLeftEnd> p; R w; TLeft left = (TLeft)val; Sinks.Many<TRight> up = Sinks.unsafe().many().unicast().onBackpressureBuffer(this.processorQueueSupplier.get()); int idx = this.leftIndex++; this.lefts.put(Integer.valueOf(idx), up); try { p = Objects.<Publisher<TLeftEnd>>requireNonNull(this.leftEnd.apply(left), "The leftEnd returned a null Publisher"); } catch (Throwable exc) { Exceptions.addThrowable(ERROR, this, Operators.onOperatorError(this, exc, left, this.actual.currentContext())); errorAll((Subscriber<?>)coreSubscriber); return; }  FluxGroupJoin.LeftRightEndSubscriber end = new FluxGroupJoin.LeftRightEndSubscriber(this, true, idx); this.cancellations.add(end); p.subscribe((Subscriber)end); ex = this.error; if (ex != null) { this.cancellations.dispose(); q.clear(); errorAll((Subscriber<?>)coreSubscriber); return; }  try { w = Objects.requireNonNull(this.resultSelector.apply(left, up.asFlux()), "The resultSelector returned a null value"); } catch (Throwable exc) { Exceptions.addThrowable(ERROR, this, Operators.onOperatorError(this, exc, up, this.actual.currentContext())); errorAll((Subscriber<?>)coreSubscriber); return; }  long r = this.requested; if (r != 0L) { coreSubscriber.onNext(w); Operators.produced(REQUESTED, this, 1L); } else { Exceptions.addThrowable(ERROR, this, Exceptions.failWithOverflow()); errorAll((Subscriber<?>)coreSubscriber); return; }  for (TRight right : this.rights.values())
/*     */             up.emitNext(right, Sinks.EmitFailureHandler.FAIL_FAST);  continue; }  if (mode == RIGHT_VALUE) { Publisher<TRightEnd> p; TRight right = (TRight)val; int idx = this.rightIndex++; this.rights.put(Integer.valueOf(idx), right); try { p = Objects.<Publisher<TRightEnd>>requireNonNull(this.rightEnd.apply(right), "The rightEnd returned a null Publisher"); } catch (Throwable exc) { Publisher<TLeftEnd> publisher; Exceptions.addThrowable(ERROR, this, Operators.onOperatorError(this, (Throwable)publisher, right, this.actual.currentContext())); errorAll((Subscriber<?>)coreSubscriber); return; }  FluxGroupJoin.LeftRightEndSubscriber end = new FluxGroupJoin.LeftRightEndSubscriber(this, false, idx); this.cancellations.add(end); p.subscribe((Subscriber)end); ex = this.error; if (ex != null) { q.clear(); this.cancellations.dispose(); errorAll((Subscriber<?>)coreSubscriber); return; }  for (Sinks.Many<TRight> up : this.lefts.values())
/*     */             up.emitNext(right, Sinks.EmitFailureHandler.FAIL_FAST);  continue; }
/*     */          if (mode == LEFT_CLOSE) { FluxGroupJoin.LeftRightEndSubscriber end = (FluxGroupJoin.LeftRightEndSubscriber)val; Sinks.Many<TRight> up = this.lefts.remove(Integer.valueOf(end.index)); this.cancellations.remove(end); if (up != null)
/*     */             up.emitComplete(Sinks.EmitFailureHandler.FAIL_FAST);  continue; }
/*     */          if (mode == RIGHT_CLOSE) { FluxGroupJoin.LeftRightEndSubscriber end = (FluxGroupJoin.LeftRightEndSubscriber)val; this.rights.remove(Integer.valueOf(end.index)); this.cancellations.remove(end); }
/*     */       
/* 447 */       }  } public void innerError(Throwable ex) { if (Exceptions.addThrowable(ERROR, this, ex)) {
/* 448 */         ACTIVE.decrementAndGet(this);
/* 449 */         drain();
/*     */       } else {
/*     */         
/* 452 */         Operators.onErrorDropped(ex, this.actual.currentContext());
/*     */       }  }
/*     */ 
/*     */ 
/*     */     
/*     */     public void innerComplete(FluxGroupJoin.LeftRightSubscriber sender) {
/* 458 */       this.cancellations.remove(sender);
/* 459 */       ACTIVE.decrementAndGet(this);
/* 460 */       drain();
/*     */     }
/*     */ 
/*     */     
/*     */     public void innerValue(boolean isLeft, Object o) {
/* 465 */       this.queueBiOffer.test(isLeft ? LEFT_VALUE : RIGHT_VALUE, o);
/* 466 */       drain();
/*     */     }
/*     */ 
/*     */     
/*     */     public void innerClose(boolean isLeft, FluxGroupJoin.LeftRightEndSubscriber index) {
/* 471 */       this.queueBiOffer.test(isLeft ? LEFT_CLOSE : RIGHT_CLOSE, index);
/* 472 */       drain();
/*     */     }
/*     */ 
/*     */     
/*     */     public void innerCloseError(Throwable ex) {
/* 477 */       if (Exceptions.addThrowable(ERROR, this, ex)) {
/* 478 */         drain();
/*     */       } else {
/*     */         
/* 481 */         Operators.onErrorDropped(ex, this.actual.currentContext());
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static final class LeftRightSubscriber
/*     */     implements InnerConsumer<Object>, Disposable
/*     */   {
/*     */     final FluxGroupJoin.JoinSupport<?> parent;
/*     */     
/*     */     final boolean isLeft;
/*     */     
/*     */     volatile Subscription subscription;
/*     */     
/* 497 */     static final AtomicReferenceFieldUpdater<LeftRightSubscriber, Subscription> SUBSCRIPTION = AtomicReferenceFieldUpdater.newUpdater(LeftRightSubscriber.class, Subscription.class, "subscription");
/*     */ 
/*     */ 
/*     */     
/*     */     LeftRightSubscriber(FluxGroupJoin.JoinSupport<?> parent, boolean isLeft) {
/* 502 */       this.parent = parent;
/* 503 */       this.isLeft = isLeft;
/*     */     }
/*     */ 
/*     */     
/*     */     public void dispose() {
/* 508 */       Operators.terminate(SUBSCRIPTION, this);
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/* 513 */       return this.parent.actual().currentContext();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 519 */       if (key == Scannable.Attr.PARENT) return this.subscription; 
/* 520 */       if (key == Scannable.Attr.ACTUAL) return this.parent; 
/* 521 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(isDisposed()); 
/* 522 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 524 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isDisposed() {
/* 529 */       return (Operators.cancelledSubscription() == this.subscription);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 534 */       if (Operators.setOnce(SUBSCRIPTION, this, s)) {
/* 535 */         s.request(Long.MAX_VALUE);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(Object t) {
/* 541 */       this.parent.innerValue(this.isLeft, t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 546 */       this.parent.innerError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 551 */       this.parent.innerComplete(this);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static final class LeftRightEndSubscriber
/*     */     implements InnerConsumer<Object>, Disposable
/*     */   {
/*     */     final FluxGroupJoin.JoinSupport<?> parent;
/*     */     
/*     */     final boolean isLeft;
/*     */     
/*     */     final int index;
/*     */     
/*     */     volatile Subscription subscription;
/*     */     
/* 568 */     static final AtomicReferenceFieldUpdater<LeftRightEndSubscriber, Subscription> SUBSCRIPTION = AtomicReferenceFieldUpdater.newUpdater(LeftRightEndSubscriber.class, Subscription.class, "subscription");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     LeftRightEndSubscriber(FluxGroupJoin.JoinSupport<?> parent, boolean isLeft, int index) {
/* 574 */       this.parent = parent;
/* 575 */       this.isLeft = isLeft;
/* 576 */       this.index = index;
/*     */     }
/*     */ 
/*     */     
/*     */     public void dispose() {
/* 581 */       Operators.terminate(SUBSCRIPTION, this);
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 587 */       if (key == Scannable.Attr.PARENT) return this.subscription; 
/* 588 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(isDisposed()); 
/* 589 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 591 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isDisposed() {
/* 596 */       return (Operators.cancelledSubscription() == this.subscription);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 601 */       if (Operators.setOnce(SUBSCRIPTION, this, s)) {
/* 602 */         s.request(Long.MAX_VALUE);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(Object t) {
/* 608 */       if (Operators.terminate(SUBSCRIPTION, this)) {
/* 609 */         this.parent.innerClose(this.isLeft, this);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 615 */       this.parent.innerError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 620 */       this.parent.innerClose(this.isLeft, this);
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/* 625 */       return this.parent.actual().currentContext();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\FluxGroupJoin.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */