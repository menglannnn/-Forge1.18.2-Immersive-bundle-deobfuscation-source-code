/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Scannable;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class FluxErrorOnRequest<T>
/*    */   extends Flux<T>
/*    */   implements SourceProducer<T>
/*    */ {
/*    */   final Throwable error;
/*    */   
/*    */   FluxErrorOnRequest(Throwable error) {
/* 38 */     this.error = Objects.<Throwable>requireNonNull(error);
/*    */   }
/*    */ 
/*    */   
/*    */   public void subscribe(CoreSubscriber<? super T> actual) {
/* 43 */     actual.onSubscribe(new ErrorSubscription(actual, this.error));
/*    */   }
/*    */ 
/*    */   
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 48 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 49 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   static final class ErrorSubscription
/*    */     implements InnerProducer
/*    */   {
/*    */     final CoreSubscriber<?> actual;
/*    */     
/*    */     final Throwable error;
/*    */     volatile int once;
/* 60 */     static final AtomicIntegerFieldUpdater<ErrorSubscription> ONCE = AtomicIntegerFieldUpdater.newUpdater(ErrorSubscription.class, "once");
/*    */     
/*    */     ErrorSubscription(CoreSubscriber<?> actual, Throwable error) {
/* 63 */       this.actual = actual;
/* 64 */       this.error = error;
/*    */     }
/*    */ 
/*    */     
/*    */     public void request(long n) {
/* 69 */       if (Operators.validate(n) && 
/* 70 */         ONCE.compareAndSet(this, 0, 1)) {
/* 71 */         this.actual.onError(this.error);
/*    */       }
/*    */     }
/*    */ 
/*    */ 
/*    */     
/*    */     public void cancel() {
/* 78 */       this.once = 1;
/*    */     }
/*    */ 
/*    */     
/*    */     public CoreSubscriber actual() {
/* 83 */       return this.actual;
/*    */     }
/*    */ 
/*    */     
/*    */     @Nullable
/*    */     public Object scanUnsafe(Scannable.Attr key) {
/* 89 */       if (key == Scannable.Attr.ERROR) return this.error; 
/* 90 */       if (key == Scannable.Attr.CANCELLED || key == Scannable.Attr.TERMINATED)
/* 91 */         return Boolean.valueOf((this.once == 1)); 
/* 92 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*    */       
/* 94 */       return super.scanUnsafe(key);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\FluxErrorOnRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */