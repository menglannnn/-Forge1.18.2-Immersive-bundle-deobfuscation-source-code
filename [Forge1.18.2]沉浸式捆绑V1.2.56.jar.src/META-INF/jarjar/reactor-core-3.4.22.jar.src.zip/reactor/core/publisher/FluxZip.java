/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Objects;
/*     */ import java.util.Queue;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.stream.Stream;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxZip<T, R>
/*     */   extends Flux<R>
/*     */   implements SourceProducer<R>
/*     */ {
/*     */   final Publisher<? extends T>[] sources;
/*     */   final Iterable<? extends Publisher<? extends T>> sourcesIterable;
/*     */   final Function<? super Object[], ? extends R> zipper;
/*     */   final Supplier<? extends Queue<T>> queueSupplier;
/*     */   final int prefetch;
/*     */   
/*     */   <U> FluxZip(Publisher<? extends T> p1, Publisher<? extends U> p2, BiFunction<? super T, ? super U, ? extends R> zipper2, Supplier<? extends Queue<T>> queueSupplier, int prefetch) {
/*  71 */     this((Publisher<? extends T>[])new Publisher[] { Objects.<Publisher>requireNonNull(p1, "p1"), 
/*  72 */           Objects.<Publisher>requireNonNull(p2, "p2") }new PairwiseZipper<>(new BiFunction[] {
/*     */             
/*  74 */             Objects.<BiFunction>requireNonNull(zipper2, "zipper2") }), queueSupplier, prefetch);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   FluxZip(Publisher<? extends T>[] sources, Function<? super Object[], ? extends R> zipper, Supplier<? extends Queue<T>> queueSupplier, int prefetch) {
/*  83 */     if (prefetch <= 0) {
/*  84 */       throw new IllegalArgumentException("prefetch > 0 required but it was " + prefetch);
/*     */     }
/*  86 */     this.sources = Objects.<Publisher<? extends T>[]>requireNonNull(sources, "sources");
/*  87 */     if (sources.length == 0) {
/*  88 */       throw new IllegalArgumentException("at least one source is required");
/*     */     }
/*  90 */     this.sourcesIterable = null;
/*  91 */     this.zipper = Objects.<Function<? super Object[], ? extends R>>requireNonNull(zipper, "zipper");
/*  92 */     this.queueSupplier = Objects.<Supplier<? extends Queue<T>>>requireNonNull(queueSupplier, "queueSupplier");
/*  93 */     this.prefetch = prefetch;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   FluxZip(Iterable<? extends Publisher<? extends T>> sourcesIterable, Function<? super Object[], ? extends R> zipper, Supplier<? extends Queue<T>> queueSupplier, int prefetch) {
/* 100 */     if (prefetch <= 0) {
/* 101 */       throw new IllegalArgumentException("prefetch > 0 required but it was " + prefetch);
/*     */     }
/* 103 */     this.sources = null;
/* 104 */     this.sourcesIterable = Objects.<Iterable<? extends Publisher<? extends T>>>requireNonNull(sourcesIterable, "sourcesIterable");
/* 105 */     this.zipper = Objects.<Function<? super Object[], ? extends R>>requireNonNull(zipper, "zipper");
/* 106 */     this.queueSupplier = Objects.<Supplier<? extends Queue<T>>>requireNonNull(queueSupplier, "queueSupplier");
/* 107 */     this.prefetch = prefetch;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPrefetch() {
/* 112 */     return this.prefetch;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   FluxZip<T, R> zipAdditionalSource(Publisher source, BiFunction zipper) {
/* 118 */     Publisher<? extends T>[] arrayOfPublisher = this.sources;
/* 119 */     if (arrayOfPublisher != null && this.zipper instanceof PairwiseZipper) {
/* 120 */       int oldLen = arrayOfPublisher.length;
/* 121 */       Publisher[] arrayOfPublisher1 = new Publisher[oldLen + 1];
/* 122 */       System.arraycopy(arrayOfPublisher, 0, arrayOfPublisher1, 0, oldLen);
/* 123 */       arrayOfPublisher1[oldLen] = source;
/*     */       
/* 125 */       Function<Object[], R> z = ((PairwiseZipper)this.zipper).then(zipper);
/*     */       
/* 127 */       return new FluxZip((Publisher<? extends T>[])arrayOfPublisher1, z, this.queueSupplier, this.prefetch);
/*     */     } 
/* 129 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super R> actual) {
/* 134 */     Publisher<? extends T>[] srcs = this.sources;
/*     */     try {
/* 136 */       if (srcs != null) {
/* 137 */         handleArrayMode(actual, srcs);
/*     */       } else {
/*     */         
/* 140 */         handleIterableMode(actual, this.sourcesIterable);
/*     */       }
/*     */     
/* 143 */     } catch (Throwable e) {
/* 144 */       Operators.reportThrowInSubscribe(actual, e);
/*     */       return;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void handleIterableMode(CoreSubscriber<? super R> s, Iterable<? extends Publisher<? extends T>> sourcesIterable) {
/* 152 */     Object[] scalars = new Object[8];
/* 153 */     Publisher[] arrayOfPublisher = new Publisher[8];
/*     */     
/* 155 */     int n = 0;
/* 156 */     int sc = 0;
/*     */     
/* 158 */     for (Publisher<? extends T> p : sourcesIterable) {
/* 159 */       if (p == null) {
/* 160 */         Operators.error((Subscriber<?>)s, 
/* 161 */             Operators.onOperatorError(new NullPointerException("The sourcesIterable returned a null Publisher"), s
/*     */               
/* 163 */               .currentContext()));
/*     */         
/*     */         return;
/*     */       } 
/* 167 */       if (p instanceof Callable) {
/* 168 */         T v; Callable<T> callable = (Callable)p;
/*     */ 
/*     */ 
/*     */         
/*     */         try {
/* 173 */           v = callable.call();
/*     */         }
/* 175 */         catch (Throwable e) {
/* 176 */           Operators.error((Subscriber<?>)s, Operators.onOperatorError(e, s
/* 177 */                 .currentContext()));
/*     */           
/*     */           return;
/*     */         } 
/* 181 */         if (v == null) {
/* 182 */           Operators.complete((Subscriber<?>)s);
/*     */           
/*     */           return;
/*     */         } 
/* 186 */         if (n == scalars.length) {
/* 187 */           Object[] b = new Object[n + (n >> 1)];
/* 188 */           System.arraycopy(scalars, 0, b, 0, n);
/*     */           
/* 190 */           Publisher[] arrayOfPublisher1 = new Publisher[b.length];
/*     */           
/* 192 */           System.arraycopy(arrayOfPublisher, 0, arrayOfPublisher1, 0, n);
/*     */           
/* 194 */           scalars = b;
/* 195 */           arrayOfPublisher = arrayOfPublisher1;
/*     */         } 
/*     */         
/* 198 */         scalars[n] = v;
/* 199 */         sc++;
/*     */       } else {
/*     */         
/* 202 */         if (n == arrayOfPublisher.length) {
/* 203 */           Object[] b = new Object[n + (n >> 1)];
/* 204 */           System.arraycopy(scalars, 0, b, 0, n);
/*     */           
/* 206 */           Publisher[] arrayOfPublisher1 = new Publisher[b.length];
/*     */           
/* 208 */           System.arraycopy(arrayOfPublisher, 0, arrayOfPublisher1, 0, n);
/*     */           
/* 210 */           scalars = b;
/* 211 */           arrayOfPublisher = arrayOfPublisher1;
/*     */         } 
/* 213 */         arrayOfPublisher[n] = p;
/*     */       } 
/* 215 */       n++;
/*     */     } 
/*     */     
/* 218 */     if (n == 0) {
/* 219 */       Operators.complete((Subscriber<?>)s);
/*     */       
/*     */       return;
/*     */     } 
/* 223 */     if (n < scalars.length) {
/* 224 */       scalars = Arrays.copyOfRange(scalars, 0, n, (Class)scalars.getClass());
/*     */     }
/*     */     
/* 227 */     handleBoth(s, (Publisher<? extends T>[])arrayOfPublisher, scalars, n, sc);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void handleArrayMode(CoreSubscriber<? super R> s, Publisher<? extends T>[] srcs) {
/* 233 */     Object[] scalars = null;
/* 234 */     int n = srcs.length;
/*     */     
/* 236 */     int sc = 0;
/*     */     
/* 238 */     for (int j = 0; j < n; j++) {
/* 239 */       Publisher<? extends T> p = srcs[j];
/*     */       
/* 241 */       if (p == null) {
/* 242 */         Operators.error((Subscriber<?>)s, new NullPointerException("The sources contained a null Publisher"));
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/* 247 */       if (p instanceof Callable) {
/*     */         Object v;
/*     */         
/*     */         try {
/* 251 */           v = ((Callable)p).call();
/*     */         }
/* 253 */         catch (Throwable e) {
/* 254 */           Operators.error((Subscriber<?>)s, Operators.onOperatorError(e, s
/* 255 */                 .currentContext()));
/*     */           
/*     */           return;
/*     */         } 
/* 259 */         if (v == null) {
/* 260 */           Operators.complete((Subscriber<?>)s);
/*     */           
/*     */           return;
/*     */         } 
/* 264 */         if (scalars == null) {
/* 265 */           scalars = new Object[n];
/*     */         }
/*     */         
/* 268 */         scalars[j] = v;
/* 269 */         sc++;
/*     */       } 
/*     */     } 
/*     */     
/* 273 */     handleBoth(s, srcs, scalars, n, sc);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void handleBoth(CoreSubscriber<? super R> s, Publisher<? extends T>[] srcs, @Nullable Object[] scalars, int n, int sc) {
/* 297 */     if (sc != 0 && scalars != null) {
/* 298 */       if (n != sc) {
/* 299 */         ZipSingleCoordinator<T, R> coordinator = new ZipSingleCoordinator<>(s, scalars, n, this.zipper);
/*     */ 
/*     */         
/* 302 */         s.onSubscribe(coordinator);
/*     */         
/* 304 */         coordinator.subscribe(n, sc, srcs);
/*     */       } else {
/*     */         R r;
/* 307 */         Operators.MonoSubscriber<R, R> sds = new Operators.MonoSubscriber<>(s);
/*     */         
/* 309 */         s.onSubscribe(sds);
/*     */ 
/*     */ 
/*     */         
/*     */         try {
/* 314 */           r = Objects.requireNonNull(this.zipper.apply(scalars), "The zipper returned a null value");
/*     */         
/*     */         }
/* 317 */         catch (Throwable e) {
/* 318 */           s.onError(Operators.onOperatorError(e, s.currentContext()));
/*     */           
/*     */           return;
/*     */         } 
/* 322 */         sds.complete(r);
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 327 */       ZipCoordinator<T, R> coordinator = new ZipCoordinator<>(s, this.zipper, n, this.queueSupplier, this.prefetch);
/*     */ 
/*     */       
/* 330 */       s.onSubscribe(coordinator);
/*     */       
/* 332 */       coordinator.subscribe(srcs, n);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/* 338 */     if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(this.prefetch); 
/* 339 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 340 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   static final class ZipSingleCoordinator<T, R>
/*     */     extends Operators.MonoSubscriber<R, R>
/*     */   {
/*     */     final Function<? super Object[], ? extends R> zipper;
/*     */     
/*     */     final Object[] scalars;
/*     */     
/*     */     final FluxZip.ZipSingleSubscriber<T>[] subscribers;
/*     */     
/*     */     volatile int wip;
/* 354 */     static final AtomicIntegerFieldUpdater<ZipSingleCoordinator> WIP = AtomicIntegerFieldUpdater.newUpdater(ZipSingleCoordinator.class, "wip");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     ZipSingleCoordinator(CoreSubscriber<? super R> subscriber, Object[] scalars, int n, Function<? super Object[], ? extends R> zipper) {
/* 361 */       super(subscriber);
/* 362 */       this.zipper = zipper;
/* 363 */       this.scalars = scalars;
/* 364 */       FluxZip.ZipSingleSubscriber[] arrayOfZipSingleSubscriber = new FluxZip.ZipSingleSubscriber[n];
/* 365 */       for (int i = 0; i < n; i++) {
/* 366 */         if (scalars[i] == null) {
/* 367 */           arrayOfZipSingleSubscriber[i] = new FluxZip.ZipSingleSubscriber<>(this, i);
/*     */         }
/*     */       } 
/* 370 */       this.subscribers = (FluxZip.ZipSingleSubscriber<T>[])arrayOfZipSingleSubscriber;
/*     */     }
/*     */     
/*     */     void subscribe(int n, int sc, Publisher<? extends T>[] sources) {
/* 374 */       WIP.lazySet(this, n - sc);
/* 375 */       FluxZip.ZipSingleSubscriber<T>[] a = this.subscribers;
/* 376 */       for (int i = 0; i < n && 
/* 377 */         this.wip > 0 && !isCancelled(); i++) {
/*     */ 
/*     */         
/* 380 */         FluxZip.ZipSingleSubscriber<T> s = a[i];
/* 381 */         if (s != null) {
/*     */           try {
/* 383 */             sources[i].subscribe((Subscriber)s);
/*     */           }
/* 385 */           catch (Throwable e) {
/* 386 */             Operators.reportThrowInSubscribe(s, e);
/*     */           } 
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*     */     void next(T value, int index) {
/* 393 */       Object[] a = this.scalars;
/* 394 */       a[index] = value;
/* 395 */       if (WIP.decrementAndGet(this) == 0) {
/*     */         R r;
/*     */         
/*     */         try {
/* 399 */           r = Objects.requireNonNull(this.zipper.apply(a), "The zipper returned a null value");
/*     */         
/*     */         }
/* 402 */         catch (Throwable e) {
/* 403 */           this.actual.onError(Operators.onOperatorError(this, e, value, this.actual
/* 404 */                 .currentContext()));
/*     */           
/*     */           return;
/*     */         } 
/* 408 */         complete(r);
/*     */       } 
/*     */     }
/*     */     
/*     */     void error(Throwable e, int index) {
/* 413 */       if (WIP.getAndSet(this, 0) > 0) {
/* 414 */         cancelAll();
/* 415 */         this.actual.onError(e);
/*     */       } else {
/*     */         
/* 418 */         Operators.onErrorDropped(e, this.actual.currentContext());
/*     */       } 
/*     */     }
/*     */     
/*     */     void complete(int index) {
/* 423 */       if (WIP.getAndSet(this, 0) > 0) {
/* 424 */         cancelAll();
/* 425 */         this.actual.onComplete();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 431 */       super.cancel();
/* 432 */       cancelAll();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 438 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf((this.wip == 0)); 
/* 439 */       if (key == Scannable.Attr.BUFFERED) return Integer.valueOf((this.wip > 0) ? this.scalars.length : 0); 
/* 440 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 442 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public Stream<? extends Scannable> inners() {
/* 447 */       return Stream.of((Scannable[])this.subscribers);
/*     */     }
/*     */     
/*     */     void cancelAll() {
/* 451 */       for (FluxZip.ZipSingleSubscriber<T> s : this.subscribers) {
/* 452 */         if (s != null) {
/* 453 */           s.dispose();
/*     */         }
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class ZipSingleSubscriber<T>
/*     */     implements InnerConsumer<T>, Disposable
/*     */   {
/*     */     final FluxZip.ZipSingleCoordinator<T, ?> parent;
/*     */     
/*     */     final int index;
/*     */     
/*     */     volatile Subscription s;
/*     */     
/* 469 */     static final AtomicReferenceFieldUpdater<ZipSingleSubscriber, Subscription> S = AtomicReferenceFieldUpdater.newUpdater(ZipSingleSubscriber.class, Subscription.class, "s");
/*     */ 
/*     */     
/*     */     boolean done;
/*     */ 
/*     */     
/*     */     ZipSingleSubscriber(FluxZip.ZipSingleCoordinator<T, ?> parent, int index) {
/* 476 */       this.parent = parent;
/* 477 */       this.index = index;
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/* 482 */       return this.parent.currentContext();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 488 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 489 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 490 */       if (key == Scannable.Attr.ACTUAL) return this.parent; 
/* 491 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf((this.s == Operators.cancelledSubscription())); 
/* 492 */       if (key == Scannable.Attr.BUFFERED) return Integer.valueOf((this.parent.scalars[this.index] == null) ? 0 : 1); 
/* 493 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 495 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 500 */       if (Operators.setOnce(S, this, s)) {
/* 501 */         this.s = s;
/* 502 */         s.request(Long.MAX_VALUE);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 508 */       if (this.done) {
/* 509 */         Operators.onNextDropped(t, this.parent.currentContext());
/*     */         return;
/*     */       } 
/* 512 */       this.done = true;
/* 513 */       Operators.terminate(S, this);
/* 514 */       this.parent.next(t, this.index);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 519 */       if (this.done) {
/* 520 */         Operators.onErrorDropped(t, this.parent.currentContext());
/*     */         return;
/*     */       } 
/* 523 */       this.done = true;
/* 524 */       this.parent.error(t, this.index);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 529 */       if (this.done) {
/*     */         return;
/*     */       }
/* 532 */       this.done = true;
/* 533 */       this.parent.complete(this.index);
/*     */     }
/*     */ 
/*     */     
/*     */     public void dispose() {
/* 538 */       Operators.terminate(S, this);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class ZipCoordinator<T, R>
/*     */     implements InnerProducer<R>
/*     */   {
/*     */     final CoreSubscriber<? super R> actual;
/*     */     
/*     */     final FluxZip.ZipInner<T>[] subscribers;
/*     */     
/*     */     final Function<? super Object[], ? extends R> zipper;
/*     */     
/*     */     volatile int wip;
/*     */     
/* 554 */     static final AtomicIntegerFieldUpdater<ZipCoordinator> WIP = AtomicIntegerFieldUpdater.newUpdater(ZipCoordinator.class, "wip");
/*     */ 
/*     */     
/*     */     volatile long requested;
/*     */     
/* 559 */     static final AtomicLongFieldUpdater<ZipCoordinator> REQUESTED = AtomicLongFieldUpdater.newUpdater(ZipCoordinator.class, "requested");
/*     */ 
/*     */     
/*     */     volatile Throwable error;
/*     */     
/* 564 */     static final AtomicReferenceFieldUpdater<ZipCoordinator, Throwable> ERROR = AtomicReferenceFieldUpdater.newUpdater(ZipCoordinator.class, Throwable.class, "error");
/*     */ 
/*     */ 
/*     */     
/*     */     volatile boolean cancelled;
/*     */ 
/*     */ 
/*     */     
/*     */     final Object[] current;
/*     */ 
/*     */ 
/*     */     
/*     */     ZipCoordinator(CoreSubscriber<? super R> actual, Function<? super Object[], ? extends R> zipper, int n, Supplier<? extends Queue<T>> queueSupplier, int prefetch) {
/* 577 */       this.actual = actual;
/* 578 */       this.zipper = zipper;
/* 579 */       FluxZip.ZipInner[] arrayOfZipInner = new FluxZip.ZipInner[n];
/* 580 */       for (int i = 0; i < n; i++) {
/* 581 */         arrayOfZipInner[i] = new FluxZip.ZipInner<>(this, prefetch, i, queueSupplier);
/*     */       }
/* 583 */       this.current = new Object[n];
/* 584 */       this.subscribers = (FluxZip.ZipInner<T>[])arrayOfZipInner;
/*     */     }
/*     */     
/*     */     void subscribe(Publisher<? extends T>[] sources, int n) {
/* 588 */       FluxZip.ZipInner<T>[] a = this.subscribers;
/* 589 */       for (int i = 0; i < n; i++) {
/* 590 */         if (this.cancelled || this.error != null) {
/*     */           return;
/*     */         }
/* 593 */         FluxZip.ZipInner<T> s = a[i];
/*     */         try {
/* 595 */           sources[i].subscribe((Subscriber)s);
/*     */         }
/* 597 */         catch (Throwable e) {
/* 598 */           Operators.reportThrowInSubscribe(s, e);
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 605 */       if (Operators.validate(n)) {
/* 606 */         Operators.addCap(REQUESTED, this, n);
/* 607 */         drain();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 613 */       if (!this.cancelled) {
/* 614 */         this.cancelled = true;
/*     */         
/* 616 */         cancelAll();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super R> actual() {
/* 622 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public Stream<? extends Scannable> inners() {
/* 627 */       return Stream.of((Scannable[])this.subscribers);
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 633 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf(this.requested); 
/* 634 */       if (key == Scannable.Attr.ERROR) return this.error; 
/* 635 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(this.cancelled); 
/* 636 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 638 */       return super.scanUnsafe(key);
/*     */     }
/*     */     
/*     */     void error(Throwable e, int index) {
/* 642 */       if (Exceptions.addThrowable(ERROR, this, e)) {
/* 643 */         drain();
/*     */       } else {
/*     */         
/* 646 */         Operators.onErrorDropped(e, this.actual.currentContext());
/*     */       } 
/*     */     }
/*     */     
/*     */     void cancelAll() {
/* 651 */       for (FluxZip.ZipInner<T> s : this.subscribers) {
/* 652 */         s.cancel();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     void drain() {
/* 658 */       if (WIP.getAndIncrement(this) != 0) {
/*     */         return;
/*     */       }
/*     */       
/* 662 */       CoreSubscriber<? super R> a = this.actual;
/* 663 */       FluxZip.ZipInner<T>[] qs = this.subscribers;
/* 664 */       int n = qs.length;
/* 665 */       Object[] values = this.current;
/*     */       
/* 667 */       int missed = 1;
/*     */ 
/*     */       
/*     */       do {
/* 671 */         long r = this.requested;
/* 672 */         long e = 0L;
/*     */         
/* 674 */         while (r != e) {
/*     */           R v;
/* 676 */           if (this.cancelled) {
/*     */             return;
/*     */           }
/*     */           
/* 680 */           if (this.error != null) {
/* 681 */             cancelAll();
/*     */             
/* 683 */             Throwable ex = Exceptions.terminate(ERROR, this);
/*     */             
/* 685 */             a.onError(ex);
/*     */             
/*     */             return;
/*     */           } 
/*     */           
/* 690 */           boolean empty = false;
/*     */           
/* 692 */           for (int j = 0; j < n; j++) {
/* 693 */             FluxZip.ZipInner<T> inner = qs[j];
/* 694 */             if (values[j] == null) {
/*     */               try {
/* 696 */                 boolean d = inner.done;
/* 697 */                 Queue<T> q = inner.queue;
/*     */                 
/* 699 */                 E e1 = (q != null) ? (E)q.poll() : null;
/*     */                 
/* 701 */                 boolean sourceEmpty = (e1 == null);
/* 702 */                 if (d && sourceEmpty) {
/* 703 */                   cancelAll();
/*     */                   
/* 705 */                   a.onComplete();
/*     */                   return;
/*     */                 } 
/* 708 */                 if (!sourceEmpty) {
/* 709 */                   values[j] = e1;
/*     */                 } else {
/*     */                   
/* 712 */                   empty = true;
/*     */                 }
/*     */               
/* 715 */               } catch (Throwable ex) {
/* 716 */                 ex = Operators.onOperatorError(ex, this.actual
/* 717 */                     .currentContext());
/*     */                 
/* 719 */                 cancelAll();
/*     */                 
/* 721 */                 Exceptions.addThrowable(ERROR, this, ex);
/*     */                 
/* 723 */                 ex = Exceptions.terminate(ERROR, this);
/*     */                 
/* 725 */                 a.onError(ex);
/*     */                 
/*     */                 return;
/*     */               } 
/*     */             }
/*     */           } 
/*     */           
/* 732 */           if (empty) {
/*     */             break;
/*     */           }
/*     */ 
/*     */           
/*     */           try {
/* 738 */             v = Objects.requireNonNull(this.zipper.apply((Object[])values.clone()), "The zipper returned a null value");
/*     */           
/*     */           }
/* 741 */           catch (Throwable ex) {
/*     */             
/* 743 */             ex = Operators.onOperatorError(null, ex, values.clone(), this.actual
/* 744 */                 .currentContext());
/* 745 */             cancelAll();
/*     */             
/* 747 */             Exceptions.addThrowable(ERROR, this, ex);
/*     */             
/* 749 */             ex = Exceptions.terminate(ERROR, this);
/*     */             
/* 751 */             a.onError(ex);
/*     */             
/*     */             return;
/*     */           } 
/*     */           
/* 756 */           a.onNext(v);
/*     */           
/* 758 */           e++;
/*     */           
/* 760 */           Arrays.fill(values, (Object)null);
/*     */         } 
/*     */         
/* 763 */         if (r == e) {
/* 764 */           if (this.cancelled) {
/*     */             return;
/*     */           }
/*     */           
/* 768 */           if (this.error != null) {
/* 769 */             cancelAll();
/*     */             
/* 771 */             Throwable ex = Exceptions.terminate(ERROR, this);
/*     */             
/* 773 */             a.onError(ex);
/*     */             
/*     */             return;
/*     */           } 
/*     */           
/* 778 */           for (int j = 0; j < n; j++) {
/* 779 */             FluxZip.ZipInner<T> inner = qs[j];
/* 780 */             if (values[j] == null) {
/*     */               try {
/* 782 */                 boolean d = inner.done;
/* 783 */                 Queue<T> q = inner.queue;
/* 784 */                 E e1 = (q != null) ? (E)q.poll() : null;
/*     */                 
/* 786 */                 boolean empty = (e1 == null);
/* 787 */                 if (d && empty) {
/* 788 */                   cancelAll();
/*     */                   
/* 790 */                   a.onComplete();
/*     */                   return;
/*     */                 } 
/* 793 */                 if (!empty) {
/* 794 */                   values[j] = e1;
/*     */                 }
/*     */               }
/* 797 */               catch (Throwable ex) {
/* 798 */                 ex = Operators.onOperatorError(null, ex, values, this.actual
/* 799 */                     .currentContext());
/*     */                 
/* 801 */                 cancelAll();
/*     */                 
/* 803 */                 Exceptions.addThrowable(ERROR, this, ex);
/*     */                 
/* 805 */                 ex = Exceptions.terminate(ERROR, this);
/*     */                 
/* 807 */                 a.onError(ex);
/*     */ 
/*     */                 
/*     */                 return;
/*     */               } 
/*     */             }
/*     */           } 
/*     */         } 
/*     */         
/* 816 */         if (e != 0L) {
/*     */           
/* 818 */           for (int j = 0; j < n; j++) {
/* 819 */             FluxZip.ZipInner<T> inner = qs[j];
/* 820 */             inner.request(e);
/*     */           } 
/*     */           
/* 823 */           if (r != Long.MAX_VALUE) {
/* 824 */             REQUESTED.addAndGet(this, -e);
/*     */           }
/*     */         } 
/*     */         
/* 828 */         missed = WIP.addAndGet(this, -missed);
/* 829 */       } while (missed != 0);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static final class ZipInner<T>
/*     */     implements InnerConsumer<T>
/*     */   {
/*     */     final FluxZip.ZipCoordinator<T, ?> parent;
/*     */ 
/*     */     
/*     */     final int prefetch;
/*     */ 
/*     */     
/*     */     final int limit;
/*     */     
/*     */     final int index;
/*     */     
/*     */     final Supplier<? extends Queue<T>> queueSupplier;
/*     */     
/*     */     volatile Queue<T> queue;
/*     */     
/*     */     volatile Subscription s;
/*     */     
/* 854 */     static final AtomicReferenceFieldUpdater<ZipInner, Subscription> S = AtomicReferenceFieldUpdater.newUpdater(ZipInner.class, Subscription.class, "s");
/*     */ 
/*     */     
/*     */     long produced;
/*     */ 
/*     */     
/*     */     volatile boolean done;
/*     */ 
/*     */     
/*     */     int sourceMode;
/*     */ 
/*     */ 
/*     */     
/*     */     ZipInner(FluxZip.ZipCoordinator<T, ?> parent, int prefetch, int index, Supplier<? extends Queue<T>> queueSupplier) {
/* 868 */       this.parent = parent;
/* 869 */       this.prefetch = prefetch;
/* 870 */       this.index = index;
/* 871 */       this.queueSupplier = queueSupplier;
/* 872 */       this.limit = Operators.unboundedOrLimit(prefetch);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 878 */       if (Operators.setOnce(S, this, s)) {
/* 879 */         if (s instanceof Fuseable.QueueSubscription) {
/* 880 */           Fuseable.QueueSubscription<T> f = (Fuseable.QueueSubscription<T>)s;
/*     */           
/* 882 */           int m = f.requestFusion(7);
/*     */           
/* 884 */           if (m == 1) {
/* 885 */             this.sourceMode = 1;
/* 886 */             this.queue = (Queue<T>)f;
/* 887 */             this.done = true;
/* 888 */             this.parent.drain();
/*     */             return;
/*     */           } 
/* 891 */           if (m == 2) {
/* 892 */             this.sourceMode = 2;
/* 893 */             this.queue = (Queue<T>)f;
/*     */           } else {
/*     */             
/* 896 */             this.queue = this.queueSupplier.get();
/*     */           } 
/*     */         } else {
/*     */           
/* 900 */           this.queue = this.queueSupplier.get();
/*     */         } 
/* 902 */         s.request(Operators.unboundedOrPrefetch(this.prefetch));
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 908 */       if (this.sourceMode != 2 && 
/* 909 */         !this.queue.offer(t)) {
/* 910 */         onError(Operators.onOperatorError(this.s, 
/* 911 */               Exceptions.failWithOverflow("Queue is full: Reactive Streams source doesn't respect backpressure"), currentContext()));
/*     */         
/*     */         return;
/*     */       } 
/* 915 */       this.parent.drain();
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/* 920 */       return this.parent.actual.currentContext();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 925 */       if (this.done) {
/* 926 */         Operators.onErrorDropped(t, currentContext());
/*     */         return;
/*     */       } 
/* 929 */       this.done = true;
/* 930 */       this.parent.error(t, this.index);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 935 */       this.done = true;
/* 936 */       this.parent.drain();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 942 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 943 */       if (key == Scannable.Attr.ACTUAL) return this.parent; 
/* 944 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf((this.s == Operators.cancelledSubscription())); 
/* 945 */       if (key == Scannable.Attr.BUFFERED) return Integer.valueOf((this.queue != null) ? this.queue.size() : 0); 
/* 946 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf((this.done && (this.queue == null || this.queue.isEmpty()))); 
/* 947 */       if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(this.prefetch); 
/* 948 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 950 */       return null;
/*     */     }
/*     */     
/*     */     void cancel() {
/* 954 */       Operators.terminate(S, this);
/*     */     }
/*     */     
/*     */     void request(long n) {
/* 958 */       if (this.sourceMode != 1) {
/* 959 */         long p = this.produced + n;
/* 960 */         if (p >= this.limit) {
/* 961 */           this.produced = 0L;
/* 962 */           this.s.request(p);
/*     */         } else {
/*     */           
/* 965 */           this.produced = p;
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   static final class PairwiseZipper<R>
/*     */     implements Function<Object[], R>
/*     */   {
/*     */     final BiFunction[] zippers;
/*     */     
/*     */     PairwiseZipper(BiFunction[] zippers) {
/* 977 */       this.zippers = zippers;
/*     */     }
/*     */ 
/*     */     
/*     */     public R apply(Object[] args) {
/* 982 */       Object o = this.zippers[0].apply(args[0], args[1]);
/* 983 */       for (int i = 1; i < this.zippers.length; i++) {
/* 984 */         o = this.zippers[i].apply(o, args[i + 1]);
/*     */       }
/* 986 */       return (R)o;
/*     */     }
/*     */     
/*     */     public PairwiseZipper then(BiFunction zipper) {
/* 990 */       BiFunction[] zippers = this.zippers;
/* 991 */       int n = zippers.length;
/* 992 */       BiFunction[] newZippers = new BiFunction[n + 1];
/* 993 */       System.arraycopy(zippers, 0, newZippers, 0, n);
/* 994 */       newZippers[n] = zipper;
/*     */       
/* 996 */       return new PairwiseZipper(newZippers);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\FluxZip.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */