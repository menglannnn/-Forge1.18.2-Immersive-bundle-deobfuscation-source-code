/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.time.Duration;
/*    */ import java.util.Objects;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Fuseable;
/*    */ import reactor.core.Scannable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MonoJust<T>
/*    */   extends Mono<T>
/*    */   implements Fuseable.ScalarCallable<T>, Fuseable, SourceProducer<T>
/*    */ {
/*    */   final T value;
/*    */   
/*    */   MonoJust(T value) {
/* 35 */     this.value = Objects.requireNonNull(value, "value");
/*    */   }
/*    */ 
/*    */   
/*    */   public T call() throws Exception {
/* 40 */     return this.value;
/*    */   }
/*    */ 
/*    */   
/*    */   public T block(Duration m) {
/* 45 */     return this.value;
/*    */   }
/*    */ 
/*    */   
/*    */   public T block() {
/* 50 */     return this.value;
/*    */   }
/*    */ 
/*    */   
/*    */   public void subscribe(CoreSubscriber<? super T> actual) {
/* 55 */     actual.onSubscribe(Operators.scalarSubscription(actual, this.value));
/*    */   }
/*    */ 
/*    */   
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 60 */     if (key == Scannable.Attr.BUFFERED) return Integer.valueOf(1); 
/* 61 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 62 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\MonoJust.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */