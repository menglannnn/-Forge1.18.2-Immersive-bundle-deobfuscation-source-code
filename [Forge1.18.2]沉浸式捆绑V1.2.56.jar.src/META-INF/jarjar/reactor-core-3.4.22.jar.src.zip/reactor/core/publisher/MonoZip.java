/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.Function;
/*     */ import java.util.stream.Stream;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MonoZip<T, R>
/*     */   extends Mono<R>
/*     */   implements SourceProducer<R>
/*     */ {
/*     */   final boolean delayError;
/*     */   final Publisher<?>[] sources;
/*     */   final Iterable<? extends Publisher<?>> sourcesIterable;
/*     */   final Function<? super Object[], ? extends R> zipper;
/*     */   
/*     */   <U> MonoZip(boolean delayError, Publisher<? extends T> p1, Publisher<? extends U> p2, BiFunction<? super T, ? super U, ? extends R> zipper2) {
/*  55 */     this(delayError, new FluxZip.PairwiseZipper<>(new BiFunction[] {
/*     */             
/*  57 */             Objects.<BiFunction>requireNonNull(zipper2, "zipper2") }), (Publisher<?>[])new Publisher[] {
/*  58 */           Objects.<Publisher>requireNonNull(p1, "p1"), 
/*  59 */           Objects.<Publisher>requireNonNull(p2, "p2")
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   MonoZip(boolean delayError, Function<? super Object[], ? extends R> zipper, Publisher<?>... sources) {
/*  65 */     this.delayError = delayError;
/*  66 */     this.zipper = Objects.<Function<? super Object[], ? extends R>>requireNonNull(zipper, "zipper");
/*  67 */     this.sources = (Publisher<?>[])Objects.requireNonNull(sources, "sources");
/*  68 */     this.sourcesIterable = null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   MonoZip(boolean delayError, Function<? super Object[], ? extends R> zipper, Iterable<? extends Publisher<?>> sourcesIterable) {
/*  74 */     this.delayError = delayError;
/*  75 */     this.zipper = Objects.<Function<? super Object[], ? extends R>>requireNonNull(zipper, "zipper");
/*  76 */     this.sources = null;
/*  77 */     this.sourcesIterable = Objects.<Iterable<? extends Publisher<?>>>requireNonNull(sourcesIterable, "sourcesIterable");
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   Mono<R> zipAdditionalSource(Publisher source, BiFunction zipper) {
/*  83 */     Publisher<?>[] arrayOfPublisher = this.sources;
/*  84 */     if (arrayOfPublisher != null && this.zipper instanceof FluxZip.PairwiseZipper) {
/*  85 */       int oldLen = arrayOfPublisher.length;
/*  86 */       Publisher[] arrayOfPublisher1 = new Publisher[oldLen + 1];
/*  87 */       System.arraycopy(arrayOfPublisher, 0, arrayOfPublisher1, 0, oldLen);
/*  88 */       arrayOfPublisher1[oldLen] = source;
/*     */ 
/*     */       
/*  91 */       Function<Object[], R> z = ((FluxZip.PairwiseZipper)this.zipper).then(zipper);
/*     */       
/*  93 */       return new MonoZip(this.delayError, z, (Publisher<?>[])arrayOfPublisher1);
/*     */     } 
/*  95 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super R> actual) {
/*     */     Publisher[] arrayOfPublisher;
/* 102 */     int n = 0;
/* 103 */     if (this.sources != null) {
/* 104 */       Publisher<?>[] a = this.sources;
/* 105 */       n = a.length;
/*     */     } else {
/*     */       
/* 108 */       arrayOfPublisher = new Publisher[8];
/* 109 */       for (Publisher<?> m : this.sourcesIterable) {
/* 110 */         if (n == arrayOfPublisher.length) {
/* 111 */           Publisher[] arrayOfPublisher1 = new Publisher[n + (n >> 2)];
/* 112 */           System.arraycopy(arrayOfPublisher, 0, arrayOfPublisher1, 0, n);
/* 113 */           arrayOfPublisher = arrayOfPublisher1;
/*     */         } 
/* 115 */         arrayOfPublisher[n++] = m;
/*     */       } 
/*     */     } 
/*     */     
/* 119 */     if (n == 0) {
/* 120 */       Operators.complete((Subscriber<?>)actual);
/*     */       
/*     */       return;
/*     */     } 
/* 124 */     ZipCoordinator<R> parent = new ZipCoordinator<>(actual, n, this.delayError, this.zipper);
/* 125 */     actual.onSubscribe(parent);
/* 126 */     ZipInner<R>[] subs = parent.subscribers;
/* 127 */     for (int i = 0; i < n; i++) {
/* 128 */       arrayOfPublisher[i].subscribe((Subscriber)subs[i]);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/* 134 */     if (key == Scannable.Attr.DELAY_ERROR) return Boolean.valueOf(this.delayError); 
/* 135 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 136 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   static final class ZipCoordinator<R>
/*     */     extends Operators.MonoSubscriber<Object, R>
/*     */   {
/*     */     final MonoZip.ZipInner<R>[] subscribers;
/*     */     
/*     */     final boolean delayError;
/*     */     
/*     */     final Function<? super Object[], ? extends R> zipper;
/*     */     
/*     */     volatile int done;
/* 150 */     static final AtomicIntegerFieldUpdater<ZipCoordinator> DONE = AtomicIntegerFieldUpdater.newUpdater(ZipCoordinator.class, "done");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     ZipCoordinator(CoreSubscriber<? super R> subscriber, int n, boolean delayError, Function<? super Object[], ? extends R> zipper) {
/* 157 */       super(subscriber);
/* 158 */       this.delayError = delayError;
/* 159 */       this.zipper = zipper;
/* 160 */       this.subscribers = (MonoZip.ZipInner<R>[])new MonoZip.ZipInner[n];
/* 161 */       for (int i = 0; i < n; i++) {
/* 162 */         this.subscribers[i] = new MonoZip.ZipInner<>(this);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 169 */       if (key == Scannable.Attr.TERMINATED) {
/* 170 */         return Boolean.valueOf((this.done == this.subscribers.length));
/*     */       }
/* 172 */       if (key == Scannable.Attr.BUFFERED) {
/* 173 */         return Integer.valueOf(this.subscribers.length);
/*     */       }
/* 175 */       if (key == Scannable.Attr.DELAY_ERROR) {
/* 176 */         return Boolean.valueOf(this.delayError);
/*     */       }
/* 178 */       if (key == Scannable.Attr.RUN_STYLE) {
/* 179 */         return Scannable.Attr.RunStyle.SYNC;
/*     */       }
/*     */       
/* 182 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public Stream<? extends Scannable> inners() {
/* 187 */       return Stream.of((Scannable[])this.subscribers);
/*     */     }
/*     */ 
/*     */     
/*     */     void signal() {
/* 192 */       MonoZip.ZipInner<R>[] a = this.subscribers;
/* 193 */       int n = a.length;
/* 194 */       if (DONE.incrementAndGet(this) != n) {
/*     */         return;
/*     */       }
/*     */       
/* 198 */       Object[] o = new Object[n];
/* 199 */       Throwable error = null;
/* 200 */       Throwable compositeError = null;
/* 201 */       boolean hasEmpty = false;
/*     */       
/* 203 */       for (int i = 0; i < a.length; i++) {
/* 204 */         MonoZip.ZipInner<R> m = a[i];
/* 205 */         Object v = m.value;
/* 206 */         if (v != null) {
/* 207 */           o[i] = v;
/*     */         } else {
/*     */           
/* 210 */           Throwable e = m.error;
/* 211 */           if (e != null) {
/* 212 */             if (compositeError != null) {
/*     */               
/* 214 */               compositeError.addSuppressed(e);
/*     */             }
/* 216 */             else if (error != null) {
/* 217 */               compositeError = Exceptions.multiple(new Throwable[] { error, e });
/*     */             } else {
/*     */               
/* 220 */               error = e;
/*     */             } 
/*     */           } else {
/*     */             
/* 224 */             hasEmpty = true;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 229 */       if (compositeError != null) {
/* 230 */         this.actual.onError(compositeError);
/*     */       }
/* 232 */       else if (error != null) {
/* 233 */         this.actual.onError(error);
/*     */       }
/* 235 */       else if (hasEmpty) {
/* 236 */         this.actual.onComplete();
/*     */       } else {
/*     */         R r;
/*     */         
/*     */         try {
/* 241 */           r = Objects.requireNonNull(this.zipper.apply(o), "zipper produced a null value");
/*     */         
/*     */         }
/* 244 */         catch (Throwable t) {
/* 245 */           this.actual.onError(Operators.onOperatorError(null, t, o, this.actual
/*     */ 
/*     */                 
/* 248 */                 .currentContext()));
/*     */           return;
/*     */         } 
/* 251 */         complete(r);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 257 */       if (!isCancelled()) {
/* 258 */         super.cancel();
/* 259 */         for (MonoZip.ZipInner<R> ms : this.subscribers) {
/* 260 */           ms.cancel();
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*     */     void cancelExcept(MonoZip.ZipInner<R> source) {
/* 266 */       if (!isCancelled()) {
/* 267 */         super.cancel();
/* 268 */         for (MonoZip.ZipInner<R> ms : this.subscribers) {
/* 269 */           if (ms != source) {
/* 270 */             ms.cancel();
/*     */           }
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class ZipInner<R>
/*     */     implements InnerConsumer<Object>
/*     */   {
/*     */     final MonoZip.ZipCoordinator<R> parent;
/*     */     
/*     */     volatile Subscription s;
/* 284 */     static final AtomicReferenceFieldUpdater<ZipInner, Subscription> S = AtomicReferenceFieldUpdater.newUpdater(ZipInner.class, Subscription.class, "s");
/*     */     
/*     */     Object value;
/*     */     
/*     */     Throwable error;
/*     */ 
/*     */     
/*     */     ZipInner(MonoZip.ZipCoordinator<R> parent) {
/* 292 */       this.parent = parent;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 298 */       if (key == Scannable.Attr.CANCELLED) {
/* 299 */         return Boolean.valueOf((this.s == Operators.cancelledSubscription()));
/*     */       }
/* 301 */       if (key == Scannable.Attr.PARENT) {
/* 302 */         return this.s;
/*     */       }
/* 304 */       if (key == Scannable.Attr.ACTUAL) {
/* 305 */         return this.parent;
/*     */       }
/* 307 */       if (key == Scannable.Attr.ERROR) {
/* 308 */         return this.error;
/*     */       }
/* 310 */       if (key == Scannable.Attr.RUN_STYLE) {
/* 311 */         return Scannable.Attr.RunStyle.SYNC;
/*     */       }
/*     */       
/* 314 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/* 319 */       return this.parent.currentContext();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 324 */       if (Operators.setOnce(S, this, s)) {
/* 325 */         s.request(Long.MAX_VALUE);
/*     */       } else {
/*     */         
/* 328 */         s.cancel();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(Object t) {
/* 334 */       if (this.value == null) {
/* 335 */         this.value = t;
/* 336 */         this.parent.signal();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 342 */       this.error = t;
/* 343 */       if (this.parent.delayError) {
/* 344 */         this.parent.signal();
/*     */       } else {
/*     */         
/* 347 */         int n = this.parent.subscribers.length;
/* 348 */         if (MonoZip.ZipCoordinator.DONE.getAndSet(this.parent, n) != n) {
/* 349 */           this.parent.cancelExcept(this);
/* 350 */           this.parent.actual.onError(t);
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 357 */       if (this.value == null) {
/* 358 */         if (this.parent.delayError) {
/* 359 */           this.parent.signal();
/*     */         } else {
/*     */           
/* 362 */           int n = this.parent.subscribers.length;
/* 363 */           if (MonoZip.ZipCoordinator.DONE.getAndSet(this.parent, n) != n) {
/* 364 */             this.parent.cancelExcept(this);
/* 365 */             this.parent.actual.onComplete();
/*     */           } 
/*     */         } 
/*     */       }
/*     */     }
/*     */     
/*     */     void cancel() {
/* 372 */       Operators.terminate(S, this);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\MonoZip.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */