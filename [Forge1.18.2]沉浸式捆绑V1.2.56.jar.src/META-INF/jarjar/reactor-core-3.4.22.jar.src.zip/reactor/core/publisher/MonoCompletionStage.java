/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import java.util.concurrent.CompletionStage;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Exceptions;
/*    */ import reactor.core.Fuseable;
/*    */ import reactor.core.Scannable;
/*    */ import reactor.util.context.Context;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MonoCompletionStage<T>
/*    */   extends Mono<T>
/*    */   implements Fuseable, Scannable
/*    */ {
/*    */   final CompletionStage<? extends T> future;
/*    */   
/*    */   MonoCompletionStage(CompletionStage<? extends T> future) {
/* 44 */     this.future = Objects.<CompletionStage<? extends T>>requireNonNull(future, "future");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void subscribe(CoreSubscriber<? super T> actual) {
/* 50 */     Operators.MonoSubscriber<T, T> sds = new Operators.MonoSubscriber<>(actual);
/*    */     
/* 52 */     actual.onSubscribe(sds);
/*    */     
/* 54 */     if (sds.isCancelled()) {
/*    */       return;
/*    */     }
/*    */     
/* 58 */     this.future.whenComplete((v, e) -> {
/*    */           if (sds.isCancelled()) {
/*    */             Context ctx = sds.currentContext();
/*    */ 
/*    */ 
/*    */             
/*    */             if (e == null || e instanceof java.util.concurrent.CancellationException) {
/*    */               Operators.onDiscard(v, ctx);
/*    */             } else {
/*    */               Operators.onErrorDropped(e, ctx);
/*    */ 
/*    */ 
/*    */               
/*    */               Operators.onDiscard(v, ctx);
/*    */             } 
/*    */ 
/*    */             
/*    */             return;
/*    */           } 
/*    */ 
/*    */           
/*    */           try {
/*    */             if (e instanceof java.util.concurrent.CompletionException) {
/*    */               actual.onError(e.getCause());
/*    */             } else if (e != null) {
/*    */               actual.onError(e);
/*    */             } else if (v != null) {
/*    */               sds.complete(v);
/*    */             } else {
/*    */               actual.onComplete();
/*    */             } 
/* 89 */           } catch (Throwable e1) {
/*    */             Operators.onErrorDropped(e1, actual.currentContext());
/*    */             throw Exceptions.bubble(e1);
/*    */           } 
/*    */         });
/*    */   }
/*    */ 
/*    */   
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 98 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.ASYNC; 
/* 99 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.22.jar!\reactor\core\publisher\MonoCompletionStage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */