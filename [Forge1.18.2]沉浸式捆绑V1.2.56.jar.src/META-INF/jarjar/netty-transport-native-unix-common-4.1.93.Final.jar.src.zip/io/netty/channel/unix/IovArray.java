/*     */ package io.netty.channel.unix;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.buffer.Unpooled;
/*     */ import io.netty.channel.ChannelOutboundBuffer;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import io.netty.util.internal.PlatformDependent;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class IovArray
/*     */   implements ChannelOutboundBuffer.MessageProcessor
/*     */ {
/*  51 */   private static final int ADDRESS_SIZE = Buffer.addressSize();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  57 */   public static final int IOV_SIZE = 2 * ADDRESS_SIZE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  63 */   private static final int MAX_CAPACITY = Limits.IOV_MAX * IOV_SIZE;
/*     */   
/*     */   private final long memoryAddress;
/*     */   private final ByteBuf memory;
/*     */   private int count;
/*     */   private long size;
/*  69 */   private long maxBytes = Limits.SSIZE_MAX;
/*     */   
/*     */   public IovArray() {
/*  72 */     this(Unpooled.wrappedBuffer(Buffer.allocateDirectWithNativeOrder(MAX_CAPACITY)).setIndex(0, 0));
/*     */   }
/*     */ 
/*     */   
/*     */   public IovArray(ByteBuf memory) {
/*  77 */     assert memory.writerIndex() == 0;
/*  78 */     assert memory.readerIndex() == 0;
/*  79 */     this.memory = PlatformDependent.hasUnsafe() ? memory : memory.order(PlatformDependent.BIG_ENDIAN_NATIVE_ORDER ? ByteOrder.BIG_ENDIAN : ByteOrder.LITTLE_ENDIAN);
/*     */     
/*  81 */     if (memory.hasMemoryAddress()) {
/*  82 */       this.memoryAddress = memory.memoryAddress();
/*     */     } else {
/*     */       
/*  85 */       this.memoryAddress = Buffer.memoryAddress(memory.internalNioBuffer(0, memory.capacity()));
/*     */     } 
/*     */   }
/*     */   
/*     */   public void clear() {
/*  90 */     this.count = 0;
/*  91 */     this.size = 0L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public boolean add(ByteBuf buf) {
/*  99 */     return add(buf, buf.readerIndex(), buf.readableBytes());
/*     */   }
/*     */   
/*     */   public boolean add(ByteBuf buf, int offset, int len) {
/* 103 */     if (this.count == Limits.IOV_MAX)
/*     */     {
/* 105 */       return false;
/*     */     }
/* 107 */     if (buf.nioBufferCount() == 1) {
/* 108 */       if (len == 0) {
/* 109 */         return true;
/*     */       }
/* 111 */       if (buf.hasMemoryAddress()) {
/* 112 */         return add(this.memoryAddress, buf.memoryAddress() + offset, len);
/*     */       }
/* 114 */       ByteBuffer nioBuffer = buf.internalNioBuffer(offset, len);
/* 115 */       return add(this.memoryAddress, Buffer.memoryAddress(nioBuffer) + nioBuffer.position(), len);
/*     */     } 
/*     */     
/* 118 */     ByteBuffer[] buffers = buf.nioBuffers(offset, len);
/* 119 */     for (ByteBuffer nioBuffer : buffers) {
/* 120 */       int remaining = nioBuffer.remaining();
/* 121 */       if (remaining != 0 && (
/* 122 */         !add(this.memoryAddress, Buffer.memoryAddress(nioBuffer) + nioBuffer.position(), remaining) || this.count == Limits.IOV_MAX))
/*     */       {
/* 124 */         return false;
/*     */       }
/*     */     } 
/* 127 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean add(long memoryAddress, long addr, int len) {
/* 132 */     assert addr != 0L;
/*     */ 
/*     */ 
/*     */     
/* 136 */     if ((this.maxBytes - len < this.size && this.count > 0) || this.memory
/*     */       
/* 138 */       .capacity() < (this.count + 1) * IOV_SIZE)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 145 */       return false;
/*     */     }
/* 147 */     int baseOffset = idx(this.count);
/* 148 */     int lengthOffset = baseOffset + ADDRESS_SIZE;
/*     */     
/* 150 */     this.size += len;
/* 151 */     this.count++;
/*     */     
/* 153 */     if (ADDRESS_SIZE == 8) {
/*     */       
/* 155 */       if (PlatformDependent.hasUnsafe()) {
/* 156 */         PlatformDependent.putLong(baseOffset + memoryAddress, addr);
/* 157 */         PlatformDependent.putLong(lengthOffset + memoryAddress, len);
/*     */       } else {
/* 159 */         this.memory.setLong(baseOffset, addr);
/* 160 */         this.memory.setLong(lengthOffset, len);
/*     */       } 
/*     */     } else {
/* 163 */       assert ADDRESS_SIZE == 4;
/* 164 */       if (PlatformDependent.hasUnsafe()) {
/* 165 */         PlatformDependent.putInt(baseOffset + memoryAddress, (int)addr);
/* 166 */         PlatformDependent.putInt(lengthOffset + memoryAddress, len);
/*     */       } else {
/* 168 */         this.memory.setInt(baseOffset, (int)addr);
/* 169 */         this.memory.setInt(lengthOffset, len);
/*     */       } 
/*     */     } 
/* 172 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int count() {
/* 179 */     return this.count;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long size() {
/* 186 */     return this.size;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void maxBytes(long maxBytes) {
/* 200 */     this.maxBytes = Math.min(Limits.SSIZE_MAX, ObjectUtil.checkPositive(maxBytes, "maxBytes"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long maxBytes() {
/* 208 */     return this.maxBytes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long memoryAddress(int offset) {
/* 215 */     return this.memoryAddress + idx(offset);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void release() {
/* 222 */     this.memory.release();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean processMessage(Object msg) throws Exception {
/* 227 */     if (msg instanceof ByteBuf) {
/* 228 */       ByteBuf buffer = (ByteBuf)msg;
/* 229 */       return add(buffer, buffer.readerIndex(), buffer.readableBytes());
/*     */     } 
/* 231 */     return false;
/*     */   }
/*     */   
/*     */   private static int idx(int index) {
/* 235 */     return IOV_SIZE * index;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-transport-native-unix-common-4.1.93.Final.jar!\io\netty\channe\\unix\IovArray.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */