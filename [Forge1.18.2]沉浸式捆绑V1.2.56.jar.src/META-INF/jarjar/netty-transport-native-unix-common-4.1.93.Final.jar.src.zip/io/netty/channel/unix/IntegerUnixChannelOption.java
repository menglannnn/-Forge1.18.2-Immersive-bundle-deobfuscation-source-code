/*    */ package io.netty.channel.unix;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class IntegerUnixChannelOption
/*    */   extends GenericUnixChannelOption<Integer>
/*    */ {
/*    */   public IntegerUnixChannelOption(String name, int level, int optname) {
/* 30 */     super(name, level, optname);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-transport-native-unix-common-4.1.93.Final.jar!\io\netty\channe\\unix\IntegerUnixChannelOption.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */