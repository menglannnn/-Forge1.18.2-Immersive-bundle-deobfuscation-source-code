package io.netty.channel.unix;

final class LimitsStaticallyReferencedJniMethods {
  static native long ssizeMax();
  
  static native int iovMax();
  
  static native int uioMaxIov();
  
  static native int sizeOfjlong();
  
  static native int udsSunPathSize();
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-transport-native-unix-common-4.1.93.Final.jar!\io\netty\channe\\unix\LimitsStaticallyReferencedJniMethods.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */