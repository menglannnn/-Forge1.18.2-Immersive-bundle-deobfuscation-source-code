/*    */ package io.netty.channel.unix;
/*    */ 
/*    */ import io.netty.util.CharsetUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DomainDatagramSocketAddress
/*    */   extends DomainSocketAddress
/*    */ {
/*    */   private static final long serialVersionUID = -5925732678737768223L;
/*    */   private final DomainDatagramSocketAddress localAddress;
/*    */   private final int receivedAmount;
/*    */   
/*    */   public DomainDatagramSocketAddress(byte[] socketPath, int receivedAmount, DomainDatagramSocketAddress localAddress) {
/* 36 */     super(new String(socketPath, CharsetUtil.UTF_8));
/* 37 */     this.localAddress = localAddress;
/* 38 */     this.receivedAmount = receivedAmount;
/*    */   }
/*    */   
/*    */   public DomainDatagramSocketAddress localAddress() {
/* 42 */     return this.localAddress;
/*    */   }
/*    */   
/*    */   public int receivedAmount() {
/* 46 */     return this.receivedAmount;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-transport-native-unix-common-4.1.93.Final.jar!\io\netty\channe\\unix\DomainDatagramSocketAddress.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */