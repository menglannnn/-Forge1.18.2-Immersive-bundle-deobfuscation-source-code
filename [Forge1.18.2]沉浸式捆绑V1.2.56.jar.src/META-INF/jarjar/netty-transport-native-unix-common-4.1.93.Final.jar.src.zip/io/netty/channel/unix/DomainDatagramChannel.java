package io.netty.channel.unix;

import io.netty.channel.Channel;

public interface DomainDatagramChannel extends UnixChannel, Channel {
  DomainDatagramChannelConfig config();
  
  boolean isConnected();
  
  DomainSocketAddress localAddress();
  
  DomainSocketAddress remoteAddress();
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-transport-native-unix-common-4.1.93.Final.jar!\io\netty\channe\\unix\DomainDatagramChannel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */