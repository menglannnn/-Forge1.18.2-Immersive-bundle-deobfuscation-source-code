/*     */ package io.netty.channel.unix;
/*     */ 
/*     */ import io.netty.channel.ChannelException;
/*     */ import io.netty.channel.socket.InternetProtocolFamily;
/*     */ import io.netty.util.CharsetUtil;
/*     */ import io.netty.util.NetUtil;
/*     */ import java.io.IOException;
/*     */ import java.net.Inet6Address;
/*     */ import java.net.InetAddress;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.PortUnreachableException;
/*     */ import java.net.SocketAddress;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.channels.ClosedChannelException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Socket
/*     */   extends FileDescriptor
/*     */ {
/*     */   private static volatile boolean isIpv6Preferred;
/*     */   @Deprecated
/*     */   public static final int UDS_SUN_PATH_SIZE = 100;
/*     */   protected final boolean ipv6;
/*     */   
/*     */   public Socket(int fd) {
/*  56 */     super(fd);
/*  57 */     this.ipv6 = isIPv6(fd);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean useIpv6(InetAddress address) {
/*  63 */     return useIpv6(this, address);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static boolean useIpv6(Socket socket, InetAddress address) {
/*  71 */     return (socket.ipv6 || address instanceof Inet6Address);
/*     */   }
/*     */   
/*     */   public final void shutdown() throws IOException {
/*  75 */     shutdown(true, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void shutdown(boolean read, boolean write) throws IOException {
/*     */     int oldState, newState;
/*     */     do {
/*  84 */       oldState = this.state;
/*  85 */       if (isClosed(oldState)) {
/*  86 */         throw new ClosedChannelException();
/*     */       }
/*  88 */       newState = oldState;
/*  89 */       if (read && !isInputShutdown(newState)) {
/*  90 */         newState = inputShutdown(newState);
/*     */       }
/*  92 */       if (write && !isOutputShutdown(newState)) {
/*  93 */         newState = outputShutdown(newState);
/*     */       }
/*     */ 
/*     */       
/*  97 */       if (newState == oldState) {
/*     */         return;
/*     */       }
/* 100 */     } while (!casState(oldState, newState));
/*     */ 
/*     */ 
/*     */     
/* 104 */     int res = shutdown(this.fd, read, write);
/* 105 */     if (res < 0) {
/* 106 */       Errors.ioResult("shutdown", res);
/*     */     }
/*     */   }
/*     */   
/*     */   public final boolean isShutdown() {
/* 111 */     int state = this.state;
/* 112 */     return (isInputShutdown(state) && isOutputShutdown(state));
/*     */   }
/*     */   
/*     */   public final boolean isInputShutdown() {
/* 116 */     return isInputShutdown(this.state);
/*     */   }
/*     */   
/*     */   public final boolean isOutputShutdown() {
/* 120 */     return isOutputShutdown(this.state);
/*     */   }
/*     */   
/*     */   public final int sendTo(ByteBuffer buf, int pos, int limit, InetAddress addr, int port) throws IOException {
/* 124 */     return sendTo(buf, pos, limit, addr, port, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int sendTo(ByteBuffer buf, int pos, int limit, InetAddress addr, int port, boolean fastOpen) throws IOException {
/*     */     byte[] address;
/*     */     int scopeId;
/* 133 */     if (addr instanceof Inet6Address) {
/* 134 */       address = addr.getAddress();
/* 135 */       scopeId = ((Inet6Address)addr).getScopeId();
/*     */     } else {
/*     */       
/* 138 */       scopeId = 0;
/* 139 */       address = NativeInetAddress.ipv4MappedIpv6Address(addr.getAddress());
/*     */     } 
/* 141 */     int flags = fastOpen ? msgFastopen() : 0;
/* 142 */     int res = sendTo(this.fd, useIpv6(addr), buf, pos, limit, address, scopeId, port, flags);
/* 143 */     if (res >= 0) {
/* 144 */       return res;
/*     */     }
/* 146 */     if (res == Errors.ERRNO_EINPROGRESS_NEGATIVE && fastOpen)
/*     */     {
/*     */ 
/*     */       
/* 150 */       return 0;
/*     */     }
/* 152 */     if (res == Errors.ERROR_ECONNREFUSED_NEGATIVE) {
/* 153 */       throw new PortUnreachableException("sendTo failed");
/*     */     }
/* 155 */     return Errors.ioResult("sendTo", res);
/*     */   }
/*     */   
/*     */   public final int sendToDomainSocket(ByteBuffer buf, int pos, int limit, byte[] path) throws IOException {
/* 159 */     int res = sendToDomainSocket(this.fd, buf, pos, limit, path);
/* 160 */     if (res >= 0) {
/* 161 */       return res;
/*     */     }
/* 163 */     return Errors.ioResult("sendToDomainSocket", res);
/*     */   }
/*     */ 
/*     */   
/*     */   public final int sendToAddress(long memoryAddress, int pos, int limit, InetAddress addr, int port) throws IOException {
/* 168 */     return sendToAddress(memoryAddress, pos, limit, addr, port, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int sendToAddress(long memoryAddress, int pos, int limit, InetAddress addr, int port, boolean fastOpen) throws IOException {
/*     */     byte[] address;
/*     */     int scopeId;
/* 177 */     if (addr instanceof Inet6Address) {
/* 178 */       address = addr.getAddress();
/* 179 */       scopeId = ((Inet6Address)addr).getScopeId();
/*     */     } else {
/*     */       
/* 182 */       scopeId = 0;
/* 183 */       address = NativeInetAddress.ipv4MappedIpv6Address(addr.getAddress());
/*     */     } 
/* 185 */     int flags = fastOpen ? msgFastopen() : 0;
/* 186 */     int res = sendToAddress(this.fd, useIpv6(addr), memoryAddress, pos, limit, address, scopeId, port, flags);
/* 187 */     if (res >= 0) {
/* 188 */       return res;
/*     */     }
/* 190 */     if (res == Errors.ERRNO_EINPROGRESS_NEGATIVE && fastOpen)
/*     */     {
/*     */ 
/*     */       
/* 194 */       return 0;
/*     */     }
/* 196 */     if (res == Errors.ERROR_ECONNREFUSED_NEGATIVE) {
/* 197 */       throw new PortUnreachableException("sendToAddress failed");
/*     */     }
/* 199 */     return Errors.ioResult("sendToAddress", res);
/*     */   }
/*     */   
/*     */   public final int sendToAddressDomainSocket(long memoryAddress, int pos, int limit, byte[] path) throws IOException {
/* 203 */     int res = sendToAddressDomainSocket(this.fd, memoryAddress, pos, limit, path);
/* 204 */     if (res >= 0) {
/* 205 */       return res;
/*     */     }
/* 207 */     return Errors.ioResult("sendToAddressDomainSocket", res);
/*     */   }
/*     */   
/*     */   public final int sendToAddresses(long memoryAddress, int length, InetAddress addr, int port) throws IOException {
/* 211 */     return sendToAddresses(memoryAddress, length, addr, port, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int sendToAddresses(long memoryAddress, int length, InetAddress addr, int port, boolean fastOpen) throws IOException {
/*     */     byte[] address;
/*     */     int scopeId;
/* 220 */     if (addr instanceof Inet6Address) {
/* 221 */       address = addr.getAddress();
/* 222 */       scopeId = ((Inet6Address)addr).getScopeId();
/*     */     } else {
/*     */       
/* 225 */       scopeId = 0;
/* 226 */       address = NativeInetAddress.ipv4MappedIpv6Address(addr.getAddress());
/*     */     } 
/* 228 */     int flags = fastOpen ? msgFastopen() : 0;
/* 229 */     int res = sendToAddresses(this.fd, useIpv6(addr), memoryAddress, length, address, scopeId, port, flags);
/* 230 */     if (res >= 0) {
/* 231 */       return res;
/*     */     }
/* 233 */     if (res == Errors.ERRNO_EINPROGRESS_NEGATIVE && fastOpen)
/*     */     {
/*     */ 
/*     */       
/* 237 */       return 0;
/*     */     }
/* 239 */     if (res == Errors.ERROR_ECONNREFUSED_NEGATIVE) {
/* 240 */       throw new PortUnreachableException("sendToAddresses failed");
/*     */     }
/* 242 */     return Errors.ioResult("sendToAddresses", res);
/*     */   }
/*     */   
/*     */   public final int sendToAddressesDomainSocket(long memoryAddress, int length, byte[] path) throws IOException {
/* 246 */     int res = sendToAddressesDomainSocket(this.fd, memoryAddress, length, path);
/* 247 */     if (res >= 0) {
/* 248 */       return res;
/*     */     }
/* 250 */     return Errors.ioResult("sendToAddressesDomainSocket", res);
/*     */   }
/*     */   
/*     */   public final DatagramSocketAddress recvFrom(ByteBuffer buf, int pos, int limit) throws IOException {
/* 254 */     return recvFrom(this.fd, buf, pos, limit);
/*     */   }
/*     */   
/*     */   public final DatagramSocketAddress recvFromAddress(long memoryAddress, int pos, int limit) throws IOException {
/* 258 */     return recvFromAddress(this.fd, memoryAddress, pos, limit);
/*     */   }
/*     */ 
/*     */   
/*     */   public final DomainDatagramSocketAddress recvFromDomainSocket(ByteBuffer buf, int pos, int limit) throws IOException {
/* 263 */     return recvFromDomainSocket(this.fd, buf, pos, limit);
/*     */   }
/*     */ 
/*     */   
/*     */   public final DomainDatagramSocketAddress recvFromAddressDomainSocket(long memoryAddress, int pos, int limit) throws IOException {
/* 268 */     return recvFromAddressDomainSocket(this.fd, memoryAddress, pos, limit);
/*     */   }
/*     */   
/*     */   public int recv(ByteBuffer buf, int pos, int limit) throws IOException {
/* 272 */     int res = recv(intValue(), buf, pos, limit);
/* 273 */     if (res > 0) {
/* 274 */       return res;
/*     */     }
/* 276 */     if (res == 0) {
/* 277 */       return -1;
/*     */     }
/* 279 */     return Errors.ioResult("recv", res);
/*     */   }
/*     */   
/*     */   public int recvAddress(long address, int pos, int limit) throws IOException {
/* 283 */     int res = recvAddress(intValue(), address, pos, limit);
/* 284 */     if (res > 0) {
/* 285 */       return res;
/*     */     }
/* 287 */     if (res == 0) {
/* 288 */       return -1;
/*     */     }
/* 290 */     return Errors.ioResult("recvAddress", res);
/*     */   }
/*     */   
/*     */   public int send(ByteBuffer buf, int pos, int limit) throws IOException {
/* 294 */     int res = send(intValue(), buf, pos, limit);
/* 295 */     if (res >= 0) {
/* 296 */       return res;
/*     */     }
/* 298 */     return Errors.ioResult("send", res);
/*     */   }
/*     */   
/*     */   public int sendAddress(long address, int pos, int limit) throws IOException {
/* 302 */     int res = sendAddress(intValue(), address, pos, limit);
/* 303 */     if (res >= 0) {
/* 304 */       return res;
/*     */     }
/* 306 */     return Errors.ioResult("sendAddress", res);
/*     */   }
/*     */   
/*     */   public final int recvFd() throws IOException {
/* 310 */     int res = recvFd(this.fd);
/* 311 */     if (res > 0) {
/* 312 */       return res;
/*     */     }
/* 314 */     if (res == 0) {
/* 315 */       return -1;
/*     */     }
/*     */     
/* 318 */     if (res == Errors.ERRNO_EAGAIN_NEGATIVE || res == Errors.ERRNO_EWOULDBLOCK_NEGATIVE)
/*     */     {
/* 320 */       return 0;
/*     */     }
/* 322 */     throw Errors.newIOException("recvFd", res);
/*     */   }
/*     */   
/*     */   public final int sendFd(int fdToSend) throws IOException {
/* 326 */     int res = sendFd(this.fd, fdToSend);
/* 327 */     if (res >= 0) {
/* 328 */       return res;
/*     */     }
/* 330 */     if (res == Errors.ERRNO_EAGAIN_NEGATIVE || res == Errors.ERRNO_EWOULDBLOCK_NEGATIVE)
/*     */     {
/* 332 */       return -1;
/*     */     }
/* 334 */     throw Errors.newIOException("sendFd", res);
/*     */   }
/*     */   
/*     */   public final boolean connect(SocketAddress socketAddress) throws IOException {
/*     */     int res;
/* 339 */     if (socketAddress instanceof InetSocketAddress) {
/* 340 */       InetSocketAddress inetSocketAddress = (InetSocketAddress)socketAddress;
/* 341 */       InetAddress inetAddress = inetSocketAddress.getAddress();
/* 342 */       NativeInetAddress address = NativeInetAddress.newInstance(inetAddress);
/* 343 */       res = connect(this.fd, useIpv6(inetAddress), address.address, address.scopeId, inetSocketAddress.getPort());
/* 344 */     } else if (socketAddress instanceof DomainSocketAddress) {
/* 345 */       DomainSocketAddress unixDomainSocketAddress = (DomainSocketAddress)socketAddress;
/* 346 */       res = connectDomainSocket(this.fd, unixDomainSocketAddress.path().getBytes(CharsetUtil.UTF_8));
/*     */     } else {
/* 348 */       throw new Error("Unexpected SocketAddress implementation " + socketAddress);
/*     */     } 
/* 350 */     if (res < 0) {
/* 351 */       return Errors.handleConnectErrno("connect", res);
/*     */     }
/* 353 */     return true;
/*     */   }
/*     */   
/*     */   public final boolean finishConnect() throws IOException {
/* 357 */     int res = finishConnect(this.fd);
/* 358 */     if (res < 0) {
/* 359 */       return Errors.handleConnectErrno("finishConnect", res);
/*     */     }
/* 361 */     return true;
/*     */   }
/*     */   
/*     */   public final void disconnect() throws IOException {
/* 365 */     int res = disconnect(this.fd, this.ipv6);
/* 366 */     if (res < 0) {
/* 367 */       Errors.handleConnectErrno("disconnect", res);
/*     */     }
/*     */   }
/*     */   
/*     */   public final void bind(SocketAddress socketAddress) throws IOException {
/* 372 */     if (socketAddress instanceof InetSocketAddress) {
/* 373 */       InetSocketAddress addr = (InetSocketAddress)socketAddress;
/* 374 */       InetAddress inetAddress = addr.getAddress();
/* 375 */       NativeInetAddress address = NativeInetAddress.newInstance(inetAddress);
/* 376 */       int res = bind(this.fd, useIpv6(inetAddress), address.address, address.scopeId, addr.getPort());
/* 377 */       if (res < 0) {
/* 378 */         throw Errors.newIOException("bind", res);
/*     */       }
/* 380 */     } else if (socketAddress instanceof DomainSocketAddress) {
/* 381 */       DomainSocketAddress addr = (DomainSocketAddress)socketAddress;
/* 382 */       int res = bindDomainSocket(this.fd, addr.path().getBytes(CharsetUtil.UTF_8));
/* 383 */       if (res < 0) {
/* 384 */         throw Errors.newIOException("bind", res);
/*     */       }
/*     */     } else {
/* 387 */       throw new Error("Unexpected SocketAddress implementation " + socketAddress);
/*     */     } 
/*     */   }
/*     */   
/*     */   public final void listen(int backlog) throws IOException {
/* 392 */     int res = listen(this.fd, backlog);
/* 393 */     if (res < 0) {
/* 394 */       throw Errors.newIOException("listen", res);
/*     */     }
/*     */   }
/*     */   
/*     */   public final int accept(byte[] addr) throws IOException {
/* 399 */     int res = accept(this.fd, addr);
/* 400 */     if (res >= 0) {
/* 401 */       return res;
/*     */     }
/* 403 */     if (res == Errors.ERRNO_EAGAIN_NEGATIVE || res == Errors.ERRNO_EWOULDBLOCK_NEGATIVE)
/*     */     {
/* 405 */       return -1;
/*     */     }
/* 407 */     throw Errors.newIOException("accept", res);
/*     */   }
/*     */   
/*     */   public final InetSocketAddress remoteAddress() {
/* 411 */     byte[] addr = remoteAddress(this.fd);
/*     */ 
/*     */     
/* 414 */     return (addr == null) ? null : NativeInetAddress.address(addr, 0, addr.length);
/*     */   }
/*     */   
/*     */   public final DomainSocketAddress remoteDomainSocketAddress() {
/* 418 */     byte[] addr = remoteDomainSocketAddress(this.fd);
/* 419 */     return (addr == null) ? null : new DomainSocketAddress(new String(addr));
/*     */   }
/*     */   
/*     */   public final InetSocketAddress localAddress() {
/* 423 */     byte[] addr = localAddress(this.fd);
/*     */ 
/*     */     
/* 426 */     return (addr == null) ? null : NativeInetAddress.address(addr, 0, addr.length);
/*     */   }
/*     */   
/*     */   public final DomainSocketAddress localDomainSocketAddress() {
/* 430 */     byte[] addr = localDomainSocketAddress(this.fd);
/* 431 */     return (addr == null) ? null : new DomainSocketAddress(new String(addr));
/*     */   }
/*     */   
/*     */   public final int getReceiveBufferSize() throws IOException {
/* 435 */     return getReceiveBufferSize(this.fd);
/*     */   }
/*     */   
/*     */   public final int getSendBufferSize() throws IOException {
/* 439 */     return getSendBufferSize(this.fd);
/*     */   }
/*     */   
/*     */   public final boolean isKeepAlive() throws IOException {
/* 443 */     return (isKeepAlive(this.fd) != 0);
/*     */   }
/*     */   
/*     */   public final boolean isTcpNoDelay() throws IOException {
/* 447 */     return (isTcpNoDelay(this.fd) != 0);
/*     */   }
/*     */   
/*     */   public final boolean isReuseAddress() throws IOException {
/* 451 */     return (isReuseAddress(this.fd) != 0);
/*     */   }
/*     */   
/*     */   public final boolean isReusePort() throws IOException {
/* 455 */     return (isReusePort(this.fd) != 0);
/*     */   }
/*     */   
/*     */   public final boolean isBroadcast() throws IOException {
/* 459 */     return (isBroadcast(this.fd) != 0);
/*     */   }
/*     */   
/*     */   public final int getSoLinger() throws IOException {
/* 463 */     return getSoLinger(this.fd);
/*     */   }
/*     */   
/*     */   public final int getSoError() throws IOException {
/* 467 */     return getSoError(this.fd);
/*     */   }
/*     */   
/*     */   public final int getTrafficClass() throws IOException {
/* 471 */     return getTrafficClass(this.fd, this.ipv6);
/*     */   }
/*     */   
/*     */   public final void setKeepAlive(boolean keepAlive) throws IOException {
/* 475 */     setKeepAlive(this.fd, keepAlive ? 1 : 0);
/*     */   }
/*     */   
/*     */   public final void setReceiveBufferSize(int receiveBufferSize) throws IOException {
/* 479 */     setReceiveBufferSize(this.fd, receiveBufferSize);
/*     */   }
/*     */   
/*     */   public final void setSendBufferSize(int sendBufferSize) throws IOException {
/* 483 */     setSendBufferSize(this.fd, sendBufferSize);
/*     */   }
/*     */   
/*     */   public final void setTcpNoDelay(boolean tcpNoDelay) throws IOException {
/* 487 */     setTcpNoDelay(this.fd, tcpNoDelay ? 1 : 0);
/*     */   }
/*     */   
/*     */   public final void setSoLinger(int soLinger) throws IOException {
/* 491 */     setSoLinger(this.fd, soLinger);
/*     */   }
/*     */   
/*     */   public final void setReuseAddress(boolean reuseAddress) throws IOException {
/* 495 */     setReuseAddress(this.fd, reuseAddress ? 1 : 0);
/*     */   }
/*     */   
/*     */   public final void setReusePort(boolean reusePort) throws IOException {
/* 499 */     setReusePort(this.fd, reusePort ? 1 : 0);
/*     */   }
/*     */   
/*     */   public final void setBroadcast(boolean broadcast) throws IOException {
/* 503 */     setBroadcast(this.fd, broadcast ? 1 : 0);
/*     */   }
/*     */   
/*     */   public final void setTrafficClass(int trafficClass) throws IOException {
/* 507 */     setTrafficClass(this.fd, this.ipv6, trafficClass);
/*     */   }
/*     */   
/*     */   public void setIntOpt(int level, int optname, int optvalue) throws IOException {
/* 511 */     setIntOpt(this.fd, level, optname, optvalue);
/*     */   }
/*     */   
/*     */   public void setRawOpt(int level, int optname, ByteBuffer optvalue) throws IOException {
/* 515 */     int limit = optvalue.limit();
/* 516 */     if (optvalue.isDirect()) {
/* 517 */       setRawOptAddress(this.fd, level, optname, 
/* 518 */           Buffer.memoryAddress(optvalue) + optvalue.position(), optvalue.remaining());
/* 519 */     } else if (optvalue.hasArray()) {
/* 520 */       setRawOptArray(this.fd, level, optname, optvalue
/* 521 */           .array(), optvalue.arrayOffset() + optvalue.position(), optvalue.remaining());
/*     */     } else {
/* 523 */       byte[] bytes = new byte[optvalue.remaining()];
/* 524 */       optvalue.duplicate().get(bytes);
/* 525 */       setRawOptArray(this.fd, level, optname, bytes, 0, bytes.length);
/*     */     } 
/* 527 */     optvalue.position(limit);
/*     */   }
/*     */   
/*     */   public int getIntOpt(int level, int optname) throws IOException {
/* 531 */     return getIntOpt(this.fd, level, optname);
/*     */   }
/*     */   
/*     */   public void getRawOpt(int level, int optname, ByteBuffer out) throws IOException {
/* 535 */     if (out.isDirect()) {
/* 536 */       getRawOptAddress(this.fd, level, optname, Buffer.memoryAddress(out) + out.position(), out.remaining());
/* 537 */     } else if (out.hasArray()) {
/* 538 */       getRawOptArray(this.fd, level, optname, out.array(), out.position() + out.arrayOffset(), out.remaining());
/*     */     } else {
/* 540 */       byte[] outArray = new byte[out.remaining()];
/* 541 */       getRawOptArray(this.fd, level, optname, outArray, 0, outArray.length);
/* 542 */       out.put(outArray);
/*     */     } 
/* 544 */     out.position(out.limit());
/*     */   }
/*     */   
/*     */   public static boolean isIPv6Preferred() {
/* 548 */     return isIpv6Preferred;
/*     */   }
/*     */   
/*     */   public static boolean shouldUseIpv6(InternetProtocolFamily family) {
/* 552 */     return (family == null) ? isIPv6Preferred() : ((family == InternetProtocolFamily.IPv6));
/*     */   }
/*     */ 
/*     */   
/*     */   private static native boolean isIPv6Preferred0(boolean paramBoolean);
/*     */ 
/*     */   
/*     */   private static native boolean isIPv6(int paramInt);
/*     */   
/*     */   public String toString() {
/* 562 */     return "Socket{fd=" + this.fd + '}';
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static Socket newSocketStream() {
/* 568 */     return new Socket(newSocketStream0());
/*     */   }
/*     */   
/*     */   public static Socket newSocketDgram() {
/* 572 */     return new Socket(newSocketDgram0());
/*     */   }
/*     */   
/*     */   public static Socket newSocketDomain() {
/* 576 */     return new Socket(newSocketDomain0());
/*     */   }
/*     */   
/*     */   public static Socket newSocketDomainDgram() {
/* 580 */     return new Socket(newSocketDomainDgram0());
/*     */   }
/*     */   
/*     */   public static void initialize() {
/* 584 */     isIpv6Preferred = isIPv6Preferred0(NetUtil.isIpV4StackPreferred());
/*     */   }
/*     */   
/*     */   protected static int newSocketStream0() {
/* 588 */     return newSocketStream0(isIPv6Preferred());
/*     */   }
/*     */   
/*     */   protected static int newSocketStream0(InternetProtocolFamily protocol) {
/* 592 */     return newSocketStream0(shouldUseIpv6(protocol));
/*     */   }
/*     */   
/*     */   protected static int newSocketStream0(boolean ipv6) {
/* 596 */     int res = newSocketStreamFd(ipv6);
/* 597 */     if (res < 0) {
/* 598 */       throw new ChannelException(Errors.newIOException("newSocketStream", res));
/*     */     }
/* 600 */     return res;
/*     */   }
/*     */   
/*     */   protected static int newSocketDgram0() {
/* 604 */     return newSocketDgram0(isIPv6Preferred());
/*     */   }
/*     */   
/*     */   protected static int newSocketDgram0(InternetProtocolFamily family) {
/* 608 */     return newSocketDgram0(shouldUseIpv6(family));
/*     */   }
/*     */   
/*     */   protected static int newSocketDgram0(boolean ipv6) {
/* 612 */     int res = newSocketDgramFd(ipv6);
/* 613 */     if (res < 0) {
/* 614 */       throw new ChannelException(Errors.newIOException("newSocketDgram", res));
/*     */     }
/* 616 */     return res;
/*     */   }
/*     */   
/*     */   protected static int newSocketDomain0() {
/* 620 */     int res = newSocketDomainFd();
/* 621 */     if (res < 0) {
/* 622 */       throw new ChannelException(Errors.newIOException("newSocketDomain", res));
/*     */     }
/* 624 */     return res;
/*     */   }
/*     */   
/*     */   protected static int newSocketDomainDgram0() {
/* 628 */     int res = newSocketDomainDgramFd();
/* 629 */     if (res < 0) {
/* 630 */       throw new ChannelException(Errors.newIOException("newSocketDomainDgram", res));
/*     */     }
/* 632 */     return res;
/*     */   }
/*     */   
/*     */   private static native int shutdown(int paramInt, boolean paramBoolean1, boolean paramBoolean2);
/*     */   
/*     */   private static native int connect(int paramInt1, boolean paramBoolean, byte[] paramArrayOfbyte, int paramInt2, int paramInt3);
/*     */   
/*     */   private static native int connectDomainSocket(int paramInt, byte[] paramArrayOfbyte);
/*     */   
/*     */   private static native int finishConnect(int paramInt);
/*     */   
/*     */   private static native int disconnect(int paramInt, boolean paramBoolean);
/*     */   
/*     */   private static native int bind(int paramInt1, boolean paramBoolean, byte[] paramArrayOfbyte, int paramInt2, int paramInt3);
/*     */   
/*     */   private static native int bindDomainSocket(int paramInt, byte[] paramArrayOfbyte);
/*     */   
/*     */   private static native int listen(int paramInt1, int paramInt2);
/*     */   
/*     */   private static native int accept(int paramInt, byte[] paramArrayOfbyte);
/*     */   
/*     */   private static native byte[] remoteAddress(int paramInt);
/*     */   
/*     */   private static native byte[] remoteDomainSocketAddress(int paramInt);
/*     */   
/*     */   private static native byte[] localAddress(int paramInt);
/*     */   
/*     */   private static native byte[] localDomainSocketAddress(int paramInt);
/*     */   
/*     */   private static native int send(int paramInt1, ByteBuffer paramByteBuffer, int paramInt2, int paramInt3);
/*     */   
/*     */   private static native int sendAddress(int paramInt1, long paramLong, int paramInt2, int paramInt3);
/*     */   
/*     */   private static native int recv(int paramInt1, ByteBuffer paramByteBuffer, int paramInt2, int paramInt3);
/*     */   
/*     */   private static native int recvAddress(int paramInt1, long paramLong, int paramInt2, int paramInt3);
/*     */   
/*     */   private static native int sendTo(int paramInt1, boolean paramBoolean, ByteBuffer paramByteBuffer, int paramInt2, int paramInt3, byte[] paramArrayOfbyte, int paramInt4, int paramInt5, int paramInt6);
/*     */   
/*     */   private static native int sendToAddress(int paramInt1, boolean paramBoolean, long paramLong, int paramInt2, int paramInt3, byte[] paramArrayOfbyte, int paramInt4, int paramInt5, int paramInt6);
/*     */   
/*     */   private static native int sendToAddresses(int paramInt1, boolean paramBoolean, long paramLong, int paramInt2, byte[] paramArrayOfbyte, int paramInt3, int paramInt4, int paramInt5);
/*     */   
/*     */   private static native int sendToDomainSocket(int paramInt1, ByteBuffer paramByteBuffer, int paramInt2, int paramInt3, byte[] paramArrayOfbyte);
/*     */   
/*     */   private static native int sendToAddressDomainSocket(int paramInt1, long paramLong, int paramInt2, int paramInt3, byte[] paramArrayOfbyte);
/*     */   
/*     */   private static native int sendToAddressesDomainSocket(int paramInt1, long paramLong, int paramInt2, byte[] paramArrayOfbyte);
/*     */   
/*     */   private static native DatagramSocketAddress recvFrom(int paramInt1, ByteBuffer paramByteBuffer, int paramInt2, int paramInt3) throws IOException;
/*     */   
/*     */   private static native DatagramSocketAddress recvFromAddress(int paramInt1, long paramLong, int paramInt2, int paramInt3) throws IOException;
/*     */   
/*     */   private static native DomainDatagramSocketAddress recvFromDomainSocket(int paramInt1, ByteBuffer paramByteBuffer, int paramInt2, int paramInt3) throws IOException;
/*     */   
/*     */   private static native DomainDatagramSocketAddress recvFromAddressDomainSocket(int paramInt1, long paramLong, int paramInt2, int paramInt3) throws IOException;
/*     */   
/*     */   private static native int recvFd(int paramInt);
/*     */   
/*     */   private static native int sendFd(int paramInt1, int paramInt2);
/*     */   
/*     */   private static native int msgFastopen();
/*     */   
/*     */   private static native int newSocketStreamFd(boolean paramBoolean);
/*     */   
/*     */   private static native int newSocketDgramFd(boolean paramBoolean);
/*     */   
/*     */   private static native int newSocketDomainFd();
/*     */   
/*     */   private static native int newSocketDomainDgramFd();
/*     */   
/*     */   private static native int isReuseAddress(int paramInt) throws IOException;
/*     */   
/*     */   private static native int isReusePort(int paramInt) throws IOException;
/*     */   
/*     */   private static native int getReceiveBufferSize(int paramInt) throws IOException;
/*     */   
/*     */   private static native int getSendBufferSize(int paramInt) throws IOException;
/*     */   
/*     */   private static native int isKeepAlive(int paramInt) throws IOException;
/*     */   
/*     */   private static native int isTcpNoDelay(int paramInt) throws IOException;
/*     */   
/*     */   private static native int isBroadcast(int paramInt) throws IOException;
/*     */   
/*     */   private static native int getSoLinger(int paramInt) throws IOException;
/*     */   
/*     */   private static native int getSoError(int paramInt) throws IOException;
/*     */   
/*     */   private static native int getTrafficClass(int paramInt, boolean paramBoolean) throws IOException;
/*     */   
/*     */   private static native void setReuseAddress(int paramInt1, int paramInt2) throws IOException;
/*     */   
/*     */   private static native void setReusePort(int paramInt1, int paramInt2) throws IOException;
/*     */   
/*     */   private static native void setKeepAlive(int paramInt1, int paramInt2) throws IOException;
/*     */   
/*     */   private static native void setReceiveBufferSize(int paramInt1, int paramInt2) throws IOException;
/*     */   
/*     */   private static native void setSendBufferSize(int paramInt1, int paramInt2) throws IOException;
/*     */   
/*     */   private static native void setTcpNoDelay(int paramInt1, int paramInt2) throws IOException;
/*     */   
/*     */   private static native void setSoLinger(int paramInt1, int paramInt2) throws IOException;
/*     */   
/*     */   private static native void setBroadcast(int paramInt1, int paramInt2) throws IOException;
/*     */   
/*     */   private static native void setTrafficClass(int paramInt1, boolean paramBoolean, int paramInt2) throws IOException;
/*     */   
/*     */   private static native void setIntOpt(int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws IOException;
/*     */   
/*     */   private static native void setRawOptArray(int paramInt1, int paramInt2, int paramInt3, byte[] paramArrayOfbyte, int paramInt4, int paramInt5) throws IOException;
/*     */   
/*     */   private static native void setRawOptAddress(int paramInt1, int paramInt2, int paramInt3, long paramLong, int paramInt4) throws IOException;
/*     */   
/*     */   private static native int getIntOpt(int paramInt1, int paramInt2, int paramInt3) throws IOException;
/*     */   
/*     */   private static native void getRawOptArray(int paramInt1, int paramInt2, int paramInt3, byte[] paramArrayOfbyte, int paramInt4, int paramInt5) throws IOException;
/*     */   
/*     */   private static native void getRawOptAddress(int paramInt1, int paramInt2, int paramInt3, long paramLong, int paramInt4) throws IOException;
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-transport-native-unix-common-4.1.93.Final.jar!\io\netty\channe\\unix\Socket.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */