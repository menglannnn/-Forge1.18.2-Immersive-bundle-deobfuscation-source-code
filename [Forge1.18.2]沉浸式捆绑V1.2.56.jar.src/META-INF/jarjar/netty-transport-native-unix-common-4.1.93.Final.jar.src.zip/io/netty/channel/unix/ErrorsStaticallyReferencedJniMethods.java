package io.netty.channel.unix;

final class ErrorsStaticallyReferencedJniMethods {
  static native int errnoENOENT();
  
  static native int errnoEBADF();
  
  static native int errnoEPIPE();
  
  static native int errnoECONNRESET();
  
  static native int errnoENOTCONN();
  
  static native int errnoEAGAIN();
  
  static native int errnoEWOULDBLOCK();
  
  static native int errnoEINPROGRESS();
  
  static native int errorECONNREFUSED();
  
  static native int errorEISCONN();
  
  static native int errorEALREADY();
  
  static native int errorENETUNREACH();
  
  static native int errorEHOSTUNREACH();
  
  static native String strError(int paramInt);
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-transport-native-unix-common-4.1.93.Final.jar!\io\netty\channe\\unix\ErrorsStaticallyReferencedJniMethods.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */