/*    */ package discord4j.voice;
/*    */ 
/*    */ import java.util.Map;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ import org.reactivestreams.Publisher;
/*    */ import reactor.core.publisher.Mono;
/*    */ import reactor.core.publisher.SignalType;
/*    */ import reactor.util.Logger;
/*    */ import reactor.util.Loggers;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultVoiceConnectionFactory
/*    */   implements VoiceConnectionFactory
/*    */ {
/* 34 */   private static final Logger log = Loggers.getLogger(DefaultVoiceConnectionFactory.class);
/*    */   
/* 36 */   private final Map<Long, Mono<VoiceConnection>> onHandshake = new ConcurrentHashMap<>();
/*    */ 
/*    */   
/*    */   public Mono<VoiceConnection> create(VoiceGatewayOptions options) {
/* 40 */     return Mono.defer(() -> (Mono)this.onHandshake.compute(Long.valueOf(options.getGuildId().asLong()), ()));
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-voice-3.2.5.jar!\discord4j\voice\DefaultVoiceConnectionFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */