/*     */ package discord4j.voice;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import java.util.function.Function;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.context.ContextView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface VoiceConnection
/*     */ {
/*     */   default Mono<Boolean> isConnected() {
/*  45 */     return stateEvents().next().filter(s -> s.equals(State.CONNECTED)).hasElement();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Mono<State> onConnectOrDisconnect() {
/*  55 */     return stateEvents().filter(s -> (s.equals(State.CONNECTED) || s.equals(State.DISCONNECTED))).next();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Flux<VoiceGatewayEvent> events();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Flux<State> stateEvents();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Mono<Void> disconnect();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Mono<Void> reconnect(Function<ContextView, Throwable> errorCause) {
/* 107 */     return reconnect();
/*     */   }
/*     */   
/*     */   Snowflake getGuildId();
/*     */   
/*     */   Mono<Snowflake> getChannelId();
/*     */   
/*     */   Mono<Void> reconnect();
/*     */   
/*     */   public enum State {
/* 117 */     CONNECTING,
/*     */ 
/*     */ 
/*     */     
/* 121 */     CONNECTED,
/*     */ 
/*     */ 
/*     */     
/* 125 */     RESUMING,
/*     */ 
/*     */ 
/*     */     
/* 129 */     RECONNECTING,
/*     */ 
/*     */ 
/*     */     
/* 133 */     DISCONNECTED;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-voice-3.2.5.jar!\discord4j\voice\VoiceConnection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */