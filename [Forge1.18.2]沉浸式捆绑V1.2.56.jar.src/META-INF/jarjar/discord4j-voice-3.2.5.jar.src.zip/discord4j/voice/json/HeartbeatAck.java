/*    */ package discord4j.voice.json;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HeartbeatAck
/*    */   extends VoiceGatewayPayload<Long>
/*    */ {
/*    */   public static final int OP = 6;
/*    */   
/*    */   public HeartbeatAck(long data) {
/* 24 */     super(6, Long.valueOf(data));
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-voice-3.2.5.jar!\discord4j\voice\json\HeartbeatAck.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */