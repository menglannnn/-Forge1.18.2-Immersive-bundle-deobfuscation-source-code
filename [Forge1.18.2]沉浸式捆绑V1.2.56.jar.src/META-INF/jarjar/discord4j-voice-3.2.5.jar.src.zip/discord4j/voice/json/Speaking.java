/*    */ package discord4j.voice.json;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Speaking
/*    */   extends VoiceGatewayPayload<Speaking.Data>
/*    */ {
/*    */   public static final int OP = 5;
/*    */   
/*    */   public Speaking(String userId, int ssrc, boolean speaking) {
/* 24 */     this(new Data(userId, ssrc, speaking));
/*    */   }
/*    */   
/*    */   public Speaking(Data data) {
/* 28 */     super(5, data);
/*    */   }
/*    */   
/*    */   public static class Data
/*    */   {
/*    */     private final String userId;
/*    */     private final int ssrc;
/*    */     private final boolean speaking;
/*    */     
/*    */     Data(String userId, int ssrc, boolean speaking) {
/* 38 */       this.userId = userId;
/* 39 */       this.ssrc = ssrc;
/* 40 */       this.speaking = speaking;
/*    */     }
/*    */     
/*    */     public String getUserId() {
/* 44 */       return this.userId;
/*    */     }
/*    */     
/*    */     public int getSsrc() {
/* 48 */       return this.ssrc;
/*    */     }
/*    */     
/*    */     public boolean isSpeaking() {
/* 52 */       return this.speaking;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-voice-3.2.5.jar!\discord4j\voice\json\Speaking.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */