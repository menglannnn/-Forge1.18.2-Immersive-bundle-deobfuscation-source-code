/*    */ package discord4j.voice.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import discord4j.voice.VoiceGatewayEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @JsonDeserialize(using = VoiceGatewayPayloadDeserializer.class)
/*    */ public abstract class VoiceGatewayPayload<T>
/*    */   implements VoiceGatewayEvent
/*    */ {
/*    */   private final int op;
/*    */   @JsonProperty("d")
/*    */   private final T data;
/*    */   
/*    */   public VoiceGatewayPayload(int op, T data) {
/* 31 */     this.op = op;
/* 32 */     this.data = data;
/*    */   }
/*    */   
/*    */   public int getOp() {
/* 36 */     return this.op;
/*    */   }
/*    */   
/*    */   public T getData() {
/* 40 */     return this.data;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-voice-3.2.5.jar!\discord4j\voice\json\VoiceGatewayPayload.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */