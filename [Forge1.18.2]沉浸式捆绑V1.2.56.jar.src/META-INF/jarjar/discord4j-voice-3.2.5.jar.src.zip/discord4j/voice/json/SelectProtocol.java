/*    */ package discord4j.voice.json;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SelectProtocol
/*    */   extends VoiceGatewayPayload<SelectProtocol.Data>
/*    */ {
/*    */   public static final int OP = 1;
/*    */   
/*    */   public SelectProtocol(String protocol, String address, int port, String mode) {
/* 24 */     this(new Data(protocol, new Data.Inner(address, port, mode)));
/*    */   }
/*    */   
/*    */   public SelectProtocol(Data data) {
/* 28 */     super(1, data);
/*    */   }
/*    */   
/*    */   public static class Data
/*    */   {
/*    */     private final String protocol;
/*    */     private final Inner data;
/*    */     
/*    */     public Data(String protocol, Inner data) {
/* 37 */       this.protocol = protocol;
/* 38 */       this.data = data;
/*    */     }
/*    */     
/*    */     public String getProtocol() {
/* 42 */       return this.protocol;
/*    */     }
/*    */     
/*    */     public Inner getData() {
/* 46 */       return this.data;
/*    */     }
/*    */     
/*    */     public static class Inner
/*    */     {
/*    */       private final String address;
/*    */       private final int port;
/*    */       private final String mode;
/*    */       
/*    */       public Inner(String address, int port, String mode) {
/* 56 */         this.address = address;
/* 57 */         this.port = port;
/* 58 */         this.mode = mode;
/*    */       }
/*    */       
/*    */       public String getAddress() {
/* 62 */         return this.address;
/*    */       }
/*    */       
/*    */       public int getPort() {
/* 66 */         return this.port;
/*    */       }
/*    */       
/*    */       public String getMode() {
/* 70 */         return this.mode; } } } public static class Inner { public String getMode() { return this.mode; }
/*    */ 
/*    */     
/*    */     private final String address;
/*    */     private final int port;
/*    */     private final String mode;
/*    */     
/*    */     public Inner(String address, int port, String mode) {
/*    */       this.address = address;
/*    */       this.port = port;
/*    */       this.mode = mode;
/*    */     }
/*    */     
/*    */     public String getAddress() {
/*    */       return this.address;
/*    */     }
/*    */     
/*    */     public int getPort() {
/*    */       return this.port;
/*    */     } }
/*    */ 
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-voice-3.2.5.jar!\discord4j\voice\json\SelectProtocol.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */