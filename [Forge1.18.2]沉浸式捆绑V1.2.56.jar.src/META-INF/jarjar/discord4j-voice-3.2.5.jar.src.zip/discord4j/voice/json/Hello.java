/*    */ package discord4j.voice.json;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Hello
/*    */   extends VoiceGatewayPayload<Hello.Data>
/*    */ {
/*    */   public static final int OP = 8;
/*    */   
/*    */   public Hello(long heartbeatInterval) {
/* 24 */     this(new Data(heartbeatInterval));
/*    */   }
/*    */   
/*    */   public Hello(Data data) {
/* 28 */     super(8, data);
/*    */   }
/*    */   
/*    */   public static class Data
/*    */   {
/*    */     private final long heartbeatInterval;
/*    */     
/*    */     public Data(long heartbeatInterval) {
/* 36 */       this.heartbeatInterval = heartbeatInterval;
/*    */     }
/*    */     
/*    */     public long getHeartbeatInterval() {
/* 40 */       return this.heartbeatInterval;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-voice-3.2.5.jar!\discord4j\voice\json\Hello.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */