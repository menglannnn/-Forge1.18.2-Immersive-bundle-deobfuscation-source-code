/*    */ package discord4j.voice.json;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Heartbeat
/*    */   extends VoiceGatewayPayload<Long>
/*    */ {
/*    */   public static final int OP = 3;
/*    */   
/*    */   public Heartbeat(long data) {
/* 24 */     super(3, Long.valueOf(data));
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-voice-3.2.5.jar!\discord4j\voice\json\Heartbeat.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */