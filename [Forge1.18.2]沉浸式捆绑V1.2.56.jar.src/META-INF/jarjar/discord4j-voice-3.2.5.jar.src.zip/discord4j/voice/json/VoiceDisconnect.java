/*    */ package discord4j.voice.json;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VoiceDisconnect
/*    */   extends VoiceGatewayPayload<VoiceDisconnect.Data>
/*    */ {
/*    */   public static final int OP = 13;
/*    */   
/*    */   public VoiceDisconnect(String userId) {
/* 24 */     this(new Data(userId));
/*    */   }
/*    */   
/*    */   public VoiceDisconnect(Data data) {
/* 28 */     super(13, data);
/*    */   }
/*    */   
/*    */   public static class Data
/*    */   {
/*    */     private final String userId;
/*    */     
/*    */     public Data(String userId) {
/* 36 */       this.userId = userId;
/*    */     }
/*    */     
/*    */     public String getUserId() {
/* 40 */       return this.userId;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-voice-3.2.5.jar!\discord4j\voice\json\VoiceDisconnect.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */