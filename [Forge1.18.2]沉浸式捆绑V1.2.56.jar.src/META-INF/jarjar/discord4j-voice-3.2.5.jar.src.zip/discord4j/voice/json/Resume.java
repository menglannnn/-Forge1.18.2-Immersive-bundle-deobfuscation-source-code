/*    */ package discord4j.voice.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Resume
/*    */   extends VoiceGatewayPayload<Resume.Data>
/*    */ {
/*    */   public static final int OP = 7;
/*    */   
/*    */   public Resume(String serverId, String sessionId, String token) {
/* 26 */     this(new Data(serverId, sessionId, token));
/*    */   }
/*    */   
/*    */   public Resume(Data data) {
/* 30 */     super(7, data);
/*    */   }
/*    */   
/*    */   public static class Data
/*    */   {
/*    */     private final String serverId;
/*    */     private final String sessionId;
/*    */     private final String token;
/*    */     
/*    */     public Data(String serverId, String sessionId, String token) {
/* 40 */       this.serverId = serverId;
/* 41 */       this.sessionId = sessionId;
/* 42 */       this.token = token;
/*    */     }
/*    */     
/*    */     @JsonProperty("server_id")
/*    */     public String getServerId() {
/* 47 */       return this.serverId;
/*    */     }
/*    */     
/*    */     @JsonProperty("session_id")
/*    */     public String getSessionId() {
/* 52 */       return this.sessionId;
/*    */     }
/*    */     
/*    */     public String getToken() {
/* 56 */       return this.token;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-voice-3.2.5.jar!\discord4j\voice\json\Resume.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */