/*    */ package discord4j.voice.json;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Ready
/*    */   extends VoiceGatewayPayload<Ready.Data>
/*    */ {
/*    */   public static final int OP = 2;
/*    */   
/*    */   public Ready(int ssrc, String ip, int port) {
/* 24 */     this(new Data(ssrc, ip, port));
/*    */   }
/*    */   
/*    */   public Ready(Data data) {
/* 28 */     super(2, data);
/*    */   }
/*    */   
/*    */   public static class Data
/*    */   {
/*    */     private final int ssrc;
/*    */     private final String ip;
/*    */     private final int port;
/*    */     
/*    */     public Data(int ssrc, String ip, int port) {
/* 38 */       this.ssrc = ssrc;
/* 39 */       this.ip = ip;
/* 40 */       this.port = port;
/*    */     }
/*    */     
/*    */     public int getSsrc() {
/* 44 */       return this.ssrc;
/*    */     }
/*    */     
/*    */     public String getIp() {
/* 48 */       return this.ip;
/*    */     }
/*    */     
/*    */     public int getPort() {
/* 52 */       return this.port;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-voice-3.2.5.jar!\discord4j\voice\json\Ready.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */