/*    */ package discord4j.voice.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Identify
/*    */   extends VoiceGatewayPayload<Identify.Data>
/*    */ {
/*    */   public static final int OP = 0;
/*    */   
/*    */   public Identify(String serverId, String userId, String sessionId, String token) {
/* 26 */     this(new Data(serverId, userId, sessionId, token));
/*    */   }
/*    */   
/*    */   public Identify(Data data) {
/* 30 */     super(0, data);
/*    */   }
/*    */   
/*    */   public static class Data
/*    */   {
/*    */     private final String serverId;
/*    */     private final String userId;
/*    */     private final String sessionId;
/*    */     private final String token;
/*    */     
/*    */     public Data(String serverId, String userId, String sessionId, String token) {
/* 41 */       this.serverId = serverId;
/* 42 */       this.userId = userId;
/* 43 */       this.sessionId = sessionId;
/* 44 */       this.token = token;
/*    */     }
/*    */     
/*    */     @JsonProperty("server_id")
/*    */     public String getServerId() {
/* 49 */       return this.serverId;
/*    */     }
/*    */     
/*    */     @JsonProperty("user_id")
/*    */     public String getUserId() {
/* 54 */       return this.userId;
/*    */     }
/*    */     
/*    */     @JsonProperty("session_id")
/*    */     public String getSessionId() {
/* 59 */       return this.sessionId;
/*    */     }
/*    */     
/*    */     public String getToken() {
/* 63 */       return this.token;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-voice-3.2.5.jar!\discord4j\voice\json\Identify.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */