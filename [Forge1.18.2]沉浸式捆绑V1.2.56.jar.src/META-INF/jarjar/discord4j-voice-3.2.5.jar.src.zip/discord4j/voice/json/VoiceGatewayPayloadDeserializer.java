/*    */ package discord4j.voice.json;
/*    */ 
/*    */ import com.fasterxml.jackson.core.JacksonException;
/*    */ import com.fasterxml.jackson.core.JsonParser;
/*    */ import com.fasterxml.jackson.databind.DeserializationContext;
/*    */ import com.fasterxml.jackson.databind.JsonNode;
/*    */ import com.fasterxml.jackson.databind.deser.std.StdDeserializer;
/*    */ import com.fasterxml.jackson.databind.node.ArrayNode;
/*    */ import java.io.IOException;
/*    */ import reactor.util.Logger;
/*    */ import reactor.util.Loggers;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VoiceGatewayPayloadDeserializer
/*    */   extends StdDeserializer<VoiceGatewayPayload<?>>
/*    */ {
/* 32 */   private static final Logger LOG = Loggers.getLogger(VoiceGatewayPayloadDeserializer.class);
/*    */   
/*    */   public VoiceGatewayPayloadDeserializer() {
/* 35 */     super(VoiceGatewayPayload.class);
/*    */   }
/*    */   @Nullable
/*    */   public VoiceGatewayPayload<?> deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/*    */     ArrayNode arrayNode;
/*    */     byte[] secret_key;
/* 41 */     JsonNode json = (JsonNode)p.getCodec().readTree(p);
/* 42 */     int op = json.get("op").asInt();
/* 43 */     JsonNode d = json.get("d");
/*    */     
/* 45 */     switch (op) {
/*    */       case 8:
/* 47 */         return new Hello(d.get("heartbeat_interval").asLong());
/*    */       case 2:
/* 49 */         return new Ready(d.get("ssrc").asInt(), d.get("ip").asText(), d.get("port").asInt());
/*    */       case 6:
/* 51 */         return new HeartbeatAck(d.asLong());
/*    */       case 4:
/* 53 */         arrayNode = (ArrayNode)d.get("secret_key");
/* 54 */         secret_key = (byte[])p.getCodec().readValue(arrayNode.traverse(p.getCodec()), byte[].class);
/* 55 */         return new SessionDescription(d.get("mode").asText(), secret_key);
/*    */       case 5:
/* 57 */         return new Speaking(d.get("user_id").asText(), d.get("ssrc").asInt(), d.get("speaking").asBoolean());
/*    */       case 13:
/* 59 */         return new VoiceDisconnect(d.get("user_id").asText());
/*    */       case 9:
/* 61 */         return new Resumed(d.asText());
/*    */     } 
/* 63 */     LOG.debug("Received voice gateway payload with unhandled OP: {}", new Object[] { Integer.valueOf(op) });
/* 64 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-voice-3.2.5.jar!\discord4j\voice\json\VoiceGatewayPayloadDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */