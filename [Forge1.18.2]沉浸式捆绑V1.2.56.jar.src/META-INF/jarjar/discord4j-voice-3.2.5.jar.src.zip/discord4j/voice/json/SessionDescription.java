/*    */ package discord4j.voice.json;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SessionDescription
/*    */   extends VoiceGatewayPayload<SessionDescription.Data>
/*    */ {
/*    */   public static final int OP = 4;
/*    */   
/*    */   public SessionDescription(Data data) {
/* 24 */     super(4, data);
/*    */   }
/*    */   
/*    */   public SessionDescription(String mode, byte[] secretKey) {
/* 28 */     this(new Data(mode, secretKey));
/*    */   }
/*    */   
/*    */   public static class Data
/*    */   {
/*    */     private final String mode;
/*    */     private final byte[] secretKey;
/*    */     
/*    */     public Data(String mode, byte[] secretKey) {
/* 37 */       this.mode = mode;
/* 38 */       this.secretKey = secretKey;
/*    */     }
/*    */     
/*    */     public String getMode() {
/* 42 */       return this.mode;
/*    */     }
/*    */     
/*    */     public byte[] getSecretKey() {
/* 46 */       return this.secretKey;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-voice-3.2.5.jar!\discord4j\voice\json\SessionDescription.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */