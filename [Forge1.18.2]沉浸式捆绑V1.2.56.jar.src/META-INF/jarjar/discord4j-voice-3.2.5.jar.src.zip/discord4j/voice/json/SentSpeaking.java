/*    */ package discord4j.voice.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SentSpeaking
/*    */   extends VoiceGatewayPayload<SentSpeaking.Data>
/*    */ {
/*    */   public SentSpeaking(boolean speaking, int delay, int ssrc) {
/* 24 */     super(5, new Data(speaking, delay, ssrc));
/*    */   }
/*    */   
/*    */   public static class Data
/*    */   {
/*    */     private final boolean speaking;
/*    */     private final int delay;
/*    */     private final int ssrc;
/*    */     
/*    */     public Data(boolean speaking, int delay, int ssrc) {
/* 34 */       this.speaking = speaking;
/* 35 */       this.delay = delay;
/* 36 */       this.ssrc = ssrc;
/*    */     }
/*    */     
/*    */     @JsonProperty("speaking")
/*    */     public boolean isSpeaking() {
/* 41 */       return this.speaking;
/*    */     }
/*    */     
/*    */     public int getDelay() {
/* 45 */       return this.delay;
/*    */     }
/*    */     
/*    */     public int getSsrc() {
/* 49 */       return this.ssrc;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-voice-3.2.5.jar!\discord4j\voice\json\SentSpeaking.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */