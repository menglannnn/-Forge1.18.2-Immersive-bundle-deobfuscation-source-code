/*     */ package discord4j.voice;
/*     */ 
/*     */ import discord4j.common.LogUtil;
/*     */ import discord4j.common.sinks.EmissionStrategy;
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.buffer.ByteBufUtil;
/*     */ import io.netty.buffer.Unpooled;
/*     */ import io.netty.channel.Channel;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.SocketAddress;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.time.Duration;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.core.publisher.Sinks;
/*     */ import reactor.netty.Connection;
/*     */ import reactor.netty.ConnectionObserver;
/*     */ import reactor.netty.udp.UdpClient;
/*     */ import reactor.netty.udp.UdpInbound;
/*     */ import reactor.netty.udp.UdpOutbound;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.Loggers;
/*     */ import reactor.util.concurrent.Queues;
/*     */ import reactor.util.context.ContextView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VoiceSocket
/*     */ {
/*  49 */   private static final Logger log = Loggers.getLogger(VoiceSocket.class);
/*  50 */   private static final Logger senderLog = Loggers.getLogger("discord4j.voice.protocol.udp.sender");
/*  51 */   private static final Logger receiverLog = Loggers.getLogger("discord4j.voice.protocol.udp.receiver");
/*     */   
/*     */   static final String PROTOCOL = "udp";
/*     */   
/*     */   static final String ENCRYPTION_MODE = "xsalsa20_poly1305";
/*     */   private static final int DISCOVERY_PACKET_LENGTH = 74;
/*     */   private static final int TYPE_LENGTH_SSRC_LENGTH = 8;
/*     */   private final UdpClient udpClient;
/*     */   private final Sinks.Many<ByteBuf> inbound;
/*     */   private final Sinks.Many<ByteBuf> outbound;
/*     */   private final EmissionStrategy emissionStrategy;
/*     */   
/*     */   public VoiceSocket(UdpClient udpClient) {
/*  64 */     this.udpClient = udpClient;
/*  65 */     this.inbound = newEmitterSink();
/*  66 */     this.outbound = newEmitterSink();
/*  67 */     this.emissionStrategy = (EmissionStrategy)EmissionStrategy.timeoutDrop(Duration.ofSeconds(5L));
/*     */   }
/*     */   
/*     */   private static <T> Sinks.Many<T> newEmitterSink() {
/*  71 */     return Sinks.many().multicast().onBackpressureBuffer(Queues.SMALL_BUFFER_SIZE, false);
/*     */   }
/*     */   
/*     */   Mono<Connection> setup(String address, int port) {
/*  75 */     return Mono.deferContextual(context -> this.udpClient.host(address).port(port).observe(getObserver(context)).doOnConnected(()).doOnDisconnected(()).handle(()).connect());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private SocketAddress address(Connection connection) {
/*  98 */     Channel c = connection.channel();
/*  99 */     if (c instanceof io.netty.channel.socket.DatagramChannel) {
/* 100 */       SocketAddress a = c.remoteAddress();
/* 101 */       return (a != null) ? a : c.localAddress();
/*     */     } 
/* 103 */     return c.remoteAddress();
/*     */   }
/*     */   
/*     */   private ConnectionObserver getObserver(ContextView context) {
/* 107 */     return (connection, newState) -> log.debug(LogUtil.format(context, "{} {}"), new Object[] { newState, connection });
/*     */   }
/*     */   
/*     */   private void logPayload(Logger logger, ContextView context, ByteBuf buf) {
/* 111 */     logger.trace(LogUtil.format(context, ByteBufUtil.hexDump(buf)));
/*     */   }
/*     */ 
/*     */   
/*     */   Mono<InetSocketAddress> performIpDiscovery(int ssrc) {
/* 116 */     Mono<Void> sendDiscoveryPacket = Mono.fromRunnable(() -> {
/*     */           ByteBuf discoveryPacket = Unpooled.buffer(74).writeShort(1).writeShort(70).writeInt(ssrc).writeZero(66);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           this.emissionStrategy.emitNext(this.outbound, discoveryPacket);
/*     */         });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 133 */     Mono<InetSocketAddress> parseResponse = this.inbound.asFlux().next().map(buf -> {
/*     */           String address = getNullTerminatedString(buf, 8);
/*     */ 
/*     */           
/*     */           int port = buf.getUnsignedShortLE(72);
/*     */           
/*     */           buf.release();
/*     */           
/*     */           return InetSocketAddress.createUnresolved(address, port);
/*     */         });
/*     */     
/* 144 */     return sendDiscoveryPacket.then(parseResponse);
/*     */   }
/*     */   
/*     */   void send(ByteBuf data) {
/* 148 */     this.emissionStrategy.emitNext(this.outbound, data);
/*     */   }
/*     */   
/*     */   Flux<ByteBuf> getInbound() {
/* 152 */     return this.inbound.asFlux();
/*     */   }
/*     */   
/*     */   private static String getNullTerminatedString(ByteBuf buffer, int offset) {
/* 156 */     buffer.skipBytes(offset);
/* 157 */     ByteArrayOutputStream os = new ByteArrayOutputStream(15);
/*     */     byte c;
/* 159 */     while ((c = buffer.readByte()) != 0) {
/* 160 */       os.write(c);
/*     */     }
/*     */     
/* 163 */     return new String(os.toByteArray(), StandardCharsets.US_ASCII);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-voice-3.2.5.jar!\discord4j\voice\VoiceSocket.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */