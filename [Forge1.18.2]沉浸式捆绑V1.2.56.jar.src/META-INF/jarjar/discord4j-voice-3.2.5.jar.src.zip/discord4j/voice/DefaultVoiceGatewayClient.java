/*     */ package discord4j.voice;
/*     */ 
/*     */ import com.fasterxml.jackson.core.type.TypeReference;
/*     */ import com.fasterxml.jackson.databind.ObjectMapper;
/*     */ import com.iwebpp.crypto.TweetNaclFast;
/*     */ import discord4j.common.JacksonResources;
/*     */ import discord4j.common.LogUtil;
/*     */ import discord4j.common.ResettableInterval;
/*     */ import discord4j.common.close.CloseException;
/*     */ import discord4j.common.close.CloseStatus;
/*     */ import discord4j.common.close.DisconnectBehavior;
/*     */ import discord4j.common.retry.ReconnectContext;
/*     */ import discord4j.common.retry.ReconnectOptions;
/*     */ import discord4j.common.sinks.EmissionStrategy;
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.voice.json.Heartbeat;
/*     */ import discord4j.voice.json.Hello;
/*     */ import discord4j.voice.json.Identify;
/*     */ import discord4j.voice.json.Ready;
/*     */ import discord4j.voice.json.Resume;
/*     */ import discord4j.voice.json.SelectProtocol;
/*     */ import discord4j.voice.json.SentSpeaking;
/*     */ import discord4j.voice.json.SessionDescription;
/*     */ import discord4j.voice.json.VoiceGatewayPayload;
/*     */ import discord4j.voice.retry.VoiceGatewayException;
/*     */ import discord4j.voice.retry.VoiceGatewayRetrySignal;
/*     */ import discord4j.voice.retry.VoiceGatewayRetrySpec;
/*     */ import discord4j.voice.retry.VoiceServerUpdateReconnectException;
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.buffer.ByteBufInputStream;
/*     */ import io.netty.buffer.Unpooled;
/*     */ import io.netty.handler.codec.http.HttpHeaderNames;
/*     */ import io.netty.handler.codec.http.HttpHeaders;
/*     */ import java.io.InputStream;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.time.Duration;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Function;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.Disposables;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.core.publisher.MonoSink;
/*     */ import reactor.core.publisher.Sinks;
/*     */ import reactor.function.TupleUtils;
/*     */ import reactor.netty.Connection;
/*     */ import reactor.netty.http.client.HttpClient;
/*     */ import reactor.netty.http.client.WebsocketClientSpec;
/*     */ import reactor.netty.http.websocket.WebsocketInbound;
/*     */ import reactor.netty.http.websocket.WebsocketOutbound;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.Loggers;
/*     */ import reactor.util.concurrent.Queues;
/*     */ import reactor.util.context.Context;
/*     */ import reactor.util.context.ContextView;
/*     */ import reactor.util.function.Tuple2;
/*     */ import reactor.util.retry.Retry;
/*     */ import reactor.util.retry.RetrySpec;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultVoiceGatewayClient
/*     */ {
/*  73 */   private static final Logger log = Loggers.getLogger(DefaultVoiceGatewayClient.class);
/*  74 */   private static final Logger senderLog = Loggers.getLogger("discord4j.voice.protocol.sender");
/*  75 */   private static final Logger receiverLog = Loggers.getLogger("discord4j.voice.protocol.receiver");
/*     */   
/*     */   private final Snowflake guildId;
/*     */   
/*     */   private final Snowflake selfId;
/*     */   
/*     */   private final Function<VoiceGatewayPayload<?>, Mono<ByteBuf>> payloadWriter;
/*     */   
/*     */   private final Function<ByteBuf, Mono<? super VoiceGatewayPayload<?>>> payloadReader;
/*     */   
/*     */   private final VoiceReactorResources reactorResources;
/*     */   
/*     */   private final ReconnectOptions reconnectOptions;
/*     */   
/*     */   private final ReconnectContext reconnectContext;
/*     */   
/*     */   private final AudioProvider audioProvider;
/*     */   
/*     */   private final AudioReceiver audioReceiver;
/*     */   
/*     */   private final VoiceSendTaskFactory sendTaskFactory;
/*     */   
/*     */   private final VoiceReceiveTaskFactory receiveTaskFactory;
/*     */   
/*     */   private final VoiceDisconnectTask disconnectTask;
/*     */   
/*     */   private final VoiceServerUpdateTask serverUpdateTask;
/*     */   
/*     */   private final VoiceChannelRetrieveTask channelRetrieveTask;
/*     */   
/*     */   private final Duration ipDiscoveryTimeout;
/*     */   
/*     */   private final RetrySpec ipDiscoveryRetrySpec;
/*     */   
/*     */   private final HttpClient httpClient;
/*     */   
/*     */   private final VoiceSocket voiceSocket;
/*     */   
/*     */   private final ResettableInterval heartbeat;
/*     */   
/*     */   private final Disposable.Swap cleanup;
/*     */   private final EmissionStrategy emissionStrategy;
/*     */   private final Sinks.Many<ByteBuf> receiver;
/*     */   private final Sinks.Many<VoiceGatewayPayload<?>> outbound;
/*     */   private final Sinks.Many<VoiceGatewayEvent> events;
/*     */   private final Sinks.Many<VoiceConnection.State> state;
/* 121 */   private final AtomicReference<VoiceServerOptions> serverOptions = new AtomicReference<>();
/* 122 */   private final AtomicReference<String> session = new AtomicReference<>();
/*     */   
/*     */   private volatile int ssrc;
/*     */   private volatile Sinks.One<CloseStatus> disconnectNotifier;
/*     */   private volatile ContextView currentContext;
/*     */   private volatile VoiceWebsocketHandler sessionHandler;
/*     */   
/*     */   public DefaultVoiceGatewayClient(VoiceGatewayOptions options) {
/* 130 */     this.guildId = options.getGuildId();
/* 131 */     this.selfId = options.getSelfId();
/* 132 */     ObjectMapper mapper = ((JacksonResources)Objects.<JacksonResources>requireNonNull(options.getJacksonResources())).getObjectMapper();
/*     */     
/* 134 */     this.payloadWriter = (payload -> Mono.fromCallable(()));
/*     */     
/* 136 */     this.payloadReader = (buf -> Mono.fromCallable(()));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 142 */     this.reactorResources = Objects.<VoiceReactorResources>requireNonNull(options.getReactorResources());
/* 143 */     this.reconnectOptions = Objects.<ReconnectOptions>requireNonNull(options.getReconnectOptions());
/* 144 */     this
/* 145 */       .reconnectContext = new ReconnectContext(this.reconnectOptions.getFirstBackoff(), this.reconnectOptions.getMaxBackoffInterval());
/* 146 */     this.audioProvider = Objects.<AudioProvider>requireNonNull(options.getAudioProvider());
/* 147 */     this.audioReceiver = Objects.<AudioReceiver>requireNonNull(options.getAudioReceiver());
/* 148 */     this.sendTaskFactory = Objects.<VoiceSendTaskFactory>requireNonNull(options.getSendTaskFactory());
/* 149 */     this.receiveTaskFactory = Objects.<VoiceReceiveTaskFactory>requireNonNull(options.getReceiveTaskFactory());
/* 150 */     this.disconnectTask = Objects.<VoiceDisconnectTask>requireNonNull(options.getDisconnectTask());
/* 151 */     this.serverUpdateTask = Objects.<VoiceServerUpdateTask>requireNonNull(options.getServerUpdateTask());
/* 152 */     this.channelRetrieveTask = Objects.<VoiceChannelRetrieveTask>requireNonNull(options.getChannelRetrieveTask());
/* 153 */     this.ipDiscoveryTimeout = Objects.<Duration>requireNonNull(options.getIpDiscoveryTimeout());
/* 154 */     this.ipDiscoveryRetrySpec = Objects.<RetrySpec>requireNonNull(options.getIpDiscoveryRetrySpec());
/*     */     
/* 156 */     this
/* 157 */       .httpClient = this.reactorResources.getHttpClient().headers(headers -> headers.add((CharSequence)HttpHeaderNames.USER_AGENT, "DiscordBot(https://discord4j.com, 3)"));
/* 158 */     this.voiceSocket = new VoiceSocket(this.reactorResources.getUdpClient());
/* 159 */     this.heartbeat = new ResettableInterval(this.reactorResources.getTimerTaskScheduler());
/* 160 */     this.cleanup = Disposables.swap();
/* 161 */     this.emissionStrategy = (EmissionStrategy)EmissionStrategy.timeoutDrop(Duration.ofSeconds(5L));
/*     */     
/* 163 */     this.receiver = newEmitterSink();
/* 164 */     this.outbound = newEmitterSink();
/* 165 */     this.events = newEmitterSink();
/* 166 */     this.state = Sinks.many().replay().latestOrDefault(VoiceConnection.State.CONNECTING);
/*     */   }
/*     */   
/*     */   private static <T> Sinks.Many<T> newEmitterSink() {
/* 170 */     return Sinks.many().multicast().onBackpressureBuffer(Queues.SMALL_BUFFER_SIZE, false);
/*     */   }
/*     */   
/*     */   public Mono<VoiceConnection> start(VoiceServerOptions voiceServerOptions, String session) {
/* 174 */     return Mono.create(sink -> sink.onRequest(()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Mono<Void> connect(VoiceServerOptions vso, String sessionId, MonoSink<VoiceConnection> voiceConnectionSink) {
/* 186 */     return Mono.deferContextual(context -> {
/*     */           this.serverOptions.compareAndSet(null, vso);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           this.session.compareAndSet(null, sessionId);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           this.disconnectNotifier = Sinks.one();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           this.currentContext = context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           Flux<ByteBuf> outFlux = this.outbound.asFlux().flatMap(this.payloadWriter).doOnNext(());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           this.sessionHandler = new VoiceWebsocketHandler(this.receiver, outFlux, context);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           Mono<?> onOpen = this.state.asFlux().next().doOnNext(());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           Disposable.Composite innerCleanup = Disposables.composite();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           Mono<Void> receiverFuture = this.receiver.asFlux().doOnNext(()).flatMap(this.payloadReader).doOnNext(()).then();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           Mono<Void> heartbeatHandler = this.heartbeat.ticks().map(Heartbeat::new).doOnNext(()).then();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           Mono<Void> httpFuture = ((HttpClient.WebsocketSender)this.httpClient.websocket(((WebsocketClientSpec.Builder)WebsocketClientSpec.builder().maxFramePayloadLength(2147483647)).build()).uri(((VoiceServerOptions)this.serverOptions.get()).getEndpoint() + "?v=4")).handle(()).contextWrite(LogUtil.clearContext()).flatMap(()).then();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           Objects.requireNonNull(this.heartbeat);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           return Mono.zip(httpFuture, receiverFuture, heartbeatHandler).doOnError(()).doOnTerminate(this.heartbeat::stop).doOnCancel(()).then();
/* 307 */         }).contextWrite(ctx -> ctx.put("discord4j.guild", this.guildId.asString()))
/* 308 */       .retryWhen(retryFactory())
/* 309 */       .then(Mono.defer(() -> this.disconnectNotifier.asMono().then()))
/* 310 */       .doOnSubscribe(s -> {
/*     */           if (this.disconnectNotifier != null) {
/*     */             throw new IllegalStateException("connect can only be subscribed once");
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   private VoiceConnection acquireConnection() {
/* 319 */     return new VoiceConnection()
/*     */       {
/*     */         public Flux<VoiceGatewayEvent> events()
/*     */         {
/* 323 */           return DefaultVoiceGatewayClient.this.events.asFlux();
/*     */         }
/*     */ 
/*     */         
/*     */         public Flux<VoiceConnection.State> stateEvents() {
/* 328 */           return DefaultVoiceGatewayClient.this.state.asFlux();
/*     */         }
/*     */ 
/*     */         
/*     */         public Mono<Void> disconnect() {
/* 333 */           return onConnectOrDisconnect()
/* 334 */             .flatMap(s -> s.equals(VoiceConnection.State.CONNECTED) ? DefaultVoiceGatewayClient.this.stop() : Mono.empty())
/* 335 */             .then();
/*     */         }
/*     */ 
/*     */         
/*     */         public Snowflake getGuildId() {
/* 340 */           return DefaultVoiceGatewayClient.this.guildId;
/*     */         }
/*     */ 
/*     */         
/*     */         public Mono<Snowflake> getChannelId() {
/* 345 */           return onConnectOrDisconnect()
/* 346 */             .flatMap(s -> s.equals(VoiceConnection.State.CONNECTED) ? DefaultVoiceGatewayClient.this.channelRetrieveTask.onRequest() : Mono.empty());
/*     */         }
/*     */ 
/*     */         
/*     */         public Mono<Void> reconnect() {
/* 351 */           return reconnect(discord4j.voice.retry.VoiceGatewayReconnectException::new);
/*     */         }
/*     */ 
/*     */         
/*     */         public Mono<Void> reconnect(Function<ContextView, Throwable> errorCause) {
/* 356 */           return onConnectOrDisconnect()
/* 357 */             .flatMap(s -> s.equals(VoiceConnection.State.CONNECTED) ? Mono.fromRunnable(()).then(stateEvents().filter(()).next()) : Mono.error(new IllegalStateException("Voice connection has already disconnected")))
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 365 */             .then();
/*     */         }
/*     */       };
/*     */   }
/*     */   
/*     */   public Mono<Void> stop() {
/* 371 */     return Mono.defer(() -> {
/*     */           if (this.sessionHandler == null || this.disconnectNotifier == null) {
/*     */             return Mono.error(new IllegalStateException("Gateway client is not active!"));
/*     */           }
/*     */           this.sessionHandler.close(DisconnectBehavior.stop(null));
/*     */           return this.disconnectNotifier.asMono().then();
/*     */         });
/*     */   }
/*     */   
/*     */   private void logPayload(Logger logger, ContextView context, ByteBuf buf) {
/* 381 */     if (logger.isTraceEnabled()) {
/* 382 */       logger.trace(LogUtil.format(context, buf.toString(StandardCharsets.UTF_8)
/* 383 */             .replaceAll("(\"token\": ?\")([A-Za-z0-9._-]*)(\")", "$1hunter2$3")));
/*     */     }
/*     */   }
/*     */   
/*     */   private Retry retryFactory() {
/* 388 */     return (Retry)VoiceGatewayRetrySpec.create(this.reconnectOptions, this.reconnectContext)
/* 389 */       .doBeforeRetry(retry -> {
/*     */           this.emissionStrategy.emitNext(this.state, retry.nextState());
/*     */           long attempt = retry.iteration();
/*     */           Duration backoff = retry.nextBackoff();
/*     */           log.debug(LogUtil.format(getContextFromException(retry.failure()), "{} in {} (attempts: {})"), new Object[] { retry.nextState(), backoff, Long.valueOf(attempt) });
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   private ContextView getContextFromException(Throwable t) {
/* 399 */     if (t instanceof CloseException) {
/* 400 */       return ((CloseException)t).getContext();
/*     */     }
/* 402 */     if (t instanceof VoiceGatewayException) {
/* 403 */       return ((VoiceGatewayException)t).getContext();
/*     */     }
/* 405 */     return (ContextView)Context.empty();
/*     */   }
/*     */   
/*     */   private Mono<CloseStatus> handleClose(DisconnectBehavior sourceBehavior, CloseStatus closeStatus) {
/* 409 */     return Mono.deferContextual(ctx -> {
/*     */           DisconnectBehavior behavior;
/*     */           if (VoiceGatewayRetrySpec.NON_RETRYABLE_STATUS_CODES.contains(Integer.valueOf(closeStatus.getCode()))) {
/*     */             behavior = DisconnectBehavior.stop(sourceBehavior.getCause());
/*     */           } else {
/*     */             behavior = sourceBehavior;
/*     */           } 
/*     */           log.debug(LogUtil.format(ctx, "Closing and {} with status {}"), new Object[] { behavior, closeStatus });
/*     */           this.heartbeat.stop();
/*     */           if (behavior.getAction() == DisconnectBehavior.Action.STOP)
/*     */             this.cleanup.dispose(); 
/*     */           switch (behavior.getAction()) {
/*     */             case STOP_ABRUPTLY:
/*     */             case STOP:
/*     */               return (behavior.getCause() != null) ? Mono.just(new CloseException(closeStatus, ctx, behavior.getCause())).flatMap(()) : Mono.just(closeStatus).flatMap(());
/*     */           } 
/*     */           return Mono.error((Throwable)new CloseException(closeStatus, ctx, behavior.getCause()));
/*     */         });
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-voice-3.2.5.jar!\discord4j\voice\DefaultVoiceGatewayClient.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */