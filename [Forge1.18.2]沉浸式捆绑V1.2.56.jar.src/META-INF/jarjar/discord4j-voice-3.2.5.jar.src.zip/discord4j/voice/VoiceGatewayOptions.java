/*     */ package discord4j.voice;
/*     */ 
/*     */ import discord4j.common.JacksonResources;
/*     */ import discord4j.common.retry.ReconnectOptions;
/*     */ import discord4j.common.util.Snowflake;
/*     */ import java.time.Duration;
/*     */ import reactor.util.retry.RetrySpec;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VoiceGatewayOptions
/*     */ {
/*     */   private final Snowflake guildId;
/*     */   private final Snowflake selfId;
/*     */   private final String session;
/*     */   private final VoiceServerOptions voiceServerOptions;
/*     */   private final JacksonResources jacksonResources;
/*     */   private final VoiceReactorResources reactorResources;
/*     */   private final ReconnectOptions reconnectOptions;
/*     */   private final AudioProvider audioProvider;
/*     */   private final AudioReceiver audioReceiver;
/*     */   private final VoiceSendTaskFactory sendTaskFactory;
/*     */   private final VoiceReceiveTaskFactory receiveTaskFactory;
/*     */   private final VoiceDisconnectTask disconnectTask;
/*     */   private final VoiceServerUpdateTask serverUpdateTask;
/*     */   private final VoiceStateUpdateTask stateUpdateTask;
/*     */   private final VoiceChannelRetrieveTask channelRetrieveTask;
/*     */   private final Duration ipDiscoveryTimeout;
/*     */   private final RetrySpec ipDiscoveryRetrySpec;
/*     */   
/*     */   public VoiceGatewayOptions(Snowflake guildId, Snowflake selfId, String session, VoiceServerOptions voiceServerOptions, JacksonResources jacksonResources, VoiceReactorResources reactorResources, ReconnectOptions reconnectOptions, AudioProvider audioProvider, AudioReceiver audioReceiver, VoiceSendTaskFactory sendTaskFactory, VoiceReceiveTaskFactory receiveTaskFactory, VoiceDisconnectTask disconnectTask, VoiceServerUpdateTask serverUpdateTask, VoiceStateUpdateTask stateUpdateTask, VoiceChannelRetrieveTask channelRetrieveTask, Duration ipDiscoveryTimeout, RetrySpec ipDiscoveryRetrySpec) {
/*  58 */     this.guildId = guildId;
/*  59 */     this.selfId = selfId;
/*  60 */     this.session = session;
/*  61 */     this.voiceServerOptions = voiceServerOptions;
/*  62 */     this.jacksonResources = jacksonResources;
/*  63 */     this.reactorResources = reactorResources;
/*  64 */     this.reconnectOptions = reconnectOptions;
/*  65 */     this.audioProvider = audioProvider;
/*  66 */     this.audioReceiver = audioReceiver;
/*  67 */     this.sendTaskFactory = sendTaskFactory;
/*  68 */     this.receiveTaskFactory = receiveTaskFactory;
/*  69 */     this.disconnectTask = disconnectTask;
/*  70 */     this.serverUpdateTask = serverUpdateTask;
/*  71 */     this.stateUpdateTask = stateUpdateTask;
/*  72 */     this.channelRetrieveTask = channelRetrieveTask;
/*  73 */     this.ipDiscoveryTimeout = ipDiscoveryTimeout;
/*  74 */     this.ipDiscoveryRetrySpec = ipDiscoveryRetrySpec;
/*     */   }
/*     */   
/*     */   public Snowflake getGuildId() {
/*  78 */     return this.guildId;
/*     */   }
/*     */   
/*     */   public Snowflake getSelfId() {
/*  82 */     return this.selfId;
/*     */   }
/*     */   
/*     */   public String getSession() {
/*  86 */     return this.session;
/*     */   }
/*     */   
/*     */   public VoiceServerOptions getVoiceServerOptions() {
/*  90 */     return this.voiceServerOptions;
/*     */   }
/*     */   
/*     */   public JacksonResources getJacksonResources() {
/*  94 */     return this.jacksonResources;
/*     */   }
/*     */   
/*     */   public VoiceReactorResources getReactorResources() {
/*  98 */     return this.reactorResources;
/*     */   }
/*     */   
/*     */   public ReconnectOptions getReconnectOptions() {
/* 102 */     return this.reconnectOptions;
/*     */   }
/*     */   
/*     */   public AudioProvider getAudioProvider() {
/* 106 */     return this.audioProvider;
/*     */   }
/*     */   
/*     */   public AudioReceiver getAudioReceiver() {
/* 110 */     return this.audioReceiver;
/*     */   }
/*     */   
/*     */   public VoiceSendTaskFactory getSendTaskFactory() {
/* 114 */     return this.sendTaskFactory;
/*     */   }
/*     */   
/*     */   public VoiceReceiveTaskFactory getReceiveTaskFactory() {
/* 118 */     return this.receiveTaskFactory;
/*     */   }
/*     */   
/*     */   public VoiceDisconnectTask getDisconnectTask() {
/* 122 */     return this.disconnectTask;
/*     */   }
/*     */   
/*     */   public VoiceServerUpdateTask getServerUpdateTask() {
/* 126 */     return this.serverUpdateTask;
/*     */   }
/*     */   
/*     */   public VoiceStateUpdateTask getStateUpdateTask() {
/* 130 */     return this.stateUpdateTask;
/*     */   }
/*     */   
/*     */   public VoiceChannelRetrieveTask getChannelRetrieveTask() {
/* 134 */     return this.channelRetrieveTask;
/*     */   }
/*     */   
/*     */   public Duration getIpDiscoveryTimeout() {
/* 138 */     return this.ipDiscoveryTimeout;
/*     */   }
/*     */   
/*     */   public RetrySpec getIpDiscoveryRetrySpec() {
/* 142 */     return this.ipDiscoveryRetrySpec;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-voice-3.2.5.jar!\discord4j\voice\VoiceGatewayOptions.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */