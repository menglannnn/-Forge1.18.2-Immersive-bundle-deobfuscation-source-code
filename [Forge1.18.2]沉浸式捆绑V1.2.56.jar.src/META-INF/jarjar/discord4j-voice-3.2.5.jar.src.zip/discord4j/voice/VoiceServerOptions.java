/*    */ package discord4j.voice;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VoiceServerOptions
/*    */ {
/*    */   private final String token;
/*    */   private final String endpoint;
/*    */   
/*    */   public VoiceServerOptions(String token, String endpoint) {
/* 29 */     this.token = token;
/* 30 */     this.endpoint = endpoint.replace(":80", "");
/*    */   }
/*    */   
/*    */   public String getToken() {
/* 34 */     return this.token;
/*    */   }
/*    */   
/*    */   public String getEndpoint() {
/* 38 */     return this.endpoint;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-voice-3.2.5.jar!\discord4j\voice\VoiceServerOptions.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */