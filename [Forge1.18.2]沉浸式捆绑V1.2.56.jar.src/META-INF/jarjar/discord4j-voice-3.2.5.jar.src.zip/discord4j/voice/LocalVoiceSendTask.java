/*    */ package discord4j.voice;
/*    */ 
/*    */ import io.netty.buffer.ByteBuf;
/*    */ import io.netty.buffer.Unpooled;
/*    */ import java.util.concurrent.TimeUnit;
/*    */ import java.util.concurrent.atomic.AtomicBoolean;
/*    */ import java.util.function.Consumer;
/*    */ import reactor.core.Disposable;
/*    */ import reactor.core.scheduler.Scheduler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LocalVoiceSendTask
/*    */   implements Disposable
/*    */ {
/*    */   private final Consumer<Boolean> speakingSender;
/*    */   private final Consumer<ByteBuf> voiceSender;
/*    */   private final AudioProvider provider;
/*    */   private final PacketTransformer transformer;
/*    */   private final Disposable task;
/* 38 */   private final AtomicBoolean speaking = new AtomicBoolean();
/* 39 */   private final AtomicBoolean sentSilence = new AtomicBoolean();
/* 40 */   private final byte[] silence = new byte[] { -8, -1, -2 };
/*    */ 
/*    */   
/*    */   public LocalVoiceSendTask(Scheduler scheduler, Consumer<Boolean> speakingSender, Consumer<ByteBuf> voiceSender, AudioProvider provider, PacketTransformer transformer) {
/* 44 */     this.speakingSender = speakingSender;
/* 45 */     this.voiceSender = voiceSender;
/* 46 */     this.provider = provider;
/* 47 */     this.transformer = transformer;
/* 48 */     this.task = scheduler.schedulePeriodically(this::run, 0L, 20L, TimeUnit.MILLISECONDS);
/*    */   }
/*    */ 
/*    */   
/*    */   public void dispose() {
/* 53 */     if (this.speaking.compareAndSet(true, false)) {
/* 54 */       changeSpeaking(false);
/*    */     }
/* 56 */     this.task.dispose();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isDisposed() {
/* 61 */     return this.task.isDisposed();
/*    */   }
/*    */   
/*    */   private void run() {
/* 65 */     if (this.provider.provide()) {
/* 66 */       if (this.speaking.compareAndSet(false, true)) {
/* 67 */         changeSpeaking(true);
/*    */       }
/*    */       
/* 70 */       byte[] b = new byte[this.provider.getBuffer().limit()];
/* 71 */       this.provider.getBuffer().get(b);
/* 72 */       this.provider.getBuffer().clear();
/* 73 */       ByteBuf packet = Unpooled.wrappedBuffer(this.transformer.nextSend(b));
/*    */       
/* 75 */       this.voiceSender.accept(packet);
/* 76 */     } else if (this.speaking.compareAndSet(true, false)) {
/* 77 */       changeSpeaking(false);
/* 78 */     } else if (this.sentSilence.compareAndSet(false, true)) {
/* 79 */       this.voiceSender.accept(Unpooled.wrappedBuffer(this.transformer.nextSend(this.silence)));
/*    */     } 
/*    */   }
/*    */   
/*    */   private void changeSpeaking(boolean speaking) {
/* 84 */     this.speakingSender.accept(Boolean.valueOf(speaking));
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-voice-3.2.5.jar!\discord4j\voice\LocalVoiceSendTask.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */