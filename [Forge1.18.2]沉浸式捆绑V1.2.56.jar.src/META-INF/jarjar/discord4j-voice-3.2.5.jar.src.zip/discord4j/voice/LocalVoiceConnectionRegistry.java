/*    */ package discord4j.voice;
/*    */ 
/*    */ import discord4j.common.util.Snowflake;
/*    */ import java.util.Map;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ import org.reactivestreams.Subscription;
/*    */ import reactor.core.publisher.Mono;
/*    */ import reactor.core.publisher.SignalType;
/*    */ import reactor.util.Logger;
/*    */ import reactor.util.Loggers;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LocalVoiceConnectionRegistry
/*    */   implements VoiceConnectionRegistry
/*    */ {
/* 33 */   private static final Logger log = Loggers.getLogger(LocalVoiceConnectionRegistry.class);
/*    */   
/* 35 */   private final Map<Long, VoiceConnection> voiceConnections = new ConcurrentHashMap<>();
/*    */ 
/*    */   
/*    */   public Mono<VoiceConnection> getVoiceConnection(Snowflake guildId) {
/* 39 */     return Mono.fromCallable(() -> (VoiceConnection)this.voiceConnections.get(Long.valueOf(guildId.asLong())))
/* 40 */       .flatMap(vc -> vc.stateEvents().next().doOnNext(()).thenReturn(vc))
/*    */ 
/*    */ 
/*    */       
/* 44 */       .switchIfEmpty(Mono.empty()
/* 45 */         .doOnSubscribe(s -> log.debug("No connection in registry to guild {}", new Object[] { Long.valueOf(guildId.asLong()) })));
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Void> registerVoiceConnection(Snowflake guildId, VoiceConnection voiceConnection) {
/* 50 */     return Mono.fromCallable(() -> (VoiceConnection)this.voiceConnections.put(Long.valueOf(guildId.asLong()), voiceConnection))
/* 51 */       .flatMap(previous -> {
/*    */           if (!previous.equals(voiceConnection)) {
/*    */             log.debug("Removing previous guild {} connection from registry", new Object[] { Long.valueOf(guildId.asLong()) });
/*    */             
/*    */             return previous.disconnect();
/*    */           } 
/*    */           return Mono.empty();
/* 58 */         }).doFinally(signal -> log.debug("Connection registry to guild {} done after {}", new Object[] { Long.valueOf(guildId.asLong()), signal }));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Mono<Void> disconnect(Snowflake guildId) {
/* 64 */     return getVoiceConnection(guildId)
/* 65 */       .flatMap(connection -> connection.disconnect().doFinally(()));
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-voice-3.2.5.jar!\discord4j\voice\LocalVoiceConnectionRegistry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */