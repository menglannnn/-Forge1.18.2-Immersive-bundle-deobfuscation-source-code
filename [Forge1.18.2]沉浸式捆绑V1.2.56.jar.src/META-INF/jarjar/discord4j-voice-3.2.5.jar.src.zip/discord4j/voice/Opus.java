package discord4j.voice;

public final class Opus {
  public static final int SAMPLE_RATE = 48000;
  
  public static final int FRAME_TIME = 20;
  
  public static final int FRAME_SIZE = 960;
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-voice-3.2.5.jar!\discord4j\voice\Opus.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */