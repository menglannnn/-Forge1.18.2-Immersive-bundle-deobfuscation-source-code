/*    */ package discord4j.voice;
/*    */ 
/*    */ import io.netty.buffer.ByteBuf;
/*    */ import org.reactivestreams.Publisher;
/*    */ import reactor.core.Disposable;
/*    */ import reactor.core.publisher.Flux;
/*    */ import reactor.core.publisher.Mono;
/*    */ import reactor.core.scheduler.Scheduler;
/*    */ import reactor.util.Logger;
/*    */ import reactor.util.Loggers;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LocalVoiceReceiveTask
/*    */   implements Disposable
/*    */ {
/* 33 */   private static final Logger log = Loggers.getLogger(LocalVoiceReceiveTask.class);
/*    */   
/*    */   private final Disposable task;
/*    */ 
/*    */   
/*    */   public LocalVoiceReceiveTask(Scheduler scheduler, Flux<ByteBuf> in, PacketTransformer transformer, AudioReceiver receiver) {
/* 39 */     this
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 54 */       .task = in.flatMap(packet -> Mono.fromCallable(()).map(()).onErrorResume(())).subscribeOn(scheduler).subscribe();
/*    */   }
/*    */ 
/*    */   
/*    */   public void dispose() {
/* 59 */     this.task.dispose();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isDisposed() {
/* 64 */     return this.task.isDisposed();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-voice-3.2.5.jar!\discord4j\voice\LocalVoiceReceiveTask.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */