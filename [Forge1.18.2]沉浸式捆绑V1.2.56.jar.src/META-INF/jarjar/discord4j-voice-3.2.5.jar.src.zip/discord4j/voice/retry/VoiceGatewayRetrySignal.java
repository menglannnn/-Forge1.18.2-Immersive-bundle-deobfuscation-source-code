/*    */ package discord4j.voice.retry;
/*    */ 
/*    */ import discord4j.voice.VoiceConnection;
/*    */ import java.time.Duration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VoiceGatewayRetrySignal
/*    */ {
/*    */   private final Throwable failure;
/*    */   private final long iteration;
/*    */   private final Duration nextBackoff;
/*    */   private final VoiceConnection.State nextState;
/*    */   
/*    */   public VoiceGatewayRetrySignal(Throwable failure, long iteration, Duration nextBackoff, VoiceConnection.State nextState) {
/* 33 */     this.failure = failure;
/* 34 */     this.iteration = iteration;
/* 35 */     this.nextBackoff = nextBackoff;
/* 36 */     this.nextState = nextState;
/*    */   }
/*    */   
/*    */   public Throwable failure() {
/* 40 */     return this.failure;
/*    */   }
/*    */   
/*    */   public long iteration() {
/* 44 */     return this.iteration;
/*    */   }
/*    */   
/*    */   public Duration nextBackoff() {
/* 48 */     return this.nextBackoff;
/*    */   }
/*    */   
/*    */   public VoiceConnection.State nextState() {
/* 52 */     return this.nextState;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 57 */     return "GatewayRetrySignal{failure=" + this.failure + ", iteration=" + this.iteration + ", nextBackoff=" + this.nextBackoff + ", nextState=" + this.nextState + '}';
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-voice-3.2.5.jar!\discord4j\voice\retry\VoiceGatewayRetrySignal.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */