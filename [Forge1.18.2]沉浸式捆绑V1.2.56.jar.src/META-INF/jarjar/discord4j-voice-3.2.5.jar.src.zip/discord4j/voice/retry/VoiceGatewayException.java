/*    */ package discord4j.voice.retry;
/*    */ 
/*    */ import reactor.util.context.ContextView;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VoiceGatewayException
/*    */   extends RuntimeException
/*    */ {
/*    */   private final ContextView context;
/*    */   
/*    */   public VoiceGatewayException(ContextView context) {
/* 27 */     this.context = context;
/*    */   }
/*    */   
/*    */   public VoiceGatewayException(ContextView context, String message) {
/* 31 */     super(message);
/* 32 */     this.context = context;
/*    */   }
/*    */   
/*    */   public VoiceGatewayException(ContextView context, String message, Throwable cause) {
/* 36 */     super(message, cause);
/* 37 */     this.context = context;
/*    */   }
/*    */   
/*    */   public ContextView getContext() {
/* 41 */     return this.context;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 46 */     String prefix = "Voice gateway exception";
/* 47 */     String message = getMessage();
/* 48 */     return (message != null) ? (prefix + ": " + message) : prefix;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-voice-3.2.5.jar!\discord4j\voice\retry\VoiceGatewayException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */