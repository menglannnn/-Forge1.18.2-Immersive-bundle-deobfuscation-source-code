/*    */ package discord4j.voice.retry;
/*    */ 
/*    */ import reactor.util.context.ContextView;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VoiceGatewayResumeException
/*    */   extends VoiceGatewayException
/*    */ {
/*    */   public VoiceGatewayResumeException(ContextView context) {
/* 25 */     super(context);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-voice-3.2.5.jar!\discord4j\voice\retry\VoiceGatewayResumeException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */