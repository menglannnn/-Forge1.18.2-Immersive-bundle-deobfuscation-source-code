/*     */ package discord4j.voice.retry;
/*     */ 
/*     */ import discord4j.common.close.CloseException;
/*     */ import discord4j.common.retry.ReconnectContext;
/*     */ import discord4j.common.retry.ReconnectOptions;
/*     */ import discord4j.voice.VoiceConnection;
/*     */ import java.time.Duration;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.ThreadLocalRandom;
/*     */ import java.util.function.Consumer;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.retry.Retry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VoiceGatewayRetrySpec
/*     */   extends Retry
/*     */ {
/*  38 */   public static final List<Integer> NON_RETRYABLE_STATUS_CODES = Arrays.asList(new Integer[] {
/*  39 */         Integer.valueOf(4004), 
/*  40 */         Integer.valueOf(4006), 
/*  41 */         Integer.valueOf(4016)
/*     */       });
/*     */   
/*     */   private static final Consumer<VoiceGatewayRetrySignal> NO_OP_CONSUMER = retrySignal -> {
/*     */     
/*     */     };
/*     */   private final ReconnectOptions reconnectOptions;
/*     */   private final ReconnectContext reconnectContext;
/*     */   private final Consumer<VoiceGatewayRetrySignal> doPreRetry;
/*     */   
/*     */   VoiceGatewayRetrySpec(ReconnectOptions reconnectOptions, ReconnectContext reconnectContext, Consumer<VoiceGatewayRetrySignal> doPreRetry) {
/*  52 */     this.reconnectOptions = reconnectOptions;
/*  53 */     this.reconnectContext = reconnectContext;
/*  54 */     this.doPreRetry = doPreRetry;
/*     */   }
/*     */   
/*     */   public static VoiceGatewayRetrySpec create(ReconnectOptions reconnectOptions, ReconnectContext reconnectContext) {
/*  58 */     return new VoiceGatewayRetrySpec(reconnectOptions, reconnectContext, NO_OP_CONSUMER);
/*     */   }
/*     */   
/*     */   public VoiceGatewayRetrySpec doBeforeRetry(Consumer<VoiceGatewayRetrySignal> doBeforeRetry) {
/*  62 */     return new VoiceGatewayRetrySpec(this.reconnectOptions, this.reconnectContext, this.doPreRetry.andThen(doBeforeRetry));
/*     */   }
/*     */   
/*     */   private boolean isRetryable(@Nullable Throwable t) {
/*  66 */     if (t instanceof CloseException) {
/*  67 */       CloseException closeException = (CloseException)t;
/*  68 */       return !NON_RETRYABLE_STATUS_CODES.contains(Integer.valueOf(closeException.getCode()));
/*     */     } 
/*  70 */     return !(t instanceof PartialDisconnectException);
/*     */   }
/*     */   
/*     */   private boolean canResume(Throwable t) {
/*  74 */     if (t instanceof CloseException) {
/*  75 */       CloseException closeException = (CloseException)t;
/*  76 */       return (closeException.getCode() < 4000);
/*     */     } 
/*  78 */     return !(t instanceof VoiceGatewayReconnectException);
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<Long> generateCompanion(Flux<Retry.RetrySignal> t) {
/*  83 */     return t.concatMap(retryWhenState -> {
/*     */           Duration nextBackoff;
/*     */           VoiceConnection.State nextState;
/*     */           Retry.RetrySignal copy = retryWhenState.copy();
/*     */           Throwable currentFailure = copy.failure();
/*     */           if (currentFailure == null) {
/*     */             return (Publisher)Mono.error(new IllegalStateException("Retry.RetrySignal#failure() not expected to be null"));
/*     */           }
/*     */           if (!isRetryable(currentFailure)) {
/*     */             return (Publisher)Mono.error(currentFailure);
/*     */           }
/*     */           long iteration = this.reconnectContext.getAttempts();
/*     */           if (iteration >= this.reconnectOptions.getMaxRetries()) {
/*     */             return (Publisher)Mono.error(Exceptions.retryExhausted("Retries exhausted: " + iteration + "/" + this.reconnectOptions.getMaxRetries(), copy.failure()));
/*     */           }
/*     */           Duration minBackoff = this.reconnectOptions.getFirstBackoff();
/*     */           Duration maxBackoff = this.reconnectOptions.getMaxBackoffInterval();
/*     */           if (canResume(currentFailure)) {
/*     */             if (iteration == 1L) {
/*     */               nextBackoff = Duration.ZERO;
/*     */             } else {
/*     */               nextBackoff = computeBackoff(iteration - 2L, minBackoff, maxBackoff);
/*     */             } 
/*     */             nextState = VoiceConnection.State.RESUMING;
/*     */           } else {
/*     */             nextBackoff = computeBackoff(iteration - 1L, minBackoff, maxBackoff);
/*     */             nextState = VoiceConnection.State.RECONNECTING;
/*     */           } 
/*     */           this.reconnectContext.next();
/*     */           if (nextBackoff.isZero()) {
/*     */             return (Publisher)applyHooks(new VoiceGatewayRetrySignal(copy.failure(), iteration, nextBackoff, nextState), Mono.just(Long.valueOf(iteration)), this.doPreRetry);
/*     */           }
/*     */           Duration effectiveBackoff = nextBackoff.plusMillis(computeJitter(nextBackoff, minBackoff, maxBackoff, this.reconnectOptions.getJitterFactor()));
/*     */           return (Publisher)applyHooks(new VoiceGatewayRetrySignal(copy.failure(), iteration, effectiveBackoff, nextState), Mono.delay(effectiveBackoff, this.reconnectOptions.getBackoffScheduler()), this.doPreRetry);
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static long computeJitter(Duration nextBackoff, Duration minBackoff, Duration maxBackoff, double factor) {
/*     */     long jitterOffset;
/* 148 */     ThreadLocalRandom random = ThreadLocalRandom.current();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 154 */       jitterOffset = nextBackoff.multipliedBy((long)(100.0D * factor)).dividedBy(100L).toMillis();
/* 155 */     } catch (ArithmeticException ae) {
/* 156 */       jitterOffset = Math.round(9.223372036854776E18D * factor);
/*     */     } 
/* 158 */     long lowBound = Math.max(minBackoff.minus(nextBackoff).toMillis(), -jitterOffset);
/* 159 */     long highBound = Math.min(maxBackoff.minus(nextBackoff).toMillis(), jitterOffset);
/*     */ 
/*     */     
/* 162 */     if (highBound == lowBound) {
/* 163 */       if (highBound == 0L) {
/* 164 */         return 0L;
/*     */       }
/* 166 */       return random.nextLong(highBound);
/*     */     } 
/*     */     
/* 169 */     return random.nextLong(lowBound, highBound);
/*     */   }
/*     */ 
/*     */   
/*     */   static Duration computeBackoff(long iteration, Duration minBackoff, Duration maxBackoff) {
/*     */     Duration nextBackoff;
/*     */     try {
/* 176 */       nextBackoff = minBackoff.multipliedBy((long)Math.pow(2.0D, iteration));
/* 177 */       if (nextBackoff.compareTo(maxBackoff) > 0) {
/* 178 */         nextBackoff = maxBackoff;
/*     */       }
/* 180 */     } catch (ArithmeticException overflow) {
/* 181 */       nextBackoff = maxBackoff;
/*     */     } 
/* 183 */     return nextBackoff;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static <T> Mono<T> applyHooks(VoiceGatewayRetrySignal retrySignal, Mono<T> originalCompanion, Consumer<VoiceGatewayRetrySignal> doPreRetry) {
/* 189 */     if (doPreRetry != NO_OP_CONSUMER) {
/*     */       try {
/* 191 */         doPreRetry.accept(retrySignal);
/* 192 */       } catch (Throwable e) {
/* 193 */         return Mono.error(e);
/*     */       } 
/*     */     }
/* 196 */     return originalCompanion;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-voice-3.2.5.jar!\discord4j\voice\retry\VoiceGatewayRetrySpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */