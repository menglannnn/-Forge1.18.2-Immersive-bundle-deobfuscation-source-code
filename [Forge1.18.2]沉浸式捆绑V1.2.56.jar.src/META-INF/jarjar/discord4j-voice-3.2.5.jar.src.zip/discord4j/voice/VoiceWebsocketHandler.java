/*     */ package discord4j.voice;
/*     */ 
/*     */ import discord4j.common.LogUtil;
/*     */ import discord4j.common.close.CloseStatus;
/*     */ import discord4j.common.close.DisconnectBehavior;
/*     */ import discord4j.common.sinks.EmissionStrategy;
/*     */ import discord4j.voice.retry.PartialDisconnectException;
/*     */ import discord4j.voice.retry.VoiceGatewayException;
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.buffer.DefaultByteBufHolder;
/*     */ import io.netty.handler.codec.http.websocketx.CloseWebSocketFrame;
/*     */ import io.netty.handler.codec.http.websocketx.WebSocketCloseStatus;
/*     */ import java.time.Duration;
/*     */ import java.util.function.Function;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.core.publisher.Sinks;
/*     */ import reactor.netty.Connection;
/*     */ import reactor.netty.http.websocket.WebsocketInbound;
/*     */ import reactor.netty.http.websocket.WebsocketOutbound;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.Loggers;
/*     */ import reactor.util.context.ContextView;
/*     */ import reactor.util.function.Tuple2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VoiceWebsocketHandler
/*     */ {
/*  58 */   private static final Logger log = Loggers.getLogger(VoiceWebsocketHandler.class);
/*     */ 
/*     */   
/*     */   private final Sinks.Many<ByteBuf> inbound;
/*     */ 
/*     */   
/*     */   private final Flux<ByteBuf> outbound;
/*     */   
/*     */   private final Sinks.One<DisconnectBehavior> sessionClose;
/*     */   
/*     */   private final ContextView context;
/*     */   
/*     */   private final EmissionStrategy emissionStrategy;
/*     */ 
/*     */   
/*     */   public VoiceWebsocketHandler(Sinks.Many<ByteBuf> inbound, Flux<ByteBuf> outbound, ContextView context) {
/*  74 */     this.inbound = inbound;
/*  75 */     this.outbound = outbound;
/*  76 */     this.sessionClose = Sinks.one();
/*  77 */     this.context = context;
/*  78 */     this.emissionStrategy = EmissionStrategy.park(Duration.ofNanos(10L));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Tuple2<DisconnectBehavior, CloseStatus>> handle(WebsocketInbound in, WebsocketOutbound out) {
/* 108 */     Mono<CloseWebSocketFrame> outboundClose = this.sessionClose.asMono().doOnNext(behavior -> log.debug(LogUtil.format(this.context, "Closing session with behavior: {}"), new Object[] { behavior })).flatMap(behavior -> { switch (behavior.getAction()) { case RETRY_ABRUPTLY: case STOP_ABRUPTLY: return Mono.error((behavior.getCause() != null) ? behavior.getCause() : (Throwable)new PartialDisconnectException(this.context)); }  return Mono.just(CloseStatus.NORMAL_CLOSE); }).map(status -> new CloseWebSocketFrame(status.getCode(), status.getReason().orElse(null)));
/*     */ 
/*     */ 
/*     */     
/* 112 */     Mono<CloseStatus> inboundClose = in.receiveCloseStatus().map(status -> new CloseStatus(status.code(), status.reasonText())).doOnNext(status -> {
/*     */           log.debug(LogUtil.format(this.context, "Received close status: {}"), new Object[] { status });
/*     */ 
/*     */           
/*     */           close(DisconnectBehavior.retryAbruptly((Throwable)new VoiceGatewayException(this.context, "Inbound close status")));
/*     */         });
/*     */ 
/*     */     
/* 120 */     Mono<Void> outboundEvents = out.sendObject((Publisher)Flux.merge(new Publisher[] { (Publisher)outboundClose, (Publisher)this.outbound.map(io.netty.handler.codec.http.websocketx.TextWebSocketFrame::new) })).then();
/*     */     
/* 122 */     in.withConnection(c -> c.onDispose(()));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 128 */     Mono<Void> inboundEvents = in.aggregateFrames().receiveFrames().map(DefaultByteBufHolder::content).doOnNext(this::emitInbound).then();
/*     */     
/* 130 */     return Mono.zip(outboundEvents, inboundEvents)
/* 131 */       .doOnError(this::error)
/* 132 */       .onErrorResume(t -> t.getCause() instanceof VoiceGatewayException, t -> Mono.empty())
/* 133 */       .then(Mono.zip(this.sessionClose.asMono(), inboundClose.defaultIfEmpty(CloseStatus.ABNORMAL_CLOSE)));
/*     */   }
/*     */   
/*     */   private void emitInbound(ByteBuf value) {
/* 137 */     this.emissionStrategy.emitNext(this.inbound, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {
/* 145 */     close(DisconnectBehavior.retry(null));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close(DisconnectBehavior behavior) {
/* 154 */     this.sessionClose.emitValue(behavior, Sinks.EmitFailureHandler.FAIL_FAST);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void error(Throwable error) {
/* 164 */     log.info(LogUtil.format(this.context, "Triggering error sequence: {}"), new Object[] { error.toString() });
/* 165 */     close(DisconnectBehavior.retryAbruptly(error));
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-voice-3.2.5.jar!\discord4j\voice\VoiceWebsocketHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */