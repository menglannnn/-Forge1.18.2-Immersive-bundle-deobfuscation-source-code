package discord4j.voice;

import io.netty.buffer.ByteBuf;
import java.util.function.Consumer;
import reactor.core.Disposable;
import reactor.core.scheduler.Scheduler;

public interface VoiceSendTaskFactory {
  Disposable create(Scheduler paramScheduler, Consumer<Boolean> paramConsumer, Consumer<ByteBuf> paramConsumer1, AudioProvider paramAudioProvider, PacketTransformer paramPacketTransformer);
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-voice-3.2.5.jar!\discord4j\voice\VoiceSendTaskFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */