/*    */ package discord4j.voice;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AudioProvider
/*    */ {
/*    */   public static final int DEFAULT_BUFFER_SIZE = 2048;
/*    */   
/* 31 */   public static final AudioProvider NO_OP = new AudioProvider(ByteBuffer.allocate(0))
/*    */     {
/*    */       public boolean provide() {
/* 34 */         return false;
/*    */       }
/*    */     };
/*    */   
/*    */   private final ByteBuffer buffer;
/*    */   
/*    */   public AudioProvider() {
/* 41 */     this(ByteBuffer.allocate(2048));
/*    */   }
/*    */   
/*    */   public AudioProvider(ByteBuffer buffer) {
/* 45 */     this.buffer = buffer;
/*    */   }
/*    */   
/*    */   public ByteBuffer getBuffer() {
/* 49 */     return this.buffer;
/*    */   }
/*    */   
/*    */   public abstract boolean provide();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-voice-3.2.5.jar!\discord4j\voice\AudioProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */