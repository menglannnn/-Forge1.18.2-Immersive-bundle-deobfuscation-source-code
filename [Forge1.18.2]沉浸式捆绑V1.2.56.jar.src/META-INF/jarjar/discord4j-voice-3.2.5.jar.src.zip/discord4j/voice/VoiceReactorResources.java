/*     */ package discord4j.voice;
/*     */ 
/*     */ import discord4j.common.ReactorResources;
/*     */ import reactor.core.scheduler.Scheduler;
/*     */ import reactor.netty.http.client.HttpClient;
/*     */ import reactor.netty.udp.UdpClient;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VoiceReactorResources
/*     */   extends ReactorResources
/*     */ {
/*     */   private final UdpClient udpClient;
/*     */   private final Scheduler sendTaskScheduler;
/*     */   private final Scheduler receiveTaskScheduler;
/*     */   
/*     */   public VoiceReactorResources(ReactorResources parent) {
/*  44 */     super(parent.getHttpClient(), parent.getTimerTaskScheduler(), parent.getBlockingTaskScheduler());
/*  45 */     this.udpClient = UdpClient.create();
/*  46 */     this.sendTaskScheduler = parent.getTimerTaskScheduler();
/*  47 */     this.receiveTaskScheduler = parent.getTimerTaskScheduler();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public VoiceReactorResources(ReactorResources parent, UdpClient udpClient, Scheduler sendTaskScheduler, Scheduler receiveTaskScheduler) {
/*  61 */     super(parent.getHttpClient(), parent.getTimerTaskScheduler(), parent.getBlockingTaskScheduler());
/*  62 */     this.udpClient = udpClient;
/*  63 */     this.sendTaskScheduler = sendTaskScheduler;
/*  64 */     this.receiveTaskScheduler = receiveTaskScheduler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public VoiceReactorResources(HttpClient httpClient, Scheduler timerTaskScheduler, Scheduler blockingTaskScheduler, UdpClient udpClient, Scheduler sendTaskScheduler, Scheduler receiveTaskScheduler) {
/*  82 */     super(httpClient, timerTaskScheduler, blockingTaskScheduler);
/*  83 */     this.udpClient = udpClient;
/*  84 */     this.sendTaskScheduler = sendTaskScheduler;
/*  85 */     this.receiveTaskScheduler = receiveTaskScheduler;
/*     */   }
/*     */   
/*     */   protected VoiceReactorResources(Builder builder) {
/*  89 */     super(builder);
/*     */     
/*  91 */     this.udpClient = (builder.udpClient == null) ? UdpClient.create() : builder.udpClient;
/*  92 */     this
/*  93 */       .sendTaskScheduler = (builder.sendTaskScheduler == null) ? DEFAULT_TIMER_TASK_SCHEDULER.get() : builder.sendTaskScheduler;
/*  94 */     this
/*  95 */       .receiveTaskScheduler = (builder.receiveTaskScheduler == null) ? DEFAULT_TIMER_TASK_SCHEDULER.get() : builder.receiveTaskScheduler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static VoiceReactorResources create() {
/* 104 */     return new VoiceReactorResources(new ReactorResources());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 113 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder(ReactorResources reactorResources) {
/* 123 */     return builder()
/* 124 */       .httpClient(reactorResources.getHttpClient())
/* 125 */       .timerTaskScheduler(reactorResources.getTimerTaskScheduler())
/* 126 */       .blockingTaskScheduler(reactorResources.getBlockingTaskScheduler());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Builder mutate() {
/* 136 */     return (new Builder())
/* 137 */       .httpClient(getHttpClient())
/* 138 */       .timerTaskScheduler(getTimerTaskScheduler())
/* 139 */       .blockingTaskScheduler(getBlockingTaskScheduler())
/* 140 */       .udpClient(getUdpClient())
/* 141 */       .sendTaskScheduler(getSendTaskScheduler())
/* 142 */       .receiveTaskScheduler(getReceiveTaskScheduler());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UdpClient getUdpClient() {
/* 151 */     return this.udpClient;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Scheduler getSendTaskScheduler() {
/* 160 */     return this.sendTaskScheduler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Scheduler getReceiveTaskScheduler() {
/* 169 */     return this.receiveTaskScheduler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Builder
/*     */     extends ReactorResources.Builder
/*     */   {
/*     */     private UdpClient udpClient;
/*     */ 
/*     */ 
/*     */     
/*     */     private Scheduler sendTaskScheduler;
/*     */ 
/*     */ 
/*     */     
/*     */     private Scheduler receiveTaskScheduler;
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder udpClient(UdpClient udpClient) {
/* 191 */       this.udpClient = udpClient;
/* 192 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder sendTaskScheduler(Scheduler sendTaskScheduler) {
/* 202 */       this.sendTaskScheduler = sendTaskScheduler;
/* 203 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder receiveTaskScheduler(Scheduler receiveTaskScheduler) {
/* 213 */       this.receiveTaskScheduler = receiveTaskScheduler;
/* 214 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder httpClient(HttpClient httpClient) {
/* 219 */       super.httpClient(httpClient);
/* 220 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder timerTaskScheduler(Scheduler timerTaskScheduler) {
/* 225 */       super.timerTaskScheduler(timerTaskScheduler);
/* 226 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder blockingTaskScheduler(Scheduler blockingTaskScheduler) {
/* 231 */       super.blockingTaskScheduler(blockingTaskScheduler);
/* 232 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public VoiceReactorResources build() {
/* 241 */       return new VoiceReactorResources(this);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-voice-3.2.5.jar!\discord4j\voice\VoiceReactorResources.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */