/*    */ package discord4j.voice;
/*    */ 
/*    */ import com.iwebpp.crypto.TweetNaclFast;
/*    */ import io.netty.buffer.ByteBuf;
/*    */ import java.nio.ByteBuffer;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class PacketTransformer
/*    */ {
/*    */   private static final int RTP_HEADER_LENGTH = 12;
/*    */   private static final int EXTENDED_RTP_HEADER_LENGTH = 24;
/*    */   private final int ssrc;
/*    */   private final TweetNaclFast.SecretBox boxer;
/* 33 */   private char seq = Character.MIN_VALUE;
/*    */   
/*    */   PacketTransformer(int ssrc, TweetNaclFast.SecretBox boxer) {
/* 36 */     this.ssrc = ssrc;
/* 37 */     this.boxer = boxer;
/*    */   }
/*    */   
/*    */   byte[] nextSend(byte[] audio) {
/* 41 */     this.seq = (char)(this.seq + 1); byte[] header = getRtpHeader(this.seq);
/* 42 */     byte[] encrypted = this.boxer.box(audio, getNonce(header));
/*    */     
/* 44 */     return getAudioPacket(header, encrypted);
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   byte[] nextReceive(ByteBuf packet) {
/* 49 */     byte[] header = new byte[12];
/* 50 */     packet.getBytes(0, header);
/*    */     
/* 52 */     int audioOffset = 12 + 4 * (byte)(header[0] & 0xF);
/*    */     
/* 54 */     byte[] encrypted = new byte[packet.readableBytes() - audioOffset];
/* 55 */     packet.getBytes(audioOffset, encrypted);
/* 56 */     packet.release();
/*    */     
/* 58 */     byte[] decrypted = this.boxer.open(encrypted, getNonce(header));
/* 59 */     if (decrypted == null) {
/* 60 */       return null;
/*    */     }
/*    */     
/* 63 */     byte[] newPacket = new byte[12 + decrypted.length];
/* 64 */     System.arraycopy(header, 0, newPacket, 0, 12);
/* 65 */     System.arraycopy(decrypted, 0, newPacket, audioOffset, decrypted.length);
/* 66 */     return newPacket;
/*    */   }
/*    */   
/*    */   private byte[] getNonce(byte[] rtpHeader) {
/* 70 */     byte[] nonce = new byte[24];
/* 71 */     System.arraycopy(rtpHeader, 0, nonce, 0, 12);
/* 72 */     return nonce;
/*    */   }
/*    */   
/*    */   private byte[] getRtpHeader(char seq) {
/* 76 */     return ByteBuffer.allocate(12)
/* 77 */       .put(-128)
/* 78 */       .put((byte)120)
/* 79 */       .putChar(seq)
/* 80 */       .putInt(seq * 960)
/* 81 */       .putInt(this.ssrc)
/* 82 */       .array();
/*    */   }
/*    */   
/*    */   private static byte[] getAudioPacket(byte[] rtpHeader, byte[] encryptedAudio) {
/* 86 */     byte[] packet = new byte[rtpHeader.length + encryptedAudio.length];
/* 87 */     System.arraycopy(rtpHeader, 0, packet, 0, rtpHeader.length);
/* 88 */     System.arraycopy(encryptedAudio, 0, packet, rtpHeader.length, encryptedAudio.length);
/* 89 */     return packet;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-voice-3.2.5.jar!\discord4j\voice\PacketTransformer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */