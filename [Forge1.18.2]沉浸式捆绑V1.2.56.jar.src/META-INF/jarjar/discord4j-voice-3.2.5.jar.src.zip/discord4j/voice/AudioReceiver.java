/*    */ package discord4j.voice;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public abstract class AudioReceiver
/*    */ {
/*    */   public static final int DEFAULT_BUFFER_SIZE = 2048;
/*    */   
/* 35 */   public static final AudioReceiver NO_OP = new AudioReceiver(ByteBuffer.allocate(0))
/*    */     {
/*    */       public void receive(char sequence, int timestamp, int ssrc, byte[] audio) {}
/*    */     };
/*    */ 
/*    */   
/*    */   private final ByteBuffer buffer;
/*    */   
/*    */   public AudioReceiver() {
/* 44 */     this(ByteBuffer.allocate(2048));
/*    */   }
/*    */   
/*    */   public AudioReceiver(ByteBuffer buffer) {
/* 48 */     this.buffer = buffer;
/*    */   }
/*    */   
/*    */   public ByteBuffer getBuffer() {
/* 52 */     return this.buffer;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void receive() {
/* 59 */     getBuffer().get();
/* 60 */     getBuffer().get();
/* 61 */     char sequence = getBuffer().getChar();
/* 62 */     int timestamp = getBuffer().getInt();
/* 63 */     int ssrc = getBuffer().getInt();
/* 64 */     byte[] audio = new byte[getBuffer().remaining()];
/* 65 */     getBuffer().get(audio);
/*    */     
/* 67 */     receive(sequence, timestamp, ssrc, audio);
/*    */     
/* 69 */     getBuffer().clear();
/*    */   }
/*    */   
/*    */   public abstract void receive(char paramChar, int paramInt1, int paramInt2, byte[] paramArrayOfbyte);
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-voice-3.2.5.jar!\discord4j\voice\AudioReceiver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */