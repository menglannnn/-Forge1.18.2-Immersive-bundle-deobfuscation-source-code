package discord4j.voice;

import discord4j.common.util.Snowflake;
import reactor.core.publisher.Mono;

@FunctionalInterface
public interface VoiceDisconnectTask {
  Mono<Void> onDisconnect(Snowflake paramSnowflake);
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-voice-3.2.5.jar!\discord4j\voice\VoiceDisconnectTask.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */