/*    */ package discord4j.voice;
/*    */ 
/*    */ import io.netty.buffer.ByteBuf;
/*    */ import reactor.core.Disposable;
/*    */ import reactor.core.publisher.Flux;
/*    */ import reactor.core.scheduler.Scheduler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LocalVoiceReceiveTaskFactory
/*    */   implements VoiceReceiveTaskFactory
/*    */ {
/*    */   public Disposable create(Scheduler scheduler, Flux<ByteBuf> in, PacketTransformer transformer, AudioReceiver receiver) {
/* 33 */     return new LocalVoiceReceiveTask(scheduler, in, transformer, receiver);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-voice-3.2.5.jar!\discord4j\voice\LocalVoiceReceiveTaskFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */