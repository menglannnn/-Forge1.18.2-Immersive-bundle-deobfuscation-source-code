module com.fasterxml.jackson.datatype.jsr310 {
  requires com.fasterxml.jackson.annotation;
  requires com.fasterxml.jackson.core;
  requires com.fasterxml.jackson.databind;
  requires java.base;
  
  exports com.fasterxml.jackson.datatype.jsr310;
  exports com.fasterxml.jackson.datatype.jsr310.deser;
  exports com.fasterxml.jackson.datatype.jsr310.deser.key;
  exports com.fasterxml.jackson.datatype.jsr310.ser;
  exports com.fasterxml.jackson.datatype.jsr310.ser.key;
  
  opens com.fasterxml.jackson.datatype.jsr310.deser;
  opens com.fasterxml.jackson.datatype.jsr310.deser.key;
  opens com.fasterxml.jackson.datatype.jsr310.ser;
  opens com.fasterxml.jackson.datatype.jsr310.ser.key;
  
  provides com.fasterxml.jackson.databind.Module with com.fasterxml.jackson.datatype.jsr310.JSR310Module;
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-datatype-jsr310-2.14.2.jar!\META-INF\versions\9\module-info.class
 * Java compiler version: 9 (53.0)
 * JD-Core Version:       1.1.3
 */