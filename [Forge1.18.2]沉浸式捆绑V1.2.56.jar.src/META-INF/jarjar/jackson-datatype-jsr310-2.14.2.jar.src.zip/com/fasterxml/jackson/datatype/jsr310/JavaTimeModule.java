/*     */ package com.fasterxml.jackson.datatype.jsr310;
/*     */ 
/*     */ import com.fasterxml.jackson.databind.BeanDescription;
/*     */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.JsonSerializer;
/*     */ import com.fasterxml.jackson.databind.KeyDeserializer;
/*     */ import com.fasterxml.jackson.databind.Module;
/*     */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*     */ import com.fasterxml.jackson.databind.deser.ValueInstantiator;
/*     */ import com.fasterxml.jackson.databind.deser.ValueInstantiators;
/*     */ import com.fasterxml.jackson.databind.deser.std.StdValueInstantiator;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedClass;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedClassResolver;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedMethod;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedWithParams;
/*     */ import com.fasterxml.jackson.databind.introspect.ClassIntrospector;
/*     */ import com.fasterxml.jackson.databind.module.SimpleModule;
/*     */ import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.DurationDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.InstantDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.JSR310StringParsableDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.LocalTimeDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.MonthDayDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.OffsetTimeDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.YearDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.YearMonthDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.key.DurationKeyDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.key.InstantKeyDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.key.LocalDateKeyDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.key.LocalDateTimeKeyDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.key.LocalTimeKeyDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.key.MonthDayKeyDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.key.OffsetDateTimeKeyDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.key.OffsetTimeKeyDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.key.PeriodKeyDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.key.YearKeyDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.key.YearMonthKeyDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.key.ZoneIdKeyDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.key.ZoneOffsetKeyDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.key.ZonedDateTimeKeyDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.ser.DurationSerializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.ser.InstantSerializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.ser.LocalTimeSerializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.ser.MonthDaySerializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.ser.OffsetDateTimeSerializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.ser.OffsetTimeSerializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.ser.YearMonthSerializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.ser.YearSerializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.ser.ZoneIdSerializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.ser.ZonedDateTimeSerializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.ser.key.ZonedDateTimeKeySerializer;
/*     */ import java.time.Duration;
/*     */ import java.time.Instant;
/*     */ import java.time.LocalDate;
/*     */ import java.time.LocalDateTime;
/*     */ import java.time.LocalTime;
/*     */ import java.time.MonthDay;
/*     */ import java.time.OffsetDateTime;
/*     */ import java.time.OffsetTime;
/*     */ import java.time.Period;
/*     */ import java.time.Year;
/*     */ import java.time.YearMonth;
/*     */ import java.time.ZoneId;
/*     */ import java.time.ZoneOffset;
/*     */ import java.time.ZonedDateTime;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class JavaTimeModule
/*     */   extends SimpleModule
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   
/*     */   public JavaTimeModule() {
/* 114 */     super(PackageVersion.VERSION);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 119 */     addDeserializer(Instant.class, (JsonDeserializer)InstantDeserializer.INSTANT);
/* 120 */     addDeserializer(OffsetDateTime.class, (JsonDeserializer)InstantDeserializer.OFFSET_DATE_TIME);
/* 121 */     addDeserializer(ZonedDateTime.class, (JsonDeserializer)InstantDeserializer.ZONED_DATE_TIME);
/*     */ 
/*     */     
/* 124 */     addDeserializer(Duration.class, (JsonDeserializer)DurationDeserializer.INSTANCE);
/* 125 */     addDeserializer(LocalDateTime.class, (JsonDeserializer)LocalDateTimeDeserializer.INSTANCE);
/* 126 */     addDeserializer(LocalDate.class, (JsonDeserializer)LocalDateDeserializer.INSTANCE);
/* 127 */     addDeserializer(LocalTime.class, (JsonDeserializer)LocalTimeDeserializer.INSTANCE);
/* 128 */     addDeserializer(MonthDay.class, (JsonDeserializer)MonthDayDeserializer.INSTANCE);
/* 129 */     addDeserializer(OffsetTime.class, (JsonDeserializer)OffsetTimeDeserializer.INSTANCE);
/* 130 */     addDeserializer(Period.class, JSR310StringParsableDeserializer.PERIOD);
/* 131 */     addDeserializer(Year.class, (JsonDeserializer)YearDeserializer.INSTANCE);
/* 132 */     addDeserializer(YearMonth.class, (JsonDeserializer)YearMonthDeserializer.INSTANCE);
/* 133 */     addDeserializer(ZoneId.class, JSR310StringParsableDeserializer.ZONE_ID);
/* 134 */     addDeserializer(ZoneOffset.class, JSR310StringParsableDeserializer.ZONE_OFFSET);
/*     */ 
/*     */     
/* 137 */     addSerializer(Duration.class, (JsonSerializer)DurationSerializer.INSTANCE);
/* 138 */     addSerializer(Instant.class, (JsonSerializer)InstantSerializer.INSTANCE);
/* 139 */     addSerializer(LocalDateTime.class, (JsonSerializer)LocalDateTimeSerializer.INSTANCE);
/* 140 */     addSerializer(LocalDate.class, (JsonSerializer)LocalDateSerializer.INSTANCE);
/* 141 */     addSerializer(LocalTime.class, (JsonSerializer)LocalTimeSerializer.INSTANCE);
/* 142 */     addSerializer(MonthDay.class, (JsonSerializer)MonthDaySerializer.INSTANCE);
/* 143 */     addSerializer(OffsetDateTime.class, (JsonSerializer)OffsetDateTimeSerializer.INSTANCE);
/* 144 */     addSerializer(OffsetTime.class, (JsonSerializer)OffsetTimeSerializer.INSTANCE);
/* 145 */     addSerializer(Period.class, (JsonSerializer)new ToStringSerializer(Period.class));
/* 146 */     addSerializer(Year.class, (JsonSerializer)YearSerializer.INSTANCE);
/* 147 */     addSerializer(YearMonth.class, (JsonSerializer)YearMonthSerializer.INSTANCE);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 154 */     addSerializer(ZonedDateTime.class, (JsonSerializer)ZonedDateTimeSerializer.INSTANCE);
/*     */ 
/*     */ 
/*     */     
/* 158 */     addSerializer(ZoneId.class, (JsonSerializer)new ZoneIdSerializer());
/* 159 */     addSerializer(ZoneOffset.class, (JsonSerializer)new ToStringSerializer(ZoneOffset.class));
/*     */ 
/*     */     
/* 162 */     addKeySerializer(ZonedDateTime.class, (JsonSerializer)ZonedDateTimeKeySerializer.INSTANCE);
/*     */ 
/*     */     
/* 165 */     addKeyDeserializer(Duration.class, (KeyDeserializer)DurationKeyDeserializer.INSTANCE);
/* 166 */     addKeyDeserializer(Instant.class, (KeyDeserializer)InstantKeyDeserializer.INSTANCE);
/* 167 */     addKeyDeserializer(LocalDateTime.class, (KeyDeserializer)LocalDateTimeKeyDeserializer.INSTANCE);
/* 168 */     addKeyDeserializer(LocalDate.class, (KeyDeserializer)LocalDateKeyDeserializer.INSTANCE);
/* 169 */     addKeyDeserializer(LocalTime.class, (KeyDeserializer)LocalTimeKeyDeserializer.INSTANCE);
/* 170 */     addKeyDeserializer(MonthDay.class, (KeyDeserializer)MonthDayKeyDeserializer.INSTANCE);
/* 171 */     addKeyDeserializer(OffsetDateTime.class, (KeyDeserializer)OffsetDateTimeKeyDeserializer.INSTANCE);
/* 172 */     addKeyDeserializer(OffsetTime.class, (KeyDeserializer)OffsetTimeKeyDeserializer.INSTANCE);
/* 173 */     addKeyDeserializer(Period.class, (KeyDeserializer)PeriodKeyDeserializer.INSTANCE);
/* 174 */     addKeyDeserializer(Year.class, (KeyDeserializer)YearKeyDeserializer.INSTANCE);
/* 175 */     addKeyDeserializer(YearMonth.class, (KeyDeserializer)YearMonthKeyDeserializer.INSTANCE);
/* 176 */     addKeyDeserializer(ZonedDateTime.class, (KeyDeserializer)ZonedDateTimeKeyDeserializer.INSTANCE);
/* 177 */     addKeyDeserializer(ZoneId.class, (KeyDeserializer)ZoneIdKeyDeserializer.INSTANCE);
/* 178 */     addKeyDeserializer(ZoneOffset.class, (KeyDeserializer)ZoneOffsetKeyDeserializer.INSTANCE);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setupModule(Module.SetupContext context) {
/* 183 */     super.setupModule(context);
/* 184 */     context.addValueInstantiators((ValueInstantiators)new ValueInstantiators.Base()
/*     */         {
/*     */           
/*     */           public ValueInstantiator findValueInstantiator(DeserializationConfig config, BeanDescription beanDesc, ValueInstantiator defaultInstantiator)
/*     */           {
/* 189 */             JavaType type = beanDesc.getType();
/* 190 */             Class<?> raw = type.getRawClass();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 196 */             if (ZoneId.class.isAssignableFrom(raw))
/*     */             {
/* 198 */               if (defaultInstantiator instanceof StdValueInstantiator) {
/* 199 */                 AnnotatedClass ac; StdValueInstantiator inst = (StdValueInstantiator)defaultInstantiator;
/*     */ 
/*     */                 
/* 202 */                 if (raw == ZoneId.class) {
/* 203 */                   ac = beanDesc.getClassInfo();
/*     */                 }
/*     */                 else {
/*     */                   
/* 207 */                   ac = AnnotatedClassResolver.resolve((MapperConfig)config, config
/* 208 */                       .constructType(ZoneId.class), (ClassIntrospector.MixInResolver)config);
/*     */                 } 
/* 210 */                 if (!inst.canCreateFromString()) {
/* 211 */                   AnnotatedMethod factory = JavaTimeModule.this._findFactory(ac, "of", new Class[] { String.class });
/* 212 */                   if (factory != null) {
/* 213 */                     inst.configureFromStringCreator((AnnotatedWithParams)factory);
/*     */                   }
/*     */                 } 
/*     */               } 
/*     */             }
/*     */ 
/*     */             
/* 220 */             return defaultInstantiator;
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   protected AnnotatedMethod _findFactory(AnnotatedClass cls, String name, Class<?>... argTypes) {
/* 227 */     int argCount = argTypes.length;
/* 228 */     for (AnnotatedMethod method : cls.getFactoryMethods()) {
/* 229 */       if (!name.equals(method.getName()) || method
/* 230 */         .getParameterCount() != argCount) {
/*     */         continue;
/*     */       }
/* 233 */       for (int i = 0; i < argCount; i++) {
/* 234 */         Class<?> argType = method.getParameter(i).getRawType();
/* 235 */         if (!argType.isAssignableFrom(argTypes[i]));
/*     */       } 
/*     */ 
/*     */       
/* 239 */       return method;
/*     */     } 
/* 241 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-datatype-jsr310-2.14.2.jar!\com\fasterxml\jackson\datatype\jsr310\JavaTimeModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */