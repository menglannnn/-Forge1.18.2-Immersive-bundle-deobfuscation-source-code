/*     */ package com.fasterxml.jackson.datatype.jsr310.ser;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat;
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.JsonNode;
/*     */ import com.fasterxml.jackson.databind.JsonSerializer;
/*     */ import com.fasterxml.jackson.databind.SerializationFeature;
/*     */ import com.fasterxml.jackson.databind.SerializerProvider;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatVisitorWrapper;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonIntegerFormatVisitor;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonNumberFormatVisitor;
/*     */ import com.fasterxml.jackson.datatype.jsr310.DecimalUtils;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Type;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ import java.time.temporal.Temporal;
/*     */ import java.time.temporal.TemporalAccessor;
/*     */ import java.util.function.ToIntFunction;
/*     */ import java.util.function.ToLongFunction;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class InstantSerializerBase<T extends Temporal>
/*     */   extends JSR310FormattedSerializerBase<T>
/*     */ {
/*     */   private final DateTimeFormatter defaultFormat;
/*     */   private final ToLongFunction<T> getEpochMillis;
/*     */   private final ToLongFunction<T> getEpochSeconds;
/*     */   private final ToIntFunction<T> getNanoseconds;
/*     */   
/*     */   protected InstantSerializerBase(Class<T> supportedType, ToLongFunction<T> getEpochMillis, ToLongFunction<T> getEpochSeconds, ToIntFunction<T> getNanoseconds, DateTimeFormatter formatter) {
/*  63 */     super(supportedType, null);
/*  64 */     this.defaultFormat = formatter;
/*  65 */     this.getEpochMillis = getEpochMillis;
/*  66 */     this.getEpochSeconds = getEpochSeconds;
/*  67 */     this.getNanoseconds = getNanoseconds;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected InstantSerializerBase(InstantSerializerBase<T> base, Boolean useTimestamp, DateTimeFormatter dtf) {
/*  73 */     this(base, useTimestamp, base._useNanoseconds, dtf);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected InstantSerializerBase(InstantSerializerBase<T> base, Boolean useTimestamp, Boolean useNanoseconds, DateTimeFormatter dtf) {
/*  79 */     this(base, useTimestamp, useNanoseconds, dtf, base._shape);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected InstantSerializerBase(InstantSerializerBase<T> base, Boolean useTimestamp, Boolean useNanoseconds, DateTimeFormatter dtf, JsonFormat.Shape shape) {
/*  87 */     super(base, useTimestamp, useNanoseconds, dtf, shape);
/*  88 */     this.defaultFormat = base.defaultFormat;
/*  89 */     this.getEpochMillis = base.getEpochMillis;
/*  90 */     this.getEpochSeconds = base.getEpochSeconds;
/*  91 */     this.getNanoseconds = base.getNanoseconds;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void serialize(T value, JsonGenerator generator, SerializerProvider provider) throws IOException {
/* 102 */     if (useTimestamp(provider)) {
/* 103 */       if (useNanoseconds(provider)) {
/* 104 */         generator.writeNumber(DecimalUtils.toBigDecimal(this.getEpochSeconds
/* 105 */               .applyAsLong(value), this.getNanoseconds.applyAsInt(value)));
/*     */         
/*     */         return;
/*     */       } 
/* 109 */       generator.writeNumber(this.getEpochMillis.applyAsLong(value));
/*     */       
/*     */       return;
/*     */     } 
/* 113 */     generator.writeString(formatValue(value, provider));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _acceptTimestampVisitor(JsonFormatVisitorWrapper visitor, JavaType typeHint) throws JsonMappingException {
/* 121 */     if (useNanoseconds(visitor.getProvider())) {
/* 122 */       JsonNumberFormatVisitor v2 = visitor.expectNumberFormat(typeHint);
/* 123 */       if (v2 != null) {
/* 124 */         v2.numberType(JsonParser.NumberType.BIG_DECIMAL);
/*     */       }
/*     */     } else {
/* 127 */       JsonIntegerFormatVisitor v2 = visitor.expectIntegerFormat(typeHint);
/* 128 */       if (v2 != null) {
/* 129 */         v2.numberType(JsonParser.NumberType.LONG);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected JsonToken serializationShape(SerializerProvider provider) {
/* 136 */     if (useTimestamp(provider)) {
/* 137 */       if (useNanoseconds(provider)) {
/* 138 */         return JsonToken.VALUE_NUMBER_FLOAT;
/*     */       }
/* 140 */       return JsonToken.VALUE_NUMBER_INT;
/*     */     } 
/* 142 */     return JsonToken.VALUE_STRING;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected String formatValue(T value, SerializerProvider provider) {
/* 148 */     DateTimeFormatter formatter = (this._formatter != null) ? this._formatter : this.defaultFormat;
/* 149 */     if (formatter != null) {
/* 150 */       if (formatter.getZone() == null)
/*     */       {
/*     */         
/* 153 */         if (provider.getConfig().hasExplicitTimeZone() && provider.isEnabled(SerializationFeature.WRITE_DATES_WITH_CONTEXT_TIME_ZONE)) {
/* 154 */           formatter = formatter.withZone(provider.getTimeZone().toZoneId());
/*     */         }
/*     */       }
/* 157 */       return formatter.format((TemporalAccessor)value);
/*     */     } 
/*     */     
/* 160 */     return value.toString();
/*     */   }
/*     */   
/*     */   protected abstract JSR310FormattedSerializerBase<?> withFormat(Boolean paramBoolean, DateTimeFormatter paramDateTimeFormatter, JsonFormat.Shape paramShape);
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-datatype-jsr310-2.14.2.jar!\com\fasterxml\jackson\datatype\jsr310\ser\InstantSerializerBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */