/*    */ package com.fasterxml.jackson.datatype.jsr310.deser.key;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.DeserializationContext;
/*    */ import com.fasterxml.jackson.databind.JsonMappingException;
/*    */ import com.fasterxml.jackson.databind.KeyDeserializer;
/*    */ import java.io.IOException;
/*    */ import java.time.DateTimeException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class Jsr310KeyDeserializer
/*    */   extends KeyDeserializer
/*    */ {
/*    */   public final Object deserializeKey(String key, DeserializationContext ctxt) throws IOException {
/* 19 */     if ("".equals(key))
/*    */     {
/* 21 */       return null;
/*    */     }
/* 23 */     return deserialize(key, ctxt);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected abstract Object deserialize(String paramString, DeserializationContext paramDeserializationContext) throws IOException;
/*    */ 
/*    */ 
/*    */   
/*    */   protected <T> T _handleDateTimeException(DeserializationContext ctxt, Class<?> type, DateTimeException e0, String value) throws IOException {
/*    */     try {
/* 34 */       return (T)ctxt.handleWeirdKey(type, value, "Failed to deserialize %s: (%s) %s", new Object[] { type
/*    */             
/* 36 */             .getName(), e0.getClass().getName(), e0.getMessage() });
/*    */     }
/* 38 */     catch (JsonMappingException e) {
/* 39 */       e.initCause(e0);
/* 40 */       throw e;
/* 41 */     } catch (IOException e) {
/* 42 */       if (null == e.getCause()) {
/* 43 */         e.initCause(e0);
/*    */       }
/* 45 */       throw JsonMappingException.fromUnexpectedIOE(e);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-datatype-jsr310-2.14.2.jar!\com\fasterxml\jackson\datatype\jsr310\deser\key\Jsr310KeyDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */