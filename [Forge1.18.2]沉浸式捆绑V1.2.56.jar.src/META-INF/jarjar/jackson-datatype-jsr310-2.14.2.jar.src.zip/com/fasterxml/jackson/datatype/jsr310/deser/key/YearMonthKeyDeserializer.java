/*    */ package com.fasterxml.jackson.datatype.jsr310.deser.key;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.DeserializationContext;
/*    */ import java.io.IOException;
/*    */ import java.time.DateTimeException;
/*    */ import java.time.YearMonth;
/*    */ import java.time.format.DateTimeFormatter;
/*    */ import java.time.format.DateTimeFormatterBuilder;
/*    */ import java.time.format.SignStyle;
/*    */ import java.time.temporal.ChronoField;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class YearMonthKeyDeserializer
/*    */   extends Jsr310KeyDeserializer
/*    */ {
/* 19 */   public static final YearMonthKeyDeserializer INSTANCE = new YearMonthKeyDeserializer();
/*    */ 
/*    */   
/* 22 */   private static final DateTimeFormatter FORMATTER = (new DateTimeFormatterBuilder())
/* 23 */     .appendValue(ChronoField.YEAR, 4, 10, SignStyle.EXCEEDS_PAD)
/* 24 */     .appendLiteral('-')
/* 25 */     .appendValue(ChronoField.MONTH_OF_YEAR, 2)
/* 26 */     .toFormatter();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected YearMonth deserialize(String key, DeserializationContext ctxt) throws IOException {
/*    */     try {
/* 33 */       return YearMonth.parse(key, FORMATTER);
/* 34 */     } catch (DateTimeException e) {
/* 35 */       return _handleDateTimeException(ctxt, YearMonth.class, e, key);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-datatype-jsr310-2.14.2.jar!\com\fasterxml\jackson\datatype\jsr310\deser\key\YearMonthKeyDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */