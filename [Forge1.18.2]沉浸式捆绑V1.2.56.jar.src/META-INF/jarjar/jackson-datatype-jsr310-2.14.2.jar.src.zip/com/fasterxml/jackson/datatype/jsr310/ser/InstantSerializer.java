/*    */ package com.fasterxml.jackson.datatype.jsr310.ser;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonFormat;
/*    */ import java.time.Instant;
/*    */ import java.time.format.DateTimeFormatter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InstantSerializer
/*    */   extends InstantSerializerBase<Instant>
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/* 35 */   public static final InstantSerializer INSTANCE = new InstantSerializer();
/*    */   
/*    */   protected InstantSerializer() {
/* 38 */     super(Instant.class, Instant::toEpochMilli, Instant::getEpochSecond, Instant::getNano, (DateTimeFormatter)null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Deprecated
/*    */   protected InstantSerializer(InstantSerializer base, Boolean useTimestamp, DateTimeFormatter formatter) {
/* 46 */     this(base, useTimestamp, base._useNanoseconds, formatter);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected InstantSerializer(InstantSerializer base, Boolean useTimestamp, DateTimeFormatter formatter, JsonFormat.Shape shape) {
/* 54 */     super(base, useTimestamp, base._useNanoseconds, formatter, shape);
/*    */   }
/*    */ 
/*    */   
/*    */   protected InstantSerializer(InstantSerializer base, Boolean useTimestamp, Boolean useNanoseconds, DateTimeFormatter formatter) {
/* 59 */     super(base, useTimestamp, useNanoseconds, formatter);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected JSR310FormattedSerializerBase<Instant> withFormat(Boolean useTimestamp, DateTimeFormatter formatter, JsonFormat.Shape shape) {
/* 65 */     return new InstantSerializer(this, useTimestamp, formatter, shape);
/*    */   }
/*    */ 
/*    */   
/*    */   protected JSR310FormattedSerializerBase<?> withFeatures(Boolean writeZoneId, Boolean writeNanoseconds) {
/* 70 */     return new InstantSerializer(this, this._useTimestamp, writeNanoseconds, this._formatter);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-datatype-jsr310-2.14.2.jar!\com\fasterxml\jackson\datatype\jsr310\ser\InstantSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */