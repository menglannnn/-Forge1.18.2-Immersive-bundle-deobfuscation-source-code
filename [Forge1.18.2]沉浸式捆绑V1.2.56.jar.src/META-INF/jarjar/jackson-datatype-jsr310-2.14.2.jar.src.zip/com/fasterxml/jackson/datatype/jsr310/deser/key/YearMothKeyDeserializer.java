/*   */ package com.fasterxml.jackson.datatype.jsr310.deser.key;
/*   */ 
/*   */ 
/*   */ 
/*   */ @Deprecated
/*   */ public class YearMothKeyDeserializer
/*   */   extends YearMonthKeyDeserializer
/*   */ {
/* 9 */   public static final YearMothKeyDeserializer INSTANCE = new YearMothKeyDeserializer();
/*   */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-datatype-jsr310-2.14.2.jar!\com\fasterxml\jackson\datatype\jsr310\deser\key\YearMothKeyDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */