/*     */ package com.fasterxml.jackson.datatype.jsr310.deser;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat;
/*     */ import com.fasterxml.jackson.core.JacksonException;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.core.StreamReadCapability;
/*     */ import com.fasterxml.jackson.core.io.NumberInput;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.deser.ContextualDeserializer;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*     */ import com.fasterxml.jackson.databind.type.LogicalType;
/*     */ import com.fasterxml.jackson.datatype.jsr310.DecimalUtils;
/*     */ import com.fasterxml.jackson.datatype.jsr310.util.DurationUnitConverter;
/*     */ import java.io.IOException;
/*     */ import java.math.BigDecimal;
/*     */ import java.time.DateTimeException;
/*     */ import java.time.Duration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DurationDeserializer
/*     */   extends JSR310DeserializerBase<Duration>
/*     */   implements ContextualDeserializer
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  48 */   public static final DurationDeserializer INSTANCE = new DurationDeserializer();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final DurationUnitConverter _durationUnitConverter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DurationDeserializer() {
/*  65 */     super(Duration.class);
/*  66 */     this._durationUnitConverter = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected DurationDeserializer(DurationDeserializer base, Boolean leniency) {
/*  73 */     super(base, leniency);
/*  74 */     this._durationUnitConverter = base._durationUnitConverter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected DurationDeserializer(DurationDeserializer base, DurationUnitConverter converter) {
/*  81 */     super(base, Boolean.valueOf(base._isLenient));
/*  82 */     this._durationUnitConverter = converter;
/*     */   }
/*     */ 
/*     */   
/*     */   protected DurationDeserializer withLeniency(Boolean leniency) {
/*  87 */     return new DurationDeserializer(this, leniency);
/*     */   }
/*     */   
/*     */   protected DurationDeserializer withConverter(DurationUnitConverter converter) {
/*  91 */     return new DurationDeserializer(this, converter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonDeserializer<?> createContextual(DeserializationContext ctxt, BeanProperty property) throws JsonMappingException {
/*  98 */     JsonFormat.Value format = findFormatOverrides(ctxt, property, handledType());
/*  99 */     DurationDeserializer deser = this;
/* 100 */     if (format != null) {
/* 101 */       if (format.hasLenient()) {
/* 102 */         Boolean leniency = format.getLenient();
/* 103 */         if (leniency != null) {
/* 104 */           deser = deser.withLeniency(leniency);
/*     */         }
/*     */       } 
/* 107 */       if (format.hasPattern()) {
/* 108 */         String pattern = format.getPattern();
/* 109 */         DurationUnitConverter p = DurationUnitConverter.from(pattern);
/* 110 */         if (p == null)
/* 111 */           ctxt.reportBadDefinition(getValueType(ctxt), 
/* 112 */               String.format("Bad 'pattern' definition (\"%s\") for `Duration`: expected one of [%s]", new Object[] {
/*     */                   
/* 114 */                   pattern, DurationUnitConverter.descForAllowed()
/*     */                 })); 
/* 116 */         deser = deser.withConverter(p);
/*     */       } 
/*     */     } 
/* 119 */     return (JsonDeserializer<?>)deser;
/*     */   }
/*     */ 
/*     */   
/*     */   public Duration deserialize(JsonParser parser, DeserializationContext context) throws IOException {
/*     */     BigDecimal value;
/* 125 */     switch (parser.currentTokenId()) {
/*     */       
/*     */       case 8:
/* 128 */         value = parser.getDecimalValue();
/* 129 */         return (Duration)DecimalUtils.extractSecondsAndNanos(value, Duration::ofSeconds);
/*     */       case 7:
/* 131 */         return _fromTimestamp(context, parser.getLongValue());
/*     */       case 6:
/* 133 */         return _fromString(parser, context, parser.getText());
/*     */       
/*     */       case 1:
/* 136 */         return _fromString(parser, context, context
/* 137 */             .extractScalarFromObject(parser, (JsonDeserializer)this, handledType()));
/*     */ 
/*     */       
/*     */       case 12:
/* 141 */         return (Duration)parser.getEmbeddedObject();
/*     */       
/*     */       case 3:
/* 144 */         return (Duration)_deserializeFromArray(parser, context);
/*     */     } 
/* 146 */     return (Duration)_handleUnexpectedToken(context, parser, new JsonToken[] { JsonToken.VALUE_STRING, JsonToken.VALUE_NUMBER_INT, JsonToken.VALUE_NUMBER_FLOAT });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Duration _fromString(JsonParser parser, DeserializationContext ctxt, String value0) throws IOException {
/* 153 */     String value = value0.trim();
/* 154 */     if (value.length() == 0)
/*     */     {
/*     */ 
/*     */       
/* 158 */       return _fromEmptyString(parser, ctxt, value);
/*     */     }
/*     */ 
/*     */     
/* 162 */     if (ctxt.isEnabled(StreamReadCapability.UNTYPED_SCALARS) && 
/* 163 */       _isValidTimestampString(value)) {
/* 164 */       return _fromTimestamp(ctxt, NumberInput.parseLong(value));
/*     */     }
/*     */     
/*     */     try {
/* 168 */       return Duration.parse(value);
/* 169 */     } catch (DateTimeException e) {
/* 170 */       return (Duration)_handleDateTimeException(ctxt, e, value);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected Duration _fromTimestamp(DeserializationContext ctxt, long ts) {
/* 175 */     if (this._durationUnitConverter != null) {
/* 176 */       return this._durationUnitConverter.convert(ts);
/*     */     }
/*     */ 
/*     */     
/* 180 */     if (ctxt.isEnabled(DeserializationFeature.READ_DATE_TIMESTAMPS_AS_NANOSECONDS)) {
/* 181 */       return Duration.ofSeconds(ts);
/*     */     }
/* 183 */     return Duration.ofMillis(ts);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-datatype-jsr310-2.14.2.jar!\com\fasterxml\jackson\datatype\jsr310\deser\DurationDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */