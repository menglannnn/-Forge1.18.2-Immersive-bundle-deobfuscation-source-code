/*    */ package com.fasterxml.jackson.datatype.jsr310.ser.key;
/*    */ 
/*    */ import com.fasterxml.jackson.core.JsonGenerator;
/*    */ import com.fasterxml.jackson.databind.JsonMappingException;
/*    */ import com.fasterxml.jackson.databind.JsonSerializer;
/*    */ import com.fasterxml.jackson.databind.SerializerProvider;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class Jsr310NullKeySerializer
/*    */   extends JsonSerializer<Object>
/*    */ {
/*    */   public static final String NULL_KEY = "";
/*    */   
/*    */   public void serialize(Object value, JsonGenerator gen, SerializerProvider serializers) throws IOException {
/* 28 */     if (value != null) {
/* 29 */       throw JsonMappingException.from(gen, "Jsr310NullKeySerializer is only for serializing null values.");
/*    */     }
/*    */     
/* 32 */     gen.writeFieldName("");
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-datatype-jsr310-2.14.2.jar!\com\fasterxml\jackson\datatype\jsr310\ser\key\Jsr310NullKeySerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */