/*    */ package com.fasterxml.jackson.datatype.jsr310.util;
/*    */ 
/*    */ import java.time.Duration;
/*    */ import java.time.temporal.ChronoUnit;
/*    */ import java.time.temporal.TemporalUnit;
/*    */ import java.util.LinkedHashMap;
/*    */ import java.util.Map;
/*    */ import java.util.function.Function;
/*    */ import java.util.stream.Collectors;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DurationUnitConverter
/*    */ {
/*    */   private static final Map<String, DurationSerialization> UNITS;
/*    */   final DurationSerialization serialization;
/*    */   
/*    */   protected static class DurationSerialization
/*    */   {
/*    */     final Function<Duration, Long> serializer;
/*    */     final Function<Long, Duration> deserializer;
/*    */     
/*    */     DurationSerialization(Function<Duration, Long> serializer, Function<Long, Duration> deserializer) {
/* 29 */       this.serializer = serializer;
/* 30 */       this.deserializer = deserializer;
/*    */     }
/*    */     
/*    */     static Function<Long, Duration> deserializer(TemporalUnit unit) {
/* 34 */       return v -> Duration.of(v.longValue(), unit);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   static {
/* 41 */     Map<String, DurationSerialization> units = new LinkedHashMap<>();
/* 42 */     units.put(ChronoUnit.NANOS.name(), new DurationSerialization(Duration::toNanos, DurationSerialization.deserializer(ChronoUnit.NANOS)));
/* 43 */     units.put(ChronoUnit.MICROS.name(), new DurationSerialization(d -> Long.valueOf(d.toNanos() / 1000L), DurationSerialization.deserializer(ChronoUnit.MICROS)));
/* 44 */     units.put(ChronoUnit.MILLIS.name(), new DurationSerialization(Duration::toMillis, DurationSerialization.deserializer(ChronoUnit.MILLIS)));
/* 45 */     units.put(ChronoUnit.SECONDS.name(), new DurationSerialization(Duration::getSeconds, DurationSerialization.deserializer(ChronoUnit.SECONDS)));
/* 46 */     units.put(ChronoUnit.MINUTES.name(), new DurationSerialization(Duration::toMinutes, DurationSerialization.deserializer(ChronoUnit.MINUTES)));
/* 47 */     units.put(ChronoUnit.HOURS.name(), new DurationSerialization(Duration::toHours, DurationSerialization.deserializer(ChronoUnit.HOURS)));
/* 48 */     units.put(ChronoUnit.HALF_DAYS.name(), new DurationSerialization(d -> Long.valueOf(d.toHours() / 12L), DurationSerialization.deserializer(ChronoUnit.HALF_DAYS)));
/* 49 */     units.put(ChronoUnit.DAYS.name(), new DurationSerialization(Duration::toDays, DurationSerialization.deserializer(ChronoUnit.DAYS)));
/* 50 */     UNITS = units;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   DurationUnitConverter(DurationSerialization serialization) {
/* 57 */     this.serialization = serialization;
/*    */   }
/*    */   
/*    */   public Duration convert(long value) {
/* 61 */     return this.serialization.deserializer.apply(Long.valueOf(value));
/*    */   }
/*    */   
/*    */   public long convert(Duration duration) {
/* 65 */     return ((Long)this.serialization.serializer.apply(duration)).longValue();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String descForAllowed() {
/* 73 */     return "\"" + (String)UNITS.keySet().stream()
/* 74 */       .collect(Collectors.joining("\", \"")) + "\"";
/*    */   }
/*    */ 
/*    */   
/*    */   public static DurationUnitConverter from(String unit) {
/* 79 */     DurationSerialization def = UNITS.get(unit);
/* 80 */     return (def == null) ? null : new DurationUnitConverter(def);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-datatype-jsr310-2.14.2.jar!\com\fasterxml\jackson\datatype\jsr31\\util\DurationUnitConverter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */