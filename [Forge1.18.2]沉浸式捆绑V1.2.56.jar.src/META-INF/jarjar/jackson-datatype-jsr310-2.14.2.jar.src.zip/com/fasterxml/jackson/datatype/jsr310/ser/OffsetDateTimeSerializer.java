/*    */ package com.fasterxml.jackson.datatype.jsr310.ser;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonFormat;
/*    */ import java.time.OffsetDateTime;
/*    */ import java.time.format.DateTimeFormatter;
/*    */ 
/*    */ public class OffsetDateTimeSerializer
/*    */   extends InstantSerializerBase<OffsetDateTime>
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/* 11 */   public static final OffsetDateTimeSerializer INSTANCE = new OffsetDateTimeSerializer();
/*    */   
/*    */   protected OffsetDateTimeSerializer() {
/* 14 */     super(OffsetDateTime.class, dt -> dt.toInstant().toEpochMilli(), OffsetDateTime::toEpochSecond, OffsetDateTime::getNano, DateTimeFormatter.ISO_OFFSET_DATE_TIME);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Deprecated
/*    */   protected OffsetDateTimeSerializer(OffsetDateTimeSerializer base, Boolean useTimestamp, DateTimeFormatter formatter) {
/* 22 */     this(base, useTimestamp, base._useNanoseconds, formatter);
/*    */   }
/*    */ 
/*    */   
/*    */   protected OffsetDateTimeSerializer(OffsetDateTimeSerializer base, Boolean useTimestamp, Boolean useNanoseconds, DateTimeFormatter formatter) {
/* 27 */     super(base, useTimestamp, useNanoseconds, formatter);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public OffsetDateTimeSerializer(OffsetDateTimeSerializer base, Boolean useTimestamp, DateTimeFormatter formatter, JsonFormat.Shape shape) {
/* 35 */     super(base, useTimestamp, base._useNanoseconds, formatter, shape);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected JSR310FormattedSerializerBase<?> withFormat(Boolean useTimestamp, DateTimeFormatter formatter, JsonFormat.Shape shape) {
/* 42 */     return new OffsetDateTimeSerializer(this, useTimestamp, formatter, shape);
/*    */   }
/*    */ 
/*    */   
/*    */   protected JSR310FormattedSerializerBase<?> withFeatures(Boolean writeZoneId, Boolean writeNanoseconds) {
/* 47 */     return new OffsetDateTimeSerializer(this, this._useTimestamp, writeNanoseconds, this._formatter);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-datatype-jsr310-2.14.2.jar!\com\fasterxml\jackson\datatype\jsr310\ser\OffsetDateTimeSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */