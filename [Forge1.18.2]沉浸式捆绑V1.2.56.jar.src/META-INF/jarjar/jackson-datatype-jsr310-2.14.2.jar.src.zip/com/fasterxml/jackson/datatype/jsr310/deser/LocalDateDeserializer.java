/*     */ package com.fasterxml.jackson.datatype.jsr310.deser;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat;
/*     */ import com.fasterxml.jackson.core.JacksonException;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.cfg.CoercionAction;
/*     */ import com.fasterxml.jackson.databind.cfg.CoercionInputShape;
/*     */ import java.io.IOException;
/*     */ import java.time.DateTimeException;
/*     */ import java.time.LocalDate;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocalDateDeserializer
/*     */   extends JSR310DateTimeDeserializerBase<LocalDate>
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  41 */   private static final DateTimeFormatter DEFAULT_FORMATTER = DateTimeFormatter.ISO_LOCAL_DATE;
/*     */   
/*  43 */   public static final LocalDateDeserializer INSTANCE = new LocalDateDeserializer();
/*     */   
/*     */   protected LocalDateDeserializer() {
/*  46 */     this(DEFAULT_FORMATTER);
/*     */   }
/*     */   
/*     */   public LocalDateDeserializer(DateTimeFormatter dtf) {
/*  50 */     super(LocalDate.class, dtf);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalDateDeserializer(LocalDateDeserializer base, DateTimeFormatter dtf) {
/*  57 */     super(base, dtf);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected LocalDateDeserializer(LocalDateDeserializer base, Boolean leniency) {
/*  64 */     super(base, leniency);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected LocalDateDeserializer(LocalDateDeserializer base, JsonFormat.Shape shape) {
/*  71 */     super(base, shape);
/*     */   }
/*     */ 
/*     */   
/*     */   protected LocalDateDeserializer withDateFormat(DateTimeFormatter dtf) {
/*  76 */     return new LocalDateDeserializer(this, dtf);
/*     */   }
/*     */ 
/*     */   
/*     */   protected LocalDateDeserializer withLeniency(Boolean leniency) {
/*  81 */     return new LocalDateDeserializer(this, leniency);
/*     */   }
/*     */   
/*     */   protected LocalDateDeserializer withShape(JsonFormat.Shape shape) {
/*  85 */     return new LocalDateDeserializer(this, shape);
/*     */   }
/*     */ 
/*     */   
/*     */   public LocalDate deserialize(JsonParser parser, DeserializationContext context) throws IOException {
/*  90 */     if (parser.hasToken(JsonToken.VALUE_STRING)) {
/*  91 */       return _fromString(parser, context, parser.getText());
/*     */     }
/*     */     
/*  94 */     if (parser.isExpectedStartObjectToken()) {
/*  95 */       return _fromString(parser, context, context
/*  96 */           .extractScalarFromObject(parser, (JsonDeserializer)this, handledType()));
/*     */     }
/*  98 */     if (parser.isExpectedStartArrayToken()) {
/*  99 */       JsonToken t = parser.nextToken();
/* 100 */       if (t == JsonToken.END_ARRAY) {
/* 101 */         return null;
/*     */       }
/* 103 */       if (context.isEnabled(DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS) && (t == JsonToken.VALUE_STRING || t == JsonToken.VALUE_EMBEDDED_OBJECT)) {
/*     */         
/* 105 */         LocalDate parsed = deserialize(parser, context);
/* 106 */         if (parser.nextToken() != JsonToken.END_ARRAY) {
/* 107 */           handleMissingEndArrayForSingle(parser, context);
/*     */         }
/* 109 */         return parsed;
/*     */       } 
/* 111 */       if (t == JsonToken.VALUE_NUMBER_INT) {
/* 112 */         int year = parser.getIntValue();
/* 113 */         int month = parser.nextIntValue(-1);
/* 114 */         int day = parser.nextIntValue(-1);
/*     */         
/* 116 */         if (parser.nextToken() != JsonToken.END_ARRAY) {
/* 117 */           throw context.wrongTokenException(parser, handledType(), JsonToken.END_ARRAY, "Expected array to end");
/*     */         }
/*     */         
/* 120 */         return LocalDate.of(year, month, day);
/*     */       } 
/* 122 */       context.reportInputMismatch(handledType(), "Unexpected token (%s) within Array, expected VALUE_NUMBER_INT", new Object[] { t });
/*     */     } 
/*     */ 
/*     */     
/* 126 */     if (parser.hasToken(JsonToken.VALUE_EMBEDDED_OBJECT)) {
/* 127 */       return (LocalDate)parser.getEmbeddedObject();
/*     */     }
/*     */     
/* 130 */     if (parser.hasToken(JsonToken.VALUE_NUMBER_INT)) {
/* 131 */       CoercionAction act = context.findCoercionAction(logicalType(), this._valueClass, CoercionInputShape.Integer);
/*     */       
/* 133 */       _checkCoercionFail(context, act, handledType(), Long.valueOf(parser.getLongValue()), "Integer value (" + parser
/* 134 */           .getLongValue() + ")");
/*     */ 
/*     */       
/* 137 */       if (this._shape == JsonFormat.Shape.NUMBER_INT || isLenient()) {
/* 138 */         return LocalDate.ofEpochDay(parser.getLongValue());
/*     */       }
/* 140 */       return _failForNotLenient(parser, context, JsonToken.VALUE_STRING);
/*     */     } 
/* 142 */     return (LocalDate)_handleUnexpectedToken(context, parser, "Expected array or string.", new Object[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected LocalDate _fromString(JsonParser p, DeserializationContext ctxt, String string0) throws IOException {
/* 148 */     String string = string0.trim();
/* 149 */     if (string.length() == 0)
/*     */     {
/*     */ 
/*     */       
/* 153 */       return _fromEmptyString(p, ctxt, string);
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 158 */       DateTimeFormatter format = this._formatter;
/* 159 */       if (format == DEFAULT_FORMATTER)
/*     */       {
/* 161 */         if (string.length() > 10 && string.charAt(10) == 'T') {
/* 162 */           if (isLenient()) {
/* 163 */             if (string.endsWith("Z")) {
/* 164 */               return LocalDate.parse(string.substring(0, string.length() - 1), DateTimeFormatter.ISO_LOCAL_DATE_TIME);
/*     */             }
/*     */             
/* 167 */             return LocalDate.parse(string, DateTimeFormatter.ISO_LOCAL_DATE_TIME);
/*     */           } 
/* 169 */           JavaType t = getValueType(ctxt);
/* 170 */           return (LocalDate)ctxt.handleWeirdStringValue(t.getRawClass(), string, "Should not contain time component when 'strict' mode set for property or type (enable 'lenient' handling to allow)", new Object[0]);
/*     */         } 
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 176 */       return LocalDate.parse(string, format);
/* 177 */     } catch (DateTimeException e) {
/* 178 */       return (LocalDate)_handleDateTimeException(ctxt, e, string);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-datatype-jsr310-2.14.2.jar!\com\fasterxml\jackson\datatype\jsr310\deser\LocalDateDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */