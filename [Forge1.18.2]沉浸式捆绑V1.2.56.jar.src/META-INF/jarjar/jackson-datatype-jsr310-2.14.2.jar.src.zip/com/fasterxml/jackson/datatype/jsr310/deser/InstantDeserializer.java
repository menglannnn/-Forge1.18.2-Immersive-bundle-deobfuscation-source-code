/*     */ package com.fasterxml.jackson.datatype.jsr310.deser;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat;
/*     */ import com.fasterxml.jackson.core.JacksonException;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.core.io.NumberInput;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.DecimalUtils;
/*     */ import java.io.IOException;
/*     */ import java.math.BigDecimal;
/*     */ import java.time.DateTimeException;
/*     */ import java.time.Instant;
/*     */ import java.time.OffsetDateTime;
/*     */ import java.time.ZoneId;
/*     */ import java.time.ZonedDateTime;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ import java.time.temporal.Temporal;
/*     */ import java.time.temporal.TemporalAccessor;
/*     */ import java.util.Objects;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.Function;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InstantDeserializer<T extends Temporal>
/*     */   extends JSR310DateTimeDeserializerBase<T>
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  62 */   private static final Pattern ISO8601_UTC_ZERO_OFFSET_SUFFIX_REGEX = Pattern.compile("\\+00:?(00)?$");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  69 */   protected static final Pattern ISO8601_COLONLESS_OFFSET_REGEX = Pattern.compile("[+-][0-9]{4}(?=\\[|$)");
/*     */   static {
/*  71 */     INSTANT = new InstantDeserializer((Class)Instant.class, DateTimeFormatter.ISO_INSTANT, Instant::from, a -> Instant.ofEpochMilli(a.value), a -> Instant.ofEpochSecond(a.integer, a.fraction), null, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  80 */     OFFSET_DATE_TIME = new InstantDeserializer((Class)OffsetDateTime.class, DateTimeFormatter.ISO_OFFSET_DATE_TIME, OffsetDateTime::from, a -> OffsetDateTime.ofInstant(Instant.ofEpochMilli(a.value), a.zoneId), a -> OffsetDateTime.ofInstant(Instant.ofEpochSecond(a.integer, a.fraction), a.zoneId), (d, z) -> 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  85 */         (d.isEqual(OffsetDateTime.MIN) || d.isEqual(OffsetDateTime.MAX)) ? d : d.withOffsetSameInstant(z.getRules().getOffset(d.toLocalDateTime())), true);
/*     */ 
/*     */ 
/*     */     
/*  89 */     ZONED_DATE_TIME = new InstantDeserializer((Class)ZonedDateTime.class, DateTimeFormatter.ISO_ZONED_DATE_TIME, ZonedDateTime::from, a -> ZonedDateTime.ofInstant(Instant.ofEpochMilli(a.value), a.zoneId), a -> ZonedDateTime.ofInstant(Instant.ofEpochSecond(a.integer, a.fraction), a.zoneId), ZonedDateTime::withZoneSameInstant, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final InstantDeserializer<Instant> INSTANT;
/*     */ 
/*     */ 
/*     */   
/*     */   public static final InstantDeserializer<OffsetDateTime> OFFSET_DATE_TIME;
/*     */ 
/*     */ 
/*     */   
/*     */   public static final InstantDeserializer<ZonedDateTime> ZONED_DATE_TIME;
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Function<FromIntegerArguments, T> fromMilliseconds;
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Function<FromDecimalArguments, T> fromNanoseconds;
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Function<TemporalAccessor, T> parsedToValue;
/*     */ 
/*     */ 
/*     */   
/*     */   protected final BiFunction<T, ZoneId, T> adjust;
/*     */ 
/*     */   
/*     */   protected final boolean replaceZeroOffsetAsZ;
/*     */ 
/*     */   
/*     */   protected final Boolean _adjustToContextTZOverride;
/*     */ 
/*     */ 
/*     */   
/*     */   protected InstantDeserializer(Class<T> supportedType, DateTimeFormatter formatter, Function<TemporalAccessor, T> parsedToValue, Function<FromIntegerArguments, T> fromMilliseconds, Function<FromDecimalArguments, T> fromNanoseconds, BiFunction<T, ZoneId, T> adjust, boolean replaceZeroOffsetAsZ) {
/* 130 */     super(supportedType, formatter);
/* 131 */     this.parsedToValue = parsedToValue;
/* 132 */     this.fromMilliseconds = fromMilliseconds;
/* 133 */     this.fromNanoseconds = fromNanoseconds;
/* 134 */     this.adjust = (adjust == null) ? ((d, z) -> d) : adjust;
/* 135 */     this.replaceZeroOffsetAsZ = replaceZeroOffsetAsZ;
/* 136 */     this._adjustToContextTZOverride = null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected InstantDeserializer(InstantDeserializer<T> base, DateTimeFormatter f) {
/* 142 */     super(base.handledType(), f);
/* 143 */     this.parsedToValue = base.parsedToValue;
/* 144 */     this.fromMilliseconds = base.fromMilliseconds;
/* 145 */     this.fromNanoseconds = base.fromNanoseconds;
/* 146 */     this.adjust = base.adjust;
/* 147 */     this.replaceZeroOffsetAsZ = (this._formatter == DateTimeFormatter.ISO_INSTANT);
/* 148 */     this._adjustToContextTZOverride = base._adjustToContextTZOverride;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected InstantDeserializer(InstantDeserializer<T> base, Boolean adjustToContextTimezoneOverride) {
/* 154 */     super(base.handledType(), base._formatter);
/* 155 */     this.parsedToValue = base.parsedToValue;
/* 156 */     this.fromMilliseconds = base.fromMilliseconds;
/* 157 */     this.fromNanoseconds = base.fromNanoseconds;
/* 158 */     this.adjust = base.adjust;
/* 159 */     this.replaceZeroOffsetAsZ = base.replaceZeroOffsetAsZ;
/* 160 */     this._adjustToContextTZOverride = adjustToContextTimezoneOverride;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected InstantDeserializer(InstantDeserializer<T> base, DateTimeFormatter f, Boolean leniency) {
/* 166 */     super(base.handledType(), f, leniency);
/* 167 */     this.parsedToValue = base.parsedToValue;
/* 168 */     this.fromMilliseconds = base.fromMilliseconds;
/* 169 */     this.fromNanoseconds = base.fromNanoseconds;
/* 170 */     this.adjust = base.adjust;
/* 171 */     this.replaceZeroOffsetAsZ = (this._formatter == DateTimeFormatter.ISO_INSTANT);
/* 172 */     this._adjustToContextTZOverride = base._adjustToContextTZOverride;
/*     */   }
/*     */ 
/*     */   
/*     */   protected InstantDeserializer<T> withDateFormat(DateTimeFormatter dtf) {
/* 177 */     if (dtf == this._formatter) {
/* 178 */       return this;
/*     */     }
/* 180 */     return new InstantDeserializer(this, dtf);
/*     */   }
/*     */ 
/*     */   
/*     */   protected InstantDeserializer<T> withLeniency(Boolean leniency) {
/* 185 */     return new InstantDeserializer(this, this._formatter, leniency);
/*     */   }
/*     */   
/*     */   protected InstantDeserializer<T> withShape(JsonFormat.Shape shape) {
/* 189 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JSR310DateTimeDeserializerBase<?> _withFormatOverrides(DeserializationContext ctxt, BeanProperty property, JsonFormat.Value formatOverrides) {
/* 196 */     InstantDeserializer<T> deser = (InstantDeserializer)super._withFormatOverrides(ctxt, property, formatOverrides);
/*     */     
/* 198 */     Boolean B = formatOverrides.getFeature(JsonFormat.Feature.ADJUST_DATES_TO_CONTEXT_TIME_ZONE);
/* 199 */     if (!Objects.equals(B, deser._adjustToContextTZOverride)) {
/* 200 */       return new InstantDeserializer(deser, B);
/*     */     }
/* 202 */     return deser;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T deserialize(JsonParser parser, DeserializationContext context) throws IOException {
/* 211 */     switch (parser.currentTokenId()) {
/*     */       
/*     */       case 8:
/* 214 */         return _fromDecimal(context, parser.getDecimalValue());
/*     */       case 7:
/* 216 */         return _fromLong(context, parser.getLongValue());
/*     */       case 6:
/* 218 */         return _fromString(parser, context, parser.getText());
/*     */       
/*     */       case 1:
/* 221 */         return _fromString(parser, context, context
/* 222 */             .extractScalarFromObject(parser, (JsonDeserializer)this, handledType()));
/*     */ 
/*     */       
/*     */       case 12:
/* 226 */         return (T)parser.getEmbeddedObject();
/*     */       
/*     */       case 3:
/* 229 */         return (T)_deserializeFromArray(parser, context);
/*     */     } 
/* 231 */     return (T)_handleUnexpectedToken(context, parser, new JsonToken[] { JsonToken.VALUE_STRING, JsonToken.VALUE_NUMBER_INT, JsonToken.VALUE_NUMBER_FLOAT });
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean shouldAdjustToContextTimezone(DeserializationContext context) {
/* 236 */     return (this._adjustToContextTZOverride != null) ? this._adjustToContextTZOverride.booleanValue() : context
/* 237 */       .isEnabled(DeserializationFeature.ADJUST_DATES_TO_CONTEXT_TIME_ZONE);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected int _countPeriods(String str) {
/* 243 */     int commas = 0;
/* 244 */     for (int i = 0, end = str.length(); i < end; i++) {
/* 245 */       int ch = str.charAt(i);
/* 246 */       if (ch < 48 || ch > 57) {
/* 247 */         if (ch == 46) {
/* 248 */           commas++;
/*     */         } else {
/* 250 */           return -1;
/*     */         } 
/*     */       }
/*     */     } 
/* 254 */     return commas;
/*     */   }
/*     */ 
/*     */   
/*     */   protected T _fromString(JsonParser p, DeserializationContext ctxt, String string0) throws IOException {
/*     */     Temporal temporal;
/* 260 */     String string = string0.trim();
/* 261 */     if (string.length() == 0)
/*     */     {
/*     */ 
/*     */       
/* 265 */       return _fromEmptyString(p, ctxt, string);
/*     */     }
/*     */     
/* 268 */     if (this._formatter == DateTimeFormatter.ISO_INSTANT || this._formatter == DateTimeFormatter.ISO_OFFSET_DATE_TIME || this._formatter == DateTimeFormatter.ISO_ZONED_DATE_TIME) {
/*     */ 
/*     */ 
/*     */       
/* 272 */       int dots = _countPeriods(string);
/* 273 */       if (dots >= 0) {
/*     */         try {
/* 275 */           if (dots == 0) {
/* 276 */             return _fromLong(ctxt, NumberInput.parseLong(string));
/*     */           }
/* 278 */           if (dots == 1) {
/* 279 */             return _fromDecimal(ctxt, NumberInput.parseBigDecimal(string));
/*     */           }
/* 281 */         } catch (NumberFormatException numberFormatException) {}
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 286 */       string = replaceZeroOffsetAsZIfNecessary(string);
/*     */     } 
/*     */ 
/*     */     
/* 290 */     if (this._formatter == DateTimeFormatter.ISO_OFFSET_DATE_TIME || this._formatter == DateTimeFormatter.ISO_ZONED_DATE_TIME)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 297 */       string = addInColonToOffsetIfMissing(string);
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 302 */       TemporalAccessor acc = this._formatter.parse(string);
/* 303 */       temporal = (Temporal)this.parsedToValue.apply(acc);
/* 304 */       if (shouldAdjustToContextTimezone(ctxt)) {
/* 305 */         return this.adjust.apply((T)temporal, getZone(ctxt));
/*     */       }
/* 307 */     } catch (DateTimeException e) {
/* 308 */       temporal = (Temporal)_handleDateTimeException(ctxt, e, string);
/*     */     } 
/* 310 */     return (T)temporal;
/*     */   }
/*     */ 
/*     */   
/*     */   protected T _fromLong(DeserializationContext context, long timestamp) {
/* 315 */     if (context.isEnabled(DeserializationFeature.READ_DATE_TIMESTAMPS_AS_NANOSECONDS)) {
/* 316 */       return this.fromNanoseconds.apply(new FromDecimalArguments(timestamp, 0, 
/* 317 */             getZone(context)));
/*     */     }
/*     */     
/* 320 */     return this.fromMilliseconds.apply(new FromIntegerArguments(timestamp, 
/* 321 */           getZone(context)));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected T _fromDecimal(DeserializationContext context, BigDecimal value) {
/* 327 */     FromDecimalArguments args = (FromDecimalArguments)DecimalUtils.extractSecondsAndNanos(value, (s, ns) -> new FromDecimalArguments(s.longValue(), ns.intValue(), getZone(context)));
/* 328 */     return this.fromNanoseconds.apply(args);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private ZoneId getZone(DeserializationContext context) {
/* 334 */     return (this._valueClass == Instant.class) ? null : context.getTimeZone().toZoneId();
/*     */   }
/*     */ 
/*     */   
/*     */   private String replaceZeroOffsetAsZIfNecessary(String text) {
/* 339 */     if (this.replaceZeroOffsetAsZ) {
/* 340 */       return ISO8601_UTC_ZERO_OFFSET_SUFFIX_REGEX.matcher(text).replaceFirst("Z");
/*     */     }
/*     */     
/* 343 */     return text;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private String addInColonToOffsetIfMissing(String text) {
/* 349 */     Matcher matcher = ISO8601_COLONLESS_OFFSET_REGEX.matcher(text);
/* 350 */     if (matcher.find()) {
/* 351 */       StringBuilder sb = new StringBuilder(matcher.group(0));
/* 352 */       sb.insert(3, ":");
/*     */       
/* 354 */       return matcher.replaceFirst(sb.toString());
/*     */     } 
/* 356 */     return text;
/*     */   }
/*     */ 
/*     */   
/*     */   public static class FromIntegerArguments
/*     */   {
/*     */     public final long value;
/*     */     public final ZoneId zoneId;
/*     */     
/*     */     FromIntegerArguments(long value, ZoneId zoneId) {
/* 366 */       this.value = value;
/* 367 */       this.zoneId = zoneId;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static class FromDecimalArguments
/*     */   {
/*     */     public final long integer;
/*     */     public final int fraction;
/*     */     public final ZoneId zoneId;
/*     */     
/*     */     FromDecimalArguments(long integer, int fraction, ZoneId zoneId) {
/* 379 */       this.integer = integer;
/* 380 */       this.fraction = fraction;
/* 381 */       this.zoneId = zoneId;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-datatype-jsr310-2.14.2.jar!\com\fasterxml\jackson\datatype\jsr310\deser\InstantDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */