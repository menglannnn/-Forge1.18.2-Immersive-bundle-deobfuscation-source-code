/*    */ package com.fasterxml.jackson.datatype.jsr310.deser.key;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.DeserializationContext;
/*    */ import java.io.IOException;
/*    */ import java.time.DateTimeException;
/*    */ import java.time.Year;
/*    */ 
/*    */ public class YearKeyDeserializer
/*    */   extends Jsr310KeyDeserializer
/*    */ {
/* 11 */   public static final YearKeyDeserializer INSTANCE = new YearKeyDeserializer();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected Year deserialize(String key, DeserializationContext ctxt) throws IOException {
/*    */     try {
/* 21 */       return Year.of(Integer.parseInt(key));
/* 22 */     } catch (NumberFormatException nfe) {
/* 23 */       return _handleDateTimeException(ctxt, Year.class, new DateTimeException("Number format exception", nfe), key);
/* 24 */     } catch (DateTimeException dte) {
/* 25 */       return _handleDateTimeException(ctxt, Year.class, dte, key);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-datatype-jsr310-2.14.2.jar!\com\fasterxml\jackson\datatype\jsr310\deser\key\YearKeyDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */