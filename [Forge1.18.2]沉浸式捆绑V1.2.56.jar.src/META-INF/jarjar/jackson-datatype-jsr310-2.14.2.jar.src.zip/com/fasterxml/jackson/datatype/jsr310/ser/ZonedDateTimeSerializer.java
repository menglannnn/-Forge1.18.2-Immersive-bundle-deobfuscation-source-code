/*     */ package com.fasterxml.jackson.datatype.jsr310.ser;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat;
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.databind.SerializationFeature;
/*     */ import com.fasterxml.jackson.databind.SerializerProvider;
/*     */ import java.io.IOException;
/*     */ import java.time.ZonedDateTime;
/*     */ import java.time.chrono.ChronoZonedDateTime;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ import java.time.temporal.Temporal;
/*     */ 
/*     */ public class ZonedDateTimeSerializer extends InstantSerializerBase<ZonedDateTime> {
/*     */   private static final long serialVersionUID = 1L;
/*  16 */   public static final ZonedDateTimeSerializer INSTANCE = new ZonedDateTimeSerializer();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Boolean _writeZoneId;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ZonedDateTimeSerializer() {
/*  29 */     this(DateTimeFormatter.ISO_OFFSET_DATE_TIME);
/*     */   }
/*     */   
/*     */   public ZonedDateTimeSerializer(DateTimeFormatter formatter) {
/*  33 */     super(ZonedDateTime.class, dt -> dt.toInstant().toEpochMilli(), ChronoZonedDateTime::toEpochSecond, ZonedDateTime::getNano, formatter);
/*     */ 
/*     */     
/*  36 */     this._writeZoneId = null;
/*     */   }
/*     */ 
/*     */   
/*     */   protected ZonedDateTimeSerializer(ZonedDateTimeSerializer base, Boolean useTimestamp, DateTimeFormatter formatter, Boolean writeZoneId) {
/*  41 */     this(base, useTimestamp, base._useNanoseconds, formatter, base._shape, writeZoneId);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected ZonedDateTimeSerializer(ZonedDateTimeSerializer base, Boolean useTimestamp, Boolean useNanoseconds, DateTimeFormatter formatter, Boolean writeZoneId) {
/*  48 */     this(base, useTimestamp, useNanoseconds, formatter, base._shape, writeZoneId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ZonedDateTimeSerializer(ZonedDateTimeSerializer base, Boolean useTimestamp, Boolean useNanoseconds, DateTimeFormatter formatter, JsonFormat.Shape shape, Boolean writeZoneId) {
/*  57 */     super(base, useTimestamp, useNanoseconds, formatter, shape);
/*  58 */     this._writeZoneId = writeZoneId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JSR310FormattedSerializerBase<?> withFormat(Boolean useTimestamp, DateTimeFormatter formatter, JsonFormat.Shape shape) {
/*  66 */     return new ZonedDateTimeSerializer(this, useTimestamp, this._useNanoseconds, formatter, shape, this._writeZoneId);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected JSR310FormattedSerializerBase<?> withFeatures(Boolean writeZoneId) {
/*  73 */     return new ZonedDateTimeSerializer(this, this._useTimestamp, this._formatter, writeZoneId);
/*     */   }
/*     */ 
/*     */   
/*     */   protected JSR310FormattedSerializerBase<?> withFeatures(Boolean writeZoneId, Boolean writeNanoseconds) {
/*  78 */     return new ZonedDateTimeSerializer(this, this._useTimestamp, writeNanoseconds, this._formatter, writeZoneId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void serialize(ZonedDateTime value, JsonGenerator g, SerializerProvider provider) throws IOException {
/*  85 */     if (!useTimestamp(provider) && 
/*  86 */       shouldWriteWithZoneId(provider)) {
/*     */       
/*  88 */       g.writeString(DateTimeFormatter.ISO_ZONED_DATE_TIME.format(value));
/*     */       
/*     */       return;
/*     */     } 
/*  92 */     super.serialize(value, g, provider);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean shouldWriteWithZoneId(SerializerProvider ctxt) {
/*  99 */     return (this._writeZoneId != null) ? this._writeZoneId.booleanValue() : ctxt
/* 100 */       .isEnabled(SerializationFeature.WRITE_DATES_WITH_ZONE_ID);
/*     */   }
/*     */ 
/*     */   
/*     */   protected JsonToken serializationShape(SerializerProvider provider) {
/* 105 */     if (!useTimestamp(provider) && shouldWriteWithZoneId(provider)) {
/* 106 */       return JsonToken.VALUE_STRING;
/*     */     }
/* 108 */     return super.serializationShape(provider);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-datatype-jsr310-2.14.2.jar!\com\fasterxml\jackson\datatype\jsr310\ser\ZonedDateTimeSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */