/*     */ package com.fasterxml.jackson.datatype.jsr310.ser;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat;
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.JsonNode;
/*     */ import com.fasterxml.jackson.databind.JsonSerializer;
/*     */ import com.fasterxml.jackson.databind.SerializationFeature;
/*     */ import com.fasterxml.jackson.databind.SerializerProvider;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatVisitorWrapper;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonIntegerFormatVisitor;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonValueFormat;
/*     */ import com.fasterxml.jackson.datatype.jsr310.DecimalUtils;
/*     */ import com.fasterxml.jackson.datatype.jsr310.util.DurationUnitConverter;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Type;
/*     */ import java.math.BigDecimal;
/*     */ import java.time.Duration;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DurationSerializer
/*     */   extends JSR310FormattedSerializerBase<Duration>
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  56 */   public static final DurationSerializer INSTANCE = new DurationSerializer();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private DurationUnitConverter _durationUnitConverter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected DurationSerializer() {
/*  69 */     super(Duration.class);
/*     */   }
/*     */ 
/*     */   
/*     */   protected DurationSerializer(DurationSerializer base, Boolean useTimestamp, DateTimeFormatter dtf) {
/*  74 */     super(base, useTimestamp, dtf, (JsonFormat.Shape)null);
/*     */   }
/*     */ 
/*     */   
/*     */   protected DurationSerializer(DurationSerializer base, Boolean useTimestamp, Boolean useNanoseconds, DateTimeFormatter dtf) {
/*  79 */     super(base, useTimestamp, useNanoseconds, dtf, (JsonFormat.Shape)null);
/*     */   }
/*     */   
/*     */   protected DurationSerializer(DurationSerializer base, DurationUnitConverter converter) {
/*  83 */     super(base, base._useTimestamp, base._useNanoseconds, base._formatter, base._shape);
/*  84 */     this._durationUnitConverter = converter;
/*     */   }
/*     */ 
/*     */   
/*     */   protected DurationSerializer withFormat(Boolean useTimestamp, DateTimeFormatter dtf, JsonFormat.Shape shape) {
/*  89 */     return new DurationSerializer(this, useTimestamp, dtf);
/*     */   }
/*     */   
/*     */   protected DurationSerializer withConverter(DurationUnitConverter converter) {
/*  93 */     return new DurationSerializer(this, converter);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected SerializationFeature getTimestampsFeature() {
/*  99 */     return SerializationFeature.WRITE_DURATIONS_AS_TIMESTAMPS;
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonSerializer<?> createContextual(SerializerProvider prov, BeanProperty property) throws JsonMappingException {
/* 104 */     DurationSerializer ser = (DurationSerializer)super.createContextual(prov, property);
/* 105 */     JsonFormat.Value format = findFormatOverrides(prov, property, handledType());
/* 106 */     if (format != null && format.hasPattern()) {
/* 107 */       String pattern = format.getPattern();
/* 108 */       DurationUnitConverter p = DurationUnitConverter.from(pattern);
/* 109 */       if (p == null)
/* 110 */         prov.reportBadDefinition(handledType(), 
/* 111 */             String.format("Bad 'pattern' definition (\"%s\") for `Duration`: expected one of [%s]", new Object[] {
/*     */                 
/* 113 */                 pattern, DurationUnitConverter.descForAllowed()
/*     */               })); 
/* 115 */       ser = ser.withConverter(p);
/*     */     } 
/* 117 */     return (JsonSerializer<?>)ser;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void serialize(Duration duration, JsonGenerator generator, SerializerProvider provider) throws IOException {
/* 123 */     if (useTimestamp(provider)) {
/*     */ 
/*     */       
/* 126 */       if (this._durationUnitConverter != null) {
/* 127 */         generator.writeNumber(this._durationUnitConverter.convert(duration));
/* 128 */       } else if (useNanoseconds(provider)) {
/* 129 */         generator.writeNumber(_toNanos(duration));
/*     */       } else {
/* 131 */         generator.writeNumber(duration.toMillis());
/*     */       } 
/*     */     } else {
/* 134 */       generator.writeString(duration.toString());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private BigDecimal _toNanos(Duration duration) {
/*     */     BigDecimal bd;
/* 143 */     if (duration.isNegative()) {
/* 144 */       duration = duration.abs();
/*     */ 
/*     */       
/* 147 */       bd = DecimalUtils.toBigDecimal(duration.getSeconds(), duration.getNano()).negate();
/*     */     } else {
/* 149 */       bd = DecimalUtils.toBigDecimal(duration.getSeconds(), duration
/* 150 */           .getNano());
/*     */     } 
/* 152 */     return bd;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _acceptTimestampVisitor(JsonFormatVisitorWrapper visitor, JavaType typeHint) throws JsonMappingException {
/* 158 */     JsonIntegerFormatVisitor v2 = visitor.expectIntegerFormat(typeHint);
/* 159 */     if (v2 != null) {
/* 160 */       v2.numberType(JsonParser.NumberType.LONG);
/* 161 */       SerializerProvider provider = visitor.getProvider();
/* 162 */       if (provider == null || !useNanoseconds(provider))
/*     */       {
/*     */         
/* 165 */         v2.format(JsonValueFormat.UTC_MILLISEC);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected JsonToken serializationShape(SerializerProvider provider) {
/* 172 */     if (useTimestamp(provider)) {
/* 173 */       if (useNanoseconds(provider)) {
/* 174 */         return JsonToken.VALUE_NUMBER_FLOAT;
/*     */       }
/* 176 */       return JsonToken.VALUE_NUMBER_INT;
/*     */     } 
/* 178 */     return JsonToken.VALUE_STRING;
/*     */   }
/*     */ 
/*     */   
/*     */   protected JSR310FormattedSerializerBase<?> withFeatures(Boolean writeZoneId, Boolean writeNanoseconds) {
/* 183 */     return new DurationSerializer(this, this._useTimestamp, writeNanoseconds, this._formatter);
/*     */   }
/*     */ 
/*     */   
/*     */   protected DateTimeFormatter _useDateTimeFormatter(SerializerProvider prov, JsonFormat.Value format) {
/* 188 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-datatype-jsr310-2.14.2.jar!\com\fasterxml\jackson\datatype\jsr310\ser\DurationSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */