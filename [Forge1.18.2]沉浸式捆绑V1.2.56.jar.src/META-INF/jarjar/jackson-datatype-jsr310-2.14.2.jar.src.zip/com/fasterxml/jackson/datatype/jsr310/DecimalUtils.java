/*     */ package com.fasterxml.jackson.datatype.jsr310;
/*     */ 
/*     */ import com.fasterxml.jackson.core.io.NumberInput;
/*     */ import java.math.BigDecimal;
/*     */ import java.time.Instant;
/*     */ import java.util.function.BiFunction;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DecimalUtils
/*     */ {
/*  33 */   private static final BigDecimal ONE_BILLION = new BigDecimal(1000000000L);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toDecimal(long seconds, int nanoseconds) {
/*  41 */     StringBuilder sb = (new StringBuilder(20)).append(seconds).append('.');
/*     */ 
/*     */     
/*  44 */     if (nanoseconds == 0L) {
/*     */ 
/*     */       
/*  47 */       if (seconds == 0L) {
/*  48 */         return "0.0";
/*     */       }
/*     */ 
/*     */       
/*  52 */       sb.append("000000000");
/*     */     } else {
/*  54 */       StringBuilder nanoSB = new StringBuilder(9);
/*  55 */       nanoSB.append(nanoseconds);
/*     */       
/*  57 */       int nanosLen = nanoSB.length();
/*  58 */       int prepZeroes = 9 - nanosLen;
/*  59 */       while (prepZeroes > 0) {
/*  60 */         prepZeroes--;
/*  61 */         sb.append('0');
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  76 */       sb.append(nanoSB);
/*     */     } 
/*  78 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BigDecimal toBigDecimal(long seconds, int nanoseconds) {
/*  89 */     if (nanoseconds == 0L) {
/*     */ 
/*     */       
/*  92 */       if (seconds == 0L) {
/*  93 */         return BigDecimal.ZERO.setScale(1);
/*     */       }
/*  95 */       return BigDecimal.valueOf(seconds).setScale(9);
/*     */     } 
/*  97 */     return NumberInput.parseBigDecimal(toDecimal(seconds, nanoseconds));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static int extractNanosecondDecimal(BigDecimal value, long integer) {
/* 109 */     return value.subtract(BigDecimal.valueOf(integer)).multiply(ONE_BILLION).intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T extractSecondsAndNanos(BigDecimal seconds, BiFunction<Long, Integer, T> convert) {
/*     */     long secondsOnly;
/*     */     int nanosOnly;
/* 127 */     BigDecimal nanoseconds = seconds.scaleByPowerOfTen(9);
/* 128 */     if (nanoseconds.precision() - nanoseconds.scale() <= 0) {
/*     */ 
/*     */       
/* 131 */       secondsOnly = (nanosOnly = 0);
/*     */     }
/* 133 */     else if (seconds.scale() < -63) {
/*     */ 
/*     */       
/* 136 */       secondsOnly = (nanosOnly = 0);
/*     */     }
/*     */     else {
/*     */       
/* 140 */       secondsOnly = seconds.longValue();
/* 141 */       nanosOnly = nanoseconds.subtract(BigDecimal.valueOf(secondsOnly).scaleByPowerOfTen(9)).intValue();
/*     */       
/* 143 */       if (secondsOnly < 0L && secondsOnly > Instant.MIN.getEpochSecond())
/*     */       {
/* 145 */         nanosOnly = Math.abs(nanosOnly);
/*     */       }
/*     */     } 
/*     */     
/* 149 */     return convert.apply(Long.valueOf(secondsOnly), Integer.valueOf(nanosOnly));
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-datatype-jsr310-2.14.2.jar!\com\fasterxml\jackson\datatype\jsr310\DecimalUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */