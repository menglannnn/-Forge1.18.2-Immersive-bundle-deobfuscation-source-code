/*    */ package com.fasterxml.jackson.datatype.jsr310.ser;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonFormat;
/*    */ import java.time.ZonedDateTime;
/*    */ import java.time.chrono.ChronoZonedDateTime;
/*    */ import java.time.format.DateTimeFormatter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class ZonedDateTimeWithZoneIdSerializer
/*    */   extends InstantSerializerBase<ZonedDateTime>
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/* 19 */   public static final ZonedDateTimeWithZoneIdSerializer INSTANCE = new ZonedDateTimeWithZoneIdSerializer();
/*    */   
/*    */   protected ZonedDateTimeWithZoneIdSerializer() {
/* 22 */     super(ZonedDateTime.class, dt -> dt.toInstant().toEpochMilli(), ChronoZonedDateTime::toEpochSecond, ZonedDateTime::getNano, (DateTimeFormatter)null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected ZonedDateTimeWithZoneIdSerializer(ZonedDateTimeWithZoneIdSerializer base, Boolean useTimestamp, DateTimeFormatter formatter) {
/* 30 */     this(base, useTimestamp, (Boolean)null, formatter);
/*    */   }
/*    */ 
/*    */   
/*    */   protected ZonedDateTimeWithZoneIdSerializer(ZonedDateTimeWithZoneIdSerializer base, Boolean useTimestamp, Boolean useNanoseconds, DateTimeFormatter formatter) {
/* 35 */     super(base, useTimestamp, useNanoseconds, formatter);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected JSR310FormattedSerializerBase<?> withFormat(Boolean useTimestamp, DateTimeFormatter formatter, JsonFormat.Shape shape) {
/* 42 */     return new ZonedDateTimeWithZoneIdSerializer(this, useTimestamp, formatter);
/*    */   }
/*    */ 
/*    */   
/*    */   protected JSR310FormattedSerializerBase<?> withFeatures(Boolean writeZoneId, Boolean writeNanoseconds) {
/* 47 */     return new ZonedDateTimeWithZoneIdSerializer(this, this._useTimestamp, writeNanoseconds, this._formatter);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-datatype-jsr310-2.14.2.jar!\com\fasterxml\jackson\datatype\jsr310\ser\ZonedDateTimeWithZoneIdSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */