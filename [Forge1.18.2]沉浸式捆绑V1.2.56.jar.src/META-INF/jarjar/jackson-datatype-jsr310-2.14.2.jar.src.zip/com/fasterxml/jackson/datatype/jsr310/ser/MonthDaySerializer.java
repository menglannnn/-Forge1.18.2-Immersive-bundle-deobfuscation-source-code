/*     */ package com.fasterxml.jackson.datatype.jsr310.ser;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat;
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.core.type.WritableTypeId;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.JsonNode;
/*     */ import com.fasterxml.jackson.databind.JsonSerializer;
/*     */ import com.fasterxml.jackson.databind.SerializerProvider;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatVisitorWrapper;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Type;
/*     */ import java.time.MonthDay;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MonthDaySerializer
/*     */   extends JSR310FormattedSerializerBase<MonthDay>
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  45 */   public static final MonthDaySerializer INSTANCE = new MonthDaySerializer();
/*     */   
/*     */   protected MonthDaySerializer() {
/*  48 */     this((DateTimeFormatter)null);
/*     */   }
/*     */   
/*     */   public MonthDaySerializer(DateTimeFormatter formatter) {
/*  52 */     super(MonthDay.class, formatter);
/*     */   }
/*     */   
/*     */   private MonthDaySerializer(MonthDaySerializer base, Boolean useTimestamp, DateTimeFormatter formatter) {
/*  56 */     super(base, useTimestamp, formatter, null);
/*     */   }
/*     */ 
/*     */   
/*     */   protected MonthDaySerializer withFormat(Boolean useTimestamp, DateTimeFormatter formatter, JsonFormat.Shape shape) {
/*  61 */     return new MonthDaySerializer(this, useTimestamp, formatter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void serialize(MonthDay value, JsonGenerator g, SerializerProvider provider) throws IOException {
/*  68 */     if (_useTimestampExplicitOnly(provider)) {
/*  69 */       g.writeStartArray();
/*  70 */       _serializeAsArrayContents(value, g, provider);
/*  71 */       g.writeEndArray();
/*     */     } else {
/*  73 */       g.writeString((this._formatter == null) ? value.toString() : value.format(this._formatter));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void serializeWithType(MonthDay value, JsonGenerator g, SerializerProvider provider, TypeSerializer typeSer) throws IOException {
/*  81 */     WritableTypeId typeIdDef = typeSer.writeTypePrefix(g, typeSer
/*  82 */         .typeId(value, serializationShape(provider)));
/*     */     
/*  84 */     if (typeIdDef.valueShape == JsonToken.START_ARRAY) {
/*  85 */       _serializeAsArrayContents(value, g, provider);
/*     */     } else {
/*  87 */       g.writeString((this._formatter == null) ? value.toString() : value.format(this._formatter));
/*     */     } 
/*  89 */     typeSer.writeTypeSuffix(g, typeIdDef);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _serializeAsArrayContents(MonthDay value, JsonGenerator g, SerializerProvider provider) throws IOException {
/*  95 */     g.writeNumber(value.getMonthValue());
/*  96 */     g.writeNumber(value.getDayOfMonth());
/*     */   }
/*     */ 
/*     */   
/*     */   protected JsonToken serializationShape(SerializerProvider provider) {
/* 101 */     return _useTimestampExplicitOnly(provider) ? JsonToken.START_ARRAY : JsonToken.VALUE_STRING;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-datatype-jsr310-2.14.2.jar!\com\fasterxml\jackson\datatype\jsr310\ser\MonthDaySerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */