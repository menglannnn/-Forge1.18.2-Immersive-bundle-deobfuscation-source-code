/*    */ package com.fasterxml.jackson.datatype.jsr310;
/*    */ 
/*    */ import com.fasterxml.jackson.core.Version;
/*    */ import com.fasterxml.jackson.core.Versioned;
/*    */ import com.fasterxml.jackson.core.util.VersionUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class PackageVersion
/*    */   implements Versioned
/*    */ {
/* 30 */   public static final Version VERSION = VersionUtil.parseVersion("2.14.2", "com.fasterxml.jackson.datatype", "jackson-datatype-jsr310");
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Version version() {
/* 37 */     return VERSION;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-datatype-jsr310-2.14.2.jar!\com\fasterxml\jackson\datatype\jsr310\PackageVersion.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */