/*      */ package com.fasterxml.jackson.databind.deser;
/*      */ 
/*      */ import com.fasterxml.jackson.core.JsonParser;
/*      */ import com.fasterxml.jackson.core.JsonToken;
/*      */ import com.fasterxml.jackson.databind.BeanDescription;
/*      */ import com.fasterxml.jackson.databind.BeanProperty;
/*      */ import com.fasterxml.jackson.databind.DeserializationContext;
/*      */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*      */ import com.fasterxml.jackson.databind.JavaType;
/*      */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*      */ import com.fasterxml.jackson.databind.JsonMappingException;
/*      */ import com.fasterxml.jackson.databind.cfg.CoercionAction;
/*      */ import com.fasterxml.jackson.databind.deser.impl.BeanAsArrayDeserializer;
/*      */ import com.fasterxml.jackson.databind.deser.impl.BeanPropertyMap;
/*      */ import com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler;
/*      */ import com.fasterxml.jackson.databind.deser.impl.ObjectIdReader;
/*      */ import com.fasterxml.jackson.databind.deser.impl.PropertyBasedCreator;
/*      */ import com.fasterxml.jackson.databind.deser.impl.PropertyValueBuffer;
/*      */ import com.fasterxml.jackson.databind.deser.impl.ReadableObjectId;
/*      */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*      */ import com.fasterxml.jackson.databind.util.IgnorePropertiesUtil;
/*      */ import com.fasterxml.jackson.databind.util.NameTransformer;
/*      */ import com.fasterxml.jackson.databind.util.TokenBuffer;
/*      */ import java.io.IOException;
/*      */ import java.io.Serializable;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class BeanDeserializer
/*      */   extends BeanDeserializerBase
/*      */   implements Serializable
/*      */ {
/*      */   private static final long serialVersionUID = 1L;
/*      */   protected transient Exception _nullFromCreator;
/*      */   private volatile transient NameTransformer _currentlyTransforming;
/*      */   
/*      */   @Deprecated
/*      */   public BeanDeserializer(BeanDeserializerBuilder builder, BeanDescription beanDesc, BeanPropertyMap properties, Map<String, SettableBeanProperty> backRefs, HashSet<String> ignorableProps, boolean ignoreAllUnknown, boolean hasViews) {
/*   70 */     super(builder, beanDesc, properties, backRefs, ignorableProps, ignoreAllUnknown, (Set<String>)null, hasViews);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BeanDeserializer(BeanDeserializerBuilder builder, BeanDescription beanDesc, BeanPropertyMap properties, Map<String, SettableBeanProperty> backRefs, HashSet<String> ignorableProps, boolean ignoreAllUnknown, Set<String> includableProps, boolean hasViews) {
/*   84 */     super(builder, beanDesc, properties, backRefs, ignorableProps, ignoreAllUnknown, includableProps, hasViews);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected BeanDeserializer(BeanDeserializerBase src) {
/*   93 */     super(src, src._ignoreAllUnknown);
/*      */   }
/*      */   
/*      */   protected BeanDeserializer(BeanDeserializerBase src, boolean ignoreAllUnknown) {
/*   97 */     super(src, ignoreAllUnknown);
/*      */   }
/*      */   
/*      */   protected BeanDeserializer(BeanDeserializerBase src, NameTransformer unwrapper) {
/*  101 */     super(src, unwrapper);
/*      */   }
/*      */   
/*      */   public BeanDeserializer(BeanDeserializerBase src, ObjectIdReader oir) {
/*  105 */     super(src, oir);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public BeanDeserializer(BeanDeserializerBase src, Set<String> ignorableProps) {
/*  113 */     super(src, ignorableProps);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BeanDeserializer(BeanDeserializerBase src, Set<String> ignorableProps, Set<String> includableProps) {
/*  120 */     super(src, ignorableProps, includableProps);
/*      */   }
/*      */   
/*      */   public BeanDeserializer(BeanDeserializerBase src, BeanPropertyMap props) {
/*  124 */     super(src, props);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonDeserializer<Object> unwrappingDeserializer(NameTransformer transformer) {
/*  132 */     if (getClass() != BeanDeserializer.class) {
/*  133 */       return (JsonDeserializer<Object>)this;
/*      */     }
/*      */ 
/*      */     
/*  137 */     if (this._currentlyTransforming == transformer) {
/*  138 */       return (JsonDeserializer<Object>)this;
/*      */     }
/*  140 */     this._currentlyTransforming = transformer;
/*      */     
/*  142 */     try { return (JsonDeserializer<Object>)new BeanDeserializer(this, transformer); }
/*  143 */     finally { this._currentlyTransforming = null; }
/*      */   
/*      */   }
/*      */   
/*      */   public BeanDeserializer withObjectIdReader(ObjectIdReader oir) {
/*  148 */     return new BeanDeserializer(this, oir);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public BeanDeserializer withByNameInclusion(Set<String> ignorableProps, Set<String> includableProps) {
/*  154 */     return new BeanDeserializer(this, ignorableProps, includableProps);
/*      */   }
/*      */ 
/*      */   
/*      */   public BeanDeserializerBase withIgnoreAllUnknown(boolean ignoreUnknown) {
/*  159 */     return new BeanDeserializer(this, ignoreUnknown);
/*      */   }
/*      */ 
/*      */   
/*      */   public BeanDeserializerBase withBeanProperties(BeanPropertyMap props) {
/*  164 */     return new BeanDeserializer(this, props);
/*      */   }
/*      */ 
/*      */   
/*      */   protected BeanDeserializerBase asArrayDeserializer() {
/*  169 */     SettableBeanProperty[] props = this._beanProperties.getPropertiesInInsertionOrder();
/*  170 */     return (BeanDeserializerBase)new BeanAsArrayDeserializer(this, props);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  186 */     if (p.isExpectedStartObjectToken()) {
/*  187 */       if (this._vanillaProcessing) {
/*  188 */         return vanillaDeserialize(p, ctxt, p.nextToken());
/*      */       }
/*      */ 
/*      */       
/*  192 */       p.nextToken();
/*  193 */       if (this._objectIdReader != null) {
/*  194 */         return deserializeWithObjectId(p, ctxt);
/*      */       }
/*  196 */       return deserializeFromObject(p, ctxt);
/*      */     } 
/*  198 */     return _deserializeOther(p, ctxt, p.currentToken());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final Object _deserializeOther(JsonParser p, DeserializationContext ctxt, JsonToken t) throws IOException {
/*  205 */     if (t != null) {
/*  206 */       switch (t) {
/*      */         case AsEmpty:
/*  208 */           return deserializeFromString(p, ctxt);
/*      */         case AsNull:
/*  210 */           return deserializeFromNumber(p, ctxt);
/*      */         case TryConvert:
/*  212 */           return deserializeFromDouble(p, ctxt);
/*      */         case null:
/*  214 */           return deserializeFromEmbedded(p, ctxt);
/*      */         case null:
/*      */         case null:
/*  217 */           return deserializeFromBoolean(p, ctxt);
/*      */         case null:
/*  219 */           return deserializeFromNull(p, ctxt);
/*      */         
/*      */         case null:
/*  222 */           return _deserializeFromArray(p, ctxt);
/*      */         case null:
/*      */         case null:
/*  225 */           if (this._vanillaProcessing) {
/*  226 */             return vanillaDeserialize(p, ctxt, t);
/*      */           }
/*  228 */           if (this._objectIdReader != null) {
/*  229 */             return deserializeWithObjectId(p, ctxt);
/*      */           }
/*  231 */           return deserializeFromObject(p, ctxt);
/*      */       } 
/*      */     
/*      */     }
/*  235 */     return ctxt.handleUnexpectedToken(getValueType(ctxt), p);
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   protected Object _missingToken(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  240 */     throw ctxt.endOfInputException(handledType());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object deserialize(JsonParser p, DeserializationContext ctxt, Object bean) throws IOException {
/*      */     String propName;
/*  252 */     p.setCurrentValue(bean);
/*  253 */     if (this._injectables != null) {
/*  254 */       injectValues(ctxt, bean);
/*      */     }
/*  256 */     if (this._unwrappedPropertyHandler != null) {
/*  257 */       return deserializeWithUnwrapped(p, ctxt, bean);
/*      */     }
/*  259 */     if (this._externalTypeIdHandler != null) {
/*  260 */       return deserializeWithExternalTypeId(p, ctxt, bean);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  265 */     if (p.isExpectedStartObjectToken()) {
/*  266 */       propName = p.nextFieldName();
/*  267 */       if (propName == null) {
/*  268 */         return bean;
/*      */       }
/*      */     }
/*  271 */     else if (p.hasTokenId(5)) {
/*  272 */       propName = p.currentName();
/*      */     } else {
/*  274 */       return bean;
/*      */     } 
/*      */     
/*  277 */     if (this._needViewProcesing) {
/*  278 */       Class<?> view = ctxt.getActiveView();
/*  279 */       if (view != null) {
/*  280 */         return deserializeWithView(p, ctxt, bean, view);
/*      */       }
/*      */     } 
/*      */     while (true) {
/*  284 */       p.nextToken();
/*  285 */       SettableBeanProperty prop = this._beanProperties.find(propName);
/*      */       
/*  287 */       if (prop != null) {
/*      */         try {
/*  289 */           prop.deserializeAndSet(p, ctxt, bean);
/*  290 */         } catch (Exception e) {
/*  291 */           wrapAndThrow(e, bean, propName, ctxt);
/*      */         } 
/*      */       } else {
/*      */         
/*  295 */         handleUnknownVanilla(p, ctxt, bean, propName);
/*  296 */       }  if ((propName = p.nextFieldName()) == null) {
/*  297 */         return bean;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final Object vanillaDeserialize(JsonParser p, DeserializationContext ctxt, JsonToken t) throws IOException {
/*  314 */     Object bean = this._valueInstantiator.createUsingDefault(ctxt);
/*      */     
/*  316 */     p.setCurrentValue(bean);
/*  317 */     if (p.hasTokenId(5)) {
/*  318 */       String propName = p.currentName();
/*      */       do {
/*  320 */         p.nextToken();
/*  321 */         SettableBeanProperty prop = this._beanProperties.find(propName);
/*      */         
/*  323 */         if (prop != null)
/*      */         { try {
/*  325 */             prop.deserializeAndSet(p, ctxt, bean);
/*  326 */           } catch (Exception e) {
/*  327 */             wrapAndThrow(e, bean, propName, ctxt);
/*      */           }  }
/*      */         else
/*      */         
/*  331 */         { handleUnknownVanilla(p, ctxt, bean, propName); } 
/*  332 */       } while ((propName = p.nextFieldName()) != null);
/*      */     } 
/*  334 */     return bean;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object deserializeFromObject(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  350 */     if (this._objectIdReader != null && this._objectIdReader.maySerializeAsObject() && 
/*  351 */       p.hasTokenId(5) && this._objectIdReader
/*  352 */       .isValidReferencePropertyName(p.currentName(), p)) {
/*  353 */       return deserializeFromObjectId(p, ctxt);
/*      */     }
/*      */     
/*  356 */     if (this._nonStandardCreation) {
/*  357 */       if (this._unwrappedPropertyHandler != null) {
/*  358 */         return deserializeWithUnwrapped(p, ctxt);
/*      */       }
/*  360 */       if (this._externalTypeIdHandler != null) {
/*  361 */         return deserializeWithExternalTypeId(p, ctxt);
/*      */       }
/*  363 */       Object object = deserializeFromObjectUsingNonDefault(p, ctxt);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  376 */       return object;
/*      */     } 
/*  378 */     Object bean = this._valueInstantiator.createUsingDefault(ctxt);
/*      */     
/*  380 */     p.setCurrentValue(bean);
/*  381 */     if (p.canReadObjectId()) {
/*  382 */       Object id = p.getObjectId();
/*  383 */       if (id != null) {
/*  384 */         _handleTypedObjectId(p, ctxt, bean, id);
/*      */       }
/*      */     } 
/*  387 */     if (this._injectables != null) {
/*  388 */       injectValues(ctxt, bean);
/*      */     }
/*  390 */     if (this._needViewProcesing) {
/*  391 */       Class<?> view = ctxt.getActiveView();
/*  392 */       if (view != null) {
/*  393 */         return deserializeWithView(p, ctxt, bean, view);
/*      */       }
/*      */     } 
/*  396 */     if (p.hasTokenId(5)) {
/*  397 */       String propName = p.currentName();
/*      */       do {
/*  399 */         p.nextToken();
/*  400 */         SettableBeanProperty prop = this._beanProperties.find(propName);
/*  401 */         if (prop != null)
/*      */         { try {
/*  403 */             prop.deserializeAndSet(p, ctxt, bean);
/*  404 */           } catch (Exception e) {
/*  405 */             wrapAndThrow(e, bean, propName, ctxt);
/*      */           }  }
/*      */         else
/*      */         
/*  409 */         { handleUnknownVanilla(p, ctxt, bean, propName); } 
/*  410 */       } while ((propName = p.nextFieldName()) != null);
/*      */     } 
/*  412 */     return bean;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object _deserializeUsingPropertyBased(JsonParser p, DeserializationContext ctxt) throws IOException {
/*      */     Object bean;
/*  427 */     PropertyBasedCreator creator = this._propertyBasedCreator;
/*  428 */     PropertyValueBuffer buffer = creator.startBuilding(p, ctxt, this._objectIdReader);
/*  429 */     TokenBuffer unknown = null;
/*  430 */     Class<?> activeView = this._needViewProcesing ? ctxt.getActiveView() : null;
/*      */     
/*  432 */     JsonToken t = p.currentToken();
/*  433 */     List<BeanReferring> referrings = null;
/*  434 */     for (; t == JsonToken.FIELD_NAME; t = p.nextToken()) {
/*  435 */       String propName = p.currentName();
/*  436 */       p.nextToken();
/*  437 */       SettableBeanProperty creatorProp = creator.findCreatorProperty(propName);
/*      */       
/*  439 */       if (!buffer.readIdProperty(propName) || creatorProp != null)
/*      */       {
/*      */ 
/*      */         
/*  443 */         if (creatorProp != null) {
/*      */ 
/*      */           
/*  446 */           if (activeView != null && !creatorProp.visibleInView(activeView)) {
/*  447 */             p.skipChildren();
/*      */           } else {
/*      */             
/*  450 */             Object value = _deserializeWithErrorWrapping(p, ctxt, creatorProp);
/*  451 */             if (buffer.assignParameter(creatorProp, value)) {
/*  452 */               Object object; p.nextToken();
/*      */               
/*      */               try {
/*  455 */                 object = creator.build(ctxt, buffer);
/*  456 */               } catch (Exception e) {
/*  457 */                 object = wrapInstantiationProblem(e, ctxt);
/*      */               } 
/*  459 */               if (object == null) {
/*  460 */                 return ctxt.handleInstantiationProblem(handledType(), null, 
/*  461 */                     _creatorReturnedNullException());
/*      */               }
/*      */               
/*  464 */               p.setCurrentValue(object);
/*      */ 
/*      */               
/*  467 */               if (object.getClass() != this._beanType.getRawClass()) {
/*  468 */                 return handlePolymorphic(p, ctxt, object, unknown);
/*      */               }
/*  470 */               if (unknown != null) {
/*  471 */                 object = handleUnknownProperties(ctxt, object, unknown);
/*      */               }
/*      */               
/*  474 */               return deserialize(p, ctxt, object);
/*      */             } 
/*      */           } 
/*      */         } else {
/*      */           
/*  479 */           SettableBeanProperty prop = this._beanProperties.find(propName);
/*  480 */           if (prop != null) {
/*      */             try {
/*  482 */               buffer.bufferProperty(prop, _deserializeWithErrorWrapping(p, ctxt, prop));
/*  483 */             } catch (UnresolvedForwardReference reference) {
/*      */ 
/*      */ 
/*      */               
/*  487 */               BeanReferring referring = handleUnresolvedReference(ctxt, prop, buffer, reference);
/*      */               
/*  489 */               if (referrings == null) {
/*  490 */                 referrings = new ArrayList<>();
/*      */               }
/*  492 */               referrings.add(referring);
/*      */             
/*      */             }
/*      */           
/*      */           }
/*  497 */           else if (IgnorePropertiesUtil.shouldIgnore(propName, this._ignorableProps, this._includableProps)) {
/*  498 */             handleIgnoredProperty(p, ctxt, handledType(), propName);
/*      */ 
/*      */           
/*      */           }
/*  502 */           else if (this._anySetter != null) {
/*      */             try {
/*  504 */               buffer.bufferAnyProperty(this._anySetter, propName, this._anySetter.deserialize(p, ctxt));
/*  505 */             } catch (Exception e) {
/*  506 */               wrapAndThrow(e, this._beanType.getRawClass(), propName, ctxt);
/*      */             }
/*      */           
/*      */           } else {
/*      */             
/*  511 */             if (unknown == null) {
/*  512 */               unknown = new TokenBuffer(p, ctxt);
/*      */             }
/*  514 */             unknown.writeFieldName(propName);
/*  515 */             unknown.copyCurrentStructure(p);
/*      */           } 
/*      */         } 
/*      */       }
/*      */     } 
/*      */     try {
/*  521 */       bean = creator.build(ctxt, buffer);
/*  522 */     } catch (Exception e) {
/*  523 */       wrapInstantiationProblem(e, ctxt);
/*  524 */       bean = null;
/*      */     } 
/*      */     
/*  527 */     if (this._injectables != null) {
/*  528 */       injectValues(ctxt, bean);
/*      */     }
/*      */     
/*  531 */     if (referrings != null) {
/*  532 */       for (BeanReferring referring : referrings) {
/*  533 */         referring.setBean(bean);
/*      */       }
/*      */     }
/*  536 */     if (unknown != null) {
/*      */       
/*  538 */       if (bean.getClass() != this._beanType.getRawClass()) {
/*  539 */         return handlePolymorphic((JsonParser)null, ctxt, bean, unknown);
/*      */       }
/*      */       
/*  542 */       return handleUnknownProperties(ctxt, bean, unknown);
/*      */     } 
/*  544 */     return bean;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private BeanReferring handleUnresolvedReference(DeserializationContext ctxt, SettableBeanProperty prop, PropertyValueBuffer buffer, UnresolvedForwardReference reference) throws JsonMappingException {
/*  556 */     BeanReferring referring = new BeanReferring(ctxt, reference, prop.getType(), buffer, prop);
/*  557 */     reference.getRoid().appendReferring(referring);
/*  558 */     return referring;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final Object _deserializeWithErrorWrapping(JsonParser p, DeserializationContext ctxt, SettableBeanProperty prop) throws IOException {
/*      */     try {
/*  566 */       return prop.deserialize(p, ctxt);
/*  567 */     } catch (Exception e) {
/*  568 */       wrapAndThrow(e, this._beanType.getRawClass(), prop.getName(), ctxt);
/*      */       
/*  570 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object deserializeFromNull(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  588 */     if (p.requiresCustomCodec()) {
/*      */       
/*  590 */       TokenBuffer tb = new TokenBuffer(p, ctxt);
/*  591 */       tb.writeEndObject();
/*  592 */       JsonParser p2 = tb.asParser(p);
/*  593 */       p2.nextToken();
/*      */ 
/*      */       
/*  596 */       Object ob = this._vanillaProcessing ? vanillaDeserialize(p2, ctxt, JsonToken.END_OBJECT) : deserializeFromObject(p2, ctxt);
/*  597 */       p2.close();
/*  598 */       return ob;
/*      */     } 
/*  600 */     return ctxt.handleUnexpectedToken(getValueType(ctxt), p);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object _deserializeFromArray(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  607 */     JsonDeserializer<Object> delegateDeser = this._arrayDelegateDeserializer;
/*      */     
/*  609 */     if (delegateDeser != null || (delegateDeser = this._delegateDeserializer) != null) {
/*  610 */       Object bean = this._valueInstantiator.createUsingArrayDelegate(ctxt, delegateDeser
/*  611 */           .deserialize(p, ctxt));
/*  612 */       if (this._injectables != null) {
/*  613 */         injectValues(ctxt, bean);
/*      */       }
/*  615 */       return bean;
/*      */     } 
/*  617 */     CoercionAction act = _findCoercionFromEmptyArray(ctxt);
/*  618 */     boolean unwrap = ctxt.isEnabled(DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS);
/*      */     
/*  620 */     if (unwrap || act != CoercionAction.Fail) {
/*  621 */       JsonToken t = p.nextToken();
/*  622 */       if (t == JsonToken.END_ARRAY) {
/*  623 */         switch (act) {
/*      */           case AsEmpty:
/*  625 */             return getEmptyValue(ctxt);
/*      */           case AsNull:
/*      */           case TryConvert:
/*  628 */             return getNullValue(ctxt);
/*      */         } 
/*      */         
/*  631 */         return ctxt.handleUnexpectedToken(getValueType(ctxt), JsonToken.START_ARRAY, p, null, new Object[0]);
/*      */       } 
/*  633 */       if (unwrap) {
/*      */ 
/*      */         
/*  636 */         if (p.nextToken() == JsonToken.START_ARRAY) {
/*  637 */           JavaType targetType = getValueType(ctxt);
/*  638 */           return ctxt.handleUnexpectedToken(targetType, JsonToken.START_ARRAY, p, "Cannot deserialize value of type %s from deeply-nested JSON Array: only single wrapper allowed with `%s`", new Object[] {
/*      */                 
/*  640 */                 ClassUtil.getTypeDescription(targetType), "DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS"
/*      */               });
/*      */         } 
/*  643 */         Object value = deserialize(p, ctxt);
/*  644 */         if (p.nextToken() != JsonToken.END_ARRAY) {
/*  645 */           handleMissingEndArrayForSingle(p, ctxt);
/*      */         }
/*  647 */         return value;
/*      */       } 
/*      */     } 
/*  650 */     return ctxt.handleUnexpectedToken(getValueType(ctxt), p);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final Object deserializeWithView(JsonParser p, DeserializationContext ctxt, Object bean, Class<?> activeView) throws IOException {
/*  663 */     if (p.hasTokenId(5)) {
/*  664 */       String propName = p.currentName();
/*      */       do {
/*  666 */         p.nextToken();
/*      */         
/*  668 */         SettableBeanProperty prop = this._beanProperties.find(propName);
/*  669 */         if (prop != null)
/*  670 */         { if (!prop.visibleInView(activeView)) {
/*  671 */             p.skipChildren();
/*      */           } else {
/*      */             
/*      */             try {
/*  675 */               prop.deserializeAndSet(p, ctxt, bean);
/*  676 */             } catch (Exception e) {
/*  677 */               wrapAndThrow(e, bean, propName, ctxt);
/*      */             } 
/*      */           }  }
/*      */         else
/*  681 */         { handleUnknownVanilla(p, ctxt, bean, propName); } 
/*  682 */       } while ((propName = p.nextFieldName()) != null);
/*      */     } 
/*  684 */     return bean;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object deserializeWithUnwrapped(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  701 */     if (this._delegateDeserializer != null) {
/*  702 */       return this._valueInstantiator.createUsingDelegate(ctxt, this._delegateDeserializer.deserialize(p, ctxt));
/*      */     }
/*  704 */     if (this._propertyBasedCreator != null) {
/*  705 */       return deserializeUsingPropertyBasedWithUnwrapped(p, ctxt);
/*      */     }
/*  707 */     TokenBuffer tokens = new TokenBuffer(p, ctxt);
/*  708 */     tokens.writeStartObject();
/*  709 */     Object bean = this._valueInstantiator.createUsingDefault(ctxt);
/*      */ 
/*      */     
/*  712 */     p.setCurrentValue(bean);
/*      */     
/*  714 */     if (this._injectables != null) {
/*  715 */       injectValues(ctxt, bean);
/*      */     }
/*  717 */     Class<?> activeView = this._needViewProcesing ? ctxt.getActiveView() : null;
/*  718 */     String propName = p.hasTokenId(5) ? p.currentName() : null;
/*      */     
/*  720 */     for (; propName != null; propName = p.nextFieldName()) {
/*  721 */       p.nextToken();
/*  722 */       SettableBeanProperty prop = this._beanProperties.find(propName);
/*  723 */       if (prop != null) {
/*  724 */         if (activeView != null && !prop.visibleInView(activeView)) {
/*  725 */           p.skipChildren();
/*      */         } else {
/*      */           
/*      */           try {
/*  729 */             prop.deserializeAndSet(p, ctxt, bean);
/*  730 */           } catch (Exception e) {
/*  731 */             wrapAndThrow(e, bean, propName, ctxt);
/*      */           }
/*      */         
/*      */         }
/*      */       
/*  736 */       } else if (IgnorePropertiesUtil.shouldIgnore(propName, this._ignorableProps, this._includableProps)) {
/*  737 */         handleIgnoredProperty(p, ctxt, bean, propName);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*  744 */       else if (this._anySetter == null) {
/*      */         
/*  746 */         tokens.writeFieldName(propName);
/*  747 */         tokens.copyCurrentStructure(p);
/*      */       }
/*      */       else {
/*      */         
/*  751 */         TokenBuffer b2 = TokenBuffer.asCopyOfValue(p);
/*  752 */         tokens.writeFieldName(propName);
/*  753 */         tokens.append(b2);
/*      */         try {
/*  755 */           this._anySetter.deserializeAndSet(b2.asParserOnFirstToken(), ctxt, bean, propName);
/*  756 */         } catch (Exception e) {
/*  757 */           wrapAndThrow(e, bean, propName, ctxt);
/*      */         } 
/*      */       } 
/*  760 */     }  tokens.writeEndObject();
/*  761 */     this._unwrappedPropertyHandler.processUnwrapped(p, ctxt, bean, tokens);
/*  762 */     return bean;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object deserializeWithUnwrapped(JsonParser p, DeserializationContext ctxt, Object bean) throws IOException {
/*  770 */     JsonToken t = p.currentToken();
/*  771 */     if (t == JsonToken.START_OBJECT) {
/*  772 */       t = p.nextToken();
/*      */     }
/*  774 */     TokenBuffer tokens = new TokenBuffer(p, ctxt);
/*  775 */     tokens.writeStartObject();
/*  776 */     Class<?> activeView = this._needViewProcesing ? ctxt.getActiveView() : null;
/*  777 */     for (; t == JsonToken.FIELD_NAME; t = p.nextToken()) {
/*  778 */       String propName = p.currentName();
/*  779 */       SettableBeanProperty prop = this._beanProperties.find(propName);
/*  780 */       p.nextToken();
/*  781 */       if (prop != null) {
/*  782 */         if (activeView != null && !prop.visibleInView(activeView)) {
/*  783 */           p.skipChildren();
/*      */         } else {
/*      */           
/*      */           try {
/*  787 */             prop.deserializeAndSet(p, ctxt, bean);
/*  788 */           } catch (Exception e) {
/*  789 */             wrapAndThrow(e, bean, propName, ctxt);
/*      */           }
/*      */         
/*      */         } 
/*  793 */       } else if (IgnorePropertiesUtil.shouldIgnore(propName, this._ignorableProps, this._includableProps)) {
/*  794 */         handleIgnoredProperty(p, ctxt, bean, propName);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*  801 */       else if (this._anySetter == null) {
/*      */         
/*  803 */         tokens.writeFieldName(propName);
/*  804 */         tokens.copyCurrentStructure(p);
/*      */       } else {
/*      */         
/*  807 */         TokenBuffer b2 = TokenBuffer.asCopyOfValue(p);
/*  808 */         tokens.writeFieldName(propName);
/*  809 */         tokens.append(b2);
/*      */         try {
/*  811 */           this._anySetter.deserializeAndSet(b2.asParserOnFirstToken(), ctxt, bean, propName);
/*  812 */         } catch (Exception e) {
/*  813 */           wrapAndThrow(e, bean, propName, ctxt);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  818 */     tokens.writeEndObject();
/*  819 */     this._unwrappedPropertyHandler.processUnwrapped(p, ctxt, bean, tokens);
/*  820 */     return bean;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object deserializeUsingPropertyBasedWithUnwrapped(JsonParser p, DeserializationContext ctxt) throws IOException {
/*      */     Object bean;
/*  831 */     PropertyBasedCreator creator = this._propertyBasedCreator;
/*  832 */     PropertyValueBuffer buffer = creator.startBuilding(p, ctxt, this._objectIdReader);
/*      */     
/*  834 */     TokenBuffer tokens = new TokenBuffer(p, ctxt);
/*  835 */     tokens.writeStartObject();
/*      */     
/*  837 */     JsonToken t = p.currentToken();
/*  838 */     for (; t == JsonToken.FIELD_NAME; t = p.nextToken()) {
/*  839 */       String propName = p.currentName();
/*  840 */       p.nextToken();
/*      */       
/*  842 */       SettableBeanProperty creatorProp = creator.findCreatorProperty(propName);
/*      */       
/*  844 */       if (!buffer.readIdProperty(propName) || creatorProp != null)
/*      */       {
/*      */         
/*  847 */         if (creatorProp != null) {
/*      */           
/*  849 */           if (buffer.assignParameter(creatorProp, 
/*  850 */               _deserializeWithErrorWrapping(p, ctxt, creatorProp))) {
/*  851 */             Object object; t = p.nextToken();
/*      */             
/*      */             try {
/*  854 */               object = creator.build(ctxt, buffer);
/*  855 */             } catch (Exception e) {
/*  856 */               object = wrapInstantiationProblem(e, ctxt);
/*      */             } 
/*      */             
/*  859 */             p.setCurrentValue(object);
/*      */             
/*  861 */             while (t == JsonToken.FIELD_NAME) {
/*      */               
/*  863 */               tokens.copyCurrentStructure(p);
/*  864 */               t = p.nextToken();
/*      */             } 
/*      */ 
/*      */             
/*  868 */             if (t != JsonToken.END_OBJECT)
/*  869 */               ctxt.reportWrongTokenException((JsonDeserializer)this, JsonToken.END_OBJECT, "Attempted to unwrap '%s' value", new Object[] {
/*      */                     
/*  871 */                     handledType().getName()
/*      */                   }); 
/*  873 */             tokens.writeEndObject();
/*  874 */             if (object.getClass() != this._beanType.getRawClass()) {
/*      */ 
/*      */               
/*  877 */               ctxt.reportInputMismatch((BeanProperty)creatorProp, "Cannot create polymorphic instances with unwrapped values", new Object[0]);
/*      */               
/*  879 */               return null;
/*      */             } 
/*  881 */             return this._unwrappedPropertyHandler.processUnwrapped(p, ctxt, object, tokens);
/*      */           }
/*      */         
/*      */         } else {
/*      */           
/*  886 */           SettableBeanProperty prop = this._beanProperties.find(propName);
/*  887 */           if (prop != null) {
/*  888 */             buffer.bufferProperty(prop, _deserializeWithErrorWrapping(p, ctxt, prop));
/*      */ 
/*      */           
/*      */           }
/*  892 */           else if (IgnorePropertiesUtil.shouldIgnore(propName, this._ignorableProps, this._includableProps)) {
/*  893 */             handleIgnoredProperty(p, ctxt, handledType(), propName);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           }
/*  900 */           else if (this._anySetter == null) {
/*      */             
/*  902 */             tokens.writeFieldName(propName);
/*  903 */             tokens.copyCurrentStructure(p);
/*      */           } else {
/*      */             
/*  906 */             TokenBuffer b2 = TokenBuffer.asCopyOfValue(p);
/*  907 */             tokens.writeFieldName(propName);
/*  908 */             tokens.append(b2);
/*      */             try {
/*  910 */               buffer.bufferAnyProperty(this._anySetter, propName, this._anySetter
/*  911 */                   .deserialize(b2.asParserOnFirstToken(), ctxt));
/*  912 */             } catch (Exception e) {
/*  913 */               wrapAndThrow(e, this._beanType.getRawClass(), propName, ctxt);
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*      */     try {
/*  922 */       bean = creator.build(ctxt, buffer);
/*  923 */     } catch (Exception e) {
/*  924 */       wrapInstantiationProblem(e, ctxt);
/*  925 */       return null;
/*      */     } 
/*  927 */     return this._unwrappedPropertyHandler.processUnwrapped(p, ctxt, bean, tokens);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object deserializeWithExternalTypeId(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  940 */     if (this._propertyBasedCreator != null) {
/*  941 */       return deserializeUsingPropertyBasedWithExternalTypeId(p, ctxt);
/*      */     }
/*  943 */     if (this._delegateDeserializer != null)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  949 */       return this._valueInstantiator.createUsingDelegate(ctxt, this._delegateDeserializer
/*  950 */           .deserialize(p, ctxt));
/*      */     }
/*      */     
/*  953 */     return deserializeWithExternalTypeId(p, ctxt, this._valueInstantiator.createUsingDefault(ctxt));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object deserializeWithExternalTypeId(JsonParser p, DeserializationContext ctxt, Object bean) throws IOException {
/*  960 */     return _deserializeWithExternalTypeId(p, ctxt, bean, this._externalTypeIdHandler
/*  961 */         .start());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object _deserializeWithExternalTypeId(JsonParser p, DeserializationContext ctxt, Object bean, ExternalTypeHandler ext) throws IOException {
/*  968 */     Class<?> activeView = this._needViewProcesing ? ctxt.getActiveView() : null;
/*  969 */     for (JsonToken t = p.currentToken(); t == JsonToken.FIELD_NAME; t = p.nextToken()) {
/*  970 */       String propName = p.currentName();
/*  971 */       t = p.nextToken();
/*  972 */       SettableBeanProperty prop = this._beanProperties.find(propName);
/*  973 */       if (prop != null) {
/*      */         
/*  975 */         if (t.isScalarValue()) {
/*  976 */           ext.handleTypePropertyValue(p, ctxt, propName, bean);
/*      */         }
/*  978 */         if (activeView != null && !prop.visibleInView(activeView)) {
/*  979 */           p.skipChildren();
/*      */         } else {
/*      */           
/*      */           try {
/*  983 */             prop.deserializeAndSet(p, ctxt, bean);
/*  984 */           } catch (Exception e) {
/*  985 */             wrapAndThrow(e, bean, propName, ctxt);
/*      */           }
/*      */         
/*      */         }
/*      */       
/*  990 */       } else if (IgnorePropertiesUtil.shouldIgnore(propName, this._ignorableProps, this._includableProps)) {
/*  991 */         handleIgnoredProperty(p, ctxt, bean, propName);
/*      */ 
/*      */       
/*      */       }
/*  995 */       else if (!ext.handlePropertyValue(p, ctxt, propName, bean)) {
/*      */ 
/*      */ 
/*      */         
/*  999 */         if (this._anySetter != null) {
/*      */           try {
/* 1001 */             this._anySetter.deserializeAndSet(p, ctxt, bean, propName);
/* 1002 */           } catch (Exception e) {
/* 1003 */             wrapAndThrow(e, bean, propName, ctxt);
/*      */           }
/*      */         
/*      */         } else {
/*      */           
/* 1008 */           handleUnknownProperty(p, ctxt, bean, propName);
/*      */         } 
/*      */       } 
/* 1011 */     }  return ext.complete(p, ctxt, bean);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object deserializeUsingPropertyBasedWithExternalTypeId(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 1019 */     ExternalTypeHandler ext = this._externalTypeIdHandler.start();
/* 1020 */     PropertyBasedCreator creator = this._propertyBasedCreator;
/* 1021 */     PropertyValueBuffer buffer = creator.startBuilding(p, ctxt, this._objectIdReader);
/* 1022 */     Class<?> activeView = this._needViewProcesing ? ctxt.getActiveView() : null;
/*      */     
/* 1024 */     JsonToken t = p.currentToken();
/* 1025 */     for (; t == JsonToken.FIELD_NAME; t = p.nextToken()) {
/* 1026 */       String propName = p.currentName();
/* 1027 */       t = p.nextToken();
/*      */       
/* 1029 */       SettableBeanProperty creatorProp = creator.findCreatorProperty(propName);
/*      */       
/* 1031 */       if (!buffer.readIdProperty(propName) || creatorProp != null)
/*      */       {
/*      */         
/* 1034 */         if (creatorProp != null) {
/*      */ 
/*      */ 
/*      */           
/* 1038 */           if (!ext.handlePropertyValue(p, ctxt, propName, null))
/*      */           {
/*      */ 
/*      */             
/* 1042 */             if (buffer.assignParameter(creatorProp, 
/* 1043 */                 _deserializeWithErrorWrapping(p, ctxt, creatorProp))) {
/* 1044 */               Object bean; t = p.nextToken();
/*      */               
/*      */               try {
/* 1047 */                 bean = creator.build(ctxt, buffer);
/* 1048 */               } catch (Exception e) {
/* 1049 */                 wrapAndThrow(e, this._beanType.getRawClass(), propName, ctxt);
/*      */               } 
/*      */               
/* 1052 */               if (bean.getClass() != this._beanType.getRawClass())
/*      */               {
/*      */                 
/* 1055 */                 return ctxt.reportBadDefinition(this._beanType, String.format("Cannot create polymorphic instances with external type ids (%s -> %s)", new Object[] { this._beanType, bean
/*      */                         
/* 1057 */                         .getClass() }));
/*      */               }
/* 1059 */               return _deserializeWithExternalTypeId(p, ctxt, bean, ext);
/*      */             }
/*      */           
/*      */           }
/*      */         } else {
/*      */           
/* 1065 */           SettableBeanProperty prop = this._beanProperties.find(propName);
/* 1066 */           if (prop != null) {
/*      */             
/* 1068 */             if (t.isScalarValue()) {
/* 1069 */               ext.handleTypePropertyValue(p, ctxt, propName, null);
/*      */             }
/*      */             
/* 1072 */             if (activeView != null && !prop.visibleInView(activeView)) {
/* 1073 */               p.skipChildren();
/*      */             } else {
/* 1075 */               buffer.bufferProperty(prop, prop.deserialize(p, ctxt));
/*      */             
/*      */             }
/*      */           
/*      */           }
/* 1080 */           else if (!ext.handlePropertyValue(p, ctxt, propName, null)) {
/*      */ 
/*      */ 
/*      */             
/* 1084 */             if (IgnorePropertiesUtil.shouldIgnore(propName, this._ignorableProps, this._includableProps)) {
/* 1085 */               handleIgnoredProperty(p, ctxt, handledType(), propName);
/*      */ 
/*      */             
/*      */             }
/* 1089 */             else if (this._anySetter != null) {
/* 1090 */               buffer.bufferAnyProperty(this._anySetter, propName, this._anySetter
/* 1091 */                   .deserialize(p, ctxt));
/*      */             }
/*      */             else {
/*      */               
/* 1095 */               handleUnknownProperty(p, ctxt, this._valueClass, propName);
/*      */             } 
/*      */           } 
/*      */         }  } 
/*      */     }  try {
/* 1100 */       return ext.complete(p, ctxt, buffer, creator);
/* 1101 */     } catch (Exception e) {
/* 1102 */       return wrapInstantiationProblem(e, ctxt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Exception _creatorReturnedNullException() {
/* 1113 */     if (this._nullFromCreator == null) {
/* 1114 */       this._nullFromCreator = new NullPointerException("JSON Creator returned null");
/*      */     }
/* 1116 */     return this._nullFromCreator;
/*      */   }
/*      */ 
/*      */   
/*      */   static class BeanReferring
/*      */     extends ReadableObjectId.Referring
/*      */   {
/*      */     private final DeserializationContext _context;
/*      */     
/*      */     private final SettableBeanProperty _prop;
/*      */     
/*      */     private Object _bean;
/*      */ 
/*      */     
/*      */     BeanReferring(DeserializationContext ctxt, UnresolvedForwardReference ref, JavaType valueType, PropertyValueBuffer buffer, SettableBeanProperty prop) {
/* 1131 */       super(ref, valueType);
/* 1132 */       this._context = ctxt;
/* 1133 */       this._prop = prop;
/*      */     }
/*      */     
/*      */     public void setBean(Object bean) {
/* 1137 */       this._bean = bean;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void handleResolvedForwardReference(Object id, Object value) throws IOException {
/* 1143 */       if (this._bean == null) {
/* 1144 */         this._context.reportInputMismatch((BeanProperty)this._prop, "Cannot resolve ObjectId forward reference using property '%s' (of type %s): Bean not yet resolved", new Object[] { this._prop
/*      */               
/* 1146 */               .getName(), this._prop.getDeclaringClass().getName() });
/*      */       }
/* 1148 */       this._prop.set(this._bean, value);
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.12.7.1.jar!\com\fasterxml\jackson\databind\deser\BeanDeserializer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */