package com.fasterxml.jackson.databind.introspect;

public interface WithMember<T> {
  T withMember(AnnotatedMember paramAnnotatedMember);
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.12.7.1.jar!\com\fasterxml\jackson\databind\introspect\WithMember.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */