/*     */ package com.fasterxml.jackson.databind.jsontype.impl;
/*     */ 
/*     */ import com.fasterxml.jackson.databind.AnnotationIntrospector;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*     */ import com.fasterxml.jackson.databind.introspect.Annotated;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedClass;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedClassResolver;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedMember;
/*     */ import com.fasterxml.jackson.databind.jsontype.NamedType;
/*     */ import com.fasterxml.jackson.databind.jsontype.SubtypeResolver;
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class StdSubtypeResolver
/*     */   extends SubtypeResolver implements Serializable {
/*     */   private static final long serialVersionUID = 1L;
/*     */   
/*     */   protected StdSubtypeResolver(StdSubtypeResolver src) {
/*  28 */     LinkedHashSet<NamedType> reg = src._registeredSubtypes;
/*  29 */     this
/*  30 */       ._registeredSubtypes = (reg == null) ? null : new LinkedHashSet<>(reg);
/*     */   }
/*     */   protected LinkedHashSet<NamedType> _registeredSubtypes;
/*     */   public StdSubtypeResolver() {}
/*     */   
/*     */   public SubtypeResolver copy() {
/*  36 */     return new StdSubtypeResolver(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerSubtypes(NamedType... types) {
/*  47 */     if (this._registeredSubtypes == null) {
/*  48 */       this._registeredSubtypes = new LinkedHashSet<>();
/*     */     }
/*  50 */     for (NamedType type : types) {
/*  51 */       this._registeredSubtypes.add(type);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void registerSubtypes(Class<?>... classes) {
/*  57 */     NamedType[] types = new NamedType[classes.length];
/*  58 */     for (int i = 0, len = classes.length; i < len; i++) {
/*  59 */       types[i] = new NamedType(classes[i]);
/*     */     }
/*  61 */     registerSubtypes(types);
/*     */   }
/*     */ 
/*     */   
/*     */   public void registerSubtypes(Collection<Class<?>> subtypes) {
/*  66 */     int len = subtypes.size();
/*  67 */     NamedType[] types = new NamedType[len];
/*  68 */     int i = 0;
/*  69 */     for (Class<?> subtype : subtypes) {
/*  70 */       types[i++] = new NamedType(subtype);
/*     */     }
/*  72 */     registerSubtypes(types);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<NamedType> collectAndResolveSubtypesByClass(MapperConfig<?> config, AnnotatedMember property, JavaType baseType) {
/*  85 */     AnnotationIntrospector ai = config.getAnnotationIntrospector();
/*     */     
/*  87 */     Class<?> rawBase = (baseType == null) ? property.getRawType() : baseType.getRawClass();
/*     */     
/*  89 */     HashMap<NamedType, NamedType> collected = new HashMap<>();
/*     */     
/*  91 */     if (this._registeredSubtypes != null) {
/*  92 */       for (NamedType subtype : this._registeredSubtypes) {
/*     */         
/*  94 */         if (rawBase.isAssignableFrom(subtype.getType())) {
/*  95 */           AnnotatedClass curr = AnnotatedClassResolver.resolveWithoutSuperTypes(config, subtype
/*  96 */               .getType());
/*  97 */           _collectAndResolve(curr, subtype, config, ai, collected);
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 103 */     if (property != null) {
/* 104 */       Collection<NamedType> st = ai.findSubtypes((Annotated)property);
/* 105 */       if (st != null) {
/* 106 */         for (NamedType nt : st) {
/* 107 */           AnnotatedClass annotatedClass = AnnotatedClassResolver.resolveWithoutSuperTypes(config, nt
/* 108 */               .getType());
/* 109 */           _collectAndResolve(annotatedClass, nt, config, ai, collected);
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 114 */     NamedType rootType = new NamedType(rawBase, null);
/* 115 */     AnnotatedClass ac = AnnotatedClassResolver.resolveWithoutSuperTypes(config, rawBase);
/*     */ 
/*     */     
/* 118 */     _collectAndResolve(ac, rootType, config, ai, collected);
/*     */     
/* 120 */     return new ArrayList<>(collected.values());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<NamedType> collectAndResolveSubtypesByClass(MapperConfig<?> config, AnnotatedClass type) {
/* 127 */     AnnotationIntrospector ai = config.getAnnotationIntrospector();
/* 128 */     HashMap<NamedType, NamedType> subtypes = new HashMap<>();
/*     */ 
/*     */     
/* 131 */     if (this._registeredSubtypes != null) {
/* 132 */       Class<?> rawBase = type.getRawType();
/* 133 */       for (NamedType subtype : this._registeredSubtypes) {
/*     */         
/* 135 */         if (rawBase.isAssignableFrom(subtype.getType())) {
/* 136 */           AnnotatedClass curr = AnnotatedClassResolver.resolveWithoutSuperTypes(config, subtype
/* 137 */               .getType());
/* 138 */           _collectAndResolve(curr, subtype, config, ai, subtypes);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 143 */     NamedType rootType = new NamedType(type.getRawType(), null);
/* 144 */     _collectAndResolve(type, rootType, config, ai, subtypes);
/* 145 */     return new ArrayList<>(subtypes.values());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<NamedType> collectAndResolveSubtypesByTypeId(MapperConfig<?> config, AnnotatedMember property, JavaType baseType) {
/* 158 */     AnnotationIntrospector ai = config.getAnnotationIntrospector();
/* 159 */     Class<?> rawBase = baseType.getRawClass();
/*     */ 
/*     */     
/* 162 */     Set<Class<?>> typesHandled = new HashSet<>();
/* 163 */     Map<String, NamedType> byName = new LinkedHashMap<>();
/*     */ 
/*     */     
/* 166 */     NamedType rootType = new NamedType(rawBase, null);
/* 167 */     AnnotatedClass ac = AnnotatedClassResolver.resolveWithoutSuperTypes(config, rawBase);
/*     */     
/* 169 */     _collectAndResolveByTypeId(ac, rootType, config, typesHandled, byName);
/*     */ 
/*     */     
/* 172 */     if (property != null) {
/* 173 */       Collection<NamedType> st = ai.findSubtypes((Annotated)property);
/* 174 */       if (st != null) {
/* 175 */         for (NamedType nt : st) {
/* 176 */           ac = AnnotatedClassResolver.resolveWithoutSuperTypes(config, nt.getType());
/* 177 */           _collectAndResolveByTypeId(ac, nt, config, typesHandled, byName);
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 182 */     if (this._registeredSubtypes != null) {
/* 183 */       for (NamedType subtype : this._registeredSubtypes) {
/*     */         
/* 185 */         if (rawBase.isAssignableFrom(subtype.getType())) {
/* 186 */           AnnotatedClass curr = AnnotatedClassResolver.resolveWithoutSuperTypes(config, subtype
/* 187 */               .getType());
/* 188 */           _collectAndResolveByTypeId(curr, subtype, config, typesHandled, byName);
/*     */         } 
/*     */       } 
/*     */     }
/* 192 */     return _combineNamedAndUnnamed(rawBase, typesHandled, byName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<NamedType> collectAndResolveSubtypesByTypeId(MapperConfig<?> config, AnnotatedClass baseType) {
/* 199 */     Class<?> rawBase = baseType.getRawType();
/* 200 */     Set<Class<?>> typesHandled = new HashSet<>();
/* 201 */     Map<String, NamedType> byName = new LinkedHashMap<>();
/*     */     
/* 203 */     NamedType rootType = new NamedType(rawBase, null);
/* 204 */     _collectAndResolveByTypeId(baseType, rootType, config, typesHandled, byName);
/*     */     
/* 206 */     if (this._registeredSubtypes != null) {
/* 207 */       for (NamedType subtype : this._registeredSubtypes) {
/*     */         
/* 209 */         if (rawBase.isAssignableFrom(subtype.getType())) {
/* 210 */           AnnotatedClass curr = AnnotatedClassResolver.resolveWithoutSuperTypes(config, subtype
/* 211 */               .getType());
/* 212 */           _collectAndResolveByTypeId(curr, subtype, config, typesHandled, byName);
/*     */         } 
/*     */       } 
/*     */     }
/* 216 */     return _combineNamedAndUnnamed(rawBase, typesHandled, byName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _collectAndResolve(AnnotatedClass annotatedType, NamedType namedType, MapperConfig<?> config, AnnotationIntrospector ai, HashMap<NamedType, NamedType> collectedSubtypes) {
/* 233 */     if (!namedType.hasName()) {
/* 234 */       String name = ai.findTypeName(annotatedType);
/* 235 */       if (name != null) {
/* 236 */         namedType = new NamedType(namedType.getType(), name);
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 242 */     NamedType typeOnlyNamedType = new NamedType(namedType.getType());
/*     */ 
/*     */     
/* 245 */     if (collectedSubtypes.containsKey(typeOnlyNamedType)) {
/*     */       
/* 247 */       if (namedType.hasName()) {
/* 248 */         NamedType prev = collectedSubtypes.get(typeOnlyNamedType);
/* 249 */         if (!prev.hasName()) {
/* 250 */           collectedSubtypes.put(typeOnlyNamedType, namedType);
/*     */         }
/*     */       } 
/*     */       
/*     */       return;
/*     */     } 
/* 256 */     collectedSubtypes.put(typeOnlyNamedType, namedType);
/* 257 */     Collection<NamedType> st = ai.findSubtypes((Annotated)annotatedType);
/* 258 */     if (st != null && !st.isEmpty()) {
/* 259 */       for (NamedType subtype : st) {
/* 260 */         AnnotatedClass subtypeClass = AnnotatedClassResolver.resolveWithoutSuperTypes(config, subtype
/* 261 */             .getType());
/* 262 */         _collectAndResolve(subtypeClass, subtype, config, ai, collectedSubtypes);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _collectAndResolveByTypeId(AnnotatedClass annotatedType, NamedType namedType, MapperConfig<?> config, Set<Class<?>> typesHandled, Map<String, NamedType> byName) {
/* 275 */     AnnotationIntrospector ai = config.getAnnotationIntrospector();
/* 276 */     if (!namedType.hasName()) {
/* 277 */       String name = ai.findTypeName(annotatedType);
/* 278 */       if (name != null) {
/* 279 */         namedType = new NamedType(namedType.getType(), name);
/*     */       }
/*     */     } 
/* 282 */     if (namedType.hasName()) {
/* 283 */       byName.put(namedType.getName(), namedType);
/*     */     }
/*     */ 
/*     */     
/* 287 */     if (typesHandled.add(namedType.getType())) {
/* 288 */       Collection<NamedType> st = ai.findSubtypes((Annotated)annotatedType);
/* 289 */       if (st != null && !st.isEmpty()) {
/* 290 */         for (NamedType subtype : st) {
/* 291 */           AnnotatedClass subtypeClass = AnnotatedClassResolver.resolveWithoutSuperTypes(config, subtype
/* 292 */               .getType());
/* 293 */           _collectAndResolveByTypeId(subtypeClass, subtype, config, typesHandled, byName);
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Collection<NamedType> _combineNamedAndUnnamed(Class<?> rawBase, Set<Class<?>> typesHandled, Map<String, NamedType> byName) {
/* 306 */     ArrayList<NamedType> result = new ArrayList<>(byName.values());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 311 */     for (NamedType t : byName.values()) {
/* 312 */       typesHandled.remove(t.getType());
/*     */     }
/* 314 */     for (Class<?> cls : typesHandled) {
/*     */ 
/*     */       
/* 317 */       if (cls == rawBase && Modifier.isAbstract(cls.getModifiers())) {
/*     */         continue;
/*     */       }
/* 320 */       result.add(new NamedType(cls));
/*     */     } 
/* 322 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.12.7.1.jar!\com\fasterxml\jackson\databind\jsontype\impl\StdSubtypeResolver.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */