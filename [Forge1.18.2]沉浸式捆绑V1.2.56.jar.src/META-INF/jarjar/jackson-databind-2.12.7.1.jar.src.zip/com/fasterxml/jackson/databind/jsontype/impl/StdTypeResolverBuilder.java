/*     */ package com.fasterxml.jackson.databind.jsontype.impl;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonTypeInfo;
/*     */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.MapperFeature;
/*     */ import com.fasterxml.jackson.databind.SerializationConfig;
/*     */ import com.fasterxml.jackson.databind.annotation.NoClass;
/*     */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*     */ import com.fasterxml.jackson.databind.jsontype.NamedType;
/*     */ import com.fasterxml.jackson.databind.jsontype.PolymorphicTypeValidator;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeIdResolver;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeResolverBuilder;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import java.util.Collection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StdTypeResolverBuilder
/*     */   implements TypeResolverBuilder<StdTypeResolverBuilder>
/*     */ {
/*     */   protected JsonTypeInfo.Id _idType;
/*     */   protected JsonTypeInfo.As _includeAs;
/*     */   protected String _typeProperty;
/*     */   protected boolean _typeIdVisible = false;
/*     */   protected Class<?> _defaultImpl;
/*     */   protected TypeIdResolver _customIdResolver;
/*     */   
/*     */   protected StdTypeResolverBuilder(JsonTypeInfo.Id idType, JsonTypeInfo.As idAs, String propName) {
/*  58 */     this._idType = idType;
/*  59 */     this._includeAs = idAs;
/*  60 */     this._typeProperty = propName;
/*     */   }
/*     */   
/*     */   public static StdTypeResolverBuilder noTypeInfoBuilder() {
/*  64 */     return (new StdTypeResolverBuilder()).init(JsonTypeInfo.Id.NONE, (TypeIdResolver)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StdTypeResolverBuilder init(JsonTypeInfo.Id idType, TypeIdResolver idRes) {
/*  71 */     if (idType == null) {
/*  72 */       throw new IllegalArgumentException("idType cannot be null");
/*     */     }
/*  74 */     this._idType = idType;
/*  75 */     this._customIdResolver = idRes;
/*     */     
/*  77 */     this._typeProperty = idType.getDefaultPropertyName();
/*  78 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeSerializer buildTypeSerializer(SerializationConfig config, JavaType baseType, Collection<NamedType> subtypes) {
/*  85 */     if (this._idType == JsonTypeInfo.Id.NONE) return null;
/*     */ 
/*     */     
/*  88 */     if (baseType.isPrimitive())
/*     */     {
/*  90 */       if (!allowPrimitiveTypes((MapperConfig<?>)config, baseType)) {
/*  91 */         return null;
/*     */       }
/*     */     }
/*     */     
/*  95 */     TypeIdResolver idRes = idResolver((MapperConfig<?>)config, baseType, subTypeValidator((MapperConfig<?>)config), subtypes, true, false);
/*     */ 
/*     */     
/*  98 */     if (this._idType == JsonTypeInfo.Id.DEDUCTION)
/*     */     {
/* 100 */       return new AsExistingPropertyTypeSerializer(idRes, null, this._typeProperty);
/*     */     }
/*     */     
/* 103 */     switch (this._includeAs) {
/*     */       case DEDUCTION:
/* 105 */         return new AsArrayTypeSerializer(idRes, null);
/*     */       case CLASS:
/* 107 */         return new AsPropertyTypeSerializer(idRes, null, this._typeProperty);
/*     */       case MINIMAL_CLASS:
/* 109 */         return new AsWrapperTypeSerializer(idRes, null);
/*     */       case NAME:
/* 111 */         return new AsExternalTypeSerializer(idRes, null, this._typeProperty);
/*     */       
/*     */       case NONE:
/* 114 */         return new AsExistingPropertyTypeSerializer(idRes, null, this._typeProperty);
/*     */     } 
/* 116 */     throw new IllegalStateException("Do not know how to construct standard type serializer for inclusion type: " + this._includeAs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeDeserializer buildTypeDeserializer(DeserializationConfig config, JavaType baseType, Collection<NamedType> subtypes) {
/* 129 */     if (this._idType == JsonTypeInfo.Id.NONE) return null;
/*     */ 
/*     */     
/* 132 */     if (baseType.isPrimitive())
/*     */     {
/* 134 */       if (!allowPrimitiveTypes((MapperConfig<?>)config, baseType)) {
/* 135 */         return null;
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 141 */     PolymorphicTypeValidator subTypeValidator = verifyBaseTypeValidity((MapperConfig<?>)config, baseType);
/*     */     
/* 143 */     TypeIdResolver idRes = idResolver((MapperConfig<?>)config, baseType, subTypeValidator, subtypes, false, true);
/*     */     
/* 145 */     JavaType defaultImpl = defineDefaultImpl(config, baseType);
/*     */     
/* 147 */     if (this._idType == JsonTypeInfo.Id.DEDUCTION)
/*     */     {
/* 149 */       return new AsDeductionTypeDeserializer(baseType, idRes, defaultImpl, config, subtypes);
/*     */     }
/*     */ 
/*     */     
/* 153 */     switch (this._includeAs) {
/*     */       case DEDUCTION:
/* 155 */         return new AsArrayTypeDeserializer(baseType, idRes, this._typeProperty, this._typeIdVisible, defaultImpl);
/*     */       
/*     */       case CLASS:
/*     */       case NONE:
/* 159 */         return new AsPropertyTypeDeserializer(baseType, idRes, this._typeProperty, this._typeIdVisible, defaultImpl, this._includeAs);
/*     */       
/*     */       case MINIMAL_CLASS:
/* 162 */         return new AsWrapperTypeDeserializer(baseType, idRes, this._typeProperty, this._typeIdVisible, defaultImpl);
/*     */       
/*     */       case NAME:
/* 165 */         return new AsExternalTypeDeserializer(baseType, idRes, this._typeProperty, this._typeIdVisible, defaultImpl);
/*     */     } 
/*     */     
/* 168 */     throw new IllegalStateException("Do not know how to construct standard type serializer for inclusion type: " + this._includeAs);
/*     */   }
/*     */   
/*     */   protected JavaType defineDefaultImpl(DeserializationConfig config, JavaType baseType) {
/*     */     JavaType defaultImpl;
/* 173 */     if (this._defaultImpl == null) {
/* 174 */       if (config.isEnabled(MapperFeature.USE_BASE_TYPE_AS_DEFAULT_IMPL) && !baseType.isAbstract()) {
/* 175 */         defaultImpl = baseType;
/*     */       } else {
/* 177 */         defaultImpl = null;
/*     */ 
/*     */ 
/*     */       
/*     */       }
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 186 */     else if (this._defaultImpl == Void.class || this._defaultImpl == NoClass.class) {
/*     */       
/* 188 */       defaultImpl = config.getTypeFactory().constructType(this._defaultImpl);
/*     */     }
/* 190 */     else if (baseType.hasRawClass(this._defaultImpl)) {
/* 191 */       defaultImpl = baseType;
/* 192 */     } else if (baseType.isTypeOrSuperTypeOf(this._defaultImpl)) {
/*     */ 
/*     */       
/* 195 */       defaultImpl = config.getTypeFactory().constructSpecializedType(baseType, this._defaultImpl);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 207 */       defaultImpl = null;
/*     */     } 
/*     */ 
/*     */     
/* 211 */     return defaultImpl;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StdTypeResolverBuilder inclusion(JsonTypeInfo.As includeAs) {
/* 222 */     if (includeAs == null) {
/* 223 */       throw new IllegalArgumentException("includeAs cannot be null");
/*     */     }
/* 225 */     this._includeAs = includeAs;
/* 226 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StdTypeResolverBuilder typeProperty(String typeIdPropName) {
/* 236 */     if (typeIdPropName == null || typeIdPropName.isEmpty()) {
/* 237 */       typeIdPropName = this._idType.getDefaultPropertyName();
/*     */     }
/* 239 */     this._typeProperty = typeIdPropName;
/* 240 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public StdTypeResolverBuilder defaultImpl(Class<?> defaultImpl) {
/* 245 */     this._defaultImpl = defaultImpl;
/* 246 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public StdTypeResolverBuilder typeIdVisibility(boolean isVisible) {
/* 251 */     this._typeIdVisible = isVisible;
/* 252 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> getDefaultImpl() {
/* 261 */     return this._defaultImpl;
/*     */   }
/* 263 */   public String getTypeProperty() { return this._typeProperty; } public boolean isTypeIdVisible() {
/* 264 */     return this._typeIdVisible;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TypeIdResolver idResolver(MapperConfig<?> config, JavaType baseType, PolymorphicTypeValidator subtypeValidator, Collection<NamedType> subtypes, boolean forSer, boolean forDeser) {
/* 282 */     if (this._customIdResolver != null) return this._customIdResolver; 
/* 283 */     if (this._idType == null) throw new IllegalStateException("Cannot build, 'init()' not yet called"); 
/* 284 */     switch (this._idType) {
/*     */       case DEDUCTION:
/*     */       case CLASS:
/* 287 */         return ClassNameIdResolver.construct(baseType, config, subtypeValidator);
/*     */       case MINIMAL_CLASS:
/* 289 */         return MinimalClassNameIdResolver.construct(baseType, config, subtypeValidator);
/*     */       case NAME:
/* 291 */         return TypeNameIdResolver.construct(config, baseType, subtypes, forSer, forDeser);
/*     */       case NONE:
/* 293 */         return null;
/*     */     } 
/*     */     
/* 296 */     throw new IllegalStateException("Do not know how to construct standard type id resolver for idType: " + this._idType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PolymorphicTypeValidator subTypeValidator(MapperConfig<?> config) {
/* 315 */     return config.getPolymorphicTypeValidator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected PolymorphicTypeValidator verifyBaseTypeValidity(MapperConfig<?> config, JavaType baseType) {
/* 328 */     PolymorphicTypeValidator ptv = subTypeValidator(config);
/* 329 */     if (this._idType == JsonTypeInfo.Id.CLASS || this._idType == JsonTypeInfo.Id.MINIMAL_CLASS) {
/* 330 */       PolymorphicTypeValidator.Validity validity = ptv.validateBaseType(config, baseType);
/*     */       
/* 332 */       if (validity == PolymorphicTypeValidator.Validity.DENIED) {
/* 333 */         return reportInvalidBaseType(config, baseType, ptv);
/*     */       }
/*     */       
/* 336 */       if (validity == PolymorphicTypeValidator.Validity.ALLOWED) {
/* 337 */         return (PolymorphicTypeValidator)LaissezFaireSubTypeValidator.instance;
/*     */       }
/*     */     } 
/*     */     
/* 341 */     return ptv;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected PolymorphicTypeValidator reportInvalidBaseType(MapperConfig<?> config, JavaType baseType, PolymorphicTypeValidator ptv) {
/* 350 */     throw new IllegalArgumentException(String.format("Configured `PolymorphicTypeValidator` (of type %s) denied resolution of all subtypes of base type %s", new Object[] {
/*     */             
/* 352 */             ClassUtil.classNameOf(ptv), ClassUtil.classNameOf(baseType.getRawClass())
/*     */           }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean allowPrimitiveTypes(MapperConfig<?> config, JavaType baseType) {
/* 380 */     return false;
/*     */   }
/*     */   
/*     */   public StdTypeResolverBuilder() {}
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.12.7.1.jar!\com\fasterxml\jackson\databind\jsontype\impl\StdTypeResolverBuilder.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */