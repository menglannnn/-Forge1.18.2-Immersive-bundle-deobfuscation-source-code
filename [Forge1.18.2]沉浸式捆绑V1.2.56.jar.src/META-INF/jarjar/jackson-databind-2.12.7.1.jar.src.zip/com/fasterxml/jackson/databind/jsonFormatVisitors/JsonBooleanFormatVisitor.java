package com.fasterxml.jackson.databind.jsonFormatVisitors;

public interface JsonBooleanFormatVisitor extends JsonValueFormatVisitor {
  public static class Base extends JsonValueFormatVisitor.Base implements JsonBooleanFormatVisitor {}
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.12.7.1.jar!\com\fasterxml\jackson\databind\jsonFormatVisitors\JsonBooleanFormatVisitor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */