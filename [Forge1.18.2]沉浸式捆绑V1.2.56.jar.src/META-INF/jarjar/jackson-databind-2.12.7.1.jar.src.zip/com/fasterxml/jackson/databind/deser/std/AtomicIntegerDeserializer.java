/*    */ package com.fasterxml.jackson.databind.deser.std;
/*    */ 
/*    */ import com.fasterxml.jackson.core.JsonParser;
/*    */ import com.fasterxml.jackson.core.JsonProcessingException;
/*    */ import com.fasterxml.jackson.databind.DeserializationContext;
/*    */ import com.fasterxml.jackson.databind.JsonMappingException;
/*    */ import com.fasterxml.jackson.databind.type.LogicalType;
/*    */ import java.io.IOException;
/*    */ import java.util.concurrent.atomic.AtomicInteger;
/*    */ 
/*    */ public class AtomicIntegerDeserializer
/*    */   extends StdScalarDeserializer<AtomicInteger>
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public AtomicIntegerDeserializer() {
/* 17 */     super(AtomicInteger.class);
/*    */   }
/*    */   
/*    */   public AtomicInteger deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 21 */     if (p.isExpectedNumberIntToken()) {
/* 22 */       return new AtomicInteger(p.getIntValue());
/*    */     }
/*    */ 
/*    */     
/* 26 */     Integer I = _parseInteger(p, ctxt, AtomicInteger.class);
/* 27 */     return (I == null) ? null : new AtomicInteger(I.intValue());
/*    */   }
/*    */   
/*    */   public LogicalType logicalType() {
/* 31 */     return LogicalType.Integer;
/*    */   }
/*    */   
/*    */   public Object getEmptyValue(DeserializationContext ctxt) throws JsonMappingException {
/* 35 */     return new AtomicInteger();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.12.7.1.jar!\com\fasterxml\jackson\databind\deser\std\AtomicIntegerDeserializer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */