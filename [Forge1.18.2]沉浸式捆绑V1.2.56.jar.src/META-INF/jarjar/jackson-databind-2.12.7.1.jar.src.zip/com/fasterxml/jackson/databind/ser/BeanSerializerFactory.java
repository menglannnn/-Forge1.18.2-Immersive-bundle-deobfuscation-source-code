/*     */ package com.fasterxml.jackson.databind.ser;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
/*     */ import com.fasterxml.jackson.annotation.JsonIncludeProperties;
/*     */ import com.fasterxml.jackson.annotation.JsonTypeInfo;
/*     */ import com.fasterxml.jackson.annotation.ObjectIdGenerator;
/*     */ import com.fasterxml.jackson.annotation.ObjectIdGenerators;
/*     */ import com.fasterxml.jackson.databind.AnnotationIntrospector;
/*     */ import com.fasterxml.jackson.databind.BeanDescription;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.JsonSerializer;
/*     */ import com.fasterxml.jackson.databind.MapperFeature;
/*     */ import com.fasterxml.jackson.databind.PropertyMetadata;
/*     */ import com.fasterxml.jackson.databind.PropertyName;
/*     */ import com.fasterxml.jackson.databind.SerializationConfig;
/*     */ import com.fasterxml.jackson.databind.SerializerProvider;
/*     */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*     */ import com.fasterxml.jackson.databind.cfg.SerializerFactoryConfig;
/*     */ import com.fasterxml.jackson.databind.introspect.Annotated;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedClass;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedMember;
/*     */ import com.fasterxml.jackson.databind.introspect.BeanPropertyDefinition;
/*     */ import com.fasterxml.jackson.databind.introspect.ObjectIdInfo;
/*     */ import com.fasterxml.jackson.databind.jsontype.NamedType;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeResolverBuilder;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*     */ import com.fasterxml.jackson.databind.ser.impl.FilteredBeanPropertyWriter;
/*     */ import com.fasterxml.jackson.databind.ser.impl.ObjectIdWriter;
/*     */ import com.fasterxml.jackson.databind.ser.impl.PropertyBasedObjectIdGenerator;
/*     */ import com.fasterxml.jackson.databind.ser.impl.UnsupportedTypeSerializer;
/*     */ import com.fasterxml.jackson.databind.ser.std.MapSerializer;
/*     */ import com.fasterxml.jackson.databind.ser.std.StdDelegatingSerializer;
/*     */ import com.fasterxml.jackson.databind.type.ReferenceType;
/*     */ import com.fasterxml.jackson.databind.util.BeanUtil;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import com.fasterxml.jackson.databind.util.Converter;
/*     */ import com.fasterxml.jackson.databind.util.IgnorePropertiesUtil;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BeanSerializerFactory
/*     */   extends BasicSerializerFactory
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  68 */   public static final BeanSerializerFactory instance = new BeanSerializerFactory(null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BeanSerializerFactory(SerializerFactoryConfig config) {
/*  81 */     super(config);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SerializerFactory withConfig(SerializerFactoryConfig config) {
/*  93 */     if (this._factoryConfig == config) {
/*  94 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 102 */     if (getClass() != BeanSerializerFactory.class) {
/* 103 */       throw new IllegalStateException("Subtype of BeanSerializerFactory (" + getClass().getName() + ") has not properly overridden method 'withAdditionalSerializers': cannot instantiate subtype with additional serializer definitions");
/*     */     }
/*     */ 
/*     */     
/* 107 */     return new BeanSerializerFactory(config);
/*     */   }
/*     */ 
/*     */   
/*     */   protected Iterable<Serializers> customSerializers() {
/* 112 */     return this._factoryConfig.serializers();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonSerializer<Object> createSerializer(SerializerProvider prov, JavaType origType) throws JsonMappingException {
/*     */     boolean staticTyping;
/*     */     JavaType type;
/* 138 */     SerializationConfig config = prov.getConfig();
/* 139 */     BeanDescription beanDesc = config.introspect(origType);
/* 140 */     JsonSerializer<?> ser = findSerializerFromAnnotation(prov, (Annotated)beanDesc.getClassInfo());
/* 141 */     if (ser != null) {
/* 142 */       return (JsonSerializer)ser;
/*     */     }
/*     */ 
/*     */     
/* 146 */     AnnotationIntrospector intr = config.getAnnotationIntrospector();
/*     */ 
/*     */     
/* 149 */     if (intr == null) {
/* 150 */       type = origType;
/*     */     } else {
/*     */       try {
/* 153 */         type = intr.refineSerializationType((MapperConfig)config, (Annotated)beanDesc.getClassInfo(), origType);
/* 154 */       } catch (JsonMappingException e) {
/* 155 */         return (JsonSerializer<Object>)prov.reportBadTypeDefinition(beanDesc, e.getMessage(), new Object[0]);
/*     */       } 
/*     */     } 
/* 158 */     if (type == origType) {
/* 159 */       staticTyping = false;
/*     */     } else {
/* 161 */       staticTyping = true;
/* 162 */       if (!type.hasRawClass(origType.getRawClass())) {
/* 163 */         beanDesc = config.introspect(type);
/*     */       }
/*     */     } 
/*     */     
/* 167 */     Converter<Object, Object> conv = beanDesc.findSerializationConverter();
/* 168 */     if (conv == null) {
/* 169 */       return (JsonSerializer)_createSerializer2(prov, type, beanDesc, staticTyping);
/*     */     }
/* 171 */     JavaType delegateType = conv.getOutputType(prov.getTypeFactory());
/*     */ 
/*     */     
/* 174 */     if (!delegateType.hasRawClass(type.getRawClass())) {
/* 175 */       beanDesc = config.introspect(delegateType);
/*     */       
/* 177 */       ser = findSerializerFromAnnotation(prov, (Annotated)beanDesc.getClassInfo());
/*     */     } 
/*     */     
/* 180 */     if (ser == null && !delegateType.isJavaLangObject()) {
/* 181 */       ser = _createSerializer2(prov, delegateType, beanDesc, true);
/*     */     }
/* 183 */     return (JsonSerializer<Object>)new StdDelegatingSerializer(conv, delegateType, ser);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonSerializer<?> _createSerializer2(SerializerProvider prov, JavaType type, BeanDescription beanDesc, boolean staticTyping) throws JsonMappingException {
/* 190 */     JsonSerializer<?> ser = null;
/* 191 */     SerializationConfig config = prov.getConfig();
/*     */ 
/*     */ 
/*     */     
/* 195 */     if (type.isContainerType()) {
/* 196 */       if (!staticTyping) {
/* 197 */         staticTyping = usesStaticTyping(config, beanDesc, null);
/*     */       }
/*     */       
/* 200 */       ser = buildContainerSerializer(prov, type, beanDesc, staticTyping);
/*     */       
/* 202 */       if (ser != null) {
/* 203 */         return ser;
/*     */       }
/*     */     } else {
/* 206 */       if (type.isReferenceType()) {
/* 207 */         ser = findReferenceSerializer(prov, (ReferenceType)type, beanDesc, staticTyping);
/*     */       } else {
/*     */         
/* 210 */         for (Serializers serializers : customSerializers()) {
/* 211 */           ser = serializers.findSerializer(config, type, beanDesc);
/* 212 */           if (ser != null) {
/*     */             break;
/*     */           }
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 219 */       if (ser == null) {
/* 220 */         ser = findSerializerByAnnotations(prov, type, beanDesc);
/*     */       }
/*     */     } 
/*     */     
/* 224 */     if (ser == null) {
/*     */ 
/*     */ 
/*     */       
/* 228 */       ser = findSerializerByLookup(type, config, beanDesc, staticTyping);
/* 229 */       if (ser == null) {
/* 230 */         ser = findSerializerByPrimaryType(prov, type, beanDesc, staticTyping);
/* 231 */         if (ser == null) {
/*     */ 
/*     */ 
/*     */           
/* 235 */           ser = findBeanOrAddOnSerializer(prov, type, beanDesc, staticTyping);
/*     */ 
/*     */ 
/*     */           
/* 239 */           if (ser == null) {
/* 240 */             ser = prov.getUnknownTypeSerializer(beanDesc.getBeanClass());
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 245 */     if (ser != null)
/*     */     {
/* 247 */       if (this._factoryConfig.hasSerializerModifiers()) {
/* 248 */         for (BeanSerializerModifier mod : this._factoryConfig.serializerModifiers()) {
/* 249 */           ser = mod.modifySerializer(config, beanDesc, ser);
/*     */         }
/*     */       }
/*     */     }
/* 253 */     return ser;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public JsonSerializer<Object> findBeanSerializer(SerializerProvider prov, JavaType type, BeanDescription beanDesc) throws JsonMappingException {
/* 268 */     return findBeanOrAddOnSerializer(prov, type, beanDesc, prov.isEnabled(MapperFeature.USE_STATIC_TYPING));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonSerializer<Object> findBeanOrAddOnSerializer(SerializerProvider prov, JavaType type, BeanDescription beanDesc, boolean staticTyping) throws JsonMappingException {
/* 283 */     if (!isPotentialBeanType(type.getRawClass()))
/*     */     {
/*     */       
/* 286 */       if (!ClassUtil.isEnumType(type.getRawClass())) {
/* 287 */         return null;
/*     */       }
/*     */     }
/* 290 */     return constructBeanOrAddOnSerializer(prov, type, beanDesc, staticTyping);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeSerializer findPropertyTypeSerializer(JavaType baseType, SerializationConfig config, AnnotatedMember accessor) throws JsonMappingException {
/*     */     TypeSerializer typeSer;
/* 307 */     AnnotationIntrospector ai = config.getAnnotationIntrospector();
/* 308 */     TypeResolverBuilder<?> b = ai.findPropertyTypeResolver((MapperConfig)config, accessor, baseType);
/*     */ 
/*     */ 
/*     */     
/* 312 */     if (b == null) {
/* 313 */       typeSer = createTypeSerializer(config, baseType);
/*     */     } else {
/* 315 */       Collection<NamedType> subtypes = config.getSubtypeResolver().collectAndResolveSubtypesByClass((MapperConfig)config, accessor, baseType);
/*     */       
/* 317 */       typeSer = b.buildTypeSerializer(config, baseType, subtypes);
/*     */     } 
/* 319 */     return typeSer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeSerializer findPropertyContentTypeSerializer(JavaType containerType, SerializationConfig config, AnnotatedMember accessor) throws JsonMappingException {
/*     */     TypeSerializer typeSer;
/* 336 */     JavaType contentType = containerType.getContentType();
/* 337 */     AnnotationIntrospector ai = config.getAnnotationIntrospector();
/* 338 */     TypeResolverBuilder<?> b = ai.findPropertyContentTypeResolver((MapperConfig)config, accessor, containerType);
/*     */ 
/*     */ 
/*     */     
/* 342 */     if (b == null) {
/* 343 */       typeSer = createTypeSerializer(config, contentType);
/*     */     } else {
/* 345 */       Collection<NamedType> subtypes = config.getSubtypeResolver().collectAndResolveSubtypesByClass((MapperConfig)config, accessor, contentType);
/*     */       
/* 347 */       typeSer = b.buildTypeSerializer(config, contentType, subtypes);
/*     */     } 
/* 349 */     return typeSer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected JsonSerializer<Object> constructBeanSerializer(SerializerProvider prov, BeanDescription beanDesc) throws JsonMappingException {
/* 363 */     return constructBeanOrAddOnSerializer(prov, beanDesc.getType(), beanDesc, prov.isEnabled(MapperFeature.USE_STATIC_TYPING));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonSerializer<Object> constructBeanOrAddOnSerializer(SerializerProvider prov, JavaType type, BeanDescription beanDesc, boolean staticTyping) throws JsonMappingException {
/* 379 */     if (beanDesc.getBeanClass() == Object.class) {
/* 380 */       return prov.getUnknownTypeSerializer(Object.class);
/*     */     }
/*     */ 
/*     */     
/* 384 */     JsonSerializer<?> ser = _findUnsupportedTypeSerializer(prov, type, beanDesc);
/* 385 */     if (ser != null) {
/* 386 */       return (JsonSerializer)ser;
/*     */     }
/*     */     
/* 389 */     SerializationConfig config = prov.getConfig();
/* 390 */     BeanSerializerBuilder builder = constructBeanSerializerBuilder(beanDesc);
/* 391 */     builder.setConfig(config);
/*     */ 
/*     */     
/* 394 */     List<BeanPropertyWriter> props = findBeanProperties(prov, beanDesc, builder);
/* 395 */     if (props == null) {
/* 396 */       props = new ArrayList<>();
/*     */     } else {
/* 398 */       props = removeOverlappingTypeIds(prov, beanDesc, builder, props);
/*     */     } 
/*     */ 
/*     */     
/* 402 */     prov.getAnnotationIntrospector().findAndAddVirtualProperties((MapperConfig)config, beanDesc.getClassInfo(), props);
/*     */ 
/*     */     
/* 405 */     if (this._factoryConfig.hasSerializerModifiers()) {
/* 406 */       for (BeanSerializerModifier mod : this._factoryConfig.serializerModifiers()) {
/* 407 */         props = mod.changeProperties(config, beanDesc, props);
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 415 */     props = filterUnwantedJDKProperties(config, beanDesc, props);
/* 416 */     props = filterBeanProperties(config, beanDesc, props);
/*     */ 
/*     */     
/* 419 */     if (this._factoryConfig.hasSerializerModifiers()) {
/* 420 */       for (BeanSerializerModifier mod : this._factoryConfig.serializerModifiers()) {
/* 421 */         props = mod.orderProperties(config, beanDesc, props);
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 428 */     builder.setObjectIdWriter(constructObjectIdHandler(prov, beanDesc, props));
/*     */     
/* 430 */     builder.setProperties(props);
/* 431 */     builder.setFilterId(findFilterId(config, beanDesc));
/*     */     
/* 433 */     AnnotatedMember anyGetter = beanDesc.findAnyGetter();
/* 434 */     if (anyGetter != null) {
/* 435 */       MapSerializer mapSerializer; JavaType anyType = anyGetter.getType();
/*     */       
/* 437 */       JavaType valueType = anyType.getContentType();
/* 438 */       TypeSerializer typeSer = createTypeSerializer(config, valueType);
/*     */ 
/*     */       
/* 441 */       JsonSerializer<?> anySer = findSerializerFromAnnotation(prov, (Annotated)anyGetter);
/* 442 */       if (anySer == null)
/*     */       {
/* 444 */         mapSerializer = MapSerializer.construct((Set)null, anyType, config
/* 445 */             .isEnabled(MapperFeature.USE_STATIC_TYPING), typeSer, null, null, null);
/*     */       }
/*     */ 
/*     */       
/* 449 */       PropertyName name = PropertyName.construct(anyGetter.getName());
/* 450 */       BeanProperty.Std anyProp = new BeanProperty.Std(name, valueType, null, anyGetter, PropertyMetadata.STD_OPTIONAL);
/*     */       
/* 452 */       builder.setAnyGetter(new AnyGetterWriter((BeanProperty)anyProp, anyGetter, (JsonSerializer<?>)mapSerializer));
/*     */     } 
/*     */     
/* 455 */     processViews(config, builder);
/*     */ 
/*     */     
/* 458 */     if (this._factoryConfig.hasSerializerModifiers()) {
/* 459 */       for (BeanSerializerModifier mod : this._factoryConfig.serializerModifiers()) {
/* 460 */         builder = mod.updateBuilder(config, beanDesc, builder);
/*     */       }
/*     */     }
/*     */     
/*     */     try {
/* 465 */       ser = builder.build();
/* 466 */     } catch (RuntimeException e) {
/* 467 */       return (JsonSerializer<Object>)prov.reportBadTypeDefinition(beanDesc, "Failed to construct BeanSerializer for %s: (%s) %s", new Object[] { beanDesc
/* 468 */             .getType(), e.getClass().getName(), e.getMessage() });
/*     */     } 
/* 470 */     if (ser == null) {
/*     */       
/* 472 */       if (type.isRecordType()) {
/* 473 */         return (JsonSerializer<Object>)builder.createDummy();
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 478 */       ser = findSerializerByAddonType(config, type, beanDesc, staticTyping);
/* 479 */       if (ser == null)
/*     */       {
/*     */ 
/*     */         
/* 483 */         if (beanDesc.hasKnownClassAnnotations()) {
/* 484 */           return (JsonSerializer<Object>)builder.createDummy();
/*     */         }
/*     */       }
/*     */     } 
/* 488 */     return (JsonSerializer)ser;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ObjectIdWriter constructObjectIdHandler(SerializerProvider prov, BeanDescription beanDesc, List<BeanPropertyWriter> props) throws JsonMappingException {
/* 495 */     ObjectIdInfo objectIdInfo = beanDesc.getObjectIdInfo();
/* 496 */     if (objectIdInfo == null) {
/* 497 */       return null;
/*     */     }
/*     */     
/* 500 */     Class<?> implClass = objectIdInfo.getGeneratorType();
/*     */ 
/*     */     
/* 503 */     if (implClass == ObjectIdGenerators.PropertyGenerator.class) {
/* 504 */       String propName = objectIdInfo.getPropertyName().getSimpleName();
/* 505 */       BeanPropertyWriter idProp = null;
/*     */       
/* 507 */       for (int i = 0, len = props.size();; i++) {
/* 508 */         if (i == len)
/* 509 */           throw new IllegalArgumentException(String.format("Invalid Object Id definition for %s: cannot find property with name %s", new Object[] {
/*     */                   
/* 511 */                   ClassUtil.getTypeDescription(beanDesc.getType()), ClassUtil.name(propName)
/*     */                 })); 
/* 513 */         BeanPropertyWriter prop = props.get(i);
/* 514 */         if (propName.equals(prop.getName())) {
/* 515 */           idProp = prop;
/*     */ 
/*     */           
/* 518 */           if (i > 0) {
/* 519 */             props.remove(i);
/* 520 */             props.add(0, idProp);
/*     */           } 
/*     */           break;
/*     */         } 
/*     */       } 
/* 525 */       JavaType javaType = idProp.getType();
/* 526 */       PropertyBasedObjectIdGenerator propertyBasedObjectIdGenerator = new PropertyBasedObjectIdGenerator(objectIdInfo, idProp);
/*     */       
/* 528 */       return ObjectIdWriter.construct(javaType, (PropertyName)null, (ObjectIdGenerator)propertyBasedObjectIdGenerator, objectIdInfo.getAlwaysAsId());
/*     */     } 
/*     */ 
/*     */     
/* 532 */     JavaType type = prov.constructType(implClass);
/*     */     
/* 534 */     JavaType idType = prov.getTypeFactory().findTypeParameters(type, ObjectIdGenerator.class)[0];
/* 535 */     ObjectIdGenerator<?> gen = prov.objectIdGeneratorInstance((Annotated)beanDesc.getClassInfo(), objectIdInfo);
/* 536 */     return ObjectIdWriter.construct(idType, objectIdInfo.getPropertyName(), gen, objectIdInfo
/* 537 */         .getAlwaysAsId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BeanPropertyWriter constructFilteredBeanWriter(BeanPropertyWriter writer, Class<?>[] inViews) {
/* 548 */     return FilteredBeanPropertyWriter.constructViewBased(writer, inViews);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected PropertyBuilder constructPropertyBuilder(SerializationConfig config, BeanDescription beanDesc) {
/* 554 */     return new PropertyBuilder(config, beanDesc);
/*     */   }
/*     */   
/*     */   protected BeanSerializerBuilder constructBeanSerializerBuilder(BeanDescription beanDesc) {
/* 558 */     return new BeanSerializerBuilder(beanDesc);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isPotentialBeanType(Class<?> type) {
/* 577 */     return (ClassUtil.canBeABeanType(type) == null && !ClassUtil.isProxyType(type));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<BeanPropertyWriter> findBeanProperties(SerializerProvider prov, BeanDescription beanDesc, BeanSerializerBuilder builder) throws JsonMappingException {
/* 588 */     List<BeanPropertyDefinition> properties = beanDesc.findProperties();
/* 589 */     SerializationConfig config = prov.getConfig();
/*     */ 
/*     */     
/* 592 */     removeIgnorableTypes(config, beanDesc, properties);
/*     */ 
/*     */     
/* 595 */     if (config.isEnabled(MapperFeature.REQUIRE_SETTERS_FOR_GETTERS)) {
/* 596 */       removeSetterlessGetters(config, beanDesc, properties);
/*     */     }
/*     */ 
/*     */     
/* 600 */     if (properties.isEmpty()) {
/* 601 */       return null;
/*     */     }
/*     */     
/* 604 */     boolean staticTyping = usesStaticTyping(config, beanDesc, null);
/* 605 */     PropertyBuilder pb = constructPropertyBuilder(config, beanDesc);
/*     */     
/* 607 */     ArrayList<BeanPropertyWriter> result = new ArrayList<>(properties.size());
/* 608 */     for (BeanPropertyDefinition property : properties) {
/* 609 */       AnnotatedMember accessor = property.getAccessor();
/*     */       
/* 611 */       if (property.isTypeId()) {
/* 612 */         if (accessor != null) {
/* 613 */           builder.setTypeId(accessor);
/*     */         }
/*     */         
/*     */         continue;
/*     */       } 
/* 618 */       AnnotationIntrospector.ReferenceProperty refType = property.findReferenceType();
/* 619 */       if (refType != null && refType.isBackReference()) {
/*     */         continue;
/*     */       }
/* 622 */       if (accessor instanceof com.fasterxml.jackson.databind.introspect.AnnotatedMethod) {
/* 623 */         result.add(_constructWriter(prov, property, pb, staticTyping, accessor)); continue;
/*     */       } 
/* 625 */       result.add(_constructWriter(prov, property, pb, staticTyping, accessor));
/*     */     } 
/*     */     
/* 628 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<BeanPropertyWriter> filterBeanProperties(SerializationConfig config, BeanDescription beanDesc, List<BeanPropertyWriter> props) {
/* 648 */     JsonIgnoreProperties.Value ignorals = config.getDefaultPropertyIgnorals(beanDesc.getBeanClass(), beanDesc
/* 649 */         .getClassInfo());
/* 650 */     Set<String> ignored = null;
/* 651 */     if (ignorals != null) {
/* 652 */       ignored = ignorals.findIgnoredForSerialization();
/*     */     }
/* 654 */     JsonIncludeProperties.Value inclusions = config.getDefaultPropertyInclusions(beanDesc.getBeanClass(), beanDesc
/* 655 */         .getClassInfo());
/* 656 */     Set<String> included = null;
/* 657 */     if (inclusions != null) {
/* 658 */       included = inclusions.getIncluded();
/*     */     }
/* 660 */     if (included != null || (ignored != null && !ignored.isEmpty())) {
/* 661 */       Iterator<BeanPropertyWriter> it = props.iterator();
/* 662 */       while (it.hasNext()) {
/* 663 */         if (IgnorePropertiesUtil.shouldIgnore(((BeanPropertyWriter)it.next()).getName(), ignored, included)) {
/* 664 */           it.remove();
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 669 */     return props;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<BeanPropertyWriter> filterUnwantedJDKProperties(SerializationConfig config, BeanDescription beanDesc, List<BeanPropertyWriter> props) {
/* 685 */     if (beanDesc.getType().isTypeOrSubTypeOf(CharSequence.class)) {
/* 686 */       Iterator<BeanPropertyWriter> it = props.iterator();
/* 687 */       while (it.hasNext()) {
/* 688 */         BeanPropertyWriter prop = it.next();
/*     */ 
/*     */         
/* 691 */         AnnotatedMember m = prop.getMember();
/* 692 */         if (m instanceof com.fasterxml.jackson.databind.introspect.AnnotatedMethod && "isEmpty"
/* 693 */           .equals(m.getName()) && m
/* 694 */           .getDeclaringClass() == CharSequence.class) {
/* 695 */           it.remove();
/*     */         }
/*     */       } 
/*     */     } 
/* 699 */     return props;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void processViews(SerializationConfig config, BeanSerializerBuilder builder) {
/* 714 */     List<BeanPropertyWriter> props = builder.getProperties();
/* 715 */     boolean includeByDefault = config.isEnabled(MapperFeature.DEFAULT_VIEW_INCLUSION);
/* 716 */     int propCount = props.size();
/* 717 */     int viewsFound = 0;
/* 718 */     BeanPropertyWriter[] filtered = new BeanPropertyWriter[propCount];
/*     */     
/* 720 */     for (int i = 0; i < propCount; i++) {
/* 721 */       BeanPropertyWriter bpw = props.get(i);
/* 722 */       Class<?>[] views = bpw.getViews();
/* 723 */       if (views == null || views.length == 0) {
/*     */ 
/*     */         
/* 726 */         if (includeByDefault) {
/* 727 */           filtered[i] = bpw;
/*     */         }
/*     */       } else {
/* 730 */         viewsFound++;
/* 731 */         filtered[i] = constructFilteredBeanWriter(bpw, views);
/*     */       } 
/*     */     } 
/*     */     
/* 735 */     if (includeByDefault && viewsFound == 0) {
/*     */       return;
/*     */     }
/* 738 */     builder.setFilteredProperties(filtered);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void removeIgnorableTypes(SerializationConfig config, BeanDescription beanDesc, List<BeanPropertyDefinition> properties) {
/* 750 */     AnnotationIntrospector intr = config.getAnnotationIntrospector();
/* 751 */     HashMap<Class<?>, Boolean> ignores = new HashMap<>();
/* 752 */     Iterator<BeanPropertyDefinition> it = properties.iterator();
/* 753 */     while (it.hasNext()) {
/* 754 */       BeanPropertyDefinition property = it.next();
/* 755 */       AnnotatedMember accessor = property.getAccessor();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 760 */       if (accessor == null) {
/* 761 */         it.remove();
/*     */         continue;
/*     */       } 
/* 764 */       Class<?> type = property.getRawPrimaryType();
/* 765 */       Boolean result = ignores.get(type);
/* 766 */       if (result == null) {
/*     */         
/* 768 */         result = config.getConfigOverride(type).getIsIgnoredType();
/* 769 */         if (result == null) {
/* 770 */           BeanDescription desc = config.introspectClassAnnotations(type);
/* 771 */           AnnotatedClass ac = desc.getClassInfo();
/* 772 */           result = intr.isIgnorableType(ac);
/*     */           
/* 774 */           if (result == null) {
/* 775 */             result = Boolean.FALSE;
/*     */           }
/*     */         } 
/* 778 */         ignores.put(type, result);
/*     */       } 
/*     */       
/* 781 */       if (result.booleanValue()) {
/* 782 */         it.remove();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void removeSetterlessGetters(SerializationConfig config, BeanDescription beanDesc, List<BeanPropertyDefinition> properties) {
/* 793 */     Iterator<BeanPropertyDefinition> it = properties.iterator();
/* 794 */     while (it.hasNext()) {
/* 795 */       BeanPropertyDefinition property = it.next();
/*     */ 
/*     */       
/* 798 */       if (!property.couldDeserialize() && !property.isExplicitlyIncluded()) {
/* 799 */         it.remove();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<BeanPropertyWriter> removeOverlappingTypeIds(SerializerProvider prov, BeanDescription beanDesc, BeanSerializerBuilder builder, List<BeanPropertyWriter> props) {
/* 814 */     for (int i = 0, end = props.size(); i < end; i++) {
/* 815 */       BeanPropertyWriter bpw = props.get(i);
/* 816 */       TypeSerializer td = bpw.getTypeSerializer();
/* 817 */       if (td != null && td.getTypeInclusion() == JsonTypeInfo.As.EXTERNAL_PROPERTY) {
/*     */ 
/*     */         
/* 820 */         String n = td.getPropertyName();
/* 821 */         PropertyName typePropName = PropertyName.construct(n);
/*     */         
/* 823 */         for (BeanPropertyWriter w2 : props) {
/* 824 */           if (w2 != bpw && w2.wouldConflictWithName(typePropName)) {
/* 825 */             bpw.assignTypeSerializer(null); break;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 830 */     return props;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BeanPropertyWriter _constructWriter(SerializerProvider prov, BeanPropertyDefinition propDef, PropertyBuilder pb, boolean staticTyping, AnnotatedMember accessor) throws JsonMappingException {
/* 848 */     PropertyName name = propDef.getFullName();
/* 849 */     JavaType type = accessor.getType();
/*     */     
/* 851 */     BeanProperty.Std property = new BeanProperty.Std(name, type, propDef.getWrapperName(), accessor, propDef.getMetadata());
/*     */ 
/*     */     
/* 854 */     JsonSerializer<?> annotatedSerializer = findSerializerFromAnnotation(prov, (Annotated)accessor);
/*     */ 
/*     */ 
/*     */     
/* 858 */     if (annotatedSerializer instanceof ResolvableSerializer) {
/* 859 */       ((ResolvableSerializer)annotatedSerializer).resolve(prov);
/*     */     }
/*     */     
/* 862 */     annotatedSerializer = prov.handlePrimaryContextualization(annotatedSerializer, (BeanProperty)property);
/*     */     
/* 864 */     TypeSerializer contentTypeSer = null;
/*     */     
/* 866 */     if (type.isContainerType() || type.isReferenceType()) {
/* 867 */       contentTypeSer = findPropertyContentTypeSerializer(type, prov.getConfig(), accessor);
/*     */     }
/*     */     
/* 870 */     TypeSerializer typeSer = findPropertyTypeSerializer(type, prov.getConfig(), accessor);
/* 871 */     return pb.buildWriter(prov, propDef, type, annotatedSerializer, typeSer, contentTypeSer, accessor, staticTyping);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonSerializer<?> _findUnsupportedTypeSerializer(SerializerProvider ctxt, JavaType type, BeanDescription beanDesc) throws JsonMappingException {
/* 881 */     String errorMsg = BeanUtil.checkUnsupportedType(type);
/* 882 */     if (errorMsg != null)
/*     */     {
/*     */       
/* 885 */       if (ctxt.getConfig().findMixInClassFor(type.getRawClass()) == null) {
/* 886 */         return (JsonSerializer<?>)new UnsupportedTypeSerializer(type, errorMsg);
/*     */       }
/*     */     }
/* 889 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.12.7.1.jar!\com\fasterxml\jackson\databind\ser\BeanSerializerFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */