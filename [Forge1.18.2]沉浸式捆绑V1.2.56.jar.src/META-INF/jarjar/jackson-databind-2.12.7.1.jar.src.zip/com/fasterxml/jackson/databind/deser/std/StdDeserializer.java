/*      */ package com.fasterxml.jackson.databind.deser.std;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JsonFormat;
/*      */ import com.fasterxml.jackson.annotation.Nulls;
/*      */ import com.fasterxml.jackson.core.JsonParseException;
/*      */ import com.fasterxml.jackson.core.JsonParser;
/*      */ import com.fasterxml.jackson.core.JsonToken;
/*      */ import com.fasterxml.jackson.core.StreamReadCapability;
/*      */ import com.fasterxml.jackson.core.io.NumberInput;
/*      */ import com.fasterxml.jackson.databind.AnnotationIntrospector;
/*      */ import com.fasterxml.jackson.databind.BeanProperty;
/*      */ import com.fasterxml.jackson.databind.DeserializationContext;
/*      */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*      */ import com.fasterxml.jackson.databind.JavaType;
/*      */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*      */ import com.fasterxml.jackson.databind.JsonMappingException;
/*      */ import com.fasterxml.jackson.databind.KeyDeserializer;
/*      */ import com.fasterxml.jackson.databind.MapperFeature;
/*      */ import com.fasterxml.jackson.databind.PropertyMetadata;
/*      */ import com.fasterxml.jackson.databind.cfg.CoercionAction;
/*      */ import com.fasterxml.jackson.databind.cfg.CoercionInputShape;
/*      */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*      */ import com.fasterxml.jackson.databind.deser.BeanDeserializerBase;
/*      */ import com.fasterxml.jackson.databind.deser.NullValueProvider;
/*      */ import com.fasterxml.jackson.databind.deser.SettableBeanProperty;
/*      */ import com.fasterxml.jackson.databind.deser.ValueInstantiator;
/*      */ import com.fasterxml.jackson.databind.deser.impl.NullsAsEmptyProvider;
/*      */ import com.fasterxml.jackson.databind.deser.impl.NullsConstantProvider;
/*      */ import com.fasterxml.jackson.databind.deser.impl.NullsFailProvider;
/*      */ import com.fasterxml.jackson.databind.introspect.Annotated;
/*      */ import com.fasterxml.jackson.databind.introspect.AnnotatedMember;
/*      */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*      */ import com.fasterxml.jackson.databind.type.LogicalType;
/*      */ import com.fasterxml.jackson.databind.util.AccessPattern;
/*      */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*      */ import com.fasterxml.jackson.databind.util.Converter;
/*      */ import java.io.IOException;
/*      */ import java.io.Serializable;
/*      */ import java.util.Collection;
/*      */ import java.util.Date;
/*      */ import java.util.Map;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class StdDeserializer<T>
/*      */   extends JsonDeserializer<T>
/*      */   implements Serializable, ValueInstantiator.Gettable
/*      */ {
/*      */   private static final long serialVersionUID = 1L;
/*   51 */   protected static final int F_MASK_INT_COERCIONS = DeserializationFeature.USE_BIG_INTEGER_FOR_INTS
/*   52 */     .getMask() | DeserializationFeature.USE_LONG_FOR_INTS
/*   53 */     .getMask();
/*      */   
/*      */   @Deprecated
/*   56 */   protected static final int F_MASK_ACCEPT_ARRAYS = DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS
/*   57 */     .getMask() | DeserializationFeature.ACCEPT_EMPTY_ARRAY_AS_NULL_OBJECT
/*   58 */     .getMask();
/*      */ 
/*      */ 
/*      */   
/*      */   protected final Class<?> _valueClass;
/*      */ 
/*      */ 
/*      */   
/*      */   protected final JavaType _valueType;
/*      */ 
/*      */ 
/*      */   
/*      */   protected StdDeserializer(Class<?> vc) {
/*   71 */     this._valueClass = vc;
/*   72 */     this._valueType = null;
/*      */   }
/*      */ 
/*      */   
/*      */   protected StdDeserializer(JavaType valueType) {
/*   77 */     this._valueClass = (valueType == null) ? Object.class : valueType.getRawClass();
/*   78 */     this._valueType = valueType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected StdDeserializer(StdDeserializer<?> src) {
/*   88 */     this._valueClass = src._valueClass;
/*   89 */     this._valueType = src._valueType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Class<?> handledType() {
/*   99 */     return this._valueClass;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public final Class<?> getValueClass() {
/*  111 */     return this._valueClass;
/*      */   }
/*      */ 
/*      */   
/*      */   public JavaType getValueType() {
/*  116 */     return this._valueType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JavaType getValueType(DeserializationContext ctxt) {
/*  132 */     if (this._valueType != null) {
/*  133 */       return this._valueType;
/*      */     }
/*  135 */     return ctxt.constructType(this._valueClass);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ValueInstantiator getValueInstantiator() {
/*  142 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isDefaultDeserializer(JsonDeserializer<?> deserializer) {
/*  151 */     return ClassUtil.isJacksonStdImpl(deserializer);
/*      */   }
/*      */   
/*      */   protected boolean isDefaultKeyDeserializer(KeyDeserializer keyDeser) {
/*  155 */     return ClassUtil.isJacksonStdImpl(keyDeser);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object deserializeWithType(JsonParser p, DeserializationContext ctxt, TypeDeserializer typeDeserializer) throws IOException {
/*  172 */     return typeDeserializer.deserializeTypedFromAny(p, ctxt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected T _deserializeFromArray(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  200 */     CoercionAction act = _findCoercionFromEmptyArray(ctxt);
/*  201 */     boolean unwrap = ctxt.isEnabled(DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS);
/*      */     
/*  203 */     if (unwrap || act != CoercionAction.Fail) {
/*  204 */       JsonToken t = p.nextToken();
/*  205 */       if (t == JsonToken.END_ARRAY) {
/*  206 */         switch (act) {
/*      */           case AsEmpty:
/*  208 */             return (T)getEmptyValue(ctxt);
/*      */           case AsNull:
/*      */           case TryConvert:
/*  211 */             return (T)getNullValue(ctxt);
/*      */         } 
/*      */       
/*  214 */       } else if (unwrap) {
/*  215 */         T parsed = _deserializeWrappedValue(p, ctxt);
/*  216 */         if (p.nextToken() != JsonToken.END_ARRAY) {
/*  217 */           handleMissingEndArrayForSingle(p, ctxt);
/*      */         }
/*  219 */         return parsed;
/*      */       } 
/*      */     } 
/*  222 */     return (T)ctxt.handleUnexpectedToken(getValueType(ctxt), JsonToken.START_ARRAY, p, null, new Object[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected T _deserializeFromEmpty(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  238 */     if (p.hasToken(JsonToken.START_ARRAY) && 
/*  239 */       ctxt.isEnabled(DeserializationFeature.ACCEPT_EMPTY_ARRAY_AS_NULL_OBJECT)) {
/*  240 */       JsonToken t = p.nextToken();
/*  241 */       if (t == JsonToken.END_ARRAY) {
/*  242 */         return null;
/*      */       }
/*  244 */       return (T)ctxt.handleUnexpectedToken(getValueType(ctxt), p);
/*      */     } 
/*      */     
/*  247 */     return (T)ctxt.handleUnexpectedToken(getValueType(ctxt), p);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected T _deserializeFromString(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  260 */     ValueInstantiator inst = getValueInstantiator();
/*  261 */     Class<?> rawTargetType = handledType();
/*  262 */     String value = p.getValueAsString();
/*      */     
/*  264 */     if (inst != null && inst.canCreateFromString()) {
/*  265 */       return (T)inst.createFromString(ctxt, value);
/*      */     }
/*  267 */     if (value.isEmpty()) {
/*  268 */       CoercionAction act = ctxt.findCoercionAction(logicalType(), rawTargetType, CoercionInputShape.EmptyString);
/*      */       
/*  270 */       return (T)_deserializeFromEmptyString(p, ctxt, act, rawTargetType, "empty String (\"\")");
/*      */     } 
/*      */     
/*  273 */     if (_isBlank(value)) {
/*  274 */       CoercionAction act = ctxt.findCoercionFromBlankString(logicalType(), rawTargetType, CoercionAction.Fail);
/*      */       
/*  276 */       return (T)_deserializeFromEmptyString(p, ctxt, act, rawTargetType, "blank String (all whitespace)");
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  283 */     if (inst != null) {
/*  284 */       value = value.trim();
/*  285 */       if (inst.canCreateFromInt() && 
/*  286 */         ctxt.findCoercionAction(LogicalType.Integer, Integer.class, CoercionInputShape.String) == CoercionAction.TryConvert)
/*      */       {
/*  288 */         return (T)inst.createFromInt(ctxt, _parseIntPrimitive(ctxt, value));
/*      */       }
/*      */       
/*  291 */       if (inst.canCreateFromLong() && 
/*  292 */         ctxt.findCoercionAction(LogicalType.Integer, Long.class, CoercionInputShape.String) == CoercionAction.TryConvert)
/*      */       {
/*  294 */         return (T)inst.createFromLong(ctxt, _parseLongPrimitive(ctxt, value));
/*      */       }
/*      */       
/*  297 */       if (inst.canCreateFromBoolean())
/*      */       {
/*  299 */         if (ctxt.findCoercionAction(LogicalType.Boolean, Boolean.class, CoercionInputShape.String) == CoercionAction.TryConvert) {
/*      */           
/*  301 */           String str = value.trim();
/*  302 */           if ("true".equals(str)) {
/*  303 */             return (T)inst.createFromBoolean(ctxt, true);
/*      */           }
/*  305 */           if ("false".equals(str)) {
/*  306 */             return (T)inst.createFromBoolean(ctxt, false);
/*      */           }
/*      */         } 
/*      */       }
/*      */     } 
/*  311 */     return (T)ctxt.handleMissingInstantiator(rawTargetType, inst, ctxt.getParser(), "no String-argument constructor/factory method to deserialize from String value ('%s')", new Object[] { value });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object _deserializeFromEmptyString(JsonParser p, DeserializationContext ctxt, CoercionAction act, Class<?> rawTargetType, String desc) throws IOException {
/*  320 */     switch (act) {
/*      */       case AsEmpty:
/*  322 */         return getEmptyValue(ctxt);
/*      */       
/*      */       case Fail:
/*  325 */         _checkCoercionFail(ctxt, act, rawTargetType, "", "empty String (\"\")");
/*      */         break;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  331 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected T _deserializeWrappedValue(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  359 */     if (p.hasToken(JsonToken.START_ARRAY)) {
/*      */       
/*  361 */       T result = (T)handleNestedArrayForSingle(p, ctxt);
/*  362 */       return result;
/*      */     } 
/*  364 */     return (T)deserialize(p, ctxt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected final boolean _parseBooleanPrimitive(DeserializationContext ctxt, JsonParser p, Class<?> targetType) throws IOException {
/*  378 */     return _parseBooleanPrimitive(p, ctxt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final boolean _parseBooleanPrimitive(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  389 */     switch (p.currentTokenId()) {
/*      */       case 6:
/*  391 */         text = p.getText();
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 7:
/*  397 */         return Boolean.TRUE.equals(_coerceBooleanFromInt(p, ctxt, boolean.class));
/*      */       case 9:
/*  399 */         return true;
/*      */       case 10:
/*  401 */         return false;
/*      */       case 11:
/*  403 */         _verifyNullForPrimitive(ctxt);
/*  404 */         return false;
/*      */       
/*      */       case 1:
/*  407 */         text = ctxt.extractScalarFromObject(p, this, boolean.class);
/*      */         break;
/*      */       
/*      */       case 3:
/*  411 */         if (ctxt.isEnabled(DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS)) {
/*  412 */           if (p.nextToken() == JsonToken.START_ARRAY) {
/*  413 */             return ((Boolean)handleNestedArrayForSingle(p, ctxt)).booleanValue();
/*      */           }
/*  415 */           boolean parsed = _parseBooleanPrimitive(p, ctxt);
/*  416 */           _verifyEndArrayForSingle(p, ctxt);
/*  417 */           return parsed;
/*      */         } 
/*      */       
/*      */       default:
/*  421 */         return ((Boolean)ctxt.handleUnexpectedToken(boolean.class, p)).booleanValue();
/*      */     } 
/*      */     
/*  424 */     CoercionAction act = _checkFromStringCoercion(ctxt, text, LogicalType.Boolean, boolean.class);
/*      */     
/*  426 */     if (act == CoercionAction.AsNull) {
/*  427 */       _verifyNullForPrimitive(ctxt);
/*  428 */       return false;
/*      */     } 
/*  430 */     if (act == CoercionAction.AsEmpty) {
/*  431 */       return false;
/*      */     }
/*  433 */     String text = text.trim();
/*  434 */     int len = text.length();
/*      */ 
/*      */ 
/*      */     
/*  438 */     if (len == 4) {
/*  439 */       if (_isTrue(text)) {
/*  440 */         return true;
/*      */       }
/*  442 */     } else if (len == 5 && 
/*  443 */       _isFalse(text)) {
/*  444 */       return false;
/*      */     } 
/*      */     
/*  447 */     if (_hasTextualNull(text)) {
/*  448 */       _verifyNullForPrimitiveCoercion(ctxt, text);
/*  449 */       return false;
/*      */     } 
/*  451 */     Boolean b = (Boolean)ctxt.handleWeirdStringValue(boolean.class, text, "only \"true\"/\"True\"/\"TRUE\" or \"false\"/\"False\"/\"FALSE\" recognized", new Object[0]);
/*      */     
/*  453 */     return Boolean.TRUE.equals(b);
/*      */   }
/*      */ 
/*      */   
/*      */   protected boolean _isTrue(String text) {
/*  458 */     char c = text.charAt(0);
/*  459 */     if (c == 't') {
/*  460 */       return "true".equals(text);
/*      */     }
/*  462 */     if (c == 'T') {
/*  463 */       return ("TRUE".equals(text) || "True".equals(text));
/*      */     }
/*  465 */     return false;
/*      */   }
/*      */   
/*      */   protected boolean _isFalse(String text) {
/*  469 */     char c = text.charAt(0);
/*  470 */     if (c == 'f') {
/*  471 */       return "false".equals(text);
/*      */     }
/*  473 */     if (c == 'F') {
/*  474 */       return ("FALSE".equals(text) || "False".equals(text));
/*      */     }
/*  476 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final Boolean _parseBoolean(JsonParser p, DeserializationContext ctxt, Class<?> targetType) throws IOException {
/*  502 */     switch (p.currentTokenId()) {
/*      */       case 6:
/*  504 */         text = p.getText();
/*      */         break;
/*      */       
/*      */       case 7:
/*  508 */         return _coerceBooleanFromInt(p, ctxt, targetType);
/*      */       case 9:
/*  510 */         return Boolean.valueOf(true);
/*      */       case 10:
/*  512 */         return Boolean.valueOf(false);
/*      */       case 11:
/*  514 */         return null;
/*      */       
/*      */       case 1:
/*  517 */         text = ctxt.extractScalarFromObject(p, this, targetType);
/*      */         break;
/*      */       case 3:
/*  520 */         return (Boolean)_deserializeFromArray(p, ctxt);
/*      */       default:
/*  522 */         return (Boolean)ctxt.handleUnexpectedToken(targetType, p);
/*      */     } 
/*      */     
/*  525 */     CoercionAction act = _checkFromStringCoercion(ctxt, text, LogicalType.Boolean, targetType);
/*      */     
/*  527 */     if (act == CoercionAction.AsNull) {
/*  528 */       return null;
/*      */     }
/*  530 */     if (act == CoercionAction.AsEmpty) {
/*  531 */       return Boolean.valueOf(false);
/*      */     }
/*  533 */     String text = text.trim();
/*  534 */     int len = text.length();
/*      */ 
/*      */ 
/*      */     
/*  538 */     if (len == 4) {
/*  539 */       if (_isTrue(text)) {
/*  540 */         return Boolean.valueOf(true);
/*      */       }
/*  542 */     } else if (len == 5 && 
/*  543 */       _isFalse(text)) {
/*  544 */       return Boolean.valueOf(false);
/*      */     } 
/*      */     
/*  547 */     if (_checkTextualNull(ctxt, text)) {
/*  548 */       return null;
/*      */     }
/*  550 */     return (Boolean)ctxt.handleWeirdStringValue(targetType, text, "only \"true\" or \"false\" recognized", new Object[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final byte _parseBytePrimitive(JsonParser p, DeserializationContext ctxt) throws IOException {
/*      */     int value;
/*  558 */     switch (p.currentTokenId()) {
/*      */       case 6:
/*  560 */         text = p.getText();
/*      */         break;
/*      */       case 8:
/*  563 */         act = _checkFloatToIntCoercion(p, ctxt, byte.class);
/*  564 */         if (act == CoercionAction.AsNull) {
/*  565 */           return 0;
/*      */         }
/*  567 */         if (act == CoercionAction.AsEmpty) {
/*  568 */           return 0;
/*      */         }
/*  570 */         return p.getByteValue();
/*      */       case 7:
/*  572 */         return p.getByteValue();
/*      */       case 11:
/*  574 */         _verifyNullForPrimitive(ctxt);
/*  575 */         return 0;
/*      */       
/*      */       case 1:
/*  578 */         text = ctxt.extractScalarFromObject(p, this, byte.class);
/*      */         break;
/*      */       
/*      */       case 3:
/*  582 */         if (ctxt.isEnabled(DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS)) {
/*  583 */           if (p.nextToken() == JsonToken.START_ARRAY) {
/*  584 */             return ((Byte)handleNestedArrayForSingle(p, ctxt)).byteValue();
/*      */           }
/*  586 */           byte parsed = _parseBytePrimitive(p, ctxt);
/*  587 */           _verifyEndArrayForSingle(p, ctxt);
/*  588 */           return parsed;
/*      */         } 
/*      */       
/*      */       default:
/*  592 */         return ((Byte)ctxt.handleUnexpectedToken(ctxt.constructType(byte.class), p)).byteValue();
/*      */     } 
/*      */ 
/*      */     
/*  596 */     CoercionAction act = _checkFromStringCoercion(ctxt, text, LogicalType.Integer, byte.class);
/*      */     
/*  598 */     if (act == CoercionAction.AsNull) {
/*  599 */       return 0;
/*      */     }
/*  601 */     if (act == CoercionAction.AsEmpty) {
/*  602 */       return 0;
/*      */     }
/*  604 */     String text = text.trim();
/*  605 */     if (_hasTextualNull(text)) {
/*  606 */       _verifyNullForPrimitiveCoercion(ctxt, text);
/*  607 */       return 0;
/*      */     } 
/*      */     
/*      */     try {
/*  611 */       value = NumberInput.parseInt(text);
/*  612 */     } catch (IllegalArgumentException iae) {
/*  613 */       return ((Byte)ctxt.handleWeirdStringValue(this._valueClass, text, "not a valid `byte` value", new Object[0])).byteValue();
/*      */     } 
/*      */ 
/*      */     
/*  617 */     if (_byteOverflow(value)) {
/*  618 */       return ((Byte)ctxt.handleWeirdStringValue(this._valueClass, text, "overflow, value cannot be represented as 8-bit value", new Object[0])).byteValue();
/*      */     }
/*      */     
/*  621 */     return (byte)value;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected final short _parseShortPrimitive(JsonParser p, DeserializationContext ctxt) throws IOException {
/*      */     int value;
/*  628 */     switch (p.currentTokenId()) {
/*      */       case 6:
/*  630 */         text = p.getText();
/*      */         break;
/*      */       case 8:
/*  633 */         act = _checkFloatToIntCoercion(p, ctxt, short.class);
/*  634 */         if (act == CoercionAction.AsNull) {
/*  635 */           return 0;
/*      */         }
/*  637 */         if (act == CoercionAction.AsEmpty) {
/*  638 */           return 0;
/*      */         }
/*  640 */         return p.getShortValue();
/*      */       case 7:
/*  642 */         return p.getShortValue();
/*      */       case 11:
/*  644 */         _verifyNullForPrimitive(ctxt);
/*  645 */         return 0;
/*      */       
/*      */       case 1:
/*  648 */         text = ctxt.extractScalarFromObject(p, this, short.class);
/*      */         break;
/*      */       
/*      */       case 3:
/*  652 */         if (ctxt.isEnabled(DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS)) {
/*  653 */           if (p.nextToken() == JsonToken.START_ARRAY) {
/*  654 */             return ((Short)handleNestedArrayForSingle(p, ctxt)).shortValue();
/*      */           }
/*  656 */           short parsed = _parseShortPrimitive(p, ctxt);
/*  657 */           _verifyEndArrayForSingle(p, ctxt);
/*  658 */           return parsed;
/*      */         } 
/*      */       
/*      */       default:
/*  662 */         return ((Short)ctxt.handleUnexpectedToken(ctxt.constructType(short.class), p)).shortValue();
/*      */     } 
/*      */     
/*  665 */     CoercionAction act = _checkFromStringCoercion(ctxt, text, LogicalType.Integer, short.class);
/*      */     
/*  667 */     if (act == CoercionAction.AsNull) {
/*  668 */       return 0;
/*      */     }
/*  670 */     if (act == CoercionAction.AsEmpty) {
/*  671 */       return 0;
/*      */     }
/*  673 */     String text = text.trim();
/*  674 */     if (_hasTextualNull(text)) {
/*  675 */       _verifyNullForPrimitiveCoercion(ctxt, text);
/*  676 */       return 0;
/*      */     } 
/*      */     
/*      */     try {
/*  680 */       value = NumberInput.parseInt(text);
/*  681 */     } catch (IllegalArgumentException iae) {
/*  682 */       return ((Short)ctxt.handleWeirdStringValue(short.class, text, "not a valid `short` value", new Object[0])).shortValue();
/*      */     } 
/*      */     
/*  685 */     if (_shortOverflow(value)) {
/*  686 */       return ((Short)ctxt.handleWeirdStringValue(short.class, text, "overflow, value cannot be represented as 16-bit value", new Object[0])).shortValue();
/*      */     }
/*      */     
/*  689 */     return (short)value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final int _parseIntPrimitive(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  696 */     switch (p.currentTokenId()) {
/*      */       case 6:
/*  698 */         text = p.getText();
/*      */         break;
/*      */       case 8:
/*  701 */         act = _checkFloatToIntCoercion(p, ctxt, int.class);
/*  702 */         if (act == CoercionAction.AsNull) {
/*  703 */           return 0;
/*      */         }
/*  705 */         if (act == CoercionAction.AsEmpty) {
/*  706 */           return 0;
/*      */         }
/*  708 */         return p.getValueAsInt();
/*      */       case 7:
/*  710 */         return p.getIntValue();
/*      */       case 11:
/*  712 */         _verifyNullForPrimitive(ctxt);
/*  713 */         return 0;
/*      */       
/*      */       case 1:
/*  716 */         text = ctxt.extractScalarFromObject(p, this, int.class);
/*      */         break;
/*      */       case 3:
/*  719 */         if (ctxt.isEnabled(DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS)) {
/*  720 */           if (p.nextToken() == JsonToken.START_ARRAY) {
/*  721 */             return ((Integer)handleNestedArrayForSingle(p, ctxt)).intValue();
/*      */           }
/*  723 */           int parsed = _parseIntPrimitive(p, ctxt);
/*  724 */           _verifyEndArrayForSingle(p, ctxt);
/*  725 */           return parsed;
/*      */         } 
/*      */       
/*      */       default:
/*  729 */         return ((Number)ctxt.handleUnexpectedToken(int.class, p)).intValue();
/*      */     } 
/*      */     
/*  732 */     CoercionAction act = _checkFromStringCoercion(ctxt, text, LogicalType.Integer, int.class);
/*      */     
/*  734 */     if (act == CoercionAction.AsNull) {
/*  735 */       return 0;
/*      */     }
/*  737 */     if (act == CoercionAction.AsEmpty) {
/*  738 */       return 0;
/*      */     }
/*  740 */     String text = text.trim();
/*  741 */     if (_hasTextualNull(text)) {
/*  742 */       _verifyNullForPrimitiveCoercion(ctxt, text);
/*  743 */       return 0;
/*      */     } 
/*  745 */     return _parseIntPrimitive(ctxt, text);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final int _parseIntPrimitive(DeserializationContext ctxt, String text) throws IOException {
/*      */     try {
/*  754 */       if (text.length() > 9) {
/*  755 */         long l = Long.parseLong(text);
/*  756 */         if (_intOverflow(l)) {
/*  757 */           Number v = (Number)ctxt.handleWeirdStringValue(int.class, text, "Overflow: numeric value (%s) out of range of int (%d -%d)", new Object[] { text, 
/*      */                 
/*  759 */                 Integer.valueOf(-2147483648), Integer.valueOf(2147483647) });
/*  760 */           return _nonNullNumber(v).intValue();
/*      */         } 
/*  762 */         return (int)l;
/*      */       } 
/*  764 */       return NumberInput.parseInt(text);
/*  765 */     } catch (IllegalArgumentException iae) {
/*  766 */       Number v = (Number)ctxt.handleWeirdStringValue(int.class, text, "not a valid `int` value", new Object[0]);
/*      */       
/*  768 */       return _nonNullNumber(v).intValue();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final Integer _parseInteger(JsonParser p, DeserializationContext ctxt, Class<?> targetType) throws IOException {
/*  780 */     switch (p.currentTokenId()) {
/*      */       case 6:
/*  782 */         text = p.getText();
/*      */         break;
/*      */       case 8:
/*  785 */         act = _checkFloatToIntCoercion(p, ctxt, targetType);
/*  786 */         if (act == CoercionAction.AsNull) {
/*  787 */           return (Integer)getNullValue(ctxt);
/*      */         }
/*  789 */         if (act == CoercionAction.AsEmpty) {
/*  790 */           return (Integer)getEmptyValue(ctxt);
/*      */         }
/*  792 */         return Integer.valueOf(p.getValueAsInt());
/*      */       case 7:
/*  794 */         return Integer.valueOf(p.getIntValue());
/*      */       case 11:
/*  796 */         return (Integer)getNullValue(ctxt);
/*      */       
/*      */       case 1:
/*  799 */         text = ctxt.extractScalarFromObject(p, this, targetType);
/*      */         break;
/*      */       case 3:
/*  802 */         return (Integer)_deserializeFromArray(p, ctxt);
/*      */       default:
/*  804 */         return (Integer)ctxt.handleUnexpectedToken(getValueType(ctxt), p);
/*      */     } 
/*      */     
/*  807 */     CoercionAction act = _checkFromStringCoercion(ctxt, text);
/*  808 */     if (act == CoercionAction.AsNull) {
/*  809 */       return (Integer)getNullValue(ctxt);
/*      */     }
/*  811 */     if (act == CoercionAction.AsEmpty) {
/*  812 */       return (Integer)getEmptyValue(ctxt);
/*      */     }
/*  814 */     String text = text.trim();
/*  815 */     if (_checkTextualNull(ctxt, text)) {
/*  816 */       return (Integer)getNullValue(ctxt);
/*      */     }
/*  818 */     return Integer.valueOf(_parseIntPrimitive(ctxt, text));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final long _parseLongPrimitive(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  825 */     switch (p.currentTokenId()) {
/*      */       case 6:
/*  827 */         text = p.getText();
/*      */         break;
/*      */       case 8:
/*  830 */         act = _checkFloatToIntCoercion(p, ctxt, long.class);
/*  831 */         if (act == CoercionAction.AsNull) {
/*  832 */           return 0L;
/*      */         }
/*  834 */         if (act == CoercionAction.AsEmpty) {
/*  835 */           return 0L;
/*      */         }
/*  837 */         return p.getValueAsLong();
/*      */       case 7:
/*  839 */         return p.getLongValue();
/*      */       case 11:
/*  841 */         _verifyNullForPrimitive(ctxt);
/*  842 */         return 0L;
/*      */       
/*      */       case 1:
/*  845 */         text = ctxt.extractScalarFromObject(p, this, long.class);
/*      */         break;
/*      */       case 3:
/*  848 */         if (ctxt.isEnabled(DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS)) {
/*  849 */           if (p.nextToken() == JsonToken.START_ARRAY) {
/*  850 */             return ((Long)handleNestedArrayForSingle(p, ctxt)).longValue();
/*      */           }
/*  852 */           long parsed = _parseLongPrimitive(p, ctxt);
/*  853 */           _verifyEndArrayForSingle(p, ctxt);
/*  854 */           return parsed;
/*      */         } 
/*      */       
/*      */       default:
/*  858 */         return ((Number)ctxt.handleUnexpectedToken(long.class, p)).longValue();
/*      */     } 
/*      */     
/*  861 */     CoercionAction act = _checkFromStringCoercion(ctxt, text, LogicalType.Integer, long.class);
/*      */     
/*  863 */     if (act == CoercionAction.AsNull) {
/*  864 */       return 0L;
/*      */     }
/*  866 */     if (act == CoercionAction.AsEmpty) {
/*  867 */       return 0L;
/*      */     }
/*  869 */     String text = text.trim();
/*  870 */     if (_hasTextualNull(text)) {
/*  871 */       _verifyNullForPrimitiveCoercion(ctxt, text);
/*  872 */       return 0L;
/*      */     } 
/*  874 */     return _parseLongPrimitive(ctxt, text);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final long _parseLongPrimitive(DeserializationContext ctxt, String text) throws IOException {
/*      */     try {
/*  883 */       return NumberInput.parseLong(text);
/*  884 */     } catch (IllegalArgumentException illegalArgumentException) {
/*      */       
/*  886 */       Number v = (Number)ctxt.handleWeirdStringValue(long.class, text, "not a valid `long` value", new Object[0]);
/*      */       
/*  888 */       return _nonNullNumber(v).longValue();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final Long _parseLong(JsonParser p, DeserializationContext ctxt, Class<?> targetType) throws IOException {
/*  900 */     switch (p.currentTokenId()) {
/*      */       case 6:
/*  902 */         text = p.getText();
/*      */         break;
/*      */       case 8:
/*  905 */         act = _checkFloatToIntCoercion(p, ctxt, targetType);
/*  906 */         if (act == CoercionAction.AsNull) {
/*  907 */           return (Long)getNullValue(ctxt);
/*      */         }
/*  909 */         if (act == CoercionAction.AsEmpty) {
/*  910 */           return (Long)getEmptyValue(ctxt);
/*      */         }
/*  912 */         return Long.valueOf(p.getValueAsLong());
/*      */       case 11:
/*  914 */         return (Long)getNullValue(ctxt);
/*      */       case 7:
/*  916 */         return Long.valueOf(p.getLongValue());
/*      */       
/*      */       case 1:
/*  919 */         text = ctxt.extractScalarFromObject(p, this, targetType);
/*      */         break;
/*      */       case 3:
/*  922 */         return (Long)_deserializeFromArray(p, ctxt);
/*      */       default:
/*  924 */         return (Long)ctxt.handleUnexpectedToken(getValueType(ctxt), p);
/*      */     } 
/*      */     
/*  927 */     CoercionAction act = _checkFromStringCoercion(ctxt, text);
/*  928 */     if (act == CoercionAction.AsNull) {
/*  929 */       return (Long)getNullValue(ctxt);
/*      */     }
/*  931 */     if (act == CoercionAction.AsEmpty) {
/*  932 */       return (Long)getEmptyValue(ctxt);
/*      */     }
/*  934 */     String text = text.trim();
/*  935 */     if (_checkTextualNull(ctxt, text)) {
/*  936 */       return (Long)getNullValue(ctxt);
/*      */     }
/*      */     
/*  939 */     return Long.valueOf(_parseLongPrimitive(ctxt, text));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final float _parseFloatPrimitive(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  946 */     switch (p.currentTokenId()) {
/*      */       case 6:
/*  948 */         text = p.getText();
/*      */         break;
/*      */       case 7:
/*      */       case 8:
/*  952 */         return p.getFloatValue();
/*      */       case 11:
/*  954 */         _verifyNullForPrimitive(ctxt);
/*  955 */         return 0.0F;
/*      */       
/*      */       case 1:
/*  958 */         text = ctxt.extractScalarFromObject(p, this, float.class);
/*      */         break;
/*      */       case 3:
/*  961 */         if (ctxt.isEnabled(DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS)) {
/*  962 */           if (p.nextToken() == JsonToken.START_ARRAY) {
/*  963 */             return ((Float)handleNestedArrayForSingle(p, ctxt)).floatValue();
/*      */           }
/*  965 */           float parsed = _parseFloatPrimitive(p, ctxt);
/*  966 */           _verifyEndArrayForSingle(p, ctxt);
/*  967 */           return parsed;
/*      */         } 
/*      */       
/*      */       default:
/*  971 */         return ((Number)ctxt.handleUnexpectedToken(float.class, p)).floatValue();
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  978 */     Float nan = _checkFloatSpecialValue(text);
/*  979 */     if (nan != null) {
/*  980 */       return nan.floatValue();
/*      */     }
/*      */ 
/*      */     
/*  984 */     CoercionAction act = _checkFromStringCoercion(ctxt, text, LogicalType.Integer, float.class);
/*      */     
/*  986 */     if (act == CoercionAction.AsNull) {
/*  987 */       return 0.0F;
/*      */     }
/*  989 */     if (act == CoercionAction.AsEmpty) {
/*  990 */       return 0.0F;
/*      */     }
/*  992 */     String text = text.trim();
/*  993 */     if (_hasTextualNull(text)) {
/*  994 */       _verifyNullForPrimitiveCoercion(ctxt, text);
/*  995 */       return 0.0F;
/*      */     } 
/*  997 */     return _parseFloatPrimitive(ctxt, text);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final float _parseFloatPrimitive(DeserializationContext ctxt, String text) throws IOException {
/*      */     try {
/* 1007 */       return Float.parseFloat(text);
/* 1008 */     } catch (IllegalArgumentException illegalArgumentException) {
/* 1009 */       Number v = (Number)ctxt.handleWeirdStringValue(float.class, text, "not a valid `float` value", new Object[0]);
/*      */       
/* 1011 */       return _nonNullNumber(v).floatValue();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Float _checkFloatSpecialValue(String text) {
/* 1028 */     if (!text.isEmpty()) {
/* 1029 */       switch (text.charAt(0)) {
/*      */         case 'I':
/* 1031 */           if (_isPosInf(text)) {
/* 1032 */             return Float.valueOf(Float.POSITIVE_INFINITY);
/*      */           }
/*      */           break;
/*      */         case 'N':
/* 1036 */           if (_isNaN(text)) return Float.valueOf(Float.NaN); 
/*      */           break;
/*      */         case '-':
/* 1039 */           if (_isNegInf(text)) {
/* 1040 */             return Float.valueOf(Float.NEGATIVE_INFINITY);
/*      */           }
/*      */           break;
/*      */       } 
/*      */     
/*      */     }
/* 1046 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final double _parseDoublePrimitive(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 1053 */     switch (p.currentTokenId()) {
/*      */       case 6:
/* 1055 */         text = p.getText();
/*      */         break;
/*      */       case 7:
/*      */       case 8:
/* 1059 */         return p.getDoubleValue();
/*      */       case 11:
/* 1061 */         _verifyNullForPrimitive(ctxt);
/* 1062 */         return 0.0D;
/*      */       
/*      */       case 1:
/* 1065 */         text = ctxt.extractScalarFromObject(p, this, double.class);
/*      */         break;
/*      */       case 3:
/* 1068 */         if (ctxt.isEnabled(DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS)) {
/* 1069 */           if (p.nextToken() == JsonToken.START_ARRAY) {
/* 1070 */             return ((Double)handleNestedArrayForSingle(p, ctxt)).doubleValue();
/*      */           }
/* 1072 */           double parsed = _parseDoublePrimitive(p, ctxt);
/* 1073 */           _verifyEndArrayForSingle(p, ctxt);
/* 1074 */           return parsed;
/*      */         } 
/*      */       
/*      */       default:
/* 1078 */         return ((Number)ctxt.handleUnexpectedToken(double.class, p)).doubleValue();
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1085 */     Double nan = _checkDoubleSpecialValue(text);
/* 1086 */     if (nan != null) {
/* 1087 */       return nan.doubleValue();
/*      */     }
/*      */ 
/*      */     
/* 1091 */     CoercionAction act = _checkFromStringCoercion(ctxt, text, LogicalType.Integer, double.class);
/*      */     
/* 1093 */     if (act == CoercionAction.AsNull) {
/* 1094 */       return 0.0D;
/*      */     }
/* 1096 */     if (act == CoercionAction.AsEmpty) {
/* 1097 */       return 0.0D;
/*      */     }
/* 1099 */     String text = text.trim();
/* 1100 */     if (_hasTextualNull(text)) {
/* 1101 */       _verifyNullForPrimitiveCoercion(ctxt, text);
/* 1102 */       return 0.0D;
/*      */     } 
/* 1104 */     return _parseDoublePrimitive(ctxt, text);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final double _parseDoublePrimitive(DeserializationContext ctxt, String text) throws IOException {
/*      */     try {
/* 1114 */       return _parseDouble(text);
/* 1115 */     } catch (IllegalArgumentException illegalArgumentException) {
/* 1116 */       Number v = (Number)ctxt.handleWeirdStringValue(double.class, text, "not a valid `double` value (as String to convert)", new Object[0]);
/*      */       
/* 1118 */       return _nonNullNumber(v).doubleValue();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static final double _parseDouble(String numStr) throws NumberFormatException {
/* 1128 */     if ("2.2250738585072012e-308".equals(numStr)) {
/* 1129 */       return 2.2250738585072014E-308D;
/*      */     }
/* 1131 */     return Double.parseDouble(numStr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Double _checkDoubleSpecialValue(String text) {
/* 1148 */     if (!text.isEmpty()) {
/* 1149 */       switch (text.charAt(0)) {
/*      */         case 'I':
/* 1151 */           if (_isPosInf(text)) {
/* 1152 */             return Double.valueOf(Double.POSITIVE_INFINITY);
/*      */           }
/*      */           break;
/*      */         case 'N':
/* 1156 */           if (_isNaN(text)) {
/* 1157 */             return Double.valueOf(Double.NaN);
/*      */           }
/*      */           break;
/*      */         case '-':
/* 1161 */           if (_isNegInf(text)) {
/* 1162 */             return Double.valueOf(Double.NEGATIVE_INFINITY);
/*      */           }
/*      */           break;
/*      */       } 
/*      */     
/*      */     }
/* 1168 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   protected Date _parseDate(JsonParser p, DeserializationContext ctxt) throws IOException {
/*      */     String text;
/*      */     long ts;
/* 1175 */     switch (p.currentTokenId()) {
/*      */       case 6:
/* 1177 */         text = p.getText();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1205 */         return _parseDate(text.trim(), ctxt);case 7: try { ts = p.getLongValue(); } catch (JsonParseException|com.fasterxml.jackson.core.exc.InputCoercionException e) { Number v = (Number)ctxt.handleWeirdNumberValue(this._valueClass, p.getNumberValue(), "not a valid 64-bit `long` for creating `java.util.Date`", new Object[0]); ts = v.longValue(); }  return new Date(ts);case 11: return (Date)getNullValue(ctxt);case 1: text = ctxt.extractScalarFromObject(p, this, this._valueClass); return _parseDate(text.trim(), ctxt);
/*      */       case 3:
/*      */         return _parseDateFromArray(p, ctxt);
/*      */     } 
/*      */     return (Date)ctxt.handleUnexpectedToken(this._valueClass, p);
/*      */   }
/*      */   protected Date _parseDateFromArray(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 1212 */     CoercionAction act = _findCoercionFromEmptyArray(ctxt);
/* 1213 */     boolean unwrap = ctxt.isEnabled(DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS);
/*      */     
/* 1215 */     if (unwrap || act != CoercionAction.Fail) {
/* 1216 */       JsonToken t = p.nextToken();
/* 1217 */       if (t == JsonToken.END_ARRAY) {
/* 1218 */         switch (act) {
/*      */           case AsEmpty:
/* 1220 */             return (Date)getEmptyValue(ctxt);
/*      */           case AsNull:
/*      */           case TryConvert:
/* 1223 */             return (Date)getNullValue(ctxt);
/*      */         } 
/*      */       
/* 1226 */       } else if (unwrap) {
/* 1227 */         if (t == JsonToken.START_ARRAY) {
/* 1228 */           return (Date)handleNestedArrayForSingle(p, ctxt);
/*      */         }
/* 1230 */         Date parsed = _parseDate(p, ctxt);
/* 1231 */         _verifyEndArrayForSingle(p, ctxt);
/* 1232 */         return parsed;
/*      */       } 
/*      */     } 
/* 1235 */     return (Date)ctxt.handleUnexpectedToken(this._valueClass, JsonToken.START_ARRAY, p, null, new Object[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Date _parseDate(String value, DeserializationContext ctxt) throws IOException {
/*      */     try {
/* 1246 */       if (value.isEmpty()) {
/* 1247 */         CoercionAction act = _checkFromStringCoercion(ctxt, value);
/* 1248 */         switch (act) {
/*      */           case AsEmpty:
/* 1250 */             return new Date(0L);
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 1255 */         return null;
/*      */       } 
/*      */       
/* 1258 */       if (_hasTextualNull(value)) {
/* 1259 */         return null;
/*      */       }
/* 1261 */       return ctxt.parseDate(value);
/* 1262 */     } catch (IllegalArgumentException iae) {
/* 1263 */       return (Date)ctxt.handleWeirdStringValue(this._valueClass, value, "not a valid representation (error: %s)", new Object[] {
/*      */             
/* 1265 */             ClassUtil.exceptionMessage(iae)
/*      */           });
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final String _parseString(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 1277 */     if (p.hasToken(JsonToken.VALUE_STRING)) {
/* 1278 */       return p.getText();
/*      */     }
/*      */     
/* 1281 */     if (p.hasToken(JsonToken.VALUE_EMBEDDED_OBJECT)) {
/* 1282 */       Object ob = p.getEmbeddedObject();
/* 1283 */       if (ob instanceof byte[]) {
/* 1284 */         return ctxt.getBase64Variant().encode((byte[])ob, false);
/*      */       }
/* 1286 */       if (ob == null) {
/* 1287 */         return null;
/*      */       }
/*      */       
/* 1290 */       return ob.toString();
/*      */     } 
/*      */     
/* 1293 */     if (p.hasToken(JsonToken.START_OBJECT)) {
/* 1294 */       return ctxt.extractScalarFromObject(p, this, this._valueClass);
/*      */     }
/*      */     
/* 1297 */     String value = p.getValueAsString();
/* 1298 */     if (value != null) {
/* 1299 */       return value;
/*      */     }
/* 1301 */     return (String)ctxt.handleUnexpectedToken(String.class, p);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _hasTextualNull(String value) {
/* 1312 */     return "null".equals(value);
/*      */   }
/*      */   
/*      */   protected final boolean _isNegInf(String text) {
/* 1316 */     return ("-Infinity".equals(text) || "-INF".equals(text));
/*      */   }
/*      */   
/*      */   protected final boolean _isPosInf(String text) {
/* 1320 */     return ("Infinity".equals(text) || "INF".equals(text));
/*      */   }
/*      */   protected final boolean _isNaN(String text) {
/* 1323 */     return "NaN".equals(text);
/*      */   }
/*      */ 
/*      */   
/*      */   protected static final boolean _isBlank(String text) {
/* 1328 */     int len = text.length();
/* 1329 */     for (int i = 0; i < len; i++) {
/* 1330 */       if (text.charAt(i) > ' ') {
/* 1331 */         return false;
/*      */       }
/*      */     } 
/* 1334 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected CoercionAction _checkFromStringCoercion(DeserializationContext ctxt, String value) throws IOException {
/* 1349 */     return _checkFromStringCoercion(ctxt, value, logicalType(), handledType());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected CoercionAction _checkFromStringCoercion(DeserializationContext ctxt, String value, LogicalType logicalType, Class<?> rawTargetType) throws IOException {
/* 1366 */     if (value.isEmpty()) {
/* 1367 */       CoercionAction coercionAction = ctxt.findCoercionAction(logicalType, rawTargetType, CoercionInputShape.EmptyString);
/*      */       
/* 1369 */       return _checkCoercionFail(ctxt, coercionAction, rawTargetType, value, "empty String (\"\")");
/*      */     } 
/* 1371 */     if (_isBlank(value)) {
/* 1372 */       CoercionAction coercionAction = ctxt.findCoercionFromBlankString(logicalType, rawTargetType, CoercionAction.Fail);
/* 1373 */       return _checkCoercionFail(ctxt, coercionAction, rawTargetType, value, "blank String (all whitespace)");
/*      */     } 
/*      */ 
/*      */     
/* 1377 */     if (ctxt.isEnabled(StreamReadCapability.UNTYPED_SCALARS)) {
/* 1378 */       return CoercionAction.TryConvert;
/*      */     }
/* 1380 */     CoercionAction act = ctxt.findCoercionAction(logicalType, rawTargetType, CoercionInputShape.String);
/* 1381 */     if (act == CoercionAction.Fail)
/*      */     {
/* 1383 */       ctxt.reportInputMismatch(this, "Cannot coerce String value (\"%s\") to %s (but might if coercion using `CoercionConfig` was enabled)", new Object[] { value, 
/*      */             
/* 1385 */             _coercedTypeDesc() });
/*      */     }
/*      */     
/* 1388 */     return act;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected CoercionAction _checkFloatToIntCoercion(JsonParser p, DeserializationContext ctxt, Class<?> rawTargetType) throws IOException {
/* 1398 */     CoercionAction act = ctxt.findCoercionAction(LogicalType.Integer, rawTargetType, CoercionInputShape.Float);
/*      */     
/* 1400 */     if (act == CoercionAction.Fail) {
/* 1401 */       return _checkCoercionFail(ctxt, act, rawTargetType, p.getNumberValue(), "Floating-point value (" + p
/* 1402 */           .getText() + ")");
/*      */     }
/* 1404 */     return act;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Boolean _coerceBooleanFromInt(JsonParser p, DeserializationContext ctxt, Class<?> rawTargetType) throws IOException {
/* 1414 */     CoercionAction act = ctxt.findCoercionAction(LogicalType.Boolean, rawTargetType, CoercionInputShape.Integer);
/* 1415 */     switch (act) {
/*      */       case Fail:
/* 1417 */         _checkCoercionFail(ctxt, act, rawTargetType, p.getNumberValue(), "Integer value (" + p
/* 1418 */             .getText() + ")");
/* 1419 */         return Boolean.FALSE;
/*      */       case AsNull:
/* 1421 */         return null;
/*      */       case AsEmpty:
/* 1423 */         return Boolean.FALSE;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1429 */     if (p.getNumberType() == JsonParser.NumberType.INT)
/*      */     {
/* 1431 */       return Boolean.valueOf((p.getIntValue() != 0));
/*      */     }
/* 1433 */     return Boolean.valueOf(!"0".equals(p.getText()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected CoercionAction _checkCoercionFail(DeserializationContext ctxt, CoercionAction act, Class<?> targetType, Object inputValue, String inputDesc) throws IOException {
/* 1444 */     if (act == CoercionAction.Fail) {
/* 1445 */       ctxt.reportBadCoercion(this, targetType, inputValue, "Cannot coerce %s to %s (but could if coercion was enabled using `CoercionConfig`)", new Object[] { inputDesc, 
/*      */             
/* 1447 */             _coercedTypeDesc() });
/*      */     }
/* 1449 */     return act;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _checkTextualNull(DeserializationContext ctxt, String text) throws JsonMappingException {
/* 1462 */     if (_hasTextualNull(text)) {
/* 1463 */       if (!ctxt.isEnabled(MapperFeature.ALLOW_COERCION_OF_SCALARS)) {
/* 1464 */         _reportFailedNullCoerce(ctxt, true, (Enum<?>)MapperFeature.ALLOW_COERCION_OF_SCALARS, "String \"null\"");
/*      */       }
/* 1466 */       return true;
/*      */     } 
/* 1468 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object _coerceIntegral(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 1490 */     int feats = ctxt.getDeserializationFeatures();
/* 1491 */     if (DeserializationFeature.USE_BIG_INTEGER_FOR_INTS.enabledIn(feats)) {
/* 1492 */       return p.getBigIntegerValue();
/*      */     }
/* 1494 */     if (DeserializationFeature.USE_LONG_FOR_INTS.enabledIn(feats)) {
/* 1495 */       return Long.valueOf(p.getLongValue());
/*      */     }
/* 1497 */     return p.getNumberValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void _verifyNullForPrimitive(DeserializationContext ctxt) throws JsonMappingException {
/* 1510 */     if (ctxt.isEnabled(DeserializationFeature.FAIL_ON_NULL_FOR_PRIMITIVES)) {
/* 1511 */       ctxt.reportInputMismatch(this, "Cannot coerce `null` to %s (disable `DeserializationFeature.FAIL_ON_NULL_FOR_PRIMITIVES` to allow)", new Object[] {
/*      */             
/* 1513 */             _coercedTypeDesc()
/*      */           });
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void _verifyNullForPrimitiveCoercion(DeserializationContext ctxt, String str) throws JsonMappingException {
/*      */     DeserializationFeature deserializationFeature;
/*      */     boolean enable;
/* 1530 */     if (!ctxt.isEnabled(MapperFeature.ALLOW_COERCION_OF_SCALARS)) {
/* 1531 */       MapperFeature mapperFeature = MapperFeature.ALLOW_COERCION_OF_SCALARS;
/* 1532 */       enable = true;
/* 1533 */     } else if (ctxt.isEnabled(DeserializationFeature.FAIL_ON_NULL_FOR_PRIMITIVES)) {
/* 1534 */       deserializationFeature = DeserializationFeature.FAIL_ON_NULL_FOR_PRIMITIVES;
/* 1535 */       enable = false;
/*      */     } else {
/*      */       return;
/*      */     } 
/* 1539 */     String strDesc = str.isEmpty() ? "empty String (\"\")" : String.format("String \"%s\"", new Object[] { str });
/* 1540 */     _reportFailedNullCoerce(ctxt, enable, (Enum<?>)deserializationFeature, strDesc);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _reportFailedNullCoerce(DeserializationContext ctxt, boolean state, Enum<?> feature, String inputDesc) throws JsonMappingException {
/* 1546 */     String enableDesc = state ? "enable" : "disable";
/* 1547 */     ctxt.reportInputMismatch(this, "Cannot coerce %s to Null value as %s (%s `%s.%s` to allow)", new Object[] { inputDesc, 
/* 1548 */           _coercedTypeDesc(), enableDesc, feature.getDeclaringClass().getSimpleName(), feature.name() });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String _coercedTypeDesc() {
/*      */     boolean structured;
/*      */     String typeDesc;
/* 1564 */     JavaType t = getValueType();
/* 1565 */     if (t != null && !t.isPrimitive()) {
/* 1566 */       structured = (t.isContainerType() || t.isReferenceType());
/* 1567 */       typeDesc = ClassUtil.getTypeDescription(t);
/*      */     } else {
/* 1569 */       Class<?> cls = handledType();
/*      */       
/* 1571 */       structured = (cls.isArray() || Collection.class.isAssignableFrom(cls) || Map.class.isAssignableFrom(cls));
/* 1572 */       typeDesc = ClassUtil.getClassDescription(cls);
/*      */     } 
/* 1574 */     if (structured) {
/* 1575 */       return "element of " + typeDesc;
/*      */     }
/* 1577 */     return typeDesc + " value";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected boolean _parseBooleanFromInt(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 1594 */     _verifyNumberForScalarCoercion(ctxt, p);
/*      */ 
/*      */     
/* 1597 */     return !"0".equals(p.getText());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected void _verifyStringForScalarCoercion(DeserializationContext ctxt, String str) throws JsonMappingException {
/* 1606 */     MapperFeature feat = MapperFeature.ALLOW_COERCION_OF_SCALARS;
/* 1607 */     if (!ctxt.isEnabled(feat)) {
/* 1608 */       ctxt.reportInputMismatch(this, "Cannot coerce String \"%s\" to %s (enable `%s.%s` to allow)", new Object[] { str, 
/* 1609 */             _coercedTypeDesc(), feat.getDeclaringClass().getSimpleName(), feat.name() });
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected Object _coerceEmptyString(DeserializationContext ctxt, boolean isPrimitive) throws JsonMappingException {
/*      */     DeserializationFeature deserializationFeature;
/*      */     boolean enable;
/* 1624 */     if (!ctxt.isEnabled(MapperFeature.ALLOW_COERCION_OF_SCALARS)) {
/* 1625 */       MapperFeature mapperFeature = MapperFeature.ALLOW_COERCION_OF_SCALARS;
/* 1626 */       enable = true;
/* 1627 */     } else if (isPrimitive && ctxt.isEnabled(DeserializationFeature.FAIL_ON_NULL_FOR_PRIMITIVES)) {
/* 1628 */       deserializationFeature = DeserializationFeature.FAIL_ON_NULL_FOR_PRIMITIVES;
/* 1629 */       enable = false;
/*      */     } else {
/* 1631 */       return getNullValue(ctxt);
/*      */     } 
/* 1633 */     _reportFailedNullCoerce(ctxt, enable, (Enum<?>)deserializationFeature, "empty String (\"\")");
/* 1634 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected void _failDoubleToIntCoercion(JsonParser p, DeserializationContext ctxt, String type) throws IOException {
/* 1641 */     ctxt.reportInputMismatch(handledType(), "Cannot coerce a floating-point value ('%s') into %s (enable `DeserializationFeature.ACCEPT_FLOAT_AS_INT` to allow)", new Object[] { p
/*      */           
/* 1643 */           .getValueAsString(), type });
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected final void _verifyNullForScalarCoercion(DeserializationContext ctxt, String str) throws JsonMappingException {
/* 1649 */     if (!ctxt.isEnabled(MapperFeature.ALLOW_COERCION_OF_SCALARS)) {
/* 1650 */       String strDesc = str.isEmpty() ? "empty String (\"\")" : String.format("String \"%s\"", new Object[] { str });
/* 1651 */       _reportFailedNullCoerce(ctxt, true, (Enum<?>)MapperFeature.ALLOW_COERCION_OF_SCALARS, strDesc);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected void _verifyNumberForScalarCoercion(DeserializationContext ctxt, JsonParser p) throws IOException {
/* 1658 */     MapperFeature feat = MapperFeature.ALLOW_COERCION_OF_SCALARS;
/* 1659 */     if (!ctxt.isEnabled(feat)) {
/*      */ 
/*      */       
/* 1662 */       String valueDesc = p.getText();
/* 1663 */       ctxt.reportInputMismatch(this, "Cannot coerce Number (%s) to %s (enable `%s.%s` to allow)", new Object[] { valueDesc, 
/* 1664 */             _coercedTypeDesc(), feat.getDeclaringClass().getSimpleName(), feat.name() });
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected Object _coerceNullToken(DeserializationContext ctxt, boolean isPrimitive) throws JsonMappingException {
/* 1671 */     if (isPrimitive) {
/* 1672 */       _verifyNullForPrimitive(ctxt);
/*      */     }
/* 1674 */     return getNullValue(ctxt);
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   protected Object _coerceTextualNull(DeserializationContext ctxt, boolean isPrimitive) throws JsonMappingException {
/* 1679 */     if (!ctxt.isEnabled(MapperFeature.ALLOW_COERCION_OF_SCALARS)) {
/* 1680 */       _reportFailedNullCoerce(ctxt, true, (Enum<?>)MapperFeature.ALLOW_COERCION_OF_SCALARS, "String \"null\"");
/*      */     }
/* 1682 */     return getNullValue(ctxt);
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   protected boolean _isEmptyOrTextualNull(String value) {
/* 1687 */     return (value.isEmpty() || "null".equals(value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonDeserializer<Object> findDeserializer(DeserializationContext ctxt, JavaType type, BeanProperty property) throws JsonMappingException {
/* 1709 */     return ctxt.findContextualValueDeserializer(type, property);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final boolean _isIntNumber(String text) {
/* 1721 */     int len = text.length();
/* 1722 */     if (len > 0) {
/* 1723 */       int i; char c = text.charAt(0);
/*      */ 
/*      */ 
/*      */       
/* 1727 */       if (c == '-' || c == '+') {
/* 1728 */         if (len == 1) {
/* 1729 */           return false;
/*      */         }
/* 1731 */         i = 1;
/*      */       } else {
/* 1733 */         i = 0;
/*      */       } 
/*      */       
/* 1736 */       for (; i < len; i++) {
/* 1737 */         int ch = text.charAt(i);
/* 1738 */         if (ch > 57 || ch < 48) {
/* 1739 */           return false;
/*      */         }
/*      */       } 
/* 1742 */       return true;
/*      */     } 
/* 1744 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonDeserializer<?> findConvertingContentDeserializer(DeserializationContext ctxt, BeanProperty prop, JsonDeserializer<?> existingDeserializer) throws JsonMappingException {
/* 1767 */     AnnotationIntrospector intr = ctxt.getAnnotationIntrospector();
/* 1768 */     if (_neitherNull(intr, prop)) {
/* 1769 */       AnnotatedMember member = prop.getMember();
/* 1770 */       if (member != null) {
/* 1771 */         Object convDef = intr.findDeserializationContentConverter(member);
/* 1772 */         if (convDef != null) {
/* 1773 */           Converter<Object, Object> conv = ctxt.converterInstance((Annotated)prop.getMember(), convDef);
/* 1774 */           JavaType delegateType = conv.getInputType(ctxt.getTypeFactory());
/* 1775 */           if (existingDeserializer == null) {
/* 1776 */             existingDeserializer = ctxt.findContextualValueDeserializer(delegateType, prop);
/*      */           }
/* 1778 */           return new StdDelegatingDeserializer(conv, delegateType, existingDeserializer);
/*      */         } 
/*      */       } 
/*      */     } 
/* 1782 */     return existingDeserializer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonFormat.Value findFormatOverrides(DeserializationContext ctxt, BeanProperty prop, Class<?> typeForDefaults) {
/* 1803 */     if (prop != null) {
/* 1804 */       return prop.findPropertyFormat((MapperConfig)ctxt.getConfig(), typeForDefaults);
/*      */     }
/*      */     
/* 1807 */     return ctxt.getDefaultPropertyFormat(typeForDefaults);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Boolean findFormatFeature(DeserializationContext ctxt, BeanProperty prop, Class<?> typeForDefaults, JsonFormat.Feature feat) {
/* 1823 */     JsonFormat.Value format = findFormatOverrides(ctxt, prop, typeForDefaults);
/* 1824 */     if (format != null) {
/* 1825 */       return format.getFeature(feat);
/*      */     }
/* 1827 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final NullValueProvider findValueNullProvider(DeserializationContext ctxt, SettableBeanProperty prop, PropertyMetadata propMetadata) throws JsonMappingException {
/* 1841 */     if (prop != null) {
/* 1842 */       return _findNullProvider(ctxt, (BeanProperty)prop, propMetadata.getValueNulls(), prop
/* 1843 */           .getValueDeserializer());
/*      */     }
/* 1845 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected NullValueProvider findContentNullProvider(DeserializationContext ctxt, BeanProperty prop, JsonDeserializer<?> valueDeser) throws JsonMappingException {
/* 1860 */     Nulls nulls = findContentNullStyle(ctxt, prop);
/* 1861 */     if (nulls == Nulls.SKIP) {
/* 1862 */       return (NullValueProvider)NullsConstantProvider.skipper();
/*      */     }
/*      */ 
/*      */     
/* 1866 */     if (nulls == Nulls.FAIL) {
/* 1867 */       if (prop == null) {
/* 1868 */         JavaType type = ctxt.constructType(valueDeser.handledType());
/*      */         
/* 1870 */         if (type.isContainerType()) {
/* 1871 */           type = type.getContentType();
/*      */         }
/* 1873 */         return (NullValueProvider)NullsFailProvider.constructForRootValue(type);
/*      */       } 
/* 1875 */       return (NullValueProvider)NullsFailProvider.constructForProperty(prop, prop.getType().getContentType());
/*      */     } 
/*      */     
/* 1878 */     NullValueProvider prov = _findNullProvider(ctxt, prop, nulls, valueDeser);
/* 1879 */     if (prov != null) {
/* 1880 */       return prov;
/*      */     }
/* 1882 */     return (NullValueProvider)valueDeser;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected Nulls findContentNullStyle(DeserializationContext ctxt, BeanProperty prop) throws JsonMappingException {
/* 1888 */     if (prop != null) {
/* 1889 */       return prop.getMetadata().getContentNulls();
/*      */     }
/* 1891 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final NullValueProvider _findNullProvider(DeserializationContext ctxt, BeanProperty prop, Nulls nulls, JsonDeserializer<?> valueDeser) throws JsonMappingException {
/* 1899 */     if (nulls == Nulls.FAIL) {
/* 1900 */       if (prop == null) {
/* 1901 */         return (NullValueProvider)NullsFailProvider.constructForRootValue(ctxt.constructType(valueDeser.handledType()));
/*      */       }
/* 1903 */       return (NullValueProvider)NullsFailProvider.constructForProperty(prop);
/*      */     } 
/* 1905 */     if (nulls == Nulls.AS_EMPTY) {
/*      */ 
/*      */       
/* 1908 */       if (valueDeser == null) {
/* 1909 */         return null;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1915 */       if (valueDeser instanceof BeanDeserializerBase) {
/* 1916 */         ValueInstantiator vi = ((BeanDeserializerBase)valueDeser).getValueInstantiator();
/* 1917 */         if (!vi.canCreateUsingDefault()) {
/* 1918 */           JavaType type = prop.getType();
/* 1919 */           ctxt.reportBadDefinition(type, 
/* 1920 */               String.format("Cannot create empty instance of %s, no default Creator", new Object[] { type }));
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/* 1925 */       AccessPattern access = valueDeser.getEmptyAccessPattern();
/* 1926 */       if (access == AccessPattern.ALWAYS_NULL) {
/* 1927 */         return (NullValueProvider)NullsConstantProvider.nuller();
/*      */       }
/* 1929 */       if (access == AccessPattern.CONSTANT) {
/* 1930 */         return (NullValueProvider)NullsConstantProvider.forValue(valueDeser.getEmptyValue(ctxt));
/*      */       }
/*      */       
/* 1933 */       return (NullValueProvider)new NullsAsEmptyProvider(valueDeser);
/*      */     } 
/* 1935 */     if (nulls == Nulls.SKIP) {
/* 1936 */       return (NullValueProvider)NullsConstantProvider.skipper();
/*      */     }
/* 1938 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   protected CoercionAction _findCoercionFromEmptyString(DeserializationContext ctxt) {
/* 1943 */     return ctxt.findCoercionAction(logicalType(), handledType(), CoercionInputShape.EmptyString);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected CoercionAction _findCoercionFromEmptyArray(DeserializationContext ctxt) {
/* 1949 */     return ctxt.findCoercionAction(logicalType(), handledType(), CoercionInputShape.EmptyArray);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected CoercionAction _findCoercionFromBlankString(DeserializationContext ctxt) {
/* 1955 */     return ctxt.findCoercionFromBlankString(logicalType(), handledType(), CoercionAction.Fail);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void handleUnknownProperty(JsonParser p, DeserializationContext ctxt, Object<?> instanceOrClass, String propName) throws IOException {
/* 1983 */     if (instanceOrClass == null) {
/* 1984 */       instanceOrClass = (Object<?>)handledType();
/*      */     }
/*      */     
/* 1987 */     if (ctxt.handleUnknownProperty(p, this, instanceOrClass, propName)) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1993 */     p.skipChildren();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void handleMissingEndArrayForSingle(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 1999 */     ctxt.reportWrongTokenException(this, JsonToken.END_ARRAY, "Attempted to unwrap '%s' value from an array (with `DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS`) but it contains more than one value", new Object[] {
/*      */           
/* 2001 */           handledType().getName()
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object handleNestedArrayForSingle(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 2014 */     String msg = String.format("Cannot deserialize instance of %s out of %s token: nested Arrays not allowed with %s", new Object[] {
/*      */           
/* 2016 */           ClassUtil.nameOf(this._valueClass), JsonToken.START_ARRAY, "DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS"
/*      */         });
/* 2018 */     return ctxt.handleUnexpectedToken(getValueType(ctxt), p.currentToken(), p, msg, new Object[0]);
/*      */   }
/*      */ 
/*      */   
/*      */   protected void _verifyEndArrayForSingle(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 2023 */     JsonToken t = p.nextToken();
/* 2024 */     if (t != JsonToken.END_ARRAY) {
/* 2025 */       handleMissingEndArrayForSingle(p, ctxt);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static final boolean _neitherNull(Object a, Object b) {
/* 2039 */     return (a != null && b != null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final boolean _byteOverflow(int value) {
/* 2048 */     return (value < -128 || value > 255);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final boolean _shortOverflow(int value) {
/* 2055 */     return (value < -32768 || value > 32767);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final boolean _intOverflow(long value) {
/* 2062 */     return (value < -2147483648L || value > 2147483647L);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Number _nonNullNumber(Number n) {
/* 2069 */     if (n == null) {
/* 2070 */       n = Integer.valueOf(0);
/*      */     }
/* 2072 */     return n;
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.12.7.1.jar!\com\fasterxml\jackson\databind\deser\std\StdDeserializer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */