/*     */ package com.fasterxml.jackson.databind.deser.std;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.MapperFeature;
/*     */ import com.fasterxml.jackson.databind.deser.ContextualDeserializer;
/*     */ import com.fasterxml.jackson.databind.deser.SettableBeanProperty;
/*     */ import com.fasterxml.jackson.databind.deser.ValueInstantiator;
/*     */ import com.fasterxml.jackson.databind.deser.impl.PropertyBasedCreator;
/*     */ import com.fasterxml.jackson.databind.deser.impl.PropertyValueBuffer;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedMethod;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*     */ import com.fasterxml.jackson.databind.type.LogicalType;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class FactoryBasedEnumDeserializer
/*     */   extends StdDeserializer<Object>
/*     */   implements ContextualDeserializer
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected final JavaType _inputType;
/*     */   protected final boolean _hasArgs;
/*     */   protected final AnnotatedMethod _factory;
/*     */   protected final JsonDeserializer<?> _deser;
/*     */   protected final ValueInstantiator _valueInstantiator;
/*     */   protected final SettableBeanProperty[] _creatorProps;
/*     */   private transient PropertyBasedCreator _propCreator;
/*     */   
/*     */   public FactoryBasedEnumDeserializer(Class<?> cls, AnnotatedMethod f, JavaType paramType, ValueInstantiator valueInstantiator, SettableBeanProperty[] creatorProps) {
/*  50 */     super(cls);
/*  51 */     this._factory = f;
/*  52 */     this._hasArgs = true;
/*     */     
/*  54 */     this._inputType = paramType.hasRawClass(String.class) ? null : paramType;
/*  55 */     this._deser = null;
/*  56 */     this._valueInstantiator = valueInstantiator;
/*  57 */     this._creatorProps = creatorProps;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FactoryBasedEnumDeserializer(Class<?> cls, AnnotatedMethod f) {
/*  65 */     super(cls);
/*  66 */     this._factory = f;
/*  67 */     this._hasArgs = false;
/*  68 */     this._inputType = null;
/*  69 */     this._deser = null;
/*  70 */     this._valueInstantiator = null;
/*  71 */     this._creatorProps = null;
/*     */   }
/*     */ 
/*     */   
/*     */   protected FactoryBasedEnumDeserializer(FactoryBasedEnumDeserializer base, JsonDeserializer<?> deser) {
/*  76 */     super(base._valueClass);
/*  77 */     this._inputType = base._inputType;
/*  78 */     this._factory = base._factory;
/*  79 */     this._hasArgs = base._hasArgs;
/*  80 */     this._valueInstantiator = base._valueInstantiator;
/*  81 */     this._creatorProps = base._creatorProps;
/*     */     
/*  83 */     this._deser = deser;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonDeserializer<?> createContextual(DeserializationContext ctxt, BeanProperty property) throws JsonMappingException {
/*  91 */     if (this._deser == null && this._inputType != null && this._creatorProps == null) {
/*  92 */       return new FactoryBasedEnumDeserializer(this, ctxt
/*  93 */           .findContextualValueDeserializer(this._inputType, property));
/*     */     }
/*  95 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Boolean supportsUpdate(DeserializationConfig config) {
/* 100 */     return Boolean.FALSE;
/*     */   }
/*     */ 
/*     */   
/*     */   public LogicalType logicalType() {
/* 105 */     return LogicalType.Enum;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCachable() {
/* 110 */     return true;
/*     */   }
/*     */   public ValueInstantiator getValueInstantiator() {
/* 113 */     return this._valueInstantiator;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/*     */     Object value;
/* 119 */     if (this._deser != null) {
/* 120 */       value = this._deser.deserialize(p, ctxt);
/* 121 */     } else if (this._hasArgs) {
/* 122 */       JsonToken curr = p.currentToken();
/*     */ 
/*     */ 
/*     */       
/* 126 */       if (this._creatorProps != null) {
/* 127 */         if (!p.isExpectedStartObjectToken()) {
/* 128 */           JavaType targetType = getValueType(ctxt);
/* 129 */           ctxt.reportInputMismatch(targetType, "Input mismatch reading Enum %s: properties-based `@JsonCreator` (%s) expects JSON Object (JsonToken.START_OBJECT), got JsonToken.%s", new Object[] {
/*     */                 
/* 131 */                 ClassUtil.getTypeDescription(targetType), this._factory, p.currentToken() });
/*     */         } 
/* 133 */         if (this._propCreator == null) {
/* 134 */           this._propCreator = PropertyBasedCreator.construct(ctxt, this._valueInstantiator, this._creatorProps, ctxt
/* 135 */               .isEnabled(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES));
/*     */         }
/* 137 */         p.nextToken();
/* 138 */         return deserializeEnumUsingPropertyBased(p, ctxt, this._propCreator);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 143 */       if (curr == JsonToken.VALUE_STRING || curr == JsonToken.FIELD_NAME) {
/* 144 */         value = p.getText();
/* 145 */       } else if (curr == JsonToken.VALUE_NUMBER_INT) {
/* 146 */         value = p.getNumberValue();
/*     */       } else {
/* 148 */         value = p.getValueAsString();
/*     */       } 
/*     */     } else {
/* 151 */       p.skipChildren();
/*     */       try {
/* 153 */         return this._factory.call();
/* 154 */       } catch (Exception e) {
/* 155 */         Throwable t = ClassUtil.throwRootCauseIfIOE(e);
/* 156 */         return ctxt.handleInstantiationProblem(this._valueClass, null, t);
/*     */       } 
/*     */     } 
/*     */     try {
/* 160 */       return this._factory.callOnWith(this._valueClass, new Object[] { value });
/* 161 */     } catch (Exception e) {
/* 162 */       Throwable t = ClassUtil.throwRootCauseIfIOE(e);
/*     */       
/* 164 */       if (ctxt.isEnabled(DeserializationFeature.READ_UNKNOWN_ENUM_VALUES_AS_NULL) && t instanceof IllegalArgumentException)
/*     */       {
/* 166 */         return null;
/*     */       }
/* 168 */       return ctxt.handleInstantiationProblem(this._valueClass, value, t);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Object deserializeWithType(JsonParser p, DeserializationContext ctxt, TypeDeserializer typeDeserializer) throws IOException {
/* 174 */     if (this._deser == null) {
/* 175 */       return deserialize(p, ctxt);
/*     */     }
/* 177 */     return typeDeserializer.deserializeTypedFromAny(p, ctxt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object deserializeEnumUsingPropertyBased(JsonParser p, DeserializationContext ctxt, PropertyBasedCreator creator) throws IOException {
/* 184 */     PropertyValueBuffer buffer = creator.startBuilding(p, ctxt, null);
/*     */     
/* 186 */     JsonToken t = p.currentToken();
/* 187 */     for (; t == JsonToken.FIELD_NAME; t = p.nextToken()) {
/* 188 */       String propName = p.currentName();
/* 189 */       p.nextToken();
/*     */       
/* 191 */       SettableBeanProperty creatorProp = creator.findCreatorProperty(propName);
/* 192 */       if (!buffer.readIdProperty(propName) || creatorProp != null)
/*     */       {
/*     */         
/* 195 */         if (creatorProp != null) {
/* 196 */           buffer.assignParameter(creatorProp, _deserializeWithErrorWrapping(p, ctxt, creatorProp));
/*     */         }
/*     */         else {
/*     */           
/* 200 */           p.skipChildren();
/*     */         }  } 
/* 202 */     }  return creator.build(ctxt, buffer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Object _deserializeWithErrorWrapping(JsonParser p, DeserializationContext ctxt, SettableBeanProperty prop) throws IOException {
/*     */     try {
/* 211 */       return prop.deserialize(p, ctxt);
/* 212 */     } catch (Exception e) {
/* 213 */       return wrapAndThrow(e, handledType(), prop.getName(), ctxt);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object wrapAndThrow(Throwable t, Object bean, String fieldName, DeserializationContext ctxt) throws IOException {
/* 220 */     throw JsonMappingException.wrapWithPath(throwOrReturnThrowable(t, ctxt), bean, fieldName);
/*     */   }
/*     */ 
/*     */   
/*     */   private Throwable throwOrReturnThrowable(Throwable t, DeserializationContext ctxt) throws IOException {
/* 225 */     t = ClassUtil.getRootCause(t);
/*     */     
/* 227 */     ClassUtil.throwIfError(t);
/* 228 */     boolean wrap = (ctxt == null || ctxt.isEnabled(DeserializationFeature.WRAP_EXCEPTIONS));
/*     */     
/* 230 */     if (t instanceof IOException) {
/* 231 */       if (!wrap || !(t instanceof com.fasterxml.jackson.core.JsonProcessingException)) {
/* 232 */         throw (IOException)t;
/*     */       }
/* 234 */     } else if (!wrap) {
/* 235 */       ClassUtil.throwIfRTE(t);
/*     */     } 
/* 237 */     return t;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.12.7.1.jar!\com\fasterxml\jackson\databind\deser\std\FactoryBasedEnumDeserializer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */