package architectury_inject_bendylib_common_6029c09d5b264ea28f5149deb3bd9cac_ae8d452df485c06495f579f3b23986c148e2a141b9014864221eb541d52584e5bendylib213test2devjar;

public final class PlatformMethods {
  public static String getCurrentTarget() {
    return "forge";
  }
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\bendy-lib-forge-2.1.3-test2.jar!\architectury_inject_bendylib_common_6029c09d5b264ea28f5149deb3bd9cac_ae8d452df485c06495f579f3b23986c148e2a141b9014864221eb541d52584e5bendylib213test2devjar\PlatformMethods.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */