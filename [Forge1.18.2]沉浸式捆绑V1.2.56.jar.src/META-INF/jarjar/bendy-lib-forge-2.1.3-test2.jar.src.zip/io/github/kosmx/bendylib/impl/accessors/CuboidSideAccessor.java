package io.github.kosmx.bendylib.impl.accessors;

import net.minecraft.client.model.geom.ModelPart;

public interface CuboidSideAccessor {
  ModelPart.Polygon[] getSides();
  
  void setSides(ModelPart.Polygon[] paramArrayOfPolygon);
  
  void resetSides();
  
  void doSideSwapping();
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\bendy-lib-forge-2.1.3-test2.jar!\io\github\kosmx\bendylib\impl\accessors\CuboidSideAccessor.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */