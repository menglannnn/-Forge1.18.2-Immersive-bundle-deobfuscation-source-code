/*    */ package io.github.kosmx.bendylib.impl;
/*    */ 
/*    */ import com.mojang.math.Vector3f;
/*    */ 
/*    */ public class Vertex
/*    */   implements IVertex
/*    */ {
/*    */   protected final Vector3f pos;
/*    */   public final float u;
/*    */   public final float v;
/*    */   
/*    */   public Vertex(float x, float y, float z, float u, float v) {
/* 13 */     this(new Vector3f(x, y, z), u, v);
/*    */   }
/*    */   public Vertex(Vector3f pos, float u, float v) {
/* 16 */     this.pos = pos;
/* 17 */     this.u = u;
/* 18 */     this.v = v;
/*    */   }
/*    */ 
/*    */   
/*    */   public Vector3f getPos() {
/* 23 */     return this.pos;
/*    */   }
/*    */ 
/*    */   
/*    */   public float getU() {
/* 28 */     return this.u;
/*    */   }
/*    */ 
/*    */   
/*    */   public float getV() {
/* 33 */     return this.v;
/*    */   }
/*    */ 
/*    */   
/*    */   public IVertex remap(float u, float v) {
/* 38 */     return new Vertex(this.pos, u, v);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\bendy-lib-forge-2.1.3-test2.jar!\io\github\kosmx\bendylib\impl\Vertex.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */