/*    */ package io.github.kosmx.bendylib;
/*    */ 
/*    */ import com.mojang.blaze3d.vertex.PoseStack;
/*    */ import com.mojang.blaze3d.vertex.VertexConsumer;
/*    */ import io.github.kosmx.bendylib.impl.ICuboid;
/*    */ import it.unimi.dsi.fastutil.objects.ObjectArrayList;
/*    */ import it.unimi.dsi.fastutil.objects.ObjectList;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import javax.annotation.Nullable;
/*    */ import net.minecraft.client.model.geom.ModelPart;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class MutableModelPart
/*    */   extends ModelPart
/*    */ {
/*    */   @Nullable
/*    */   @Deprecated
/* 22 */   private MutableModelPart last = null;
/*    */ 
/*    */ 
/*    */   
/* 26 */   protected final ObjectList<ICuboid> iCuboids = (ObjectList<ICuboid>)new ObjectArrayList();
/*    */   
/*    */   public MutableModelPart(List<ModelPart.Cube> cuboids, Map<String, ModelPart> children) {
/* 29 */     super(cuboids, children);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void m_104306_(PoseStack matrices, VertexConsumer vertices, int light, int overlay, float red, float green, float blue, float alpha) {
/* 35 */     super.m_104306_(matrices, vertices, light, overlay, red, green, blue, alpha);
/* 36 */     if (!this.iCuboids.isEmpty()) {
/* 37 */       matrices.m_85836_();
/* 38 */       m_104299_(matrices);
/* 39 */       renderICuboids(matrices.m_85850_(), vertices, light, overlay, red, green, blue, alpha);
/* 40 */       matrices.m_85849_();
/*    */     } 
/*    */   }
/*    */   
/*    */   protected void renderICuboids(PoseStack.Pose matrices, VertexConsumer vertexConsumer, int light, int overlay, float red, float green, float blue, float alpha) {
/* 45 */     this.iCuboids.forEach(cuboid -> cuboid.render(matrices, vertexConsumer, red, green, blue, alpha, light, overlay));
/*    */   }
/*    */   
/*    */   public void addICuboid(ICuboid cuboid) {
/* 49 */     this.iCuboids.add(cuboid);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\bendy-lib-forge-2.1.3-test2.jar!\io\github\kosmx\bendylib\MutableModelPart.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */