/*    */ package io.github.kosmx.bendylib.forge;
/*    */ 
/*    */ import io.github.kosmx.bendylib.PlatformUtils;
/*    */ import io.github.kosmx.bendylib.compat.tr7zw.TDSkinCompat;
/*    */ import net.minecraftforge.eventbus.api.SubscribeEvent;
/*    */ import net.minecraftforge.fml.common.Mod;
/*    */ import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
/*    */ import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
/*    */ import net.minecraftforge.fml.loading.FMLLoader;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ @Mod("bendylib")
/*    */ public class ForgeModInterface {
/* 15 */   public static Logger LOGGER = LoggerFactory.getLogger("bendy-lib");
/*    */   public ForgeModInterface() {
/* 17 */     if (!FMLLoader.getDist().isClient()) {
/* 18 */       System.out.println("[bendy-lib] You're loading a client-only mod on server-side");
/* 19 */       System.out.println("[bendy-lib] Most likely it won't be a problem");
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   @EventBusSubscriber(modid = "bendylib", bus = Mod.EventBusSubscriber.Bus.MOD)
/*    */   public static class ClientModEvents
/*    */   {
/*    */     @SubscribeEvent
/*    */     public static void onClientSetup(FMLClientSetupEvent event) {
/* 29 */       if (PlatformUtils.isSkinLayersPresent())
/*    */         try {
/* 31 */           TDSkinCompat.init(ForgeModInterface.LOGGER);
/* 32 */         } catch (NoClassDefFoundError|ClassNotFoundException e) {
/* 33 */           ForgeModInterface.LOGGER.error("Failed to initialize 3D Skin Layers compatibility");
/*    */         }  
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\bendy-lib-forge-2.1.3-test2.jar!\io\github\kosmx\bendylib\forge\ForgeModInterface.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */