/*    */ package io.github.kosmx.bendylib.impl;
/*    */ 
/*    */ import com.mojang.math.Vector3f;
/*    */ import net.minecraft.client.model.geom.ModelPart;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface IVertex
/*    */ {
/*    */   Vector3f getPos();
/*    */   
/*    */   float getU();
/*    */   
/*    */   float getV();
/*    */   
/*    */   IVertex remap(float paramFloat1, float paramFloat2);
/*    */   
/*    */   default ModelPart.Vertex toMojVertex() {
/* 39 */     return new ModelPart.Vertex(getPos(), getU(), getV());
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\bendy-lib-forge-2.1.3-test2.jar!\io\github\kosmx\bendylib\impl\IVertex.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */