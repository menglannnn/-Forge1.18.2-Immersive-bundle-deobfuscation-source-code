/*     */ package io.github.kosmx.bendylib.impl;
/*     */ 
/*     */ import com.mojang.blaze3d.vertex.PoseStack;
/*     */ import com.mojang.blaze3d.vertex.VertexConsumer;
/*     */ import com.mojang.math.Matrix4f;
/*     */ import com.mojang.math.Vector3f;
/*     */ import com.mojang.math.Vector4f;
/*     */ import io.github.kosmx.bendylib.ICuboidBuilder;
/*     */ import io.github.kosmx.bendylib.impl.accessors.DirectionMutator;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.function.Consumer;
/*     */ import net.minecraft.client.model.geom.ModelPart;
/*     */ import net.minecraft.core.Direction;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BendableCuboid
/*     */   implements ICuboid, IBendable, IterableRePos
/*     */ {
/*     */   protected final Quad[] sides;
/*     */   protected final RememberingPos[] positions;
/*     */   protected Matrix4f lastPosMatrix;
/*     */   public final float minX;
/*     */   public final float minY;
/*     */   public final float minZ;
/*     */   public final float maxX;
/*     */   public final float maxY;
/*     */   public final float maxZ;
/*     */   protected final float fixX;
/*     */   protected final float fixY;
/*     */   protected final float fixZ;
/*     */   protected final Direction direction;
/*     */   protected final IBendable.Plane basePlane;
/*     */   protected final IBendable.Plane otherPlane;
/*     */   protected final float fullSize;
/*     */   private float bend;
/*     */   private float bendAxis;
/*     */   
/*     */   protected BendableCuboid(Quad[] sides, RememberingPos[] positions, float minX, float minY, float minZ, float maxX, float maxY, float maxZ, float fixX, float fixY, float fixZ, Direction direction, IBendable.Plane basePlane, IBendable.Plane otherPlane, float fullSize) {
/*  48 */     this.sides = sides;
/*  49 */     this.positions = positions;
/*  50 */     this.minX = minX;
/*  51 */     this.minY = minY;
/*  52 */     this.minZ = minZ;
/*  53 */     this.maxX = maxX;
/*  54 */     this.maxY = maxY;
/*  55 */     this.maxZ = maxZ;
/*  56 */     this.fixX = fixX;
/*  57 */     this.fixY = fixY;
/*  58 */     this.fixZ = fixZ;
/*     */     
/*  60 */     this.direction = direction;
/*  61 */     this.basePlane = basePlane;
/*  62 */     this.otherPlane = otherPlane;
/*  63 */     this.fullSize = fullSize;
/*     */     
/*  65 */     applyBend(0.0F, 0.0F);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Matrix4f applyBend(float bendAxis, float bendValue) {
/*  76 */     this.bend = bendValue; this.bendAxis = bendAxis;
/*  77 */     return applyBend(bendAxis, bendValue, this);
/*     */   }
/*     */ 
/*     */   
/*     */   public Direction getBendDirection() {
/*  82 */     return this.direction;
/*     */   }
/*     */ 
/*     */   
/*     */   public float getBendX() {
/*  87 */     return this.fixX;
/*     */   }
/*     */ 
/*     */   
/*     */   public float getBendY() {
/*  92 */     return this.fixY;
/*     */   }
/*     */ 
/*     */   
/*     */   public float getBendZ() {
/*  97 */     return this.fixZ;
/*     */   }
/*     */ 
/*     */   
/*     */   public IBendable.Plane getBasePlane() {
/* 102 */     return this.basePlane;
/*     */   }
/*     */ 
/*     */   
/*     */   public IBendable.Plane getOtherSidePlane() {
/* 107 */     return this.otherPlane;
/*     */   }
/*     */ 
/*     */   
/*     */   public float bendHeight() {
/* 112 */     return this.fullSize;
/*     */   }
/*     */ 
/*     */   
/*     */   public void iteratePositions(Consumer<IPosWithOrigin> consumer) {
/* 117 */     for (IPosWithOrigin pos : this.positions) {
/* 118 */       consumer.accept(pos);
/*     */     }
/*     */   }
/*     */   
/*     */   public float getBend() {
/* 123 */     return this.bend;
/*     */   }
/*     */   
/*     */   public float getBendAxis() {
/* 127 */     return this.bendAxis;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Builder
/*     */     implements ICuboidBuilder<BendableCuboid>
/*     */   {
/*     */     public Direction direction;
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setDirection(Direction d) {
/* 140 */       this.direction = d;
/* 141 */       return this;
/*     */     }
/*     */     
/*     */     public BendableCuboid build(ICuboidBuilder.Data data, BendableCuboid.BuildableBendable builder) {
/* 145 */       ArrayList<BendableCuboid.Quad> planes = new ArrayList<>();
/* 146 */       HashMap<Vector3f, RememberingPos> positions = new HashMap<>();
/* 147 */       float minX = data.x, minY = data.y, minZ = data.z, maxX = data.x + data.sizeX, maxY = data.y + data.sizeY, maxZ = data.z + data.sizeZ;
/* 148 */       float pminX = data.x - data.extraX, pminY = data.y - data.extraY, pminZ = data.z - data.extraZ, pmaxX = maxX + data.extraX, pmaxY = maxY + data.extraY, pmaxZ = maxZ + data.extraZ;
/* 149 */       if (data.mirror) {
/* 150 */         float tmp = pminX;
/* 151 */         pminX = pmaxX;
/* 152 */         pmaxX = tmp;
/*     */       } 
/*     */ 
/*     */       
/* 156 */       Vector3f vertex1 = new Vector3f(pminX, pminY, pminZ);
/* 157 */       Vector3f vertex2 = new Vector3f(pmaxX, pminY, pminZ);
/* 158 */       Vector3f vertex3 = new Vector3f(pmaxX, pmaxY, pminZ);
/* 159 */       Vector3f vertex4 = new Vector3f(pminX, pmaxY, pminZ);
/* 160 */       Vector3f vertex5 = new Vector3f(pminX, pminY, pmaxZ);
/* 161 */       Vector3f vertex6 = new Vector3f(pmaxX, pminY, pmaxZ);
/* 162 */       Vector3f vertex7 = new Vector3f(pmaxX, pmaxY, pmaxZ);
/* 163 */       Vector3f vertex8 = new Vector3f(pminX, pmaxY, pmaxZ);
/*     */       
/* 165 */       int j = data.u;
/* 166 */       int k = (int)(data.u + data.sizeZ);
/* 167 */       int l = (int)(data.u + data.sizeZ + data.sizeX);
/* 168 */       int m = (int)(data.u + data.sizeZ + data.sizeX + data.sizeX);
/* 169 */       int n = (int)(data.u + data.sizeZ + data.sizeX + data.sizeZ);
/* 170 */       int o = (int)(data.u + data.sizeZ + data.sizeX + data.sizeZ + data.sizeX);
/* 171 */       int p = data.v;
/* 172 */       int q = (int)(data.v + data.sizeZ);
/* 173 */       int r = (int)(data.v + data.sizeZ + data.sizeY);
/* 174 */       createAndAddQuads(planes, positions, new Vector3f[] { vertex6, vertex5, vertex2 }, k, p, l, q, data.textureWidth, data.textureHeight, data.mirror, data);
/* 175 */       createAndAddQuads(planes, positions, new Vector3f[] { vertex3, vertex4, vertex7 }, l, q, m, p, data.textureWidth, data.textureHeight, data.mirror, data);
/* 176 */       createAndAddQuads(planes, positions, new Vector3f[] { vertex1, vertex5, vertex4 }, j, q, k, r, data.textureWidth, data.textureHeight, data.mirror, data);
/* 177 */       createAndAddQuads(planes, positions, new Vector3f[] { vertex2, vertex1, vertex3 }, k, q, l, r, data.textureWidth, data.textureHeight, data.mirror, data);
/* 178 */       createAndAddQuads(planes, positions, new Vector3f[] { vertex6, vertex2, vertex7 }, l, q, n, r, data.textureWidth, data.textureHeight, data.mirror, data);
/* 179 */       createAndAddQuads(planes, positions, new Vector3f[] { vertex5, vertex6, vertex8 }, n, q, o, r, data.textureWidth, data.textureHeight, data.mirror, data);
/*     */       
/* 181 */       IBendable.Plane aPlane = new IBendable.Plane(this.direction.m_122432_(), vertex7);
/* 182 */       IBendable.Plane bPlane = new IBendable.Plane(this.direction.m_122432_(), vertex1);
/* 183 */       boolean bl = (this.direction == Direction.UP || this.direction == Direction.SOUTH || this.direction == Direction.EAST);
/* 184 */       float fullSize = -this.direction.m_122432_().m_122276_(vertex1) + this.direction.m_122432_().m_122276_(vertex7);
/* 185 */       float bendX = (data.sizeX + data.x + data.x) / 2.0F;
/* 186 */       float bendY = (data.sizeY + data.y + data.y) / 2.0F;
/* 187 */       float bendZ = (data.sizeZ + data.z + data.z) / 2.0F;
/* 188 */       return builder.build(planes.<BendableCuboid.Quad>toArray(new BendableCuboid.Quad[0]), (RememberingPos[])positions.values().toArray((Object[])new RememberingPos[0]), minX, minY, minZ, maxX, maxY, maxZ, bendX, bendY, bendZ, this.direction, bl ? aPlane : bPlane, bl ? bPlane : aPlane, fullSize);
/*     */     }
/*     */     
/*     */     public BendableCuboid build(ICuboidBuilder.Data data) {
/* 192 */       return build(data, BendableCuboid::new);
/*     */     }
/*     */ 
/*     */     
/*     */     private void createAndAddQuads(Collection<BendableCuboid.Quad> quads, HashMap<Vector3f, RememberingPos> positions, Vector3f[] edges, int u1, int v1, int u2, int v2, float squishU, float squishV, boolean flip, ICuboidBuilder.Data data) {
/* 197 */       int du = (u2 < u1) ? 1 : -1;
/* 198 */       int dv = (v1 < v2) ? 1 : -1; int localU;
/* 199 */       for (localU = u2; localU != u1; localU += du) {
/* 200 */         int localV; for (localV = v1; localV != v2; localV += dv) {
/* 201 */           int localU2 = localU + du;
/* 202 */           int localV2 = localV + dv;
/* 203 */           RememberingPos rp0 = getOrCreate(positions, transformVector(edges[0].m_122281_(), edges[1].m_122281_(), edges[2].m_122281_(), u2, v1, u1, v2, localU2, localV));
/* 204 */           RememberingPos rp1 = getOrCreate(positions, transformVector(edges[0].m_122281_(), edges[1].m_122281_(), edges[2].m_122281_(), u2, v1, u1, v2, localU2, localV2));
/* 205 */           RememberingPos rp2 = getOrCreate(positions, transformVector(edges[0].m_122281_(), edges[1].m_122281_(), edges[2].m_122281_(), u2, v1, u1, v2, localU, localV2));
/* 206 */           RememberingPos rp3 = getOrCreate(positions, transformVector(edges[0].m_122281_(), edges[1].m_122281_(), edges[2].m_122281_(), u2, v1, u1, v2, localU, localV));
/* 207 */           quads.add(new BendableCuboid.Quad(new RememberingPos[] { rp3, rp0, rp1, rp2 }, localU2, localV, localU, localV2, data.textureWidth, data.textureHeight, data.mirror));
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     Vector3f transformVector(Vector3f pos, Vector3f vectorU, Vector3f vectorV, int u1, int v1, int u2, int v2, int u, int v) {
/* 213 */       vectorU.m_122267_(pos);
/* 214 */       vectorU.m_122261_((u - u1) / (u2 - u1));
/* 215 */       vectorV.m_122267_(pos);
/* 216 */       vectorV.m_122261_((v - v1) / (v2 - v1));
/* 217 */       pos.m_122253_(vectorU);
/* 218 */       pos.m_122253_(vectorV);
/* 219 */       return pos;
/*     */     }
/*     */ 
/*     */     
/*     */     RememberingPos getOrCreate(HashMap<Vector3f, RememberingPos> positions, Vector3f pos) {
/* 224 */       if (!positions.containsKey(pos)) {
/* 225 */         positions.put(pos, new RememberingPos(pos));
/*     */       }
/* 227 */       return positions.get(pos);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Matrix4f setRotationRad(float axisf, float value) {
/* 245 */     return applyBend(axisf, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Matrix4f setRotationDeg(float axis, float val) {
/* 257 */     return applyBend(axis * 0.0174533F, val * 0.0174533F);
/*     */   }
/*     */ 
/*     */   
/*     */   public void render(PoseStack.Pose matrices, VertexConsumer vertexConsumer, float red, float green, float blue, float alpha, int light, int overlay) {
/* 262 */     for (Quad quad : this.sides) {
/* 263 */       quad.render(matrices, vertexConsumer, light, overlay, red, green, blue, alpha);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void copyState(ICuboid other) {
/* 269 */     if (other instanceof BendableCuboid) { BendableCuboid b = (BendableCuboid)other;
/* 270 */       applyBend(b.bendAxis, b.bend); }
/*     */   
/*     */   } @FunctionalInterface
/*     */   public static interface BuildableBendable {
/*     */     BendableCuboid build(BendableCuboid.Quad[] param1ArrayOfQuad, RememberingPos[] param1ArrayOfRememberingPos, float param1Float1, float param1Float2, float param1Float3, float param1Float4, float param1Float5, float param1Float6, float param1Float7, float param1Float8, float param1Float9, Direction param1Direction, IBendable.Plane param1Plane1, IBendable.Plane param1Plane2, float param1Float10); } public Matrix4f getLastPosMatrix() {
/* 275 */     return this.lastPosMatrix.m_27658_();
/*     */   }
/*     */   
/*     */   public static class Quad { public final IVertex[] vertices;
/*     */     final float u1;
/*     */     final float u2;
/*     */     final float v1;
/*     */     final float v2;
/*     */     final float su;
/*     */     final float sv;
/*     */     
/*     */     public Quad(RememberingPos[] vertices, float u1, float v1, float u2, float v2, float squishU, float squishV, boolean flip) {
/* 287 */       this.u1 = u1; this.u2 = u2; this.v1 = v1; this.v2 = v2; this.su = squishU; this.sv = squishV;
/* 288 */       float f = 0.0F / squishU;
/* 289 */       float g = 0.0F / squishV;
/* 290 */       this.vertices = new IVertex[4];
/* 291 */       this.vertices[0] = new RepositionableVertex(u2 / squishU - f, v1 / squishV + g, vertices[0]);
/* 292 */       this.vertices[1] = new RepositionableVertex(u1 / squishU + f, v1 / squishV + g, vertices[1]);
/* 293 */       this.vertices[2] = new RepositionableVertex(u1 / squishU + f, v2 / squishV - g, vertices[2]);
/* 294 */       this.vertices[3] = new RepositionableVertex(u2 / squishU - f, v2 / squishV - g, vertices[3]);
/* 295 */       if (flip) {
/* 296 */         int i = vertices.length;
/*     */         
/* 298 */         for (int j = 0; j < i / 2; j++) {
/* 299 */           IVertex vertex = this.vertices[j];
/* 300 */           this.vertices[j] = this.vertices[i - 1 - j];
/* 301 */           this.vertices[i - 1 - j] = vertex;
/*     */         } 
/*     */       } 
/*     */     }
/*     */     public void render(PoseStack.Pose matrices, VertexConsumer vertexConsumer, int light, int overlay, float red, float green, float blue, float alpha) {
/* 306 */       Vector3f direction = getDirection();
/* 307 */       direction.m_122249_(matrices.m_85864_());
/*     */       
/* 309 */       for (int i = 0; i != 4; i++) {
/* 310 */         IVertex vertex = this.vertices[i];
/* 311 */         Vector3f vertexPos = vertex.getPos();
/* 312 */         Vector4f pos = new Vector4f(vertexPos.m_122239_() / 16.0F, vertexPos.m_122260_() / 16.0F, vertexPos.m_122269_() / 16.0F, 1.0F);
/* 313 */         pos.m_123607_(matrices.m_85861_());
/* 314 */         vertexConsumer.m_5954_(pos.m_123601_(), pos.m_123615_(), pos.m_123616_(), red, green, blue, alpha, vertex.getU(), vertex.getV(), overlay, light, direction.m_122239_(), direction.m_122260_(), direction.m_122269_());
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Vector3f getDirection() {
/* 323 */       Vector3f buf = this.vertices[3].getPos().m_122281_();
/* 324 */       buf.m_122261_(-1.0F);
/* 325 */       Vector3f vecB = this.vertices[1].getPos().m_122281_();
/* 326 */       vecB.m_122253_(buf);
/* 327 */       buf = this.vertices[2].getPos().m_122281_();
/* 328 */       buf.m_122261_(-1.0F);
/* 329 */       Vector3f vecA = this.vertices[0].getPos().m_122281_();
/* 330 */       vecA.m_122253_(buf);
/* 331 */       vecA.m_122279_(vecB);
/*     */       
/* 333 */       return vecA.m_122278_() ? vecA : Direction.NORTH.m_122432_();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private ModelPart.Polygon toModelPart_Quad() {
/* 342 */       ModelPart.Polygon quad = new ModelPart.Polygon(new ModelPart.Vertex[] { this.vertices[0].toMojVertex(), this.vertices[1].toMojVertex(), this.vertices[2].toMojVertex(), this.vertices[3].toMojVertex() }, this.u1, this.v1, this.u2, this.v2, this.su, this.sv, false, Direction.UP);
/*     */       
/* 344 */       ((DirectionMutator)quad).setDirection(getDirection());
/* 345 */       return quad;
/*     */     } }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean disableAfterDraw() {
/* 351 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<ModelPart.Polygon> getQuads() {
/* 356 */     List<ModelPart.Polygon> sides = new ArrayList<>();
/* 357 */     for (Quad quad : this.sides) {
/* 358 */       sides.add(quad.toModelPart_Quad());
/*     */     }
/* 360 */     return sides;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\bendy-lib-forge-2.1.3-test2.jar!\io\github\kosmx\bendylib\impl\BendableCuboid.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */