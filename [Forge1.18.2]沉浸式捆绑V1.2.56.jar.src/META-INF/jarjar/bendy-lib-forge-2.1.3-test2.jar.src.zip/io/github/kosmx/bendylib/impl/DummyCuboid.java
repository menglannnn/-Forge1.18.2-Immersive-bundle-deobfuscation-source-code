/*    */ package io.github.kosmx.bendylib.impl;
/*    */ 
/*    */ import io.github.kosmx.bendylib.ICuboidBuilder;
/*    */ import io.github.kosmx.bendylib.MutableCuboid;
/*    */ import javax.annotation.Nullable;
/*    */ import net.minecraft.util.Tuple;
/*    */ import org.jetbrains.annotations.ApiStatus.Experimental;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ @Deprecated
/*    */ @Experimental
/*    */ public class DummyCuboid
/*    */   implements MutableCuboid {
/*    */   private static boolean bl = true;
/*    */   
/*    */   public DummyCuboid() {
/* 17 */     if (bl) {
/* 18 */       System.out.println("A Dummy cuboid was created. that is not good, but can be worse");
/* 19 */       bl = false;
/*    */     } 
/*    */   }
/*    */   
/*    */   public boolean registerMutator(String name, ICuboidBuilder<ICuboid> builder) {
/* 24 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean unregisterMutator(String name) {
/* 29 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public Tuple<String, ICuboid> getActiveMutator() {
/* 35 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean hasMutator(String key) {
/* 40 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public ICuboidBuilder<ICuboid> getCuboidBuilder(String key) {
/* 46 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public ICuboid getMutator(String name) {
/* 52 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public ICuboid getAndActivateMutator(@Nullable String name) {
/* 58 */     return null;
/*    */   }
/*    */   
/*    */   public void copyStateFrom(MutableCuboid other) {}
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\bendy-lib-forge-2.1.3-test2.jar!\io\github\kosmx\bendylib\impl\DummyCuboid.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */