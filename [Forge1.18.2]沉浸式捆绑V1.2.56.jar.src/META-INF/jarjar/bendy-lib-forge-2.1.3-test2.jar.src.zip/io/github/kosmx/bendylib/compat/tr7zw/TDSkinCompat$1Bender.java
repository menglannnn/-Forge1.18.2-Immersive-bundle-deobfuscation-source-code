/*    */ package io.github.kosmx.bendylib.compat.tr7zw;
/*    */ 
/*    */ import com.mojang.math.Vector3f;
/*    */ import com.mojang.math.Vector4f;
/*    */ import dev.tr7zw.skinlayers.api.MeshTransformer;
/*    */ import io.github.kosmx.bendylib.ICuboidBuilder;
/*    */ import io.github.kosmx.bendylib.MutableCuboid;
/*    */ import io.github.kosmx.bendylib.impl.BendableCuboid;
/*    */ import io.github.kosmx.bendylib.impl.IBendable;
/*    */ import io.github.kosmx.bendylib.impl.ICuboid;
/*    */ import io.github.kosmx.bendylib.impl.IPosWithOrigin;
/*    */ import io.github.kosmx.bendylib.impl.RememberingPos;
/*    */ import java.util.Optional;
/*    */ import java.util.function.Consumer;
/*    */ import net.minecraft.client.model.geom.ModelPart;
/*    */ import net.minecraft.core.Direction;
/*    */ import net.minecraft.util.Tuple;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class Bender
/*    */   extends TDSkinCompat.BendyMeshTransformer
/*    */   implements MeshTransformer
/*    */ {
/* 32 */   private Consumer<IPosWithOrigin> transform = null;
/*    */   
/*    */   private Bender(BendableCuboid cuboid) {
/* 35 */     super(cuboid);
/* 36 */     applyBend(bendableSource.getBendAxis(), bendableSource.getBend(), consumer -> this.transform = consumer);
/* 37 */     assert this.transform != null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void transform(Vector3f vec3f, Vector4f[] vector4fs) {
/* 46 */     for (int i = 0; i < vector4fs.length; i++) {
/* 47 */       RememberingPos pos = new RememberingPos(new Vector3f(vector4fs[i]));
/* 48 */       this.transform.accept(pos);
/* 49 */       vector4fs[i] = new Vector4f(pos.getPos());
/*    */     } 
/* 51 */     vec3f.m_176768_(TDSkinCompat.calculateNormal(vector4fs));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void transform(ModelPart.Cube cuboid) {
/* 57 */     MutableCuboid sourceCuboid = sourceCuboidOptional.get();
/* 58 */     Tuple<String, ICuboid> mutator = ((MutableCuboid)sourceCuboidOptional.get()).getActiveMutator();
/*    */     
/* 60 */     if (cuboid instanceof MutableCuboid) { MutableCuboid mutableCuboid = (MutableCuboid)cuboid;
/* 61 */       if (!mutableCuboid.hasMutator((String)mutator.m_14418_())) {
/* 62 */         mutableCuboid.registerMutator((String)mutator.m_14418_(), data -> (new BendableCuboid.Builder()).setDirection(getBendDirection()).build(data, ()));
/*    */       }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 70 */       mutableCuboid.copyStateFrom(sourceCuboid); }
/*    */   
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\bendy-lib-forge-2.1.3-test2.jar!\io\github\kosmx\bendylib\compat\tr7zw\TDSkinCompat$1Bender.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */