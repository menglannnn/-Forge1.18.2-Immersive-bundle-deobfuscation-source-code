/*    */ package io.github.kosmx.bendylib.mixin;
/*    */ 
/*    */ import com.mojang.math.Vector3f;
/*    */ import io.github.kosmx.bendylib.impl.accessors.DirectionMutator;
/*    */ import net.minecraft.client.model.geom.ModelPart;
/*    */ import org.spongepowered.asm.mixin.Final;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Mutable;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({ModelPart.Polygon.class})
/*    */ public class QuadMixin
/*    */   implements DirectionMutator
/*    */ {
/*    */   public void setDirection(Vector3f vec3f) {
/* 18 */     this.f_104360_ = vec3f;
/*    */   }
/*    */   
/*    */   @Mutable
/*    */   @Shadow
/*    */   @Final
/*    */   public Vector3f f_104360_;
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\bendy-lib-forge-2.1.3-test2.jar!\io\github\kosmx\bendylib\mixin\QuadMixin.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */