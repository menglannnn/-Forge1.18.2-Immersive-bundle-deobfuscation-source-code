/*     */ package io.github.kosmx.bendylib.impl;
/*     */ 
/*     */ import com.mojang.math.Vector3f;
/*     */ import io.github.kosmx.bendylib.ICuboidBuilder;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import net.minecraft.core.Direction;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Builder
/*     */   implements ICuboidBuilder<BendableCuboid>
/*     */ {
/*     */   public Direction direction;
/*     */   
/*     */   public Builder setDirection(Direction d) {
/* 140 */     this.direction = d;
/* 141 */     return this;
/*     */   }
/*     */   
/*     */   public BendableCuboid build(ICuboidBuilder.Data data, BendableCuboid.BuildableBendable builder) {
/* 145 */     ArrayList<BendableCuboid.Quad> planes = new ArrayList<>();
/* 146 */     HashMap<Vector3f, RememberingPos> positions = new HashMap<>();
/* 147 */     float minX = data.x, minY = data.y, minZ = data.z, maxX = data.x + data.sizeX, maxY = data.y + data.sizeY, maxZ = data.z + data.sizeZ;
/* 148 */     float pminX = data.x - data.extraX, pminY = data.y - data.extraY, pminZ = data.z - data.extraZ, pmaxX = maxX + data.extraX, pmaxY = maxY + data.extraY, pmaxZ = maxZ + data.extraZ;
/* 149 */     if (data.mirror) {
/* 150 */       float tmp = pminX;
/* 151 */       pminX = pmaxX;
/* 152 */       pmaxX = tmp;
/*     */     } 
/*     */ 
/*     */     
/* 156 */     Vector3f vertex1 = new Vector3f(pminX, pminY, pminZ);
/* 157 */     Vector3f vertex2 = new Vector3f(pmaxX, pminY, pminZ);
/* 158 */     Vector3f vertex3 = new Vector3f(pmaxX, pmaxY, pminZ);
/* 159 */     Vector3f vertex4 = new Vector3f(pminX, pmaxY, pminZ);
/* 160 */     Vector3f vertex5 = new Vector3f(pminX, pminY, pmaxZ);
/* 161 */     Vector3f vertex6 = new Vector3f(pmaxX, pminY, pmaxZ);
/* 162 */     Vector3f vertex7 = new Vector3f(pmaxX, pmaxY, pmaxZ);
/* 163 */     Vector3f vertex8 = new Vector3f(pminX, pmaxY, pmaxZ);
/*     */     
/* 165 */     int j = data.u;
/* 166 */     int k = (int)(data.u + data.sizeZ);
/* 167 */     int l = (int)(data.u + data.sizeZ + data.sizeX);
/* 168 */     int m = (int)(data.u + data.sizeZ + data.sizeX + data.sizeX);
/* 169 */     int n = (int)(data.u + data.sizeZ + data.sizeX + data.sizeZ);
/* 170 */     int o = (int)(data.u + data.sizeZ + data.sizeX + data.sizeZ + data.sizeX);
/* 171 */     int p = data.v;
/* 172 */     int q = (int)(data.v + data.sizeZ);
/* 173 */     int r = (int)(data.v + data.sizeZ + data.sizeY);
/* 174 */     createAndAddQuads(planes, positions, new Vector3f[] { vertex6, vertex5, vertex2 }, k, p, l, q, data.textureWidth, data.textureHeight, data.mirror, data);
/* 175 */     createAndAddQuads(planes, positions, new Vector3f[] { vertex3, vertex4, vertex7 }, l, q, m, p, data.textureWidth, data.textureHeight, data.mirror, data);
/* 176 */     createAndAddQuads(planes, positions, new Vector3f[] { vertex1, vertex5, vertex4 }, j, q, k, r, data.textureWidth, data.textureHeight, data.mirror, data);
/* 177 */     createAndAddQuads(planes, positions, new Vector3f[] { vertex2, vertex1, vertex3 }, k, q, l, r, data.textureWidth, data.textureHeight, data.mirror, data);
/* 178 */     createAndAddQuads(planes, positions, new Vector3f[] { vertex6, vertex2, vertex7 }, l, q, n, r, data.textureWidth, data.textureHeight, data.mirror, data);
/* 179 */     createAndAddQuads(planes, positions, new Vector3f[] { vertex5, vertex6, vertex8 }, n, q, o, r, data.textureWidth, data.textureHeight, data.mirror, data);
/*     */     
/* 181 */     IBendable.Plane aPlane = new IBendable.Plane(this.direction.m_122432_(), vertex7);
/* 182 */     IBendable.Plane bPlane = new IBendable.Plane(this.direction.m_122432_(), vertex1);
/* 183 */     boolean bl = (this.direction == Direction.UP || this.direction == Direction.SOUTH || this.direction == Direction.EAST);
/* 184 */     float fullSize = -this.direction.m_122432_().m_122276_(vertex1) + this.direction.m_122432_().m_122276_(vertex7);
/* 185 */     float bendX = (data.sizeX + data.x + data.x) / 2.0F;
/* 186 */     float bendY = (data.sizeY + data.y + data.y) / 2.0F;
/* 187 */     float bendZ = (data.sizeZ + data.z + data.z) / 2.0F;
/* 188 */     return builder.build(planes.<BendableCuboid.Quad>toArray(new BendableCuboid.Quad[0]), (RememberingPos[])positions.values().toArray((Object[])new RememberingPos[0]), minX, minY, minZ, maxX, maxY, maxZ, bendX, bendY, bendZ, this.direction, bl ? aPlane : bPlane, bl ? bPlane : aPlane, fullSize);
/*     */   }
/*     */   
/*     */   public BendableCuboid build(ICuboidBuilder.Data data) {
/* 192 */     return build(data, BendableCuboid::new);
/*     */   }
/*     */ 
/*     */   
/*     */   private void createAndAddQuads(Collection<BendableCuboid.Quad> quads, HashMap<Vector3f, RememberingPos> positions, Vector3f[] edges, int u1, int v1, int u2, int v2, float squishU, float squishV, boolean flip, ICuboidBuilder.Data data) {
/* 197 */     int du = (u2 < u1) ? 1 : -1;
/* 198 */     int dv = (v1 < v2) ? 1 : -1; int localU;
/* 199 */     for (localU = u2; localU != u1; localU += du) {
/* 200 */       int localV; for (localV = v1; localV != v2; localV += dv) {
/* 201 */         int localU2 = localU + du;
/* 202 */         int localV2 = localV + dv;
/* 203 */         RememberingPos rp0 = getOrCreate(positions, transformVector(edges[0].m_122281_(), edges[1].m_122281_(), edges[2].m_122281_(), u2, v1, u1, v2, localU2, localV));
/* 204 */         RememberingPos rp1 = getOrCreate(positions, transformVector(edges[0].m_122281_(), edges[1].m_122281_(), edges[2].m_122281_(), u2, v1, u1, v2, localU2, localV2));
/* 205 */         RememberingPos rp2 = getOrCreate(positions, transformVector(edges[0].m_122281_(), edges[1].m_122281_(), edges[2].m_122281_(), u2, v1, u1, v2, localU, localV2));
/* 206 */         RememberingPos rp3 = getOrCreate(positions, transformVector(edges[0].m_122281_(), edges[1].m_122281_(), edges[2].m_122281_(), u2, v1, u1, v2, localU, localV));
/* 207 */         quads.add(new BendableCuboid.Quad(new RememberingPos[] { rp3, rp0, rp1, rp2 }, localU2, localV, localU, localV2, data.textureWidth, data.textureHeight, data.mirror));
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   Vector3f transformVector(Vector3f pos, Vector3f vectorU, Vector3f vectorV, int u1, int v1, int u2, int v2, int u, int v) {
/* 213 */     vectorU.m_122267_(pos);
/* 214 */     vectorU.m_122261_((u - u1) / (u2 - u1));
/* 215 */     vectorV.m_122267_(pos);
/* 216 */     vectorV.m_122261_((v - v1) / (v2 - v1));
/* 217 */     pos.m_122253_(vectorU);
/* 218 */     pos.m_122253_(vectorV);
/* 219 */     return pos;
/*     */   }
/*     */ 
/*     */   
/*     */   RememberingPos getOrCreate(HashMap<Vector3f, RememberingPos> positions, Vector3f pos) {
/* 224 */     if (!positions.containsKey(pos)) {
/* 225 */       positions.put(pos, new RememberingPos(pos));
/*     */     }
/* 227 */     return positions.get(pos);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\bendy-lib-forge-2.1.3-test2.jar!\io\github\kosmx\bendylib\impl\BendableCuboid$Builder.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */