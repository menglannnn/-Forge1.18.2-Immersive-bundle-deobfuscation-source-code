package io.github.kosmx.bendylib.impl;

import java.util.function.Consumer;

@FunctionalInterface
public interface IterableRePos {
  void iteratePositions(Consumer<IPosWithOrigin> paramConsumer);
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\bendy-lib-forge-2.1.3-test2.jar!\io\github\kosmx\bendylib\impl\IterableRePos.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */