/*    */ package io.github.kosmx.bendylib.impl;
/*    */ 
/*    */ import com.mojang.math.Vector3f;
/*    */ import java.util.Objects;
/*    */ 
/*    */ public class RememberingPos
/*    */   implements IPosWithOrigin
/*    */ {
/*    */   final Vector3f originPos;
/* 10 */   Vector3f currentPos = null;
/*    */   
/*    */   public RememberingPos(Vector3f originPos) {
/* 13 */     this.originPos = originPos;
/*    */   }
/*    */   
/*    */   public RememberingPos(float x, float y, float z) {
/* 17 */     this(new Vector3f(x, y, z));
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 22 */     if (this == o) return true; 
/* 23 */     if (!(o instanceof RememberingPos)) return false;
/*    */     
/* 25 */     RememberingPos that = (RememberingPos)o;
/*    */     
/* 27 */     if (!this.originPos.equals(that.originPos)) return false; 
/* 28 */     return Objects.equals(this.currentPos, that.currentPos);
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 33 */     int result = this.originPos.hashCode();
/* 34 */     result = 31 * result + ((this.currentPos != null) ? this.currentPos.hashCode() : 0);
/* 35 */     return result;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Vector3f getOriginalPos() {
/* 44 */     return this.originPos.m_122281_();
/*    */   }
/*    */ 
/*    */   
/*    */   public Vector3f getPos() {
/* 49 */     return this.currentPos;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setPos(Vector3f vector3f) {
/* 54 */     this.currentPos = vector3f;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\bendy-lib-forge-2.1.3-test2.jar!\io\github\kosmx\bendylib\impl\RememberingPos.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */