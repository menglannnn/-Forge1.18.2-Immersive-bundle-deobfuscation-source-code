package io.github.kosmx.bendylib;

import dev.architectury.injectables.annotations.ExpectPlatform;
import dev.architectury.injectables.annotations.ExpectPlatform.Transformed;
import io.github.kosmx.bendylib.forge.PlatformUtilsImpl;

public class PlatformUtils {
  @ExpectPlatform
  @Transformed
  public static boolean isSkinLayersPresent() {
    return PlatformUtilsImpl.isSkinLayersPresent();
  }
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\bendy-lib-forge-2.1.3-test2.jar!\io\github\kosmx\bendylib\PlatformUtils.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */