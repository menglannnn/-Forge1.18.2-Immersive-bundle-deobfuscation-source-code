/*     */ package io.github.kosmx.bendylib.impl;
/*     */ 
/*     */ import com.mojang.blaze3d.vertex.PoseStack;
/*     */ import com.mojang.blaze3d.vertex.VertexConsumer;
/*     */ import com.mojang.math.Vector3f;
/*     */ import com.mojang.math.Vector4f;
/*     */ import io.github.kosmx.bendylib.impl.accessors.DirectionMutator;
/*     */ import net.minecraft.client.model.geom.ModelPart;
/*     */ import net.minecraft.core.Direction;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Quad
/*     */ {
/*     */   public final IVertex[] vertices;
/*     */   final float u1;
/*     */   final float u2;
/*     */   final float v1;
/*     */   final float v2;
/*     */   final float su;
/*     */   final float sv;
/*     */   
/*     */   public Quad(RememberingPos[] vertices, float u1, float v1, float u2, float v2, float squishU, float squishV, boolean flip) {
/* 287 */     this.u1 = u1; this.u2 = u2; this.v1 = v1; this.v2 = v2; this.su = squishU; this.sv = squishV;
/* 288 */     float f = 0.0F / squishU;
/* 289 */     float g = 0.0F / squishV;
/* 290 */     this.vertices = new IVertex[4];
/* 291 */     this.vertices[0] = new RepositionableVertex(u2 / squishU - f, v1 / squishV + g, vertices[0]);
/* 292 */     this.vertices[1] = new RepositionableVertex(u1 / squishU + f, v1 / squishV + g, vertices[1]);
/* 293 */     this.vertices[2] = new RepositionableVertex(u1 / squishU + f, v2 / squishV - g, vertices[2]);
/* 294 */     this.vertices[3] = new RepositionableVertex(u2 / squishU - f, v2 / squishV - g, vertices[3]);
/* 295 */     if (flip) {
/* 296 */       int i = vertices.length;
/*     */       
/* 298 */       for (int j = 0; j < i / 2; j++) {
/* 299 */         IVertex vertex = this.vertices[j];
/* 300 */         this.vertices[j] = this.vertices[i - 1 - j];
/* 301 */         this.vertices[i - 1 - j] = vertex;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   public void render(PoseStack.Pose matrices, VertexConsumer vertexConsumer, int light, int overlay, float red, float green, float blue, float alpha) {
/* 306 */     Vector3f direction = getDirection();
/* 307 */     direction.m_122249_(matrices.m_85864_());
/*     */     
/* 309 */     for (int i = 0; i != 4; i++) {
/* 310 */       IVertex vertex = this.vertices[i];
/* 311 */       Vector3f vertexPos = vertex.getPos();
/* 312 */       Vector4f pos = new Vector4f(vertexPos.m_122239_() / 16.0F, vertexPos.m_122260_() / 16.0F, vertexPos.m_122269_() / 16.0F, 1.0F);
/* 313 */       pos.m_123607_(matrices.m_85861_());
/* 314 */       vertexConsumer.m_5954_(pos.m_123601_(), pos.m_123615_(), pos.m_123616_(), red, green, blue, alpha, vertex.getU(), vertex.getV(), overlay, light, direction.m_122239_(), direction.m_122260_(), direction.m_122269_());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Vector3f getDirection() {
/* 323 */     Vector3f buf = this.vertices[3].getPos().m_122281_();
/* 324 */     buf.m_122261_(-1.0F);
/* 325 */     Vector3f vecB = this.vertices[1].getPos().m_122281_();
/* 326 */     vecB.m_122253_(buf);
/* 327 */     buf = this.vertices[2].getPos().m_122281_();
/* 328 */     buf.m_122261_(-1.0F);
/* 329 */     Vector3f vecA = this.vertices[0].getPos().m_122281_();
/* 330 */     vecA.m_122253_(buf);
/* 331 */     vecA.m_122279_(vecB);
/*     */     
/* 333 */     return vecA.m_122278_() ? vecA : Direction.NORTH.m_122432_();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ModelPart.Polygon toModelPart_Quad() {
/* 342 */     ModelPart.Polygon quad = new ModelPart.Polygon(new ModelPart.Vertex[] { this.vertices[0].toMojVertex(), this.vertices[1].toMojVertex(), this.vertices[2].toMojVertex(), this.vertices[3].toMojVertex() }, this.u1, this.v1, this.u2, this.v2, this.su, this.sv, false, Direction.UP);
/*     */     
/* 344 */     ((DirectionMutator)quad).setDirection(getDirection());
/* 345 */     return quad;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\bendy-lib-forge-2.1.3-test2.jar!\io\github\kosmx\bendylib\impl\BendableCuboid$Quad.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */