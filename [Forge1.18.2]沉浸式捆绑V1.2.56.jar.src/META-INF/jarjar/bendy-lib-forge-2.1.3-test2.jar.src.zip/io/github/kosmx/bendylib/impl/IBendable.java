/*     */ package io.github.kosmx.bendylib.impl;
/*     */ 
/*     */ import com.mojang.math.Matrix3f;
/*     */ import com.mojang.math.Matrix4f;
/*     */ import com.mojang.math.Vector3f;
/*     */ import com.mojang.math.Vector4f;
/*     */ import net.minecraft.core.Direction;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface IBendable
/*     */ {
/*     */   default Matrix4f applyBend(float bendAxis, float bendValue, IterableRePos posSupplier) {
/*  19 */     Vector3f axis = new Vector3f((float)Math.cos(bendAxis), 0.0F, (float)Math.sin(bendAxis));
/*  20 */     Matrix3f matrix3f = new Matrix3f(getBendDirection().m_122406_());
/*  21 */     axis.m_122249_(matrix3f);
/*  22 */     Matrix4f transformMatrix = new Matrix4f();
/*  23 */     transformMatrix.m_27624_();
/*     */     
/*  25 */     transformMatrix.m_27644_(Matrix4f.m_27653_(getBendX(), getBendY(), getBendZ()));
/*  26 */     transformMatrix.m_27646_(axis.m_122270_(bendValue));
/*  27 */     transformMatrix.m_27644_(Matrix4f.m_27653_(-getBendX(), -getBendY(), -getBendZ()));
/*     */ 
/*     */ 
/*     */     
/*  31 */     Plane basePlane = getBasePlane();
/*  32 */     Plane otherPlane = getOtherSidePlane();
/*     */     
/*  34 */     Vector3f directionUnit = getBendDirection().m_122432_();
/*  35 */     directionUnit.m_122279_(axis);
/*     */     
/*  37 */     Plane bendPlane = new Plane(directionUnit, new Vector3f(getBendX(), getBendY(), getBendZ()));
/*  38 */     float halfSize = bendHeight() / 2.0F;
/*     */     
/*  40 */     boolean bl = isBendInverted();
/*     */     
/*  42 */     posSupplier.iteratePositions(iPosWithOrigin -> {
/*     */           Vector3f newPos = iPosWithOrigin.getOriginalPos();
/*     */           
/*     */           float distFromBend = bl ? -bendPlane.distanceTo(newPos) : bendPlane.distanceTo(newPos);
/*     */           
/*     */           float distFromBase = basePlane.distanceTo(newPos);
/*     */           float distFromOther = otherPlane.distanceTo(newPos);
/*     */           double s = Math.tan((bendValue / 2.0F)) * distFromBend;
/*     */           Vector3f x = getBendDirection().m_122432_();
/*     */           if (Math.abs(distFromBase) < Math.abs(distFromOther)) {
/*     */             x.m_122261_((float)((-distFromBase / halfSize) * s));
/*     */             newPos.m_122253_(x);
/*     */             Vector4f reposVector = new Vector4f(newPos);
/*     */             reposVector.m_123607_(transformMatrix);
/*     */             newPos = new Vector3f(reposVector.m_123601_(), reposVector.m_123615_(), reposVector.m_123616_());
/*     */           } else {
/*     */             x.m_122261_((float)((-distFromOther / halfSize) * s));
/*     */             newPos.m_122253_(x);
/*     */           } 
/*     */           iPosWithOrigin.setPos(newPos);
/*     */         });
/*  63 */     return transformMatrix;
/*     */   }
/*     */   
/*     */   default boolean isBendInverted() {
/*  67 */     return (getBendDirection() == Direction.UP || getBendDirection() == Direction.SOUTH || getBendDirection() == Direction.EAST);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default float bendHeight() {
/*  89 */     return getBasePlane().distanceTo(getOtherSidePlane());
/*     */   }
/*     */   Direction getBendDirection();
/*     */   float getBendX();
/*     */   float getBendY();
/*     */   float getBendZ();
/*     */   Plane getBasePlane();
/*     */   
/*     */   Plane getOtherSidePlane();
/*     */   
/*     */   public static final class Plane { public final Vector3f normal;
/*     */     
/*     */     public Plane(Vector3f normal, Vector3f position) {
/* 102 */       this.normal = normal;
/* 103 */       this.normal.m_122278_();
/* 104 */       this.normDistance = -this.normal.m_122276_(position);
/*     */     }
/*     */     private final float normDistance;
/*     */     private Plane(Vector3f normal, float normDistance) {
/* 108 */       this.normal = normal;
/* 109 */       this.normDistance = normDistance;
/*     */     }
/*     */     
/*     */     public Plane scaled(float scalar) {
/* 113 */       return new Plane(this.normal.m_122281_(), this.normDistance * scalar);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public float distanceTo(Vector3f pos) {
/* 122 */       return this.normal.m_122276_(pos) + this.normDistance;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public float distanceTo(Plane otherPlane) {
/* 131 */       Vector3f tmp = this.normal.m_122281_();
/* 132 */       tmp.m_122279_(otherPlane.normal);
/*     */       
/* 134 */       if (tmp.m_122276_(tmp) < 0.01D) {
/* 135 */         return this.normDistance + this.normal.m_122276_(otherPlane.normal) * otherPlane.normDistance;
/*     */       }
/*     */       
/* 138 */       return 0.0F;
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\bendy-lib-forge-2.1.3-test2.jar!\io\github\kosmx\bendylib\impl\IBendable.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */