/*   */ package io.github.kosmx.bendylib.forge;
/*   */ 
/*   */ import net.minecraftforge.fml.ModList;
/*   */ 
/*   */ public class PlatformUtilsImpl {
/*   */   public static boolean isSkinLayersPresent() {
/* 7 */     return ModList.get().isLoaded("skinlayers3d");
/*   */   }
/*   */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\bendy-lib-forge-2.1.3-test2.jar!\io\github\kosmx\bendylib\forge\PlatformUtilsImpl.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */