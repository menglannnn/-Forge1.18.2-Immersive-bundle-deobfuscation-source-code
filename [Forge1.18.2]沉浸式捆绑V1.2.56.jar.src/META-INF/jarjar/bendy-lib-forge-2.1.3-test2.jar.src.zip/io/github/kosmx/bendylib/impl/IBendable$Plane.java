/*     */ package io.github.kosmx.bendylib.impl;
/*     */ 
/*     */ import com.mojang.math.Vector3f;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Plane
/*     */ {
/*     */   public final Vector3f normal;
/*     */   private final float normDistance;
/*     */   
/*     */   public Plane(Vector3f normal, Vector3f position) {
/* 102 */     this.normal = normal;
/* 103 */     this.normal.m_122278_();
/* 104 */     this.normDistance = -this.normal.m_122276_(position);
/*     */   }
/*     */   
/*     */   private Plane(Vector3f normal, float normDistance) {
/* 108 */     this.normal = normal;
/* 109 */     this.normDistance = normDistance;
/*     */   }
/*     */   
/*     */   public Plane scaled(float scalar) {
/* 113 */     return new Plane(this.normal.m_122281_(), this.normDistance * scalar);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float distanceTo(Vector3f pos) {
/* 122 */     return this.normal.m_122276_(pos) + this.normDistance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float distanceTo(Plane otherPlane) {
/* 131 */     Vector3f tmp = this.normal.m_122281_();
/* 132 */     tmp.m_122279_(otherPlane.normal);
/*     */     
/* 134 */     if (tmp.m_122276_(tmp) < 0.01D) {
/* 135 */       return this.normDistance + this.normal.m_122276_(otherPlane.normal) * otherPlane.normDistance;
/*     */     }
/*     */     
/* 138 */     return 0.0F;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\bendy-lib-forge-2.1.3-test2.jar!\io\github\kosmx\bendylib\impl\IBendable$Plane.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */