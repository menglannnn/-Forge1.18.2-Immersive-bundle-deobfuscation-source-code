/*    */ package io.github.kosmx.bendylib.compat.tr7zw;
/*    */ 
/*    */ import com.mojang.math.Vector3f;
/*    */ import com.mojang.math.Vector4f;
/*    */ import dev.tr7zw.skinlayers.api.MeshTransformer;
/*    */ import io.github.kosmx.bendylib.MutableCuboid;
/*    */ import net.minecraft.client.model.geom.ModelPart;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class null
/*    */   implements MeshTransformer
/*    */ {
/*    */   public void transform(Vector3f vec3f, Vector4f[] vector4fs) {}
/*    */   
/*    */   public void transform(ModelPart.Cube cuboid) {
/* 86 */     ((MutableCuboid)cuboid).getAndActivateMutator(null);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\bendy-lib-forge-2.1.3-test2.jar!\io\github\kosmx\bendylib\compat\tr7zw\TDSkinCompat$2.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */