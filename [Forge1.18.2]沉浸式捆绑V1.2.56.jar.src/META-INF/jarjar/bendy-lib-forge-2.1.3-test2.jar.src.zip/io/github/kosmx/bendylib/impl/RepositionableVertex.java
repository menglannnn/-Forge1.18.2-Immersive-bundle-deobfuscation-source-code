/*    */ package io.github.kosmx.bendylib.impl;
/*    */ 
/*    */ import com.mojang.math.Vector3f;
/*    */ 
/*    */ 
/*    */ public class RepositionableVertex
/*    */   implements IRepositionableVertex
/*    */ {
/*    */   public final float u;
/*    */   public final float v;
/*    */   protected final RememberingPos pos;
/*    */   
/*    */   public RepositionableVertex(float u, float v, RememberingPos pos) {
/* 14 */     this.u = u;
/* 15 */     this.v = v;
/* 16 */     this.pos = pos;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public RepositionableVertex remap(float u, float v) {
/* 22 */     return new RepositionableVertex(u, v, this.pos);
/*    */   }
/*    */ 
/*    */   
/*    */   public Vector3f getPos() {
/* 27 */     return this.pos.getPos();
/*    */   }
/*    */ 
/*    */   
/*    */   public float getU() {
/* 32 */     return this.u;
/*    */   }
/*    */ 
/*    */   
/*    */   public float getV() {
/* 37 */     return this.v;
/*    */   }
/*    */ 
/*    */   
/*    */   public RememberingPos getPosObject() {
/* 42 */     return this.pos;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\bendy-lib-forge-2.1.3-test2.jar!\io\github\kosmx\bendylib\impl\RepositionableVertex.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */