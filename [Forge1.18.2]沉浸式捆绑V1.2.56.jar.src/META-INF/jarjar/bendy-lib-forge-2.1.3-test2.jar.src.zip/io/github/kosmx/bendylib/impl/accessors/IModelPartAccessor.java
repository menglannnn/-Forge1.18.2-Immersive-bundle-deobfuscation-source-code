package io.github.kosmx.bendylib.impl.accessors;

import io.github.kosmx.bendylib.ModelPartAccessor;
import java.util.List;
import java.util.Map;
import net.minecraft.client.model.geom.ModelPart;

public interface IModelPartAccessor {
  List<ModelPart.Cube> getCuboids();
  
  Map<String, ModelPart> getChildren();
  
  void setWorkaround(ModelPartAccessor.Workaround paramWorkaround);
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\bendy-lib-forge-2.1.3-test2.jar!\io\github\kosmx\bendylib\impl\accessors\IModelPartAccessor.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */