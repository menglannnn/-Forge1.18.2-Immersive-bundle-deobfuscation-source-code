/*     */ package io.github.kosmx.bendylib.compat.tr7zw;
/*     */ 
/*     */ import io.github.kosmx.bendylib.impl.BendableCuboid;
/*     */ import io.github.kosmx.bendylib.impl.IBendable;
/*     */ import net.minecraft.core.Direction;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BendyMeshTransformer
/*     */   implements IBendable
/*     */ {
/*     */   private final Direction bendDirection;
/*     */   private final float bendX;
/*     */   private final float bendY;
/*     */   private final float bendZ;
/*     */   private final IBendable.Plane basePlane;
/*     */   private final IBendable.Plane otherSidePlane;
/*     */   private final float bendHeight;
/*     */   
/*     */   private BendyMeshTransformer(Direction bendDirection, float bendX, float bendY, float bendZ, IBendable.Plane basePlane, IBendable.Plane otherSidePlane, float bendHeight) {
/* 123 */     this.bendDirection = bendDirection;
/* 124 */     this.bendX = bendX / 16.0F;
/* 125 */     this.bendY = bendY / 16.0F;
/* 126 */     this.bendZ = bendZ / 16.0F;
/* 127 */     this.basePlane = basePlane.scaled(0.0625F);
/* 128 */     this.otherSidePlane = otherSidePlane.scaled(0.0625F);
/* 129 */     this.bendHeight = bendHeight / 16.0F;
/*     */   }
/*     */   
/*     */   private BendyMeshTransformer(BendableCuboid cuboid) {
/* 133 */     this(cuboid.getBendDirection(), cuboid.getBendX(), cuboid.getBendY(), cuboid.getBendZ(), cuboid
/* 134 */         .getBasePlane(), cuboid.getOtherSidePlane(), cuboid.bendHeight());
/*     */   }
/*     */ 
/*     */   
/*     */   public float bendHeight() {
/* 139 */     return this.bendHeight;
/*     */   }
/*     */ 
/*     */   
/*     */   public Direction getBendDirection() {
/* 144 */     return this.bendDirection;
/*     */   }
/*     */ 
/*     */   
/*     */   public float getBendX() {
/* 149 */     return this.bendX;
/*     */   }
/*     */ 
/*     */   
/*     */   public float getBendY() {
/* 154 */     return this.bendY;
/*     */   }
/*     */ 
/*     */   
/*     */   public float getBendZ() {
/* 159 */     return this.bendZ;
/*     */   }
/*     */ 
/*     */   
/*     */   public IBendable.Plane getBasePlane() {
/* 164 */     return this.basePlane;
/*     */   }
/*     */ 
/*     */   
/*     */   public IBendable.Plane getOtherSidePlane() {
/* 169 */     return this.otherSidePlane;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\bendy-lib-forge-2.1.3-test2.jar!\io\github\kosmx\bendylib\compat\tr7zw\TDSkinCompat$BendyMeshTransformer.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */