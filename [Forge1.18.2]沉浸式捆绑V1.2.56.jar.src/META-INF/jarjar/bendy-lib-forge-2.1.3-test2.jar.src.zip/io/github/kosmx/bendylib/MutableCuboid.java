package io.github.kosmx.bendylib;

import io.github.kosmx.bendylib.impl.ICuboid;
import javax.annotation.Nullable;
import net.minecraft.util.Tuple;

public interface MutableCuboid {
  boolean registerMutator(String paramString, ICuboidBuilder<ICuboid> paramICuboidBuilder);
  
  boolean unregisterMutator(String paramString);
  
  @Nullable
  Tuple<String, ICuboid> getActiveMutator();
  
  boolean hasMutator(String paramString);
  
  @Nullable
  ICuboidBuilder<ICuboid> getCuboidBuilder(String paramString);
  
  @Nullable
  @Deprecated
  ICuboid getMutator(String paramString);
  
  @Nullable
  ICuboid getAndActivateMutator(@Nullable String paramString);
  
  void copyStateFrom(MutableCuboid paramMutableCuboid);
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\bendy-lib-forge-2.1.3-test2.jar!\io\github\kosmx\bendylib\MutableCuboid.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */