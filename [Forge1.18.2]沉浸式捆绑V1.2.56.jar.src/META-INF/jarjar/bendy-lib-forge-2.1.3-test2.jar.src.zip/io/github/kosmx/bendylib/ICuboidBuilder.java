/*    */ package io.github.kosmx.bendylib;
/*    */ 
/*    */ @FunctionalInterface
/*    */ public interface ICuboidBuilder<C extends io.github.kosmx.bendylib.impl.ICuboid>
/*    */ {
/*    */   C build(Data paramData);
/*    */   
/*    */   public static class Data {
/*    */     public float x;
/*    */     public float y;
/*    */     public float z;
/*    */     public float sizeX;
/*    */     public float sizeY;
/*    */     public float sizeZ;
/*    */     public float extraX;
/*    */     public float extraY;
/*    */     public float extraZ;
/*    */     public int u;
/*    */     public int v;
/*    */     public boolean mirror = false;
/*    */     public int textureWidth;
/*    */     public int textureHeight;
/*    */     
/*    */     public Data() {}
/*    */     
/*    */     public Data(int u, int v, float x, float y, float z, float sizeX, float sizeY, float sizeZ, float extraX, float extraY, float extraZ, boolean mirror, float textureWidth, float textureHeight) {
/* 27 */       this.u = u;
/* 28 */       this.v = v;
/* 29 */       this.x = x;
/* 30 */       this.y = y;
/* 31 */       this.z = z;
/* 32 */       this.sizeX = sizeX;
/* 33 */       this.sizeY = sizeY;
/* 34 */       this.sizeZ = sizeZ;
/* 35 */       this.extraX = extraX;
/* 36 */       this.extraY = extraY;
/* 37 */       this.extraZ = extraZ;
/* 38 */       this.mirror = mirror;
/*    */       
/* 40 */       this.textureWidth = (int)textureWidth;
/* 41 */       this.textureHeight = (int)textureHeight;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\bendy-lib-forge-2.1.3-test2.jar!\io\github\kosmx\bendylib\ICuboidBuilder.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */