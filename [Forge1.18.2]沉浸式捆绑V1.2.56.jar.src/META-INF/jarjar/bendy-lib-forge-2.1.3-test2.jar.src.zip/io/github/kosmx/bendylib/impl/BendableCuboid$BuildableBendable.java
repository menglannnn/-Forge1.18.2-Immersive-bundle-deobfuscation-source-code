package io.github.kosmx.bendylib.impl;

import net.minecraft.core.Direction;

@FunctionalInterface
public interface BuildableBendable {
  BendableCuboid build(BendableCuboid.Quad[] paramArrayOfQuad, RememberingPos[] paramArrayOfRememberingPos, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, Direction paramDirection, IBendable.Plane paramPlane1, IBendable.Plane paramPlane2, float paramFloat10);
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\bendy-lib-forge-2.1.3-test2.jar!\io\github\kosmx\bendylib\impl\BendableCuboid$BuildableBendable.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */