/*     */ package io.github.kosmx.bendylib.mixin;
/*     */ 
/*     */ import com.mojang.blaze3d.vertex.PoseStack;
/*     */ import com.mojang.blaze3d.vertex.VertexConsumer;
/*     */ import io.github.kosmx.bendylib.ModelPartAccessor;
/*     */ import io.github.kosmx.bendylib.MutableCuboid;
/*     */ import io.github.kosmx.bendylib.impl.accessors.CuboidSideAccessor;
/*     */ import io.github.kosmx.bendylib.impl.accessors.IModelPartAccessor;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import net.minecraft.client.model.geom.ModelPart;
/*     */ import org.spongepowered.asm.mixin.Dynamic;
/*     */ import org.spongepowered.asm.mixin.Final;
/*     */ import org.spongepowered.asm.mixin.Mixin;
/*     */ import org.spongepowered.asm.mixin.Shadow;
/*     */ import org.spongepowered.asm.mixin.Unique;
/*     */ import org.spongepowered.asm.mixin.injection.At;
/*     */ import org.spongepowered.asm.mixin.injection.Inject;
/*     */ import org.spongepowered.asm.mixin.injection.Redirect;
/*     */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*     */ 
/*     */ @Mixin({ModelPart.class})
/*     */ public abstract class IModelPartMixin
/*     */   implements IModelPartAccessor {
/*     */   @Shadow
/*     */   @Final
/*     */   private Map<String, ModelPart> f_104213_;
/*     */   @Shadow
/*     */   @Final
/*     */   private List<ModelPart.Cube> f_104212_;
/*     */   @Unique
/*     */   private boolean hasMutatedCuboid = false;
/*  34 */   private ModelPartAccessor.Workaround workaround = ModelPartAccessor.Workaround.VanillaDraw;
/*     */   
/*     */   @Shadow
/*     */   protected abstract void m_104290_(PoseStack.Pose paramPose, VertexConsumer paramVertexConsumer, int paramInt1, int paramInt2, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
/*     */   
/*     */   public List<ModelPart.Cube> getCuboids() {
/*  40 */     this.hasMutatedCuboid = true;
/*  41 */     return this.f_104212_;
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, ModelPart> getChildren() {
/*  46 */     return this.f_104213_;
/*     */   }
/*     */   
/*     */   @Inject(method = {"copyTransform"}, at = {@At("RETURN")})
/*     */   private void copyTransformExtended(ModelPart part, CallbackInfo ci) {
/*  51 */     if (((IModelPartAccessor)part).getCuboids() == null || this.f_104212_ == null)
/*  52 */       return;  Iterator<ModelPart.Cube> iterator0 = ((IModelPartAccessor)part).getCuboids().iterator();
/*  53 */     Iterator<ModelPart.Cube> iterator1 = this.f_104212_.iterator();
/*     */     
/*  55 */     while (iterator0.hasNext() && iterator1.hasNext()) {
/*  56 */       MutableCuboid cuboid1 = (MutableCuboid)iterator1.next();
/*  57 */       MutableCuboid cuboid0 = (MutableCuboid)iterator0.next();
/*  58 */       cuboid1.copyStateFrom(cuboid0);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @Redirect(method = {"render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumer;IIFFFF)V"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/model/ModelPart;renderCuboids(Lnet/minecraft/client/util/math/MatrixStack$Entry;Lnet/minecraft/client/render/VertexConsumer;IIFFFF)V"), require = 0)
/*     */   private void redirectRenderCuboids(ModelPart modelPart, PoseStack.Pose entry, VertexConsumer vertexConsumer, int light, int overlay, float red, float green, float blue, float alpha) {
/*  65 */     redirectedFunction(modelPart, entry, vertexConsumer, light, overlay, red, green, blue, alpha);
/*     */   }
/*     */   
/*     */   @Redirect(method = {"render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumer;IIFFFFZ)V"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/model/ModelPart;renderCuboids(Lnet/minecraft/client/util/math/MatrixStack$Entry;Lnet/minecraft/client/render/VertexConsumer;IIFFFF)V"), require = 0)
/*     */   @Dynamic("render function is replaced with this by Optifine")
/*     */   private void redirectOF(ModelPart modelPart, PoseStack.Pose entry, VertexConsumer vertexConsumer, int light, int overlay, float red, float green, float blue, float alpha) {
/*  71 */     redirectedFunction(modelPart, entry, vertexConsumer, light, overlay, red, green, blue, alpha);
/*     */   }
/*     */   
/*     */   @Unique
/*     */   private void redirectedFunction(ModelPart modelPart, PoseStack.Pose entry, VertexConsumer vertexConsumer, int light, int overlay, float red, float green, float blue, float alpha) {
/*  76 */     if (this.workaround == ModelPartAccessor.Workaround.ExportQuads) {
/*  77 */       for (ModelPart.Cube cuboid : this.f_104212_) {
/*  78 */         ((CuboidSideAccessor)cuboid).doSideSwapping();
/*     */       }
/*  80 */       m_104290_(entry, vertexConsumer, light, overlay, red, green, blue, alpha);
/*  81 */       for (ModelPart.Cube cuboid : this.f_104212_) {
/*  82 */         ((CuboidSideAccessor)cuboid).resetSides();
/*     */       }
/*     */     }
/*  85 */     else if (this.workaround == ModelPartAccessor.Workaround.VanillaDraw) {
/*  86 */       if (!this.hasMutatedCuboid || (this.f_104212_.size() == 1 && ((MutableCuboid)this.f_104212_.get(0)).getActiveMutator() == null)) {
/*  87 */         m_104290_(entry, vertexConsumer, light, overlay, red, green, blue, alpha);
/*     */       } else {
/*     */         
/*  90 */         for (ModelPart.Cube cuboid : this.f_104212_) {
/*  91 */           cuboid.m_171332_(entry, vertexConsumer, light, overlay, red, green, blue, alpha);
/*     */         }
/*     */       } 
/*     */     } else {
/*     */       
/*  96 */       m_104290_(entry, vertexConsumer, light, overlay, red, green, blue, alpha);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setWorkaround(ModelPartAccessor.Workaround workaround) {
/* 102 */     this.workaround = workaround;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\bendy-lib-forge-2.1.3-test2.jar!\io\github\kosmx\bendylib\mixin\IModelPartMixin.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */