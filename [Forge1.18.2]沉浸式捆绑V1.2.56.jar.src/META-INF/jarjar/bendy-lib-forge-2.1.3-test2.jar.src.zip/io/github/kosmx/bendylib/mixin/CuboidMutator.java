/*     */ package io.github.kosmx.bendylib.mixin;
/*     */ 
/*     */ import com.mojang.blaze3d.vertex.PoseStack;
/*     */ import com.mojang.blaze3d.vertex.VertexConsumer;
/*     */ import io.github.kosmx.bendylib.ICuboidBuilder;
/*     */ import io.github.kosmx.bendylib.MutableCuboid;
/*     */ import io.github.kosmx.bendylib.impl.ICuboid;
/*     */ import io.github.kosmx.bendylib.impl.accessors.CuboidSideAccessor;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import net.minecraft.client.model.geom.ModelPart;
/*     */ import net.minecraft.util.Tuple;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ import org.spongepowered.asm.mixin.Final;
/*     */ import org.spongepowered.asm.mixin.Mixin;
/*     */ import org.spongepowered.asm.mixin.Mutable;
/*     */ import org.spongepowered.asm.mixin.Shadow;
/*     */ import org.spongepowered.asm.mixin.Unique;
/*     */ import org.spongepowered.asm.mixin.injection.At;
/*     */ import org.spongepowered.asm.mixin.injection.Inject;
/*     */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*     */ 
/*     */ @Mixin({ModelPart.Cube.class})
/*     */ public class CuboidMutator implements MutableCuboid, CuboidSideAccessor {
/*     */   @Shadow
/*     */   @Final
/*     */   public float f_104335_;
/*     */   @Shadow
/*     */   @Final
/*     */   public float f_104336_;
/*     */   @Unique
/*  32 */   private HashMap<String, ICuboid> mutators = new HashMap<>();
/*     */   
/*     */   @Unique
/*  35 */   private HashMap<String, ICuboidBuilder> mutatorBuilders = new HashMap<>();
/*     */ 
/*     */ 
/*     */   
/*     */   @Shadow
/*     */   @Final
/*     */   public float f_104337_;
/*     */ 
/*     */   
/*     */   @Mutable
/*     */   @Shadow
/*     */   @Final
/*     */   private ModelPart.Polygon[] f_104341_;
/*     */ 
/*     */   
/*     */   @Unique
/*     */   private ModelPart.Polygon[] originalQuads;
/*     */ 
/*     */ 
/*     */   
/*     */   @Inject(method = {"<init>"}, at = {@At("RETURN")})
/*     */   private void constructor(int u, int v, float x, float y, float z, float sizeX, float sizeY, float sizeZ, float extraX, float extraY, float extraZ, boolean mirror, float textureWidth, float textureHeight, CallbackInfo ci) {
/*  57 */     this.partData = new ICuboidBuilder.Data(u, v, this.f_104335_, this.f_104336_, this.f_104337_, sizeX, sizeY, sizeZ, extraX, extraY, extraZ, mirror, textureWidth, textureHeight);
/*  58 */     this.originalQuads = this.f_104341_; } @Unique
/*     */   private boolean isSidesSwapped = false; @Unique
/*     */   private ICuboidBuilder.Data partData; @Unique
/*     */   @Nullable
/*     */   private ICuboid activeMutator; @Unique
/*     */   @Nullable
/*  64 */   private String activeMutatorID; public boolean registerMutator(String name, ICuboidBuilder<ICuboid> builder) { if (this.mutatorBuilders.containsKey(name)) return false; 
/*  65 */     if (builder == null) throw new NullPointerException("builder can not be null"); 
/*  66 */     this.mutatorBuilders.put(name, builder);
/*  67 */     return true; }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean unregisterMutator(String name) {
/*  72 */     if (this.mutatorBuilders.remove(name) != null) {
/*  73 */       if (name.equals(this.activeMutatorID)) {
/*  74 */         this.activeMutator = null;
/*  75 */         this.activeMutatorID = null;
/*     */       } 
/*  77 */       this.mutators.remove(name);
/*     */       
/*  79 */       return true;
/*     */     } 
/*  81 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Tuple<String, ICuboid> getActiveMutator() {
/*  87 */     return (this.activeMutator == null) ? null : new Tuple(this.activeMutatorID, this.activeMutator);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasMutator(String key) {
/*  92 */     return (this.mutators.containsKey(key) || this.mutatorBuilders.containsKey(key));
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public ICuboidBuilder<ICuboid> getCuboidBuilder(String key) {
/*  98 */     return this.mutatorBuilders.get(key);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public ICuboid getMutator(String name) {
/* 104 */     return this.mutators.get(name);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public ICuboid getAndActivateMutator(@Nullable String name) {
/* 110 */     if (name == null) {
/* 111 */       this.activeMutatorID = null;
/* 112 */       this.activeMutator = null;
/* 113 */       return null;
/*     */     } 
/* 115 */     if (this.mutatorBuilders.containsKey(name)) {
/* 116 */       if (!this.mutators.containsKey(name)) {
/* 117 */         this.mutators.put(name, ((ICuboidBuilder)this.mutatorBuilders.get(name)).build(this.partData));
/*     */       }
/* 119 */       this.activeMutatorID = name;
/* 120 */       return this.activeMutator = this.mutators.get(name);
/*     */     } 
/* 122 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void copyStateFrom(MutableCuboid other) {
/* 128 */     if (other.getActiveMutator() == null) {
/* 129 */       this.activeMutator = null;
/* 130 */       this.activeMutatorID = null;
/*     */     
/*     */     }
/* 133 */     else if (getAndActivateMutator((String)other.getActiveMutator().m_14418_()) != null) {
/* 134 */       this.activeMutator.copyState((ICuboid)other.getActiveMutator().m_14419_());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @Inject(method = {"renderCuboid"}, at = {@At("HEAD")}, cancellable = true)
/*     */   private void renderRedirect(PoseStack.Pose entry, VertexConsumer vertexConsumer, int light, int overlay, float red, float green, float blue, float alpha, CallbackInfo ci) {
/* 141 */     if (getActiveMutator() != null) {
/* 142 */       ((ICuboid)getActiveMutator().m_14419_()).render(entry, vertexConsumer, red, green, blue, alpha, light, overlay);
/* 143 */       if (((ICuboid)getActiveMutator().m_14419_()).disableAfterDraw()) {
/* 144 */         this.activeMutator = null;
/* 145 */         this.activeMutatorID = null;
/*     */       } 
/* 147 */       ci.cancel();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void doSideSwapping() {
/* 153 */     if (getActiveMutator() != null) {
/* 154 */       List<ModelPart.Polygon> sides = ((ICuboid)getActiveMutator().m_14419_()).getQuads();
/* 155 */       if (sides != null) {
/* 156 */         this.isSidesSwapped = true;
/* 157 */         this.f_104341_ = sides.<ModelPart.Polygon>toArray(new ModelPart.Polygon[4]);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public ModelPart.Polygon[] getSides() {
/* 164 */     return this.f_104341_;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setSides(ModelPart.Polygon[] sides) {
/* 169 */     this.isSidesSwapped = true;
/* 170 */     this.f_104341_ = sides;
/*     */   }
/*     */ 
/*     */   
/*     */   public void resetSides() {
/* 175 */     this.f_104341_ = this.originalQuads;
/* 176 */     this.isSidesSwapped = false;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\bendy-lib-forge-2.1.3-test2.jar!\io\github\kosmx\bendylib\mixin\CuboidMutator.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */