/*     */ package io.github.kosmx.bendylib.compat.tr7zw;
/*     */ import com.mojang.math.Vector3f;
/*     */ import com.mojang.math.Vector4f;
/*     */ import dev.tr7zw.skinlayers.api.MeshTransformer;
/*     */ import io.github.kosmx.bendylib.ICuboidBuilder;
/*     */ import io.github.kosmx.bendylib.MutableCuboid;
/*     */ import io.github.kosmx.bendylib.impl.BendableCuboid;
/*     */ import io.github.kosmx.bendylib.impl.IBendable;
/*     */ import io.github.kosmx.bendylib.impl.ICuboid;
/*     */ import io.github.kosmx.bendylib.impl.IPosWithOrigin;
/*     */ import io.github.kosmx.bendylib.impl.RememberingPos;
/*     */ import java.util.Optional;
/*     */ import java.util.function.Consumer;
/*     */ import net.minecraft.client.model.geom.ModelPart;
/*     */ import net.minecraft.core.Direction;
/*     */ import net.minecraft.util.Tuple;
/*     */ import org.slf4j.Logger;
/*     */ 
/*     */ public class TDSkinCompat {
/*     */   public static void init(Logger logger) throws ClassNotFoundException, NoClassDefFoundError {
/*  21 */     logger.info("Initializing 3D Skin Layers compatibility");
/*     */     
/*  23 */     SkinLayersAPI.setupMeshTransformerProvider(modelPart -> {
/*     */           final Optional<MutableCuboid> sourceCuboidOptional = ModelPartAccessor.optionalGetCuboid(modelPart, 0);
/*     */           if (sourceCuboidOptional.isPresent() && ((MutableCuboid)sourceCuboidOptional.get()).getActiveMutator() != null) {
/*     */             Object patt1232$temp = ((MutableCuboid)sourceCuboidOptional.get()).getActiveMutator().m_14419_();
/*     */             if (patt1232$temp instanceof BendableCuboid) {
/*     */               final BendableCuboid bendableSource = (BendableCuboid)patt1232$temp;
/*     */               return new Bender(bendableSource)
/*     */                 {
/*     */                 
/*     */                 };
/*     */             } 
/*     */           } 
/*     */           return new MeshTransformer()
/*     */             {
/*     */               public void transform(Vector3f vec3f, Vector4f[] vector4fs) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/*     */               public void transform(ModelPart.Cube cuboid) {
/*  86 */                 ((MutableCuboid)cuboid).getAndActivateMutator(null);
/*     */               }
/*     */             };
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   public static Vector3f calculateNormal(Vector4f[] vertices) {
/*  94 */     Vector3f buf = new Vector3f(vertices[3]);
/*  95 */     buf.m_122261_(-1.0F);
/*  96 */     Vector3f vecB = new Vector3f(vertices[1]);
/*  97 */     vecB.m_122253_(buf);
/*  98 */     buf = new Vector3f(vertices[2]);
/*  99 */     buf.m_122261_(-1.0F);
/* 100 */     Vector3f vecA = new Vector3f(vertices[0]);
/* 101 */     vecA.m_122253_(buf);
/* 102 */     vecA.m_122279_(vecB);
/*     */     
/* 104 */     return vecA.m_122278_() ? vecA : Direction.NORTH.m_122432_();
/*     */   }
/*     */   
/*     */   private static class ModifiedBendableCuboid
/*     */     extends BendableCuboid {
/*     */     protected ModifiedBendableCuboid(BendableCuboid.Quad[] sides, RememberingPos[] positions, float minX, float minY, float minZ, float maxX, float maxY, float maxZ, float fixX, float fixY, float fixZ, Direction direction, IBendable.Plane basePlane, IBendable.Plane otherPlane, float fullSize) {
/* 110 */       super(sides, positions, minX, minY, minZ, maxX, maxY, maxZ, fixX, fixY, fixZ, direction, basePlane, otherPlane, fullSize);
/*     */     } }
/*     */   
/*     */   private static class BendyMeshTransformer implements IBendable {
/*     */     private final Direction bendDirection;
/*     */     private final float bendX;
/*     */     private final float bendY;
/*     */     private final float bendZ;
/*     */     private final IBendable.Plane basePlane;
/*     */     private final IBendable.Plane otherSidePlane;
/*     */     private final float bendHeight;
/*     */     
/*     */     private BendyMeshTransformer(Direction bendDirection, float bendX, float bendY, float bendZ, IBendable.Plane basePlane, IBendable.Plane otherSidePlane, float bendHeight) {
/* 123 */       this.bendDirection = bendDirection;
/* 124 */       this.bendX = bendX / 16.0F;
/* 125 */       this.bendY = bendY / 16.0F;
/* 126 */       this.bendZ = bendZ / 16.0F;
/* 127 */       this.basePlane = basePlane.scaled(0.0625F);
/* 128 */       this.otherSidePlane = otherSidePlane.scaled(0.0625F);
/* 129 */       this.bendHeight = bendHeight / 16.0F;
/*     */     }
/*     */     
/*     */     private BendyMeshTransformer(BendableCuboid cuboid) {
/* 133 */       this(cuboid.getBendDirection(), cuboid.getBendX(), cuboid.getBendY(), cuboid.getBendZ(), cuboid
/* 134 */           .getBasePlane(), cuboid.getOtherSidePlane(), cuboid.bendHeight());
/*     */     }
/*     */ 
/*     */     
/*     */     public float bendHeight() {
/* 139 */       return this.bendHeight;
/*     */     }
/*     */ 
/*     */     
/*     */     public Direction getBendDirection() {
/* 144 */       return this.bendDirection;
/*     */     }
/*     */ 
/*     */     
/*     */     public float getBendX() {
/* 149 */       return this.bendX;
/*     */     }
/*     */ 
/*     */     
/*     */     public float getBendY() {
/* 154 */       return this.bendY;
/*     */     }
/*     */ 
/*     */     
/*     */     public float getBendZ() {
/* 159 */       return this.bendZ;
/*     */     }
/*     */ 
/*     */     
/*     */     public IBendable.Plane getBasePlane() {
/* 164 */       return this.basePlane;
/*     */     }
/*     */ 
/*     */     
/*     */     public IBendable.Plane getOtherSidePlane() {
/* 169 */       return this.otherSidePlane;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\bendy-lib-forge-2.1.3-test2.jar!\io\github\kosmx\bendylib\compat\tr7zw\TDSkinCompat.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */