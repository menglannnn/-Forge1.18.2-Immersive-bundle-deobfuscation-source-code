/*    */ package io.github.kosmx.bendylib;
/*    */ 
/*    */ import io.github.kosmx.bendylib.impl.accessors.IModelPartAccessor;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.Optional;
/*    */ import java.util.function.Supplier;
/*    */ import net.minecraft.client.model.geom.ModelPart;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ModelPartAccessor
/*    */ {
/*    */   public static Map<String, ModelPart> getChildren(ModelPart modelPart) {
/* 16 */     return ((IModelPartAccessor)modelPart).getChildren();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Deprecated
/*    */   public static MutableCuboid getCuboid(ModelPart modelPart, int index) {
/* 28 */     Optional<MutableCuboid> optionalMutableCuboid = optionalGetCuboid(modelPart, index);
/* 29 */     return optionalMutableCuboid.orElseGet(io.github.kosmx.bendylib.impl.DummyCuboid::new);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Optional<MutableCuboid> optionalGetCuboid(ModelPart modelPart, int index) {
/* 40 */     if (modelPart == null || getCuboids(modelPart) == null || getCuboids(modelPart).size() <= index) return Optional.empty(); 
/* 41 */     return Optional.of((MutableCuboid)getCuboids(modelPart).get(index));
/*    */   }
/*    */   
/*    */   public static List<ModelPart.Cube> getCuboids(ModelPart modelPart) {
/* 45 */     return ((IModelPartAccessor)modelPart).getCuboids();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public enum Workaround
/*    */   {
/* 53 */     ExportQuads, VanillaDraw, None;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\bendy-lib-forge-2.1.3-test2.jar!\io\github\kosmx\bendylib\ModelPartAccessor.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */