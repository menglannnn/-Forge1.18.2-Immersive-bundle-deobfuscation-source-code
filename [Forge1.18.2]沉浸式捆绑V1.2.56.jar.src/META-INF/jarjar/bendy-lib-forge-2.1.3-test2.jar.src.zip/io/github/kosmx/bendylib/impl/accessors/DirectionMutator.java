package io.github.kosmx.bendylib.impl.accessors;

import com.mojang.math.Vector3f;

public interface DirectionMutator {
  void setDirection(Vector3f paramVector3f);
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\bendy-lib-forge-2.1.3-test2.jar!\io\github\kosmx\bendylib\impl\accessors\DirectionMutator.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */