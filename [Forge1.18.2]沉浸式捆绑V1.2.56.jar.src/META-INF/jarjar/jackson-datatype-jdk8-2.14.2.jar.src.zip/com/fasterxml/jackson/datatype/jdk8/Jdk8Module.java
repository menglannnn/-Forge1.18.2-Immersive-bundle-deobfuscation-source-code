/*     */ package com.fasterxml.jackson.datatype.jdk8;
/*     */ 
/*     */ import com.fasterxml.jackson.core.Version;
/*     */ import com.fasterxml.jackson.databind.Module;
/*     */ import com.fasterxml.jackson.databind.deser.Deserializers;
/*     */ import com.fasterxml.jackson.databind.ser.Serializers;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Jdk8Module
/*     */   extends Module
/*     */ {
/*     */   public static final boolean DEFAULT_READ_ABSENT_AS_NULL = false;
/*     */   protected boolean _cfgWriteAbsentAsNull = false;
/*     */   protected boolean _cfgReadAbsentAsNull = false;
/*     */   
/*     */   public void setupModule(Module.SetupContext context) {
/*  39 */     context.addSerializers((Serializers)new Jdk8Serializers());
/*  40 */     context.addDeserializers((Deserializers)new Jdk8Deserializers(this._cfgReadAbsentAsNull));
/*     */     
/*  42 */     context.addTypeModifier(new Jdk8TypeModifier());
/*     */ 
/*     */     
/*  45 */     if (this._cfgWriteAbsentAsNull) {
/*  46 */       context.addBeanSerializerModifier(new Jdk8BeanSerializerModifier());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public Version version() {
/*  52 */     return PackageVersion.VERSION;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Jdk8Module configureAbsentsAsNulls(boolean state) {
/*  77 */     this._cfgWriteAbsentAsNull = state;
/*  78 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Jdk8Module configureReadAbsentAsNull(boolean state) {
/*  95 */     this._cfgReadAbsentAsNull = state;
/*  96 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 101 */     return getClass().hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 106 */     return (this == o);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getModuleName() {
/* 111 */     return "Jdk8Module";
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-datatype-jdk8-2.14.2.jar!\com\fasterxml\jackson\datatype\jdk8\Jdk8Module.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */