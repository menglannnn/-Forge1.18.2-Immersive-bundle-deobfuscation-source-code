/*    */ package com.fasterxml.jackson.datatype.jdk8;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WrappedIOException
/*    */   extends RuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public WrappedIOException(IOException cause) {
/* 21 */     super(cause);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public IOException getCause() {
/* 31 */     return (IOException)super.getCause();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-datatype-jdk8-2.14.2.jar!\com\fasterxml\jackson\datatype\jdk8\WrappedIOException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */