module com.fasterxml.jackson.datatype.jdk8 {
  requires com.fasterxml.jackson.core;
  requires com.fasterxml.jackson.databind;
  requires java.base;
  
  exports com.fasterxml.jackson.datatype.jdk8;
  
  provides com.fasterxml.jackson.databind.Module with com.fasterxml.jackson.datatype.jdk8.Jdk8Module;
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-datatype-jdk8-2.14.2.jar!\META-INF\versions\9\module-info.class
 * Java compiler version: 9 (53.0)
 * JD-Core Version:       1.1.3
 */