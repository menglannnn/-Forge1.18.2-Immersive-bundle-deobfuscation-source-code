/*    */ package io.netty.handler.pcap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ enum State
/*    */ {
/* 26 */   INIT,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 31 */   WRITING,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 36 */   PAUSED,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 41 */   CLOSED;
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-handler-4.1.93.Final.jar!\io\netty\handler\pcap\State.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */