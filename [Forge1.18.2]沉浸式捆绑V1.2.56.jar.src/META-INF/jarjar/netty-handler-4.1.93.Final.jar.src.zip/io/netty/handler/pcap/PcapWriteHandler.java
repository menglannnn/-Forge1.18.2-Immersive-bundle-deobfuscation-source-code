/*     */ package io.netty.handler.pcap;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.buffer.ByteBufAllocator;
/*     */ import io.netty.channel.ChannelDuplexHandler;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.channel.ChannelPromise;
/*     */ import io.netty.channel.socket.DatagramChannel;
/*     */ import io.netty.channel.socket.DatagramPacket;
/*     */ import io.netty.util.NetUtil;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import io.netty.util.internal.logging.InternalLogger;
/*     */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*     */ import java.io.Closeable;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.net.Inet4Address;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PcapWriteHandler
/*     */   extends ChannelDuplexHandler
/*     */   implements Closeable
/*     */ {
/*  72 */   private final InternalLogger logger = InternalLoggerFactory.getInstance(PcapWriteHandler.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private PcapWriter pCapWriter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final OutputStream outputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final boolean captureZeroByte;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final boolean writePcapGlobalHeader;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final boolean sharedOutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 105 */   private int sendSegmentNumber = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 111 */   private int receiveSegmentNumber = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ChannelType channelType;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private InetSocketAddress initiatorAddr;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private InetSocketAddress handlerAddr;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isServerPipeline;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 136 */   private final AtomicReference<State> state = new AtomicReference<State>(State.INIT);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public PcapWriteHandler(OutputStream outputStream) {
/* 152 */     this(outputStream, false, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public PcapWriteHandler(OutputStream outputStream, boolean captureZeroByte, boolean writePcapGlobalHeader) {
/* 173 */     this.outputStream = (OutputStream)ObjectUtil.checkNotNull(outputStream, "OutputStream");
/* 174 */     this.captureZeroByte = captureZeroByte;
/* 175 */     this.writePcapGlobalHeader = writePcapGlobalHeader;
/* 176 */     this.sharedOutputStream = false;
/*     */   }
/*     */   
/*     */   private PcapWriteHandler(Builder builder, OutputStream outputStream) {
/* 180 */     this.outputStream = outputStream;
/* 181 */     this.captureZeroByte = builder.captureZeroByte;
/* 182 */     this.sharedOutputStream = builder.sharedOutputStream;
/* 183 */     this.writePcapGlobalHeader = builder.writePcapGlobalHeader;
/* 184 */     this.channelType = builder.channelType;
/* 185 */     this.handlerAddr = builder.handlerAddr;
/* 186 */     this.initiatorAddr = builder.initiatorAddr;
/* 187 */     this.isServerPipeline = builder.isServerPipeline;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void writeGlobalHeader(OutputStream outputStream) throws IOException {
/* 197 */     PcapHeaders.writeGlobalHeader(outputStream);
/*     */   }
/*     */ 
/*     */   
/*     */   private void initializeIfNecessary(ChannelHandlerContext ctx) throws Exception {
/* 202 */     if (this.state.get() != State.INIT) {
/*     */       return;
/*     */     }
/*     */     
/* 206 */     this.pCapWriter = new PcapWriter(this);
/*     */     
/* 208 */     if (this.channelType == null)
/*     */     {
/* 210 */       if (ctx.channel() instanceof io.netty.channel.socket.SocketChannel) {
/* 211 */         this.channelType = ChannelType.TCP;
/*     */ 
/*     */ 
/*     */         
/* 215 */         if (ctx.channel().parent() instanceof io.netty.channel.socket.ServerSocketChannel) {
/* 216 */           this.isServerPipeline = true;
/* 217 */           this.initiatorAddr = (InetSocketAddress)ctx.channel().remoteAddress();
/* 218 */           this.handlerAddr = (InetSocketAddress)ctx.channel().localAddress();
/*     */         } else {
/* 220 */           this.isServerPipeline = false;
/* 221 */           this.initiatorAddr = (InetSocketAddress)ctx.channel().localAddress();
/* 222 */           this.handlerAddr = (InetSocketAddress)ctx.channel().remoteAddress();
/*     */         } 
/* 224 */       } else if (ctx.channel() instanceof DatagramChannel) {
/* 225 */         this.channelType = ChannelType.UDP;
/*     */         
/* 227 */         DatagramChannel datagramChannel = (DatagramChannel)ctx.channel();
/*     */ 
/*     */ 
/*     */         
/* 231 */         if (datagramChannel.isConnected()) {
/* 232 */           this.initiatorAddr = (InetSocketAddress)ctx.channel().localAddress();
/* 233 */           this.handlerAddr = (InetSocketAddress)ctx.channel().remoteAddress();
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/* 238 */     if (this.channelType == ChannelType.TCP) {
/* 239 */       this.logger.debug("Initiating Fake TCP 3-Way Handshake");
/*     */       
/* 241 */       ByteBuf tcpBuf = ctx.alloc().buffer();
/*     */ 
/*     */       
/*     */       try {
/* 245 */         TCPPacket.writePacket(tcpBuf, null, 0, 0, this.initiatorAddr
/* 246 */             .getPort(), this.handlerAddr.getPort(), new TCPPacket.TCPFlag[] { TCPPacket.TCPFlag.SYN });
/* 247 */         completeTCPWrite(this.initiatorAddr, this.handlerAddr, tcpBuf, ctx.alloc(), ctx);
/*     */ 
/*     */         
/* 250 */         TCPPacket.writePacket(tcpBuf, null, 0, 1, this.handlerAddr
/* 251 */             .getPort(), this.initiatorAddr.getPort(), new TCPPacket.TCPFlag[] { TCPPacket.TCPFlag.SYN, TCPPacket.TCPFlag.ACK });
/* 252 */         completeTCPWrite(this.handlerAddr, this.initiatorAddr, tcpBuf, ctx.alloc(), ctx);
/*     */ 
/*     */         
/* 255 */         TCPPacket.writePacket(tcpBuf, null, 1, 1, this.initiatorAddr.getPort(), this.handlerAddr
/* 256 */             .getPort(), new TCPPacket.TCPFlag[] { TCPPacket.TCPFlag.ACK });
/* 257 */         completeTCPWrite(this.initiatorAddr, this.handlerAddr, tcpBuf, ctx.alloc(), ctx);
/*     */       } finally {
/* 259 */         tcpBuf.release();
/*     */       } 
/*     */       
/* 262 */       this.logger.debug("Finished Fake TCP 3-Way Handshake");
/*     */     } 
/*     */     
/* 265 */     this.state.set(State.WRITING);
/*     */   }
/*     */ 
/*     */   
/*     */   public void channelActive(ChannelHandlerContext ctx) throws Exception {
/* 270 */     initializeIfNecessary(ctx);
/* 271 */     super.channelActive(ctx);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
/* 277 */     if (this.state.get() == State.INIT) {
/* 278 */       initializeIfNecessary(ctx);
/*     */     }
/*     */ 
/*     */     
/* 282 */     if (this.state.get() == State.WRITING) {
/* 283 */       if (this.channelType == ChannelType.TCP) {
/* 284 */         handleTCP(ctx, msg, false);
/* 285 */       } else if (this.channelType == ChannelType.UDP) {
/* 286 */         handleUDP(ctx, msg);
/*     */       } else {
/* 288 */         logDiscard();
/*     */       } 
/*     */     }
/* 291 */     super.channelRead(ctx, msg);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(ChannelHandlerContext ctx, Object msg, ChannelPromise promise) throws Exception {
/* 297 */     if (this.state.get() == State.INIT) {
/* 298 */       initializeIfNecessary(ctx);
/*     */     }
/*     */ 
/*     */     
/* 302 */     if (this.state.get() == State.WRITING) {
/* 303 */       if (this.channelType == ChannelType.TCP) {
/* 304 */         handleTCP(ctx, msg, true);
/* 305 */       } else if (this.channelType == ChannelType.UDP) {
/* 306 */         handleUDP(ctx, msg);
/*     */       } else {
/* 308 */         logDiscard();
/*     */       } 
/*     */     }
/* 311 */     super.write(ctx, msg, promise);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void handleTCP(ChannelHandlerContext ctx, Object msg, boolean isWriteOperation) {
/* 324 */     if (msg instanceof ByteBuf) {
/*     */ 
/*     */       
/* 327 */       if (((ByteBuf)msg).readableBytes() == 0 && !this.captureZeroByte) {
/* 328 */         this.logger.debug("Discarding Zero Byte TCP Packet. isWriteOperation {}", Boolean.valueOf(isWriteOperation));
/*     */         
/*     */         return;
/*     */       } 
/* 332 */       ByteBufAllocator byteBufAllocator = ctx.alloc();
/* 333 */       ByteBuf packet = ((ByteBuf)msg).duplicate();
/* 334 */       ByteBuf tcpBuf = byteBufAllocator.buffer();
/* 335 */       int bytes = packet.readableBytes();
/*     */       
/*     */       try {
/* 338 */         if (isWriteOperation) {
/*     */           InetSocketAddress srcAddr, dstAddr;
/*     */           
/* 341 */           if (this.isServerPipeline) {
/* 342 */             srcAddr = this.handlerAddr;
/* 343 */             dstAddr = this.initiatorAddr;
/*     */           } else {
/* 345 */             srcAddr = this.initiatorAddr;
/* 346 */             dstAddr = this.handlerAddr;
/*     */           } 
/*     */           
/* 349 */           TCPPacket.writePacket(tcpBuf, packet, this.sendSegmentNumber, this.receiveSegmentNumber, srcAddr.getPort(), dstAddr
/* 350 */               .getPort(), new TCPPacket.TCPFlag[] { TCPPacket.TCPFlag.ACK });
/* 351 */           completeTCPWrite(srcAddr, dstAddr, tcpBuf, byteBufAllocator, ctx);
/* 352 */           logTCP(true, bytes, this.sendSegmentNumber, this.receiveSegmentNumber, srcAddr, dstAddr, false);
/*     */           
/* 354 */           this.sendSegmentNumber += bytes;
/*     */           
/* 356 */           TCPPacket.writePacket(tcpBuf, null, this.receiveSegmentNumber, this.sendSegmentNumber, dstAddr.getPort(), srcAddr
/* 357 */               .getPort(), new TCPPacket.TCPFlag[] { TCPPacket.TCPFlag.ACK });
/* 358 */           completeTCPWrite(dstAddr, srcAddr, tcpBuf, byteBufAllocator, ctx);
/* 359 */           logTCP(true, bytes, this.sendSegmentNumber, this.receiveSegmentNumber, dstAddr, srcAddr, true);
/*     */         } else {
/*     */           InetSocketAddress srcAddr, dstAddr;
/*     */           
/* 363 */           if (this.isServerPipeline) {
/* 364 */             srcAddr = this.initiatorAddr;
/* 365 */             dstAddr = this.handlerAddr;
/*     */           } else {
/* 367 */             srcAddr = this.handlerAddr;
/* 368 */             dstAddr = this.initiatorAddr;
/*     */           } 
/*     */           
/* 371 */           TCPPacket.writePacket(tcpBuf, packet, this.receiveSegmentNumber, this.sendSegmentNumber, srcAddr.getPort(), dstAddr
/* 372 */               .getPort(), new TCPPacket.TCPFlag[] { TCPPacket.TCPFlag.ACK });
/* 373 */           completeTCPWrite(srcAddr, dstAddr, tcpBuf, byteBufAllocator, ctx);
/* 374 */           logTCP(false, bytes, this.receiveSegmentNumber, this.sendSegmentNumber, srcAddr, dstAddr, false);
/*     */           
/* 376 */           this.receiveSegmentNumber += bytes;
/*     */           
/* 378 */           TCPPacket.writePacket(tcpBuf, null, this.sendSegmentNumber, this.receiveSegmentNumber, dstAddr.getPort(), srcAddr
/* 379 */               .getPort(), new TCPPacket.TCPFlag[] { TCPPacket.TCPFlag.ACK });
/* 380 */           completeTCPWrite(dstAddr, srcAddr, tcpBuf, byteBufAllocator, ctx);
/* 381 */           logTCP(false, bytes, this.sendSegmentNumber, this.receiveSegmentNumber, dstAddr, srcAddr, true);
/*     */         } 
/*     */       } finally {
/* 384 */         tcpBuf.release();
/*     */       } 
/*     */     } else {
/* 387 */       this.logger.debug("Discarding Pcap Write for TCP Object: {}", msg);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void completeTCPWrite(InetSocketAddress srcAddr, InetSocketAddress dstAddr, ByteBuf tcpBuf, ByteBufAllocator byteBufAllocator, ChannelHandlerContext ctx) {
/* 403 */     ByteBuf ipBuf = byteBufAllocator.buffer();
/* 404 */     ByteBuf ethernetBuf = byteBufAllocator.buffer();
/* 405 */     ByteBuf pcap = byteBufAllocator.buffer();
/*     */     
/*     */     try {
/* 408 */       if (srcAddr.getAddress() instanceof Inet4Address && dstAddr.getAddress() instanceof Inet4Address) {
/* 409 */         IPPacket.writeTCPv4(ipBuf, tcpBuf, 
/* 410 */             NetUtil.ipv4AddressToInt((Inet4Address)srcAddr.getAddress()), 
/* 411 */             NetUtil.ipv4AddressToInt((Inet4Address)dstAddr.getAddress()));
/*     */         
/* 413 */         EthernetPacket.writeIPv4(ethernetBuf, ipBuf);
/* 414 */       } else if (srcAddr.getAddress() instanceof java.net.Inet6Address && dstAddr.getAddress() instanceof java.net.Inet6Address) {
/* 415 */         IPPacket.writeTCPv6(ipBuf, tcpBuf, srcAddr
/* 416 */             .getAddress().getAddress(), dstAddr
/* 417 */             .getAddress().getAddress());
/*     */         
/* 419 */         EthernetPacket.writeIPv6(ethernetBuf, ipBuf);
/*     */       } else {
/* 421 */         this.logger.error("Source and Destination IP Address versions are not same. Source Address: {}, Destination Address: {}", srcAddr
/* 422 */             .getAddress(), dstAddr.getAddress());
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/* 427 */       this.pCapWriter.writePacket(pcap, ethernetBuf);
/* 428 */     } catch (IOException ex) {
/* 429 */       this.logger.error("Caught Exception While Writing Packet into Pcap", ex);
/* 430 */       ctx.fireExceptionCaught(ex);
/*     */     } finally {
/* 432 */       ipBuf.release();
/* 433 */       ethernetBuf.release();
/* 434 */       pcap.release();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void handleUDP(ChannelHandlerContext ctx, Object msg) {
/* 446 */     ByteBuf udpBuf = ctx.alloc().buffer();
/*     */     
/*     */     try {
/* 449 */       if (msg instanceof DatagramPacket) {
/*     */ 
/*     */         
/* 452 */         if (((ByteBuf)((DatagramPacket)msg).content()).readableBytes() == 0 && !this.captureZeroByte) {
/* 453 */           this.logger.debug("Discarding Zero Byte UDP Packet");
/*     */           
/*     */           return;
/*     */         } 
/* 457 */         DatagramPacket datagramPacket = ((DatagramPacket)msg).duplicate();
/* 458 */         InetSocketAddress srcAddr = (InetSocketAddress)datagramPacket.sender();
/* 459 */         InetSocketAddress dstAddr = (InetSocketAddress)datagramPacket.recipient();
/*     */ 
/*     */ 
/*     */         
/* 463 */         if (srcAddr == null) {
/* 464 */           srcAddr = (InetSocketAddress)ctx.channel().localAddress();
/*     */         }
/*     */         
/* 467 */         this.logger.debug("Writing UDP Data of {} Bytes, Src Addr {}, Dst Addr {}", new Object[] {
/* 468 */               Integer.valueOf(((ByteBuf)datagramPacket.content()).readableBytes()), srcAddr, dstAddr
/*     */             });
/* 470 */         UDPPacket.writePacket(udpBuf, (ByteBuf)datagramPacket.content(), srcAddr.getPort(), dstAddr.getPort());
/* 471 */         completeUDPWrite(srcAddr, dstAddr, udpBuf, ctx.alloc(), ctx);
/* 472 */       } else if (msg instanceof ByteBuf && (
/* 473 */         !(ctx.channel() instanceof DatagramChannel) || ((DatagramChannel)ctx.channel()).isConnected())) {
/*     */ 
/*     */         
/* 476 */         if (((ByteBuf)msg).readableBytes() == 0 && !this.captureZeroByte) {
/* 477 */           this.logger.debug("Discarding Zero Byte UDP Packet");
/*     */           
/*     */           return;
/*     */         } 
/* 481 */         ByteBuf byteBuf = ((ByteBuf)msg).duplicate();
/*     */         
/* 483 */         this.logger.debug("Writing UDP Data of {} Bytes, Src Addr {}, Dst Addr {}", new Object[] {
/* 484 */               Integer.valueOf(byteBuf.readableBytes()), this.initiatorAddr, this.handlerAddr
/*     */             });
/* 486 */         UDPPacket.writePacket(udpBuf, byteBuf, this.initiatorAddr.getPort(), this.handlerAddr.getPort());
/* 487 */         completeUDPWrite(this.initiatorAddr, this.handlerAddr, udpBuf, ctx.alloc(), ctx);
/*     */       } else {
/* 489 */         this.logger.debug("Discarding Pcap Write for UDP Object: {}", msg);
/*     */       } 
/*     */     } finally {
/* 492 */       udpBuf.release();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void completeUDPWrite(InetSocketAddress srcAddr, InetSocketAddress dstAddr, ByteBuf udpBuf, ByteBufAllocator byteBufAllocator, ChannelHandlerContext ctx) {
/* 508 */     ByteBuf ipBuf = byteBufAllocator.buffer();
/* 509 */     ByteBuf ethernetBuf = byteBufAllocator.buffer();
/* 510 */     ByteBuf pcap = byteBufAllocator.buffer();
/*     */     
/*     */     try {
/* 513 */       if (srcAddr.getAddress() instanceof Inet4Address && dstAddr.getAddress() instanceof Inet4Address) {
/* 514 */         IPPacket.writeUDPv4(ipBuf, udpBuf, 
/* 515 */             NetUtil.ipv4AddressToInt((Inet4Address)srcAddr.getAddress()), 
/* 516 */             NetUtil.ipv4AddressToInt((Inet4Address)dstAddr.getAddress()));
/*     */         
/* 518 */         EthernetPacket.writeIPv4(ethernetBuf, ipBuf);
/* 519 */       } else if (srcAddr.getAddress() instanceof java.net.Inet6Address && dstAddr.getAddress() instanceof java.net.Inet6Address) {
/* 520 */         IPPacket.writeUDPv6(ipBuf, udpBuf, srcAddr
/* 521 */             .getAddress().getAddress(), dstAddr
/* 522 */             .getAddress().getAddress());
/*     */         
/* 524 */         EthernetPacket.writeIPv6(ethernetBuf, ipBuf);
/*     */       } else {
/* 526 */         this.logger.error("Source and Destination IP Address versions are not same. Source Address: {}, Destination Address: {}", srcAddr
/* 527 */             .getAddress(), dstAddr.getAddress());
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/* 532 */       this.pCapWriter.writePacket(pcap, ethernetBuf);
/* 533 */     } catch (IOException ex) {
/* 534 */       this.logger.error("Caught Exception While Writing Packet into Pcap", ex);
/* 535 */       ctx.fireExceptionCaught(ex);
/*     */     } finally {
/* 537 */       ipBuf.release();
/* 538 */       ethernetBuf.release();
/* 539 */       pcap.release();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void handlerRemoved(ChannelHandlerContext ctx) throws Exception {
/* 547 */     if (this.channelType == ChannelType.TCP) {
/* 548 */       this.logger.debug("Starting Fake TCP FIN+ACK Flow to close connection");
/*     */       
/* 550 */       ByteBufAllocator byteBufAllocator = ctx.alloc();
/* 551 */       ByteBuf tcpBuf = byteBufAllocator.buffer();
/*     */ 
/*     */       
/*     */       try {
/* 555 */         TCPPacket.writePacket(tcpBuf, null, this.sendSegmentNumber, this.receiveSegmentNumber, this.initiatorAddr.getPort(), this.handlerAddr
/* 556 */             .getPort(), new TCPPacket.TCPFlag[] { TCPPacket.TCPFlag.FIN, TCPPacket.TCPFlag.ACK });
/* 557 */         completeTCPWrite(this.initiatorAddr, this.handlerAddr, tcpBuf, byteBufAllocator, ctx);
/*     */ 
/*     */         
/* 560 */         TCPPacket.writePacket(tcpBuf, null, this.receiveSegmentNumber, this.sendSegmentNumber, this.handlerAddr.getPort(), this.initiatorAddr
/* 561 */             .getPort(), new TCPPacket.TCPFlag[] { TCPPacket.TCPFlag.FIN, TCPPacket.TCPFlag.ACK });
/* 562 */         completeTCPWrite(this.handlerAddr, this.initiatorAddr, tcpBuf, byteBufAllocator, ctx);
/*     */ 
/*     */         
/* 565 */         TCPPacket.writePacket(tcpBuf, null, this.sendSegmentNumber + 1, this.receiveSegmentNumber + 1, this.initiatorAddr
/* 566 */             .getPort(), this.handlerAddr.getPort(), new TCPPacket.TCPFlag[] { TCPPacket.TCPFlag.ACK });
/* 567 */         completeTCPWrite(this.initiatorAddr, this.handlerAddr, tcpBuf, byteBufAllocator, ctx);
/*     */       } finally {
/* 569 */         tcpBuf.release();
/*     */       } 
/*     */       
/* 572 */       this.logger.debug("Finished Fake TCP FIN+ACK Flow to close connection");
/*     */     } 
/*     */     
/* 575 */     close();
/* 576 */     super.handlerRemoved(ctx);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
/* 582 */     if (this.channelType == ChannelType.TCP) {
/* 583 */       ByteBuf tcpBuf = ctx.alloc().buffer();
/*     */ 
/*     */       
/*     */       try {
/* 587 */         TCPPacket.writePacket(tcpBuf, null, this.sendSegmentNumber, this.receiveSegmentNumber, this.initiatorAddr.getPort(), this.handlerAddr
/* 588 */             .getPort(), new TCPPacket.TCPFlag[] { TCPPacket.TCPFlag.RST, TCPPacket.TCPFlag.ACK });
/* 589 */         completeTCPWrite(this.initiatorAddr, this.handlerAddr, tcpBuf, ctx.alloc(), ctx);
/*     */       } finally {
/* 591 */         tcpBuf.release();
/*     */       } 
/*     */       
/* 594 */       this.logger.debug("Sent Fake TCP RST to close connection");
/*     */     } 
/*     */     
/* 597 */     close();
/* 598 */     ctx.fireExceptionCaught(cause);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void logTCP(boolean isWriteOperation, int bytes, int sendSegmentNumber, int receiveSegmentNumber, InetSocketAddress srcAddr, InetSocketAddress dstAddr, boolean ackOnly) {
/* 608 */     if (this.logger.isDebugEnabled())
/* 609 */       if (ackOnly) {
/* 610 */         this.logger.debug("Writing TCP ACK, isWriteOperation {}, Segment Number {}, Ack Number {}, Src Addr {}, Dst Addr {}", new Object[] {
/* 611 */               Boolean.valueOf(isWriteOperation), Integer.valueOf(sendSegmentNumber), Integer.valueOf(receiveSegmentNumber), dstAddr, srcAddr });
/*     */       } else {
/* 613 */         this.logger.debug("Writing TCP Data of {} Bytes, isWriteOperation {}, Segment Number {}, Ack Number {}, Src Addr {}, Dst Addr {}", new Object[] {
/* 614 */               Integer.valueOf(bytes), Boolean.valueOf(isWriteOperation), Integer.valueOf(sendSegmentNumber), 
/* 615 */               Integer.valueOf(receiveSegmentNumber), srcAddr, dstAddr
/*     */             });
/*     */       }  
/*     */   }
/*     */   
/*     */   OutputStream outputStream() {
/* 621 */     return this.outputStream;
/*     */   }
/*     */   
/*     */   boolean sharedOutputStream() {
/* 625 */     return this.sharedOutputStream;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isWriting() {
/* 633 */     return (this.state.get() == State.WRITING);
/*     */   }
/*     */   
/*     */   State state() {
/* 637 */     return this.state.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void pause() {
/* 644 */     if (!this.state.compareAndSet(State.WRITING, State.PAUSED)) {
/* 645 */       throw new IllegalStateException("State must be 'STARTED' to pause but current state is: " + this.state);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resume() {
/* 653 */     if (!this.state.compareAndSet(State.PAUSED, State.WRITING)) {
/* 654 */       throw new IllegalStateException("State must be 'PAUSED' to resume but current state is: " + this.state);
/*     */     }
/*     */   }
/*     */   
/*     */   void markClosed() {
/* 659 */     if (this.state.get() != State.CLOSED) {
/* 660 */       this.state.set(State.CLOSED);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   PcapWriter pCapWriter() {
/* 666 */     return this.pCapWriter;
/*     */   }
/*     */   
/*     */   private void logDiscard() {
/* 670 */     this.logger.warn("Discarding pcap write because channel type is unknown. The channel this handler is registered on is not a SocketChannel or DatagramChannel, so the inference does not work. Please call forceTcpChannel or forceUdpChannel before registering the handler.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 677 */     return "PcapWriteHandler{captureZeroByte=" + this.captureZeroByte + ", writePcapGlobalHeader=" + this.writePcapGlobalHeader + ", sharedOutputStream=" + this.sharedOutputStream + ", sendSegmentNumber=" + this.sendSegmentNumber + ", receiveSegmentNumber=" + this.receiveSegmentNumber + ", channelType=" + this.channelType + ", initiatorAddr=" + this.initiatorAddr + ", handlerAddr=" + this.handlerAddr + ", isServerPipeline=" + this.isServerPipeline + ", state=" + this.state + '}';
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 700 */     if (this.state.get() == State.CLOSED) {
/* 701 */       this.logger.debug("PcapWriterHandler is already closed");
/*     */     } else {
/* 703 */       markClosed();
/* 704 */       this.pCapWriter.close();
/* 705 */       this.logger.debug("PcapWriterHandler is now closed");
/*     */     } 
/*     */   }
/*     */   
/*     */   private enum ChannelType {
/* 710 */     TCP, UDP;
/*     */   }
/*     */   
/*     */   public static Builder builder() {
/* 714 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Builder
/*     */   {
/*     */     private boolean captureZeroByte;
/*     */ 
/*     */     
/*     */     private boolean sharedOutputStream;
/*     */ 
/*     */     
/*     */     private boolean writePcapGlobalHeader = true;
/*     */ 
/*     */     
/*     */     private PcapWriteHandler.ChannelType channelType;
/*     */ 
/*     */     
/*     */     private InetSocketAddress initiatorAddr;
/*     */     
/*     */     private InetSocketAddress handlerAddr;
/*     */     
/*     */     private boolean isServerPipeline;
/*     */ 
/*     */     
/*     */     public Builder captureZeroByte(boolean captureZeroByte) {
/* 741 */       this.captureZeroByte = captureZeroByte;
/* 742 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder sharedOutputStream(boolean sharedOutputStream) {
/* 757 */       this.sharedOutputStream = sharedOutputStream;
/* 758 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder writePcapGlobalHeader(boolean writePcapGlobalHeader) {
/* 770 */       this.writePcapGlobalHeader = writePcapGlobalHeader;
/* 771 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder forceTcpChannel(InetSocketAddress serverAddress, InetSocketAddress clientAddress, boolean isServerPipeline) {
/* 785 */       this.channelType = PcapWriteHandler.ChannelType.TCP;
/* 786 */       this.handlerAddr = (InetSocketAddress)ObjectUtil.checkNotNull(serverAddress, "serverAddress");
/* 787 */       this.initiatorAddr = (InetSocketAddress)ObjectUtil.checkNotNull(clientAddress, "clientAddress");
/* 788 */       this.isServerPipeline = isServerPipeline;
/* 789 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder forceUdpChannel(InetSocketAddress localAddress, InetSocketAddress remoteAddress) {
/* 804 */       this.channelType = PcapWriteHandler.ChannelType.UDP;
/* 805 */       this.handlerAddr = (InetSocketAddress)ObjectUtil.checkNotNull(remoteAddress, "remoteAddress");
/* 806 */       this.initiatorAddr = (InetSocketAddress)ObjectUtil.checkNotNull(localAddress, "localAddress");
/* 807 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public PcapWriteHandler build(OutputStream outputStream) {
/* 817 */       ObjectUtil.checkNotNull(outputStream, "outputStream");
/* 818 */       return new PcapWriteHandler(this, outputStream);
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-handler-4.1.93.Final.jar!\io\netty\handler\pcap\PcapWriteHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */