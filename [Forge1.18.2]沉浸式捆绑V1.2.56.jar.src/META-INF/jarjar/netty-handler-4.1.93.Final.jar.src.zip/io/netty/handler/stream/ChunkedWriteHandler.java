/*     */ package io.netty.handler.stream;
/*     */ 
/*     */ import io.netty.buffer.ByteBufAllocator;
/*     */ import io.netty.buffer.Unpooled;
/*     */ import io.netty.channel.Channel;
/*     */ import io.netty.channel.ChannelDuplexHandler;
/*     */ import io.netty.channel.ChannelFuture;
/*     */ import io.netty.channel.ChannelFutureListener;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.channel.ChannelProgressivePromise;
/*     */ import io.netty.channel.ChannelPromise;
/*     */ import io.netty.util.ReferenceCountUtil;
/*     */ import io.netty.util.concurrent.Future;
/*     */ import io.netty.util.concurrent.GenericFutureListener;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import io.netty.util.internal.logging.InternalLogger;
/*     */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*     */ import java.nio.channels.ClosedChannelException;
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.Queue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ChunkedWriteHandler
/*     */   extends ChannelDuplexHandler
/*     */ {
/*  73 */   private static final InternalLogger logger = InternalLoggerFactory.getInstance(ChunkedWriteHandler.class);
/*     */   
/*  75 */   private final Queue<PendingWrite> queue = new ArrayDeque<PendingWrite>();
/*     */ 
/*     */ 
/*     */   
/*     */   private volatile ChannelHandlerContext ctx;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public ChunkedWriteHandler(int maxPendingWrites) {
/*  86 */     ObjectUtil.checkPositive(maxPendingWrites, "maxPendingWrites");
/*     */   }
/*     */ 
/*     */   
/*     */   public void handlerAdded(ChannelHandlerContext ctx) throws Exception {
/*  91 */     this.ctx = ctx;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resumeTransfer() {
/*  98 */     final ChannelHandlerContext ctx = this.ctx;
/*  99 */     if (ctx == null) {
/*     */       return;
/*     */     }
/* 102 */     if (ctx.executor().inEventLoop()) {
/* 103 */       resumeTransfer0(ctx);
/*     */     } else {
/*     */       
/* 106 */       ctx.executor().execute(new Runnable()
/*     */           {
/*     */             public void run()
/*     */             {
/* 110 */               ChunkedWriteHandler.this.resumeTransfer0(ctx);
/*     */             }
/*     */           });
/*     */     } 
/*     */   }
/*     */   
/*     */   private void resumeTransfer0(ChannelHandlerContext ctx) {
/*     */     try {
/* 118 */       doFlush(ctx);
/* 119 */     } catch (Exception e) {
/* 120 */       logger.warn("Unexpected exception while sending chunks.", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void write(ChannelHandlerContext ctx, Object msg, ChannelPromise promise) throws Exception {
/* 126 */     this.queue.add(new PendingWrite(msg, promise));
/*     */   }
/*     */ 
/*     */   
/*     */   public void flush(ChannelHandlerContext ctx) throws Exception {
/* 131 */     doFlush(ctx);
/*     */   }
/*     */ 
/*     */   
/*     */   public void channelInactive(ChannelHandlerContext ctx) throws Exception {
/* 136 */     doFlush(ctx);
/* 137 */     ctx.fireChannelInactive();
/*     */   }
/*     */ 
/*     */   
/*     */   public void channelWritabilityChanged(ChannelHandlerContext ctx) throws Exception {
/* 142 */     if (ctx.channel().isWritable())
/*     */     {
/* 144 */       doFlush(ctx);
/*     */     }
/* 146 */     ctx.fireChannelWritabilityChanged();
/*     */   }
/*     */   
/*     */   private void discard(Throwable cause) {
/*     */     while (true) {
/* 151 */       PendingWrite currentWrite = this.queue.poll();
/*     */       
/* 153 */       if (currentWrite == null) {
/*     */         break;
/*     */       }
/* 156 */       Object message = currentWrite.msg;
/* 157 */       if (message instanceof ChunkedInput) {
/* 158 */         boolean endOfInput; long inputLength; ChunkedInput<?> in = (ChunkedInput)message;
/*     */ 
/*     */         
/*     */         try {
/* 162 */           endOfInput = in.isEndOfInput();
/* 163 */           inputLength = in.length();
/* 164 */           closeInput(in);
/* 165 */         } catch (Exception e) {
/* 166 */           closeInput(in);
/* 167 */           currentWrite.fail(e);
/* 168 */           if (logger.isWarnEnabled()) {
/* 169 */             logger.warn(ChunkedInput.class.getSimpleName() + " failed", e);
/*     */           }
/*     */           
/*     */           continue;
/*     */         } 
/* 174 */         if (!endOfInput) {
/* 175 */           if (cause == null) {
/* 176 */             cause = new ClosedChannelException();
/*     */           }
/* 178 */           currentWrite.fail(cause); continue;
/*     */         } 
/* 180 */         currentWrite.success(inputLength);
/*     */         continue;
/*     */       } 
/* 183 */       if (cause == null) {
/* 184 */         cause = new ClosedChannelException();
/*     */       }
/* 186 */       currentWrite.fail(cause);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void doFlush(ChannelHandlerContext ctx) {
/* 192 */     Channel channel = ctx.channel();
/* 193 */     if (!channel.isActive()) {
/* 194 */       discard(null);
/*     */       
/*     */       return;
/*     */     } 
/* 198 */     boolean requiresFlush = true;
/* 199 */     ByteBufAllocator allocator = ctx.alloc();
/* 200 */     while (channel.isWritable()) {
/* 201 */       final PendingWrite currentWrite = this.queue.peek();
/*     */       
/* 203 */       if (currentWrite == null) {
/*     */         break;
/*     */       }
/*     */       
/* 207 */       if (currentWrite.promise.isDone()) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 217 */         this.queue.remove();
/*     */         
/*     */         continue;
/*     */       } 
/* 221 */       Object pendingMessage = currentWrite.msg;
/*     */       
/* 223 */       if (pendingMessage instanceof ChunkedInput) {
/* 224 */         boolean endOfInput, suspend; ChunkedInput<?> chunks = (ChunkedInput)pendingMessage;
/*     */ 
/*     */         
/* 227 */         Object message = null;
/*     */         try {
/* 229 */           message = chunks.readChunk(allocator);
/* 230 */           endOfInput = chunks.isEndOfInput();
/*     */           
/* 232 */           if (message == null) {
/*     */             
/* 234 */             suspend = !endOfInput;
/*     */           } else {
/* 236 */             suspend = false;
/*     */           } 
/* 238 */         } catch (Throwable t) {
/* 239 */           this.queue.remove();
/*     */           
/* 241 */           if (message != null) {
/* 242 */             ReferenceCountUtil.release(message);
/*     */           }
/*     */           
/* 245 */           closeInput(chunks);
/* 246 */           currentWrite.fail(t);
/*     */           
/*     */           break;
/*     */         } 
/* 250 */         if (suspend) {
/*     */           break;
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 257 */         if (message == null)
/*     */         {
/*     */           
/* 260 */           message = Unpooled.EMPTY_BUFFER;
/*     */         }
/*     */         
/* 263 */         if (endOfInput)
/*     */         {
/*     */           
/* 266 */           this.queue.remove();
/*     */         }
/*     */         
/* 269 */         ChannelFuture f = ctx.writeAndFlush(message);
/* 270 */         if (endOfInput) {
/* 271 */           if (f.isDone()) {
/* 272 */             handleEndOfInputFuture(f, currentWrite);
/*     */ 
/*     */           
/*     */           }
/*     */           else {
/*     */ 
/*     */             
/* 279 */             f.addListener((GenericFutureListener)new ChannelFutureListener()
/*     */                 {
/*     */                   public void operationComplete(ChannelFuture future) {
/* 282 */                     ChunkedWriteHandler.handleEndOfInputFuture(future, currentWrite);
/*     */                   }
/*     */                 });
/*     */           } 
/*     */         } else {
/* 287 */           final boolean resume = !channel.isWritable();
/* 288 */           if (f.isDone()) {
/* 289 */             handleFuture(f, currentWrite, resume);
/*     */           } else {
/* 291 */             f.addListener((GenericFutureListener)new ChannelFutureListener()
/*     */                 {
/*     */                   public void operationComplete(ChannelFuture future) {
/* 294 */                     ChunkedWriteHandler.this.handleFuture(future, currentWrite, resume);
/*     */                   }
/*     */                 });
/*     */           } 
/*     */         } 
/* 299 */         requiresFlush = false;
/*     */       } else {
/* 301 */         this.queue.remove();
/* 302 */         ctx.write(pendingMessage, currentWrite.promise);
/* 303 */         requiresFlush = true;
/*     */       } 
/*     */       
/* 306 */       if (!channel.isActive()) {
/* 307 */         discard(new ClosedChannelException());
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/* 312 */     if (requiresFlush) {
/* 313 */       ctx.flush();
/*     */     }
/*     */   }
/*     */   
/*     */   private static void handleEndOfInputFuture(ChannelFuture future, PendingWrite currentWrite) {
/* 318 */     ChunkedInput<?> input = (ChunkedInput)currentWrite.msg;
/* 319 */     if (!future.isSuccess()) {
/* 320 */       closeInput(input);
/* 321 */       currentWrite.fail(future.cause());
/*     */     } else {
/*     */       
/* 324 */       long inputProgress = input.progress();
/* 325 */       long inputLength = input.length();
/* 326 */       closeInput(input);
/* 327 */       currentWrite.progress(inputProgress, inputLength);
/* 328 */       currentWrite.success(inputLength);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void handleFuture(ChannelFuture future, PendingWrite currentWrite, boolean resume) {
/* 333 */     ChunkedInput<?> input = (ChunkedInput)currentWrite.msg;
/* 334 */     if (!future.isSuccess()) {
/* 335 */       closeInput(input);
/* 336 */       currentWrite.fail(future.cause());
/*     */     } else {
/* 338 */       currentWrite.progress(input.progress(), input.length());
/* 339 */       if (resume && future.channel().isWritable()) {
/* 340 */         resumeTransfer();
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void closeInput(ChunkedInput<?> chunks) {
/*     */     try {
/* 347 */       chunks.close();
/* 348 */     } catch (Throwable t) {
/* 349 */       if (logger.isWarnEnabled())
/* 350 */         logger.warn("Failed to close a chunked input.", t); 
/*     */     } 
/*     */   }
/*     */   
/*     */   public ChunkedWriteHandler() {}
/*     */   
/*     */   private static final class PendingWrite { final Object msg;
/*     */     final ChannelPromise promise;
/*     */     
/*     */     PendingWrite(Object msg, ChannelPromise promise) {
/* 360 */       this.msg = msg;
/* 361 */       this.promise = promise;
/*     */     }
/*     */     
/*     */     void fail(Throwable cause) {
/* 365 */       ReferenceCountUtil.release(this.msg);
/* 366 */       this.promise.tryFailure(cause);
/*     */     }
/*     */     
/*     */     void success(long total) {
/* 370 */       if (this.promise.isDone()) {
/*     */         return;
/*     */       }
/*     */       
/* 374 */       progress(total, total);
/* 375 */       this.promise.trySuccess();
/*     */     }
/*     */     
/*     */     void progress(long progress, long total) {
/* 379 */       if (this.promise instanceof ChannelProgressivePromise)
/* 380 */         ((ChannelProgressivePromise)this.promise).tryProgress(progress, total); 
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-handler-4.1.93.Final.jar!\io\netty\handler\stream\ChunkedWriteHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */