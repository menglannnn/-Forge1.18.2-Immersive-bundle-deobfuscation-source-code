/*    */ package io.netty.handler.timeout;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum IdleState
/*    */ {
/* 28 */   READER_IDLE,
/*    */ 
/*    */ 
/*    */   
/* 32 */   WRITER_IDLE,
/*    */ 
/*    */ 
/*    */   
/* 36 */   ALL_IDLE;
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-handler-4.1.93.Final.jar!\io\netty\handler\timeout\IdleState.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */