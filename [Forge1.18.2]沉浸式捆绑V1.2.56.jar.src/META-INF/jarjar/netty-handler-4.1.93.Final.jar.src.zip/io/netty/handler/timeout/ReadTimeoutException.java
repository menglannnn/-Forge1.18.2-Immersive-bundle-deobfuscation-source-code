/*    */ package io.netty.handler.timeout;
/*    */ 
/*    */ import io.netty.util.internal.PlatformDependent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ReadTimeoutException
/*    */   extends TimeoutException
/*    */ {
/*    */   private static final long serialVersionUID = 169287984113283421L;
/* 28 */   public static final ReadTimeoutException INSTANCE = (PlatformDependent.javaVersion() >= 7) ? new ReadTimeoutException(true) : new ReadTimeoutException();
/*    */ 
/*    */   
/*    */   public ReadTimeoutException() {}
/*    */   
/*    */   public ReadTimeoutException(String message) {
/* 34 */     super(message, false);
/*    */   }
/*    */   
/*    */   private ReadTimeoutException(boolean shared) {
/* 38 */     super(null, shared);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-handler-4.1.93.Final.jar!\io\netty\handler\timeout\ReadTimeoutException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */