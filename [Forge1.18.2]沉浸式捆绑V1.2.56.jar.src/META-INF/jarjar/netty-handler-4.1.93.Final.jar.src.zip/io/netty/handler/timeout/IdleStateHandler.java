/*     */ package io.netty.handler.timeout;
/*     */ 
/*     */ import io.netty.channel.Channel;
/*     */ import io.netty.channel.ChannelDuplexHandler;
/*     */ import io.netty.channel.ChannelFuture;
/*     */ import io.netty.channel.ChannelFutureListener;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.channel.ChannelOutboundBuffer;
/*     */ import io.netty.channel.ChannelPromise;
/*     */ import io.netty.util.concurrent.Future;
/*     */ import io.netty.util.concurrent.GenericFutureListener;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IdleStateHandler
/*     */   extends ChannelDuplexHandler
/*     */ {
/* 100 */   private static final long MIN_TIMEOUT_NANOS = TimeUnit.MILLISECONDS.toNanos(1L);
/*     */ 
/*     */   
/* 103 */   private final ChannelFutureListener writeListener = new ChannelFutureListener()
/*     */     {
/*     */       public void operationComplete(ChannelFuture future) throws Exception {
/* 106 */         IdleStateHandler.this.lastWriteTime = IdleStateHandler.this.ticksInNanos();
/* 107 */         IdleStateHandler.this.firstWriterIdleEvent = IdleStateHandler.this.firstAllIdleEvent = true;
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */   
/*     */   private final boolean observeOutput;
/*     */ 
/*     */   
/*     */   private final long readerIdleTimeNanos;
/*     */ 
/*     */   
/*     */   private final long writerIdleTimeNanos;
/*     */ 
/*     */   
/*     */   private final long allIdleTimeNanos;
/*     */ 
/*     */   
/*     */   private Future<?> readerIdleTimeout;
/*     */ 
/*     */   
/*     */   private long lastReadTime;
/*     */   
/*     */   private boolean firstReaderIdleEvent = true;
/*     */   
/*     */   private Future<?> writerIdleTimeout;
/*     */   
/*     */   private long lastWriteTime;
/*     */   
/*     */   private boolean firstWriterIdleEvent = true;
/*     */   
/*     */   private Future<?> allIdleTimeout;
/*     */   
/*     */   private boolean firstAllIdleEvent = true;
/*     */   
/*     */   private byte state;
/*     */   
/*     */   private boolean reading;
/*     */   
/*     */   private long lastChangeCheckTimeStamp;
/*     */   
/*     */   private int lastMessageHashCode;
/*     */   
/*     */   private long lastPendingWriteBytes;
/*     */   
/*     */   private long lastFlushProgress;
/*     */ 
/*     */   
/*     */   public IdleStateHandler(int readerIdleTimeSeconds, int writerIdleTimeSeconds, int allIdleTimeSeconds) {
/* 156 */     this(readerIdleTimeSeconds, writerIdleTimeSeconds, allIdleTimeSeconds, TimeUnit.SECONDS);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IdleStateHandler(long readerIdleTime, long writerIdleTime, long allIdleTime, TimeUnit unit) {
/* 166 */     this(false, readerIdleTime, writerIdleTime, allIdleTime, unit);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IdleStateHandler(boolean observeOutput, long readerIdleTime, long writerIdleTime, long allIdleTime, TimeUnit unit) {
/* 194 */     ObjectUtil.checkNotNull(unit, "unit");
/*     */     
/* 196 */     this.observeOutput = observeOutput;
/*     */     
/* 198 */     if (readerIdleTime <= 0L) {
/* 199 */       this.readerIdleTimeNanos = 0L;
/*     */     } else {
/* 201 */       this.readerIdleTimeNanos = Math.max(unit.toNanos(readerIdleTime), MIN_TIMEOUT_NANOS);
/*     */     } 
/* 203 */     if (writerIdleTime <= 0L) {
/* 204 */       this.writerIdleTimeNanos = 0L;
/*     */     } else {
/* 206 */       this.writerIdleTimeNanos = Math.max(unit.toNanos(writerIdleTime), MIN_TIMEOUT_NANOS);
/*     */     } 
/* 208 */     if (allIdleTime <= 0L) {
/* 209 */       this.allIdleTimeNanos = 0L;
/*     */     } else {
/* 211 */       this.allIdleTimeNanos = Math.max(unit.toNanos(allIdleTime), MIN_TIMEOUT_NANOS);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getReaderIdleTimeInMillis() {
/* 220 */     return TimeUnit.NANOSECONDS.toMillis(this.readerIdleTimeNanos);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getWriterIdleTimeInMillis() {
/* 228 */     return TimeUnit.NANOSECONDS.toMillis(this.writerIdleTimeNanos);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getAllIdleTimeInMillis() {
/* 236 */     return TimeUnit.NANOSECONDS.toMillis(this.allIdleTimeNanos);
/*     */   }
/*     */ 
/*     */   
/*     */   public void handlerAdded(ChannelHandlerContext ctx) throws Exception {
/* 241 */     if (ctx.channel().isActive() && ctx.channel().isRegistered())
/*     */     {
/*     */       
/* 244 */       initialize(ctx);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void handlerRemoved(ChannelHandlerContext ctx) throws Exception {
/* 253 */     destroy();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void channelRegistered(ChannelHandlerContext ctx) throws Exception {
/* 259 */     if (ctx.channel().isActive()) {
/* 260 */       initialize(ctx);
/*     */     }
/* 262 */     super.channelRegistered(ctx);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void channelActive(ChannelHandlerContext ctx) throws Exception {
/* 270 */     initialize(ctx);
/* 271 */     super.channelActive(ctx);
/*     */   }
/*     */ 
/*     */   
/*     */   public void channelInactive(ChannelHandlerContext ctx) throws Exception {
/* 276 */     destroy();
/* 277 */     super.channelInactive(ctx);
/*     */   }
/*     */ 
/*     */   
/*     */   public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
/* 282 */     if (this.readerIdleTimeNanos > 0L || this.allIdleTimeNanos > 0L) {
/* 283 */       this.reading = true;
/* 284 */       this.firstReaderIdleEvent = this.firstAllIdleEvent = true;
/*     */     } 
/* 286 */     ctx.fireChannelRead(msg);
/*     */   }
/*     */ 
/*     */   
/*     */   public void channelReadComplete(ChannelHandlerContext ctx) throws Exception {
/* 291 */     if ((this.readerIdleTimeNanos > 0L || this.allIdleTimeNanos > 0L) && this.reading) {
/* 292 */       this.lastReadTime = ticksInNanos();
/* 293 */       this.reading = false;
/*     */     } 
/* 295 */     ctx.fireChannelReadComplete();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(ChannelHandlerContext ctx, Object msg, ChannelPromise promise) throws Exception {
/* 301 */     if (this.writerIdleTimeNanos > 0L || this.allIdleTimeNanos > 0L) {
/* 302 */       ctx.write(msg, promise.unvoid()).addListener((GenericFutureListener)this.writeListener);
/*     */     } else {
/* 304 */       ctx.write(msg, promise);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void initialize(ChannelHandlerContext ctx) {
/* 311 */     switch (this.state) {
/*     */       case 1:
/*     */       case 2:
/*     */         return;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 319 */     this.state = 1;
/* 320 */     initOutputChanged(ctx);
/*     */     
/* 322 */     this.lastReadTime = this.lastWriteTime = ticksInNanos();
/* 323 */     if (this.readerIdleTimeNanos > 0L) {
/* 324 */       this.readerIdleTimeout = schedule(ctx, new ReaderIdleTimeoutTask(ctx), this.readerIdleTimeNanos, TimeUnit.NANOSECONDS);
/*     */     }
/*     */     
/* 327 */     if (this.writerIdleTimeNanos > 0L) {
/* 328 */       this.writerIdleTimeout = schedule(ctx, new WriterIdleTimeoutTask(ctx), this.writerIdleTimeNanos, TimeUnit.NANOSECONDS);
/*     */     }
/*     */     
/* 331 */     if (this.allIdleTimeNanos > 0L) {
/* 332 */       this.allIdleTimeout = schedule(ctx, new AllIdleTimeoutTask(ctx), this.allIdleTimeNanos, TimeUnit.NANOSECONDS);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   long ticksInNanos() {
/* 341 */     return System.nanoTime();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Future<?> schedule(ChannelHandlerContext ctx, Runnable task, long delay, TimeUnit unit) {
/* 348 */     return (Future<?>)ctx.executor().schedule(task, delay, unit);
/*     */   }
/*     */   
/*     */   private void destroy() {
/* 352 */     this.state = 2;
/*     */     
/* 354 */     if (this.readerIdleTimeout != null) {
/* 355 */       this.readerIdleTimeout.cancel(false);
/* 356 */       this.readerIdleTimeout = null;
/*     */     } 
/* 358 */     if (this.writerIdleTimeout != null) {
/* 359 */       this.writerIdleTimeout.cancel(false);
/* 360 */       this.writerIdleTimeout = null;
/*     */     } 
/* 362 */     if (this.allIdleTimeout != null) {
/* 363 */       this.allIdleTimeout.cancel(false);
/* 364 */       this.allIdleTimeout = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void channelIdle(ChannelHandlerContext ctx, IdleStateEvent evt) throws Exception {
/* 373 */     ctx.fireUserEventTriggered(evt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IdleStateEvent newIdleStateEvent(IdleState state, boolean first) {
/* 380 */     switch (state) {
/*     */       case ALL_IDLE:
/* 382 */         return first ? IdleStateEvent.FIRST_ALL_IDLE_STATE_EVENT : IdleStateEvent.ALL_IDLE_STATE_EVENT;
/*     */       case READER_IDLE:
/* 384 */         return first ? IdleStateEvent.FIRST_READER_IDLE_STATE_EVENT : IdleStateEvent.READER_IDLE_STATE_EVENT;
/*     */       case WRITER_IDLE:
/* 386 */         return first ? IdleStateEvent.FIRST_WRITER_IDLE_STATE_EVENT : IdleStateEvent.WRITER_IDLE_STATE_EVENT;
/*     */     } 
/* 388 */     throw new IllegalArgumentException("Unhandled: state=" + state + ", first=" + first);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initOutputChanged(ChannelHandlerContext ctx) {
/* 396 */     if (this.observeOutput) {
/* 397 */       Channel channel = ctx.channel();
/* 398 */       Channel.Unsafe unsafe = channel.unsafe();
/* 399 */       ChannelOutboundBuffer buf = unsafe.outboundBuffer();
/*     */       
/* 401 */       if (buf != null) {
/* 402 */         this.lastMessageHashCode = System.identityHashCode(buf.current());
/* 403 */         this.lastPendingWriteBytes = buf.totalPendingWriteBytes();
/* 404 */         this.lastFlushProgress = buf.currentProgress();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean hasOutputChanged(ChannelHandlerContext ctx, boolean first) {
/* 417 */     if (this.observeOutput) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 424 */       if (this.lastChangeCheckTimeStamp != this.lastWriteTime) {
/* 425 */         this.lastChangeCheckTimeStamp = this.lastWriteTime;
/*     */ 
/*     */         
/* 428 */         if (!first) {
/* 429 */           return true;
/*     */         }
/*     */       } 
/*     */       
/* 433 */       Channel channel = ctx.channel();
/* 434 */       Channel.Unsafe unsafe = channel.unsafe();
/* 435 */       ChannelOutboundBuffer buf = unsafe.outboundBuffer();
/*     */       
/* 437 */       if (buf != null) {
/* 438 */         int messageHashCode = System.identityHashCode(buf.current());
/* 439 */         long pendingWriteBytes = buf.totalPendingWriteBytes();
/*     */         
/* 441 */         if (messageHashCode != this.lastMessageHashCode || pendingWriteBytes != this.lastPendingWriteBytes) {
/* 442 */           this.lastMessageHashCode = messageHashCode;
/* 443 */           this.lastPendingWriteBytes = pendingWriteBytes;
/*     */           
/* 445 */           if (!first) {
/* 446 */             return true;
/*     */           }
/*     */         } 
/*     */         
/* 450 */         long flushProgress = buf.currentProgress();
/* 451 */         if (flushProgress != this.lastFlushProgress) {
/* 452 */           this.lastFlushProgress = flushProgress;
/* 453 */           return !first;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 458 */     return false;
/*     */   }
/*     */   
/*     */   private static abstract class AbstractIdleTask
/*     */     implements Runnable {
/*     */     private final ChannelHandlerContext ctx;
/*     */     
/*     */     AbstractIdleTask(ChannelHandlerContext ctx) {
/* 466 */       this.ctx = ctx;
/*     */     }
/*     */ 
/*     */     
/*     */     public void run() {
/* 471 */       if (!this.ctx.channel().isOpen()) {
/*     */         return;
/*     */       }
/*     */       
/* 475 */       run(this.ctx);
/*     */     }
/*     */     
/*     */     protected abstract void run(ChannelHandlerContext param1ChannelHandlerContext);
/*     */   }
/*     */   
/*     */   private final class ReaderIdleTimeoutTask
/*     */     extends AbstractIdleTask {
/*     */     ReaderIdleTimeoutTask(ChannelHandlerContext ctx) {
/* 484 */       super(ctx);
/*     */     }
/*     */ 
/*     */     
/*     */     protected void run(ChannelHandlerContext ctx) {
/* 489 */       long nextDelay = IdleStateHandler.this.readerIdleTimeNanos;
/* 490 */       if (!IdleStateHandler.this.reading) {
/* 491 */         nextDelay -= IdleStateHandler.this.ticksInNanos() - IdleStateHandler.this.lastReadTime;
/*     */       }
/*     */       
/* 494 */       if (nextDelay <= 0L) {
/*     */         
/* 496 */         IdleStateHandler.this.readerIdleTimeout = IdleStateHandler.this.schedule(ctx, this, IdleStateHandler.this.readerIdleTimeNanos, TimeUnit.NANOSECONDS);
/*     */         
/* 498 */         boolean first = IdleStateHandler.this.firstReaderIdleEvent;
/* 499 */         IdleStateHandler.this.firstReaderIdleEvent = false;
/*     */         
/*     */         try {
/* 502 */           IdleStateEvent event = IdleStateHandler.this.newIdleStateEvent(IdleState.READER_IDLE, first);
/* 503 */           IdleStateHandler.this.channelIdle(ctx, event);
/* 504 */         } catch (Throwable t) {
/* 505 */           ctx.fireExceptionCaught(t);
/*     */         } 
/*     */       } else {
/*     */         
/* 509 */         IdleStateHandler.this.readerIdleTimeout = IdleStateHandler.this.schedule(ctx, this, nextDelay, TimeUnit.NANOSECONDS);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private final class WriterIdleTimeoutTask
/*     */     extends AbstractIdleTask {
/*     */     WriterIdleTimeoutTask(ChannelHandlerContext ctx) {
/* 517 */       super(ctx);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected void run(ChannelHandlerContext ctx) {
/* 523 */       long lastWriteTime = IdleStateHandler.this.lastWriteTime;
/* 524 */       long nextDelay = IdleStateHandler.this.writerIdleTimeNanos - IdleStateHandler.this.ticksInNanos() - lastWriteTime;
/* 525 */       if (nextDelay <= 0L) {
/*     */         
/* 527 */         IdleStateHandler.this.writerIdleTimeout = IdleStateHandler.this.schedule(ctx, this, IdleStateHandler.this.writerIdleTimeNanos, TimeUnit.NANOSECONDS);
/*     */         
/* 529 */         boolean first = IdleStateHandler.this.firstWriterIdleEvent;
/* 530 */         IdleStateHandler.this.firstWriterIdleEvent = false;
/*     */         
/*     */         try {
/* 533 */           if (IdleStateHandler.this.hasOutputChanged(ctx, first)) {
/*     */             return;
/*     */           }
/*     */           
/* 537 */           IdleStateEvent event = IdleStateHandler.this.newIdleStateEvent(IdleState.WRITER_IDLE, first);
/* 538 */           IdleStateHandler.this.channelIdle(ctx, event);
/* 539 */         } catch (Throwable t) {
/* 540 */           ctx.fireExceptionCaught(t);
/*     */         } 
/*     */       } else {
/*     */         
/* 544 */         IdleStateHandler.this.writerIdleTimeout = IdleStateHandler.this.schedule(ctx, this, nextDelay, TimeUnit.NANOSECONDS);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private final class AllIdleTimeoutTask
/*     */     extends AbstractIdleTask {
/*     */     AllIdleTimeoutTask(ChannelHandlerContext ctx) {
/* 552 */       super(ctx);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected void run(ChannelHandlerContext ctx) {
/* 558 */       long nextDelay = IdleStateHandler.this.allIdleTimeNanos;
/* 559 */       if (!IdleStateHandler.this.reading) {
/* 560 */         nextDelay -= IdleStateHandler.this.ticksInNanos() - Math.max(IdleStateHandler.this.lastReadTime, IdleStateHandler.this.lastWriteTime);
/*     */       }
/* 562 */       if (nextDelay <= 0L) {
/*     */ 
/*     */         
/* 565 */         IdleStateHandler.this.allIdleTimeout = IdleStateHandler.this.schedule(ctx, this, IdleStateHandler.this.allIdleTimeNanos, TimeUnit.NANOSECONDS);
/*     */         
/* 567 */         boolean first = IdleStateHandler.this.firstAllIdleEvent;
/* 568 */         IdleStateHandler.this.firstAllIdleEvent = false;
/*     */         
/*     */         try {
/* 571 */           if (IdleStateHandler.this.hasOutputChanged(ctx, first)) {
/*     */             return;
/*     */           }
/*     */           
/* 575 */           IdleStateEvent event = IdleStateHandler.this.newIdleStateEvent(IdleState.ALL_IDLE, first);
/* 576 */           IdleStateHandler.this.channelIdle(ctx, event);
/* 577 */         } catch (Throwable t) {
/* 578 */           ctx.fireExceptionCaught(t);
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/* 583 */         IdleStateHandler.this.allIdleTimeout = IdleStateHandler.this.schedule(ctx, this, nextDelay, TimeUnit.NANOSECONDS);
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-handler-4.1.93.Final.jar!\io\netty\handler\timeout\IdleStateHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */