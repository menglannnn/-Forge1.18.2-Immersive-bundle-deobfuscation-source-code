/*    */ package io.netty.handler.timeout;
/*    */ 
/*    */ import io.netty.util.internal.PlatformDependent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class WriteTimeoutException
/*    */   extends TimeoutException
/*    */ {
/*    */   private static final long serialVersionUID = -144786655770296065L;
/* 28 */   public static final WriteTimeoutException INSTANCE = (PlatformDependent.javaVersion() >= 7) ? new WriteTimeoutException(true) : new WriteTimeoutException();
/*    */ 
/*    */   
/*    */   public WriteTimeoutException() {}
/*    */   
/*    */   public WriteTimeoutException(String message) {
/* 34 */     super(message, false);
/*    */   }
/*    */   
/*    */   private WriteTimeoutException(boolean shared) {
/* 38 */     super(null, shared);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-handler-4.1.93.Final.jar!\io\netty\handler\timeout\WriteTimeoutException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */