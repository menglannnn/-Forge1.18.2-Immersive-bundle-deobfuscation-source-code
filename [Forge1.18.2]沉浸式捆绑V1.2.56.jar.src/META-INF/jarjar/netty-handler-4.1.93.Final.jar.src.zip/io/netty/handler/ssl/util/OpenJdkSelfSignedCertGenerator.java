/*     */ package io.netty.handler.ssl.util;
/*     */ 
/*     */ import io.netty.util.internal.PlatformDependent;
/*     */ import io.netty.util.internal.SuppressJava6Requirement;
/*     */ import io.netty.util.internal.logging.InternalLogger;
/*     */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.math.BigInteger;
/*     */ import java.security.AccessController;
/*     */ import java.security.KeyPair;
/*     */ import java.security.PrivateKey;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.security.SecureRandom;
/*     */ import java.util.Date;
/*     */ import sun.security.x509.AlgorithmId;
/*     */ import sun.security.x509.CertificateAlgorithmId;
/*     */ import sun.security.x509.CertificateSerialNumber;
/*     */ import sun.security.x509.CertificateSubjectName;
/*     */ import sun.security.x509.CertificateValidity;
/*     */ import sun.security.x509.CertificateVersion;
/*     */ import sun.security.x509.CertificateX509Key;
/*     */ import sun.security.x509.X500Name;
/*     */ import sun.security.x509.X509CertImpl;
/*     */ import sun.security.x509.X509CertInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class OpenJdkSelfSignedCertGenerator
/*     */ {
/*  53 */   private static final InternalLogger logger = InternalLoggerFactory.getInstance(OpenJdkSelfSignedCertGenerator.class);
/*     */   
/*     */   private static final Method CERT_INFO_SET_METHOD;
/*     */   private static final Constructor<?> ISSUER_NAME_CONSTRUCTOR;
/*     */   private static final Constructor<X509CertImpl> CERT_IMPL_CONSTRUCTOR;
/*     */   private static final Method CERT_IMPL_GET_METHOD;
/*     */   private static final Method CERT_IMPL_SIGN_METHOD;
/*     */   
/*     */   static {
/*  62 */     Method certInfoSetMethod = null;
/*  63 */     Constructor<?> issuerNameConstructor = null;
/*  64 */     Constructor<X509CertImpl> certImplConstructor = null;
/*  65 */     Method certImplGetMethod = null;
/*  66 */     Method certImplSignMethod = null;
/*     */     try {
/*  68 */       Object maybeCertInfoSetMethod = AccessController.doPrivileged(new PrivilegedAction()
/*     */           {
/*     */             public Object run() {
/*     */               try {
/*  72 */                 return X509CertInfo.class.getMethod("set", new Class[] { String.class, Object.class });
/*  73 */               } catch (Throwable cause) {
/*  74 */                 return cause;
/*     */               } 
/*     */             }
/*     */           });
/*  78 */       if (maybeCertInfoSetMethod instanceof Method) {
/*  79 */         certInfoSetMethod = (Method)maybeCertInfoSetMethod;
/*     */       } else {
/*  81 */         throw (Throwable)maybeCertInfoSetMethod;
/*     */       } 
/*     */       
/*  84 */       Object maybeIssuerNameConstructor = AccessController.doPrivileged(new PrivilegedAction()
/*     */           {
/*     */             public Object run() {
/*     */               try {
/*  88 */                 Class<?> issuerName = Class.forName("sun.security.x509.CertificateIssuerName", false, 
/*  89 */                     PlatformDependent.getClassLoader(OpenJdkSelfSignedCertGenerator.class));
/*  90 */                 return issuerName.getConstructor(new Class[] { X500Name.class });
/*  91 */               } catch (Throwable cause) {
/*  92 */                 return cause;
/*     */               } 
/*     */             }
/*     */           });
/*  96 */       if (maybeIssuerNameConstructor instanceof Constructor) {
/*  97 */         issuerNameConstructor = (Constructor)maybeIssuerNameConstructor;
/*     */       } else {
/*  99 */         throw (Throwable)maybeIssuerNameConstructor;
/*     */       } 
/*     */       
/* 102 */       Object maybeCertImplConstructor = AccessController.doPrivileged(new PrivilegedAction()
/*     */           {
/*     */             public Object run() {
/*     */               try {
/* 106 */                 return X509CertImpl.class.getConstructor(new Class[] { X509CertInfo.class });
/* 107 */               } catch (Throwable cause) {
/* 108 */                 return cause;
/*     */               } 
/*     */             }
/*     */           });
/* 112 */       if (maybeCertImplConstructor instanceof Constructor) {
/*     */         
/* 114 */         Constructor<X509CertImpl> constructor = (Constructor<X509CertImpl>)maybeCertImplConstructor;
/* 115 */         certImplConstructor = constructor;
/*     */       } else {
/* 117 */         throw (Throwable)maybeCertImplConstructor;
/*     */       } 
/*     */       
/* 120 */       Object maybeCertImplGetMethod = AccessController.doPrivileged(new PrivilegedAction()
/*     */           {
/*     */             public Object run() {
/*     */               try {
/* 124 */                 return X509CertImpl.class.getMethod("get", new Class[] { String.class });
/* 125 */               } catch (Throwable cause) {
/* 126 */                 return cause;
/*     */               } 
/*     */             }
/*     */           });
/* 130 */       if (maybeCertImplGetMethod instanceof Method) {
/* 131 */         certImplGetMethod = (Method)maybeCertImplGetMethod;
/*     */       } else {
/* 133 */         throw (Throwable)maybeCertImplGetMethod;
/*     */       } 
/*     */       
/* 136 */       Object maybeCertImplSignMethod = AccessController.doPrivileged(new PrivilegedAction()
/*     */           {
/*     */             public Object run() {
/*     */               try {
/* 140 */                 return X509CertImpl.class.getMethod("sign", new Class[] { PrivateKey.class, String.class });
/* 141 */               } catch (Throwable cause) {
/* 142 */                 return cause;
/*     */               } 
/*     */             }
/*     */           });
/* 146 */       if (maybeCertImplSignMethod instanceof Method) {
/* 147 */         certImplSignMethod = (Method)maybeCertImplSignMethod;
/*     */       } else {
/* 149 */         throw (Throwable)maybeCertImplSignMethod;
/*     */       } 
/* 151 */     } catch (Throwable cause) {
/* 152 */       logger.debug(OpenJdkSelfSignedCertGenerator.class.getSimpleName() + " not supported", cause);
/*     */     } 
/* 154 */     CERT_INFO_SET_METHOD = certInfoSetMethod;
/* 155 */     ISSUER_NAME_CONSTRUCTOR = issuerNameConstructor;
/* 156 */     CERT_IMPL_CONSTRUCTOR = certImplConstructor;
/* 157 */     CERT_IMPL_GET_METHOD = certImplGetMethod;
/* 158 */     CERT_IMPL_SIGN_METHOD = certImplSignMethod;
/*     */   }
/*     */ 
/*     */   
/*     */   @SuppressJava6Requirement(reason = "Usage guarded by dependency check")
/*     */   static String[] generate(String fqdn, KeyPair keypair, SecureRandom random, Date notBefore, Date notAfter, String algorithm) throws Exception {
/* 164 */     if (CERT_INFO_SET_METHOD == null || ISSUER_NAME_CONSTRUCTOR == null || CERT_IMPL_CONSTRUCTOR == null || CERT_IMPL_GET_METHOD == null || CERT_IMPL_SIGN_METHOD == null)
/*     */     {
/* 166 */       throw new UnsupportedOperationException(OpenJdkSelfSignedCertGenerator.class
/* 167 */           .getSimpleName() + " not supported on the used JDK version");
/*     */     }
/* 169 */     PrivateKey key = keypair.getPrivate();
/*     */ 
/*     */     
/* 172 */     X509CertInfo info = new X509CertInfo();
/* 173 */     X500Name owner = new X500Name("CN=" + fqdn);
/*     */     
/* 175 */     CERT_INFO_SET_METHOD.invoke(info, new Object[] { "version", new CertificateVersion(2) });
/* 176 */     CERT_INFO_SET_METHOD.invoke(info, new Object[] { "serialNumber", new CertificateSerialNumber(new BigInteger(64, random)) });
/*     */     
/*     */     try {
/* 179 */       CERT_INFO_SET_METHOD.invoke(info, new Object[] { "subject", new CertificateSubjectName(owner) });
/* 180 */     } catch (InvocationTargetException ex) {
/* 181 */       if (ex.getCause() instanceof java.security.cert.CertificateException) {
/* 182 */         CERT_INFO_SET_METHOD.invoke(info, new Object[] { "subject", owner });
/*     */       } else {
/* 184 */         throw ex;
/*     */       } 
/*     */     } 
/*     */     try {
/* 188 */       CERT_INFO_SET_METHOD.invoke(info, new Object[] { "issuer", ISSUER_NAME_CONSTRUCTOR.newInstance(new Object[] { owner }) });
/* 189 */     } catch (InvocationTargetException ex) {
/* 190 */       if (ex.getCause() instanceof java.security.cert.CertificateException) {
/* 191 */         CERT_INFO_SET_METHOD.invoke(info, new Object[] { "issuer", owner });
/*     */       } else {
/* 193 */         throw ex;
/*     */       } 
/*     */     } 
/* 196 */     CERT_INFO_SET_METHOD.invoke(info, new Object[] { "validity", new CertificateValidity(notBefore, notAfter) });
/* 197 */     CERT_INFO_SET_METHOD.invoke(info, new Object[] { "key", new CertificateX509Key(keypair.getPublic()) });
/* 198 */     CERT_INFO_SET_METHOD.invoke(info, new Object[] { "algorithmID", new CertificateAlgorithmId(
/*     */             
/* 200 */             AlgorithmId.get("1.2.840.113549.1.1.11")) });
/*     */ 
/*     */     
/* 203 */     X509CertImpl cert = CERT_IMPL_CONSTRUCTOR.newInstance(new Object[] { info });
/* 204 */     CERT_IMPL_SIGN_METHOD.invoke(cert, new Object[] { key, algorithm.equalsIgnoreCase("EC") ? "SHA256withECDSA" : "SHA256withRSA" });
/*     */ 
/*     */     
/* 207 */     CERT_INFO_SET_METHOD.invoke(info, new Object[] { "algorithmID.algorithm", CERT_IMPL_GET_METHOD
/* 208 */           .invoke(cert, new Object[] { "x509.algorithm" }) });
/* 209 */     cert = CERT_IMPL_CONSTRUCTOR.newInstance(new Object[] { info });
/* 210 */     CERT_IMPL_SIGN_METHOD.invoke(cert, new Object[] { key, 
/* 211 */           algorithm.equalsIgnoreCase("EC") ? "SHA256withECDSA" : "SHA256withRSA" });
/* 212 */     cert.verify(keypair.getPublic());
/*     */     
/* 214 */     return SelfSignedCertificate.newSelfSignedCertificate(fqdn, key, cert);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-handler-4.1.93.Final.jar!\io\netty\handler\ss\\util\OpenJdkSelfSignedCertGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */