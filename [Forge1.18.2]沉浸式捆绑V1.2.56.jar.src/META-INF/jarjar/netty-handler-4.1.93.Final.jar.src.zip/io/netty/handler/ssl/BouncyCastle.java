/*    */ package io.netty.handler.ssl;
/*    */ 
/*    */ import javax.net.ssl.SSLEngine;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class BouncyCastle
/*    */ {
/*    */   private static final boolean BOUNCY_CASTLE_ON_CLASSPATH;
/*    */   
/*    */   static {
/* 28 */     boolean bcOnClasspath = false;
/*    */     try {
/* 30 */       Class.forName("org.bouncycastle.jsse.provider.BouncyCastleJsseProvider");
/* 31 */       bcOnClasspath = true;
/* 32 */     } catch (Throwable throwable) {}
/*    */ 
/*    */     
/* 35 */     BOUNCY_CASTLE_ON_CLASSPATH = bcOnClasspath;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static boolean isAvailable() {
/* 42 */     return BOUNCY_CASTLE_ON_CLASSPATH;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static boolean isInUse(SSLEngine engine) {
/* 49 */     return engine.getClass().getPackage().getName().startsWith("org.bouncycastle.jsse.provider");
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-handler-4.1.93.Final.jar!\io\netty\handler\ssl\BouncyCastle.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */