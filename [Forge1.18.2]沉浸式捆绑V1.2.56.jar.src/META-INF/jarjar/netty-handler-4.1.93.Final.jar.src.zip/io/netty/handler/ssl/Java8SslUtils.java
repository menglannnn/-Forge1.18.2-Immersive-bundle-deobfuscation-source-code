/*     */ package io.netty.handler.ssl;
/*     */ 
/*     */ import io.netty.util.CharsetUtil;
/*     */ import io.netty.util.internal.SuppressJava6Requirement;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import javax.net.ssl.SNIHostName;
/*     */ import javax.net.ssl.SNIMatcher;
/*     */ import javax.net.ssl.SNIServerName;
/*     */ import javax.net.ssl.SSLParameters;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @SuppressJava6Requirement(reason = "Usage guarded by java version check")
/*     */ final class Java8SslUtils
/*     */ {
/*     */   static List<String> getSniHostNames(SSLParameters sslParameters) {
/*  37 */     List<SNIServerName> names = sslParameters.getServerNames();
/*  38 */     if (names == null || names.isEmpty()) {
/*  39 */       return Collections.emptyList();
/*     */     }
/*  41 */     List<String> strings = new ArrayList<String>(names.size());
/*     */     
/*  43 */     for (SNIServerName serverName : names) {
/*  44 */       if (serverName instanceof SNIHostName) {
/*  45 */         strings.add(((SNIHostName)serverName).getAsciiName()); continue;
/*     */       } 
/*  47 */       throw new IllegalArgumentException("Only " + SNIHostName.class.getName() + " instances are supported, but found: " + serverName);
/*     */     } 
/*     */ 
/*     */     
/*  51 */     return strings;
/*     */   }
/*     */   
/*     */   static void setSniHostNames(SSLParameters sslParameters, List<String> names) {
/*  55 */     sslParameters.setServerNames(getSniHostNames(names));
/*     */   }
/*     */   
/*     */   static boolean isValidHostNameForSNI(String hostname) {
/*     */     try {
/*  60 */       new SNIHostName(hostname);
/*  61 */       return true;
/*  62 */     } catch (IllegalArgumentException illegal) {
/*  63 */       return false;
/*     */     } 
/*     */   }
/*     */   
/*     */   static List getSniHostNames(List<String> names) {
/*  68 */     if (names == null || names.isEmpty()) {
/*  69 */       return Collections.emptyList();
/*     */     }
/*  71 */     List<SNIServerName> sniServerNames = new ArrayList<SNIServerName>(names.size());
/*  72 */     for (String name : names) {
/*  73 */       sniServerNames.add(new SNIHostName(name.getBytes(CharsetUtil.UTF_8)));
/*     */     }
/*  75 */     return sniServerNames;
/*     */   }
/*     */   
/*     */   static List getSniHostName(byte[] hostname) {
/*  79 */     if (hostname == null || hostname.length == 0) {
/*  80 */       return Collections.emptyList();
/*     */     }
/*  82 */     return Collections.singletonList(new SNIHostName(hostname));
/*     */   }
/*     */   
/*     */   static boolean getUseCipherSuitesOrder(SSLParameters sslParameters) {
/*  86 */     return sslParameters.getUseCipherSuitesOrder();
/*     */   }
/*     */   
/*     */   static void setUseCipherSuitesOrder(SSLParameters sslParameters, boolean useOrder) {
/*  90 */     sslParameters.setUseCipherSuitesOrder(useOrder);
/*     */   }
/*     */ 
/*     */   
/*     */   static void setSNIMatchers(SSLParameters sslParameters, Collection<?> matchers) {
/*  95 */     sslParameters.setSNIMatchers((Collection)matchers);
/*     */   }
/*     */ 
/*     */   
/*     */   static boolean checkSniHostnameMatch(Collection<?> matchers, byte[] hostname) {
/* 100 */     if (matchers != null && !matchers.isEmpty()) {
/* 101 */       SNIHostName name = new SNIHostName(hostname);
/* 102 */       Iterator<SNIMatcher> matcherIt = (Iterator)matchers.iterator();
/* 103 */       while (matcherIt.hasNext()) {
/* 104 */         SNIMatcher matcher = matcherIt.next();
/*     */         
/* 106 */         if (matcher.getType() == 0 && matcher.matches(name)) {
/* 107 */           return true;
/*     */         }
/*     */       } 
/* 110 */       return false;
/*     */     } 
/* 112 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-handler-4.1.93.Final.jar!\io\netty\handler\ssl\Java8SslUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */