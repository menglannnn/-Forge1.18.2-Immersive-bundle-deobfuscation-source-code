/*     */ package io.netty.handler.ssl;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.buffer.ByteBufAllocator;
/*     */ import io.netty.buffer.ByteBufUtil;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.handler.codec.base64.Base64;
/*     */ import io.netty.handler.codec.base64.Base64Dialect;
/*     */ import io.netty.util.NetUtil;
/*     */ import io.netty.util.internal.EmptyArrays;
/*     */ import io.netty.util.internal.StringUtil;
/*     */ import io.netty.util.internal.logging.InternalLogger;
/*     */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ import java.security.KeyManagementException;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.NoSuchProviderException;
/*     */ import java.security.Provider;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javax.net.ssl.SSLContext;
/*     */ import javax.net.ssl.SSLHandshakeException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class SslUtils
/*     */ {
/*  51 */   private static final InternalLogger logger = InternalLoggerFactory.getInstance(SslUtils.class);
/*     */ 
/*     */   
/*  54 */   static final Set<String> TLSV13_CIPHERS = Collections.unmodifiableSet(new LinkedHashSet<String>(
/*  55 */         Arrays.asList(new String[] { "TLS_AES_256_GCM_SHA384", "TLS_CHACHA20_POLY1305_SHA256", "TLS_AES_128_GCM_SHA256", "TLS_AES_128_CCM_8_SHA256", "TLS_AES_128_CCM_SHA256" })));
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final int GMSSL_PROTOCOL_VERSION = 257;
/*     */ 
/*     */ 
/*     */   
/*     */   static final String INVALID_CIPHER = "SSL_NULL_WITH_NULL_NULL";
/*     */ 
/*     */ 
/*     */   
/*     */   static final int SSL_CONTENT_TYPE_CHANGE_CIPHER_SPEC = 20;
/*     */ 
/*     */ 
/*     */   
/*     */   static final int SSL_CONTENT_TYPE_ALERT = 21;
/*     */ 
/*     */ 
/*     */   
/*     */   static final int SSL_CONTENT_TYPE_HANDSHAKE = 22;
/*     */ 
/*     */ 
/*     */   
/*     */   static final int SSL_CONTENT_TYPE_APPLICATION_DATA = 23;
/*     */ 
/*     */ 
/*     */   
/*     */   static final int SSL_CONTENT_TYPE_EXTENSION_HEARTBEAT = 24;
/*     */ 
/*     */ 
/*     */   
/*     */   static final int SSL_RECORD_HEADER_LENGTH = 5;
/*     */ 
/*     */ 
/*     */   
/*     */   static final int NOT_ENOUGH_DATA = -1;
/*     */ 
/*     */ 
/*     */   
/*     */   static final int NOT_ENCRYPTED = -2;
/*     */ 
/*     */ 
/*     */   
/*     */   static final String[] DEFAULT_CIPHER_SUITES;
/*     */ 
/*     */ 
/*     */   
/*     */   static final String[] DEFAULT_TLSV13_CIPHER_SUITES;
/*     */ 
/*     */ 
/*     */   
/* 108 */   static final String[] TLSV13_CIPHER_SUITES = new String[] { "TLS_AES_128_GCM_SHA256", "TLS_AES_256_GCM_SHA384" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 114 */   private static final boolean TLSV1_3_JDK_SUPPORTED = isTLSv13SupportedByJDK0(null);
/* 115 */   private static final boolean TLSV1_3_JDK_DEFAULT_ENABLED = isTLSv13EnabledByJDK0(null); static {
/* 116 */     if (TLSV1_3_JDK_SUPPORTED) {
/* 117 */       DEFAULT_TLSV13_CIPHER_SUITES = TLSV13_CIPHER_SUITES;
/*     */     } else {
/* 119 */       DEFAULT_TLSV13_CIPHER_SUITES = EmptyArrays.EMPTY_STRINGS;
/*     */     } 
/*     */     
/* 122 */     Set<String> defaultCiphers = new LinkedHashSet<String>();
/*     */     
/* 124 */     defaultCiphers.add("TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384");
/* 125 */     defaultCiphers.add("TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256");
/* 126 */     defaultCiphers.add("TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256");
/* 127 */     defaultCiphers.add("TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384");
/* 128 */     defaultCiphers.add("TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA");
/*     */     
/* 130 */     defaultCiphers.add("TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA");
/*     */     
/* 132 */     defaultCiphers.add("TLS_RSA_WITH_AES_128_GCM_SHA256");
/* 133 */     defaultCiphers.add("TLS_RSA_WITH_AES_128_CBC_SHA");
/*     */     
/* 135 */     defaultCiphers.add("TLS_RSA_WITH_AES_256_CBC_SHA");
/*     */     
/* 137 */     Collections.addAll(defaultCiphers, DEFAULT_TLSV13_CIPHER_SUITES);
/*     */     
/* 139 */     DEFAULT_CIPHER_SUITES = defaultCiphers.<String>toArray(EmptyArrays.EMPTY_STRINGS);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean isTLSv13SupportedByJDK(Provider provider) {
/* 146 */     if (provider == null) {
/* 147 */       return TLSV1_3_JDK_SUPPORTED;
/*     */     }
/* 149 */     return isTLSv13SupportedByJDK0(provider);
/*     */   }
/*     */   
/*     */   private static boolean isTLSv13SupportedByJDK0(Provider provider) {
/*     */     try {
/* 154 */       return arrayContains(newInitContext(provider)
/* 155 */           .getSupportedSSLParameters().getProtocols(), "TLSv1.3");
/* 156 */     } catch (Throwable cause) {
/* 157 */       logger.debug("Unable to detect if JDK SSLEngine with provider {} supports TLSv1.3, assuming no", provider, cause);
/*     */       
/* 159 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean isTLSv13EnabledByJDK(Provider provider) {
/* 167 */     if (provider == null) {
/* 168 */       return TLSV1_3_JDK_DEFAULT_ENABLED;
/*     */     }
/* 170 */     return isTLSv13EnabledByJDK0(provider);
/*     */   }
/*     */   
/*     */   private static boolean isTLSv13EnabledByJDK0(Provider provider) {
/*     */     try {
/* 175 */       return arrayContains(newInitContext(provider)
/* 176 */           .getDefaultSSLParameters().getProtocols(), "TLSv1.3");
/* 177 */     } catch (Throwable cause) {
/* 178 */       logger.debug("Unable to detect if JDK SSLEngine with provider {} enables TLSv1.3 by default, assuming no", provider, cause);
/*     */       
/* 180 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static SSLContext newInitContext(Provider provider) throws NoSuchAlgorithmException, KeyManagementException {
/*     */     SSLContext context;
/* 187 */     if (provider == null) {
/* 188 */       context = SSLContext.getInstance("TLS");
/*     */     } else {
/* 190 */       context = SSLContext.getInstance("TLS", provider);
/*     */     } 
/* 192 */     context.init(null, new javax.net.ssl.TrustManager[0], null);
/* 193 */     return context;
/*     */   }
/*     */ 
/*     */   
/*     */   static SSLContext getSSLContext(String provider) throws NoSuchAlgorithmException, KeyManagementException, NoSuchProviderException {
/*     */     SSLContext context;
/* 199 */     if (StringUtil.isNullOrEmpty(provider)) {
/* 200 */       context = SSLContext.getInstance(getTlsVersion());
/*     */     } else {
/* 202 */       context = SSLContext.getInstance(getTlsVersion(), provider);
/*     */     } 
/* 204 */     context.init(null, new javax.net.ssl.TrustManager[0], null);
/* 205 */     return context;
/*     */   }
/*     */   
/*     */   private static String getTlsVersion() {
/* 209 */     return TLSV1_3_JDK_SUPPORTED ? "TLSv1.3" : "TLSv1.2";
/*     */   }
/*     */   
/*     */   static boolean arrayContains(String[] array, String value) {
/* 213 */     for (String v : array) {
/* 214 */       if (value.equals(v)) {
/* 215 */         return true;
/*     */       }
/*     */     } 
/* 218 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void addIfSupported(Set<String> supported, List<String> enabled, String... names) {
/* 225 */     for (String n : names) {
/* 226 */       if (supported.contains(n)) {
/* 227 */         enabled.add(n);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   static void useFallbackCiphersIfDefaultIsEmpty(List<String> defaultCiphers, Iterable<String> fallbackCiphers) {
/* 233 */     if (defaultCiphers.isEmpty()) {
/* 234 */       for (String cipher : fallbackCiphers) {
/* 235 */         if (cipher.startsWith("SSL_") || cipher.contains("_RC4_")) {
/*     */           continue;
/*     */         }
/* 238 */         defaultCiphers.add(cipher);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   static void useFallbackCiphersIfDefaultIsEmpty(List<String> defaultCiphers, String... fallbackCiphers) {
/* 244 */     useFallbackCiphersIfDefaultIsEmpty(defaultCiphers, Arrays.asList(fallbackCiphers));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static SSLHandshakeException toSSLHandshakeException(Throwable e) {
/* 251 */     if (e instanceof SSLHandshakeException) {
/* 252 */       return (SSLHandshakeException)e;
/*     */     }
/*     */     
/* 255 */     return (SSLHandshakeException)(new SSLHandshakeException(e.getMessage())).initCause(e);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int getEncryptedPacketLength(ByteBuf buffer, int offset) {
/*     */     boolean tls;
/* 276 */     int packetLength = 0;
/*     */ 
/*     */ 
/*     */     
/* 280 */     switch (buffer.getUnsignedByte(offset)) {
/*     */       case 20:
/*     */       case 21:
/*     */       case 22:
/*     */       case 23:
/*     */       case 24:
/* 286 */         tls = true;
/*     */         break;
/*     */       
/*     */       default:
/* 290 */         tls = false;
/*     */         break;
/*     */     } 
/* 293 */     if (tls) {
/*     */       
/* 295 */       int majorVersion = buffer.getUnsignedByte(offset + 1);
/* 296 */       if (majorVersion == 3 || buffer.getShort(offset + 1) == 257) {
/*     */         
/* 298 */         packetLength = unsignedShortBE(buffer, offset + 3) + 5;
/* 299 */         if (packetLength <= 5)
/*     */         {
/* 301 */           tls = false;
/*     */         }
/*     */       } else {
/*     */         
/* 305 */         tls = false;
/*     */       } 
/*     */     } 
/*     */     
/* 309 */     if (!tls) {
/*     */       
/* 311 */       int headerLength = ((buffer.getUnsignedByte(offset) & 0x80) != 0) ? 2 : 3;
/* 312 */       int majorVersion = buffer.getUnsignedByte(offset + headerLength + 1);
/* 313 */       if (majorVersion == 2 || majorVersion == 3) {
/*     */ 
/*     */         
/* 316 */         packetLength = (headerLength == 2) ? ((shortBE(buffer, offset) & Short.MAX_VALUE) + 2) : ((shortBE(buffer, offset) & 0x3FFF) + 3);
/* 317 */         if (packetLength <= headerLength) {
/* 318 */           return -1;
/*     */         }
/*     */       } else {
/* 321 */         return -2;
/*     */       } 
/*     */     } 
/* 324 */     return packetLength;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static int unsignedShortBE(ByteBuf buffer, int offset) {
/* 330 */     int value = buffer.getUnsignedShort(offset);
/* 331 */     if (buffer.order() == ByteOrder.LITTLE_ENDIAN) {
/* 332 */       value = Integer.reverseBytes(value) >>> 16;
/*     */     }
/* 334 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static short shortBE(ByteBuf buffer, int offset) {
/* 340 */     short value = buffer.getShort(offset);
/* 341 */     if (buffer.order() == ByteOrder.LITTLE_ENDIAN) {
/* 342 */       value = Short.reverseBytes(value);
/*     */     }
/* 344 */     return value;
/*     */   }
/*     */   
/*     */   private static short unsignedByte(byte b) {
/* 348 */     return (short)(b & 0xFF);
/*     */   }
/*     */ 
/*     */   
/*     */   private static int unsignedShortBE(ByteBuffer buffer, int offset) {
/* 353 */     return shortBE(buffer, offset) & 0xFFFF;
/*     */   }
/*     */ 
/*     */   
/*     */   private static short shortBE(ByteBuffer buffer, int offset) {
/* 358 */     return (buffer.order() == ByteOrder.BIG_ENDIAN) ? buffer
/* 359 */       .getShort(offset) : ByteBufUtil.swapShort(buffer.getShort(offset));
/*     */   }
/*     */   
/*     */   static int getEncryptedPacketLength(ByteBuffer[] buffers, int offset) {
/* 363 */     ByteBuffer buffer = buffers[offset];
/*     */ 
/*     */     
/* 366 */     if (buffer.remaining() >= 5) {
/* 367 */       return getEncryptedPacketLength(buffer);
/*     */     }
/*     */ 
/*     */     
/* 371 */     ByteBuffer tmp = ByteBuffer.allocate(5);
/*     */     
/*     */     do {
/* 374 */       buffer = buffers[offset++].duplicate();
/* 375 */       if (buffer.remaining() > tmp.remaining()) {
/* 376 */         buffer.limit(buffer.position() + tmp.remaining());
/*     */       }
/* 378 */       tmp.put(buffer);
/* 379 */     } while (tmp.hasRemaining());
/*     */ 
/*     */     
/* 382 */     tmp.flip();
/* 383 */     return getEncryptedPacketLength(tmp);
/*     */   }
/*     */   private static int getEncryptedPacketLength(ByteBuffer buffer) {
/*     */     boolean tls;
/* 387 */     int packetLength = 0;
/* 388 */     int pos = buffer.position();
/*     */ 
/*     */     
/* 391 */     switch (unsignedByte(buffer.get(pos))) {
/*     */       case 20:
/*     */       case 21:
/*     */       case 22:
/*     */       case 23:
/*     */       case 24:
/* 397 */         tls = true;
/*     */         break;
/*     */       
/*     */       default:
/* 401 */         tls = false;
/*     */         break;
/*     */     } 
/* 404 */     if (tls) {
/*     */       
/* 406 */       int majorVersion = unsignedByte(buffer.get(pos + 1));
/* 407 */       if (majorVersion == 3 || buffer.getShort(pos + 1) == 257) {
/*     */         
/* 409 */         packetLength = unsignedShortBE(buffer, pos + 3) + 5;
/* 410 */         if (packetLength <= 5)
/*     */         {
/* 412 */           tls = false;
/*     */         }
/*     */       } else {
/*     */         
/* 416 */         tls = false;
/*     */       } 
/*     */     } 
/*     */     
/* 420 */     if (!tls) {
/*     */       
/* 422 */       int headerLength = ((unsignedByte(buffer.get(pos)) & 0x80) != 0) ? 2 : 3;
/* 423 */       int majorVersion = unsignedByte(buffer.get(pos + headerLength + 1));
/* 424 */       if (majorVersion == 2 || majorVersion == 3) {
/*     */ 
/*     */         
/* 427 */         packetLength = (headerLength == 2) ? ((shortBE(buffer, pos) & Short.MAX_VALUE) + 2) : ((shortBE(buffer, pos) & 0x3FFF) + 3);
/* 428 */         if (packetLength <= headerLength) {
/* 429 */           return -1;
/*     */         }
/*     */       } else {
/* 432 */         return -2;
/*     */       } 
/*     */     } 
/* 435 */     return packetLength;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static void handleHandshakeFailure(ChannelHandlerContext ctx, Throwable cause, boolean notify) {
/* 441 */     ctx.flush();
/* 442 */     if (notify) {
/* 443 */       ctx.fireUserEventTriggered(new SslHandshakeCompletionEvent(cause));
/*     */     }
/* 445 */     ctx.close();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void zeroout(ByteBuf buffer) {
/* 452 */     if (!buffer.isReadOnly()) {
/* 453 */       buffer.setZero(0, buffer.capacity());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void zerooutAndRelease(ByteBuf buffer) {
/* 461 */     zeroout(buffer);
/* 462 */     buffer.release();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ByteBuf toBase64(ByteBufAllocator allocator, ByteBuf src) {
/* 471 */     ByteBuf dst = Base64.encode(src, src.readerIndex(), src
/* 472 */         .readableBytes(), true, Base64Dialect.STANDARD, allocator);
/* 473 */     src.readerIndex(src.writerIndex());
/* 474 */     return dst;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean isValidHostNameForSNI(String hostname) {
/* 482 */     return (hostname != null && hostname
/*     */ 
/*     */       
/* 485 */       .indexOf('.') > 0 && 
/* 486 */       !hostname.endsWith(".") && !hostname.startsWith("/") && 
/* 487 */       !NetUtil.isValidIpV4Address(hostname) && 
/* 488 */       !NetUtil.isValidIpV6Address(hostname));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean isTLSv13Cipher(String cipher) {
/* 496 */     return TLSV13_CIPHERS.contains(cipher);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-handler-4.1.93.Final.jar!\io\netty\handler\ssl\SslUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */