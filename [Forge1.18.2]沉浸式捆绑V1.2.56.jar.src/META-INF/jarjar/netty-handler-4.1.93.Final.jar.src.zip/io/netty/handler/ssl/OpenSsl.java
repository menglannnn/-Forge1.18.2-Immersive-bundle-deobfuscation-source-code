/*     */ package io.netty.handler.ssl;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.buffer.ByteBufAllocator;
/*     */ import io.netty.buffer.UnpooledByteBufAllocator;
/*     */ import io.netty.internal.tcnative.Buffer;
/*     */ import io.netty.internal.tcnative.Library;
/*     */ import io.netty.internal.tcnative.SSL;
/*     */ import io.netty.internal.tcnative.SSLContext;
/*     */ import io.netty.util.CharsetUtil;
/*     */ import io.netty.util.ReferenceCountUtil;
/*     */ import io.netty.util.ReferenceCounted;
/*     */ import io.netty.util.internal.EmptyArrays;
/*     */ import io.netty.util.internal.NativeLibraryLoader;
/*     */ import io.netty.util.internal.PlatformDependent;
/*     */ import io.netty.util.internal.SystemPropertyUtil;
/*     */ import io.netty.util.internal.logging.InternalLogger;
/*     */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.security.cert.CertificateException;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class OpenSsl
/*     */ {
/*  57 */   private static final InternalLogger logger = InternalLoggerFactory.getInstance(OpenSsl.class);
/*     */   
/*     */   private static final Throwable UNAVAILABILITY_CAUSE;
/*     */   
/*     */   static final List<String> DEFAULT_CIPHERS;
/*     */   
/*     */   static final Set<String> AVAILABLE_CIPHER_SUITES;
/*     */   
/*     */   private static final Set<String> AVAILABLE_OPENSSL_CIPHER_SUITES;
/*     */   
/*     */   private static final Set<String> AVAILABLE_JAVA_CIPHER_SUITES;
/*     */   private static final boolean SUPPORTS_KEYMANAGER_FACTORY;
/*     */   private static final boolean USE_KEYMANAGER_FACTORY;
/*     */   private static final boolean SUPPORTS_OCSP;
/*     */   private static final boolean TLSV13_SUPPORTED;
/*     */   private static final boolean IS_BORINGSSL;
/*     */   private static final Set<String> CLIENT_DEFAULT_PROTOCOLS;
/*     */   private static final Set<String> SERVER_DEFAULT_PROTOCOLS;
/*     */   static final Set<String> SUPPORTED_PROTOCOLS_SET;
/*     */   static final String[] EXTRA_SUPPORTED_TLS_1_3_CIPHERS;
/*     */   static final String EXTRA_SUPPORTED_TLS_1_3_CIPHERS_STRING;
/*     */   static final String[] NAMED_GROUPS;
/*  79 */   private static final String[] DEFAULT_NAMED_GROUPS = new String[] { "x25519", "secp256r1", "secp384r1", "secp521r1" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String CERT = "-----BEGIN CERTIFICATE-----\nMIICrjCCAZagAwIBAgIIdSvQPv1QAZQwDQYJKoZIhvcNAQELBQAwFjEUMBIGA1UEAxMLZXhhbXBs\nZS5jb20wIBcNMTgwNDA2MjIwNjU5WhgPOTk5OTEyMzEyMzU5NTlaMBYxFDASBgNVBAMTC2V4YW1w\nbGUuY29tMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAggbWsmDQ6zNzRZ5AW8E3eoGl\nqWvOBDb5Fs1oBRrVQHuYmVAoaqwDzXYJ0LOwa293AgWEQ1jpcbZ2hpoYQzqEZBTLnFhMrhRFlH6K\nbJND8Y33kZ/iSVBBDuGbdSbJShlM+4WwQ9IAso4MZ4vW3S1iv5fGGpLgbtXRmBf/RU8omN0Gijlv\nWlLWHWijLN8xQtySFuBQ7ssW8RcKAary3pUm6UUQB+Co6lnfti0Tzag8PgjhAJq2Z3wbsGRnP2YS\nvYoaK6qzmHXRYlp/PxrjBAZAmkLJs4YTm/XFF+fkeYx4i9zqHbyone5yerRibsHaXZWLnUL+rFoe\nMdKvr0VS3sGmhQIDAQABMA0GCSqGSIb3DQEBCwUAA4IBAQADQi441pKmXf9FvUV5EHU4v8nJT9Iq\nyqwsKwXnr7AsUlDGHBD7jGrjAXnG5rGxuNKBQ35wRxJATKrUtyaquFUL6H8O6aGQehiFTk6zmPbe\n12Gu44vqqTgIUxnv3JQJiox8S2hMxsSddpeCmSdvmalvD6WG4NthH6B9ZaBEiep1+0s0RUaBYn73\nI7CCUaAtbjfR6pcJjrFk5ei7uwdQZFSJtkP2z8r7zfeANJddAKFlkaMWn7u+OIVuB4XPooWicObk\nNAHFtP65bocUYnDpTVdiyvn8DdqyZ/EO8n1bBKBzuSLplk2msW4pdgaFgY7Vw/0wzcFXfUXmL1uy\nG8sQD/wx\n-----END CERTIFICATE-----";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String KEY = "-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCCBtayYNDrM3NFnkBbwTd6gaWp\na84ENvkWzWgFGtVAe5iZUChqrAPNdgnQs7Brb3cCBYRDWOlxtnaGmhhDOoRkFMucWEyuFEWUfops\nk0PxjfeRn+JJUEEO4Zt1JslKGUz7hbBD0gCyjgxni9bdLWK/l8YakuBu1dGYF/9FTyiY3QaKOW9a\nUtYdaKMs3zFC3JIW4FDuyxbxFwoBqvLelSbpRRAH4KjqWd+2LRPNqDw+COEAmrZnfBuwZGc/ZhK9\nihorqrOYddFiWn8/GuMEBkCaQsmzhhOb9cUX5+R5jHiL3OodvKid7nJ6tGJuwdpdlYudQv6sWh4x\n0q+vRVLewaaFAgMBAAECggEAP8tPJvFtTxhNJAkCloHz0D0vpDHqQBMgntlkgayqmBqLwhyb18pR\ni0qwgh7HHc7wWqOOQuSqlEnrWRrdcI6TSe8R/sErzfTQNoznKWIPYcI/hskk4sdnQ//Yn9/Jvnsv\nU/BBjOTJxtD+sQbhAl80JcA3R+5sArURQkfzzHOL/YMqzAsn5hTzp7HZCxUqBk3KaHRxV7NefeOE\nxlZuWSmxYWfbFIs4kx19/1t7h8CHQWezw+G60G2VBtSBBxDnhBWvqG6R/wpzJ3nEhPLLY9T+XIHe\nipzdMOOOUZorfIg7M+pyYPji+ZIZxIpY5OjrOzXHciAjRtr5Y7l99K1CG1LguQKBgQDrQfIMxxtZ\nvxU/1cRmUV9l7pt5bjV5R6byXq178LxPKVYNjdZ840Q0/OpZEVqaT1xKVi35ohP1QfNjxPLlHD+K\niDAR9z6zkwjIrbwPCnb5kuXy4lpwPcmmmkva25fI7qlpHtbcuQdoBdCfr/KkKaUCMPyY89LCXgEw\n5KTDj64UywKBgQCNfbO+eZLGzhiHhtNJurresCsIGWlInv322gL8CSfBMYl6eNfUTZvUDdFhPISL\nUljKWzXDrjw0ujFSPR0XhUGtiq89H+HUTuPPYv25gVXO+HTgBFZEPl4PpA+BUsSVZy0NddneyqLk\n42Wey9omY9Q8WsdNQS5cbUvy0uG6WFoX7wKBgQDZ1jpW8pa0x2bZsQsm4vo+3G5CRnZlUp+XlWt2\ndDcp5dC0xD1zbs1dc0NcLeGDOTDv9FSl7hok42iHXXq8AygjEm/QcuwwQ1nC2HxmQP5holAiUs4D\nWHM8PWs3wFYPzE459EBoKTxeaeP/uWAn+he8q7d5uWvSZlEcANs/6e77eQKBgD21Ar0hfFfj7mK8\n9E0FeRZBsqK3omkfnhcYgZC11Xa2SgT1yvs2Va2n0RcdM5kncr3eBZav2GYOhhAdwyBM55XuE/sO\neokDVutNeuZ6d5fqV96TRaRBpvgfTvvRwxZ9hvKF4Vz+9wfn/JvCwANaKmegF6ejs7pvmF3whq2k\ndrZVAoGAX5YxQ5XMTD0QbMAl7/6qp6S58xNoVdfCkmkj1ZLKaHKIjS/benkKGlySVQVPexPfnkZx\np/Vv9yyphBoudiTBS9Uog66ueLYZqpgxlM/6OhYg86Gm3U2ycvMxYjBM1NFiyze21AqAhI+HX+Ot\nmraV2/guSgDgZAhukRZzeQ2RucI=\n-----END PRIVATE KEY-----";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/* 124 */     Throwable cause = null;
/*     */     
/* 126 */     if (SystemPropertyUtil.getBoolean("io.netty.handler.ssl.noOpenSsl", false)) {
/* 127 */       cause = new UnsupportedOperationException("OpenSSL was explicit disabled with -Dio.netty.handler.ssl.noOpenSsl=true");
/*     */ 
/*     */       
/* 130 */       logger.debug("netty-tcnative explicit disabled; " + OpenSslEngine.class
/*     */           
/* 132 */           .getSimpleName() + " will be unavailable.", cause);
/*     */     } else {
/*     */       
/*     */       try {
/* 136 */         Class.forName("io.netty.internal.tcnative.SSLContext", false, 
/* 137 */             PlatformDependent.getClassLoader(OpenSsl.class));
/* 138 */       } catch (ClassNotFoundException t) {
/* 139 */         cause = t;
/* 140 */         logger.debug("netty-tcnative not in the classpath; " + OpenSslEngine.class
/*     */             
/* 142 */             .getSimpleName() + " will be unavailable.");
/*     */       } 
/*     */ 
/*     */       
/* 146 */       if (cause == null) {
/*     */         
/*     */         try {
/* 149 */           loadTcNative();
/* 150 */         } catch (Throwable t) {
/* 151 */           cause = t;
/* 152 */           logger.debug("Failed to load netty-tcnative; " + OpenSslEngine.class
/*     */               
/* 154 */               .getSimpleName() + " will be unavailable, unless the application has already loaded the symbols by some other means. See https://netty.io/wiki/forked-tomcat-native.html for more information.", t);
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/*     */         try {
/* 160 */           String engine = SystemPropertyUtil.get("io.netty.handler.ssl.openssl.engine", null);
/* 161 */           if (engine == null) {
/* 162 */             logger.debug("Initialize netty-tcnative using engine: 'default'");
/*     */           } else {
/* 164 */             logger.debug("Initialize netty-tcnative using engine: '{}'", engine);
/*     */           } 
/* 166 */           initializeTcNative(engine);
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 171 */           cause = null;
/* 172 */         } catch (Throwable t) {
/* 173 */           if (cause == null) {
/* 174 */             cause = t;
/*     */           }
/* 176 */           logger.debug("Failed to initialize netty-tcnative; " + OpenSslEngine.class
/*     */               
/* 178 */               .getSimpleName() + " will be unavailable. See https://netty.io/wiki/forked-tomcat-native.html for more information.", t);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 184 */     UNAVAILABILITY_CAUSE = cause;
/* 185 */     CLIENT_DEFAULT_PROTOCOLS = protocols("jdk.tls.client.protocols");
/* 186 */     SERVER_DEFAULT_PROTOCOLS = protocols("jdk.tls.server.protocols");
/*     */     
/* 188 */     if (cause == null) {
/* 189 */       logger.debug("netty-tcnative using native library: {}", SSL.versionString());
/*     */       
/* 191 */       List<String> defaultCiphers = new ArrayList<String>();
/* 192 */       Set<String> availableOpenSslCipherSuites = new LinkedHashSet<String>(128);
/* 193 */       boolean supportsKeyManagerFactory = false;
/* 194 */       boolean useKeyManagerFactory = false;
/* 195 */       boolean tlsv13Supported = false;
/* 196 */       String[] namedGroups = DEFAULT_NAMED_GROUPS;
/* 197 */       String[] defaultConvertedNamedGroups = new String[namedGroups.length];
/* 198 */       for (int i = 0; i < namedGroups.length; i++) {
/* 199 */         defaultConvertedNamedGroups[i] = GroupsConverter.toOpenSsl(namedGroups[i]);
/*     */       }
/*     */       
/* 202 */       IS_BORINGSSL = "BoringSSL".equals(versionString());
/* 203 */       if (IS_BORINGSSL) {
/* 204 */         EXTRA_SUPPORTED_TLS_1_3_CIPHERS = new String[] { "TLS_AES_128_GCM_SHA256", "TLS_AES_256_GCM_SHA384", "TLS_CHACHA20_POLY1305_SHA256" };
/*     */ 
/*     */ 
/*     */         
/* 208 */         StringBuilder ciphersBuilder = new StringBuilder(128);
/* 209 */         for (String cipher : EXTRA_SUPPORTED_TLS_1_3_CIPHERS) {
/* 210 */           ciphersBuilder.append(cipher).append(":");
/*     */         }
/* 212 */         ciphersBuilder.setLength(ciphersBuilder.length() - 1);
/* 213 */         EXTRA_SUPPORTED_TLS_1_3_CIPHERS_STRING = ciphersBuilder.toString();
/*     */       } else {
/* 215 */         EXTRA_SUPPORTED_TLS_1_3_CIPHERS = EmptyArrays.EMPTY_STRINGS;
/* 216 */         EXTRA_SUPPORTED_TLS_1_3_CIPHERS_STRING = "";
/*     */       } 
/*     */       
/*     */       try {
/* 220 */         long sslCtx = SSLContext.make(63, 1);
/* 221 */         long certBio = 0L;
/* 222 */         long keyBio = 0L;
/* 223 */         long cert = 0L;
/* 224 */         long key = 0L;
/*     */ 
/*     */         
/*     */         try {
/* 228 */           if (SslProvider.isTlsv13Supported(SslProvider.JDK)) {
/*     */             try {
/* 230 */               StringBuilder tlsv13Ciphers = new StringBuilder();
/*     */               
/* 232 */               for (String cipher : SslUtils.TLSV13_CIPHERS) {
/* 233 */                 String converted = CipherSuiteConverter.toOpenSsl(cipher, IS_BORINGSSL);
/* 234 */                 if (converted != null) {
/* 235 */                   tlsv13Ciphers.append(converted).append(':');
/*     */                 }
/*     */               } 
/* 238 */               if (tlsv13Ciphers.length() == 0) {
/* 239 */                 tlsv13Supported = false;
/*     */               } else {
/* 241 */                 tlsv13Ciphers.setLength(tlsv13Ciphers.length() - 1);
/* 242 */                 SSLContext.setCipherSuite(sslCtx, tlsv13Ciphers.toString(), true);
/* 243 */                 tlsv13Supported = true;
/*     */               }
/*     */             
/* 246 */             } catch (Exception ignore) {
/* 247 */               tlsv13Supported = false;
/*     */             } 
/*     */           }
/*     */           
/* 251 */           SSLContext.setCipherSuite(sslCtx, "ALL", false);
/*     */           
/* 253 */           long ssl = SSL.newSSL(sslCtx, true);
/*     */           try {
/* 255 */             for (String c : SSL.getCiphers(ssl)) {
/*     */               
/* 257 */               if (c != null && !c.isEmpty() && !availableOpenSslCipherSuites.contains(c) && (tlsv13Supported || 
/*     */                 
/* 259 */                 !SslUtils.isTLSv13Cipher(c)))
/*     */               {
/*     */                 
/* 262 */                 availableOpenSslCipherSuites.add(c); } 
/*     */             } 
/* 264 */             if (IS_BORINGSSL) {
/*     */ 
/*     */               
/* 267 */               Collections.addAll(availableOpenSslCipherSuites, EXTRA_SUPPORTED_TLS_1_3_CIPHERS);
/* 268 */               Collections.addAll(availableOpenSslCipherSuites, new String[] { "AEAD-AES128-GCM-SHA256", "AEAD-AES256-GCM-SHA384", "AEAD-CHACHA20-POLY1305-SHA256" });
/*     */             } 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 274 */             PemEncoded privateKey = PemPrivateKey.valueOf("-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCCBtayYNDrM3NFnkBbwTd6gaWp\na84ENvkWzWgFGtVAe5iZUChqrAPNdgnQs7Brb3cCBYRDWOlxtnaGmhhDOoRkFMucWEyuFEWUfops\nk0PxjfeRn+JJUEEO4Zt1JslKGUz7hbBD0gCyjgxni9bdLWK/l8YakuBu1dGYF/9FTyiY3QaKOW9a\nUtYdaKMs3zFC3JIW4FDuyxbxFwoBqvLelSbpRRAH4KjqWd+2LRPNqDw+COEAmrZnfBuwZGc/ZhK9\nihorqrOYddFiWn8/GuMEBkCaQsmzhhOb9cUX5+R5jHiL3OodvKid7nJ6tGJuwdpdlYudQv6sWh4x\n0q+vRVLewaaFAgMBAAECggEAP8tPJvFtTxhNJAkCloHz0D0vpDHqQBMgntlkgayqmBqLwhyb18pR\ni0qwgh7HHc7wWqOOQuSqlEnrWRrdcI6TSe8R/sErzfTQNoznKWIPYcI/hskk4sdnQ//Yn9/Jvnsv\nU/BBjOTJxtD+sQbhAl80JcA3R+5sArURQkfzzHOL/YMqzAsn5hTzp7HZCxUqBk3KaHRxV7NefeOE\nxlZuWSmxYWfbFIs4kx19/1t7h8CHQWezw+G60G2VBtSBBxDnhBWvqG6R/wpzJ3nEhPLLY9T+XIHe\nipzdMOOOUZorfIg7M+pyYPji+ZIZxIpY5OjrOzXHciAjRtr5Y7l99K1CG1LguQKBgQDrQfIMxxtZ\nvxU/1cRmUV9l7pt5bjV5R6byXq178LxPKVYNjdZ840Q0/OpZEVqaT1xKVi35ohP1QfNjxPLlHD+K\niDAR9z6zkwjIrbwPCnb5kuXy4lpwPcmmmkva25fI7qlpHtbcuQdoBdCfr/KkKaUCMPyY89LCXgEw\n5KTDj64UywKBgQCNfbO+eZLGzhiHhtNJurresCsIGWlInv322gL8CSfBMYl6eNfUTZvUDdFhPISL\nUljKWzXDrjw0ujFSPR0XhUGtiq89H+HUTuPPYv25gVXO+HTgBFZEPl4PpA+BUsSVZy0NddneyqLk\n42Wey9omY9Q8WsdNQS5cbUvy0uG6WFoX7wKBgQDZ1jpW8pa0x2bZsQsm4vo+3G5CRnZlUp+XlWt2\ndDcp5dC0xD1zbs1dc0NcLeGDOTDv9FSl7hok42iHXXq8AygjEm/QcuwwQ1nC2HxmQP5holAiUs4D\nWHM8PWs3wFYPzE459EBoKTxeaeP/uWAn+he8q7d5uWvSZlEcANs/6e77eQKBgD21Ar0hfFfj7mK8\n9E0FeRZBsqK3omkfnhcYgZC11Xa2SgT1yvs2Va2n0RcdM5kncr3eBZav2GYOhhAdwyBM55XuE/sO\neokDVutNeuZ6d5fqV96TRaRBpvgfTvvRwxZ9hvKF4Vz+9wfn/JvCwANaKmegF6ejs7pvmF3whq2k\ndrZVAoGAX5YxQ5XMTD0QbMAl7/6qp6S58xNoVdfCkmkj1ZLKaHKIjS/benkKGlySVQVPexPfnkZx\np/Vv9yyphBoudiTBS9Uog66ueLYZqpgxlM/6OhYg86Gm3U2ycvMxYjBM1NFiyze21AqAhI+HX+Ot\nmraV2/guSgDgZAhukRZzeQ2RucI=\n-----END PRIVATE KEY-----".getBytes(CharsetUtil.US_ASCII));
/*     */ 
/*     */             
/*     */             try {
/* 278 */               SSLContext.setCertificateCallback(sslCtx, null);
/*     */               
/* 280 */               X509Certificate certificate = selfSignedCertificate();
/* 281 */               certBio = ReferenceCountedOpenSslContext.toBIO(ByteBufAllocator.DEFAULT, new X509Certificate[] { certificate });
/* 282 */               cert = SSL.parseX509Chain(certBio);
/*     */               
/* 284 */               keyBio = ReferenceCountedOpenSslContext.toBIO((ByteBufAllocator)UnpooledByteBufAllocator.DEFAULT, privateKey
/* 285 */                   .retain());
/* 286 */               key = SSL.parsePrivateKey(keyBio, null);
/*     */               
/* 288 */               SSL.setKeyMaterial(ssl, cert, key);
/* 289 */               supportsKeyManagerFactory = true;
/*     */               try {
/* 291 */                 boolean propertySet = SystemPropertyUtil.contains("io.netty.handler.ssl.openssl.useKeyManagerFactory");
/*     */                 
/* 293 */                 if (!IS_BORINGSSL) {
/* 294 */                   useKeyManagerFactory = SystemPropertyUtil.getBoolean("io.netty.handler.ssl.openssl.useKeyManagerFactory", true);
/*     */ 
/*     */                   
/* 297 */                   if (propertySet) {
/* 298 */                     logger.info("System property 'io.netty.handler.ssl.openssl.useKeyManagerFactory' is deprecated and so will be ignored in the future");
/*     */                   }
/*     */                 }
/*     */                 else {
/*     */                   
/* 303 */                   useKeyManagerFactory = true;
/* 304 */                   if (propertySet) {
/* 305 */                     logger.info("System property 'io.netty.handler.ssl.openssl.useKeyManagerFactory' is deprecated and will be ignored when using BoringSSL");
/*     */                   }
/*     */                 }
/*     */               
/*     */               }
/* 310 */               catch (Throwable ignore) {
/* 311 */                 logger.debug("Failed to get useKeyManagerFactory system property.");
/*     */               } 
/* 313 */             } catch (Error ignore) {
/* 314 */               logger.debug("KeyManagerFactory not supported.");
/*     */             } finally {
/* 316 */               privateKey.release();
/*     */             } 
/*     */           } finally {
/* 319 */             SSL.freeSSL(ssl);
/* 320 */             if (certBio != 0L) {
/* 321 */               SSL.freeBIO(certBio);
/*     */             }
/* 323 */             if (keyBio != 0L) {
/* 324 */               SSL.freeBIO(keyBio);
/*     */             }
/* 326 */             if (cert != 0L) {
/* 327 */               SSL.freeX509Chain(cert);
/*     */             }
/* 329 */             if (key != 0L) {
/* 330 */               SSL.freePrivateKey(key);
/*     */             }
/*     */           } 
/*     */           
/* 334 */           String groups = SystemPropertyUtil.get("jdk.tls.namedGroups", null);
/* 335 */           if (groups != null) {
/* 336 */             String[] nGroups = groups.split(",");
/* 337 */             Set<String> supportedNamedGroups = new LinkedHashSet<String>(nGroups.length);
/* 338 */             Set<String> supportedConvertedNamedGroups = new LinkedHashSet<String>(nGroups.length);
/*     */             
/* 340 */             Set<String> unsupportedNamedGroups = new LinkedHashSet<String>();
/* 341 */             for (String namedGroup : nGroups) {
/* 342 */               String converted = GroupsConverter.toOpenSsl(namedGroup);
/* 343 */               if (SSLContext.setCurvesList(sslCtx, new String[] { converted })) {
/* 344 */                 supportedConvertedNamedGroups.add(converted);
/* 345 */                 supportedNamedGroups.add(namedGroup);
/*     */               } else {
/* 347 */                 unsupportedNamedGroups.add(namedGroup);
/*     */               } 
/*     */             } 
/*     */             
/* 351 */             if (supportedNamedGroups.isEmpty()) {
/* 352 */               namedGroups = defaultConvertedNamedGroups;
/* 353 */               logger.info("All configured namedGroups are not supported: {}. Use default: {}.", 
/* 354 */                   Arrays.toString(unsupportedNamedGroups.toArray((Object[])EmptyArrays.EMPTY_STRINGS)), 
/* 355 */                   Arrays.toString((Object[])DEFAULT_NAMED_GROUPS));
/*     */             } else {
/* 357 */               String[] groupArray = supportedNamedGroups.<String>toArray(EmptyArrays.EMPTY_STRINGS);
/* 358 */               if (unsupportedNamedGroups.isEmpty()) {
/* 359 */                 logger.info("Using configured namedGroups -D 'jdk.tls.namedGroup': {} ", 
/* 360 */                     Arrays.toString((Object[])groupArray));
/*     */               } else {
/* 362 */                 logger.info("Using supported configured namedGroups: {}. Unsupported namedGroups: {}. ", 
/* 363 */                     Arrays.toString((Object[])groupArray), 
/* 364 */                     Arrays.toString(unsupportedNamedGroups.toArray((Object[])EmptyArrays.EMPTY_STRINGS)));
/*     */               } 
/* 366 */               namedGroups = supportedConvertedNamedGroups.<String>toArray(EmptyArrays.EMPTY_STRINGS);
/*     */             } 
/*     */           } else {
/* 369 */             namedGroups = defaultConvertedNamedGroups;
/*     */           } 
/*     */         } finally {
/* 372 */           SSLContext.free(sslCtx);
/*     */         } 
/* 374 */       } catch (Exception e) {
/* 375 */         logger.warn("Failed to get the list of available OpenSSL cipher suites.", e);
/*     */       } 
/* 377 */       NAMED_GROUPS = namedGroups;
/* 378 */       AVAILABLE_OPENSSL_CIPHER_SUITES = Collections.unmodifiableSet(availableOpenSslCipherSuites);
/*     */       
/* 380 */       Set<String> availableJavaCipherSuites = new LinkedHashSet<String>(AVAILABLE_OPENSSL_CIPHER_SUITES.size() * 2);
/* 381 */       for (String cipher : AVAILABLE_OPENSSL_CIPHER_SUITES) {
/*     */         
/* 383 */         if (!SslUtils.isTLSv13Cipher(cipher)) {
/* 384 */           availableJavaCipherSuites.add(CipherSuiteConverter.toJava(cipher, "TLS"));
/* 385 */           availableJavaCipherSuites.add(CipherSuiteConverter.toJava(cipher, "SSL"));
/*     */           continue;
/*     */         } 
/* 388 */         availableJavaCipherSuites.add(cipher);
/*     */       } 
/*     */ 
/*     */       
/* 392 */       SslUtils.addIfSupported(availableJavaCipherSuites, defaultCiphers, SslUtils.DEFAULT_CIPHER_SUITES);
/* 393 */       SslUtils.addIfSupported(availableJavaCipherSuites, defaultCiphers, SslUtils.TLSV13_CIPHER_SUITES);
/*     */       
/* 395 */       SslUtils.addIfSupported(availableJavaCipherSuites, defaultCiphers, EXTRA_SUPPORTED_TLS_1_3_CIPHERS);
/*     */       
/* 397 */       SslUtils.useFallbackCiphersIfDefaultIsEmpty(defaultCiphers, availableJavaCipherSuites);
/* 398 */       DEFAULT_CIPHERS = Collections.unmodifiableList(defaultCiphers);
/*     */       
/* 400 */       AVAILABLE_JAVA_CIPHER_SUITES = Collections.unmodifiableSet(availableJavaCipherSuites);
/*     */ 
/*     */       
/* 403 */       Set<String> availableCipherSuites = new LinkedHashSet<String>(AVAILABLE_OPENSSL_CIPHER_SUITES.size() + AVAILABLE_JAVA_CIPHER_SUITES.size());
/* 404 */       availableCipherSuites.addAll(AVAILABLE_OPENSSL_CIPHER_SUITES);
/* 405 */       availableCipherSuites.addAll(AVAILABLE_JAVA_CIPHER_SUITES);
/*     */       
/* 407 */       AVAILABLE_CIPHER_SUITES = availableCipherSuites;
/* 408 */       SUPPORTS_KEYMANAGER_FACTORY = supportsKeyManagerFactory;
/* 409 */       USE_KEYMANAGER_FACTORY = useKeyManagerFactory;
/*     */       
/* 411 */       Set<String> protocols = new LinkedHashSet<String>(6);
/*     */       
/* 413 */       protocols.add("SSLv2Hello");
/* 414 */       if (doesSupportProtocol(1, SSL.SSL_OP_NO_SSLv2)) {
/* 415 */         protocols.add("SSLv2");
/*     */       }
/* 417 */       if (doesSupportProtocol(2, SSL.SSL_OP_NO_SSLv3)) {
/* 418 */         protocols.add("SSLv3");
/*     */       }
/* 420 */       if (doesSupportProtocol(4, SSL.SSL_OP_NO_TLSv1)) {
/* 421 */         protocols.add("TLSv1");
/*     */       }
/* 423 */       if (doesSupportProtocol(8, SSL.SSL_OP_NO_TLSv1_1)) {
/* 424 */         protocols.add("TLSv1.1");
/*     */       }
/* 426 */       if (doesSupportProtocol(16, SSL.SSL_OP_NO_TLSv1_2)) {
/* 427 */         protocols.add("TLSv1.2");
/*     */       }
/*     */ 
/*     */       
/* 431 */       if (tlsv13Supported && doesSupportProtocol(32, SSL.SSL_OP_NO_TLSv1_3)) {
/* 432 */         protocols.add("TLSv1.3");
/* 433 */         TLSV13_SUPPORTED = true;
/*     */       } else {
/* 435 */         TLSV13_SUPPORTED = false;
/*     */       } 
/*     */       
/* 438 */       SUPPORTED_PROTOCOLS_SET = Collections.unmodifiableSet(protocols);
/* 439 */       SUPPORTS_OCSP = doesSupportOcsp();
/*     */       
/* 441 */       if (logger.isDebugEnabled()) {
/* 442 */         logger.debug("Supported protocols (OpenSSL): {} ", SUPPORTED_PROTOCOLS_SET);
/* 443 */         logger.debug("Default cipher suites (OpenSSL): {}", DEFAULT_CIPHERS);
/*     */       } 
/*     */     } else {
/* 446 */       DEFAULT_CIPHERS = Collections.emptyList();
/* 447 */       AVAILABLE_OPENSSL_CIPHER_SUITES = Collections.emptySet();
/* 448 */       AVAILABLE_JAVA_CIPHER_SUITES = Collections.emptySet();
/* 449 */       AVAILABLE_CIPHER_SUITES = Collections.emptySet();
/* 450 */       SUPPORTS_KEYMANAGER_FACTORY = false;
/* 451 */       USE_KEYMANAGER_FACTORY = false;
/* 452 */       SUPPORTED_PROTOCOLS_SET = Collections.emptySet();
/* 453 */       SUPPORTS_OCSP = false;
/* 454 */       TLSV13_SUPPORTED = false;
/* 455 */       IS_BORINGSSL = false;
/* 456 */       EXTRA_SUPPORTED_TLS_1_3_CIPHERS = EmptyArrays.EMPTY_STRINGS;
/* 457 */       EXTRA_SUPPORTED_TLS_1_3_CIPHERS_STRING = "";
/* 458 */       NAMED_GROUPS = DEFAULT_NAMED_GROUPS;
/*     */     } 
/*     */   }
/*     */   
/*     */   static String checkTls13Ciphers(InternalLogger logger, String ciphers) {
/* 463 */     if (IS_BORINGSSL && !ciphers.isEmpty()) {
/* 464 */       assert EXTRA_SUPPORTED_TLS_1_3_CIPHERS.length > 0;
/* 465 */       Set<String> boringsslTlsv13Ciphers = new HashSet<String>(EXTRA_SUPPORTED_TLS_1_3_CIPHERS.length);
/* 466 */       Collections.addAll(boringsslTlsv13Ciphers, EXTRA_SUPPORTED_TLS_1_3_CIPHERS);
/* 467 */       boolean ciphersNotMatch = false;
/* 468 */       for (String cipher : ciphers.split(":")) {
/* 469 */         if (boringsslTlsv13Ciphers.isEmpty()) {
/* 470 */           ciphersNotMatch = true;
/*     */           break;
/*     */         } 
/* 473 */         if (!boringsslTlsv13Ciphers.remove(cipher) && 
/* 474 */           !boringsslTlsv13Ciphers.remove(CipherSuiteConverter.toJava(cipher, "TLS"))) {
/* 475 */           ciphersNotMatch = true;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*     */       
/* 481 */       int i = ciphersNotMatch | (!boringsslTlsv13Ciphers.isEmpty() ? 1 : 0);
/*     */       
/* 483 */       if (i != 0) {
/* 484 */         if (logger.isInfoEnabled()) {
/* 485 */           StringBuilder javaCiphers = new StringBuilder(128);
/* 486 */           for (String cipher : ciphers.split(":")) {
/* 487 */             javaCiphers.append(CipherSuiteConverter.toJava(cipher, "TLS")).append(":");
/*     */           }
/* 489 */           javaCiphers.setLength(javaCiphers.length() - 1);
/* 490 */           logger.info("BoringSSL doesn't allow to enable or disable TLSv1.3 ciphers explicitly. Provided TLSv1.3 ciphers: '{}', default TLSv1.3 ciphers that will be used: '{}'.", javaCiphers, EXTRA_SUPPORTED_TLS_1_3_CIPHERS_STRING);
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 495 */         return EXTRA_SUPPORTED_TLS_1_3_CIPHERS_STRING;
/*     */       } 
/*     */     } 
/* 498 */     return ciphers;
/*     */   }
/*     */   
/*     */   static boolean isSessionCacheSupported() {
/* 502 */     return (version() >= 269484032L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static X509Certificate selfSignedCertificate() throws CertificateException {
/* 509 */     return (X509Certificate)SslContext.X509_CERT_FACTORY.generateCertificate(new ByteArrayInputStream("-----BEGIN CERTIFICATE-----\nMIICrjCCAZagAwIBAgIIdSvQPv1QAZQwDQYJKoZIhvcNAQELBQAwFjEUMBIGA1UEAxMLZXhhbXBs\nZS5jb20wIBcNMTgwNDA2MjIwNjU5WhgPOTk5OTEyMzEyMzU5NTlaMBYxFDASBgNVBAMTC2V4YW1w\nbGUuY29tMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAggbWsmDQ6zNzRZ5AW8E3eoGl\nqWvOBDb5Fs1oBRrVQHuYmVAoaqwDzXYJ0LOwa293AgWEQ1jpcbZ2hpoYQzqEZBTLnFhMrhRFlH6K\nbJND8Y33kZ/iSVBBDuGbdSbJShlM+4WwQ9IAso4MZ4vW3S1iv5fGGpLgbtXRmBf/RU8omN0Gijlv\nWlLWHWijLN8xQtySFuBQ7ssW8RcKAary3pUm6UUQB+Co6lnfti0Tzag8PgjhAJq2Z3wbsGRnP2YS\nvYoaK6qzmHXRYlp/PxrjBAZAmkLJs4YTm/XFF+fkeYx4i9zqHbyone5yerRibsHaXZWLnUL+rFoe\nMdKvr0VS3sGmhQIDAQABMA0GCSqGSIb3DQEBCwUAA4IBAQADQi441pKmXf9FvUV5EHU4v8nJT9Iq\nyqwsKwXnr7AsUlDGHBD7jGrjAXnG5rGxuNKBQ35wRxJATKrUtyaquFUL6H8O6aGQehiFTk6zmPbe\n12Gu44vqqTgIUxnv3JQJiox8S2hMxsSddpeCmSdvmalvD6WG4NthH6B9ZaBEiep1+0s0RUaBYn73\nI7CCUaAtbjfR6pcJjrFk5ei7uwdQZFSJtkP2z8r7zfeANJddAKFlkaMWn7u+OIVuB4XPooWicObk\nNAHFtP65bocUYnDpTVdiyvn8DdqyZ/EO8n1bBKBzuSLplk2msW4pdgaFgY7Vw/0wzcFXfUXmL1uy\nG8sQD/wx\n-----END CERTIFICATE-----"
/* 510 */           .getBytes(CharsetUtil.US_ASCII)));
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean doesSupportOcsp() {
/* 515 */     boolean supportsOcsp = false;
/* 516 */     if (version() >= 268443648L) {
/* 517 */       long sslCtx = -1L;
/*     */       try {
/* 519 */         sslCtx = SSLContext.make(16, 1);
/* 520 */         SSLContext.enableOcsp(sslCtx, false);
/* 521 */         supportsOcsp = true;
/* 522 */       } catch (Exception exception) {
/*     */       
/*     */       } finally {
/* 525 */         if (sslCtx != -1L) {
/* 526 */           SSLContext.free(sslCtx);
/*     */         }
/*     */       } 
/*     */     } 
/* 530 */     return supportsOcsp;
/*     */   }
/*     */   private static boolean doesSupportProtocol(int protocol, int opt) {
/* 533 */     if (opt == 0)
/*     */     {
/* 535 */       return false;
/*     */     }
/* 537 */     long sslCtx = -1L;
/*     */     try {
/* 539 */       sslCtx = SSLContext.make(protocol, 2);
/* 540 */       return true;
/* 541 */     } catch (Exception ignore) {
/* 542 */       return false;
/*     */     } finally {
/* 544 */       if (sslCtx != -1L) {
/* 545 */         SSLContext.free(sslCtx);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isAvailable() {
/* 556 */     return (UNAVAILABILITY_CAUSE == null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static boolean isAlpnSupported() {
/* 567 */     return (version() >= 268443648L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isOcspSupported() {
/* 574 */     return SUPPORTS_OCSP;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int version() {
/* 582 */     return isAvailable() ? SSL.version() : -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String versionString() {
/* 590 */     return isAvailable() ? SSL.versionString() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void ensureAvailability() {
/* 600 */     if (UNAVAILABILITY_CAUSE != null) {
/* 601 */       throw (Error)(new UnsatisfiedLinkError("failed to load the required native library"))
/* 602 */         .initCause(UNAVAILABILITY_CAUSE);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Throwable unavailabilityCause() {
/* 613 */     return UNAVAILABILITY_CAUSE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static Set<String> availableCipherSuites() {
/* 621 */     return availableOpenSslCipherSuites();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Set<String> availableOpenSslCipherSuites() {
/* 629 */     return AVAILABLE_OPENSSL_CIPHER_SUITES;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Set<String> availableJavaCipherSuites() {
/* 637 */     return AVAILABLE_JAVA_CIPHER_SUITES;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isCipherSuiteAvailable(String cipherSuite) {
/* 645 */     String converted = CipherSuiteConverter.toOpenSsl(cipherSuite, IS_BORINGSSL);
/* 646 */     if (converted != null) {
/* 647 */       cipherSuite = converted;
/*     */     }
/* 649 */     return AVAILABLE_OPENSSL_CIPHER_SUITES.contains(cipherSuite);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean supportsKeyManagerFactory() {
/* 656 */     return SUPPORTS_KEYMANAGER_FACTORY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static boolean supportsHostnameValidation() {
/* 667 */     return isAvailable();
/*     */   }
/*     */   
/*     */   static boolean useKeyManagerFactory() {
/* 671 */     return USE_KEYMANAGER_FACTORY;
/*     */   }
/*     */   
/*     */   static long memoryAddress(ByteBuf buf) {
/* 675 */     assert buf.isDirect();
/* 676 */     return buf.hasMemoryAddress() ? buf.memoryAddress() : 
/*     */       
/* 678 */       Buffer.address(buf.internalNioBuffer(0, buf.readableBytes()));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static void loadTcNative() throws Exception {
/* 684 */     String os = PlatformDependent.normalizedOs();
/* 685 */     String arch = PlatformDependent.normalizedArch();
/*     */     
/* 687 */     Set<String> libNames = new LinkedHashSet<String>(5);
/* 688 */     String staticLibName = "netty_tcnative";
/*     */ 
/*     */ 
/*     */     
/* 692 */     if ("linux".equals(os)) {
/* 693 */       Set<String> classifiers = PlatformDependent.normalizedLinuxClassifiers();
/* 694 */       for (String classifier : classifiers) {
/* 695 */         libNames.add(staticLibName + "_" + os + '_' + arch + "_" + classifier);
/*     */       }
/*     */       
/* 698 */       libNames.add(staticLibName + "_" + os + '_' + arch);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 703 */       libNames.add(staticLibName + "_" + os + '_' + arch + "_fedora");
/*     */     } else {
/* 705 */       libNames.add(staticLibName + "_" + os + '_' + arch);
/*     */     } 
/* 707 */     libNames.add(staticLibName + "_" + arch);
/* 708 */     libNames.add(staticLibName);
/*     */     
/* 710 */     NativeLibraryLoader.loadFirstAvailable(PlatformDependent.getClassLoader(SSLContext.class), libNames
/* 711 */         .<String>toArray(new String[0]));
/*     */   }
/*     */   
/*     */   private static boolean initializeTcNative(String engine) throws Exception {
/* 715 */     return Library.initialize("provided", engine);
/*     */   }
/*     */   
/*     */   static void releaseIfNeeded(ReferenceCounted counted) {
/* 719 */     if (counted.refCnt() > 0) {
/* 720 */       ReferenceCountUtil.safeRelease(counted);
/*     */     }
/*     */   }
/*     */   
/*     */   static boolean isTlsv13Supported() {
/* 725 */     return TLSV13_SUPPORTED;
/*     */   }
/*     */   
/*     */   static boolean isOptionSupported(SslContextOption<?> option) {
/* 729 */     if (isAvailable()) {
/* 730 */       if (option == OpenSslContextOption.USE_TASKS) {
/* 731 */         return true;
/*     */       }
/*     */       
/* 734 */       if (isBoringSSL()) {
/* 735 */         return (option == OpenSslContextOption.ASYNC_PRIVATE_KEY_METHOD || option == OpenSslContextOption.PRIVATE_KEY_METHOD || option == OpenSslContextOption.CERTIFICATE_COMPRESSION_ALGORITHMS || option == OpenSslContextOption.TLS_FALSE_START || option == OpenSslContextOption.MAX_CERTIFICATE_LIST_BYTES);
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 742 */     return false;
/*     */   }
/*     */   
/*     */   private static Set<String> protocols(String property) {
/* 746 */     String protocolsString = SystemPropertyUtil.get(property, null);
/* 747 */     if (protocolsString != null) {
/* 748 */       Set<String> protocols = new HashSet<String>();
/* 749 */       for (String proto : protocolsString.split(",")) {
/* 750 */         String p = proto.trim();
/* 751 */         protocols.add(p);
/*     */       } 
/* 753 */       return protocols;
/*     */     } 
/* 755 */     return null;
/*     */   }
/*     */   
/*     */   static String[] defaultProtocols(boolean isClient) {
/* 759 */     Collection<String> defaultProtocols = isClient ? CLIENT_DEFAULT_PROTOCOLS : SERVER_DEFAULT_PROTOCOLS;
/* 760 */     if (defaultProtocols == null) {
/* 761 */       return null;
/*     */     }
/* 763 */     List<String> protocols = new ArrayList<String>(defaultProtocols.size());
/* 764 */     for (String proto : defaultProtocols) {
/* 765 */       if (SUPPORTED_PROTOCOLS_SET.contains(proto)) {
/* 766 */         protocols.add(proto);
/*     */       }
/*     */     } 
/* 769 */     return protocols.<String>toArray(new String[0]);
/*     */   }
/*     */   
/*     */   static boolean isBoringSSL() {
/* 773 */     return IS_BORINGSSL;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-handler-4.1.93.Final.jar!\io\netty\handler\ssl\OpenSsl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */