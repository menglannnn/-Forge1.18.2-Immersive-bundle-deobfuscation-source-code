/*    */ package io.netty.handler.ssl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum ClientAuth
/*    */ {
/* 27 */   NONE,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 32 */   OPTIONAL,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 37 */   REQUIRE;
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-handler-4.1.93.Final.jar!\io\netty\handler\ssl\ClientAuth.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */