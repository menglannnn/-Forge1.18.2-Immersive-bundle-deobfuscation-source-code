/*     */ package io.netty.handler.ssl;
/*     */ 
/*     */ import io.netty.handler.ssl.util.KeyManagerFactoryWrapper;
/*     */ import io.netty.handler.ssl.util.TrustManagerFactoryWrapper;
/*     */ import io.netty.util.internal.EmptyArrays;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import java.io.File;
/*     */ import java.io.InputStream;
/*     */ import java.security.KeyStore;
/*     */ import java.security.PrivateKey;
/*     */ import java.security.Provider;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.net.ssl.KeyManager;
/*     */ import javax.net.ssl.KeyManagerFactory;
/*     */ import javax.net.ssl.SSLException;
/*     */ import javax.net.ssl.TrustManager;
/*     */ import javax.net.ssl.TrustManagerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SslContextBuilder
/*     */ {
/*  51 */   private static final Map.Entry[] EMPTY_ENTRIES = new Map.Entry[0];
/*     */   
/*     */   private final boolean forServer;
/*     */   private SslProvider provider;
/*     */   
/*     */   public static SslContextBuilder forClient() {
/*  57 */     return new SslContextBuilder(false);
/*     */   }
/*     */   private Provider sslContextProvider; private X509Certificate[] trustCertCollection;
/*     */   private TrustManagerFactory trustManagerFactory;
/*     */   private X509Certificate[] keyCertChain;
/*     */   private PrivateKey key;
/*     */   private String keyPassword;
/*     */   private KeyManagerFactory keyManagerFactory;
/*     */   private Iterable<String> ciphers;
/*     */   
/*     */   public static SslContextBuilder forServer(File keyCertChainFile, File keyFile) {
/*  68 */     return (new SslContextBuilder(true)).keyManager(keyCertChainFile, keyFile);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SslContextBuilder forServer(InputStream keyCertChainInputStream, InputStream keyInputStream) {
/*  84 */     return (new SslContextBuilder(true)).keyManager(keyCertChainInputStream, keyInputStream);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SslContextBuilder forServer(PrivateKey key, X509Certificate... keyCertChain) {
/*  95 */     return (new SslContextBuilder(true)).keyManager(key, keyCertChain);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SslContextBuilder forServer(PrivateKey key, Iterable<? extends X509Certificate> keyCertChain) {
/* 106 */     return forServer(key, toArray(keyCertChain, EmptyArrays.EMPTY_X509_CERTIFICATES));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SslContextBuilder forServer(File keyCertChainFile, File keyFile, String keyPassword) {
/* 120 */     return (new SslContextBuilder(true)).keyManager(keyCertChainFile, keyFile, keyPassword);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SslContextBuilder forServer(InputStream keyCertChainInputStream, InputStream keyInputStream, String keyPassword) {
/* 138 */     return (new SslContextBuilder(true)).keyManager(keyCertChainInputStream, keyInputStream, keyPassword);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SslContextBuilder forServer(PrivateKey key, String keyPassword, X509Certificate... keyCertChain) {
/* 152 */     return (new SslContextBuilder(true)).keyManager(key, keyPassword, keyCertChain);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SslContextBuilder forServer(PrivateKey key, String keyPassword, Iterable<? extends X509Certificate> keyCertChain) {
/* 166 */     return forServer(key, keyPassword, toArray(keyCertChain, EmptyArrays.EMPTY_X509_CERTIFICATES));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SslContextBuilder forServer(KeyManagerFactory keyManagerFactory) {
/* 179 */     return (new SslContextBuilder(true)).keyManager(keyManagerFactory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SslContextBuilder forServer(KeyManager keyManager) {
/* 188 */     return (new SslContextBuilder(true)).keyManager(keyManager);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 201 */   private CipherSuiteFilter cipherFilter = IdentityCipherSuiteFilter.INSTANCE;
/*     */   private ApplicationProtocolConfig apn;
/*     */   private long sessionCacheSize;
/*     */   private long sessionTimeout;
/* 205 */   private ClientAuth clientAuth = ClientAuth.NONE;
/*     */   private String[] protocols;
/*     */   private boolean startTls;
/*     */   private boolean enableOcsp;
/* 209 */   private String keyStoreType = KeyStore.getDefaultType();
/* 210 */   private final Map<SslContextOption<?>, Object> options = new HashMap<SslContextOption<?>, Object>();
/*     */   
/*     */   private SslContextBuilder(boolean forServer) {
/* 213 */     this.forServer = forServer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> SslContextBuilder option(SslContextOption<T> option, T value) {
/* 220 */     if (value == null) {
/* 221 */       this.options.remove(option);
/*     */     } else {
/* 223 */       this.options.put(option, value);
/*     */     } 
/* 225 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SslContextBuilder sslProvider(SslProvider provider) {
/* 232 */     this.provider = provider;
/* 233 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SslContextBuilder keyStoreType(String keyStoreType) {
/* 240 */     this.keyStoreType = keyStoreType;
/* 241 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SslContextBuilder sslContextProvider(Provider sslContextProvider) {
/* 249 */     this.sslContextProvider = sslContextProvider;
/* 250 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SslContextBuilder trustManager(File trustCertCollectionFile) {
/*     */     try {
/* 259 */       return trustManager(SslContext.toX509Certificates(trustCertCollectionFile));
/* 260 */     } catch (Exception e) {
/* 261 */       throw new IllegalArgumentException("File does not contain valid certificates: " + trustCertCollectionFile, e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SslContextBuilder trustManager(InputStream trustCertCollectionInputStream) {
/*     */     try {
/* 274 */       return trustManager(SslContext.toX509Certificates(trustCertCollectionInputStream));
/* 275 */     } catch (Exception e) {
/* 276 */       throw new IllegalArgumentException("Input stream does not contain valid certificates.", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SslContextBuilder trustManager(X509Certificate... trustCertCollection) {
/* 284 */     this.trustCertCollection = (trustCertCollection != null) ? (X509Certificate[])trustCertCollection.clone() : null;
/* 285 */     this.trustManagerFactory = null;
/* 286 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SslContextBuilder trustManager(Iterable<? extends X509Certificate> trustCertCollection) {
/* 293 */     return trustManager(toArray(trustCertCollection, EmptyArrays.EMPTY_X509_CERTIFICATES));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SslContextBuilder trustManager(TrustManagerFactory trustManagerFactory) {
/* 300 */     this.trustCertCollection = null;
/* 301 */     this.trustManagerFactory = trustManagerFactory;
/* 302 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SslContextBuilder trustManager(TrustManager trustManager) {
/* 313 */     if (trustManager != null) {
/* 314 */       this.trustManagerFactory = (TrustManagerFactory)new TrustManagerFactoryWrapper(trustManager);
/*     */     } else {
/* 316 */       this.trustManagerFactory = null;
/*     */     } 
/* 318 */     this.trustCertCollection = null;
/* 319 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SslContextBuilder keyManager(File keyCertChainFile, File keyFile) {
/* 330 */     return keyManager(keyCertChainFile, keyFile, (String)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SslContextBuilder keyManager(InputStream keyCertChainInputStream, InputStream keyInputStream) {
/* 345 */     return keyManager(keyCertChainInputStream, keyInputStream, (String)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SslContextBuilder keyManager(PrivateKey key, X509Certificate... keyCertChain) {
/* 356 */     return keyManager(key, (String)null, keyCertChain);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SslContextBuilder keyManager(PrivateKey key, Iterable<? extends X509Certificate> keyCertChain) {
/* 367 */     return keyManager(key, toArray(keyCertChain, EmptyArrays.EMPTY_X509_CERTIFICATES));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SslContextBuilder keyManager(File keyCertChainFile, File keyFile, String keyPassword) {
/*     */     X509Certificate[] keyCertChain;
/*     */     PrivateKey key;
/*     */     try {
/* 383 */       keyCertChain = SslContext.toX509Certificates(keyCertChainFile);
/* 384 */     } catch (Exception e) {
/* 385 */       throw new IllegalArgumentException("File does not contain valid certificates: " + keyCertChainFile, e);
/*     */     } 
/*     */     try {
/* 388 */       key = SslContext.toPrivateKey(keyFile, keyPassword);
/* 389 */     } catch (Exception e) {
/* 390 */       throw new IllegalArgumentException("File does not contain valid private key: " + keyFile, e);
/*     */     } 
/* 392 */     return keyManager(key, keyPassword, keyCertChain);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SslContextBuilder keyManager(InputStream keyCertChainInputStream, InputStream keyInputStream, String keyPassword) {
/*     */     X509Certificate[] keyCertChain;
/*     */     PrivateKey key;
/*     */     try {
/* 413 */       keyCertChain = SslContext.toX509Certificates(keyCertChainInputStream);
/* 414 */     } catch (Exception e) {
/* 415 */       throw new IllegalArgumentException("Input stream not contain valid certificates.", e);
/*     */     } 
/*     */     try {
/* 418 */       key = SslContext.toPrivateKey(keyInputStream, keyPassword);
/* 419 */     } catch (Exception e) {
/* 420 */       throw new IllegalArgumentException("Input stream does not contain valid private key.", e);
/*     */     } 
/* 422 */     return keyManager(key, keyPassword, keyCertChain);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SslContextBuilder keyManager(PrivateKey key, String keyPassword, X509Certificate... keyCertChain) {
/* 435 */     if (this.forServer) {
/* 436 */       ObjectUtil.checkNonEmpty((Object[])keyCertChain, "keyCertChain");
/* 437 */       ObjectUtil.checkNotNull(key, "key required for servers");
/*     */     } 
/* 439 */     if (keyCertChain == null || keyCertChain.length == 0) {
/* 440 */       this.keyCertChain = null;
/*     */     } else {
/* 442 */       for (X509Certificate cert : keyCertChain) {
/* 443 */         ObjectUtil.checkNotNullWithIAE(cert, "cert");
/*     */       }
/* 445 */       this.keyCertChain = (X509Certificate[])keyCertChain.clone();
/*     */     } 
/* 447 */     this.key = key;
/* 448 */     this.keyPassword = keyPassword;
/* 449 */     this.keyManagerFactory = null;
/* 450 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SslContextBuilder keyManager(PrivateKey key, String keyPassword, Iterable<? extends X509Certificate> keyCertChain) {
/* 464 */     return keyManager(key, keyPassword, toArray(keyCertChain, EmptyArrays.EMPTY_X509_CERTIFICATES));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SslContextBuilder keyManager(KeyManagerFactory keyManagerFactory) {
/* 479 */     if (this.forServer) {
/* 480 */       ObjectUtil.checkNotNull(keyManagerFactory, "keyManagerFactory required for servers");
/*     */     }
/* 482 */     this.keyCertChain = null;
/* 483 */     this.key = null;
/* 484 */     this.keyPassword = null;
/* 485 */     this.keyManagerFactory = keyManagerFactory;
/* 486 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SslContextBuilder keyManager(KeyManager keyManager) {
/* 497 */     if (this.forServer) {
/* 498 */       ObjectUtil.checkNotNull(keyManager, "keyManager required for servers");
/*     */     }
/* 500 */     if (keyManager != null) {
/* 501 */       this.keyManagerFactory = (KeyManagerFactory)new KeyManagerFactoryWrapper(keyManager);
/*     */     } else {
/* 503 */       this.keyManagerFactory = null;
/*     */     } 
/* 505 */     this.keyCertChain = null;
/* 506 */     this.key = null;
/* 507 */     this.keyPassword = null;
/* 508 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SslContextBuilder ciphers(Iterable<String> ciphers) {
/* 516 */     return ciphers(ciphers, IdentityCipherSuiteFilter.INSTANCE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SslContextBuilder ciphers(Iterable<String> ciphers, CipherSuiteFilter cipherFilter) {
/* 525 */     this.cipherFilter = (CipherSuiteFilter)ObjectUtil.checkNotNull(cipherFilter, "cipherFilter");
/* 526 */     this.ciphers = ciphers;
/* 527 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SslContextBuilder applicationProtocolConfig(ApplicationProtocolConfig apn) {
/* 534 */     this.apn = apn;
/* 535 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SslContextBuilder sessionCacheSize(long sessionCacheSize) {
/* 543 */     this.sessionCacheSize = sessionCacheSize;
/* 544 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SslContextBuilder sessionTimeout(long sessionTimeout) {
/* 552 */     this.sessionTimeout = sessionTimeout;
/* 553 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SslContextBuilder clientAuth(ClientAuth clientAuth) {
/* 560 */     this.clientAuth = (ClientAuth)ObjectUtil.checkNotNull(clientAuth, "clientAuth");
/* 561 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SslContextBuilder protocols(String... protocols) {
/* 570 */     this.protocols = (protocols == null) ? null : (String[])protocols.clone();
/* 571 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SslContextBuilder protocols(Iterable<String> protocols) {
/* 580 */     return protocols(toArray(protocols, EmptyArrays.EMPTY_STRINGS));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SslContextBuilder startTls(boolean startTls) {
/* 587 */     this.startTls = startTls;
/* 588 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SslContextBuilder enableOcsp(boolean enableOcsp) {
/* 599 */     this.enableOcsp = enableOcsp;
/* 600 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SslContext build() throws SSLException {
/* 609 */     if (this.forServer) {
/* 610 */       return SslContext.newServerContextInternal(this.provider, this.sslContextProvider, this.trustCertCollection, this.trustManagerFactory, this.keyCertChain, this.key, this.keyPassword, this.keyManagerFactory, this.ciphers, this.cipherFilter, this.apn, this.sessionCacheSize, this.sessionTimeout, this.clientAuth, this.protocols, this.startTls, this.enableOcsp, this.keyStoreType, 
/*     */ 
/*     */           
/* 613 */           toArray(this.options.entrySet(), (Map.Entry<SslContextOption<?>, Object>[])EMPTY_ENTRIES));
/*     */     }
/* 615 */     return SslContext.newClientContextInternal(this.provider, this.sslContextProvider, this.trustCertCollection, this.trustManagerFactory, this.keyCertChain, this.key, this.keyPassword, this.keyManagerFactory, this.ciphers, this.cipherFilter, this.apn, this.protocols, this.sessionCacheSize, this.sessionTimeout, this.enableOcsp, this.keyStoreType, 
/*     */ 
/*     */         
/* 618 */         toArray(this.options.entrySet(), (Map.Entry<SslContextOption<?>, Object>[])EMPTY_ENTRIES));
/*     */   }
/*     */ 
/*     */   
/*     */   private static <T> T[] toArray(Iterable<? extends T> iterable, T[] prototype) {
/* 623 */     if (iterable == null) {
/* 624 */       return null;
/*     */     }
/* 626 */     List<T> list = new ArrayList<T>();
/* 627 */     for (T element : iterable) {
/* 628 */       list.add(element);
/*     */     }
/* 630 */     return list.toArray(prototype);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-handler-4.1.93.Final.jar!\io\netty\handler\ssl\SslContextBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */