/*      */ package io.netty.handler.ssl;
/*      */ 
/*      */ import io.netty.buffer.ByteBuf;
/*      */ import io.netty.buffer.ByteBufAllocator;
/*      */ import io.netty.handler.ssl.util.LazyJavaxX509Certificate;
/*      */ import io.netty.handler.ssl.util.LazyX509Certificate;
/*      */ import io.netty.internal.tcnative.AsyncTask;
/*      */ import io.netty.internal.tcnative.Buffer;
/*      */ import io.netty.internal.tcnative.SSL;
/*      */ import io.netty.util.AbstractReferenceCounted;
/*      */ import io.netty.util.CharsetUtil;
/*      */ import io.netty.util.ReferenceCounted;
/*      */ import io.netty.util.ResourceLeakDetector;
/*      */ import io.netty.util.ResourceLeakDetectorFactory;
/*      */ import io.netty.util.ResourceLeakTracker;
/*      */ import io.netty.util.internal.EmptyArrays;
/*      */ import io.netty.util.internal.ObjectUtil;
/*      */ import io.netty.util.internal.PlatformDependent;
/*      */ import io.netty.util.internal.SuppressJava6Requirement;
/*      */ import io.netty.util.internal.ThrowableUtil;
/*      */ import io.netty.util.internal.logging.InternalLogger;
/*      */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.nio.ReadOnlyBufferException;
/*      */ import java.security.Principal;
/*      */ import java.security.cert.Certificate;
/*      */ import java.security.cert.X509Certificate;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.locks.Lock;
/*      */ import javax.crypto.spec.SecretKeySpec;
/*      */ import javax.net.ssl.SSLEngine;
/*      */ import javax.net.ssl.SSLEngineResult;
/*      */ import javax.net.ssl.SSLException;
/*      */ import javax.net.ssl.SSLHandshakeException;
/*      */ import javax.net.ssl.SSLParameters;
/*      */ import javax.net.ssl.SSLPeerUnverifiedException;
/*      */ import javax.net.ssl.SSLSession;
/*      */ import javax.net.ssl.SSLSessionBindingEvent;
/*      */ import javax.net.ssl.SSLSessionBindingListener;
/*      */ import javax.net.ssl.SSLSessionContext;
/*      */ import javax.security.cert.X509Certificate;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ReferenceCountedOpenSslEngine
/*      */   extends SSLEngine
/*      */   implements ReferenceCounted, ApplicationProtocolAccessor
/*      */ {
/*   96 */   private static final InternalLogger logger = InternalLoggerFactory.getInstance(ReferenceCountedOpenSslEngine.class);
/*      */ 
/*      */   
/*   99 */   private static final ResourceLeakDetector<ReferenceCountedOpenSslEngine> leakDetector = ResourceLeakDetectorFactory.instance().newResourceLeakDetector(ReferenceCountedOpenSslEngine.class);
/*      */   private static final int OPENSSL_OP_NO_PROTOCOL_INDEX_SSLV2 = 0;
/*      */   private static final int OPENSSL_OP_NO_PROTOCOL_INDEX_SSLV3 = 1;
/*      */   private static final int OPENSSL_OP_NO_PROTOCOL_INDEX_TLSv1 = 2;
/*      */   private static final int OPENSSL_OP_NO_PROTOCOL_INDEX_TLSv1_1 = 3;
/*      */   private static final int OPENSSL_OP_NO_PROTOCOL_INDEX_TLSv1_2 = 4;
/*      */   private static final int OPENSSL_OP_NO_PROTOCOL_INDEX_TLSv1_3 = 5;
/*  106 */   private static final int[] OPENSSL_OP_NO_PROTOCOLS = new int[] { SSL.SSL_OP_NO_SSLv2, SSL.SSL_OP_NO_SSLv3, SSL.SSL_OP_NO_TLSv1, SSL.SSL_OP_NO_TLSv1_1, SSL.SSL_OP_NO_TLSv1_2, SSL.SSL_OP_NO_TLSv1_3 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  118 */   static final int MAX_PLAINTEXT_LENGTH = SSL.SSL_MAX_PLAINTEXT_LENGTH;
/*      */ 
/*      */ 
/*      */   
/*  122 */   static final int MAX_RECORD_SIZE = SSL.SSL_MAX_RECORD_LENGTH;
/*      */   
/*  124 */   private static final SSLEngineResult NEED_UNWRAP_OK = new SSLEngineResult(SSLEngineResult.Status.OK, SSLEngineResult.HandshakeStatus.NEED_UNWRAP, 0, 0);
/*  125 */   private static final SSLEngineResult NEED_UNWRAP_CLOSED = new SSLEngineResult(SSLEngineResult.Status.CLOSED, SSLEngineResult.HandshakeStatus.NEED_UNWRAP, 0, 0);
/*  126 */   private static final SSLEngineResult NEED_WRAP_OK = new SSLEngineResult(SSLEngineResult.Status.OK, SSLEngineResult.HandshakeStatus.NEED_WRAP, 0, 0);
/*  127 */   private static final SSLEngineResult NEED_WRAP_CLOSED = new SSLEngineResult(SSLEngineResult.Status.CLOSED, SSLEngineResult.HandshakeStatus.NEED_WRAP, 0, 0); private long ssl; private long networkBIO; private HandshakeState handshakeState; private boolean receivedShutdown; private volatile boolean destroyed; private volatile String applicationProtocol; private volatile boolean needTask; private String[] explicitlyEnabledProtocols; private boolean sessionSet; private final ResourceLeakTracker<ReferenceCountedOpenSslEngine> leak; private final AbstractReferenceCounted refCnt; private volatile ClientAuth clientAuth; private volatile long lastAccessed; private String endPointIdentificationAlgorithm; private Object algorithmConstraints; private List<String> sniHostNames;
/*  128 */   private static final SSLEngineResult CLOSED_NOT_HANDSHAKING = new SSLEngineResult(SSLEngineResult.Status.CLOSED, SSLEngineResult.HandshakeStatus.NOT_HANDSHAKING, 0, 0); private volatile Collection<?> matchers; private boolean isInboundDone; private boolean outboundClosed; final boolean jdkCompatibilityMode; private final boolean clientMode; final ByteBufAllocator alloc; private final OpenSslEngineMap engineMap; private final OpenSslApplicationProtocolNegotiator apn;
/*      */   private final ReferenceCountedOpenSslContext parentContext;
/*      */   private final OpenSslSession session;
/*      */   private final ByteBuffer[] singleSrcBuffer;
/*      */   private final ByteBuffer[] singleDstBuffer;
/*      */   private final boolean enableOcsp;
/*      */   private int maxWrapOverhead;
/*      */   private int maxWrapBufferSize;
/*      */   private Throwable pendingException;
/*      */   
/*  138 */   private enum HandshakeState { NOT_STARTED,
/*      */ 
/*      */ 
/*      */     
/*  142 */     STARTED_IMPLICITLY,
/*      */ 
/*      */ 
/*      */     
/*  146 */     STARTED_EXPLICITLY,
/*      */ 
/*      */ 
/*      */     
/*  150 */     FINISHED; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   ReferenceCountedOpenSslEngine(ReferenceCountedOpenSslContext context, ByteBufAllocator alloc, String peerHost, int peerPort, boolean jdkCompatibilityMode, boolean leakDetection) {
/*  230 */     super(peerHost, peerPort); long finalSsl; this.handshakeState = HandshakeState.NOT_STARTED; this.refCnt = new AbstractReferenceCounted() { public ReferenceCounted touch(Object hint) { if (ReferenceCountedOpenSslEngine.this.leak != null) ReferenceCountedOpenSslEngine.this.leak.record(hint);  return ReferenceCountedOpenSslEngine.this; } protected void deallocate() { ReferenceCountedOpenSslEngine.this.shutdown(); if (ReferenceCountedOpenSslEngine.this.leak != null) { boolean closed = ReferenceCountedOpenSslEngine.this.leak.close(ReferenceCountedOpenSslEngine.this); assert closed; }  ReferenceCountedOpenSslEngine.this.parentContext.release(); } }
/*  231 */       ; this.clientAuth = ClientAuth.NONE; this.lastAccessed = -1L; this.singleSrcBuffer = new ByteBuffer[1]; this.singleDstBuffer = new ByteBuffer[1]; OpenSsl.ensureAvailability();
/*  232 */     this.engineMap = context.engineMap;
/*  233 */     this.enableOcsp = context.enableOcsp;
/*  234 */     this.jdkCompatibilityMode = jdkCompatibilityMode;
/*  235 */     this.alloc = (ByteBufAllocator)ObjectUtil.checkNotNull(alloc, "alloc");
/*  236 */     this.apn = (OpenSslApplicationProtocolNegotiator)context.applicationProtocolNegotiator();
/*  237 */     this.clientMode = context.isClient();
/*      */     
/*  239 */     if (PlatformDependent.javaVersion() >= 7) {
/*  240 */       this.session = new ExtendedOpenSslSession(new DefaultOpenSslSession(context.sessionContext()))
/*      */         {
/*      */           private String[] peerSupportedSignatureAlgorithms;
/*      */           private List requestedServerNames;
/*      */           
/*      */           public List getRequestedServerNames() {
/*  246 */             if (ReferenceCountedOpenSslEngine.this.clientMode) {
/*  247 */               return Java8SslUtils.getSniHostNames(ReferenceCountedOpenSslEngine.this.sniHostNames);
/*      */             }
/*  249 */             synchronized (ReferenceCountedOpenSslEngine.this) {
/*  250 */               if (this.requestedServerNames == null) {
/*  251 */                 if (ReferenceCountedOpenSslEngine.this.isDestroyed()) {
/*  252 */                   this.requestedServerNames = Collections.emptyList();
/*      */                 } else {
/*  254 */                   String name = SSL.getSniHostname(ReferenceCountedOpenSslEngine.this.ssl);
/*  255 */                   if (name == null) {
/*  256 */                     this.requestedServerNames = Collections.emptyList();
/*      */                   }
/*      */                   else {
/*      */                     
/*  260 */                     this
/*  261 */                       .requestedServerNames = Java8SslUtils.getSniHostName(
/*  262 */                         SSL.getSniHostname(ReferenceCountedOpenSslEngine.this.ssl).getBytes(CharsetUtil.UTF_8));
/*      */                   } 
/*      */                 } 
/*      */               }
/*  266 */               return this.requestedServerNames;
/*      */             } 
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*      */           public String[] getPeerSupportedSignatureAlgorithms() {
/*  273 */             synchronized (ReferenceCountedOpenSslEngine.this) {
/*  274 */               if (this.peerSupportedSignatureAlgorithms == null) {
/*  275 */                 if (ReferenceCountedOpenSslEngine.this.isDestroyed()) {
/*  276 */                   this.peerSupportedSignatureAlgorithms = EmptyArrays.EMPTY_STRINGS;
/*      */                 } else {
/*  278 */                   String[] algs = SSL.getSigAlgs(ReferenceCountedOpenSslEngine.this.ssl);
/*  279 */                   if (algs == null) {
/*  280 */                     this.peerSupportedSignatureAlgorithms = EmptyArrays.EMPTY_STRINGS;
/*      */                   } else {
/*  282 */                     Set<String> algorithmList = new LinkedHashSet<String>(algs.length);
/*  283 */                     for (String alg : algs) {
/*  284 */                       String converted = SignatureAlgorithmConverter.toJavaName(alg);
/*      */                       
/*  286 */                       if (converted != null) {
/*  287 */                         algorithmList.add(converted);
/*      */                       }
/*      */                     } 
/*  290 */                     this.peerSupportedSignatureAlgorithms = algorithmList.<String>toArray(new String[0]);
/*      */                   } 
/*      */                 } 
/*      */               }
/*  294 */               return (String[])this.peerSupportedSignatureAlgorithms.clone();
/*      */             } 
/*      */           }
/*      */ 
/*      */           
/*      */           public List<byte[]> getStatusResponses() {
/*  300 */             byte[] ocspResponse = null;
/*  301 */             if (ReferenceCountedOpenSslEngine.this.enableOcsp && ReferenceCountedOpenSslEngine.this.clientMode) {
/*  302 */               synchronized (ReferenceCountedOpenSslEngine.this) {
/*  303 */                 if (!ReferenceCountedOpenSslEngine.this.isDestroyed()) {
/*  304 */                   ocspResponse = SSL.getOcspResponse(ReferenceCountedOpenSslEngine.this.ssl);
/*      */                 }
/*      */               } 
/*      */             }
/*  308 */             return (ocspResponse == null) ? 
/*  309 */               (List)Collections.<byte[]>emptyList() : (List)Collections.<byte[]>singletonList(ocspResponse);
/*      */           }
/*      */         };
/*      */     } else {
/*  313 */       this.session = new DefaultOpenSslSession(context.sessionContext());
/*      */     } 
/*      */     
/*  316 */     if (!context.sessionContext().useKeyManager()) {
/*  317 */       this.session.setLocalCertificate(context.keyCertChain);
/*      */     }
/*      */     
/*  320 */     Lock readerLock = context.ctxLock.readLock();
/*  321 */     readerLock.lock();
/*      */     
/*      */     try {
/*  324 */       finalSsl = SSL.newSSL(context.ctx, !context.isClient());
/*      */     } finally {
/*  326 */       readerLock.unlock();
/*      */     } 
/*  328 */     synchronized (this) {
/*  329 */       this.ssl = finalSsl;
/*      */       try {
/*  331 */         this.networkBIO = SSL.bioNewByteBuffer(this.ssl, context.getBioNonApplicationBufferSize());
/*      */ 
/*      */ 
/*      */         
/*  335 */         setClientAuth(this.clientMode ? ClientAuth.NONE : context.clientAuth);
/*      */         
/*  337 */         if (context.protocols != null) {
/*  338 */           setEnabledProtocols0(context.protocols, true);
/*      */         } else {
/*  340 */           this.explicitlyEnabledProtocols = getEnabledProtocols();
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/*  345 */         if (this.clientMode && SslUtils.isValidHostNameForSNI(peerHost))
/*      */         {
/*      */           
/*  348 */           if (PlatformDependent.javaVersion() >= 8) {
/*  349 */             if (Java8SslUtils.isValidHostNameForSNI(peerHost)) {
/*  350 */               SSL.setTlsExtHostName(this.ssl, peerHost);
/*  351 */               this.sniHostNames = Collections.singletonList(peerHost);
/*      */             } 
/*      */           } else {
/*  354 */             SSL.setTlsExtHostName(this.ssl, peerHost);
/*  355 */             this.sniHostNames = Collections.singletonList(peerHost);
/*      */           } 
/*      */         }
/*      */         
/*  359 */         if (this.enableOcsp) {
/*  360 */           SSL.enableOcsp(this.ssl);
/*      */         }
/*      */         
/*  363 */         if (!jdkCompatibilityMode) {
/*  364 */           SSL.setMode(this.ssl, SSL.getMode(this.ssl) | SSL.SSL_MODE_ENABLE_PARTIAL_WRITE);
/*      */         }
/*      */         
/*  367 */         if (isProtocolEnabled(SSL.getOptions(this.ssl), SSL.SSL_OP_NO_TLSv1_3, "TLSv1.3")) {
/*  368 */           boolean enableTickets = this.clientMode ? ReferenceCountedOpenSslContext.CLIENT_ENABLE_SESSION_TICKET_TLSV13 : ReferenceCountedOpenSslContext.SERVER_ENABLE_SESSION_TICKET_TLSV13;
/*      */ 
/*      */           
/*  371 */           if (enableTickets)
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  379 */             SSL.clearOptions(this.ssl, SSL.SSL_OP_NO_TICKET);
/*      */           }
/*      */         } 
/*      */         
/*  383 */         if (OpenSsl.isBoringSSL() && this.clientMode)
/*      */         {
/*      */ 
/*      */ 
/*      */           
/*  388 */           SSL.setRenegotiateMode(this.ssl, SSL.SSL_RENEGOTIATE_ONCE);
/*      */         }
/*      */         
/*  391 */         calculateMaxWrapOverhead();
/*  392 */       } catch (Throwable cause) {
/*      */ 
/*      */         
/*  395 */         shutdown();
/*      */         
/*  397 */         PlatformDependent.throwException(cause);
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  403 */     this.parentContext = context;
/*  404 */     this.parentContext.retain();
/*      */ 
/*      */ 
/*      */     
/*  408 */     this.leak = leakDetection ? leakDetector.track(this) : null;
/*      */   }
/*      */   
/*      */   final synchronized String[] authMethods() {
/*  412 */     if (isDestroyed()) {
/*  413 */       return EmptyArrays.EMPTY_STRINGS;
/*      */     }
/*  415 */     return SSL.authenticationMethods(this.ssl);
/*      */   }
/*      */   
/*      */   final boolean setKeyMaterial(OpenSslKeyMaterial keyMaterial) throws Exception {
/*  419 */     synchronized (this) {
/*  420 */       if (isDestroyed()) {
/*  421 */         return false;
/*      */       }
/*  423 */       SSL.setKeyMaterial(this.ssl, keyMaterial.certificateChainAddress(), keyMaterial.privateKeyAddress());
/*      */     } 
/*  425 */     this.session.setLocalCertificate((Certificate[])keyMaterial.certificateChain());
/*  426 */     return true;
/*      */   }
/*      */   
/*      */   final synchronized SecretKeySpec masterKey() {
/*  430 */     if (isDestroyed()) {
/*  431 */       return null;
/*      */     }
/*  433 */     return new SecretKeySpec(SSL.getMasterKey(this.ssl), "AES");
/*      */   }
/*      */   
/*      */   synchronized boolean isSessionReused() {
/*  437 */     if (isDestroyed()) {
/*  438 */       return false;
/*      */     }
/*  440 */     return SSL.isSessionReused(this.ssl);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOcspResponse(byte[] response) {
/*  448 */     if (!this.enableOcsp) {
/*  449 */       throw new IllegalStateException("OCSP stapling is not enabled");
/*      */     }
/*      */     
/*  452 */     if (this.clientMode) {
/*  453 */       throw new IllegalStateException("Not a server SSLEngine");
/*      */     }
/*      */     
/*  456 */     synchronized (this) {
/*  457 */       if (!isDestroyed()) {
/*  458 */         SSL.setOcspResponse(this.ssl, response);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] getOcspResponse() {
/*  468 */     if (!this.enableOcsp) {
/*  469 */       throw new IllegalStateException("OCSP stapling is not enabled");
/*      */     }
/*      */     
/*  472 */     if (!this.clientMode) {
/*  473 */       throw new IllegalStateException("Not a client SSLEngine");
/*      */     }
/*      */     
/*  476 */     synchronized (this) {
/*  477 */       if (isDestroyed()) {
/*  478 */         return EmptyArrays.EMPTY_BYTES;
/*      */       }
/*  480 */       return SSL.getOcspResponse(this.ssl);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public final int refCnt() {
/*  486 */     return this.refCnt.refCnt();
/*      */   }
/*      */ 
/*      */   
/*      */   public final ReferenceCounted retain() {
/*  491 */     this.refCnt.retain();
/*  492 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public final ReferenceCounted retain(int increment) {
/*  497 */     this.refCnt.retain(increment);
/*  498 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public final ReferenceCounted touch() {
/*  503 */     this.refCnt.touch();
/*  504 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public final ReferenceCounted touch(Object hint) {
/*  509 */     this.refCnt.touch(hint);
/*  510 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public final boolean release() {
/*  515 */     return this.refCnt.release();
/*      */   }
/*      */ 
/*      */   
/*      */   public final boolean release(int decrement) {
/*  520 */     return this.refCnt.release(decrement);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getApplicationProtocol() {
/*  526 */     return this.applicationProtocol;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getHandshakeApplicationProtocol() {
/*  532 */     return this.applicationProtocol;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final synchronized SSLSession getHandshakeSession() {
/*  541 */     switch (this.handshakeState) {
/*      */       case NONE:
/*      */       case ALPN:
/*  544 */         return null;
/*      */     } 
/*  546 */     return this.session;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final synchronized long sslPointer() {
/*  556 */     return this.ssl;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final synchronized void shutdown() {
/*  563 */     if (!this.destroyed) {
/*  564 */       this.destroyed = true;
/*      */ 
/*      */ 
/*      */       
/*  568 */       if (this.engineMap != null) {
/*  569 */         this.engineMap.remove(this.ssl);
/*      */       }
/*  571 */       SSL.freeSSL(this.ssl);
/*  572 */       this.ssl = this.networkBIO = 0L;
/*      */       
/*  574 */       this.isInboundDone = this.outboundClosed = true;
/*      */     } 
/*      */ 
/*      */     
/*  578 */     SSL.clearError();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int writePlaintextData(ByteBuffer src, int len) {
/*  587 */     int sslWrote, pos = src.position();
/*  588 */     int limit = src.limit();
/*      */ 
/*      */     
/*  591 */     if (src.isDirect()) {
/*  592 */       sslWrote = SSL.writeToSSL(this.ssl, bufferAddress(src) + pos, len);
/*  593 */       if (sslWrote > 0) {
/*  594 */         src.position(pos + sslWrote);
/*      */       }
/*      */     } else {
/*  597 */       ByteBuf buf = this.alloc.directBuffer(len);
/*      */       try {
/*  599 */         src.limit(pos + len);
/*      */         
/*  601 */         buf.setBytes(0, src);
/*  602 */         src.limit(limit);
/*      */         
/*  604 */         sslWrote = SSL.writeToSSL(this.ssl, OpenSsl.memoryAddress(buf), len);
/*  605 */         if (sslWrote > 0) {
/*  606 */           src.position(pos + sslWrote);
/*      */         } else {
/*  608 */           src.position(pos);
/*      */         } 
/*      */       } finally {
/*  611 */         buf.release();
/*      */       } 
/*      */     } 
/*  614 */     return sslWrote;
/*      */   }
/*      */   
/*      */   synchronized void bioSetFd(int fd) {
/*  618 */     if (!isDestroyed()) {
/*  619 */       SSL.bioSetFd(this.ssl, fd);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ByteBuf writeEncryptedData(ByteBuffer src, int len) throws SSLException {
/*  627 */     int pos = src.position();
/*  628 */     if (src.isDirect()) {
/*  629 */       SSL.bioSetByteBuffer(this.networkBIO, bufferAddress(src) + pos, len, false);
/*      */     } else {
/*  631 */       ByteBuf buf = this.alloc.directBuffer(len);
/*      */       try {
/*  633 */         int limit = src.limit();
/*  634 */         src.limit(pos + len);
/*  635 */         buf.writeBytes(src);
/*      */         
/*  637 */         src.position(pos);
/*  638 */         src.limit(limit);
/*      */         
/*  640 */         SSL.bioSetByteBuffer(this.networkBIO, OpenSsl.memoryAddress(buf), len, false);
/*  641 */         return buf;
/*  642 */       } catch (Throwable cause) {
/*  643 */         buf.release();
/*  644 */         PlatformDependent.throwException(cause);
/*      */       } 
/*      */     } 
/*  647 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int readPlaintextData(ByteBuffer dst) throws SSLException {
/*  655 */     int sslRead, pos = dst.position();
/*  656 */     if (dst.isDirect()) {
/*  657 */       sslRead = SSL.readFromSSL(this.ssl, bufferAddress(dst) + pos, dst.limit() - pos);
/*  658 */       if (sslRead > 0) {
/*  659 */         dst.position(pos + sslRead);
/*      */       }
/*      */     } else {
/*  662 */       int limit = dst.limit();
/*  663 */       int len = Math.min(maxEncryptedPacketLength0(), limit - pos);
/*  664 */       ByteBuf buf = this.alloc.directBuffer(len);
/*      */       try {
/*  666 */         sslRead = SSL.readFromSSL(this.ssl, OpenSsl.memoryAddress(buf), len);
/*  667 */         if (sslRead > 0) {
/*  668 */           dst.limit(pos + sslRead);
/*  669 */           buf.getBytes(buf.readerIndex(), dst);
/*  670 */           dst.limit(limit);
/*      */         } 
/*      */       } finally {
/*  673 */         buf.release();
/*      */       } 
/*      */     } 
/*      */     
/*  677 */     return sslRead;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final synchronized int maxWrapOverhead() {
/*  684 */     return this.maxWrapOverhead;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final synchronized int maxEncryptedPacketLength() {
/*  691 */     return maxEncryptedPacketLength0();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final int maxEncryptedPacketLength0() {
/*  699 */     return this.maxWrapOverhead + MAX_PLAINTEXT_LENGTH;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final int calculateMaxLengthForWrap(int plaintextLength, int numComponents) {
/*  708 */     return (int)Math.min(this.maxWrapBufferSize, plaintextLength + this.maxWrapOverhead * numComponents);
/*      */   }
/*      */   
/*      */   final synchronized int sslPending() {
/*  712 */     return sslPending0();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void calculateMaxWrapOverhead() {
/*  719 */     this.maxWrapOverhead = SSL.getMaxWrapOverhead(this.ssl);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  724 */     this.maxWrapBufferSize = this.jdkCompatibilityMode ? maxEncryptedPacketLength0() : (maxEncryptedPacketLength0() << 4);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int sslPending0() {
/*  732 */     return (this.handshakeState != HandshakeState.FINISHED) ? 0 : SSL.sslPending(this.ssl);
/*      */   }
/*      */   
/*      */   private boolean isBytesAvailableEnoughForWrap(int bytesAvailable, int plaintextLength, int numComponents) {
/*  736 */     return (bytesAvailable - this.maxWrapOverhead * numComponents >= plaintextLength);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final SSLEngineResult wrap(ByteBuffer[] srcs, int offset, int length, ByteBuffer dst) throws SSLException {
/*  743 */     ObjectUtil.checkNotNullWithIAE(srcs, "srcs");
/*  744 */     ObjectUtil.checkNotNullWithIAE(dst, "dst");
/*      */     
/*  746 */     if (offset >= srcs.length || offset + length > srcs.length) {
/*  747 */       throw new IndexOutOfBoundsException("offset: " + offset + ", length: " + length + " (expected: offset <= offset + length <= srcs.length (" + srcs.length + "))");
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  752 */     if (dst.isReadOnly()) {
/*  753 */       throw new ReadOnlyBufferException();
/*      */     }
/*      */     
/*  756 */     synchronized (this) {
/*  757 */       if (isOutboundDone())
/*      */       {
/*  759 */         return (isInboundDone() || isDestroyed()) ? CLOSED_NOT_HANDSHAKING : NEED_UNWRAP_CLOSED;
/*      */       }
/*      */       
/*  762 */       int bytesProduced = 0;
/*  763 */       ByteBuf bioReadCopyBuf = null;
/*      */       
/*      */       try {
/*  766 */         if (dst.isDirect()) {
/*  767 */           SSL.bioSetByteBuffer(this.networkBIO, bufferAddress(dst) + dst.position(), dst.remaining(), true);
/*      */         } else {
/*      */           
/*  770 */           bioReadCopyBuf = this.alloc.directBuffer(dst.remaining());
/*  771 */           SSL.bioSetByteBuffer(this.networkBIO, OpenSsl.memoryAddress(bioReadCopyBuf), bioReadCopyBuf.writableBytes(), true);
/*      */         } 
/*      */ 
/*      */         
/*  775 */         int bioLengthBefore = SSL.bioLengthByteBuffer(this.networkBIO);
/*      */ 
/*      */         
/*  778 */         if (this.outboundClosed) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  784 */           if (!isBytesAvailableEnoughForWrap(dst.remaining(), 2, 1)) {
/*  785 */             return new SSLEngineResult(SSLEngineResult.Status.BUFFER_OVERFLOW, getHandshakeStatus(), 0, 0);
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*  790 */           bytesProduced = SSL.bioFlushByteBuffer(this.networkBIO);
/*  791 */           if (bytesProduced <= 0) {
/*  792 */             return newResultMayFinishHandshake(SSLEngineResult.HandshakeStatus.NOT_HANDSHAKING, 0, 0);
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*  797 */           if (!doSSLShutdown()) {
/*  798 */             return newResultMayFinishHandshake(SSLEngineResult.HandshakeStatus.NOT_HANDSHAKING, 0, bytesProduced);
/*      */           }
/*  800 */           bytesProduced = bioLengthBefore - SSL.bioLengthByteBuffer(this.networkBIO);
/*  801 */           return newResultMayFinishHandshake(SSLEngineResult.HandshakeStatus.NEED_WRAP, 0, bytesProduced);
/*      */         } 
/*      */ 
/*      */         
/*  805 */         SSLEngineResult.HandshakeStatus status = SSLEngineResult.HandshakeStatus.NOT_HANDSHAKING;
/*  806 */         HandshakeState oldHandshakeState = this.handshakeState;
/*      */ 
/*      */         
/*  809 */         if (this.handshakeState != HandshakeState.FINISHED) {
/*  810 */           if (this.handshakeState != HandshakeState.STARTED_EXPLICITLY)
/*      */           {
/*  812 */             this.handshakeState = HandshakeState.STARTED_IMPLICITLY;
/*      */           }
/*      */ 
/*      */           
/*  816 */           bytesProduced = SSL.bioFlushByteBuffer(this.networkBIO);
/*      */           
/*  818 */           if (this.pendingException != null) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  830 */             if (bytesProduced > 0) {
/*  831 */               return newResult(SSLEngineResult.HandshakeStatus.NEED_WRAP, 0, bytesProduced);
/*      */             }
/*      */ 
/*      */ 
/*      */             
/*  836 */             return newResult(handshakeException(), 0, 0);
/*      */           } 
/*      */           
/*  839 */           status = handshake();
/*      */ 
/*      */ 
/*      */           
/*  843 */           bytesProduced = bioLengthBefore - SSL.bioLengthByteBuffer(this.networkBIO);
/*      */           
/*  845 */           if (status == SSLEngineResult.HandshakeStatus.NEED_TASK) {
/*  846 */             return newResult(status, 0, bytesProduced);
/*      */           }
/*      */           
/*  849 */           if (bytesProduced > 0)
/*      */           {
/*      */ 
/*      */             
/*  853 */             return newResult(mayFinishHandshake((status != SSLEngineResult.HandshakeStatus.FINISHED) ? ((bytesProduced == bioLengthBefore) ? SSLEngineResult.HandshakeStatus.NEED_WRAP : 
/*      */                   
/*  855 */                   getHandshakeStatus(SSL.bioLengthNonApplication(this.networkBIO))) : SSLEngineResult.HandshakeStatus.FINISHED), 0, bytesProduced);
/*      */           }
/*      */ 
/*      */           
/*  859 */           if (status == SSLEngineResult.HandshakeStatus.NEED_UNWRAP)
/*      */           {
/*  861 */             return isOutboundDone() ? NEED_UNWRAP_CLOSED : NEED_UNWRAP_OK;
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*  866 */           if (this.outboundClosed) {
/*  867 */             bytesProduced = SSL.bioFlushByteBuffer(this.networkBIO);
/*  868 */             return newResultMayFinishHandshake(status, 0, bytesProduced);
/*      */           } 
/*      */         } 
/*      */         
/*  872 */         int endOffset = offset + length;
/*  873 */         if (this.jdkCompatibilityMode || oldHandshakeState != HandshakeState.FINISHED) {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  878 */           int srcsLen = 0;
/*  879 */           for (int i = offset; i < endOffset; i++) {
/*  880 */             ByteBuffer src = srcs[i];
/*  881 */             if (src == null) {
/*  882 */               throw new IllegalArgumentException("srcs[" + i + "] is null");
/*      */             }
/*  884 */             if (srcsLen != MAX_PLAINTEXT_LENGTH) {
/*      */ 
/*      */ 
/*      */               
/*  888 */               srcsLen += src.remaining();
/*  889 */               if (srcsLen > MAX_PLAINTEXT_LENGTH || srcsLen < 0)
/*      */               {
/*      */ 
/*      */                 
/*  893 */                 srcsLen = MAX_PLAINTEXT_LENGTH;
/*      */               }
/*      */             } 
/*      */           } 
/*      */ 
/*      */           
/*  899 */           if (!isBytesAvailableEnoughForWrap(dst.remaining(), srcsLen, 1)) {
/*  900 */             return new SSLEngineResult(SSLEngineResult.Status.BUFFER_OVERFLOW, getHandshakeStatus(), 0, 0);
/*      */           }
/*      */         } 
/*      */ 
/*      */         
/*  905 */         int bytesConsumed = 0;
/*  906 */         assert bytesProduced == 0;
/*      */ 
/*      */         
/*  909 */         bytesProduced = SSL.bioFlushByteBuffer(this.networkBIO);
/*      */         
/*  911 */         if (bytesProduced > 0) {
/*  912 */           return newResultMayFinishHandshake(status, bytesConsumed, bytesProduced);
/*      */         }
/*      */ 
/*      */         
/*  916 */         if (this.pendingException != null) {
/*  917 */           Throwable error = this.pendingException;
/*  918 */           this.pendingException = null;
/*  919 */           shutdown();
/*      */ 
/*      */           
/*  922 */           throw new SSLException(error);
/*      */         } 
/*      */         
/*  925 */         for (; offset < endOffset; offset++) {
/*  926 */           ByteBuffer src = srcs[offset];
/*  927 */           int remaining = src.remaining();
/*  928 */           if (remaining != 0) {
/*      */             int bytesWritten;
/*      */ 
/*      */ 
/*      */             
/*  933 */             if (this.jdkCompatibilityMode) {
/*      */ 
/*      */ 
/*      */               
/*  937 */               bytesWritten = writePlaintextData(src, Math.min(remaining, MAX_PLAINTEXT_LENGTH - bytesConsumed));
/*      */             
/*      */             }
/*      */             else {
/*      */               
/*  942 */               int availableCapacityForWrap = dst.remaining() - bytesProduced - this.maxWrapOverhead;
/*  943 */               if (availableCapacityForWrap <= 0) {
/*  944 */                 return new SSLEngineResult(SSLEngineResult.Status.BUFFER_OVERFLOW, getHandshakeStatus(), bytesConsumed, bytesProduced);
/*      */               }
/*      */               
/*  947 */               bytesWritten = writePlaintextData(src, Math.min(remaining, availableCapacityForWrap));
/*      */             } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  955 */             int pendingNow = SSL.bioLengthByteBuffer(this.networkBIO);
/*  956 */             bytesProduced += bioLengthBefore - pendingNow;
/*  957 */             bioLengthBefore = pendingNow;
/*      */             
/*  959 */             if (bytesWritten > 0) {
/*  960 */               bytesConsumed += bytesWritten;
/*      */               
/*  962 */               if (this.jdkCompatibilityMode || bytesProduced == dst.remaining()) {
/*  963 */                 return newResultMayFinishHandshake(status, bytesConsumed, bytesProduced);
/*      */               }
/*      */             } else {
/*  966 */               int sslError = SSL.getError(this.ssl, bytesWritten);
/*  967 */               if (sslError == SSL.SSL_ERROR_ZERO_RETURN) {
/*      */                 
/*  969 */                 if (!this.receivedShutdown) {
/*  970 */                   closeAll();
/*      */                   
/*  972 */                   bytesProduced += bioLengthBefore - SSL.bioLengthByteBuffer(this.networkBIO);
/*      */ 
/*      */ 
/*      */ 
/*      */                   
/*  977 */                   SSLEngineResult.HandshakeStatus hs = mayFinishHandshake((status != SSLEngineResult.HandshakeStatus.FINISHED) ? (
/*  978 */                       (bytesProduced == dst.remaining()) ? SSLEngineResult.HandshakeStatus.NEED_WRAP : 
/*  979 */                       getHandshakeStatus(SSL.bioLengthNonApplication(this.networkBIO))) : SSLEngineResult.HandshakeStatus.FINISHED);
/*      */                   
/*  981 */                   return newResult(hs, bytesConsumed, bytesProduced);
/*      */                 } 
/*      */                 
/*  984 */                 return newResult(SSLEngineResult.HandshakeStatus.NOT_HANDSHAKING, bytesConsumed, bytesProduced);
/*  985 */               }  if (sslError == SSL.SSL_ERROR_WANT_READ)
/*      */               {
/*      */ 
/*      */                 
/*  989 */                 return newResult(SSLEngineResult.HandshakeStatus.NEED_UNWRAP, bytesConsumed, bytesProduced); } 
/*  990 */               if (sslError == SSL.SSL_ERROR_WANT_WRITE) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/* 1003 */                 if (bytesProduced > 0)
/*      */                 {
/*      */                   
/* 1006 */                   return newResult(SSLEngineResult.HandshakeStatus.NEED_WRAP, bytesConsumed, bytesProduced);
/*      */                 }
/* 1008 */                 return newResult(SSLEngineResult.Status.BUFFER_OVERFLOW, status, bytesConsumed, bytesProduced);
/* 1009 */               }  if (sslError == SSL.SSL_ERROR_WANT_X509_LOOKUP || sslError == SSL.SSL_ERROR_WANT_CERTIFICATE_VERIFY || sslError == SSL.SSL_ERROR_WANT_PRIVATE_KEY_OPERATION)
/*      */               {
/*      */ 
/*      */                 
/* 1013 */                 return newResult(SSLEngineResult.HandshakeStatus.NEED_TASK, bytesConsumed, bytesProduced);
/*      */               }
/*      */               
/* 1016 */               throw shutdownWithError("SSL_write", sslError);
/*      */             } 
/*      */           } 
/*      */         } 
/* 1020 */         return newResultMayFinishHandshake(status, bytesConsumed, bytesProduced);
/*      */       } finally {
/* 1022 */         SSL.bioClearByteBuffer(this.networkBIO);
/* 1023 */         if (bioReadCopyBuf == null) {
/* 1024 */           dst.position(dst.position() + bytesProduced);
/*      */         } else {
/* 1026 */           assert bioReadCopyBuf.readableBytes() <= dst.remaining() : "The destination buffer " + dst + " didn't have enough remaining space to hold the encrypted content in " + bioReadCopyBuf;
/*      */           
/* 1028 */           dst.put(bioReadCopyBuf.internalNioBuffer(bioReadCopyBuf.readerIndex(), bytesProduced));
/* 1029 */           bioReadCopyBuf.release();
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private SSLEngineResult newResult(SSLEngineResult.HandshakeStatus hs, int bytesConsumed, int bytesProduced) {
/* 1036 */     return newResult(SSLEngineResult.Status.OK, hs, bytesConsumed, bytesProduced);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private SSLEngineResult newResult(SSLEngineResult.Status status, SSLEngineResult.HandshakeStatus hs, int bytesConsumed, int bytesProduced) {
/* 1044 */     if (isOutboundDone()) {
/* 1045 */       if (isInboundDone()) {
/*      */         
/* 1047 */         hs = SSLEngineResult.HandshakeStatus.NOT_HANDSHAKING;
/*      */ 
/*      */         
/* 1050 */         shutdown();
/*      */       } 
/* 1052 */       return new SSLEngineResult(SSLEngineResult.Status.CLOSED, hs, bytesConsumed, bytesProduced);
/*      */     } 
/* 1054 */     if (hs == SSLEngineResult.HandshakeStatus.NEED_TASK)
/*      */     {
/* 1056 */       this.needTask = true;
/*      */     }
/* 1058 */     return new SSLEngineResult(status, hs, bytesConsumed, bytesProduced);
/*      */   }
/*      */ 
/*      */   
/*      */   private SSLEngineResult newResultMayFinishHandshake(SSLEngineResult.HandshakeStatus hs, int bytesConsumed, int bytesProduced) throws SSLException {
/* 1063 */     return newResult(mayFinishHandshake(hs, bytesConsumed, bytesProduced), bytesConsumed, bytesProduced);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private SSLEngineResult newResultMayFinishHandshake(SSLEngineResult.Status status, SSLEngineResult.HandshakeStatus hs, int bytesConsumed, int bytesProduced) throws SSLException {
/* 1069 */     return newResult(status, mayFinishHandshake(hs, bytesConsumed, bytesProduced), bytesConsumed, bytesProduced);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private SSLException shutdownWithError(String operations, int sslError) {
/* 1076 */     return shutdownWithError(operations, sslError, SSL.getLastErrorNumber());
/*      */   }
/*      */   
/*      */   private SSLException shutdownWithError(String operation, int sslError, int error) {
/* 1080 */     if (logger.isDebugEnabled()) {
/* 1081 */       String errorString = SSL.getErrorString(error);
/* 1082 */       logger.debug("{} failed with {}: OpenSSL error: {} {}", new Object[] { operation, 
/* 1083 */             Integer.valueOf(sslError), Integer.valueOf(error), errorString });
/*      */     } 
/*      */ 
/*      */     
/* 1087 */     shutdown();
/*      */     
/* 1089 */     SSLException exception = newSSLExceptionForError(error);
/*      */     
/* 1091 */     if (this.pendingException != null) {
/* 1092 */       exception.initCause(this.pendingException);
/* 1093 */       this.pendingException = null;
/*      */     } 
/* 1095 */     return exception;
/*      */   }
/*      */ 
/*      */   
/*      */   private SSLEngineResult handleUnwrapException(int bytesConsumed, int bytesProduced, SSLException e) throws SSLException {
/* 1100 */     int lastError = SSL.getLastErrorNumber();
/* 1101 */     if (lastError != 0) {
/* 1102 */       return sslReadErrorResult(SSL.SSL_ERROR_SSL, lastError, bytesConsumed, bytesProduced);
/*      */     }
/*      */     
/* 1105 */     throw e;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final SSLEngineResult unwrap(ByteBuffer[] srcs, int srcsOffset, int srcsLength, ByteBuffer[] dsts, int dstsOffset, int dstsLength) throws SSLException {
/* 1113 */     ObjectUtil.checkNotNullWithIAE(srcs, "srcs");
/* 1114 */     if (srcsOffset >= srcs.length || srcsOffset + srcsLength > srcs.length)
/*      */     {
/* 1116 */       throw new IndexOutOfBoundsException("offset: " + srcsOffset + ", length: " + srcsLength + " (expected: offset <= offset + length <= srcs.length (" + srcs.length + "))");
/*      */     }
/*      */ 
/*      */     
/* 1120 */     ObjectUtil.checkNotNullWithIAE(dsts, "dsts");
/* 1121 */     if (dstsOffset >= dsts.length || dstsOffset + dstsLength > dsts.length) {
/* 1122 */       throw new IndexOutOfBoundsException("offset: " + dstsOffset + ", length: " + dstsLength + " (expected: offset <= offset + length <= dsts.length (" + dsts.length + "))");
/*      */     }
/*      */ 
/*      */     
/* 1126 */     long capacity = 0L;
/* 1127 */     int dstsEndOffset = dstsOffset + dstsLength;
/* 1128 */     for (int i = dstsOffset; i < dstsEndOffset; i++) {
/* 1129 */       ByteBuffer dst = (ByteBuffer)ObjectUtil.checkNotNullArrayParam(dsts[i], i, "dsts");
/* 1130 */       if (dst.isReadOnly()) {
/* 1131 */         throw new ReadOnlyBufferException();
/*      */       }
/* 1133 */       capacity += dst.remaining();
/*      */     } 
/*      */     
/* 1136 */     int srcsEndOffset = srcsOffset + srcsLength;
/* 1137 */     long len = 0L;
/* 1138 */     for (int j = srcsOffset; j < srcsEndOffset; j++) {
/* 1139 */       ByteBuffer src = (ByteBuffer)ObjectUtil.checkNotNullArrayParam(srcs[j], j, "srcs");
/* 1140 */       len += src.remaining();
/*      */     } 
/*      */     
/* 1143 */     synchronized (this) {
/* 1144 */       int packetLength; if (isInboundDone()) {
/* 1145 */         return (isOutboundDone() || isDestroyed()) ? CLOSED_NOT_HANDSHAKING : NEED_WRAP_CLOSED;
/*      */       }
/*      */       
/* 1148 */       SSLEngineResult.HandshakeStatus status = SSLEngineResult.HandshakeStatus.NOT_HANDSHAKING;
/* 1149 */       HandshakeState oldHandshakeState = this.handshakeState;
/*      */       
/* 1151 */       if (this.handshakeState != HandshakeState.FINISHED) {
/* 1152 */         if (this.handshakeState != HandshakeState.STARTED_EXPLICITLY)
/*      */         {
/* 1154 */           this.handshakeState = HandshakeState.STARTED_IMPLICITLY;
/*      */         }
/*      */         
/* 1157 */         status = handshake();
/*      */         
/* 1159 */         if (status == SSLEngineResult.HandshakeStatus.NEED_TASK) {
/* 1160 */           return newResult(status, 0, 0);
/*      */         }
/*      */         
/* 1163 */         if (status == SSLEngineResult.HandshakeStatus.NEED_WRAP) {
/* 1164 */           return NEED_WRAP_OK;
/*      */         }
/*      */         
/* 1167 */         if (this.isInboundDone) {
/* 1168 */           return NEED_WRAP_CLOSED;
/*      */         }
/*      */       } 
/*      */       
/* 1172 */       int sslPending = sslPending0();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1178 */       if (this.jdkCompatibilityMode || oldHandshakeState != HandshakeState.FINISHED) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1183 */         if (len < 5L) {
/* 1184 */           return newResultMayFinishHandshake(SSLEngineResult.Status.BUFFER_UNDERFLOW, status, 0, 0);
/*      */         }
/*      */         
/* 1187 */         packetLength = SslUtils.getEncryptedPacketLength(srcs, srcsOffset);
/* 1188 */         if (packetLength == -2) {
/* 1189 */           throw new NotSslRecordException("not an SSL/TLS record");
/*      */         }
/*      */         
/* 1192 */         int packetLengthDataOnly = packetLength - 5;
/* 1193 */         if (packetLengthDataOnly > capacity) {
/*      */ 
/*      */           
/* 1196 */           if (packetLengthDataOnly > MAX_RECORD_SIZE)
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1202 */             throw new SSLException("Illegal packet length: " + packetLengthDataOnly + " > " + this.session
/* 1203 */                 .getApplicationBufferSize());
/*      */           }
/* 1205 */           this.session.tryExpandApplicationBufferSize(packetLengthDataOnly);
/*      */           
/* 1207 */           return newResultMayFinishHandshake(SSLEngineResult.Status.BUFFER_OVERFLOW, status, 0, 0);
/*      */         } 
/*      */         
/* 1210 */         if (len < packetLength)
/*      */         {
/*      */           
/* 1213 */           return newResultMayFinishHandshake(SSLEngineResult.Status.BUFFER_UNDERFLOW, status, 0, 0); } 
/*      */       } else {
/* 1215 */         if (len == 0L && sslPending <= 0)
/* 1216 */           return newResultMayFinishHandshake(SSLEngineResult.Status.BUFFER_UNDERFLOW, status, 0, 0); 
/* 1217 */         if (capacity == 0L) {
/* 1218 */           return newResultMayFinishHandshake(SSLEngineResult.Status.BUFFER_OVERFLOW, status, 0, 0);
/*      */         }
/* 1220 */         packetLength = (int)Math.min(2147483647L, len);
/*      */       } 
/*      */ 
/*      */       
/* 1224 */       assert srcsOffset < srcsEndOffset;
/*      */ 
/*      */       
/* 1227 */       assert capacity > 0L;
/*      */ 
/*      */       
/* 1230 */       int bytesProduced = 0;
/* 1231 */       int bytesConsumed = 0; try {
/*      */         while (true) {
/*      */           ByteBuf bioWriteCopyBuf;
/*      */           int pendingEncryptedBytes;
/* 1235 */           ByteBuffer src = srcs[srcsOffset];
/* 1236 */           int remaining = src.remaining();
/*      */ 
/*      */           
/* 1239 */           if (remaining == 0) {
/* 1240 */             if (sslPending <= 0) {
/*      */ 
/*      */               
/* 1243 */               if (++srcsOffset >= srcsEndOffset) {
/*      */                 break;
/*      */               }
/*      */               continue;
/*      */             } 
/* 1248 */             bioWriteCopyBuf = null;
/* 1249 */             pendingEncryptedBytes = SSL.bioLengthByteBuffer(this.networkBIO);
/*      */           
/*      */           }
/*      */           else {
/*      */             
/* 1254 */             pendingEncryptedBytes = Math.min(packetLength, remaining);
/*      */             try {
/* 1256 */               bioWriteCopyBuf = writeEncryptedData(src, pendingEncryptedBytes);
/* 1257 */             } catch (SSLException e) {
/*      */               
/* 1259 */               return handleUnwrapException(bytesConsumed, bytesProduced, e);
/*      */             } 
/*      */           } 
/*      */           while (true) {
/*      */             int bytesRead;
/* 1264 */             ByteBuffer dst = dsts[dstsOffset];
/* 1265 */             if (!dst.hasRemaining())
/*      */             
/* 1267 */             { if (++dstsOffset >= dstsEndOffset)
/*      */               
/*      */               { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/* 1335 */                 if (bioWriteCopyBuf != null)
/* 1336 */                   bioWriteCopyBuf.release();  break; }  continue; }  try { bytesRead = readPlaintextData(dst); } catch (SSLException e) { SSLEngineResult sSLEngineResult1 = handleUnwrapException(bytesConsumed, bytesProduced, e); if (bioWriteCopyBuf != null) bioWriteCopyBuf.release();  return sSLEngineResult1; }  int localBytesConsumed = pendingEncryptedBytes - SSL.bioLengthByteBuffer(this.networkBIO); bytesConsumed += localBytesConsumed; packetLength -= localBytesConsumed; pendingEncryptedBytes -= localBytesConsumed; src.position(src.position() + localBytesConsumed); if (bytesRead > 0) { bytesProduced += bytesRead; if (!dst.hasRemaining()) { sslPending = sslPending0(); if (++dstsOffset >= dstsEndOffset) { SSLEngineResult sSLEngineResult1 = (sslPending > 0) ? newResult(SSLEngineResult.Status.BUFFER_OVERFLOW, status, bytesConsumed, bytesProduced) : newResultMayFinishHandshake(isInboundDone() ? SSLEngineResult.Status.CLOSED : SSLEngineResult.Status.OK, status, bytesConsumed, bytesProduced); if (bioWriteCopyBuf != null) bioWriteCopyBuf.release();  return sSLEngineResult1; }  continue; }  if (packetLength == 0 || this.jdkCompatibilityMode) { if (bioWriteCopyBuf != null) bioWriteCopyBuf.release();  break; }  continue; }  int sslError = SSL.getError(this.ssl, bytesRead); if (sslError == SSL.SSL_ERROR_WANT_READ || sslError == SSL.SSL_ERROR_WANT_WRITE) { if (++srcsOffset >= srcsEndOffset) { if (bioWriteCopyBuf != null) bioWriteCopyBuf.release();  break; }  if (bioWriteCopyBuf != null) bioWriteCopyBuf.release();  continue; }  if (sslError == SSL.SSL_ERROR_ZERO_RETURN) { if (!this.receivedShutdown) closeAll();  SSLEngineResult sSLEngineResult1 = newResultMayFinishHandshake(isInboundDone() ? SSLEngineResult.Status.CLOSED : SSLEngineResult.Status.OK, status, bytesConsumed, bytesProduced); if (bioWriteCopyBuf != null) bioWriteCopyBuf.release();  return sSLEngineResult1; }  if (sslError == SSL.SSL_ERROR_WANT_X509_LOOKUP || sslError == SSL.SSL_ERROR_WANT_CERTIFICATE_VERIFY || sslError == SSL.SSL_ERROR_WANT_PRIVATE_KEY_OPERATION) { SSLEngineResult sSLEngineResult1 = newResult(isInboundDone() ? SSLEngineResult.Status.CLOSED : SSLEngineResult.Status.OK, SSLEngineResult.HandshakeStatus.NEED_TASK, bytesConsumed, bytesProduced); if (bioWriteCopyBuf != null) bioWriteCopyBuf.release();  return sSLEngineResult1; }  SSLEngineResult sSLEngineResult = sslReadErrorResult(sslError, SSL.getLastErrorNumber(), bytesConsumed, bytesProduced); if (bioWriteCopyBuf != null) bioWriteCopyBuf.release();  return sSLEngineResult;
/*      */           } 
/*      */           break;
/*      */         } 
/*      */       } finally {
/* 1341 */         SSL.bioClearByteBuffer(this.networkBIO);
/* 1342 */         rejectRemoteInitiatedRenegotiation();
/*      */       } 
/*      */ 
/*      */       
/* 1346 */       if (!this.receivedShutdown && (SSL.getShutdown(this.ssl) & SSL.SSL_RECEIVED_SHUTDOWN) == SSL.SSL_RECEIVED_SHUTDOWN) {
/* 1347 */         closeAll();
/*      */       }
/*      */       
/* 1350 */       return newResultMayFinishHandshake(isInboundDone() ? SSLEngineResult.Status.CLOSED : SSLEngineResult.Status.OK, status, bytesConsumed, bytesProduced);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean needWrapAgain(int stackError) {
/* 1359 */     if (SSL.bioLengthNonApplication(this.networkBIO) > 0) {
/*      */ 
/*      */       
/* 1362 */       if (this.pendingException == null) {
/* 1363 */         this.pendingException = newSSLExceptionForError(stackError);
/* 1364 */       } else if (shouldAddSuppressed(this.pendingException, stackError)) {
/* 1365 */         ThrowableUtil.addSuppressed(this.pendingException, newSSLExceptionForError(stackError));
/*      */       } 
/*      */ 
/*      */       
/* 1369 */       SSL.clearError();
/* 1370 */       return true;
/*      */     } 
/* 1372 */     return false;
/*      */   }
/*      */   
/*      */   private SSLException newSSLExceptionForError(int stackError) {
/* 1376 */     String message = SSL.getErrorString(stackError);
/* 1377 */     return (this.handshakeState == HandshakeState.FINISHED) ? new OpenSslException(message, stackError) : new OpenSslHandshakeException(message, stackError);
/*      */   }
/*      */ 
/*      */   
/*      */   private static boolean shouldAddSuppressed(Throwable target, int errorCode) {
/* 1382 */     for (Throwable suppressed : ThrowableUtil.getSuppressed(target)) {
/* 1383 */       if (suppressed instanceof NativeSslException && ((NativeSslException)suppressed)
/* 1384 */         .errorCode() == errorCode)
/*      */       {
/* 1386 */         return false;
/*      */       }
/*      */     } 
/* 1389 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   private SSLEngineResult sslReadErrorResult(int error, int stackError, int bytesConsumed, int bytesProduced) throws SSLException {
/* 1394 */     if (needWrapAgain(stackError))
/*      */     {
/*      */       
/* 1397 */       return new SSLEngineResult(SSLEngineResult.Status.OK, SSLEngineResult.HandshakeStatus.NEED_WRAP, bytesConsumed, bytesProduced);
/*      */     }
/* 1399 */     throw shutdownWithError("SSL_read", error, stackError);
/*      */   }
/*      */   
/*      */   private void closeAll() throws SSLException {
/* 1403 */     this.receivedShutdown = true;
/* 1404 */     closeOutbound();
/* 1405 */     closeInbound();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void rejectRemoteInitiatedRenegotiation() throws SSLHandshakeException {
/* 1412 */     if (!isDestroyed() && ((!this.clientMode && SSL.getHandshakeCount(this.ssl) > 1) || (this.clientMode && 
/*      */       
/* 1414 */       SSL.getHandshakeCount(this.ssl) > 2)) && 
/*      */ 
/*      */       
/* 1417 */       !"TLSv1.3".equals(this.session.getProtocol()) && this.handshakeState == HandshakeState.FINISHED) {
/*      */ 
/*      */       
/* 1420 */       shutdown();
/* 1421 */       throw new SSLHandshakeException("remote-initiated renegotiation not allowed");
/*      */     } 
/*      */   }
/*      */   
/*      */   public final SSLEngineResult unwrap(ByteBuffer[] srcs, ByteBuffer[] dsts) throws SSLException {
/* 1426 */     return unwrap(srcs, 0, srcs.length, dsts, 0, dsts.length);
/*      */   }
/*      */   
/*      */   private ByteBuffer[] singleSrcBuffer(ByteBuffer src) {
/* 1430 */     this.singleSrcBuffer[0] = src;
/* 1431 */     return this.singleSrcBuffer;
/*      */   }
/*      */   
/*      */   private void resetSingleSrcBuffer() {
/* 1435 */     this.singleSrcBuffer[0] = null;
/*      */   }
/*      */   
/*      */   private ByteBuffer[] singleDstBuffer(ByteBuffer src) {
/* 1439 */     this.singleDstBuffer[0] = src;
/* 1440 */     return this.singleDstBuffer;
/*      */   }
/*      */   
/*      */   private void resetSingleDstBuffer() {
/* 1444 */     this.singleDstBuffer[0] = null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final synchronized SSLEngineResult unwrap(ByteBuffer src, ByteBuffer[] dsts, int offset, int length) throws SSLException {
/*      */     try {
/* 1451 */       return unwrap(singleSrcBuffer(src), 0, 1, dsts, offset, length);
/*      */     } finally {
/* 1453 */       resetSingleSrcBuffer();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public final synchronized SSLEngineResult wrap(ByteBuffer src, ByteBuffer dst) throws SSLException {
/*      */     try {
/* 1460 */       return wrap(singleSrcBuffer(src), dst);
/*      */     } finally {
/* 1462 */       resetSingleSrcBuffer();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public final synchronized SSLEngineResult unwrap(ByteBuffer src, ByteBuffer dst) throws SSLException {
/*      */     try {
/* 1469 */       return unwrap(singleSrcBuffer(src), singleDstBuffer(dst));
/*      */     } finally {
/* 1471 */       resetSingleSrcBuffer();
/* 1472 */       resetSingleDstBuffer();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public final synchronized SSLEngineResult unwrap(ByteBuffer src, ByteBuffer[] dsts) throws SSLException {
/*      */     try {
/* 1479 */       return unwrap(singleSrcBuffer(src), dsts);
/*      */     } finally {
/* 1481 */       resetSingleSrcBuffer();
/*      */     } 
/*      */   }
/*      */   
/*      */   private class TaskDecorator<R extends Runnable> implements Runnable { protected final R task;
/*      */     
/*      */     TaskDecorator(R task) {
/* 1488 */       this.task = task;
/*      */     }
/*      */ 
/*      */     
/*      */     public void run() {
/* 1493 */       ReferenceCountedOpenSslEngine.this.runAndResetNeedTask((Runnable)this.task);
/*      */     } }
/*      */ 
/*      */   
/*      */   private final class AsyncTaskDecorator extends TaskDecorator<AsyncTask> implements AsyncRunnable {
/*      */     AsyncTaskDecorator(AsyncTask task) {
/* 1499 */       super(task);
/*      */     }
/*      */ 
/*      */     
/*      */     public void run(Runnable runnable) {
/* 1504 */       if (ReferenceCountedOpenSslEngine.this.isDestroyed()) {
/*      */         return;
/*      */       }
/*      */       
/* 1508 */       this.task.runAsync(new ReferenceCountedOpenSslEngine.TaskDecorator<Runnable>(runnable));
/*      */     }
/*      */   }
/*      */   
/*      */   private synchronized void runAndResetNeedTask(Runnable task) {
/*      */     try {
/* 1514 */       if (isDestroyed()) {
/*      */         return;
/*      */       }
/*      */       
/* 1518 */       task.run();
/*      */     } finally {
/*      */       
/* 1521 */       this.needTask = false;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public final synchronized Runnable getDelegatedTask() {
/* 1527 */     if (isDestroyed()) {
/* 1528 */       return null;
/*      */     }
/* 1530 */     Runnable task = SSL.getTask(this.ssl);
/* 1531 */     if (task == null) {
/* 1532 */       return null;
/*      */     }
/* 1534 */     if (task instanceof AsyncTask) {
/* 1535 */       return new AsyncTaskDecorator((AsyncTask)task);
/*      */     }
/* 1537 */     return new TaskDecorator<Runnable>(task);
/*      */   }
/*      */ 
/*      */   
/*      */   public final synchronized void closeInbound() throws SSLException {
/* 1542 */     if (this.isInboundDone) {
/*      */       return;
/*      */     }
/*      */     
/* 1546 */     this.isInboundDone = true;
/*      */     
/* 1548 */     if (isOutboundDone())
/*      */     {
/*      */       
/* 1551 */       shutdown();
/*      */     }
/*      */     
/* 1554 */     if (this.handshakeState != HandshakeState.NOT_STARTED && !this.receivedShutdown) {
/* 1555 */       throw new SSLException("Inbound closed before receiving peer's close_notify: possible truncation attack?");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final synchronized boolean isInboundDone() {
/* 1562 */     return this.isInboundDone;
/*      */   }
/*      */ 
/*      */   
/*      */   public final synchronized void closeOutbound() {
/* 1567 */     if (this.outboundClosed) {
/*      */       return;
/*      */     }
/*      */     
/* 1571 */     this.outboundClosed = true;
/*      */     
/* 1573 */     if (this.handshakeState != HandshakeState.NOT_STARTED && !isDestroyed()) {
/* 1574 */       int mode = SSL.getShutdown(this.ssl);
/* 1575 */       if ((mode & SSL.SSL_SENT_SHUTDOWN) != SSL.SSL_SENT_SHUTDOWN) {
/* 1576 */         doSSLShutdown();
/*      */       }
/*      */     } else {
/*      */       
/* 1580 */       shutdown();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean doSSLShutdown() {
/* 1589 */     if (SSL.isInInit(this.ssl) != 0)
/*      */     {
/*      */ 
/*      */ 
/*      */       
/* 1594 */       return false;
/*      */     }
/* 1596 */     int err = SSL.shutdownSSL(this.ssl);
/* 1597 */     if (err < 0) {
/* 1598 */       int sslErr = SSL.getError(this.ssl, err);
/* 1599 */       if (sslErr == SSL.SSL_ERROR_SYSCALL || sslErr == SSL.SSL_ERROR_SSL) {
/* 1600 */         if (logger.isDebugEnabled()) {
/* 1601 */           int error = SSL.getLastErrorNumber();
/* 1602 */           logger.debug("SSL_shutdown failed: OpenSSL error: {} {}", Integer.valueOf(error), SSL.getErrorString(error));
/*      */         } 
/*      */         
/* 1605 */         shutdown();
/* 1606 */         return false;
/*      */       } 
/* 1608 */       SSL.clearError();
/*      */     } 
/* 1610 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final synchronized boolean isOutboundDone() {
/* 1617 */     return (this.outboundClosed && (this.networkBIO == 0L || SSL.bioLengthNonApplication(this.networkBIO) == 0));
/*      */   }
/*      */ 
/*      */   
/*      */   public final String[] getSupportedCipherSuites() {
/* 1622 */     return OpenSsl.AVAILABLE_CIPHER_SUITES.<String>toArray(new String[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final String[] getEnabledCipherSuites() {
/*      */     String[] extraCiphers, enabled;
/*      */     boolean tls13Enabled;
/* 1630 */     synchronized (this) {
/* 1631 */       if (!isDestroyed()) {
/* 1632 */         enabled = SSL.getCiphers(this.ssl);
/* 1633 */         int opts = SSL.getOptions(this.ssl);
/* 1634 */         if (isProtocolEnabled(opts, SSL.SSL_OP_NO_TLSv1_3, "TLSv1.3")) {
/* 1635 */           extraCiphers = OpenSsl.EXTRA_SUPPORTED_TLS_1_3_CIPHERS;
/* 1636 */           tls13Enabled = true;
/*      */         } else {
/* 1638 */           extraCiphers = EmptyArrays.EMPTY_STRINGS;
/* 1639 */           tls13Enabled = false;
/*      */         } 
/*      */       } else {
/* 1642 */         return EmptyArrays.EMPTY_STRINGS;
/*      */       } 
/*      */     } 
/* 1645 */     if (enabled == null) {
/* 1646 */       return EmptyArrays.EMPTY_STRINGS;
/*      */     }
/* 1648 */     Set<String> enabledSet = new LinkedHashSet<String>(enabled.length + extraCiphers.length);
/* 1649 */     synchronized (this) {
/* 1650 */       for (int i = 0; i < enabled.length; i++) {
/* 1651 */         String mapped = toJavaCipherSuite(enabled[i]);
/* 1652 */         String cipher = (mapped == null) ? enabled[i] : mapped;
/* 1653 */         if ((tls13Enabled && OpenSsl.isTlsv13Supported()) || !SslUtils.isTLSv13Cipher(cipher))
/*      */         {
/*      */           
/* 1656 */           enabledSet.add(cipher); } 
/*      */       } 
/* 1658 */       Collections.addAll(enabledSet, extraCiphers);
/*      */     } 
/* 1660 */     return enabledSet.<String>toArray(new String[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setEnabledCipherSuites(String[] cipherSuites) {
/* 1666 */     ObjectUtil.checkNotNull(cipherSuites, "cipherSuites");
/*      */     
/* 1668 */     StringBuilder buf = new StringBuilder();
/* 1669 */     StringBuilder bufTLSv13 = new StringBuilder();
/*      */     
/* 1671 */     CipherSuiteConverter.convertToCipherStrings(Arrays.asList(cipherSuites), buf, bufTLSv13, OpenSsl.isBoringSSL());
/* 1672 */     String cipherSuiteSpec = buf.toString();
/* 1673 */     String cipherSuiteSpecTLSv13 = bufTLSv13.toString();
/*      */     
/* 1675 */     if (!OpenSsl.isTlsv13Supported() && !cipherSuiteSpecTLSv13.isEmpty()) {
/* 1676 */       throw new IllegalArgumentException("TLSv1.3 is not supported by this java version.");
/*      */     }
/* 1678 */     synchronized (this) {
/* 1679 */       if (!isDestroyed()) {
/*      */         
/*      */         try {
/* 1682 */           SSL.setCipherSuites(this.ssl, cipherSuiteSpec, false);
/* 1683 */           if (OpenSsl.isTlsv13Supported())
/*      */           {
/* 1685 */             SSL.setCipherSuites(this.ssl, OpenSsl.checkTls13Ciphers(logger, cipherSuiteSpecTLSv13), true);
/*      */           }
/*      */ 
/*      */ 
/*      */           
/* 1690 */           Set<String> protocols = new HashSet<String>(this.explicitlyEnabledProtocols.length);
/* 1691 */           Collections.addAll(protocols, this.explicitlyEnabledProtocols);
/*      */ 
/*      */ 
/*      */           
/* 1695 */           if (cipherSuiteSpec.isEmpty()) {
/* 1696 */             protocols.remove("TLSv1");
/* 1697 */             protocols.remove("TLSv1.1");
/* 1698 */             protocols.remove("TLSv1.2");
/* 1699 */             protocols.remove("SSLv3");
/* 1700 */             protocols.remove("SSLv2");
/* 1701 */             protocols.remove("SSLv2Hello");
/*      */           } 
/*      */           
/* 1704 */           if (cipherSuiteSpecTLSv13.isEmpty()) {
/* 1705 */             protocols.remove("TLSv1.3");
/*      */           }
/*      */ 
/*      */           
/* 1709 */           setEnabledProtocols0(protocols.<String>toArray(EmptyArrays.EMPTY_STRINGS), false);
/* 1710 */         } catch (Exception e) {
/* 1711 */           throw new IllegalStateException("failed to enable cipher suites: " + cipherSuiteSpec, e);
/*      */         } 
/*      */       } else {
/* 1714 */         throw new IllegalStateException("failed to enable cipher suites: " + cipherSuiteSpec);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public final String[] getSupportedProtocols() {
/* 1721 */     return OpenSsl.SUPPORTED_PROTOCOLS_SET.<String>toArray(new String[0]);
/*      */   }
/*      */   
/*      */   public final String[] getEnabledProtocols() {
/*      */     int opts;
/* 1726 */     List<String> enabled = new ArrayList<String>(6);
/*      */     
/* 1728 */     enabled.add("SSLv2Hello");
/*      */ 
/*      */     
/* 1731 */     synchronized (this) {
/* 1732 */       if (!isDestroyed()) {
/* 1733 */         opts = SSL.getOptions(this.ssl);
/*      */       } else {
/* 1735 */         return enabled.<String>toArray(new String[0]);
/*      */       } 
/*      */     } 
/* 1738 */     if (isProtocolEnabled(opts, SSL.SSL_OP_NO_TLSv1, "TLSv1")) {
/* 1739 */       enabled.add("TLSv1");
/*      */     }
/* 1741 */     if (isProtocolEnabled(opts, SSL.SSL_OP_NO_TLSv1_1, "TLSv1.1")) {
/* 1742 */       enabled.add("TLSv1.1");
/*      */     }
/* 1744 */     if (isProtocolEnabled(opts, SSL.SSL_OP_NO_TLSv1_2, "TLSv1.2")) {
/* 1745 */       enabled.add("TLSv1.2");
/*      */     }
/* 1747 */     if (isProtocolEnabled(opts, SSL.SSL_OP_NO_TLSv1_3, "TLSv1.3")) {
/* 1748 */       enabled.add("TLSv1.3");
/*      */     }
/* 1750 */     if (isProtocolEnabled(opts, SSL.SSL_OP_NO_SSLv2, "SSLv2")) {
/* 1751 */       enabled.add("SSLv2");
/*      */     }
/* 1753 */     if (isProtocolEnabled(opts, SSL.SSL_OP_NO_SSLv3, "SSLv3")) {
/* 1754 */       enabled.add("SSLv3");
/*      */     }
/* 1756 */     return enabled.<String>toArray(new String[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean isProtocolEnabled(int opts, int disableMask, String protocolString) {
/* 1762 */     return ((opts & disableMask) == 0 && OpenSsl.SUPPORTED_PROTOCOLS_SET.contains(protocolString));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setEnabledProtocols(String[] protocols) {
/* 1776 */     setEnabledProtocols0(protocols, true);
/*      */   }
/*      */ 
/*      */   
/*      */   private void setEnabledProtocols0(String[] protocols, boolean cache) {
/* 1781 */     ObjectUtil.checkNotNullWithIAE(protocols, "protocols");
/* 1782 */     int minProtocolIndex = OPENSSL_OP_NO_PROTOCOLS.length;
/* 1783 */     int maxProtocolIndex = 0;
/* 1784 */     for (String p : protocols) {
/* 1785 */       if (!OpenSsl.SUPPORTED_PROTOCOLS_SET.contains(p)) {
/* 1786 */         throw new IllegalArgumentException("Protocol " + p + " is not supported.");
/*      */       }
/* 1788 */       if (p.equals("SSLv2")) {
/* 1789 */         if (minProtocolIndex > 0) {
/* 1790 */           minProtocolIndex = 0;
/*      */         }
/* 1792 */         if (maxProtocolIndex < 0) {
/* 1793 */           maxProtocolIndex = 0;
/*      */         }
/* 1795 */       } else if (p.equals("SSLv3")) {
/* 1796 */         if (minProtocolIndex > 1) {
/* 1797 */           minProtocolIndex = 1;
/*      */         }
/* 1799 */         if (maxProtocolIndex < 1) {
/* 1800 */           maxProtocolIndex = 1;
/*      */         }
/* 1802 */       } else if (p.equals("TLSv1")) {
/* 1803 */         if (minProtocolIndex > 2) {
/* 1804 */           minProtocolIndex = 2;
/*      */         }
/* 1806 */         if (maxProtocolIndex < 2) {
/* 1807 */           maxProtocolIndex = 2;
/*      */         }
/* 1809 */       } else if (p.equals("TLSv1.1")) {
/* 1810 */         if (minProtocolIndex > 3) {
/* 1811 */           minProtocolIndex = 3;
/*      */         }
/* 1813 */         if (maxProtocolIndex < 3) {
/* 1814 */           maxProtocolIndex = 3;
/*      */         }
/* 1816 */       } else if (p.equals("TLSv1.2")) {
/* 1817 */         if (minProtocolIndex > 4) {
/* 1818 */           minProtocolIndex = 4;
/*      */         }
/* 1820 */         if (maxProtocolIndex < 4) {
/* 1821 */           maxProtocolIndex = 4;
/*      */         }
/* 1823 */       } else if (p.equals("TLSv1.3")) {
/* 1824 */         if (minProtocolIndex > 5) {
/* 1825 */           minProtocolIndex = 5;
/*      */         }
/* 1827 */         if (maxProtocolIndex < 5) {
/* 1828 */           maxProtocolIndex = 5;
/*      */         }
/*      */       } 
/*      */     } 
/* 1832 */     synchronized (this) {
/* 1833 */       if (cache) {
/* 1834 */         this.explicitlyEnabledProtocols = protocols;
/*      */       }
/* 1836 */       if (!isDestroyed()) {
/*      */         
/* 1838 */         SSL.clearOptions(this.ssl, SSL.SSL_OP_NO_SSLv2 | SSL.SSL_OP_NO_SSLv3 | SSL.SSL_OP_NO_TLSv1 | SSL.SSL_OP_NO_TLSv1_1 | SSL.SSL_OP_NO_TLSv1_2 | SSL.SSL_OP_NO_TLSv1_3);
/*      */ 
/*      */         
/* 1841 */         int opts = 0; int i;
/* 1842 */         for (i = 0; i < minProtocolIndex; i++) {
/* 1843 */           opts |= OPENSSL_OP_NO_PROTOCOLS[i];
/*      */         }
/* 1845 */         assert maxProtocolIndex != Integer.MAX_VALUE;
/* 1846 */         for (i = maxProtocolIndex + 1; i < OPENSSL_OP_NO_PROTOCOLS.length; i++) {
/* 1847 */           opts |= OPENSSL_OP_NO_PROTOCOLS[i];
/*      */         }
/*      */ 
/*      */         
/* 1851 */         SSL.setOptions(this.ssl, opts);
/*      */       } else {
/* 1853 */         throw new IllegalStateException("failed to enable protocols: " + Arrays.asList(protocols));
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public final SSLSession getSession() {
/* 1860 */     return this.session;
/*      */   }
/*      */ 
/*      */   
/*      */   public final synchronized void beginHandshake() throws SSLException {
/* 1865 */     switch (this.handshakeState) {
/*      */       case NPN:
/* 1867 */         checkEngineClosed();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1875 */         this.handshakeState = HandshakeState.STARTED_EXPLICITLY;
/* 1876 */         calculateMaxWrapOverhead();
/*      */ 
/*      */       
/*      */       case NPN_AND_ALPN:
/*      */         return;
/*      */       
/*      */       case ALPN:
/* 1883 */         throw new SSLException("renegotiation unsupported");
/*      */       case NONE:
/* 1885 */         this.handshakeState = HandshakeState.STARTED_EXPLICITLY;
/* 1886 */         if (handshake() == SSLEngineResult.HandshakeStatus.NEED_TASK)
/*      */         {
/* 1888 */           this.needTask = true;
/*      */         }
/* 1890 */         calculateMaxWrapOverhead();
/*      */     } 
/*      */     
/* 1893 */     throw new Error();
/*      */   }
/*      */ 
/*      */   
/*      */   private void checkEngineClosed() throws SSLException {
/* 1898 */     if (isDestroyed()) {
/* 1899 */       throw new SSLException("engine closed");
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private static SSLEngineResult.HandshakeStatus pendingStatus(int pendingStatus) {
/* 1905 */     return (pendingStatus > 0) ? SSLEngineResult.HandshakeStatus.NEED_WRAP : SSLEngineResult.HandshakeStatus.NEED_UNWRAP;
/*      */   }
/*      */   
/*      */   private static boolean isEmpty(Object[] arr) {
/* 1909 */     return (arr == null || arr.length == 0);
/*      */   }
/*      */   
/*      */   private static boolean isEmpty(byte[] cert) {
/* 1913 */     return (cert == null || cert.length == 0);
/*      */   }
/*      */   
/*      */   private SSLEngineResult.HandshakeStatus handshakeException() throws SSLException {
/* 1917 */     if (SSL.bioLengthNonApplication(this.networkBIO) > 0)
/*      */     {
/* 1919 */       return SSLEngineResult.HandshakeStatus.NEED_WRAP;
/*      */     }
/*      */     
/* 1922 */     Throwable exception = this.pendingException;
/* 1923 */     assert exception != null;
/* 1924 */     this.pendingException = null;
/* 1925 */     shutdown();
/* 1926 */     if (exception instanceof SSLHandshakeException) {
/* 1927 */       throw (SSLHandshakeException)exception;
/*      */     }
/* 1929 */     SSLHandshakeException e = new SSLHandshakeException("General OpenSslEngine problem");
/* 1930 */     e.initCause(exception);
/* 1931 */     throw e;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void initHandshakeException(Throwable cause) {
/* 1939 */     if (this.pendingException == null) {
/* 1940 */       this.pendingException = cause;
/*      */     } else {
/* 1942 */       ThrowableUtil.addSuppressed(this.pendingException, cause);
/*      */     } 
/*      */   }
/*      */   
/*      */   private SSLEngineResult.HandshakeStatus handshake() throws SSLException {
/* 1947 */     if (this.needTask) {
/* 1948 */       return SSLEngineResult.HandshakeStatus.NEED_TASK;
/*      */     }
/* 1950 */     if (this.handshakeState == HandshakeState.FINISHED) {
/* 1951 */       return SSLEngineResult.HandshakeStatus.FINISHED;
/*      */     }
/*      */     
/* 1954 */     checkEngineClosed();
/*      */     
/* 1956 */     if (this.pendingException != null) {
/*      */ 
/*      */       
/* 1959 */       if (SSL.doHandshake(this.ssl) <= 0)
/*      */       {
/* 1961 */         SSL.clearError();
/*      */       }
/* 1963 */       return handshakeException();
/*      */     } 
/*      */ 
/*      */     
/* 1967 */     this.engineMap.add(this);
/*      */     
/* 1969 */     if (!this.sessionSet) {
/* 1970 */       this.parentContext.sessionContext().setSessionFromCache(getPeerHost(), getPeerPort(), this.ssl);
/* 1971 */       this.sessionSet = true;
/*      */     } 
/*      */     
/* 1974 */     if (this.lastAccessed == -1L) {
/* 1975 */       this.lastAccessed = System.currentTimeMillis();
/*      */     }
/*      */     
/* 1978 */     int code = SSL.doHandshake(this.ssl);
/* 1979 */     if (code <= 0) {
/* 1980 */       int sslError = SSL.getError(this.ssl, code);
/* 1981 */       if (sslError == SSL.SSL_ERROR_WANT_READ || sslError == SSL.SSL_ERROR_WANT_WRITE) {
/* 1982 */         return pendingStatus(SSL.bioLengthNonApplication(this.networkBIO));
/*      */       }
/*      */       
/* 1985 */       if (sslError == SSL.SSL_ERROR_WANT_X509_LOOKUP || sslError == SSL.SSL_ERROR_WANT_CERTIFICATE_VERIFY || sslError == SSL.SSL_ERROR_WANT_PRIVATE_KEY_OPERATION)
/*      */       {
/*      */         
/* 1988 */         return SSLEngineResult.HandshakeStatus.NEED_TASK;
/*      */       }
/*      */       
/* 1991 */       if (needWrapAgain(SSL.getLastErrorNumber()))
/*      */       {
/*      */         
/* 1994 */         return SSLEngineResult.HandshakeStatus.NEED_WRAP;
/*      */       }
/*      */ 
/*      */       
/* 1998 */       if (this.pendingException != null) {
/* 1999 */         return handshakeException();
/*      */       }
/*      */ 
/*      */       
/* 2003 */       throw shutdownWithError("SSL_do_handshake", sslError);
/*      */     } 
/*      */     
/* 2006 */     if (SSL.bioLengthNonApplication(this.networkBIO) > 0) {
/* 2007 */       return SSLEngineResult.HandshakeStatus.NEED_WRAP;
/*      */     }
/*      */     
/* 2010 */     this.session.handshakeFinished(SSL.getSessionId(this.ssl), SSL.getCipherForSSL(this.ssl), SSL.getVersion(this.ssl), 
/* 2011 */         SSL.getPeerCertificate(this.ssl), SSL.getPeerCertChain(this.ssl), 
/* 2012 */         SSL.getTime(this.ssl) * 1000L, this.parentContext.sessionTimeout() * 1000L);
/* 2013 */     selectApplicationProtocol();
/* 2014 */     return SSLEngineResult.HandshakeStatus.FINISHED;
/*      */   }
/*      */ 
/*      */   
/*      */   private SSLEngineResult.HandshakeStatus mayFinishHandshake(SSLEngineResult.HandshakeStatus hs, int bytesConsumed, int bytesProduced) throws SSLException {
/* 2019 */     return ((hs == SSLEngineResult.HandshakeStatus.NEED_UNWRAP && bytesProduced > 0) || (hs == SSLEngineResult.HandshakeStatus.NEED_WRAP && bytesConsumed > 0)) ? 
/* 2020 */       handshake() : mayFinishHandshake((hs != SSLEngineResult.HandshakeStatus.FINISHED) ? getHandshakeStatus() : SSLEngineResult.HandshakeStatus.FINISHED);
/*      */   }
/*      */ 
/*      */   
/*      */   private SSLEngineResult.HandshakeStatus mayFinishHandshake(SSLEngineResult.HandshakeStatus status) throws SSLException {
/* 2025 */     if (status == SSLEngineResult.HandshakeStatus.NOT_HANDSHAKING) {
/* 2026 */       if (this.handshakeState != HandshakeState.FINISHED)
/*      */       {
/*      */         
/* 2029 */         return handshake();
/*      */       }
/* 2031 */       if (!isDestroyed() && SSL.bioLengthNonApplication(this.networkBIO) > 0)
/*      */       {
/* 2033 */         return SSLEngineResult.HandshakeStatus.NEED_WRAP;
/*      */       }
/*      */     } 
/* 2036 */     return status;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final synchronized SSLEngineResult.HandshakeStatus getHandshakeStatus() {
/* 2042 */     if (needPendingStatus()) {
/* 2043 */       if (this.needTask)
/*      */       {
/* 2045 */         return SSLEngineResult.HandshakeStatus.NEED_TASK;
/*      */       }
/* 2047 */       return pendingStatus(SSL.bioLengthNonApplication(this.networkBIO));
/*      */     } 
/* 2049 */     return SSLEngineResult.HandshakeStatus.NOT_HANDSHAKING;
/*      */   }
/*      */ 
/*      */   
/*      */   private SSLEngineResult.HandshakeStatus getHandshakeStatus(int pending) {
/* 2054 */     if (needPendingStatus()) {
/* 2055 */       if (this.needTask)
/*      */       {
/* 2057 */         return SSLEngineResult.HandshakeStatus.NEED_TASK;
/*      */       }
/* 2059 */       return pendingStatus(pending);
/*      */     } 
/* 2061 */     return SSLEngineResult.HandshakeStatus.NOT_HANDSHAKING;
/*      */   }
/*      */   
/*      */   private boolean needPendingStatus() {
/* 2065 */     return (this.handshakeState != HandshakeState.NOT_STARTED && !isDestroyed() && (this.handshakeState != HandshakeState.FINISHED || 
/* 2066 */       isInboundDone() || isOutboundDone()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String toJavaCipherSuite(String openSslCipherSuite) {
/* 2073 */     if (openSslCipherSuite == null) {
/* 2074 */       return null;
/*      */     }
/*      */     
/* 2077 */     String version = SSL.getVersion(this.ssl);
/* 2078 */     String prefix = toJavaCipherSuitePrefix(version);
/* 2079 */     return CipherSuiteConverter.toJava(openSslCipherSuite, prefix);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String toJavaCipherSuitePrefix(String protocolVersion) {
/*      */     char c;
/* 2087 */     if (protocolVersion == null || protocolVersion.isEmpty()) {
/* 2088 */       c = Character.MIN_VALUE;
/*      */     } else {
/* 2090 */       c = protocolVersion.charAt(0);
/*      */     } 
/*      */     
/* 2093 */     switch (c) {
/*      */       case 'T':
/* 2095 */         return "TLS";
/*      */       case 'S':
/* 2097 */         return "SSL";
/*      */     } 
/* 2099 */     return "UNKNOWN";
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setUseClientMode(boolean clientMode) {
/* 2105 */     if (clientMode != this.clientMode) {
/* 2106 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public final boolean getUseClientMode() {
/* 2112 */     return this.clientMode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setNeedClientAuth(boolean b) {
/* 2117 */     setClientAuth(b ? ClientAuth.REQUIRE : ClientAuth.NONE);
/*      */   }
/*      */ 
/*      */   
/*      */   public final boolean getNeedClientAuth() {
/* 2122 */     return (this.clientAuth == ClientAuth.REQUIRE);
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setWantClientAuth(boolean b) {
/* 2127 */     setClientAuth(b ? ClientAuth.OPTIONAL : ClientAuth.NONE);
/*      */   }
/*      */ 
/*      */   
/*      */   public final boolean getWantClientAuth() {
/* 2132 */     return (this.clientAuth == ClientAuth.OPTIONAL);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final synchronized void setVerify(int verifyMode, int depth) {
/* 2141 */     if (!isDestroyed()) {
/* 2142 */       SSL.setVerify(this.ssl, verifyMode, depth);
/*      */     }
/*      */   }
/*      */   
/*      */   private void setClientAuth(ClientAuth mode) {
/* 2147 */     if (this.clientMode) {
/*      */       return;
/*      */     }
/* 2150 */     synchronized (this) {
/* 2151 */       if (this.clientAuth == mode) {
/*      */         return;
/*      */       }
/*      */       
/* 2155 */       if (!isDestroyed()) {
/* 2156 */         switch (mode) {
/*      */           case NONE:
/* 2158 */             SSL.setVerify(this.ssl, 0, 10);
/*      */             break;
/*      */           case ALPN:
/* 2161 */             SSL.setVerify(this.ssl, 2, 10);
/*      */             break;
/*      */           case NPN:
/* 2164 */             SSL.setVerify(this.ssl, 1, 10);
/*      */             break;
/*      */           default:
/* 2167 */             throw new Error(mode.toString());
/*      */         } 
/*      */       }
/* 2170 */       this.clientAuth = mode;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setEnableSessionCreation(boolean b) {
/* 2176 */     if (b) {
/* 2177 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public final boolean getEnableSessionCreation() {
/* 2183 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   @SuppressJava6Requirement(reason = "Usage guarded by java version check")
/*      */   public final synchronized SSLParameters getSSLParameters() {
/* 2189 */     SSLParameters sslParameters = super.getSSLParameters();
/*      */     
/* 2191 */     int version = PlatformDependent.javaVersion();
/* 2192 */     if (version >= 7) {
/* 2193 */       sslParameters.setEndpointIdentificationAlgorithm(this.endPointIdentificationAlgorithm);
/* 2194 */       Java7SslParametersUtils.setAlgorithmConstraints(sslParameters, this.algorithmConstraints);
/* 2195 */       if (version >= 8) {
/* 2196 */         if (this.sniHostNames != null) {
/* 2197 */           Java8SslUtils.setSniHostNames(sslParameters, this.sniHostNames);
/*      */         }
/* 2199 */         if (!isDestroyed()) {
/* 2200 */           Java8SslUtils.setUseCipherSuitesOrder(sslParameters, 
/* 2201 */               ((SSL.getOptions(this.ssl) & SSL.SSL_OP_CIPHER_SERVER_PREFERENCE) != 0));
/*      */         }
/*      */         
/* 2204 */         Java8SslUtils.setSNIMatchers(sslParameters, this.matchers);
/*      */       } 
/*      */     } 
/* 2207 */     return sslParameters;
/*      */   }
/*      */ 
/*      */   
/*      */   @SuppressJava6Requirement(reason = "Usage guarded by java version check")
/*      */   public final synchronized void setSSLParameters(SSLParameters sslParameters) {
/* 2213 */     int version = PlatformDependent.javaVersion();
/* 2214 */     if (version >= 7) {
/* 2215 */       if (sslParameters.getAlgorithmConstraints() != null) {
/* 2216 */         throw new IllegalArgumentException("AlgorithmConstraints are not supported.");
/*      */       }
/*      */       
/* 2219 */       boolean isDestroyed = isDestroyed();
/* 2220 */       if (version >= 8) {
/* 2221 */         if (!isDestroyed) {
/* 2222 */           if (this.clientMode) {
/* 2223 */             List<String> sniHostNames = Java8SslUtils.getSniHostNames(sslParameters);
/* 2224 */             for (String name : sniHostNames) {
/* 2225 */               SSL.setTlsExtHostName(this.ssl, name);
/*      */             }
/* 2227 */             this.sniHostNames = sniHostNames;
/*      */           } 
/* 2229 */           if (Java8SslUtils.getUseCipherSuitesOrder(sslParameters)) {
/* 2230 */             SSL.setOptions(this.ssl, SSL.SSL_OP_CIPHER_SERVER_PREFERENCE);
/*      */           } else {
/* 2232 */             SSL.clearOptions(this.ssl, SSL.SSL_OP_CIPHER_SERVER_PREFERENCE);
/*      */           } 
/*      */         } 
/* 2235 */         this.matchers = sslParameters.getSNIMatchers();
/*      */       } 
/*      */       
/* 2238 */       String endPointIdentificationAlgorithm = sslParameters.getEndpointIdentificationAlgorithm();
/* 2239 */       if (!isDestroyed)
/*      */       {
/*      */         
/* 2242 */         if (this.clientMode && isEndPointVerificationEnabled(endPointIdentificationAlgorithm)) {
/* 2243 */           SSL.setVerify(this.ssl, 2, -1);
/*      */         }
/*      */       }
/* 2246 */       this.endPointIdentificationAlgorithm = endPointIdentificationAlgorithm;
/* 2247 */       this.algorithmConstraints = sslParameters.getAlgorithmConstraints();
/*      */     } 
/* 2249 */     super.setSSLParameters(sslParameters);
/*      */   }
/*      */   
/*      */   private static boolean isEndPointVerificationEnabled(String endPointIdentificationAlgorithm) {
/* 2253 */     return (endPointIdentificationAlgorithm != null && !endPointIdentificationAlgorithm.isEmpty());
/*      */   }
/*      */   
/*      */   private boolean isDestroyed() {
/* 2257 */     return this.destroyed;
/*      */   }
/*      */   
/*      */   final boolean checkSniHostnameMatch(byte[] hostname) {
/* 2261 */     return Java8SslUtils.checkSniHostnameMatch(this.matchers, hostname);
/*      */   }
/*      */ 
/*      */   
/*      */   public String getNegotiatedApplicationProtocol() {
/* 2266 */     return this.applicationProtocol;
/*      */   }
/*      */   
/*      */   private static long bufferAddress(ByteBuffer b) {
/* 2270 */     assert b.isDirect();
/* 2271 */     if (PlatformDependent.hasUnsafe()) {
/* 2272 */       return PlatformDependent.directBufferAddress(b);
/*      */     }
/* 2274 */     return Buffer.address(b);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void selectApplicationProtocol() throws SSLException {
/*      */     String applicationProtocol;
/* 2281 */     ApplicationProtocolConfig.SelectedListenerFailureBehavior behavior = this.apn.selectedListenerFailureBehavior();
/* 2282 */     List<String> protocols = this.apn.protocols();
/*      */     
/* 2284 */     switch (this.apn.protocol()) {
/*      */       case NONE:
/*      */         return;
/*      */ 
/*      */       
/*      */       case ALPN:
/* 2290 */         applicationProtocol = SSL.getAlpnSelected(this.ssl);
/* 2291 */         if (applicationProtocol != null) {
/* 2292 */           this.applicationProtocol = selectApplicationProtocol(protocols, behavior, applicationProtocol);
/*      */         }
/*      */ 
/*      */       
/*      */       case NPN:
/* 2297 */         applicationProtocol = SSL.getNextProtoNegotiated(this.ssl);
/* 2298 */         if (applicationProtocol != null) {
/* 2299 */           this.applicationProtocol = selectApplicationProtocol(protocols, behavior, applicationProtocol);
/*      */         }
/*      */ 
/*      */       
/*      */       case NPN_AND_ALPN:
/* 2304 */         applicationProtocol = SSL.getAlpnSelected(this.ssl);
/* 2305 */         if (applicationProtocol == null) {
/* 2306 */           applicationProtocol = SSL.getNextProtoNegotiated(this.ssl);
/*      */         }
/* 2308 */         if (applicationProtocol != null) {
/* 2309 */           this.applicationProtocol = selectApplicationProtocol(protocols, behavior, applicationProtocol);
/*      */         }
/*      */     } 
/*      */ 
/*      */     
/* 2314 */     throw new Error();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String selectApplicationProtocol(List<String> protocols, ApplicationProtocolConfig.SelectedListenerFailureBehavior behavior, String applicationProtocol) throws SSLException {
/* 2321 */     if (behavior == ApplicationProtocolConfig.SelectedListenerFailureBehavior.ACCEPT) {
/* 2322 */       return applicationProtocol;
/*      */     }
/* 2324 */     int size = protocols.size();
/* 2325 */     assert size > 0;
/* 2326 */     if (protocols.contains(applicationProtocol)) {
/* 2327 */       return applicationProtocol;
/*      */     }
/* 2329 */     if (behavior == ApplicationProtocolConfig.SelectedListenerFailureBehavior.CHOOSE_MY_LAST_PROTOCOL) {
/* 2330 */       return protocols.get(size - 1);
/*      */     }
/* 2332 */     throw new SSLException("unknown protocol " + applicationProtocol);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void setSessionId(OpenSslSessionId id) {
/* 2339 */     this.session.setSessionId(id);
/*      */   }
/*      */ 
/*      */   
/*      */   private final class DefaultOpenSslSession
/*      */     implements OpenSslSession
/*      */   {
/*      */     private final OpenSslSessionContext sessionContext;
/*      */     
/*      */     private X509Certificate[] x509PeerCerts;
/*      */     private Certificate[] peerCerts;
/*      */     private boolean valid = true;
/*      */     private String protocol;
/*      */     private String cipher;
/* 2353 */     private OpenSslSessionId id = OpenSslSessionId.NULL_ID;
/*      */     private volatile long creationTime;
/* 2355 */     private volatile int applicationBufferSize = ReferenceCountedOpenSslEngine.MAX_PLAINTEXT_LENGTH;
/*      */     
/*      */     private volatile Certificate[] localCertificateChain;
/*      */     private Map<String, Object> values;
/*      */     
/*      */     DefaultOpenSslSession(OpenSslSessionContext sessionContext) {
/* 2361 */       this.sessionContext = sessionContext;
/*      */     }
/*      */     
/*      */     private SSLSessionBindingEvent newSSLSessionBindingEvent(String name) {
/* 2365 */       return new SSLSessionBindingEvent(ReferenceCountedOpenSslEngine.this.session, name);
/*      */     }
/*      */ 
/*      */     
/*      */     public void setSessionId(OpenSslSessionId sessionId) {
/* 2370 */       synchronized (ReferenceCountedOpenSslEngine.this) {
/* 2371 */         if (this.id == OpenSslSessionId.NULL_ID) {
/* 2372 */           this.id = sessionId;
/* 2373 */           this.creationTime = System.currentTimeMillis();
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public OpenSslSessionId sessionId() {
/* 2380 */       synchronized (ReferenceCountedOpenSslEngine.this) {
/* 2381 */         if (this.id == OpenSslSessionId.NULL_ID && !ReferenceCountedOpenSslEngine.this.isDestroyed()) {
/* 2382 */           byte[] sessionId = SSL.getSessionId(ReferenceCountedOpenSslEngine.this.ssl);
/* 2383 */           if (sessionId != null) {
/* 2384 */             this.id = new OpenSslSessionId(sessionId);
/*      */           }
/*      */         } 
/*      */         
/* 2388 */         return this.id;
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void setLocalCertificate(Certificate[] localCertificate) {
/* 2394 */       this.localCertificateChain = localCertificate;
/*      */     }
/*      */ 
/*      */     
/*      */     public byte[] getId() {
/* 2399 */       return sessionId().cloneBytes();
/*      */     }
/*      */ 
/*      */     
/*      */     public OpenSslSessionContext getSessionContext() {
/* 2404 */       return this.sessionContext;
/*      */     }
/*      */ 
/*      */     
/*      */     public long getCreationTime() {
/* 2409 */       synchronized (ReferenceCountedOpenSslEngine.this) {
/* 2410 */         return this.creationTime;
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public long getLastAccessedTime() {
/* 2416 */       long lastAccessed = ReferenceCountedOpenSslEngine.this.lastAccessed;
/*      */       
/* 2418 */       return (lastAccessed == -1L) ? getCreationTime() : lastAccessed;
/*      */     }
/*      */ 
/*      */     
/*      */     public void invalidate() {
/* 2423 */       synchronized (ReferenceCountedOpenSslEngine.this) {
/* 2424 */         this.valid = false;
/* 2425 */         this.sessionContext.removeFromCache(this.id);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isValid() {
/* 2431 */       synchronized (ReferenceCountedOpenSslEngine.this) {
/* 2432 */         return (this.valid || this.sessionContext.isInCache(this.id));
/*      */       } 
/*      */     }
/*      */     
/*      */     public void putValue(String name, Object value) {
/*      */       Object old;
/* 2438 */       ObjectUtil.checkNotNull(name, "name");
/* 2439 */       ObjectUtil.checkNotNull(value, "value");
/*      */ 
/*      */       
/* 2442 */       synchronized (this) {
/* 2443 */         Map<String, Object> values = this.values;
/* 2444 */         if (values == null)
/*      */         {
/* 2446 */           values = this.values = new HashMap<String, Object>(2);
/*      */         }
/* 2448 */         old = values.put(name, value);
/*      */       } 
/*      */       
/* 2451 */       if (value instanceof SSLSessionBindingListener)
/*      */       {
/* 2453 */         ((SSLSessionBindingListener)value).valueBound(newSSLSessionBindingEvent(name));
/*      */       }
/* 2455 */       notifyUnbound(old, name);
/*      */     }
/*      */ 
/*      */     
/*      */     public Object getValue(String name) {
/* 2460 */       ObjectUtil.checkNotNull(name, "name");
/* 2461 */       synchronized (this) {
/* 2462 */         if (this.values == null) {
/* 2463 */           return null;
/*      */         }
/* 2465 */         return this.values.get(name);
/*      */       } 
/*      */     }
/*      */     
/*      */     public void removeValue(String name) {
/*      */       Object old;
/* 2471 */       ObjectUtil.checkNotNull(name, "name");
/*      */ 
/*      */       
/* 2474 */       synchronized (this) {
/* 2475 */         Map<String, Object> values = this.values;
/* 2476 */         if (values == null) {
/*      */           return;
/*      */         }
/* 2479 */         old = values.remove(name);
/*      */       } 
/*      */       
/* 2482 */       notifyUnbound(old, name);
/*      */     }
/*      */ 
/*      */     
/*      */     public String[] getValueNames() {
/* 2487 */       synchronized (this) {
/* 2488 */         Map<String, Object> values = this.values;
/* 2489 */         if (values == null || values.isEmpty()) {
/* 2490 */           return EmptyArrays.EMPTY_STRINGS;
/*      */         }
/* 2492 */         return (String[])values.keySet().toArray((Object[])new String[0]);
/*      */       } 
/*      */     }
/*      */     
/*      */     private void notifyUnbound(Object value, String name) {
/* 2497 */       if (value instanceof SSLSessionBindingListener)
/*      */       {
/* 2499 */         ((SSLSessionBindingListener)value).valueUnbound(newSSLSessionBindingEvent(name));
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void handshakeFinished(byte[] id, String cipher, String protocol, byte[] peerCertificate, byte[][] peerCertificateChain, long creationTime, long timeout) throws SSLException {
/* 2511 */       synchronized (ReferenceCountedOpenSslEngine.this) {
/* 2512 */         if (!ReferenceCountedOpenSslEngine.this.isDestroyed()) {
/* 2513 */           this.creationTime = creationTime;
/* 2514 */           if (this.id == OpenSslSessionId.NULL_ID) {
/* 2515 */             this.id = (id == null) ? OpenSslSessionId.NULL_ID : new OpenSslSessionId(id);
/*      */           }
/* 2517 */           this.cipher = ReferenceCountedOpenSslEngine.this.toJavaCipherSuite(cipher);
/* 2518 */           this.protocol = protocol;
/*      */           
/* 2520 */           if (ReferenceCountedOpenSslEngine.this.clientMode) {
/* 2521 */             if (ReferenceCountedOpenSslEngine.isEmpty((Object[])peerCertificateChain)) {
/* 2522 */               this.peerCerts = EmptyArrays.EMPTY_CERTIFICATES;
/* 2523 */               this.x509PeerCerts = EmptyArrays.EMPTY_JAVAX_X509_CERTIFICATES;
/*      */             } else {
/* 2525 */               this.peerCerts = new Certificate[peerCertificateChain.length];
/* 2526 */               this.x509PeerCerts = new X509Certificate[peerCertificateChain.length];
/* 2527 */               initCerts(peerCertificateChain, 0);
/*      */ 
/*      */             
/*      */             }
/*      */ 
/*      */ 
/*      */           
/*      */           }
/* 2535 */           else if (ReferenceCountedOpenSslEngine.isEmpty(peerCertificate)) {
/* 2536 */             this.peerCerts = EmptyArrays.EMPTY_CERTIFICATES;
/* 2537 */             this.x509PeerCerts = EmptyArrays.EMPTY_JAVAX_X509_CERTIFICATES;
/*      */           }
/* 2539 */           else if (ReferenceCountedOpenSslEngine.isEmpty((Object[])peerCertificateChain)) {
/* 2540 */             this.peerCerts = new Certificate[] { (Certificate)new LazyX509Certificate(peerCertificate) };
/* 2541 */             this.x509PeerCerts = new X509Certificate[] { (X509Certificate)new LazyJavaxX509Certificate(peerCertificate) };
/*      */           } else {
/* 2543 */             this.peerCerts = new Certificate[peerCertificateChain.length + 1];
/* 2544 */             this.x509PeerCerts = new X509Certificate[peerCertificateChain.length + 1];
/* 2545 */             this.peerCerts[0] = (Certificate)new LazyX509Certificate(peerCertificate);
/* 2546 */             this.x509PeerCerts[0] = (X509Certificate)new LazyJavaxX509Certificate(peerCertificate);
/* 2547 */             initCerts(peerCertificateChain, 1);
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/* 2552 */           ReferenceCountedOpenSslEngine.this.calculateMaxWrapOverhead();
/*      */           
/* 2554 */           ReferenceCountedOpenSslEngine.this.handshakeState = ReferenceCountedOpenSslEngine.HandshakeState.FINISHED;
/*      */         } else {
/* 2556 */           throw new SSLException("Already closed");
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*      */     private void initCerts(byte[][] chain, int startPos) {
/* 2562 */       for (int i = 0; i < chain.length; i++) {
/* 2563 */         int certPos = startPos + i;
/* 2564 */         this.peerCerts[certPos] = (Certificate)new LazyX509Certificate(chain[i]);
/* 2565 */         this.x509PeerCerts[certPos] = (X509Certificate)new LazyJavaxX509Certificate(chain[i]);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public Certificate[] getPeerCertificates() throws SSLPeerUnverifiedException {
/* 2571 */       synchronized (ReferenceCountedOpenSslEngine.this) {
/* 2572 */         if (ReferenceCountedOpenSslEngine.isEmpty((Object[])this.peerCerts)) {
/* 2573 */           throw new SSLPeerUnverifiedException("peer not verified");
/*      */         }
/* 2575 */         return (Certificate[])this.peerCerts.clone();
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public Certificate[] getLocalCertificates() {
/* 2581 */       Certificate[] localCerts = this.localCertificateChain;
/* 2582 */       if (localCerts == null) {
/* 2583 */         return null;
/*      */       }
/* 2585 */       return (Certificate[])localCerts.clone();
/*      */     }
/*      */ 
/*      */     
/*      */     public X509Certificate[] getPeerCertificateChain() throws SSLPeerUnverifiedException {
/* 2590 */       synchronized (ReferenceCountedOpenSslEngine.this) {
/* 2591 */         if (ReferenceCountedOpenSslEngine.isEmpty((Object[])this.x509PeerCerts)) {
/* 2592 */           throw new SSLPeerUnverifiedException("peer not verified");
/*      */         }
/* 2594 */         return (X509Certificate[])this.x509PeerCerts.clone();
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public Principal getPeerPrincipal() throws SSLPeerUnverifiedException {
/* 2600 */       Certificate[] peer = getPeerCertificates();
/*      */ 
/*      */       
/* 2603 */       return ((X509Certificate)peer[0]).getSubjectX500Principal();
/*      */     }
/*      */ 
/*      */     
/*      */     public Principal getLocalPrincipal() {
/* 2608 */       Certificate[] local = this.localCertificateChain;
/* 2609 */       if (local == null || local.length == 0) {
/* 2610 */         return null;
/*      */       }
/* 2612 */       return ((X509Certificate)local[0]).getSubjectX500Principal();
/*      */     }
/*      */ 
/*      */     
/*      */     public String getCipherSuite() {
/* 2617 */       synchronized (ReferenceCountedOpenSslEngine.this) {
/* 2618 */         if (this.cipher == null) {
/* 2619 */           return "SSL_NULL_WITH_NULL_NULL";
/*      */         }
/* 2621 */         return this.cipher;
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public String getProtocol() {
/* 2627 */       String protocol = this.protocol;
/* 2628 */       if (protocol == null) {
/* 2629 */         synchronized (ReferenceCountedOpenSslEngine.this) {
/* 2630 */           if (!ReferenceCountedOpenSslEngine.this.isDestroyed()) {
/* 2631 */             protocol = SSL.getVersion(ReferenceCountedOpenSslEngine.this.ssl);
/*      */           } else {
/* 2633 */             protocol = "";
/*      */           } 
/*      */         } 
/*      */       }
/* 2637 */       return protocol;
/*      */     }
/*      */ 
/*      */     
/*      */     public String getPeerHost() {
/* 2642 */       return ReferenceCountedOpenSslEngine.this.getPeerHost();
/*      */     }
/*      */ 
/*      */     
/*      */     public int getPeerPort() {
/* 2647 */       return ReferenceCountedOpenSslEngine.this.getPeerPort();
/*      */     }
/*      */ 
/*      */     
/*      */     public int getPacketBufferSize() {
/* 2652 */       return SSL.SSL_MAX_ENCRYPTED_LENGTH;
/*      */     }
/*      */ 
/*      */     
/*      */     public int getApplicationBufferSize() {
/* 2657 */       return this.applicationBufferSize;
/*      */     }
/*      */ 
/*      */     
/*      */     public void tryExpandApplicationBufferSize(int packetLengthDataOnly) {
/* 2662 */       if (packetLengthDataOnly > ReferenceCountedOpenSslEngine.MAX_PLAINTEXT_LENGTH && this.applicationBufferSize != ReferenceCountedOpenSslEngine.MAX_RECORD_SIZE) {
/* 2663 */         this.applicationBufferSize = ReferenceCountedOpenSslEngine.MAX_RECORD_SIZE;
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/* 2669 */       return "DefaultOpenSslSession{sessionContext=" + this.sessionContext + ", id=" + this.id + '}';
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static final class OpenSslException
/*      */     extends SSLException
/*      */     implements NativeSslException
/*      */   {
/*      */     private final int errorCode;
/*      */ 
/*      */ 
/*      */     
/*      */     OpenSslException(String reason, int errorCode) {
/* 2684 */       super(reason);
/* 2685 */       this.errorCode = errorCode;
/*      */     }
/*      */ 
/*      */     
/*      */     public int errorCode() {
/* 2690 */       return this.errorCode;
/*      */     }
/*      */   }
/*      */   
/*      */   private static final class OpenSslHandshakeException extends SSLHandshakeException implements NativeSslException {
/*      */     private final int errorCode;
/*      */     
/*      */     OpenSslHandshakeException(String reason, int errorCode) {
/* 2698 */       super(reason);
/* 2699 */       this.errorCode = errorCode;
/*      */     }
/*      */ 
/*      */     
/*      */     public int errorCode() {
/* 2704 */       return this.errorCode;
/*      */     }
/*      */   }
/*      */   
/*      */   private static interface NativeSslException {
/*      */     int errorCode();
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-handler-4.1.93.Final.jar!\io\netty\handler\ssl\ReferenceCountedOpenSslEngine.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */