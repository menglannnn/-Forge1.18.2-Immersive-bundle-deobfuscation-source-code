/*    */ package io.netty.handler.ssl.ocsp;
/*    */ 
/*    */ import io.netty.channel.ChannelHandler;
/*    */ import io.netty.channel.ChannelHandlerContext;
/*    */ import io.netty.channel.ChannelInboundHandlerAdapter;
/*    */ import io.netty.handler.ssl.ReferenceCountedOpenSslEngine;
/*    */ import io.netty.handler.ssl.SslHandshakeCompletionEvent;
/*    */ import io.netty.util.internal.ObjectUtil;
/*    */ import javax.net.ssl.SSLHandshakeException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class OcspClientHandler
/*    */   extends ChannelInboundHandlerAdapter
/*    */ {
/*    */   private final ReferenceCountedOpenSslEngine engine;
/*    */   
/*    */   protected OcspClientHandler(ReferenceCountedOpenSslEngine engine) {
/* 40 */     this.engine = (ReferenceCountedOpenSslEngine)ObjectUtil.checkNotNull(engine, "engine");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected abstract boolean verify(ChannelHandlerContext paramChannelHandlerContext, ReferenceCountedOpenSslEngine paramReferenceCountedOpenSslEngine) throws Exception;
/*    */ 
/*    */ 
/*    */   
/*    */   public void userEventTriggered(ChannelHandlerContext ctx, Object evt) throws Exception {
/* 50 */     if (evt instanceof SslHandshakeCompletionEvent) {
/* 51 */       ctx.pipeline().remove((ChannelHandler)this);
/*    */       
/* 53 */       SslHandshakeCompletionEvent event = (SslHandshakeCompletionEvent)evt;
/* 54 */       if (event.isSuccess() && !verify(ctx, this.engine)) {
/* 55 */         throw new SSLHandshakeException("Bad OCSP response");
/*    */       }
/*    */     } 
/*    */     
/* 59 */     ctx.fireUserEventTriggered(evt);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-handler-4.1.93.Final.jar!\io\netty\handler\ssl\ocsp\OcspClientHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */