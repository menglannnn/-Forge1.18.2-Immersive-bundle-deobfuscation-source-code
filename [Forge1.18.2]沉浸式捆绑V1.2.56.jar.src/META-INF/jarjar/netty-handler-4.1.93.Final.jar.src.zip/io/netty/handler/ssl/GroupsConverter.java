/*    */ package io.netty.handler.ssl;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class GroupsConverter
/*    */ {
/*    */   private static final Map<String, String> mappings;
/*    */   
/*    */   static {
/* 31 */     Map<String, String> map = new HashMap<String, String>();
/* 32 */     map.put("secp224r1", "P-224");
/* 33 */     map.put("prime256v1", "P-256");
/* 34 */     map.put("secp256r1", "P-256");
/* 35 */     map.put("secp384r1", "P-384");
/* 36 */     map.put("secp521r1", "P-521");
/* 37 */     map.put("x25519", "X25519");
/* 38 */     mappings = Collections.unmodifiableMap(map);
/*    */   }
/*    */   
/*    */   static String toOpenSsl(String key) {
/* 42 */     String mapping = mappings.get(key);
/* 43 */     if (mapping == null) {
/* 44 */       return key;
/*    */     }
/* 46 */     return mapping;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-handler-4.1.93.Final.jar!\io\netty\handler\ssl\GroupsConverter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */