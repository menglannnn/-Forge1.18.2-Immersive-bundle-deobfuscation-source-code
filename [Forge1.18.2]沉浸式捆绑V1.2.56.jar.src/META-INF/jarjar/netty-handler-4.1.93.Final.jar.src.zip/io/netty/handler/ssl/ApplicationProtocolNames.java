package io.netty.handler.ssl;

public final class ApplicationProtocolNames {
  public static final String HTTP_2 = "h2";
  
  public static final String HTTP_1_1 = "http/1.1";
  
  public static final String SPDY_3_1 = "spdy/3.1";
  
  public static final String SPDY_3 = "spdy/3";
  
  public static final String SPDY_2 = "spdy/2";
  
  public static final String SPDY_1 = "spdy/1";
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-handler-4.1.93.Final.jar!\io\netty\handler\ssl\ApplicationProtocolNames.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */