/*     */ package io.netty.handler.ssl;
/*     */ 
/*     */ import io.netty.util.internal.PlatformDependent;
/*     */ import io.netty.util.internal.logging.InternalLogger;
/*     */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CipherSuiteConverter
/*     */ {
/*  41 */   private static final InternalLogger logger = InternalLoggerFactory.getInstance(CipherSuiteConverter.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  57 */   private static final Pattern JAVA_CIPHERSUITE_PATTERN = Pattern.compile("^(?:TLS|SSL)_((?:(?!_WITH_).)+)_WITH_(.*)_(.*)$");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  73 */   private static final Pattern OPENSSL_CIPHERSUITE_PATTERN = Pattern.compile("^(?:((?:(?:EXP-)?(?:(?:DHE|EDH|ECDH|ECDHE|SRP|RSA)-(?:DSS|RSA|ECDSA|PSK)|(?:ADH|AECDH|KRB5|PSK|SRP)))|EXP)-)?(.*)-(.*)$");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  85 */   private static final Pattern JAVA_AES_CBC_PATTERN = Pattern.compile("^(AES)_([0-9]+)_CBC$");
/*  86 */   private static final Pattern JAVA_AES_PATTERN = Pattern.compile("^(AES)_([0-9]+)_(.*)$");
/*  87 */   private static final Pattern OPENSSL_AES_CBC_PATTERN = Pattern.compile("^(AES)([0-9]+)$");
/*  88 */   private static final Pattern OPENSSL_AES_PATTERN = Pattern.compile("^(AES)([0-9]+)-(.*)$");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  94 */   private static final ConcurrentMap<String, String> j2o = PlatformDependent.newConcurrentHashMap();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 101 */   private static final ConcurrentMap<String, Map<String, String>> o2j = PlatformDependent.newConcurrentHashMap();
/*     */   
/*     */   private static final Map<String, String> j2oTls13;
/*     */   private static final Map<String, Map<String, String>> o2jTls13;
/*     */   
/*     */   static {
/* 107 */     Map<String, String> j2oTls13Map = new HashMap<String, String>();
/* 108 */     j2oTls13Map.put("TLS_AES_128_GCM_SHA256", "AEAD-AES128-GCM-SHA256");
/* 109 */     j2oTls13Map.put("TLS_AES_256_GCM_SHA384", "AEAD-AES256-GCM-SHA384");
/* 110 */     j2oTls13Map.put("TLS_CHACHA20_POLY1305_SHA256", "AEAD-CHACHA20-POLY1305-SHA256");
/* 111 */     j2oTls13 = Collections.unmodifiableMap(j2oTls13Map);
/*     */     
/* 113 */     Map<String, Map<String, String>> o2jTls13Map = new HashMap<String, Map<String, String>>();
/* 114 */     o2jTls13Map.put("TLS_AES_128_GCM_SHA256", Collections.singletonMap("TLS", "TLS_AES_128_GCM_SHA256"));
/* 115 */     o2jTls13Map.put("TLS_AES_256_GCM_SHA384", Collections.singletonMap("TLS", "TLS_AES_256_GCM_SHA384"));
/* 116 */     o2jTls13Map.put("TLS_CHACHA20_POLY1305_SHA256", Collections.singletonMap("TLS", "TLS_CHACHA20_POLY1305_SHA256"));
/* 117 */     o2jTls13Map.put("AEAD-AES128-GCM-SHA256", Collections.singletonMap("TLS", "TLS_AES_128_GCM_SHA256"));
/* 118 */     o2jTls13Map.put("AEAD-AES256-GCM-SHA384", Collections.singletonMap("TLS", "TLS_AES_256_GCM_SHA384"));
/* 119 */     o2jTls13Map.put("AEAD-CHACHA20-POLY1305-SHA256", Collections.singletonMap("TLS", "TLS_CHACHA20_POLY1305_SHA256"));
/* 120 */     o2jTls13 = Collections.unmodifiableMap(o2jTls13Map);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void clearCache() {
/* 127 */     j2o.clear();
/* 128 */     o2j.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean isJ2OCached(String key, String value) {
/* 135 */     return value.equals(j2o.get(key));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean isO2JCached(String key, String protocol, String value) {
/* 142 */     Map<String, String> p2j = o2j.get(key);
/* 143 */     if (p2j == null) {
/* 144 */       return false;
/*     */     }
/* 146 */     return value.equals(p2j.get(protocol));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toOpenSsl(String javaCipherSuite, boolean boringSSL) {
/* 156 */     String converted = j2o.get(javaCipherSuite);
/* 157 */     if (converted != null) {
/* 158 */       return converted;
/*     */     }
/* 160 */     return cacheFromJava(javaCipherSuite, boringSSL);
/*     */   }
/*     */   
/*     */   private static String cacheFromJava(String javaCipherSuite, boolean boringSSL) {
/* 164 */     String converted = j2oTls13.get(javaCipherSuite);
/* 165 */     if (converted != null) {
/* 166 */       return boringSSL ? converted : javaCipherSuite;
/*     */     }
/*     */     
/* 169 */     String openSslCipherSuite = toOpenSslUncached(javaCipherSuite, boringSSL);
/* 170 */     if (openSslCipherSuite == null) {
/* 171 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 175 */     j2o.putIfAbsent(javaCipherSuite, openSslCipherSuite);
/*     */ 
/*     */     
/* 178 */     String javaCipherSuiteSuffix = javaCipherSuite.substring(4);
/* 179 */     Map<String, String> p2j = new HashMap<String, String>(4);
/* 180 */     p2j.put("", javaCipherSuiteSuffix);
/* 181 */     p2j.put("SSL", "SSL_" + javaCipherSuiteSuffix);
/* 182 */     p2j.put("TLS", "TLS_" + javaCipherSuiteSuffix);
/* 183 */     o2j.put(openSslCipherSuite, p2j);
/*     */     
/* 185 */     logger.debug("Cipher suite mapping: {} => {}", javaCipherSuite, openSslCipherSuite);
/*     */     
/* 187 */     return openSslCipherSuite;
/*     */   }
/*     */   
/*     */   static String toOpenSslUncached(String javaCipherSuite, boolean boringSSL) {
/* 191 */     String converted = j2oTls13.get(javaCipherSuite);
/* 192 */     if (converted != null) {
/* 193 */       return boringSSL ? converted : javaCipherSuite;
/*     */     }
/*     */     
/* 196 */     Matcher m = JAVA_CIPHERSUITE_PATTERN.matcher(javaCipherSuite);
/* 197 */     if (!m.matches()) {
/* 198 */       return null;
/*     */     }
/*     */     
/* 201 */     String handshakeAlgo = toOpenSslHandshakeAlgo(m.group(1));
/* 202 */     String bulkCipher = toOpenSslBulkCipher(m.group(2));
/* 203 */     String hmacAlgo = toOpenSslHmacAlgo(m.group(3));
/* 204 */     if (handshakeAlgo.isEmpty())
/* 205 */       return bulkCipher + '-' + hmacAlgo; 
/* 206 */     if (bulkCipher.contains("CHACHA20")) {
/* 207 */       return handshakeAlgo + '-' + bulkCipher;
/*     */     }
/* 209 */     return handshakeAlgo + '-' + bulkCipher + '-' + hmacAlgo;
/*     */   }
/*     */ 
/*     */   
/*     */   private static String toOpenSslHandshakeAlgo(String handshakeAlgo) {
/* 214 */     boolean export = handshakeAlgo.endsWith("_EXPORT");
/* 215 */     if (export) {
/* 216 */       handshakeAlgo = handshakeAlgo.substring(0, handshakeAlgo.length() - 7);
/*     */     }
/*     */     
/* 219 */     if ("RSA".equals(handshakeAlgo)) {
/* 220 */       handshakeAlgo = "";
/* 221 */     } else if (handshakeAlgo.endsWith("_anon")) {
/* 222 */       handshakeAlgo = 'A' + handshakeAlgo.substring(0, handshakeAlgo.length() - 5);
/*     */     } 
/*     */     
/* 225 */     if (export) {
/* 226 */       if (handshakeAlgo.isEmpty()) {
/* 227 */         handshakeAlgo = "EXP";
/*     */       } else {
/* 229 */         handshakeAlgo = "EXP-" + handshakeAlgo;
/*     */       } 
/*     */     }
/*     */     
/* 233 */     return handshakeAlgo.replace('_', '-');
/*     */   }
/*     */   
/*     */   private static String toOpenSslBulkCipher(String bulkCipher) {
/* 237 */     if (bulkCipher.startsWith("AES_")) {
/* 238 */       Matcher m = JAVA_AES_CBC_PATTERN.matcher(bulkCipher);
/* 239 */       if (m.matches()) {
/* 240 */         return m.replaceFirst("$1$2");
/*     */       }
/*     */       
/* 243 */       m = JAVA_AES_PATTERN.matcher(bulkCipher);
/* 244 */       if (m.matches()) {
/* 245 */         return m.replaceFirst("$1$2-$3");
/*     */       }
/*     */     } 
/*     */     
/* 249 */     if ("3DES_EDE_CBC".equals(bulkCipher)) {
/* 250 */       return "DES-CBC3";
/*     */     }
/*     */     
/* 253 */     if ("RC4_128".equals(bulkCipher) || "RC4_40".equals(bulkCipher)) {
/* 254 */       return "RC4";
/*     */     }
/*     */     
/* 257 */     if ("DES40_CBC".equals(bulkCipher) || "DES_CBC_40".equals(bulkCipher)) {
/* 258 */       return "DES-CBC";
/*     */     }
/*     */     
/* 261 */     if ("RC2_CBC_40".equals(bulkCipher)) {
/* 262 */       return "RC2-CBC";
/*     */     }
/*     */     
/* 265 */     return bulkCipher.replace('_', '-');
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String toOpenSslHmacAlgo(String hmacAlgo) {
/* 275 */     return hmacAlgo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toJava(String openSslCipherSuite, String protocol) {
/* 285 */     Map<String, String> p2j = o2j.get(openSslCipherSuite);
/* 286 */     if (p2j == null) {
/* 287 */       p2j = cacheFromOpenSsl(openSslCipherSuite);
/*     */ 
/*     */       
/* 290 */       if (p2j == null) {
/* 291 */         return null;
/*     */       }
/*     */     } 
/*     */     
/* 295 */     String javaCipherSuite = p2j.get(protocol);
/* 296 */     if (javaCipherSuite == null) {
/* 297 */       String cipher = p2j.get("");
/* 298 */       if (cipher == null) {
/* 299 */         return null;
/*     */       }
/* 301 */       javaCipherSuite = protocol + '_' + cipher;
/*     */     } 
/*     */     
/* 304 */     return javaCipherSuite;
/*     */   }
/*     */   
/*     */   private static Map<String, String> cacheFromOpenSsl(String openSslCipherSuite) {
/* 308 */     Map<String, String> converted = o2jTls13.get(openSslCipherSuite);
/* 309 */     if (converted != null) {
/* 310 */       return converted;
/*     */     }
/*     */     
/* 313 */     String javaCipherSuiteSuffix = toJavaUncached0(openSslCipherSuite, false);
/* 314 */     if (javaCipherSuiteSuffix == null) {
/* 315 */       return null;
/*     */     }
/*     */     
/* 318 */     String javaCipherSuiteSsl = "SSL_" + javaCipherSuiteSuffix;
/* 319 */     String javaCipherSuiteTls = "TLS_" + javaCipherSuiteSuffix;
/*     */ 
/*     */     
/* 322 */     Map<String, String> p2j = new HashMap<String, String>(4);
/* 323 */     p2j.put("", javaCipherSuiteSuffix);
/* 324 */     p2j.put("SSL", javaCipherSuiteSsl);
/* 325 */     p2j.put("TLS", javaCipherSuiteTls);
/* 326 */     o2j.putIfAbsent(openSslCipherSuite, p2j);
/*     */ 
/*     */     
/* 329 */     j2o.putIfAbsent(javaCipherSuiteTls, openSslCipherSuite);
/* 330 */     j2o.putIfAbsent(javaCipherSuiteSsl, openSslCipherSuite);
/*     */     
/* 332 */     logger.debug("Cipher suite mapping: {} => {}", javaCipherSuiteTls, openSslCipherSuite);
/* 333 */     logger.debug("Cipher suite mapping: {} => {}", javaCipherSuiteSsl, openSslCipherSuite);
/*     */     
/* 335 */     return p2j;
/*     */   }
/*     */   
/*     */   static String toJavaUncached(String openSslCipherSuite) {
/* 339 */     return toJavaUncached0(openSslCipherSuite, true);
/*     */   }
/*     */   private static String toJavaUncached0(String openSslCipherSuite, boolean checkTls13) {
/*     */     boolean export;
/* 343 */     if (checkTls13) {
/* 344 */       Map<String, String> converted = o2jTls13.get(openSslCipherSuite);
/* 345 */       if (converted != null) {
/* 346 */         return converted.get("TLS");
/*     */       }
/*     */     } 
/*     */     
/* 350 */     Matcher m = OPENSSL_CIPHERSUITE_PATTERN.matcher(openSslCipherSuite);
/* 351 */     if (!m.matches()) {
/* 352 */       return null;
/*     */     }
/*     */     
/* 355 */     String handshakeAlgo = m.group(1);
/*     */     
/* 357 */     if (handshakeAlgo == null) {
/* 358 */       handshakeAlgo = "";
/* 359 */       export = false;
/* 360 */     } else if (handshakeAlgo.startsWith("EXP-")) {
/* 361 */       handshakeAlgo = handshakeAlgo.substring(4);
/* 362 */       export = true;
/* 363 */     } else if ("EXP".equals(handshakeAlgo)) {
/* 364 */       handshakeAlgo = "";
/* 365 */       export = true;
/*     */     } else {
/* 367 */       export = false;
/*     */     } 
/*     */     
/* 370 */     handshakeAlgo = toJavaHandshakeAlgo(handshakeAlgo, export);
/* 371 */     String bulkCipher = toJavaBulkCipher(m.group(2), export);
/* 372 */     String hmacAlgo = toJavaHmacAlgo(m.group(3));
/*     */     
/* 374 */     String javaCipherSuite = handshakeAlgo + "_WITH_" + bulkCipher + '_' + hmacAlgo;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 379 */     return bulkCipher.contains("CHACHA20") ? (javaCipherSuite + "_SHA256") : javaCipherSuite;
/*     */   }
/*     */   
/*     */   private static String toJavaHandshakeAlgo(String handshakeAlgo, boolean export) {
/* 383 */     if (handshakeAlgo.isEmpty()) {
/* 384 */       handshakeAlgo = "RSA";
/* 385 */     } else if ("ADH".equals(handshakeAlgo)) {
/* 386 */       handshakeAlgo = "DH_anon";
/* 387 */     } else if ("AECDH".equals(handshakeAlgo)) {
/* 388 */       handshakeAlgo = "ECDH_anon";
/*     */     } 
/*     */     
/* 391 */     handshakeAlgo = handshakeAlgo.replace('-', '_');
/* 392 */     if (export) {
/* 393 */       return handshakeAlgo + "_EXPORT";
/*     */     }
/* 395 */     return handshakeAlgo;
/*     */   }
/*     */ 
/*     */   
/*     */   private static String toJavaBulkCipher(String bulkCipher, boolean export) {
/* 400 */     if (bulkCipher.startsWith("AES")) {
/* 401 */       Matcher m = OPENSSL_AES_CBC_PATTERN.matcher(bulkCipher);
/* 402 */       if (m.matches()) {
/* 403 */         return m.replaceFirst("$1_$2_CBC");
/*     */       }
/*     */       
/* 406 */       m = OPENSSL_AES_PATTERN.matcher(bulkCipher);
/* 407 */       if (m.matches()) {
/* 408 */         return m.replaceFirst("$1_$2_$3");
/*     */       }
/*     */     } 
/*     */     
/* 412 */     if ("DES-CBC3".equals(bulkCipher)) {
/* 413 */       return "3DES_EDE_CBC";
/*     */     }
/*     */     
/* 416 */     if ("RC4".equals(bulkCipher)) {
/* 417 */       if (export) {
/* 418 */         return "RC4_40";
/*     */       }
/* 420 */       return "RC4_128";
/*     */     } 
/*     */ 
/*     */     
/* 424 */     if ("DES-CBC".equals(bulkCipher)) {
/* 425 */       if (export) {
/* 426 */         return "DES_CBC_40";
/*     */       }
/* 428 */       return "DES_CBC";
/*     */     } 
/*     */ 
/*     */     
/* 432 */     if ("RC2-CBC".equals(bulkCipher)) {
/* 433 */       if (export) {
/* 434 */         return "RC2_CBC_40";
/*     */       }
/* 436 */       return "RC2_CBC";
/*     */     } 
/*     */ 
/*     */     
/* 440 */     return bulkCipher.replace('-', '_');
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String toJavaHmacAlgo(String hmacAlgo) {
/* 450 */     return hmacAlgo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void convertToCipherStrings(Iterable<String> cipherSuites, StringBuilder cipherBuilder, StringBuilder cipherTLSv13Builder, boolean boringSSL) {
/* 461 */     for (String c : cipherSuites) {
/* 462 */       if (c == null) {
/*     */         break;
/*     */       }
/*     */       
/* 466 */       String converted = toOpenSsl(c, boringSSL);
/* 467 */       if (converted == null) {
/* 468 */         converted = c;
/*     */       }
/*     */       
/* 471 */       if (!OpenSsl.isCipherSuiteAvailable(converted)) {
/* 472 */         throw new IllegalArgumentException("unsupported cipher suite: " + c + '(' + converted + ')');
/*     */       }
/*     */       
/* 475 */       if (SslUtils.isTLSv13Cipher(converted) || SslUtils.isTLSv13Cipher(c)) {
/* 476 */         cipherTLSv13Builder.append(converted);
/* 477 */         cipherTLSv13Builder.append(':'); continue;
/*     */       } 
/* 479 */       cipherBuilder.append(converted);
/* 480 */       cipherBuilder.append(':');
/*     */     } 
/*     */ 
/*     */     
/* 484 */     if (cipherBuilder.length() == 0 && cipherTLSv13Builder.length() == 0) {
/* 485 */       throw new IllegalArgumentException("empty cipher suites");
/*     */     }
/* 487 */     if (cipherBuilder.length() > 0) {
/* 488 */       cipherBuilder.setLength(cipherBuilder.length() - 1);
/*     */     }
/* 490 */     if (cipherTLSv13Builder.length() > 0)
/* 491 */       cipherTLSv13Builder.setLength(cipherTLSv13Builder.length() - 1); 
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-handler-4.1.93.Final.jar!\io\netty\handler\ssl\CipherSuiteConverter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */