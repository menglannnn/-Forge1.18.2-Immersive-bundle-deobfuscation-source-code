/*     */ package io.netty.handler.ssl;
/*     */ 
/*     */ import io.netty.util.internal.SuppressJava6Requirement;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.function.BiConsumer;
/*     */ import java.util.function.BiFunction;
/*     */ import javax.net.ssl.SSLEngine;
/*     */ import javax.net.ssl.SSLEngineResult;
/*     */ import javax.net.ssl.SSLException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @SuppressJava6Requirement(reason = "Usage guarded by java version check")
/*     */ class JdkAlpnSslEngine
/*     */   extends JdkSslEngine
/*     */ {
/*     */   private final JdkApplicationProtocolNegotiator.ProtocolSelectionListener selectionListener;
/*     */   private final AlpnSelector alpnSelector;
/*     */   
/*     */   final class AlpnSelector
/*     */     implements BiFunction<SSLEngine, List<String>, String>
/*     */   {
/*     */     private final JdkApplicationProtocolNegotiator.ProtocolSelector selector;
/*     */     private boolean called;
/*     */     
/*     */     AlpnSelector(JdkApplicationProtocolNegotiator.ProtocolSelector selector) {
/*  45 */       this.selector = selector;
/*     */     }
/*     */ 
/*     */     
/*     */     public String apply(SSLEngine sslEngine, List<String> strings) {
/*  50 */       assert !this.called;
/*  51 */       this.called = true;
/*     */       
/*     */       try {
/*  54 */         String selected = this.selector.select(strings);
/*  55 */         return (selected == null) ? "" : selected;
/*  56 */       } catch (Exception cause) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  61 */         return null;
/*     */       } 
/*     */     }
/*     */     
/*     */     void checkUnsupported() {
/*  66 */       if (this.called) {
/*     */         return;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  73 */       String protocol = JdkAlpnSslEngine.this.getApplicationProtocol();
/*  74 */       assert protocol != null;
/*     */       
/*  76 */       if (protocol.isEmpty())
/*     */       {
/*  78 */         this.selector.unsupported();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   JdkAlpnSslEngine(SSLEngine engine, JdkApplicationProtocolNegotiator applicationNegotiator, boolean isServer, BiConsumer<SSLEngine, AlpnSelector> setHandshakeApplicationProtocolSelector, BiConsumer<SSLEngine, List<String>> setApplicationProtocols) {
/*  87 */     super(engine);
/*  88 */     if (isServer) {
/*  89 */       this.selectionListener = null;
/*  90 */       this
/*  91 */         .alpnSelector = new AlpnSelector(applicationNegotiator.protocolSelectorFactory().newSelector(this, new LinkedHashSet<String>(applicationNegotiator.protocols())));
/*  92 */       setHandshakeApplicationProtocolSelector.accept(engine, this.alpnSelector);
/*     */     } else {
/*  94 */       this
/*  95 */         .selectionListener = applicationNegotiator.protocolListenerFactory().newListener(this, applicationNegotiator.protocols());
/*  96 */       this.alpnSelector = null;
/*  97 */       setApplicationProtocols.accept(engine, applicationNegotiator.protocols());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   JdkAlpnSslEngine(SSLEngine engine, JdkApplicationProtocolNegotiator applicationNegotiator, boolean isServer) {
/* 104 */     this(engine, applicationNegotiator, isServer, new BiConsumer<SSLEngine, AlpnSelector>()
/*     */         {
/*     */           public void accept(SSLEngine e, JdkAlpnSslEngine.AlpnSelector s)
/*     */           {
/* 108 */             JdkAlpnSslUtils.setHandshakeApplicationProtocolSelector(e, s);
/*     */           }
/*     */         }new BiConsumer<SSLEngine, List<String>>()
/*     */         {
/*     */           public void accept(SSLEngine e, List<String> p)
/*     */           {
/* 114 */             JdkAlpnSslUtils.setApplicationProtocols(e, p);
/*     */           }
/*     */         });
/*     */   }
/*     */   
/*     */   private SSLEngineResult verifyProtocolSelection(SSLEngineResult result) throws SSLException {
/* 120 */     if (result.getHandshakeStatus() == SSLEngineResult.HandshakeStatus.FINISHED) {
/* 121 */       if (this.alpnSelector == null) {
/*     */         
/*     */         try {
/* 124 */           String protocol = getApplicationProtocol();
/* 125 */           assert protocol != null;
/* 126 */           if (protocol.isEmpty()) {
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 131 */             this.selectionListener.unsupported();
/*     */           } else {
/* 133 */             this.selectionListener.selected(protocol);
/*     */           } 
/* 135 */         } catch (Throwable e) {
/* 136 */           throw SslUtils.toSSLHandshakeException(e);
/*     */         } 
/*     */       } else {
/* 139 */         assert this.selectionListener == null;
/* 140 */         this.alpnSelector.checkUnsupported();
/*     */       } 
/*     */     }
/* 143 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public SSLEngineResult wrap(ByteBuffer src, ByteBuffer dst) throws SSLException {
/* 148 */     return verifyProtocolSelection(super.wrap(src, dst));
/*     */   }
/*     */ 
/*     */   
/*     */   public SSLEngineResult wrap(ByteBuffer[] srcs, ByteBuffer dst) throws SSLException {
/* 153 */     return verifyProtocolSelection(super.wrap(srcs, dst));
/*     */   }
/*     */ 
/*     */   
/*     */   public SSLEngineResult wrap(ByteBuffer[] srcs, int offset, int len, ByteBuffer dst) throws SSLException {
/* 158 */     return verifyProtocolSelection(super.wrap(srcs, offset, len, dst));
/*     */   }
/*     */ 
/*     */   
/*     */   public SSLEngineResult unwrap(ByteBuffer src, ByteBuffer dst) throws SSLException {
/* 163 */     return verifyProtocolSelection(super.unwrap(src, dst));
/*     */   }
/*     */ 
/*     */   
/*     */   public SSLEngineResult unwrap(ByteBuffer src, ByteBuffer[] dsts) throws SSLException {
/* 168 */     return verifyProtocolSelection(super.unwrap(src, dsts));
/*     */   }
/*     */ 
/*     */   
/*     */   public SSLEngineResult unwrap(ByteBuffer src, ByteBuffer[] dst, int offset, int len) throws SSLException {
/* 173 */     return verifyProtocolSelection(super.unwrap(src, dst, offset, len));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void setNegotiatedApplicationProtocol(String applicationProtocol) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public String getNegotiatedApplicationProtocol() {
/* 183 */     String protocol = getApplicationProtocol();
/* 184 */     if (protocol != null) {
/* 185 */       return protocol.isEmpty() ? null : protocol;
/*     */     }
/* 187 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getApplicationProtocol() {
/* 193 */     return JdkAlpnSslUtils.getApplicationProtocol(getWrappedEngine());
/*     */   }
/*     */   
/*     */   public String getHandshakeApplicationProtocol() {
/* 197 */     return JdkAlpnSslUtils.getHandshakeApplicationProtocol(getWrappedEngine());
/*     */   }
/*     */   
/*     */   public void setHandshakeApplicationProtocolSelector(BiFunction<SSLEngine, List<String>, String> selector) {
/* 201 */     JdkAlpnSslUtils.setHandshakeApplicationProtocolSelector(getWrappedEngine(), selector);
/*     */   }
/*     */   
/*     */   public BiFunction<SSLEngine, List<String>, String> getHandshakeApplicationProtocolSelector() {
/* 205 */     return JdkAlpnSslUtils.getHandshakeApplicationProtocolSelector(getWrappedEngine());
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-handler-4.1.93.Final.jar!\io\netty\handler\ssl\JdkAlpnSslEngine.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */