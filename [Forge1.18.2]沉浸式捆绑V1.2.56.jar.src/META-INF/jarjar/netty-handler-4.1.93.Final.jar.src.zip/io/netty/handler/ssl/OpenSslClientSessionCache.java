/*     */ package io.netty.handler.ssl;
/*     */ 
/*     */ import io.netty.internal.tcnative.SSL;
/*     */ import io.netty.util.AsciiString;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class OpenSslClientSessionCache
/*     */   extends OpenSslSessionCache
/*     */ {
/*  30 */   private final Map<HostPort, OpenSslSessionCache.NativeSslSession> sessions = new HashMap<HostPort, OpenSslSessionCache.NativeSslSession>();
/*     */   
/*     */   OpenSslClientSessionCache(OpenSslEngineMap engineMap) {
/*  33 */     super(engineMap);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean sessionCreated(OpenSslSessionCache.NativeSslSession session) {
/*  38 */     assert Thread.holdsLock(this);
/*  39 */     HostPort hostPort = keyFor(session.getPeerHost(), session.getPeerPort());
/*  40 */     if (hostPort == null || this.sessions.containsKey(hostPort)) {
/*  41 */       return false;
/*     */     }
/*  43 */     this.sessions.put(hostPort, session);
/*  44 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void sessionRemoved(OpenSslSessionCache.NativeSslSession session) {
/*  49 */     assert Thread.holdsLock(this);
/*  50 */     HostPort hostPort = keyFor(session.getPeerHost(), session.getPeerPort());
/*  51 */     if (hostPort == null) {
/*     */       return;
/*     */     }
/*  54 */     this.sessions.remove(hostPort);
/*     */   }
/*     */   void setSession(long ssl, String host, int port) {
/*     */     OpenSslSessionCache.NativeSslSession session;
/*     */     boolean reused;
/*  59 */     HostPort hostPort = keyFor(host, port);
/*  60 */     if (hostPort == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/*  65 */     synchronized (this) {
/*  66 */       session = this.sessions.get(hostPort);
/*  67 */       if (session == null) {
/*     */         return;
/*     */       }
/*  70 */       if (!session.isValid()) {
/*  71 */         removeSessionWithId(session.sessionId());
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/*  76 */       reused = SSL.setSession(ssl, session.session());
/*     */     } 
/*     */     
/*  79 */     if (reused) {
/*  80 */       if (session.shouldBeSingleUse())
/*     */       {
/*  82 */         session.invalidate();
/*     */       }
/*  84 */       session.updateLastAccessedTime();
/*     */     } 
/*     */   }
/*     */   
/*     */   private static HostPort keyFor(String host, int port) {
/*  89 */     if (host == null && port < 1) {
/*  90 */       return null;
/*     */     }
/*  92 */     return new HostPort(host, port);
/*     */   }
/*     */ 
/*     */   
/*     */   synchronized void clear() {
/*  97 */     super.clear();
/*  98 */     this.sessions.clear();
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class HostPort
/*     */   {
/*     */     private final int hash;
/*     */     
/*     */     private final String host;
/*     */     private final int port;
/*     */     
/*     */     HostPort(String host, int port) {
/* 110 */       this.host = host;
/* 111 */       this.port = port;
/*     */       
/* 113 */       this.hash = 31 * AsciiString.hashCode(host) + port;
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 118 */       return this.hash;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/* 123 */       if (!(obj instanceof HostPort)) {
/* 124 */         return false;
/*     */       }
/* 126 */       HostPort other = (HostPort)obj;
/* 127 */       return (this.port == other.port && this.host.equalsIgnoreCase(other.host));
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 132 */       return "HostPort{host='" + this.host + '\'' + ", port=" + this.port + '}';
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-handler-4.1.93.Final.jar!\io\netty\handler\ssl\OpenSslClientSessionCache.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */