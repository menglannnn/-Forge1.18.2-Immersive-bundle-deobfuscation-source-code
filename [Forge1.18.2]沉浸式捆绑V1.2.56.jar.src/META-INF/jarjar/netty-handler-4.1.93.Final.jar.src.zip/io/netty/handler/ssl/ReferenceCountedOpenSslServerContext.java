/*     */ package io.netty.handler.ssl;
/*     */ 
/*     */ import io.netty.buffer.ByteBufAllocator;
/*     */ import io.netty.internal.tcnative.CertificateCallback;
/*     */ import io.netty.internal.tcnative.SSLContext;
/*     */ import io.netty.internal.tcnative.SniHostNameMatcher;
/*     */ import io.netty.util.CharsetUtil;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import io.netty.util.internal.PlatformDependent;
/*     */ import io.netty.util.internal.SuppressJava6Requirement;
/*     */ import io.netty.util.internal.logging.InternalLogger;
/*     */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*     */ import java.security.KeyStore;
/*     */ import java.security.PrivateKey;
/*     */ import java.security.cert.Certificate;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.Map;
/*     */ import javax.net.ssl.KeyManagerFactory;
/*     */ import javax.net.ssl.SSLException;
/*     */ import javax.net.ssl.SSLSessionContext;
/*     */ import javax.net.ssl.TrustManagerFactory;
/*     */ import javax.net.ssl.X509ExtendedTrustManager;
/*     */ import javax.net.ssl.X509TrustManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ReferenceCountedOpenSslServerContext
/*     */   extends ReferenceCountedOpenSslContext
/*     */ {
/*  51 */   private static final InternalLogger logger = InternalLoggerFactory.getInstance(ReferenceCountedOpenSslServerContext.class);
/*  52 */   private static final byte[] ID = new byte[] { 110, 101, 116, 116, 121 };
/*     */ 
/*     */ 
/*     */   
/*     */   private final OpenSslServerSessionContext sessionContext;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ReferenceCountedOpenSslServerContext(X509Certificate[] trustCertCollection, TrustManagerFactory trustManagerFactory, X509Certificate[] keyCertChain, PrivateKey key, String keyPassword, KeyManagerFactory keyManagerFactory, Iterable<String> ciphers, CipherSuiteFilter cipherFilter, ApplicationProtocolConfig apn, long sessionCacheSize, long sessionTimeout, ClientAuth clientAuth, String[] protocols, boolean startTls, boolean enableOcsp, String keyStore, Map.Entry<SslContextOption<?>, Object>... options) throws SSLException {
/*  62 */     this(trustCertCollection, trustManagerFactory, keyCertChain, key, keyPassword, keyManagerFactory, ciphers, cipherFilter, 
/*  63 */         toNegotiator(apn), sessionCacheSize, sessionTimeout, clientAuth, protocols, startTls, enableOcsp, keyStore, options);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ReferenceCountedOpenSslServerContext(X509Certificate[] trustCertCollection, TrustManagerFactory trustManagerFactory, X509Certificate[] keyCertChain, PrivateKey key, String keyPassword, KeyManagerFactory keyManagerFactory, Iterable<String> ciphers, CipherSuiteFilter cipherFilter, OpenSslApplicationProtocolNegotiator apn, long sessionCacheSize, long sessionTimeout, ClientAuth clientAuth, String[] protocols, boolean startTls, boolean enableOcsp, String keyStore, Map.Entry<SslContextOption<?>, Object>... options) throws SSLException {
/*  74 */     super(ciphers, cipherFilter, apn, 1, (Certificate[])keyCertChain, clientAuth, protocols, startTls, enableOcsp, true, options);
/*     */ 
/*     */     
/*  77 */     boolean success = false;
/*     */     try {
/*  79 */       this.sessionContext = newSessionContext(this, this.ctx, this.engineMap, trustCertCollection, trustManagerFactory, keyCertChain, key, keyPassword, keyManagerFactory, keyStore, sessionCacheSize, sessionTimeout);
/*     */ 
/*     */       
/*  82 */       if (SERVER_ENABLE_SESSION_TICKET) {
/*  83 */         this.sessionContext.setTicketKeys(new OpenSslSessionTicketKey[0]);
/*     */       }
/*  85 */       success = true;
/*     */     } finally {
/*  87 */       if (!success) {
/*  88 */         release();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public OpenSslServerSessionContext sessionContext() {
/*  95 */     return this.sessionContext;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static OpenSslServerSessionContext newSessionContext(ReferenceCountedOpenSslContext thiz, long ctx, OpenSslEngineMap engineMap, X509Certificate[] trustCertCollection, TrustManagerFactory trustManagerFactory, X509Certificate[] keyCertChain, PrivateKey key, String keyPassword, KeyManagerFactory keyManagerFactory, String keyStore, long sessionCacheSize, long sessionTimeout) throws SSLException {
/* 106 */     OpenSslKeyMaterialProvider keyMaterialProvider = null;
/*     */     try {
/*     */       try {
/* 109 */         SSLContext.setVerify(ctx, 0, 10);
/* 110 */         if (!OpenSsl.useKeyManagerFactory()) {
/* 111 */           if (keyManagerFactory != null) {
/* 112 */             throw new IllegalArgumentException("KeyManagerFactory not supported");
/*     */           }
/*     */           
/* 115 */           ObjectUtil.checkNotNull(keyCertChain, "keyCertChain");
/*     */           
/* 117 */           setKeyMaterial(ctx, keyCertChain, key, keyPassword);
/*     */         }
/*     */         else {
/*     */           
/* 121 */           if (keyManagerFactory == null) {
/* 122 */             char[] keyPasswordChars = keyStorePassword(keyPassword);
/* 123 */             KeyStore ks = buildKeyStore(keyCertChain, key, keyPasswordChars, keyStore);
/* 124 */             if (ks.aliases().hasMoreElements()) {
/* 125 */               keyManagerFactory = new OpenSslX509KeyManagerFactory();
/*     */             } else {
/*     */               
/* 128 */               keyManagerFactory = new OpenSslCachingX509KeyManagerFactory(KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm()));
/*     */             } 
/* 130 */             keyManagerFactory.init(ks, keyPasswordChars);
/*     */           } 
/* 132 */           keyMaterialProvider = providerFor(keyManagerFactory, keyPassword);
/*     */           
/* 134 */           SSLContext.setCertificateCallback(ctx, new OpenSslServerCertificateCallback(engineMap, new OpenSslKeyMaterialManager(keyMaterialProvider)));
/*     */         }
/*     */       
/* 137 */       } catch (Exception e) {
/* 138 */         throw new SSLException("failed to set certificate and key", e);
/*     */       } 
/*     */       try {
/* 141 */         if (trustCertCollection != null) {
/* 142 */           trustManagerFactory = buildTrustManagerFactory(trustCertCollection, trustManagerFactory, keyStore);
/* 143 */         } else if (trustManagerFactory == null) {
/*     */           
/* 145 */           trustManagerFactory = TrustManagerFactory.getInstance(
/* 146 */               TrustManagerFactory.getDefaultAlgorithm());
/* 147 */           trustManagerFactory.init((KeyStore)null);
/*     */         } 
/*     */         
/* 150 */         X509TrustManager manager = chooseTrustManager(trustManagerFactory.getTrustManagers());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 158 */         setVerifyCallback(ctx, engineMap, manager);
/*     */         
/* 160 */         X509Certificate[] issuers = manager.getAcceptedIssuers();
/* 161 */         if (issuers != null && issuers.length > 0) {
/* 162 */           long bio = 0L;
/*     */           try {
/* 164 */             bio = toBIO(ByteBufAllocator.DEFAULT, issuers);
/* 165 */             if (!SSLContext.setCACertificateBio(ctx, bio)) {
/* 166 */               throw new SSLException("unable to setup accepted issuers for trustmanager " + manager);
/*     */             }
/*     */           } finally {
/* 169 */             freeBio(bio);
/*     */           } 
/*     */         } 
/*     */         
/* 173 */         if (PlatformDependent.javaVersion() >= 8)
/*     */         {
/*     */ 
/*     */ 
/*     */           
/* 178 */           SSLContext.setSniHostnameMatcher(ctx, new OpenSslSniHostnameMatcher(engineMap));
/*     */         }
/* 180 */       } catch (SSLException e) {
/* 181 */         throw e;
/* 182 */       } catch (Exception e) {
/* 183 */         throw new SSLException("unable to setup trustmanager", e);
/*     */       } 
/*     */       
/* 186 */       OpenSslServerSessionContext sessionContext = new OpenSslServerSessionContext(thiz, keyMaterialProvider);
/* 187 */       sessionContext.setSessionIdContext(ID);
/*     */       
/* 189 */       sessionContext.setSessionCacheEnabled(SERVER_ENABLE_SESSION_CACHE);
/* 190 */       if (sessionCacheSize > 0L) {
/* 191 */         sessionContext.setSessionCacheSize((int)Math.min(sessionCacheSize, 2147483647L));
/*     */       }
/* 193 */       if (sessionTimeout > 0L) {
/* 194 */         sessionContext.setSessionTimeout((int)Math.min(sessionTimeout, 2147483647L));
/*     */       }
/*     */       
/* 197 */       keyMaterialProvider = null;
/*     */       
/* 199 */       return sessionContext;
/*     */     } finally {
/* 201 */       if (keyMaterialProvider != null) {
/* 202 */         keyMaterialProvider.destroy();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @SuppressJava6Requirement(reason = "Guarded by java version check")
/*     */   private static void setVerifyCallback(long ctx, OpenSslEngineMap engineMap, X509TrustManager manager) {
/* 210 */     if (useExtendedTrustManager(manager)) {
/* 211 */       SSLContext.setCertVerifyCallback(ctx, new ExtendedTrustManagerVerifyCallback(engineMap, (X509ExtendedTrustManager)manager));
/*     */     } else {
/*     */       
/* 214 */       SSLContext.setCertVerifyCallback(ctx, new TrustManagerVerifyCallback(engineMap, manager));
/*     */     } 
/*     */   }
/*     */   
/*     */   private static final class OpenSslServerCertificateCallback implements CertificateCallback {
/*     */     private final OpenSslEngineMap engineMap;
/*     */     private final OpenSslKeyMaterialManager keyManagerHolder;
/*     */     
/*     */     OpenSslServerCertificateCallback(OpenSslEngineMap engineMap, OpenSslKeyMaterialManager keyManagerHolder) {
/* 223 */       this.engineMap = engineMap;
/* 224 */       this.keyManagerHolder = keyManagerHolder;
/*     */     }
/*     */ 
/*     */     
/*     */     public void handle(long ssl, byte[] keyTypeBytes, byte[][] asn1DerEncodedPrincipals) throws Exception {
/* 229 */       ReferenceCountedOpenSslEngine engine = this.engineMap.get(ssl);
/* 230 */       if (engine == null) {
/*     */         return;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 237 */         this.keyManagerHolder.setKeyMaterialServerSide(engine);
/* 238 */       } catch (Throwable cause) {
/* 239 */         engine.initHandshakeException(cause);
/*     */         
/* 241 */         if (cause instanceof Exception) {
/* 242 */           throw (Exception)cause;
/*     */         }
/* 244 */         throw new SSLException(cause);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class TrustManagerVerifyCallback extends ReferenceCountedOpenSslContext.AbstractCertificateVerifier {
/*     */     private final X509TrustManager manager;
/*     */     
/*     */     TrustManagerVerifyCallback(OpenSslEngineMap engineMap, X509TrustManager manager) {
/* 253 */       super(engineMap);
/* 254 */       this.manager = manager;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     void verify(ReferenceCountedOpenSslEngine engine, X509Certificate[] peerCerts, String auth) throws Exception {
/* 260 */       this.manager.checkClientTrusted(peerCerts, auth);
/*     */     }
/*     */   }
/*     */   
/*     */   @SuppressJava6Requirement(reason = "Usage guarded by java version check")
/*     */   private static final class ExtendedTrustManagerVerifyCallback extends ReferenceCountedOpenSslContext.AbstractCertificateVerifier {
/*     */     private final X509ExtendedTrustManager manager;
/*     */     
/*     */     ExtendedTrustManagerVerifyCallback(OpenSslEngineMap engineMap, X509ExtendedTrustManager manager) {
/* 269 */       super(engineMap);
/* 270 */       this.manager = manager;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     void verify(ReferenceCountedOpenSslEngine engine, X509Certificate[] peerCerts, String auth) throws Exception {
/* 276 */       this.manager.checkClientTrusted(peerCerts, auth, engine);
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class OpenSslSniHostnameMatcher implements SniHostNameMatcher {
/*     */     private final OpenSslEngineMap engineMap;
/*     */     
/*     */     OpenSslSniHostnameMatcher(OpenSslEngineMap engineMap) {
/* 284 */       this.engineMap = engineMap;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean match(long ssl, String hostname) {
/* 289 */       ReferenceCountedOpenSslEngine engine = this.engineMap.get(ssl);
/* 290 */       if (engine != null)
/*     */       {
/* 292 */         return engine.checkSniHostnameMatch(hostname.getBytes(CharsetUtil.UTF_8));
/*     */       }
/* 294 */       ReferenceCountedOpenSslServerContext.logger.warn("No ReferenceCountedOpenSslEngine found for SSL pointer: {}", Long.valueOf(ssl));
/* 295 */       return false;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-handler-4.1.93.Final.jar!\io\netty\handler\ssl\ReferenceCountedOpenSslServerContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */