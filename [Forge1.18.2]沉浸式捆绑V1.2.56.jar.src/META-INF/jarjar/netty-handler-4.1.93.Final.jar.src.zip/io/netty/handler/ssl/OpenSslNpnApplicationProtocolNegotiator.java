/*    */ package io.netty.handler.ssl;
/*    */ 
/*    */ import io.netty.util.internal.ObjectUtil;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public final class OpenSslNpnApplicationProtocolNegotiator
/*    */   implements OpenSslApplicationProtocolNegotiator
/*    */ {
/*    */   private final List<String> protocols;
/*    */   
/*    */   public OpenSslNpnApplicationProtocolNegotiator(Iterable<String> protocols) {
/* 33 */     this.protocols = (List<String>)ObjectUtil.checkNotNull(ApplicationProtocolUtil.toList(protocols), "protocols");
/*    */   }
/*    */   
/*    */   public OpenSslNpnApplicationProtocolNegotiator(String... protocols) {
/* 37 */     this.protocols = (List<String>)ObjectUtil.checkNotNull(ApplicationProtocolUtil.toList(protocols), "protocols");
/*    */   }
/*    */ 
/*    */   
/*    */   public ApplicationProtocolConfig.Protocol protocol() {
/* 42 */     return ApplicationProtocolConfig.Protocol.NPN;
/*    */   }
/*    */ 
/*    */   
/*    */   public List<String> protocols() {
/* 47 */     return this.protocols;
/*    */   }
/*    */ 
/*    */   
/*    */   public ApplicationProtocolConfig.SelectorFailureBehavior selectorFailureBehavior() {
/* 52 */     return ApplicationProtocolConfig.SelectorFailureBehavior.CHOOSE_MY_LAST_PROTOCOL;
/*    */   }
/*    */ 
/*    */   
/*    */   public ApplicationProtocolConfig.SelectedListenerFailureBehavior selectedListenerFailureBehavior() {
/* 57 */     return ApplicationProtocolConfig.SelectedListenerFailureBehavior.ACCEPT;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-handler-4.1.93.Final.jar!\io\netty\handler\ssl\OpenSslNpnApplicationProtocolNegotiator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */