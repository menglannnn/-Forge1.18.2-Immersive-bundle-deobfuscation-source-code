/*    */ package io.netty.handler.ssl;
/*    */ 
/*    */ import io.netty.util.internal.SuppressJava6Requirement;
/*    */ import java.security.AlgorithmConstraints;
/*    */ import javax.net.ssl.SSLParameters;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class Java7SslParametersUtils
/*    */ {
/*    */   @SuppressJava6Requirement(reason = "Usage guarded by java version check")
/*    */   static void setAlgorithmConstraints(SSLParameters sslParameters, Object algorithmConstraints) {
/* 36 */     sslParameters.setAlgorithmConstraints((AlgorithmConstraints)algorithmConstraints);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-handler-4.1.93.Final.jar!\io\netty\handler\ssl\Java7SslParametersUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */