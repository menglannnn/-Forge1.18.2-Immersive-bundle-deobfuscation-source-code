/*     */ package io.netty.handler.ssl;
/*     */ 
/*     */ import io.netty.buffer.ByteBufAllocator;
/*     */ import java.util.List;
/*     */ import javax.net.ssl.SSLEngine;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public final class JdkAlpnApplicationProtocolNegotiator
/*     */   extends JdkBaseApplicationProtocolNegotiator
/*     */ {
/*  29 */   private static final boolean AVAILABLE = (Conscrypt.isAvailable() || 
/*  30 */     JdkAlpnSslUtils.supportsAlpn() || 
/*  31 */     JettyAlpnSslEngine.isAvailable() || 
/*  32 */     BouncyCastle.isAvailable());
/*     */   
/*  34 */   private static final JdkApplicationProtocolNegotiator.SslEngineWrapperFactory ALPN_WRAPPER = AVAILABLE ? new AlpnWrapper() : new FailureWrapper();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JdkAlpnApplicationProtocolNegotiator(Iterable<String> protocols) {
/*  41 */     this(false, protocols);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JdkAlpnApplicationProtocolNegotiator(String... protocols) {
/*  49 */     this(false, protocols);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JdkAlpnApplicationProtocolNegotiator(boolean failIfNoCommonProtocols, Iterable<String> protocols) {
/*  58 */     this(failIfNoCommonProtocols, failIfNoCommonProtocols, protocols);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JdkAlpnApplicationProtocolNegotiator(boolean failIfNoCommonProtocols, String... protocols) {
/*  67 */     this(failIfNoCommonProtocols, failIfNoCommonProtocols, protocols);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JdkAlpnApplicationProtocolNegotiator(boolean clientFailIfNoCommonProtocols, boolean serverFailIfNoCommonProtocols, Iterable<String> protocols) {
/*  78 */     this(serverFailIfNoCommonProtocols ? FAIL_SELECTOR_FACTORY : NO_FAIL_SELECTOR_FACTORY, clientFailIfNoCommonProtocols ? FAIL_SELECTION_LISTENER_FACTORY : NO_FAIL_SELECTION_LISTENER_FACTORY, protocols);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JdkAlpnApplicationProtocolNegotiator(boolean clientFailIfNoCommonProtocols, boolean serverFailIfNoCommonProtocols, String... protocols) {
/*  91 */     this(serverFailIfNoCommonProtocols ? FAIL_SELECTOR_FACTORY : NO_FAIL_SELECTOR_FACTORY, clientFailIfNoCommonProtocols ? FAIL_SELECTION_LISTENER_FACTORY : NO_FAIL_SELECTION_LISTENER_FACTORY, protocols);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JdkAlpnApplicationProtocolNegotiator(JdkApplicationProtocolNegotiator.ProtocolSelectorFactory selectorFactory, JdkApplicationProtocolNegotiator.ProtocolSelectionListenerFactory listenerFactory, Iterable<String> protocols) {
/* 104 */     super(ALPN_WRAPPER, selectorFactory, listenerFactory, protocols);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JdkAlpnApplicationProtocolNegotiator(JdkApplicationProtocolNegotiator.ProtocolSelectorFactory selectorFactory, JdkApplicationProtocolNegotiator.ProtocolSelectionListenerFactory listenerFactory, String... protocols) {
/* 115 */     super(ALPN_WRAPPER, selectorFactory, listenerFactory, protocols);
/*     */   }
/*     */   
/*     */   private static final class FailureWrapper extends JdkApplicationProtocolNegotiator.AllocatorAwareSslEngineWrapperFactory {
/*     */     private FailureWrapper() {}
/*     */     
/*     */     public SSLEngine wrapSslEngine(SSLEngine engine, ByteBufAllocator alloc, JdkApplicationProtocolNegotiator applicationNegotiator, boolean isServer) {
/* 122 */       throw new RuntimeException("ALPN unsupported. Is your classpath configured correctly? For Conscrypt, add the appropriate Conscrypt JAR to classpath and set the security provider. For Jetty-ALPN, see https://www.eclipse.org/jetty/documentation/current/alpn-chapter.html#alpn-starting");
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class AlpnWrapper
/*     */     extends JdkApplicationProtocolNegotiator.AllocatorAwareSslEngineWrapperFactory
/*     */   {
/*     */     private AlpnWrapper() {}
/*     */     
/*     */     public SSLEngine wrapSslEngine(SSLEngine engine, ByteBufAllocator alloc, JdkApplicationProtocolNegotiator applicationNegotiator, boolean isServer) {
/* 133 */       if (Conscrypt.isEngineSupported(engine)) {
/* 134 */         return isServer ? ConscryptAlpnSslEngine.newServerEngine(engine, alloc, applicationNegotiator) : 
/* 135 */           ConscryptAlpnSslEngine.newClientEngine(engine, alloc, applicationNegotiator);
/*     */       }
/* 137 */       if (BouncyCastle.isInUse(engine)) {
/* 138 */         return new BouncyCastleAlpnSslEngine(engine, applicationNegotiator, isServer);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 144 */       if (JdkAlpnSslUtils.supportsAlpn()) {
/* 145 */         return new JdkAlpnSslEngine(engine, applicationNegotiator, isServer);
/*     */       }
/* 147 */       if (JettyAlpnSslEngine.isAvailable()) {
/* 148 */         return isServer ? JettyAlpnSslEngine.newServerEngine(engine, applicationNegotiator) : 
/* 149 */           JettyAlpnSslEngine.newClientEngine(engine, applicationNegotiator);
/*     */       }
/* 151 */       throw new UnsupportedOperationException("ALPN not supported. Unable to wrap SSLEngine of type '" + engine
/* 152 */           .getClass().getName() + "')");
/*     */     }
/*     */   }
/*     */   
/*     */   static boolean isAlpnSupported() {
/* 157 */     return AVAILABLE;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-handler-4.1.93.Final.jar!\io\netty\handler\ssl\JdkAlpnApplicationProtocolNegotiator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */