/*     */ package io.netty.handler.ssl;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.buffer.Unpooled;
/*     */ import io.netty.handler.codec.base64.Base64;
/*     */ import io.netty.util.CharsetUtil;
/*     */ import io.netty.util.internal.logging.InternalLogger;
/*     */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.security.KeyException;
/*     */ import java.security.cert.CertificateException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class PemReader
/*     */ {
/*  46 */   private static final InternalLogger logger = InternalLoggerFactory.getInstance(PemReader.class);
/*     */   
/*  48 */   private static final Pattern CERT_HEADER = Pattern.compile("-+BEGIN\\s[^-\\r\\n]*CERTIFICATE[^-\\r\\n]*-+(?:\\s|\\r|\\n)+");
/*     */   
/*  50 */   private static final Pattern CERT_FOOTER = Pattern.compile("-+END\\s[^-\\r\\n]*CERTIFICATE[^-\\r\\n]*-+(?:\\s|\\r|\\n)*");
/*     */   
/*  52 */   private static final Pattern KEY_HEADER = Pattern.compile("-+BEGIN\\s[^-\\r\\n]*PRIVATE\\s+KEY[^-\\r\\n]*-+(?:\\s|\\r|\\n)+");
/*     */   
/*  54 */   private static final Pattern KEY_FOOTER = Pattern.compile("-+END\\s[^-\\r\\n]*PRIVATE\\s+KEY[^-\\r\\n]*-+(?:\\s|\\r|\\n)*");
/*     */   
/*  56 */   private static final Pattern BODY = Pattern.compile("[a-z0-9+/=][a-z0-9+/=\\r\\n]*", 2);
/*     */   
/*     */   static ByteBuf[] readCertificates(File file) throws CertificateException {
/*     */     try {
/*  60 */       InputStream in = new FileInputStream(file);
/*     */       
/*     */       try {
/*  63 */         return readCertificates(in);
/*     */       } finally {
/*  65 */         safeClose(in);
/*     */       } 
/*  67 */     } catch (FileNotFoundException e) {
/*  68 */       throw new CertificateException("could not find certificate file: " + file);
/*     */     } 
/*     */   }
/*     */   
/*     */   static ByteBuf[] readCertificates(InputStream in) throws CertificateException {
/*     */     String content;
/*     */     try {
/*  75 */       content = readContent(in);
/*  76 */     } catch (IOException e) {
/*  77 */       throw new CertificateException("failed to read certificate input stream", e);
/*     */     } 
/*     */     
/*  80 */     List<ByteBuf> certs = new ArrayList<ByteBuf>();
/*  81 */     Matcher m = CERT_HEADER.matcher(content);
/*  82 */     int start = 0;
/*     */     
/*  84 */     while (m.find(start)) {
/*     */ 
/*     */       
/*  87 */       m.usePattern(BODY);
/*  88 */       if (!m.find()) {
/*     */         break;
/*     */       }
/*     */       
/*  92 */       ByteBuf base64 = Unpooled.copiedBuffer(m.group(0), CharsetUtil.US_ASCII);
/*  93 */       m.usePattern(CERT_FOOTER);
/*  94 */       if (!m.find()) {
/*     */         break;
/*     */       }
/*     */       
/*  98 */       ByteBuf der = Base64.decode(base64);
/*  99 */       base64.release();
/* 100 */       certs.add(der);
/*     */       
/* 102 */       start = m.end();
/* 103 */       m.usePattern(CERT_HEADER);
/*     */     } 
/*     */     
/* 106 */     if (certs.isEmpty()) {
/* 107 */       throw new CertificateException("found no certificates in input stream");
/*     */     }
/*     */     
/* 110 */     return certs.<ByteBuf>toArray(new ByteBuf[0]);
/*     */   }
/*     */   
/*     */   static ByteBuf readPrivateKey(File file) throws KeyException {
/*     */     try {
/* 115 */       InputStream in = new FileInputStream(file);
/*     */       
/*     */       try {
/* 118 */         return readPrivateKey(in);
/*     */       } finally {
/* 120 */         safeClose(in);
/*     */       } 
/* 122 */     } catch (FileNotFoundException e) {
/* 123 */       throw new KeyException("could not find key file: " + file);
/*     */     } 
/*     */   }
/*     */   
/*     */   static ByteBuf readPrivateKey(InputStream in) throws KeyException {
/*     */     String content;
/*     */     try {
/* 130 */       content = readContent(in);
/* 131 */     } catch (IOException e) {
/* 132 */       throw new KeyException("failed to read key input stream", e);
/*     */     } 
/*     */     
/* 135 */     Matcher m = KEY_HEADER.matcher(content);
/* 136 */     if (!m.find()) {
/* 137 */       throw keyNotFoundException();
/*     */     }
/* 139 */     m.usePattern(BODY);
/* 140 */     if (!m.find()) {
/* 141 */       throw keyNotFoundException();
/*     */     }
/*     */     
/* 144 */     ByteBuf base64 = Unpooled.copiedBuffer(m.group(0), CharsetUtil.US_ASCII);
/* 145 */     m.usePattern(KEY_FOOTER);
/* 146 */     if (!m.find())
/*     */     {
/* 148 */       throw keyNotFoundException();
/*     */     }
/* 150 */     ByteBuf der = Base64.decode(base64);
/* 151 */     base64.release();
/* 152 */     return der;
/*     */   }
/*     */   
/*     */   private static KeyException keyNotFoundException() {
/* 156 */     return new KeyException("could not find a PKCS #8 private key in input stream (see https://netty.io/wiki/sslcontextbuilder-and-private-key.html for more information)");
/*     */   }
/*     */ 
/*     */   
/*     */   private static String readContent(InputStream in) throws IOException {
/* 161 */     ByteArrayOutputStream out = new ByteArrayOutputStream();
/*     */     try {
/* 163 */       byte[] buf = new byte[8192];
/*     */       while (true) {
/* 165 */         int ret = in.read(buf);
/* 166 */         if (ret < 0) {
/*     */           break;
/*     */         }
/* 169 */         out.write(buf, 0, ret);
/*     */       } 
/* 171 */       return out.toString(CharsetUtil.US_ASCII.name());
/*     */     } finally {
/* 173 */       safeClose(out);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void safeClose(InputStream in) {
/*     */     try {
/* 179 */       in.close();
/* 180 */     } catch (IOException e) {
/* 181 */       logger.warn("Failed to close a stream.", e);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void safeClose(OutputStream out) {
/*     */     try {
/* 187 */       out.close();
/* 188 */     } catch (IOException e) {
/* 189 */       logger.warn("Failed to close a stream.", e);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-handler-4.1.93.Final.jar!\io\netty\handler\ssl\PemReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */