/*     */ package io.netty.handler.ssl;
/*     */ 
/*     */ import io.netty.buffer.ByteBufAllocator;
/*     */ import io.netty.channel.ChannelHandler;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.handler.codec.DecoderException;
/*     */ import io.netty.util.AsyncMapping;
/*     */ import io.netty.util.DomainNameMapping;
/*     */ import io.netty.util.Mapping;
/*     */ import io.netty.util.ReferenceCountUtil;
/*     */ import io.netty.util.concurrent.Future;
/*     */ import io.netty.util.concurrent.Promise;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import io.netty.util.internal.PlatformDependent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SniHandler
/*     */   extends AbstractSniHandler<SslContext>
/*     */ {
/*  38 */   private static final Selection EMPTY_SELECTION = new Selection(null, null);
/*     */   
/*     */   protected final AsyncMapping<String, SslContext> mapping;
/*     */   
/*  42 */   private volatile Selection selection = EMPTY_SELECTION;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SniHandler(Mapping<? super String, ? extends SslContext> mapping) {
/*  51 */     this(new AsyncMappingAdapter(mapping, null));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SniHandler(Mapping<? super String, ? extends SslContext> mapping, long handshakeTimeoutMillis) {
/*  62 */     this(new AsyncMappingAdapter(mapping, null), handshakeTimeoutMillis);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SniHandler(DomainNameMapping<? extends SslContext> mapping) {
/*  72 */     this((Mapping)mapping);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SniHandler(AsyncMapping<? super String, ? extends SslContext> mapping) {
/*  83 */     this(mapping, 0L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SniHandler(AsyncMapping<? super String, ? extends SslContext> mapping, long handshakeTimeoutMillis) {
/*  95 */     super(handshakeTimeoutMillis);
/*  96 */     this.mapping = (AsyncMapping<String, SslContext>)ObjectUtil.checkNotNull(mapping, "mapping");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String hostname() {
/* 103 */     return this.selection.hostname;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SslContext sslContext() {
/* 110 */     return this.selection.context;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Future<SslContext> lookup(ChannelHandlerContext ctx, String hostname) throws Exception {
/* 121 */     return this.mapping.map(hostname, ctx.executor().newPromise());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void onLookupComplete(ChannelHandlerContext ctx, String hostname, Future<SslContext> future) throws Exception {
/* 127 */     if (!future.isSuccess()) {
/* 128 */       Throwable cause = future.cause();
/* 129 */       if (cause instanceof Error) {
/* 130 */         throw (Error)cause;
/*     */       }
/* 132 */       throw new DecoderException("failed to get the SslContext for " + hostname, cause);
/*     */     } 
/*     */     
/* 135 */     SslContext sslContext = (SslContext)future.getNow();
/* 136 */     this.selection = new Selection(sslContext, hostname);
/*     */     try {
/* 138 */       replaceHandler(ctx, hostname, sslContext);
/* 139 */     } catch (Throwable cause) {
/* 140 */       this.selection = EMPTY_SELECTION;
/* 141 */       PlatformDependent.throwException(cause);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void replaceHandler(ChannelHandlerContext ctx, String hostname, SslContext sslContext) throws Exception {
/* 155 */     SslHandler sslHandler = null;
/*     */     try {
/* 157 */       sslHandler = newSslHandler(sslContext, ctx.alloc());
/* 158 */       ctx.pipeline().replace((ChannelHandler)this, SslHandler.class.getName(), (ChannelHandler)sslHandler);
/* 159 */       sslHandler = null;
/*     */     
/*     */     }
/*     */     finally {
/*     */       
/* 164 */       if (sslHandler != null) {
/* 165 */         ReferenceCountUtil.safeRelease(sslHandler.engine());
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SslHandler newSslHandler(SslContext context, ByteBufAllocator allocator) {
/* 175 */     SslHandler sslHandler = context.newHandler(allocator);
/* 176 */     sslHandler.setHandshakeTimeoutMillis(this.handshakeTimeoutMillis);
/* 177 */     return sslHandler;
/*     */   }
/*     */   
/*     */   private static final class AsyncMappingAdapter implements AsyncMapping<String, SslContext> {
/*     */     private final Mapping<? super String, ? extends SslContext> mapping;
/*     */     
/*     */     private AsyncMappingAdapter(Mapping<? super String, ? extends SslContext> mapping) {
/* 184 */       this.mapping = (Mapping<? super String, ? extends SslContext>)ObjectUtil.checkNotNull(mapping, "mapping");
/*     */     }
/*     */ 
/*     */     
/*     */     public Future<SslContext> map(String input, Promise<SslContext> promise) {
/*     */       SslContext context;
/*     */       try {
/* 191 */         context = (SslContext)this.mapping.map(input);
/* 192 */       } catch (Throwable cause) {
/* 193 */         return (Future<SslContext>)promise.setFailure(cause);
/*     */       } 
/* 195 */       return (Future<SslContext>)promise.setSuccess(context);
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class Selection {
/*     */     final SslContext context;
/*     */     final String hostname;
/*     */     
/*     */     Selection(SslContext context, String hostname) {
/* 204 */       this.context = context;
/* 205 */       this.hostname = hostname;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-handler-4.1.93.Final.jar!\io\netty\handler\ssl\SniHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */