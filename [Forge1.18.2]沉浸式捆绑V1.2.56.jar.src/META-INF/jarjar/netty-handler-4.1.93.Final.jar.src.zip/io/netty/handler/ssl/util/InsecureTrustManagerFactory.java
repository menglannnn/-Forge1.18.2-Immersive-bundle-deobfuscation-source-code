/*    */ package io.netty.handler.ssl.util;
/*    */ 
/*    */ import io.netty.util.internal.EmptyArrays;
/*    */ import io.netty.util.internal.logging.InternalLogger;
/*    */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*    */ import java.security.KeyStore;
/*    */ import java.security.cert.X509Certificate;
/*    */ import javax.net.ssl.ManagerFactoryParameters;
/*    */ import javax.net.ssl.TrustManager;
/*    */ import javax.net.ssl.TrustManagerFactory;
/*    */ import javax.net.ssl.X509TrustManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class InsecureTrustManagerFactory
/*    */   extends SimpleTrustManagerFactory
/*    */ {
/* 40 */   private static final InternalLogger logger = InternalLoggerFactory.getInstance(InsecureTrustManagerFactory.class);
/*    */   
/* 42 */   public static final TrustManagerFactory INSTANCE = new InsecureTrustManagerFactory();
/*    */   
/* 44 */   private static final TrustManager tm = new X509TrustManager()
/*    */     {
/*    */       public void checkClientTrusted(X509Certificate[] chain, String s) {
/* 47 */         if (InsecureTrustManagerFactory.logger.isDebugEnabled()) {
/* 48 */           InsecureTrustManagerFactory.logger.debug("Accepting a client certificate: " + chain[0].getSubjectDN());
/*    */         }
/*    */       }
/*    */ 
/*    */       
/*    */       public void checkServerTrusted(X509Certificate[] chain, String s) {
/* 54 */         if (InsecureTrustManagerFactory.logger.isDebugEnabled()) {
/* 55 */           InsecureTrustManagerFactory.logger.debug("Accepting a server certificate: " + chain[0].getSubjectDN());
/*    */         }
/*    */       }
/*    */ 
/*    */       
/*    */       public X509Certificate[] getAcceptedIssuers() {
/* 61 */         return EmptyArrays.EMPTY_X509_CERTIFICATES;
/*    */       }
/*    */     };
/*    */ 
/*    */ 
/*    */   
/*    */   protected void engineInit(KeyStore keyStore) throws Exception {}
/*    */ 
/*    */ 
/*    */   
/*    */   protected void engineInit(ManagerFactoryParameters managerFactoryParameters) throws Exception {}
/*    */ 
/*    */   
/*    */   protected TrustManager[] engineGetTrustManagers() {
/* 75 */     return new TrustManager[] { tm };
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-handler-4.1.93.Final.jar!\io\netty\handler\ss\\util\InsecureTrustManagerFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */