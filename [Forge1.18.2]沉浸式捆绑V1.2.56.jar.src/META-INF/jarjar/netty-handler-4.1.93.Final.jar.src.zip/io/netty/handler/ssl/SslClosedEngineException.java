/*    */ package io.netty.handler.ssl;
/*    */ 
/*    */ import javax.net.ssl.SSLException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SslClosedEngineException
/*    */   extends SSLException
/*    */ {
/*    */   private static final long serialVersionUID = -5204207600474401904L;
/*    */   
/*    */   public SslClosedEngineException(String reason) {
/* 29 */     super(reason);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-handler-4.1.93.Final.jar!\io\netty\handler\ssl\SslClosedEngineException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */