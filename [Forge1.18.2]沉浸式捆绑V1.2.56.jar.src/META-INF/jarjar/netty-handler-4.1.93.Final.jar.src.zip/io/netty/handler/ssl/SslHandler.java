/*      */ package io.netty.handler.ssl;
/*      */ 
/*      */ import io.netty.buffer.ByteBuf;
/*      */ import io.netty.buffer.ByteBufAllocator;
/*      */ import io.netty.buffer.ByteBufUtil;
/*      */ import io.netty.buffer.CompositeByteBuf;
/*      */ import io.netty.buffer.Unpooled;
/*      */ import io.netty.channel.AbstractCoalescingBufferQueue;
/*      */ import io.netty.channel.Channel;
/*      */ import io.netty.channel.ChannelException;
/*      */ import io.netty.channel.ChannelFuture;
/*      */ import io.netty.channel.ChannelFutureListener;
/*      */ import io.netty.channel.ChannelHandlerContext;
/*      */ import io.netty.channel.ChannelOption;
/*      */ import io.netty.channel.ChannelOutboundBuffer;
/*      */ import io.netty.channel.ChannelOutboundHandler;
/*      */ import io.netty.channel.ChannelOutboundInvoker;
/*      */ import io.netty.channel.ChannelPromise;
/*      */ import io.netty.channel.unix.UnixChannel;
/*      */ import io.netty.handler.codec.ByteToMessageDecoder;
/*      */ import io.netty.handler.codec.DecoderException;
/*      */ import io.netty.handler.codec.UnsupportedMessageTypeException;
/*      */ import io.netty.util.ReferenceCountUtil;
/*      */ import io.netty.util.concurrent.DefaultPromise;
/*      */ import io.netty.util.concurrent.EventExecutor;
/*      */ import io.netty.util.concurrent.Future;
/*      */ import io.netty.util.concurrent.FutureListener;
/*      */ import io.netty.util.concurrent.GenericFutureListener;
/*      */ import io.netty.util.concurrent.ImmediateExecutor;
/*      */ import io.netty.util.concurrent.Promise;
/*      */ import io.netty.util.concurrent.PromiseNotifier;
/*      */ import io.netty.util.concurrent.ScheduledFuture;
/*      */ import io.netty.util.internal.ObjectUtil;
/*      */ import io.netty.util.internal.PlatformDependent;
/*      */ import io.netty.util.internal.ThrowableUtil;
/*      */ import io.netty.util.internal.logging.InternalLogger;
/*      */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*      */ import java.net.SocketAddress;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.nio.channels.ClosedChannelException;
/*      */ import java.nio.channels.DatagramChannel;
/*      */ import java.nio.channels.SocketChannel;
/*      */ import java.util.List;
/*      */ import java.util.concurrent.Executor;
/*      */ import java.util.concurrent.RejectedExecutionException;
/*      */ import java.util.concurrent.TimeUnit;
/*      */ import java.util.regex.Pattern;
/*      */ import javax.net.ssl.SSLEngine;
/*      */ import javax.net.ssl.SSLEngineResult;
/*      */ import javax.net.ssl.SSLException;
/*      */ import javax.net.ssl.SSLHandshakeException;
/*      */ import javax.net.ssl.SSLSession;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class SslHandler
/*      */   extends ByteToMessageDecoder
/*      */   implements ChannelOutboundHandler
/*      */ {
/*  172 */   private static final InternalLogger logger = InternalLoggerFactory.getInstance(SslHandler.class);
/*  173 */   private static final Pattern IGNORABLE_CLASS_IN_STACK = Pattern.compile("^.*(?:Socket|Datagram|Sctp|Udt)Channel.*$");
/*      */   
/*  175 */   private static final Pattern IGNORABLE_ERROR_MESSAGE = Pattern.compile("^.*(?:connection.*(?:reset|closed|abort|broken)|broken.*pipe).*$", 2);
/*      */   
/*      */   private static final int STATE_SENT_FIRST_MESSAGE = 1;
/*      */   
/*      */   private static final int STATE_FLUSHED_BEFORE_HANDSHAKE = 2;
/*      */   
/*      */   private static final int STATE_READ_DURING_HANDSHAKE = 4;
/*      */   
/*      */   private static final int STATE_HANDSHAKE_STARTED = 8;
/*      */   
/*      */   private static final int STATE_NEEDS_FLUSH = 16;
/*      */   
/*      */   private static final int STATE_OUTBOUND_CLOSED = 32;
/*      */   
/*      */   private static final int STATE_CLOSE_NOTIFY = 64;
/*      */   
/*      */   private static final int STATE_PROCESS_TASK = 128;
/*      */   private static final int STATE_FIRE_CHANNEL_READ = 256;
/*      */   private static final int STATE_UNWRAP_REENTRY = 512;
/*      */   private static final int MAX_PLAINTEXT_LENGTH = 16384;
/*      */   private volatile ChannelHandlerContext ctx;
/*      */   private final SSLEngine engine;
/*      */   private final SslEngineType engineType;
/*      */   private final Executor delegatedTaskExecutor;
/*      */   private final boolean jdkCompatibilityMode;
/*      */   
/*      */   private enum SslEngineType
/*      */   {
/*  203 */     TCNATIVE(true, ByteToMessageDecoder.COMPOSITE_CUMULATOR) {
/*      */       SSLEngineResult unwrap(SslHandler handler, ByteBuf in, int len, ByteBuf out) throws SSLException {
/*      */         SSLEngineResult result;
/*  206 */         int nioBufferCount = in.nioBufferCount();
/*  207 */         int writerIndex = out.writerIndex();
/*      */         
/*  209 */         if (nioBufferCount > 1) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  215 */           ReferenceCountedOpenSslEngine opensslEngine = (ReferenceCountedOpenSslEngine)handler.engine;
/*      */           try {
/*  217 */             handler.singleBuffer[0] = SslHandler.toByteBuffer(out, writerIndex, out.writableBytes());
/*  218 */             result = opensslEngine.unwrap(in.nioBuffers(in.readerIndex(), len), handler.singleBuffer);
/*      */           } finally {
/*  220 */             handler.singleBuffer[0] = null;
/*      */           } 
/*      */         } else {
/*  223 */           result = handler.engine.unwrap(SslHandler.toByteBuffer(in, in.readerIndex(), len), SslHandler
/*  224 */               .toByteBuffer(out, writerIndex, out.writableBytes()));
/*      */         } 
/*  226 */         out.writerIndex(writerIndex + result.bytesProduced());
/*  227 */         return result;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*      */       ByteBuf allocateWrapBuffer(SslHandler handler, ByteBufAllocator allocator, int pendingBytes, int numComponents) {
/*  233 */         return allocator.directBuffer(((ReferenceCountedOpenSslEngine)handler.engine)
/*  234 */             .calculateMaxLengthForWrap(pendingBytes, numComponents));
/*      */       }
/*      */ 
/*      */       
/*      */       int calculatePendingData(SslHandler handler, int guess) {
/*  239 */         int sslPending = ((ReferenceCountedOpenSslEngine)handler.engine).sslPending();
/*  240 */         return (sslPending > 0) ? sslPending : guess;
/*      */       }
/*      */ 
/*      */       
/*      */       boolean jdkCompatibilityMode(SSLEngine engine) {
/*  245 */         return ((ReferenceCountedOpenSslEngine)engine).jdkCompatibilityMode;
/*      */       }
/*      */     },
/*  248 */     CONSCRYPT(true, ByteToMessageDecoder.COMPOSITE_CUMULATOR) {
/*      */       SSLEngineResult unwrap(SslHandler handler, ByteBuf in, int len, ByteBuf out) throws SSLException {
/*      */         SSLEngineResult result;
/*  251 */         int nioBufferCount = in.nioBufferCount();
/*  252 */         int writerIndex = out.writerIndex();
/*      */         
/*  254 */         if (nioBufferCount > 1) {
/*      */ 
/*      */           
/*      */           try {
/*      */             
/*  259 */             handler.singleBuffer[0] = SslHandler.toByteBuffer(out, writerIndex, out.writableBytes());
/*  260 */             result = ((ConscryptAlpnSslEngine)handler.engine).unwrap(in
/*  261 */                 .nioBuffers(in.readerIndex(), len), handler
/*  262 */                 .singleBuffer);
/*      */           } finally {
/*  264 */             handler.singleBuffer[0] = null;
/*      */           } 
/*      */         } else {
/*  267 */           result = handler.engine.unwrap(SslHandler.toByteBuffer(in, in.readerIndex(), len), SslHandler
/*  268 */               .toByteBuffer(out, writerIndex, out.writableBytes()));
/*      */         } 
/*  270 */         out.writerIndex(writerIndex + result.bytesProduced());
/*  271 */         return result;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*      */       ByteBuf allocateWrapBuffer(SslHandler handler, ByteBufAllocator allocator, int pendingBytes, int numComponents) {
/*  277 */         return allocator.directBuffer((
/*  278 */             (ConscryptAlpnSslEngine)handler.engine).calculateOutNetBufSize(pendingBytes, numComponents));
/*      */       }
/*      */ 
/*      */       
/*      */       int calculatePendingData(SslHandler handler, int guess) {
/*  283 */         return guess;
/*      */       }
/*      */ 
/*      */       
/*      */       boolean jdkCompatibilityMode(SSLEngine engine) {
/*  288 */         return true;
/*      */       }
/*      */     },
/*  291 */     JDK(false, ByteToMessageDecoder.MERGE_CUMULATOR)
/*      */     {
/*      */       SSLEngineResult unwrap(SslHandler handler, ByteBuf in, int len, ByteBuf out) throws SSLException {
/*  294 */         int writerIndex = out.writerIndex();
/*  295 */         ByteBuffer inNioBuffer = SslHandler.toByteBuffer(in, in.readerIndex(), len);
/*  296 */         int position = inNioBuffer.position();
/*  297 */         SSLEngineResult result = handler.engine.unwrap(inNioBuffer, SslHandler
/*  298 */             .toByteBuffer(out, writerIndex, out.writableBytes()));
/*  299 */         out.writerIndex(writerIndex + result.bytesProduced());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  307 */         if (result.bytesConsumed() == 0) {
/*  308 */           int consumed = inNioBuffer.position() - position;
/*  309 */           if (consumed != result.bytesConsumed())
/*      */           {
/*  311 */             return new SSLEngineResult(result
/*  312 */                 .getStatus(), result.getHandshakeStatus(), consumed, result.bytesProduced());
/*      */           }
/*      */         } 
/*  315 */         return result;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       ByteBuf allocateWrapBuffer(SslHandler handler, ByteBufAllocator allocator, int pendingBytes, int numComponents) {
/*  327 */         return allocator.heapBuffer(handler.engine.getSession().getPacketBufferSize());
/*      */       }
/*      */ 
/*      */       
/*      */       int calculatePendingData(SslHandler handler, int guess) {
/*  332 */         return guess;
/*      */       }
/*      */ 
/*      */       
/*      */       boolean jdkCompatibilityMode(SSLEngine engine) {
/*  337 */         return true;
/*      */       } };
/*      */     final boolean wantsDirectBuffer;
/*      */     
/*      */     static SslEngineType forEngine(SSLEngine engine) {
/*  342 */       return (engine instanceof ReferenceCountedOpenSslEngine) ? TCNATIVE : ((engine instanceof ConscryptAlpnSslEngine) ? CONSCRYPT : JDK);
/*      */     }
/*      */     final ByteToMessageDecoder.Cumulator cumulator;
/*      */     
/*      */     SslEngineType(boolean wantsDirectBuffer, ByteToMessageDecoder.Cumulator cumulator) {
/*  347 */       this.wantsDirectBuffer = wantsDirectBuffer;
/*  348 */       this.cumulator = cumulator;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     abstract SSLEngineResult unwrap(SslHandler param1SslHandler, ByteBuf param1ByteBuf1, int param1Int, ByteBuf param1ByteBuf2) throws SSLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     abstract int calculatePendingData(SslHandler param1SslHandler, int param1Int);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     abstract boolean jdkCompatibilityMode(SSLEngine param1SSLEngine);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     abstract ByteBuf allocateWrapBuffer(SslHandler param1SslHandler, ByteBufAllocator param1ByteBufAllocator, int param1Int1, int param1Int2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  392 */   private final ByteBuffer[] singleBuffer = new ByteBuffer[1];
/*      */   
/*      */   private final boolean startTls;
/*      */   
/*  396 */   private final SslTasksRunner sslTaskRunnerForUnwrap = new SslTasksRunner(true);
/*  397 */   private final SslTasksRunner sslTaskRunner = new SslTasksRunner(false);
/*      */   
/*      */   private SslHandlerCoalescingBufferQueue pendingUnencryptedWrites;
/*  400 */   private Promise<Channel> handshakePromise = (Promise<Channel>)new LazyChannelPromise();
/*  401 */   private final LazyChannelPromise sslClosePromise = new LazyChannelPromise();
/*      */   
/*      */   private int packetLength;
/*      */   
/*      */   private short state;
/*  406 */   private volatile long handshakeTimeoutMillis = 10000L;
/*  407 */   private volatile long closeNotifyFlushTimeoutMillis = 3000L;
/*      */   private volatile long closeNotifyReadTimeoutMillis;
/*  409 */   volatile int wrapDataSize = 16384;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SslHandler(SSLEngine engine) {
/*  417 */     this(engine, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SslHandler(SSLEngine engine, boolean startTls) {
/*  428 */     this(engine, startTls, (Executor)ImmediateExecutor.INSTANCE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SslHandler(SSLEngine engine, Executor delegatedTaskExecutor) {
/*  439 */     this(engine, false, delegatedTaskExecutor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SslHandler(SSLEngine engine, boolean startTls, Executor delegatedTaskExecutor) {
/*  452 */     this.engine = (SSLEngine)ObjectUtil.checkNotNull(engine, "engine");
/*  453 */     this.delegatedTaskExecutor = (Executor)ObjectUtil.checkNotNull(delegatedTaskExecutor, "delegatedTaskExecutor");
/*  454 */     this.engineType = SslEngineType.forEngine(engine);
/*  455 */     this.startTls = startTls;
/*  456 */     this.jdkCompatibilityMode = this.engineType.jdkCompatibilityMode(engine);
/*  457 */     setCumulator(this.engineType.cumulator);
/*      */   }
/*      */   
/*      */   public long getHandshakeTimeoutMillis() {
/*  461 */     return this.handshakeTimeoutMillis;
/*      */   }
/*      */   
/*      */   public void setHandshakeTimeout(long handshakeTimeout, TimeUnit unit) {
/*  465 */     ObjectUtil.checkNotNull(unit, "unit");
/*  466 */     setHandshakeTimeoutMillis(unit.toMillis(handshakeTimeout));
/*      */   }
/*      */   
/*      */   public void setHandshakeTimeoutMillis(long handshakeTimeoutMillis) {
/*  470 */     this.handshakeTimeoutMillis = ObjectUtil.checkPositiveOrZero(handshakeTimeoutMillis, "handshakeTimeoutMillis");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setWrapDataSize(int wrapDataSize) {
/*  495 */     this.wrapDataSize = wrapDataSize;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public long getCloseNotifyTimeoutMillis() {
/*  503 */     return getCloseNotifyFlushTimeoutMillis();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void setCloseNotifyTimeout(long closeNotifyTimeout, TimeUnit unit) {
/*  511 */     setCloseNotifyFlushTimeout(closeNotifyTimeout, unit);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void setCloseNotifyTimeoutMillis(long closeNotifyFlushTimeoutMillis) {
/*  519 */     setCloseNotifyFlushTimeoutMillis(closeNotifyFlushTimeoutMillis);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final long getCloseNotifyFlushTimeoutMillis() {
/*  528 */     return this.closeNotifyFlushTimeoutMillis;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setCloseNotifyFlushTimeout(long closeNotifyFlushTimeout, TimeUnit unit) {
/*  537 */     setCloseNotifyFlushTimeoutMillis(unit.toMillis(closeNotifyFlushTimeout));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setCloseNotifyFlushTimeoutMillis(long closeNotifyFlushTimeoutMillis) {
/*  544 */     this.closeNotifyFlushTimeoutMillis = ObjectUtil.checkPositiveOrZero(closeNotifyFlushTimeoutMillis, "closeNotifyFlushTimeoutMillis");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final long getCloseNotifyReadTimeoutMillis() {
/*  554 */     return this.closeNotifyReadTimeoutMillis;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setCloseNotifyReadTimeout(long closeNotifyReadTimeout, TimeUnit unit) {
/*  563 */     setCloseNotifyReadTimeoutMillis(unit.toMillis(closeNotifyReadTimeout));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setCloseNotifyReadTimeoutMillis(long closeNotifyReadTimeoutMillis) {
/*  570 */     this.closeNotifyReadTimeoutMillis = ObjectUtil.checkPositiveOrZero(closeNotifyReadTimeoutMillis, "closeNotifyReadTimeoutMillis");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SSLEngine engine() {
/*  578 */     return this.engine;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String applicationProtocol() {
/*  587 */     SSLEngine engine = engine();
/*  588 */     if (!(engine instanceof ApplicationProtocolAccessor)) {
/*  589 */       return null;
/*      */     }
/*      */     
/*  592 */     return ((ApplicationProtocolAccessor)engine).getNegotiatedApplicationProtocol();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Future<Channel> handshakeFuture() {
/*  602 */     return (Future<Channel>)this.handshakePromise;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ChannelFuture close() {
/*  610 */     return closeOutbound();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ChannelFuture close(ChannelPromise promise) {
/*  618 */     return closeOutbound(promise);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ChannelFuture closeOutbound() {
/*  628 */     return closeOutbound(this.ctx.newPromise());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ChannelFuture closeOutbound(final ChannelPromise promise) {
/*  638 */     ChannelHandlerContext ctx = this.ctx;
/*  639 */     if (ctx.executor().inEventLoop()) {
/*  640 */       closeOutbound0(promise);
/*      */     } else {
/*  642 */       ctx.executor().execute(new Runnable()
/*      */           {
/*      */             public void run() {
/*  645 */               SslHandler.this.closeOutbound0(promise);
/*      */             }
/*      */           });
/*      */     } 
/*  649 */     return (ChannelFuture)promise;
/*      */   }
/*      */   
/*      */   private void closeOutbound0(ChannelPromise promise) {
/*  653 */     setState(32);
/*  654 */     this.engine.closeOutbound();
/*      */     try {
/*  656 */       flush(this.ctx, promise);
/*  657 */     } catch (Exception e) {
/*  658 */       if (!promise.tryFailure(e)) {
/*  659 */         logger.warn("{} flush() raised a masked exception.", this.ctx.channel(), e);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Future<Channel> sslCloseFuture() {
/*  672 */     return (Future<Channel>)this.sslClosePromise;
/*      */   }
/*      */ 
/*      */   
/*      */   public void handlerRemoved0(ChannelHandlerContext ctx) throws Exception {
/*      */     try {
/*  678 */       if (this.pendingUnencryptedWrites != null && !this.pendingUnencryptedWrites.isEmpty())
/*      */       {
/*  680 */         this.pendingUnencryptedWrites.releaseAndFailAll((ChannelOutboundInvoker)ctx, (Throwable)new ChannelException("Pending write on removal of SslHandler"));
/*      */       }
/*      */       
/*  683 */       this.pendingUnencryptedWrites = null;
/*      */       
/*  685 */       SSLException cause = null;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  690 */       if (!this.handshakePromise.isDone()) {
/*  691 */         cause = new SSLHandshakeException("SslHandler removed before handshake completed");
/*  692 */         if (this.handshakePromise.tryFailure(cause)) {
/*  693 */           ctx.fireUserEventTriggered(new SslHandshakeCompletionEvent(cause));
/*      */         }
/*      */       } 
/*  696 */       if (!this.sslClosePromise.isDone()) {
/*  697 */         if (cause == null) {
/*  698 */           cause = new SSLException("SslHandler removed before SSLEngine was closed");
/*      */         }
/*  700 */         notifyClosePromise(cause);
/*      */       } 
/*      */     } finally {
/*  703 */       ReferenceCountUtil.release(this.engine);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void bind(ChannelHandlerContext ctx, SocketAddress localAddress, ChannelPromise promise) throws Exception {
/*  709 */     ctx.bind(localAddress, promise);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void connect(ChannelHandlerContext ctx, SocketAddress remoteAddress, SocketAddress localAddress, ChannelPromise promise) throws Exception {
/*  715 */     ctx.connect(remoteAddress, localAddress, promise);
/*      */   }
/*      */ 
/*      */   
/*      */   public void deregister(ChannelHandlerContext ctx, ChannelPromise promise) throws Exception {
/*  720 */     ctx.deregister(promise);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void disconnect(ChannelHandlerContext ctx, ChannelPromise promise) throws Exception {
/*  726 */     closeOutboundAndChannel(ctx, promise, true);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void close(ChannelHandlerContext ctx, ChannelPromise promise) throws Exception {
/*  732 */     closeOutboundAndChannel(ctx, promise, false);
/*      */   }
/*      */ 
/*      */   
/*      */   public void read(ChannelHandlerContext ctx) throws Exception {
/*  737 */     if (!this.handshakePromise.isDone()) {
/*  738 */       setState(4);
/*      */     }
/*      */     
/*  741 */     ctx.read();
/*      */   }
/*      */   
/*      */   private static IllegalStateException newPendingWritesNullException() {
/*  745 */     return new IllegalStateException("pendingUnencryptedWrites is null, handlerRemoved0 called?");
/*      */   }
/*      */ 
/*      */   
/*      */   public void write(ChannelHandlerContext ctx, Object msg, ChannelPromise promise) throws Exception {
/*  750 */     if (!(msg instanceof ByteBuf)) {
/*  751 */       UnsupportedMessageTypeException exception = new UnsupportedMessageTypeException(msg, new Class[] { ByteBuf.class });
/*  752 */       ReferenceCountUtil.safeRelease(msg);
/*  753 */       promise.setFailure((Throwable)exception);
/*  754 */     } else if (this.pendingUnencryptedWrites == null) {
/*  755 */       ReferenceCountUtil.safeRelease(msg);
/*  756 */       promise.setFailure(newPendingWritesNullException());
/*      */     } else {
/*  758 */       this.pendingUnencryptedWrites.add((ByteBuf)msg, promise);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void flush(ChannelHandlerContext ctx) throws Exception {
/*  766 */     if (this.startTls && !isStateSet(1)) {
/*  767 */       setState(1);
/*  768 */       this.pendingUnencryptedWrites.writeAndRemoveAll(ctx);
/*  769 */       forceFlush(ctx);
/*      */ 
/*      */       
/*  772 */       startHandshakeProcessing(true);
/*      */       
/*      */       return;
/*      */     } 
/*  776 */     if (isStateSet(128)) {
/*      */       return;
/*      */     }
/*      */     
/*      */     try {
/*  781 */       wrapAndFlush(ctx);
/*  782 */     } catch (Throwable cause) {
/*  783 */       setHandshakeFailure(ctx, cause);
/*  784 */       PlatformDependent.throwException(cause);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void wrapAndFlush(ChannelHandlerContext ctx) throws SSLException {
/*  789 */     if (this.pendingUnencryptedWrites.isEmpty())
/*      */     {
/*      */ 
/*      */ 
/*      */       
/*  794 */       this.pendingUnencryptedWrites.add(Unpooled.EMPTY_BUFFER, ctx.newPromise());
/*      */     }
/*  796 */     if (!this.handshakePromise.isDone()) {
/*  797 */       setState(2);
/*      */     }
/*      */     try {
/*  800 */       wrap(ctx, false);
/*      */     }
/*      */     finally {
/*      */       
/*  804 */       forceFlush(ctx);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void wrap(ChannelHandlerContext ctx, boolean inUnwrap) throws SSLException {
/*  810 */     ByteBuf out = null;
/*  811 */     ByteBufAllocator alloc = ctx.alloc();
/*      */     try {
/*  813 */       int wrapDataSize = this.wrapDataSize;
/*      */ 
/*      */       
/*  816 */       while (!ctx.isRemoved()) {
/*  817 */         ChannelPromise promise = ctx.newPromise();
/*      */ 
/*      */         
/*  820 */         ByteBuf buf = (wrapDataSize > 0) ? this.pendingUnencryptedWrites.remove(alloc, wrapDataSize, promise) : this.pendingUnencryptedWrites.removeFirst(promise);
/*  821 */         if (buf == null) {
/*      */           break;
/*      */         }
/*      */         
/*  825 */         if (out == null) {
/*  826 */           out = allocateOutNetBuf(ctx, buf.readableBytes(), buf.nioBufferCount());
/*      */         }
/*      */         
/*  829 */         SSLEngineResult result = wrap(alloc, this.engine, buf, out);
/*  830 */         if (buf.isReadable()) {
/*  831 */           this.pendingUnencryptedWrites.addFirst(buf, promise);
/*      */ 
/*      */           
/*  834 */           promise = null;
/*      */         } else {
/*  836 */           buf.release();
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/*  841 */         if (out.isReadable()) {
/*  842 */           ByteBuf b = out;
/*  843 */           out = null;
/*  844 */           if (promise != null) {
/*  845 */             ctx.write(b, promise);
/*      */           } else {
/*  847 */             ctx.write(b);
/*      */           } 
/*  849 */         } else if (promise != null) {
/*  850 */           ctx.write(Unpooled.EMPTY_BUFFER, promise);
/*      */         } 
/*      */ 
/*      */         
/*  854 */         if (result.getStatus() == SSLEngineResult.Status.CLOSED) {
/*      */ 
/*      */           
/*  857 */           Throwable exception = this.handshakePromise.cause();
/*  858 */           if (exception == null) {
/*  859 */             exception = this.sslClosePromise.cause();
/*  860 */             if (exception == null) {
/*  861 */               exception = new SslClosedEngineException("SSLEngine closed already");
/*      */             }
/*      */           } 
/*  864 */           this.pendingUnencryptedWrites.releaseAndFailAll((ChannelOutboundInvoker)ctx, exception);
/*      */           return;
/*      */         } 
/*  867 */         switch (result.getHandshakeStatus()) {
/*      */           case NEED_TASK:
/*  869 */             if (!runDelegatedTasks(inUnwrap)) {
/*      */               break;
/*      */             }
/*      */             continue;
/*      */ 
/*      */           
/*      */           case FINISHED:
/*      */           case NOT_HANDSHAKING:
/*  877 */             setHandshakeSuccess();
/*      */             continue;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case NEED_WRAP:
/*  884 */             if (result.bytesProduced() > 0 && this.pendingUnencryptedWrites.isEmpty()) {
/*  885 */               this.pendingUnencryptedWrites.add(Unpooled.EMPTY_BUFFER);
/*      */             }
/*      */             continue;
/*      */ 
/*      */           
/*      */           case NEED_UNWRAP:
/*  891 */             readIfNeeded(ctx);
/*      */             return;
/*      */         } 
/*  894 */         throw new IllegalStateException("Unknown handshake status: " + result
/*  895 */             .getHandshakeStatus());
/*      */       }
/*      */     
/*      */     } finally {
/*      */       
/*  900 */       if (out != null) {
/*  901 */         out.release();
/*      */       }
/*  903 */       if (inUnwrap) {
/*  904 */         setState(16);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean wrapNonAppData(final ChannelHandlerContext ctx, boolean inUnwrap) throws SSLException {
/*  916 */     ByteBuf out = null;
/*  917 */     ByteBufAllocator alloc = ctx.alloc();
/*      */ 
/*      */     
/*      */     try {
/*  921 */       while (!ctx.isRemoved()) {
/*  922 */         boolean bool; if (out == null)
/*      */         {
/*      */ 
/*      */           
/*  926 */           out = allocateOutNetBuf(ctx, 2048, 1);
/*      */         }
/*  928 */         SSLEngineResult result = wrap(alloc, this.engine, Unpooled.EMPTY_BUFFER, out);
/*  929 */         if (result.bytesProduced() > 0) {
/*  930 */           ctx.write(out).addListener((GenericFutureListener)new ChannelFutureListener()
/*      */               {
/*      */                 public void operationComplete(ChannelFuture future) {
/*  933 */                   Throwable cause = future.cause();
/*  934 */                   if (cause != null) {
/*  935 */                     SslHandler.this.setHandshakeFailureTransportFailure(ctx, cause);
/*      */                   }
/*      */                 }
/*      */               });
/*  939 */           if (inUnwrap) {
/*  940 */             setState(16);
/*      */           }
/*  942 */           out = null;
/*      */         } 
/*      */         
/*  945 */         SSLEngineResult.HandshakeStatus status = result.getHandshakeStatus();
/*  946 */         switch (status) {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case FINISHED:
/*  952 */             if (setHandshakeSuccess() && inUnwrap && !this.pendingUnencryptedWrites.isEmpty()) {
/*  953 */               wrap(ctx, true);
/*      */             }
/*  955 */             bool = false; return bool;
/*      */           case NEED_TASK:
/*  957 */             if (!runDelegatedTasks(inUnwrap)) {
/*      */               break;
/*      */             }
/*      */             break;
/*      */ 
/*      */           
/*      */           case NEED_UNWRAP:
/*  964 */             if (inUnwrap || unwrapNonAppData(ctx) <= 0) {
/*      */ 
/*      */ 
/*      */               
/*  968 */               bool = false; return bool;
/*      */             } 
/*      */             break;
/*      */           case NEED_WRAP:
/*      */             break;
/*      */           case NOT_HANDSHAKING:
/*  974 */             if (setHandshakeSuccess() && inUnwrap && !this.pendingUnencryptedWrites.isEmpty()) {
/*  975 */               wrap(ctx, true);
/*      */             }
/*      */ 
/*      */             
/*  979 */             if (!inUnwrap) {
/*  980 */               unwrapNonAppData(ctx);
/*      */             }
/*  982 */             bool = true; return bool;
/*      */           default:
/*  984 */             throw new IllegalStateException("Unknown handshake status: " + result.getHandshakeStatus());
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/*  989 */         if (result.bytesProduced() == 0 && status != SSLEngineResult.HandshakeStatus.NEED_TASK) {
/*      */           break;
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*  995 */         if (result.bytesConsumed() == 0 && result.getHandshakeStatus() == SSLEngineResult.HandshakeStatus.NOT_HANDSHAKING) {
/*      */           break;
/*      */         }
/*      */       } 
/*      */     } finally {
/* 1000 */       if (out != null) {
/* 1001 */         out.release();
/*      */       }
/*      */     } 
/* 1004 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private SSLEngineResult wrap(ByteBufAllocator alloc, SSLEngine engine, ByteBuf in, ByteBuf out) throws SSLException {
/* 1009 */     ByteBuf newDirectIn = null; try {
/*      */       ByteBuffer[] in0; SSLEngineResult result;
/* 1011 */       int readerIndex = in.readerIndex();
/* 1012 */       int readableBytes = in.readableBytes();
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1017 */       if (in.isDirect() || !this.engineType.wantsDirectBuffer) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1022 */         if (!(in instanceof CompositeByteBuf) && in.nioBufferCount() == 1) {
/* 1023 */           in0 = this.singleBuffer;
/*      */ 
/*      */           
/* 1026 */           in0[0] = in.internalNioBuffer(readerIndex, readableBytes);
/*      */         } else {
/* 1028 */           in0 = in.nioBuffers();
/*      */         }
/*      */       
/*      */       }
/*      */       else {
/*      */         
/* 1034 */         newDirectIn = alloc.directBuffer(readableBytes);
/* 1035 */         newDirectIn.writeBytes(in, readerIndex, readableBytes);
/* 1036 */         in0 = this.singleBuffer;
/* 1037 */         in0[0] = newDirectIn.internalNioBuffer(newDirectIn.readerIndex(), readableBytes);
/*      */       } 
/*      */       
/*      */       while (true) {
/* 1041 */         ByteBuffer out0 = out.nioBuffer(out.writerIndex(), out.writableBytes());
/* 1042 */         result = engine.wrap(in0, out0);
/* 1043 */         in.skipBytes(result.bytesConsumed());
/* 1044 */         out.writerIndex(out.writerIndex() + result.bytesProduced());
/*      */         
/* 1046 */         if (result.getStatus() == SSLEngineResult.Status.BUFFER_OVERFLOW) {
/* 1047 */           out.ensureWritable(engine.getSession().getPacketBufferSize()); continue;
/*      */         }  break;
/* 1049 */       }  return result;
/*      */     
/*      */     }
/*      */     finally {
/*      */       
/* 1054 */       this.singleBuffer[0] = null;
/*      */       
/* 1056 */       if (newDirectIn != null) {
/* 1057 */         newDirectIn.release();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void channelInactive(ChannelHandlerContext ctx) throws Exception {
/* 1064 */     boolean handshakeFailed = (this.handshakePromise.cause() != null);
/*      */ 
/*      */     
/* 1067 */     ClosedChannelException exception = new ClosedChannelException();
/*      */ 
/*      */     
/* 1070 */     if (isStateSet(8) && !this.handshakePromise.isDone()) {
/* 1071 */       ThrowableUtil.addSuppressed(exception, StacklessSSLHandshakeException.newInstance("Connection closed while SSL/TLS handshake was in progress", SslHandler.class, "channelInactive"));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1078 */     setHandshakeFailure(ctx, exception, !isStateSet(32), isStateSet(8), false);
/*      */ 
/*      */ 
/*      */     
/* 1082 */     notifyClosePromise(exception);
/*      */     
/*      */     try {
/* 1085 */       super.channelInactive(ctx);
/* 1086 */     } catch (DecoderException e) {
/* 1087 */       if (!handshakeFailed || !(e.getCause() instanceof SSLException))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1093 */         throw e;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
/* 1100 */     if (ignoreException(cause)) {
/*      */ 
/*      */       
/* 1103 */       if (logger.isDebugEnabled()) {
/* 1104 */         logger.debug("{} Swallowing a harmless 'connection reset by peer / broken pipe' error that occurred while writing close_notify in response to the peer's close_notify", ctx
/*      */             
/* 1106 */             .channel(), cause);
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 1111 */       if (ctx.channel().isActive()) {
/* 1112 */         ctx.close();
/*      */       }
/*      */     } else {
/* 1115 */       ctx.fireExceptionCaught(cause);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean ignoreException(Throwable t) {
/* 1129 */     if (!(t instanceof SSLException) && t instanceof java.io.IOException && this.sslClosePromise.isDone()) {
/* 1130 */       String message = t.getMessage();
/*      */ 
/*      */ 
/*      */       
/* 1134 */       if (message != null && IGNORABLE_ERROR_MESSAGE.matcher(message).matches()) {
/* 1135 */         return true;
/*      */       }
/*      */ 
/*      */       
/* 1139 */       StackTraceElement[] elements = t.getStackTrace();
/* 1140 */       for (StackTraceElement element : elements) {
/* 1141 */         String classname = element.getClassName();
/* 1142 */         String methodname = element.getMethodName();
/*      */ 
/*      */         
/* 1145 */         if (!classname.startsWith("io.netty."))
/*      */         {
/*      */ 
/*      */ 
/*      */           
/* 1150 */           if ("read".equals(methodname)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1156 */             if (IGNORABLE_CLASS_IN_STACK.matcher(classname).matches()) {
/* 1157 */               return true;
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             try {
/* 1164 */               Class<?> clazz = PlatformDependent.getClassLoader(getClass()).loadClass(classname);
/*      */               
/* 1166 */               if (SocketChannel.class.isAssignableFrom(clazz) || DatagramChannel.class
/* 1167 */                 .isAssignableFrom(clazz)) {
/* 1168 */                 return true;
/*      */               }
/*      */ 
/*      */               
/* 1172 */               if (PlatformDependent.javaVersion() >= 7 && "com.sun.nio.sctp.SctpChannel"
/* 1173 */                 .equals(clazz.getSuperclass().getName())) {
/* 1174 */                 return true;
/*      */               }
/* 1176 */             } catch (Throwable cause) {
/* 1177 */               if (logger.isDebugEnabled())
/* 1178 */                 logger.debug("Unexpected exception while loading class {} classname {}", new Object[] {
/* 1179 */                       getClass(), classname, cause
/*      */                     }); 
/*      */             } 
/*      */           }  } 
/*      */       } 
/*      */     } 
/* 1185 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isEncrypted(ByteBuf buffer) {
/* 1201 */     if (buffer.readableBytes() < 5) {
/* 1202 */       throw new IllegalArgumentException("buffer must have at least 5 readable bytes");
/*      */     }
/*      */     
/* 1205 */     return (SslUtils.getEncryptedPacketLength(buffer, buffer.readerIndex()) != -2);
/*      */   }
/*      */   
/*      */   private void decodeJdkCompatible(ChannelHandlerContext ctx, ByteBuf in) throws NotSslRecordException {
/* 1209 */     int packetLength = this.packetLength;
/*      */     
/* 1211 */     if (packetLength > 0) {
/* 1212 */       if (in.readableBytes() < packetLength) {
/*      */         return;
/*      */       }
/*      */     } else {
/*      */       
/* 1217 */       int readableBytes = in.readableBytes();
/* 1218 */       if (readableBytes < 5) {
/*      */         return;
/*      */       }
/* 1221 */       packetLength = SslUtils.getEncryptedPacketLength(in, in.readerIndex());
/* 1222 */       if (packetLength == -2) {
/*      */ 
/*      */         
/* 1225 */         NotSslRecordException e = new NotSslRecordException("not an SSL/TLS record: " + ByteBufUtil.hexDump(in));
/* 1226 */         in.skipBytes(in.readableBytes());
/*      */ 
/*      */ 
/*      */         
/* 1230 */         setHandshakeFailure(ctx, e);
/*      */         
/* 1232 */         throw e;
/*      */       } 
/* 1234 */       assert packetLength > 0;
/* 1235 */       if (packetLength > readableBytes) {
/*      */         
/* 1237 */         this.packetLength = packetLength;
/*      */ 
/*      */         
/*      */         return;
/*      */       } 
/*      */     } 
/*      */     
/* 1244 */     this.packetLength = 0;
/*      */     try {
/* 1246 */       int bytesConsumed = unwrap(ctx, in, packetLength);
/* 1247 */       assert bytesConsumed == packetLength || this.engine.isInboundDone() : "we feed the SSLEngine a packets worth of data: " + packetLength + " but it only consumed: " + bytesConsumed;
/*      */     
/*      */     }
/* 1250 */     catch (Throwable cause) {
/* 1251 */       handleUnwrapThrowable(ctx, cause);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void decodeNonJdkCompatible(ChannelHandlerContext ctx, ByteBuf in) {
/*      */     try {
/* 1257 */       unwrap(ctx, in, in.readableBytes());
/* 1258 */     } catch (Throwable cause) {
/* 1259 */       handleUnwrapThrowable(ctx, cause);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void handleUnwrapThrowable(ChannelHandlerContext ctx, Throwable cause) {
/*      */     try {
/* 1269 */       if (this.handshakePromise.tryFailure(cause)) {
/* 1270 */         ctx.fireUserEventTriggered(new SslHandshakeCompletionEvent(cause));
/*      */       }
/*      */ 
/*      */       
/* 1274 */       if (this.pendingUnencryptedWrites != null)
/*      */       {
/*      */         
/* 1277 */         wrapAndFlush(ctx);
/*      */       }
/* 1279 */     } catch (SSLException ex) {
/* 1280 */       logger.debug("SSLException during trying to call SSLEngine.wrap(...) because of an previous SSLException, ignoring...", ex);
/*      */     }
/*      */     finally {
/*      */       
/* 1284 */       setHandshakeFailure(ctx, cause, true, false, true);
/*      */     } 
/* 1286 */     PlatformDependent.throwException(cause);
/*      */   }
/*      */ 
/*      */   
/*      */   protected void decode(ChannelHandlerContext ctx, ByteBuf in, List<Object> out) throws SSLException {
/* 1291 */     if (isStateSet(128)) {
/*      */       return;
/*      */     }
/* 1294 */     if (this.jdkCompatibilityMode) {
/* 1295 */       decodeJdkCompatible(ctx, in);
/*      */     } else {
/* 1297 */       decodeNonJdkCompatible(ctx, in);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void channelReadComplete(ChannelHandlerContext ctx) throws Exception {
/* 1303 */     channelReadComplete0(ctx);
/*      */   }
/*      */ 
/*      */   
/*      */   private void channelReadComplete0(ChannelHandlerContext ctx) {
/* 1308 */     discardSomeReadBytes();
/*      */     
/* 1310 */     flushIfNeeded(ctx);
/* 1311 */     readIfNeeded(ctx);
/*      */     
/* 1313 */     clearState(256);
/* 1314 */     ctx.fireChannelReadComplete();
/*      */   }
/*      */ 
/*      */   
/*      */   private void readIfNeeded(ChannelHandlerContext ctx) {
/* 1319 */     if (!ctx.channel().config().isAutoRead() && (
/* 1320 */       !isStateSet(256) || !this.handshakePromise.isDone()))
/*      */     {
/*      */       
/* 1323 */       ctx.read();
/*      */     }
/*      */   }
/*      */   
/*      */   private void flushIfNeeded(ChannelHandlerContext ctx) {
/* 1328 */     if (isStateSet(16)) {
/* 1329 */       forceFlush(ctx);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int unwrapNonAppData(ChannelHandlerContext ctx) throws SSLException {
/* 1337 */     return unwrap(ctx, Unpooled.EMPTY_BUFFER, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int unwrap(ChannelHandlerContext ctx, ByteBuf packet, int length) throws SSLException {
/*      */     // Byte code:
/*      */     //   0: iload_3
/*      */     //   1: istore #4
/*      */     //   3: iconst_0
/*      */     //   4: istore #5
/*      */     //   6: iconst_0
/*      */     //   7: istore #6
/*      */     //   9: iconst_0
/*      */     //   10: istore #7
/*      */     //   12: aload_0
/*      */     //   13: aload_1
/*      */     //   14: iload_3
/*      */     //   15: invokespecial allocate : (Lio/netty/channel/ChannelHandlerContext;I)Lio/netty/buffer/ByteBuf;
/*      */     //   18: astore #8
/*      */     //   20: aload_0
/*      */     //   21: getfield engineType : Lio/netty/handler/ssl/SslHandler$SslEngineType;
/*      */     //   24: aload_0
/*      */     //   25: aload_2
/*      */     //   26: iload_3
/*      */     //   27: aload #8
/*      */     //   29: invokevirtual unwrap : (Lio/netty/handler/ssl/SslHandler;Lio/netty/buffer/ByteBuf;ILio/netty/buffer/ByteBuf;)Ljavax/net/ssl/SSLEngineResult;
/*      */     //   32: astore #9
/*      */     //   34: aload #9
/*      */     //   36: invokevirtual getStatus : ()Ljavax/net/ssl/SSLEngineResult$Status;
/*      */     //   39: astore #10
/*      */     //   41: aload #9
/*      */     //   43: invokevirtual getHandshakeStatus : ()Ljavax/net/ssl/SSLEngineResult$HandshakeStatus;
/*      */     //   46: astore #11
/*      */     //   48: aload #9
/*      */     //   50: invokevirtual bytesProduced : ()I
/*      */     //   53: istore #12
/*      */     //   55: aload #9
/*      */     //   57: invokevirtual bytesConsumed : ()I
/*      */     //   60: istore #13
/*      */     //   62: aload_2
/*      */     //   63: iload #13
/*      */     //   65: invokevirtual skipBytes : (I)Lio/netty/buffer/ByteBuf;
/*      */     //   68: pop
/*      */     //   69: iload_3
/*      */     //   70: iload #13
/*      */     //   72: isub
/*      */     //   73: istore_3
/*      */     //   74: aload #11
/*      */     //   76: getstatic javax/net/ssl/SSLEngineResult$HandshakeStatus.FINISHED : Ljavax/net/ssl/SSLEngineResult$HandshakeStatus;
/*      */     //   79: if_acmpeq -> 90
/*      */     //   82: aload #11
/*      */     //   84: getstatic javax/net/ssl/SSLEngineResult$HandshakeStatus.NOT_HANDSHAKING : Ljavax/net/ssl/SSLEngineResult$HandshakeStatus;
/*      */     //   87: if_acmpne -> 133
/*      */     //   90: iload #5
/*      */     //   92: aload #8
/*      */     //   94: invokevirtual isReadable : ()Z
/*      */     //   97: ifeq -> 110
/*      */     //   100: aload_0
/*      */     //   101: invokespecial setHandshakeSuccessUnwrapMarkReentry : ()Z
/*      */     //   104: ifeq -> 117
/*      */     //   107: goto -> 125
/*      */     //   110: aload_0
/*      */     //   111: invokespecial setHandshakeSuccess : ()Z
/*      */     //   114: ifne -> 125
/*      */     //   117: aload #11
/*      */     //   119: getstatic javax/net/ssl/SSLEngineResult$HandshakeStatus.FINISHED : Ljavax/net/ssl/SSLEngineResult$HandshakeStatus;
/*      */     //   122: if_acmpne -> 129
/*      */     //   125: iconst_1
/*      */     //   126: goto -> 130
/*      */     //   129: iconst_0
/*      */     //   130: ior
/*      */     //   131: istore #5
/*      */     //   133: aload #8
/*      */     //   135: invokevirtual isReadable : ()Z
/*      */     //   138: ifeq -> 183
/*      */     //   141: aload_0
/*      */     //   142: sipush #256
/*      */     //   145: invokespecial setState : (I)V
/*      */     //   148: aload_0
/*      */     //   149: sipush #512
/*      */     //   152: invokespecial isStateSet : (I)Z
/*      */     //   155: ifeq -> 171
/*      */     //   158: iconst_1
/*      */     //   159: istore #7
/*      */     //   161: aload_0
/*      */     //   162: aload_1
/*      */     //   163: aload #8
/*      */     //   165: invokespecial executeChannelRead : (Lio/netty/channel/ChannelHandlerContext;Lio/netty/buffer/ByteBuf;)V
/*      */     //   168: goto -> 180
/*      */     //   171: aload_1
/*      */     //   172: aload #8
/*      */     //   174: invokeinterface fireChannelRead : (Ljava/lang/Object;)Lio/netty/channel/ChannelHandlerContext;
/*      */     //   179: pop
/*      */     //   180: aconst_null
/*      */     //   181: astore #8
/*      */     //   183: aload #10
/*      */     //   185: getstatic javax/net/ssl/SSLEngineResult$Status.CLOSED : Ljavax/net/ssl/SSLEngineResult$Status;
/*      */     //   188: if_acmpne -> 197
/*      */     //   191: iconst_1
/*      */     //   192: istore #6
/*      */     //   194: goto -> 265
/*      */     //   197: aload #10
/*      */     //   199: getstatic javax/net/ssl/SSLEngineResult$Status.BUFFER_OVERFLOW : Ljavax/net/ssl/SSLEngineResult$Status;
/*      */     //   202: if_acmpne -> 265
/*      */     //   205: aload #8
/*      */     //   207: ifnull -> 216
/*      */     //   210: aload #8
/*      */     //   212: invokevirtual release : ()Z
/*      */     //   215: pop
/*      */     //   216: aload_0
/*      */     //   217: getfield engine : Ljavax/net/ssl/SSLEngine;
/*      */     //   220: invokevirtual getSession : ()Ljavax/net/ssl/SSLSession;
/*      */     //   223: invokeinterface getApplicationBufferSize : ()I
/*      */     //   228: istore #14
/*      */     //   230: aload_0
/*      */     //   231: aload_1
/*      */     //   232: aload_0
/*      */     //   233: getfield engineType : Lio/netty/handler/ssl/SslHandler$SslEngineType;
/*      */     //   236: aload_0
/*      */     //   237: iload #14
/*      */     //   239: iload #12
/*      */     //   241: if_icmpge -> 249
/*      */     //   244: iload #14
/*      */     //   246: goto -> 254
/*      */     //   249: iload #14
/*      */     //   251: iload #12
/*      */     //   253: isub
/*      */     //   254: invokevirtual calculatePendingData : (Lio/netty/handler/ssl/SslHandler;I)I
/*      */     //   257: invokespecial allocate : (Lio/netty/channel/ChannelHandlerContext;I)Lio/netty/buffer/ByteBuf;
/*      */     //   260: astore #8
/*      */     //   262: goto -> 385
/*      */     //   265: aload #11
/*      */     //   267: getstatic javax/net/ssl/SSLEngineResult$HandshakeStatus.NEED_TASK : Ljavax/net/ssl/SSLEngineResult$HandshakeStatus;
/*      */     //   270: if_acmpne -> 294
/*      */     //   273: aload_0
/*      */     //   274: iconst_1
/*      */     //   275: invokespecial runDelegatedTasks : (Z)Z
/*      */     //   278: istore #14
/*      */     //   280: iload #14
/*      */     //   282: ifne -> 291
/*      */     //   285: iconst_0
/*      */     //   286: istore #5
/*      */     //   288: goto -> 394
/*      */     //   291: goto -> 318
/*      */     //   294: aload #11
/*      */     //   296: getstatic javax/net/ssl/SSLEngineResult$HandshakeStatus.NEED_WRAP : Ljavax/net/ssl/SSLEngineResult$HandshakeStatus;
/*      */     //   299: if_acmpne -> 318
/*      */     //   302: aload_0
/*      */     //   303: aload_1
/*      */     //   304: iconst_1
/*      */     //   305: invokespecial wrapNonAppData : (Lio/netty/channel/ChannelHandlerContext;Z)Z
/*      */     //   308: ifeq -> 318
/*      */     //   311: iload_3
/*      */     //   312: ifne -> 318
/*      */     //   315: goto -> 394
/*      */     //   318: aload #10
/*      */     //   320: getstatic javax/net/ssl/SSLEngineResult$Status.BUFFER_UNDERFLOW : Ljavax/net/ssl/SSLEngineResult$Status;
/*      */     //   323: if_acmpeq -> 356
/*      */     //   326: aload #11
/*      */     //   328: getstatic javax/net/ssl/SSLEngineResult$HandshakeStatus.NEED_TASK : Ljavax/net/ssl/SSLEngineResult$HandshakeStatus;
/*      */     //   331: if_acmpeq -> 372
/*      */     //   334: iload #13
/*      */     //   336: ifne -> 344
/*      */     //   339: iload #12
/*      */     //   341: ifeq -> 356
/*      */     //   344: iload_3
/*      */     //   345: ifne -> 372
/*      */     //   348: aload #11
/*      */     //   350: getstatic javax/net/ssl/SSLEngineResult$HandshakeStatus.NOT_HANDSHAKING : Ljavax/net/ssl/SSLEngineResult$HandshakeStatus;
/*      */     //   353: if_acmpne -> 372
/*      */     //   356: aload #11
/*      */     //   358: getstatic javax/net/ssl/SSLEngineResult$HandshakeStatus.NEED_UNWRAP : Ljavax/net/ssl/SSLEngineResult$HandshakeStatus;
/*      */     //   361: if_acmpne -> 394
/*      */     //   364: aload_0
/*      */     //   365: aload_1
/*      */     //   366: invokespecial readIfNeeded : (Lio/netty/channel/ChannelHandlerContext;)V
/*      */     //   369: goto -> 394
/*      */     //   372: aload #8
/*      */     //   374: ifnonnull -> 385
/*      */     //   377: aload_0
/*      */     //   378: aload_1
/*      */     //   379: iload_3
/*      */     //   380: invokespecial allocate : (Lio/netty/channel/ChannelHandlerContext;I)Lio/netty/buffer/ByteBuf;
/*      */     //   383: astore #8
/*      */     //   385: aload_1
/*      */     //   386: invokeinterface isRemoved : ()Z
/*      */     //   391: ifeq -> 20
/*      */     //   394: aload_0
/*      */     //   395: iconst_2
/*      */     //   396: invokespecial isStateSet : (I)Z
/*      */     //   399: ifeq -> 422
/*      */     //   402: aload_0
/*      */     //   403: getfield handshakePromise : Lio/netty/util/concurrent/Promise;
/*      */     //   406: invokeinterface isDone : ()Z
/*      */     //   411: ifeq -> 422
/*      */     //   414: aload_0
/*      */     //   415: iconst_2
/*      */     //   416: invokespecial clearState : (I)V
/*      */     //   419: iconst_1
/*      */     //   420: istore #5
/*      */     //   422: iload #5
/*      */     //   424: ifeq -> 433
/*      */     //   427: aload_0
/*      */     //   428: aload_1
/*      */     //   429: iconst_1
/*      */     //   430: invokespecial wrap : (Lio/netty/channel/ChannelHandlerContext;Z)V
/*      */     //   433: aload #8
/*      */     //   435: ifnull -> 444
/*      */     //   438: aload #8
/*      */     //   440: invokevirtual release : ()Z
/*      */     //   443: pop
/*      */     //   444: iload #6
/*      */     //   446: ifeq -> 509
/*      */     //   449: iload #7
/*      */     //   451: ifeq -> 462
/*      */     //   454: aload_0
/*      */     //   455: aload_1
/*      */     //   456: invokespecial executeNotifyClosePromise : (Lio/netty/channel/ChannelHandlerContext;)V
/*      */     //   459: goto -> 509
/*      */     //   462: aload_0
/*      */     //   463: aconst_null
/*      */     //   464: invokespecial notifyClosePromise : (Ljava/lang/Throwable;)V
/*      */     //   467: goto -> 509
/*      */     //   470: astore #15
/*      */     //   472: aload #8
/*      */     //   474: ifnull -> 483
/*      */     //   477: aload #8
/*      */     //   479: invokevirtual release : ()Z
/*      */     //   482: pop
/*      */     //   483: iload #6
/*      */     //   485: ifeq -> 506
/*      */     //   488: iload #7
/*      */     //   490: ifeq -> 501
/*      */     //   493: aload_0
/*      */     //   494: aload_1
/*      */     //   495: invokespecial executeNotifyClosePromise : (Lio/netty/channel/ChannelHandlerContext;)V
/*      */     //   498: goto -> 506
/*      */     //   501: aload_0
/*      */     //   502: aconst_null
/*      */     //   503: invokespecial notifyClosePromise : (Ljava/lang/Throwable;)V
/*      */     //   506: aload #15
/*      */     //   508: athrow
/*      */     //   509: iload #4
/*      */     //   511: iload_3
/*      */     //   512: isub
/*      */     //   513: ireturn
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #1344	-> 0
/*      */     //   #1345	-> 3
/*      */     //   #1346	-> 6
/*      */     //   #1347	-> 9
/*      */     //   #1348	-> 12
/*      */     //   #1353	-> 20
/*      */     //   #1354	-> 34
/*      */     //   #1355	-> 41
/*      */     //   #1356	-> 48
/*      */     //   #1357	-> 55
/*      */     //   #1362	-> 62
/*      */     //   #1363	-> 69
/*      */     //   #1368	-> 74
/*      */     //   #1369	-> 90
/*      */     //   #1370	-> 101
/*      */     //   #1377	-> 133
/*      */     //   #1378	-> 141
/*      */     //   #1379	-> 148
/*      */     //   #1380	-> 158
/*      */     //   #1381	-> 161
/*      */     //   #1383	-> 171
/*      */     //   #1385	-> 180
/*      */     //   #1388	-> 183
/*      */     //   #1389	-> 191
/*      */     //   #1390	-> 197
/*      */     //   #1391	-> 205
/*      */     //   #1392	-> 210
/*      */     //   #1394	-> 216
/*      */     //   #1399	-> 230
/*      */     //   #1401	-> 262
/*      */     //   #1404	-> 265
/*      */     //   #1405	-> 273
/*      */     //   #1406	-> 280
/*      */     //   #1412	-> 285
/*      */     //   #1413	-> 288
/*      */     //   #1415	-> 291
/*      */     //   #1419	-> 302
/*      */     //   #1420	-> 315
/*      */     //   #1424	-> 318
/*      */     //   #1428	-> 356
/*      */     //   #1431	-> 364
/*      */     //   #1435	-> 372
/*      */     //   #1436	-> 377
/*      */     //   #1438	-> 385
/*      */     //   #1440	-> 394
/*      */     //   #1445	-> 414
/*      */     //   #1446	-> 419
/*      */     //   #1449	-> 422
/*      */     //   #1450	-> 427
/*      */     //   #1453	-> 433
/*      */     //   #1454	-> 438
/*      */     //   #1457	-> 444
/*      */     //   #1458	-> 449
/*      */     //   #1459	-> 454
/*      */     //   #1461	-> 462
/*      */     //   #1453	-> 470
/*      */     //   #1454	-> 477
/*      */     //   #1457	-> 483
/*      */     //   #1458	-> 488
/*      */     //   #1459	-> 493
/*      */     //   #1461	-> 501
/*      */     //   #1464	-> 506
/*      */     //   #1465	-> 509
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   230	35	14	applicationBufferSize	I
/*      */     //   280	11	14	pending	Z
/*      */     //   34	351	9	result	Ljavax/net/ssl/SSLEngineResult;
/*      */     //   41	344	10	status	Ljavax/net/ssl/SSLEngineResult$Status;
/*      */     //   48	337	11	handshakeStatus	Ljavax/net/ssl/SSLEngineResult$HandshakeStatus;
/*      */     //   55	330	12	produced	I
/*      */     //   62	323	13	consumed	I
/*      */     //   0	514	0	this	Lio/netty/handler/ssl/SslHandler;
/*      */     //   0	514	1	ctx	Lio/netty/channel/ChannelHandlerContext;
/*      */     //   0	514	2	packet	Lio/netty/buffer/ByteBuf;
/*      */     //   0	514	3	length	I
/*      */     //   3	511	4	originalLength	I
/*      */     //   6	508	5	wrapLater	Z
/*      */     //   9	505	6	notifyClosure	Z
/*      */     //   12	502	7	executedRead	Z
/*      */     //   20	494	8	decodeOut	Lio/netty/buffer/ByteBuf;
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   20	433	470	finally
/*      */     //   470	472	470	finally
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean setHandshakeSuccessUnwrapMarkReentry() {
/* 1471 */     boolean setReentryState = !isStateSet(512);
/* 1472 */     if (setReentryState) {
/* 1473 */       setState(512);
/*      */     }
/*      */     try {
/* 1476 */       return setHandshakeSuccess();
/*      */     }
/*      */     finally {
/*      */       
/* 1480 */       if (setReentryState) {
/* 1481 */         clearState(512);
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   private void executeNotifyClosePromise(ChannelHandlerContext ctx) {
/*      */     try {
/* 1488 */       ctx.executor().execute(new Runnable()
/*      */           {
/*      */             public void run() {
/* 1491 */               SslHandler.this.notifyClosePromise((Throwable)null);
/*      */             }
/*      */           });
/* 1494 */     } catch (RejectedExecutionException e) {
/* 1495 */       notifyClosePromise(e);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void executeChannelRead(final ChannelHandlerContext ctx, final ByteBuf decodedOut) {
/*      */     try {
/* 1501 */       ctx.executor().execute(new Runnable()
/*      */           {
/*      */             public void run() {
/* 1504 */               ctx.fireChannelRead(decodedOut);
/*      */             }
/*      */           });
/* 1507 */     } catch (RejectedExecutionException e) {
/* 1508 */       decodedOut.release();
/* 1509 */       throw e;
/*      */     } 
/*      */   }
/*      */   
/*      */   private static ByteBuffer toByteBuffer(ByteBuf out, int index, int len) {
/* 1514 */     return (out.nioBufferCount() == 1) ? out.internalNioBuffer(index, len) : out
/* 1515 */       .nioBuffer(index, len);
/*      */   }
/*      */   
/*      */   private static boolean inEventLoop(Executor executor) {
/* 1519 */     return (executor instanceof EventExecutor && ((EventExecutor)executor).inEventLoop());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean runDelegatedTasks(boolean inUnwrap) {
/* 1530 */     if (this.delegatedTaskExecutor == ImmediateExecutor.INSTANCE || inEventLoop(this.delegatedTaskExecutor))
/*      */     {
/*      */       while (true) {
/*      */         
/* 1534 */         Runnable task = this.engine.getDelegatedTask();
/* 1535 */         if (task == null) {
/* 1536 */           return true;
/*      */         }
/* 1538 */         setState(128);
/* 1539 */         if (task instanceof AsyncRunnable) {
/*      */           
/* 1541 */           boolean pending = false;
/*      */           try {
/* 1543 */             AsyncRunnable asyncTask = (AsyncRunnable)task;
/* 1544 */             AsyncTaskCompletionHandler completionHandler = new AsyncTaskCompletionHandler(inUnwrap);
/* 1545 */             asyncTask.run(completionHandler);
/* 1546 */             pending = completionHandler.resumeLater();
/* 1547 */             if (pending) {
/* 1548 */               return false;
/*      */             }
/*      */           } finally {
/* 1551 */             if (!pending)
/*      */             {
/*      */               
/* 1554 */               clearState(128); } 
/*      */           } 
/*      */           continue;
/*      */         } 
/*      */         try {
/* 1559 */           task.run();
/*      */         } finally {
/* 1561 */           clearState(128);
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/* 1566 */     executeDelegatedTask(inUnwrap);
/* 1567 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private SslTasksRunner getTaskRunner(boolean inUnwrap) {
/* 1572 */     return inUnwrap ? this.sslTaskRunnerForUnwrap : this.sslTaskRunner;
/*      */   }
/*      */   
/*      */   private void executeDelegatedTask(boolean inUnwrap) {
/* 1576 */     executeDelegatedTask(getTaskRunner(inUnwrap));
/*      */   }
/*      */   
/*      */   private void executeDelegatedTask(SslTasksRunner task) {
/* 1580 */     setState(128);
/*      */     try {
/* 1582 */       this.delegatedTaskExecutor.execute(task);
/* 1583 */     } catch (RejectedExecutionException e) {
/* 1584 */       clearState(128);
/* 1585 */       throw e;
/*      */     } 
/*      */   }
/*      */   
/*      */   private final class AsyncTaskCompletionHandler implements Runnable {
/*      */     private final boolean inUnwrap;
/*      */     boolean didRun;
/*      */     boolean resumeLater;
/*      */     
/*      */     AsyncTaskCompletionHandler(boolean inUnwrap) {
/* 1595 */       this.inUnwrap = inUnwrap;
/*      */     }
/*      */ 
/*      */     
/*      */     public void run() {
/* 1600 */       this.didRun = true;
/* 1601 */       if (this.resumeLater) {
/* 1602 */         SslHandler.this.getTaskRunner(this.inUnwrap).runComplete();
/*      */       }
/*      */     }
/*      */     
/*      */     boolean resumeLater() {
/* 1607 */       if (!this.didRun) {
/* 1608 */         this.resumeLater = true;
/* 1609 */         return true;
/*      */       } 
/* 1611 */       return false;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private final class SslTasksRunner
/*      */     implements Runnable
/*      */   {
/*      */     private final boolean inUnwrap;
/*      */     
/* 1621 */     private final Runnable runCompleteTask = new Runnable()
/*      */       {
/*      */         public void run() {
/* 1624 */           SslHandler.SslTasksRunner.this.runComplete();
/*      */         }
/*      */       };
/*      */     
/*      */     SslTasksRunner(boolean inUnwrap) {
/* 1629 */       this.inUnwrap = inUnwrap;
/*      */     }
/*      */ 
/*      */     
/*      */     private void taskError(Throwable e) {
/* 1634 */       if (this.inUnwrap) {
/*      */ 
/*      */         
/*      */         try {
/*      */ 
/*      */           
/* 1640 */           SslHandler.this.handleUnwrapThrowable(SslHandler.this.ctx, e);
/* 1641 */         } catch (Throwable cause) {
/* 1642 */           safeExceptionCaught(cause);
/*      */         } 
/*      */       } else {
/* 1645 */         SslHandler.this.setHandshakeFailure(SslHandler.this.ctx, e);
/* 1646 */         SslHandler.this.forceFlush(SslHandler.this.ctx);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     private void safeExceptionCaught(Throwable cause) {
/*      */       try {
/* 1653 */         SslHandler.this.exceptionCaught(SslHandler.this.ctx, wrapIfNeeded(cause));
/* 1654 */       } catch (Throwable error) {
/* 1655 */         SslHandler.this.ctx.fireExceptionCaught(error);
/*      */       } 
/*      */     }
/*      */     
/*      */     private Throwable wrapIfNeeded(Throwable cause) {
/* 1660 */       if (!this.inUnwrap)
/*      */       {
/* 1662 */         return cause;
/*      */       }
/*      */ 
/*      */       
/* 1666 */       return (cause instanceof DecoderException) ? cause : (Throwable)new DecoderException(cause);
/*      */     }
/*      */     
/*      */     private void tryDecodeAgain() {
/*      */       try {
/* 1671 */         SslHandler.this.channelRead(SslHandler.this.ctx, Unpooled.EMPTY_BUFFER);
/* 1672 */       } catch (Throwable cause) {
/* 1673 */         safeExceptionCaught(cause);
/*      */       
/*      */       }
/*      */       finally {
/*      */         
/* 1678 */         SslHandler.this.channelReadComplete0(SslHandler.this.ctx);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void resumeOnEventExecutor() {
/* 1687 */       assert SslHandler.this.ctx.executor().inEventLoop();
/* 1688 */       SslHandler.this.clearState(128);
/*      */       try {
/* 1690 */         SSLEngineResult.HandshakeStatus status = SslHandler.this.engine.getHandshakeStatus();
/* 1691 */         switch (status) {
/*      */ 
/*      */           
/*      */           case NEED_TASK:
/* 1695 */             SslHandler.this.executeDelegatedTask(this);
/*      */             return;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case FINISHED:
/*      */           case NOT_HANDSHAKING:
/* 1703 */             SslHandler.this.setHandshakeSuccess();
/*      */ 
/*      */             
/*      */             try {
/* 1707 */               SslHandler.this.wrap(SslHandler.this.ctx, this.inUnwrap);
/* 1708 */             } catch (Throwable e) {
/* 1709 */               taskError(e);
/*      */               return;
/*      */             } 
/* 1712 */             if (this.inUnwrap)
/*      */             {
/*      */               
/* 1715 */               SslHandler.this.unwrapNonAppData(SslHandler.this.ctx);
/*      */             }
/*      */ 
/*      */             
/* 1719 */             SslHandler.this.forceFlush(SslHandler.this.ctx);
/*      */             
/* 1721 */             tryDecodeAgain();
/*      */             return;
/*      */ 
/*      */ 
/*      */           
/*      */           case NEED_UNWRAP:
/*      */             try {
/* 1728 */               SslHandler.this.unwrapNonAppData(SslHandler.this.ctx);
/* 1729 */             } catch (SSLException e) {
/* 1730 */               SslHandler.this.handleUnwrapThrowable(SslHandler.this.ctx, e);
/*      */               return;
/*      */             } 
/* 1733 */             tryDecodeAgain();
/*      */             return;
/*      */ 
/*      */ 
/*      */           
/*      */           case NEED_WRAP:
/*      */             try {
/* 1740 */               if (!SslHandler.this.wrapNonAppData(SslHandler.this.ctx, false) && this.inUnwrap)
/*      */               {
/*      */ 
/*      */ 
/*      */                 
/* 1745 */                 SslHandler.this.unwrapNonAppData(SslHandler.this.ctx);
/*      */               }
/*      */ 
/*      */               
/* 1749 */               SslHandler.this.forceFlush(SslHandler.this.ctx);
/* 1750 */             } catch (Throwable e) {
/* 1751 */               taskError(e);
/*      */               
/*      */               return;
/*      */             } 
/*      */             
/* 1756 */             tryDecodeAgain();
/*      */             return;
/*      */         } 
/*      */ 
/*      */         
/* 1761 */         throw new AssertionError();
/*      */       }
/* 1763 */       catch (Throwable cause) {
/* 1764 */         safeExceptionCaught(cause);
/*      */       } 
/*      */     }
/*      */     
/*      */     void runComplete() {
/* 1769 */       EventExecutor executor = SslHandler.this.ctx.executor();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1777 */       executor.execute(new Runnable()
/*      */           {
/*      */             public void run() {
/* 1780 */               SslHandler.SslTasksRunner.this.resumeOnEventExecutor();
/*      */             }
/*      */           });
/*      */     }
/*      */ 
/*      */     
/*      */     public void run() {
/*      */       try {
/* 1788 */         Runnable task = SslHandler.this.engine.getDelegatedTask();
/* 1789 */         if (task == null) {
/*      */           return;
/*      */         }
/*      */         
/* 1793 */         if (task instanceof AsyncRunnable) {
/* 1794 */           AsyncRunnable asyncTask = (AsyncRunnable)task;
/* 1795 */           asyncTask.run(this.runCompleteTask);
/*      */         } else {
/* 1797 */           task.run();
/* 1798 */           runComplete();
/*      */         } 
/* 1800 */       } catch (Throwable cause) {
/* 1801 */         handleException(cause);
/*      */       } 
/*      */     }
/*      */     
/*      */     private void handleException(final Throwable cause) {
/* 1806 */       EventExecutor executor = SslHandler.this.ctx.executor();
/* 1807 */       if (executor.inEventLoop()) {
/* 1808 */         SslHandler.this.clearState(128);
/* 1809 */         safeExceptionCaught(cause);
/*      */       } else {
/*      */         try {
/* 1812 */           executor.execute(new Runnable()
/*      */               {
/*      */                 public void run() {
/* 1815 */                   SslHandler.this.clearState(128);
/* 1816 */                   SslHandler.SslTasksRunner.this.safeExceptionCaught(cause);
/*      */                 }
/*      */               });
/* 1819 */         } catch (RejectedExecutionException ignore) {
/* 1820 */           SslHandler.this.clearState(128);
/*      */ 
/*      */           
/* 1823 */           SslHandler.this.ctx.fireExceptionCaught(cause);
/*      */         } 
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean setHandshakeSuccess() {
/*      */     boolean notified;
/* 1839 */     if (notified = (!this.handshakePromise.isDone() && this.handshakePromise.trySuccess(this.ctx.channel()))) {
/* 1840 */       if (logger.isDebugEnabled()) {
/* 1841 */         SSLSession session = this.engine.getSession();
/* 1842 */         logger.debug("{} HANDSHAKEN: protocol:{} cipher suite:{}", new Object[] { this.ctx
/*      */               
/* 1844 */               .channel(), session
/* 1845 */               .getProtocol(), session
/* 1846 */               .getCipherSuite() });
/*      */       } 
/* 1848 */       this.ctx.fireUserEventTriggered(SslHandshakeCompletionEvent.SUCCESS);
/*      */     } 
/* 1850 */     if (isStateSet(4)) {
/* 1851 */       clearState(4);
/* 1852 */       if (!this.ctx.channel().config().isAutoRead()) {
/* 1853 */         this.ctx.read();
/*      */       }
/*      */     } 
/* 1856 */     return notified;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setHandshakeFailure(ChannelHandlerContext ctx, Throwable cause) {
/* 1863 */     setHandshakeFailure(ctx, cause, true, true, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setHandshakeFailure(ChannelHandlerContext ctx, Throwable cause, boolean closeInbound, boolean notify, boolean alwaysFlushAndClose) {
/*      */     try {
/* 1873 */       setState(32);
/* 1874 */       this.engine.closeOutbound();
/*      */       
/* 1876 */       if (closeInbound) {
/*      */         try {
/* 1878 */           this.engine.closeInbound();
/* 1879 */         } catch (SSLException e) {
/* 1880 */           if (logger.isDebugEnabled()) {
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1885 */             String msg = e.getMessage();
/* 1886 */             if (msg == null || (!msg.contains("possible truncation attack") && 
/* 1887 */               !msg.contains("closing inbound before receiving peer's close_notify"))) {
/* 1888 */               logger.debug("{} SSLEngine.closeInbound() raised an exception.", ctx.channel(), e);
/*      */             }
/*      */           } 
/*      */         } 
/*      */       }
/* 1893 */       if (this.handshakePromise.tryFailure(cause) || alwaysFlushAndClose) {
/* 1894 */         SslUtils.handleHandshakeFailure(ctx, cause, notify);
/*      */       }
/*      */     } finally {
/*      */       
/* 1898 */       releaseAndFailAll(ctx, cause);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setHandshakeFailureTransportFailure(ChannelHandlerContext ctx, Throwable cause) {
/*      */     try {
/* 1907 */       SSLException transportFailure = new SSLException("failure when writing TLS control frames", cause);
/* 1908 */       releaseAndFailAll(ctx, transportFailure);
/* 1909 */       if (this.handshakePromise.tryFailure(transportFailure)) {
/* 1910 */         ctx.fireUserEventTriggered(new SslHandshakeCompletionEvent(transportFailure));
/*      */       }
/*      */     } finally {
/* 1913 */       ctx.close();
/*      */     } 
/*      */   }
/*      */   
/*      */   private void releaseAndFailAll(ChannelHandlerContext ctx, Throwable cause) {
/* 1918 */     if (this.pendingUnencryptedWrites != null) {
/* 1919 */       this.pendingUnencryptedWrites.releaseAndFailAll((ChannelOutboundInvoker)ctx, cause);
/*      */     }
/*      */   }
/*      */   
/*      */   private void notifyClosePromise(Throwable cause) {
/* 1924 */     if (cause == null) {
/* 1925 */       if (this.sslClosePromise.trySuccess(this.ctx.channel())) {
/* 1926 */         this.ctx.fireUserEventTriggered(SslCloseCompletionEvent.SUCCESS);
/*      */       }
/*      */     }
/* 1929 */     else if (this.sslClosePromise.tryFailure(cause)) {
/* 1930 */       this.ctx.fireUserEventTriggered(new SslCloseCompletionEvent(cause));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void closeOutboundAndChannel(ChannelHandlerContext ctx, final ChannelPromise promise, boolean disconnect) throws Exception {
/* 1937 */     setState(32);
/* 1938 */     this.engine.closeOutbound();
/*      */     
/* 1940 */     if (!ctx.channel().isActive()) {
/* 1941 */       if (disconnect) {
/* 1942 */         ctx.disconnect(promise);
/*      */       } else {
/* 1944 */         ctx.close(promise);
/*      */       } 
/*      */       
/*      */       return;
/*      */     } 
/* 1949 */     ChannelPromise closeNotifyPromise = ctx.newPromise();
/*      */     try {
/* 1951 */       flush(ctx, closeNotifyPromise);
/*      */     } finally {
/* 1953 */       if (!isStateSet(64)) {
/* 1954 */         setState(64);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1963 */         safeClose(ctx, (ChannelFuture)closeNotifyPromise, (ChannelPromise)PromiseNotifier.cascade(false, (Future)ctx.newPromise(), (Promise)promise));
/*      */       } else {
/*      */         
/* 1966 */         this.sslClosePromise.addListener((GenericFutureListener)new FutureListener<Channel>()
/*      */             {
/*      */               public void operationComplete(Future<Channel> future) {
/* 1969 */                 promise.setSuccess();
/*      */               }
/*      */             });
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private void flush(ChannelHandlerContext ctx, ChannelPromise promise) throws Exception {
/* 1977 */     if (this.pendingUnencryptedWrites != null) {
/* 1978 */       this.pendingUnencryptedWrites.add(Unpooled.EMPTY_BUFFER, promise);
/*      */     } else {
/* 1980 */       promise.setFailure(newPendingWritesNullException());
/*      */     } 
/* 1982 */     flush(ctx);
/*      */   }
/*      */ 
/*      */   
/*      */   public void handlerAdded(ChannelHandlerContext ctx) throws Exception {
/* 1987 */     this.ctx = ctx;
/* 1988 */     Channel channel = ctx.channel();
/* 1989 */     this.pendingUnencryptedWrites = new SslHandlerCoalescingBufferQueue(channel, 16);
/*      */     
/* 1991 */     setOpensslEngineSocketFd(channel);
/* 1992 */     boolean fastOpen = Boolean.TRUE.equals(channel.config().getOption(ChannelOption.TCP_FASTOPEN_CONNECT));
/* 1993 */     boolean active = channel.isActive();
/* 1994 */     if (active || fastOpen) {
/*      */ 
/*      */ 
/*      */       
/* 1998 */       startHandshakeProcessing(active);
/*      */       
/*      */       ChannelOutboundBuffer outboundBuffer;
/*      */       
/* 2002 */       if (fastOpen && ((outboundBuffer = channel.unsafe().outboundBuffer()) == null || outboundBuffer
/* 2003 */         .totalPendingWriteBytes() > 0L)) {
/* 2004 */         setState(16);
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   private void startHandshakeProcessing(boolean flushAtEnd) {
/* 2010 */     if (!isStateSet(8)) {
/* 2011 */       setState(8);
/* 2012 */       if (this.engine.getUseClientMode())
/*      */       {
/*      */ 
/*      */         
/* 2016 */         handshake(flushAtEnd);
/*      */       }
/* 2018 */       applyHandshakeTimeout();
/* 2019 */     } else if (isStateSet(16)) {
/* 2020 */       forceFlush(this.ctx);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Future<Channel> renegotiate() {
/* 2028 */     ChannelHandlerContext ctx = this.ctx;
/* 2029 */     if (ctx == null) {
/* 2030 */       throw new IllegalStateException();
/*      */     }
/*      */     
/* 2033 */     return renegotiate(ctx.executor().newPromise());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Future<Channel> renegotiate(final Promise<Channel> promise) {
/* 2040 */     ObjectUtil.checkNotNull(promise, "promise");
/*      */     
/* 2042 */     ChannelHandlerContext ctx = this.ctx;
/* 2043 */     if (ctx == null) {
/* 2044 */       throw new IllegalStateException();
/*      */     }
/*      */     
/* 2047 */     EventExecutor executor = ctx.executor();
/* 2048 */     if (!executor.inEventLoop()) {
/* 2049 */       executor.execute(new Runnable()
/*      */           {
/*      */             public void run() {
/* 2052 */               SslHandler.this.renegotiateOnEventLoop(promise);
/*      */             }
/*      */           });
/* 2055 */       return (Future<Channel>)promise;
/*      */     } 
/*      */     
/* 2058 */     renegotiateOnEventLoop(promise);
/* 2059 */     return (Future<Channel>)promise;
/*      */   }
/*      */   
/*      */   private void renegotiateOnEventLoop(Promise<Channel> newHandshakePromise) {
/* 2063 */     Promise<Channel> oldHandshakePromise = this.handshakePromise;
/* 2064 */     if (!oldHandshakePromise.isDone()) {
/*      */ 
/*      */       
/* 2067 */       PromiseNotifier.cascade((Future)oldHandshakePromise, newHandshakePromise);
/*      */     } else {
/* 2069 */       this.handshakePromise = newHandshakePromise;
/* 2070 */       handshake(true);
/* 2071 */       applyHandshakeTimeout();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void handshake(boolean flushAtEnd) {
/* 2082 */     if (this.engine.getHandshakeStatus() != SSLEngineResult.HandshakeStatus.NOT_HANDSHAKING) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/* 2087 */     if (this.handshakePromise.isDone()) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2097 */     ChannelHandlerContext ctx = this.ctx;
/*      */     try {
/* 2099 */       this.engine.beginHandshake();
/* 2100 */       wrapNonAppData(ctx, false);
/* 2101 */     } catch (Throwable e) {
/* 2102 */       setHandshakeFailure(ctx, e);
/*      */     } finally {
/* 2104 */       if (flushAtEnd) {
/* 2105 */         forceFlush(ctx);
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   private void applyHandshakeTimeout() {
/* 2111 */     final Promise<Channel> localHandshakePromise = this.handshakePromise;
/*      */ 
/*      */     
/* 2114 */     final long handshakeTimeoutMillis = this.handshakeTimeoutMillis;
/* 2115 */     if (handshakeTimeoutMillis <= 0L || localHandshakePromise.isDone()) {
/*      */       return;
/*      */     }
/*      */     
/* 2119 */     final ScheduledFuture timeoutFuture = this.ctx.executor().schedule(new Runnable()
/*      */         {
/*      */           public void run() {
/* 2122 */             if (localHandshakePromise.isDone()) {
/*      */               return;
/*      */             }
/* 2125 */             SSLException exception = new SslHandshakeTimeoutException("handshake timed out after " + handshakeTimeoutMillis + "ms");
/*      */             
/*      */             try {
/* 2128 */               if (localHandshakePromise.tryFailure(exception)) {
/* 2129 */                 SslUtils.handleHandshakeFailure(SslHandler.this.ctx, exception, true);
/*      */               }
/*      */             } finally {
/* 2132 */               SslHandler.this.releaseAndFailAll(SslHandler.this.ctx, exception);
/*      */             } 
/*      */           }
/*      */         }handshakeTimeoutMillis, TimeUnit.MILLISECONDS);
/*      */ 
/*      */     
/* 2138 */     localHandshakePromise.addListener((GenericFutureListener)new FutureListener<Channel>()
/*      */         {
/*      */           public void operationComplete(Future<Channel> f) throws Exception {
/* 2141 */             timeoutFuture.cancel(false);
/*      */           }
/*      */         });
/*      */   }
/*      */   
/*      */   private void forceFlush(ChannelHandlerContext ctx) {
/* 2147 */     clearState(16);
/* 2148 */     ctx.flush();
/*      */   }
/*      */   
/*      */   private void setOpensslEngineSocketFd(Channel c) {
/* 2152 */     if (c instanceof UnixChannel && this.engine instanceof ReferenceCountedOpenSslEngine) {
/* 2153 */       ((ReferenceCountedOpenSslEngine)this.engine).bioSetFd(((UnixChannel)c).fd().intValue());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void channelActive(ChannelHandlerContext ctx) throws Exception {
/* 2162 */     setOpensslEngineSocketFd(ctx.channel());
/* 2163 */     if (!this.startTls) {
/* 2164 */       startHandshakeProcessing(true);
/*      */     }
/* 2166 */     ctx.fireChannelActive();
/*      */   }
/*      */ 
/*      */   
/*      */   private void safeClose(final ChannelHandlerContext ctx, final ChannelFuture flushFuture, final ChannelPromise promise) {
/*      */     final Future<?> timeoutFuture;
/* 2172 */     if (!ctx.channel().isActive()) {
/* 2173 */       ctx.close(promise);
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 2178 */     if (!flushFuture.isDone()) {
/* 2179 */       long closeNotifyTimeout = this.closeNotifyFlushTimeoutMillis;
/* 2180 */       if (closeNotifyTimeout > 0L) {
/*      */         
/* 2182 */         ScheduledFuture scheduledFuture = ctx.executor().schedule(new Runnable()
/*      */             {
/*      */               public void run()
/*      */               {
/* 2186 */                 if (!flushFuture.isDone()) {
/* 2187 */                   SslHandler.logger.warn("{} Last write attempt timed out; force-closing the connection.", ctx
/* 2188 */                       .channel());
/* 2189 */                   SslHandler.addCloseListener(ctx.close(ctx.newPromise()), promise);
/*      */                 } 
/*      */               }
/*      */             }closeNotifyTimeout, TimeUnit.MILLISECONDS);
/*      */       } else {
/* 2194 */         timeoutFuture = null;
/*      */       } 
/*      */     } else {
/* 2197 */       timeoutFuture = null;
/*      */     } 
/*      */ 
/*      */     
/* 2201 */     flushFuture.addListener((GenericFutureListener)new ChannelFutureListener()
/*      */         {
/*      */           public void operationComplete(ChannelFuture f) {
/* 2204 */             if (timeoutFuture != null) {
/* 2205 */               timeoutFuture.cancel(false);
/*      */             }
/* 2207 */             final long closeNotifyReadTimeout = SslHandler.this.closeNotifyReadTimeoutMillis;
/* 2208 */             if (closeNotifyReadTimeout <= 0L) {
/*      */ 
/*      */               
/* 2211 */               SslHandler.addCloseListener(ctx.close(ctx.newPromise()), promise);
/*      */             } else {
/*      */               final Future<?> closeNotifyReadTimeoutFuture;
/*      */               
/* 2215 */               if (!SslHandler.this.sslClosePromise.isDone()) {
/* 2216 */                 ScheduledFuture scheduledFuture = ctx.executor().schedule(new Runnable()
/*      */                     {
/*      */                       public void run() {
/* 2219 */                         if (!SslHandler.this.sslClosePromise.isDone()) {
/* 2220 */                           SslHandler.logger.debug("{} did not receive close_notify in {}ms; force-closing the connection.", ctx
/*      */                               
/* 2222 */                               .channel(), Long.valueOf(closeNotifyReadTimeout));
/*      */ 
/*      */                           
/* 2225 */                           SslHandler.addCloseListener(ctx.close(ctx.newPromise()), promise);
/*      */                         } 
/*      */                       }
/*      */                     }closeNotifyReadTimeout, TimeUnit.MILLISECONDS);
/*      */               } else {
/* 2230 */                 closeNotifyReadTimeoutFuture = null;
/*      */               } 
/*      */ 
/*      */               
/* 2234 */               SslHandler.this.sslClosePromise.addListener((GenericFutureListener)new FutureListener<Channel>()
/*      */                   {
/*      */                     public void operationComplete(Future<Channel> future) throws Exception {
/* 2237 */                       if (closeNotifyReadTimeoutFuture != null) {
/* 2238 */                         closeNotifyReadTimeoutFuture.cancel(false);
/*      */                       }
/* 2240 */                       SslHandler.addCloseListener(ctx.close(ctx.newPromise()), promise);
/*      */                     }
/*      */                   });
/*      */             } 
/*      */           }
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void addCloseListener(ChannelFuture future, ChannelPromise promise) {
/* 2255 */     PromiseNotifier.cascade(false, (Future)future, (Promise)promise);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ByteBuf allocate(ChannelHandlerContext ctx, int capacity) {
/* 2263 */     ByteBufAllocator alloc = ctx.alloc();
/* 2264 */     if (this.engineType.wantsDirectBuffer) {
/* 2265 */       return alloc.directBuffer(capacity);
/*      */     }
/* 2267 */     return alloc.buffer(capacity);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ByteBuf allocateOutNetBuf(ChannelHandlerContext ctx, int pendingBytes, int numComponents) {
/* 2276 */     return this.engineType.allocateWrapBuffer(this, ctx.alloc(), pendingBytes, numComponents);
/*      */   }
/*      */   
/*      */   private boolean isStateSet(int bit) {
/* 2280 */     return ((this.state & bit) == bit);
/*      */   }
/*      */   
/*      */   private void setState(int bit) {
/* 2284 */     this.state = (short)(this.state | bit);
/*      */   }
/*      */   
/*      */   private void clearState(int bit) {
/* 2288 */     this.state = (short)(this.state & (bit ^ 0xFFFFFFFF));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final class SslHandlerCoalescingBufferQueue
/*      */     extends AbstractCoalescingBufferQueue
/*      */   {
/*      */     SslHandlerCoalescingBufferQueue(Channel channel, int initSize) {
/* 2299 */       super(channel, initSize);
/*      */     }
/*      */ 
/*      */     
/*      */     protected ByteBuf compose(ByteBufAllocator alloc, ByteBuf cumulation, ByteBuf next) {
/* 2304 */       int wrapDataSize = SslHandler.this.wrapDataSize;
/* 2305 */       if (cumulation instanceof CompositeByteBuf) {
/* 2306 */         CompositeByteBuf composite = (CompositeByteBuf)cumulation;
/* 2307 */         int numComponents = composite.numComponents();
/* 2308 */         if (numComponents == 0 || 
/* 2309 */           !SslHandler.attemptCopyToCumulation(composite.internalComponent(numComponents - 1), next, wrapDataSize)) {
/* 2310 */           composite.addComponent(true, next);
/*      */         }
/* 2312 */         return (ByteBuf)composite;
/*      */       } 
/* 2314 */       return SslHandler.attemptCopyToCumulation(cumulation, next, wrapDataSize) ? cumulation : 
/* 2315 */         copyAndCompose(alloc, cumulation, next);
/*      */     }
/*      */ 
/*      */     
/*      */     protected ByteBuf composeFirst(ByteBufAllocator allocator, ByteBuf first) {
/* 2320 */       if (first instanceof CompositeByteBuf) {
/* 2321 */         CompositeByteBuf composite = (CompositeByteBuf)first;
/* 2322 */         if (SslHandler.this.engineType.wantsDirectBuffer) {
/* 2323 */           first = allocator.directBuffer(composite.readableBytes());
/*      */         } else {
/* 2325 */           first = allocator.heapBuffer(composite.readableBytes());
/*      */         } 
/*      */         try {
/* 2328 */           first.writeBytes((ByteBuf)composite);
/* 2329 */         } catch (Throwable cause) {
/* 2330 */           first.release();
/* 2331 */           PlatformDependent.throwException(cause);
/*      */         } 
/* 2333 */         composite.release();
/*      */       } 
/* 2335 */       return first;
/*      */     }
/*      */ 
/*      */     
/*      */     protected ByteBuf removeEmptyValue() {
/* 2340 */       return null;
/*      */     }
/*      */   }
/*      */   
/*      */   private static boolean attemptCopyToCumulation(ByteBuf cumulation, ByteBuf next, int wrapDataSize) {
/* 2345 */     int inReadableBytes = next.readableBytes();
/* 2346 */     int cumulationCapacity = cumulation.capacity();
/* 2347 */     if (wrapDataSize - cumulation.readableBytes() >= inReadableBytes && ((cumulation
/*      */ 
/*      */ 
/*      */       
/* 2351 */       .isWritable(inReadableBytes) && cumulationCapacity >= wrapDataSize) || (cumulationCapacity < wrapDataSize && 
/*      */       
/* 2353 */       ByteBufUtil.ensureWritableSuccess(cumulation.ensureWritable(inReadableBytes, false))))) {
/* 2354 */       cumulation.writeBytes(next);
/* 2355 */       next.release();
/* 2356 */       return true;
/*      */     } 
/* 2358 */     return false;
/*      */   }
/*      */   
/*      */   private final class LazyChannelPromise extends DefaultPromise<Channel> {
/*      */     private LazyChannelPromise() {}
/*      */     
/*      */     protected EventExecutor executor() {
/* 2365 */       if (SslHandler.this.ctx == null) {
/* 2366 */         throw new IllegalStateException();
/*      */       }
/* 2368 */       return SslHandler.this.ctx.executor();
/*      */     }
/*      */ 
/*      */     
/*      */     protected void checkDeadLock() {
/* 2373 */       if (SslHandler.this.ctx == null) {
/*      */         return;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2382 */       super.checkDeadLock();
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-handler-4.1.93.Final.jar!\io\netty\handler\ssl\SslHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */