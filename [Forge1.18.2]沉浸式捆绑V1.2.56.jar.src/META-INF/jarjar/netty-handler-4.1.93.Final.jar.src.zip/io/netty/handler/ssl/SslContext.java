/*      */ package io.netty.handler.ssl;
/*      */ 
/*      */ import io.netty.buffer.ByteBuf;
/*      */ import io.netty.buffer.ByteBufAllocator;
/*      */ import io.netty.buffer.ByteBufInputStream;
/*      */ import io.netty.util.AttributeMap;
/*      */ import io.netty.util.DefaultAttributeMap;
/*      */ import io.netty.util.internal.EmptyArrays;
/*      */ import java.io.BufferedInputStream;
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.security.InvalidAlgorithmParameterException;
/*      */ import java.security.InvalidKeyException;
/*      */ import java.security.KeyException;
/*      */ import java.security.KeyFactory;
/*      */ import java.security.KeyStore;
/*      */ import java.security.KeyStoreException;
/*      */ import java.security.NoSuchAlgorithmException;
/*      */ import java.security.PrivateKey;
/*      */ import java.security.Provider;
/*      */ import java.security.UnrecoverableKeyException;
/*      */ import java.security.cert.Certificate;
/*      */ import java.security.cert.CertificateException;
/*      */ import java.security.cert.CertificateFactory;
/*      */ import java.security.cert.X509Certificate;
/*      */ import java.security.spec.InvalidKeySpecException;
/*      */ import java.security.spec.PKCS8EncodedKeySpec;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.concurrent.Executor;
/*      */ import javax.crypto.Cipher;
/*      */ import javax.crypto.EncryptedPrivateKeyInfo;
/*      */ import javax.crypto.NoSuchPaddingException;
/*      */ import javax.crypto.SecretKey;
/*      */ import javax.crypto.SecretKeyFactory;
/*      */ import javax.crypto.spec.PBEKeySpec;
/*      */ import javax.net.ssl.KeyManagerFactory;
/*      */ import javax.net.ssl.SSLEngine;
/*      */ import javax.net.ssl.SSLException;
/*      */ import javax.net.ssl.SSLSessionContext;
/*      */ import javax.net.ssl.TrustManagerFactory;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class SslContext
/*      */ {
/*      */   static final String ALIAS = "key";
/*      */   static final CertificateFactory X509_CERT_FACTORY;
/*      */   private final boolean startTls;
/*      */   
/*      */   static {
/*      */     try {
/*   97 */       X509_CERT_FACTORY = CertificateFactory.getInstance("X.509");
/*   98 */     } catch (CertificateException e) {
/*   99 */       throw new IllegalStateException("unable to instance X.509 CertificateFactory", e);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*  104 */   private final AttributeMap attributes = (AttributeMap)new DefaultAttributeMap();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SslProvider defaultServerProvider() {
/*  112 */     return defaultProvider();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SslProvider defaultClientProvider() {
/*  121 */     return defaultProvider();
/*      */   }
/*      */   
/*      */   private static SslProvider defaultProvider() {
/*  125 */     if (OpenSsl.isAvailable()) {
/*  126 */       return SslProvider.OPENSSL;
/*      */     }
/*  128 */     return SslProvider.JDK;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static SslContext newServerContext(File certChainFile, File keyFile) throws SSLException {
/*  142 */     return newServerContext(certChainFile, keyFile, (String)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static SslContext newServerContext(File certChainFile, File keyFile, String keyPassword) throws SSLException {
/*  158 */     return newServerContext(null, certChainFile, keyFile, keyPassword);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static SslContext newServerContext(File certChainFile, File keyFile, String keyPassword, Iterable<String> ciphers, Iterable<String> nextProtocols, long sessionCacheSize, long sessionTimeout) throws SSLException {
/*  185 */     return newServerContext((SslProvider)null, certChainFile, keyFile, keyPassword, ciphers, nextProtocols, sessionCacheSize, sessionTimeout);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static SslContext newServerContext(File certChainFile, File keyFile, String keyPassword, Iterable<String> ciphers, CipherSuiteFilter cipherFilter, ApplicationProtocolConfig apn, long sessionCacheSize, long sessionTimeout) throws SSLException {
/*  213 */     return newServerContext((SslProvider)null, certChainFile, keyFile, keyPassword, ciphers, cipherFilter, apn, sessionCacheSize, sessionTimeout);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static SslContext newServerContext(SslProvider provider, File certChainFile, File keyFile) throws SSLException {
/*  231 */     return newServerContext(provider, certChainFile, keyFile, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static SslContext newServerContext(SslProvider provider, File certChainFile, File keyFile, String keyPassword) throws SSLException {
/*  249 */     return newServerContext(provider, certChainFile, keyFile, keyPassword, (Iterable<String>)null, IdentityCipherSuiteFilter.INSTANCE, (ApplicationProtocolConfig)null, 0L, 0L);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static SslContext newServerContext(SslProvider provider, File certChainFile, File keyFile, String keyPassword, Iterable<String> ciphers, Iterable<String> nextProtocols, long sessionCacheSize, long sessionTimeout) throws SSLException {
/*  279 */     return newServerContext(provider, certChainFile, keyFile, keyPassword, ciphers, IdentityCipherSuiteFilter.INSTANCE, 
/*      */         
/*  281 */         toApplicationProtocolConfig(nextProtocols), sessionCacheSize, sessionTimeout);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static SslContext newServerContext(SslProvider provider, File certChainFile, File keyFile, String keyPassword, TrustManagerFactory trustManagerFactory, Iterable<String> ciphers, Iterable<String> nextProtocols, long sessionCacheSize, long sessionTimeout) throws SSLException {
/*  314 */     return newServerContext(provider, null, trustManagerFactory, certChainFile, keyFile, keyPassword, null, ciphers, IdentityCipherSuiteFilter.INSTANCE, 
/*      */ 
/*      */         
/*  317 */         toApplicationProtocolConfig(nextProtocols), sessionCacheSize, sessionTimeout);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static SslContext newServerContext(SslProvider provider, File certChainFile, File keyFile, String keyPassword, Iterable<String> ciphers, CipherSuiteFilter cipherFilter, ApplicationProtocolConfig apn, long sessionCacheSize, long sessionTimeout) throws SSLException {
/*  346 */     return newServerContext(provider, null, null, certChainFile, keyFile, keyPassword, null, ciphers, cipherFilter, apn, sessionCacheSize, sessionTimeout, 
/*  347 */         KeyStore.getDefaultType());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static SslContext newServerContext(SslProvider provider, File trustCertCollectionFile, TrustManagerFactory trustManagerFactory, File keyCertChainFile, File keyFile, String keyPassword, KeyManagerFactory keyManagerFactory, Iterable<String> ciphers, CipherSuiteFilter cipherFilter, ApplicationProtocolConfig apn, long sessionCacheSize, long sessionTimeout) throws SSLException {
/*  390 */     return newServerContext(provider, trustCertCollectionFile, trustManagerFactory, keyCertChainFile, keyFile, keyPassword, keyManagerFactory, ciphers, cipherFilter, apn, sessionCacheSize, sessionTimeout, 
/*      */         
/*  392 */         KeyStore.getDefaultType());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static SslContext newServerContext(SslProvider provider, File trustCertCollectionFile, TrustManagerFactory trustManagerFactory, File keyCertChainFile, File keyFile, String keyPassword, KeyManagerFactory keyManagerFactory, Iterable<String> ciphers, CipherSuiteFilter cipherFilter, ApplicationProtocolConfig apn, long sessionCacheSize, long sessionTimeout, String keyStore) throws SSLException {
/*      */     try {
/*  435 */       return newServerContextInternal(provider, null, toX509Certificates(trustCertCollectionFile), trustManagerFactory, 
/*  436 */           toX509Certificates(keyCertChainFile), 
/*  437 */           toPrivateKey(keyFile, keyPassword), keyPassword, keyManagerFactory, ciphers, cipherFilter, apn, sessionCacheSize, sessionTimeout, ClientAuth.NONE, null, false, false, keyStore, (Map.Entry<SslContextOption<?>, Object>[])new Map.Entry[0]);
/*      */ 
/*      */     
/*      */     }
/*  441 */     catch (Exception e) {
/*  442 */       if (e instanceof SSLException) {
/*  443 */         throw (SSLException)e;
/*      */       }
/*  445 */       throw new SSLException("failed to initialize the server-side SSL context", e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static SslContext newServerContextInternal(SslProvider provider, Provider sslContextProvider, X509Certificate[] trustCertCollection, TrustManagerFactory trustManagerFactory, X509Certificate[] keyCertChain, PrivateKey key, String keyPassword, KeyManagerFactory keyManagerFactory, Iterable<String> ciphers, CipherSuiteFilter cipherFilter, ApplicationProtocolConfig apn, long sessionCacheSize, long sessionTimeout, ClientAuth clientAuth, String[] protocols, boolean startTls, boolean enableOcsp, String keyStoreType, Map.Entry<SslContextOption<?>, Object>... ctxOptions) throws SSLException {
/*  459 */     if (provider == null) {
/*  460 */       provider = defaultServerProvider();
/*      */     }
/*      */     
/*  463 */     switch (provider) {
/*      */       case JDK:
/*  465 */         if (enableOcsp) {
/*  466 */           throw new IllegalArgumentException("OCSP is not supported with this SslProvider: " + provider);
/*      */         }
/*  468 */         return new JdkSslServerContext(sslContextProvider, trustCertCollection, trustManagerFactory, keyCertChain, key, keyPassword, keyManagerFactory, ciphers, cipherFilter, apn, sessionCacheSize, sessionTimeout, clientAuth, protocols, startTls, keyStoreType);
/*      */ 
/*      */ 
/*      */       
/*      */       case OPENSSL:
/*  473 */         verifyNullSslContextProvider(provider, sslContextProvider);
/*  474 */         return new OpenSslServerContext(trustCertCollection, trustManagerFactory, keyCertChain, key, keyPassword, keyManagerFactory, ciphers, cipherFilter, apn, sessionCacheSize, sessionTimeout, clientAuth, protocols, startTls, enableOcsp, keyStoreType, ctxOptions);
/*      */ 
/*      */ 
/*      */       
/*      */       case OPENSSL_REFCNT:
/*  479 */         verifyNullSslContextProvider(provider, sslContextProvider);
/*  480 */         return new ReferenceCountedOpenSslServerContext(trustCertCollection, trustManagerFactory, keyCertChain, key, keyPassword, keyManagerFactory, ciphers, cipherFilter, apn, sessionCacheSize, sessionTimeout, clientAuth, protocols, startTls, enableOcsp, keyStoreType, ctxOptions);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  485 */     throw new Error(provider.toString());
/*      */   }
/*      */ 
/*      */   
/*      */   private static void verifyNullSslContextProvider(SslProvider provider, Provider sslContextProvider) {
/*  490 */     if (sslContextProvider != null) {
/*  491 */       throw new IllegalArgumentException("Java Security Provider unsupported for SslProvider: " + provider);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static SslContext newClientContext() throws SSLException {
/*  503 */     return newClientContext(null, null, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static SslContext newClientContext(File certChainFile) throws SSLException {
/*  516 */     return newClientContext((SslProvider)null, certChainFile);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static SslContext newClientContext(TrustManagerFactory trustManagerFactory) throws SSLException {
/*  531 */     return newClientContext(null, null, trustManagerFactory);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static SslContext newClientContext(File certChainFile, TrustManagerFactory trustManagerFactory) throws SSLException {
/*  549 */     return newClientContext(null, certChainFile, trustManagerFactory);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static SslContext newClientContext(File certChainFile, TrustManagerFactory trustManagerFactory, Iterable<String> ciphers, Iterable<String> nextProtocols, long sessionCacheSize, long sessionTimeout) throws SSLException {
/*  577 */     return newClientContext((SslProvider)null, certChainFile, trustManagerFactory, ciphers, nextProtocols, sessionCacheSize, sessionTimeout);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static SslContext newClientContext(File certChainFile, TrustManagerFactory trustManagerFactory, Iterable<String> ciphers, CipherSuiteFilter cipherFilter, ApplicationProtocolConfig apn, long sessionCacheSize, long sessionTimeout) throws SSLException {
/*  607 */     return newClientContext(null, certChainFile, trustManagerFactory, ciphers, cipherFilter, apn, sessionCacheSize, sessionTimeout);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static SslContext newClientContext(SslProvider provider) throws SSLException {
/*  623 */     return newClientContext(provider, null, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static SslContext newClientContext(SslProvider provider, File certChainFile) throws SSLException {
/*  639 */     return newClientContext(provider, certChainFile, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static SslContext newClientContext(SslProvider provider, TrustManagerFactory trustManagerFactory) throws SSLException {
/*  657 */     return newClientContext(provider, null, trustManagerFactory);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static SslContext newClientContext(SslProvider provider, File certChainFile, TrustManagerFactory trustManagerFactory) throws SSLException {
/*  677 */     return newClientContext(provider, certChainFile, trustManagerFactory, null, IdentityCipherSuiteFilter.INSTANCE, null, 0L, 0L);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static SslContext newClientContext(SslProvider provider, File certChainFile, TrustManagerFactory trustManagerFactory, Iterable<String> ciphers, Iterable<String> nextProtocols, long sessionCacheSize, long sessionTimeout) throws SSLException {
/*  709 */     return newClientContext(provider, certChainFile, trustManagerFactory, null, null, null, null, ciphers, IdentityCipherSuiteFilter.INSTANCE, 
/*      */ 
/*      */         
/*  712 */         toApplicationProtocolConfig(nextProtocols), sessionCacheSize, sessionTimeout);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static SslContext newClientContext(SslProvider provider, File certChainFile, TrustManagerFactory trustManagerFactory, Iterable<String> ciphers, CipherSuiteFilter cipherFilter, ApplicationProtocolConfig apn, long sessionCacheSize, long sessionTimeout) throws SSLException {
/*  744 */     return newClientContext(provider, certChainFile, trustManagerFactory, null, null, null, null, ciphers, cipherFilter, apn, sessionCacheSize, sessionTimeout);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static SslContext newClientContext(SslProvider provider, File trustCertCollectionFile, TrustManagerFactory trustManagerFactory, File keyCertChainFile, File keyFile, String keyPassword, KeyManagerFactory keyManagerFactory, Iterable<String> ciphers, CipherSuiteFilter cipherFilter, ApplicationProtocolConfig apn, long sessionCacheSize, long sessionTimeout) throws SSLException {
/*      */     try {
/*  795 */       return newClientContextInternal(provider, null, 
/*  796 */           toX509Certificates(trustCertCollectionFile), trustManagerFactory, 
/*  797 */           toX509Certificates(keyCertChainFile), toPrivateKey(keyFile, keyPassword), keyPassword, keyManagerFactory, ciphers, cipherFilter, apn, null, sessionCacheSize, sessionTimeout, false, 
/*      */ 
/*      */           
/*  800 */           KeyStore.getDefaultType(), (Map.Entry<SslContextOption<?>, Object>[])new Map.Entry[0]);
/*  801 */     } catch (Exception e) {
/*  802 */       if (e instanceof SSLException) {
/*  803 */         throw (SSLException)e;
/*      */       }
/*  805 */       throw new SSLException("failed to initialize the client-side SSL context", e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static SslContext newClientContextInternal(SslProvider provider, Provider sslContextProvider, X509Certificate[] trustCert, TrustManagerFactory trustManagerFactory, X509Certificate[] keyCertChain, PrivateKey key, String keyPassword, KeyManagerFactory keyManagerFactory, Iterable<String> ciphers, CipherSuiteFilter cipherFilter, ApplicationProtocolConfig apn, String[] protocols, long sessionCacheSize, long sessionTimeout, boolean enableOcsp, String keyStoreType, Map.Entry<SslContextOption<?>, Object>... options) throws SSLException {
/*  817 */     if (provider == null) {
/*  818 */       provider = defaultClientProvider();
/*      */     }
/*  820 */     switch (provider) {
/*      */       case JDK:
/*  822 */         if (enableOcsp) {
/*  823 */           throw new IllegalArgumentException("OCSP is not supported with this SslProvider: " + provider);
/*      */         }
/*  825 */         return new JdkSslClientContext(sslContextProvider, trustCert, trustManagerFactory, keyCertChain, key, keyPassword, keyManagerFactory, ciphers, cipherFilter, apn, protocols, sessionCacheSize, sessionTimeout, keyStoreType);
/*      */ 
/*      */ 
/*      */       
/*      */       case OPENSSL:
/*  830 */         verifyNullSslContextProvider(provider, sslContextProvider);
/*  831 */         OpenSsl.ensureAvailability();
/*  832 */         return new OpenSslClientContext(trustCert, trustManagerFactory, keyCertChain, key, keyPassword, keyManagerFactory, ciphers, cipherFilter, apn, protocols, sessionCacheSize, sessionTimeout, enableOcsp, keyStoreType, options);
/*      */ 
/*      */ 
/*      */       
/*      */       case OPENSSL_REFCNT:
/*  837 */         verifyNullSslContextProvider(provider, sslContextProvider);
/*  838 */         OpenSsl.ensureAvailability();
/*  839 */         return new ReferenceCountedOpenSslClientContext(trustCert, trustManagerFactory, keyCertChain, key, keyPassword, keyManagerFactory, ciphers, cipherFilter, apn, protocols, sessionCacheSize, sessionTimeout, enableOcsp, keyStoreType, options);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  844 */     throw new Error(provider.toString());
/*      */   }
/*      */ 
/*      */   
/*      */   static ApplicationProtocolConfig toApplicationProtocolConfig(Iterable<String> nextProtocols) {
/*      */     ApplicationProtocolConfig apn;
/*  850 */     if (nextProtocols == null) {
/*  851 */       apn = ApplicationProtocolConfig.DISABLED;
/*      */     } else {
/*  853 */       apn = new ApplicationProtocolConfig(ApplicationProtocolConfig.Protocol.NPN_AND_ALPN, ApplicationProtocolConfig.SelectorFailureBehavior.CHOOSE_MY_LAST_PROTOCOL, ApplicationProtocolConfig.SelectedListenerFailureBehavior.ACCEPT, nextProtocols);
/*      */     } 
/*      */ 
/*      */     
/*  857 */     return apn;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected SslContext() {
/*  864 */     this(false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected SslContext(boolean startTls) {
/*  871 */     this.startTls = startTls;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final AttributeMap attributes() {
/*  878 */     return this.attributes;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isServer() {
/*  885 */     return !isClient();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long sessionCacheSize() {
/*  902 */     return sessionContext().getSessionCacheSize();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long sessionTimeout() {
/*  909 */     return sessionContext().getSessionTimeout();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public final List<String> nextProtocols() {
/*  917 */     return applicationProtocolNegotiator().protocols();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final SslHandler newHandler(ByteBufAllocator alloc) {
/*  955 */     return newHandler(alloc, this.startTls);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected SslHandler newHandler(ByteBufAllocator alloc, boolean startTls) {
/*  963 */     return new SslHandler(newEngine(alloc), startTls);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SslHandler newHandler(ByteBufAllocator alloc, Executor delegatedTaskExecutor) {
/*  992 */     return newHandler(alloc, this.startTls, delegatedTaskExecutor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected SslHandler newHandler(ByteBufAllocator alloc, boolean startTls, Executor executor) {
/* 1000 */     return new SslHandler(newEngine(alloc), startTls, executor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final SslHandler newHandler(ByteBufAllocator alloc, String peerHost, int peerPort) {
/* 1009 */     return newHandler(alloc, peerHost, peerPort, this.startTls);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected SslHandler newHandler(ByteBufAllocator alloc, String peerHost, int peerPort, boolean startTls) {
/* 1017 */     return new SslHandler(newEngine(alloc, peerHost, peerPort), startTls);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SslHandler newHandler(ByteBufAllocator alloc, String peerHost, int peerPort, Executor delegatedTaskExecutor) {
/* 1050 */     return newHandler(alloc, peerHost, peerPort, this.startTls, delegatedTaskExecutor);
/*      */   }
/*      */ 
/*      */   
/*      */   protected SslHandler newHandler(ByteBufAllocator alloc, String peerHost, int peerPort, boolean startTls, Executor delegatedTaskExecutor) {
/* 1055 */     return new SslHandler(newEngine(alloc, peerHost, peerPort), startTls, delegatedTaskExecutor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected static PKCS8EncodedKeySpec generateKeySpec(char[] password, byte[] key) throws IOException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException, InvalidKeyException, InvalidAlgorithmParameterException {
/* 1079 */     if (password == null) {
/* 1080 */       return new PKCS8EncodedKeySpec(key);
/*      */     }
/*      */     
/* 1083 */     EncryptedPrivateKeyInfo encryptedPrivateKeyInfo = new EncryptedPrivateKeyInfo(key);
/* 1084 */     SecretKeyFactory keyFactory = SecretKeyFactory.getInstance(encryptedPrivateKeyInfo.getAlgName());
/* 1085 */     PBEKeySpec pbeKeySpec = new PBEKeySpec(password);
/* 1086 */     SecretKey pbeKey = keyFactory.generateSecret(pbeKeySpec);
/*      */     
/* 1088 */     Cipher cipher = Cipher.getInstance(encryptedPrivateKeyInfo.getAlgName());
/* 1089 */     cipher.init(2, pbeKey, encryptedPrivateKeyInfo.getAlgParameters());
/*      */     
/* 1091 */     return encryptedPrivateKeyInfo.getKeySpec(cipher);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static KeyStore buildKeyStore(X509Certificate[] certChain, PrivateKey key, char[] keyPasswordChars, String keyStoreType) throws KeyStoreException, NoSuchAlgorithmException, CertificateException, IOException {
/* 1108 */     if (keyStoreType == null) {
/* 1109 */       keyStoreType = KeyStore.getDefaultType();
/*      */     }
/* 1111 */     KeyStore ks = KeyStore.getInstance(keyStoreType);
/* 1112 */     ks.load(null, null);
/* 1113 */     ks.setKeyEntry("key", key, keyPasswordChars, (Certificate[])certChain);
/* 1114 */     return ks;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static PrivateKey toPrivateKey(File keyFile, String keyPassword) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException, KeyException, IOException {
/* 1121 */     if (keyFile == null) {
/* 1122 */       return null;
/*      */     }
/*      */ 
/*      */     
/* 1126 */     if (BouncyCastlePemReader.isAvailable()) {
/* 1127 */       PrivateKey pk = BouncyCastlePemReader.getPrivateKey(keyFile, keyPassword);
/* 1128 */       if (pk != null) {
/* 1129 */         return pk;
/*      */       }
/*      */     } 
/*      */     
/* 1133 */     return getPrivateKeyFromByteBuffer(PemReader.readPrivateKey(keyFile), keyPassword);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static PrivateKey toPrivateKey(InputStream keyInputStream, String keyPassword) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException, KeyException, IOException {
/* 1141 */     if (keyInputStream == null) {
/* 1142 */       return null;
/*      */     }
/*      */ 
/*      */     
/* 1146 */     if (BouncyCastlePemReader.isAvailable()) {
/* 1147 */       if (!keyInputStream.markSupported())
/*      */       {
/* 1149 */         keyInputStream = new BufferedInputStream(keyInputStream);
/*      */       }
/* 1151 */       keyInputStream.mark(1048576);
/* 1152 */       PrivateKey pk = BouncyCastlePemReader.getPrivateKey(keyInputStream, keyPassword);
/* 1153 */       if (pk != null) {
/* 1154 */         return pk;
/*      */       }
/*      */       
/* 1157 */       keyInputStream.reset();
/*      */     } 
/*      */     
/* 1160 */     return getPrivateKeyFromByteBuffer(PemReader.readPrivateKey(keyInputStream), keyPassword);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static PrivateKey getPrivateKeyFromByteBuffer(ByteBuf encodedKeyBuf, String keyPassword) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException, KeyException, IOException {
/* 1167 */     byte[] encodedKey = new byte[encodedKeyBuf.readableBytes()];
/* 1168 */     encodedKeyBuf.readBytes(encodedKey).release();
/*      */     
/* 1170 */     PKCS8EncodedKeySpec encodedKeySpec = generateKeySpec((keyPassword == null) ? null : keyPassword
/* 1171 */         .toCharArray(), encodedKey);
/*      */     try {
/* 1173 */       return KeyFactory.getInstance("RSA").generatePrivate(encodedKeySpec);
/* 1174 */     } catch (InvalidKeySpecException ignore) {
/*      */       try {
/* 1176 */         return KeyFactory.getInstance("DSA").generatePrivate(encodedKeySpec);
/* 1177 */       } catch (InvalidKeySpecException ignore2) {
/*      */         try {
/* 1179 */           return KeyFactory.getInstance("EC").generatePrivate(encodedKeySpec);
/* 1180 */         } catch (InvalidKeySpecException e) {
/* 1181 */           throw new InvalidKeySpecException("Neither RSA, DSA nor EC worked", e);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected static TrustManagerFactory buildTrustManagerFactory(File certChainFile, TrustManagerFactory trustManagerFactory) throws NoSuchAlgorithmException, CertificateException, KeyStoreException, IOException {
/* 1197 */     return buildTrustManagerFactory(certChainFile, trustManagerFactory, (String)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static TrustManagerFactory buildTrustManagerFactory(File certChainFile, TrustManagerFactory trustManagerFactory, String keyType) throws NoSuchAlgorithmException, CertificateException, KeyStoreException, IOException {
/* 1210 */     X509Certificate[] x509Certs = toX509Certificates(certChainFile);
/*      */     
/* 1212 */     return buildTrustManagerFactory(x509Certs, trustManagerFactory, keyType);
/*      */   }
/*      */   
/*      */   protected static X509Certificate[] toX509Certificates(File file) throws CertificateException {
/* 1216 */     if (file == null) {
/* 1217 */       return null;
/*      */     }
/* 1219 */     return getCertificatesFromBuffers(PemReader.readCertificates(file));
/*      */   }
/*      */   
/*      */   protected static X509Certificate[] toX509Certificates(InputStream in) throws CertificateException {
/* 1223 */     if (in == null) {
/* 1224 */       return null;
/*      */     }
/* 1226 */     return getCertificatesFromBuffers(PemReader.readCertificates(in));
/*      */   }
/*      */   
/*      */   private static X509Certificate[] getCertificatesFromBuffers(ByteBuf[] certs) throws CertificateException {
/* 1230 */     CertificateFactory cf = CertificateFactory.getInstance("X.509");
/* 1231 */     X509Certificate[] x509Certs = new X509Certificate[certs.length];
/*      */     
/*      */     try {
/* 1234 */       for (int i = 0; i < certs.length; i++) {
/* 1235 */         ByteBufInputStream byteBufInputStream = new ByteBufInputStream(certs[i], false);
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*      */     finally {
/*      */ 
/*      */ 
/*      */       
/* 1248 */       for (ByteBuf buf : certs) {
/* 1249 */         buf.release();
/*      */       }
/*      */     } 
/* 1252 */     return x509Certs;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected static TrustManagerFactory buildTrustManagerFactory(X509Certificate[] certCollection, TrustManagerFactory trustManagerFactory, String keyStoreType) throws NoSuchAlgorithmException, CertificateException, KeyStoreException, IOException {
/* 1258 */     if (keyStoreType == null) {
/* 1259 */       keyStoreType = KeyStore.getDefaultType();
/*      */     }
/* 1261 */     KeyStore ks = KeyStore.getInstance(keyStoreType);
/* 1262 */     ks.load(null, null);
/*      */     
/* 1264 */     int i = 1;
/* 1265 */     for (X509Certificate cert : certCollection) {
/* 1266 */       String alias = Integer.toString(i);
/* 1267 */       ks.setCertificateEntry(alias, cert);
/* 1268 */       i++;
/*      */     } 
/*      */ 
/*      */     
/* 1272 */     if (trustManagerFactory == null) {
/* 1273 */       trustManagerFactory = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
/*      */     }
/* 1275 */     trustManagerFactory.init(ks);
/*      */     
/* 1277 */     return trustManagerFactory;
/*      */   }
/*      */   
/*      */   static PrivateKey toPrivateKeyInternal(File keyFile, String keyPassword) throws SSLException {
/*      */     try {
/* 1282 */       return toPrivateKey(keyFile, keyPassword);
/* 1283 */     } catch (Exception e) {
/* 1284 */       throw new SSLException(e);
/*      */     } 
/*      */   }
/*      */   
/*      */   static X509Certificate[] toX509CertificatesInternal(File file) throws SSLException {
/*      */     try {
/* 1290 */       return toX509Certificates(file);
/* 1291 */     } catch (CertificateException e) {
/* 1292 */       throw new SSLException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static KeyManagerFactory buildKeyManagerFactory(X509Certificate[] certChainFile, String keyAlgorithm, PrivateKey key, String keyPassword, KeyManagerFactory kmf, String keyStore) throws KeyStoreException, NoSuchAlgorithmException, IOException, CertificateException, UnrecoverableKeyException {
/* 1302 */     if (keyAlgorithm == null) {
/* 1303 */       keyAlgorithm = KeyManagerFactory.getDefaultAlgorithm();
/*      */     }
/* 1305 */     char[] keyPasswordChars = keyStorePassword(keyPassword);
/* 1306 */     KeyStore ks = buildKeyStore(certChainFile, key, keyPasswordChars, keyStore);
/* 1307 */     return buildKeyManagerFactory(ks, keyAlgorithm, keyPasswordChars, kmf);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static KeyManagerFactory buildKeyManagerFactory(KeyStore ks, String keyAlgorithm, char[] keyPasswordChars, KeyManagerFactory kmf) throws KeyStoreException, NoSuchAlgorithmException, UnrecoverableKeyException {
/* 1315 */     if (kmf == null) {
/* 1316 */       if (keyAlgorithm == null) {
/* 1317 */         keyAlgorithm = KeyManagerFactory.getDefaultAlgorithm();
/*      */       }
/* 1319 */       kmf = KeyManagerFactory.getInstance(keyAlgorithm);
/*      */     } 
/* 1321 */     kmf.init(ks, keyPasswordChars);
/*      */     
/* 1323 */     return kmf;
/*      */   }
/*      */   
/*      */   static char[] keyStorePassword(String keyPassword) {
/* 1327 */     return (keyPassword == null) ? EmptyArrays.EMPTY_CHARS : keyPassword.toCharArray();
/*      */   }
/*      */   
/*      */   public abstract boolean isClient();
/*      */   
/*      */   public abstract List<String> cipherSuites();
/*      */   
/*      */   public abstract ApplicationProtocolNegotiator applicationProtocolNegotiator();
/*      */   
/*      */   public abstract SSLEngine newEngine(ByteBufAllocator paramByteBufAllocator);
/*      */   
/*      */   public abstract SSLEngine newEngine(ByteBufAllocator paramByteBufAllocator, String paramString, int paramInt);
/*      */   
/*      */   public abstract SSLSessionContext sessionContext();
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-handler-4.1.93.Final.jar!\io\netty\handler\ssl\SslContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */