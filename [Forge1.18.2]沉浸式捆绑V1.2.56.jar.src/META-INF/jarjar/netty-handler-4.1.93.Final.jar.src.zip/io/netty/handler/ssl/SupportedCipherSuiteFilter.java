/*    */ package io.netty.handler.ssl;
/*    */ 
/*    */ import io.netty.util.internal.ObjectUtil;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.Set;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SupportedCipherSuiteFilter
/*    */   implements CipherSuiteFilter
/*    */ {
/* 29 */   public static final SupportedCipherSuiteFilter INSTANCE = new SupportedCipherSuiteFilter();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String[] filterCipherSuites(Iterable<String> ciphers, List<String> defaultCiphers, Set<String> supportedCiphers) {
/*    */     List<String> newCiphers;
/* 36 */     ObjectUtil.checkNotNull(defaultCiphers, "defaultCiphers");
/* 37 */     ObjectUtil.checkNotNull(supportedCiphers, "supportedCiphers");
/*    */ 
/*    */     
/* 40 */     if (ciphers == null) {
/* 41 */       newCiphers = new ArrayList<String>(defaultCiphers.size());
/* 42 */       ciphers = defaultCiphers;
/*    */     } else {
/* 44 */       newCiphers = new ArrayList<String>(supportedCiphers.size());
/*    */     } 
/* 46 */     for (String c : ciphers) {
/* 47 */       if (c == null) {
/*    */         break;
/*    */       }
/* 50 */       if (supportedCiphers.contains(c)) {
/* 51 */         newCiphers.add(c);
/*    */       }
/*    */     } 
/* 54 */     return newCiphers.<String>toArray(new String[0]);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-handler-4.1.93.Final.jar!\io\netty\handler\ssl\SupportedCipherSuiteFilter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */