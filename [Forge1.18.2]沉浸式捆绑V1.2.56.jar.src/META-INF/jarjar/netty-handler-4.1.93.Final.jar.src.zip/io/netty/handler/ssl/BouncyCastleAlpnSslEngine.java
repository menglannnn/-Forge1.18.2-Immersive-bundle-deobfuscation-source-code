/*    */ package io.netty.handler.ssl;
/*    */ 
/*    */ import io.netty.util.internal.SuppressJava6Requirement;
/*    */ import java.util.List;
/*    */ import java.util.function.BiConsumer;
/*    */ import java.util.function.BiFunction;
/*    */ import javax.net.ssl.SSLEngine;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @SuppressJava6Requirement(reason = "Usage guarded by java version check")
/*    */ final class BouncyCastleAlpnSslEngine
/*    */   extends JdkAlpnSslEngine
/*    */ {
/*    */   BouncyCastleAlpnSslEngine(SSLEngine engine, JdkApplicationProtocolNegotiator applicationNegotiator, boolean isServer) {
/* 31 */     super(engine, applicationNegotiator, isServer, new BiConsumer<SSLEngine, JdkAlpnSslEngine.AlpnSelector>()
/*    */         {
/*    */           public void accept(SSLEngine e, JdkAlpnSslEngine.AlpnSelector s)
/*    */           {
/* 35 */             BouncyCastleAlpnSslUtils.setHandshakeApplicationProtocolSelector(e, s);
/*    */           }
/*    */         }new BiConsumer<SSLEngine, List<String>>()
/*    */         {
/*    */           public void accept(SSLEngine e, List<String> p)
/*    */           {
/* 41 */             BouncyCastleAlpnSslUtils.setApplicationProtocols(e, p);
/*    */           }
/*    */         });
/*    */   }
/*    */   
/*    */   public String getApplicationProtocol() {
/* 47 */     return BouncyCastleAlpnSslUtils.getApplicationProtocol(getWrappedEngine());
/*    */   }
/*    */   
/*    */   public String getHandshakeApplicationProtocol() {
/* 51 */     return BouncyCastleAlpnSslUtils.getHandshakeApplicationProtocol(getWrappedEngine());
/*    */   }
/*    */   
/*    */   public void setHandshakeApplicationProtocolSelector(BiFunction<SSLEngine, List<String>, String> selector) {
/* 55 */     BouncyCastleAlpnSslUtils.setHandshakeApplicationProtocolSelector(getWrappedEngine(), selector);
/*    */   }
/*    */   
/*    */   public BiFunction<SSLEngine, List<String>, String> getHandshakeApplicationProtocolSelector() {
/* 59 */     return BouncyCastleAlpnSslUtils.getHandshakeApplicationProtocolSelector(getWrappedEngine());
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-handler-4.1.93.Final.jar!\io\netty\handler\ssl\BouncyCastleAlpnSslEngine.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */