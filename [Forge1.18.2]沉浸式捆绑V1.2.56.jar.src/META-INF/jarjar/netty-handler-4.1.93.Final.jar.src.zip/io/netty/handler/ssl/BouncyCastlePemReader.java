/*     */ package io.netty.handler.ssl;
/*     */ 
/*     */ import io.netty.util.CharsetUtil;
/*     */ import io.netty.util.internal.logging.InternalLogger;
/*     */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivateKey;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.security.Provider;
/*     */ import org.bouncycastle.asn1.pkcs.PrivateKeyInfo;
/*     */ import org.bouncycastle.openssl.PEMDecryptorProvider;
/*     */ import org.bouncycastle.openssl.PEMEncryptedKeyPair;
/*     */ import org.bouncycastle.openssl.PEMKeyPair;
/*     */ import org.bouncycastle.openssl.PEMParser;
/*     */ import org.bouncycastle.openssl.jcajce.JcaPEMKeyConverter;
/*     */ import org.bouncycastle.openssl.jcajce.JceOpenSSLPKCS8DecryptorProviderBuilder;
/*     */ import org.bouncycastle.openssl.jcajce.JcePEMDecryptorProviderBuilder;
/*     */ import org.bouncycastle.operator.InputDecryptorProvider;
/*     */ import org.bouncycastle.operator.OperatorCreationException;
/*     */ import org.bouncycastle.pkcs.PKCS8EncryptedPrivateKeyInfo;
/*     */ import org.bouncycastle.pkcs.PKCSException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class BouncyCastlePemReader
/*     */ {
/*     */   private static final String BC_PROVIDER = "org.bouncycastle.jce.provider.BouncyCastleProvider";
/*     */   private static final String BC_PEMPARSER = "org.bouncycastle.openssl.PEMParser";
/*  48 */   private static final InternalLogger logger = InternalLoggerFactory.getInstance(BouncyCastlePemReader.class);
/*     */   
/*     */   private static volatile Throwable unavailabilityCause;
/*     */   private static volatile Provider bcProvider;
/*     */   private static volatile boolean attemptedLoading;
/*     */   
/*     */   public static boolean hasAttemptedLoading() {
/*  55 */     return attemptedLoading;
/*     */   }
/*     */   
/*     */   public static boolean isAvailable() {
/*  59 */     if (!hasAttemptedLoading()) {
/*  60 */       tryLoading();
/*     */     }
/*  62 */     return (unavailabilityCause == null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Throwable unavailabilityCause() {
/*  69 */     return unavailabilityCause;
/*     */   }
/*     */   
/*     */   private static void tryLoading() {
/*  73 */     AccessController.doPrivileged(new PrivilegedAction<Void>()
/*     */         {
/*     */           public Void run() {
/*     */             try {
/*  77 */               ClassLoader classLoader = getClass().getClassLoader();
/*     */ 
/*     */               
/*  80 */               Class<Provider> bcProviderClass = (Class)Class.forName("org.bouncycastle.jce.provider.BouncyCastleProvider", true, classLoader);
/*     */               
/*  82 */               Class.forName("org.bouncycastle.openssl.PEMParser", true, classLoader);
/*  83 */               BouncyCastlePemReader.bcProvider = bcProviderClass.getConstructor(new Class[0]).newInstance(new Object[0]);
/*  84 */               BouncyCastlePemReader.logger.debug("Bouncy Castle provider available");
/*  85 */               BouncyCastlePemReader.attemptedLoading = true;
/*  86 */             } catch (Throwable e) {
/*  87 */               BouncyCastlePemReader.logger.debug("Cannot load Bouncy Castle provider", e);
/*  88 */               BouncyCastlePemReader.unavailabilityCause = e;
/*  89 */               BouncyCastlePemReader.attemptedLoading = true;
/*     */             } 
/*  91 */             return null;
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PrivateKey getPrivateKey(InputStream keyInputStream, String keyPassword) {
/* 105 */     if (!isAvailable()) {
/* 106 */       if (logger.isDebugEnabled()) {
/* 107 */         logger.debug("Bouncy castle provider is unavailable.", unavailabilityCause());
/*     */       }
/* 109 */       return null;
/*     */     } 
/*     */     try {
/* 112 */       PEMParser parser = newParser(keyInputStream);
/* 113 */       return getPrivateKey(parser, keyPassword);
/* 114 */     } catch (Exception e) {
/* 115 */       logger.debug("Unable to extract private key", e);
/* 116 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PrivateKey getPrivateKey(File keyFile, String keyPassword) {
/* 129 */     if (!isAvailable()) {
/* 130 */       if (logger.isDebugEnabled()) {
/* 131 */         logger.debug("Bouncy castle provider is unavailable.", unavailabilityCause());
/*     */       }
/* 133 */       return null;
/*     */     } 
/*     */     try {
/* 136 */       PEMParser parser = newParser(keyFile);
/* 137 */       return getPrivateKey(parser, keyPassword);
/* 138 */     } catch (Exception e) {
/* 139 */       logger.debug("Unable to extract private key", e);
/* 140 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static JcaPEMKeyConverter newConverter() {
/* 145 */     return (new JcaPEMKeyConverter()).setProvider(bcProvider);
/*     */   }
/*     */ 
/*     */   
/*     */   private static PrivateKey getPrivateKey(PEMParser pemParser, String keyPassword) throws IOException, PKCSException, OperatorCreationException {
/*     */     try {
/* 151 */       JcaPEMKeyConverter converter = newConverter();
/* 152 */       PrivateKey pk = null;
/*     */       
/* 154 */       Object object = pemParser.readObject();
/* 155 */       while (object != null && pk == null) {
/* 156 */         if (logger.isDebugEnabled()) {
/* 157 */           logger.debug("Parsed PEM object of type {} and assume key is {}encrypted", object
/* 158 */               .getClass().getName(), (keyPassword == null) ? "not " : "");
/*     */         }
/*     */         
/* 161 */         if (keyPassword == null) {
/*     */           
/* 163 */           if (object instanceof PrivateKeyInfo) {
/* 164 */             pk = converter.getPrivateKey((PrivateKeyInfo)object);
/* 165 */           } else if (object instanceof PEMKeyPair) {
/* 166 */             pk = converter.getKeyPair((PEMKeyPair)object).getPrivate();
/*     */           } else {
/* 168 */             logger.debug("Unable to handle PEM object of type {} as a non encrypted key", object
/* 169 */                 .getClass());
/*     */           }
/*     */         
/*     */         }
/* 173 */         else if (object instanceof PEMEncryptedKeyPair) {
/*     */ 
/*     */           
/* 176 */           PEMDecryptorProvider decProv = (new JcePEMDecryptorProviderBuilder()).setProvider(bcProvider).build(keyPassword.toCharArray());
/* 177 */           pk = converter.getKeyPair(((PEMEncryptedKeyPair)object).decryptKeyPair(decProv)).getPrivate();
/* 178 */         } else if (object instanceof PKCS8EncryptedPrivateKeyInfo) {
/*     */ 
/*     */ 
/*     */           
/* 182 */           InputDecryptorProvider pkcs8InputDecryptorProvider = (new JceOpenSSLPKCS8DecryptorProviderBuilder()).setProvider(bcProvider).build(keyPassword.toCharArray());
/* 183 */           pk = converter.getPrivateKey(((PKCS8EncryptedPrivateKeyInfo)object)
/* 184 */               .decryptPrivateKeyInfo(pkcs8InputDecryptorProvider));
/*     */         } else {
/* 186 */           logger.debug("Unable to handle PEM object of type {} as a encrypted key", object.getClass());
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 191 */         if (pk == null) {
/* 192 */           object = pemParser.readObject();
/*     */         }
/*     */       } 
/*     */       
/* 196 */       if (pk == null && 
/* 197 */         logger.isDebugEnabled()) {
/* 198 */         logger.debug("No key found");
/*     */       }
/*     */ 
/*     */       
/* 202 */       return pk;
/*     */     } finally {
/* 204 */       if (pemParser != null) {
/*     */         try {
/* 206 */           pemParser.close();
/* 207 */         } catch (Exception exception) {
/* 208 */           logger.debug("Failed closing pem parser", exception);
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private static PEMParser newParser(File keyFile) throws FileNotFoundException {
/* 215 */     return new PEMParser(new FileReader(keyFile));
/*     */   }
/*     */   
/*     */   private static PEMParser newParser(InputStream keyInputStream) {
/* 219 */     return new PEMParser(new InputStreamReader(keyInputStream, CharsetUtil.US_ASCII));
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-handler-4.1.93.Final.jar!\io\netty\handler\ssl\BouncyCastlePemReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */