/*     */ package io.netty.handler.ssl;
/*     */ 
/*     */ import io.netty.internal.tcnative.CertificateCallback;
/*     */ import io.netty.internal.tcnative.SSL;
/*     */ import io.netty.internal.tcnative.SSLContext;
/*     */ import io.netty.util.internal.SuppressJava6Requirement;
/*     */ import java.security.KeyStore;
/*     */ import java.security.PrivateKey;
/*     */ import java.security.cert.Certificate;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.net.ssl.KeyManagerFactory;
/*     */ import javax.net.ssl.SSLException;
/*     */ import javax.net.ssl.SSLSessionContext;
/*     */ import javax.net.ssl.TrustManagerFactory;
/*     */ import javax.net.ssl.X509ExtendedTrustManager;
/*     */ import javax.net.ssl.X509TrustManager;
/*     */ import javax.security.auth.x500.X500Principal;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ReferenceCountedOpenSslClientContext
/*     */   extends ReferenceCountedOpenSslContext
/*     */ {
/*  51 */   private static final Set<String> SUPPORTED_KEY_TYPES = Collections.unmodifiableSet(new LinkedHashSet<String>(
/*  52 */         Arrays.asList(new String[] { "RSA", "DH_RSA", "EC", "EC_RSA", "EC_EC" })));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final OpenSslSessionContext sessionContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ReferenceCountedOpenSslClientContext(X509Certificate[] trustCertCollection, TrustManagerFactory trustManagerFactory, X509Certificate[] keyCertChain, PrivateKey key, String keyPassword, KeyManagerFactory keyManagerFactory, Iterable<String> ciphers, CipherSuiteFilter cipherFilter, ApplicationProtocolConfig apn, String[] protocols, long sessionCacheSize, long sessionTimeout, boolean enableOcsp, String keyStore, Map.Entry<SslContextOption<?>, Object>... options) throws SSLException {
/*  67 */     super(ciphers, cipherFilter, toNegotiator(apn), 0, (Certificate[])keyCertChain, ClientAuth.NONE, protocols, false, enableOcsp, true, options);
/*     */     
/*  69 */     boolean success = false;
/*     */     try {
/*  71 */       this.sessionContext = newSessionContext(this, this.ctx, this.engineMap, trustCertCollection, trustManagerFactory, keyCertChain, key, keyPassword, keyManagerFactory, keyStore, sessionCacheSize, sessionTimeout);
/*     */ 
/*     */       
/*  74 */       success = true;
/*     */     } finally {
/*  76 */       if (!success) {
/*  77 */         release();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public OpenSslSessionContext sessionContext() {
/*  84 */     return this.sessionContext;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static OpenSslSessionContext newSessionContext(ReferenceCountedOpenSslContext thiz, long ctx, OpenSslEngineMap engineMap, X509Certificate[] trustCertCollection, TrustManagerFactory trustManagerFactory, X509Certificate[] keyCertChain, PrivateKey key, String keyPassword, KeyManagerFactory keyManagerFactory, String keyStore, long sessionCacheSize, long sessionTimeout) throws SSLException {
/*  95 */     if ((key == null && keyCertChain != null) || (key != null && keyCertChain == null)) {
/*  96 */       throw new IllegalArgumentException("Either both keyCertChain and key needs to be null or none of them");
/*     */     }
/*     */     
/*  99 */     OpenSslKeyMaterialProvider keyMaterialProvider = null;
/*     */     try {
/*     */       try {
/* 102 */         if (!OpenSsl.useKeyManagerFactory()) {
/* 103 */           if (keyManagerFactory != null) {
/* 104 */             throw new IllegalArgumentException("KeyManagerFactory not supported");
/*     */           }
/*     */           
/* 107 */           if (keyCertChain != null) {
/* 108 */             setKeyMaterial(ctx, keyCertChain, key, keyPassword);
/*     */           }
/*     */         } else {
/*     */           
/* 112 */           if (keyManagerFactory == null && keyCertChain != null) {
/* 113 */             char[] keyPasswordChars = keyStorePassword(keyPassword);
/* 114 */             KeyStore ks = buildKeyStore(keyCertChain, key, keyPasswordChars, keyStore);
/* 115 */             if (ks.aliases().hasMoreElements()) {
/* 116 */               keyManagerFactory = new OpenSslX509KeyManagerFactory();
/*     */             } else {
/*     */               
/* 119 */               keyManagerFactory = new OpenSslCachingX509KeyManagerFactory(KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm()));
/*     */             } 
/* 121 */             keyManagerFactory.init(ks, keyPasswordChars);
/* 122 */             keyMaterialProvider = providerFor(keyManagerFactory, keyPassword);
/* 123 */           } else if (keyManagerFactory != null) {
/* 124 */             keyMaterialProvider = providerFor(keyManagerFactory, keyPassword);
/*     */           } 
/*     */           
/* 127 */           if (keyMaterialProvider != null) {
/* 128 */             OpenSslKeyMaterialManager materialManager = new OpenSslKeyMaterialManager(keyMaterialProvider);
/* 129 */             SSLContext.setCertificateCallback(ctx, new OpenSslClientCertificateCallback(engineMap, materialManager));
/*     */           }
/*     */         
/*     */         } 
/* 133 */       } catch (Exception e) {
/* 134 */         throw new SSLException("failed to set certificate and key", e);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 143 */       SSLContext.setVerify(ctx, 1, 10);
/*     */       
/*     */       try {
/* 146 */         if (trustCertCollection != null) {
/* 147 */           trustManagerFactory = buildTrustManagerFactory(trustCertCollection, trustManagerFactory, keyStore);
/* 148 */         } else if (trustManagerFactory == null) {
/* 149 */           trustManagerFactory = TrustManagerFactory.getInstance(
/* 150 */               TrustManagerFactory.getDefaultAlgorithm());
/* 151 */           trustManagerFactory.init((KeyStore)null);
/*     */         } 
/* 153 */         X509TrustManager manager = chooseTrustManager(trustManagerFactory.getTrustManagers());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 161 */         setVerifyCallback(ctx, engineMap, manager);
/* 162 */       } catch (Exception e) {
/* 163 */         if (keyMaterialProvider != null) {
/* 164 */           keyMaterialProvider.destroy();
/*     */         }
/* 166 */         throw new SSLException("unable to setup trustmanager", e);
/*     */       } 
/* 168 */       OpenSslClientSessionContext context = new OpenSslClientSessionContext(thiz, keyMaterialProvider);
/* 169 */       context.setSessionCacheEnabled(CLIENT_ENABLE_SESSION_CACHE);
/* 170 */       if (sessionCacheSize > 0L) {
/* 171 */         context.setSessionCacheSize((int)Math.min(sessionCacheSize, 2147483647L));
/*     */       }
/* 173 */       if (sessionTimeout > 0L) {
/* 174 */         context.setSessionTimeout((int)Math.min(sessionTimeout, 2147483647L));
/*     */       }
/*     */       
/* 177 */       if (CLIENT_ENABLE_SESSION_TICKET) {
/* 178 */         context.setTicketKeys(new OpenSslSessionTicketKey[0]);
/*     */       }
/*     */       
/* 181 */       keyMaterialProvider = null;
/* 182 */       return context;
/*     */     } finally {
/* 184 */       if (keyMaterialProvider != null) {
/* 185 */         keyMaterialProvider.destroy();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @SuppressJava6Requirement(reason = "Guarded by java version check")
/*     */   private static void setVerifyCallback(long ctx, OpenSslEngineMap engineMap, X509TrustManager manager) {
/* 193 */     if (useExtendedTrustManager(manager)) {
/* 194 */       SSLContext.setCertVerifyCallback(ctx, new ExtendedTrustManagerVerifyCallback(engineMap, (X509ExtendedTrustManager)manager));
/*     */     } else {
/*     */       
/* 197 */       SSLContext.setCertVerifyCallback(ctx, new TrustManagerVerifyCallback(engineMap, manager));
/*     */     } 
/*     */   }
/*     */   
/*     */   static final class OpenSslClientSessionContext extends OpenSslSessionContext {
/*     */     OpenSslClientSessionContext(ReferenceCountedOpenSslContext context, OpenSslKeyMaterialProvider provider) {
/* 203 */       super(context, provider, SSL.SSL_SESS_CACHE_CLIENT, new OpenSslClientSessionCache(context.engineMap));
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class TrustManagerVerifyCallback extends ReferenceCountedOpenSslContext.AbstractCertificateVerifier {
/*     */     private final X509TrustManager manager;
/*     */     
/*     */     TrustManagerVerifyCallback(OpenSslEngineMap engineMap, X509TrustManager manager) {
/* 211 */       super(engineMap);
/* 212 */       this.manager = manager;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     void verify(ReferenceCountedOpenSslEngine engine, X509Certificate[] peerCerts, String auth) throws Exception {
/* 218 */       this.manager.checkServerTrusted(peerCerts, auth);
/*     */     }
/*     */   }
/*     */   
/*     */   @SuppressJava6Requirement(reason = "Usage guarded by java version check")
/*     */   private static final class ExtendedTrustManagerVerifyCallback extends ReferenceCountedOpenSslContext.AbstractCertificateVerifier {
/*     */     private final X509ExtendedTrustManager manager;
/*     */     
/*     */     ExtendedTrustManagerVerifyCallback(OpenSslEngineMap engineMap, X509ExtendedTrustManager manager) {
/* 227 */       super(engineMap);
/* 228 */       this.manager = manager;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     void verify(ReferenceCountedOpenSslEngine engine, X509Certificate[] peerCerts, String auth) throws Exception {
/* 234 */       this.manager.checkServerTrusted(peerCerts, auth, engine);
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class OpenSslClientCertificateCallback implements CertificateCallback {
/*     */     private final OpenSslEngineMap engineMap;
/*     */     private final OpenSslKeyMaterialManager keyManagerHolder;
/*     */     
/*     */     OpenSslClientCertificateCallback(OpenSslEngineMap engineMap, OpenSslKeyMaterialManager keyManagerHolder) {
/* 243 */       this.engineMap = engineMap;
/* 244 */       this.keyManagerHolder = keyManagerHolder;
/*     */     }
/*     */ 
/*     */     
/*     */     public void handle(long ssl, byte[] keyTypeBytes, byte[][] asn1DerEncodedPrincipals) throws Exception {
/* 249 */       ReferenceCountedOpenSslEngine engine = this.engineMap.get(ssl);
/*     */       
/* 251 */       if (engine == null)
/*     */         return; 
/*     */       try {
/*     */         X500Principal[] issuers;
/* 255 */         Set<String> keyTypesSet = supportedClientKeyTypes(keyTypeBytes);
/* 256 */         String[] keyTypes = keyTypesSet.<String>toArray(new String[0]);
/*     */         
/* 258 */         if (asn1DerEncodedPrincipals == null) {
/* 259 */           issuers = null;
/*     */         } else {
/* 261 */           issuers = new X500Principal[asn1DerEncodedPrincipals.length];
/* 262 */           for (int i = 0; i < asn1DerEncodedPrincipals.length; i++) {
/* 263 */             issuers[i] = new X500Principal(asn1DerEncodedPrincipals[i]);
/*     */           }
/*     */         } 
/* 266 */         this.keyManagerHolder.setKeyMaterialClientSide(engine, keyTypes, issuers);
/* 267 */       } catch (Throwable cause) {
/* 268 */         engine.initHandshakeException(cause);
/* 269 */         if (cause instanceof Exception) {
/* 270 */           throw (Exception)cause;
/*     */         }
/* 272 */         throw new SSLException(cause);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private static Set<String> supportedClientKeyTypes(byte[] clientCertificateTypes) {
/* 285 */       if (clientCertificateTypes == null)
/*     */       {
/* 287 */         return ReferenceCountedOpenSslClientContext.SUPPORTED_KEY_TYPES;
/*     */       }
/* 289 */       Set<String> result = new HashSet<String>(clientCertificateTypes.length);
/* 290 */       for (byte keyTypeCode : clientCertificateTypes) {
/* 291 */         String keyType = clientKeyType(keyTypeCode);
/* 292 */         if (keyType != null)
/*     */         {
/*     */ 
/*     */           
/* 296 */           result.add(keyType); } 
/*     */       } 
/* 298 */       return result;
/*     */     }
/*     */ 
/*     */     
/*     */     private static String clientKeyType(byte clientCertificateType) {
/* 303 */       switch (clientCertificateType) {
/*     */         case 1:
/* 305 */           return "RSA";
/*     */         case 3:
/* 307 */           return "DH_RSA";
/*     */         case 64:
/* 309 */           return "EC";
/*     */         case 65:
/* 311 */           return "EC_RSA";
/*     */         case 66:
/* 313 */           return "EC_EC";
/*     */       } 
/* 315 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-handler-4.1.93.Final.jar!\io\netty\handler\ssl\ReferenceCountedOpenSslClientContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */