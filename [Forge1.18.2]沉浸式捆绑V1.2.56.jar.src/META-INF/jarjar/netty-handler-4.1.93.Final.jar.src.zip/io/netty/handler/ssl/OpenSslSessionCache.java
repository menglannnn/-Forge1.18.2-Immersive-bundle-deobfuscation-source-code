/*     */ package io.netty.handler.ssl;
/*     */ 
/*     */ import io.netty.internal.tcnative.SSLSession;
/*     */ import io.netty.internal.tcnative.SSLSessionCache;
/*     */ import io.netty.util.ResourceLeakDetector;
/*     */ import io.netty.util.ResourceLeakDetectorFactory;
/*     */ import io.netty.util.ResourceLeakTracker;
/*     */ import io.netty.util.internal.EmptyArrays;
/*     */ import io.netty.util.internal.SystemPropertyUtil;
/*     */ import java.security.Principal;
/*     */ import java.security.cert.Certificate;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import javax.net.ssl.SSLSessionContext;
/*     */ import javax.security.cert.X509Certificate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class OpenSslSessionCache
/*     */   implements SSLSessionCache
/*     */ {
/*  40 */   private static final OpenSslSession[] EMPTY_SESSIONS = new OpenSslSession[0];
/*     */   private static final int DEFAULT_CACHE_SIZE;
/*     */   private final OpenSslEngineMap engineMap;
/*     */   
/*     */   static {
/*  45 */     int cacheSize = SystemPropertyUtil.getInt("javax.net.ssl.sessionCacheSize", 20480);
/*  46 */     if (cacheSize >= 0) {
/*  47 */       DEFAULT_CACHE_SIZE = cacheSize;
/*     */     } else {
/*  49 */       DEFAULT_CACHE_SIZE = 20480;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*  54 */   private final Map<OpenSslSessionId, NativeSslSession> sessions = new LinkedHashMap<OpenSslSessionId, NativeSslSession>()
/*     */     {
/*     */       private static final long serialVersionUID = -7773696788135734448L;
/*     */ 
/*     */ 
/*     */       
/*     */       protected boolean removeEldestEntry(Map.Entry<OpenSslSessionId, OpenSslSessionCache.NativeSslSession> eldest) {
/*  61 */         int maxSize = OpenSslSessionCache.this.maximumCacheSize.get();
/*  62 */         if (maxSize >= 0 && size() > maxSize) {
/*  63 */           OpenSslSessionCache.this.removeSessionWithId(eldest.getKey());
/*     */         }
/*     */         
/*  66 */         return false;
/*     */       }
/*     */     };
/*     */   
/*  70 */   private final AtomicInteger maximumCacheSize = new AtomicInteger(DEFAULT_CACHE_SIZE);
/*     */ 
/*     */ 
/*     */   
/*  74 */   private final AtomicInteger sessionTimeout = new AtomicInteger(300);
/*     */   private int sessionCounter;
/*     */   
/*     */   OpenSslSessionCache(OpenSslEngineMap engineMap) {
/*  78 */     this.engineMap = engineMap;
/*     */   }
/*     */   
/*     */   final void setSessionTimeout(int seconds) {
/*  82 */     int oldTimeout = this.sessionTimeout.getAndSet(seconds);
/*  83 */     if (oldTimeout > seconds)
/*     */     {
/*     */       
/*  86 */       clear();
/*     */     }
/*     */   }
/*     */   
/*     */   final int getSessionTimeout() {
/*  91 */     return this.sessionTimeout.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean sessionCreated(NativeSslSession session) {
/* 101 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void sessionRemoved(NativeSslSession session) {}
/*     */ 
/*     */ 
/*     */   
/*     */   final void setSessionCacheSize(int size) {
/* 112 */     long oldSize = this.maximumCacheSize.getAndSet(size);
/* 113 */     if (oldSize > size || size == 0)
/*     */     {
/* 115 */       clear();
/*     */     }
/*     */   }
/*     */   
/*     */   final int getSessionCacheSize() {
/* 120 */     return this.maximumCacheSize.get();
/*     */   }
/*     */   
/*     */   private void expungeInvalidSessions() {
/* 124 */     if (this.sessions.isEmpty()) {
/*     */       return;
/*     */     }
/* 127 */     long now = System.currentTimeMillis();
/* 128 */     Iterator<Map.Entry<OpenSslSessionId, NativeSslSession>> iterator = this.sessions.entrySet().iterator();
/* 129 */     while (iterator.hasNext()) {
/* 130 */       NativeSslSession session = (NativeSslSession)((Map.Entry)iterator.next()).getValue();
/*     */ 
/*     */ 
/*     */       
/* 134 */       if (session.isValid(now)) {
/*     */         break;
/*     */       }
/* 137 */       iterator.remove();
/*     */       
/* 139 */       notifyRemovalAndFree(session);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean sessionCreated(long ssl, long sslSession) {
/* 145 */     ReferenceCountedOpenSslEngine engine = this.engineMap.get(ssl);
/* 146 */     if (engine == null)
/*     */     {
/* 148 */       return false;
/*     */     }
/*     */     
/* 151 */     NativeSslSession session = new NativeSslSession(sslSession, engine.getPeerHost(), engine.getPeerPort(), getSessionTimeout() * 1000L);
/* 152 */     engine.setSessionId(session.sessionId());
/* 153 */     synchronized (this) {
/*     */ 
/*     */       
/* 156 */       if (++this.sessionCounter == 255) {
/* 157 */         this.sessionCounter = 0;
/* 158 */         expungeInvalidSessions();
/*     */       } 
/*     */       
/* 161 */       if (!sessionCreated(session)) {
/*     */ 
/*     */         
/* 164 */         session.close();
/* 165 */         return false;
/*     */       } 
/*     */       
/* 168 */       NativeSslSession old = this.sessions.put(session.sessionId(), session);
/* 169 */       if (old != null) {
/* 170 */         notifyRemovalAndFree(old);
/*     */       }
/*     */     } 
/* 173 */     return true;
/*     */   }
/*     */   
/*     */   public final long getSession(long ssl, byte[] sessionId) {
/*     */     NativeSslSession session;
/* 178 */     OpenSslSessionId id = new OpenSslSessionId(sessionId);
/*     */     
/* 180 */     synchronized (this) {
/* 181 */       session = this.sessions.get(id);
/* 182 */       if (session == null) {
/* 183 */         return -1L;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 188 */       if (!session.isValid() || 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 193 */         !session.upRef()) {
/*     */         
/* 195 */         removeSessionWithId(session.sessionId());
/* 196 */         return -1L;
/*     */       } 
/*     */ 
/*     */       
/* 200 */       if (session.shouldBeSingleUse())
/*     */       {
/*     */         
/* 203 */         removeSessionWithId(session.sessionId());
/*     */       }
/*     */     } 
/* 206 */     session.updateLastAccessedTime();
/* 207 */     return session.session();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setSession(long ssl, String host, int port) {}
/*     */ 
/*     */ 
/*     */   
/*     */   final synchronized void removeSessionWithId(OpenSslSessionId id) {
/* 218 */     NativeSslSession sslSession = this.sessions.remove(id);
/* 219 */     if (sslSession != null) {
/* 220 */       notifyRemovalAndFree(sslSession);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final synchronized boolean containsSessionWithId(OpenSslSessionId id) {
/* 228 */     return this.sessions.containsKey(id);
/*     */   }
/*     */   
/*     */   private void notifyRemovalAndFree(NativeSslSession session) {
/* 232 */     sessionRemoved(session);
/* 233 */     session.free();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final synchronized OpenSslSession getSession(OpenSslSessionId id) {
/* 240 */     NativeSslSession session = this.sessions.get(id);
/* 241 */     if (session != null && !session.isValid()) {
/*     */ 
/*     */       
/* 244 */       removeSessionWithId(session.sessionId());
/* 245 */       return null;
/*     */     } 
/* 247 */     return session;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final List<OpenSslSessionId> getIds() {
/*     */     OpenSslSession[] sessionsArray;
/* 255 */     synchronized (this) {
/* 256 */       sessionsArray = (OpenSslSession[])this.sessions.values().toArray((Object[])EMPTY_SESSIONS);
/*     */     } 
/* 258 */     List<OpenSslSessionId> ids = new ArrayList<OpenSslSessionId>(sessionsArray.length);
/* 259 */     for (OpenSslSession session : sessionsArray) {
/* 260 */       if (session.isValid()) {
/* 261 */         ids.add(session.sessionId());
/*     */       }
/*     */     } 
/* 264 */     return ids;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   synchronized void clear() {
/* 271 */     Iterator<Map.Entry<OpenSslSessionId, NativeSslSession>> iterator = this.sessions.entrySet().iterator();
/* 272 */     while (iterator.hasNext()) {
/* 273 */       NativeSslSession session = (NativeSslSession)((Map.Entry)iterator.next()).getValue();
/* 274 */       iterator.remove();
/*     */ 
/*     */       
/* 277 */       notifyRemovalAndFree(session);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   static final class NativeSslSession
/*     */     implements OpenSslSession
/*     */   {
/* 285 */     static final ResourceLeakDetector<NativeSslSession> LEAK_DETECTOR = ResourceLeakDetectorFactory.instance()
/* 286 */       .newResourceLeakDetector(NativeSslSession.class);
/*     */     private final ResourceLeakTracker<NativeSslSession> leakTracker;
/*     */     private final long session;
/*     */     private final String peerHost;
/*     */     private final int peerPort;
/*     */     private final OpenSslSessionId id;
/*     */     private final long timeout;
/* 293 */     private final long creationTime = System.currentTimeMillis();
/* 294 */     private volatile long lastAccessedTime = this.creationTime;
/*     */     private volatile boolean valid = true;
/*     */     private boolean freed;
/*     */     
/*     */     NativeSslSession(long session, String peerHost, int peerPort, long timeout) {
/* 299 */       this.session = session;
/* 300 */       this.peerHost = peerHost;
/* 301 */       this.peerPort = peerPort;
/* 302 */       this.timeout = timeout;
/* 303 */       this.id = new OpenSslSessionId(SSLSession.getSessionId(session));
/* 304 */       this.leakTracker = LEAK_DETECTOR.track(this);
/*     */     }
/*     */ 
/*     */     
/*     */     public void setSessionId(OpenSslSessionId id) {
/* 309 */       throw new UnsupportedOperationException();
/*     */     }
/*     */     
/*     */     boolean shouldBeSingleUse() {
/* 313 */       assert !this.freed;
/* 314 */       return SSLSession.shouldBeSingleUse(this.session);
/*     */     }
/*     */     
/*     */     long session() {
/* 318 */       assert !this.freed;
/* 319 */       return this.session;
/*     */     }
/*     */     
/*     */     boolean upRef() {
/* 323 */       assert !this.freed;
/* 324 */       return SSLSession.upRef(this.session);
/*     */     }
/*     */     
/*     */     synchronized void free() {
/* 328 */       close();
/* 329 */       SSLSession.free(this.session);
/*     */     }
/*     */     
/*     */     void close() {
/* 333 */       assert !this.freed;
/* 334 */       this.freed = true;
/* 335 */       invalidate();
/* 336 */       if (this.leakTracker != null) {
/* 337 */         this.leakTracker.close(this);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public OpenSslSessionId sessionId() {
/* 343 */       return this.id;
/*     */     }
/*     */     
/*     */     boolean isValid(long now) {
/* 347 */       return (this.creationTime + this.timeout >= now && this.valid);
/*     */     }
/*     */ 
/*     */     
/*     */     public void setLocalCertificate(Certificate[] localCertificate) {
/* 352 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public OpenSslSessionContext getSessionContext() {
/* 357 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public void tryExpandApplicationBufferSize(int packetLengthDataOnly) {
/* 362 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void handshakeFinished(byte[] id, String cipher, String protocol, byte[] peerCertificate, byte[][] peerCertificateChain, long creationTime, long timeout) {
/* 368 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public byte[] getId() {
/* 373 */       return this.id.cloneBytes();
/*     */     }
/*     */ 
/*     */     
/*     */     public long getCreationTime() {
/* 378 */       return this.creationTime;
/*     */     }
/*     */     
/*     */     void updateLastAccessedTime() {
/* 382 */       this.lastAccessedTime = System.currentTimeMillis();
/*     */     }
/*     */ 
/*     */     
/*     */     public long getLastAccessedTime() {
/* 387 */       return this.lastAccessedTime;
/*     */     }
/*     */ 
/*     */     
/*     */     public void invalidate() {
/* 392 */       this.valid = false;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isValid() {
/* 397 */       return isValid(System.currentTimeMillis());
/*     */     }
/*     */ 
/*     */     
/*     */     public void putValue(String name, Object value) {
/* 402 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public Object getValue(String name) {
/* 407 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void removeValue(String name) {}
/*     */ 
/*     */ 
/*     */     
/*     */     public String[] getValueNames() {
/* 417 */       return EmptyArrays.EMPTY_STRINGS;
/*     */     }
/*     */ 
/*     */     
/*     */     public Certificate[] getPeerCertificates() {
/* 422 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public Certificate[] getLocalCertificates() {
/* 427 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public X509Certificate[] getPeerCertificateChain() {
/* 432 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public Principal getPeerPrincipal() {
/* 437 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public Principal getLocalPrincipal() {
/* 442 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public String getCipherSuite() {
/* 447 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getProtocol() {
/* 452 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getPeerHost() {
/* 457 */       return this.peerHost;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getPeerPort() {
/* 462 */       return this.peerPort;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getPacketBufferSize() {
/* 467 */       return ReferenceCountedOpenSslEngine.MAX_RECORD_SIZE;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getApplicationBufferSize() {
/* 472 */       return ReferenceCountedOpenSslEngine.MAX_PLAINTEXT_LENGTH;
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 477 */       return this.id.hashCode();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/* 482 */       if (this == o) {
/* 483 */         return true;
/*     */       }
/* 485 */       if (!(o instanceof OpenSslSession)) {
/* 486 */         return false;
/*     */       }
/* 488 */       OpenSslSession session1 = (OpenSslSession)o;
/* 489 */       return this.id.equals(session1.sessionId());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-handler-4.1.93.Final.jar!\io\netty\handler\ssl\OpenSslSessionCache.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */