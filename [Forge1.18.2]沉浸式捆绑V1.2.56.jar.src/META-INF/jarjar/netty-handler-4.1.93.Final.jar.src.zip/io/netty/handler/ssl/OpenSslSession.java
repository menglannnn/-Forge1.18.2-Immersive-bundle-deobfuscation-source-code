package io.netty.handler.ssl;

import java.security.cert.Certificate;
import javax.net.ssl.SSLException;
import javax.net.ssl.SSLSession;

interface OpenSslSession extends SSLSession {
  OpenSslSessionId sessionId();
  
  void setLocalCertificate(Certificate[] paramArrayOfCertificate);
  
  void setSessionId(OpenSslSessionId paramOpenSslSessionId);
  
  OpenSslSessionContext getSessionContext();
  
  void tryExpandApplicationBufferSize(int paramInt);
  
  void handshakeFinished(byte[] paramArrayOfbyte1, String paramString1, String paramString2, byte[] paramArrayOfbyte2, byte[][] paramArrayOfbyte, long paramLong1, long paramLong2) throws SSLException;
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-handler-4.1.93.Final.jar!\io\netty\handler\ssl\OpenSslSession.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */