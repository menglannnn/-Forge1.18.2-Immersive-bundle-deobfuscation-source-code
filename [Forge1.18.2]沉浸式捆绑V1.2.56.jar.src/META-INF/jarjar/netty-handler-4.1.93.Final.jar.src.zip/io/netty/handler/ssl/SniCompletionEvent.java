/*    */ package io.netty.handler.ssl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SniCompletionEvent
/*    */   extends SslCompletionEvent
/*    */ {
/*    */   private final String hostname;
/*    */   
/*    */   public SniCompletionEvent(String hostname) {
/* 29 */     this.hostname = hostname;
/*    */   }
/*    */   
/*    */   public SniCompletionEvent(String hostname, Throwable cause) {
/* 33 */     super(cause);
/* 34 */     this.hostname = hostname;
/*    */   }
/*    */   
/*    */   public SniCompletionEvent(Throwable cause) {
/* 38 */     this(null, cause);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String hostname() {
/* 45 */     return this.hostname;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 50 */     Throwable cause = cause();
/* 51 */     return (cause == null) ? (getClass().getSimpleName() + "(SUCCESS='" + this.hostname + "'\")") : (
/* 52 */       getClass().getSimpleName() + '(' + cause + ')');
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-handler-4.1.93.Final.jar!\io\netty\handler\ssl\SniCompletionEvent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */