/*     */ package io.netty.handler.ssl;
/*     */ 
/*     */ import java.security.Principal;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.net.ssl.SSLException;
/*     */ import javax.net.ssl.SSLHandshakeException;
/*     */ import javax.net.ssl.X509ExtendedKeyManager;
/*     */ import javax.net.ssl.X509KeyManager;
/*     */ import javax.security.auth.x500.X500Principal;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class OpenSslKeyMaterialManager
/*     */ {
/*     */   static final String KEY_TYPE_RSA = "RSA";
/*     */   static final String KEY_TYPE_DH_RSA = "DH_RSA";
/*     */   static final String KEY_TYPE_EC = "EC";
/*     */   static final String KEY_TYPE_EC_EC = "EC_EC";
/*     */   static final String KEY_TYPE_EC_RSA = "EC_RSA";
/*  51 */   private static final Map<String, String> KEY_TYPES = new HashMap<String, String>();
/*     */   static {
/*  53 */     KEY_TYPES.put("RSA", "RSA");
/*  54 */     KEY_TYPES.put("DHE_RSA", "RSA");
/*  55 */     KEY_TYPES.put("ECDHE_RSA", "RSA");
/*  56 */     KEY_TYPES.put("ECDHE_ECDSA", "EC");
/*  57 */     KEY_TYPES.put("ECDH_RSA", "EC_RSA");
/*  58 */     KEY_TYPES.put("ECDH_ECDSA", "EC_EC");
/*  59 */     KEY_TYPES.put("DH_RSA", "DH_RSA");
/*     */   }
/*     */   
/*     */   private final OpenSslKeyMaterialProvider provider;
/*     */   
/*     */   OpenSslKeyMaterialManager(OpenSslKeyMaterialProvider provider) {
/*  65 */     this.provider = provider;
/*     */   }
/*     */   
/*     */   void setKeyMaterialServerSide(ReferenceCountedOpenSslEngine engine) throws SSLException {
/*  69 */     String[] authMethods = engine.authMethods();
/*  70 */     if (authMethods.length == 0) {
/*  71 */       throw new SSLHandshakeException("Unable to find key material");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  77 */     Set<String> typeSet = new HashSet<String>(KEY_TYPES.size());
/*  78 */     for (String authMethod : authMethods) {
/*  79 */       String type = KEY_TYPES.get(authMethod);
/*  80 */       if (type != null && typeSet.add(type)) {
/*  81 */         String alias = chooseServerAlias(engine, type);
/*  82 */         if (alias != null) {
/*     */           
/*  84 */           setKeyMaterial(engine, alias);
/*     */           return;
/*     */         } 
/*     */       } 
/*     */     } 
/*  89 */     throw new SSLHandshakeException("Unable to find key material for auth method(s): " + 
/*  90 */         Arrays.toString(authMethods));
/*     */   }
/*     */ 
/*     */   
/*     */   void setKeyMaterialClientSide(ReferenceCountedOpenSslEngine engine, String[] keyTypes, X500Principal[] issuer) throws SSLException {
/*  95 */     String alias = chooseClientAlias(engine, keyTypes, issuer);
/*     */ 
/*     */ 
/*     */     
/*  99 */     if (alias != null) {
/* 100 */       setKeyMaterial(engine, alias);
/*     */     }
/*     */   }
/*     */   
/*     */   private void setKeyMaterial(ReferenceCountedOpenSslEngine engine, String alias) throws SSLException {
/* 105 */     OpenSslKeyMaterial keyMaterial = null;
/*     */     try {
/* 107 */       keyMaterial = this.provider.chooseKeyMaterial(engine.alloc, alias);
/* 108 */       if (keyMaterial == null) {
/*     */         return;
/*     */       }
/* 111 */       engine.setKeyMaterial(keyMaterial);
/* 112 */     } catch (SSLException e) {
/* 113 */       throw e;
/* 114 */     } catch (Exception e) {
/* 115 */       throw new SSLException(e);
/*     */     } finally {
/* 117 */       if (keyMaterial != null) {
/* 118 */         keyMaterial.release();
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private String chooseClientAlias(ReferenceCountedOpenSslEngine engine, String[] keyTypes, X500Principal[] issuer) {
/* 124 */     X509KeyManager manager = this.provider.keyManager();
/* 125 */     if (manager instanceof X509ExtendedKeyManager) {
/* 126 */       return ((X509ExtendedKeyManager)manager).chooseEngineClientAlias(keyTypes, (Principal[])issuer, engine);
/*     */     }
/* 128 */     return manager.chooseClientAlias(keyTypes, (Principal[])issuer, null);
/*     */   }
/*     */   
/*     */   private String chooseServerAlias(ReferenceCountedOpenSslEngine engine, String type) {
/* 132 */     X509KeyManager manager = this.provider.keyManager();
/* 133 */     if (manager instanceof X509ExtendedKeyManager) {
/* 134 */       return ((X509ExtendedKeyManager)manager).chooseEngineServerAlias(type, null, engine);
/*     */     }
/* 136 */     return manager.chooseServerAlias(type, null, null);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-handler-4.1.93.Final.jar!\io\netty\handler\ssl\OpenSslKeyMaterialManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */