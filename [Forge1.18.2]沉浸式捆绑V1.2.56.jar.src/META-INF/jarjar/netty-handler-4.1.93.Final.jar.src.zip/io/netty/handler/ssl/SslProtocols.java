package io.netty.handler.ssl;

public final class SslProtocols {
  @Deprecated
  public static final String SSL_v2_HELLO = "SSLv2Hello";
  
  @Deprecated
  public static final String SSL_v2 = "SSLv2";
  
  @Deprecated
  public static final String SSL_v3 = "SSLv3";
  
  @Deprecated
  public static final String TLS_v1 = "TLSv1";
  
  @Deprecated
  public static final String TLS_v1_1 = "TLSv1.1";
  
  public static final String TLS_v1_2 = "TLSv1.2";
  
  public static final String TLS_v1_3 = "TLSv1.3";
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-handler-4.1.93.Final.jar!\io\netty\handler\ssl\SslProtocols.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */