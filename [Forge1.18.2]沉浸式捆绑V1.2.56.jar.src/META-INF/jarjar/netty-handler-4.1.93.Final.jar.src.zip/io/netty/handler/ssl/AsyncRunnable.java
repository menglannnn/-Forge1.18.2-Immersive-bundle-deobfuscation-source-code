package io.netty.handler.ssl;

interface AsyncRunnable extends Runnable {
  void run(Runnable paramRunnable);
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-handler-4.1.93.Final.jar!\io\netty\handler\ssl\AsyncRunnable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */