/*    */ package io.netty.handler.ssl;
/*    */ 
/*    */ import io.netty.internal.tcnative.SSL;
/*    */ import io.netty.internal.tcnative.SSLContext;
/*    */ import java.util.concurrent.locks.Lock;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class OpenSslServerSessionContext
/*    */   extends OpenSslSessionContext
/*    */ {
/*    */   OpenSslServerSessionContext(ReferenceCountedOpenSslContext context, OpenSslKeyMaterialProvider provider) {
/* 29 */     super(context, provider, SSL.SSL_SESS_CACHE_SERVER, new OpenSslSessionCache(context.engineMap));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean setSessionIdContext(byte[] sidCtx) {
/* 42 */     Lock writerLock = this.context.ctxLock.writeLock();
/* 43 */     writerLock.lock();
/*    */     try {
/* 45 */       return SSLContext.setSessionIdContext(this.context.ctx, sidCtx);
/*    */     } finally {
/* 47 */       writerLock.unlock();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-handler-4.1.93.Final.jar!\io\netty\handler\ssl\OpenSslServerSessionContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */