/*     */ package io.netty.handler.ssl;
/*     */ 
/*     */ import io.netty.buffer.ByteBufAllocator;
/*     */ import io.netty.util.ReferenceCountUtil;
/*     */ import io.netty.util.internal.EmptyArrays;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import io.netty.util.internal.logging.InternalLogger;
/*     */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.security.InvalidAlgorithmParameterException;
/*     */ import java.security.KeyException;
/*     */ import java.security.KeyStore;
/*     */ import java.security.KeyStoreException;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.Provider;
/*     */ import java.security.Security;
/*     */ import java.security.UnrecoverableKeyException;
/*     */ import java.security.cert.CertificateException;
/*     */ import java.security.spec.InvalidKeySpecException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javax.crypto.NoSuchPaddingException;
/*     */ import javax.net.ssl.KeyManagerFactory;
/*     */ import javax.net.ssl.SSLContext;
/*     */ import javax.net.ssl.SSLEngine;
/*     */ import javax.net.ssl.SSLSessionContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JdkSslContext
/*     */   extends SslContext
/*     */ {
/*     */   static final String PROTOCOL = "TLS";
/*     */   private static final String[] DEFAULT_PROTOCOLS;
/*     */   private static final List<String> DEFAULT_CIPHERS;
/*     */   private static final List<String> DEFAULT_CIPHERS_NON_TLSV13;
/*     */   private static final Set<String> SUPPORTED_CIPHERS;
/*     */   private static final Set<String> SUPPORTED_CIPHERS_NON_TLSV13;
/*     */   private static final Provider DEFAULT_PROVIDER;
/*  61 */   private static final InternalLogger logger = InternalLoggerFactory.getInstance(JdkSslContext.class);
/*     */   
/*     */   private final String[] protocols;
/*     */   private final String[] cipherSuites;
/*     */   private final List<String> unmodifiableCipherSuites;
/*     */   private final JdkApplicationProtocolNegotiator apn;
/*     */   private final ClientAuth clientAuth;
/*     */   private final SSLContext sslContext;
/*     */   private final boolean isClient;
/*     */   
/*     */   static {
/*  72 */     Defaults defaults = new Defaults();
/*  73 */     defaults.init();
/*     */     
/*  75 */     DEFAULT_PROVIDER = defaults.defaultProvider;
/*  76 */     DEFAULT_PROTOCOLS = defaults.defaultProtocols;
/*  77 */     SUPPORTED_CIPHERS = defaults.supportedCiphers;
/*  78 */     DEFAULT_CIPHERS = defaults.defaultCiphers;
/*  79 */     DEFAULT_CIPHERS_NON_TLSV13 = defaults.defaultCiphersNonTLSv13;
/*  80 */     SUPPORTED_CIPHERS_NON_TLSV13 = defaults.supportedCiphersNonTLSv13;
/*     */     
/*  82 */     if (logger.isDebugEnabled()) {
/*  83 */       logger.debug("Default protocols (JDK): {} ", Arrays.asList(DEFAULT_PROTOCOLS));
/*  84 */       logger.debug("Default cipher suites (JDK): {}", DEFAULT_CIPHERS);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class Defaults
/*     */   {
/*     */     String[] defaultProtocols;
/*     */     
/*     */     List<String> defaultCiphers;
/*     */     List<String> defaultCiphersNonTLSv13;
/*     */     
/*     */     void init() {
/*     */       SSLContext context;
/*     */       try {
/*  99 */         context = SSLContext.getInstance("TLS");
/* 100 */         context.init(null, null, null);
/* 101 */       } catch (Exception e) {
/* 102 */         throw new Error("failed to initialize the default SSL context", e);
/*     */       } 
/*     */       
/* 105 */       this.defaultProvider = context.getProvider();
/*     */       
/* 107 */       SSLEngine engine = context.createSSLEngine();
/* 108 */       this.defaultProtocols = JdkSslContext.defaultProtocols(context, engine);
/*     */       
/* 110 */       this.supportedCiphers = Collections.unmodifiableSet(JdkSslContext.supportedCiphers(engine));
/* 111 */       this.defaultCiphers = Collections.unmodifiableList(JdkSslContext.defaultCiphers(engine, this.supportedCiphers));
/*     */       
/* 113 */       List<String> ciphersNonTLSv13 = new ArrayList<String>(this.defaultCiphers);
/* 114 */       ciphersNonTLSv13.removeAll(Arrays.asList((Object[])SslUtils.DEFAULT_TLSV13_CIPHER_SUITES));
/* 115 */       this.defaultCiphersNonTLSv13 = Collections.unmodifiableList(ciphersNonTLSv13);
/*     */       
/* 117 */       Set<String> suppertedCiphersNonTLSv13 = new LinkedHashSet<String>(this.supportedCiphers);
/* 118 */       suppertedCiphersNonTLSv13.removeAll(Arrays.asList((Object[])SslUtils.DEFAULT_TLSV13_CIPHER_SUITES));
/* 119 */       this.supportedCiphersNonTLSv13 = Collections.unmodifiableSet(suppertedCiphersNonTLSv13);
/*     */     }
/*     */     Set<String> supportedCiphers; Set<String> supportedCiphersNonTLSv13; Provider defaultProvider;
/*     */     private Defaults() {} }
/*     */   
/*     */   private static String[] defaultProtocols(SSLContext context, SSLEngine engine) {
/* 125 */     String[] supportedProtocols = context.getDefaultSSLParameters().getProtocols();
/* 126 */     Set<String> supportedProtocolsSet = new HashSet<String>(supportedProtocols.length);
/* 127 */     Collections.addAll(supportedProtocolsSet, supportedProtocols);
/* 128 */     List<String> protocols = new ArrayList<String>();
/* 129 */     SslUtils.addIfSupported(supportedProtocolsSet, protocols, new String[] { "TLSv1.3", "TLSv1.2", "TLSv1.1", "TLSv1" });
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 134 */     if (!protocols.isEmpty()) {
/* 135 */       return protocols.<String>toArray(EmptyArrays.EMPTY_STRINGS);
/*     */     }
/* 137 */     return engine.getEnabledProtocols();
/*     */   }
/*     */ 
/*     */   
/*     */   private static Set<String> supportedCiphers(SSLEngine engine) {
/* 142 */     String[] supportedCiphers = engine.getSupportedCipherSuites();
/* 143 */     Set<String> supportedCiphersSet = new LinkedHashSet<String>(supportedCiphers.length);
/* 144 */     for (int i = 0; i < supportedCiphers.length; i++) {
/* 145 */       String supportedCipher = supportedCiphers[i];
/* 146 */       supportedCiphersSet.add(supportedCipher);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 156 */       if (supportedCipher.startsWith("SSL_")) {
/* 157 */         String tlsPrefixedCipherName = "TLS_" + supportedCipher.substring("SSL_".length());
/*     */         try {
/* 159 */           engine.setEnabledCipherSuites(new String[] { tlsPrefixedCipherName });
/* 160 */           supportedCiphersSet.add(tlsPrefixedCipherName);
/* 161 */         } catch (IllegalArgumentException illegalArgumentException) {}
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 166 */     return supportedCiphersSet;
/*     */   }
/*     */   
/*     */   private static List<String> defaultCiphers(SSLEngine engine, Set<String> supportedCiphers) {
/* 170 */     List<String> ciphers = new ArrayList<String>();
/* 171 */     SslUtils.addIfSupported(supportedCiphers, ciphers, SslUtils.DEFAULT_CIPHER_SUITES);
/* 172 */     SslUtils.useFallbackCiphersIfDefaultIsEmpty(ciphers, engine.getEnabledCipherSuites());
/* 173 */     return ciphers;
/*     */   }
/*     */   
/*     */   private static boolean isTlsV13Supported(String[] protocols) {
/* 177 */     for (String protocol : protocols) {
/* 178 */       if ("TLSv1.3".equals(protocol)) {
/* 179 */         return true;
/*     */       }
/*     */     } 
/* 182 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public JdkSslContext(SSLContext sslContext, boolean isClient, ClientAuth clientAuth) {
/* 206 */     this(sslContext, isClient, (Iterable<String>)null, IdentityCipherSuiteFilter.INSTANCE, JdkDefaultApplicationProtocolNegotiator.INSTANCE, clientAuth, (String[])null, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public JdkSslContext(SSLContext sslContext, boolean isClient, Iterable<String> ciphers, CipherSuiteFilter cipherFilter, ApplicationProtocolConfig apn, ClientAuth clientAuth) {
/* 226 */     this(sslContext, isClient, ciphers, cipherFilter, apn, clientAuth, (String[])null, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JdkSslContext(SSLContext sslContext, boolean isClient, Iterable<String> ciphers, CipherSuiteFilter cipherFilter, ApplicationProtocolConfig apn, ClientAuth clientAuth, String[] protocols, boolean startTls) {
/* 249 */     this(sslContext, isClient, ciphers, cipherFilter, 
/*     */ 
/*     */ 
/*     */         
/* 253 */         toNegotiator(apn, !isClient), clientAuth, (protocols == null) ? null : (String[])protocols
/*     */         
/* 255 */         .clone(), startTls);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   JdkSslContext(SSLContext sslContext, boolean isClient, Iterable<String> ciphers, CipherSuiteFilter cipherFilter, JdkApplicationProtocolNegotiator apn, ClientAuth clientAuth, String[] protocols, boolean startTls) {
/* 262 */     super(startTls); List<String> defaultCiphers; Set<String> supportedCiphers;
/* 263 */     this.apn = (JdkApplicationProtocolNegotiator)ObjectUtil.checkNotNull(apn, "apn");
/* 264 */     this.clientAuth = (ClientAuth)ObjectUtil.checkNotNull(clientAuth, "clientAuth");
/* 265 */     this.sslContext = (SSLContext)ObjectUtil.checkNotNull(sslContext, "sslContext");
/*     */ 
/*     */ 
/*     */     
/* 269 */     if (DEFAULT_PROVIDER.equals(sslContext.getProvider())) {
/* 270 */       this.protocols = (protocols == null) ? DEFAULT_PROTOCOLS : protocols;
/* 271 */       if (isTlsV13Supported(this.protocols)) {
/* 272 */         supportedCiphers = SUPPORTED_CIPHERS;
/* 273 */         defaultCiphers = DEFAULT_CIPHERS;
/*     */       } else {
/*     */         
/* 276 */         supportedCiphers = SUPPORTED_CIPHERS_NON_TLSV13;
/* 277 */         defaultCiphers = DEFAULT_CIPHERS_NON_TLSV13;
/*     */       }
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 283 */       SSLEngine engine = sslContext.createSSLEngine();
/*     */       try {
/* 285 */         if (protocols == null) {
/* 286 */           this.protocols = defaultProtocols(sslContext, engine);
/*     */         } else {
/* 288 */           this.protocols = protocols;
/*     */         } 
/* 290 */         supportedCiphers = supportedCiphers(engine);
/* 291 */         defaultCiphers = defaultCiphers(engine, supportedCiphers);
/* 292 */         if (!isTlsV13Supported(this.protocols))
/*     */         {
/* 294 */           for (String cipher : SslUtils.DEFAULT_TLSV13_CIPHER_SUITES) {
/* 295 */             supportedCiphers.remove(cipher);
/* 296 */             defaultCiphers.remove(cipher);
/*     */           } 
/*     */         }
/*     */       } finally {
/* 300 */         ReferenceCountUtil.release(engine);
/*     */       } 
/*     */     } 
/*     */     
/* 304 */     this.cipherSuites = ((CipherSuiteFilter)ObjectUtil.checkNotNull(cipherFilter, "cipherFilter")).filterCipherSuites(ciphers, defaultCiphers, supportedCiphers);
/*     */ 
/*     */     
/* 307 */     this.unmodifiableCipherSuites = Collections.unmodifiableList(Arrays.asList(this.cipherSuites));
/* 308 */     this.isClient = isClient;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final SSLContext context() {
/* 315 */     return this.sslContext;
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean isClient() {
/* 320 */     return this.isClient;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final SSLSessionContext sessionContext() {
/* 328 */     if (isServer()) {
/* 329 */       return context().getServerSessionContext();
/*     */     }
/* 331 */     return context().getClientSessionContext();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final List<String> cipherSuites() {
/* 337 */     return this.unmodifiableCipherSuites;
/*     */   }
/*     */ 
/*     */   
/*     */   public final SSLEngine newEngine(ByteBufAllocator alloc) {
/* 342 */     return configureAndWrapEngine(context().createSSLEngine(), alloc);
/*     */   }
/*     */ 
/*     */   
/*     */   public final SSLEngine newEngine(ByteBufAllocator alloc, String peerHost, int peerPort) {
/* 347 */     return configureAndWrapEngine(context().createSSLEngine(peerHost, peerPort), alloc);
/*     */   }
/*     */ 
/*     */   
/*     */   private SSLEngine configureAndWrapEngine(SSLEngine engine, ByteBufAllocator alloc) {
/* 352 */     engine.setEnabledCipherSuites(this.cipherSuites);
/* 353 */     engine.setEnabledProtocols(this.protocols);
/* 354 */     engine.setUseClientMode(isClient());
/* 355 */     if (isServer()) {
/* 356 */       switch (this.clientAuth) {
/*     */         case NONE:
/* 358 */           engine.setWantClientAuth(true);
/*     */           break;
/*     */         case ALPN:
/* 361 */           engine.setNeedClientAuth(true);
/*     */           break;
/*     */         case NPN:
/*     */           break;
/*     */         default:
/* 366 */           throw new Error("Unknown auth " + this.clientAuth);
/*     */       } 
/*     */     }
/* 369 */     JdkApplicationProtocolNegotiator.SslEngineWrapperFactory factory = this.apn.wrapperFactory();
/* 370 */     if (factory instanceof JdkApplicationProtocolNegotiator.AllocatorAwareSslEngineWrapperFactory) {
/* 371 */       return ((JdkApplicationProtocolNegotiator.AllocatorAwareSslEngineWrapperFactory)factory)
/* 372 */         .wrapSslEngine(engine, alloc, this.apn, isServer());
/*     */     }
/* 374 */     return factory.wrapSslEngine(engine, this.apn, isServer());
/*     */   }
/*     */ 
/*     */   
/*     */   public final JdkApplicationProtocolNegotiator applicationProtocolNegotiator() {
/* 379 */     return this.apn;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static JdkApplicationProtocolNegotiator toNegotiator(ApplicationProtocolConfig config, boolean isServer) {
/* 390 */     if (config == null) {
/* 391 */       return JdkDefaultApplicationProtocolNegotiator.INSTANCE;
/*     */     }
/*     */     
/* 394 */     switch (config.protocol()) {
/*     */       case NONE:
/* 396 */         return JdkDefaultApplicationProtocolNegotiator.INSTANCE;
/*     */       case ALPN:
/* 398 */         if (isServer) {
/* 399 */           switch (config.selectorFailureBehavior()) {
/*     */             case NONE:
/* 401 */               return new JdkAlpnApplicationProtocolNegotiator(true, config.supportedProtocols());
/*     */             case ALPN:
/* 403 */               return new JdkAlpnApplicationProtocolNegotiator(false, config.supportedProtocols());
/*     */           } 
/* 405 */           throw new UnsupportedOperationException("JDK provider does not support " + config
/* 406 */               .selectorFailureBehavior() + " failure behavior");
/*     */         } 
/*     */         
/* 409 */         switch (config.selectedListenerFailureBehavior()) {
/*     */           case NONE:
/* 411 */             return new JdkAlpnApplicationProtocolNegotiator(false, config.supportedProtocols());
/*     */           case ALPN:
/* 413 */             return new JdkAlpnApplicationProtocolNegotiator(true, config.supportedProtocols());
/*     */         } 
/* 415 */         throw new UnsupportedOperationException("JDK provider does not support " + config
/* 416 */             .selectedListenerFailureBehavior() + " failure behavior");
/*     */ 
/*     */       
/*     */       case NPN:
/* 420 */         if (isServer) {
/* 421 */           switch (config.selectedListenerFailureBehavior()) {
/*     */             case NONE:
/* 423 */               return new JdkNpnApplicationProtocolNegotiator(false, config.supportedProtocols());
/*     */             case ALPN:
/* 425 */               return new JdkNpnApplicationProtocolNegotiator(true, config.supportedProtocols());
/*     */           } 
/* 427 */           throw new UnsupportedOperationException("JDK provider does not support " + config
/* 428 */               .selectedListenerFailureBehavior() + " failure behavior");
/*     */         } 
/*     */         
/* 431 */         switch (config.selectorFailureBehavior()) {
/*     */           case NONE:
/* 433 */             return new JdkNpnApplicationProtocolNegotiator(true, config.supportedProtocols());
/*     */           case ALPN:
/* 435 */             return new JdkNpnApplicationProtocolNegotiator(false, config.supportedProtocols());
/*     */         } 
/* 437 */         throw new UnsupportedOperationException("JDK provider does not support " + config
/* 438 */             .selectorFailureBehavior() + " failure behavior");
/*     */     } 
/*     */ 
/*     */     
/* 442 */     throw new UnsupportedOperationException("JDK provider does not support " + config
/* 443 */         .protocol() + " protocol");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static KeyManagerFactory buildKeyManagerFactory(File certChainFile, File keyFile, String keyPassword, KeyManagerFactory kmf, String keyStore) throws UnrecoverableKeyException, KeyStoreException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException, CertificateException, KeyException, IOException {
/* 462 */     String algorithm = Security.getProperty("ssl.KeyManagerFactory.algorithm");
/* 463 */     if (algorithm == null) {
/* 464 */       algorithm = "SunX509";
/*     */     }
/* 466 */     return buildKeyManagerFactory(certChainFile, algorithm, keyFile, keyPassword, kmf, keyStore);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected static KeyManagerFactory buildKeyManagerFactory(File certChainFile, File keyFile, String keyPassword, KeyManagerFactory kmf) throws UnrecoverableKeyException, KeyStoreException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException, CertificateException, KeyException, IOException {
/* 485 */     return buildKeyManagerFactory(certChainFile, keyFile, keyPassword, kmf, KeyStore.getDefaultType());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static KeyManagerFactory buildKeyManagerFactory(File certChainFile, String keyAlgorithm, File keyFile, String keyPassword, KeyManagerFactory kmf, String keyStore) throws KeyStoreException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException, IOException, CertificateException, KeyException, UnrecoverableKeyException {
/* 508 */     return buildKeyManagerFactory(toX509Certificates(certChainFile), keyAlgorithm, 
/* 509 */         toPrivateKey(keyFile, keyPassword), keyPassword, kmf, keyStore);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected static KeyManagerFactory buildKeyManagerFactory(File certChainFile, String keyAlgorithm, File keyFile, String keyPassword, KeyManagerFactory kmf) throws KeyStoreException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException, IOException, CertificateException, KeyException, UnrecoverableKeyException {
/* 533 */     return buildKeyManagerFactory(toX509Certificates(certChainFile), keyAlgorithm, 
/* 534 */         toPrivateKey(keyFile, keyPassword), keyPassword, kmf, KeyStore.getDefaultType());
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-handler-4.1.93.Final.jar!\io\netty\handler\ssl\JdkSslContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */