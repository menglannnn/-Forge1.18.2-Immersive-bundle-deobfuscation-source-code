/*     */ package io.netty.handler.ssl.util;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.buffer.Unpooled;
/*     */ import io.netty.handler.codec.base64.Base64;
/*     */ import io.netty.util.CharsetUtil;
/*     */ import io.netty.util.internal.PlatformDependent;
/*     */ import io.netty.util.internal.SystemPropertyUtil;
/*     */ import io.netty.util.internal.ThrowableUtil;
/*     */ import io.netty.util.internal.logging.InternalLogger;
/*     */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.security.KeyPair;
/*     */ import java.security.KeyPairGenerator;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.PrivateKey;
/*     */ import java.security.SecureRandom;
/*     */ import java.security.cert.CertificateEncodingException;
/*     */ import java.security.cert.CertificateException;
/*     */ import java.security.cert.CertificateFactory;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.Date;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SelfSignedCertificate
/*     */ {
/*  63 */   private static final InternalLogger logger = InternalLoggerFactory.getInstance(SelfSignedCertificate.class);
/*     */ 
/*     */   
/*  66 */   private static final Date DEFAULT_NOT_BEFORE = new Date(SystemPropertyUtil.getLong("io.netty.selfSignedCertificate.defaultNotBefore", 
/*  67 */         System.currentTimeMillis() - 31536000000L));
/*     */   
/*  69 */   private static final Date DEFAULT_NOT_AFTER = new Date(SystemPropertyUtil.getLong("io.netty.selfSignedCertificate.defaultNotAfter", 253402300799000L));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  78 */   private static final int DEFAULT_KEY_LENGTH_BITS = SystemPropertyUtil.getInt("io.netty.handler.ssl.util.selfSignedKeyStrength", 2048);
/*     */   
/*     */   private final File certificate;
/*     */   
/*     */   private final File privateKey;
/*     */   
/*     */   private final X509Certificate cert;
/*     */   
/*     */   private final PrivateKey key;
/*     */ 
/*     */   
/*     */   public SelfSignedCertificate() throws CertificateException {
/*  90 */     this(DEFAULT_NOT_BEFORE, DEFAULT_NOT_AFTER, "RSA", DEFAULT_KEY_LENGTH_BITS);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SelfSignedCertificate(Date notBefore, Date notAfter) throws CertificateException {
/* 102 */     this("localhost", notBefore, notAfter, "RSA", DEFAULT_KEY_LENGTH_BITS);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SelfSignedCertificate(Date notBefore, Date notAfter, String algorithm, int bits) throws CertificateException {
/* 115 */     this("localhost", notBefore, notAfter, algorithm, bits);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SelfSignedCertificate(String fqdn) throws CertificateException {
/* 125 */     this(fqdn, DEFAULT_NOT_BEFORE, DEFAULT_NOT_AFTER, "RSA", DEFAULT_KEY_LENGTH_BITS);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SelfSignedCertificate(String fqdn, String algorithm, int bits) throws CertificateException {
/* 136 */     this(fqdn, DEFAULT_NOT_BEFORE, DEFAULT_NOT_AFTER, algorithm, bits);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SelfSignedCertificate(String fqdn, Date notBefore, Date notAfter) throws CertificateException {
/* 150 */     this(fqdn, ThreadLocalInsecureRandom.current(), DEFAULT_KEY_LENGTH_BITS, notBefore, notAfter, "RSA");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SelfSignedCertificate(String fqdn, Date notBefore, Date notAfter, String algorithm, int bits) throws CertificateException {
/* 166 */     this(fqdn, ThreadLocalInsecureRandom.current(), bits, notBefore, notAfter, algorithm);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SelfSignedCertificate(String fqdn, SecureRandom random, int bits) throws CertificateException {
/* 179 */     this(fqdn, random, bits, DEFAULT_NOT_BEFORE, DEFAULT_NOT_AFTER, "RSA");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SelfSignedCertificate(String fqdn, SecureRandom random, String algorithm, int bits) throws CertificateException {
/* 192 */     this(fqdn, random, bits, DEFAULT_NOT_BEFORE, DEFAULT_NOT_AFTER, algorithm);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SelfSignedCertificate(String fqdn, SecureRandom random, int bits, Date notBefore, Date notAfter) throws CertificateException {
/* 207 */     this(fqdn, random, bits, notBefore, notAfter, "RSA");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SelfSignedCertificate(String fqdn, SecureRandom random, int bits, Date notBefore, Date notAfter, String algorithm) throws CertificateException {
/*     */     KeyPair keypair;
/*     */     String[] paths;
/* 223 */     if (!"EC".equalsIgnoreCase(algorithm) && !"RSA".equalsIgnoreCase(algorithm)) {
/* 224 */       throw new IllegalArgumentException("Algorithm not valid: " + algorithm);
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 229 */       KeyPairGenerator keyGen = KeyPairGenerator.getInstance(algorithm);
/* 230 */       keyGen.initialize(bits, random);
/* 231 */       keypair = keyGen.generateKeyPair();
/* 232 */     } catch (NoSuchAlgorithmException e) {
/*     */       
/* 234 */       throw new Error(e);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 240 */       paths = BouncyCastleSelfSignedCertGenerator.generate(fqdn, keypair, random, notBefore, notAfter, algorithm);
/*     */     }
/* 242 */     catch (Throwable t) {
/* 243 */       logger.debug("Failed to generate a self-signed X.509 certificate using Bouncy Castle:", t);
/*     */       
/*     */       try {
/* 246 */         paths = OpenJdkSelfSignedCertGenerator.generate(fqdn, keypair, random, notBefore, notAfter, algorithm);
/* 247 */       } catch (Throwable t2) {
/* 248 */         logger.debug("Failed to generate a self-signed X.509 certificate using sun.security.x509:", t2);
/* 249 */         CertificateException certificateException = new CertificateException("No provider succeeded to generate a self-signed certificate. See debug log for the root cause.", t2);
/*     */ 
/*     */         
/* 252 */         ThrowableUtil.addSuppressed(certificateException, t);
/* 253 */         throw certificateException;
/*     */       } 
/*     */     } 
/*     */     
/* 257 */     this.certificate = new File(paths[0]);
/* 258 */     this.privateKey = new File(paths[1]);
/* 259 */     this.key = keypair.getPrivate();
/* 260 */     FileInputStream certificateInput = null;
/*     */     try {
/* 262 */       certificateInput = new FileInputStream(this.certificate);
/* 263 */       this.cert = (X509Certificate)CertificateFactory.getInstance("X509").generateCertificate(certificateInput);
/* 264 */     } catch (Exception e) {
/* 265 */       throw new CertificateEncodingException(e);
/*     */     } finally {
/* 267 */       if (certificateInput != null) {
/*     */         try {
/* 269 */           certificateInput.close();
/* 270 */         } catch (IOException e) {
/* 271 */           if (logger.isWarnEnabled()) {
/* 272 */             logger.warn("Failed to close a file: " + this.certificate, e);
/*     */           }
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public File certificate() {
/* 283 */     return this.certificate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public File privateKey() {
/* 290 */     return this.privateKey;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public X509Certificate cert() {
/* 297 */     return this.cert;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PrivateKey key() {
/* 304 */     return this.key;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void delete() {
/* 311 */     safeDelete(this.certificate);
/* 312 */     safeDelete(this.privateKey);
/*     */   }
/*     */ 
/*     */   
/*     */   static String[] newSelfSignedCertificate(String fqdn, PrivateKey key, X509Certificate cert) throws IOException, CertificateEncodingException {
/*     */     String keyText, certText;
/* 318 */     ByteBuf wrappedBuf = Unpooled.wrappedBuffer(key.getEncoded());
/*     */ 
/*     */     
/*     */     try {
/* 322 */       ByteBuf encodedBuf = Base64.encode(wrappedBuf, true);
/*     */       
/*     */       try {
/* 325 */         keyText = "-----BEGIN PRIVATE KEY-----\n" + encodedBuf.toString(CharsetUtil.US_ASCII) + "\n-----END PRIVATE KEY-----\n";
/*     */       } finally {
/*     */         
/* 328 */         encodedBuf.release();
/*     */       } 
/*     */     } finally {
/* 331 */       wrappedBuf.release();
/*     */     } 
/*     */ 
/*     */     
/* 335 */     fqdn = fqdn.replaceAll("[^\\w.-]", "x");
/*     */     
/* 337 */     File keyFile = PlatformDependent.createTempFile("keyutil_" + fqdn + '_', ".key", null);
/* 338 */     keyFile.deleteOnExit();
/*     */     
/* 340 */     OutputStream keyOut = new FileOutputStream(keyFile);
/*     */     try {
/* 342 */       keyOut.write(keyText.getBytes(CharsetUtil.US_ASCII));
/* 343 */       keyOut.close();
/* 344 */       keyOut = null;
/*     */     } finally {
/* 346 */       if (keyOut != null) {
/* 347 */         safeClose(keyFile, keyOut);
/* 348 */         safeDelete(keyFile);
/*     */       } 
/*     */     } 
/*     */     
/* 352 */     wrappedBuf = Unpooled.wrappedBuffer(cert.getEncoded());
/*     */     
/*     */     try {
/* 355 */       ByteBuf encodedBuf = Base64.encode(wrappedBuf, true);
/*     */ 
/*     */       
/*     */       try {
/* 359 */         certText = "-----BEGIN CERTIFICATE-----\n" + encodedBuf.toString(CharsetUtil.US_ASCII) + "\n-----END CERTIFICATE-----\n";
/*     */       } finally {
/*     */         
/* 362 */         encodedBuf.release();
/*     */       } 
/*     */     } finally {
/* 365 */       wrappedBuf.release();
/*     */     } 
/*     */     
/* 368 */     File certFile = PlatformDependent.createTempFile("keyutil_" + fqdn + '_', ".crt", null);
/* 369 */     certFile.deleteOnExit();
/*     */     
/* 371 */     OutputStream certOut = new FileOutputStream(certFile);
/*     */     try {
/* 373 */       certOut.write(certText.getBytes(CharsetUtil.US_ASCII));
/* 374 */       certOut.close();
/* 375 */       certOut = null;
/*     */     } finally {
/* 377 */       if (certOut != null) {
/* 378 */         safeClose(certFile, certOut);
/* 379 */         safeDelete(certFile);
/* 380 */         safeDelete(keyFile);
/*     */       } 
/*     */     } 
/*     */     
/* 384 */     return new String[] { certFile.getPath(), keyFile.getPath() };
/*     */   }
/*     */   
/*     */   private static void safeDelete(File certFile) {
/* 388 */     if (!certFile.delete() && 
/* 389 */       logger.isWarnEnabled()) {
/* 390 */       logger.warn("Failed to delete a file: " + certFile);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static void safeClose(File keyFile, OutputStream keyOut) {
/*     */     try {
/* 397 */       keyOut.close();
/* 398 */     } catch (IOException e) {
/* 399 */       if (logger.isWarnEnabled())
/* 400 */         logger.warn("Failed to close a file: " + keyFile, e); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-handler-4.1.93.Final.jar!\io\netty\handler\ss\\util\SelfSignedCertificate.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */