/*     */ package io.netty.handler.ssl;
/*     */ 
/*     */ import io.netty.util.internal.EmptyArrays;
/*     */ import io.netty.util.internal.SuppressJava6Requirement;
/*     */ import java.security.Principal;
/*     */ import java.security.cert.Certificate;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import javax.net.ssl.ExtendedSSLSession;
/*     */ import javax.net.ssl.SSLException;
/*     */ import javax.net.ssl.SSLPeerUnverifiedException;
/*     */ import javax.net.ssl.SSLSessionBindingEvent;
/*     */ import javax.net.ssl.SSLSessionBindingListener;
/*     */ import javax.net.ssl.SSLSessionContext;
/*     */ import javax.security.cert.X509Certificate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @SuppressJava6Requirement(reason = "Usage guarded by java version check")
/*     */ abstract class ExtendedOpenSslSession
/*     */   extends ExtendedSSLSession
/*     */   implements OpenSslSession
/*     */ {
/*  42 */   private static final String[] LOCAL_SUPPORTED_SIGNATURE_ALGORITHMS = new String[] { "SHA512withRSA", "SHA512withECDSA", "SHA384withRSA", "SHA384withECDSA", "SHA256withRSA", "SHA256withECDSA", "SHA224withRSA", "SHA224withECDSA", "SHA1withRSA", "SHA1withECDSA", "RSASSA-PSS" };
/*     */ 
/*     */ 
/*     */   
/*     */   private final OpenSslSession wrapped;
/*     */ 
/*     */ 
/*     */   
/*     */   ExtendedOpenSslSession(OpenSslSession wrapped) {
/*  51 */     this.wrapped = wrapped;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<byte[]> getStatusResponses() {
/*  63 */     return (List)Collections.emptyList();
/*     */   }
/*     */ 
/*     */   
/*     */   public OpenSslSessionId sessionId() {
/*  68 */     return this.wrapped.sessionId();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setSessionId(OpenSslSessionId id) {
/*  73 */     this.wrapped.setSessionId(id);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void setLocalCertificate(Certificate[] localCertificate) {
/*  78 */     this.wrapped.setLocalCertificate(localCertificate);
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getPeerSupportedSignatureAlgorithms() {
/*  83 */     return EmptyArrays.EMPTY_STRINGS;
/*     */   }
/*     */ 
/*     */   
/*     */   public final void tryExpandApplicationBufferSize(int packetLengthDataOnly) {
/*  88 */     this.wrapped.tryExpandApplicationBufferSize(packetLengthDataOnly);
/*     */   }
/*     */ 
/*     */   
/*     */   public final String[] getLocalSupportedSignatureAlgorithms() {
/*  93 */     return (String[])LOCAL_SUPPORTED_SIGNATURE_ALGORITHMS.clone();
/*     */   }
/*     */ 
/*     */   
/*     */   public final byte[] getId() {
/*  98 */     return this.wrapped.getId();
/*     */   }
/*     */ 
/*     */   
/*     */   public final OpenSslSessionContext getSessionContext() {
/* 103 */     return this.wrapped.getSessionContext();
/*     */   }
/*     */ 
/*     */   
/*     */   public final long getCreationTime() {
/* 108 */     return this.wrapped.getCreationTime();
/*     */   }
/*     */ 
/*     */   
/*     */   public final long getLastAccessedTime() {
/* 113 */     return this.wrapped.getLastAccessedTime();
/*     */   }
/*     */ 
/*     */   
/*     */   public final void invalidate() {
/* 118 */     this.wrapped.invalidate();
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean isValid() {
/* 123 */     return this.wrapped.isValid();
/*     */   }
/*     */ 
/*     */   
/*     */   public final void putValue(String name, Object value) {
/* 128 */     if (value instanceof SSLSessionBindingListener)
/*     */     {
/* 130 */       value = new SSLSessionBindingListenerDecorator((SSLSessionBindingListener)value);
/*     */     }
/* 132 */     this.wrapped.putValue(name, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public final Object getValue(String s) {
/* 137 */     Object value = this.wrapped.getValue(s);
/* 138 */     if (value instanceof SSLSessionBindingListenerDecorator)
/*     */     {
/* 140 */       return ((SSLSessionBindingListenerDecorator)value).delegate;
/*     */     }
/* 142 */     return value;
/*     */   }
/*     */ 
/*     */   
/*     */   public final void removeValue(String s) {
/* 147 */     this.wrapped.removeValue(s);
/*     */   }
/*     */ 
/*     */   
/*     */   public final String[] getValueNames() {
/* 152 */     return this.wrapped.getValueNames();
/*     */   }
/*     */ 
/*     */   
/*     */   public final Certificate[] getPeerCertificates() throws SSLPeerUnverifiedException {
/* 157 */     return this.wrapped.getPeerCertificates();
/*     */   }
/*     */ 
/*     */   
/*     */   public final Certificate[] getLocalCertificates() {
/* 162 */     return this.wrapped.getLocalCertificates();
/*     */   }
/*     */ 
/*     */   
/*     */   public final X509Certificate[] getPeerCertificateChain() throws SSLPeerUnverifiedException {
/* 167 */     return this.wrapped.getPeerCertificateChain();
/*     */   }
/*     */ 
/*     */   
/*     */   public final Principal getPeerPrincipal() throws SSLPeerUnverifiedException {
/* 172 */     return this.wrapped.getPeerPrincipal();
/*     */   }
/*     */ 
/*     */   
/*     */   public final Principal getLocalPrincipal() {
/* 177 */     return this.wrapped.getLocalPrincipal();
/*     */   }
/*     */ 
/*     */   
/*     */   public final String getCipherSuite() {
/* 182 */     return this.wrapped.getCipherSuite();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getProtocol() {
/* 187 */     return this.wrapped.getProtocol();
/*     */   }
/*     */ 
/*     */   
/*     */   public final String getPeerHost() {
/* 192 */     return this.wrapped.getPeerHost();
/*     */   }
/*     */ 
/*     */   
/*     */   public final int getPeerPort() {
/* 197 */     return this.wrapped.getPeerPort();
/*     */   }
/*     */ 
/*     */   
/*     */   public final int getPacketBufferSize() {
/* 202 */     return this.wrapped.getPacketBufferSize();
/*     */   }
/*     */ 
/*     */   
/*     */   public final int getApplicationBufferSize() {
/* 207 */     return this.wrapped.getApplicationBufferSize();
/*     */   }
/*     */   
/*     */   private final class SSLSessionBindingListenerDecorator
/*     */     implements SSLSessionBindingListener {
/*     */     final SSLSessionBindingListener delegate;
/*     */     
/*     */     SSLSessionBindingListenerDecorator(SSLSessionBindingListener delegate) {
/* 215 */       this.delegate = delegate;
/*     */     }
/*     */ 
/*     */     
/*     */     public void valueBound(SSLSessionBindingEvent event) {
/* 220 */       this.delegate.valueBound(new SSLSessionBindingEvent(ExtendedOpenSslSession.this, event.getName()));
/*     */     }
/*     */ 
/*     */     
/*     */     public void valueUnbound(SSLSessionBindingEvent event) {
/* 225 */       this.delegate.valueUnbound(new SSLSessionBindingEvent(ExtendedOpenSslSession.this, event.getName()));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void handshakeFinished(byte[] id, String cipher, String protocol, byte[] peerCertificate, byte[][] peerCertificateChain, long creationTime, long timeout) throws SSLException {
/* 232 */     this.wrapped.handshakeFinished(id, cipher, protocol, peerCertificate, peerCertificateChain, creationTime, timeout);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 237 */     return "ExtendedOpenSslSession{wrapped=" + this.wrapped + '}';
/*     */   }
/*     */   
/*     */   public abstract List getRequestedServerNames();
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-handler-4.1.93.Final.jar!\io\netty\handler\ssl\ExtendedOpenSslSession.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */