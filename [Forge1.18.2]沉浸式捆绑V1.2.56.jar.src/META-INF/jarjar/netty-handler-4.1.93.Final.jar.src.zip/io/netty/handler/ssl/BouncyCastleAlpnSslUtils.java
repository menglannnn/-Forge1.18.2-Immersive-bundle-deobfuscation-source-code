/*     */ package io.netty.handler.ssl;
/*     */ 
/*     */ import io.netty.util.internal.EmptyArrays;
/*     */ import io.netty.util.internal.PlatformDependent;
/*     */ import io.netty.util.internal.SuppressJava6Requirement;
/*     */ import io.netty.util.internal.logging.InternalLogger;
/*     */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.util.List;
/*     */ import java.util.function.BiFunction;
/*     */ import javax.net.ssl.SSLContext;
/*     */ import javax.net.ssl.SSLEngine;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @SuppressJava6Requirement(reason = "Usage guarded by java version check")
/*     */ final class BouncyCastleAlpnSslUtils
/*     */ {
/*     */   static {
/*     */     Method getParameters, setParameters, setApplicationProtocols, getApplicationProtocol, getHandshakeApplicationProtocol, setHandshakeApplicationProtocolSelector, getHandshakeApplicationProtocolSelector, bcApplicationProtocolSelectorSelect;
/*     */     Class bcApplicationProtocolSelector;
/*     */   }
/*     */   
/*  39 */   private static final InternalLogger logger = InternalLoggerFactory.getInstance(BouncyCastleAlpnSslUtils.class);
/*     */ 
/*     */   
/*     */   private static final Method SET_PARAMETERS;
/*     */   
/*     */   private static final Method GET_PARAMETERS;
/*     */   
/*     */   private static final Method SET_APPLICATION_PROTOCOLS;
/*     */   
/*     */   private static final Method GET_APPLICATION_PROTOCOL;
/*     */   
/*     */   private static final Method GET_HANDSHAKE_APPLICATION_PROTOCOL;
/*     */   
/*     */   private static final Method SET_HANDSHAKE_APPLICATION_PROTOCOL_SELECTOR;
/*     */   
/*     */   private static final Method GET_HANDSHAKE_APPLICATION_PROTOCOL_SELECTOR;
/*     */   
/*     */   private static final Class BC_APPLICATION_PROTOCOL_SELECTOR;
/*     */   
/*     */   private static final Method BC_APPLICATION_PROTOCOL_SELECTOR_SELECT;
/*     */ 
/*     */   
/*     */   static {
/*     */     try {
/*  63 */       Class<?> bcSslEngine = Class.forName("org.bouncycastle.jsse.BCSSLEngine");
/*  64 */       final Class<?> testBCSslEngine = bcSslEngine;
/*     */ 
/*     */       
/*  67 */       bcApplicationProtocolSelector = Class.forName("org.bouncycastle.jsse.BCApplicationProtocolSelector");
/*     */       
/*  69 */       final Class<?> testBCApplicationProtocolSelector = bcApplicationProtocolSelector;
/*     */       
/*  71 */       bcApplicationProtocolSelectorSelect = AccessController.<Method>doPrivileged(new PrivilegedExceptionAction<Method>()
/*     */           {
/*     */             public Method run() throws Exception
/*     */             {
/*  75 */               return testBCApplicationProtocolSelector.getMethod("select", new Class[] { Object.class, List.class });
/*     */             }
/*     */           });
/*     */       
/*  79 */       SSLContext context = SslUtils.getSSLContext("BCJSSE");
/*  80 */       SSLEngine engine = context.createSSLEngine();
/*     */       
/*  82 */       getParameters = AccessController.<Method>doPrivileged(new PrivilegedExceptionAction<Method>()
/*     */           {
/*     */             public Method run() throws Exception {
/*  85 */               return testBCSslEngine.getMethod("getParameters", new Class[0]);
/*     */             }
/*     */           });
/*     */       
/*  89 */       Object bcSslParameters = getParameters.invoke(engine, new Object[0]);
/*  90 */       final Class<?> bCSslParametersClass = bcSslParameters.getClass();
/*     */       
/*  92 */       setParameters = AccessController.<Method>doPrivileged(new PrivilegedExceptionAction<Method>()
/*     */           {
/*     */             public Method run() throws Exception {
/*  95 */               return testBCSslEngine.getMethod("setParameters", new Class[] { this.val$bCSslParametersClass });
/*     */             }
/*     */           });
/*  98 */       setParameters.invoke(engine, new Object[] { bcSslParameters });
/*     */       
/* 100 */       setApplicationProtocols = AccessController.<Method>doPrivileged(new PrivilegedExceptionAction<Method>()
/*     */           {
/*     */             public Method run() throws Exception {
/* 103 */               return bCSslParametersClass.getMethod("setApplicationProtocols", new Class[] { String[].class });
/*     */             }
/*     */           });
/* 106 */       setApplicationProtocols.invoke(bcSslParameters, new Object[] { EmptyArrays.EMPTY_STRINGS });
/*     */       
/* 108 */       getApplicationProtocol = AccessController.<Method>doPrivileged(new PrivilegedExceptionAction<Method>()
/*     */           {
/*     */             public Method run() throws Exception {
/* 111 */               return testBCSslEngine.getMethod("getApplicationProtocol", new Class[0]);
/*     */             }
/*     */           });
/* 114 */       getApplicationProtocol.invoke(engine, new Object[0]);
/*     */       
/* 116 */       getHandshakeApplicationProtocol = AccessController.<Method>doPrivileged(new PrivilegedExceptionAction<Method>()
/*     */           {
/*     */             public Method run() throws Exception {
/* 119 */               return testBCSslEngine.getMethod("getHandshakeApplicationProtocol", new Class[0]);
/*     */             }
/*     */           });
/* 122 */       getHandshakeApplicationProtocol.invoke(engine, new Object[0]);
/*     */ 
/*     */       
/* 125 */       setHandshakeApplicationProtocolSelector = AccessController.<Method>doPrivileged(new PrivilegedExceptionAction<Method>()
/*     */           {
/*     */             public Method run() throws Exception {
/* 128 */               return testBCSslEngine.getMethod("setBCHandshakeApplicationProtocolSelector", new Class[] { this.val$testBCApplicationProtocolSelector });
/*     */             }
/*     */           });
/*     */ 
/*     */ 
/*     */       
/* 134 */       getHandshakeApplicationProtocolSelector = AccessController.<Method>doPrivileged(new PrivilegedExceptionAction<Method>()
/*     */           {
/*     */             public Method run() throws Exception {
/* 137 */               return testBCSslEngine.getMethod("getBCHandshakeApplicationProtocolSelector", new Class[0]);
/*     */             }
/*     */           });
/* 140 */       getHandshakeApplicationProtocolSelector.invoke(engine, new Object[0]);
/*     */     }
/* 142 */     catch (Throwable t) {
/* 143 */       logger.error("Unable to initialize BouncyCastleAlpnSslUtils.", t);
/* 144 */       setParameters = null;
/* 145 */       getParameters = null;
/* 146 */       setApplicationProtocols = null;
/* 147 */       getApplicationProtocol = null;
/* 148 */       getHandshakeApplicationProtocol = null;
/* 149 */       setHandshakeApplicationProtocolSelector = null;
/* 150 */       getHandshakeApplicationProtocolSelector = null;
/* 151 */       bcApplicationProtocolSelectorSelect = null;
/* 152 */       bcApplicationProtocolSelector = null;
/*     */     } 
/* 154 */     SET_PARAMETERS = setParameters;
/* 155 */     GET_PARAMETERS = getParameters;
/* 156 */     SET_APPLICATION_PROTOCOLS = setApplicationProtocols;
/* 157 */     GET_APPLICATION_PROTOCOL = getApplicationProtocol;
/* 158 */     GET_HANDSHAKE_APPLICATION_PROTOCOL = getHandshakeApplicationProtocol;
/* 159 */     SET_HANDSHAKE_APPLICATION_PROTOCOL_SELECTOR = setHandshakeApplicationProtocolSelector;
/* 160 */     GET_HANDSHAKE_APPLICATION_PROTOCOL_SELECTOR = getHandshakeApplicationProtocolSelector;
/* 161 */     BC_APPLICATION_PROTOCOL_SELECTOR_SELECT = bcApplicationProtocolSelectorSelect;
/* 162 */     BC_APPLICATION_PROTOCOL_SELECTOR = bcApplicationProtocolSelector;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String getApplicationProtocol(SSLEngine sslEngine) {
/*     */     try {
/* 170 */       return (String)GET_APPLICATION_PROTOCOL.invoke(sslEngine, new Object[0]);
/* 171 */     } catch (UnsupportedOperationException ex) {
/* 172 */       throw ex;
/* 173 */     } catch (Exception ex) {
/* 174 */       throw new IllegalStateException(ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   static void setApplicationProtocols(SSLEngine engine, List<String> supportedProtocols) {
/* 179 */     String[] protocolArray = supportedProtocols.<String>toArray(EmptyArrays.EMPTY_STRINGS);
/*     */     try {
/* 181 */       Object bcSslParameters = GET_PARAMETERS.invoke(engine, new Object[0]);
/* 182 */       SET_APPLICATION_PROTOCOLS.invoke(bcSslParameters, new Object[] { protocolArray });
/* 183 */       SET_PARAMETERS.invoke(engine, new Object[] { bcSslParameters });
/* 184 */     } catch (UnsupportedOperationException ex) {
/* 185 */       throw ex;
/* 186 */     } catch (Exception ex) {
/* 187 */       throw new IllegalStateException(ex);
/*     */     } 
/* 189 */     if (PlatformDependent.javaVersion() >= 9) {
/* 190 */       JdkAlpnSslUtils.setApplicationProtocols(engine, supportedProtocols);
/*     */     }
/*     */   }
/*     */   
/*     */   static String getHandshakeApplicationProtocol(SSLEngine sslEngine) {
/*     */     try {
/* 196 */       return (String)GET_HANDSHAKE_APPLICATION_PROTOCOL.invoke(sslEngine, new Object[0]);
/* 197 */     } catch (UnsupportedOperationException ex) {
/* 198 */       throw ex;
/* 199 */     } catch (Exception ex) {
/* 200 */       throw new IllegalStateException(ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   static void setHandshakeApplicationProtocolSelector(SSLEngine engine, final BiFunction<SSLEngine, List<String>, String> selector) {
/*     */     try {
/* 207 */       Object selectorProxyInstance = Proxy.newProxyInstance(BouncyCastleAlpnSslUtils.class
/* 208 */           .getClassLoader(), new Class[] { BC_APPLICATION_PROTOCOL_SELECTOR }, new InvocationHandler()
/*     */           {
/*     */             
/*     */             public Object invoke(Object proxy, Method method, Object[] args) throws Throwable
/*     */             {
/* 213 */               if (method.getName().equals("select")) {
/*     */                 try {
/* 215 */                   return selector.apply(args[0], args[1]);
/* 216 */                 } catch (ClassCastException e) {
/* 217 */                   throw new RuntimeException("BCApplicationProtocolSelector select method parameter of invalid type.", e);
/*     */                 } 
/*     */               }
/*     */               
/* 221 */               throw new UnsupportedOperationException(String.format("Method '%s' not supported.", new Object[] { method
/* 222 */                       .getName() }));
/*     */             }
/*     */           });
/*     */ 
/*     */       
/* 227 */       SET_HANDSHAKE_APPLICATION_PROTOCOL_SELECTOR.invoke(engine, new Object[] { selectorProxyInstance });
/* 228 */     } catch (UnsupportedOperationException ex) {
/* 229 */       throw ex;
/* 230 */     } catch (Exception ex) {
/* 231 */       throw new IllegalStateException(ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   static BiFunction<SSLEngine, List<String>, String> getHandshakeApplicationProtocolSelector(SSLEngine engine) {
/*     */     try {
/* 238 */       final Object selector = GET_HANDSHAKE_APPLICATION_PROTOCOL_SELECTOR.invoke(engine, new Object[0]);
/* 239 */       return new BiFunction<SSLEngine, List<String>, String>()
/*     */         {
/*     */           public String apply(SSLEngine sslEngine, List<String> strings)
/*     */           {
/*     */             try {
/* 244 */               return (String)BouncyCastleAlpnSslUtils.BC_APPLICATION_PROTOCOL_SELECTOR_SELECT.invoke(selector, new Object[] { sslEngine, strings });
/*     */             }
/* 246 */             catch (Exception e) {
/* 247 */               throw new RuntimeException("Could not call getHandshakeApplicationProtocolSelector", e);
/*     */             }
/*     */           
/*     */           }
/*     */         };
/* 252 */     } catch (UnsupportedOperationException ex) {
/* 253 */       throw ex;
/* 254 */     } catch (Exception ex) {
/* 255 */       throw new IllegalStateException(ex);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-handler-4.1.93.Final.jar!\io\netty\handler\ssl\BouncyCastleAlpnSslUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */