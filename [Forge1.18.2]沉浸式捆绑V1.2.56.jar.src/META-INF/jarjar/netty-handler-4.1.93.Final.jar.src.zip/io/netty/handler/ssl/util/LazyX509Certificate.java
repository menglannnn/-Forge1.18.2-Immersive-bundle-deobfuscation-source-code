/*     */ package io.netty.handler.ssl.util;
/*     */ 
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import io.netty.util.internal.SuppressJava6Requirement;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.math.BigInteger;
/*     */ import java.security.InvalidKeyException;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.NoSuchProviderException;
/*     */ import java.security.Principal;
/*     */ import java.security.Provider;
/*     */ import java.security.PublicKey;
/*     */ import java.security.SignatureException;
/*     */ import java.security.cert.CertificateEncodingException;
/*     */ import java.security.cert.CertificateException;
/*     */ import java.security.cert.CertificateExpiredException;
/*     */ import java.security.cert.CertificateFactory;
/*     */ import java.security.cert.CertificateNotYetValidException;
/*     */ import java.security.cert.CertificateParsingException;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.Collection;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javax.security.auth.x500.X500Principal;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class LazyX509Certificate
/*     */   extends X509Certificate
/*     */ {
/*     */   static final CertificateFactory X509_CERT_FACTORY;
/*     */   private final byte[] bytes;
/*     */   private X509Certificate wrapped;
/*     */   
/*     */   static {
/*     */     try {
/*  48 */       X509_CERT_FACTORY = CertificateFactory.getInstance("X.509");
/*  49 */     } catch (CertificateException e) {
/*  50 */       throw new ExceptionInInitializerError(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LazyX509Certificate(byte[] bytes) {
/*  61 */     this.bytes = (byte[])ObjectUtil.checkNotNull(bytes, "bytes");
/*     */   }
/*     */ 
/*     */   
/*     */   public void checkValidity() throws CertificateExpiredException, CertificateNotYetValidException {
/*  66 */     unwrap().checkValidity();
/*     */   }
/*     */ 
/*     */   
/*     */   public void checkValidity(Date date) throws CertificateExpiredException, CertificateNotYetValidException {
/*  71 */     unwrap().checkValidity(date);
/*     */   }
/*     */ 
/*     */   
/*     */   public X500Principal getIssuerX500Principal() {
/*  76 */     return unwrap().getIssuerX500Principal();
/*     */   }
/*     */ 
/*     */   
/*     */   public X500Principal getSubjectX500Principal() {
/*  81 */     return unwrap().getSubjectX500Principal();
/*     */   }
/*     */ 
/*     */   
/*     */   public List<String> getExtendedKeyUsage() throws CertificateParsingException {
/*  86 */     return unwrap().getExtendedKeyUsage();
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<List<?>> getSubjectAlternativeNames() throws CertificateParsingException {
/*  91 */     return unwrap().getSubjectAlternativeNames();
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<List<?>> getIssuerAlternativeNames() throws CertificateParsingException {
/*  96 */     return unwrap().getSubjectAlternativeNames();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SuppressJava6Requirement(reason = "Can only be called from Java8 as class is package-private")
/*     */   public void verify(PublicKey key, Provider sigProvider) throws CertificateException, NoSuchAlgorithmException, InvalidKeyException, SignatureException {
/* 103 */     unwrap().verify(key, sigProvider);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getVersion() {
/* 108 */     return unwrap().getVersion();
/*     */   }
/*     */ 
/*     */   
/*     */   public BigInteger getSerialNumber() {
/* 113 */     return unwrap().getSerialNumber();
/*     */   }
/*     */ 
/*     */   
/*     */   public Principal getIssuerDN() {
/* 118 */     return unwrap().getIssuerDN();
/*     */   }
/*     */ 
/*     */   
/*     */   public Principal getSubjectDN() {
/* 123 */     return unwrap().getSubjectDN();
/*     */   }
/*     */ 
/*     */   
/*     */   public Date getNotBefore() {
/* 128 */     return unwrap().getNotBefore();
/*     */   }
/*     */ 
/*     */   
/*     */   public Date getNotAfter() {
/* 133 */     return unwrap().getNotAfter();
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] getTBSCertificate() throws CertificateEncodingException {
/* 138 */     return unwrap().getTBSCertificate();
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] getSignature() {
/* 143 */     return unwrap().getSignature();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getSigAlgName() {
/* 148 */     return unwrap().getSigAlgName();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getSigAlgOID() {
/* 153 */     return unwrap().getSigAlgOID();
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] getSigAlgParams() {
/* 158 */     return unwrap().getSigAlgParams();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean[] getIssuerUniqueID() {
/* 163 */     return unwrap().getIssuerUniqueID();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean[] getSubjectUniqueID() {
/* 168 */     return unwrap().getSubjectUniqueID();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean[] getKeyUsage() {
/* 173 */     return unwrap().getKeyUsage();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getBasicConstraints() {
/* 178 */     return unwrap().getBasicConstraints();
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] getEncoded() {
/* 183 */     return (byte[])this.bytes.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void verify(PublicKey key) throws CertificateException, NoSuchAlgorithmException, InvalidKeyException, NoSuchProviderException, SignatureException {
/* 190 */     unwrap().verify(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void verify(PublicKey key, String sigProvider) throws CertificateException, NoSuchAlgorithmException, InvalidKeyException, NoSuchProviderException, SignatureException {
/* 197 */     unwrap().verify(key, sigProvider);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 202 */     return unwrap().toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public PublicKey getPublicKey() {
/* 207 */     return unwrap().getPublicKey();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasUnsupportedCriticalExtension() {
/* 212 */     return unwrap().hasUnsupportedCriticalExtension();
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<String> getCriticalExtensionOIDs() {
/* 217 */     return unwrap().getCriticalExtensionOIDs();
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<String> getNonCriticalExtensionOIDs() {
/* 222 */     return unwrap().getNonCriticalExtensionOIDs();
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] getExtensionValue(String oid) {
/* 227 */     return unwrap().getExtensionValue(oid);
/*     */   }
/*     */   
/*     */   private X509Certificate unwrap() {
/* 231 */     X509Certificate wrapped = this.wrapped;
/* 232 */     if (wrapped == null) {
/*     */       try {
/* 234 */         wrapped = this.wrapped = (X509Certificate)X509_CERT_FACTORY.generateCertificate(new ByteArrayInputStream(this.bytes));
/*     */       }
/* 236 */       catch (CertificateException e) {
/* 237 */         throw new IllegalStateException(e);
/*     */       } 
/*     */     }
/* 240 */     return wrapped;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-handler-4.1.93.Final.jar!\io\netty\handler\ss\\util\LazyX509Certificate.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */