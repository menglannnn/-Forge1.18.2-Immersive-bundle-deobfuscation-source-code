/*    */ package io.netty.handler.ssl.util;
/*    */ 
/*    */ import io.netty.util.internal.ObjectUtil;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class FingerprintTrustManagerFactoryBuilder
/*    */ {
/*    */   private final String algorithm;
/* 39 */   private final List<String> fingerprints = new ArrayList<String>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   FingerprintTrustManagerFactoryBuilder(String algorithm) {
/* 47 */     this.algorithm = (String)ObjectUtil.checkNotNull(algorithm, "algorithm");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public FingerprintTrustManagerFactoryBuilder fingerprints(CharSequence... fingerprints) {
/* 57 */     return fingerprints(Arrays.asList((Object[])ObjectUtil.checkNotNull(fingerprints, "fingerprints")));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public FingerprintTrustManagerFactoryBuilder fingerprints(Iterable<? extends CharSequence> fingerprints) {
/* 67 */     ObjectUtil.checkNotNull(fingerprints, "fingerprints");
/* 68 */     for (CharSequence fingerprint : fingerprints) {
/* 69 */       ObjectUtil.checkNotNullWithIAE(fingerprint, "fingerprint");
/* 70 */       this.fingerprints.add(fingerprint.toString());
/*    */     } 
/* 72 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public FingerprintTrustManagerFactory build() {
/* 81 */     if (this.fingerprints.isEmpty()) {
/* 82 */       throw new IllegalStateException("No fingerprints provided");
/*    */     }
/* 84 */     return new FingerprintTrustManagerFactory(this.algorithm, 
/* 85 */         FingerprintTrustManagerFactory.toFingerprintArray(this.fingerprints));
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-handler-4.1.93.Final.jar!\io\netty\handler\ss\\util\FingerprintTrustManagerFactoryBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */