/*      */ package io.netty.handler.ssl;
/*      */ 
/*      */ import io.netty.buffer.ByteBuf;
/*      */ import io.netty.buffer.ByteBufAllocator;
/*      */ import io.netty.handler.ssl.util.LazyX509Certificate;
/*      */ import io.netty.internal.tcnative.AsyncSSLPrivateKeyMethod;
/*      */ import io.netty.internal.tcnative.CertificateCompressionAlgo;
/*      */ import io.netty.internal.tcnative.CertificateVerifier;
/*      */ import io.netty.internal.tcnative.ResultCallback;
/*      */ import io.netty.internal.tcnative.SSL;
/*      */ import io.netty.internal.tcnative.SSLContext;
/*      */ import io.netty.internal.tcnative.SSLPrivateKeyMethod;
/*      */ import io.netty.util.AbstractReferenceCounted;
/*      */ import io.netty.util.ReferenceCounted;
/*      */ import io.netty.util.ResourceLeakDetector;
/*      */ import io.netty.util.ResourceLeakDetectorFactory;
/*      */ import io.netty.util.ResourceLeakTracker;
/*      */ import io.netty.util.concurrent.Future;
/*      */ import io.netty.util.concurrent.FutureListener;
/*      */ import io.netty.util.concurrent.GenericFutureListener;
/*      */ import io.netty.util.internal.ObjectUtil;
/*      */ import io.netty.util.internal.PlatformDependent;
/*      */ import io.netty.util.internal.StringUtil;
/*      */ import io.netty.util.internal.SuppressJava6Requirement;
/*      */ import io.netty.util.internal.SystemPropertyUtil;
/*      */ import io.netty.util.internal.logging.InternalLogger;
/*      */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*      */ import java.security.PrivateKey;
/*      */ import java.security.SignatureException;
/*      */ import java.security.cert.CertPathValidatorException;
/*      */ import java.security.cert.Certificate;
/*      */ import java.security.cert.X509Certificate;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.concurrent.Executor;
/*      */ import java.util.concurrent.locks.Lock;
/*      */ import java.util.concurrent.locks.ReadWriteLock;
/*      */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*      */ import javax.net.ssl.KeyManager;
/*      */ import javax.net.ssl.KeyManagerFactory;
/*      */ import javax.net.ssl.SSLEngine;
/*      */ import javax.net.ssl.SSLException;
/*      */ import javax.net.ssl.SSLSessionContext;
/*      */ import javax.net.ssl.TrustManager;
/*      */ import javax.net.ssl.X509KeyManager;
/*      */ import javax.net.ssl.X509TrustManager;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class ReferenceCountedOpenSslContext
/*      */   extends SslContext
/*      */   implements ReferenceCounted
/*      */ {
/*   88 */   private static final InternalLogger logger = InternalLoggerFactory.getInstance(ReferenceCountedOpenSslContext.class);
/*      */   
/*   90 */   private static final int DEFAULT_BIO_NON_APPLICATION_BUFFER_SIZE = Math.max(1, 
/*   91 */       SystemPropertyUtil.getInt("io.netty.handler.ssl.openssl.bioNonApplicationBufferSize", 2048));
/*      */ 
/*      */ 
/*      */   
/*   95 */   static final boolean USE_TASKS = SystemPropertyUtil.getBoolean("io.netty.handler.ssl.openssl.useTasks", true);
/*      */   
/*      */   private static final Integer DH_KEY_LENGTH;
/*   98 */   private static final ResourceLeakDetector<ReferenceCountedOpenSslContext> leakDetector = ResourceLeakDetectorFactory.instance().newResourceLeakDetector(ReferenceCountedOpenSslContext.class);
/*      */ 
/*      */   
/*      */   protected static final int VERIFY_DEPTH = 10;
/*      */ 
/*      */   
/*  104 */   static final boolean CLIENT_ENABLE_SESSION_TICKET = SystemPropertyUtil.getBoolean("jdk.tls.client.enableSessionTicketExtension", false);
/*      */ 
/*      */   
/*  107 */   static final boolean CLIENT_ENABLE_SESSION_TICKET_TLSV13 = SystemPropertyUtil.getBoolean("jdk.tls.client.enableSessionTicketExtension", true);
/*      */ 
/*      */   
/*  110 */   static final boolean SERVER_ENABLE_SESSION_TICKET = SystemPropertyUtil.getBoolean("jdk.tls.server.enableSessionTicketExtension", false);
/*      */ 
/*      */   
/*  113 */   static final boolean SERVER_ENABLE_SESSION_TICKET_TLSV13 = SystemPropertyUtil.getBoolean("jdk.tls.server.enableSessionTicketExtension", true);
/*      */ 
/*      */   
/*  116 */   static final boolean SERVER_ENABLE_SESSION_CACHE = SystemPropertyUtil.getBoolean("io.netty.handler.ssl.openssl.sessionCacheServer", true);
/*      */ 
/*      */ 
/*      */   
/*  120 */   static final boolean CLIENT_ENABLE_SESSION_CACHE = SystemPropertyUtil.getBoolean("io.netty.handler.ssl.openssl.sessionCacheClient", false);
/*      */ 
/*      */   
/*      */   protected long ctx;
/*      */   
/*      */   private final List<String> unmodifiableCiphers;
/*      */   
/*      */   private final OpenSslApplicationProtocolNegotiator apn;
/*      */   
/*      */   private final int mode;
/*      */   
/*      */   private final ResourceLeakTracker<ReferenceCountedOpenSslContext> leak;
/*      */ 
/*      */   
/*  134 */   private final AbstractReferenceCounted refCnt = new AbstractReferenceCounted()
/*      */     {
/*      */       public ReferenceCounted touch(Object hint) {
/*  137 */         if (ReferenceCountedOpenSslContext.this.leak != null) {
/*  138 */           ReferenceCountedOpenSslContext.this.leak.record(hint);
/*      */         }
/*      */         
/*  141 */         return ReferenceCountedOpenSslContext.this;
/*      */       }
/*      */ 
/*      */       
/*      */       protected void deallocate() {
/*  146 */         ReferenceCountedOpenSslContext.this.destroy();
/*  147 */         if (ReferenceCountedOpenSslContext.this.leak != null) {
/*  148 */           boolean closed = ReferenceCountedOpenSslContext.this.leak.close(ReferenceCountedOpenSslContext.this);
/*  149 */           assert closed;
/*      */         } 
/*      */       }
/*      */     };
/*      */   
/*      */   final Certificate[] keyCertChain;
/*      */   final ClientAuth clientAuth;
/*      */   final String[] protocols;
/*      */   final boolean enableOcsp;
/*  158 */   final OpenSslEngineMap engineMap = new DefaultOpenSslEngineMap();
/*  159 */   final ReadWriteLock ctxLock = new ReentrantReadWriteLock();
/*      */   
/*  161 */   private volatile int bioNonApplicationBufferSize = DEFAULT_BIO_NON_APPLICATION_BUFFER_SIZE;
/*      */ 
/*      */   
/*  164 */   static final OpenSslApplicationProtocolNegotiator NONE_PROTOCOL_NEGOTIATOR = new OpenSslApplicationProtocolNegotiator()
/*      */     {
/*      */       public ApplicationProtocolConfig.Protocol protocol()
/*      */       {
/*  168 */         return ApplicationProtocolConfig.Protocol.NONE;
/*      */       }
/*      */ 
/*      */       
/*      */       public List<String> protocols() {
/*  173 */         return Collections.emptyList();
/*      */       }
/*      */ 
/*      */       
/*      */       public ApplicationProtocolConfig.SelectorFailureBehavior selectorFailureBehavior() {
/*  178 */         return ApplicationProtocolConfig.SelectorFailureBehavior.CHOOSE_MY_LAST_PROTOCOL;
/*      */       }
/*      */ 
/*      */       
/*      */       public ApplicationProtocolConfig.SelectedListenerFailureBehavior selectedListenerFailureBehavior() {
/*  183 */         return ApplicationProtocolConfig.SelectedListenerFailureBehavior.ACCEPT;
/*      */       }
/*      */     };
/*      */   
/*      */   static {
/*  188 */     Integer dhLen = null;
/*      */     
/*      */     try {
/*  191 */       String dhKeySize = SystemPropertyUtil.get("jdk.tls.ephemeralDHKeySize");
/*  192 */       if (dhKeySize != null) {
/*      */         try {
/*  194 */           dhLen = Integer.valueOf(dhKeySize);
/*  195 */         } catch (NumberFormatException e) {
/*  196 */           logger.debug("ReferenceCountedOpenSslContext supports -Djdk.tls.ephemeralDHKeySize={int}, but got: " + dhKeySize);
/*      */         }
/*      */       
/*      */       }
/*  200 */     } catch (Throwable throwable) {}
/*      */ 
/*      */     
/*  203 */     DH_KEY_LENGTH = dhLen;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   final boolean tlsFalseStart;
/*      */ 
/*      */ 
/*      */   
/*      */   ReferenceCountedOpenSslContext(Iterable<String> ciphers, CipherSuiteFilter cipherFilter, OpenSslApplicationProtocolNegotiator apn, int mode, Certificate[] keyCertChain, ClientAuth clientAuth, String[] protocols, boolean startTls, boolean enableOcsp, boolean leakDetection, Map.Entry<SslContextOption<?>, Object>... ctxOptions) throws SSLException {
/*  213 */     super(startTls);
/*      */     
/*  215 */     OpenSsl.ensureAvailability();
/*      */     
/*  217 */     if (enableOcsp && !OpenSsl.isOcspSupported()) {
/*  218 */       throw new IllegalStateException("OCSP is not supported.");
/*      */     }
/*      */     
/*  221 */     if (mode != 1 && mode != 0) {
/*  222 */       throw new IllegalArgumentException("mode most be either SSL.SSL_MODE_SERVER or SSL.SSL_MODE_CLIENT");
/*      */     }
/*      */     
/*  225 */     boolean tlsFalseStart = false;
/*  226 */     boolean useTasks = USE_TASKS;
/*  227 */     OpenSslPrivateKeyMethod privateKeyMethod = null;
/*  228 */     OpenSslAsyncPrivateKeyMethod asyncPrivateKeyMethod = null;
/*  229 */     OpenSslCertificateCompressionConfig certCompressionConfig = null;
/*  230 */     Integer maxCertificateList = null;
/*      */     
/*  232 */     if (ctxOptions != null) {
/*  233 */       for (Map.Entry<SslContextOption<?>, Object> ctxOpt : ctxOptions) {
/*  234 */         SslContextOption<?> option = ctxOpt.getKey();
/*      */         
/*  236 */         if (option == OpenSslContextOption.TLS_FALSE_START) {
/*  237 */           tlsFalseStart = ((Boolean)ctxOpt.getValue()).booleanValue();
/*  238 */         } else if (option == OpenSslContextOption.USE_TASKS) {
/*  239 */           useTasks = ((Boolean)ctxOpt.getValue()).booleanValue();
/*  240 */         } else if (option == OpenSslContextOption.PRIVATE_KEY_METHOD) {
/*  241 */           privateKeyMethod = (OpenSslPrivateKeyMethod)ctxOpt.getValue();
/*  242 */         } else if (option == OpenSslContextOption.ASYNC_PRIVATE_KEY_METHOD) {
/*  243 */           asyncPrivateKeyMethod = (OpenSslAsyncPrivateKeyMethod)ctxOpt.getValue();
/*  244 */         } else if (option == OpenSslContextOption.CERTIFICATE_COMPRESSION_ALGORITHMS) {
/*  245 */           certCompressionConfig = (OpenSslCertificateCompressionConfig)ctxOpt.getValue();
/*  246 */         } else if (option == OpenSslContextOption.MAX_CERTIFICATE_LIST_BYTES) {
/*  247 */           maxCertificateList = (Integer)ctxOpt.getValue();
/*      */         } else {
/*  249 */           logger.debug("Skipping unsupported " + SslContextOption.class.getSimpleName() + ": " + ctxOpt
/*  250 */               .getKey());
/*      */         } 
/*      */       } 
/*      */     }
/*  254 */     if (privateKeyMethod != null && asyncPrivateKeyMethod != null) {
/*  255 */       throw new IllegalArgumentException("You can either only use " + OpenSslAsyncPrivateKeyMethod.class
/*  256 */           .getSimpleName() + " or " + OpenSslPrivateKeyMethod.class
/*  257 */           .getSimpleName());
/*      */     }
/*      */     
/*  260 */     this.tlsFalseStart = tlsFalseStart;
/*      */     
/*  262 */     this.leak = leakDetection ? leakDetector.track(this) : null;
/*  263 */     this.mode = mode;
/*  264 */     this.clientAuth = isServer() ? (ClientAuth)ObjectUtil.checkNotNull(clientAuth, "clientAuth") : ClientAuth.NONE;
/*  265 */     this.protocols = (protocols == null) ? OpenSsl.defaultProtocols((mode == 0)) : protocols;
/*  266 */     this.enableOcsp = enableOcsp;
/*      */     
/*  268 */     this.keyCertChain = (keyCertChain == null) ? null : (Certificate[])keyCertChain.clone();
/*      */     
/*  270 */     String[] suites = ((CipherSuiteFilter)ObjectUtil.checkNotNull(cipherFilter, "cipherFilter")).filterCipherSuites(ciphers, OpenSsl.DEFAULT_CIPHERS, 
/*  271 */         OpenSsl.availableJavaCipherSuites());
/*      */     
/*  273 */     LinkedHashSet<String> suitesSet = new LinkedHashSet<String>(suites.length);
/*  274 */     Collections.addAll(suitesSet, suites);
/*  275 */     this.unmodifiableCiphers = new ArrayList<String>(suitesSet);
/*      */     
/*  277 */     this.apn = (OpenSslApplicationProtocolNegotiator)ObjectUtil.checkNotNull(apn, "apn");
/*      */ 
/*      */     
/*  280 */     boolean success = false;
/*      */     try {
/*  282 */       boolean tlsv13Supported = OpenSsl.isTlsv13Supported();
/*      */       
/*      */       try {
/*  285 */         int protocolOpts = 30;
/*      */         
/*  287 */         if (tlsv13Supported) {
/*  288 */           protocolOpts |= 0x20;
/*      */         }
/*  290 */         this.ctx = SSLContext.make(protocolOpts, mode);
/*  291 */       } catch (Exception e) {
/*  292 */         throw new SSLException("failed to create an SSL_CTX", e);
/*      */       } 
/*      */       
/*  295 */       StringBuilder cipherBuilder = new StringBuilder();
/*  296 */       StringBuilder cipherTLSv13Builder = new StringBuilder();
/*      */ 
/*      */       
/*      */       try {
/*  300 */         if (this.unmodifiableCiphers.isEmpty()) {
/*      */           
/*  302 */           SSLContext.setCipherSuite(this.ctx, "", false);
/*  303 */           if (tlsv13Supported)
/*      */           {
/*  305 */             SSLContext.setCipherSuite(this.ctx, "", true);
/*      */           }
/*      */         } else {
/*  308 */           CipherSuiteConverter.convertToCipherStrings(this.unmodifiableCiphers, cipherBuilder, cipherTLSv13Builder, 
/*  309 */               OpenSsl.isBoringSSL());
/*      */ 
/*      */           
/*  312 */           SSLContext.setCipherSuite(this.ctx, cipherBuilder.toString(), false);
/*  313 */           if (tlsv13Supported)
/*      */           {
/*  315 */             SSLContext.setCipherSuite(this.ctx, 
/*  316 */                 OpenSsl.checkTls13Ciphers(logger, cipherTLSv13Builder.toString()), true);
/*      */           }
/*      */         } 
/*  319 */       } catch (SSLException e) {
/*  320 */         throw e;
/*  321 */       } catch (Exception e) {
/*  322 */         throw new SSLException("failed to set cipher suite: " + this.unmodifiableCiphers, e);
/*      */       } 
/*      */       
/*  325 */       int options = SSLContext.getOptions(this.ctx) | SSL.SSL_OP_NO_SSLv2 | SSL.SSL_OP_NO_SSLv3 | SSL.SSL_OP_NO_TLSv1 | SSL.SSL_OP_NO_TLSv1_1 | SSL.SSL_OP_CIPHER_SERVER_PREFERENCE | SSL.SSL_OP_NO_COMPRESSION | SSL.SSL_OP_NO_TICKET;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  345 */       if (cipherBuilder.length() == 0)
/*      */       {
/*  347 */         options |= SSL.SSL_OP_NO_SSLv2 | SSL.SSL_OP_NO_SSLv3 | SSL.SSL_OP_NO_TLSv1 | SSL.SSL_OP_NO_TLSv1_1 | SSL.SSL_OP_NO_TLSv1_2;
/*      */       }
/*      */ 
/*      */       
/*  351 */       if (!tlsv13Supported)
/*      */       {
/*      */         
/*  354 */         options |= SSL.SSL_OP_NO_TLSv1_3;
/*      */       }
/*      */       
/*  357 */       SSLContext.setOptions(this.ctx, options);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  362 */       SSLContext.setMode(this.ctx, SSLContext.getMode(this.ctx) | SSL.SSL_MODE_ACCEPT_MOVING_WRITE_BUFFER);
/*      */       
/*  364 */       if (DH_KEY_LENGTH != null) {
/*  365 */         SSLContext.setTmpDHLength(this.ctx, DH_KEY_LENGTH.intValue());
/*      */       }
/*      */       
/*  368 */       List<String> nextProtoList = apn.protocols();
/*      */       
/*  370 */       if (!nextProtoList.isEmpty()) {
/*  371 */         String[] appProtocols = nextProtoList.<String>toArray(new String[0]);
/*  372 */         int selectorBehavior = opensslSelectorFailureBehavior(apn.selectorFailureBehavior());
/*      */         
/*  374 */         switch (apn.protocol()) {
/*      */           case CHOOSE_MY_LAST_PROTOCOL:
/*  376 */             SSLContext.setNpnProtos(this.ctx, appProtocols, selectorBehavior);
/*      */             break;
/*      */           case ACCEPT:
/*  379 */             SSLContext.setAlpnProtos(this.ctx, appProtocols, selectorBehavior);
/*      */             break;
/*      */           case null:
/*  382 */             SSLContext.setNpnProtos(this.ctx, appProtocols, selectorBehavior);
/*  383 */             SSLContext.setAlpnProtos(this.ctx, appProtocols, selectorBehavior);
/*      */             break;
/*      */           default:
/*  386 */             throw new Error();
/*      */         } 
/*      */       
/*      */       } 
/*  390 */       if (enableOcsp) {
/*  391 */         SSLContext.enableOcsp(this.ctx, isClient());
/*      */       }
/*      */       
/*  394 */       SSLContext.setUseTasks(this.ctx, useTasks);
/*  395 */       if (privateKeyMethod != null) {
/*  396 */         SSLContext.setPrivateKeyMethod(this.ctx, new PrivateKeyMethod(this.engineMap, privateKeyMethod));
/*      */       }
/*  398 */       if (asyncPrivateKeyMethod != null) {
/*  399 */         SSLContext.setPrivateKeyMethod(this.ctx, new AsyncPrivateKeyMethod(this.engineMap, asyncPrivateKeyMethod));
/*      */       }
/*  401 */       if (certCompressionConfig != null) {
/*  402 */         for (OpenSslCertificateCompressionConfig.AlgorithmConfig configPair : certCompressionConfig) {
/*  403 */           CertificateCompressionAlgo algo = new CompressionAlgorithm(this.engineMap, configPair.algorithm());
/*  404 */           switch (configPair.mode()) {
/*      */             case CHOOSE_MY_LAST_PROTOCOL:
/*  406 */               SSLContext.addCertificateCompressionAlgorithm(this.ctx, SSL.SSL_CERT_COMPRESSION_DIRECTION_DECOMPRESS, algo);
/*      */               continue;
/*      */             
/*      */             case ACCEPT:
/*  410 */               SSLContext.addCertificateCompressionAlgorithm(this.ctx, SSL.SSL_CERT_COMPRESSION_DIRECTION_COMPRESS, algo);
/*      */               continue;
/*      */             
/*      */             case null:
/*  414 */               SSLContext.addCertificateCompressionAlgorithm(this.ctx, SSL.SSL_CERT_COMPRESSION_DIRECTION_BOTH, algo);
/*      */               continue;
/*      */           } 
/*      */           
/*  418 */           throw new IllegalStateException();
/*      */         } 
/*      */       }
/*      */       
/*  422 */       if (maxCertificateList != null) {
/*  423 */         SSLContext.setMaxCertList(this.ctx, maxCertificateList.intValue());
/*      */       }
/*      */       
/*  426 */       SSLContext.setCurvesList(this.ctx, OpenSsl.NAMED_GROUPS);
/*  427 */       success = true;
/*      */     } finally {
/*  429 */       if (!success) {
/*  430 */         release();
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   private static int opensslSelectorFailureBehavior(ApplicationProtocolConfig.SelectorFailureBehavior behavior) {
/*  436 */     switch (behavior) {
/*      */       case CHOOSE_MY_LAST_PROTOCOL:
/*  438 */         return 0;
/*      */       case ACCEPT:
/*  440 */         return 1;
/*      */     } 
/*  442 */     throw new Error();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final List<String> cipherSuites() {
/*  448 */     return this.unmodifiableCiphers;
/*      */   }
/*      */ 
/*      */   
/*      */   public ApplicationProtocolNegotiator applicationProtocolNegotiator() {
/*  453 */     return this.apn;
/*      */   }
/*      */ 
/*      */   
/*      */   public final boolean isClient() {
/*  458 */     return (this.mode == 0);
/*      */   }
/*      */ 
/*      */   
/*      */   public final SSLEngine newEngine(ByteBufAllocator alloc, String peerHost, int peerPort) {
/*  463 */     return newEngine0(alloc, peerHost, peerPort, true);
/*      */   }
/*      */ 
/*      */   
/*      */   protected final SslHandler newHandler(ByteBufAllocator alloc, boolean startTls) {
/*  468 */     return new SslHandler(newEngine0(alloc, null, -1, false), startTls);
/*      */   }
/*      */ 
/*      */   
/*      */   protected final SslHandler newHandler(ByteBufAllocator alloc, String peerHost, int peerPort, boolean startTls) {
/*  473 */     return new SslHandler(newEngine0(alloc, peerHost, peerPort, false), startTls);
/*      */   }
/*      */ 
/*      */   
/*      */   protected SslHandler newHandler(ByteBufAllocator alloc, boolean startTls, Executor executor) {
/*  478 */     return new SslHandler(newEngine0(alloc, null, -1, false), startTls, executor);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected SslHandler newHandler(ByteBufAllocator alloc, String peerHost, int peerPort, boolean startTls, Executor executor) {
/*  484 */     return new SslHandler(newEngine0(alloc, peerHost, peerPort, false), executor);
/*      */   }
/*      */   
/*      */   SSLEngine newEngine0(ByteBufAllocator alloc, String peerHost, int peerPort, boolean jdkCompatibilityMode) {
/*  488 */     return new ReferenceCountedOpenSslEngine(this, alloc, peerHost, peerPort, jdkCompatibilityMode, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final SSLEngine newEngine(ByteBufAllocator alloc) {
/*  496 */     return newEngine(alloc, null, -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public final long context() {
/*  508 */     return sslCtxPointer();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public final OpenSslSessionStats stats() {
/*  518 */     return sessionContext().stats();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void setRejectRemoteInitiatedRenegotiation(boolean rejectRemoteInitiatedRenegotiation) {
/*  528 */     if (!rejectRemoteInitiatedRenegotiation) {
/*  529 */       throw new UnsupportedOperationException("Renegotiation is not supported");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public boolean getRejectRemoteInitiatedRenegotiation() {
/*  539 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBioNonApplicationBufferSize(int bioNonApplicationBufferSize) {
/*  547 */     this
/*  548 */       .bioNonApplicationBufferSize = ObjectUtil.checkPositiveOrZero(bioNonApplicationBufferSize, "bioNonApplicationBufferSize");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getBioNonApplicationBufferSize() {
/*  555 */     return this.bioNonApplicationBufferSize;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public final void setTicketKeys(byte[] keys) {
/*  565 */     sessionContext().setTicketKeys(keys);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public final long sslCtxPointer() {
/*  580 */     Lock readerLock = this.ctxLock.readLock();
/*  581 */     readerLock.lock();
/*      */     try {
/*  583 */       return SSLContext.getSslCtx(this.ctx);
/*      */     } finally {
/*  585 */       readerLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public final void setPrivateKeyMethod(OpenSslPrivateKeyMethod method) {
/*  602 */     ObjectUtil.checkNotNull(method, "method");
/*  603 */     Lock writerLock = this.ctxLock.writeLock();
/*  604 */     writerLock.lock();
/*      */     try {
/*  606 */       SSLContext.setPrivateKeyMethod(this.ctx, new PrivateKeyMethod(this.engineMap, method));
/*      */     } finally {
/*  608 */       writerLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public final void setUseTasks(boolean useTasks) {
/*  618 */     Lock writerLock = this.ctxLock.writeLock();
/*  619 */     writerLock.lock();
/*      */     try {
/*  621 */       SSLContext.setUseTasks(this.ctx, useTasks);
/*      */     } finally {
/*  623 */       writerLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void destroy() {
/*  631 */     Lock writerLock = this.ctxLock.writeLock();
/*  632 */     writerLock.lock();
/*      */     try {
/*  634 */       if (this.ctx != 0L) {
/*  635 */         if (this.enableOcsp) {
/*  636 */           SSLContext.disableOcsp(this.ctx);
/*      */         }
/*      */         
/*  639 */         SSLContext.free(this.ctx);
/*  640 */         this.ctx = 0L;
/*      */         
/*  642 */         OpenSslSessionContext context = sessionContext();
/*  643 */         if (context != null) {
/*  644 */           context.destroy();
/*      */         }
/*      */       } 
/*      */     } finally {
/*  648 */       writerLock.unlock();
/*      */     } 
/*      */   }
/*      */   
/*      */   protected static X509Certificate[] certificates(byte[][] chain) {
/*  653 */     X509Certificate[] peerCerts = new X509Certificate[chain.length];
/*  654 */     for (int i = 0; i < peerCerts.length; i++) {
/*  655 */       peerCerts[i] = (X509Certificate)new LazyX509Certificate(chain[i]);
/*      */     }
/*  657 */     return peerCerts;
/*      */   }
/*      */   
/*      */   protected static X509TrustManager chooseTrustManager(TrustManager[] managers) {
/*  661 */     for (TrustManager m : managers) {
/*  662 */       if (m instanceof X509TrustManager) {
/*  663 */         if (PlatformDependent.javaVersion() >= 7) {
/*  664 */           return OpenSslX509TrustManagerWrapper.wrapIfNeeded((X509TrustManager)m);
/*      */         }
/*  666 */         return (X509TrustManager)m;
/*      */       } 
/*      */     } 
/*  669 */     throw new IllegalStateException("no X509TrustManager found");
/*      */   }
/*      */   
/*      */   protected static X509KeyManager chooseX509KeyManager(KeyManager[] kms) {
/*  673 */     for (KeyManager km : kms) {
/*  674 */       if (km instanceof X509KeyManager) {
/*  675 */         return (X509KeyManager)km;
/*      */       }
/*      */     } 
/*  678 */     throw new IllegalStateException("no X509KeyManager found");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static OpenSslApplicationProtocolNegotiator toNegotiator(ApplicationProtocolConfig config) {
/*  690 */     if (config == null) {
/*  691 */       return NONE_PROTOCOL_NEGOTIATOR;
/*      */     }
/*      */     
/*  694 */     switch (config.protocol()) {
/*      */       case null:
/*  696 */         return NONE_PROTOCOL_NEGOTIATOR;
/*      */       case CHOOSE_MY_LAST_PROTOCOL:
/*      */       case ACCEPT:
/*      */       case null:
/*  700 */         switch (config.selectedListenerFailureBehavior()) {
/*      */           case CHOOSE_MY_LAST_PROTOCOL:
/*      */           case ACCEPT:
/*  703 */             switch (config.selectorFailureBehavior()) {
/*      */               case CHOOSE_MY_LAST_PROTOCOL:
/*      */               case ACCEPT:
/*  706 */                 return new OpenSslDefaultApplicationProtocolNegotiator(config);
/*      */             } 
/*      */             
/*  709 */             throw new UnsupportedOperationException("OpenSSL provider does not support " + config
/*      */                 
/*  711 */                 .selectorFailureBehavior() + " behavior");
/*      */         } 
/*      */ 
/*      */         
/*  715 */         throw new UnsupportedOperationException("OpenSSL provider does not support " + config
/*      */             
/*  717 */             .selectedListenerFailureBehavior() + " behavior");
/*      */     } 
/*      */ 
/*      */     
/*  721 */     throw new Error();
/*      */   }
/*      */ 
/*      */   
/*      */   @SuppressJava6Requirement(reason = "Guarded by java version check")
/*      */   static boolean useExtendedTrustManager(X509TrustManager trustManager) {
/*  727 */     return (PlatformDependent.javaVersion() >= 7 && trustManager instanceof javax.net.ssl.X509ExtendedTrustManager);
/*      */   }
/*      */ 
/*      */   
/*      */   public final int refCnt() {
/*  732 */     return this.refCnt.refCnt();
/*      */   }
/*      */ 
/*      */   
/*      */   public final ReferenceCounted retain() {
/*  737 */     this.refCnt.retain();
/*  738 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public final ReferenceCounted retain(int increment) {
/*  743 */     this.refCnt.retain(increment);
/*  744 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public final ReferenceCounted touch() {
/*  749 */     this.refCnt.touch();
/*  750 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public final ReferenceCounted touch(Object hint) {
/*  755 */     this.refCnt.touch(hint);
/*  756 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public final boolean release() {
/*  761 */     return this.refCnt.release();
/*      */   }
/*      */ 
/*      */   
/*      */   public final boolean release(int decrement) {
/*  766 */     return this.refCnt.release(decrement);
/*      */   }
/*      */   
/*      */   static abstract class AbstractCertificateVerifier extends CertificateVerifier {
/*      */     private final OpenSslEngineMap engineMap;
/*      */     
/*      */     AbstractCertificateVerifier(OpenSslEngineMap engineMap) {
/*  773 */       this.engineMap = engineMap;
/*      */     }
/*      */ 
/*      */     
/*      */     public final int verify(long ssl, byte[][] chain, String auth) {
/*  778 */       ReferenceCountedOpenSslEngine engine = this.engineMap.get(ssl);
/*  779 */       if (engine == null)
/*      */       {
/*  781 */         return CertificateVerifier.X509_V_ERR_UNSPECIFIED;
/*      */       }
/*  783 */       X509Certificate[] peerCerts = ReferenceCountedOpenSslContext.certificates(chain);
/*      */       try {
/*  785 */         verify(engine, peerCerts, auth);
/*  786 */         return CertificateVerifier.X509_V_OK;
/*  787 */       } catch (Throwable cause) {
/*  788 */         ReferenceCountedOpenSslContext.logger.debug("verification of certificate failed", cause);
/*  789 */         engine.initHandshakeException(cause);
/*      */ 
/*      */         
/*  792 */         if (cause instanceof OpenSslCertificateException)
/*      */         {
/*      */           
/*  795 */           return ((OpenSslCertificateException)cause).errorCode();
/*      */         }
/*  797 */         if (cause instanceof java.security.cert.CertificateExpiredException) {
/*  798 */           return CertificateVerifier.X509_V_ERR_CERT_HAS_EXPIRED;
/*      */         }
/*  800 */         if (cause instanceof java.security.cert.CertificateNotYetValidException) {
/*  801 */           return CertificateVerifier.X509_V_ERR_CERT_NOT_YET_VALID;
/*      */         }
/*  803 */         if (PlatformDependent.javaVersion() >= 7) {
/*  804 */           return translateToError(cause);
/*      */         }
/*      */ 
/*      */         
/*  808 */         return CertificateVerifier.X509_V_ERR_UNSPECIFIED;
/*      */       } 
/*      */     }
/*      */     
/*      */     @SuppressJava6Requirement(reason = "Usage guarded by java version check")
/*      */     private static int translateToError(Throwable cause) {
/*  814 */       if (cause instanceof java.security.cert.CertificateRevokedException) {
/*  815 */         return CertificateVerifier.X509_V_ERR_CERT_REVOKED;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  821 */       Throwable wrapped = cause.getCause();
/*  822 */       while (wrapped != null) {
/*  823 */         if (wrapped instanceof CertPathValidatorException) {
/*  824 */           CertPathValidatorException ex = (CertPathValidatorException)wrapped;
/*  825 */           CertPathValidatorException.Reason reason = ex.getReason();
/*  826 */           if (reason == CertPathValidatorException.BasicReason.EXPIRED) {
/*  827 */             return CertificateVerifier.X509_V_ERR_CERT_HAS_EXPIRED;
/*      */           }
/*  829 */           if (reason == CertPathValidatorException.BasicReason.NOT_YET_VALID) {
/*  830 */             return CertificateVerifier.X509_V_ERR_CERT_NOT_YET_VALID;
/*      */           }
/*  832 */           if (reason == CertPathValidatorException.BasicReason.REVOKED) {
/*  833 */             return CertificateVerifier.X509_V_ERR_CERT_REVOKED;
/*      */           }
/*      */         } 
/*  836 */         wrapped = wrapped.getCause();
/*      */       } 
/*  838 */       return CertificateVerifier.X509_V_ERR_UNSPECIFIED;
/*      */     }
/*      */     
/*      */     abstract void verify(ReferenceCountedOpenSslEngine param1ReferenceCountedOpenSslEngine, X509Certificate[] param1ArrayOfX509Certificate, String param1String) throws Exception;
/*      */   }
/*      */   
/*      */   private static final class DefaultOpenSslEngineMap
/*      */     implements OpenSslEngineMap {
/*  846 */     private final Map<Long, ReferenceCountedOpenSslEngine> engines = PlatformDependent.newConcurrentHashMap();
/*      */ 
/*      */     
/*      */     public ReferenceCountedOpenSslEngine remove(long ssl) {
/*  850 */       return this.engines.remove(Long.valueOf(ssl));
/*      */     }
/*      */ 
/*      */     
/*      */     public void add(ReferenceCountedOpenSslEngine engine) {
/*  855 */       this.engines.put(Long.valueOf(engine.sslPointer()), engine);
/*      */     }
/*      */ 
/*      */     
/*      */     public ReferenceCountedOpenSslEngine get(long ssl) {
/*  860 */       return this.engines.get(Long.valueOf(ssl));
/*      */     }
/*      */     
/*      */     private DefaultOpenSslEngineMap() {}
/*      */   }
/*      */   
/*      */   static void setKeyMaterial(long ctx, X509Certificate[] keyCertChain, PrivateKey key, String keyPassword) throws SSLException {
/*  867 */     long keyBio = 0L;
/*  868 */     long keyCertChainBio = 0L;
/*  869 */     long keyCertChainBio2 = 0L;
/*  870 */     PemEncoded encoded = null;
/*      */     
/*      */     try {
/*  873 */       encoded = PemX509Certificate.toPEM(ByteBufAllocator.DEFAULT, true, keyCertChain);
/*  874 */       keyCertChainBio = toBIO(ByteBufAllocator.DEFAULT, encoded.retain());
/*  875 */       keyCertChainBio2 = toBIO(ByteBufAllocator.DEFAULT, encoded.retain());
/*      */       
/*  877 */       if (key != null) {
/*  878 */         keyBio = toBIO(ByteBufAllocator.DEFAULT, key);
/*      */       }
/*      */       
/*  881 */       SSLContext.setCertificateBio(ctx, keyCertChainBio, keyBio, (keyPassword == null) ? "" : keyPassword);
/*      */ 
/*      */ 
/*      */       
/*  885 */       SSLContext.setCertificateChainBio(ctx, keyCertChainBio2, true);
/*  886 */     } catch (SSLException e) {
/*  887 */       throw e;
/*  888 */     } catch (Exception e) {
/*  889 */       throw new SSLException("failed to set certificate and key", e);
/*      */     } finally {
/*  891 */       freeBio(keyBio);
/*  892 */       freeBio(keyCertChainBio);
/*  893 */       freeBio(keyCertChainBio2);
/*  894 */       if (encoded != null) {
/*  895 */         encoded.release();
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   static void freeBio(long bio) {
/*  901 */     if (bio != 0L) {
/*  902 */       SSL.freeBIO(bio);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static long toBIO(ByteBufAllocator allocator, PrivateKey key) throws Exception {
/*  911 */     if (key == null) {
/*  912 */       return 0L;
/*      */     }
/*      */     
/*  915 */     PemEncoded pem = PemPrivateKey.toPEM(allocator, true, key);
/*      */     try {
/*  917 */       return toBIO(allocator, pem.retain());
/*      */     } finally {
/*  919 */       pem.release();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static long toBIO(ByteBufAllocator allocator, X509Certificate... certChain) throws Exception {
/*  928 */     if (certChain == null) {
/*  929 */       return 0L;
/*      */     }
/*      */     
/*  932 */     ObjectUtil.checkNonEmpty((Object[])certChain, "certChain");
/*      */     
/*  934 */     PemEncoded pem = PemX509Certificate.toPEM(allocator, true, certChain);
/*      */     try {
/*  936 */       return toBIO(allocator, pem.retain());
/*      */     } finally {
/*  938 */       pem.release();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static long toBIO(ByteBufAllocator allocator, PemEncoded pem) throws Exception {
/*      */     try {
/*  946 */       ByteBuf content = pem.content();
/*      */       
/*  948 */       if (content.isDirect()) {
/*  949 */         return newBIO(content.retainedSlice());
/*      */       }
/*      */       
/*  952 */       ByteBuf buffer = allocator.directBuffer(content.readableBytes());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*      */     finally {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  968 */       pem.release();
/*      */     } 
/*      */   }
/*      */   
/*      */   private static long newBIO(ByteBuf buffer) throws Exception {
/*      */     try {
/*  974 */       long bio = SSL.newMemBIO();
/*  975 */       int readable = buffer.readableBytes();
/*  976 */       if (SSL.bioWrite(bio, OpenSsl.memoryAddress(buffer) + buffer.readerIndex(), readable) != readable) {
/*  977 */         SSL.freeBIO(bio);
/*  978 */         throw new IllegalStateException("Could not write data to memory BIO");
/*      */       } 
/*  980 */       return bio;
/*      */     } finally {
/*  982 */       buffer.release();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static OpenSslKeyMaterialProvider providerFor(KeyManagerFactory factory, String password) {
/*  992 */     if (factory instanceof OpenSslX509KeyManagerFactory) {
/*  993 */       return ((OpenSslX509KeyManagerFactory)factory).newProvider();
/*      */     }
/*      */     
/*  996 */     if (factory instanceof OpenSslCachingX509KeyManagerFactory)
/*      */     {
/*  998 */       return ((OpenSslCachingX509KeyManagerFactory)factory).newProvider(password);
/*      */     }
/*      */     
/* 1001 */     return new OpenSslKeyMaterialProvider(chooseX509KeyManager(factory.getKeyManagers()), password);
/*      */   }
/*      */ 
/*      */   
/*      */   private static ReferenceCountedOpenSslEngine retrieveEngine(OpenSslEngineMap engineMap, long ssl) throws SSLException {
/* 1006 */     ReferenceCountedOpenSslEngine engine = engineMap.get(ssl);
/* 1007 */     if (engine == null) {
/* 1008 */       throw new SSLException("Could not find a " + 
/* 1009 */           StringUtil.simpleClassName(ReferenceCountedOpenSslEngine.class) + " for sslPointer " + ssl);
/*      */     }
/* 1011 */     return engine;
/*      */   }
/*      */   
/*      */   private static final class PrivateKeyMethod implements SSLPrivateKeyMethod {
/*      */     private final OpenSslEngineMap engineMap;
/*      */     private final OpenSslPrivateKeyMethod keyMethod;
/*      */     
/*      */     PrivateKeyMethod(OpenSslEngineMap engineMap, OpenSslPrivateKeyMethod keyMethod) {
/* 1019 */       this.engineMap = engineMap;
/* 1020 */       this.keyMethod = keyMethod;
/*      */     }
/*      */ 
/*      */     
/*      */     public byte[] sign(long ssl, int signatureAlgorithm, byte[] digest) throws Exception {
/* 1025 */       ReferenceCountedOpenSslEngine engine = ReferenceCountedOpenSslContext.retrieveEngine(this.engineMap, ssl);
/*      */       try {
/* 1027 */         return ReferenceCountedOpenSslContext.verifyResult(this.keyMethod.sign(engine, signatureAlgorithm, digest));
/* 1028 */       } catch (Exception e) {
/* 1029 */         engine.initHandshakeException(e);
/* 1030 */         throw e;
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public byte[] decrypt(long ssl, byte[] input) throws Exception {
/* 1036 */       ReferenceCountedOpenSslEngine engine = ReferenceCountedOpenSslContext.retrieveEngine(this.engineMap, ssl);
/*      */       try {
/* 1038 */         return ReferenceCountedOpenSslContext.verifyResult(this.keyMethod.decrypt(engine, input));
/* 1039 */       } catch (Exception e) {
/* 1040 */         engine.initHandshakeException(e);
/* 1041 */         throw e;
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   private static final class AsyncPrivateKeyMethod
/*      */     implements AsyncSSLPrivateKeyMethod {
/*      */     private final OpenSslEngineMap engineMap;
/*      */     private final OpenSslAsyncPrivateKeyMethod keyMethod;
/*      */     
/*      */     AsyncPrivateKeyMethod(OpenSslEngineMap engineMap, OpenSslAsyncPrivateKeyMethod keyMethod) {
/* 1052 */       this.engineMap = engineMap;
/* 1053 */       this.keyMethod = keyMethod;
/*      */     }
/*      */ 
/*      */     
/*      */     public void sign(long ssl, int signatureAlgorithm, byte[] bytes, ResultCallback<byte[]> resultCallback) {
/*      */       try {
/* 1059 */         ReferenceCountedOpenSslEngine engine = ReferenceCountedOpenSslContext.retrieveEngine(this.engineMap, ssl);
/* 1060 */         this.keyMethod.sign(engine, signatureAlgorithm, bytes)
/* 1061 */           .addListener((GenericFutureListener)new ResultCallbackListener(engine, ssl, resultCallback));
/* 1062 */       } catch (SSLException e) {
/* 1063 */         resultCallback.onError(ssl, e);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void decrypt(long ssl, byte[] bytes, ResultCallback<byte[]> resultCallback) {
/*      */       try {
/* 1070 */         ReferenceCountedOpenSslEngine engine = ReferenceCountedOpenSslContext.retrieveEngine(this.engineMap, ssl);
/* 1071 */         this.keyMethod.decrypt(engine, bytes)
/* 1072 */           .addListener((GenericFutureListener)new ResultCallbackListener(engine, ssl, resultCallback));
/* 1073 */       } catch (SSLException e) {
/* 1074 */         resultCallback.onError(ssl, e);
/*      */       } 
/*      */     }
/*      */     
/*      */     private static final class ResultCallbackListener
/*      */       implements FutureListener<byte[]> {
/*      */       private final ReferenceCountedOpenSslEngine engine;
/*      */       private final long ssl;
/*      */       private final ResultCallback<byte[]> resultCallback;
/*      */       
/*      */       ResultCallbackListener(ReferenceCountedOpenSslEngine engine, long ssl, ResultCallback<byte[]> resultCallback) {
/* 1085 */         this.engine = engine;
/* 1086 */         this.ssl = ssl;
/* 1087 */         this.resultCallback = resultCallback;
/*      */       }
/*      */ 
/*      */       
/*      */       public void operationComplete(Future<byte[]> future) {
/* 1092 */         Throwable cause = future.cause();
/* 1093 */         if (cause == null) {
/*      */           try {
/* 1095 */             byte[] result = ReferenceCountedOpenSslContext.verifyResult((byte[])future.getNow());
/* 1096 */             this.resultCallback.onSuccess(this.ssl, result);
/*      */             return;
/* 1098 */           } catch (SignatureException e) {
/* 1099 */             cause = e;
/* 1100 */             this.engine.initHandshakeException(e);
/*      */           } 
/*      */         }
/* 1103 */         this.resultCallback.onError(this.ssl, cause);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private static byte[] verifyResult(byte[] result) throws SignatureException {
/* 1109 */     if (result == null) {
/* 1110 */       throw new SignatureException();
/*      */     }
/* 1112 */     return result;
/*      */   }
/*      */   
/*      */   public abstract OpenSslSessionContext sessionContext();
/*      */   
/*      */   private static final class CompressionAlgorithm implements CertificateCompressionAlgo { private final OpenSslEngineMap engineMap;
/*      */     
/*      */     CompressionAlgorithm(OpenSslEngineMap engineMap, OpenSslCertificateCompressionAlgorithm compressionAlgorithm) {
/* 1120 */       this.engineMap = engineMap;
/* 1121 */       this.compressionAlgorithm = compressionAlgorithm;
/*      */     }
/*      */     private final OpenSslCertificateCompressionAlgorithm compressionAlgorithm;
/*      */     
/*      */     public byte[] compress(long ssl, byte[] bytes) throws Exception {
/* 1126 */       ReferenceCountedOpenSslEngine engine = ReferenceCountedOpenSslContext.retrieveEngine(this.engineMap, ssl);
/* 1127 */       return this.compressionAlgorithm.compress(engine, bytes);
/*      */     }
/*      */ 
/*      */     
/*      */     public byte[] decompress(long ssl, int len, byte[] bytes) throws Exception {
/* 1132 */       ReferenceCountedOpenSslEngine engine = ReferenceCountedOpenSslContext.retrieveEngine(this.engineMap, ssl);
/* 1133 */       return this.compressionAlgorithm.decompress(engine, len, bytes);
/*      */     }
/*      */ 
/*      */     
/*      */     public int algorithmId() {
/* 1138 */       return this.compressionAlgorithm.algorithmId();
/*      */     } }
/*      */ 
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-handler-4.1.93.Final.jar!\io\netty\handler\ssl\ReferenceCountedOpenSslContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */