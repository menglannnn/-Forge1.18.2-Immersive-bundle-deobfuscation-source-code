/*     */ package io.netty.handler.flow;
/*     */ 
/*     */ import io.netty.channel.ChannelConfig;
/*     */ import io.netty.channel.ChannelDuplexHandler;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.util.ReferenceCountUtil;
/*     */ import io.netty.util.internal.ObjectPool;
/*     */ import io.netty.util.internal.logging.InternalLogger;
/*     */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*     */ import java.util.ArrayDeque;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FlowControlHandler
/*     */   extends ChannelDuplexHandler
/*     */ {
/*  69 */   private static final InternalLogger logger = InternalLoggerFactory.getInstance(FlowControlHandler.class);
/*     */   
/*     */   private final boolean releaseMessages;
/*     */   
/*     */   private RecyclableArrayDeque queue;
/*     */   
/*     */   private ChannelConfig config;
/*     */   
/*     */   private boolean shouldConsume;
/*     */   
/*     */   public FlowControlHandler() {
/*  80 */     this(true);
/*     */   }
/*     */   
/*     */   public FlowControlHandler(boolean releaseMessages) {
/*  84 */     this.releaseMessages = releaseMessages;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isQueueEmpty() {
/*  92 */     return (this.queue == null || this.queue.isEmpty());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void destroy() {
/*  99 */     if (this.queue != null) {
/*     */       
/* 101 */       if (!this.queue.isEmpty()) {
/* 102 */         logger.trace("Non-empty queue: {}", this.queue);
/*     */         
/* 104 */         if (this.releaseMessages) {
/*     */           Object msg;
/* 106 */           while ((msg = this.queue.poll()) != null) {
/* 107 */             ReferenceCountUtil.safeRelease(msg);
/*     */           }
/*     */         } 
/*     */       } 
/*     */       
/* 112 */       this.queue.recycle();
/* 113 */       this.queue = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void handlerAdded(ChannelHandlerContext ctx) throws Exception {
/* 119 */     this.config = ctx.channel().config();
/*     */   }
/*     */ 
/*     */   
/*     */   public void handlerRemoved(ChannelHandlerContext ctx) throws Exception {
/* 124 */     super.handlerRemoved(ctx);
/* 125 */     if (!isQueueEmpty()) {
/* 126 */       dequeue(ctx, this.queue.size());
/*     */     }
/* 128 */     destroy();
/*     */   }
/*     */ 
/*     */   
/*     */   public void channelInactive(ChannelHandlerContext ctx) throws Exception {
/* 133 */     destroy();
/* 134 */     ctx.fireChannelInactive();
/*     */   }
/*     */ 
/*     */   
/*     */   public void read(ChannelHandlerContext ctx) throws Exception {
/* 139 */     if (dequeue(ctx, 1) == 0) {
/*     */ 
/*     */ 
/*     */       
/* 143 */       this.shouldConsume = true;
/* 144 */       ctx.read();
/* 145 */     } else if (this.config.isAutoRead()) {
/* 146 */       ctx.read();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
/* 152 */     if (this.queue == null) {
/* 153 */       this.queue = RecyclableArrayDeque.newInstance();
/*     */     }
/*     */     
/* 156 */     this.queue.offer(msg);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 161 */     int minConsume = this.shouldConsume ? 1 : 0;
/* 162 */     this.shouldConsume = false;
/*     */     
/* 164 */     dequeue(ctx, minConsume);
/*     */   }
/*     */ 
/*     */   
/*     */   public void channelReadComplete(ChannelHandlerContext ctx) throws Exception {
/* 169 */     if (isQueueEmpty()) {
/* 170 */       ctx.fireChannelReadComplete();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int dequeue(ChannelHandlerContext ctx, int minConsume) {
/* 191 */     int consumed = 0;
/*     */ 
/*     */ 
/*     */     
/* 195 */     while (this.queue != null && (consumed < minConsume || this.config.isAutoRead())) {
/* 196 */       Object msg = this.queue.poll();
/* 197 */       if (msg == null) {
/*     */         break;
/*     */       }
/*     */       
/* 201 */       consumed++;
/* 202 */       ctx.fireChannelRead(msg);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 208 */     if (this.queue != null && this.queue.isEmpty()) {
/* 209 */       this.queue.recycle();
/* 210 */       this.queue = null;
/*     */       
/* 212 */       if (consumed > 0) {
/* 213 */         ctx.fireChannelReadComplete();
/*     */       }
/*     */     } 
/*     */     
/* 217 */     return consumed;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class RecyclableArrayDeque
/*     */     extends ArrayDeque<Object>
/*     */   {
/*     */     private static final long serialVersionUID = 0L;
/*     */ 
/*     */     
/*     */     private static final int DEFAULT_NUM_ELEMENTS = 2;
/*     */ 
/*     */ 
/*     */     
/* 232 */     private static final ObjectPool<RecyclableArrayDeque> RECYCLER = ObjectPool.newPool(new ObjectPool.ObjectCreator<RecyclableArrayDeque>()
/*     */         {
/*     */           public FlowControlHandler.RecyclableArrayDeque newObject(ObjectPool.Handle<FlowControlHandler.RecyclableArrayDeque> handle)
/*     */           {
/* 236 */             return new FlowControlHandler.RecyclableArrayDeque(2, handle);
/*     */           }
/*     */         });
/*     */     
/*     */     public static RecyclableArrayDeque newInstance() {
/* 241 */       return (RecyclableArrayDeque)RECYCLER.get();
/*     */     }
/*     */     
/*     */     private final ObjectPool.Handle<RecyclableArrayDeque> handle;
/*     */     
/*     */     private RecyclableArrayDeque(int numElements, ObjectPool.Handle<RecyclableArrayDeque> handle) {
/* 247 */       super(numElements);
/* 248 */       this.handle = handle;
/*     */     }
/*     */     
/*     */     public void recycle() {
/* 252 */       clear();
/* 253 */       this.handle.recycle(this);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-handler-4.1.93.Final.jar!\io\netty\handler\flow\FlowControlHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */