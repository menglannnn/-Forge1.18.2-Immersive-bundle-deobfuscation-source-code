/*    */ package io.netty.handler.ipfilter;
/*    */ 
/*    */ import java.net.InetSocketAddress;
/*    */ import java.util.Comparator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class IpSubnetFilterRuleComparator
/*    */   implements Comparator<Object>
/*    */ {
/* 26 */   static final IpSubnetFilterRuleComparator INSTANCE = new IpSubnetFilterRuleComparator();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int compare(Object o1, Object o2) {
/* 34 */     return ((IpSubnetFilterRule)o1).compareTo((InetSocketAddress)o2);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-handler-4.1.93.Final.jar!\io\netty\handler\ipfilter\IpSubnetFilterRuleComparator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */