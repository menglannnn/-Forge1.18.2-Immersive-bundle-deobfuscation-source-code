/*     */ package io.netty.handler.ipfilter;
/*     */ 
/*     */ import io.netty.util.NetUtil;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import io.netty.util.internal.SocketUtils;
/*     */ import java.math.BigInteger;
/*     */ import java.net.Inet4Address;
/*     */ import java.net.Inet6Address;
/*     */ import java.net.InetAddress;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.UnknownHostException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class IpSubnetFilterRule
/*     */   implements IpFilterRule, Comparable<IpSubnetFilterRule>
/*     */ {
/*     */   private final IpFilterRule filterRule;
/*     */   private final String ipAddress;
/*     */   
/*     */   public IpSubnetFilterRule(String ipAddress, int cidrPrefix, IpFilterRuleType ruleType) {
/*     */     try {
/*  40 */       this.ipAddress = ipAddress;
/*  41 */       this.filterRule = selectFilterRule(SocketUtils.addressByName(ipAddress), cidrPrefix, ruleType);
/*  42 */     } catch (UnknownHostException e) {
/*  43 */       throw new IllegalArgumentException("ipAddress", e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public IpSubnetFilterRule(InetAddress ipAddress, int cidrPrefix, IpFilterRuleType ruleType) {
/*  48 */     this.ipAddress = ipAddress.getHostAddress();
/*  49 */     this.filterRule = selectFilterRule(ipAddress, cidrPrefix, ruleType);
/*     */   }
/*     */   
/*     */   private static IpFilterRule selectFilterRule(InetAddress ipAddress, int cidrPrefix, IpFilterRuleType ruleType) {
/*  53 */     ObjectUtil.checkNotNull(ipAddress, "ipAddress");
/*  54 */     ObjectUtil.checkNotNull(ruleType, "ruleType");
/*     */     
/*  56 */     if (ipAddress instanceof Inet4Address)
/*  57 */       return new Ip4SubnetFilterRule((Inet4Address)ipAddress, cidrPrefix, ruleType); 
/*  58 */     if (ipAddress instanceof Inet6Address) {
/*  59 */       return new Ip6SubnetFilterRule((Inet6Address)ipAddress, cidrPrefix, ruleType);
/*     */     }
/*  61 */     throw new IllegalArgumentException("Only IPv4 and IPv6 addresses are supported");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean matches(InetSocketAddress remoteAddress) {
/*  67 */     return this.filterRule.matches(remoteAddress);
/*     */   }
/*     */ 
/*     */   
/*     */   public IpFilterRuleType ruleType() {
/*  72 */     return this.filterRule.ruleType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getIpAddress() {
/*  79 */     return this.ipAddress;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   IpFilterRule getFilterRule() {
/*  86 */     return this.filterRule;
/*     */   }
/*     */ 
/*     */   
/*     */   public int compareTo(IpSubnetFilterRule ipSubnetFilterRule) {
/*  91 */     if (this.filterRule instanceof Ip4SubnetFilterRule) {
/*  92 */       return compareInt(((Ip4SubnetFilterRule)this.filterRule).networkAddress, ((Ip4SubnetFilterRule)ipSubnetFilterRule.filterRule)
/*  93 */           .networkAddress);
/*     */     }
/*  95 */     return ((Ip6SubnetFilterRule)this.filterRule).networkAddress
/*  96 */       .compareTo(((Ip6SubnetFilterRule)ipSubnetFilterRule.filterRule).networkAddress);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int compareTo(InetSocketAddress inetSocketAddress) {
/* 108 */     if (this.filterRule instanceof Ip4SubnetFilterRule) {
/* 109 */       Ip4SubnetFilterRule ip4SubnetFilterRule = (Ip4SubnetFilterRule)this.filterRule;
/* 110 */       return compareInt(ip4SubnetFilterRule.networkAddress, NetUtil.ipv4AddressToInt((Inet4Address)inetSocketAddress
/* 111 */             .getAddress()) & ip4SubnetFilterRule.subnetMask);
/*     */     } 
/* 113 */     Ip6SubnetFilterRule ip6SubnetFilterRule = (Ip6SubnetFilterRule)this.filterRule;
/* 114 */     return ip6SubnetFilterRule.networkAddress
/* 115 */       .compareTo(Ip6SubnetFilterRule.ipToInt((Inet6Address)inetSocketAddress.getAddress())
/* 116 */         .and(ip6SubnetFilterRule.networkAddress));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int compareInt(int x, int y) {
/* 124 */     return (x < y) ? -1 : ((x == y) ? 0 : 1);
/*     */   }
/*     */   
/*     */   static final class Ip4SubnetFilterRule
/*     */     implements IpFilterRule {
/*     */     private final int networkAddress;
/*     */     private final int subnetMask;
/*     */     private final IpFilterRuleType ruleType;
/*     */     
/*     */     private Ip4SubnetFilterRule(Inet4Address ipAddress, int cidrPrefix, IpFilterRuleType ruleType) {
/* 134 */       if (cidrPrefix < 0 || cidrPrefix > 32) {
/* 135 */         throw new IllegalArgumentException(String.format("IPv4 requires the subnet prefix to be in range of [0,32]. The prefix was: %d", new Object[] {
/* 136 */                 Integer.valueOf(cidrPrefix)
/*     */               }));
/*     */       }
/* 139 */       this.subnetMask = prefixToSubnetMask(cidrPrefix);
/* 140 */       this.networkAddress = NetUtil.ipv4AddressToInt(ipAddress) & this.subnetMask;
/* 141 */       this.ruleType = ruleType;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean matches(InetSocketAddress remoteAddress) {
/* 146 */       InetAddress inetAddress = remoteAddress.getAddress();
/* 147 */       if (inetAddress instanceof Inet4Address) {
/* 148 */         int ipAddress = NetUtil.ipv4AddressToInt((Inet4Address)inetAddress);
/* 149 */         return ((ipAddress & this.subnetMask) == this.networkAddress);
/*     */       } 
/* 151 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public IpFilterRuleType ruleType() {
/* 156 */       return this.ruleType;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private static int prefixToSubnetMask(int cidrPrefix) {
/* 170 */       return (int)(-1L << 32 - cidrPrefix);
/*     */     }
/*     */   }
/*     */   
/*     */   static final class Ip6SubnetFilterRule
/*     */     implements IpFilterRule {
/* 176 */     private static final BigInteger MINUS_ONE = BigInteger.valueOf(-1L);
/*     */     
/*     */     private final BigInteger networkAddress;
/*     */     private final BigInteger subnetMask;
/*     */     private final IpFilterRuleType ruleType;
/*     */     
/*     */     private Ip6SubnetFilterRule(Inet6Address ipAddress, int cidrPrefix, IpFilterRuleType ruleType) {
/* 183 */       if (cidrPrefix < 0 || cidrPrefix > 128) {
/* 184 */         throw new IllegalArgumentException(String.format("IPv6 requires the subnet prefix to be in range of [0,128]. The prefix was: %d", new Object[] {
/* 185 */                 Integer.valueOf(cidrPrefix)
/*     */               }));
/*     */       }
/* 188 */       this.subnetMask = prefixToSubnetMask(cidrPrefix);
/* 189 */       this.networkAddress = ipToInt(ipAddress).and(this.subnetMask);
/* 190 */       this.ruleType = ruleType;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean matches(InetSocketAddress remoteAddress) {
/* 195 */       InetAddress inetAddress = remoteAddress.getAddress();
/* 196 */       if (inetAddress instanceof Inet6Address) {
/* 197 */         BigInteger ipAddress = ipToInt((Inet6Address)inetAddress);
/* 198 */         return (ipAddress.and(this.subnetMask).equals(this.subnetMask) || ipAddress.and(this.subnetMask).equals(this.networkAddress));
/*     */       } 
/* 200 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public IpFilterRuleType ruleType() {
/* 205 */       return this.ruleType;
/*     */     }
/*     */     
/*     */     private static BigInteger ipToInt(Inet6Address ipAddress) {
/* 209 */       byte[] octets = ipAddress.getAddress();
/* 210 */       assert octets.length == 16;
/*     */       
/* 212 */       return new BigInteger(octets);
/*     */     }
/*     */     
/*     */     private static BigInteger prefixToSubnetMask(int cidrPrefix) {
/* 216 */       return MINUS_ONE.shiftLeft(128 - cidrPrefix);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-handler-4.1.93.Final.jar!\io\netty\handler\ipfilter\IpSubnetFilterRule.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */