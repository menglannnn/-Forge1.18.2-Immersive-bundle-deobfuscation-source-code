/*    */ package com.discord4j.fsm;
/*    */ 
/*    */ import java.util.function.BiFunction;
/*    */ import java.util.function.Predicate;
/*    */ 
/*    */ 
/*    */ class EventHandler<S, E, U extends S>
/*    */ {
/*    */   private final BiFunction<? super U, ? super E, ? extends S> handle;
/*    */   private final Predicate<? super E> canHandle;
/*    */   
/*    */   EventHandler(BiFunction<? super U, ? super E, ? extends S> handle, Predicate<? super E> canHandle) {
/* 13 */     this.handle = handle;
/* 14 */     this.canHandle = canHandle;
/*    */   }
/*    */   
/*    */   S handle(U curState, E event) {
/* 18 */     return this.handle.apply(curState, event);
/*    */   }
/*    */   
/*    */   boolean canHandle(E event) {
/* 22 */     return this.canHandle.test(event);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\simple-fsm-1.0.1.jar!\com\discord4j\fsm\EventHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */