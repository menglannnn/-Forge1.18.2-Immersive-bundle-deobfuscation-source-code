/*    */ package com.discord4j.fsm;
/*    */ 
/*    */ import java.util.function.BiFunction;
/*    */ import java.util.function.Predicate;
/*    */ 
/*    */ public class StateMachineDSL<S, E, U extends S>
/*    */ {
/*    */   private final FiniteStateMachine<S, E> owner;
/*    */   private final Class<U> fromState;
/*    */   
/*    */   StateMachineDSL(FiniteStateMachine<S, E> owner, Class<U> fromState) {
/* 12 */     this.owner = owner;
/* 13 */     this.fromState = fromState;
/*    */   }
/*    */   
/*    */   public <C extends E> StateMachineDSL<S, E, U> on(Class<C> eventType, BiFunction<? super U, ? super C, ? extends S> handler) {
/* 17 */     return on(eventType, e -> true, handler);
/*    */   }
/*    */   
/*    */   public <C extends E> StateMachineDSL<S, E, U> on(Class<C> eventType, Predicate<? super C> canHandle, BiFunction<? super U, ? super C, ? extends S> handler) {
/* 21 */     this.owner.addHandler(this.fromState, eventType, canHandle, handler);
/* 22 */     return this;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\simple-fsm-1.0.1.jar!\com\discord4j\fsm\StateMachineDSL.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */