/*    */ package com.discord4j.fsm;
/*    */ 
/*    */ import java.util.Objects;
/*    */ 
/*    */ class HandlerKey<S, E> {
/*    */   private final Class<?> state;
/*    */   private final Class<?> eventType;
/*    */   
/*    */   HandlerKey(Class<? extends S> state, Class<? extends E> eventType) {
/* 10 */     this.state = state;
/* 11 */     this.eventType = eventType;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 16 */     if (this == o) {
/* 17 */       return true;
/*    */     }
/* 19 */     if (o == null || getClass() != o.getClass()) {
/* 20 */       return false;
/*    */     }
/* 22 */     HandlerKey<?, ?> key = (HandlerKey<?, ?>)o;
/* 23 */     return (Objects.equals(this.state, key.state) && 
/* 24 */       Objects.equals(this.eventType, key.eventType));
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 29 */     return Objects.hash(new Object[] { this.state, this.eventType });
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\simple-fsm-1.0.1.jar!\com\discord4j\fsm\HandlerKey.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */