/*   */ package com.discord4j.fsm;
/*   */ 
/*   */ public class UnhandledTransitionException
/*   */   extends RuntimeException {
/*   */   UnhandledTransitionException(Object state, Object event) {
/* 6 */     super("Unhandled transition with no fallback handler: " + state + " on " + event);
/*   */   }
/*   */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\simple-fsm-1.0.1.jar!\com\discord4j\fsm\UnhandledTransitionException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */