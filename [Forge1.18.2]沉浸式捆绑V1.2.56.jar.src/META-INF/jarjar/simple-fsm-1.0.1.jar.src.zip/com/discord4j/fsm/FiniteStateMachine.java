/*    */ package com.discord4j.fsm;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import java.util.function.BiFunction;
/*    */ import java.util.function.Function;
/*    */ import java.util.function.Predicate;
/*    */ 
/*    */ public abstract class FiniteStateMachine<S, E> {
/* 10 */   private final Map<HandlerKey<S, E>, List<EventHandler<S, E, S>>> transitionHandlers = new HashMap<>();
/*    */   private Function<? super E, ? extends S> fallbackHandler;
/*    */   private S currentState;
/*    */   
/*    */   public void startWith(S initialState) {
/* 15 */     this.currentState = initialState;
/*    */   }
/*    */   
/*    */   public <U extends S> StateMachineDSL<S, E, U> when(Class<U> fromState) {
/* 19 */     return new StateMachineDSL<>(this, fromState);
/*    */   }
/*    */   
/*    */   public StateMachineDSL<S, E, S> whenAny() {
/* 23 */     return new StateMachineDSL<>(this, null);
/*    */   }
/*    */   
/*    */   public void onUnhandled(Function<? super E, ? extends S> fallbackHandler) {
/* 27 */     this.fallbackHandler = fallbackHandler;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onEvent(E event) {
/* 32 */     if (this.currentState == null) {
/* 33 */       throw new IllegalStateException("Attempt to trigger event before setting initial state");
/*    */     }
/*    */     
/* 36 */     HandlerKey<S, E> key = new HandlerKey<>((Class)this.currentState.getClass(), (Class)event.getClass());
/* 37 */     List<EventHandler<S, E, S>> handlers = this.transitionHandlers.getOrDefault(key, Collections.emptyList());
/* 38 */     for (EventHandler<S, E, S> handler : handlers) {
/* 39 */       if (handler.canHandle(event)) {
/* 40 */         this.currentState = handler.handle(getCurrentState(), event);
/*    */         
/*    */         return;
/*    */       } 
/*    */     } 
/* 45 */     key = new HandlerKey<>(null, (Class)event.getClass());
/* 46 */     List<EventHandler<S, E, S>> anyHandlers = this.transitionHandlers.getOrDefault(key, Collections.emptyList());
/* 47 */     for (EventHandler<S, E, S> handler : anyHandlers) {
/* 48 */       if (handler.canHandle(event)) {
/* 49 */         this.currentState = handler.handle(getCurrentState(), event);
/*    */         
/*    */         return;
/*    */       } 
/*    */     } 
/* 54 */     if (this.fallbackHandler != null) {
/* 55 */       this.currentState = this.fallbackHandler.apply(event);
/*    */     } else {
/* 57 */       throw new UnhandledTransitionException(this.currentState, event);
/*    */     } 
/*    */   }
/*    */   
/*    */   public S getCurrentState() {
/* 62 */     return this.currentState;
/*    */   }
/*    */ 
/*    */   
/*    */   <C extends E, U extends S> void addHandler(Class<U> from, Class<C> eventType, Predicate<? super C> canHandle, BiFunction<? super U, ? super C, ? extends S> handler) {
/* 67 */     ((List)this.transitionHandlers
/* 68 */       .computeIfAbsent(new HandlerKey<>(from, eventType), key -> new ArrayList()))
/* 69 */       .add(new EventHandler<>(handler, canHandle));
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\simple-fsm-1.0.1.jar!\com\discord4j\fsm\FiniteStateMachine.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */