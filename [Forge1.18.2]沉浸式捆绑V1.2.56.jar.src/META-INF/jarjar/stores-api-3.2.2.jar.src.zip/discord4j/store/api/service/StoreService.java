/*    */ package discord4j.store.api.service;
/*    */ 
/*    */ import discord4j.store.api.Store;
/*    */ import discord4j.store.api.primitive.LongObjStore;
/*    */ import discord4j.store.api.util.StoreContext;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface StoreService
/*    */ {
/*    */   default int order() {
/* 45 */     return 0;
/*    */   }
/*    */   
/*    */   boolean hasGenericStores();
/*    */   
/*    */   <K extends Comparable<K>, V> Store<K, V> provideGenericStore(Class<K> paramClass, Class<V> paramClass1);
/*    */   
/*    */   boolean hasLongObjStores();
/*    */   
/*    */   <V> LongObjStore<V> provideLongObjStore(Class<V> paramClass);
/*    */   
/*    */   void init(StoreContext paramStoreContext);
/*    */   
/*    */   Mono<Void> dispose();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\stores-api-3.2.2.jar!\discord4j\store\api\service\StoreService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */