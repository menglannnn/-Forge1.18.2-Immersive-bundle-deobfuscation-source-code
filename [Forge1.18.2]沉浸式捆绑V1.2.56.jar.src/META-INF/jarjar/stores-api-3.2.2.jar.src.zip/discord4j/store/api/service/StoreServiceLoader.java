/*     */ package discord4j.store.api.service;
/*     */ 
/*     */ import discord4j.store.api.Store;
/*     */ import discord4j.store.api.noop.NoOpStoreService;
/*     */ import discord4j.store.api.primitive.ForwardingStoreService;
/*     */ import discord4j.store.api.primitive.LongObjStore;
/*     */ import discord4j.store.api.util.Lazy;
/*     */ import discord4j.store.api.util.StoreContext;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.ServiceLoader;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StoreServiceLoader
/*     */ {
/*     */   private final Lazy<StoreService> generalService;
/*     */   
/*     */   public StoreServiceLoader() {
/*  42 */     this(Collections.emptyMap());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StoreServiceLoader(final Map<Class<? extends StoreService>, Integer> priorityOverrides) {
/*  52 */     this.generalService = new Lazy(() -> {
/*     */           List<StoreService> services = new ArrayList<>();
/*     */           
/*     */           ServiceLoader<StoreService> serviceLoader = ServiceLoader.load(StoreService.class);
/*     */           
/*     */           serviceLoader.iterator().forEachRemaining(services::add);
/*     */           services.add(new NoOpStoreService());
/*     */           services.sort(new Comparator<StoreService>()
/*     */               {
/*     */                 public int compare(StoreService ss1, StoreService ss2)
/*     */                 {
/*  63 */                   return Integer.compare(((Integer)priorityOverrides.getOrDefault(ss1.getClass(), Integer.valueOf(ss1.order()))).intValue(), ((Integer)priorityOverrides
/*  64 */                       .getOrDefault(ss2.getClass(), Integer.valueOf(ss2.order()))).intValue());
/*     */                 }
/*     */               });
/*     */           
/*     */           StoreService generic = services.stream().filter(StoreService::hasGenericStores).findFirst().get();
/*     */           
/*     */           StoreService primitive = services.stream().filter(StoreService::hasLongObjStores).findFirst().get();
/*  71 */           return (StoreService)((primitive instanceof NoOpStoreService && !(generic instanceof NoOpStoreService)) ? new ForwardingStoreService(generic) : ((generic == primitive) ? generic : new ComposedStoreService(generic, primitive)));
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StoreService getStoreService() {
/*  87 */     return (StoreService)this.generalService.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <K extends Comparable<K>, V> Store<K, V> newGenericStore(Class<K> keyClass, Class<V> valueClass) {
/* 102 */     return getStoreService().provideGenericStore(keyClass, valueClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <V> LongObjStore<V> newLongObjStore(Class<V> valueClass) {
/* 113 */     return getStoreService().provideLongObjStore(valueClass);
/*     */   }
/*     */   
/*     */   private static final class ComposedStoreService implements StoreService {
/*     */     private final StoreService genericService;
/*     */     private final StoreService primitiveService;
/*     */     
/*     */     private ComposedStoreService(StoreService genericService, StoreService primitiveService) {
/* 121 */       this.genericService = genericService;
/* 122 */       this.primitiveService = primitiveService;
/*     */     }
/*     */ 
/*     */     
/*     */     public int order() {
/* 127 */       int p1 = this.genericService.order(), p2 = this.primitiveService.order();
/* 128 */       return Math.max(p1, p2);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasGenericStores() {
/* 133 */       return this.genericService.hasGenericStores();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public <K extends Comparable<K>, V> Store<K, V> provideGenericStore(Class<K> keyClass, Class<V> valueClass) {
/* 139 */       return this.genericService.provideGenericStore(keyClass, valueClass);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasLongObjStores() {
/* 144 */       return this.primitiveService.hasLongObjStores();
/*     */     }
/*     */ 
/*     */     
/*     */     public <V> LongObjStore<V> provideLongObjStore(Class<V> valueClass) {
/* 149 */       return this.primitiveService.provideLongObjStore(valueClass);
/*     */     }
/*     */ 
/*     */     
/*     */     public void init(StoreContext context) {
/* 154 */       this.genericService.init(context);
/* 155 */       this.primitiveService.init(context);
/*     */     }
/*     */ 
/*     */     
/*     */     public Mono<Void> dispose() {
/* 160 */       return this.genericService.dispose().and((Publisher)this.primitiveService.dispose());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\stores-api-3.2.2.jar!\discord4j\store\api\service\StoreServiceLoader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */