/*    */ package discord4j.store.api.delegating;
/*    */ 
/*    */ import discord4j.store.api.Store;
/*    */ import org.reactivestreams.Publisher;
/*    */ import reactor.core.publisher.Flux;
/*    */ import reactor.core.publisher.Mono;
/*    */ import reactor.util.function.Tuple2;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DelegatingStore<K extends Comparable<K>, V>
/*    */   implements Store<K, V>
/*    */ {
/*    */   private final Store<K, V> delegate;
/*    */   
/*    */   public DelegatingStore(Store<K, V> delegate) {
/* 31 */     this.delegate = delegate;
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Void> save(K key, V value) {
/* 36 */     return this.delegate.save((Comparable)key, value);
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Void> save(Publisher<Tuple2<K, V>> entryStream) {
/* 41 */     return this.delegate.save(entryStream);
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Void> delete(K id) {
/* 46 */     return this.delegate.delete((Comparable)id);
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Void> delete(Publisher<K> ids) {
/* 51 */     return this.delegate.delete(ids);
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Void> deleteInRange(K start, K end) {
/* 56 */     return this.delegate.deleteInRange((Comparable)start, (Comparable)end);
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Void> deleteAll() {
/* 61 */     return this.delegate.deleteAll();
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Void> invalidate() {
/* 66 */     return this.delegate.invalidate();
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<V> find(K id) {
/* 71 */     return this.delegate.find((Comparable)id);
/*    */   }
/*    */ 
/*    */   
/*    */   public Flux<V> findInRange(K start, K end) {
/* 76 */     return this.delegate.findInRange((Comparable)start, (Comparable)end);
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Long> count() {
/* 81 */     return this.delegate.count();
/*    */   }
/*    */ 
/*    */   
/*    */   public Flux<K> keys() {
/* 86 */     return this.delegate.keys();
/*    */   }
/*    */ 
/*    */   
/*    */   public Flux<V> values() {
/* 91 */     return this.delegate.values();
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 96 */     return "DelegatingStore{delegate=" + this.delegate + '}';
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\stores-api-3.2.2.jar!\discord4j\store\api\delegating\DelegatingStore.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */