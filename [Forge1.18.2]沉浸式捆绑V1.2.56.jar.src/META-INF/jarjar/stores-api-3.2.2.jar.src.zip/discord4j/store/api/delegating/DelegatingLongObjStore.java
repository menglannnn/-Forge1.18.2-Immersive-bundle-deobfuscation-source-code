/*    */ package discord4j.store.api.delegating;
/*    */ 
/*    */ import discord4j.store.api.primitive.LongObjStore;
/*    */ import discord4j.store.api.util.LongObjTuple2;
/*    */ import org.reactivestreams.Publisher;
/*    */ import reactor.core.publisher.Flux;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DelegatingLongObjStore<V>
/*    */   implements LongObjStore<V>
/*    */ {
/*    */   private final LongObjStore<V> delegate;
/*    */   
/*    */   public DelegatingLongObjStore(LongObjStore<V> delegate) {
/* 31 */     this.delegate = delegate;
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Void> saveWithLong(long key, V value) {
/* 36 */     return this.delegate.saveWithLong(key, value);
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Void> saveWithLong(Publisher<LongObjTuple2<V>> entryStream) {
/* 41 */     return this.delegate.saveWithLong(entryStream);
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<V> find(long id) {
/* 46 */     return this.delegate.find(id);
/*    */   }
/*    */ 
/*    */   
/*    */   public Flux<V> findInRange(long start, long end) {
/* 51 */     return this.delegate.findInRange(start, end);
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Void> delete(long id) {
/* 56 */     return this.delegate.delete(id);
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Void> delete(Publisher<Long> ids) {
/* 61 */     return this.delegate.delete(ids);
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Void> deleteAll() {
/* 66 */     return this.delegate.deleteAll();
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Void> invalidate() {
/* 71 */     return this.delegate.invalidate();
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Void> deleteInRange(long start, long end) {
/* 76 */     return this.delegate.deleteInRange(start, end);
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Long> count() {
/* 81 */     return this.delegate.count();
/*    */   }
/*    */ 
/*    */   
/*    */   public Flux<Long> keys() {
/* 86 */     return this.delegate.keys();
/*    */   }
/*    */ 
/*    */   
/*    */   public Flux<V> values() {
/* 91 */     return this.delegate.values();
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 96 */     return "DelegatingLongObjStore{delegate=" + this.delegate + '}';
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\stores-api-3.2.2.jar!\discord4j\store\api\delegating\DelegatingLongObjStore.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */