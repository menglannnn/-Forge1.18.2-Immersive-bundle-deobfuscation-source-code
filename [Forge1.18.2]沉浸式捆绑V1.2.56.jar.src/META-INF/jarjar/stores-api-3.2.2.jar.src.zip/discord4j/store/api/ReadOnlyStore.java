/*    */ package discord4j.store.api;
/*    */ 
/*    */ import org.reactivestreams.Publisher;
/*    */ import reactor.core.publisher.Flux;
/*    */ import reactor.core.publisher.Mono;
/*    */ import reactor.util.function.Tuple2;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface ReadOnlyStore<K extends Comparable<K>, V>
/*    */ {
/*    */   Mono<V> find(K paramK);
/*    */   
/*    */   Flux<V> findInRange(K paramK1, K paramK2);
/*    */   
/*    */   Mono<Long> count();
/*    */   
/*    */   Flux<K> keys();
/*    */   
/*    */   Flux<V> values();
/*    */   
/*    */   default Flux<Tuple2<K, V>> entries() {
/* 79 */     return keys().zipWith((Publisher)values());
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\stores-api-3.2.2.jar!\discord4j\store\api\ReadOnlyStore.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */