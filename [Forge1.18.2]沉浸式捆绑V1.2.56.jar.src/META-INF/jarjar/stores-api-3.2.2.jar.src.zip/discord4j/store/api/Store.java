package discord4j.store.api;

import org.reactivestreams.Publisher;
import reactor.core.publisher.Mono;
import reactor.util.function.Tuple2;

public interface Store<K extends Comparable<K>, V> extends ReadOnlyStore<K, V> {
  Mono<Void> save(K paramK, V paramV);
  
  Mono<Void> save(Publisher<Tuple2<K, V>> paramPublisher);
  
  Mono<Void> delete(K paramK);
  
  Mono<Void> delete(Publisher<K> paramPublisher);
  
  Mono<Void> deleteInRange(K paramK1, K paramK2);
  
  Mono<Void> deleteAll();
  
  Mono<Void> invalidate();
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\stores-api-3.2.2.jar!\discord4j\store\api\Store.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */