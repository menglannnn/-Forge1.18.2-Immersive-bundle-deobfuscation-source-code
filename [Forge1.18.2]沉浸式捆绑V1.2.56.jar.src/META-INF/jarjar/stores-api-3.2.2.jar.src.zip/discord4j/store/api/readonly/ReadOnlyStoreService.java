/*    */ package discord4j.store.api.readonly;
/*    */ 
/*    */ import discord4j.store.api.Store;
/*    */ import discord4j.store.api.primitive.LongObjStore;
/*    */ import discord4j.store.api.service.StoreService;
/*    */ import discord4j.store.api.util.StoreContext;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReadOnlyStoreService
/*    */   implements StoreService
/*    */ {
/*    */   private final StoreService delegate;
/*    */   
/*    */   public ReadOnlyStoreService(StoreService delegate) {
/* 39 */     this.delegate = delegate;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean hasGenericStores() {
/* 44 */     return this.delegate.hasGenericStores();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public <K extends Comparable<K>, V> Store<K, V> provideGenericStore(Class<K> keyClass, Class<V> valueClass) {
/* 50 */     return new ReadOnlyStore<>(this.delegate.provideGenericStore(keyClass, valueClass));
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean hasLongObjStores() {
/* 55 */     return this.delegate.hasLongObjStores();
/*    */   }
/*    */ 
/*    */   
/*    */   public <V> LongObjStore<V> provideLongObjStore(Class<V> valueClass) {
/* 60 */     return new ReadOnlyLongObjStore<>(this.delegate.provideLongObjStore(valueClass));
/*    */   }
/*    */ 
/*    */   
/*    */   public void init(StoreContext context) {
/* 65 */     this.delegate.init(context);
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Void> dispose() {
/* 70 */     return this.delegate.dispose();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\stores-api-3.2.2.jar!\discord4j\store\api\readonly\ReadOnlyStoreService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */