/*    */ package discord4j.store.api.readonly;
/*    */ 
/*    */ import discord4j.store.api.primitive.LongObjStore;
/*    */ import discord4j.store.api.util.LongObjTuple2;
/*    */ import org.reactivestreams.Publisher;
/*    */ import reactor.core.publisher.Flux;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReadOnlyLongObjStore<V>
/*    */   implements LongObjStore<V>
/*    */ {
/*    */   private final LongObjStore<V> backing;
/*    */   
/*    */   public ReadOnlyLongObjStore(LongObjStore<V> backing) {
/* 31 */     this.backing = backing;
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Void> saveWithLong(long key, V value) {
/* 36 */     return Mono.empty();
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Void> saveWithLong(Publisher<LongObjTuple2<V>> entryStream) {
/* 41 */     return Mono.empty();
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<V> find(long id) {
/* 46 */     return this.backing.find(id);
/*    */   }
/*    */ 
/*    */   
/*    */   public Flux<V> findInRange(long start, long end) {
/* 51 */     return this.backing.findInRange(start, end);
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Void> delete(long id) {
/* 56 */     return Mono.empty();
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Long> count() {
/* 61 */     return this.backing.count();
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Void> delete(Publisher<Long> ids) {
/* 66 */     return Mono.empty();
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Void> deleteAll() {
/* 71 */     return Mono.empty();
/*    */   }
/*    */ 
/*    */   
/*    */   public Flux<Long> keys() {
/* 76 */     return this.backing.keys();
/*    */   }
/*    */ 
/*    */   
/*    */   public Flux<V> values() {
/* 81 */     return this.backing.values();
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Void> invalidate() {
/* 86 */     return Mono.empty();
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Void> deleteInRange(long start, long end) {
/* 91 */     return Mono.empty();
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 96 */     return "ReadOnlyLongObjStore{backing=" + this.backing + '}';
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\stores-api-3.2.2.jar!\discord4j\store\api\readonly\ReadOnlyLongObjStore.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */