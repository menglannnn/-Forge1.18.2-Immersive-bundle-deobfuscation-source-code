/*     */ package discord4j.store.api.readonly;
/*     */ 
/*     */ import discord4j.store.api.Store;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.function.Tuple2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReadOnlyStore<K extends Comparable<K>, V>
/*     */   implements Store<K, V>
/*     */ {
/*     */   private final Store<K, V> backing;
/*     */   
/*     */   public ReadOnlyStore(Store<K, V> backing) {
/*  37 */     this.backing = backing;
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> save(K key, V value) {
/*  42 */     return Mono.empty();
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> save(Publisher<Tuple2<K, V>> entryStream) {
/*  47 */     return Mono.empty();
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<V> find(K id) {
/*  52 */     return this.backing.find((Comparable)id);
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<V> findInRange(K start, K end) {
/*  57 */     return this.backing.findInRange((Comparable)start, (Comparable)end);
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Long> count() {
/*  62 */     return this.backing.count();
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> delete(K id) {
/*  67 */     return Mono.empty();
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> delete(Publisher<K> ids) {
/*  72 */     return Mono.empty();
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> deleteInRange(K start, K end) {
/*  77 */     return Mono.empty();
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> deleteAll() {
/*  82 */     return Mono.empty();
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<K> keys() {
/*  87 */     return this.backing.keys();
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<V> values() {
/*  92 */     return this.backing.values();
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> invalidate() {
/*  97 */     return Mono.empty();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 102 */     return "ReadOnlyStore{backing=" + this.backing + '}';
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\stores-api-3.2.2.jar!\discord4j\store\api\readonly\ReadOnlyStore.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */