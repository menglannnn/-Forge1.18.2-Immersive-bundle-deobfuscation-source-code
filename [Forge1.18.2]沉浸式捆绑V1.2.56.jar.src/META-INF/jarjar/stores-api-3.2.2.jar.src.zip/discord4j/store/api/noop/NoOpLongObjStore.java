/*    */ package discord4j.store.api.noop;
/*    */ 
/*    */ import discord4j.store.api.primitive.LongObjStore;
/*    */ import discord4j.store.api.util.LongObjTuple2;
/*    */ import org.reactivestreams.Publisher;
/*    */ import reactor.core.publisher.Flux;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NoOpLongObjStore<V>
/*    */   implements LongObjStore<V>
/*    */ {
/*    */   public Mono<Void> saveWithLong(long key, V value) {
/* 35 */     return Mono.empty();
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Void> saveWithLong(Publisher<LongObjTuple2<V>> entryStream) {
/* 40 */     return Mono.empty();
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<V> find(long id) {
/* 45 */     return Mono.empty();
/*    */   }
/*    */ 
/*    */   
/*    */   public Flux<V> findInRange(long start, long end) {
/* 50 */     return Flux.empty();
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Long> count() {
/* 55 */     return Mono.just(Long.valueOf(0L));
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Void> delete(long id) {
/* 60 */     return Mono.empty();
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Void> delete(Publisher<Long> ids) {
/* 65 */     return Mono.empty();
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Void> deleteAll() {
/* 70 */     return Mono.empty();
/*    */   }
/*    */ 
/*    */   
/*    */   public Flux<Long> keys() {
/* 75 */     return Flux.empty();
/*    */   }
/*    */ 
/*    */   
/*    */   public Flux<V> values() {
/* 80 */     return Flux.empty();
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Void> invalidate() {
/* 85 */     return Mono.empty();
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Void> deleteInRange(long start, long end) {
/* 90 */     return Mono.empty();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\stores-api-3.2.2.jar!\discord4j\store\api\noop\NoOpLongObjStore.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */