/*    */ package discord4j.store.api.noop;
/*    */ 
/*    */ import discord4j.store.api.Store;
/*    */ import org.reactivestreams.Publisher;
/*    */ import reactor.core.publisher.Flux;
/*    */ import reactor.core.publisher.Mono;
/*    */ import reactor.util.function.Tuple2;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NoOpStore<K extends Comparable<K>, V>
/*    */   implements Store<K, V>
/*    */ {
/*    */   public Mono<Void> save(K key, V value) {
/* 35 */     return Mono.empty();
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Void> save(Publisher<Tuple2<K, V>> entryStream) {
/* 40 */     return Mono.empty();
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<V> find(K id) {
/* 45 */     return Mono.empty();
/*    */   }
/*    */ 
/*    */   
/*    */   public Flux<V> findInRange(K start, K end) {
/* 50 */     return Flux.empty();
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Long> count() {
/* 55 */     return Mono.just(Long.valueOf(0L));
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Void> delete(K id) {
/* 60 */     return Mono.empty();
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Void> delete(Publisher<K> ids) {
/* 65 */     return Mono.empty();
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Void> deleteInRange(K start, K end) {
/* 70 */     return Mono.empty();
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Void> deleteAll() {
/* 75 */     return Mono.empty();
/*    */   }
/*    */ 
/*    */   
/*    */   public Flux<K> keys() {
/* 80 */     return Flux.empty();
/*    */   }
/*    */ 
/*    */   
/*    */   public Flux<V> values() {
/* 85 */     return Flux.empty();
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Void> invalidate() {
/* 90 */     return Mono.empty();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\stores-api-3.2.2.jar!\discord4j\store\api\noop\NoOpStore.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */