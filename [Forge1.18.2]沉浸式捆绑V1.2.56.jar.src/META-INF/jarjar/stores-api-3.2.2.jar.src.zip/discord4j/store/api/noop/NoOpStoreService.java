/*    */ package discord4j.store.api.noop;
/*    */ 
/*    */ import discord4j.store.api.Store;
/*    */ import discord4j.store.api.primitive.LongObjStore;
/*    */ import discord4j.store.api.service.StoreService;
/*    */ import discord4j.store.api.util.StoreContext;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NoOpStoreService
/*    */   implements StoreService
/*    */ {
/*    */   public int order() {
/* 35 */     return Integer.MAX_VALUE;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean hasGenericStores() {
/* 40 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public <K extends Comparable<K>, V> Store<K, V> provideGenericStore(Class<K> keyClass, Class<V> valueClass) {
/* 46 */     return new NoOpStore<>();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean hasLongObjStores() {
/* 51 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public <V> LongObjStore<V> provideLongObjStore(Class<V> valueClass) {
/* 56 */     return new NoOpLongObjStore<>();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void init(StoreContext context) {}
/*    */ 
/*    */   
/*    */   public Mono<Void> dispose() {
/* 65 */     return Mono.empty();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\stores-api-3.2.2.jar!\discord4j\store\api\noop\NoOpStoreService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */