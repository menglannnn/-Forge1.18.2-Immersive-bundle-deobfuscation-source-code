/*    */ package discord4j.store.api.util;
/*    */ 
/*    */ import java.util.function.Predicate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WithinRangePredicate<T extends Comparable<T>>
/*    */   implements Predicate<T>
/*    */ {
/*    */   private final T start;
/*    */   private final T end;
/*    */   
/*    */   public WithinRangePredicate(T start, T end) {
/* 38 */     this.start = start;
/* 39 */     this.end = end;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean test(T t) {
/* 44 */     return (this.start.compareTo(t) <= 0 && this.end.compareTo(t) > 0);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\stores-api-3.2.2.jar!\discord4j\store\ap\\util\WithinRangePredicate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */