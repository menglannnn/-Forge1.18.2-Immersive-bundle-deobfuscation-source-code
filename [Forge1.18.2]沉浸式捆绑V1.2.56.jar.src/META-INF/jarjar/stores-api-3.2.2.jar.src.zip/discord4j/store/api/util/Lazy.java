/*    */ package discord4j.store.api.util;
/*    */ 
/*    */ import java.util.function.Supplier;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Lazy<T>
/*    */ {
/*    */   private T obj;
/*    */   private final Supplier<T> supplier;
/*    */   
/*    */   public Lazy(Supplier<T> supplier) {
/* 33 */     this.supplier = supplier;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public T get() {
/* 42 */     if (this.obj == null) this.obj = this.supplier.get(); 
/* 43 */     return this.obj;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\stores-api-3.2.2.jar!\discord4j\store\ap\\util\Lazy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */