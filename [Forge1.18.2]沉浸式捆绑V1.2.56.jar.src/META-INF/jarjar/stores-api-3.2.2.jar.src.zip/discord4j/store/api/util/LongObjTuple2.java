/*     */ package discord4j.store.api.util;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import reactor.util.annotation.NonNull;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.function.Tuple2;
/*     */ import reactor.util.function.Tuples;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LongObjTuple2<T>
/*     */   implements Iterable<Object>, Comparable<LongObjTuple2<T>>
/*     */ {
/*     */   private static final long serialVersionUID = 6977984978741213834L;
/*     */   final long t1;
/*     */   @NonNull
/*     */   final T t2;
/*     */   
/*     */   public static <T> LongObjTuple2<T> of(long t1, T t2) {
/*  47 */     return new LongObjTuple2<>(t1, t2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> LongObjTuple2<T> from(Tuple2<Long, T> tuple2) {
/*  58 */     return of(((Long)tuple2.getT1()).longValue(), (T)tuple2.getT2());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Tuple2<Long, T> convert(LongObjTuple2<T> tuple) {
/*  69 */     return Tuples.of(Long.valueOf(tuple.getT1()), tuple.getT2());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonCreator
/*     */   LongObjTuple2(@JsonProperty("t1") long t1, @JsonProperty("t2") T t2) {
/*  80 */     this.t1 = t1;
/*  81 */     this.t2 = Objects.requireNonNull(t2, "t2");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getT1() {
/*  90 */     return this.t1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T getT2() {
/*  99 */     return this.t2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object get(int index) {
/* 111 */     switch (index) {
/*     */       case 0:
/* 113 */         return Long.valueOf(this.t1);
/*     */       case 1:
/* 115 */         return this.t2;
/*     */     } 
/* 117 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Object> toList() {
/* 127 */     return Arrays.asList(toArray());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] toArray() {
/* 136 */     return new Object[] { Long.valueOf(this.t1), this.t2 };
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<Object> iterator() {
/* 141 */     return Collections.<Object>unmodifiableList(toList()).iterator();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object o) {
/* 146 */     if (this == o) {
/* 147 */       return true;
/*     */     }
/* 149 */     if (o == null || (getClass() != o.getClass() && !o.getClass().equals(Tuple2.class))) {
/* 150 */       return false;
/*     */     }
/*     */     
/* 153 */     if (o.getClass().equals(Tuple2.class)) {
/* 154 */       Tuple2<?, ?> tuple21 = (Tuple2<?, ?>)o;
/*     */       
/* 156 */       return (tuple21.getT1().equals(Long.valueOf(this.t1)) && this.t2.equals(tuple21.getT2()));
/*     */     } 
/* 158 */     LongObjTuple2<?> tuple2 = (LongObjTuple2)o;
/*     */     
/* 160 */     return (tuple2.t1 == this.t1 && this.t2.equals(tuple2.getT2()));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 166 */     int result = size();
/* 167 */     result = 31 * result + Long.hashCode(this.t1);
/* 168 */     result = 31 * result + this.t2.hashCode();
/* 169 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/* 178 */     return 2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String toString() {
/* 189 */     return tupleStringRepresentation(toArray()).insert(0, '[').append(']').toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static StringBuilder tupleStringRepresentation(Object... values) {
/* 203 */     StringBuilder sb = new StringBuilder();
/* 204 */     for (int i = 0; i < values.length; i++) {
/* 205 */       Object t = values[i];
/* 206 */       if (i != 0) {
/* 207 */         sb.append(',');
/*     */       }
/* 209 */       if (t != null) {
/* 210 */         sb.append(t);
/*     */       }
/*     */     } 
/* 213 */     return sb;
/*     */   }
/*     */ 
/*     */   
/*     */   public int compareTo(LongObjTuple2<T> o) {
/* 218 */     if (o.t1 != this.t1) {
/* 219 */       return (this.t1 < o.t1) ? -1 : 1;
/*     */     }
/*     */     
/* 222 */     if (this.t2 instanceof Comparable) {
/* 223 */       return ((Comparable<T>)this.t2).compareTo(o.t2);
/*     */     }
/*     */     
/* 226 */     return 0;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\stores-api-3.2.2.jar!\discord4j\store\ap\\util\LongObjTuple2.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */