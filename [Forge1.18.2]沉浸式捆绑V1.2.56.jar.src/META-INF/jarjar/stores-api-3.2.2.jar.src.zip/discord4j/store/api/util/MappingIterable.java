/*     */ package discord4j.store.api.util;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.Spliterator;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Function;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MappingIterable<I, O>
/*     */   implements Iterable<O>
/*     */ {
/*     */   private final Function<I, O> mapper;
/*     */   private final Iterable<I> original;
/*     */   
/*     */   public MappingIterable(Function<I, O> mapper, Iterable<I> original) {
/*  43 */     this.mapper = mapper;
/*  44 */     this.original = original;
/*     */   }
/*     */ 
/*     */   
/*     */   public void forEach(Consumer<? super O> action) {
/*  49 */     this.original.forEach(it -> {
/*     */           O mapped = this.mapper.apply((I)it);
/*     */           action.accept(mapped);
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   public Spliterator<O> spliterator() {
/*  57 */     return new MappingSpliterator(this.original.spliterator());
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<O> iterator() {
/*  62 */     return new MappingIterator(this.original.iterator());
/*     */   }
/*     */   
/*     */   private class MappingIterator
/*     */     implements Iterator<O> {
/*     */     private final Iterator<I> original;
/*     */     
/*     */     private MappingIterator(Iterator<I> original) {
/*  70 */       this.original = original;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/*  75 */       return this.original.hasNext();
/*     */     }
/*     */ 
/*     */     
/*     */     public O next() {
/*  80 */       return (O)MappingIterable.this.mapper.apply(this.original.next());
/*     */     }
/*     */ 
/*     */     
/*     */     public void remove() {
/*  85 */       this.original.remove();
/*     */     }
/*     */ 
/*     */     
/*     */     public void forEachRemaining(Consumer<? super O> action) {
/*  90 */       this.original.forEachRemaining(it -> {
/*     */             O mapped = (O)MappingIterable.this.mapper.apply(it);
/*     */             action.accept(mapped);
/*     */           });
/*     */     }
/*     */   }
/*     */   
/*     */   private class MappingSpliterator
/*     */     implements Spliterator<O> {
/*     */     private final Spliterator<I> original;
/*     */     
/*     */     private MappingSpliterator(Spliterator<I> original) {
/* 102 */       this.original = original;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean tryAdvance(Consumer<? super O> action) {
/* 107 */       return this.original.tryAdvance(it -> {
/*     */             O mapped = (O)MappingIterable.this.mapper.apply(it);
/*     */             action.accept(mapped);
/*     */           });
/*     */     }
/*     */ 
/*     */     
/*     */     public void forEachRemaining(Consumer<? super O> action) {
/* 115 */       this.original.forEachRemaining(it -> {
/*     */             O mapped = (O)MappingIterable.this.mapper.apply(it);
/*     */             action.accept(mapped);
/*     */           });
/*     */     }
/*     */ 
/*     */     
/*     */     public Spliterator<O> trySplit() {
/* 123 */       return new MappingSpliterator(this.original.trySplit());
/*     */     }
/*     */ 
/*     */     
/*     */     public long estimateSize() {
/* 128 */       return this.original.estimateSize();
/*     */     }
/*     */ 
/*     */     
/*     */     public long getExactSizeIfKnown() {
/* 133 */       return this.original.getExactSizeIfKnown();
/*     */     }
/*     */ 
/*     */     
/*     */     public int characteristics() {
/* 138 */       return this.original.characteristics();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasCharacteristics(int characteristics) {
/* 143 */       return this.original.hasCharacteristics(characteristics);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\stores-api-3.2.2.jar!\discord4j\store\ap\\util\MappingIterable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */