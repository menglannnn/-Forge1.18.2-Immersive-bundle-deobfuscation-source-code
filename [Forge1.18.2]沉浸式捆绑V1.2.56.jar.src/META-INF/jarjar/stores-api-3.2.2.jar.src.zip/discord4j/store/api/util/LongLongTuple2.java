/*     */ package discord4j.store.api.util;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.function.Tuple2;
/*     */ import reactor.util.function.Tuples;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LongLongTuple2
/*     */   implements Iterable<Long>, Comparable<LongLongTuple2>
/*     */ {
/*     */   private static final long serialVersionUID = 6977984978741213834L;
/*     */   final long t1;
/*     */   final long t2;
/*     */   
/*     */   public static LongLongTuple2 of(long t1, long t2) {
/*  47 */     return new LongLongTuple2(t1, t2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LongLongTuple2 from(Tuple2<Long, Long> tuple2) {
/*  57 */     return of(((Long)tuple2.getT1()).longValue(), ((Long)tuple2.getT2()).longValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Tuple2<Long, Long> convert(LongLongTuple2 tuple) {
/*  67 */     return Tuples.of(Long.valueOf(tuple.getT1()), Long.valueOf(tuple.getT2()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonCreator
/*     */   LongLongTuple2(@JsonProperty("t1") long t1, @JsonProperty("t2") long t2) {
/*  77 */     this.t1 = t1;
/*  78 */     this.t2 = t2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getT1() {
/*  87 */     return this.t1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getT2() {
/*  96 */     return this.t2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long get(int index) {
/* 108 */     switch (index) {
/*     */       case 0:
/* 110 */         return this.t1;
/*     */       case 1:
/* 112 */         return this.t2;
/*     */     } 
/* 114 */     throw new IndexOutOfBoundsException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Long> toList() {
/* 124 */     List<Long> list = new ArrayList<>();
/* 125 */     list.add(Long.valueOf(this.t1));
/* 126 */     list.add(Long.valueOf(this.t2));
/* 127 */     return list;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long[] toArray() {
/* 136 */     return new long[] { this.t1, this.t2 };
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<Long> iterator() {
/* 141 */     return Collections.<Long>unmodifiableList(toList()).iterator();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object o) {
/* 146 */     if (this == o) {
/* 147 */       return true;
/*     */     }
/* 149 */     if (o == null || (getClass() != o.getClass() && !o.getClass().equals(Tuple2.class))) {
/* 150 */       return false;
/*     */     }
/*     */     
/* 153 */     if (o.getClass().equals(Tuple2.class)) {
/* 154 */       Tuple2<?, ?> tuple21 = (Tuple2<?, ?>)o;
/*     */       
/* 156 */       return (tuple21.getT1().equals(Long.valueOf(this.t1)) && tuple21.getT2().equals(Long.valueOf(this.t2)));
/*     */     } 
/* 158 */     LongLongTuple2 tuple2 = (LongLongTuple2)o;
/*     */     
/* 160 */     return (tuple2.t1 == this.t1 && tuple2.t2 == this.t2);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 166 */     int result = size();
/* 167 */     result = 31 * result + Long.hashCode(this.t1);
/* 168 */     result = 31 * result + Long.hashCode(this.t2);
/* 169 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/* 178 */     return 2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String toString() {
/* 189 */     return tupleStringRepresentation(new Object[] { Long.valueOf(this.t1), Long.valueOf(this.t2) }).insert(0, '[').append(']').toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static StringBuilder tupleStringRepresentation(Object... values) {
/* 203 */     StringBuilder sb = new StringBuilder();
/* 204 */     for (int i = 0; i < values.length; i++) {
/* 205 */       Object t = values[i];
/* 206 */       if (i != 0) {
/* 207 */         sb.append(',');
/*     */       }
/* 209 */       if (t != null) {
/* 210 */         sb.append(t);
/*     */       }
/*     */     } 
/* 213 */     return sb;
/*     */   }
/*     */ 
/*     */   
/*     */   public int compareTo(LongLongTuple2 o) {
/* 218 */     if (o.t1 == this.t1 && o.t2 == this.t2) {
/* 219 */       return 0;
/*     */     }
/*     */     
/* 222 */     if (o.t1 != this.t1) {
/* 223 */       return (this.t1 < o.t1) ? -1 : 1;
/*     */     }
/*     */     
/* 226 */     return (this.t2 < o.t2) ? -1 : 1;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\stores-api-3.2.2.jar!\discord4j\store\ap\\util\LongLongTuple2.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */