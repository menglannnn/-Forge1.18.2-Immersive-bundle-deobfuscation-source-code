/*     */ package discord4j.store.api.primitive;
/*     */ 
/*     */ import discord4j.store.api.Store;
/*     */ import discord4j.store.api.util.LongObjTuple2;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.function.Tuple2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface LongObjStore<V>
/*     */   extends Store<Long, V>
/*     */ {
/*     */   default Mono<Void> save(Long key, V value) {
/*  38 */     return saveWithLong(key.longValue(), value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Mono<Void> save(Publisher<Tuple2<Long, V>> entryStream) {
/*  52 */     return saveWithLong((Publisher<LongObjTuple2<V>>)Flux.from(entryStream).map(LongObjTuple2::from));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Mono<V> find(Long id) {
/*  65 */     return find(id.longValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Flux<V> findInRange(Long start, Long end) {
/*  78 */     return findInRange(start.longValue(), end.longValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Mono<Void> delete(Long id) {
/*  92 */     return delete(id.longValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Mono<Void> deleteInRange(Long start, Long end) {
/* 108 */     return deleteInRange(start.longValue(), end.longValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Flux<Tuple2<Long, V>> entries() {
/* 122 */     return super.entries();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Flux<LongObjTuple2<V>> longObjEntries() {
/* 131 */     return entries().map(LongObjTuple2::from);
/*     */   }
/*     */   
/*     */   Mono<Void> saveWithLong(long paramLong, V paramV);
/*     */   
/*     */   Mono<Void> saveWithLong(Publisher<LongObjTuple2<V>> paramPublisher);
/*     */   
/*     */   Mono<V> find(long paramLong);
/*     */   
/*     */   Flux<V> findInRange(long paramLong1, long paramLong2);
/*     */   
/*     */   Mono<Void> delete(long paramLong);
/*     */   
/*     */   Mono<Void> delete(Publisher<Long> paramPublisher);
/*     */   
/*     */   Mono<Void> deleteInRange(long paramLong1, long paramLong2);
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\stores-api-3.2.2.jar!\discord4j\store\api\primitive\LongObjStore.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */