/*    */ package discord4j.store.api.primitive;
/*    */ 
/*    */ import discord4j.store.api.Store;
/*    */ import discord4j.store.api.service.StoreService;
/*    */ import discord4j.store.api.util.StoreContext;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ForwardingStoreService
/*    */   implements StoreService
/*    */ {
/*    */   private final StoreService toForward;
/*    */   
/*    */   public ForwardingStoreService(StoreService toForward) {
/* 39 */     this.toForward = toForward;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public StoreService getOriginal() {
/* 48 */     return this.toForward;
/*    */   }
/*    */ 
/*    */   
/*    */   public int order() {
/* 53 */     return this.toForward.order();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean hasGenericStores() {
/* 58 */     return getOriginal().hasGenericStores();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public <K extends Comparable<K>, V> Store<K, V> provideGenericStore(Class<K> keyClass, Class<V> valueClass) {
/* 64 */     return getOriginal().provideGenericStore(keyClass, valueClass);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean hasLongObjStores() {
/* 69 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public <V> LongObjStore<V> provideLongObjStore(Class<V> valueClass) {
/* 74 */     return new ForwardingStore<>(getOriginal().provideGenericStore(Long.class, valueClass));
/*    */   }
/*    */ 
/*    */   
/*    */   public void init(StoreContext context) {
/* 79 */     this.toForward.init(context);
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Void> dispose() {
/* 84 */     return this.toForward.dispose();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\stores-api-3.2.2.jar!\discord4j\store\api\primitive\ForwardingStoreService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */