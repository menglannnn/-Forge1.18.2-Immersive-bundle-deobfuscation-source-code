/*     */ package discord4j.store.api.primitive;
/*     */ 
/*     */ import discord4j.store.api.Store;
/*     */ import discord4j.store.api.util.LongObjTuple2;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.function.Tuple2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ForwardingStore<V>
/*     */   implements LongObjStore<V>
/*     */ {
/*     */   private final Store<Long, V> toForward;
/*     */   
/*     */   public ForwardingStore(Store<Long, V> toForward) {
/*  42 */     this.toForward = toForward;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Store<Long, V> getOriginal() {
/*  51 */     return this.toForward;
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> save(Long key, V value) {
/*  56 */     return this.toForward.save(key, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> saveWithLong(long key, V value) {
/*  61 */     return save(Long.valueOf(key), value);
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> save(Publisher<Tuple2<Long, V>> entryStream) {
/*  66 */     return this.toForward.save(entryStream);
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> saveWithLong(Publisher<LongObjTuple2<V>> entryStream) {
/*  71 */     return save((Publisher<Tuple2<Long, V>>)Flux.from(entryStream).map(LongObjTuple2::convert));
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<V> find(Long id) {
/*  76 */     return this.toForward.find(id);
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<V> find(long id) {
/*  81 */     return find(Long.valueOf(id));
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<V> findInRange(Long start, Long end) {
/*  86 */     return this.toForward.findInRange(start, end);
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<V> findInRange(long start, long end) {
/*  91 */     return findInRange(Long.valueOf(start), Long.valueOf(end));
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Long> count() {
/*  96 */     return this.toForward.count();
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> delete(Long id) {
/* 101 */     return this.toForward.delete(id);
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> delete(long id) {
/* 106 */     return delete(Long.valueOf(id));
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> delete(Publisher<Long> ids) {
/* 111 */     return this.toForward.delete(ids);
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> deleteInRange(Long start, Long end) {
/* 116 */     return this.toForward.deleteInRange(start, end);
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> deleteInRange(long start, long end) {
/* 121 */     return deleteInRange(Long.valueOf(start), Long.valueOf(end));
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> deleteAll() {
/* 126 */     return this.toForward.deleteAll();
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<Long> keys() {
/* 131 */     return this.toForward.keys();
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<V> values() {
/* 136 */     return this.toForward.values();
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<Tuple2<Long, V>> entries() {
/* 141 */     return this.toForward.entries();
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> invalidate() {
/* 146 */     return this.toForward.invalidate();
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<LongObjTuple2<V>> longObjEntries() {
/* 151 */     return entries().map(LongObjTuple2::from);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 156 */     return "ForwardingStore{forwardingTo=" + this.toForward + '}';
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\stores-api-3.2.2.jar!\discord4j\store\api\primitive\ForwardingStore.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */