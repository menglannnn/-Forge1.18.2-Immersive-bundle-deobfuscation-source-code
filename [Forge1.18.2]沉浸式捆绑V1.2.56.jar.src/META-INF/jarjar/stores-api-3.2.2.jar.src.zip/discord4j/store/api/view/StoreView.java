/*    */ package discord4j.store.api.view;
/*    */ 
/*    */ import discord4j.store.api.Store;
/*    */ import reactor.core.publisher.Flux;
/*    */ import reactor.core.publisher.Mono;
/*    */ import reactor.util.function.Tuple2;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StoreView<K extends Comparable<K>, V>
/*    */ {
/*    */   private final Store<K, V> backing;
/*    */   
/*    */   public StoreView(Store<K, V> backing) {
/* 30 */     this.backing = backing;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Mono<V> find(K id) {
/* 40 */     return this.backing.find((Comparable)id);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Flux<V> findInRange(K start, K end) {
/* 51 */     return this.backing.findInRange((Comparable)start, (Comparable)end);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Mono<Long> count() {
/* 60 */     return this.backing.count();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Flux<K> keys() {
/* 69 */     return this.backing.keys();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Flux<V> values() {
/* 78 */     return this.backing.values();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Flux<Tuple2<K, V>> entries() {
/* 87 */     return this.backing.entries();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\stores-api-3.2.2.jar!\discord4j\store\api\view\StoreView.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */