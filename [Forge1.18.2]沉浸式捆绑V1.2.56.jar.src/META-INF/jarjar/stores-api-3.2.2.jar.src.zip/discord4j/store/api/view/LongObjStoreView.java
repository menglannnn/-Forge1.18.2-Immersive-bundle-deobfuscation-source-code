/*    */ package discord4j.store.api.view;
/*    */ 
/*    */ import discord4j.store.api.primitive.LongObjStore;
/*    */ import discord4j.store.api.util.LongObjTuple2;
/*    */ import reactor.core.publisher.Flux;
/*    */ import reactor.core.publisher.Mono;
/*    */ import reactor.util.function.Tuple2;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LongObjStoreView<V>
/*    */ {
/*    */   private final LongObjStore<V> backing;
/*    */   
/*    */   public LongObjStoreView(LongObjStore<V> backing) {
/* 31 */     this.backing = backing;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Mono<V> find(long id) {
/* 41 */     return this.backing.find(id);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Flux<V> findInRange(long start, long end) {
/* 52 */     return this.backing.findInRange(start, end);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Mono<Long> count() {
/* 61 */     return this.backing.count();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Flux<Long> keys() {
/* 70 */     return this.backing.keys();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Flux<V> values() {
/* 79 */     return this.backing.values();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Flux<Tuple2<Long, V>> entries() {
/* 88 */     return this.backing.entries();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Flux<LongObjTuple2<V>> longObjEntries() {
/* 97 */     return this.backing.longObjEntries();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\stores-api-3.2.2.jar!\discord4j\store\api\view\LongObjStoreView.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */