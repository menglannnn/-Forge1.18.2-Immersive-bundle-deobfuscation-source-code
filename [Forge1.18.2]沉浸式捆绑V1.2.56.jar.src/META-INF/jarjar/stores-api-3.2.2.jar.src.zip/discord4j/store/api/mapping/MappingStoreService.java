/*     */ package discord4j.store.api.mapping;
/*     */ 
/*     */ import discord4j.store.api.Store;
/*     */ import discord4j.store.api.noop.NoOpStoreService;
/*     */ import discord4j.store.api.primitive.LongObjStore;
/*     */ import discord4j.store.api.service.StoreService;
/*     */ import discord4j.store.api.util.StoreContext;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MappingStoreService
/*     */   implements StoreService
/*     */ {
/*     */   private final Map<Class<?>, StoreService> serviceMap;
/*     */   private final StoreService fallback;
/*     */   
/*     */   private MappingStoreService(Map<Class<?>, StoreService> serviceMap, @Nullable StoreService fallback) {
/*  52 */     this.serviceMap = serviceMap;
/*  53 */     this.fallback = (fallback == null) ? (StoreService)new NoOpStoreService() : fallback;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MappingStoreService create() {
/*  64 */     return new MappingStoreService(new ConcurrentHashMap<>(), null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MappingStoreService setMapping(StoreService storeService, Class<?> valueClass) {
/*  75 */     Map<Class<?>, StoreService> updatedMap = new ConcurrentHashMap<>(this.serviceMap);
/*  76 */     updatedMap.put(valueClass, storeService);
/*  77 */     return new MappingStoreService(updatedMap, this.fallback);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MappingStoreService setMappings(StoreService storeService, Class<?>... valueClasses) {
/*  88 */     Map<Class<?>, StoreService> updatedMap = new ConcurrentHashMap<>(this.serviceMap);
/*  89 */     for (Class<?> valueClass : valueClasses) {
/*  90 */       updatedMap.put(valueClass, storeService);
/*     */     }
/*  92 */     return new MappingStoreService(updatedMap, this.fallback);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MappingStoreService setFallback(@Nullable StoreService storeService) {
/* 102 */     return new MappingStoreService(this.serviceMap, storeService);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasGenericStores() {
/* 107 */     return (this.serviceMap.values().stream().anyMatch(StoreService::hasGenericStores) || this.fallback.hasGenericStores());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <K extends Comparable<K>, V> Store<K, V> provideGenericStore(Class<K> keyClass, Class<V> valueClass) {
/* 113 */     return getGenericStore(valueClass).provideGenericStore(keyClass, valueClass);
/*     */   }
/*     */   
/*     */   private <V> StoreService getGenericStore(Class<V> valueClass) {
/* 117 */     StoreService service = this.serviceMap.getOrDefault(valueClass, this.fallback);
/* 118 */     return service.hasGenericStores() ? service : this.fallback;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasLongObjStores() {
/* 123 */     return (this.serviceMap.values().stream().anyMatch(StoreService::hasLongObjStores) || this.fallback.hasLongObjStores());
/*     */   }
/*     */ 
/*     */   
/*     */   public <V> LongObjStore<V> provideLongObjStore(Class<V> valueClass) {
/* 128 */     return getLongObjStore(valueClass).provideLongObjStore(valueClass);
/*     */   }
/*     */   
/*     */   private <V> StoreService getLongObjStore(Class<V> valueClass) {
/* 132 */     StoreService service = this.serviceMap.getOrDefault(valueClass, this.fallback);
/* 133 */     return service.hasLongObjStores() ? service : this.fallback;
/*     */   }
/*     */ 
/*     */   
/*     */   public void init(StoreContext context) {
/* 138 */     this.serviceMap.values().forEach(service -> service.init(context));
/* 139 */     this.fallback.init(context);
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> dispose() {
/* 144 */     return Flux.fromIterable(this.serviceMap.values())
/* 145 */       .concatWithValues((Object[])new StoreService[] { this.fallback
/* 146 */         }).flatMap(StoreService::dispose)
/* 147 */       .then();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\stores-api-3.2.2.jar!\discord4j\store\api\mapping\MappingStoreService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */