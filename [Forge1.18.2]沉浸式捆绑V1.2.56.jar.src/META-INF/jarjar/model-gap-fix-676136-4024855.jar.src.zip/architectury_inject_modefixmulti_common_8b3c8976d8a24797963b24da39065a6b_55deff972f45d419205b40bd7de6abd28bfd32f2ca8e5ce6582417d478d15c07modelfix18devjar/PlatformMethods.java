package architectury_inject_modefixmulti_common_8b3c8976d8a24797963b24da39065a6b_55deff972f45d419205b40bd7de6abd28bfd32f2ca8e5ce6582417d478d15c07modelfix18devjar;

public final class PlatformMethods {
  public static String getCurrentTarget() {
    return "forge";
  }
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\model-gap-fix-676136-4024855.jar!\architectury_inject_modefixmulti_common_8b3c8976d8a24797963b24da39065a6b_55deff972f45d419205b40bd7de6abd28bfd32f2ca8e5ce6582417d478d15c07modelfix18devjar\PlatformMethods.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */