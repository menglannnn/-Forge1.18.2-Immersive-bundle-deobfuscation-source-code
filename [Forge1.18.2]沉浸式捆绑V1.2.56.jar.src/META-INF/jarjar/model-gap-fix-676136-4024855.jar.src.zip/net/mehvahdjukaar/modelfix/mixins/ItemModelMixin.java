/*    */ package net.mehvahdjukaar.modelfix.mixins;
/*    */ 
/*    */ import java.util.List;
/*    */ import net.mehvahdjukaar.modelfix.ModelFix;
/*    */ import net.minecraft.client.renderer.block.model.BlockElement;
/*    */ import net.minecraft.client.renderer.block.model.ItemModelGenerator;
/*    */ import net.minecraft.client.renderer.texture.TextureAtlasSprite;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Overwrite;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/*    */ 
/*    */ 
/*    */ @Mixin({ItemModelGenerator.class})
/*    */ public abstract class ItemModelMixin
/*    */ {
/*    */   @Shadow
/*    */   protected abstract boolean m_111654_(TextureAtlasSprite paramTextureAtlasSprite, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5);
/*    */   
/*    */   @Inject(method = {"createSideElements"}, at = {@At("RETURN")})
/*    */   public void increaseSide(TextureAtlasSprite sprite, String texture, int tintIndex, CallbackInfoReturnable<List<BlockElement>> cir) {
/* 24 */     ModelFix.enlargeFaces(cir);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Overwrite
/*    */   private void m_111665_(List<ItemModelGenerator.Span> listSpans, ItemModelGenerator.SpanFacing spanFacing, int pixelX, int pixelY) {
/* 33 */     ModelFix.createOrExpandSpan(listSpans, spanFacing, pixelX, pixelY);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\model-gap-fix-676136-4024855.jar!\net\mehvahdjukaar\modelfix\mixins\ItemModelMixin.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */