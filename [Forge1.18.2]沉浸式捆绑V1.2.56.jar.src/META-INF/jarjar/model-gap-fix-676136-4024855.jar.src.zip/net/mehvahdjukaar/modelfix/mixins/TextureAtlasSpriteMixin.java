/*    */ package net.mehvahdjukaar.modelfix.mixins;
/*    */ 
/*    */ import net.mehvahdjukaar.modelfix.ModelFix;
/*    */ import net.minecraft.client.renderer.texture.TextureAtlas;
/*    */ import net.minecraft.client.renderer.texture.TextureAtlasSprite;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({TextureAtlasSprite.class})
/*    */ public abstract class TextureAtlasSpriteMixin
/*    */ {
/*    */   @Shadow
/*    */   public abstract TextureAtlas m_118414_();
/*    */   
/*    */   @Shadow
/*    */   protected abstract float m_118366_();
/*    */   
/*    */   @Inject(method = {"uvShrinkRatio"}, at = {@At("RETURN")}, cancellable = true)
/*    */   public void cancelShrink(CallbackInfoReturnable<Float> cir) {
/* 25 */     float newS = ModelFix.getShrinkRatio(m_118414_(), 4.0F / m_118366_(), cir.getReturnValueF());
/* 26 */     if (newS != -1.0F) cir.setReturnValue(Float.valueOf(newS)); 
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\model-gap-fix-676136-4024855.jar!\net\mehvahdjukaar\modelfix\mixins\TextureAtlasSpriteMixin.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */