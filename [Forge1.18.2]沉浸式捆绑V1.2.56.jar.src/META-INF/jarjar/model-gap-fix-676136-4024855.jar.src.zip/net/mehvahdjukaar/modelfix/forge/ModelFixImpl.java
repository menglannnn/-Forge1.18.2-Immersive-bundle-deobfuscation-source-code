/*    */ package net.mehvahdjukaar.modelfix.forge;
/*    */ 
/*    */ import net.minecraftforge.common.ForgeConfigSpec;
/*    */ import net.minecraftforge.fml.ModLoadingContext;
/*    */ import net.minecraftforge.fml.common.Mod;
/*    */ import net.minecraftforge.fml.config.IConfigSpec;
/*    */ import net.minecraftforge.fml.config.ModConfig;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mod("modelfix")
/*    */ public class ModelFixImpl
/*    */ {
/*    */   private static ForgeConfigSpec.DoubleValue EXPANSION;
/*    */   public static ForgeConfigSpec.DoubleValue RECESS;
/*    */   
/*    */   public ModelFixImpl() {
/* 32 */     ForgeConfigSpec.Builder builder = new ForgeConfigSpec.Builder();
/*    */ 
/*    */     
/* 35 */     RECESS = builder.comment("quad x/y offset. simply put moves the quad toward the center of the item. Use to hide gaps").defineInRange("quad_recess", 0.007D, -0.1D, 0.1D);
/*    */     
/* 37 */     EXPANSION = builder.comment("quad expansion increment. enlarges each quad. Use to hide gaps. Keep both as close to 0 as possible").defineInRange("quad_expansion", 0.008D, -0.1D, 0.1D);
/*    */     
/* 39 */     ModLoadingContext.get().registerConfig(ModConfig.Type.CLIENT, (IConfigSpec)builder.build());
/*    */   }
/*    */   
/*    */   public static double getRecess() {
/* 43 */     return ((Double)RECESS.get()).doubleValue();
/*    */   }
/*    */   public static double getExpansion() {
/* 46 */     return ((Double)EXPANSION.get()).doubleValue();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\model-gap-fix-676136-4024855.jar!\net\mehvahdjukaar\modelfix\forge\ModelFixImpl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */