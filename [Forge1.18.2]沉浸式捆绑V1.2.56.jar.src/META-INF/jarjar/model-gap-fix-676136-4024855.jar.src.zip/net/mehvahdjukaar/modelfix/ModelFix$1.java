/*    */ package net.mehvahdjukaar.modelfix;
/*    */ 
/*    */ import net.minecraft.core.Direction;
/*    */ 


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\model-gap-fix-676136-4024855.jar!\net\mehvahdjukaar\modelfix\ModelFix$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */