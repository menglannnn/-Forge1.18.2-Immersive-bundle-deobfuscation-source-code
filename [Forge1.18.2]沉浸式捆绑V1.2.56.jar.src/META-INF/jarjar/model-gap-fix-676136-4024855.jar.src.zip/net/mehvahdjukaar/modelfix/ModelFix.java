/*    */ package net.mehvahdjukaar.modelfix;
/*    */ 
/*    */ import com.mojang.math.Vector3f;
/*    */ import dev.architectury.injectables.annotations.ExpectPlatform;
/*    */ import dev.architectury.injectables.annotations.ExpectPlatform.Transformed;
/*    */ import java.util.List;
/*    */ import java.util.Set;
/*    */ import net.mehvahdjukaar.modelfix.forge.ModelFixImpl;
/*    */ import net.minecraft.client.renderer.block.model.BlockElement;
/*    */ import net.minecraft.client.renderer.block.model.ItemModelGenerator;
/*    */ import net.minecraft.client.renderer.texture.TextureAtlas;
/*    */ import net.minecraft.core.Direction;
/*    */ import net.minecraft.resources.ResourceLocation;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/*    */ 
/*    */ public class ModelFix
/*    */ {
/*    */   public static final String MOD_ID = "modelfix";
/* 19 */   private static final ResourceLocation BLOCK_ATLAS = new ResourceLocation("textures/atlas/blocks.png");
/*    */   
/*    */   public static float getShrinkRatio(TextureAtlas atlas, float defaultValue, float returnValue) {
/* 22 */     if (atlas.m_118330_().equals(BLOCK_ATLAS) && defaultValue == returnValue) {
/* 23 */       return 0.0F;
/*    */     }
/* 25 */     return -1.0F;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @ExpectPlatform
/*    */   @Transformed
/*    */   public static double getRecess() {
/*    */     return ModelFixImpl.getRecess();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static void createOrExpandSpan(List<ItemModelGenerator.Span> listSpans, ItemModelGenerator.SpanFacing spanFacing, int pixelX, int pixelY) {
/* 40 */     ItemModelGenerator.Span existingSpan = null;
/* 41 */     for (ItemModelGenerator.Span span2 : listSpans) {
/* 42 */       if (span2.m_111683_() == spanFacing) {
/* 43 */         int i = spanFacing.m_111709_() ? pixelY : pixelX;
/* 44 */         if (span2.m_111688_() != i)
/*    */           continue; 
/* 46 */         if (getExpansion() != 0.0D && span2.m_111687_() != (!spanFacing.m_111709_() ? pixelY : pixelX) - 1)
/*    */           continue; 
/* 48 */         existingSpan = span2;
/*    */         
/*    */         break;
/*    */       } 
/*    */     } 
/*    */     
/* 54 */     int length = spanFacing.m_111709_() ? pixelX : pixelY;
/* 55 */     if (existingSpan == null) {
/* 56 */       int newStart = spanFacing.m_111709_() ? pixelY : pixelX;
/* 57 */       listSpans.add(new ItemModelGenerator.Span(spanFacing, length, newStart));
/*    */     } else {
/* 59 */       existingSpan.m_111684_(length);
/*    */     } 
/*    */   } @ExpectPlatform
/*    */   @Transformed
/*    */   public static double getExpansion() { return ModelFixImpl.getExpansion(); } public static void enlargeFaces(CallbackInfoReturnable<List<BlockElement>> cir) {
/* 64 */     float inc = (float)getRecess();
/* 65 */     float inc2 = (float)getExpansion();
/* 66 */     for (BlockElement e : cir.getReturnValue()) {
/* 67 */       Vector3f from = e.f_111308_;
/* 68 */       Vector3f to = e.f_111309_;
/*    */       
/* 70 */       Set<Direction> set = e.f_111310_.keySet();
/* 71 */       if (set.size() == 1) {
/* 72 */         Direction dir = set.stream().findAny().get();
/* 73 */         switch (dir) {
/*    */           case UP:
/* 75 */             from.m_122245_(from.m_122239_() - inc2, from.m_122260_() - inc, from.m_122269_() - inc2);
/* 76 */             to.m_122245_(to.m_122239_() + inc2, to.m_122260_() - inc, to.m_122269_() + inc2);
/*    */           
/*    */           case DOWN:
/* 79 */             from.m_122245_(from.m_122239_() - inc2, from.m_122260_() + inc, from.m_122269_() - inc2);
/* 80 */             to.m_122245_(to.m_122239_() + inc2, to.m_122260_() + inc, to.m_122269_() + inc2);
/*    */           
/*    */           case WEST:
/* 83 */             from.m_122245_(from.m_122239_() - inc, from.m_122260_() + inc2, from.m_122269_() - inc2);
/* 84 */             to.m_122245_(to.m_122239_() - inc, to.m_122260_() - inc2, to.m_122269_() + inc2);
/*    */           
/*    */           case EAST:
/* 87 */             from.m_122245_(from.m_122239_() + inc, from.m_122260_() + inc2, from.m_122269_() - inc2);
/* 88 */             to.m_122245_(to.m_122239_() + inc, to.m_122260_() - inc2, to.m_122269_() + inc2);
/*    */         } 
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\model-gap-fix-676136-4024855.jar!\net\mehvahdjukaar\modelfix\ModelFix.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */