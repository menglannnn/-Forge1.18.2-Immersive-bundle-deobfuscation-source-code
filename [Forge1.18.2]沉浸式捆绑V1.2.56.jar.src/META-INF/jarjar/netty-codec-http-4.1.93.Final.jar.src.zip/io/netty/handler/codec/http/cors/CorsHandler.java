/*     */ package io.netty.handler.codec.http.cors;
/*     */ 
/*     */ import io.netty.channel.ChannelDuplexHandler;
/*     */ import io.netty.channel.ChannelFuture;
/*     */ import io.netty.channel.ChannelFutureListener;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.channel.ChannelPromise;
/*     */ import io.netty.handler.codec.http.DefaultFullHttpResponse;
/*     */ import io.netty.handler.codec.http.HttpHeaderNames;
/*     */ import io.netty.handler.codec.http.HttpHeaderValues;
/*     */ import io.netty.handler.codec.http.HttpHeaders;
/*     */ import io.netty.handler.codec.http.HttpMessage;
/*     */ import io.netty.handler.codec.http.HttpMethod;
/*     */ import io.netty.handler.codec.http.HttpRequest;
/*     */ import io.netty.handler.codec.http.HttpResponse;
/*     */ import io.netty.handler.codec.http.HttpResponseStatus;
/*     */ import io.netty.handler.codec.http.HttpUtil;
/*     */ import io.netty.util.ReferenceCountUtil;
/*     */ import io.netty.util.concurrent.GenericFutureListener;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import io.netty.util.internal.logging.InternalLogger;
/*     */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CorsHandler
/*     */   extends ChannelDuplexHandler
/*     */ {
/*  51 */   private static final InternalLogger logger = InternalLoggerFactory.getInstance(CorsHandler.class);
/*     */   
/*     */   private static final String ANY_ORIGIN = "*";
/*     */   
/*     */   private static final String NULL_ORIGIN = "null";
/*     */   
/*     */   private CorsConfig config;
/*     */   
/*     */   private HttpRequest request;
/*     */   private final List<CorsConfig> configList;
/*     */   private final boolean isShortCircuit;
/*     */   
/*     */   public CorsHandler(CorsConfig config) {
/*  64 */     this(Collections.singletonList(ObjectUtil.checkNotNull(config, "config")), config.isShortCircuit());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CorsHandler(List<CorsConfig> configList, boolean isShortCircuit) {
/*  75 */     ObjectUtil.checkNonEmpty(configList, "configList");
/*  76 */     this.configList = configList;
/*  77 */     this.isShortCircuit = isShortCircuit;
/*     */   }
/*     */ 
/*     */   
/*     */   public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
/*  82 */     if (msg instanceof HttpRequest) {
/*  83 */       this.request = (HttpRequest)msg;
/*  84 */       String origin = this.request.headers().get((CharSequence)HttpHeaderNames.ORIGIN);
/*  85 */       this.config = getForOrigin(origin);
/*  86 */       if (isPreflightRequest(this.request)) {
/*  87 */         handlePreflight(ctx, this.request);
/*     */         return;
/*     */       } 
/*  90 */       if (this.isShortCircuit && origin != null && this.config == null) {
/*  91 */         forbidden(ctx, this.request);
/*     */         return;
/*     */       } 
/*     */     } 
/*  95 */     ctx.fireChannelRead(msg);
/*     */   }
/*     */   
/*     */   private void handlePreflight(ChannelHandlerContext ctx, HttpRequest request) {
/*  99 */     DefaultFullHttpResponse defaultFullHttpResponse = new DefaultFullHttpResponse(request.protocolVersion(), HttpResponseStatus.OK, true, true);
/* 100 */     if (setOrigin((HttpResponse)defaultFullHttpResponse)) {
/* 101 */       setAllowMethods((HttpResponse)defaultFullHttpResponse);
/* 102 */       setAllowHeaders((HttpResponse)defaultFullHttpResponse);
/* 103 */       setAllowCredentials((HttpResponse)defaultFullHttpResponse);
/* 104 */       setMaxAge((HttpResponse)defaultFullHttpResponse);
/* 105 */       setPreflightHeaders((HttpResponse)defaultFullHttpResponse);
/* 106 */       setAllowPrivateNetwork((HttpResponse)defaultFullHttpResponse);
/*     */     } 
/* 108 */     if (!defaultFullHttpResponse.headers().contains((CharSequence)HttpHeaderNames.CONTENT_LENGTH)) {
/* 109 */       defaultFullHttpResponse.headers().set((CharSequence)HttpHeaderNames.CONTENT_LENGTH, HttpHeaderValues.ZERO);
/*     */     }
/* 111 */     ReferenceCountUtil.release(request);
/* 112 */     respond(ctx, request, (HttpResponse)defaultFullHttpResponse);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setPreflightHeaders(HttpResponse response) {
/* 122 */     response.headers().add(this.config.preflightResponseHeaders());
/*     */   }
/*     */   
/*     */   private CorsConfig getForOrigin(String requestOrigin) {
/* 126 */     for (CorsConfig corsConfig : this.configList) {
/* 127 */       if (corsConfig.isAnyOriginSupported()) {
/* 128 */         return corsConfig;
/*     */       }
/* 130 */       if (corsConfig.origins().contains(requestOrigin)) {
/* 131 */         return corsConfig;
/*     */       }
/* 133 */       if (corsConfig.isNullOriginAllowed() || "null".equals(requestOrigin)) {
/* 134 */         return corsConfig;
/*     */       }
/*     */     } 
/* 137 */     return null;
/*     */   }
/*     */   
/*     */   private boolean setOrigin(HttpResponse response) {
/* 141 */     String origin = this.request.headers().get((CharSequence)HttpHeaderNames.ORIGIN);
/* 142 */     if (origin != null && this.config != null) {
/* 143 */       if ("null".equals(origin) && this.config.isNullOriginAllowed()) {
/* 144 */         setNullOrigin(response);
/* 145 */         return true;
/*     */       } 
/* 147 */       if (this.config.isAnyOriginSupported()) {
/* 148 */         if (this.config.isCredentialsAllowed()) {
/* 149 */           echoRequestOrigin(response);
/* 150 */           setVaryHeader(response);
/*     */         } else {
/* 152 */           setAnyOrigin(response);
/*     */         } 
/* 154 */         return true;
/*     */       } 
/* 156 */       if (this.config.origins().contains(origin)) {
/* 157 */         setOrigin(response, origin);
/* 158 */         setVaryHeader(response);
/* 159 */         return true;
/*     */       } 
/* 161 */       logger.debug("Request origin [{}]] was not among the configured origins [{}]", origin, this.config.origins());
/*     */     } 
/* 163 */     return false;
/*     */   }
/*     */   
/*     */   private void echoRequestOrigin(HttpResponse response) {
/* 167 */     setOrigin(response, this.request.headers().get((CharSequence)HttpHeaderNames.ORIGIN));
/*     */   }
/*     */   
/*     */   private static void setVaryHeader(HttpResponse response) {
/* 171 */     response.headers().set((CharSequence)HttpHeaderNames.VARY, HttpHeaderNames.ORIGIN);
/*     */   }
/*     */   
/*     */   private static void setAnyOrigin(HttpResponse response) {
/* 175 */     setOrigin(response, "*");
/*     */   }
/*     */   
/*     */   private static void setNullOrigin(HttpResponse response) {
/* 179 */     setOrigin(response, "null");
/*     */   }
/*     */   
/*     */   private static void setOrigin(HttpResponse response, String origin) {
/* 183 */     response.headers().set((CharSequence)HttpHeaderNames.ACCESS_CONTROL_ALLOW_ORIGIN, origin);
/*     */   }
/*     */   
/*     */   private void setAllowCredentials(HttpResponse response) {
/* 187 */     if (this.config.isCredentialsAllowed() && 
/* 188 */       !response.headers().get((CharSequence)HttpHeaderNames.ACCESS_CONTROL_ALLOW_ORIGIN).equals("*")) {
/* 189 */       response.headers().set((CharSequence)HttpHeaderNames.ACCESS_CONTROL_ALLOW_CREDENTIALS, "true");
/*     */     }
/*     */   }
/*     */   
/*     */   private static boolean isPreflightRequest(HttpRequest request) {
/* 194 */     HttpHeaders headers = request.headers();
/* 195 */     return (HttpMethod.OPTIONS.equals(request.method()) && headers
/* 196 */       .contains((CharSequence)HttpHeaderNames.ORIGIN) && headers
/* 197 */       .contains((CharSequence)HttpHeaderNames.ACCESS_CONTROL_REQUEST_METHOD));
/*     */   }
/*     */   
/*     */   private void setExposeHeaders(HttpResponse response) {
/* 201 */     if (!this.config.exposedHeaders().isEmpty()) {
/* 202 */       response.headers().set((CharSequence)HttpHeaderNames.ACCESS_CONTROL_EXPOSE_HEADERS, this.config.exposedHeaders());
/*     */     }
/*     */   }
/*     */   
/*     */   private void setAllowMethods(HttpResponse response) {
/* 207 */     response.headers().set((CharSequence)HttpHeaderNames.ACCESS_CONTROL_ALLOW_METHODS, this.config.allowedRequestMethods());
/*     */   }
/*     */   
/*     */   private void setAllowHeaders(HttpResponse response) {
/* 211 */     response.headers().set((CharSequence)HttpHeaderNames.ACCESS_CONTROL_ALLOW_HEADERS, this.config.allowedRequestHeaders());
/*     */   }
/*     */   
/*     */   private void setMaxAge(HttpResponse response) {
/* 215 */     response.headers().set((CharSequence)HttpHeaderNames.ACCESS_CONTROL_MAX_AGE, Long.valueOf(this.config.maxAge()));
/*     */   }
/*     */   
/*     */   private void setAllowPrivateNetwork(HttpResponse response) {
/* 219 */     if (this.request.headers().contains((CharSequence)HttpHeaderNames.ACCESS_CONTROL_REQUEST_PRIVATE_NETWORK)) {
/* 220 */       if (this.config.isPrivateNetworkAllowed()) {
/* 221 */         response.headers().set((CharSequence)HttpHeaderNames.ACCESS_CONTROL_ALLOW_PRIVATE_NETWORK, "true");
/*     */       } else {
/* 223 */         response.headers().set((CharSequence)HttpHeaderNames.ACCESS_CONTROL_ALLOW_PRIVATE_NETWORK, "false");
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(ChannelHandlerContext ctx, Object msg, ChannelPromise promise) throws Exception {
/* 231 */     if (this.config != null && this.config.isCorsSupportEnabled() && msg instanceof HttpResponse) {
/* 232 */       HttpResponse response = (HttpResponse)msg;
/* 233 */       if (setOrigin(response)) {
/* 234 */         setAllowCredentials(response);
/* 235 */         setExposeHeaders(response);
/*     */       } 
/*     */     } 
/* 238 */     ctx.write(msg, promise);
/*     */   }
/*     */ 
/*     */   
/*     */   private static void forbidden(ChannelHandlerContext ctx, HttpRequest request) {
/* 243 */     DefaultFullHttpResponse defaultFullHttpResponse = new DefaultFullHttpResponse(request.protocolVersion(), HttpResponseStatus.FORBIDDEN, ctx.alloc().buffer(0));
/* 244 */     defaultFullHttpResponse.headers().set((CharSequence)HttpHeaderNames.CONTENT_LENGTH, HttpHeaderValues.ZERO);
/* 245 */     ReferenceCountUtil.release(request);
/* 246 */     respond(ctx, request, (HttpResponse)defaultFullHttpResponse);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void respond(ChannelHandlerContext ctx, HttpRequest request, HttpResponse response) {
/* 254 */     boolean keepAlive = HttpUtil.isKeepAlive((HttpMessage)request);
/*     */     
/* 256 */     HttpUtil.setKeepAlive((HttpMessage)response, keepAlive);
/*     */     
/* 258 */     ChannelFuture future = ctx.writeAndFlush(response);
/* 259 */     if (!keepAlive)
/* 260 */       future.addListener((GenericFutureListener)ChannelFutureListener.CLOSE); 
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http-4.1.93.Final.jar!\io\netty\handler\codec\http\cors\CorsHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */