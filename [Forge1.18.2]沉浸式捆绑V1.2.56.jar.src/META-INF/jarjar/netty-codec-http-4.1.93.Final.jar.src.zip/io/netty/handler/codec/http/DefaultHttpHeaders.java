/*     */ package io.netty.handler.codec.http;
/*     */ 
/*     */ import io.netty.handler.codec.CharSequenceValueConverter;
/*     */ import io.netty.handler.codec.DateFormatter;
/*     */ import io.netty.handler.codec.DefaultHeaders;
/*     */ import io.netty.handler.codec.DefaultHeadersImpl;
/*     */ import io.netty.handler.codec.Headers;
/*     */ import io.netty.handler.codec.HeadersUtils;
/*     */ import io.netty.handler.codec.ValueConverter;
/*     */ import io.netty.util.AsciiString;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Calendar;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultHttpHeaders
/*     */   extends HttpHeaders
/*     */ {
/*  43 */   static final DefaultHeaders.NameValidator<CharSequence> HttpNameValidator = new DefaultHeaders.NameValidator<CharSequence>()
/*     */     {
/*     */       public void validateName(CharSequence name) {
/*  46 */         if (name == null || name.length() == 0) {
/*  47 */           throw new IllegalArgumentException("empty headers are not allowed [" + name + ']');
/*     */         }
/*  49 */         int index = HttpHeaderValidationUtil.validateToken(name);
/*  50 */         if (index != -1) {
/*  51 */           throw new IllegalArgumentException("a header name can only contain \"token\" characters, but found invalid character 0x" + 
/*  52 */               Integer.toHexString(name.charAt(index)) + " at index " + index + " of header '" + name + "'.");
/*     */         }
/*     */       }
/*     */     };
/*     */ 
/*     */   
/*     */   private final DefaultHeaders<CharSequence, CharSequence, ?> headers;
/*     */   
/*     */   public DefaultHttpHeaders() {
/*  61 */     this(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultHttpHeaders(boolean validate) {
/*  77 */     this(validate, nameValidator(validate));
/*     */   }
/*     */   
/*     */   protected DefaultHttpHeaders(boolean validate, DefaultHeaders.NameValidator<CharSequence> nameValidator) {
/*  81 */     this((DefaultHeaders<CharSequence, CharSequence, ?>)new DefaultHeadersImpl(AsciiString.CASE_INSENSITIVE_HASHER, (ValueConverter)HeaderValueConverter.INSTANCE, nameValidator, 16, 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*  86 */           valueValidator(validate)));
/*     */   }
/*     */   
/*     */   protected DefaultHttpHeaders(DefaultHeaders<CharSequence, CharSequence, ?> headers) {
/*  90 */     this.headers = headers;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpHeaders add(HttpHeaders headers) {
/*  95 */     if (headers instanceof DefaultHttpHeaders) {
/*  96 */       this.headers.add((Headers)((DefaultHttpHeaders)headers).headers);
/*  97 */       return this;
/*     */     } 
/*  99 */     return super.add(headers);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpHeaders set(HttpHeaders headers) {
/* 105 */     if (headers instanceof DefaultHttpHeaders) {
/* 106 */       this.headers.set((Headers)((DefaultHttpHeaders)headers).headers);
/* 107 */       return this;
/*     */     } 
/* 109 */     return super.set(headers);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpHeaders add(String name, Object value) {
/* 115 */     this.headers.addObject(name, value);
/* 116 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpHeaders add(CharSequence name, Object value) {
/* 121 */     this.headers.addObject(name, value);
/* 122 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpHeaders add(String name, Iterable<?> values) {
/* 127 */     this.headers.addObject(name, values);
/* 128 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpHeaders add(CharSequence name, Iterable<?> values) {
/* 133 */     this.headers.addObject(name, values);
/* 134 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpHeaders addInt(CharSequence name, int value) {
/* 139 */     this.headers.addInt(name, value);
/* 140 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpHeaders addShort(CharSequence name, short value) {
/* 145 */     this.headers.addShort(name, value);
/* 146 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpHeaders remove(String name) {
/* 151 */     this.headers.remove(name);
/* 152 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpHeaders remove(CharSequence name) {
/* 157 */     this.headers.remove(name);
/* 158 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpHeaders set(String name, Object value) {
/* 163 */     this.headers.setObject(name, value);
/* 164 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpHeaders set(CharSequence name, Object value) {
/* 169 */     this.headers.setObject(name, value);
/* 170 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpHeaders set(String name, Iterable<?> values) {
/* 175 */     this.headers.setObject(name, values);
/* 176 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpHeaders set(CharSequence name, Iterable<?> values) {
/* 181 */     this.headers.setObject(name, values);
/* 182 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpHeaders setInt(CharSequence name, int value) {
/* 187 */     this.headers.setInt(name, value);
/* 188 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpHeaders setShort(CharSequence name, short value) {
/* 193 */     this.headers.setShort(name, value);
/* 194 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpHeaders clear() {
/* 199 */     this.headers.clear();
/* 200 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public String get(String name) {
/* 205 */     return get(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public String get(CharSequence name) {
/* 210 */     return HeadersUtils.getAsString((Headers)this.headers, name);
/*     */   }
/*     */ 
/*     */   
/*     */   public Integer getInt(CharSequence name) {
/* 215 */     return this.headers.getInt(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getInt(CharSequence name, int defaultValue) {
/* 220 */     return this.headers.getInt(name, defaultValue);
/*     */   }
/*     */ 
/*     */   
/*     */   public Short getShort(CharSequence name) {
/* 225 */     return this.headers.getShort(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public short getShort(CharSequence name, short defaultValue) {
/* 230 */     return this.headers.getShort(name, defaultValue);
/*     */   }
/*     */ 
/*     */   
/*     */   public Long getTimeMillis(CharSequence name) {
/* 235 */     return this.headers.getTimeMillis(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public long getTimeMillis(CharSequence name, long defaultValue) {
/* 240 */     return this.headers.getTimeMillis(name, defaultValue);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<String> getAll(String name) {
/* 245 */     return getAll(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<String> getAll(CharSequence name) {
/* 250 */     return HeadersUtils.getAllAsString((Headers)this.headers, name);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<Map.Entry<String, String>> entries() {
/* 255 */     if (isEmpty()) {
/* 256 */       return Collections.emptyList();
/*     */     }
/*     */     
/* 259 */     List<Map.Entry<String, String>> entriesConverted = new ArrayList<Map.Entry<String, String>>(this.headers.size());
/* 260 */     for (Map.Entry<String, String> entry : (Iterable<Map.Entry<String, String>>)this) {
/* 261 */       entriesConverted.add(entry);
/*     */     }
/* 263 */     return entriesConverted;
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Iterator<Map.Entry<String, String>> iterator() {
/* 269 */     return HeadersUtils.iteratorAsString((Iterable)this.headers);
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<Map.Entry<CharSequence, CharSequence>> iteratorCharSequence() {
/* 274 */     return this.headers.iterator();
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<String> valueStringIterator(CharSequence name) {
/* 279 */     final Iterator<CharSequence> itr = valueCharSequenceIterator(name);
/* 280 */     return new Iterator<String>()
/*     */       {
/*     */         public boolean hasNext() {
/* 283 */           return itr.hasNext();
/*     */         }
/*     */ 
/*     */         
/*     */         public String next() {
/* 288 */           return ((CharSequence)itr.next()).toString();
/*     */         }
/*     */ 
/*     */         
/*     */         public void remove() {
/* 293 */           itr.remove();
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<CharSequence> valueCharSequenceIterator(CharSequence name) {
/* 300 */     return this.headers.valueIterator(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean contains(String name) {
/* 305 */     return contains(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean contains(CharSequence name) {
/* 310 */     return this.headers.contains(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 315 */     return this.headers.isEmpty();
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/* 320 */     return this.headers.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean contains(String name, String value, boolean ignoreCase) {
/* 325 */     return contains(name, value, ignoreCase);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean contains(CharSequence name, CharSequence value, boolean ignoreCase) {
/* 330 */     return this.headers.contains(name, value, ignoreCase ? AsciiString.CASE_INSENSITIVE_HASHER : AsciiString.CASE_SENSITIVE_HASHER);
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<String> names() {
/* 335 */     return HeadersUtils.namesAsString((Headers)this.headers);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 340 */     return (o instanceof DefaultHttpHeaders && this.headers
/* 341 */       .equals((Headers)((DefaultHttpHeaders)o).headers, AsciiString.CASE_SENSITIVE_HASHER));
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 346 */     return this.headers.hashCode(AsciiString.CASE_SENSITIVE_HASHER);
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpHeaders copy() {
/* 351 */     return new DefaultHttpHeaders(this.headers.copy());
/*     */   }
/*     */   
/*     */   static ValueConverter<CharSequence> valueConverter() {
/* 355 */     return (ValueConverter<CharSequence>)HeaderValueConverter.INSTANCE;
/*     */   }
/*     */ 
/*     */   
/*     */   static DefaultHeaders.ValueValidator<CharSequence> valueValidator(boolean validate) {
/* 360 */     return validate ? HeaderValueValidator.INSTANCE : DefaultHeaders.ValueValidator.NO_VALIDATION;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static DefaultHeaders.NameValidator<CharSequence> nameValidator(boolean validate) {
/* 366 */     return validate ? HttpNameValidator : DefaultHeaders.NameValidator.NOT_NULL;
/*     */   }
/*     */   
/*     */   private static class HeaderValueConverter extends CharSequenceValueConverter {
/* 370 */     static final HeaderValueConverter INSTANCE = new HeaderValueConverter();
/*     */ 
/*     */     
/*     */     public CharSequence convertObject(Object value) {
/* 374 */       if (value instanceof CharSequence) {
/* 375 */         return (CharSequence)value;
/*     */       }
/* 377 */       if (value instanceof Date) {
/* 378 */         return DateFormatter.format((Date)value);
/*     */       }
/* 380 */       if (value instanceof Calendar) {
/* 381 */         return DateFormatter.format(((Calendar)value).getTime());
/*     */       }
/* 383 */       return value.toString();
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class HeaderValueValidator implements DefaultHeaders.ValueValidator<CharSequence> {
/* 388 */     static final HeaderValueValidator INSTANCE = new HeaderValueValidator();
/*     */ 
/*     */     
/*     */     public void validate(CharSequence value) {
/* 392 */       int index = HttpHeaderValidationUtil.validateValidHeaderValue(value);
/* 393 */       if (index != -1)
/* 394 */         throw new IllegalArgumentException("a header value contains prohibited character 0x" + 
/* 395 */             Integer.toHexString(value.charAt(index)) + " at index " + index + '.'); 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http-4.1.93.Final.jar!\io\netty\handler\codec\http\DefaultHttpHeaders.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */