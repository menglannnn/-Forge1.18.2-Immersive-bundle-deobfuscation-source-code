/*    */ package io.netty.handler.codec.spdy;
/*    */ 
/*    */ import io.netty.util.internal.PlatformDependent;
/*    */ import io.netty.util.internal.SuppressJava6Requirement;
/*    */ import io.netty.util.internal.ThrowableUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SpdyProtocolException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 7870000537743847264L;
/*    */   
/*    */   public SpdyProtocolException() {}
/*    */   
/*    */   public SpdyProtocolException(String message, Throwable cause) {
/* 35 */     super(message, cause);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SpdyProtocolException(String message) {
/* 42 */     super(message);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SpdyProtocolException(Throwable cause) {
/* 49 */     super(cause);
/*    */   }
/*    */   
/*    */   static SpdyProtocolException newStatic(String message, Class<?> clazz, String method) {
/*    */     SpdyProtocolException exception;
/* 54 */     if (PlatformDependent.javaVersion() >= 7) {
/* 55 */       exception = new StacklessSpdyProtocolException(message, true);
/*    */     } else {
/* 57 */       exception = new StacklessSpdyProtocolException(message);
/*    */     } 
/* 59 */     return (SpdyProtocolException)ThrowableUtil.unknownStackTrace(exception, clazz, method);
/*    */   }
/*    */ 
/*    */   
/*    */   @SuppressJava6Requirement(reason = "uses Java 7+ Exception.<init>(String, Throwable, boolean, boolean) but is guarded by version checks")
/*    */   private SpdyProtocolException(String message, boolean shared) {
/* 65 */     super(message, null, false, true);
/* 66 */     assert shared;
/*    */   }
/*    */   
/*    */   private static final class StacklessSpdyProtocolException extends SpdyProtocolException {
/*    */     private static final long serialVersionUID = -6302754207557485099L;
/*    */     
/*    */     StacklessSpdyProtocolException(String message) {
/* 73 */       super(message);
/*    */     }
/*    */     
/*    */     StacklessSpdyProtocolException(String message, boolean shared) {
/* 77 */       super(message, shared);
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     public Throwable fillInStackTrace() {
/* 84 */       return this;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http-4.1.93.Final.jar!\io\netty\handler\codec\spdy\SpdyProtocolException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */