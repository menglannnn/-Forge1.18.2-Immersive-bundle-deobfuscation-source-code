/*     */ package io.netty.handler.codec.http.websocketx;
/*     */ 
/*     */ import io.netty.channel.ChannelFuture;
/*     */ import io.netty.channel.ChannelFutureListener;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.channel.ChannelOutboundHandler;
/*     */ import io.netty.channel.ChannelPromise;
/*     */ import io.netty.handler.codec.MessageToMessageDecoder;
/*     */ import io.netty.util.ReferenceCountUtil;
/*     */ import io.netty.util.concurrent.Future;
/*     */ import io.netty.util.concurrent.GenericFutureListener;
/*     */ import io.netty.util.concurrent.Promise;
/*     */ import io.netty.util.concurrent.PromiseNotifier;
/*     */ import io.netty.util.concurrent.ScheduledFuture;
/*     */ import java.net.SocketAddress;
/*     */ import java.nio.channels.ClosedChannelException;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class WebSocketProtocolHandler
/*     */   extends MessageToMessageDecoder<WebSocketFrame>
/*     */   implements ChannelOutboundHandler
/*     */ {
/*     */   private final boolean dropPongFrames;
/*     */   private final WebSocketCloseStatus closeStatus;
/*     */   private final long forceCloseTimeoutMillis;
/*     */   private ChannelPromise closeSent;
/*     */   
/*     */   WebSocketProtocolHandler() {
/*  46 */     this(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   WebSocketProtocolHandler(boolean dropPongFrames) {
/*  57 */     this(dropPongFrames, null, 0L);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   WebSocketProtocolHandler(boolean dropPongFrames, WebSocketCloseStatus closeStatus, long forceCloseTimeoutMillis) {
/*  63 */     this.dropPongFrames = dropPongFrames;
/*  64 */     this.closeStatus = closeStatus;
/*  65 */     this.forceCloseTimeoutMillis = forceCloseTimeoutMillis;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void decode(ChannelHandlerContext ctx, WebSocketFrame frame, List<Object> out) throws Exception {
/*  70 */     if (frame instanceof PingWebSocketFrame) {
/*  71 */       frame.content().retain();
/*  72 */       ctx.writeAndFlush(new PongWebSocketFrame(frame.content()));
/*  73 */       readIfNeeded(ctx);
/*     */       return;
/*     */     } 
/*  76 */     if (frame instanceof PongWebSocketFrame && this.dropPongFrames) {
/*  77 */       readIfNeeded(ctx);
/*     */       
/*     */       return;
/*     */     } 
/*  81 */     out.add(frame.retain());
/*     */   }
/*     */   
/*     */   private static void readIfNeeded(ChannelHandlerContext ctx) {
/*  85 */     if (!ctx.channel().config().isAutoRead()) {
/*  86 */       ctx.read();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void close(final ChannelHandlerContext ctx, final ChannelPromise promise) throws Exception {
/*  92 */     if (this.closeStatus == null || !ctx.channel().isActive()) {
/*  93 */       ctx.close(promise);
/*     */     } else {
/*  95 */       if (this.closeSent == null) {
/*  96 */         write(ctx, new CloseWebSocketFrame(this.closeStatus), ctx.newPromise());
/*     */       }
/*  98 */       flush(ctx);
/*  99 */       applyCloseSentTimeout(ctx);
/* 100 */       this.closeSent.addListener((GenericFutureListener)new ChannelFutureListener()
/*     */           {
/*     */             public void operationComplete(ChannelFuture future) {
/* 103 */               ctx.close(promise);
/*     */             }
/*     */           });
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void write(ChannelHandlerContext ctx, Object msg, ChannelPromise promise) throws Exception {
/* 111 */     if (this.closeSent != null) {
/* 112 */       ReferenceCountUtil.release(msg);
/* 113 */       promise.setFailure(new ClosedChannelException());
/* 114 */     } else if (msg instanceof CloseWebSocketFrame) {
/* 115 */       closeSent(promise.unvoid());
/* 116 */       ctx.write(msg).addListener((GenericFutureListener)new PromiseNotifier(false, new Promise[] { (Promise)this.closeSent }));
/*     */     } else {
/* 118 */       ctx.write(msg, promise);
/*     */     } 
/*     */   }
/*     */   
/*     */   void closeSent(ChannelPromise promise) {
/* 123 */     this.closeSent = promise;
/*     */   }
/*     */   
/*     */   private void applyCloseSentTimeout(ChannelHandlerContext ctx) {
/* 127 */     if (this.closeSent.isDone() || this.forceCloseTimeoutMillis < 0L) {
/*     */       return;
/*     */     }
/*     */     
/* 131 */     final ScheduledFuture timeoutTask = ctx.executor().schedule(new Runnable()
/*     */         {
/*     */           public void run() {
/* 134 */             if (!WebSocketProtocolHandler.this.closeSent.isDone()) {
/* 135 */               WebSocketProtocolHandler.this.closeSent.tryFailure(WebSocketProtocolHandler.this.buildHandshakeException("send close frame timed out"));
/*     */             }
/*     */           }
/*     */         },  this.forceCloseTimeoutMillis, TimeUnit.MILLISECONDS);
/*     */     
/* 140 */     this.closeSent.addListener((GenericFutureListener)new ChannelFutureListener()
/*     */         {
/*     */           public void operationComplete(ChannelFuture future) {
/* 143 */             timeoutTask.cancel(false);
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected WebSocketHandshakeException buildHandshakeException(String message) {
/* 153 */     return new WebSocketHandshakeException(message);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void bind(ChannelHandlerContext ctx, SocketAddress localAddress, ChannelPromise promise) throws Exception {
/* 159 */     ctx.bind(localAddress, promise);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void connect(ChannelHandlerContext ctx, SocketAddress remoteAddress, SocketAddress localAddress, ChannelPromise promise) throws Exception {
/* 165 */     ctx.connect(remoteAddress, localAddress, promise);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void disconnect(ChannelHandlerContext ctx, ChannelPromise promise) throws Exception {
/* 171 */     ctx.disconnect(promise);
/*     */   }
/*     */ 
/*     */   
/*     */   public void deregister(ChannelHandlerContext ctx, ChannelPromise promise) throws Exception {
/* 176 */     ctx.deregister(promise);
/*     */   }
/*     */ 
/*     */   
/*     */   public void read(ChannelHandlerContext ctx) throws Exception {
/* 181 */     ctx.read();
/*     */   }
/*     */ 
/*     */   
/*     */   public void flush(ChannelHandlerContext ctx) throws Exception {
/* 186 */     ctx.flush();
/*     */   }
/*     */ 
/*     */   
/*     */   public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
/* 191 */     ctx.fireExceptionCaught(cause);
/* 192 */     ctx.close();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http-4.1.93.Final.jar!\io\netty\handler\codec\http\websocketx\WebSocketProtocolHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */