/*    */ package io.netty.handler.codec.http.websocketx.extensions;
/*    */ 
/*    */ import io.netty.handler.codec.http.websocketx.WebSocketFrame;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface WebSocketExtensionFilter
/*    */ {
/* 30 */   public static final WebSocketExtensionFilter NEVER_SKIP = new WebSocketExtensionFilter()
/*    */     {
/*    */       public boolean mustSkip(WebSocketFrame frame) {
/* 33 */         return false;
/*    */       }
/*    */     };
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 41 */   public static final WebSocketExtensionFilter ALWAYS_SKIP = new WebSocketExtensionFilter()
/*    */     {
/*    */       public boolean mustSkip(WebSocketFrame frame) {
/* 44 */         return true;
/*    */       }
/*    */     };
/*    */   
/*    */   boolean mustSkip(WebSocketFrame paramWebSocketFrame);
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http-4.1.93.Final.jar!\io\netty\handler\codec\http\websocketx\extensions\WebSocketExtensionFilter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */