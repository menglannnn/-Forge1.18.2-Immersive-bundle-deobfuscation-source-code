/*     */ package io.netty.handler.codec.http;
/*     */ 
/*     */ import io.netty.handler.codec.CharSequenceValueConverter;
/*     */ import io.netty.util.AsciiString;
/*     */ import java.util.AbstractMap;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ReadOnlyHttpHeaders
/*     */   extends HttpHeaders
/*     */ {
/*     */   private final CharSequence[] nameValuePairs;
/*     */   
/*     */   public ReadOnlyHttpHeaders(boolean validateHeaders, CharSequence... nameValuePairs) {
/*  57 */     if ((nameValuePairs.length & 0x1) != 0) {
/*  58 */       throw newInvalidArraySizeException();
/*     */     }
/*  60 */     if (validateHeaders) {
/*  61 */       validateHeaders(nameValuePairs);
/*     */     }
/*  63 */     this.nameValuePairs = nameValuePairs;
/*     */   }
/*     */   
/*     */   private static IllegalArgumentException newInvalidArraySizeException() {
/*  67 */     return new IllegalArgumentException("nameValuePairs must be arrays of [name, value] pairs");
/*     */   }
/*     */   
/*     */   private static void validateHeaders(CharSequence... keyValuePairs) {
/*  71 */     for (int i = 0; i < keyValuePairs.length; i += 2) {
/*  72 */       DefaultHttpHeaders.HttpNameValidator.validateName(keyValuePairs[i]);
/*     */     }
/*     */   }
/*     */   
/*     */   private CharSequence get0(CharSequence name) {
/*  77 */     int nameHash = AsciiString.hashCode(name);
/*  78 */     for (int i = 0; i < this.nameValuePairs.length; i += 2) {
/*  79 */       CharSequence roName = this.nameValuePairs[i];
/*  80 */       if (AsciiString.hashCode(roName) == nameHash && AsciiString.contentEqualsIgnoreCase(roName, name))
/*     */       {
/*  82 */         return this.nameValuePairs[i + 1];
/*     */       }
/*     */     } 
/*  85 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String get(String name) {
/*  90 */     CharSequence value = get0(name);
/*  91 */     return (value == null) ? null : value.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public Integer getInt(CharSequence name) {
/*  96 */     CharSequence value = get0(name);
/*  97 */     return (value == null) ? null : Integer.valueOf(CharSequenceValueConverter.INSTANCE.convertToInt(value));
/*     */   }
/*     */ 
/*     */   
/*     */   public int getInt(CharSequence name, int defaultValue) {
/* 102 */     CharSequence value = get0(name);
/* 103 */     return (value == null) ? defaultValue : CharSequenceValueConverter.INSTANCE.convertToInt(value);
/*     */   }
/*     */ 
/*     */   
/*     */   public Short getShort(CharSequence name) {
/* 108 */     CharSequence value = get0(name);
/* 109 */     return (value == null) ? null : Short.valueOf(CharSequenceValueConverter.INSTANCE.convertToShort(value));
/*     */   }
/*     */ 
/*     */   
/*     */   public short getShort(CharSequence name, short defaultValue) {
/* 114 */     CharSequence value = get0(name);
/* 115 */     return (value == null) ? defaultValue : CharSequenceValueConverter.INSTANCE.convertToShort(value);
/*     */   }
/*     */ 
/*     */   
/*     */   public Long getTimeMillis(CharSequence name) {
/* 120 */     CharSequence value = get0(name);
/* 121 */     return (value == null) ? null : Long.valueOf(CharSequenceValueConverter.INSTANCE.convertToTimeMillis(value));
/*     */   }
/*     */ 
/*     */   
/*     */   public long getTimeMillis(CharSequence name, long defaultValue) {
/* 126 */     CharSequence value = get0(name);
/* 127 */     return (value == null) ? defaultValue : CharSequenceValueConverter.INSTANCE.convertToTimeMillis(value);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<String> getAll(String name) {
/* 132 */     if (isEmpty()) {
/* 133 */       return Collections.emptyList();
/*     */     }
/* 135 */     int nameHash = AsciiString.hashCode(name);
/* 136 */     List<String> values = new ArrayList<String>(4);
/* 137 */     for (int i = 0; i < this.nameValuePairs.length; i += 2) {
/* 138 */       CharSequence roName = this.nameValuePairs[i];
/* 139 */       if (AsciiString.hashCode(roName) == nameHash && AsciiString.contentEqualsIgnoreCase(roName, name)) {
/* 140 */         values.add(this.nameValuePairs[i + 1].toString());
/*     */       }
/*     */     } 
/* 143 */     return values;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<Map.Entry<String, String>> entries() {
/* 148 */     if (isEmpty()) {
/* 149 */       return Collections.emptyList();
/*     */     }
/* 151 */     List<Map.Entry<String, String>> entries = new ArrayList<Map.Entry<String, String>>(size());
/* 152 */     for (int i = 0; i < this.nameValuePairs.length; i += 2) {
/* 153 */       entries.add(new AbstractMap.SimpleImmutableEntry<String, String>(this.nameValuePairs[i].toString(), this.nameValuePairs[i + 1]
/* 154 */             .toString()));
/*     */     }
/* 156 */     return entries;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean contains(String name) {
/* 161 */     return (get0(name) != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean contains(String name, String value, boolean ignoreCase) {
/* 166 */     return containsValue(name, value, ignoreCase);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsValue(CharSequence name, CharSequence value, boolean ignoreCase) {
/* 171 */     if (ignoreCase) {
/* 172 */       for (int i = 0; i < this.nameValuePairs.length; i += 2) {
/* 173 */         if (AsciiString.contentEqualsIgnoreCase(this.nameValuePairs[i], name) && 
/* 174 */           AsciiString.contentEqualsIgnoreCase(this.nameValuePairs[i + 1], value)) {
/* 175 */           return true;
/*     */         }
/*     */       } 
/*     */     } else {
/* 179 */       for (int i = 0; i < this.nameValuePairs.length; i += 2) {
/* 180 */         if (AsciiString.contentEqualsIgnoreCase(this.nameValuePairs[i], name) && 
/* 181 */           AsciiString.contentEquals(this.nameValuePairs[i + 1], value)) {
/* 182 */           return true;
/*     */         }
/*     */       } 
/*     */     } 
/* 186 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<String> valueStringIterator(CharSequence name) {
/* 191 */     return new ReadOnlyStringValueIterator(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<CharSequence> valueCharSequenceIterator(CharSequence name) {
/* 196 */     return new ReadOnlyValueIterator(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<Map.Entry<String, String>> iterator() {
/* 201 */     return new ReadOnlyStringIterator();
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<Map.Entry<CharSequence, CharSequence>> iteratorCharSequence() {
/* 206 */     return new ReadOnlyIterator();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 211 */     return (this.nameValuePairs.length == 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/* 216 */     return this.nameValuePairs.length >>> 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<String> names() {
/* 221 */     if (isEmpty()) {
/* 222 */       return Collections.emptySet();
/*     */     }
/* 224 */     Set<String> names = new LinkedHashSet<String>(size());
/* 225 */     for (int i = 0; i < this.nameValuePairs.length; i += 2) {
/* 226 */       names.add(this.nameValuePairs[i].toString());
/*     */     }
/* 228 */     return names;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpHeaders add(String name, Object value) {
/* 233 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpHeaders add(String name, Iterable<?> values) {
/* 238 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpHeaders addInt(CharSequence name, int value) {
/* 243 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpHeaders addShort(CharSequence name, short value) {
/* 248 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpHeaders set(String name, Object value) {
/* 253 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpHeaders set(String name, Iterable<?> values) {
/* 258 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpHeaders setInt(CharSequence name, int value) {
/* 263 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpHeaders setShort(CharSequence name, short value) {
/* 268 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpHeaders remove(String name) {
/* 273 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpHeaders clear() {
/* 278 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */   
/*     */   private final class ReadOnlyIterator implements Map.Entry<CharSequence, CharSequence>, Iterator<Map.Entry<CharSequence, CharSequence>> {
/*     */     private CharSequence key;
/*     */     private CharSequence value;
/*     */     private int nextNameIndex;
/*     */     
/*     */     private ReadOnlyIterator() {}
/*     */     
/*     */     public boolean hasNext() {
/* 289 */       return (this.nextNameIndex != ReadOnlyHttpHeaders.this.nameValuePairs.length);
/*     */     }
/*     */ 
/*     */     
/*     */     public Map.Entry<CharSequence, CharSequence> next() {
/* 294 */       if (!hasNext()) {
/* 295 */         throw new NoSuchElementException();
/*     */       }
/* 297 */       this.key = ReadOnlyHttpHeaders.this.nameValuePairs[this.nextNameIndex];
/* 298 */       this.value = ReadOnlyHttpHeaders.this.nameValuePairs[this.nextNameIndex + 1];
/* 299 */       this.nextNameIndex += 2;
/* 300 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public void remove() {
/* 305 */       throw new UnsupportedOperationException("read only");
/*     */     }
/*     */ 
/*     */     
/*     */     public CharSequence getKey() {
/* 310 */       return this.key;
/*     */     }
/*     */ 
/*     */     
/*     */     public CharSequence getValue() {
/* 315 */       return this.value;
/*     */     }
/*     */ 
/*     */     
/*     */     public CharSequence setValue(CharSequence value) {
/* 320 */       throw new UnsupportedOperationException("read only");
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 325 */       return this.key.toString() + '=' + this.value.toString();
/*     */     }
/*     */   }
/*     */   
/*     */   private final class ReadOnlyStringIterator implements Map.Entry<String, String>, Iterator<Map.Entry<String, String>> {
/*     */     private String key;
/*     */     private String value;
/*     */     private int nextNameIndex;
/*     */     
/*     */     private ReadOnlyStringIterator() {}
/*     */     
/*     */     public boolean hasNext() {
/* 337 */       return (this.nextNameIndex != ReadOnlyHttpHeaders.this.nameValuePairs.length);
/*     */     }
/*     */ 
/*     */     
/*     */     public Map.Entry<String, String> next() {
/* 342 */       if (!hasNext()) {
/* 343 */         throw new NoSuchElementException();
/*     */       }
/* 345 */       this.key = ReadOnlyHttpHeaders.this.nameValuePairs[this.nextNameIndex].toString();
/* 346 */       this.value = ReadOnlyHttpHeaders.this.nameValuePairs[this.nextNameIndex + 1].toString();
/* 347 */       this.nextNameIndex += 2;
/* 348 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public void remove() {
/* 353 */       throw new UnsupportedOperationException("read only");
/*     */     }
/*     */ 
/*     */     
/*     */     public String getKey() {
/* 358 */       return this.key;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getValue() {
/* 363 */       return this.value;
/*     */     }
/*     */ 
/*     */     
/*     */     public String setValue(String value) {
/* 368 */       throw new UnsupportedOperationException("read only");
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 373 */       return this.key + '=' + this.value;
/*     */     }
/*     */   }
/*     */   
/*     */   private final class ReadOnlyStringValueIterator implements Iterator<String> {
/*     */     private final CharSequence name;
/*     */     private final int nameHash;
/*     */     private int nextNameIndex;
/*     */     
/*     */     ReadOnlyStringValueIterator(CharSequence name) {
/* 383 */       this.name = name;
/* 384 */       this.nameHash = AsciiString.hashCode(name);
/* 385 */       this.nextNameIndex = findNextValue();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/* 390 */       return (this.nextNameIndex != -1);
/*     */     }
/*     */ 
/*     */     
/*     */     public String next() {
/* 395 */       if (!hasNext()) {
/* 396 */         throw new NoSuchElementException();
/*     */       }
/* 398 */       String value = ReadOnlyHttpHeaders.this.nameValuePairs[this.nextNameIndex + 1].toString();
/* 399 */       this.nextNameIndex = findNextValue();
/* 400 */       return value;
/*     */     }
/*     */ 
/*     */     
/*     */     public void remove() {
/* 405 */       throw new UnsupportedOperationException("read only");
/*     */     }
/*     */     
/*     */     private int findNextValue() {
/* 409 */       for (int i = this.nextNameIndex; i < ReadOnlyHttpHeaders.this.nameValuePairs.length; i += 2) {
/* 410 */         CharSequence roName = ReadOnlyHttpHeaders.this.nameValuePairs[i];
/* 411 */         if (this.nameHash == AsciiString.hashCode(roName) && AsciiString.contentEqualsIgnoreCase(this.name, roName)) {
/* 412 */           return i;
/*     */         }
/*     */       } 
/* 415 */       return -1;
/*     */     }
/*     */   }
/*     */   
/*     */   private final class ReadOnlyValueIterator implements Iterator<CharSequence> {
/*     */     private final CharSequence name;
/*     */     private final int nameHash;
/*     */     private int nextNameIndex;
/*     */     
/*     */     ReadOnlyValueIterator(CharSequence name) {
/* 425 */       this.name = name;
/* 426 */       this.nameHash = AsciiString.hashCode(name);
/* 427 */       this.nextNameIndex = findNextValue();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/* 432 */       return (this.nextNameIndex != -1);
/*     */     }
/*     */ 
/*     */     
/*     */     public CharSequence next() {
/* 437 */       if (!hasNext()) {
/* 438 */         throw new NoSuchElementException();
/*     */       }
/* 440 */       CharSequence value = ReadOnlyHttpHeaders.this.nameValuePairs[this.nextNameIndex + 1];
/* 441 */       this.nextNameIndex = findNextValue();
/* 442 */       return value;
/*     */     }
/*     */ 
/*     */     
/*     */     public void remove() {
/* 447 */       throw new UnsupportedOperationException("read only");
/*     */     }
/*     */     
/*     */     private int findNextValue() {
/* 451 */       for (int i = this.nextNameIndex; i < ReadOnlyHttpHeaders.this.nameValuePairs.length; i += 2) {
/* 452 */         CharSequence roName = ReadOnlyHttpHeaders.this.nameValuePairs[i];
/* 453 */         if (this.nameHash == AsciiString.hashCode(roName) && AsciiString.contentEqualsIgnoreCase(this.name, roName)) {
/* 454 */           return i;
/*     */         }
/*     */       } 
/* 457 */       return -1;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http-4.1.93.Final.jar!\io\netty\handler\codec\http\ReadOnlyHttpHeaders.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */