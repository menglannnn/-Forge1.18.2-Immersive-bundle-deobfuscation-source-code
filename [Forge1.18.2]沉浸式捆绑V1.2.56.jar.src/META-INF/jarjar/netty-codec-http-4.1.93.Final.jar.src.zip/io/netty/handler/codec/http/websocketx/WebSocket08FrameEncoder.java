/*     */ package io.netty.handler.codec.http.websocketx;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.handler.codec.MessageToMessageEncoder;
/*     */ import io.netty.handler.codec.TooLongFrameException;
/*     */ import io.netty.util.internal.PlatformDependent;
/*     */ import io.netty.util.internal.logging.InternalLogger;
/*     */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*     */ import java.nio.ByteOrder;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WebSocket08FrameEncoder
/*     */   extends MessageToMessageEncoder<WebSocketFrame>
/*     */   implements WebSocketFrameEncoder
/*     */ {
/*  75 */   private static final InternalLogger logger = InternalLoggerFactory.getInstance(WebSocket08FrameEncoder.class);
/*     */ 
/*     */   
/*     */   private static final byte OPCODE_CONT = 0;
/*     */ 
/*     */   
/*     */   private static final byte OPCODE_TEXT = 1;
/*     */ 
/*     */   
/*     */   private static final byte OPCODE_BINARY = 2;
/*     */ 
/*     */   
/*     */   private static final byte OPCODE_CLOSE = 8;
/*     */ 
/*     */   
/*     */   private static final byte OPCODE_PING = 9;
/*     */ 
/*     */   
/*     */   private static final byte OPCODE_PONG = 10;
/*     */ 
/*     */   
/*     */   private static final int GATHERING_WRITE_THRESHOLD = 1024;
/*     */   
/*     */   private final boolean maskPayload;
/*     */ 
/*     */   
/*     */   public WebSocket08FrameEncoder(boolean maskPayload) {
/* 102 */     this.maskPayload = maskPayload;
/*     */   }
/*     */   
/*     */   protected void encode(ChannelHandlerContext ctx, WebSocketFrame msg, List<Object> out) throws Exception {
/*     */     byte opcode;
/* 107 */     ByteBuf data = msg.content();
/*     */ 
/*     */     
/* 110 */     if (msg instanceof TextWebSocketFrame) {
/* 111 */       opcode = 1;
/* 112 */     } else if (msg instanceof PingWebSocketFrame) {
/* 113 */       opcode = 9;
/* 114 */     } else if (msg instanceof PongWebSocketFrame) {
/* 115 */       opcode = 10;
/* 116 */     } else if (msg instanceof CloseWebSocketFrame) {
/* 117 */       opcode = 8;
/* 118 */     } else if (msg instanceof BinaryWebSocketFrame) {
/* 119 */       opcode = 2;
/* 120 */     } else if (msg instanceof ContinuationWebSocketFrame) {
/* 121 */       opcode = 0;
/*     */     } else {
/* 123 */       throw new UnsupportedOperationException("Cannot encode frame of type: " + msg.getClass().getName());
/*     */     } 
/*     */     
/* 126 */     int length = data.readableBytes();
/*     */     
/* 128 */     if (logger.isTraceEnabled()) {
/* 129 */       logger.trace("Encoding WebSocket Frame opCode={} length={}", Byte.valueOf(opcode), Integer.valueOf(length));
/*     */     }
/*     */     
/* 132 */     int b0 = 0;
/* 133 */     if (msg.isFinalFragment()) {
/* 134 */       b0 |= 0x80;
/*     */     }
/* 136 */     b0 |= msg.rsv() % 8 << 4;
/* 137 */     b0 |= opcode % 128;
/*     */     
/* 139 */     if (opcode == 9 && length > 125) {
/* 140 */       throw new TooLongFrameException("invalid payload for PING (payload length must be <= 125, was " + length);
/*     */     }
/*     */     
/* 143 */     boolean release = true;
/* 144 */     ByteBuf buf = null;
/*     */     try {
/* 146 */       int maskLength = this.maskPayload ? 4 : 0;
/* 147 */       if (length <= 125) {
/* 148 */         int size = 2 + maskLength + length;
/* 149 */         buf = ctx.alloc().buffer(size);
/* 150 */         buf.writeByte(b0);
/* 151 */         byte b = (byte)(this.maskPayload ? (0x80 | (byte)length) : (byte)length);
/* 152 */         buf.writeByte(b);
/* 153 */       } else if (length <= 65535) {
/* 154 */         int size = 4 + maskLength;
/* 155 */         if (this.maskPayload || length <= 1024) {
/* 156 */           size += length;
/*     */         }
/* 158 */         buf = ctx.alloc().buffer(size);
/* 159 */         buf.writeByte(b0);
/* 160 */         buf.writeByte(this.maskPayload ? 254 : 126);
/* 161 */         buf.writeByte(length >>> 8 & 0xFF);
/* 162 */         buf.writeByte(length & 0xFF);
/*     */       } else {
/* 164 */         int size = 10 + maskLength;
/* 165 */         if (this.maskPayload) {
/* 166 */           size += length;
/*     */         }
/* 168 */         buf = ctx.alloc().buffer(size);
/* 169 */         buf.writeByte(b0);
/* 170 */         buf.writeByte(this.maskPayload ? 255 : 127);
/* 171 */         buf.writeLong(length);
/*     */       } 
/*     */ 
/*     */       
/* 175 */       if (this.maskPayload) {
/* 176 */         int mask = PlatformDependent.threadLocalRandom().nextInt(2147483647);
/* 177 */         buf.writeInt(mask);
/*     */         
/* 179 */         if (data.isReadable()) {
/*     */           
/* 181 */           ByteOrder srcOrder = data.order();
/* 182 */           ByteOrder dstOrder = buf.order();
/*     */           
/* 184 */           int i = data.readerIndex();
/* 185 */           int end = data.writerIndex();
/*     */           
/* 187 */           if (srcOrder == dstOrder) {
/*     */ 
/*     */             
/* 190 */             long longMask = mask & 0xFFFFFFFFL;
/* 191 */             longMask |= longMask << 32L;
/*     */ 
/*     */ 
/*     */             
/* 195 */             if (srcOrder == ByteOrder.LITTLE_ENDIAN) {
/* 196 */               longMask = Long.reverseBytes(longMask);
/*     */             }
/*     */             
/* 199 */             for (int lim = end - 7; i < lim; i += 8) {
/* 200 */               buf.writeLong(data.getLong(i) ^ longMask);
/*     */             }
/*     */             
/* 203 */             if (i < end - 3) {
/* 204 */               buf.writeInt(data.getInt(i) ^ (int)longMask);
/* 205 */               i += 4;
/*     */             } 
/*     */           } 
/* 208 */           int maskOffset = 0;
/* 209 */           for (; i < end; i++) {
/* 210 */             byte byteData = data.getByte(i);
/* 211 */             buf.writeByte(byteData ^ WebSocketUtil.byteAtIndex(mask, maskOffset++ & 0x3));
/*     */           } 
/*     */         } 
/* 214 */         out.add(buf);
/*     */       }
/* 216 */       else if (buf.writableBytes() >= data.readableBytes()) {
/*     */         
/* 218 */         buf.writeBytes(data);
/* 219 */         out.add(buf);
/*     */       } else {
/* 221 */         out.add(buf);
/* 222 */         out.add(data.retain());
/*     */       } 
/*     */       
/* 225 */       release = false;
/*     */     } finally {
/* 227 */       if (release && buf != null)
/* 228 */         buf.release(); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http-4.1.93.Final.jar!\io\netty\handler\codec\http\websocketx\WebSocket08FrameEncoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */