/*     */ package io.netty.handler.codec.http;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.util.CharsetUtil;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpVersion
/*     */   implements Comparable<HttpVersion>
/*     */ {
/*  36 */   private static final Pattern VERSION_PATTERN = Pattern.compile("(\\S+)/(\\d+)\\.(\\d+)");
/*     */ 
/*     */   
/*     */   static final String HTTP_1_0_STRING = "HTTP/1.0";
/*     */ 
/*     */   
/*     */   static final String HTTP_1_1_STRING = "HTTP/1.1";
/*     */   
/*  44 */   public static final HttpVersion HTTP_1_0 = new HttpVersion("HTTP", 1, 0, false, true);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  49 */   public static final HttpVersion HTTP_1_1 = new HttpVersion("HTTP", 1, 1, true, true);
/*     */   
/*     */   private final String protocolName;
/*     */   
/*     */   private final int majorVersion;
/*     */   private final int minorVersion;
/*     */   private final String text;
/*     */   private final boolean keepAliveDefault;
/*     */   private final byte[] bytes;
/*     */   
/*     */   public static HttpVersion valueOf(String text) {
/*  60 */     ObjectUtil.checkNotNull(text, "text");
/*     */ 
/*     */     
/*  63 */     if (text == "HTTP/1.1")
/*  64 */       return HTTP_1_1; 
/*  65 */     if (text == "HTTP/1.0") {
/*  66 */       return HTTP_1_0;
/*     */     }
/*     */     
/*  69 */     text = text.trim();
/*     */     
/*  71 */     if (text.isEmpty()) {
/*  72 */       throw new IllegalArgumentException("text is empty (possibly HTTP/0.9)");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  83 */     HttpVersion version = version0(text);
/*  84 */     if (version == null) {
/*  85 */       version = new HttpVersion(text, true);
/*     */     }
/*  87 */     return version;
/*     */   }
/*     */   
/*     */   private static HttpVersion version0(String text) {
/*  91 */     if ("HTTP/1.1".equals(text)) {
/*  92 */       return HTTP_1_1;
/*     */     }
/*  94 */     if ("HTTP/1.0".equals(text)) {
/*  95 */       return HTTP_1_0;
/*     */     }
/*  97 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpVersion(String text, boolean keepAliveDefault) {
/* 119 */     text = ObjectUtil.checkNonEmptyAfterTrim(text, "text").toUpperCase();
/*     */     
/* 121 */     Matcher m = VERSION_PATTERN.matcher(text);
/* 122 */     if (!m.matches()) {
/* 123 */       throw new IllegalArgumentException("invalid version format: " + text);
/*     */     }
/*     */     
/* 126 */     this.protocolName = m.group(1);
/* 127 */     this.majorVersion = Integer.parseInt(m.group(2));
/* 128 */     this.minorVersion = Integer.parseInt(m.group(3));
/* 129 */     this.text = this.protocolName + '/' + this.majorVersion + '.' + this.minorVersion;
/* 130 */     this.keepAliveDefault = keepAliveDefault;
/* 131 */     this.bytes = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpVersion(String protocolName, int majorVersion, int minorVersion, boolean keepAliveDefault) {
/* 148 */     this(protocolName, majorVersion, minorVersion, keepAliveDefault, false);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private HttpVersion(String protocolName, int majorVersion, int minorVersion, boolean keepAliveDefault, boolean bytes) {
/* 154 */     protocolName = ObjectUtil.checkNonEmptyAfterTrim(protocolName, "protocolName").toUpperCase();
/*     */     
/* 156 */     for (int i = 0; i < protocolName.length(); i++) {
/* 157 */       if (Character.isISOControl(protocolName.charAt(i)) || 
/* 158 */         Character.isWhitespace(protocolName.charAt(i))) {
/* 159 */         throw new IllegalArgumentException("invalid character in protocolName");
/*     */       }
/*     */     } 
/*     */     
/* 163 */     ObjectUtil.checkPositiveOrZero(majorVersion, "majorVersion");
/* 164 */     ObjectUtil.checkPositiveOrZero(minorVersion, "minorVersion");
/*     */     
/* 166 */     this.protocolName = protocolName;
/* 167 */     this.majorVersion = majorVersion;
/* 168 */     this.minorVersion = minorVersion;
/* 169 */     this.text = protocolName + '/' + majorVersion + '.' + minorVersion;
/* 170 */     this.keepAliveDefault = keepAliveDefault;
/*     */     
/* 172 */     if (bytes) {
/* 173 */       this.bytes = this.text.getBytes(CharsetUtil.US_ASCII);
/*     */     } else {
/* 175 */       this.bytes = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String protocolName() {
/* 183 */     return this.protocolName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int majorVersion() {
/* 190 */     return this.majorVersion;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int minorVersion() {
/* 197 */     return this.minorVersion;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String text() {
/* 204 */     return this.text;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isKeepAliveDefault() {
/* 212 */     return this.keepAliveDefault;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 220 */     return text();
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 225 */     return (protocolName().hashCode() * 31 + majorVersion()) * 31 + 
/* 226 */       minorVersion();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 231 */     if (!(o instanceof HttpVersion)) {
/* 232 */       return false;
/*     */     }
/*     */     
/* 235 */     HttpVersion that = (HttpVersion)o;
/* 236 */     return (minorVersion() == that.minorVersion() && 
/* 237 */       majorVersion() == that.majorVersion() && 
/* 238 */       protocolName().equals(that.protocolName()));
/*     */   }
/*     */ 
/*     */   
/*     */   public int compareTo(HttpVersion o) {
/* 243 */     int v = protocolName().compareTo(o.protocolName());
/* 244 */     if (v != 0) {
/* 245 */       return v;
/*     */     }
/*     */     
/* 248 */     v = majorVersion() - o.majorVersion();
/* 249 */     if (v != 0) {
/* 250 */       return v;
/*     */     }
/*     */     
/* 253 */     return minorVersion() - o.minorVersion();
/*     */   }
/*     */   
/*     */   void encode(ByteBuf buf) {
/* 257 */     if (this.bytes == null) {
/* 258 */       buf.writeCharSequence(this.text, CharsetUtil.US_ASCII);
/*     */     } else {
/* 260 */       buf.writeBytes(this.bytes);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http-4.1.93.Final.jar!\io\netty\handler\codec\http\HttpVersion.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */