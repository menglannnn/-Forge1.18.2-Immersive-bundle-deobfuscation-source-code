/*     */ package io.netty.handler.codec.spdy;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.buffer.ByteBufAllocator;
/*     */ import io.netty.buffer.Unpooled;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import io.netty.util.internal.PlatformDependent;
/*     */ import io.netty.util.internal.SuppressJava6Requirement;
/*     */ import java.util.zip.Deflater;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SpdyHeaderBlockZlibEncoder
/*     */   extends SpdyHeaderBlockRawEncoder
/*     */ {
/*     */   private final Deflater compressor;
/*     */   private boolean finished;
/*     */   
/*     */   SpdyHeaderBlockZlibEncoder(SpdyVersion spdyVersion, int compressionLevel) {
/*  36 */     super(spdyVersion);
/*  37 */     if (compressionLevel < 0 || compressionLevel > 9) {
/*  38 */       throw new IllegalArgumentException("compressionLevel: " + compressionLevel + " (expected: 0-9)");
/*     */     }
/*     */     
/*  41 */     this.compressor = new Deflater(compressionLevel);
/*  42 */     this.compressor.setDictionary(SpdyCodecUtil.SPDY_DICT);
/*     */   }
/*     */   
/*     */   private int setInput(ByteBuf decompressed) {
/*  46 */     int len = decompressed.readableBytes();
/*     */     
/*  48 */     if (decompressed.hasArray()) {
/*  49 */       this.compressor.setInput(decompressed.array(), decompressed.arrayOffset() + decompressed.readerIndex(), len);
/*     */     } else {
/*  51 */       byte[] in = new byte[len];
/*  52 */       decompressed.getBytes(decompressed.readerIndex(), in);
/*  53 */       this.compressor.setInput(in, 0, in.length);
/*     */     } 
/*     */     
/*  56 */     return len;
/*     */   }
/*     */   
/*     */   private ByteBuf encode(ByteBufAllocator alloc, int len) {
/*  60 */     ByteBuf compressed = alloc.heapBuffer(len);
/*  61 */     boolean release = true;
/*     */     try {
/*  63 */       while (compressInto(compressed))
/*     */       {
/*  65 */         compressed.ensureWritable(compressed.capacity() << 1);
/*     */       }
/*  67 */       release = false;
/*  68 */       return compressed;
/*     */     } finally {
/*  70 */       if (release)
/*  71 */         compressed.release(); 
/*     */     } 
/*     */   }
/*     */   
/*     */   @SuppressJava6Requirement(reason = "Guarded by java version check")
/*     */   private boolean compressInto(ByteBuf compressed) {
/*     */     int numBytes;
/*  78 */     byte[] out = compressed.array();
/*  79 */     int off = compressed.arrayOffset() + compressed.writerIndex();
/*  80 */     int toWrite = compressed.writableBytes();
/*     */     
/*  82 */     if (PlatformDependent.javaVersion() >= 7) {
/*  83 */       numBytes = this.compressor.deflate(out, off, toWrite, 2);
/*     */     } else {
/*  85 */       numBytes = this.compressor.deflate(out, off, toWrite);
/*     */     } 
/*  87 */     compressed.writerIndex(compressed.writerIndex() + numBytes);
/*  88 */     return (numBytes == toWrite);
/*     */   }
/*     */ 
/*     */   
/*     */   public ByteBuf encode(ByteBufAllocator alloc, SpdyHeadersFrame frame) throws Exception {
/*  93 */     ObjectUtil.checkNotNullWithIAE(alloc, "alloc");
/*  94 */     ObjectUtil.checkNotNullWithIAE(frame, "frame");
/*     */     
/*  96 */     if (this.finished) {
/*  97 */       return Unpooled.EMPTY_BUFFER;
/*     */     }
/*     */     
/* 100 */     ByteBuf decompressed = super.encode(alloc, frame);
/*     */     try {
/* 102 */       if (!decompressed.isReadable()) {
/* 103 */         return Unpooled.EMPTY_BUFFER;
/*     */       }
/*     */       
/* 106 */       int len = setInput(decompressed);
/* 107 */       return encode(alloc, len);
/*     */     } finally {
/* 109 */       decompressed.release();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void end() {
/* 115 */     if (this.finished) {
/*     */       return;
/*     */     }
/* 118 */     this.finished = true;
/* 119 */     this.compressor.end();
/* 120 */     super.end();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http-4.1.93.Final.jar!\io\netty\handler\codec\spdy\SpdyHeaderBlockZlibEncoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */