/*     */ package io.netty.handler.codec.http;
/*     */ 
/*     */ import io.netty.util.AsciiString;
/*     */ import io.netty.util.CharsetUtil;
/*     */ import io.netty.util.NetUtil;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.URI;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.IllegalCharsetNameException;
/*     */ import java.nio.charset.UnsupportedCharsetException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class HttpUtil
/*     */ {
/*  41 */   private static final AsciiString CHARSET_EQUALS = AsciiString.of(HttpHeaderValues.CHARSET + "=");
/*  42 */   private static final AsciiString SEMICOLON = AsciiString.cached(";");
/*  43 */   private static final String COMMA_STRING = String.valueOf(',');
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isOriginForm(URI uri) {
/*  52 */     return isOriginForm(uri.toString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isOriginForm(String uri) {
/*  60 */     return uri.startsWith("/");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isAsteriskForm(URI uri) {
/*  68 */     return isAsteriskForm(uri.toString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isAsteriskForm(String uri) {
/*  76 */     return "*".equals(uri);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isKeepAlive(HttpMessage message) {
/*  87 */     return (!message.headers().containsValue((CharSequence)HttpHeaderNames.CONNECTION, (CharSequence)HttpHeaderValues.CLOSE, true) && (message
/*  88 */       .protocolVersion().isKeepAliveDefault() || message
/*  89 */       .headers().containsValue((CharSequence)HttpHeaderNames.CONNECTION, (CharSequence)HttpHeaderValues.KEEP_ALIVE, true)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setKeepAlive(HttpMessage message, boolean keepAlive) {
/* 113 */     setKeepAlive(message.headers(), message.protocolVersion(), keepAlive);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setKeepAlive(HttpHeaders h, HttpVersion httpVersion, boolean keepAlive) {
/* 136 */     if (httpVersion.isKeepAliveDefault()) {
/* 137 */       if (keepAlive) {
/* 138 */         h.remove((CharSequence)HttpHeaderNames.CONNECTION);
/*     */       } else {
/* 140 */         h.set((CharSequence)HttpHeaderNames.CONNECTION, HttpHeaderValues.CLOSE);
/*     */       }
/*     */     
/* 143 */     } else if (keepAlive) {
/* 144 */       h.set((CharSequence)HttpHeaderNames.CONNECTION, HttpHeaderValues.KEEP_ALIVE);
/*     */     } else {
/* 146 */       h.remove((CharSequence)HttpHeaderNames.CONNECTION);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long getContentLength(HttpMessage message) {
/* 164 */     String value = message.headers().get((CharSequence)HttpHeaderNames.CONTENT_LENGTH);
/* 165 */     if (value != null) {
/* 166 */       return Long.parseLong(value);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 171 */     long webSocketContentLength = getWebSocketContentLength(message);
/* 172 */     if (webSocketContentLength >= 0L) {
/* 173 */       return webSocketContentLength;
/*     */     }
/*     */ 
/*     */     
/* 177 */     throw new NumberFormatException("header not found: " + HttpHeaderNames.CONTENT_LENGTH);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long getContentLength(HttpMessage message, long defaultValue) {
/* 191 */     String value = message.headers().get((CharSequence)HttpHeaderNames.CONTENT_LENGTH);
/* 192 */     if (value != null) {
/* 193 */       return Long.parseLong(value);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 198 */     long webSocketContentLength = getWebSocketContentLength(message);
/* 199 */     if (webSocketContentLength >= 0L) {
/* 200 */       return webSocketContentLength;
/*     */     }
/*     */ 
/*     */     
/* 204 */     return defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getContentLength(HttpMessage message, int defaultValue) {
/* 216 */     return (int)Math.min(2147483647L, getContentLength(message, defaultValue));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int getWebSocketContentLength(HttpMessage message) {
/* 225 */     HttpHeaders h = message.headers();
/* 226 */     if (message instanceof HttpRequest) {
/* 227 */       HttpRequest req = (HttpRequest)message;
/* 228 */       if (HttpMethod.GET.equals(req.method()) && h
/* 229 */         .contains((CharSequence)HttpHeaderNames.SEC_WEBSOCKET_KEY1) && h
/* 230 */         .contains((CharSequence)HttpHeaderNames.SEC_WEBSOCKET_KEY2)) {
/* 231 */         return 8;
/*     */       }
/* 233 */     } else if (message instanceof HttpResponse) {
/* 234 */       HttpResponse res = (HttpResponse)message;
/* 235 */       if (res.status().code() == 101 && h
/* 236 */         .contains((CharSequence)HttpHeaderNames.SEC_WEBSOCKET_ORIGIN) && h
/* 237 */         .contains((CharSequence)HttpHeaderNames.SEC_WEBSOCKET_LOCATION)) {
/* 238 */         return 16;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 243 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setContentLength(HttpMessage message, long length) {
/* 250 */     message.headers().set((CharSequence)HttpHeaderNames.CONTENT_LENGTH, Long.valueOf(length));
/*     */   }
/*     */   
/*     */   public static boolean isContentLengthSet(HttpMessage m) {
/* 254 */     return m.headers().contains((CharSequence)HttpHeaderNames.CONTENT_LENGTH);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean is100ContinueExpected(HttpMessage message) {
/* 267 */     return (isExpectHeaderValid(message) && message
/*     */       
/* 269 */       .headers().contains((CharSequence)HttpHeaderNames.EXPECT, (CharSequence)HttpHeaderValues.CONTINUE, true));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean isUnsupportedExpectation(HttpMessage message) {
/* 281 */     if (!isExpectHeaderValid(message)) {
/* 282 */       return false;
/*     */     }
/*     */     
/* 285 */     String expectValue = message.headers().get((CharSequence)HttpHeaderNames.EXPECT);
/* 286 */     return (expectValue != null && !HttpHeaderValues.CONTINUE.toString().equalsIgnoreCase(expectValue));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isExpectHeaderValid(HttpMessage message) {
/* 295 */     return (message instanceof HttpRequest && message
/* 296 */       .protocolVersion().compareTo(HttpVersion.HTTP_1_1) >= 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void set100ContinueExpected(HttpMessage message, boolean expected) {
/* 307 */     if (expected) {
/* 308 */       message.headers().set((CharSequence)HttpHeaderNames.EXPECT, HttpHeaderValues.CONTINUE);
/*     */     } else {
/* 310 */       message.headers().remove((CharSequence)HttpHeaderNames.EXPECT);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isTransferEncodingChunked(HttpMessage message) {
/* 321 */     return message.headers().containsValue((CharSequence)HttpHeaderNames.TRANSFER_ENCODING, (CharSequence)HttpHeaderValues.CHUNKED, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setTransferEncodingChunked(HttpMessage m, boolean chunked) {
/* 333 */     if (chunked) {
/* 334 */       m.headers().set((CharSequence)HttpHeaderNames.TRANSFER_ENCODING, HttpHeaderValues.CHUNKED);
/* 335 */       m.headers().remove((CharSequence)HttpHeaderNames.CONTENT_LENGTH);
/*     */     } else {
/* 337 */       List<String> encodings = m.headers().getAll((CharSequence)HttpHeaderNames.TRANSFER_ENCODING);
/* 338 */       if (encodings.isEmpty()) {
/*     */         return;
/*     */       }
/* 341 */       List<CharSequence> values = new ArrayList<CharSequence>((Collection)encodings);
/* 342 */       Iterator<CharSequence> valuesIt = values.iterator();
/* 343 */       while (valuesIt.hasNext()) {
/* 344 */         CharSequence value = valuesIt.next();
/* 345 */         if (HttpHeaderValues.CHUNKED.contentEqualsIgnoreCase(value)) {
/* 346 */           valuesIt.remove();
/*     */         }
/*     */       } 
/* 349 */       if (values.isEmpty()) {
/* 350 */         m.headers().remove((CharSequence)HttpHeaderNames.TRANSFER_ENCODING);
/*     */       } else {
/* 352 */         m.headers().set((CharSequence)HttpHeaderNames.TRANSFER_ENCODING, values);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Charset getCharset(HttpMessage message) {
/* 365 */     return getCharset(message, CharsetUtil.ISO_8859_1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Charset getCharset(CharSequence contentTypeValue) {
/* 376 */     if (contentTypeValue != null) {
/* 377 */       return getCharset(contentTypeValue, CharsetUtil.ISO_8859_1);
/*     */     }
/* 379 */     return CharsetUtil.ISO_8859_1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Charset getCharset(HttpMessage message, Charset defaultCharset) {
/* 392 */     CharSequence contentTypeValue = message.headers().get((CharSequence)HttpHeaderNames.CONTENT_TYPE);
/* 393 */     if (contentTypeValue != null) {
/* 394 */       return getCharset(contentTypeValue, defaultCharset);
/*     */     }
/* 396 */     return defaultCharset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Charset getCharset(CharSequence contentTypeValue, Charset defaultCharset) {
/* 409 */     if (contentTypeValue != null) {
/* 410 */       CharSequence charsetRaw = getCharsetAsSequence(contentTypeValue);
/* 411 */       if (charsetRaw != null) {
/* 412 */         if (charsetRaw.length() > 2 && 
/* 413 */           charsetRaw.charAt(0) == '"' && charsetRaw.charAt(charsetRaw.length() - 1) == '"') {
/* 414 */           charsetRaw = charsetRaw.subSequence(1, charsetRaw.length() - 1);
/*     */         }
/*     */         
/*     */         try {
/* 418 */           return Charset.forName(charsetRaw.toString());
/* 419 */         } catch (IllegalCharsetNameException illegalCharsetNameException) {
/*     */         
/* 421 */         } catch (UnsupportedCharsetException unsupportedCharsetException) {}
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 426 */     return defaultCharset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static CharSequence getCharsetAsString(HttpMessage message) {
/* 442 */     return getCharsetAsSequence(message);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CharSequence getCharsetAsSequence(HttpMessage message) {
/* 455 */     CharSequence contentTypeValue = message.headers().get((CharSequence)HttpHeaderNames.CONTENT_TYPE);
/* 456 */     if (contentTypeValue != null) {
/* 457 */       return getCharsetAsSequence(contentTypeValue);
/*     */     }
/* 459 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CharSequence getCharsetAsSequence(CharSequence contentTypeValue) {
/* 475 */     ObjectUtil.checkNotNull(contentTypeValue, "contentTypeValue");
/*     */     
/* 477 */     int indexOfCharset = AsciiString.indexOfIgnoreCaseAscii(contentTypeValue, (CharSequence)CHARSET_EQUALS, 0);
/* 478 */     if (indexOfCharset == -1) {
/* 479 */       return null;
/*     */     }
/*     */     
/* 482 */     int indexOfEncoding = indexOfCharset + CHARSET_EQUALS.length();
/* 483 */     if (indexOfEncoding < contentTypeValue.length()) {
/* 484 */       CharSequence charsetCandidate = contentTypeValue.subSequence(indexOfEncoding, contentTypeValue.length());
/* 485 */       int indexOfSemicolon = AsciiString.indexOfIgnoreCaseAscii(charsetCandidate, (CharSequence)SEMICOLON, 0);
/* 486 */       if (indexOfSemicolon == -1) {
/* 487 */         return charsetCandidate;
/*     */       }
/*     */       
/* 490 */       return charsetCandidate.subSequence(0, indexOfSemicolon);
/*     */     } 
/*     */     
/* 493 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CharSequence getMimeType(HttpMessage message) {
/* 508 */     CharSequence contentTypeValue = message.headers().get((CharSequence)HttpHeaderNames.CONTENT_TYPE);
/* 509 */     if (contentTypeValue != null) {
/* 510 */       return getMimeType(contentTypeValue);
/*     */     }
/* 512 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CharSequence getMimeType(CharSequence contentTypeValue) {
/* 529 */     ObjectUtil.checkNotNull(contentTypeValue, "contentTypeValue");
/*     */     
/* 531 */     int indexOfSemicolon = AsciiString.indexOfIgnoreCaseAscii(contentTypeValue, (CharSequence)SEMICOLON, 0);
/* 532 */     if (indexOfSemicolon != -1) {
/* 533 */       return contentTypeValue.subSequence(0, indexOfSemicolon);
/*     */     }
/* 535 */     return (contentTypeValue.length() > 0) ? contentTypeValue : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String formatHostnameForHttp(InetSocketAddress addr) {
/* 547 */     String hostString = NetUtil.getHostname(addr);
/* 548 */     if (NetUtil.isValidIpV6Address(hostString)) {
/* 549 */       if (!addr.isUnresolved()) {
/* 550 */         hostString = NetUtil.toAddressString(addr.getAddress());
/*     */       }
/* 552 */       return '[' + hostString + ']';
/*     */     } 
/* 554 */     return hostString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long normalizeAndGetContentLength(List<? extends CharSequence> contentLengthFields, boolean isHttp10OrEarlier, boolean allowDuplicateContentLengths) {
/* 571 */     if (contentLengthFields.isEmpty()) {
/* 572 */       return -1L;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 588 */     String firstField = ((CharSequence)contentLengthFields.get(0)).toString();
/*     */     
/* 590 */     boolean multipleContentLengths = (contentLengthFields.size() > 1 || firstField.indexOf(',') >= 0);
/*     */     
/* 592 */     if (multipleContentLengths && !isHttp10OrEarlier) {
/* 593 */       if (allowDuplicateContentLengths) {
/*     */         
/* 595 */         String firstValue = null;
/* 596 */         for (CharSequence field : contentLengthFields) {
/* 597 */           String[] tokens = field.toString().split(COMMA_STRING, -1);
/* 598 */           for (String token : tokens) {
/* 599 */             String trimmed = token.trim();
/* 600 */             if (firstValue == null) {
/* 601 */               firstValue = trimmed;
/* 602 */             } else if (!trimmed.equals(firstValue)) {
/* 603 */               throw new IllegalArgumentException("Multiple Content-Length values found: " + contentLengthFields);
/*     */             } 
/*     */           } 
/*     */         } 
/*     */ 
/*     */         
/* 609 */         firstField = firstValue;
/*     */       } else {
/*     */         
/* 612 */         throw new IllegalArgumentException("Multiple Content-Length values found: " + contentLengthFields);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 618 */     if (firstField.isEmpty() || !Character.isDigit(firstField.charAt(0)))
/*     */     {
/* 620 */       throw new IllegalArgumentException("Content-Length value is not a number: " + firstField);
/*     */     }
/*     */     
/*     */     try {
/* 624 */       long value = Long.parseLong(firstField);
/* 625 */       return ObjectUtil.checkPositiveOrZero(value, "Content-Length value");
/* 626 */     } catch (NumberFormatException e) {
/*     */       
/* 628 */       throw new IllegalArgumentException("Content-Length value is not a number: " + firstField, e);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http-4.1.93.Final.jar!\io\netty\handler\codec\http\HttpUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */