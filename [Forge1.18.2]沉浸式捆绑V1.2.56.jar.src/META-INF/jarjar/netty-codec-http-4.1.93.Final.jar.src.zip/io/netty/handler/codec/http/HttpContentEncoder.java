/*     */ package io.netty.handler.codec.http;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.buffer.ByteBufHolder;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.channel.embedded.EmbeddedChannel;
/*     */ import io.netty.handler.codec.DecoderResult;
/*     */ import io.netty.handler.codec.MessageToMessageCodec;
/*     */ import io.netty.util.ReferenceCountUtil;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import io.netty.util.internal.StringUtil;
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.List;
/*     */ import java.util.Queue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class HttpContentEncoder
/*     */   extends MessageToMessageCodec<HttpRequest, HttpObject>
/*     */ {
/*     */   private enum State
/*     */   {
/*  59 */     PASS_THROUGH,
/*  60 */     AWAIT_HEADERS,
/*  61 */     AWAIT_CONTENT;
/*     */   }
/*     */   
/*  64 */   private static final CharSequence ZERO_LENGTH_HEAD = "HEAD";
/*  65 */   private static final CharSequence ZERO_LENGTH_CONNECT = "CONNECT";
/*     */   
/*  67 */   private final Queue<CharSequence> acceptEncodingQueue = new ArrayDeque<CharSequence>();
/*     */   private EmbeddedChannel encoder;
/*  69 */   private State state = State.AWAIT_HEADERS;
/*     */ 
/*     */   
/*     */   public boolean acceptOutboundMessage(Object msg) throws Exception {
/*  73 */     return (msg instanceof HttpContent || msg instanceof HttpResponse);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void decode(ChannelHandlerContext ctx, HttpRequest msg, List<Object> out) throws Exception {
/*     */     CharSequence acceptEncoding;
/*  79 */     List<String> acceptEncodingHeaders = msg.headers().getAll((CharSequence)HttpHeaderNames.ACCEPT_ENCODING);
/*  80 */     switch (acceptEncodingHeaders.size()) {
/*     */       case 0:
/*  82 */         acceptEncoding = HttpContentDecoder.IDENTITY;
/*     */         break;
/*     */       case 1:
/*  85 */         acceptEncoding = acceptEncodingHeaders.get(0);
/*     */         break;
/*     */       
/*     */       default:
/*  89 */         acceptEncoding = StringUtil.join(",", acceptEncodingHeaders);
/*     */         break;
/*     */     } 
/*     */     
/*  93 */     HttpMethod method = msg.method();
/*  94 */     if (HttpMethod.HEAD.equals(method)) {
/*  95 */       acceptEncoding = ZERO_LENGTH_HEAD;
/*  96 */     } else if (HttpMethod.CONNECT.equals(method)) {
/*  97 */       acceptEncoding = ZERO_LENGTH_CONNECT;
/*     */     } 
/*     */     
/* 100 */     this.acceptEncodingQueue.add(acceptEncoding);
/* 101 */     out.add(ReferenceCountUtil.retain(msg)); } protected void encode(ChannelHandlerContext ctx, HttpObject msg, List<Object> out) throws Exception { HttpResponse res;
/*     */     int code;
/*     */     HttpStatusClass codeClass;
/*     */     CharSequence acceptEncoding;
/*     */     Result result;
/* 106 */     boolean isFull = (msg instanceof HttpResponse && msg instanceof LastHttpContent);
/* 107 */     switch (this.state) {
/*     */       case AWAIT_HEADERS:
/* 109 */         ensureHeaders(msg);
/* 110 */         assert this.encoder == null;
/*     */         
/* 112 */         res = (HttpResponse)msg;
/* 113 */         code = res.status().code();
/* 114 */         codeClass = res.status().codeClass();
/*     */         
/* 116 */         if (codeClass == HttpStatusClass.INFORMATIONAL) {
/*     */ 
/*     */ 
/*     */           
/* 120 */           acceptEncoding = null;
/*     */         } else {
/*     */           
/* 123 */           acceptEncoding = this.acceptEncodingQueue.poll();
/* 124 */           if (acceptEncoding == null) {
/* 125 */             throw new IllegalStateException("cannot send more responses than requests");
/*     */           }
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 142 */         if (isPassthru(res.protocolVersion(), code, acceptEncoding)) {
/* 143 */           if (isFull) {
/* 144 */             out.add(ReferenceCountUtil.retain(res)); break;
/*     */           } 
/* 146 */           out.add(ReferenceCountUtil.retain(res));
/*     */           
/* 148 */           this.state = State.PASS_THROUGH;
/*     */           
/*     */           break;
/*     */         } 
/*     */         
/* 153 */         if (isFull)
/*     */         {
/* 155 */           if (!((ByteBufHolder)res).content().isReadable()) {
/* 156 */             out.add(ReferenceCountUtil.retain(res));
/*     */             
/*     */             break;
/*     */           } 
/*     */         }
/*     */         
/* 162 */         result = beginEncode(res, acceptEncoding.toString());
/*     */ 
/*     */         
/* 165 */         if (result == null) {
/* 166 */           if (isFull) {
/* 167 */             out.add(ReferenceCountUtil.retain(res)); break;
/*     */           } 
/* 169 */           out.add(ReferenceCountUtil.retain(res));
/*     */           
/* 171 */           this.state = State.PASS_THROUGH;
/*     */           
/*     */           break;
/*     */         } 
/*     */         
/* 176 */         this.encoder = result.contentEncoder();
/*     */ 
/*     */ 
/*     */         
/* 180 */         res.headers().set((CharSequence)HttpHeaderNames.CONTENT_ENCODING, result.targetContentEncoding());
/*     */ 
/*     */         
/* 183 */         if (isFull) {
/*     */           
/* 185 */           HttpResponse newRes = new DefaultHttpResponse(res.protocolVersion(), res.status());
/* 186 */           newRes.headers().set(res.headers());
/* 187 */           out.add(newRes);
/*     */           
/* 189 */           ensureContent(res);
/* 190 */           encodeFullResponse(newRes, (HttpContent)res, out);
/*     */           
/*     */           break;
/*     */         } 
/* 194 */         res.headers().remove((CharSequence)HttpHeaderNames.CONTENT_LENGTH);
/* 195 */         res.headers().set((CharSequence)HttpHeaderNames.TRANSFER_ENCODING, HttpHeaderValues.CHUNKED);
/*     */         
/* 197 */         out.add(ReferenceCountUtil.retain(res));
/* 198 */         this.state = State.AWAIT_CONTENT;
/* 199 */         if (!(msg instanceof HttpContent)) {
/*     */           break;
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case AWAIT_CONTENT:
/* 208 */         ensureContent(msg);
/* 209 */         if (encodeContent((HttpContent)msg, out)) {
/* 210 */           this.state = State.AWAIT_HEADERS;
/*     */         }
/*     */         break;
/*     */       
/*     */       case PASS_THROUGH:
/* 215 */         ensureContent(msg);
/* 216 */         out.add(ReferenceCountUtil.retain(msg));
/*     */         
/* 218 */         if (msg instanceof LastHttpContent) {
/* 219 */           this.state = State.AWAIT_HEADERS;
/*     */         }
/*     */         break;
/*     */     }  }
/*     */ 
/*     */ 
/*     */   
/*     */   private void encodeFullResponse(HttpResponse newRes, HttpContent content, List<Object> out) {
/* 227 */     int existingMessages = out.size();
/* 228 */     encodeContent(content, out);
/*     */     
/* 230 */     if (HttpUtil.isContentLengthSet(newRes)) {
/*     */       
/* 232 */       int messageSize = 0;
/* 233 */       for (int i = existingMessages; i < out.size(); i++) {
/* 234 */         Object item = out.get(i);
/* 235 */         if (item instanceof HttpContent) {
/* 236 */           messageSize += ((HttpContent)item).content().readableBytes();
/*     */         }
/*     */       } 
/* 239 */       HttpUtil.setContentLength(newRes, messageSize);
/*     */     } else {
/* 241 */       newRes.headers().set((CharSequence)HttpHeaderNames.TRANSFER_ENCODING, HttpHeaderValues.CHUNKED);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static boolean isPassthru(HttpVersion version, int code, CharSequence httpMethod) {
/* 246 */     return (code < 200 || code == 204 || code == 304 || httpMethod == ZERO_LENGTH_HEAD || (httpMethod == ZERO_LENGTH_CONNECT && code == 200) || version == HttpVersion.HTTP_1_0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static void ensureHeaders(HttpObject msg) {
/* 252 */     if (!(msg instanceof HttpResponse)) {
/* 253 */       throw new IllegalStateException("unexpected message type: " + msg
/*     */           
/* 255 */           .getClass().getName() + " (expected: " + HttpResponse.class.getSimpleName() + ')');
/*     */     }
/*     */   }
/*     */   
/*     */   private static void ensureContent(HttpObject msg) {
/* 260 */     if (!(msg instanceof HttpContent)) {
/* 261 */       throw new IllegalStateException("unexpected message type: " + msg
/*     */           
/* 263 */           .getClass().getName() + " (expected: " + HttpContent.class.getSimpleName() + ')');
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean encodeContent(HttpContent c, List<Object> out) {
/* 268 */     ByteBuf content = c.content();
/*     */     
/* 270 */     encode(content, out);
/*     */     
/* 272 */     if (c instanceof LastHttpContent) {
/* 273 */       finishEncode(out);
/* 274 */       LastHttpContent last = (LastHttpContent)c;
/*     */ 
/*     */ 
/*     */       
/* 278 */       HttpHeaders headers = last.trailingHeaders();
/* 279 */       if (headers.isEmpty()) {
/* 280 */         out.add(LastHttpContent.EMPTY_LAST_CONTENT);
/*     */       } else {
/* 282 */         out.add(new ComposedLastHttpContent(headers, DecoderResult.SUCCESS));
/*     */       } 
/* 284 */       return true;
/*     */     } 
/* 286 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void handlerRemoved(ChannelHandlerContext ctx) throws Exception {
/* 307 */     cleanupSafely(ctx);
/* 308 */     super.handlerRemoved(ctx);
/*     */   }
/*     */ 
/*     */   
/*     */   public void channelInactive(ChannelHandlerContext ctx) throws Exception {
/* 313 */     cleanupSafely(ctx);
/* 314 */     super.channelInactive(ctx);
/*     */   }
/*     */   
/*     */   private void cleanup() {
/* 318 */     if (this.encoder != null) {
/*     */       
/* 320 */       this.encoder.finishAndReleaseAll();
/* 321 */       this.encoder = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void cleanupSafely(ChannelHandlerContext ctx) {
/*     */     try {
/* 327 */       cleanup();
/* 328 */     } catch (Throwable cause) {
/*     */ 
/*     */       
/* 331 */       ctx.fireExceptionCaught(cause);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void encode(ByteBuf in, List<Object> out) {
/* 337 */     this.encoder.writeOutbound(new Object[] { in.retain() });
/* 338 */     fetchEncoderOutput(out);
/*     */   }
/*     */   
/*     */   private void finishEncode(List<Object> out) {
/* 342 */     if (this.encoder.finish()) {
/* 343 */       fetchEncoderOutput(out);
/*     */     }
/* 345 */     this.encoder = null;
/*     */   }
/*     */   
/*     */   private void fetchEncoderOutput(List<Object> out) {
/*     */     while (true) {
/* 350 */       ByteBuf buf = (ByteBuf)this.encoder.readOutbound();
/* 351 */       if (buf == null) {
/*     */         break;
/*     */       }
/* 354 */       if (!buf.isReadable()) {
/* 355 */         buf.release();
/*     */         continue;
/*     */       } 
/* 358 */       out.add(new DefaultHttpContent(buf));
/*     */     } 
/*     */   }
/*     */   protected abstract Result beginEncode(HttpResponse paramHttpResponse, String paramString) throws Exception;
/*     */   
/*     */   public static final class Result { private final String targetContentEncoding;
/*     */     private final EmbeddedChannel contentEncoder;
/*     */     
/*     */     public Result(String targetContentEncoding, EmbeddedChannel contentEncoder) {
/* 367 */       this.targetContentEncoding = (String)ObjectUtil.checkNotNull(targetContentEncoding, "targetContentEncoding");
/* 368 */       this.contentEncoder = (EmbeddedChannel)ObjectUtil.checkNotNull(contentEncoder, "contentEncoder");
/*     */     }
/*     */     
/*     */     public String targetContentEncoding() {
/* 372 */       return this.targetContentEncoding;
/*     */     }
/*     */     
/*     */     public EmbeddedChannel contentEncoder() {
/* 376 */       return this.contentEncoder;
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http-4.1.93.Final.jar!\io\netty\handler\codec\http\HttpContentEncoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */