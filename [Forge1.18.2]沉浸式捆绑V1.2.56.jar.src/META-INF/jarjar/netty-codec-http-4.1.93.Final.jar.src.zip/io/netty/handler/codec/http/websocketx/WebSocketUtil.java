/*     */ package io.netty.handler.codec.http.websocketx;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.buffer.Unpooled;
/*     */ import io.netty.handler.codec.base64.Base64;
/*     */ import io.netty.util.CharsetUtil;
/*     */ import io.netty.util.concurrent.FastThreadLocal;
/*     */ import io.netty.util.internal.PlatformDependent;
/*     */ import io.netty.util.internal.SuppressJava6Requirement;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.util.Base64;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class WebSocketUtil
/*     */ {
/*  34 */   private static final FastThreadLocal<MessageDigest> MD5 = new FastThreadLocal<MessageDigest>()
/*     */     {
/*     */ 
/*     */       
/*     */       protected MessageDigest initialValue() throws Exception
/*     */       {
/*     */         try {
/*  41 */           return MessageDigest.getInstance("MD5");
/*  42 */         } catch (NoSuchAlgorithmException e) {
/*     */           
/*  44 */           throw new InternalError("MD5 not supported on this platform - Outdated?");
/*     */         } 
/*     */       }
/*     */     };
/*     */   
/*  49 */   private static final FastThreadLocal<MessageDigest> SHA1 = new FastThreadLocal<MessageDigest>()
/*     */     {
/*     */ 
/*     */       
/*     */       protected MessageDigest initialValue() throws Exception
/*     */       {
/*     */         try {
/*  56 */           return MessageDigest.getInstance("SHA1");
/*  57 */         } catch (NoSuchAlgorithmException e) {
/*     */           
/*  59 */           throw new InternalError("SHA-1 not supported on this platform - Outdated?");
/*     */         } 
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static byte[] md5(byte[] data) {
/*  72 */     return digest(MD5, data);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static byte[] sha1(byte[] data) {
/*  83 */     return digest(SHA1, data);
/*     */   }
/*     */   
/*     */   private static byte[] digest(FastThreadLocal<MessageDigest> digestFastThreadLocal, byte[] data) {
/*  87 */     MessageDigest digest = (MessageDigest)digestFastThreadLocal.get();
/*  88 */     digest.reset();
/*  89 */     return digest.digest(data);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SuppressJava6Requirement(reason = "Guarded with java version check")
/*     */   static String base64(byte[] data) {
/*     */     String encodedString;
/* 100 */     if (PlatformDependent.javaVersion() >= 8) {
/* 101 */       return Base64.getEncoder().encodeToString(data);
/*     */     }
/*     */     
/* 104 */     ByteBuf encodedData = Unpooled.wrappedBuffer(data);
/*     */     try {
/* 106 */       ByteBuf encoded = Base64.encode(encodedData);
/*     */       try {
/* 108 */         encodedString = encoded.toString(CharsetUtil.UTF_8);
/*     */       } finally {
/* 110 */         encoded.release();
/*     */       } 
/*     */     } finally {
/* 113 */       encodedData.release();
/*     */     } 
/* 115 */     return encodedString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static byte[] randomBytes(int size) {
/* 125 */     byte[] bytes = new byte[size];
/* 126 */     PlatformDependent.threadLocalRandom().nextBytes(bytes);
/* 127 */     return bytes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int randomNumber(int minimum, int maximum) {
/* 138 */     assert minimum < maximum;
/* 139 */     double fraction = PlatformDependent.threadLocalRandom().nextDouble();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 160 */     return (int)(minimum + fraction * (maximum - minimum));
/*     */   }
/*     */   
/*     */   static int byteAtIndex(int mask, int index) {
/* 164 */     return mask >> 8 * (3 - index) & 0xFF;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http-4.1.93.Final.jar!\io\netty\handler\codec\http\websocketx\WebSocketUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */