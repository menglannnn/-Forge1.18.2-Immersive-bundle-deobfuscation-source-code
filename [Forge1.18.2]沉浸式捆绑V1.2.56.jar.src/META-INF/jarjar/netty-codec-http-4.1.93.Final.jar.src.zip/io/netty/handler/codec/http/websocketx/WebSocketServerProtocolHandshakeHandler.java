/*     */ package io.netty.handler.codec.http.websocketx;
/*     */ 
/*     */ import io.netty.channel.ChannelFuture;
/*     */ import io.netty.channel.ChannelFutureListener;
/*     */ import io.netty.channel.ChannelHandler;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.channel.ChannelInboundHandlerAdapter;
/*     */ import io.netty.channel.ChannelPipeline;
/*     */ import io.netty.channel.ChannelPromise;
/*     */ import io.netty.handler.codec.http.HttpHeaderNames;
/*     */ import io.netty.handler.codec.http.HttpMessage;
/*     */ import io.netty.handler.codec.http.HttpObject;
/*     */ import io.netty.handler.codec.http.HttpRequest;
/*     */ import io.netty.handler.codec.http.HttpResponse;
/*     */ import io.netty.handler.codec.http.HttpUtil;
/*     */ import io.netty.handler.ssl.SslHandler;
/*     */ import io.netty.util.ReferenceCountUtil;
/*     */ import io.netty.util.concurrent.Future;
/*     */ import io.netty.util.concurrent.FutureListener;
/*     */ import io.netty.util.concurrent.GenericFutureListener;
/*     */ import io.netty.util.concurrent.ScheduledFuture;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class WebSocketServerProtocolHandshakeHandler
/*     */   extends ChannelInboundHandlerAdapter
/*     */ {
/*     */   private final WebSocketServerProtocolConfig serverConfig;
/*     */   private ChannelHandlerContext ctx;
/*     */   private ChannelPromise handshakePromise;
/*     */   private boolean isWebSocketPath;
/*     */   
/*     */   WebSocketServerProtocolHandshakeHandler(WebSocketServerProtocolConfig serverConfig) {
/*  54 */     this.serverConfig = (WebSocketServerProtocolConfig)ObjectUtil.checkNotNull(serverConfig, "serverConfig");
/*     */   }
/*     */ 
/*     */   
/*     */   public void handlerAdded(ChannelHandlerContext ctx) {
/*  59 */     this.ctx = ctx;
/*  60 */     this.handshakePromise = ctx.newPromise();
/*     */   }
/*     */ 
/*     */   
/*     */   public void channelRead(final ChannelHandlerContext ctx, Object msg) throws Exception {
/*  65 */     HttpObject httpObject = (HttpObject)msg;
/*     */     
/*  67 */     if (httpObject instanceof HttpRequest) {
/*  68 */       final HttpRequest req = (HttpRequest)httpObject;
/*  69 */       this.isWebSocketPath = isWebSocketPath(req);
/*  70 */       if (!this.isWebSocketPath) {
/*  71 */         ctx.fireChannelRead(msg);
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/*     */       try {
/*  78 */         WebSocketServerHandshakerFactory wsFactory = new WebSocketServerHandshakerFactory(getWebSocketLocation(ctx.pipeline(), req, this.serverConfig.websocketPath()), this.serverConfig.subprotocols(), this.serverConfig.decoderConfig());
/*  79 */         final WebSocketServerHandshaker handshaker = wsFactory.newHandshaker(req);
/*  80 */         final ChannelPromise localHandshakePromise = this.handshakePromise;
/*  81 */         if (handshaker == null) {
/*  82 */           WebSocketServerHandshakerFactory.sendUnsupportedVersionResponse(ctx.channel());
/*     */ 
/*     */         
/*     */         }
/*     */         else {
/*     */ 
/*     */           
/*  89 */           WebSocketServerProtocolHandler.setHandshaker(ctx.channel(), handshaker);
/*  90 */           ctx.pipeline().remove((ChannelHandler)this);
/*     */           
/*  92 */           ChannelFuture handshakeFuture = handshaker.handshake(ctx.channel(), req);
/*  93 */           handshakeFuture.addListener((GenericFutureListener)new ChannelFutureListener()
/*     */               {
/*     */                 public void operationComplete(ChannelFuture future) {
/*  96 */                   if (!future.isSuccess()) {
/*  97 */                     localHandshakePromise.tryFailure(future.cause());
/*  98 */                     ctx.fireExceptionCaught(future.cause());
/*     */                   } else {
/* 100 */                     localHandshakePromise.trySuccess();
/*     */                     
/* 102 */                     ctx.fireUserEventTriggered(WebSocketServerProtocolHandler.ServerHandshakeStateEvent.HANDSHAKE_COMPLETE);
/*     */                     
/* 104 */                     ctx.fireUserEventTriggered(new WebSocketServerProtocolHandler.HandshakeComplete(req
/*     */                           
/* 106 */                           .uri(), req.headers(), handshaker.selectedSubprotocol()));
/*     */                   } 
/*     */                 }
/*     */               });
/* 110 */           applyHandshakeTimeout();
/*     */         } 
/*     */       } finally {
/* 113 */         ReferenceCountUtil.release(req);
/*     */       } 
/* 115 */     } else if (!this.isWebSocketPath) {
/* 116 */       ctx.fireChannelRead(msg);
/*     */     } else {
/* 118 */       ReferenceCountUtil.release(msg);
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isWebSocketPath(HttpRequest req) {
/* 123 */     String websocketPath = this.serverConfig.websocketPath();
/* 124 */     String uri = req.uri();
/* 125 */     boolean checkStartUri = uri.startsWith(websocketPath);
/* 126 */     boolean checkNextUri = ("/".equals(websocketPath) || checkNextUri(uri, websocketPath));
/* 127 */     return this.serverConfig.checkStartsWith() ? ((checkStartUri && checkNextUri)) : uri.equals(websocketPath);
/*     */   }
/*     */   
/*     */   private boolean checkNextUri(String uri, String websocketPath) {
/* 131 */     int len = websocketPath.length();
/* 132 */     if (uri.length() > len) {
/* 133 */       char nextUri = uri.charAt(len);
/* 134 */       return (nextUri == '/' || nextUri == '?');
/*     */     } 
/* 136 */     return true;
/*     */   }
/*     */   
/*     */   private static void sendHttpResponse(ChannelHandlerContext ctx, HttpRequest req, HttpResponse res) {
/* 140 */     ChannelFuture f = ctx.writeAndFlush(res);
/* 141 */     if (!HttpUtil.isKeepAlive((HttpMessage)req) || res.status().code() != 200) {
/* 142 */       f.addListener((GenericFutureListener)ChannelFutureListener.CLOSE);
/*     */     }
/*     */   }
/*     */   
/*     */   private static String getWebSocketLocation(ChannelPipeline cp, HttpRequest req, String path) {
/* 147 */     String protocol = "ws";
/* 148 */     if (cp.get(SslHandler.class) != null)
/*     */     {
/* 150 */       protocol = "wss";
/*     */     }
/* 152 */     String host = req.headers().get((CharSequence)HttpHeaderNames.HOST);
/* 153 */     return protocol + "://" + host + path;
/*     */   }
/*     */   
/*     */   private void applyHandshakeTimeout() {
/* 157 */     final ChannelPromise localHandshakePromise = this.handshakePromise;
/* 158 */     long handshakeTimeoutMillis = this.serverConfig.handshakeTimeoutMillis();
/* 159 */     if (handshakeTimeoutMillis <= 0L || localHandshakePromise.isDone()) {
/*     */       return;
/*     */     }
/*     */     
/* 163 */     final ScheduledFuture timeoutFuture = this.ctx.executor().schedule(new Runnable()
/*     */         {
/*     */           public void run() {
/* 166 */             if (!localHandshakePromise.isDone() && localHandshakePromise
/* 167 */               .tryFailure(new WebSocketServerHandshakeException("handshake timed out"))) {
/* 168 */               WebSocketServerProtocolHandshakeHandler.this.ctx.flush()
/* 169 */                 .fireUserEventTriggered(WebSocketServerProtocolHandler.ServerHandshakeStateEvent.HANDSHAKE_TIMEOUT)
/* 170 */                 .close();
/*     */             }
/*     */           }
/*     */         },  handshakeTimeoutMillis, TimeUnit.MILLISECONDS);
/*     */ 
/*     */     
/* 176 */     localHandshakePromise.addListener((GenericFutureListener)new FutureListener<Void>()
/*     */         {
/*     */           public void operationComplete(Future<Void> f) {
/* 179 */             timeoutFuture.cancel(false);
/*     */           }
/*     */         });
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http-4.1.93.Final.jar!\io\netty\handler\codec\http\websocketx\WebSocketServerProtocolHandshakeHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */