/*      */ package io.netty.handler.codec.http;
/*      */ 
/*      */ import io.netty.buffer.ByteBuf;
/*      */ import io.netty.buffer.Unpooled;
/*      */ import io.netty.channel.ChannelHandlerContext;
/*      */ import io.netty.handler.codec.ByteToMessageDecoder;
/*      */ import io.netty.handler.codec.DecoderResult;
/*      */ import io.netty.handler.codec.PrematureChannelClosureException;
/*      */ import io.netty.handler.codec.TooLongFrameException;
/*      */ import io.netty.util.AsciiString;
/*      */ import io.netty.util.ByteProcessor;
/*      */ import io.netty.util.internal.ObjectUtil;
/*      */ import io.netty.util.internal.StringUtil;
/*      */ import java.util.List;
/*      */ import java.util.concurrent.atomic.AtomicBoolean;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class HttpObjectDecoder
/*      */   extends ByteToMessageDecoder
/*      */ {
/*      */   public static final int DEFAULT_MAX_INITIAL_LINE_LENGTH = 4096;
/*      */   public static final int DEFAULT_MAX_HEADER_SIZE = 8192;
/*      */   public static final boolean DEFAULT_CHUNKED_SUPPORTED = true;
/*      */   public static final boolean DEFAULT_ALLOW_PARTIAL_CHUNKS = true;
/*      */   public static final int DEFAULT_MAX_CHUNK_SIZE = 8192;
/*      */   public static final boolean DEFAULT_VALIDATE_HEADERS = true;
/*      */   public static final int DEFAULT_INITIAL_BUFFER_SIZE = 128;
/*      */   public static final boolean DEFAULT_ALLOW_DUPLICATE_CONTENT_LENGTHS = false;
/*      */   private final int maxChunkSize;
/*      */   private final boolean chunkedSupported;
/*      */   private final boolean allowPartialChunks;
/*      */   protected final boolean validateHeaders;
/*      */   private final boolean allowDuplicateContentLengths;
/*      */   private final ByteBuf parserScratchBuffer;
/*      */   private final HeaderParser headerParser;
/*      */   private final LineParser lineParser;
/*      */   private HttpMessage message;
/*      */   private long chunkSize;
/*  153 */   private long contentLength = Long.MIN_VALUE;
/*  154 */   private final AtomicBoolean resetRequested = new AtomicBoolean();
/*      */   
/*      */   private AsciiString name;
/*      */   
/*      */   private String value;
/*      */   
/*      */   private LastHttpContent trailer;
/*      */   
/*      */   protected void handlerRemoved0(ChannelHandlerContext ctx) throws Exception {
/*      */     try {
/*  164 */       this.parserScratchBuffer.release();
/*      */     } finally {
/*  166 */       super.handlerRemoved0(ctx);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private enum State
/*      */   {
/*  175 */     SKIP_CONTROL_CHARS,
/*  176 */     READ_INITIAL,
/*  177 */     READ_HEADER,
/*  178 */     READ_VARIABLE_LENGTH_CONTENT,
/*  179 */     READ_FIXED_LENGTH_CONTENT,
/*  180 */     READ_CHUNK_SIZE,
/*  181 */     READ_CHUNKED_CONTENT,
/*  182 */     READ_CHUNK_DELIMITER,
/*  183 */     READ_CHUNK_FOOTER,
/*  184 */     BAD_MESSAGE,
/*  185 */     UPGRADED;
/*      */   }
/*      */   
/*  188 */   private State currentState = State.SKIP_CONTROL_CHARS;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected HttpObjectDecoder() {
/*  196 */     this(4096, 8192, 8192, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected HttpObjectDecoder(int maxInitialLineLength, int maxHeaderSize, int maxChunkSize, boolean chunkedSupported) {
/*  205 */     this(maxInitialLineLength, maxHeaderSize, maxChunkSize, chunkedSupported, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected HttpObjectDecoder(int maxInitialLineLength, int maxHeaderSize, int maxChunkSize, boolean chunkedSupported, boolean validateHeaders) {
/*  214 */     this(maxInitialLineLength, maxHeaderSize, maxChunkSize, chunkedSupported, validateHeaders, 128);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected HttpObjectDecoder(int maxInitialLineLength, int maxHeaderSize, int maxChunkSize, boolean chunkedSupported, boolean validateHeaders, int initialBufferSize) {
/*  224 */     this(maxInitialLineLength, maxHeaderSize, maxChunkSize, chunkedSupported, validateHeaders, initialBufferSize, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected HttpObjectDecoder(int maxInitialLineLength, int maxHeaderSize, int maxChunkSize, boolean chunkedSupported, boolean validateHeaders, int initialBufferSize, boolean allowDuplicateContentLengths) {
/*  235 */     this(maxInitialLineLength, maxHeaderSize, maxChunkSize, chunkedSupported, validateHeaders, initialBufferSize, allowDuplicateContentLengths, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected HttpObjectDecoder(int maxInitialLineLength, int maxHeaderSize, int maxChunkSize, boolean chunkedSupported, boolean validateHeaders, int initialBufferSize, boolean allowDuplicateContentLengths, boolean allowPartialChunks) {
/*  246 */     ObjectUtil.checkPositive(maxInitialLineLength, "maxInitialLineLength");
/*  247 */     ObjectUtil.checkPositive(maxHeaderSize, "maxHeaderSize");
/*  248 */     ObjectUtil.checkPositive(maxChunkSize, "maxChunkSize");
/*      */     
/*  250 */     this.parserScratchBuffer = Unpooled.buffer(initialBufferSize);
/*  251 */     this.lineParser = new LineParser(this.parserScratchBuffer, maxInitialLineLength);
/*  252 */     this.headerParser = new HeaderParser(this.parserScratchBuffer, maxHeaderSize);
/*  253 */     this.maxChunkSize = maxChunkSize;
/*  254 */     this.chunkedSupported = chunkedSupported;
/*  255 */     this.validateHeaders = validateHeaders;
/*  256 */     this.allowDuplicateContentLengths = allowDuplicateContentLengths;
/*  257 */     this.allowPartialChunks = allowPartialChunks; } protected void decode(ChannelHandlerContext ctx, ByteBuf buffer, List<Object> out) throws Exception { int i; int readLimit; int toRead; int wIdx; int readableBytes;
/*      */     int j;
/*      */     HttpContent chunk;
/*      */     int rIdx;
/*      */     ByteBuf content;
/*  262 */     if (this.resetRequested.get()) {
/*  263 */       resetNow();
/*      */     }
/*      */     
/*  266 */     switch (this.currentState) {
/*      */       case SKIP_CONTROL_CHARS:
/*      */       case READ_INITIAL:
/*      */         try {
/*  270 */           ByteBuf line = this.lineParser.parse(buffer);
/*  271 */           if (line == null) {
/*      */             return;
/*      */           }
/*  274 */           String[] initialLine = splitInitialLine(line);
/*  275 */           assert initialLine.length == 3 : "initialLine::length must be 3";
/*      */           
/*  277 */           this.message = createMessage(initialLine);
/*  278 */           this.currentState = State.READ_HEADER;
/*      */         }
/*  280 */         catch (Exception e) {
/*  281 */           out.add(invalidMessage(buffer, e)); return;
/*      */         } 
/*      */       case READ_HEADER:
/*      */         try {
/*  285 */           State nextState = readHeaders(buffer);
/*  286 */           if (nextState == null) {
/*      */             return;
/*      */           }
/*  289 */           this.currentState = nextState;
/*  290 */           switch (nextState) {
/*      */ 
/*      */             
/*      */             case SKIP_CONTROL_CHARS:
/*  294 */               out.add(this.message);
/*  295 */               out.add(LastHttpContent.EMPTY_LAST_CONTENT);
/*  296 */               resetNow();
/*      */               return;
/*      */             case READ_CHUNK_SIZE:
/*  299 */               if (!this.chunkedSupported) {
/*  300 */                 throw new IllegalArgumentException("Chunked messages not supported");
/*      */               }
/*      */               
/*  303 */               out.add(this.message);
/*      */               return;
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  312 */           long contentLength = contentLength();
/*  313 */           if (contentLength == 0L || (contentLength == -1L && isDecodingRequest())) {
/*  314 */             out.add(this.message);
/*  315 */             out.add(LastHttpContent.EMPTY_LAST_CONTENT);
/*  316 */             resetNow();
/*      */             
/*      */             return;
/*      */           } 
/*  320 */           assert nextState == State.READ_FIXED_LENGTH_CONTENT || nextState == State.READ_VARIABLE_LENGTH_CONTENT;
/*      */ 
/*      */           
/*  323 */           out.add(this.message);
/*      */           
/*  325 */           if (nextState == State.READ_FIXED_LENGTH_CONTENT)
/*      */           {
/*  327 */             this.chunkSize = contentLength;
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*      */           return;
/*  333 */         } catch (Exception e) {
/*  334 */           out.add(invalidMessage(buffer, e));
/*      */           return;
/*      */         } 
/*      */       
/*      */       case READ_VARIABLE_LENGTH_CONTENT:
/*  339 */         i = Math.min(buffer.readableBytes(), this.maxChunkSize);
/*  340 */         if (i > 0) {
/*  341 */           ByteBuf byteBuf = buffer.readRetainedSlice(i);
/*  342 */           out.add(new DefaultHttpContent(byteBuf));
/*      */         } 
/*      */         return;
/*      */       
/*      */       case READ_FIXED_LENGTH_CONTENT:
/*  347 */         readLimit = buffer.readableBytes();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  355 */         if (readLimit == 0) {
/*      */           return;
/*      */         }
/*      */         
/*  359 */         j = Math.min(readLimit, this.maxChunkSize);
/*  360 */         if (j > this.chunkSize) {
/*  361 */           j = (int)this.chunkSize;
/*      */         }
/*  363 */         content = buffer.readRetainedSlice(j);
/*  364 */         this.chunkSize -= j;
/*      */         
/*  366 */         if (this.chunkSize == 0L) {
/*      */           
/*  368 */           out.add(new DefaultLastHttpContent(content, this.validateHeaders));
/*  369 */           resetNow();
/*      */         } else {
/*  371 */           out.add(new DefaultHttpContent(content));
/*      */         } 
/*      */         return;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case READ_CHUNK_SIZE:
/*      */         try {
/*  380 */           ByteBuf line = this.lineParser.parse(buffer);
/*  381 */           if (line == null) {
/*      */             return;
/*      */           }
/*  384 */           int chunkSize = getChunkSize(line.array(), line.arrayOffset() + line.readerIndex(), line.readableBytes());
/*  385 */           this.chunkSize = chunkSize;
/*  386 */           if (chunkSize == 0) {
/*  387 */             this.currentState = State.READ_CHUNK_FOOTER;
/*      */             return;
/*      */           } 
/*  390 */           this.currentState = State.READ_CHUNKED_CONTENT;
/*      */         }
/*  392 */         catch (Exception e) {
/*  393 */           out.add(invalidChunk(buffer, e));
/*      */           return;
/*      */         } 
/*      */       case READ_CHUNKED_CONTENT:
/*  397 */         assert this.chunkSize <= 2147483647L;
/*  398 */         toRead = Math.min((int)this.chunkSize, this.maxChunkSize);
/*  399 */         if (!this.allowPartialChunks && buffer.readableBytes() < toRead) {
/*      */           return;
/*      */         }
/*  402 */         toRead = Math.min(toRead, buffer.readableBytes());
/*  403 */         if (toRead == 0) {
/*      */           return;
/*      */         }
/*  406 */         chunk = new DefaultHttpContent(buffer.readRetainedSlice(toRead));
/*  407 */         this.chunkSize -= toRead;
/*      */         
/*  409 */         out.add(chunk);
/*      */         
/*  411 */         if (this.chunkSize != 0L) {
/*      */           return;
/*      */         }
/*  414 */         this.currentState = State.READ_CHUNK_DELIMITER;
/*      */ 
/*      */       
/*      */       case READ_CHUNK_DELIMITER:
/*  418 */         wIdx = buffer.writerIndex();
/*  419 */         rIdx = buffer.readerIndex();
/*  420 */         while (wIdx > rIdx) {
/*  421 */           byte next = buffer.getByte(rIdx++);
/*  422 */           if (next == 10) {
/*  423 */             this.currentState = State.READ_CHUNK_SIZE;
/*      */             break;
/*      */           } 
/*      */         } 
/*  427 */         buffer.readerIndex(rIdx);
/*      */         return;
/*      */       case READ_CHUNK_FOOTER:
/*      */         try {
/*  431 */           LastHttpContent trailer = readTrailingHeaders(buffer);
/*  432 */           if (trailer == null) {
/*      */             return;
/*      */           }
/*  435 */           out.add(trailer);
/*  436 */           resetNow();
/*      */           return;
/*  438 */         } catch (Exception e) {
/*  439 */           out.add(invalidChunk(buffer, e));
/*      */           return;
/*      */         } 
/*      */       
/*      */       case BAD_MESSAGE:
/*  444 */         buffer.skipBytes(buffer.readableBytes());
/*      */         break;
/*      */       
/*      */       case UPGRADED:
/*  448 */         readableBytes = buffer.readableBytes();
/*  449 */         if (readableBytes > 0)
/*      */         {
/*      */ 
/*      */ 
/*      */           
/*  454 */           out.add(buffer.readBytes(readableBytes));
/*      */         }
/*      */         break;
/*      */     }  }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void decodeLast(ChannelHandlerContext ctx, ByteBuf in, List<Object> out) throws Exception {
/*  465 */     super.decodeLast(ctx, in, out);
/*      */     
/*  467 */     if (this.resetRequested.get())
/*      */     {
/*      */       
/*  470 */       resetNow();
/*      */     }
/*      */     
/*  473 */     if (this.message != null) {
/*  474 */       boolean prematureClosure, chunked = HttpUtil.isTransferEncodingChunked(this.message);
/*  475 */       if (this.currentState == State.READ_VARIABLE_LENGTH_CONTENT && !in.isReadable() && !chunked) {
/*      */         
/*  477 */         out.add(LastHttpContent.EMPTY_LAST_CONTENT);
/*  478 */         resetNow();
/*      */         
/*      */         return;
/*      */       } 
/*  482 */       if (this.currentState == State.READ_HEADER) {
/*      */ 
/*      */         
/*  485 */         out.add(invalidMessage(Unpooled.EMPTY_BUFFER, (Exception)new PrematureChannelClosureException("Connection closed before received headers")));
/*      */         
/*  487 */         resetNow();
/*      */ 
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/*  493 */       if (isDecodingRequest() || chunked) {
/*      */         
/*  495 */         prematureClosure = true;
/*      */       
/*      */       }
/*      */       else {
/*      */         
/*  500 */         prematureClosure = (contentLength() > 0L);
/*      */       } 
/*      */       
/*  503 */       if (!prematureClosure) {
/*  504 */         out.add(LastHttpContent.EMPTY_LAST_CONTENT);
/*      */       }
/*  506 */       resetNow();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void userEventTriggered(ChannelHandlerContext ctx, Object evt) throws Exception {
/*  512 */     if (evt instanceof HttpExpectationFailedEvent) {
/*  513 */       switch (this.currentState) {
/*      */         case READ_CHUNK_SIZE:
/*      */         case READ_VARIABLE_LENGTH_CONTENT:
/*      */         case READ_FIXED_LENGTH_CONTENT:
/*  517 */           reset();
/*      */           break;
/*      */       } 
/*      */ 
/*      */     
/*      */     }
/*  523 */     super.userEventTriggered(ctx, evt);
/*      */   }
/*      */   
/*      */   protected boolean isContentAlwaysEmpty(HttpMessage msg) {
/*  527 */     if (msg instanceof HttpResponse) {
/*  528 */       HttpResponse res = (HttpResponse)msg;
/*  529 */       HttpResponseStatus status = res.status();
/*  530 */       int code = status.code();
/*  531 */       HttpStatusClass statusClass = status.codeClass();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  538 */       if (statusClass == HttpStatusClass.INFORMATIONAL)
/*      */       {
/*  540 */         return (code != 101 || res.headers().contains((CharSequence)HttpHeaderNames.SEC_WEBSOCKET_ACCEPT) || 
/*  541 */           !res.headers().contains((CharSequence)HttpHeaderNames.UPGRADE, (CharSequence)HttpHeaderValues.WEBSOCKET, true));
/*      */       }
/*      */       
/*  544 */       switch (code) { case 204:
/*      */         case 304:
/*  546 */           return true; }
/*      */       
/*  548 */       return false;
/*      */     } 
/*      */     
/*  551 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isSwitchingToNonHttp1Protocol(HttpResponse msg) {
/*  559 */     if (msg.status().code() != HttpResponseStatus.SWITCHING_PROTOCOLS.code()) {
/*  560 */       return false;
/*      */     }
/*  562 */     String newProtocol = msg.headers().get((CharSequence)HttpHeaderNames.UPGRADE);
/*  563 */     return (newProtocol == null || (
/*  564 */       !newProtocol.contains(HttpVersion.HTTP_1_0.text()) && 
/*  565 */       !newProtocol.contains(HttpVersion.HTTP_1_1.text())));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void reset() {
/*  573 */     this.resetRequested.lazySet(true);
/*      */   }
/*      */   
/*      */   private void resetNow() {
/*  577 */     HttpMessage message = this.message;
/*  578 */     this.message = null;
/*  579 */     this.name = null;
/*  580 */     this.value = null;
/*  581 */     this.contentLength = Long.MIN_VALUE;
/*  582 */     this.lineParser.reset();
/*  583 */     this.headerParser.reset();
/*  584 */     this.trailer = null;
/*  585 */     if (!isDecodingRequest()) {
/*  586 */       HttpResponse res = (HttpResponse)message;
/*  587 */       if (res != null && isSwitchingToNonHttp1Protocol(res)) {
/*  588 */         this.currentState = State.UPGRADED;
/*      */         
/*      */         return;
/*      */       } 
/*      */     } 
/*  593 */     this.resetRequested.lazySet(false);
/*  594 */     this.currentState = State.SKIP_CONTROL_CHARS;
/*      */   }
/*      */   
/*      */   private HttpMessage invalidMessage(ByteBuf in, Exception cause) {
/*  598 */     this.currentState = State.BAD_MESSAGE;
/*      */ 
/*      */ 
/*      */     
/*  602 */     in.skipBytes(in.readableBytes());
/*      */     
/*  604 */     if (this.message == null) {
/*  605 */       this.message = createInvalidMessage();
/*      */     }
/*  607 */     this.message.setDecoderResult(DecoderResult.failure(cause));
/*      */     
/*  609 */     HttpMessage ret = this.message;
/*  610 */     this.message = null;
/*  611 */     return ret;
/*      */   }
/*      */   
/*      */   private HttpContent invalidChunk(ByteBuf in, Exception cause) {
/*  615 */     this.currentState = State.BAD_MESSAGE;
/*      */ 
/*      */ 
/*      */     
/*  619 */     in.skipBytes(in.readableBytes());
/*      */     
/*  621 */     HttpContent chunk = new DefaultLastHttpContent(Unpooled.EMPTY_BUFFER);
/*  622 */     chunk.setDecoderResult(DecoderResult.failure(cause));
/*  623 */     this.message = null;
/*  624 */     this.trailer = null;
/*  625 */     return chunk;
/*      */   }
/*      */   
/*      */   private State readHeaders(ByteBuf buffer) {
/*  629 */     HttpMessage message = this.message;
/*  630 */     HttpHeaders headers = message.headers();
/*      */     
/*  632 */     HeaderParser headerParser = this.headerParser;
/*      */     
/*  634 */     ByteBuf line = headerParser.parse(buffer);
/*  635 */     if (line == null) {
/*  636 */       return null;
/*      */     }
/*  638 */     int lineLength = line.readableBytes();
/*  639 */     while (lineLength > 0) {
/*  640 */       byte[] lineContent = line.array();
/*  641 */       int startLine = line.arrayOffset() + line.readerIndex();
/*  642 */       byte firstChar = lineContent[startLine];
/*  643 */       if (this.name != null && (firstChar == 32 || firstChar == 9)) {
/*      */ 
/*      */         
/*  646 */         String trimmedLine = langAsciiString(lineContent, startLine, lineLength).trim();
/*  647 */         String valueStr = this.value;
/*  648 */         this.value = valueStr + ' ' + trimmedLine;
/*      */       } else {
/*  650 */         if (this.name != null) {
/*  651 */           headers.add((CharSequence)this.name, this.value);
/*      */         }
/*  653 */         splitHeader(lineContent, startLine, lineLength);
/*      */       } 
/*      */       
/*  656 */       line = headerParser.parse(buffer);
/*  657 */       if (line == null) {
/*  658 */         return null;
/*      */       }
/*  660 */       lineLength = line.readableBytes();
/*      */     } 
/*      */ 
/*      */     
/*  664 */     if (this.name != null) {
/*  665 */       headers.add((CharSequence)this.name, this.value);
/*      */     }
/*      */ 
/*      */     
/*  669 */     this.name = null;
/*  670 */     this.value = null;
/*      */ 
/*      */     
/*  673 */     HttpMessageDecoderResult decoderResult = new HttpMessageDecoderResult(this.lineParser.size, headerParser.size);
/*  674 */     message.setDecoderResult(decoderResult);
/*      */     
/*  676 */     List<String> contentLengthFields = headers.getAll((CharSequence)HttpHeaderNames.CONTENT_LENGTH);
/*  677 */     if (!contentLengthFields.isEmpty()) {
/*  678 */       HttpVersion version = message.protocolVersion();
/*      */       
/*  680 */       boolean isHttp10OrEarlier = (version.majorVersion() < 1 || (version.majorVersion() == 1 && version.minorVersion() == 0));
/*      */ 
/*      */       
/*  683 */       this.contentLength = HttpUtil.normalizeAndGetContentLength((List)contentLengthFields, isHttp10OrEarlier, this.allowDuplicateContentLengths);
/*      */       
/*  685 */       if (this.contentLength != -1L) {
/*  686 */         String lengthValue = ((String)contentLengthFields.get(0)).trim();
/*  687 */         if (contentLengthFields.size() > 1 || 
/*  688 */           !lengthValue.equals(Long.toString(this.contentLength))) {
/*  689 */           headers.set((CharSequence)HttpHeaderNames.CONTENT_LENGTH, Long.valueOf(this.contentLength));
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/*  694 */     if (isContentAlwaysEmpty(message)) {
/*  695 */       HttpUtil.setTransferEncodingChunked(message, false);
/*  696 */       return State.SKIP_CONTROL_CHARS;
/*  697 */     }  if (HttpUtil.isTransferEncodingChunked(message)) {
/*  698 */       if (!contentLengthFields.isEmpty() && message.protocolVersion() == HttpVersion.HTTP_1_1) {
/*  699 */         handleTransferEncodingChunkedWithContentLength(message);
/*      */       }
/*  701 */       return State.READ_CHUNK_SIZE;
/*  702 */     }  if (contentLength() >= 0L) {
/*  703 */       return State.READ_FIXED_LENGTH_CONTENT;
/*      */     }
/*  705 */     return State.READ_VARIABLE_LENGTH_CONTENT;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void handleTransferEncodingChunkedWithContentLength(HttpMessage message) {
/*  731 */     message.headers().remove((CharSequence)HttpHeaderNames.CONTENT_LENGTH);
/*  732 */     this.contentLength = Long.MIN_VALUE;
/*      */   }
/*      */   
/*      */   private long contentLength() {
/*  736 */     if (this.contentLength == Long.MIN_VALUE) {
/*  737 */       this.contentLength = HttpUtil.getContentLength(this.message, -1L);
/*      */     }
/*  739 */     return this.contentLength;
/*      */   }
/*      */   
/*      */   private LastHttpContent readTrailingHeaders(ByteBuf buffer) {
/*  743 */     HeaderParser headerParser = this.headerParser;
/*  744 */     ByteBuf line = headerParser.parse(buffer);
/*  745 */     if (line == null) {
/*  746 */       return null;
/*      */     }
/*  748 */     LastHttpContent trailer = this.trailer;
/*  749 */     int lineLength = line.readableBytes();
/*  750 */     if (lineLength == 0 && trailer == null)
/*      */     {
/*      */       
/*  753 */       return LastHttpContent.EMPTY_LAST_CONTENT;
/*      */     }
/*      */     
/*  756 */     CharSequence lastHeader = null;
/*  757 */     if (trailer == null) {
/*  758 */       trailer = this.trailer = new DefaultLastHttpContent(Unpooled.EMPTY_BUFFER, this.validateHeaders);
/*      */     }
/*  760 */     while (lineLength > 0) {
/*  761 */       byte[] lineContent = line.array();
/*  762 */       int startLine = line.arrayOffset() + line.readerIndex();
/*  763 */       byte firstChar = lineContent[startLine];
/*  764 */       if (lastHeader != null && (firstChar == 32 || firstChar == 9)) {
/*  765 */         List<String> current = trailer.trailingHeaders().getAll(lastHeader);
/*  766 */         if (!current.isEmpty()) {
/*  767 */           int lastPos = current.size() - 1;
/*      */ 
/*      */           
/*  770 */           String lineTrimmed = langAsciiString(lineContent, startLine, line.readableBytes()).trim();
/*  771 */           String currentLastPos = current.get(lastPos);
/*  772 */           current.set(lastPos, currentLastPos + lineTrimmed);
/*      */         } 
/*      */       } else {
/*  775 */         splitHeader(lineContent, startLine, lineLength);
/*  776 */         AsciiString headerName = this.name;
/*  777 */         if (!HttpHeaderNames.CONTENT_LENGTH.contentEqualsIgnoreCase((CharSequence)headerName) && 
/*  778 */           !HttpHeaderNames.TRANSFER_ENCODING.contentEqualsIgnoreCase((CharSequence)headerName) && 
/*  779 */           !HttpHeaderNames.TRAILER.contentEqualsIgnoreCase((CharSequence)headerName)) {
/*  780 */           trailer.trailingHeaders().add((CharSequence)headerName, this.value);
/*      */         }
/*  782 */         AsciiString asciiString1 = this.name;
/*      */         
/*  784 */         this.name = null;
/*  785 */         this.value = null;
/*      */       } 
/*  787 */       line = headerParser.parse(buffer);
/*  788 */       if (line == null) {
/*  789 */         return null;
/*      */       }
/*  791 */       lineLength = line.readableBytes();
/*      */     } 
/*      */     
/*  794 */     this.trailer = null;
/*  795 */     return trailer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int skipWhiteSpaces(byte[] hex, int start, int length) {
/*  806 */     for (int i = 0; i < length; i++) {
/*  807 */       if (!isWhitespace(hex[start + i])) {
/*  808 */         return i;
/*      */       }
/*      */     } 
/*  811 */     return length;
/*      */   }
/*      */ 
/*      */   
/*      */   private static int getChunkSize(byte[] hex, int start, int length) {
/*  816 */     int skipped = skipWhiteSpaces(hex, start, length);
/*  817 */     if (skipped == length)
/*      */     {
/*  819 */       throw new NumberFormatException();
/*      */     }
/*  821 */     start += skipped;
/*  822 */     length -= skipped;
/*  823 */     int result = 0;
/*  824 */     for (int i = 0; i < length; i++) {
/*  825 */       int digit = StringUtil.decodeHexNibble(hex[start + i]);
/*  826 */       if (digit == -1) {
/*      */         
/*  828 */         byte b = hex[start + i];
/*  829 */         if (b == 59 || isControlOrWhitespaceAsciiChar(b)) {
/*  830 */           if (i == 0)
/*      */           {
/*  832 */             throw new NumberFormatException();
/*      */           }
/*  834 */           return result;
/*      */         } 
/*      */         
/*  837 */         throw new NumberFormatException();
/*      */       } 
/*  839 */       result *= 16;
/*  840 */       result += digit;
/*      */     } 
/*  842 */     return result;
/*      */   }
/*      */   
/*      */   private String[] splitInitialLine(ByteBuf asciiBuffer) {
/*  846 */     byte[] asciiBytes = asciiBuffer.array();
/*      */     
/*  848 */     int arrayOffset = asciiBuffer.arrayOffset();
/*      */     
/*  850 */     int startContent = arrayOffset + asciiBuffer.readerIndex();
/*      */     
/*  852 */     int end = startContent + asciiBuffer.readableBytes();
/*      */     
/*  854 */     int aStart = findNonSPLenient(asciiBytes, startContent, end);
/*  855 */     int aEnd = findSPLenient(asciiBytes, aStart, end);
/*      */     
/*  857 */     int bStart = findNonSPLenient(asciiBytes, aEnd, end);
/*  858 */     int bEnd = findSPLenient(asciiBytes, bStart, end);
/*      */     
/*  860 */     int cStart = findNonSPLenient(asciiBytes, bEnd, end);
/*  861 */     int cEnd = findEndOfString(asciiBytes, Math.max(cStart - 1, startContent), end);
/*      */     
/*  863 */     return new String[] {
/*  864 */         splitFirstWordInitialLine(asciiBytes, aStart, aEnd - aStart), 
/*  865 */         splitSecondWordInitialLine(asciiBytes, bStart, bEnd - bStart), (cStart < cEnd) ? 
/*  866 */         splitThirdWordInitialLine(asciiBytes, cStart, cEnd - cStart) : "" };
/*      */   }
/*      */   
/*      */   protected String splitFirstWordInitialLine(byte[] asciiContent, int start, int length) {
/*  870 */     return langAsciiString(asciiContent, start, length);
/*      */   }
/*      */   
/*      */   protected String splitSecondWordInitialLine(byte[] asciiContent, int start, int length) {
/*  874 */     return langAsciiString(asciiContent, start, length);
/*      */   }
/*      */   
/*      */   protected String splitThirdWordInitialLine(byte[] asciiContent, int start, int length) {
/*  878 */     return langAsciiString(asciiContent, start, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String langAsciiString(byte[] asciiContent, int start, int length) {
/*  885 */     if (length == 0) {
/*  886 */       return "";
/*      */     }
/*      */     
/*  889 */     if (start == 0) {
/*  890 */       if (length == asciiContent.length) {
/*  891 */         return new String(asciiContent, 0, 0, asciiContent.length);
/*      */       }
/*  893 */       return new String(asciiContent, 0, 0, length);
/*      */     } 
/*  895 */     return new String(asciiContent, 0, start, length);
/*      */   }
/*      */   
/*      */   private void splitHeader(byte[] line, int start, int length) {
/*  899 */     int end = start + length;
/*      */     
/*  901 */     int nameStart = findNonWhitespace(line, start, end);
/*      */     
/*  903 */     boolean isDecodingRequest = isDecodingRequest(); int nameEnd;
/*  904 */     for (nameEnd = nameStart; nameEnd < end; nameEnd++) {
/*  905 */       byte ch = line[nameEnd];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  915 */       if (ch == 58 || (!isDecodingRequest && 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  920 */         isOWS(ch))) {
/*      */         break;
/*      */       }
/*      */     } 
/*      */     
/*  925 */     if (nameEnd == end)
/*      */     {
/*  927 */       throw new IllegalArgumentException("No colon found");
/*      */     }
/*      */     int colonEnd;
/*  930 */     for (colonEnd = nameEnd; colonEnd < end; colonEnd++) {
/*  931 */       if (line[colonEnd] == 58) {
/*  932 */         colonEnd++;
/*      */         break;
/*      */       } 
/*      */     } 
/*  936 */     this.name = splitHeaderName(line, nameStart, nameEnd - nameStart);
/*  937 */     int valueStart = findNonWhitespace(line, colonEnd, end);
/*  938 */     if (valueStart == end) {
/*  939 */       this.value = "";
/*      */     } else {
/*  941 */       int valueEnd = findEndOfString(line, start, end);
/*      */       
/*  943 */       this.value = langAsciiString(line, valueStart, valueEnd - valueStart);
/*      */     } 
/*      */   }
/*      */   
/*      */   protected AsciiString splitHeaderName(byte[] sb, int start, int length) {
/*  948 */     return new AsciiString(sb, start, length, true);
/*      */   }
/*      */   
/*      */   private static int findNonSPLenient(byte[] sb, int offset, int end) {
/*  952 */     for (int result = offset; result < end; ) {
/*  953 */       byte c = sb[result];
/*      */       
/*  955 */       if (isSPLenient(c)) {
/*      */         result++; continue;
/*      */       } 
/*  958 */       if (isWhitespace(c))
/*      */       {
/*  960 */         throw new IllegalArgumentException("Invalid separator");
/*      */       }
/*  962 */       return result;
/*      */     } 
/*  964 */     return end;
/*      */   }
/*      */   
/*      */   private static int findSPLenient(byte[] sb, int offset, int end) {
/*  968 */     for (int result = offset; result < end; result++) {
/*  969 */       if (isSPLenient(sb[result])) {
/*  970 */         return result;
/*      */       }
/*      */     } 
/*  973 */     return end;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  981 */   private static final boolean[] SP_LENIENT_BYTES = new boolean[256]; static {
/*  982 */     SP_LENIENT_BYTES[160] = true;
/*  983 */     SP_LENIENT_BYTES[137] = true;
/*  984 */     SP_LENIENT_BYTES[139] = true;
/*  985 */     SP_LENIENT_BYTES[140] = true;
/*  986 */     SP_LENIENT_BYTES[141] = true;
/*      */   }
/*  988 */   private static final boolean[] LATIN_WHITESPACE = new boolean[256]; static { byte b;
/*  989 */     for (b = Byte.MIN_VALUE; b < Byte.MAX_VALUE; b = (byte)(b + 1)) {
/*  990 */       LATIN_WHITESPACE[128 + b] = Character.isWhitespace(b);
/*      */     } }
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean isSPLenient(byte c) {
/*  996 */     return SP_LENIENT_BYTES[c + 128];
/*      */   }
/*      */   
/*      */   private static boolean isWhitespace(byte b) {
/* 1000 */     return LATIN_WHITESPACE[b + 128];
/*      */   }
/*      */   
/*      */   private static int findNonWhitespace(byte[] sb, int offset, int end) {
/* 1004 */     for (int result = offset; result < end; result++) {
/* 1005 */       byte c = sb[result];
/* 1006 */       if (!isWhitespace(c))
/* 1007 */         return result; 
/* 1008 */       if (!isOWS(c))
/*      */       {
/* 1010 */         throw new IllegalArgumentException("Invalid separator, only a single space or horizontal tab allowed, but received a '" + c + "' (0x" + 
/* 1011 */             Integer.toHexString(c) + ")");
/*      */       }
/*      */     } 
/* 1014 */     return end;
/*      */   }
/*      */   
/*      */   private static int findEndOfString(byte[] sb, int start, int end) {
/* 1018 */     for (int result = end - 1; result > start; result--) {
/* 1019 */       if (!isWhitespace(sb[result])) {
/* 1020 */         return result + 1;
/*      */       }
/*      */     } 
/* 1023 */     return 0;
/*      */   }
/*      */   
/*      */   private static boolean isOWS(byte ch) {
/* 1027 */     return (ch == 32 || ch == 9);
/*      */   }
/*      */   
/*      */   private static class HeaderParser {
/*      */     protected final ByteBuf seq;
/*      */     protected final int maxLength;
/*      */     int size;
/*      */     
/*      */     HeaderParser(ByteBuf seq, int maxLength) {
/* 1036 */       this.seq = seq;
/* 1037 */       this.maxLength = maxLength;
/*      */     }
/*      */     
/*      */     public ByteBuf parse(ByteBuf buffer) {
/* 1041 */       int endOfSeqIncluded, readableBytes = buffer.readableBytes();
/* 1042 */       int readerIndex = buffer.readerIndex();
/* 1043 */       int maxBodySize = this.maxLength - this.size;
/* 1044 */       assert maxBodySize >= 0;
/*      */ 
/*      */       
/* 1047 */       long maxBodySizeWithCRLF = maxBodySize + 2L;
/* 1048 */       int toProcess = (int)Math.min(maxBodySizeWithCRLF, readableBytes);
/* 1049 */       int toIndexExclusive = readerIndex + toProcess;
/* 1050 */       assert toIndexExclusive >= readerIndex;
/* 1051 */       int indexOfLf = buffer.indexOf(readerIndex, toIndexExclusive, (byte)10);
/* 1052 */       if (indexOfLf == -1) {
/* 1053 */         if (readableBytes > maxBodySize)
/*      */         {
/*      */ 
/*      */ 
/*      */           
/* 1058 */           throw newException(this.maxLength);
/*      */         }
/* 1060 */         return null;
/*      */       } 
/*      */       
/* 1063 */       if (indexOfLf > readerIndex && buffer.getByte(indexOfLf - 1) == 13) {
/*      */         
/* 1065 */         endOfSeqIncluded = indexOfLf - 1;
/*      */       } else {
/* 1067 */         endOfSeqIncluded = indexOfLf;
/*      */       } 
/* 1069 */       int newSize = endOfSeqIncluded - readerIndex;
/* 1070 */       if (newSize == 0) {
/* 1071 */         this.seq.clear();
/* 1072 */         buffer.readerIndex(indexOfLf + 1);
/* 1073 */         return this.seq;
/*      */       } 
/* 1075 */       int size = this.size + newSize;
/* 1076 */       if (size > this.maxLength) {
/* 1077 */         throw newException(this.maxLength);
/*      */       }
/* 1079 */       this.size = size;
/* 1080 */       this.seq.clear();
/* 1081 */       this.seq.writeBytes(buffer, readerIndex, newSize);
/* 1082 */       buffer.readerIndex(indexOfLf + 1);
/* 1083 */       return this.seq;
/*      */     }
/*      */     
/*      */     public void reset() {
/* 1087 */       this.size = 0;
/*      */     }
/*      */     
/*      */     protected TooLongFrameException newException(int maxLength) {
/* 1091 */       return new TooLongHttpHeaderException("HTTP header is larger than " + maxLength + " bytes.");
/*      */     }
/*      */   }
/*      */   
/*      */   private final class LineParser
/*      */     extends HeaderParser {
/*      */     LineParser(ByteBuf seq, int maxLength) {
/* 1098 */       super(seq, maxLength);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public ByteBuf parse(ByteBuf buffer) {
/* 1104 */       reset();
/* 1105 */       int readableBytes = buffer.readableBytes();
/* 1106 */       if (readableBytes == 0) {
/* 1107 */         return null;
/*      */       }
/* 1109 */       int readerIndex = buffer.readerIndex();
/* 1110 */       if (HttpObjectDecoder.this.currentState == HttpObjectDecoder.State.SKIP_CONTROL_CHARS && skipControlChars(buffer, readableBytes, readerIndex)) {
/* 1111 */         return null;
/*      */       }
/* 1113 */       return super.parse(buffer);
/*      */     }
/*      */     
/*      */     private boolean skipControlChars(ByteBuf buffer, int readableBytes, int readerIndex) {
/* 1117 */       assert HttpObjectDecoder.this.currentState == HttpObjectDecoder.State.SKIP_CONTROL_CHARS;
/* 1118 */       int maxToSkip = Math.min(this.maxLength, readableBytes);
/* 1119 */       int firstNonControlIndex = buffer.forEachByte(readerIndex, maxToSkip, HttpObjectDecoder.SKIP_CONTROL_CHARS_BYTES);
/* 1120 */       if (firstNonControlIndex == -1) {
/* 1121 */         buffer.skipBytes(maxToSkip);
/* 1122 */         if (readableBytes > this.maxLength) {
/* 1123 */           throw newException(this.maxLength);
/*      */         }
/* 1125 */         return true;
/*      */       } 
/*      */       
/* 1128 */       buffer.readerIndex(firstNonControlIndex);
/* 1129 */       HttpObjectDecoder.this.currentState = HttpObjectDecoder.State.READ_INITIAL;
/* 1130 */       return false;
/*      */     }
/*      */ 
/*      */     
/*      */     protected TooLongFrameException newException(int maxLength) {
/* 1135 */       return new TooLongHttpLineException("An HTTP line is larger than " + maxLength + " bytes.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1142 */   private static final boolean[] ISO_CONTROL_OR_WHITESPACE = new boolean[256]; static {
/* 1143 */     for (b = Byte.MIN_VALUE; b < Byte.MAX_VALUE; b = (byte)(b + 1)) {
/* 1144 */       ISO_CONTROL_OR_WHITESPACE[128 + b] = (Character.isISOControl(b) || isWhitespace(b));
/*      */     }
/*      */   }
/*      */   
/* 1148 */   private static final ByteProcessor SKIP_CONTROL_CHARS_BYTES = new ByteProcessor()
/*      */     {
/*      */       public boolean process(byte value)
/*      */       {
/* 1152 */         return HttpObjectDecoder.ISO_CONTROL_OR_WHITESPACE[128 + value];
/*      */       }
/*      */     };
/*      */   
/*      */   private static boolean isControlOrWhitespaceAsciiChar(byte b) {
/* 1157 */     return ISO_CONTROL_OR_WHITESPACE[128 + b];
/*      */   }
/*      */   
/*      */   protected abstract boolean isDecodingRequest();
/*      */   
/*      */   protected abstract HttpMessage createMessage(String[] paramArrayOfString) throws Exception;
/*      */   
/*      */   protected abstract HttpMessage createInvalidMessage();
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http-4.1.93.Final.jar!\io\netty\handler\codec\http\HttpObjectDecoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */