/*    */ package io.netty.handler.codec.spdy;
/*    */ 
/*    */ import io.netty.util.AsciiString;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SpdyHttpHeaders
/*    */ {
/*    */   public static final class Names
/*    */   {
/* 33 */     public static final AsciiString STREAM_ID = AsciiString.cached("x-spdy-stream-id");
/*    */ 
/*    */ 
/*    */     
/* 37 */     public static final AsciiString ASSOCIATED_TO_STREAM_ID = AsciiString.cached("x-spdy-associated-to-stream-id");
/*    */ 
/*    */ 
/*    */     
/* 41 */     public static final AsciiString PRIORITY = AsciiString.cached("x-spdy-priority");
/*    */ 
/*    */ 
/*    */     
/* 45 */     public static final AsciiString SCHEME = AsciiString.cached("x-spdy-scheme");
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http-4.1.93.Final.jar!\io\netty\handler\codec\spdy\SpdyHttpHeaders.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */