/*     */ package io.netty.handler.codec.http.websocketx;
/*     */ 
/*     */ import io.netty.buffer.Unpooled;
/*     */ import io.netty.channel.Channel;
/*     */ import io.netty.channel.ChannelFuture;
/*     */ import io.netty.channel.ChannelFutureListener;
/*     */ import io.netty.channel.ChannelHandler;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.channel.ChannelInboundHandlerAdapter;
/*     */ import io.netty.channel.ChannelOutboundInvoker;
/*     */ import io.netty.channel.ChannelPipeline;
/*     */ import io.netty.channel.ChannelPromise;
/*     */ import io.netty.handler.codec.http.DefaultFullHttpRequest;
/*     */ import io.netty.handler.codec.http.EmptyHttpHeaders;
/*     */ import io.netty.handler.codec.http.FullHttpRequest;
/*     */ import io.netty.handler.codec.http.FullHttpResponse;
/*     */ import io.netty.handler.codec.http.HttpContentCompressor;
/*     */ import io.netty.handler.codec.http.HttpHeaders;
/*     */ import io.netty.handler.codec.http.HttpMessage;
/*     */ import io.netty.handler.codec.http.HttpObject;
/*     */ import io.netty.handler.codec.http.HttpObjectAggregator;
/*     */ import io.netty.handler.codec.http.HttpRequest;
/*     */ import io.netty.handler.codec.http.HttpRequestDecoder;
/*     */ import io.netty.handler.codec.http.HttpResponseEncoder;
/*     */ import io.netty.handler.codec.http.HttpServerCodec;
/*     */ import io.netty.handler.codec.http.HttpUtil;
/*     */ import io.netty.util.ReferenceCountUtil;
/*     */ import io.netty.util.concurrent.Future;
/*     */ import io.netty.util.concurrent.GenericFutureListener;
/*     */ import io.netty.util.internal.EmptyArrays;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import io.netty.util.internal.logging.InternalLogger;
/*     */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*     */ import java.nio.channels.ClosedChannelException;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class WebSocketServerHandshaker
/*     */ {
/*  57 */   protected static final InternalLogger logger = InternalLoggerFactory.getInstance(WebSocketServerHandshaker.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String uri;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String[] subprotocols;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final WebSocketVersion version;
/*     */ 
/*     */ 
/*     */   
/*     */   private final WebSocketDecoderConfig decoderConfig;
/*     */ 
/*     */ 
/*     */   
/*     */   private String selectedSubprotocol;
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String SUB_PROTOCOL_WILDCARD = "*";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected WebSocketServerHandshaker(WebSocketVersion version, String uri, String subprotocols, int maxFramePayloadLength) {
/*  90 */     this(version, uri, subprotocols, WebSocketDecoderConfig.newBuilder()
/*  91 */         .maxFramePayloadLength(maxFramePayloadLength)
/*  92 */         .build());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected WebSocketServerHandshaker(WebSocketVersion version, String uri, String subprotocols, WebSocketDecoderConfig decoderConfig) {
/* 110 */     this.version = version;
/* 111 */     this.uri = uri;
/* 112 */     if (subprotocols != null) {
/* 113 */       String[] subprotocolArray = subprotocols.split(",");
/* 114 */       for (int i = 0; i < subprotocolArray.length; i++) {
/* 115 */         subprotocolArray[i] = subprotocolArray[i].trim();
/*     */       }
/* 117 */       this.subprotocols = subprotocolArray;
/*     */     } else {
/* 119 */       this.subprotocols = EmptyArrays.EMPTY_STRINGS;
/*     */     } 
/* 121 */     this.decoderConfig = (WebSocketDecoderConfig)ObjectUtil.checkNotNull(decoderConfig, "decoderConfig");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String uri() {
/* 128 */     return this.uri;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> subprotocols() {
/* 135 */     Set<String> ret = new LinkedHashSet<String>();
/* 136 */     Collections.addAll(ret, this.subprotocols);
/* 137 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebSocketVersion version() {
/* 144 */     return this.version;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int maxFramePayloadLength() {
/* 153 */     return this.decoderConfig.maxFramePayloadLength();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebSocketDecoderConfig decoderConfig() {
/* 162 */     return this.decoderConfig;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelFuture handshake(Channel channel, FullHttpRequest req) {
/* 177 */     return handshake(channel, req, (HttpHeaders)null, channel.newPromise());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ChannelFuture handshake(Channel channel, FullHttpRequest req, HttpHeaders responseHeaders, final ChannelPromise promise) {
/*     */     final String encoderName;
/* 199 */     if (logger.isDebugEnabled()) {
/* 200 */       logger.debug("{} WebSocket version {} server handshake", channel, version());
/*     */     }
/* 202 */     FullHttpResponse response = newHandshakeResponse(req, responseHeaders);
/* 203 */     ChannelPipeline p = channel.pipeline();
/* 204 */     if (p.get(HttpObjectAggregator.class) != null) {
/* 205 */       p.remove(HttpObjectAggregator.class);
/*     */     }
/* 207 */     if (p.get(HttpContentCompressor.class) != null) {
/* 208 */       p.remove(HttpContentCompressor.class);
/*     */     }
/* 210 */     ChannelHandlerContext ctx = p.context(HttpRequestDecoder.class);
/*     */     
/* 212 */     if (ctx == null) {
/*     */       
/* 214 */       ctx = p.context(HttpServerCodec.class);
/* 215 */       if (ctx == null) {
/* 216 */         promise.setFailure(new IllegalStateException("No HttpDecoder and no HttpServerCodec in the pipeline"));
/*     */         
/* 218 */         response.release();
/* 219 */         return (ChannelFuture)promise;
/*     */       } 
/* 221 */       p.addBefore(ctx.name(), "wsencoder", (ChannelHandler)newWebSocketEncoder());
/* 222 */       p.addBefore(ctx.name(), "wsdecoder", (ChannelHandler)newWebsocketDecoder());
/* 223 */       encoderName = ctx.name();
/*     */     } else {
/* 225 */       p.replace(ctx.name(), "wsdecoder", (ChannelHandler)newWebsocketDecoder());
/*     */       
/* 227 */       encoderName = p.context(HttpResponseEncoder.class).name();
/* 228 */       p.addBefore(encoderName, "wsencoder", (ChannelHandler)newWebSocketEncoder());
/*     */     } 
/* 230 */     channel.writeAndFlush(response).addListener((GenericFutureListener)new ChannelFutureListener()
/*     */         {
/*     */           public void operationComplete(ChannelFuture future) throws Exception {
/* 233 */             if (future.isSuccess()) {
/* 234 */               ChannelPipeline p = future.channel().pipeline();
/* 235 */               p.remove(encoderName);
/* 236 */               promise.setSuccess();
/*     */             } else {
/* 238 */               promise.setFailure(future.cause());
/*     */             } 
/*     */           }
/*     */         });
/* 242 */     return (ChannelFuture)promise;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelFuture handshake(Channel channel, HttpRequest req) {
/* 257 */     return handshake(channel, req, (HttpHeaders)null, channel.newPromise());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ChannelFuture handshake(final Channel channel, HttpRequest req, final HttpHeaders responseHeaders, final ChannelPromise promise) {
/* 278 */     if (req instanceof FullHttpRequest) {
/* 279 */       return handshake(channel, (FullHttpRequest)req, responseHeaders, promise);
/*     */     }
/*     */     
/* 282 */     if (logger.isDebugEnabled()) {
/* 283 */       logger.debug("{} WebSocket version {} server handshake", channel, version());
/*     */     }
/*     */     
/* 286 */     ChannelPipeline p = channel.pipeline();
/* 287 */     ChannelHandlerContext ctx = p.context(HttpRequestDecoder.class);
/* 288 */     if (ctx == null) {
/*     */       
/* 290 */       ctx = p.context(HttpServerCodec.class);
/* 291 */       if (ctx == null) {
/* 292 */         promise.setFailure(new IllegalStateException("No HttpDecoder and no HttpServerCodec in the pipeline"));
/*     */         
/* 294 */         return (ChannelFuture)promise;
/*     */       } 
/*     */     } 
/*     */     
/* 298 */     String aggregatorCtx = ctx.name();
/* 299 */     if (HttpUtil.isContentLengthSet((HttpMessage)req) || HttpUtil.isTransferEncodingChunked((HttpMessage)req) || this.version == WebSocketVersion.V00) {
/*     */ 
/*     */ 
/*     */       
/* 303 */       aggregatorCtx = "httpAggregator";
/* 304 */       p.addAfter(ctx.name(), aggregatorCtx, (ChannelHandler)new HttpObjectAggregator(8192));
/*     */     } 
/*     */     
/* 307 */     p.addAfter(aggregatorCtx, "handshaker", (ChannelHandler)new ChannelInboundHandlerAdapter()
/*     */         {
/*     */           private FullHttpRequest fullHttpRequest;
/*     */ 
/*     */           
/*     */           public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
/* 313 */             if (msg instanceof HttpObject) {
/*     */               try {
/* 315 */                 handleHandshakeRequest(ctx, (HttpObject)msg);
/*     */               } finally {
/* 317 */                 ReferenceCountUtil.release(msg);
/*     */               } 
/*     */             } else {
/* 320 */               super.channelRead(ctx, msg);
/*     */             } 
/*     */           }
/*     */ 
/*     */ 
/*     */           
/*     */           public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
/* 327 */             ctx.pipeline().remove((ChannelHandler)this);
/* 328 */             promise.tryFailure(cause);
/* 329 */             ctx.fireExceptionCaught(cause);
/*     */           }
/*     */ 
/*     */ 
/*     */           
/*     */           public void channelInactive(ChannelHandlerContext ctx) throws Exception {
/*     */             try {
/* 336 */               if (!promise.isDone()) {
/* 337 */                 promise.tryFailure(new ClosedChannelException());
/*     */               }
/* 339 */               ctx.fireChannelInactive();
/*     */             } finally {
/* 341 */               releaseFullHttpRequest();
/*     */             } 
/*     */           }
/*     */ 
/*     */           
/*     */           public void handlerRemoved(ChannelHandlerContext ctx) throws Exception {
/* 347 */             releaseFullHttpRequest();
/*     */           }
/*     */           
/*     */           private void handleHandshakeRequest(ChannelHandlerContext ctx, HttpObject httpObject) {
/* 351 */             if (httpObject instanceof FullHttpRequest) {
/* 352 */               ctx.pipeline().remove((ChannelHandler)this);
/* 353 */               WebSocketServerHandshaker.this.handshake(channel, (FullHttpRequest)httpObject, responseHeaders, promise);
/*     */               
/*     */               return;
/*     */             } 
/* 357 */             if (httpObject instanceof io.netty.handler.codec.http.LastHttpContent) {
/* 358 */               assert this.fullHttpRequest != null;
/* 359 */               FullHttpRequest handshakeRequest = this.fullHttpRequest;
/* 360 */               this.fullHttpRequest = null;
/*     */               try {
/* 362 */                 ctx.pipeline().remove((ChannelHandler)this);
/* 363 */                 WebSocketServerHandshaker.this.handshake(channel, handshakeRequest, responseHeaders, promise);
/*     */               } finally {
/* 365 */                 handshakeRequest.release();
/*     */               } 
/*     */               
/*     */               return;
/*     */             } 
/* 370 */             if (httpObject instanceof HttpRequest) {
/* 371 */               HttpRequest httpRequest = (HttpRequest)httpObject;
/* 372 */               this
/* 373 */                 .fullHttpRequest = (FullHttpRequest)new DefaultFullHttpRequest(httpRequest.protocolVersion(), httpRequest.method(), httpRequest.uri(), Unpooled.EMPTY_BUFFER, httpRequest.headers(), (HttpHeaders)EmptyHttpHeaders.INSTANCE);
/* 374 */               if (httpRequest.decoderResult().isFailure()) {
/* 375 */                 this.fullHttpRequest.setDecoderResult(httpRequest.decoderResult());
/*     */               }
/*     */             } 
/*     */           }
/*     */           
/*     */           private void releaseFullHttpRequest() {
/* 381 */             if (this.fullHttpRequest != null) {
/* 382 */               this.fullHttpRequest.release();
/* 383 */               this.fullHttpRequest = null;
/*     */             } 
/*     */           }
/*     */         });
/*     */     try {
/* 388 */       ctx.fireChannelRead(ReferenceCountUtil.retain(req));
/* 389 */     } catch (Throwable cause) {
/* 390 */       promise.setFailure(cause);
/*     */     } 
/* 392 */     return (ChannelFuture)promise;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract FullHttpResponse newHandshakeResponse(FullHttpRequest paramFullHttpRequest, HttpHeaders paramHttpHeaders);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelFuture close(Channel channel, CloseWebSocketFrame frame) {
/* 412 */     ObjectUtil.checkNotNull(channel, "channel");
/* 413 */     return close(channel, frame, channel.newPromise());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelFuture close(Channel channel, CloseWebSocketFrame frame, ChannelPromise promise) {
/* 430 */     return close0((ChannelOutboundInvoker)channel, frame, promise);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelFuture close(ChannelHandlerContext ctx, CloseWebSocketFrame frame) {
/* 442 */     ObjectUtil.checkNotNull(ctx, "ctx");
/* 443 */     return close(ctx, frame, ctx.newPromise());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelFuture close(ChannelHandlerContext ctx, CloseWebSocketFrame frame, ChannelPromise promise) {
/* 457 */     ObjectUtil.checkNotNull(ctx, "ctx");
/* 458 */     return close0((ChannelOutboundInvoker)ctx, frame, promise).addListener((GenericFutureListener)ChannelFutureListener.CLOSE);
/*     */   }
/*     */   
/*     */   private ChannelFuture close0(ChannelOutboundInvoker invoker, CloseWebSocketFrame frame, ChannelPromise promise) {
/* 462 */     return invoker.writeAndFlush(frame, promise).addListener((GenericFutureListener)ChannelFutureListener.CLOSE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String selectSubprotocol(String requestedSubprotocols) {
/* 473 */     if (requestedSubprotocols == null || this.subprotocols.length == 0) {
/* 474 */       return null;
/*     */     }
/*     */     
/* 477 */     String[] requestedSubprotocolArray = requestedSubprotocols.split(",");
/* 478 */     for (String p : requestedSubprotocolArray) {
/* 479 */       String requestedSubprotocol = p.trim();
/*     */       
/* 481 */       for (String supportedSubprotocol : this.subprotocols) {
/* 482 */         if ("*".equals(supportedSubprotocol) || requestedSubprotocol
/* 483 */           .equals(supportedSubprotocol)) {
/* 484 */           this.selectedSubprotocol = requestedSubprotocol;
/* 485 */           return requestedSubprotocol;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 491 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String selectedSubprotocol() {
/* 501 */     return this.selectedSubprotocol;
/*     */   }
/*     */   
/*     */   protected abstract WebSocketFrameDecoder newWebsocketDecoder();
/*     */   
/*     */   protected abstract WebSocketFrameEncoder newWebSocketEncoder();
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http-4.1.93.Final.jar!\io\netty\handler\codec\http\websocketx\WebSocketServerHandshaker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */