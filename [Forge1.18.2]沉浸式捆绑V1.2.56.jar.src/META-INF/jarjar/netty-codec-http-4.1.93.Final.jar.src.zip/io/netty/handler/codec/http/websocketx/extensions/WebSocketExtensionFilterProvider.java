/*    */ package io.netty.handler.codec.http.websocketx.extensions;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface WebSocketExtensionFilterProvider
/*    */ {
/* 23 */   public static final WebSocketExtensionFilterProvider DEFAULT = new WebSocketExtensionFilterProvider()
/*    */     {
/*    */       public WebSocketExtensionFilter encoderFilter() {
/* 26 */         return WebSocketExtensionFilter.NEVER_SKIP;
/*    */       }
/*    */ 
/*    */       
/*    */       public WebSocketExtensionFilter decoderFilter() {
/* 31 */         return WebSocketExtensionFilter.NEVER_SKIP;
/*    */       }
/*    */     };
/*    */   
/*    */   WebSocketExtensionFilter encoderFilter();
/*    */   
/*    */   WebSocketExtensionFilter decoderFilter();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http-4.1.93.Final.jar!\io\netty\handler\codec\http\websocketx\extensions\WebSocketExtensionFilterProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */