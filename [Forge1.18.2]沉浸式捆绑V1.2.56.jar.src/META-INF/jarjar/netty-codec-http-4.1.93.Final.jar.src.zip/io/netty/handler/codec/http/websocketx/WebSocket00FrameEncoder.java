/*    */ package io.netty.handler.codec.http.websocketx;
/*    */ 
/*    */ import io.netty.buffer.ByteBuf;
/*    */ import io.netty.buffer.Unpooled;
/*    */ import io.netty.channel.ChannelHandler.Sharable;
/*    */ import io.netty.channel.ChannelHandlerContext;
/*    */ import io.netty.handler.codec.MessageToMessageEncoder;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Sharable
/*    */ public class WebSocket00FrameEncoder
/*    */   extends MessageToMessageEncoder<WebSocketFrame>
/*    */   implements WebSocketFrameEncoder
/*    */ {
/* 34 */   private static final ByteBuf _0X00 = Unpooled.unreleasableBuffer(
/* 35 */       Unpooled.directBuffer(1, 1).writeByte(0)).asReadOnly();
/* 36 */   private static final ByteBuf _0XFF = Unpooled.unreleasableBuffer(
/* 37 */       Unpooled.directBuffer(1, 1).writeByte(-1)).asReadOnly();
/* 38 */   private static final ByteBuf _0XFF_0X00 = Unpooled.unreleasableBuffer(
/* 39 */       Unpooled.directBuffer(2, 2).writeByte(-1).writeByte(0)).asReadOnly();
/*    */ 
/*    */   
/*    */   protected void encode(ChannelHandlerContext ctx, WebSocketFrame msg, List<Object> out) throws Exception {
/* 43 */     if (msg instanceof TextWebSocketFrame) {
/*    */       
/* 45 */       ByteBuf data = msg.content();
/*    */       
/* 47 */       out.add(_0X00.duplicate());
/* 48 */       out.add(data.retain());
/* 49 */       out.add(_0XFF.duplicate());
/* 50 */     } else if (msg instanceof CloseWebSocketFrame) {
/*    */ 
/*    */       
/* 53 */       out.add(_0XFF_0X00.duplicate());
/*    */     } else {
/*    */       
/* 56 */       ByteBuf data = msg.content();
/* 57 */       int dataLen = data.readableBytes();
/*    */       
/* 59 */       ByteBuf buf = ctx.alloc().buffer(5);
/* 60 */       boolean release = true;
/*    */       
/*    */       try {
/* 63 */         buf.writeByte(-128);
/*    */ 
/*    */         
/* 66 */         int b1 = dataLen >>> 28 & 0x7F;
/* 67 */         int b2 = dataLen >>> 14 & 0x7F;
/* 68 */         int b3 = dataLen >>> 7 & 0x7F;
/* 69 */         int b4 = dataLen & 0x7F;
/* 70 */         if (b1 == 0) {
/* 71 */           if (b2 == 0) {
/* 72 */             if (b3 != 0) {
/* 73 */               buf.writeByte(b3 | 0x80);
/*    */             }
/* 75 */             buf.writeByte(b4);
/*    */           } else {
/* 77 */             buf.writeByte(b2 | 0x80);
/* 78 */             buf.writeByte(b3 | 0x80);
/* 79 */             buf.writeByte(b4);
/*    */           } 
/*    */         } else {
/* 82 */           buf.writeByte(b1 | 0x80);
/* 83 */           buf.writeByte(b2 | 0x80);
/* 84 */           buf.writeByte(b3 | 0x80);
/* 85 */           buf.writeByte(b4);
/*    */         } 
/*    */ 
/*    */         
/* 89 */         out.add(buf);
/* 90 */         out.add(data.retain());
/* 91 */         release = false;
/*    */       } finally {
/* 93 */         if (release)
/* 94 */           buf.release(); 
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http-4.1.93.Final.jar!\io\netty\handler\codec\http\websocketx\WebSocket00FrameEncoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */