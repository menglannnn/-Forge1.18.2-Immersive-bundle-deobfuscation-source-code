/*    */ package io.netty.handler.codec.http.websocketx.extensions.compression;
/*    */ 
/*    */ import io.netty.channel.ChannelHandlerContext;
/*    */ import io.netty.handler.codec.http.websocketx.WebSocketFrame;
/*    */ import io.netty.handler.codec.http.websocketx.extensions.WebSocketExtensionFilter;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class PerMessageDeflateDecoder
/*    */   extends DeflateDecoder
/*    */ {
/*    */   private boolean compressing;
/*    */   
/*    */   PerMessageDeflateDecoder(boolean noContext) {
/* 41 */     super(noContext, WebSocketExtensionFilter.NEVER_SKIP);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   PerMessageDeflateDecoder(boolean noContext, WebSocketExtensionFilter extensionDecoderFilter) {
/* 51 */     super(noContext, extensionDecoderFilter);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean acceptInboundMessage(Object msg) throws Exception {
/* 56 */     if (!super.acceptInboundMessage(msg)) {
/* 57 */       return false;
/*    */     }
/*    */     
/* 60 */     WebSocketFrame wsFrame = (WebSocketFrame)msg;
/* 61 */     if (extensionDecoderFilter().mustSkip(wsFrame)) {
/* 62 */       if (this.compressing) {
/* 63 */         throw new IllegalStateException("Cannot skip per message deflate decoder, compression in progress");
/*    */       }
/* 65 */       return false;
/*    */     } 
/*    */     
/* 68 */     return (((wsFrame instanceof io.netty.handler.codec.http.websocketx.TextWebSocketFrame || wsFrame instanceof io.netty.handler.codec.http.websocketx.BinaryWebSocketFrame) && (wsFrame
/* 69 */       .rsv() & 0x4) > 0) || (wsFrame instanceof io.netty.handler.codec.http.websocketx.ContinuationWebSocketFrame && this.compressing));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected int newRsv(WebSocketFrame msg) {
/* 75 */     return ((msg.rsv() & 0x4) > 0) ? (msg
/* 76 */       .rsv() ^ 0x4) : msg.rsv();
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean appendFrameTail(WebSocketFrame msg) {
/* 81 */     return msg.isFinalFragment();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void decode(ChannelHandlerContext ctx, WebSocketFrame msg, List<Object> out) throws Exception {
/* 87 */     super.decode(ctx, msg, out);
/*    */     
/* 89 */     if (msg.isFinalFragment()) {
/* 90 */       this.compressing = false;
/* 91 */     } else if (msg instanceof io.netty.handler.codec.http.websocketx.TextWebSocketFrame || msg instanceof io.netty.handler.codec.http.websocketx.BinaryWebSocketFrame) {
/* 92 */       this.compressing = true;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http-4.1.93.Final.jar!\io\netty\handler\codec\http\websocketx\extensions\compression\PerMessageDeflateDecoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */