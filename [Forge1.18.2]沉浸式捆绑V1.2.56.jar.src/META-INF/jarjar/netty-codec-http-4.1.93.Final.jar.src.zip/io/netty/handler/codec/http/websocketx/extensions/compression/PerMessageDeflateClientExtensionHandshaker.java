/*     */ package io.netty.handler.codec.http.websocketx.extensions.compression;
/*     */ 
/*     */ import io.netty.handler.codec.compression.ZlibCodecFactory;
/*     */ import io.netty.handler.codec.http.websocketx.extensions.WebSocketClientExtension;
/*     */ import io.netty.handler.codec.http.websocketx.extensions.WebSocketClientExtensionHandshaker;
/*     */ import io.netty.handler.codec.http.websocketx.extensions.WebSocketExtensionData;
/*     */ import io.netty.handler.codec.http.websocketx.extensions.WebSocketExtensionDecoder;
/*     */ import io.netty.handler.codec.http.websocketx.extensions.WebSocketExtensionEncoder;
/*     */ import io.netty.handler.codec.http.websocketx.extensions.WebSocketExtensionFilterProvider;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PerMessageDeflateClientExtensionHandshaker
/*     */   implements WebSocketClientExtensionHandshaker
/*     */ {
/*     */   private final int compressionLevel;
/*     */   private final boolean allowClientWindowSize;
/*     */   private final int requestedServerWindowSize;
/*     */   private final boolean allowClientNoContext;
/*     */   private final boolean requestedServerNoContext;
/*     */   private final WebSocketExtensionFilterProvider extensionFilterProvider;
/*     */   
/*     */   public PerMessageDeflateClientExtensionHandshaker() {
/*  50 */     this(6, ZlibCodecFactory.isSupportingWindowSizeAndMemLevel(), 15, false, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PerMessageDeflateClientExtensionHandshaker(int compressionLevel, boolean allowClientWindowSize, int requestedServerWindowSize, boolean allowClientNoContext, boolean requestedServerNoContext) {
/*  73 */     this(compressionLevel, allowClientWindowSize, requestedServerWindowSize, allowClientNoContext, requestedServerNoContext, WebSocketExtensionFilterProvider.DEFAULT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PerMessageDeflateClientExtensionHandshaker(int compressionLevel, boolean allowClientWindowSize, int requestedServerWindowSize, boolean allowClientNoContext, boolean requestedServerNoContext, WebSocketExtensionFilterProvider extensionFilterProvider) {
/* 101 */     if (requestedServerWindowSize > 15 || requestedServerWindowSize < 8) {
/* 102 */       throw new IllegalArgumentException("requestedServerWindowSize: " + requestedServerWindowSize + " (expected: 8-15)");
/*     */     }
/*     */     
/* 105 */     if (compressionLevel < 0 || compressionLevel > 9) {
/* 106 */       throw new IllegalArgumentException("compressionLevel: " + compressionLevel + " (expected: 0-9)");
/*     */     }
/*     */     
/* 109 */     this.compressionLevel = compressionLevel;
/* 110 */     this.allowClientWindowSize = allowClientWindowSize;
/* 111 */     this.requestedServerWindowSize = requestedServerWindowSize;
/* 112 */     this.allowClientNoContext = allowClientNoContext;
/* 113 */     this.requestedServerNoContext = requestedServerNoContext;
/* 114 */     this.extensionFilterProvider = (WebSocketExtensionFilterProvider)ObjectUtil.checkNotNull(extensionFilterProvider, "extensionFilterProvider");
/*     */   }
/*     */ 
/*     */   
/*     */   public WebSocketExtensionData newRequestData() {
/* 119 */     HashMap<String, String> parameters = new HashMap<String, String>(4);
/* 120 */     if (this.requestedServerNoContext) {
/* 121 */       parameters.put("server_no_context_takeover", null);
/*     */     }
/* 123 */     if (this.allowClientNoContext) {
/* 124 */       parameters.put("client_no_context_takeover", null);
/*     */     }
/* 126 */     if (this.requestedServerWindowSize != 15) {
/* 127 */       parameters.put("server_max_window_bits", Integer.toString(this.requestedServerWindowSize));
/*     */     }
/* 129 */     if (this.allowClientWindowSize) {
/* 130 */       parameters.put("client_max_window_bits", null);
/*     */     }
/* 132 */     return new WebSocketExtensionData("permessage-deflate", parameters);
/*     */   }
/*     */ 
/*     */   
/*     */   public WebSocketClientExtension handshakeExtension(WebSocketExtensionData extensionData) {
/* 137 */     if (!"permessage-deflate".equals(extensionData.name())) {
/* 138 */       return null;
/*     */     }
/*     */     
/* 141 */     boolean succeed = true;
/* 142 */     int clientWindowSize = 15;
/* 143 */     int serverWindowSize = 15;
/* 144 */     boolean serverNoContext = false;
/* 145 */     boolean clientNoContext = false;
/*     */ 
/*     */     
/* 148 */     Iterator<Map.Entry<String, String>> parametersIterator = extensionData.parameters().entrySet().iterator();
/* 149 */     while (succeed && parametersIterator.hasNext()) {
/* 150 */       Map.Entry<String, String> parameter = parametersIterator.next();
/*     */       
/* 152 */       if ("client_max_window_bits".equalsIgnoreCase(parameter.getKey())) {
/*     */         
/* 154 */         if (this.allowClientWindowSize) {
/* 155 */           clientWindowSize = Integer.parseInt(parameter.getValue());
/* 156 */           if (clientWindowSize > 15 || clientWindowSize < 8)
/* 157 */             succeed = false; 
/*     */           continue;
/*     */         } 
/* 160 */         succeed = false; continue;
/*     */       } 
/* 162 */       if ("server_max_window_bits".equalsIgnoreCase(parameter.getKey())) {
/*     */         
/* 164 */         serverWindowSize = Integer.parseInt(parameter.getValue());
/* 165 */         if (serverWindowSize > 15 || serverWindowSize < 8)
/* 166 */           succeed = false;  continue;
/*     */       } 
/* 168 */       if ("client_no_context_takeover".equalsIgnoreCase(parameter.getKey())) {
/*     */         
/* 170 */         if (this.allowClientNoContext) {
/* 171 */           clientNoContext = true; continue;
/*     */         } 
/* 173 */         succeed = false; continue;
/*     */       } 
/* 175 */       if ("server_no_context_takeover".equalsIgnoreCase(parameter.getKey())) {
/*     */         
/* 177 */         serverNoContext = true;
/*     */         continue;
/*     */       } 
/* 180 */       succeed = false;
/*     */     } 
/*     */ 
/*     */     
/* 184 */     if ((this.requestedServerNoContext && !serverNoContext) || this.requestedServerWindowSize < serverWindowSize)
/*     */     {
/* 186 */       succeed = false;
/*     */     }
/*     */     
/* 189 */     if (succeed) {
/* 190 */       return new PermessageDeflateExtension(serverNoContext, serverWindowSize, clientNoContext, clientWindowSize, this.extensionFilterProvider);
/*     */     }
/*     */     
/* 193 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private final class PermessageDeflateExtension
/*     */     implements WebSocketClientExtension
/*     */   {
/*     */     private final boolean serverNoContext;
/*     */     private final int serverWindowSize;
/*     */     private final boolean clientNoContext;
/*     */     private final int clientWindowSize;
/*     */     private final WebSocketExtensionFilterProvider extensionFilterProvider;
/*     */     
/*     */     public int rsv() {
/* 207 */       return 4;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     PermessageDeflateExtension(boolean serverNoContext, int serverWindowSize, boolean clientNoContext, int clientWindowSize, WebSocketExtensionFilterProvider extensionFilterProvider) {
/* 213 */       this.serverNoContext = serverNoContext;
/* 214 */       this.serverWindowSize = serverWindowSize;
/* 215 */       this.clientNoContext = clientNoContext;
/* 216 */       this.clientWindowSize = clientWindowSize;
/* 217 */       this.extensionFilterProvider = extensionFilterProvider;
/*     */     }
/*     */ 
/*     */     
/*     */     public WebSocketExtensionEncoder newExtensionEncoder() {
/* 222 */       return new PerMessageDeflateEncoder(PerMessageDeflateClientExtensionHandshaker.this.compressionLevel, this.clientWindowSize, this.clientNoContext, this.extensionFilterProvider
/* 223 */           .encoderFilter());
/*     */     }
/*     */ 
/*     */     
/*     */     public WebSocketExtensionDecoder newExtensionDecoder() {
/* 228 */       return new PerMessageDeflateDecoder(this.serverNoContext, this.extensionFilterProvider.decoderFilter());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http-4.1.93.Final.jar!\io\netty\handler\codec\http\websocketx\extensions\compression\PerMessageDeflateClientExtensionHandshaker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */