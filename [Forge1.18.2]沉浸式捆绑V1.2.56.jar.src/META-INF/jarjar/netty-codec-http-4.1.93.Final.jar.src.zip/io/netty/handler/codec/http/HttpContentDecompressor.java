/*    */ package io.netty.handler.codec.http;
/*    */ 
/*    */ import io.netty.channel.ChannelHandler;
/*    */ import io.netty.channel.embedded.EmbeddedChannel;
/*    */ import io.netty.handler.codec.compression.Brotli;
/*    */ import io.netty.handler.codec.compression.BrotliDecoder;
/*    */ import io.netty.handler.codec.compression.SnappyFrameDecoder;
/*    */ import io.netty.handler.codec.compression.ZlibCodecFactory;
/*    */ import io.netty.handler.codec.compression.ZlibWrapper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HttpContentDecompressor
/*    */   extends HttpContentDecoder
/*    */ {
/*    */   private final boolean strict;
/*    */   
/*    */   public HttpContentDecompressor() {
/* 45 */     this(false);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public HttpContentDecompressor(boolean strict) {
/* 55 */     this.strict = strict;
/*    */   }
/*    */ 
/*    */   
/*    */   protected EmbeddedChannel newContentDecoder(String contentEncoding) throws Exception {
/* 60 */     if (HttpHeaderValues.GZIP.contentEqualsIgnoreCase(contentEncoding) || HttpHeaderValues.X_GZIP
/* 61 */       .contentEqualsIgnoreCase(contentEncoding)) {
/* 62 */       return new EmbeddedChannel(this.ctx.channel().id(), this.ctx.channel().metadata().hasDisconnect(), this.ctx
/* 63 */           .channel().config(), new ChannelHandler[] { (ChannelHandler)ZlibCodecFactory.newZlibDecoder(ZlibWrapper.GZIP) });
/*    */     }
/* 65 */     if (HttpHeaderValues.DEFLATE.contentEqualsIgnoreCase(contentEncoding) || HttpHeaderValues.X_DEFLATE
/* 66 */       .contentEqualsIgnoreCase(contentEncoding)) {
/* 67 */       ZlibWrapper wrapper = this.strict ? ZlibWrapper.ZLIB : ZlibWrapper.ZLIB_OR_NONE;
/*    */       
/* 69 */       return new EmbeddedChannel(this.ctx.channel().id(), this.ctx.channel().metadata().hasDisconnect(), this.ctx
/* 70 */           .channel().config(), new ChannelHandler[] { (ChannelHandler)ZlibCodecFactory.newZlibDecoder(wrapper) });
/*    */     } 
/* 72 */     if (Brotli.isAvailable() && HttpHeaderValues.BR.contentEqualsIgnoreCase(contentEncoding)) {
/* 73 */       return new EmbeddedChannel(this.ctx.channel().id(), this.ctx.channel().metadata().hasDisconnect(), this.ctx
/* 74 */           .channel().config(), new ChannelHandler[] { (ChannelHandler)new BrotliDecoder() });
/*    */     }
/*    */     
/* 77 */     if (HttpHeaderValues.SNAPPY.contentEqualsIgnoreCase(contentEncoding)) {
/* 78 */       return new EmbeddedChannel(this.ctx.channel().id(), this.ctx.channel().metadata().hasDisconnect(), this.ctx
/* 79 */           .channel().config(), new ChannelHandler[] { (ChannelHandler)new SnappyFrameDecoder() });
/*    */     }
/*    */ 
/*    */     
/* 83 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http-4.1.93.Final.jar!\io\netty\handler\codec\http\HttpContentDecompressor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */