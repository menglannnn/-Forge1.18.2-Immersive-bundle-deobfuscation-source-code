/*     */ package io.netty.handler.codec.http;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.buffer.ByteBufHolder;
/*     */ import io.netty.buffer.ByteBufUtil;
/*     */ import io.netty.buffer.Unpooled;
/*     */ import io.netty.util.IllegalReferenceCountException;
/*     */ import io.netty.util.ReferenceCounted;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultFullHttpResponse
/*     */   extends DefaultHttpResponse
/*     */   implements FullHttpResponse
/*     */ {
/*     */   private final ByteBuf content;
/*     */   private final HttpHeaders trailingHeaders;
/*     */   private int hash;
/*     */   
/*     */   public DefaultFullHttpResponse(HttpVersion version, HttpResponseStatus status) {
/*  39 */     this(version, status, Unpooled.buffer(0));
/*     */   }
/*     */   
/*     */   public DefaultFullHttpResponse(HttpVersion version, HttpResponseStatus status, ByteBuf content) {
/*  43 */     this(version, status, content, true);
/*     */   }
/*     */   
/*     */   public DefaultFullHttpResponse(HttpVersion version, HttpResponseStatus status, boolean validateHeaders) {
/*  47 */     this(version, status, Unpooled.buffer(0), validateHeaders, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public DefaultFullHttpResponse(HttpVersion version, HttpResponseStatus status, boolean validateHeaders, boolean singleFieldHeaders) {
/*  52 */     this(version, status, Unpooled.buffer(0), validateHeaders, singleFieldHeaders);
/*     */   }
/*     */ 
/*     */   
/*     */   public DefaultFullHttpResponse(HttpVersion version, HttpResponseStatus status, ByteBuf content, boolean validateHeaders) {
/*  57 */     this(version, status, content, validateHeaders, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public DefaultFullHttpResponse(HttpVersion version, HttpResponseStatus status, ByteBuf content, boolean validateHeaders, boolean singleFieldHeaders) {
/*  62 */     super(version, status, validateHeaders, singleFieldHeaders);
/*  63 */     this.content = (ByteBuf)ObjectUtil.checkNotNull(content, "content");
/*  64 */     this.trailingHeaders = singleFieldHeaders ? new CombinedHttpHeaders(validateHeaders) : new DefaultHttpHeaders(validateHeaders);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultFullHttpResponse(HttpVersion version, HttpResponseStatus status, ByteBuf content, HttpHeaders headers, HttpHeaders trailingHeaders) {
/*  70 */     super(version, status, headers);
/*  71 */     this.content = (ByteBuf)ObjectUtil.checkNotNull(content, "content");
/*  72 */     this.trailingHeaders = (HttpHeaders)ObjectUtil.checkNotNull(trailingHeaders, "trailingHeaders");
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpHeaders trailingHeaders() {
/*  77 */     return this.trailingHeaders;
/*     */   }
/*     */ 
/*     */   
/*     */   public ByteBuf content() {
/*  82 */     return this.content;
/*     */   }
/*     */ 
/*     */   
/*     */   public int refCnt() {
/*  87 */     return this.content.refCnt();
/*     */   }
/*     */ 
/*     */   
/*     */   public FullHttpResponse retain() {
/*  92 */     this.content.retain();
/*  93 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public FullHttpResponse retain(int increment) {
/*  98 */     this.content.retain(increment);
/*  99 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public FullHttpResponse touch() {
/* 104 */     this.content.touch();
/* 105 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public FullHttpResponse touch(Object hint) {
/* 110 */     this.content.touch(hint);
/* 111 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean release() {
/* 116 */     return this.content.release();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean release(int decrement) {
/* 121 */     return this.content.release(decrement);
/*     */   }
/*     */ 
/*     */   
/*     */   public FullHttpResponse setProtocolVersion(HttpVersion version) {
/* 126 */     super.setProtocolVersion(version);
/* 127 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public FullHttpResponse setStatus(HttpResponseStatus status) {
/* 132 */     super.setStatus(status);
/* 133 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public FullHttpResponse copy() {
/* 138 */     return replace(content().copy());
/*     */   }
/*     */ 
/*     */   
/*     */   public FullHttpResponse duplicate() {
/* 143 */     return replace(content().duplicate());
/*     */   }
/*     */ 
/*     */   
/*     */   public FullHttpResponse retainedDuplicate() {
/* 148 */     return replace(content().retainedDuplicate());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public FullHttpResponse replace(ByteBuf content) {
/* 154 */     FullHttpResponse response = new DefaultFullHttpResponse(protocolVersion(), status(), content, headers().copy(), trailingHeaders().copy());
/* 155 */     response.setDecoderResult(decoderResult());
/* 156 */     return response;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 161 */     int hash = this.hash;
/* 162 */     if (hash == 0) {
/* 163 */       if (ByteBufUtil.isAccessible(content())) {
/*     */         try {
/* 165 */           hash = 31 + content().hashCode();
/* 166 */         } catch (IllegalReferenceCountException ignored) {
/*     */           
/* 168 */           hash = 31;
/*     */         } 
/*     */       } else {
/* 171 */         hash = 31;
/*     */       } 
/* 173 */       hash = 31 * hash + trailingHeaders().hashCode();
/* 174 */       hash = 31 * hash + super.hashCode();
/* 175 */       this.hash = hash;
/*     */     } 
/* 177 */     return hash;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 182 */     if (!(o instanceof DefaultFullHttpResponse)) {
/* 183 */       return false;
/*     */     }
/*     */     
/* 186 */     DefaultFullHttpResponse other = (DefaultFullHttpResponse)o;
/*     */     
/* 188 */     return (super.equals(other) && 
/* 189 */       content().equals(other.content()) && 
/* 190 */       trailingHeaders().equals(other.trailingHeaders()));
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 195 */     return HttpMessageUtil.appendFullResponse(new StringBuilder(256), this).toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http-4.1.93.Final.jar!\io\netty\handler\codec\http\DefaultFullHttpResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */