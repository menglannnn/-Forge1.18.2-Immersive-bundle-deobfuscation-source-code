/*     */ package io.netty.handler.codec.http;
/*     */ 
/*     */ import io.netty.handler.codec.DefaultHeaders;
/*     */ import io.netty.handler.codec.Headers;
/*     */ import io.netty.handler.codec.ValueConverter;
/*     */ import io.netty.util.AsciiString;
/*     */ import io.netty.util.HashingStrategy;
/*     */ import io.netty.util.internal.StringUtil;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CombinedHttpHeaders
/*     */   extends DefaultHttpHeaders
/*     */ {
/*     */   public CombinedHttpHeaders(boolean validate) {
/*  41 */     super(new CombinedHttpHeadersImpl(AsciiString.CASE_INSENSITIVE_HASHER, valueConverter(), nameValidator(validate), 
/*  42 */           valueValidator(validate)));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsValue(CharSequence name, CharSequence value, boolean ignoreCase) {
/*  47 */     return super.containsValue(name, StringUtil.trimOws(value), ignoreCase);
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class CombinedHttpHeadersImpl
/*     */     extends DefaultHeaders<CharSequence, CharSequence, CombinedHttpHeadersImpl>
/*     */   {
/*     */     private static final int VALUE_LENGTH_ESTIMATE = 10;
/*     */     
/*     */     private CsvValueEscaper<Object> objectEscaper;
/*     */     private CsvValueEscaper<CharSequence> charSequenceEscaper;
/*     */     
/*     */     private CsvValueEscaper<Object> objectEscaper() {
/*  60 */       if (this.objectEscaper == null) {
/*  61 */         this.objectEscaper = new CsvValueEscaper()
/*     */           {
/*     */             public CharSequence escape(CharSequence name, Object value) {
/*     */               CharSequence converted;
/*     */               try {
/*  66 */                 converted = (CharSequence)CombinedHttpHeaders.CombinedHttpHeadersImpl.this.valueConverter().convertObject(value);
/*  67 */               } catch (IllegalArgumentException e) {
/*  68 */                 throw new IllegalArgumentException("Failed to convert object value for header '" + name + '\'', e);
/*     */               } 
/*     */               
/*  71 */               return StringUtil.escapeCsv(converted, true);
/*     */             }
/*     */           };
/*     */       }
/*  75 */       return this.objectEscaper;
/*     */     }
/*     */     
/*     */     private CsvValueEscaper<CharSequence> charSequenceEscaper() {
/*  79 */       if (this.charSequenceEscaper == null) {
/*  80 */         this.charSequenceEscaper = new CsvValueEscaper<CharSequence>()
/*     */           {
/*     */             public CharSequence escape(CharSequence name, CharSequence value) {
/*  83 */               return StringUtil.escapeCsv(value, true);
/*     */             }
/*     */           };
/*     */       }
/*  87 */       return this.charSequenceEscaper;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     CombinedHttpHeadersImpl(HashingStrategy<CharSequence> nameHashingStrategy, ValueConverter<CharSequence> valueConverter, DefaultHeaders.NameValidator<CharSequence> nameValidator, DefaultHeaders.ValueValidator<CharSequence> valueValidator) {
/*  94 */       super(nameHashingStrategy, valueConverter, nameValidator, 16, valueValidator);
/*     */     }
/*     */ 
/*     */     
/*     */     public Iterator<CharSequence> valueIterator(CharSequence name) {
/*  99 */       Iterator<CharSequence> itr = super.valueIterator(name);
/* 100 */       if (!itr.hasNext() || cannotBeCombined(name)) {
/* 101 */         return itr;
/*     */       }
/* 103 */       Iterator<CharSequence> unescapedItr = StringUtil.unescapeCsvFields(itr.next()).iterator();
/* 104 */       if (itr.hasNext()) {
/* 105 */         throw new IllegalStateException("CombinedHttpHeaders should only have one value");
/*     */       }
/* 107 */       return unescapedItr;
/*     */     }
/*     */ 
/*     */     
/*     */     public List<CharSequence> getAll(CharSequence name) {
/* 112 */       List<CharSequence> values = super.getAll(name);
/* 113 */       if (values.isEmpty() || cannotBeCombined(name)) {
/* 114 */         return values;
/*     */       }
/* 116 */       if (values.size() != 1) {
/* 117 */         throw new IllegalStateException("CombinedHttpHeaders should only have one value");
/*     */       }
/* 119 */       return StringUtil.unescapeCsvFields(values.get(0));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public CombinedHttpHeadersImpl add(Headers<? extends CharSequence, ? extends CharSequence, ?> headers) {
/* 125 */       if (headers == this) {
/* 126 */         throw new IllegalArgumentException("can't add to itself.");
/*     */       }
/* 128 */       if (headers instanceof CombinedHttpHeadersImpl) {
/* 129 */         if (isEmpty()) {
/*     */           
/* 131 */           addImpl(headers);
/*     */         } else {
/*     */           
/* 134 */           for (Map.Entry<? extends CharSequence, ? extends CharSequence> header : headers) {
/* 135 */             addEscapedValue(header.getKey(), header.getValue());
/*     */           }
/*     */         } 
/*     */       } else {
/* 139 */         for (Map.Entry<? extends CharSequence, ? extends CharSequence> header : headers) {
/* 140 */           add(header.getKey(), header.getValue());
/*     */         }
/*     */       } 
/* 143 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public CombinedHttpHeadersImpl set(Headers<? extends CharSequence, ? extends CharSequence, ?> headers) {
/* 148 */       if (headers == this) {
/* 149 */         return this;
/*     */       }
/* 151 */       clear();
/* 152 */       return add(headers);
/*     */     }
/*     */ 
/*     */     
/*     */     public CombinedHttpHeadersImpl setAll(Headers<? extends CharSequence, ? extends CharSequence, ?> headers) {
/* 157 */       if (headers == this) {
/* 158 */         return this;
/*     */       }
/* 160 */       for (CharSequence key : headers.names()) {
/* 161 */         remove(key);
/*     */       }
/* 163 */       return add(headers);
/*     */     }
/*     */ 
/*     */     
/*     */     public CombinedHttpHeadersImpl add(CharSequence name, CharSequence value) {
/* 168 */       return addEscapedValue(name, charSequenceEscaper().escape(name, value));
/*     */     }
/*     */ 
/*     */     
/*     */     public CombinedHttpHeadersImpl add(CharSequence name, CharSequence... values) {
/* 173 */       return addEscapedValue(name, commaSeparate(name, charSequenceEscaper(), values));
/*     */     }
/*     */ 
/*     */     
/*     */     public CombinedHttpHeadersImpl add(CharSequence name, Iterable<? extends CharSequence> values) {
/* 178 */       return addEscapedValue(name, commaSeparate(name, charSequenceEscaper(), values));
/*     */     }
/*     */ 
/*     */     
/*     */     public CombinedHttpHeadersImpl addObject(CharSequence name, Object value) {
/* 183 */       return addEscapedValue(name, commaSeparate(name, objectEscaper(), new Object[] { value }));
/*     */     }
/*     */ 
/*     */     
/*     */     public CombinedHttpHeadersImpl addObject(CharSequence name, Iterable<?> values) {
/* 188 */       return addEscapedValue(name, commaSeparate(name, objectEscaper(), values));
/*     */     }
/*     */ 
/*     */     
/*     */     public CombinedHttpHeadersImpl addObject(CharSequence name, Object... values) {
/* 193 */       return addEscapedValue(name, commaSeparate(name, objectEscaper(), values));
/*     */     }
/*     */ 
/*     */     
/*     */     public CombinedHttpHeadersImpl set(CharSequence name, CharSequence... values) {
/* 198 */       set(name, commaSeparate(name, charSequenceEscaper(), values));
/* 199 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public CombinedHttpHeadersImpl set(CharSequence name, Iterable<? extends CharSequence> values) {
/* 204 */       set(name, commaSeparate(name, charSequenceEscaper(), values));
/* 205 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public CombinedHttpHeadersImpl setObject(CharSequence name, Object value) {
/* 210 */       set(name, commaSeparate(name, objectEscaper(), new Object[] { value }));
/* 211 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public CombinedHttpHeadersImpl setObject(CharSequence name, Object... values) {
/* 216 */       set(name, commaSeparate(name, objectEscaper(), values));
/* 217 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public CombinedHttpHeadersImpl setObject(CharSequence name, Iterable<?> values) {
/* 222 */       set(name, commaSeparate(name, objectEscaper(), values));
/* 223 */       return this;
/*     */     }
/*     */     
/*     */     private static boolean cannotBeCombined(CharSequence name) {
/* 227 */       return HttpHeaderNames.SET_COOKIE.contentEqualsIgnoreCase(name);
/*     */     }
/*     */     
/*     */     private CombinedHttpHeadersImpl addEscapedValue(CharSequence name, CharSequence escapedValue) {
/* 231 */       CharSequence currentValue = (CharSequence)get(name);
/* 232 */       if (currentValue == null || cannotBeCombined(name)) {
/* 233 */         super.add(name, escapedValue);
/*     */       } else {
/* 235 */         set(name, commaSeparateEscapedValues(currentValue, escapedValue));
/*     */       } 
/* 237 */       return this;
/*     */     }
/*     */     
/*     */     private static <T> CharSequence commaSeparate(CharSequence name, CsvValueEscaper<T> escaper, T... values) {
/* 241 */       StringBuilder sb = new StringBuilder(values.length * 10);
/* 242 */       if (values.length > 0) {
/* 243 */         int end = values.length - 1;
/* 244 */         for (int i = 0; i < end; i++) {
/* 245 */           sb.append(escaper.escape(name, values[i])).append(',');
/*     */         }
/* 247 */         sb.append(escaper.escape(name, values[end]));
/*     */       } 
/* 249 */       return sb;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private static <T> CharSequence commaSeparate(CharSequence name, CsvValueEscaper<T> escaper, Iterable<? extends T> values) {
/* 256 */       StringBuilder sb = (values instanceof Collection) ? new StringBuilder(((Collection)values).size() * 10) : new StringBuilder();
/* 257 */       Iterator<? extends T> iterator = values.iterator();
/* 258 */       if (iterator.hasNext()) {
/* 259 */         T next = iterator.next();
/* 260 */         while (iterator.hasNext()) {
/* 261 */           sb.append(escaper.escape(name, next)).append(',');
/* 262 */           next = iterator.next();
/*     */         } 
/* 264 */         sb.append(escaper.escape(name, next));
/*     */       } 
/* 266 */       return sb;
/*     */     }
/*     */     
/*     */     private static CharSequence commaSeparateEscapedValues(CharSequence currentValue, CharSequence value) {
/* 270 */       return (new StringBuilder(currentValue.length() + 1 + value.length()))
/* 271 */         .append(currentValue)
/* 272 */         .append(',')
/* 273 */         .append(value);
/*     */     }
/*     */     
/*     */     private static interface CsvValueEscaper<T> {
/*     */       CharSequence escape(CharSequence param2CharSequence, T param2T);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http-4.1.93.Final.jar!\io\netty\handler\codec\http\CombinedHttpHeaders.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */