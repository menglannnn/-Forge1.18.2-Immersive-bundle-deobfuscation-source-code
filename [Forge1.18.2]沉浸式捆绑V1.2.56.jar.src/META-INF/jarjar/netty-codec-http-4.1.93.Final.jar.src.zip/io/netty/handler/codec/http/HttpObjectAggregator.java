/*     */ package io.netty.handler.codec.http;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.buffer.ByteBufHolder;
/*     */ import io.netty.buffer.Unpooled;
/*     */ import io.netty.channel.ChannelFuture;
/*     */ import io.netty.channel.ChannelFutureListener;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.channel.ChannelPipeline;
/*     */ import io.netty.handler.codec.DecoderResult;
/*     */ import io.netty.handler.codec.MessageAggregator;
/*     */ import io.netty.util.ReferenceCounted;
/*     */ import io.netty.util.concurrent.Future;
/*     */ import io.netty.util.concurrent.GenericFutureListener;
/*     */ import io.netty.util.internal.logging.InternalLogger;
/*     */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpObjectAggregator
/*     */   extends MessageAggregator<HttpObject, HttpMessage, HttpContent, FullHttpMessage>
/*     */ {
/*  88 */   private static final InternalLogger logger = InternalLoggerFactory.getInstance(HttpObjectAggregator.class);
/*  89 */   private static final FullHttpResponse CONTINUE = new DefaultFullHttpResponse(HttpVersion.HTTP_1_1, HttpResponseStatus.CONTINUE, Unpooled.EMPTY_BUFFER);
/*     */   
/*  91 */   private static final FullHttpResponse EXPECTATION_FAILED = new DefaultFullHttpResponse(HttpVersion.HTTP_1_1, HttpResponseStatus.EXPECTATION_FAILED, Unpooled.EMPTY_BUFFER);
/*     */   
/*  93 */   private static final FullHttpResponse TOO_LARGE_CLOSE = new DefaultFullHttpResponse(HttpVersion.HTTP_1_1, HttpResponseStatus.REQUEST_ENTITY_TOO_LARGE, Unpooled.EMPTY_BUFFER);
/*     */   
/*  95 */   private static final FullHttpResponse TOO_LARGE = new DefaultFullHttpResponse(HttpVersion.HTTP_1_1, HttpResponseStatus.REQUEST_ENTITY_TOO_LARGE, Unpooled.EMPTY_BUFFER);
/*     */   private final boolean closeOnExpectationFailed;
/*     */   
/*     */   static {
/*  99 */     EXPECTATION_FAILED.headers().set((CharSequence)HttpHeaderNames.CONTENT_LENGTH, Integer.valueOf(0));
/* 100 */     TOO_LARGE.headers().set((CharSequence)HttpHeaderNames.CONTENT_LENGTH, Integer.valueOf(0));
/*     */     
/* 102 */     TOO_LARGE_CLOSE.headers().set((CharSequence)HttpHeaderNames.CONTENT_LENGTH, Integer.valueOf(0));
/* 103 */     TOO_LARGE_CLOSE.headers().set((CharSequence)HttpHeaderNames.CONNECTION, HttpHeaderValues.CLOSE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpObjectAggregator(int maxContentLength) {
/* 115 */     this(maxContentLength, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpObjectAggregator(int maxContentLength, boolean closeOnExpectationFailed) {
/* 128 */     super(maxContentLength);
/* 129 */     this.closeOnExpectationFailed = closeOnExpectationFailed;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isStartMessage(HttpObject msg) throws Exception {
/* 134 */     return msg instanceof HttpMessage;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isContentMessage(HttpObject msg) throws Exception {
/* 139 */     return msg instanceof HttpContent;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isLastContentMessage(HttpContent msg) throws Exception {
/* 144 */     return msg instanceof LastHttpContent;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isAggregated(HttpObject msg) throws Exception {
/* 149 */     return msg instanceof FullHttpMessage;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isContentLengthInvalid(HttpMessage start, int maxContentLength) {
/*     */     try {
/* 155 */       return (HttpUtil.getContentLength(start, -1L) > maxContentLength);
/* 156 */     } catch (NumberFormatException e) {
/* 157 */       return false;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static Object continueResponse(HttpMessage start, int maxContentLength, ChannelPipeline pipeline) {
/* 162 */     if (HttpUtil.isUnsupportedExpectation(start)) {
/*     */       
/* 164 */       pipeline.fireUserEventTriggered(HttpExpectationFailedEvent.INSTANCE);
/* 165 */       return EXPECTATION_FAILED.retainedDuplicate();
/* 166 */     }  if (HttpUtil.is100ContinueExpected(start)) {
/*     */       
/* 168 */       if (HttpUtil.getContentLength(start, -1L) <= maxContentLength) {
/* 169 */         return CONTINUE.retainedDuplicate();
/*     */       }
/* 171 */       pipeline.fireUserEventTriggered(HttpExpectationFailedEvent.INSTANCE);
/* 172 */       return TOO_LARGE.retainedDuplicate();
/*     */     } 
/*     */     
/* 175 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Object newContinueResponse(HttpMessage start, int maxContentLength, ChannelPipeline pipeline) {
/* 180 */     Object response = continueResponse(start, maxContentLength, pipeline);
/*     */ 
/*     */     
/* 183 */     if (response != null) {
/* 184 */       start.headers().remove((CharSequence)HttpHeaderNames.EXPECT);
/*     */     }
/* 186 */     return response;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean closeAfterContinueResponse(Object msg) {
/* 191 */     return (this.closeOnExpectationFailed && ignoreContentAfterContinueResponse(msg));
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean ignoreContentAfterContinueResponse(Object msg) {
/* 196 */     if (msg instanceof HttpResponse) {
/* 197 */       HttpResponse httpResponse = (HttpResponse)msg;
/* 198 */       return httpResponse.status().codeClass().equals(HttpStatusClass.CLIENT_ERROR);
/*     */     } 
/* 200 */     return false;
/*     */   }
/*     */   
/*     */   protected FullHttpMessage beginAggregation(HttpMessage start, ByteBuf content) throws Exception {
/*     */     AggregatedFullHttpMessage ret;
/* 205 */     assert !(start instanceof FullHttpMessage);
/*     */     
/* 207 */     HttpUtil.setTransferEncodingChunked(start, false);
/*     */ 
/*     */     
/* 210 */     if (start instanceof HttpRequest) {
/* 211 */       ret = new AggregatedFullHttpRequest((HttpRequest)start, content, null);
/* 212 */     } else if (start instanceof HttpResponse) {
/* 213 */       ret = new AggregatedFullHttpResponse((HttpResponse)start, content, null);
/*     */     } else {
/* 215 */       throw new Error();
/*     */     } 
/* 217 */     return ret;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void aggregate(FullHttpMessage aggregated, HttpContent content) throws Exception {
/* 222 */     if (content instanceof LastHttpContent)
/*     */     {
/* 224 */       ((AggregatedFullHttpMessage)aggregated).setTrailingHeaders(((LastHttpContent)content).trailingHeaders());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void finishAggregation(FullHttpMessage aggregated) throws Exception {
/* 236 */     if (!HttpUtil.isContentLengthSet(aggregated)) {
/* 237 */       aggregated.headers().set((CharSequence)HttpHeaderNames.CONTENT_LENGTH, 
/*     */           
/* 239 */           String.valueOf(aggregated.content().readableBytes()));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected void handleOversizedMessage(final ChannelHandlerContext ctx, HttpMessage oversized) throws Exception {
/* 245 */     if (oversized instanceof HttpRequest) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 250 */       if (oversized instanceof FullHttpMessage || (
/* 251 */         !HttpUtil.is100ContinueExpected(oversized) && !HttpUtil.isKeepAlive(oversized))) {
/* 252 */         ChannelFuture future = ctx.writeAndFlush(TOO_LARGE_CLOSE.retainedDuplicate());
/* 253 */         future.addListener((GenericFutureListener)new ChannelFutureListener()
/*     */             {
/*     */               public void operationComplete(ChannelFuture future) throws Exception {
/* 256 */                 if (!future.isSuccess()) {
/* 257 */                   HttpObjectAggregator.logger.debug("Failed to send a 413 Request Entity Too Large.", future.cause());
/*     */                 }
/* 259 */                 ctx.close();
/*     */               }
/*     */             });
/*     */       } else {
/* 263 */         ctx.writeAndFlush(TOO_LARGE.retainedDuplicate()).addListener((GenericFutureListener)new ChannelFutureListener()
/*     */             {
/*     */               public void operationComplete(ChannelFuture future) throws Exception {
/* 266 */                 if (!future.isSuccess()) {
/* 267 */                   HttpObjectAggregator.logger.debug("Failed to send a 413 Request Entity Too Large.", future.cause());
/* 268 */                   ctx.close();
/*     */                 }  }
/*     */             });
/*     */       } 
/*     */     } else {
/* 273 */       if (oversized instanceof HttpResponse) {
/* 274 */         ctx.close();
/* 275 */         throw new TooLongHttpContentException("Response entity too large: " + oversized);
/*     */       } 
/* 277 */       throw new IllegalStateException();
/*     */     } 
/*     */   }
/*     */   
/*     */   private static abstract class AggregatedFullHttpMessage implements FullHttpMessage {
/*     */     protected final HttpMessage message;
/*     */     private final ByteBuf content;
/*     */     private HttpHeaders trailingHeaders;
/*     */     
/*     */     AggregatedFullHttpMessage(HttpMessage message, ByteBuf content, HttpHeaders trailingHeaders) {
/* 287 */       this.message = message;
/* 288 */       this.content = content;
/* 289 */       this.trailingHeaders = trailingHeaders;
/*     */     }
/*     */ 
/*     */     
/*     */     public HttpHeaders trailingHeaders() {
/* 294 */       HttpHeaders trailingHeaders = this.trailingHeaders;
/* 295 */       if (trailingHeaders == null) {
/* 296 */         return EmptyHttpHeaders.INSTANCE;
/*     */       }
/* 298 */       return trailingHeaders;
/*     */     }
/*     */ 
/*     */     
/*     */     void setTrailingHeaders(HttpHeaders trailingHeaders) {
/* 303 */       this.trailingHeaders = trailingHeaders;
/*     */     }
/*     */ 
/*     */     
/*     */     public HttpVersion getProtocolVersion() {
/* 308 */       return this.message.protocolVersion();
/*     */     }
/*     */ 
/*     */     
/*     */     public HttpVersion protocolVersion() {
/* 313 */       return this.message.protocolVersion();
/*     */     }
/*     */ 
/*     */     
/*     */     public FullHttpMessage setProtocolVersion(HttpVersion version) {
/* 318 */       this.message.setProtocolVersion(version);
/* 319 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public HttpHeaders headers() {
/* 324 */       return this.message.headers();
/*     */     }
/*     */ 
/*     */     
/*     */     public DecoderResult decoderResult() {
/* 329 */       return this.message.decoderResult();
/*     */     }
/*     */ 
/*     */     
/*     */     public DecoderResult getDecoderResult() {
/* 334 */       return this.message.decoderResult();
/*     */     }
/*     */ 
/*     */     
/*     */     public void setDecoderResult(DecoderResult result) {
/* 339 */       this.message.setDecoderResult(result);
/*     */     }
/*     */ 
/*     */     
/*     */     public ByteBuf content() {
/* 344 */       return this.content;
/*     */     }
/*     */ 
/*     */     
/*     */     public int refCnt() {
/* 349 */       return this.content.refCnt();
/*     */     }
/*     */ 
/*     */     
/*     */     public FullHttpMessage retain() {
/* 354 */       this.content.retain();
/* 355 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public FullHttpMessage retain(int increment) {
/* 360 */       this.content.retain(increment);
/* 361 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public FullHttpMessage touch(Object hint) {
/* 366 */       this.content.touch(hint);
/* 367 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public FullHttpMessage touch() {
/* 372 */       this.content.touch();
/* 373 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean release() {
/* 378 */       return this.content.release();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean release(int decrement) {
/* 383 */       return this.content.release(decrement);
/*     */     }
/*     */ 
/*     */     
/*     */     public abstract FullHttpMessage copy();
/*     */     
/*     */     public abstract FullHttpMessage duplicate();
/*     */     
/*     */     public abstract FullHttpMessage retainedDuplicate();
/*     */   }
/*     */   
/*     */   private static final class AggregatedFullHttpRequest
/*     */     extends AggregatedFullHttpMessage
/*     */     implements FullHttpRequest
/*     */   {
/*     */     AggregatedFullHttpRequest(HttpRequest request, ByteBuf content, HttpHeaders trailingHeaders) {
/* 399 */       super(request, content, trailingHeaders);
/*     */     }
/*     */ 
/*     */     
/*     */     public FullHttpRequest copy() {
/* 404 */       return replace(content().copy());
/*     */     }
/*     */ 
/*     */     
/*     */     public FullHttpRequest duplicate() {
/* 409 */       return replace(content().duplicate());
/*     */     }
/*     */ 
/*     */     
/*     */     public FullHttpRequest retainedDuplicate() {
/* 414 */       return replace(content().retainedDuplicate());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public FullHttpRequest replace(ByteBuf content) {
/* 420 */       DefaultFullHttpRequest dup = new DefaultFullHttpRequest(protocolVersion(), method(), uri(), content, headers().copy(), trailingHeaders().copy());
/* 421 */       dup.setDecoderResult(decoderResult());
/* 422 */       return dup;
/*     */     }
/*     */ 
/*     */     
/*     */     public FullHttpRequest retain(int increment) {
/* 427 */       super.retain(increment);
/* 428 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public FullHttpRequest retain() {
/* 433 */       super.retain();
/* 434 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public FullHttpRequest touch() {
/* 439 */       super.touch();
/* 440 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public FullHttpRequest touch(Object hint) {
/* 445 */       super.touch(hint);
/* 446 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public FullHttpRequest setMethod(HttpMethod method) {
/* 451 */       ((HttpRequest)this.message).setMethod(method);
/* 452 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public FullHttpRequest setUri(String uri) {
/* 457 */       ((HttpRequest)this.message).setUri(uri);
/* 458 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public HttpMethod getMethod() {
/* 463 */       return ((HttpRequest)this.message).method();
/*     */     }
/*     */ 
/*     */     
/*     */     public String getUri() {
/* 468 */       return ((HttpRequest)this.message).uri();
/*     */     }
/*     */ 
/*     */     
/*     */     public HttpMethod method() {
/* 473 */       return getMethod();
/*     */     }
/*     */ 
/*     */     
/*     */     public String uri() {
/* 478 */       return getUri();
/*     */     }
/*     */ 
/*     */     
/*     */     public FullHttpRequest setProtocolVersion(HttpVersion version) {
/* 483 */       super.setProtocolVersion(version);
/* 484 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 489 */       return HttpMessageUtil.appendFullRequest(new StringBuilder(256), this).toString();
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class AggregatedFullHttpResponse
/*     */     extends AggregatedFullHttpMessage
/*     */     implements FullHttpResponse {
/*     */     AggregatedFullHttpResponse(HttpResponse message, ByteBuf content, HttpHeaders trailingHeaders) {
/* 497 */       super(message, content, trailingHeaders);
/*     */     }
/*     */ 
/*     */     
/*     */     public FullHttpResponse copy() {
/* 502 */       return replace(content().copy());
/*     */     }
/*     */ 
/*     */     
/*     */     public FullHttpResponse duplicate() {
/* 507 */       return replace(content().duplicate());
/*     */     }
/*     */ 
/*     */     
/*     */     public FullHttpResponse retainedDuplicate() {
/* 512 */       return replace(content().retainedDuplicate());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public FullHttpResponse replace(ByteBuf content) {
/* 518 */       DefaultFullHttpResponse dup = new DefaultFullHttpResponse(getProtocolVersion(), getStatus(), content, headers().copy(), trailingHeaders().copy());
/* 519 */       dup.setDecoderResult(decoderResult());
/* 520 */       return dup;
/*     */     }
/*     */ 
/*     */     
/*     */     public FullHttpResponse setStatus(HttpResponseStatus status) {
/* 525 */       ((HttpResponse)this.message).setStatus(status);
/* 526 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public HttpResponseStatus getStatus() {
/* 531 */       return ((HttpResponse)this.message).status();
/*     */     }
/*     */ 
/*     */     
/*     */     public HttpResponseStatus status() {
/* 536 */       return getStatus();
/*     */     }
/*     */ 
/*     */     
/*     */     public FullHttpResponse setProtocolVersion(HttpVersion version) {
/* 541 */       super.setProtocolVersion(version);
/* 542 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public FullHttpResponse retain(int increment) {
/* 547 */       super.retain(increment);
/* 548 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public FullHttpResponse retain() {
/* 553 */       super.retain();
/* 554 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public FullHttpResponse touch(Object hint) {
/* 559 */       super.touch(hint);
/* 560 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public FullHttpResponse touch() {
/* 565 */       super.touch();
/* 566 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 571 */       return HttpMessageUtil.appendFullResponse(new StringBuilder(256), this).toString();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http-4.1.93.Final.jar!\io\netty\handler\codec\http\HttpObjectAggregator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */