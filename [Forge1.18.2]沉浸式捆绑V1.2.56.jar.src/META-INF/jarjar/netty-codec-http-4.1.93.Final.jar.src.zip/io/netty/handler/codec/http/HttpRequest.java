package io.netty.handler.codec.http;

public interface HttpRequest extends HttpMessage {
  @Deprecated
  HttpMethod getMethod();
  
  HttpMethod method();
  
  HttpRequest setMethod(HttpMethod paramHttpMethod);
  
  @Deprecated
  String getUri();
  
  String uri();
  
  HttpRequest setUri(String paramString);
  
  HttpRequest setProtocolVersion(HttpVersion paramHttpVersion);
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http-4.1.93.Final.jar!\io\netty\handler\codec\http\HttpRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */