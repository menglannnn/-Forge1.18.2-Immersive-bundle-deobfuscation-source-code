/*     */ package io.netty.handler.codec.http.websocketx;
/*     */ 
/*     */ import io.netty.handler.codec.http.EmptyHttpHeaders;
/*     */ import io.netty.handler.codec.http.HttpHeaders;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import java.net.URI;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class WebSocketClientProtocolConfig
/*     */ {
/*     */   static final boolean DEFAULT_PERFORM_MASKING = true;
/*     */   static final boolean DEFAULT_ALLOW_MASK_MISMATCH = false;
/*     */   static final boolean DEFAULT_HANDLE_CLOSE_FRAMES = true;
/*     */   static final boolean DEFAULT_DROP_PONG_FRAMES = true;
/*     */   static final boolean DEFAULT_GENERATE_ORIGIN_HEADER = true;
/*     */   private final URI webSocketUri;
/*     */   private final String subprotocol;
/*     */   private final WebSocketVersion version;
/*     */   private final boolean allowExtensions;
/*     */   private final HttpHeaders customHeaders;
/*     */   private final int maxFramePayloadLength;
/*     */   private final boolean performMasking;
/*     */   private final boolean allowMaskMismatch;
/*     */   private final boolean handleCloseFrames;
/*     */   private final WebSocketCloseStatus sendCloseFrame;
/*     */   private final boolean dropPongFrames;
/*     */   private final long handshakeTimeoutMillis;
/*     */   private final long forceCloseTimeoutMillis;
/*     */   private final boolean absoluteUpgradeUrl;
/*     */   private final boolean generateOriginHeader;
/*     */   private final boolean withUTF8Validator;
/*     */   
/*     */   private WebSocketClientProtocolConfig(URI webSocketUri, String subprotocol, WebSocketVersion version, boolean allowExtensions, HttpHeaders customHeaders, int maxFramePayloadLength, boolean performMasking, boolean allowMaskMismatch, boolean handleCloseFrames, WebSocketCloseStatus sendCloseFrame, boolean dropPongFrames, long handshakeTimeoutMillis, long forceCloseTimeoutMillis, boolean absoluteUpgradeUrl, boolean generateOriginHeader, boolean withUTF8Validator) {
/*  74 */     this.webSocketUri = webSocketUri;
/*  75 */     this.subprotocol = subprotocol;
/*  76 */     this.version = version;
/*  77 */     this.allowExtensions = allowExtensions;
/*  78 */     this.customHeaders = customHeaders;
/*  79 */     this.maxFramePayloadLength = maxFramePayloadLength;
/*  80 */     this.performMasking = performMasking;
/*  81 */     this.allowMaskMismatch = allowMaskMismatch;
/*  82 */     this.forceCloseTimeoutMillis = forceCloseTimeoutMillis;
/*  83 */     this.handleCloseFrames = handleCloseFrames;
/*  84 */     this.sendCloseFrame = sendCloseFrame;
/*  85 */     this.dropPongFrames = dropPongFrames;
/*  86 */     this.handshakeTimeoutMillis = ObjectUtil.checkPositive(handshakeTimeoutMillis, "handshakeTimeoutMillis");
/*  87 */     this.absoluteUpgradeUrl = absoluteUpgradeUrl;
/*  88 */     this.generateOriginHeader = generateOriginHeader;
/*  89 */     this.withUTF8Validator = withUTF8Validator;
/*     */   }
/*     */   
/*     */   public URI webSocketUri() {
/*  93 */     return this.webSocketUri;
/*     */   }
/*     */   
/*     */   public String subprotocol() {
/*  97 */     return this.subprotocol;
/*     */   }
/*     */   
/*     */   public WebSocketVersion version() {
/* 101 */     return this.version;
/*     */   }
/*     */   
/*     */   public boolean allowExtensions() {
/* 105 */     return this.allowExtensions;
/*     */   }
/*     */   
/*     */   public HttpHeaders customHeaders() {
/* 109 */     return this.customHeaders;
/*     */   }
/*     */   
/*     */   public int maxFramePayloadLength() {
/* 113 */     return this.maxFramePayloadLength;
/*     */   }
/*     */   
/*     */   public boolean performMasking() {
/* 117 */     return this.performMasking;
/*     */   }
/*     */   
/*     */   public boolean allowMaskMismatch() {
/* 121 */     return this.allowMaskMismatch;
/*     */   }
/*     */   
/*     */   public boolean handleCloseFrames() {
/* 125 */     return this.handleCloseFrames;
/*     */   }
/*     */   
/*     */   public WebSocketCloseStatus sendCloseFrame() {
/* 129 */     return this.sendCloseFrame;
/*     */   }
/*     */   
/*     */   public boolean dropPongFrames() {
/* 133 */     return this.dropPongFrames;
/*     */   }
/*     */   
/*     */   public long handshakeTimeoutMillis() {
/* 137 */     return this.handshakeTimeoutMillis;
/*     */   }
/*     */   
/*     */   public long forceCloseTimeoutMillis() {
/* 141 */     return this.forceCloseTimeoutMillis;
/*     */   }
/*     */   
/*     */   public boolean absoluteUpgradeUrl() {
/* 145 */     return this.absoluteUpgradeUrl;
/*     */   }
/*     */   
/*     */   public boolean generateOriginHeader() {
/* 149 */     return this.generateOriginHeader;
/*     */   }
/*     */   
/*     */   public boolean withUTF8Validator() {
/* 153 */     return this.withUTF8Validator;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 158 */     return "WebSocketClientProtocolConfig {webSocketUri=" + this.webSocketUri + ", subprotocol=" + this.subprotocol + ", version=" + this.version + ", allowExtensions=" + this.allowExtensions + ", customHeaders=" + this.customHeaders + ", maxFramePayloadLength=" + this.maxFramePayloadLength + ", performMasking=" + this.performMasking + ", allowMaskMismatch=" + this.allowMaskMismatch + ", handleCloseFrames=" + this.handleCloseFrames + ", sendCloseFrame=" + this.sendCloseFrame + ", dropPongFrames=" + this.dropPongFrames + ", handshakeTimeoutMillis=" + this.handshakeTimeoutMillis + ", forceCloseTimeoutMillis=" + this.forceCloseTimeoutMillis + ", absoluteUpgradeUrl=" + this.absoluteUpgradeUrl + ", generateOriginHeader=" + this.generateOriginHeader + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Builder toBuilder() {
/* 178 */     return new Builder(this);
/*     */   }
/*     */   
/*     */   public static Builder newBuilder() {
/* 182 */     return new Builder(
/* 183 */         URI.create("https://localhost/"), null, WebSocketVersion.V13, false, (HttpHeaders)EmptyHttpHeaders.INSTANCE, 65536, true, false, true, WebSocketCloseStatus.NORMAL_CLOSURE, true, 10000L, -1L, false, true, true);
/*     */   }
/*     */ 
/*     */   
/*     */   public static final class Builder
/*     */   {
/*     */     private URI webSocketUri;
/*     */     
/*     */     private String subprotocol;
/*     */     
/*     */     private WebSocketVersion version;
/*     */     
/*     */     private boolean allowExtensions;
/*     */     
/*     */     private HttpHeaders customHeaders;
/*     */     
/*     */     private int maxFramePayloadLength;
/*     */     
/*     */     private boolean performMasking;
/*     */     
/*     */     private boolean allowMaskMismatch;
/*     */     
/*     */     private boolean handleCloseFrames;
/*     */     
/*     */     private WebSocketCloseStatus sendCloseFrame;
/*     */     
/*     */     private boolean dropPongFrames;
/*     */     
/*     */     private long handshakeTimeoutMillis;
/*     */     
/*     */     private long forceCloseTimeoutMillis;
/*     */     
/*     */     private boolean absoluteUpgradeUrl;
/*     */     private boolean generateOriginHeader;
/*     */     private boolean withUTF8Validator;
/*     */     
/*     */     private Builder(WebSocketClientProtocolConfig clientConfig) {
/* 220 */       this(((WebSocketClientProtocolConfig)ObjectUtil.checkNotNull(clientConfig, "clientConfig")).webSocketUri(), clientConfig
/* 221 */           .subprotocol(), clientConfig
/* 222 */           .version(), clientConfig
/* 223 */           .allowExtensions(), clientConfig
/* 224 */           .customHeaders(), clientConfig
/* 225 */           .maxFramePayloadLength(), clientConfig
/* 226 */           .performMasking(), clientConfig
/* 227 */           .allowMaskMismatch(), clientConfig
/* 228 */           .handleCloseFrames(), clientConfig
/* 229 */           .sendCloseFrame(), clientConfig
/* 230 */           .dropPongFrames(), clientConfig
/* 231 */           .handshakeTimeoutMillis(), clientConfig
/* 232 */           .forceCloseTimeoutMillis(), clientConfig
/* 233 */           .absoluteUpgradeUrl(), clientConfig
/* 234 */           .generateOriginHeader(), clientConfig
/* 235 */           .withUTF8Validator());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Builder(URI webSocketUri, String subprotocol, WebSocketVersion version, boolean allowExtensions, HttpHeaders customHeaders, int maxFramePayloadLength, boolean performMasking, boolean allowMaskMismatch, boolean handleCloseFrames, WebSocketCloseStatus sendCloseFrame, boolean dropPongFrames, long handshakeTimeoutMillis, long forceCloseTimeoutMillis, boolean absoluteUpgradeUrl, boolean generateOriginHeader, boolean withUTF8Validator) {
/* 254 */       this.webSocketUri = webSocketUri;
/* 255 */       this.subprotocol = subprotocol;
/* 256 */       this.version = version;
/* 257 */       this.allowExtensions = allowExtensions;
/* 258 */       this.customHeaders = customHeaders;
/* 259 */       this.maxFramePayloadLength = maxFramePayloadLength;
/* 260 */       this.performMasking = performMasking;
/* 261 */       this.allowMaskMismatch = allowMaskMismatch;
/* 262 */       this.handleCloseFrames = handleCloseFrames;
/* 263 */       this.sendCloseFrame = sendCloseFrame;
/* 264 */       this.dropPongFrames = dropPongFrames;
/* 265 */       this.handshakeTimeoutMillis = handshakeTimeoutMillis;
/* 266 */       this.forceCloseTimeoutMillis = forceCloseTimeoutMillis;
/* 267 */       this.absoluteUpgradeUrl = absoluteUpgradeUrl;
/* 268 */       this.generateOriginHeader = generateOriginHeader;
/* 269 */       this.withUTF8Validator = withUTF8Validator;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder webSocketUri(String webSocketUri) {
/* 277 */       return webSocketUri(URI.create(webSocketUri));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder webSocketUri(URI webSocketUri) {
/* 285 */       this.webSocketUri = webSocketUri;
/* 286 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder subprotocol(String subprotocol) {
/* 293 */       this.subprotocol = subprotocol;
/* 294 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder version(WebSocketVersion version) {
/* 301 */       this.version = version;
/* 302 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder allowExtensions(boolean allowExtensions) {
/* 309 */       this.allowExtensions = allowExtensions;
/* 310 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder customHeaders(HttpHeaders customHeaders) {
/* 317 */       this.customHeaders = customHeaders;
/* 318 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder maxFramePayloadLength(int maxFramePayloadLength) {
/* 325 */       this.maxFramePayloadLength = maxFramePayloadLength;
/* 326 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder performMasking(boolean performMasking) {
/* 335 */       this.performMasking = performMasking;
/* 336 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder allowMaskMismatch(boolean allowMaskMismatch) {
/* 343 */       this.allowMaskMismatch = allowMaskMismatch;
/* 344 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder handleCloseFrames(boolean handleCloseFrames) {
/* 351 */       this.handleCloseFrames = handleCloseFrames;
/* 352 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder sendCloseFrame(WebSocketCloseStatus sendCloseFrame) {
/* 359 */       this.sendCloseFrame = sendCloseFrame;
/* 360 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder dropPongFrames(boolean dropPongFrames) {
/* 367 */       this.dropPongFrames = dropPongFrames;
/* 368 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder handshakeTimeoutMillis(long handshakeTimeoutMillis) {
/* 376 */       this.handshakeTimeoutMillis = handshakeTimeoutMillis;
/* 377 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder forceCloseTimeoutMillis(long forceCloseTimeoutMillis) {
/* 384 */       this.forceCloseTimeoutMillis = forceCloseTimeoutMillis;
/* 385 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder absoluteUpgradeUrl(boolean absoluteUpgradeUrl) {
/* 392 */       this.absoluteUpgradeUrl = absoluteUpgradeUrl;
/* 393 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder generateOriginHeader(boolean generateOriginHeader) {
/* 402 */       this.generateOriginHeader = generateOriginHeader;
/* 403 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder withUTF8Validator(boolean withUTF8Validator) {
/* 410 */       this.withUTF8Validator = withUTF8Validator;
/* 411 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public WebSocketClientProtocolConfig build() {
/* 418 */       return new WebSocketClientProtocolConfig(this.webSocketUri, this.subprotocol, this.version, this.allowExtensions, this.customHeaders, this.maxFramePayloadLength, this.performMasking, this.allowMaskMismatch, this.handleCloseFrames, this.sendCloseFrame, this.dropPongFrames, this.handshakeTimeoutMillis, this.forceCloseTimeoutMillis, this.absoluteUpgradeUrl, this.generateOriginHeader, this.withUTF8Validator);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http-4.1.93.Final.jar!\io\netty\handler\codec\http\websocketx\WebSocketClientProtocolConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */