/*     */ package io.netty.handler.codec.http;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.channel.ChannelHandler;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.channel.embedded.EmbeddedChannel;
/*     */ import io.netty.handler.codec.MessageToByteEncoder;
/*     */ import io.netty.handler.codec.compression.Brotli;
/*     */ import io.netty.handler.codec.compression.BrotliEncoder;
/*     */ import io.netty.handler.codec.compression.BrotliOptions;
/*     */ import io.netty.handler.codec.compression.CompressionOptions;
/*     */ import io.netty.handler.codec.compression.DeflateOptions;
/*     */ import io.netty.handler.codec.compression.GzipOptions;
/*     */ import io.netty.handler.codec.compression.StandardCompressionOptions;
/*     */ import io.netty.handler.codec.compression.ZlibCodecFactory;
/*     */ import io.netty.handler.codec.compression.ZlibWrapper;
/*     */ import io.netty.handler.codec.compression.Zstd;
/*     */ import io.netty.handler.codec.compression.ZstdEncoder;
/*     */ import io.netty.handler.codec.compression.ZstdOptions;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpContentCompressor
/*     */   extends HttpContentEncoder
/*     */ {
/*     */   private final boolean supportsCompressionOptions;
/*     */   private final BrotliOptions brotliOptions;
/*     */   private final GzipOptions gzipOptions;
/*     */   private final DeflateOptions deflateOptions;
/*     */   private final ZstdOptions zstdOptions;
/*     */   private final int compressionLevel;
/*     */   private final int windowBits;
/*     */   private final int memLevel;
/*     */   private final int contentSizeThreshold;
/*     */   private ChannelHandlerContext ctx;
/*     */   private final Map<String, CompressionEncoderFactory> factories;
/*     */   
/*     */   public HttpContentCompressor() {
/*  67 */     this(6);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public HttpContentCompressor(int compressionLevel) {
/*  81 */     this(compressionLevel, 15, 8, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public HttpContentCompressor(int compressionLevel, int windowBits, int memLevel) {
/* 105 */     this(compressionLevel, windowBits, memLevel, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public HttpContentCompressor(int compressionLevel, int windowBits, int memLevel, int contentSizeThreshold) {
/* 133 */     this.compressionLevel = ObjectUtil.checkInRange(compressionLevel, 0, 9, "compressionLevel");
/* 134 */     this.windowBits = ObjectUtil.checkInRange(windowBits, 9, 15, "windowBits");
/* 135 */     this.memLevel = ObjectUtil.checkInRange(memLevel, 1, 9, "memLevel");
/* 136 */     this.contentSizeThreshold = ObjectUtil.checkPositiveOrZero(contentSizeThreshold, "contentSizeThreshold");
/* 137 */     this.brotliOptions = null;
/* 138 */     this.gzipOptions = null;
/* 139 */     this.deflateOptions = null;
/* 140 */     this.zstdOptions = null;
/* 141 */     this.factories = null;
/* 142 */     this.supportsCompressionOptions = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpContentCompressor(CompressionOptions... compressionOptions) {
/* 153 */     this(0, compressionOptions);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpContentCompressor(int contentSizeThreshold, CompressionOptions... compressionOptions) {
/* 168 */     this.contentSizeThreshold = ObjectUtil.checkPositiveOrZero(contentSizeThreshold, "contentSizeThreshold");
/* 169 */     BrotliOptions brotliOptions = null;
/* 170 */     GzipOptions gzipOptions = null;
/* 171 */     DeflateOptions deflateOptions = null;
/* 172 */     ZstdOptions zstdOptions = null;
/* 173 */     if (compressionOptions == null || compressionOptions.length == 0) {
/* 174 */       brotliOptions = Brotli.isAvailable() ? StandardCompressionOptions.brotli() : null;
/* 175 */       gzipOptions = StandardCompressionOptions.gzip();
/* 176 */       deflateOptions = StandardCompressionOptions.deflate();
/* 177 */       zstdOptions = Zstd.isAvailable() ? StandardCompressionOptions.zstd() : null;
/*     */     } else {
/* 179 */       ObjectUtil.deepCheckNotNull("compressionOptions", (Object[])compressionOptions);
/* 180 */       for (CompressionOptions compressionOption : compressionOptions) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 187 */         if (Brotli.isAvailable() && compressionOption instanceof BrotliOptions) {
/* 188 */           brotliOptions = (BrotliOptions)compressionOption;
/* 189 */         } else if (compressionOption instanceof GzipOptions) {
/* 190 */           gzipOptions = (GzipOptions)compressionOption;
/* 191 */         } else if (compressionOption instanceof DeflateOptions) {
/* 192 */           deflateOptions = (DeflateOptions)compressionOption;
/* 193 */         } else if (compressionOption instanceof ZstdOptions) {
/* 194 */           zstdOptions = (ZstdOptions)compressionOption;
/*     */         } else {
/* 196 */           throw new IllegalArgumentException("Unsupported " + CompressionOptions.class.getSimpleName() + ": " + compressionOption);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 202 */     this.gzipOptions = gzipOptions;
/* 203 */     this.deflateOptions = deflateOptions;
/* 204 */     this.brotliOptions = brotliOptions;
/* 205 */     this.zstdOptions = zstdOptions;
/*     */     
/* 207 */     this.factories = new HashMap<String, CompressionEncoderFactory>();
/*     */     
/* 209 */     if (this.gzipOptions != null) {
/* 210 */       this.factories.put("gzip", new GzipEncoderFactory());
/*     */     }
/* 212 */     if (this.deflateOptions != null) {
/* 213 */       this.factories.put("deflate", new DeflateEncoderFactory());
/*     */     }
/* 215 */     if (Brotli.isAvailable() && this.brotliOptions != null) {
/* 216 */       this.factories.put("br", new BrEncoderFactory());
/*     */     }
/* 218 */     if (this.zstdOptions != null) {
/* 219 */       this.factories.put("zstd", new ZstdEncoderFactory());
/*     */     }
/*     */     
/* 222 */     this.compressionLevel = -1;
/* 223 */     this.windowBits = -1;
/* 224 */     this.memLevel = -1;
/* 225 */     this.supportsCompressionOptions = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void handlerAdded(ChannelHandlerContext ctx) throws Exception {
/* 230 */     this.ctx = ctx;
/*     */   }
/*     */   
/*     */   protected HttpContentEncoder.Result beginEncode(HttpResponse httpResponse, String acceptEncoding) throws Exception {
/*     */     String targetContentEncoding;
/* 235 */     if (this.contentSizeThreshold > 0 && 
/* 236 */       httpResponse instanceof HttpContent && ((HttpContent)httpResponse)
/* 237 */       .content().readableBytes() < this.contentSizeThreshold) {
/* 238 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 242 */     String contentEncoding = httpResponse.headers().get((CharSequence)HttpHeaderNames.CONTENT_ENCODING);
/* 243 */     if (contentEncoding != null)
/*     */     {
/*     */       
/* 246 */       return null;
/*     */     }
/*     */     
/* 249 */     if (this.supportsCompressionOptions) {
/* 250 */       String str = determineEncoding(acceptEncoding);
/* 251 */       if (str == null) {
/* 252 */         return null;
/*     */       }
/*     */       
/* 255 */       CompressionEncoderFactory encoderFactory = this.factories.get(str);
/*     */       
/* 257 */       if (encoderFactory == null) {
/* 258 */         throw new Error();
/*     */       }
/*     */       
/* 261 */       return new HttpContentEncoder.Result(str, new EmbeddedChannel(this.ctx
/* 262 */             .channel().id(), this.ctx.channel().metadata().hasDisconnect(), this.ctx
/* 263 */             .channel().config(), new ChannelHandler[] { (ChannelHandler)encoderFactory.createEncoder() }));
/*     */     } 
/* 265 */     ZlibWrapper wrapper = determineWrapper(acceptEncoding);
/* 266 */     if (wrapper == null) {
/* 267 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 271 */     switch (wrapper) {
/*     */       case GZIP:
/* 273 */         targetContentEncoding = "gzip";
/*     */         break;
/*     */       case ZLIB:
/* 276 */         targetContentEncoding = "deflate";
/*     */         break;
/*     */       default:
/* 279 */         throw new Error();
/*     */     } 
/*     */     
/* 282 */     return new HttpContentEncoder.Result(targetContentEncoding, new EmbeddedChannel(this.ctx
/*     */           
/* 284 */           .channel().id(), this.ctx.channel().metadata().hasDisconnect(), this.ctx
/* 285 */           .channel().config(), new ChannelHandler[] { (ChannelHandler)ZlibCodecFactory.newZlibEncoder(wrapper, this.compressionLevel, this.windowBits, this.memLevel) }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String determineEncoding(String acceptEncoding) {
/* 292 */     float starQ = -1.0F;
/* 293 */     float brQ = -1.0F;
/* 294 */     float zstdQ = -1.0F;
/* 295 */     float gzipQ = -1.0F;
/* 296 */     float deflateQ = -1.0F;
/* 297 */     for (String encoding : acceptEncoding.split(",")) {
/* 298 */       float q = 1.0F;
/* 299 */       int equalsPos = encoding.indexOf('=');
/* 300 */       if (equalsPos != -1) {
/*     */         try {
/* 302 */           q = Float.parseFloat(encoding.substring(equalsPos + 1));
/* 303 */         } catch (NumberFormatException e) {
/*     */           
/* 305 */           q = 0.0F;
/*     */         } 
/*     */       }
/* 308 */       if (encoding.contains("*")) {
/* 309 */         starQ = q;
/* 310 */       } else if (encoding.contains("br") && q > brQ) {
/* 311 */         brQ = q;
/* 312 */       } else if (encoding.contains("zstd") && q > zstdQ) {
/* 313 */         zstdQ = q;
/* 314 */       } else if (encoding.contains("gzip") && q > gzipQ) {
/* 315 */         gzipQ = q;
/* 316 */       } else if (encoding.contains("deflate") && q > deflateQ) {
/* 317 */         deflateQ = q;
/*     */       } 
/*     */     } 
/* 320 */     if (brQ > 0.0F || zstdQ > 0.0F || gzipQ > 0.0F || deflateQ > 0.0F) {
/* 321 */       if (brQ != -1.0F && brQ >= zstdQ && this.brotliOptions != null)
/* 322 */         return "br"; 
/* 323 */       if (zstdQ != -1.0F && zstdQ >= gzipQ && this.zstdOptions != null)
/* 324 */         return "zstd"; 
/* 325 */       if (gzipQ != -1.0F && gzipQ >= deflateQ && this.gzipOptions != null)
/* 326 */         return "gzip"; 
/* 327 */       if (deflateQ != -1.0F && this.deflateOptions != null) {
/* 328 */         return "deflate";
/*     */       }
/*     */     } 
/* 331 */     if (starQ > 0.0F) {
/* 332 */       if (brQ == -1.0F && this.brotliOptions != null) {
/* 333 */         return "br";
/*     */       }
/* 335 */       if (zstdQ == -1.0F && this.zstdOptions != null) {
/* 336 */         return "zstd";
/*     */       }
/* 338 */       if (gzipQ == -1.0F && this.gzipOptions != null) {
/* 339 */         return "gzip";
/*     */       }
/* 341 */       if (deflateQ == -1.0F && this.deflateOptions != null) {
/* 342 */         return "deflate";
/*     */       }
/*     */     } 
/* 345 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected ZlibWrapper determineWrapper(String acceptEncoding) {
/* 351 */     float starQ = -1.0F;
/* 352 */     float gzipQ = -1.0F;
/* 353 */     float deflateQ = -1.0F;
/* 354 */     for (String encoding : acceptEncoding.split(",")) {
/* 355 */       float q = 1.0F;
/* 356 */       int equalsPos = encoding.indexOf('=');
/* 357 */       if (equalsPos != -1) {
/*     */         try {
/* 359 */           q = Float.parseFloat(encoding.substring(equalsPos + 1));
/* 360 */         } catch (NumberFormatException e) {
/*     */           
/* 362 */           q = 0.0F;
/*     */         } 
/*     */       }
/* 365 */       if (encoding.contains("*")) {
/* 366 */         starQ = q;
/* 367 */       } else if (encoding.contains("gzip") && q > gzipQ) {
/* 368 */         gzipQ = q;
/* 369 */       } else if (encoding.contains("deflate") && q > deflateQ) {
/* 370 */         deflateQ = q;
/*     */       } 
/*     */     } 
/* 373 */     if (gzipQ > 0.0F || deflateQ > 0.0F) {
/* 374 */       if (gzipQ >= deflateQ) {
/* 375 */         return ZlibWrapper.GZIP;
/*     */       }
/* 377 */       return ZlibWrapper.ZLIB;
/*     */     } 
/*     */     
/* 380 */     if (starQ > 0.0F) {
/* 381 */       if (gzipQ == -1.0F) {
/* 382 */         return ZlibWrapper.GZIP;
/*     */       }
/* 384 */       if (deflateQ == -1.0F) {
/* 385 */         return ZlibWrapper.ZLIB;
/*     */       }
/*     */     } 
/* 388 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private final class GzipEncoderFactory
/*     */     implements CompressionEncoderFactory
/*     */   {
/*     */     private GzipEncoderFactory() {}
/*     */ 
/*     */     
/*     */     public MessageToByteEncoder<ByteBuf> createEncoder() {
/* 399 */       return (MessageToByteEncoder<ByteBuf>)ZlibCodecFactory.newZlibEncoder(ZlibWrapper.GZIP, HttpContentCompressor.this
/* 400 */           .gzipOptions.compressionLevel(), HttpContentCompressor.this
/* 401 */           .gzipOptions.windowBits(), HttpContentCompressor.this.gzipOptions.memLevel());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private final class DeflateEncoderFactory
/*     */     implements CompressionEncoderFactory
/*     */   {
/*     */     private DeflateEncoderFactory() {}
/*     */ 
/*     */     
/*     */     public MessageToByteEncoder<ByteBuf> createEncoder() {
/* 413 */       return (MessageToByteEncoder<ByteBuf>)ZlibCodecFactory.newZlibEncoder(ZlibWrapper.ZLIB, HttpContentCompressor.this
/* 414 */           .deflateOptions.compressionLevel(), HttpContentCompressor.this
/* 415 */           .deflateOptions.windowBits(), HttpContentCompressor.this.deflateOptions.memLevel());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private final class BrEncoderFactory
/*     */     implements CompressionEncoderFactory
/*     */   {
/*     */     private BrEncoderFactory() {}
/*     */ 
/*     */     
/*     */     public MessageToByteEncoder<ByteBuf> createEncoder() {
/* 427 */       return (MessageToByteEncoder<ByteBuf>)new BrotliEncoder(HttpContentCompressor.this.brotliOptions.parameters());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private final class ZstdEncoderFactory
/*     */     implements CompressionEncoderFactory
/*     */   {
/*     */     private ZstdEncoderFactory() {}
/*     */ 
/*     */     
/*     */     public MessageToByteEncoder<ByteBuf> createEncoder() {
/* 439 */       return (MessageToByteEncoder<ByteBuf>)new ZstdEncoder(HttpContentCompressor.this.zstdOptions.compressionLevel(), HttpContentCompressor.this
/* 440 */           .zstdOptions.blockSize(), HttpContentCompressor.this.zstdOptions.maxEncodeSize());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http-4.1.93.Final.jar!\io\netty\handler\codec\http\HttpContentCompressor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */