package io.netty.handler.codec.http.websocketx;

import io.netty.channel.ChannelInboundHandler;

public interface WebSocketFrameDecoder extends ChannelInboundHandler {}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http-4.1.93.Final.jar!\io\netty\handler\codec\http\websocketx\WebSocketFrameDecoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */