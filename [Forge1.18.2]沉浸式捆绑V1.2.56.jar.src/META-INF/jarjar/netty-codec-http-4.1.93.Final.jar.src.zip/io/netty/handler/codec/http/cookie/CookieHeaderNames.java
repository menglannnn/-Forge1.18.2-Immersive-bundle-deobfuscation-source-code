/*    */ package io.netty.handler.codec.http.cookie;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class CookieHeaderNames
/*    */ {
/*    */   public static final String PATH = "Path";
/*    */   public static final String EXPIRES = "Expires";
/*    */   public static final String MAX_AGE = "Max-Age";
/*    */   public static final String DOMAIN = "Domain";
/*    */   public static final String SECURE = "Secure";
/*    */   public static final String HTTPONLY = "HTTPOnly";
/*    */   public static final String SAMESITE = "SameSite";
/*    */   
/*    */   public enum SameSite
/*    */   {
/* 38 */     Lax,
/* 39 */     Strict,
/* 40 */     None;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     static SameSite of(String name) {
/* 49 */       if (name != null) {
/* 50 */         for (SameSite each : (SameSite[])SameSite.class.getEnumConstants()) {
/* 51 */           if (each.name().equalsIgnoreCase(name)) {
/* 52 */             return each;
/*    */           }
/*    */         } 
/*    */       }
/* 56 */       return null;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http-4.1.93.Final.jar!\io\netty\handler\codec\http\cookie\CookieHeaderNames.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */