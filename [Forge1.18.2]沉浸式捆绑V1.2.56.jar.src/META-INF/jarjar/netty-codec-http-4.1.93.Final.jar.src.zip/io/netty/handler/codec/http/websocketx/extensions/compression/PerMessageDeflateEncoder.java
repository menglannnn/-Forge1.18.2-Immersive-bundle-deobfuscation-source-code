/*    */ package io.netty.handler.codec.http.websocketx.extensions.compression;
/*    */ 
/*    */ import io.netty.channel.ChannelHandlerContext;
/*    */ import io.netty.handler.codec.http.websocketx.WebSocketFrame;
/*    */ import io.netty.handler.codec.http.websocketx.extensions.WebSocketExtensionFilter;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class PerMessageDeflateEncoder
/*    */   extends DeflateEncoder
/*    */ {
/*    */   private boolean compressing;
/*    */   
/*    */   PerMessageDeflateEncoder(int compressionLevel, int windowSize, boolean noContext) {
/* 43 */     super(compressionLevel, windowSize, noContext, WebSocketExtensionFilter.NEVER_SKIP);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   PerMessageDeflateEncoder(int compressionLevel, int windowSize, boolean noContext, WebSocketExtensionFilter extensionEncoderFilter) {
/* 56 */     super(compressionLevel, windowSize, noContext, extensionEncoderFilter);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean acceptOutboundMessage(Object msg) throws Exception {
/* 61 */     if (!super.acceptOutboundMessage(msg)) {
/* 62 */       return false;
/*    */     }
/*    */     
/* 65 */     WebSocketFrame wsFrame = (WebSocketFrame)msg;
/* 66 */     if (extensionEncoderFilter().mustSkip(wsFrame)) {
/* 67 */       if (this.compressing) {
/* 68 */         throw new IllegalStateException("Cannot skip per message deflate encoder, compression in progress");
/*    */       }
/* 70 */       return false;
/*    */     } 
/*    */     
/* 73 */     return (((wsFrame instanceof io.netty.handler.codec.http.websocketx.TextWebSocketFrame || wsFrame instanceof io.netty.handler.codec.http.websocketx.BinaryWebSocketFrame) && (wsFrame
/* 74 */       .rsv() & 0x4) == 0) || (wsFrame instanceof io.netty.handler.codec.http.websocketx.ContinuationWebSocketFrame && this.compressing));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected int rsv(WebSocketFrame msg) {
/* 80 */     return (msg instanceof io.netty.handler.codec.http.websocketx.TextWebSocketFrame || msg instanceof io.netty.handler.codec.http.websocketx.BinaryWebSocketFrame) ? (msg
/* 81 */       .rsv() | 0x4) : msg.rsv();
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean removeFrameTail(WebSocketFrame msg) {
/* 86 */     return msg.isFinalFragment();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void encode(ChannelHandlerContext ctx, WebSocketFrame msg, List<Object> out) throws Exception {
/* 92 */     super.encode(ctx, msg, out);
/*    */     
/* 94 */     if (msg.isFinalFragment()) {
/* 95 */       this.compressing = false;
/* 96 */     } else if (msg instanceof io.netty.handler.codec.http.websocketx.TextWebSocketFrame || msg instanceof io.netty.handler.codec.http.websocketx.BinaryWebSocketFrame) {
/* 97 */       this.compressing = true;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http-4.1.93.Final.jar!\io\netty\handler\codec\http\websocketx\extensions\compression\PerMessageDeflateEncoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */