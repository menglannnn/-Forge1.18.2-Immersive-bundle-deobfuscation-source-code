/*     */ package io.netty.handler.codec.http.cookie;
/*     */ 
/*     */ import io.netty.handler.codec.DateFormatter;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import java.util.Date;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ClientCookieDecoder
/*     */   extends CookieDecoder
/*     */ {
/*  39 */   public static final ClientCookieDecoder STRICT = new ClientCookieDecoder(true);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  44 */   public static final ClientCookieDecoder LAX = new ClientCookieDecoder(false);
/*     */   
/*     */   private ClientCookieDecoder(boolean strict) {
/*  47 */     super(strict);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cookie decode(String header) {
/*  56 */     int headerLen = ((String)ObjectUtil.checkNotNull(header, "header")).length();
/*     */     
/*  58 */     if (headerLen == 0) {
/*  59 */       return null;
/*     */     }
/*     */     
/*  62 */     CookieBuilder cookieBuilder = null;
/*     */     
/*  64 */     int i = 0;
/*     */ 
/*     */ 
/*     */     
/*  68 */     while (i != headerLen) {
/*     */       int nameEnd, valueBegin, valueEnd;
/*     */       
/*  71 */       char c = header.charAt(i);
/*  72 */       if (c == ',') {
/*     */         break;
/*     */       }
/*     */ 
/*     */       
/*  77 */       if (c == '\t' || c == '\n' || c == '\013' || c == '\f' || c == '\r' || c == ' ' || c == ';') {
/*     */         
/*  79 */         i++;
/*     */ 
/*     */         
/*     */         continue;
/*     */       } 
/*     */       
/*  85 */       int nameBegin = i;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       while (true) {
/*  91 */         char curChar = header.charAt(i);
/*  92 */         if (curChar == ';') {
/*     */           
/*  94 */           nameEnd = i;
/*  95 */           valueBegin = valueEnd = -1;
/*     */           break;
/*     */         } 
/*  98 */         if (curChar == '=') {
/*     */           
/* 100 */           nameEnd = i;
/* 101 */           i++;
/* 102 */           if (i == headerLen) {
/*     */             
/* 104 */             int k = 0, j = k;
/*     */             
/*     */             break;
/*     */           } 
/* 108 */           valueBegin = i;
/*     */           
/* 110 */           int semiPos = header.indexOf(';', i);
/* 111 */           valueEnd = i = (semiPos > 0) ? semiPos : headerLen;
/*     */           break;
/*     */         } 
/* 114 */         i++;
/*     */ 
/*     */         
/* 117 */         if (i == headerLen) {
/*     */           
/* 119 */           nameEnd = headerLen;
/* 120 */           valueBegin = valueEnd = -1;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/* 125 */       if (valueEnd > 0 && header.charAt(valueEnd - 1) == ',')
/*     */       {
/* 127 */         valueEnd--;
/*     */       }
/*     */       
/* 130 */       if (cookieBuilder == null) {
/*     */         
/* 132 */         DefaultCookie cookie = initCookie(header, nameBegin, nameEnd, valueBegin, valueEnd);
/*     */         
/* 134 */         if (cookie == null) {
/* 135 */           return null;
/*     */         }
/*     */         
/* 138 */         cookieBuilder = new CookieBuilder(cookie, header);
/*     */         continue;
/*     */       } 
/* 141 */       cookieBuilder.appendAttribute(nameBegin, nameEnd, valueBegin, valueEnd);
/*     */     } 
/*     */     
/* 144 */     return (cookieBuilder != null) ? cookieBuilder.cookie() : null;
/*     */   }
/*     */   
/*     */   private static class CookieBuilder
/*     */   {
/*     */     private final String header;
/*     */     private final DefaultCookie cookie;
/*     */     private String domain;
/*     */     private String path;
/* 153 */     private long maxAge = Long.MIN_VALUE;
/*     */     private int expiresStart;
/*     */     private int expiresEnd;
/*     */     private boolean secure;
/*     */     private boolean httpOnly;
/*     */     private CookieHeaderNames.SameSite sameSite;
/*     */     
/*     */     CookieBuilder(DefaultCookie cookie, String header) {
/* 161 */       this.cookie = cookie;
/* 162 */       this.header = header;
/*     */     }
/*     */ 
/*     */     
/*     */     private long mergeMaxAgeAndExpires() {
/* 167 */       if (this.maxAge != Long.MIN_VALUE)
/* 168 */         return this.maxAge; 
/* 169 */       if (isValueDefined(this.expiresStart, this.expiresEnd)) {
/* 170 */         Date expiresDate = DateFormatter.parseHttpDate(this.header, this.expiresStart, this.expiresEnd);
/* 171 */         if (expiresDate != null) {
/* 172 */           long maxAgeMillis = expiresDate.getTime() - System.currentTimeMillis();
/* 173 */           return maxAgeMillis / 1000L + ((maxAgeMillis % 1000L != 0L) ? 1L : 0L);
/*     */         } 
/*     */       } 
/* 176 */       return Long.MIN_VALUE;
/*     */     }
/*     */     
/*     */     Cookie cookie() {
/* 180 */       this.cookie.setDomain(this.domain);
/* 181 */       this.cookie.setPath(this.path);
/* 182 */       this.cookie.setMaxAge(mergeMaxAgeAndExpires());
/* 183 */       this.cookie.setSecure(this.secure);
/* 184 */       this.cookie.setHttpOnly(this.httpOnly);
/* 185 */       this.cookie.setSameSite(this.sameSite);
/* 186 */       return this.cookie;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void appendAttribute(int keyStart, int keyEnd, int valueStart, int valueEnd) {
/* 203 */       int length = keyEnd - keyStart;
/*     */       
/* 205 */       if (length == 4) {
/* 206 */         parse4(keyStart, valueStart, valueEnd);
/* 207 */       } else if (length == 6) {
/* 208 */         parse6(keyStart, valueStart, valueEnd);
/* 209 */       } else if (length == 7) {
/* 210 */         parse7(keyStart, valueStart, valueEnd);
/* 211 */       } else if (length == 8) {
/* 212 */         parse8(keyStart, valueStart, valueEnd);
/*     */       } 
/*     */     }
/*     */     
/*     */     private void parse4(int nameStart, int valueStart, int valueEnd) {
/* 217 */       if (this.header.regionMatches(true, nameStart, "Path", 0, 4)) {
/* 218 */         this.path = computeValue(valueStart, valueEnd);
/*     */       }
/*     */     }
/*     */     
/*     */     private void parse6(int nameStart, int valueStart, int valueEnd) {
/* 223 */       if (this.header.regionMatches(true, nameStart, "Domain", 0, 5)) {
/* 224 */         this.domain = computeValue(valueStart, valueEnd);
/* 225 */       } else if (this.header.regionMatches(true, nameStart, "Secure", 0, 5)) {
/* 226 */         this.secure = true;
/*     */       } 
/*     */     }
/*     */     
/*     */     private void setMaxAge(String value) {
/*     */       try {
/* 232 */         this.maxAge = Math.max(Long.parseLong(value), 0L);
/* 233 */       } catch (NumberFormatException numberFormatException) {}
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private void parse7(int nameStart, int valueStart, int valueEnd) {
/* 239 */       if (this.header.regionMatches(true, nameStart, "Expires", 0, 7)) {
/* 240 */         this.expiresStart = valueStart;
/* 241 */         this.expiresEnd = valueEnd;
/* 242 */       } else if (this.header.regionMatches(true, nameStart, "Max-Age", 0, 7)) {
/* 243 */         setMaxAge(computeValue(valueStart, valueEnd));
/*     */       } 
/*     */     }
/*     */     
/*     */     private void parse8(int nameStart, int valueStart, int valueEnd) {
/* 248 */       if (this.header.regionMatches(true, nameStart, "HTTPOnly", 0, 8)) {
/* 249 */         this.httpOnly = true;
/* 250 */       } else if (this.header.regionMatches(true, nameStart, "SameSite", 0, 8)) {
/* 251 */         this.sameSite = CookieHeaderNames.SameSite.of(computeValue(valueStart, valueEnd));
/*     */       } 
/*     */     }
/*     */     
/*     */     private static boolean isValueDefined(int valueStart, int valueEnd) {
/* 256 */       return (valueStart != -1 && valueStart != valueEnd);
/*     */     }
/*     */     
/*     */     private String computeValue(int valueStart, int valueEnd) {
/* 260 */       return isValueDefined(valueStart, valueEnd) ? this.header.substring(valueStart, valueEnd) : null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http-4.1.93.Final.jar!\io\netty\handler\codec\http\cookie\ClientCookieDecoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */