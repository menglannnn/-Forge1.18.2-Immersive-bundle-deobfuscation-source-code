/*     */ package io.netty.handler.codec.http;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.buffer.ByteBufHolder;
/*     */ import io.netty.buffer.Unpooled;
/*     */ import io.netty.handler.codec.DefaultHeaders;
/*     */ import io.netty.util.ReferenceCounted;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import io.netty.util.internal.StringUtil;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultLastHttpContent
/*     */   extends DefaultHttpContent
/*     */   implements LastHttpContent
/*     */ {
/*     */   private final HttpHeaders trailingHeaders;
/*     */   private final boolean validateHeaders;
/*     */   
/*     */   public DefaultLastHttpContent() {
/*  35 */     this(Unpooled.buffer(0));
/*     */   }
/*     */   
/*     */   public DefaultLastHttpContent(ByteBuf content) {
/*  39 */     this(content, true);
/*     */   }
/*     */   
/*     */   public DefaultLastHttpContent(ByteBuf content, boolean validateHeaders) {
/*  43 */     super(content);
/*  44 */     this.trailingHeaders = new TrailingHttpHeaders(validateHeaders);
/*  45 */     this.validateHeaders = validateHeaders;
/*     */   }
/*     */   
/*     */   public DefaultLastHttpContent(ByteBuf content, HttpHeaders trailingHeaders) {
/*  49 */     super(content);
/*  50 */     this.trailingHeaders = (HttpHeaders)ObjectUtil.checkNotNull(trailingHeaders, "trailingHeaders");
/*  51 */     this.validateHeaders = false;
/*     */   }
/*     */ 
/*     */   
/*     */   public LastHttpContent copy() {
/*  56 */     return replace(content().copy());
/*     */   }
/*     */ 
/*     */   
/*     */   public LastHttpContent duplicate() {
/*  61 */     return replace(content().duplicate());
/*     */   }
/*     */ 
/*     */   
/*     */   public LastHttpContent retainedDuplicate() {
/*  66 */     return replace(content().retainedDuplicate());
/*     */   }
/*     */ 
/*     */   
/*     */   public LastHttpContent replace(ByteBuf content) {
/*  71 */     DefaultLastHttpContent dup = new DefaultLastHttpContent(content, this.validateHeaders);
/*  72 */     dup.trailingHeaders().set(trailingHeaders());
/*  73 */     return dup;
/*     */   }
/*     */ 
/*     */   
/*     */   public LastHttpContent retain(int increment) {
/*  78 */     super.retain(increment);
/*  79 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public LastHttpContent retain() {
/*  84 */     super.retain();
/*  85 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public LastHttpContent touch() {
/*  90 */     super.touch();
/*  91 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public LastHttpContent touch(Object hint) {
/*  96 */     super.touch(hint);
/*  97 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpHeaders trailingHeaders() {
/* 102 */     return this.trailingHeaders;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 107 */     StringBuilder buf = new StringBuilder(super.toString());
/* 108 */     buf.append(StringUtil.NEWLINE);
/* 109 */     appendHeaders(buf);
/*     */ 
/*     */     
/* 112 */     buf.setLength(buf.length() - StringUtil.NEWLINE.length());
/* 113 */     return buf.toString();
/*     */   }
/*     */   
/*     */   private void appendHeaders(StringBuilder buf) {
/* 117 */     for (Map.Entry<String, String> e : (Iterable<Map.Entry<String, String>>)trailingHeaders()) {
/* 118 */       buf.append(e.getKey());
/* 119 */       buf.append(": ");
/* 120 */       buf.append(e.getValue());
/* 121 */       buf.append(StringUtil.NEWLINE);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static final class TrailingHttpHeaders extends DefaultHttpHeaders {
/* 126 */     private static final DefaultHeaders.NameValidator<CharSequence> TrailerNameValidator = new DefaultHeaders.NameValidator<CharSequence>()
/*     */       {
/*     */         public void validateName(CharSequence name) {
/* 129 */           DefaultHttpHeaders.HttpNameValidator.validateName(name);
/* 130 */           if (HttpHeaderNames.CONTENT_LENGTH.contentEqualsIgnoreCase(name) || HttpHeaderNames.TRANSFER_ENCODING
/* 131 */             .contentEqualsIgnoreCase(name) || HttpHeaderNames.TRAILER
/* 132 */             .contentEqualsIgnoreCase(name)) {
/* 133 */             throw new IllegalArgumentException("prohibited trailing header: " + name);
/*     */           }
/*     */         }
/*     */       };
/*     */ 
/*     */     
/*     */     TrailingHttpHeaders(boolean validate) {
/* 140 */       super(validate, validate ? TrailerNameValidator : DefaultHeaders.NameValidator.NOT_NULL);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http-4.1.93.Final.jar!\io\netty\handler\codec\http\DefaultLastHttpContent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */