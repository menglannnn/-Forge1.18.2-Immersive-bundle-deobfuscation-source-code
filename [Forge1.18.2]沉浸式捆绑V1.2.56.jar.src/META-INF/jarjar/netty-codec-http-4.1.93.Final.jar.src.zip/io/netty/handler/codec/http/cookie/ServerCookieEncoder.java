/*     */ package io.netty.handler.codec.http.cookie;
/*     */ 
/*     */ import io.netty.handler.codec.DateFormatter;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ServerCookieEncoder
/*     */   extends CookieEncoder
/*     */ {
/*  61 */   public static final ServerCookieEncoder STRICT = new ServerCookieEncoder(true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  67 */   public static final ServerCookieEncoder LAX = new ServerCookieEncoder(false);
/*     */   
/*     */   private ServerCookieEncoder(boolean strict) {
/*  70 */     super(strict);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String encode(String name, String value) {
/*  81 */     return encode(new DefaultCookie(name, value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String encode(Cookie cookie) {
/*  91 */     String name = ((Cookie)ObjectUtil.checkNotNull(cookie, "cookie")).name();
/*  92 */     String value = (cookie.value() != null) ? cookie.value() : "";
/*     */     
/*  94 */     validateCookie(name, value);
/*     */     
/*  96 */     StringBuilder buf = CookieUtil.stringBuilder();
/*     */     
/*  98 */     if (cookie.wrap()) {
/*  99 */       CookieUtil.addQuoted(buf, name, value);
/*     */     } else {
/* 101 */       CookieUtil.add(buf, name, value);
/*     */     } 
/*     */     
/* 104 */     if (cookie.maxAge() != Long.MIN_VALUE) {
/* 105 */       CookieUtil.add(buf, "Max-Age", cookie.maxAge());
/* 106 */       Date expires = new Date(cookie.maxAge() * 1000L + System.currentTimeMillis());
/* 107 */       buf.append("Expires");
/* 108 */       buf.append('=');
/* 109 */       DateFormatter.append(expires, buf);
/* 110 */       buf.append(';');
/* 111 */       buf.append(' ');
/*     */     } 
/*     */     
/* 114 */     if (cookie.path() != null) {
/* 115 */       CookieUtil.add(buf, "Path", cookie.path());
/*     */     }
/*     */     
/* 118 */     if (cookie.domain() != null) {
/* 119 */       CookieUtil.add(buf, "Domain", cookie.domain());
/*     */     }
/* 121 */     if (cookie.isSecure()) {
/* 122 */       CookieUtil.add(buf, "Secure");
/*     */     }
/* 124 */     if (cookie.isHttpOnly()) {
/* 125 */       CookieUtil.add(buf, "HTTPOnly");
/*     */     }
/* 127 */     if (cookie instanceof DefaultCookie) {
/* 128 */       DefaultCookie c = (DefaultCookie)cookie;
/* 129 */       if (c.sameSite() != null) {
/* 130 */         CookieUtil.add(buf, "SameSite", c.sameSite().name());
/*     */       }
/*     */     } 
/*     */     
/* 134 */     return CookieUtil.stripTrailingSeparator(buf);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static List<String> dedup(List<String> encoded, Map<String, Integer> nameToLastIndex) {
/* 144 */     boolean[] isLastInstance = new boolean[encoded.size()];
/* 145 */     for (Iterator<Integer> iterator = nameToLastIndex.values().iterator(); iterator.hasNext(); ) { int idx = ((Integer)iterator.next()).intValue();
/* 146 */       isLastInstance[idx] = true; }
/*     */     
/* 148 */     List<String> dedupd = new ArrayList<String>(nameToLastIndex.size());
/* 149 */     for (int i = 0, n = encoded.size(); i < n; i++) {
/* 150 */       if (isLastInstance[i]) {
/* 151 */         dedupd.add(encoded.get(i));
/*     */       }
/*     */     } 
/* 154 */     return dedupd;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> encode(Cookie... cookies) {
/*     */     int j;
/* 164 */     if (((Cookie[])ObjectUtil.checkNotNull(cookies, "cookies")).length == 0) {
/* 165 */       return Collections.emptyList();
/*     */     }
/*     */     
/* 168 */     List<String> encoded = new ArrayList<String>(cookies.length);
/* 169 */     Map<String, Integer> nameToIndex = (this.strict && cookies.length > 1) ? new HashMap<String, Integer>() : null;
/* 170 */     boolean hasDupdName = false;
/* 171 */     for (int i = 0; i < cookies.length; i++) {
/* 172 */       Cookie c = cookies[i];
/* 173 */       encoded.add(encode(c));
/* 174 */       if (nameToIndex != null) {
/* 175 */         j = hasDupdName | ((nameToIndex.put(c.name(), Integer.valueOf(i)) != null) ? 1 : 0);
/*     */       }
/*     */     } 
/* 178 */     return (j != 0) ? dedup(encoded, nameToIndex) : encoded;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> encode(Collection<? extends Cookie> cookies) {
/*     */     int j;
/* 188 */     if (((Collection)ObjectUtil.checkNotNull(cookies, "cookies")).isEmpty()) {
/* 189 */       return Collections.emptyList();
/*     */     }
/*     */     
/* 192 */     List<String> encoded = new ArrayList<String>(cookies.size());
/* 193 */     Map<String, Integer> nameToIndex = (this.strict && cookies.size() > 1) ? new HashMap<String, Integer>() : null;
/* 194 */     int i = 0;
/* 195 */     boolean hasDupdName = false;
/* 196 */     for (Cookie c : cookies) {
/* 197 */       encoded.add(encode(c));
/* 198 */       if (nameToIndex != null) {
/* 199 */         j = hasDupdName | ((nameToIndex.put(c.name(), Integer.valueOf(i++)) != null) ? 1 : 0);
/*     */       }
/*     */     } 
/* 202 */     return (j != 0) ? dedup(encoded, nameToIndex) : encoded;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> encode(Iterable<? extends Cookie> cookies) {
/*     */     int j;
/* 212 */     Iterator<? extends Cookie> cookiesIt = ((Iterable<? extends Cookie>)ObjectUtil.checkNotNull(cookies, "cookies")).iterator();
/* 213 */     if (!cookiesIt.hasNext()) {
/* 214 */       return Collections.emptyList();
/*     */     }
/*     */     
/* 217 */     List<String> encoded = new ArrayList<String>();
/* 218 */     Cookie firstCookie = cookiesIt.next();
/* 219 */     Map<String, Integer> nameToIndex = (this.strict && cookiesIt.hasNext()) ? new HashMap<String, Integer>() : null;
/* 220 */     int i = 0;
/* 221 */     encoded.add(encode(firstCookie));
/* 222 */     boolean hasDupdName = (nameToIndex != null && nameToIndex.put(firstCookie.name(), Integer.valueOf(i++)) != null);
/* 223 */     while (cookiesIt.hasNext()) {
/* 224 */       Cookie c = cookiesIt.next();
/* 225 */       encoded.add(encode(c));
/* 226 */       if (nameToIndex != null) {
/* 227 */         j = hasDupdName | ((nameToIndex.put(c.name(), Integer.valueOf(i++)) != null) ? 1 : 0);
/*     */       }
/*     */     } 
/* 230 */     return (j != 0) ? dedup(encoded, nameToIndex) : encoded;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http-4.1.93.Final.jar!\io\netty\handler\codec\http\cookie\ServerCookieEncoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */