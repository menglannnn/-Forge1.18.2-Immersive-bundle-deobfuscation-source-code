/*     */ package io.netty.handler.codec.http;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.channel.embedded.EmbeddedChannel;
/*     */ import io.netty.handler.codec.CodecException;
/*     */ import io.netty.handler.codec.DecoderResult;
/*     */ import io.netty.handler.codec.MessageToMessageDecoder;
/*     */ import io.netty.util.ReferenceCountUtil;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class HttpContentDecoder
/*     */   extends MessageToMessageDecoder<HttpObject>
/*     */ {
/*  49 */   static final String IDENTITY = HttpHeaderValues.IDENTITY.toString();
/*     */   
/*     */   protected ChannelHandlerContext ctx;
/*     */   
/*     */   private EmbeddedChannel decoder;
/*     */   private boolean continueResponse;
/*     */   private boolean needRead = true;
/*     */   
/*     */   protected void decode(ChannelHandlerContext ctx, HttpObject msg, List<Object> out) throws Exception {
/*     */     try {
/*  59 */       if (msg instanceof HttpResponse && ((HttpResponse)msg).status().code() == 100) {
/*     */         
/*  61 */         if (!(msg instanceof LastHttpContent)) {
/*  62 */           this.continueResponse = true;
/*     */         }
/*     */         
/*  65 */         out.add(ReferenceCountUtil.retain(msg));
/*     */         
/*     */         return;
/*     */       } 
/*  69 */       if (this.continueResponse) {
/*  70 */         if (msg instanceof LastHttpContent) {
/*  71 */           this.continueResponse = false;
/*     */         }
/*     */         
/*  74 */         out.add(ReferenceCountUtil.retain(msg));
/*     */         
/*     */         return;
/*     */       } 
/*  78 */       if (msg instanceof HttpMessage) {
/*  79 */         cleanup();
/*  80 */         HttpMessage message = (HttpMessage)msg;
/*  81 */         HttpHeaders headers = message.headers();
/*     */ 
/*     */         
/*  84 */         String contentEncoding = headers.get((CharSequence)HttpHeaderNames.CONTENT_ENCODING);
/*  85 */         if (contentEncoding != null) {
/*  86 */           contentEncoding = contentEncoding.trim();
/*     */         } else {
/*  88 */           String transferEncoding = headers.get((CharSequence)HttpHeaderNames.TRANSFER_ENCODING);
/*  89 */           if (transferEncoding != null) {
/*  90 */             int idx = transferEncoding.indexOf(",");
/*  91 */             if (idx != -1) {
/*  92 */               contentEncoding = transferEncoding.substring(0, idx).trim();
/*     */             } else {
/*  94 */               contentEncoding = transferEncoding.trim();
/*     */             } 
/*     */           } else {
/*  97 */             contentEncoding = IDENTITY;
/*     */           } 
/*     */         } 
/* 100 */         this.decoder = newContentDecoder(contentEncoding);
/*     */         
/* 102 */         if (this.decoder == null) {
/* 103 */           if (message instanceof HttpContent) {
/* 104 */             ((HttpContent)message).retain();
/*     */           }
/* 106 */           out.add(message);
/*     */ 
/*     */ 
/*     */           
/*     */           return;
/*     */         } 
/*     */ 
/*     */         
/* 114 */         if (headers.contains((CharSequence)HttpHeaderNames.CONTENT_LENGTH)) {
/* 115 */           headers.remove((CharSequence)HttpHeaderNames.CONTENT_LENGTH);
/* 116 */           headers.set((CharSequence)HttpHeaderNames.TRANSFER_ENCODING, HttpHeaderValues.CHUNKED);
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 122 */         CharSequence targetContentEncoding = getTargetContentEncoding(contentEncoding);
/* 123 */         if (HttpHeaderValues.IDENTITY.contentEquals(targetContentEncoding)) {
/*     */ 
/*     */           
/* 126 */           headers.remove((CharSequence)HttpHeaderNames.CONTENT_ENCODING);
/*     */         } else {
/* 128 */           headers.set((CharSequence)HttpHeaderNames.CONTENT_ENCODING, targetContentEncoding);
/*     */         } 
/*     */         
/* 131 */         if (message instanceof HttpContent) {
/*     */           HttpMessage copy;
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 137 */           if (message instanceof HttpRequest) {
/* 138 */             HttpRequest r = (HttpRequest)message;
/* 139 */             copy = new DefaultHttpRequest(r.protocolVersion(), r.method(), r.uri());
/* 140 */           } else if (message instanceof HttpResponse) {
/* 141 */             HttpResponse r = (HttpResponse)message;
/* 142 */             copy = new DefaultHttpResponse(r.protocolVersion(), r.status());
/*     */           } else {
/* 144 */             throw new CodecException("Object of class " + message.getClass().getName() + " is not an HttpRequest or HttpResponse");
/*     */           } 
/*     */           
/* 147 */           copy.headers().set(message.headers());
/* 148 */           copy.setDecoderResult(message.decoderResult());
/* 149 */           out.add(copy);
/*     */         } else {
/* 151 */           out.add(message);
/*     */         } 
/*     */       } 
/*     */       
/* 155 */       if (msg instanceof HttpContent) {
/* 156 */         HttpContent c = (HttpContent)msg;
/* 157 */         if (this.decoder == null) {
/* 158 */           out.add(c.retain());
/*     */         } else {
/* 160 */           decodeContent(c, out);
/*     */         } 
/*     */       } 
/*     */     } finally {
/* 164 */       this.needRead = out.isEmpty();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void decodeContent(HttpContent c, List<Object> out) {
/* 169 */     ByteBuf content = c.content();
/*     */     
/* 171 */     decode(content, out);
/*     */     
/* 173 */     if (c instanceof LastHttpContent) {
/* 174 */       finishDecode(out);
/*     */       
/* 176 */       LastHttpContent last = (LastHttpContent)c;
/*     */ 
/*     */       
/* 179 */       HttpHeaders headers = last.trailingHeaders();
/* 180 */       if (headers.isEmpty()) {
/* 181 */         out.add(LastHttpContent.EMPTY_LAST_CONTENT);
/*     */       } else {
/* 183 */         out.add(new ComposedLastHttpContent(headers, DecoderResult.SUCCESS));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void channelReadComplete(ChannelHandlerContext ctx) throws Exception {
/* 190 */     boolean needRead = this.needRead;
/* 191 */     this.needRead = true;
/*     */     
/*     */     try {
/* 194 */       ctx.fireChannelReadComplete();
/*     */     } finally {
/* 196 */       if (needRead && !ctx.channel().config().isAutoRead()) {
/* 197 */         ctx.read();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getTargetContentEncoding(String contentEncoding) throws Exception {
/* 223 */     return IDENTITY;
/*     */   }
/*     */ 
/*     */   
/*     */   public void handlerRemoved(ChannelHandlerContext ctx) throws Exception {
/* 228 */     cleanupSafely(ctx);
/* 229 */     super.handlerRemoved(ctx);
/*     */   }
/*     */ 
/*     */   
/*     */   public void channelInactive(ChannelHandlerContext ctx) throws Exception {
/* 234 */     cleanupSafely(ctx);
/* 235 */     super.channelInactive(ctx);
/*     */   }
/*     */ 
/*     */   
/*     */   public void handlerAdded(ChannelHandlerContext ctx) throws Exception {
/* 240 */     this.ctx = ctx;
/* 241 */     super.handlerAdded(ctx);
/*     */   }
/*     */   
/*     */   private void cleanup() {
/* 245 */     if (this.decoder != null) {
/*     */       
/* 247 */       this.decoder.finishAndReleaseAll();
/* 248 */       this.decoder = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void cleanupSafely(ChannelHandlerContext ctx) {
/*     */     try {
/* 254 */       cleanup();
/* 255 */     } catch (Throwable cause) {
/*     */ 
/*     */       
/* 258 */       ctx.fireExceptionCaught(cause);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void decode(ByteBuf in, List<Object> out) {
/* 264 */     this.decoder.writeInbound(new Object[] { in.retain() });
/* 265 */     fetchDecoderOutput(out);
/*     */   }
/*     */   
/*     */   private void finishDecode(List<Object> out) {
/* 269 */     if (this.decoder.finish()) {
/* 270 */       fetchDecoderOutput(out);
/*     */     }
/* 272 */     this.decoder = null;
/*     */   }
/*     */   
/*     */   private void fetchDecoderOutput(List<Object> out) {
/*     */     while (true) {
/* 277 */       ByteBuf buf = (ByteBuf)this.decoder.readInbound();
/* 278 */       if (buf == null) {
/*     */         break;
/*     */       }
/* 281 */       if (!buf.isReadable()) {
/* 282 */         buf.release();
/*     */         continue;
/*     */       } 
/* 285 */       out.add(new DefaultHttpContent(buf));
/*     */     } 
/*     */   }
/*     */   
/*     */   protected abstract EmbeddedChannel newContentDecoder(String paramString) throws Exception;
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http-4.1.93.Final.jar!\io\netty\handler\codec\http\HttpContentDecoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */