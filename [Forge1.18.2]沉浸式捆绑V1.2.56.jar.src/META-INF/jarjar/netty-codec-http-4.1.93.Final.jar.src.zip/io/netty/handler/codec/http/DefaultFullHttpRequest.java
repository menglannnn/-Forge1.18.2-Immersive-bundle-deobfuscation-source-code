/*     */ package io.netty.handler.codec.http;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.buffer.ByteBufHolder;
/*     */ import io.netty.buffer.ByteBufUtil;
/*     */ import io.netty.buffer.Unpooled;
/*     */ import io.netty.util.IllegalReferenceCountException;
/*     */ import io.netty.util.ReferenceCounted;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultFullHttpRequest
/*     */   extends DefaultHttpRequest
/*     */   implements FullHttpRequest
/*     */ {
/*     */   private final ByteBuf content;
/*     */   private final HttpHeaders trailingHeader;
/*     */   private int hash;
/*     */   
/*     */   public DefaultFullHttpRequest(HttpVersion httpVersion, HttpMethod method, String uri) {
/*  37 */     this(httpVersion, method, uri, Unpooled.buffer(0));
/*     */   }
/*     */   
/*     */   public DefaultFullHttpRequest(HttpVersion httpVersion, HttpMethod method, String uri, ByteBuf content) {
/*  41 */     this(httpVersion, method, uri, content, true);
/*     */   }
/*     */   
/*     */   public DefaultFullHttpRequest(HttpVersion httpVersion, HttpMethod method, String uri, boolean validateHeaders) {
/*  45 */     this(httpVersion, method, uri, Unpooled.buffer(0), validateHeaders);
/*     */   }
/*     */ 
/*     */   
/*     */   public DefaultFullHttpRequest(HttpVersion httpVersion, HttpMethod method, String uri, ByteBuf content, boolean validateHeaders) {
/*  50 */     super(httpVersion, method, uri, validateHeaders);
/*  51 */     this.content = (ByteBuf)ObjectUtil.checkNotNull(content, "content");
/*  52 */     this.trailingHeader = new DefaultHttpHeaders(validateHeaders);
/*     */   }
/*     */ 
/*     */   
/*     */   public DefaultFullHttpRequest(HttpVersion httpVersion, HttpMethod method, String uri, ByteBuf content, HttpHeaders headers, HttpHeaders trailingHeader) {
/*  57 */     super(httpVersion, method, uri, headers);
/*  58 */     this.content = (ByteBuf)ObjectUtil.checkNotNull(content, "content");
/*  59 */     this.trailingHeader = (HttpHeaders)ObjectUtil.checkNotNull(trailingHeader, "trailingHeader");
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpHeaders trailingHeaders() {
/*  64 */     return this.trailingHeader;
/*     */   }
/*     */ 
/*     */   
/*     */   public ByteBuf content() {
/*  69 */     return this.content;
/*     */   }
/*     */ 
/*     */   
/*     */   public int refCnt() {
/*  74 */     return this.content.refCnt();
/*     */   }
/*     */ 
/*     */   
/*     */   public FullHttpRequest retain() {
/*  79 */     this.content.retain();
/*  80 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public FullHttpRequest retain(int increment) {
/*  85 */     this.content.retain(increment);
/*  86 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public FullHttpRequest touch() {
/*  91 */     this.content.touch();
/*  92 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public FullHttpRequest touch(Object hint) {
/*  97 */     this.content.touch(hint);
/*  98 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean release() {
/* 103 */     return this.content.release();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean release(int decrement) {
/* 108 */     return this.content.release(decrement);
/*     */   }
/*     */ 
/*     */   
/*     */   public FullHttpRequest setProtocolVersion(HttpVersion version) {
/* 113 */     super.setProtocolVersion(version);
/* 114 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public FullHttpRequest setMethod(HttpMethod method) {
/* 119 */     super.setMethod(method);
/* 120 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public FullHttpRequest setUri(String uri) {
/* 125 */     super.setUri(uri);
/* 126 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public FullHttpRequest copy() {
/* 131 */     return replace(content().copy());
/*     */   }
/*     */ 
/*     */   
/*     */   public FullHttpRequest duplicate() {
/* 136 */     return replace(content().duplicate());
/*     */   }
/*     */ 
/*     */   
/*     */   public FullHttpRequest retainedDuplicate() {
/* 141 */     return replace(content().retainedDuplicate());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public FullHttpRequest replace(ByteBuf content) {
/* 147 */     FullHttpRequest request = new DefaultFullHttpRequest(protocolVersion(), method(), uri(), content, headers().copy(), trailingHeaders().copy());
/* 148 */     request.setDecoderResult(decoderResult());
/* 149 */     return request;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 154 */     int hash = this.hash;
/* 155 */     if (hash == 0) {
/* 156 */       if (ByteBufUtil.isAccessible(content())) {
/*     */         try {
/* 158 */           hash = 31 + content().hashCode();
/* 159 */         } catch (IllegalReferenceCountException ignored) {
/*     */           
/* 161 */           hash = 31;
/*     */         } 
/*     */       } else {
/* 164 */         hash = 31;
/*     */       } 
/* 166 */       hash = 31 * hash + trailingHeaders().hashCode();
/* 167 */       hash = 31 * hash + super.hashCode();
/* 168 */       this.hash = hash;
/*     */     } 
/* 170 */     return hash;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 175 */     if (!(o instanceof DefaultFullHttpRequest)) {
/* 176 */       return false;
/*     */     }
/*     */     
/* 179 */     DefaultFullHttpRequest other = (DefaultFullHttpRequest)o;
/*     */     
/* 181 */     return (super.equals(other) && 
/* 182 */       content().equals(other.content()) && 
/* 183 */       trailingHeaders().equals(other.trailingHeaders()));
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 188 */     return HttpMessageUtil.appendFullRequest(new StringBuilder(256), this).toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http-4.1.93.Final.jar!\io\netty\handler\codec\http\DefaultFullHttpRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */