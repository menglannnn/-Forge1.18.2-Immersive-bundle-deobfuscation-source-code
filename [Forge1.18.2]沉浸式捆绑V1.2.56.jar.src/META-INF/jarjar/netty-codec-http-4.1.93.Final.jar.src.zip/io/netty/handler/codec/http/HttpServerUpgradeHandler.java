/*     */ package io.netty.handler.codec.http;
/*     */ 
/*     */ import io.netty.buffer.Unpooled;
/*     */ import io.netty.channel.ChannelFuture;
/*     */ import io.netty.channel.ChannelFutureListener;
/*     */ import io.netty.channel.ChannelHandler;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.util.AsciiString;
/*     */ import io.netty.util.ReferenceCountUtil;
/*     */ import io.netty.util.ReferenceCounted;
/*     */ import io.netty.util.concurrent.GenericFutureListener;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpServerUpgradeHandler
/*     */   extends HttpObjectAggregator
/*     */ {
/*     */   private final SourceCodec sourceCodec;
/*     */   private final UpgradeCodecFactory upgradeCodecFactory;
/*     */   private final boolean validateHeaders;
/*     */   private boolean handlingUpgrade;
/*     */   
/*     */   public static final class UpgradeEvent
/*     */     implements ReferenceCounted
/*     */   {
/*     */     private final CharSequence protocol;
/*     */     private final FullHttpRequest upgradeRequest;
/*     */     
/*     */     UpgradeEvent(CharSequence protocol, FullHttpRequest upgradeRequest) {
/* 107 */       this.protocol = protocol;
/* 108 */       this.upgradeRequest = upgradeRequest;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public CharSequence protocol() {
/* 115 */       return this.protocol;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public FullHttpRequest upgradeRequest() {
/* 122 */       return this.upgradeRequest;
/*     */     }
/*     */ 
/*     */     
/*     */     public int refCnt() {
/* 127 */       return this.upgradeRequest.refCnt();
/*     */     }
/*     */ 
/*     */     
/*     */     public UpgradeEvent retain() {
/* 132 */       this.upgradeRequest.retain();
/* 133 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public UpgradeEvent retain(int increment) {
/* 138 */       this.upgradeRequest.retain(increment);
/* 139 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public UpgradeEvent touch() {
/* 144 */       this.upgradeRequest.touch();
/* 145 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public UpgradeEvent touch(Object hint) {
/* 150 */       this.upgradeRequest.touch(hint);
/* 151 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean release() {
/* 156 */       return this.upgradeRequest.release();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean release(int decrement) {
/* 161 */       return this.upgradeRequest.release(decrement);
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 166 */       return "UpgradeEvent [protocol=" + this.protocol + ", upgradeRequest=" + this.upgradeRequest + ']';
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpServerUpgradeHandler(SourceCodec sourceCodec, UpgradeCodecFactory upgradeCodecFactory) {
/* 190 */     this(sourceCodec, upgradeCodecFactory, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpServerUpgradeHandler(SourceCodec sourceCodec, UpgradeCodecFactory upgradeCodecFactory, int maxContentLength) {
/* 203 */     this(sourceCodec, upgradeCodecFactory, maxContentLength, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpServerUpgradeHandler(SourceCodec sourceCodec, UpgradeCodecFactory upgradeCodecFactory, int maxContentLength, boolean validateHeaders) {
/* 217 */     super(maxContentLength);
/*     */     
/* 219 */     this.sourceCodec = (SourceCodec)ObjectUtil.checkNotNull(sourceCodec, "sourceCodec");
/* 220 */     this.upgradeCodecFactory = (UpgradeCodecFactory)ObjectUtil.checkNotNull(upgradeCodecFactory, "upgradeCodecFactory");
/* 221 */     this.validateHeaders = validateHeaders;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void decode(ChannelHandlerContext ctx, HttpObject msg, List<Object> out) throws Exception {
/*     */     FullHttpRequest fullRequest;
/* 228 */     if (!this.handlingUpgrade)
/*     */     {
/* 230 */       if (msg instanceof HttpRequest) {
/* 231 */         HttpRequest req = (HttpRequest)msg;
/* 232 */         if (req.headers().contains((CharSequence)HttpHeaderNames.UPGRADE) && 
/* 233 */           shouldHandleUpgradeRequest(req)) {
/* 234 */           this.handlingUpgrade = true;
/*     */         } else {
/* 236 */           ReferenceCountUtil.retain(msg);
/* 237 */           ctx.fireChannelRead(msg);
/*     */           return;
/*     */         } 
/*     */       } else {
/* 241 */         ReferenceCountUtil.retain(msg);
/* 242 */         ctx.fireChannelRead(msg);
/*     */         
/*     */         return;
/*     */       } 
/*     */     }
/*     */     
/* 248 */     if (msg instanceof FullHttpRequest) {
/* 249 */       fullRequest = (FullHttpRequest)msg;
/* 250 */       ReferenceCountUtil.retain(msg);
/* 251 */       out.add(msg);
/*     */     } else {
/*     */       
/* 254 */       super.decode(ctx, msg, out);
/* 255 */       if (out.isEmpty()) {
/*     */         return;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 261 */       assert out.size() == 1;
/* 262 */       this.handlingUpgrade = false;
/* 263 */       fullRequest = (FullHttpRequest)out.get(0);
/*     */     } 
/*     */     
/* 266 */     if (upgrade(ctx, fullRequest))
/*     */     {
/*     */ 
/*     */       
/* 270 */       out.clear();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean shouldHandleUpgradeRequest(HttpRequest req) {
/* 291 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean upgrade(ChannelHandlerContext ctx, FullHttpRequest request) {
/* 304 */     List<CharSequence> requestedProtocols = splitHeader(request.headers().get((CharSequence)HttpHeaderNames.UPGRADE));
/* 305 */     int numRequestedProtocols = requestedProtocols.size();
/* 306 */     UpgradeCodec upgradeCodec = null;
/* 307 */     CharSequence upgradeProtocol = null;
/* 308 */     for (int i = 0; i < numRequestedProtocols; i++) {
/* 309 */       CharSequence p = requestedProtocols.get(i);
/* 310 */       UpgradeCodec c = this.upgradeCodecFactory.newUpgradeCodec(p);
/* 311 */       if (c != null) {
/* 312 */         upgradeProtocol = p;
/* 313 */         upgradeCodec = c;
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/* 318 */     if (upgradeCodec == null)
/*     */     {
/* 320 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 324 */     List<String> connectionHeaderValues = request.headers().getAll((CharSequence)HttpHeaderNames.CONNECTION);
/*     */     
/* 326 */     if (connectionHeaderValues == null || connectionHeaderValues.isEmpty()) {
/* 327 */       return false;
/*     */     }
/*     */     
/* 330 */     StringBuilder concatenatedConnectionValue = new StringBuilder(connectionHeaderValues.size() * 10);
/* 331 */     for (CharSequence connectionHeaderValue : connectionHeaderValues) {
/* 332 */       concatenatedConnectionValue.append(connectionHeaderValue).append(',');
/*     */     }
/* 334 */     concatenatedConnectionValue.setLength(concatenatedConnectionValue.length() - 1);
/*     */ 
/*     */     
/* 337 */     Collection<CharSequence> requiredHeaders = upgradeCodec.requiredUpgradeHeaders();
/* 338 */     List<CharSequence> values = splitHeader(concatenatedConnectionValue);
/* 339 */     if (!AsciiString.containsContentEqualsIgnoreCase(values, (CharSequence)HttpHeaderNames.UPGRADE) || 
/* 340 */       !AsciiString.containsAllContentEqualsIgnoreCase(values, requiredHeaders)) {
/* 341 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 345 */     for (CharSequence requiredHeader : requiredHeaders) {
/* 346 */       if (!request.headers().contains(requiredHeader)) {
/* 347 */         return false;
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 353 */     FullHttpResponse upgradeResponse = createUpgradeResponse(upgradeProtocol);
/* 354 */     if (!upgradeCodec.prepareUpgradeResponse(ctx, request, upgradeResponse.headers())) {
/* 355 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 359 */     UpgradeEvent event = new UpgradeEvent(upgradeProtocol, request);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 366 */       ChannelFuture writeComplete = ctx.writeAndFlush(upgradeResponse);
/*     */       
/* 368 */       this.sourceCodec.upgradeFrom(ctx);
/* 369 */       upgradeCodec.upgradeTo(ctx, request);
/*     */ 
/*     */       
/* 372 */       ctx.pipeline().remove((ChannelHandler)this);
/*     */ 
/*     */ 
/*     */       
/* 376 */       ctx.fireUserEventTriggered(event.retain());
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 381 */       writeComplete.addListener((GenericFutureListener)ChannelFutureListener.CLOSE_ON_FAILURE);
/*     */     } finally {
/*     */       
/* 384 */       event.release();
/*     */     } 
/* 386 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private FullHttpResponse createUpgradeResponse(CharSequence upgradeProtocol) {
/* 393 */     DefaultFullHttpResponse res = new DefaultFullHttpResponse(HttpVersion.HTTP_1_1, HttpResponseStatus.SWITCHING_PROTOCOLS, Unpooled.EMPTY_BUFFER, this.validateHeaders);
/*     */     
/* 395 */     res.headers().add((CharSequence)HttpHeaderNames.CONNECTION, HttpHeaderValues.UPGRADE);
/* 396 */     res.headers().add((CharSequence)HttpHeaderNames.UPGRADE, upgradeProtocol);
/* 397 */     return res;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static List<CharSequence> splitHeader(CharSequence header) {
/* 405 */     StringBuilder builder = new StringBuilder(header.length());
/* 406 */     List<CharSequence> protocols = new ArrayList<CharSequence>(4);
/* 407 */     for (int i = 0; i < header.length(); i++) {
/* 408 */       char c = header.charAt(i);
/* 409 */       if (!Character.isWhitespace(c))
/*     */       {
/*     */ 
/*     */         
/* 413 */         if (c == ',') {
/*     */           
/* 415 */           protocols.add(builder.toString());
/* 416 */           builder.setLength(0);
/*     */         } else {
/* 418 */           builder.append(c);
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 423 */     if (builder.length() > 0) {
/* 424 */       protocols.add(builder.toString());
/*     */     }
/*     */     
/* 427 */     return protocols;
/*     */   }
/*     */   
/*     */   public static interface UpgradeCodecFactory {
/*     */     HttpServerUpgradeHandler.UpgradeCodec newUpgradeCodec(CharSequence param1CharSequence);
/*     */   }
/*     */   
/*     */   public static interface UpgradeCodec {
/*     */     Collection<CharSequence> requiredUpgradeHeaders();
/*     */     
/*     */     boolean prepareUpgradeResponse(ChannelHandlerContext param1ChannelHandlerContext, FullHttpRequest param1FullHttpRequest, HttpHeaders param1HttpHeaders);
/*     */     
/*     */     void upgradeTo(ChannelHandlerContext param1ChannelHandlerContext, FullHttpRequest param1FullHttpRequest);
/*     */   }
/*     */   
/*     */   public static interface SourceCodec {
/*     */     void upgradeFrom(ChannelHandlerContext param1ChannelHandlerContext);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http-4.1.93.Final.jar!\io\netty\handler\codec\http\HttpServerUpgradeHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */