/*     */ package io.netty.handler.codec.http;
/*     */ 
/*     */ import io.netty.util.AsciiString;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpRequestDecoder
/*     */   extends HttpObjectDecoder
/*     */ {
/*  80 */   private static final AsciiString Host = AsciiString.cached("Host");
/*  81 */   private static final AsciiString Connection = AsciiString.cached("Connection");
/*  82 */   private static final AsciiString ContentType = AsciiString.cached("Content-Type");
/*  83 */   private static final AsciiString ContentLength = AsciiString.cached("Content-Length");
/*     */ 
/*     */   
/*     */   private static final int GET_AS_INT = 5522759;
/*     */ 
/*     */   
/*     */   private static final int POST_AS_INT = 1414745936;
/*     */ 
/*     */   
/*     */   private static final long HTTP_1_1_AS_LONG = 3543824036068086856L;
/*     */ 
/*     */   
/*     */   private static final long HTTP_1_0_AS_LONG = 3471766442030158920L;
/*     */ 
/*     */   
/*     */   private static final int HOST_AS_INT = 1953722184;
/*     */ 
/*     */   
/*     */   private static final long CONNECTION_AS_LONG_0 = 7598807758576447299L;
/*     */ 
/*     */   
/*     */   private static final short CONNECTION_AS_SHORT_1 = 28271;
/*     */ 
/*     */   
/*     */   private static final long CONTENT_AS_LONG = 3275364211029339971L;
/*     */ 
/*     */   
/*     */   private static final int TYPE_AS_INT = 1701869908;
/*     */ 
/*     */   
/*     */   private static final long LENGTH_AS_LONG = 114849160783180L;
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpRequestDecoder() {}
/*     */ 
/*     */   
/*     */   public HttpRequestDecoder(int maxInitialLineLength, int maxHeaderSize, int maxChunkSize) {
/* 121 */     super(maxInitialLineLength, maxHeaderSize, maxChunkSize, true);
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpRequestDecoder(int maxInitialLineLength, int maxHeaderSize, int maxChunkSize, boolean validateHeaders) {
/* 126 */     super(maxInitialLineLength, maxHeaderSize, maxChunkSize, true, validateHeaders);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpRequestDecoder(int maxInitialLineLength, int maxHeaderSize, int maxChunkSize, boolean validateHeaders, int initialBufferSize) {
/* 132 */     super(maxInitialLineLength, maxHeaderSize, maxChunkSize, true, validateHeaders, initialBufferSize);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpRequestDecoder(int maxInitialLineLength, int maxHeaderSize, int maxChunkSize, boolean validateHeaders, int initialBufferSize, boolean allowDuplicateContentLengths) {
/* 139 */     super(maxInitialLineLength, maxHeaderSize, maxChunkSize, true, validateHeaders, initialBufferSize, allowDuplicateContentLengths);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpRequestDecoder(int maxInitialLineLength, int maxHeaderSize, int maxChunkSize, boolean validateHeaders, int initialBufferSize, boolean allowDuplicateContentLengths, boolean allowPartialChunks) {
/* 146 */     super(maxInitialLineLength, maxHeaderSize, maxChunkSize, true, validateHeaders, initialBufferSize, allowDuplicateContentLengths, allowPartialChunks);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected HttpMessage createMessage(String[] initialLine) throws Exception {
/* 152 */     return new DefaultHttpRequest(
/* 153 */         HttpVersion.valueOf(initialLine[2]), 
/* 154 */         HttpMethod.valueOf(initialLine[0]), initialLine[1], this.validateHeaders);
/*     */   }
/*     */ 
/*     */   
/*     */   protected AsciiString splitHeaderName(byte[] sb, int start, int length) {
/* 159 */     byte firstChar = sb[start];
/* 160 */     if (firstChar == 72 && length == 4) {
/* 161 */       if (isHost(sb, start)) {
/* 162 */         return Host;
/*     */       }
/* 164 */     } else if (firstChar == 67) {
/* 165 */       if (length == 10) {
/* 166 */         if (isConnection(sb, start)) {
/* 167 */           return Connection;
/*     */         }
/* 169 */       } else if (length == 12) {
/* 170 */         if (isContentType(sb, start)) {
/* 171 */           return ContentType;
/*     */         }
/* 173 */       } else if (length == 14 && 
/* 174 */         isContentLength(sb, start)) {
/* 175 */         return ContentLength;
/*     */       } 
/*     */     } 
/*     */     
/* 179 */     return super.splitHeaderName(sb, start, length);
/*     */   }
/*     */   
/*     */   private static boolean isHost(byte[] sb, int start) {
/* 183 */     int maybeHost = sb[start] | sb[start + 1] << 8 | sb[start + 2] << 16 | sb[start + 3] << 24;
/*     */ 
/*     */ 
/*     */     
/* 187 */     return (maybeHost == 1953722184);
/*     */   }
/*     */   
/*     */   private static boolean isConnection(byte[] sb, int start) {
/* 191 */     long maybeConnecti = (sb[start] | sb[start + 1] << 8 | sb[start + 2] << 16 | sb[start + 3] << 24) | sb[start + 4] << 32L | sb[start + 5] << 40L | sb[start + 6] << 48L | sb[start + 7] << 56L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 199 */     if (maybeConnecti != 7598807758576447299L) {
/* 200 */       return false;
/*     */     }
/* 202 */     short maybeOn = (short)(sb[start + 8] | sb[start + 9] << 8);
/* 203 */     return (maybeOn == 28271);
/*     */   }
/*     */   
/*     */   private static boolean isContentType(byte[] sb, int start) {
/* 207 */     long maybeContent = (sb[start] | sb[start + 1] << 8 | sb[start + 2] << 16 | sb[start + 3] << 24) | sb[start + 4] << 32L | sb[start + 5] << 40L | sb[start + 6] << 48L | sb[start + 7] << 56L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 215 */     if (maybeContent != 3275364211029339971L) {
/* 216 */       return false;
/*     */     }
/* 218 */     int maybeType = sb[start + 8] | sb[start + 9] << 8 | sb[start + 10] << 16 | sb[start + 11] << 24;
/*     */ 
/*     */ 
/*     */     
/* 222 */     return (maybeType == 1701869908);
/*     */   }
/*     */   
/*     */   private static boolean isContentLength(byte[] sb, int start) {
/* 226 */     long maybeContent = (sb[start] | sb[start + 1] << 8 | sb[start + 2] << 16 | sb[start + 3] << 24) | sb[start + 4] << 32L | sb[start + 5] << 40L | sb[start + 6] << 48L | sb[start + 7] << 56L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 234 */     if (maybeContent != 3275364211029339971L) {
/* 235 */       return false;
/*     */     }
/* 237 */     long maybeLength = (sb[start + 8] | sb[start + 9] << 8 | sb[start + 10] << 16 | sb[start + 11] << 24) | sb[start + 12] << 32L | sb[start + 13] << 40L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 243 */     return (maybeLength == 114849160783180L);
/*     */   }
/*     */   
/*     */   private static boolean isGetMethod(byte[] sb, int start) {
/* 247 */     int maybeGet = sb[start] | sb[start + 1] << 8 | sb[start + 2] << 16;
/*     */ 
/*     */     
/* 250 */     return (maybeGet == 5522759);
/*     */   }
/*     */   
/*     */   private static boolean isPostMethod(byte[] sb, int start) {
/* 254 */     int maybePost = sb[start] | sb[start + 1] << 8 | sb[start + 2] << 16 | sb[start + 3] << 24;
/*     */ 
/*     */ 
/*     */     
/* 258 */     return (maybePost == 1414745936);
/*     */   }
/*     */ 
/*     */   
/*     */   protected String splitFirstWordInitialLine(byte[] sb, int start, int length) {
/* 263 */     if (length == 3) {
/* 264 */       if (isGetMethod(sb, start)) {
/* 265 */         return HttpMethod.GET.name();
/*     */       }
/* 267 */     } else if (length == 4 && 
/* 268 */       isPostMethod(sb, start)) {
/* 269 */       return HttpMethod.POST.name();
/*     */     } 
/*     */     
/* 272 */     return super.splitFirstWordInitialLine(sb, start, length);
/*     */   }
/*     */ 
/*     */   
/*     */   protected String splitThirdWordInitialLine(byte[] sb, int start, int length) {
/* 277 */     if (length == 8) {
/* 278 */       long maybeHttp1_x = (sb[start] | sb[start + 1] << 8 | sb[start + 2] << 16 | sb[start + 3] << 24) | sb[start + 4] << 32L | sb[start + 5] << 40L | sb[start + 6] << 48L | sb[start + 7] << 56L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 286 */       if (maybeHttp1_x == 3543824036068086856L)
/* 287 */         return "HTTP/1.1"; 
/* 288 */       if (maybeHttp1_x == 3471766442030158920L) {
/* 289 */         return "HTTP/1.0";
/*     */       }
/*     */     } 
/* 292 */     return super.splitThirdWordInitialLine(sb, start, length);
/*     */   }
/*     */ 
/*     */   
/*     */   protected HttpMessage createInvalidMessage() {
/* 297 */     return new DefaultFullHttpRequest(HttpVersion.HTTP_1_0, HttpMethod.GET, "/bad-request", this.validateHeaders);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isDecodingRequest() {
/* 302 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isContentAlwaysEmpty(HttpMessage msg) {
/* 310 */     if (msg.getClass() == DefaultHttpRequest.class) {
/* 311 */       return false;
/*     */     }
/* 313 */     return super.isContentAlwaysEmpty(msg);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http-4.1.93.Final.jar!\io\netty\handler\codec\http\HttpRequestDecoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */