/*     */ package io.netty.handler.codec.http.cookie;
/*     */ 
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultCookie
/*     */   implements Cookie
/*     */ {
/*     */   private final String name;
/*     */   private String value;
/*     */   private boolean wrap;
/*     */   private String domain;
/*     */   private String path;
/*  35 */   private long maxAge = Long.MIN_VALUE;
/*     */   
/*     */   private boolean secure;
/*     */   
/*     */   private boolean httpOnly;
/*     */   
/*     */   private CookieHeaderNames.SameSite sameSite;
/*     */   
/*     */   public DefaultCookie(String name, String value) {
/*  44 */     this.name = ObjectUtil.checkNonEmptyAfterTrim(name, "name");
/*  45 */     setValue(value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String name() {
/*  50 */     return this.name;
/*     */   }
/*     */ 
/*     */   
/*     */   public String value() {
/*  55 */     return this.value;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setValue(String value) {
/*  60 */     this.value = (String)ObjectUtil.checkNotNull(value, "value");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean wrap() {
/*  65 */     return this.wrap;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setWrap(boolean wrap) {
/*  70 */     this.wrap = wrap;
/*     */   }
/*     */ 
/*     */   
/*     */   public String domain() {
/*  75 */     return this.domain;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setDomain(String domain) {
/*  80 */     this.domain = CookieUtil.validateAttributeValue("domain", domain);
/*     */   }
/*     */ 
/*     */   
/*     */   public String path() {
/*  85 */     return this.path;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setPath(String path) {
/*  90 */     this.path = CookieUtil.validateAttributeValue("path", path);
/*     */   }
/*     */ 
/*     */   
/*     */   public long maxAge() {
/*  95 */     return this.maxAge;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setMaxAge(long maxAge) {
/* 100 */     this.maxAge = maxAge;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSecure() {
/* 105 */     return this.secure;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setSecure(boolean secure) {
/* 110 */     this.secure = secure;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isHttpOnly() {
/* 115 */     return this.httpOnly;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setHttpOnly(boolean httpOnly) {
/* 120 */     this.httpOnly = httpOnly;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CookieHeaderNames.SameSite sameSite() {
/* 130 */     return this.sameSite;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSameSite(CookieHeaderNames.SameSite sameSite) {
/* 140 */     this.sameSite = sameSite;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 145 */     return name().hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 150 */     if (this == o) {
/* 151 */       return true;
/*     */     }
/*     */     
/* 154 */     if (!(o instanceof Cookie)) {
/* 155 */       return false;
/*     */     }
/*     */     
/* 158 */     Cookie that = (Cookie)o;
/* 159 */     if (!name().equals(that.name())) {
/* 160 */       return false;
/*     */     }
/*     */     
/* 163 */     if (path() == null) {
/* 164 */       if (that.path() != null)
/* 165 */         return false; 
/*     */     } else {
/* 167 */       if (that.path() == null)
/* 168 */         return false; 
/* 169 */       if (!path().equals(that.path())) {
/* 170 */         return false;
/*     */       }
/*     */     } 
/* 173 */     if (domain() == null) {
/* 174 */       if (that.domain() != null) {
/* 175 */         return false;
/*     */       }
/*     */     } else {
/* 178 */       return domain().equalsIgnoreCase(that.domain());
/*     */     } 
/*     */     
/* 181 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int compareTo(Cookie c) {
/* 186 */     int v = name().compareTo(c.name());
/* 187 */     if (v != 0) {
/* 188 */       return v;
/*     */     }
/*     */     
/* 191 */     if (path() == null) {
/* 192 */       if (c.path() != null)
/* 193 */         return -1; 
/*     */     } else {
/* 195 */       if (c.path() == null) {
/* 196 */         return 1;
/*     */       }
/* 198 */       v = path().compareTo(c.path());
/* 199 */       if (v != 0) {
/* 200 */         return v;
/*     */       }
/*     */     } 
/*     */     
/* 204 */     if (domain() == null) {
/* 205 */       if (c.domain() != null)
/* 206 */         return -1; 
/*     */     } else {
/* 208 */       if (c.domain() == null) {
/* 209 */         return 1;
/*     */       }
/* 211 */       v = domain().compareToIgnoreCase(c.domain());
/* 212 */       return v;
/*     */     } 
/*     */     
/* 215 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected String validateValue(String name, String value) {
/* 228 */     return CookieUtil.validateAttributeValue(name, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 236 */     StringBuilder buf = CookieUtil.stringBuilder().append(name()).append('=').append(value());
/* 237 */     if (domain() != null) {
/* 238 */       buf.append(", domain=")
/* 239 */         .append(domain());
/*     */     }
/* 241 */     if (path() != null) {
/* 242 */       buf.append(", path=")
/* 243 */         .append(path());
/*     */     }
/* 245 */     if (maxAge() >= 0L) {
/* 246 */       buf.append(", maxAge=")
/* 247 */         .append(maxAge())
/* 248 */         .append('s');
/*     */     }
/* 250 */     if (isSecure()) {
/* 251 */       buf.append(", secure");
/*     */     }
/* 253 */     if (isHttpOnly()) {
/* 254 */       buf.append(", HTTPOnly");
/*     */     }
/* 256 */     if (sameSite() != null) {
/* 257 */       buf.append(", SameSite=").append(sameSite());
/*     */     }
/* 259 */     return buf.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http-4.1.93.Final.jar!\io\netty\handler\codec\http\cookie\DefaultCookie.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */