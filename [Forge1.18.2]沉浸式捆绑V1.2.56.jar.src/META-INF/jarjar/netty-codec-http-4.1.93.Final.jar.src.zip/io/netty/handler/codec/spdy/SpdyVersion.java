/*    */ package io.netty.handler.codec.spdy;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum SpdyVersion
/*    */ {
/* 19 */   SPDY_3_1(3, 1);
/*    */   
/*    */   private final int minorVersion;
/*    */   private final int version;
/*    */   
/*    */   SpdyVersion(int version, int minorVersion) {
/* 25 */     this.version = version;
/* 26 */     this.minorVersion = minorVersion;
/*    */   }
/*    */   
/*    */   int getVersion() {
/* 30 */     return this.version;
/*    */   }
/*    */   
/*    */   int getMinorVersion() {
/* 34 */     return this.minorVersion;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http-4.1.93.Final.jar!\io\netty\handler\codec\spdy\SpdyVersion.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */