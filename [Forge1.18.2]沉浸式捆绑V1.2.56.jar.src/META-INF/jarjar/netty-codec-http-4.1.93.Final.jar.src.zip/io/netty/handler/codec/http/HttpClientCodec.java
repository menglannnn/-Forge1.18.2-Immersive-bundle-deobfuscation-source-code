/*     */ package io.netty.handler.codec.http;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.channel.ChannelHandler;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.channel.ChannelInboundHandler;
/*     */ import io.netty.channel.ChannelOutboundHandler;
/*     */ import io.netty.channel.ChannelPipeline;
/*     */ import io.netty.channel.CombinedChannelDuplexHandler;
/*     */ import io.netty.handler.codec.PrematureChannelClosureException;
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.List;
/*     */ import java.util.Queue;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class HttpClientCodec
/*     */   extends CombinedChannelDuplexHandler<HttpResponseDecoder, HttpRequestEncoder>
/*     */   implements HttpClientUpgradeHandler.SourceCodec
/*     */ {
/*     */   public static final boolean DEFAULT_FAIL_ON_MISSING_RESPONSE = false;
/*     */   public static final boolean DEFAULT_PARSE_HTTP_AFTER_CONNECT_REQUEST = false;
/*  58 */   private final Queue<HttpMethod> queue = new ArrayDeque<HttpMethod>();
/*     */   
/*     */   private final boolean parseHttpAfterConnectRequest;
/*     */   
/*     */   private boolean done;
/*     */   
/*  64 */   private final AtomicLong requestResponseCounter = new AtomicLong();
/*     */ 
/*     */ 
/*     */   
/*     */   private final boolean failOnMissingResponse;
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpClientCodec() {
/*  73 */     this(4096, 8192, 8192, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpClientCodec(int maxInitialLineLength, int maxHeaderSize, int maxChunkSize) {
/*  81 */     this(maxInitialLineLength, maxHeaderSize, maxChunkSize, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpClientCodec(int maxInitialLineLength, int maxHeaderSize, int maxChunkSize, boolean failOnMissingResponse) {
/*  89 */     this(maxInitialLineLength, maxHeaderSize, maxChunkSize, failOnMissingResponse, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpClientCodec(int maxInitialLineLength, int maxHeaderSize, int maxChunkSize, boolean failOnMissingResponse, boolean validateHeaders) {
/*  98 */     this(maxInitialLineLength, maxHeaderSize, maxChunkSize, failOnMissingResponse, validateHeaders, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpClientCodec(int maxInitialLineLength, int maxHeaderSize, int maxChunkSize, boolean failOnMissingResponse, boolean validateHeaders, boolean parseHttpAfterConnectRequest) {
/* 108 */     init((ChannelInboundHandler)new Decoder(maxInitialLineLength, maxHeaderSize, maxChunkSize, validateHeaders), (ChannelOutboundHandler)new Encoder());
/* 109 */     this.failOnMissingResponse = failOnMissingResponse;
/* 110 */     this.parseHttpAfterConnectRequest = parseHttpAfterConnectRequest;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpClientCodec(int maxInitialLineLength, int maxHeaderSize, int maxChunkSize, boolean failOnMissingResponse, boolean validateHeaders, int initialBufferSize) {
/* 119 */     this(maxInitialLineLength, maxHeaderSize, maxChunkSize, failOnMissingResponse, validateHeaders, initialBufferSize, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpClientCodec(int maxInitialLineLength, int maxHeaderSize, int maxChunkSize, boolean failOnMissingResponse, boolean validateHeaders, int initialBufferSize, boolean parseHttpAfterConnectRequest) {
/* 129 */     this(maxInitialLineLength, maxHeaderSize, maxChunkSize, failOnMissingResponse, validateHeaders, initialBufferSize, parseHttpAfterConnectRequest, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpClientCodec(int maxInitialLineLength, int maxHeaderSize, int maxChunkSize, boolean failOnMissingResponse, boolean validateHeaders, int initialBufferSize, boolean parseHttpAfterConnectRequest, boolean allowDuplicateContentLengths) {
/* 140 */     this(maxInitialLineLength, maxHeaderSize, maxChunkSize, failOnMissingResponse, validateHeaders, initialBufferSize, parseHttpAfterConnectRequest, allowDuplicateContentLengths, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpClientCodec(int maxInitialLineLength, int maxHeaderSize, int maxChunkSize, boolean failOnMissingResponse, boolean validateHeaders, int initialBufferSize, boolean parseHttpAfterConnectRequest, boolean allowDuplicateContentLengths, boolean allowPartialChunks) {
/* 152 */     init((ChannelInboundHandler)new Decoder(maxInitialLineLength, maxHeaderSize, maxChunkSize, validateHeaders, initialBufferSize, allowDuplicateContentLengths, allowPartialChunks), (ChannelOutboundHandler)new Encoder());
/*     */ 
/*     */     
/* 155 */     this.parseHttpAfterConnectRequest = parseHttpAfterConnectRequest;
/* 156 */     this.failOnMissingResponse = failOnMissingResponse;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void prepareUpgradeFrom(ChannelHandlerContext ctx) {
/* 164 */     ((Encoder)outboundHandler()).upgraded = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void upgradeFrom(ChannelHandlerContext ctx) {
/* 173 */     ChannelPipeline p = ctx.pipeline();
/* 174 */     p.remove((ChannelHandler)this);
/*     */   }
/*     */   
/*     */   public void setSingleDecode(boolean singleDecode) {
/* 178 */     ((HttpResponseDecoder)inboundHandler()).setSingleDecode(singleDecode);
/*     */   }
/*     */   
/*     */   public boolean isSingleDecode() {
/* 182 */     return ((HttpResponseDecoder)inboundHandler()).isSingleDecode();
/*     */   }
/*     */   
/*     */   private final class Encoder
/*     */     extends HttpRequestEncoder
/*     */   {
/*     */     boolean upgraded;
/*     */     
/*     */     private Encoder() {}
/*     */     
/*     */     protected void encode(ChannelHandlerContext ctx, Object msg, List<Object> out) throws Exception {
/* 193 */       if (this.upgraded) {
/*     */         
/* 195 */         out.add(msg);
/*     */         
/*     */         return;
/*     */       } 
/* 199 */       if (msg instanceof HttpRequest) {
/* 200 */         HttpClientCodec.this.queue.offer(((HttpRequest)msg).method());
/*     */       }
/*     */       
/* 203 */       super.encode(ctx, msg, out);
/*     */       
/* 205 */       if (HttpClientCodec.this.failOnMissingResponse && !HttpClientCodec.this.done)
/*     */       {
/* 207 */         if (msg instanceof LastHttpContent)
/*     */         {
/* 209 */           HttpClientCodec.this.requestResponseCounter.incrementAndGet();
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private final class Decoder extends HttpResponseDecoder {
/*     */     Decoder(int maxInitialLineLength, int maxHeaderSize, int maxChunkSize, boolean validateHeaders) {
/* 217 */       super(maxInitialLineLength, maxHeaderSize, maxChunkSize, validateHeaders);
/*     */     }
/*     */ 
/*     */     
/*     */     Decoder(int maxInitialLineLength, int maxHeaderSize, int maxChunkSize, boolean validateHeaders, int initialBufferSize, boolean allowDuplicateContentLengths, boolean allowPartialChunks) {
/* 222 */       super(maxInitialLineLength, maxHeaderSize, maxChunkSize, validateHeaders, initialBufferSize, allowDuplicateContentLengths, allowPartialChunks);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void decode(ChannelHandlerContext ctx, ByteBuf buffer, List<Object> out) throws Exception {
/* 229 */       if (HttpClientCodec.this.done) {
/* 230 */         int readable = actualReadableBytes();
/* 231 */         if (readable == 0) {
/*     */           return;
/*     */         }
/*     */ 
/*     */         
/* 236 */         out.add(buffer.readBytes(readable));
/*     */       } else {
/* 238 */         int oldSize = out.size();
/* 239 */         super.decode(ctx, buffer, out);
/* 240 */         if (HttpClientCodec.this.failOnMissingResponse) {
/* 241 */           int size = out.size();
/* 242 */           for (int i = oldSize; i < size; i++) {
/* 243 */             decrement(out.get(i));
/*     */           }
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     private void decrement(Object msg) {
/* 250 */       if (msg == null) {
/*     */         return;
/*     */       }
/*     */ 
/*     */       
/* 255 */       if (msg instanceof LastHttpContent) {
/* 256 */         HttpClientCodec.this.requestResponseCounter.decrementAndGet();
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected boolean isContentAlwaysEmpty(HttpMessage msg) {
/* 267 */       HttpMethod method = HttpClientCodec.this.queue.poll();
/*     */       
/* 269 */       HttpResponseStatus status = ((HttpResponse)msg).status();
/* 270 */       HttpStatusClass statusClass = status.codeClass();
/* 271 */       int statusCode = status.code();
/* 272 */       if (statusClass == HttpStatusClass.INFORMATIONAL)
/*     */       {
/*     */         
/* 275 */         return super.isContentAlwaysEmpty(msg);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 280 */       if (method != null) {
/* 281 */         char firstChar = method.name().charAt(0);
/* 282 */         switch (firstChar) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           case 'H':
/* 288 */             if (HttpMethod.HEAD.equals(method)) {
/* 289 */               return true;
/*     */             }
/*     */             break;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           case 'C':
/* 307 */             if (statusCode == 200 && 
/* 308 */               HttpMethod.CONNECT.equals(method)) {
/*     */ 
/*     */               
/* 311 */               if (!HttpClientCodec.this.parseHttpAfterConnectRequest) {
/* 312 */                 HttpClientCodec.this.done = true;
/* 313 */                 HttpClientCodec.this.queue.clear();
/*     */               } 
/* 315 */               return true;
/*     */             } 
/*     */             break;
/*     */         } 
/*     */ 
/*     */ 
/*     */       
/*     */       } 
/* 323 */       return super.isContentAlwaysEmpty(msg);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void channelInactive(ChannelHandlerContext ctx) throws Exception {
/* 329 */       super.channelInactive(ctx);
/*     */       
/* 331 */       if (HttpClientCodec.this.failOnMissingResponse) {
/* 332 */         long missingResponses = HttpClientCodec.this.requestResponseCounter.get();
/* 333 */         if (missingResponses > 0L)
/* 334 */           ctx.fireExceptionCaught((Throwable)new PrematureChannelClosureException("channel gone inactive with " + missingResponses + " missing response(s)")); 
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http-4.1.93.Final.jar!\io\netty\handler\codec\http\HttpClientCodec.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */