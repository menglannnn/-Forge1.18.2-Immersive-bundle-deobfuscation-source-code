/*     */ package io.netty.handler.codec.http;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.buffer.ByteBufUtil;
/*     */ import io.netty.buffer.Unpooled;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.channel.ChannelPromise;
/*     */ import io.netty.channel.FileRegion;
/*     */ import io.netty.handler.codec.EncoderException;
/*     */ import io.netty.handler.codec.MessageToMessageEncoder;
/*     */ import io.netty.util.CharsetUtil;
/*     */ import io.netty.util.ReferenceCountUtil;
/*     */ import io.netty.util.concurrent.Future;
/*     */ import io.netty.util.concurrent.Promise;
/*     */ import io.netty.util.concurrent.PromiseCombiner;
/*     */ import io.netty.util.internal.StringUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class HttpObjectEncoder<H extends HttpMessage>
/*     */   extends MessageToMessageEncoder<Object>
/*     */ {
/*     */   static final int CRLF_SHORT = 3338;
/*     */   private static final int ZERO_CRLF_MEDIUM = 3149066;
/*  57 */   private static final byte[] ZERO_CRLF_CRLF = new byte[] { 48, 13, 10, 13, 10 };
/*  58 */   private static final ByteBuf CRLF_BUF = Unpooled.unreleasableBuffer(
/*  59 */       Unpooled.directBuffer(2).writeByte(13).writeByte(10)).asReadOnly();
/*  60 */   private static final ByteBuf ZERO_CRLF_CRLF_BUF = Unpooled.unreleasableBuffer(
/*  61 */       Unpooled.directBuffer(ZERO_CRLF_CRLF.length).writeBytes(ZERO_CRLF_CRLF)).asReadOnly();
/*     */   
/*     */   private static final float HEADERS_WEIGHT_NEW = 0.2F;
/*     */   
/*     */   private static final float HEADERS_WEIGHT_HISTORICAL = 0.8F;
/*     */   private static final float TRAILERS_WEIGHT_NEW = 0.2F;
/*     */   private static final float TRAILERS_WEIGHT_HISTORICAL = 0.8F;
/*     */   private static final int ST_INIT = 0;
/*     */   private static final int ST_CONTENT_NON_CHUNK = 1;
/*     */   private static final int ST_CONTENT_CHUNK = 2;
/*     */   private static final int ST_CONTENT_ALWAYS_EMPTY = 3;
/*  72 */   private int state = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  79 */   private float headersEncodedSizeAccumulator = 256.0F;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  85 */   private float trailersEncodedSizeAccumulator = 256.0F;
/*     */   
/*  87 */   private final List<Object> out = new ArrayList();
/*     */   
/*     */   private static boolean checkContentState(int state) {
/*  90 */     return (state == 2 || state == 1 || state == 3);
/*     */   }
/*     */ 
/*     */   
/*     */   public void write(ChannelHandlerContext ctx, Object msg, ChannelPromise promise) throws Exception {
/*     */     try {
/*  96 */       if (acceptOutboundMessage(msg)) {
/*  97 */         encode(ctx, msg, this.out);
/*  98 */         if (this.out.isEmpty()) {
/*  99 */           throw new EncoderException(
/* 100 */               StringUtil.simpleClassName(this) + " must produce at least one message.");
/*     */         }
/*     */       } else {
/* 103 */         ctx.write(msg, promise);
/*     */       } 
/* 105 */     } catch (EncoderException e) {
/* 106 */       throw e;
/* 107 */     } catch (Throwable t) {
/* 108 */       throw new EncoderException(t);
/*     */     } finally {
/* 110 */       writeOutList(ctx, this.out, promise);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void writeOutList(ChannelHandlerContext ctx, List<Object> out, ChannelPromise promise) {
/* 115 */     int size = out.size();
/*     */     try {
/* 117 */       if (size == 1) {
/* 118 */         ctx.write(out.get(0), promise);
/* 119 */       } else if (size > 1) {
/*     */ 
/*     */         
/* 122 */         if (promise == ctx.voidPromise()) {
/* 123 */           writeVoidPromise(ctx, out);
/*     */         } else {
/* 125 */           writePromiseCombiner(ctx, out, promise);
/*     */         } 
/*     */       } 
/*     */     } finally {
/* 129 */       out.clear();
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void writeVoidPromise(ChannelHandlerContext ctx, List<Object> out) {
/* 134 */     ChannelPromise voidPromise = ctx.voidPromise();
/* 135 */     for (int i = 0; i < out.size(); i++) {
/* 136 */       ctx.write(out.get(i), voidPromise);
/*     */     }
/*     */   }
/*     */   
/*     */   private static void writePromiseCombiner(ChannelHandlerContext ctx, List<Object> out, ChannelPromise promise) {
/* 141 */     PromiseCombiner combiner = new PromiseCombiner(ctx.executor());
/* 142 */     for (int i = 0; i < out.size(); i++) {
/* 143 */       combiner.add((Future)ctx.write(out.get(i)));
/*     */     }
/* 145 */     combiner.finish((Promise)promise);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void encode(ChannelHandlerContext ctx, Object msg, List<Object> out) throws Exception {
/* 152 */     if (msg == Unpooled.EMPTY_BUFFER) {
/* 153 */       out.add(Unpooled.EMPTY_BUFFER);
/*     */ 
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */     
/* 161 */     if (msg instanceof FullHttpMessage) {
/* 162 */       encodeFullHttpMessage(ctx, msg, out);
/*     */       return;
/*     */     } 
/* 165 */     if (msg instanceof HttpMessage) {
/*     */       HttpMessage httpMessage;
/*     */       try {
/* 168 */         httpMessage = (HttpMessage)msg;
/* 169 */       } catch (Exception rethrow) {
/* 170 */         ReferenceCountUtil.release(msg);
/* 171 */         throw rethrow;
/*     */       } 
/* 173 */       if (httpMessage instanceof LastHttpContent) {
/* 174 */         encodeHttpMessageLastContent(ctx, (H)httpMessage, out);
/* 175 */       } else if (httpMessage instanceof HttpContent) {
/* 176 */         encodeHttpMessageNotLastContent(ctx, (H)httpMessage, out);
/*     */       } else {
/* 178 */         encodeJustHttpMessage(ctx, (H)httpMessage, out);
/*     */       } 
/*     */     } else {
/* 181 */       encodeNotHttpMessageContentTypes(ctx, msg, out);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void encodeJustHttpMessage(ChannelHandlerContext ctx, H m, List<Object> out) throws Exception {
/* 186 */     assert !(m instanceof HttpContent);
/*     */     try {
/* 188 */       if (this.state != 0) {
/* 189 */         throwUnexpectedMessageTypeEx(m, this.state);
/*     */       }
/* 191 */       ByteBuf buf = encodeInitHttpMessage(ctx, m);
/*     */       
/* 193 */       assert checkContentState(this.state);
/*     */       
/* 195 */       out.add(buf);
/*     */     } finally {
/* 197 */       ReferenceCountUtil.release(m);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void encodeByteBufHttpContent(int state, ChannelHandlerContext ctx, ByteBuf buf, ByteBuf content, HttpHeaders trailingHeaders, List<Object> out) {
/* 203 */     switch (state) {
/*     */       case 1:
/* 205 */         if (encodeContentNonChunk(out, buf, content)) {
/*     */           return;
/*     */         }
/*     */ 
/*     */       
/*     */       case 3:
/* 211 */         out.add(buf);
/*     */         return;
/*     */       
/*     */       case 2:
/* 215 */         out.add(buf);
/* 216 */         encodeChunkedHttpContent(ctx, content, trailingHeaders, out);
/*     */         return;
/*     */     } 
/* 219 */     throw new Error();
/*     */   }
/*     */ 
/*     */   
/*     */   private void encodeHttpMessageNotLastContent(ChannelHandlerContext ctx, H m, List<Object> out) throws Exception {
/* 224 */     assert m instanceof HttpContent;
/* 225 */     assert !(m instanceof LastHttpContent);
/* 226 */     HttpContent httpContent = (HttpContent)m;
/*     */     try {
/* 228 */       if (this.state != 0) {
/* 229 */         throwUnexpectedMessageTypeEx(m, this.state);
/*     */       }
/* 231 */       ByteBuf buf = encodeInitHttpMessage(ctx, m);
/*     */       
/* 233 */       assert checkContentState(this.state);
/*     */       
/* 235 */       encodeByteBufHttpContent(this.state, ctx, buf, httpContent.content(), null, out);
/*     */     } finally {
/* 237 */       httpContent.release();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void encodeHttpMessageLastContent(ChannelHandlerContext ctx, H m, List<Object> out) throws Exception {
/* 242 */     assert m instanceof LastHttpContent;
/* 243 */     LastHttpContent httpContent = (LastHttpContent)m;
/*     */     try {
/* 245 */       if (this.state != 0) {
/* 246 */         throwUnexpectedMessageTypeEx(m, this.state);
/*     */       }
/* 248 */       ByteBuf buf = encodeInitHttpMessage(ctx, m);
/*     */       
/* 250 */       assert checkContentState(this.state);
/*     */       
/* 252 */       encodeByteBufHttpContent(this.state, ctx, buf, httpContent.content(), httpContent.trailingHeaders(), out);
/*     */       
/* 254 */       this.state = 0;
/*     */     } finally {
/* 256 */       httpContent.release();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void encodeNotHttpMessageContentTypes(ChannelHandlerContext ctx, Object msg, List<Object> out) {
/* 261 */     assert !(msg instanceof HttpMessage);
/* 262 */     if (this.state == 0) {
/*     */       try {
/* 264 */         if (msg instanceof ByteBuf && bypassEncoderIfEmpty((ByteBuf)msg, out)) {
/*     */           return;
/*     */         }
/* 267 */         throwUnexpectedMessageTypeEx(msg, 0);
/*     */       } finally {
/* 269 */         ReferenceCountUtil.release(msg);
/*     */       } 
/*     */     }
/* 272 */     if (msg == LastHttpContent.EMPTY_LAST_CONTENT) {
/* 273 */       this.state = encodeEmptyLastHttpContent(this.state, out);
/*     */       return;
/*     */     } 
/* 276 */     if (msg instanceof LastHttpContent) {
/* 277 */       encodeLastHttpContent(ctx, (LastHttpContent)msg, out);
/*     */       return;
/*     */     } 
/* 280 */     if (msg instanceof HttpContent) {
/* 281 */       encodeHttpContent(ctx, (HttpContent)msg, out);
/*     */       return;
/*     */     } 
/* 284 */     if (msg instanceof ByteBuf) {
/* 285 */       encodeByteBufContent(ctx, (ByteBuf)msg, out);
/*     */       return;
/*     */     } 
/* 288 */     if (msg instanceof FileRegion) {
/* 289 */       encodeFileRegionContent(ctx, (FileRegion)msg, out);
/*     */       return;
/*     */     } 
/*     */     try {
/* 293 */       throwUnexpectedMessageTypeEx(msg, this.state);
/*     */     } finally {
/* 295 */       ReferenceCountUtil.release(msg);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void encodeFullHttpMessage(ChannelHandlerContext ctx, Object o, List<Object> out) throws Exception {
/* 301 */     assert o instanceof FullHttpMessage;
/* 302 */     FullHttpMessage msg = (FullHttpMessage)o;
/*     */     try {
/* 304 */       if (this.state != 0) {
/* 305 */         throwUnexpectedMessageTypeEx(o, this.state);
/*     */       }
/*     */       
/* 308 */       HttpMessage httpMessage = (HttpMessage)o;
/*     */       
/* 310 */       ByteBuf buf = ctx.alloc().buffer((int)this.headersEncodedSizeAccumulator);
/*     */       
/* 312 */       encodeInitialLine(buf, (H)httpMessage);
/*     */ 
/*     */       
/* 315 */       int state = isContentAlwaysEmpty((H)httpMessage) ? 3 : (HttpUtil.isTransferEncodingChunked(httpMessage) ? 2 : 1);
/*     */       
/* 317 */       sanitizeHeadersBeforeEncode((H)httpMessage, (state == 3));
/*     */       
/* 319 */       encodeHeaders(httpMessage.headers(), buf);
/* 320 */       ByteBufUtil.writeShortBE(buf, 3338);
/*     */       
/* 322 */       this.headersEncodedSizeAccumulator = 0.2F * padSizeForAccumulation(buf.readableBytes()) + 0.8F * this.headersEncodedSizeAccumulator;
/*     */ 
/*     */       
/* 325 */       encodeByteBufHttpContent(state, ctx, buf, msg.content(), msg.trailingHeaders(), out);
/*     */     } finally {
/* 327 */       msg.release();
/*     */     } 
/*     */   }
/*     */   
/*     */   private static boolean encodeContentNonChunk(List<Object> out, ByteBuf buf, ByteBuf content) {
/* 332 */     int contentLength = content.readableBytes();
/* 333 */     if (contentLength > 0) {
/* 334 */       if (buf.writableBytes() >= contentLength) {
/*     */         
/* 336 */         buf.writeBytes(content);
/* 337 */         out.add(buf);
/*     */       } else {
/* 339 */         out.add(buf);
/* 340 */         out.add(content.retain());
/*     */       } 
/* 342 */       return true;
/*     */     } 
/* 344 */     return false;
/*     */   }
/*     */   
/*     */   private static void throwUnexpectedMessageTypeEx(Object msg, int state) {
/* 348 */     throw new IllegalStateException("unexpected message type: " + StringUtil.simpleClassName(msg) + ", state: " + state);
/*     */   }
/*     */ 
/*     */   
/*     */   private void encodeFileRegionContent(ChannelHandlerContext ctx, FileRegion msg, List<Object> out) {
/*     */     try {
/* 354 */       assert this.state != 0;
/* 355 */       switch (this.state) {
/*     */         case 1:
/* 357 */           if (msg.count() > 0L) {
/* 358 */             out.add(msg.retain());
/*     */             break;
/*     */           } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case 3:
/* 371 */           out.add(Unpooled.EMPTY_BUFFER);
/*     */           break;
/*     */         case 2:
/* 374 */           encodedChunkedFileRegionContent(ctx, msg, out);
/*     */           break;
/*     */         default:
/* 377 */           throw new Error();
/*     */       } 
/*     */     } finally {
/* 380 */       msg.release();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean bypassEncoderIfEmpty(ByteBuf msg, List<Object> out) {
/* 390 */     if (!msg.isReadable()) {
/* 391 */       out.add(msg.retain());
/* 392 */       return true;
/*     */     } 
/* 394 */     return false;
/*     */   }
/*     */   
/*     */   private void encodeByteBufContent(ChannelHandlerContext ctx, ByteBuf content, List<Object> out) {
/*     */     try {
/* 399 */       assert this.state != 0;
/* 400 */       if (bypassEncoderIfEmpty(content, out)) {
/*     */         return;
/*     */       }
/* 403 */       encodeByteBufAndTrailers(this.state, ctx, out, content, null);
/*     */     } finally {
/* 405 */       content.release();
/*     */     } 
/*     */   }
/*     */   
/*     */   private static int encodeEmptyLastHttpContent(int state, List<Object> out) {
/* 410 */     assert state != 0;
/*     */     
/* 412 */     switch (state) {
/*     */       case 1:
/*     */       case 3:
/* 415 */         out.add(Unpooled.EMPTY_BUFFER);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 423 */         return 0;case 2: out.add(ZERO_CRLF_CRLF_BUF.duplicate()); return 0;
/*     */     } 
/*     */     throw new Error();
/*     */   } private void encodeLastHttpContent(ChannelHandlerContext ctx, LastHttpContent msg, List<Object> out) {
/* 427 */     assert this.state != 0;
/* 428 */     assert !(msg instanceof HttpMessage);
/*     */     try {
/* 430 */       encodeByteBufAndTrailers(this.state, ctx, out, msg.content(), msg.trailingHeaders());
/* 431 */       this.state = 0;
/*     */     } finally {
/* 433 */       msg.release();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void encodeHttpContent(ChannelHandlerContext ctx, HttpContent msg, List<Object> out) {
/* 438 */     assert this.state != 0;
/* 439 */     assert !(msg instanceof HttpMessage);
/* 440 */     assert !(msg instanceof LastHttpContent);
/*     */     try {
/* 442 */       encodeByteBufAndTrailers(this.state, ctx, out, msg.content(), null);
/*     */     } finally {
/* 444 */       msg.release();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void encodeByteBufAndTrailers(int state, ChannelHandlerContext ctx, List<Object> out, ByteBuf content, HttpHeaders trailingHeaders) {
/* 450 */     switch (state) {
/*     */       case 1:
/* 452 */         if (content.isReadable()) {
/* 453 */           out.add(content.retain());
/*     */           return;
/*     */         } 
/*     */       
/*     */       case 3:
/* 458 */         out.add(Unpooled.EMPTY_BUFFER);
/*     */         return;
/*     */       case 2:
/* 461 */         encodeChunkedHttpContent(ctx, content, trailingHeaders, out);
/*     */         return;
/*     */     } 
/* 464 */     throw new Error();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void encodeChunkedHttpContent(ChannelHandlerContext ctx, ByteBuf content, HttpHeaders trailingHeaders, List<Object> out) {
/* 470 */     int contentLength = content.readableBytes();
/* 471 */     if (contentLength > 0) {
/* 472 */       addEncodedLengthHex(ctx, contentLength, out);
/* 473 */       out.add(content.retain());
/* 474 */       out.add(CRLF_BUF.duplicate());
/*     */     } 
/* 476 */     if (trailingHeaders != null) {
/* 477 */       encodeTrailingHeaders(ctx, trailingHeaders, out);
/* 478 */     } else if (contentLength == 0) {
/*     */ 
/*     */       
/* 481 */       out.add(content.retain());
/*     */     } 
/*     */   }
/*     */   
/*     */   private void encodeTrailingHeaders(ChannelHandlerContext ctx, HttpHeaders trailingHeaders, List<Object> out) {
/* 486 */     if (trailingHeaders.isEmpty()) {
/* 487 */       out.add(ZERO_CRLF_CRLF_BUF.duplicate());
/*     */     } else {
/* 489 */       ByteBuf buf = ctx.alloc().buffer((int)this.trailersEncodedSizeAccumulator);
/* 490 */       ByteBufUtil.writeMediumBE(buf, 3149066);
/* 491 */       encodeHeaders(trailingHeaders, buf);
/* 492 */       ByteBufUtil.writeShortBE(buf, 3338);
/* 493 */       this.trailersEncodedSizeAccumulator = 0.2F * padSizeForAccumulation(buf.readableBytes()) + 0.8F * this.trailersEncodedSizeAccumulator;
/*     */       
/* 495 */       out.add(buf);
/*     */     } 
/*     */   }
/*     */   
/*     */   private ByteBuf encodeInitHttpMessage(ChannelHandlerContext ctx, H m) throws Exception {
/* 500 */     assert this.state == 0;
/*     */     
/* 502 */     ByteBuf buf = ctx.alloc().buffer((int)this.headersEncodedSizeAccumulator);
/*     */     
/* 504 */     encodeInitialLine(buf, m);
/* 505 */     this
/* 506 */       .state = isContentAlwaysEmpty(m) ? 3 : (HttpUtil.isTransferEncodingChunked((HttpMessage)m) ? 2 : 1);
/*     */     
/* 508 */     sanitizeHeadersBeforeEncode(m, (this.state == 3));
/*     */     
/* 510 */     encodeHeaders(m.headers(), buf);
/* 511 */     ByteBufUtil.writeShortBE(buf, 3338);
/*     */     
/* 513 */     this.headersEncodedSizeAccumulator = 0.2F * padSizeForAccumulation(buf.readableBytes()) + 0.8F * this.headersEncodedSizeAccumulator;
/*     */     
/* 515 */     return buf;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void encodeHeaders(HttpHeaders headers, ByteBuf buf) {
/* 522 */     Iterator<Map.Entry<CharSequence, CharSequence>> iter = headers.iteratorCharSequence();
/* 523 */     while (iter.hasNext()) {
/* 524 */       Map.Entry<CharSequence, CharSequence> header = iter.next();
/* 525 */       HttpHeadersEncoder.encoderHeader(header.getKey(), header.getValue(), buf);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void encodedChunkedFileRegionContent(ChannelHandlerContext ctx, FileRegion msg, List<Object> out) {
/* 530 */     long contentLength = msg.count();
/* 531 */     if (contentLength > 0L) {
/* 532 */       addEncodedLengthHex(ctx, contentLength, out);
/* 533 */       out.add(msg.retain());
/* 534 */       out.add(CRLF_BUF.duplicate());
/* 535 */     } else if (contentLength == 0L) {
/*     */ 
/*     */       
/* 538 */       out.add(msg.retain());
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void addEncodedLengthHex(ChannelHandlerContext ctx, long contentLength, List<Object> out) {
/* 543 */     String lengthHex = Long.toHexString(contentLength);
/* 544 */     ByteBuf buf = ctx.alloc().buffer(lengthHex.length() + 2);
/* 545 */     buf.writeCharSequence(lengthHex, CharsetUtil.US_ASCII);
/* 546 */     ByteBufUtil.writeShortBE(buf, 3338);
/* 547 */     out.add(buf);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void sanitizeHeadersBeforeEncode(H msg, boolean isAlwaysEmpty) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isContentAlwaysEmpty(H msg) {
/* 565 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean acceptOutboundMessage(Object msg) throws Exception {
/* 571 */     return (msg == Unpooled.EMPTY_BUFFER || msg == LastHttpContent.EMPTY_LAST_CONTENT || msg instanceof FullHttpMessage || msg instanceof HttpMessage || msg instanceof LastHttpContent || msg instanceof HttpContent || msg instanceof ByteBuf || msg instanceof FileRegion);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int padSizeForAccumulation(int readableBytes) {
/* 588 */     return (readableBytes << 2) / 3;
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   protected static void encodeAscii(String s, ByteBuf buf) {
/* 593 */     buf.writeCharSequence(s, CharsetUtil.US_ASCII);
/*     */   }
/*     */   
/*     */   protected abstract void encodeInitialLine(ByteBuf paramByteBuf, H paramH) throws Exception;
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http-4.1.93.Final.jar!\io\netty\handler\codec\http\HttpObjectEncoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */