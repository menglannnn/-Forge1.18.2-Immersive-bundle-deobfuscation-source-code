/*     */ package io.netty.handler.codec.http.multipart;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.buffer.ByteBufHolder;
/*     */ import io.netty.channel.ChannelException;
/*     */ import io.netty.handler.codec.http.HttpConstants;
/*     */ import io.netty.util.AbstractReferenceCounted;
/*     */ import io.netty.util.ReferenceCounted;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import java.io.IOException;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractHttpData
/*     */   extends AbstractReferenceCounted
/*     */   implements HttpData
/*     */ {
/*  35 */   private static final Pattern STRIP_PATTERN = Pattern.compile("(?:^\\s+|\\s+$|\\n)");
/*  36 */   private static final Pattern REPLACE_PATTERN = Pattern.compile("[\\r\\t]");
/*     */   
/*     */   private final String name;
/*     */   protected long definedSize;
/*     */   protected long size;
/*  41 */   private Charset charset = HttpConstants.DEFAULT_CHARSET;
/*     */   private boolean completed;
/*  43 */   private long maxSize = -1L;
/*     */   
/*     */   protected AbstractHttpData(String name, Charset charset, long size) {
/*  46 */     ObjectUtil.checkNotNull(name, "name");
/*     */     
/*  48 */     name = REPLACE_PATTERN.matcher(name).replaceAll(" ");
/*  49 */     name = STRIP_PATTERN.matcher(name).replaceAll("");
/*     */     
/*  51 */     this.name = ObjectUtil.checkNonEmpty(name, "name");
/*  52 */     if (charset != null) {
/*  53 */       setCharset(charset);
/*     */     }
/*  55 */     this.definedSize = size;
/*     */   }
/*     */ 
/*     */   
/*     */   public long getMaxSize() {
/*  60 */     return this.maxSize;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setMaxSize(long maxSize) {
/*  65 */     this.maxSize = maxSize;
/*     */   }
/*     */ 
/*     */   
/*     */   public void checkSize(long newSize) throws IOException {
/*  70 */     if (this.maxSize >= 0L && newSize > this.maxSize) {
/*  71 */       throw new IOException("Size exceed allowed maximum capacity");
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/*  77 */     return this.name;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCompleted() {
/*  82 */     return this.completed;
/*     */   }
/*     */   
/*     */   protected void setCompleted() {
/*  86 */     setCompleted(true);
/*     */   }
/*     */   
/*     */   protected void setCompleted(boolean completed) {
/*  90 */     this.completed = completed;
/*     */   }
/*     */ 
/*     */   
/*     */   public Charset getCharset() {
/*  95 */     return this.charset;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setCharset(Charset charset) {
/* 100 */     this.charset = (Charset)ObjectUtil.checkNotNull(charset, "charset");
/*     */   }
/*     */ 
/*     */   
/*     */   public long length() {
/* 105 */     return this.size;
/*     */   }
/*     */ 
/*     */   
/*     */   public long definedLength() {
/* 110 */     return this.definedSize;
/*     */   }
/*     */ 
/*     */   
/*     */   public ByteBuf content() {
/*     */     try {
/* 116 */       return getByteBuf();
/* 117 */     } catch (IOException e) {
/* 118 */       throw new ChannelException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void deallocate() {
/* 124 */     delete();
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpData retain() {
/* 129 */     super.retain();
/* 130 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpData retain(int increment) {
/* 135 */     super.retain(increment);
/* 136 */     return this;
/*     */   }
/*     */   
/*     */   public abstract HttpData touch();
/*     */   
/*     */   public abstract HttpData touch(Object paramObject);
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http-4.1.93.Final.jar!\io\netty\handler\codec\http\multipart\AbstractHttpData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */