/*     */ package io.netty.handler.codec.rtsp;
/*     */ 
/*     */ import io.netty.handler.codec.http.DefaultFullHttpRequest;
/*     */ import io.netty.handler.codec.http.DefaultFullHttpResponse;
/*     */ import io.netty.handler.codec.http.DefaultHttpRequest;
/*     */ import io.netty.handler.codec.http.DefaultHttpResponse;
/*     */ import io.netty.handler.codec.http.HttpMessage;
/*     */ import io.netty.handler.codec.http.HttpObjectDecoder;
/*     */ import io.netty.handler.codec.http.HttpResponseStatus;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RtspDecoder
/*     */   extends HttpObjectDecoder
/*     */ {
/*  61 */   private static final HttpResponseStatus UNKNOWN_STATUS = new HttpResponseStatus(999, "Unknown");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isDecodingRequest;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  72 */   private static final Pattern versionPattern = Pattern.compile("RTSP/\\d\\.\\d");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int DEFAULT_MAX_CONTENT_LENGTH = 8192;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RtspDecoder() {
/*  85 */     this(4096, 8192, 8192);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RtspDecoder(int maxInitialLineLength, int maxHeaderSize, int maxContentLength) {
/*  99 */     super(maxInitialLineLength, maxHeaderSize, maxContentLength * 2, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RtspDecoder(int maxInitialLineLength, int maxHeaderSize, int maxContentLength, boolean validateHeaders) {
/* 113 */     super(maxInitialLineLength, maxHeaderSize, maxContentLength * 2, false, validateHeaders);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected HttpMessage createMessage(String[] initialLine) throws Exception {
/* 125 */     if (versionPattern.matcher(initialLine[0]).matches()) {
/* 126 */       this.isDecodingRequest = false;
/* 127 */       return (HttpMessage)new DefaultHttpResponse(RtspVersions.valueOf(initialLine[0]), new HttpResponseStatus(
/* 128 */             Integer.parseInt(initialLine[1]), initialLine[2]), this.validateHeaders);
/*     */     } 
/*     */ 
/*     */     
/* 132 */     this.isDecodingRequest = true;
/* 133 */     return (HttpMessage)new DefaultHttpRequest(RtspVersions.valueOf(initialLine[2]), 
/* 134 */         RtspMethods.valueOf(initialLine[0]), initialLine[1], this.validateHeaders);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isContentAlwaysEmpty(HttpMessage msg) {
/* 144 */     return (super.isContentAlwaysEmpty(msg) || !msg.headers().contains((CharSequence)RtspHeaderNames.CONTENT_LENGTH));
/*     */   }
/*     */ 
/*     */   
/*     */   protected HttpMessage createInvalidMessage() {
/* 149 */     if (this.isDecodingRequest) {
/* 150 */       return (HttpMessage)new DefaultFullHttpRequest(RtspVersions.RTSP_1_0, RtspMethods.OPTIONS, "/bad-request", this.validateHeaders);
/*     */     }
/*     */     
/* 153 */     return (HttpMessage)new DefaultFullHttpResponse(RtspVersions.RTSP_1_0, UNKNOWN_STATUS, this.validateHeaders);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isDecodingRequest() {
/* 161 */     return this.isDecodingRequest;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http-4.1.93.Final.jar!\io\netty\handler\codec\rtsp\RtspDecoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */