/*     */ package io.netty.handler.codec.http.websocketx;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.channel.ChannelFutureListener;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.channel.ChannelInboundHandlerAdapter;
/*     */ import io.netty.util.concurrent.GenericFutureListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Utf8FrameValidator
/*     */   extends ChannelInboundHandlerAdapter
/*     */ {
/*     */   private final boolean closeOnProtocolViolation;
/*     */   private int fragmentedFramesCount;
/*     */   private Utf8Validator utf8Validator;
/*     */   
/*     */   public Utf8FrameValidator() {
/*  34 */     this(true);
/*     */   }
/*     */   
/*     */   public Utf8FrameValidator(boolean closeOnProtocolViolation) {
/*  38 */     this.closeOnProtocolViolation = closeOnProtocolViolation;
/*     */   }
/*     */ 
/*     */   
/*     */   public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
/*  43 */     if (msg instanceof WebSocketFrame) {
/*  44 */       WebSocketFrame frame = (WebSocketFrame)msg;
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/*  49 */         if (((WebSocketFrame)msg).isFinalFragment()) {
/*     */ 
/*     */           
/*  52 */           if (!(frame instanceof PingWebSocketFrame)) {
/*  53 */             this.fragmentedFramesCount = 0;
/*     */ 
/*     */             
/*  56 */             if (frame instanceof TextWebSocketFrame || (this.utf8Validator != null && this.utf8Validator
/*  57 */               .isChecking()))
/*     */             {
/*  59 */               checkUTF8String(frame.content());
/*     */ 
/*     */ 
/*     */               
/*  63 */               this.utf8Validator.finish();
/*     */             }
/*     */           
/*     */           } 
/*     */         } else {
/*     */           
/*  69 */           if (this.fragmentedFramesCount == 0) {
/*     */             
/*  71 */             if (frame instanceof TextWebSocketFrame) {
/*  72 */               checkUTF8String(frame.content());
/*     */             
/*     */             }
/*     */           }
/*  76 */           else if (this.utf8Validator != null && this.utf8Validator.isChecking()) {
/*  77 */             checkUTF8String(frame.content());
/*     */           } 
/*     */ 
/*     */ 
/*     */           
/*  82 */           this.fragmentedFramesCount++;
/*     */         } 
/*  84 */       } catch (CorruptedWebSocketFrameException e) {
/*  85 */         protocolViolation(ctx, frame, e);
/*     */       } 
/*     */     } 
/*     */     
/*  89 */     super.channelRead(ctx, msg);
/*     */   }
/*     */   
/*     */   private void checkUTF8String(ByteBuf buffer) {
/*  93 */     if (this.utf8Validator == null) {
/*  94 */       this.utf8Validator = new Utf8Validator();
/*     */     }
/*  96 */     this.utf8Validator.check(buffer);
/*     */   }
/*     */ 
/*     */   
/*     */   private void protocolViolation(ChannelHandlerContext ctx, WebSocketFrame frame, CorruptedWebSocketFrameException ex) {
/* 101 */     frame.release();
/* 102 */     if (this.closeOnProtocolViolation && ctx.channel().isOpen()) {
/* 103 */       WebSocketCloseStatus closeStatus = ex.closeStatus();
/* 104 */       String reasonText = ex.getMessage();
/* 105 */       if (reasonText == null) {
/* 106 */         reasonText = closeStatus.reasonText();
/*     */       }
/*     */       
/* 109 */       CloseWebSocketFrame closeFrame = new CloseWebSocketFrame(closeStatus.code(), reasonText);
/* 110 */       ctx.writeAndFlush(closeFrame).addListener((GenericFutureListener)ChannelFutureListener.CLOSE);
/*     */     } 
/*     */     
/* 113 */     throw ex;
/*     */   }
/*     */ 
/*     */   
/*     */   public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
/* 118 */     super.exceptionCaught(ctx, cause);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http-4.1.93.Final.jar!\io\netty\handler\codec\http\websocketx\Utf8FrameValidator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */