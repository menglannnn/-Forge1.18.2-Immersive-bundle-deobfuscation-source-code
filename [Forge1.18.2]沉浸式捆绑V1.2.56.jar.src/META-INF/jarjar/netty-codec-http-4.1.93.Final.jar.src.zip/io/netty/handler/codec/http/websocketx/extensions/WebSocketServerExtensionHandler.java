/*     */ package io.netty.handler.codec.http.websocketx.extensions;
/*     */ 
/*     */ import io.netty.buffer.Unpooled;
/*     */ import io.netty.channel.ChannelDuplexHandler;
/*     */ import io.netty.channel.ChannelFuture;
/*     */ import io.netty.channel.ChannelFutureListener;
/*     */ import io.netty.channel.ChannelHandler;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.channel.ChannelPromise;
/*     */ import io.netty.handler.codec.http.HttpHeaderNames;
/*     */ import io.netty.handler.codec.http.HttpHeaders;
/*     */ import io.netty.handler.codec.http.HttpRequest;
/*     */ import io.netty.handler.codec.http.HttpResponse;
/*     */ import io.netty.handler.codec.http.HttpResponseStatus;
/*     */ import io.netty.handler.codec.http.LastHttpContent;
/*     */ import io.netty.util.concurrent.Future;
/*     */ import io.netty.util.concurrent.GenericFutureListener;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Queue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WebSocketServerExtensionHandler
/*     */   extends ChannelDuplexHandler
/*     */ {
/*     */   private final List<WebSocketServerExtensionHandshaker> extensionHandshakers;
/*  59 */   private final Queue<List<WebSocketServerExtension>> validExtensions = new ArrayDeque<List<WebSocketServerExtension>>(4);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebSocketServerExtensionHandler(WebSocketServerExtensionHandshaker... extensionHandshakers) {
/*  70 */     this.extensionHandshakers = Arrays.asList(ObjectUtil.checkNonEmpty((Object[])extensionHandshakers, "extensionHandshakers"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
/*  80 */     if (msg != LastHttpContent.EMPTY_LAST_CONTENT) {
/*  81 */       if (msg instanceof io.netty.handler.codec.http.DefaultHttpRequest) {
/*     */         
/*  83 */         onHttpRequestChannelRead(ctx, (HttpRequest)msg);
/*  84 */       } else if (msg instanceof HttpRequest) {
/*     */         
/*  86 */         onHttpRequestChannelRead(ctx, (HttpRequest)msg);
/*     */       } else {
/*  88 */         super.channelRead(ctx, msg);
/*     */       } 
/*     */     } else {
/*  91 */       super.channelRead(ctx, msg);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onHttpRequestChannelRead(ChannelHandlerContext ctx, HttpRequest request) throws Exception {
/* 124 */     List<WebSocketServerExtension> validExtensionsList = null;
/*     */     
/* 126 */     if (WebSocketExtensionUtil.isWebsocketUpgrade(request.headers())) {
/* 127 */       String extensionsHeader = request.headers().getAsString((CharSequence)HttpHeaderNames.SEC_WEBSOCKET_EXTENSIONS);
/*     */       
/* 129 */       if (extensionsHeader != null) {
/*     */         
/* 131 */         List<WebSocketExtensionData> extensions = WebSocketExtensionUtil.extractExtensions(extensionsHeader);
/* 132 */         int rsv = 0;
/*     */         
/* 134 */         for (WebSocketExtensionData extensionData : extensions) {
/*     */           
/* 136 */           Iterator<WebSocketServerExtensionHandshaker> extensionHandshakersIterator = this.extensionHandshakers.iterator();
/* 137 */           WebSocketServerExtension validExtension = null;
/*     */           
/* 139 */           while (validExtension == null && extensionHandshakersIterator.hasNext()) {
/*     */             
/* 141 */             WebSocketServerExtensionHandshaker extensionHandshaker = extensionHandshakersIterator.next();
/* 142 */             validExtension = extensionHandshaker.handshakeExtension(extensionData);
/*     */           } 
/*     */           
/* 145 */           if (validExtension != null && (validExtension.rsv() & rsv) == 0) {
/* 146 */             if (validExtensionsList == null) {
/* 147 */               validExtensionsList = new ArrayList<WebSocketServerExtension>(1);
/*     */             }
/* 149 */             rsv |= validExtension.rsv();
/* 150 */             validExtensionsList.add(validExtension);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 156 */     if (validExtensionsList == null) {
/* 157 */       validExtensionsList = Collections.emptyList();
/*     */     }
/* 159 */     this.validExtensions.offer(validExtensionsList);
/* 160 */     super.channelRead(ctx, request);
/*     */   }
/*     */ 
/*     */   
/*     */   public void write(ChannelHandlerContext ctx, Object msg, ChannelPromise promise) throws Exception {
/* 165 */     if (msg != Unpooled.EMPTY_BUFFER && !(msg instanceof io.netty.buffer.ByteBuf)) {
/* 166 */       if (msg instanceof io.netty.handler.codec.http.DefaultHttpResponse) {
/* 167 */         onHttpResponseWrite(ctx, (HttpResponse)msg, promise);
/* 168 */       } else if (msg instanceof HttpResponse) {
/* 169 */         onHttpResponseWrite(ctx, (HttpResponse)msg, promise);
/*     */       } else {
/* 171 */         super.write(ctx, msg, promise);
/*     */       } 
/*     */     } else {
/* 174 */       super.write(ctx, msg, promise);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onHttpResponseWrite(ChannelHandlerContext ctx, HttpResponse response, ChannelPromise promise) throws Exception {
/* 207 */     List<WebSocketServerExtension> validExtensionsList = this.validExtensions.poll();
/* 208 */     HttpResponse httpResponse = response;
/*     */ 
/*     */     
/* 211 */     if (HttpResponseStatus.SWITCHING_PROTOCOLS.equals(httpResponse.status())) {
/* 212 */       handlePotentialUpgrade(ctx, promise, httpResponse, validExtensionsList);
/*     */     }
/* 214 */     super.write(ctx, response, promise);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void handlePotentialUpgrade(final ChannelHandlerContext ctx, ChannelPromise promise, HttpResponse httpResponse, final List<WebSocketServerExtension> validExtensionsList) {
/* 220 */     HttpHeaders headers = httpResponse.headers();
/*     */     
/* 222 */     if (WebSocketExtensionUtil.isWebsocketUpgrade(headers)) {
/* 223 */       if (validExtensionsList != null && !validExtensionsList.isEmpty()) {
/* 224 */         String headerValue = headers.getAsString((CharSequence)HttpHeaderNames.SEC_WEBSOCKET_EXTENSIONS);
/*     */         
/* 226 */         List<WebSocketExtensionData> extraExtensions = new ArrayList<WebSocketExtensionData>(this.extensionHandshakers.size());
/* 227 */         for (WebSocketServerExtension extension : validExtensionsList) {
/* 228 */           extraExtensions.add(extension.newReponseData());
/*     */         }
/*     */         
/* 231 */         String newHeaderValue = WebSocketExtensionUtil.computeMergeExtensionsHeaderValue(headerValue, extraExtensions);
/* 232 */         promise.addListener((GenericFutureListener)new ChannelFutureListener()
/*     */             {
/*     */               public void operationComplete(ChannelFuture future) {
/* 235 */                 if (future.isSuccess()) {
/* 236 */                   for (WebSocketServerExtension extension : validExtensionsList) {
/* 237 */                     WebSocketExtensionDecoder decoder = extension.newExtensionDecoder();
/* 238 */                     WebSocketExtensionEncoder encoder = extension.newExtensionEncoder();
/* 239 */                     String name = ctx.name();
/* 240 */                     ctx.pipeline()
/* 241 */                       .addAfter(name, decoder.getClass().getName(), (ChannelHandler)decoder)
/* 242 */                       .addAfter(name, encoder.getClass().getName(), (ChannelHandler)encoder);
/*     */                   } 
/*     */                 }
/*     */               }
/*     */             });
/*     */         
/* 248 */         if (newHeaderValue != null) {
/* 249 */           headers.set((CharSequence)HttpHeaderNames.SEC_WEBSOCKET_EXTENSIONS, newHeaderValue);
/*     */         }
/*     */       } 
/*     */       
/* 253 */       promise.addListener((GenericFutureListener)new ChannelFutureListener()
/*     */           {
/*     */             public void operationComplete(ChannelFuture future) {
/* 256 */               if (future.isSuccess())
/* 257 */                 ctx.pipeline().remove((ChannelHandler)WebSocketServerExtensionHandler.this); 
/*     */             }
/*     */           });
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http-4.1.93.Final.jar!\io\netty\handler\codec\http\websocketx\extensions\WebSocketServerExtensionHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */