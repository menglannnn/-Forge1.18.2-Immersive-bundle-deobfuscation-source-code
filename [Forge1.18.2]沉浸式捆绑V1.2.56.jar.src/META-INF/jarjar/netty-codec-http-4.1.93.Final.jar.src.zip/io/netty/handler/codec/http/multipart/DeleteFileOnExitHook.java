/*    */ package io.netty.handler.codec.http.multipart;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.util.Collections;
/*    */ import java.util.Set;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class DeleteFileOnExitHook
/*    */ {
/* 27 */   private static final Set<String> FILES = Collections.newSetFromMap(new ConcurrentHashMap<String, Boolean>());
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static {
/* 37 */     Runtime.getRuntime().addShutdownHook(new Thread()
/*    */         {
/*    */           public void run()
/*    */           {
/* 41 */             DeleteFileOnExitHook.runHook();
/*    */           }
/*    */         });
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void remove(String file) {
/* 52 */     FILES.remove(file);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void add(String file) {
/* 61 */     FILES.add(file);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static boolean checkFileExist(String file) {
/* 71 */     return FILES.contains(file);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static void runHook() {
/* 78 */     for (String filename : FILES)
/* 79 */       (new File(filename)).delete(); 
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http-4.1.93.Final.jar!\io\netty\handler\codec\http\multipart\DeleteFileOnExitHook.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */