/*    */ package io.netty.handler.codec.http;
/*    */ 
/*    */ import io.netty.util.CharsetUtil;
/*    */ import java.nio.charset.Charset;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class HttpConstants
/*    */ {
/*    */   public static final byte SP = 32;
/*    */   public static final byte HT = 9;
/*    */   public static final byte CR = 13;
/*    */   public static final byte EQUALS = 61;
/*    */   public static final byte LF = 10;
/*    */   public static final byte COLON = 58;
/*    */   public static final byte SEMICOLON = 59;
/*    */   public static final byte COMMA = 44;
/*    */   public static final byte DOUBLE_QUOTE = 34;
/* 72 */   public static final Charset DEFAULT_CHARSET = CharsetUtil.UTF_8;
/*    */   public static final char SP_CHAR = ' ';
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http-4.1.93.Final.jar!\io\netty\handler\codec\http\HttpConstants.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */