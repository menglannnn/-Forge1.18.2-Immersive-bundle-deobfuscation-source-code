/*     */ package io.netty.handler.codec.http;
/*     */ 
/*     */ import io.netty.util.AsciiString;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class HttpHeaderValidationUtil
/*     */ {
/*     */   private static final long TOKEN_CHARS_HIGH;
/*     */   private static final long TOKEN_CHARS_LOW;
/*     */   
/*     */   public static boolean isConnectionHeader(CharSequence name, boolean ignoreTeHeader) {
/*  65 */     int len = name.length();
/*  66 */     switch (len) { case 2:
/*  67 */         return ignoreTeHeader ? false : AsciiString.contentEqualsIgnoreCase(name, (CharSequence)HttpHeaderNames.TE);
/*  68 */       case 7: return AsciiString.contentEqualsIgnoreCase(name, (CharSequence)HttpHeaderNames.UPGRADE);
/*  69 */       case 10: return (AsciiString.contentEqualsIgnoreCase(name, (CharSequence)HttpHeaderNames.CONNECTION) || 
/*  70 */           AsciiString.contentEqualsIgnoreCase(name, (CharSequence)HttpHeaderNames.KEEP_ALIVE));
/*  71 */       case 16: return AsciiString.contentEqualsIgnoreCase(name, (CharSequence)HttpHeaderNames.PROXY_CONNECTION);
/*  72 */       case 17: return AsciiString.contentEqualsIgnoreCase(name, (CharSequence)HttpHeaderNames.TRANSFER_ENCODING); }
/*     */     
/*  74 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isTeNotTrailers(CharSequence name, CharSequence value) {
/*  92 */     if (name.length() == 2) {
/*  93 */       return (AsciiString.contentEqualsIgnoreCase(name, (CharSequence)HttpHeaderNames.TE) && 
/*  94 */         !AsciiString.contentEqualsIgnoreCase(value, (CharSequence)HttpHeaderValues.TRAILERS));
/*     */     }
/*  96 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int validateValidHeaderValue(CharSequence value) {
/* 107 */     int length = value.length();
/* 108 */     if (length == 0) {
/* 109 */       return -1;
/*     */     }
/* 111 */     if (value instanceof AsciiString) {
/* 112 */       return verifyValidHeaderValueAsciiString((AsciiString)value);
/*     */     }
/* 114 */     return verifyValidHeaderValueCharSequence(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int verifyValidHeaderValueAsciiString(AsciiString value) {
/* 127 */     byte[] array = value.array();
/* 128 */     int start = value.arrayOffset();
/* 129 */     int b = array[start] & 0xFF;
/* 130 */     if (b < 33 || b == 127) {
/* 131 */       return 0;
/*     */     }
/* 133 */     int length = value.length();
/* 134 */     for (int i = start + 1; i < length; i++) {
/* 135 */       b = array[i] & 0xFF;
/* 136 */       if ((b < 32 && b != 9) || b == 127) {
/* 137 */         return i - start;
/*     */       }
/*     */     } 
/* 140 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int verifyValidHeaderValueCharSequence(CharSequence value) {
/* 153 */     int b = value.charAt(0);
/* 154 */     if (b < 33 || b == 127) {
/* 155 */       return 0;
/*     */     }
/* 157 */     int length = value.length();
/* 158 */     for (int i = 1; i < length; i++) {
/* 159 */       b = value.charAt(i);
/* 160 */       if ((b < 32 && b != 9) || b == 127) {
/* 161 */         return i;
/*     */       }
/*     */     } 
/* 164 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int validateToken(CharSequence token) {
/* 181 */     if (token instanceof AsciiString) {
/* 182 */       return validateAsciiStringToken((AsciiString)token);
/*     */     }
/* 184 */     return validateCharSequenceToken(token);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int validateAsciiStringToken(AsciiString token) {
/* 194 */     byte[] array = token.array();
/* 195 */     for (int i = token.arrayOffset(), len = token.arrayOffset() + token.length(); i < len; i++) {
/* 196 */       if (!BitSet128.contains(array[i], TOKEN_CHARS_HIGH, TOKEN_CHARS_LOW)) {
/* 197 */         return i - token.arrayOffset();
/*     */       }
/*     */     } 
/* 200 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int validateCharSequenceToken(CharSequence token) {
/* 210 */     for (int i = 0, len = token.length(); i < len; i++) {
/* 211 */       byte value = (byte)token.charAt(i);
/* 212 */       if (!BitSet128.contains(value, TOKEN_CHARS_HIGH, TOKEN_CHARS_LOW)) {
/* 213 */         return i;
/*     */       }
/*     */     } 
/* 216 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/* 251 */     BitSet128 tokenChars = (new BitSet128()).range('0', '9').range('a', 'z').range('A', 'Z').bits(new char[] { '-', '.', '_', '~' }).bits(new char[] { '!', '#', '$', '%', '&', '\'', '*', '+', '^', '`', 
/* 252 */           '|' }); TOKEN_CHARS_HIGH = tokenChars.high();
/* 253 */     TOKEN_CHARS_LOW = tokenChars.low();
/*     */   }
/*     */   private static final class BitSet128 { private long high;
/*     */     private long low;
/*     */     
/*     */     private BitSet128() {}
/*     */     
/*     */     BitSet128 range(char fromInc, char toInc) {
/* 261 */       for (int bit = fromInc; bit <= toInc; bit++) {
/* 262 */         if (bit < 64) {
/* 263 */           this.low |= 1L << bit;
/*     */         } else {
/* 265 */           this.high |= 1L << bit - 64;
/*     */         } 
/*     */       } 
/* 268 */       return this;
/*     */     }
/*     */     
/*     */     BitSet128 bits(char... bits) {
/* 272 */       for (char bit : bits) {
/* 273 */         if (bit < '@') {
/* 274 */           this.low |= 1L << bit;
/*     */         } else {
/* 276 */           this.high |= 1L << bit - 64;
/*     */         } 
/*     */       } 
/* 279 */       return this;
/*     */     }
/*     */     
/*     */     long high() {
/* 283 */       return this.high;
/*     */     }
/*     */     
/*     */     long low() {
/* 287 */       return this.low;
/*     */     }
/*     */     
/*     */     static boolean contains(byte bit, long high, long low) {
/* 291 */       if (bit < 0) {
/* 292 */         return false;
/*     */       }
/* 294 */       if (bit < 64) {
/* 295 */         return (0L != (low & 1L << bit));
/*     */       }
/* 297 */       return (0L != (high & 1L << bit - 64));
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http-4.1.93.Final.jar!\io\netty\handler\codec\http\HttpHeaderValidationUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */