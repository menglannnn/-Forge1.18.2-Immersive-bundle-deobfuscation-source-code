/*      */ package io.netty.handler.codec.http.multipart;
/*      */ 
/*      */ import io.netty.buffer.ByteBuf;
/*      */ import io.netty.handler.codec.http.HttpConstants;
/*      */ import io.netty.handler.codec.http.HttpContent;
/*      */ import io.netty.handler.codec.http.HttpHeaderNames;
/*      */ import io.netty.handler.codec.http.HttpHeaderValues;
/*      */ import io.netty.handler.codec.http.HttpRequest;
/*      */ import io.netty.handler.codec.http.QueryStringDecoder;
/*      */ import io.netty.util.CharsetUtil;
/*      */ import io.netty.util.internal.InternalThreadLocalMap;
/*      */ import io.netty.util.internal.ObjectUtil;
/*      */ import io.netty.util.internal.PlatformDependent;
/*      */ import io.netty.util.internal.StringUtil;
/*      */ import java.io.IOException;
/*      */ import java.nio.charset.Charset;
/*      */ import java.nio.charset.IllegalCharsetNameException;
/*      */ import java.nio.charset.UnsupportedCharsetException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.TreeMap;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class HttpPostMultipartRequestDecoder
/*      */   implements InterfaceHttpPostRequestDecoder
/*      */ {
/*      */   private final HttpDataFactory factory;
/*      */   private final HttpRequest request;
/*      */   private Charset charset;
/*      */   private boolean isLastChunk;
/*   79 */   private final List<InterfaceHttpData> bodyListHttpData = new ArrayList<InterfaceHttpData>();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   84 */   private final Map<String, List<InterfaceHttpData>> bodyMapHttpData = new TreeMap<String, List<InterfaceHttpData>>(CaseIgnoringComparator.INSTANCE);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ByteBuf undecodedChunk;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int bodyListHttpDataRank;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final String multipartDataBoundary;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String multipartMixedBoundary;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  111 */   private HttpPostRequestDecoder.MultiPartStatus currentStatus = HttpPostRequestDecoder.MultiPartStatus.NOTSTARTED;
/*      */ 
/*      */ 
/*      */   
/*      */   private Map<CharSequence, Attribute> currentFieldAttributes;
/*      */ 
/*      */ 
/*      */   
/*      */   private FileUpload currentFileUpload;
/*      */ 
/*      */ 
/*      */   
/*      */   private Attribute currentAttribute;
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean destroyed;
/*      */ 
/*      */   
/*  130 */   private int discardThreshold = 10485760;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpPostMultipartRequestDecoder(HttpRequest request) {
/*  143 */     this(new DefaultHttpDataFactory(16384L), request, HttpConstants.DEFAULT_CHARSET);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpPostMultipartRequestDecoder(HttpDataFactory factory, HttpRequest request) {
/*  159 */     this(factory, request, HttpConstants.DEFAULT_CHARSET);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpPostMultipartRequestDecoder(HttpDataFactory factory, HttpRequest request, Charset charset) {
/*  177 */     this.request = (HttpRequest)ObjectUtil.checkNotNull(request, "request");
/*  178 */     this.charset = (Charset)ObjectUtil.checkNotNull(charset, "charset");
/*  179 */     this.factory = (HttpDataFactory)ObjectUtil.checkNotNull(factory, "factory");
/*      */ 
/*      */     
/*  182 */     String contentTypeValue = this.request.headers().get((CharSequence)HttpHeaderNames.CONTENT_TYPE);
/*  183 */     if (contentTypeValue == null) {
/*  184 */       throw new HttpPostRequestDecoder.ErrorDataDecoderException("No '" + HttpHeaderNames.CONTENT_TYPE + "' header present.");
/*      */     }
/*      */     
/*  187 */     String[] dataBoundary = HttpPostRequestDecoder.getMultipartDataBoundary(contentTypeValue);
/*  188 */     if (dataBoundary != null) {
/*  189 */       this.multipartDataBoundary = dataBoundary[0];
/*  190 */       if (dataBoundary.length > 1 && dataBoundary[1] != null) {
/*      */         try {
/*  192 */           this.charset = Charset.forName(dataBoundary[1]);
/*  193 */         } catch (IllegalCharsetNameException e) {
/*  194 */           throw new HttpPostRequestDecoder.ErrorDataDecoderException(e);
/*      */         } 
/*      */       }
/*      */     } else {
/*  198 */       this.multipartDataBoundary = null;
/*      */     } 
/*  200 */     this.currentStatus = HttpPostRequestDecoder.MultiPartStatus.HEADERDELIMITER;
/*      */     
/*      */     try {
/*  203 */       if (request instanceof HttpContent) {
/*      */ 
/*      */         
/*  206 */         offer((HttpContent)request);
/*      */       } else {
/*  208 */         parseBody();
/*      */       } 
/*  210 */     } catch (Throwable e) {
/*  211 */       destroy();
/*  212 */       PlatformDependent.throwException(e);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void checkDestroyed() {
/*  217 */     if (this.destroyed) {
/*  218 */       throw new IllegalStateException(HttpPostMultipartRequestDecoder.class.getSimpleName() + " was destroyed already");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isMultipart() {
/*  230 */     checkDestroyed();
/*  231 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDiscardThreshold(int discardThreshold) {
/*  241 */     this.discardThreshold = ObjectUtil.checkPositiveOrZero(discardThreshold, "discardThreshold");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getDiscardThreshold() {
/*  249 */     return this.discardThreshold;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<InterfaceHttpData> getBodyHttpDatas() {
/*  264 */     checkDestroyed();
/*      */     
/*  266 */     if (!this.isLastChunk) {
/*  267 */       throw new HttpPostRequestDecoder.NotEnoughDataDecoderException();
/*      */     }
/*  269 */     return this.bodyListHttpData;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<InterfaceHttpData> getBodyHttpDatas(String name) {
/*  285 */     checkDestroyed();
/*      */     
/*  287 */     if (!this.isLastChunk) {
/*  288 */       throw new HttpPostRequestDecoder.NotEnoughDataDecoderException();
/*      */     }
/*  290 */     return this.bodyMapHttpData.get(name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InterfaceHttpData getBodyHttpData(String name) {
/*  307 */     checkDestroyed();
/*      */     
/*  309 */     if (!this.isLastChunk) {
/*  310 */       throw new HttpPostRequestDecoder.NotEnoughDataDecoderException();
/*      */     }
/*  312 */     List<InterfaceHttpData> list = this.bodyMapHttpData.get(name);
/*  313 */     if (list != null) {
/*  314 */       return list.get(0);
/*      */     }
/*  316 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpPostMultipartRequestDecoder offer(HttpContent content) {
/*  330 */     checkDestroyed();
/*      */     
/*  332 */     if (content instanceof io.netty.handler.codec.http.LastHttpContent) {
/*  333 */       this.isLastChunk = true;
/*      */     }
/*      */     
/*  336 */     ByteBuf buf = content.content();
/*  337 */     if (this.undecodedChunk == null) {
/*  338 */       this
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  343 */         .undecodedChunk = buf.alloc().buffer(buf.readableBytes()).writeBytes(buf);
/*      */     } else {
/*  345 */       this.undecodedChunk.writeBytes(buf);
/*      */     } 
/*  347 */     parseBody();
/*  348 */     if (this.undecodedChunk != null && this.undecodedChunk.writerIndex() > this.discardThreshold) {
/*  349 */       if (this.undecodedChunk.refCnt() == 1) {
/*      */         
/*  351 */         this.undecodedChunk.discardReadBytes();
/*      */       }
/*      */       else {
/*      */         
/*  355 */         ByteBuf buffer = this.undecodedChunk.alloc().buffer(this.undecodedChunk.readableBytes());
/*  356 */         buffer.writeBytes(this.undecodedChunk);
/*  357 */         this.undecodedChunk.release();
/*  358 */         this.undecodedChunk = buffer;
/*      */       } 
/*      */     }
/*  361 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hasNext() {
/*  376 */     checkDestroyed();
/*      */     
/*  378 */     if (this.currentStatus == HttpPostRequestDecoder.MultiPartStatus.EPILOGUE)
/*      */     {
/*  380 */       if (this.bodyListHttpDataRank >= this.bodyListHttpData.size()) {
/*  381 */         throw new HttpPostRequestDecoder.EndOfDataDecoderException();
/*      */       }
/*      */     }
/*  384 */     return (!this.bodyListHttpData.isEmpty() && this.bodyListHttpDataRank < this.bodyListHttpData.size());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InterfaceHttpData next() {
/*  401 */     checkDestroyed();
/*      */     
/*  403 */     if (hasNext()) {
/*  404 */       return this.bodyListHttpData.get(this.bodyListHttpDataRank++);
/*      */     }
/*  406 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public InterfaceHttpData currentPartialHttpData() {
/*  411 */     if (this.currentFileUpload != null) {
/*  412 */       return this.currentFileUpload;
/*      */     }
/*  414 */     return this.currentAttribute;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void parseBody() {
/*  426 */     if (this.currentStatus == HttpPostRequestDecoder.MultiPartStatus.PREEPILOGUE || this.currentStatus == HttpPostRequestDecoder.MultiPartStatus.EPILOGUE) {
/*  427 */       if (this.isLastChunk) {
/*  428 */         this.currentStatus = HttpPostRequestDecoder.MultiPartStatus.EPILOGUE;
/*      */       }
/*      */       return;
/*      */     } 
/*  432 */     parseBodyMultipart();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void addHttpData(InterfaceHttpData data) {
/*  439 */     if (data == null) {
/*      */       return;
/*      */     }
/*  442 */     List<InterfaceHttpData> datas = this.bodyMapHttpData.get(data.getName());
/*  443 */     if (datas == null) {
/*  444 */       datas = new ArrayList<InterfaceHttpData>(1);
/*  445 */       this.bodyMapHttpData.put(data.getName(), datas);
/*      */     } 
/*  447 */     datas.add(data);
/*  448 */     this.bodyListHttpData.add(data);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void parseBodyMultipart() {
/*  459 */     if (this.undecodedChunk == null || this.undecodedChunk.readableBytes() == 0) {
/*      */       return;
/*      */     }
/*      */     
/*  463 */     InterfaceHttpData data = decodeMultipart(this.currentStatus);
/*  464 */     while (data != null) {
/*  465 */       addHttpData(data);
/*  466 */       if (this.currentStatus == HttpPostRequestDecoder.MultiPartStatus.PREEPILOGUE || this.currentStatus == HttpPostRequestDecoder.MultiPartStatus.EPILOGUE) {
/*      */         break;
/*      */       }
/*  469 */       data = decodeMultipart(this.currentStatus);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private InterfaceHttpData decodeMultipart(HttpPostRequestDecoder.MultiPartStatus state) {
/*      */     Charset localCharset;
/*      */     Attribute charsetAttribute;
/*      */     Attribute nameAttribute;
/*      */     Attribute finalAttribute;
/*  490 */     switch (state) {
/*      */       case NOTSTARTED:
/*  492 */         throw new HttpPostRequestDecoder.ErrorDataDecoderException("Should not be called with the current getStatus");
/*      */       
/*      */       case PREAMBLE:
/*  495 */         throw new HttpPostRequestDecoder.ErrorDataDecoderException("Should not be called with the current getStatus");
/*      */       
/*      */       case HEADERDELIMITER:
/*  498 */         return findMultipartDelimiter(this.multipartDataBoundary, HttpPostRequestDecoder.MultiPartStatus.DISPOSITION, HttpPostRequestDecoder.MultiPartStatus.PREEPILOGUE);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case DISPOSITION:
/*  511 */         return findMultipartDisposition();
/*      */ 
/*      */       
/*      */       case FIELD:
/*  515 */         localCharset = null;
/*  516 */         charsetAttribute = this.currentFieldAttributes.get(HttpHeaderValues.CHARSET);
/*  517 */         if (charsetAttribute != null) {
/*      */           try {
/*  519 */             localCharset = Charset.forName(charsetAttribute.getValue());
/*  520 */           } catch (IOException e) {
/*  521 */             throw new HttpPostRequestDecoder.ErrorDataDecoderException(e);
/*  522 */           } catch (UnsupportedCharsetException e) {
/*  523 */             throw new HttpPostRequestDecoder.ErrorDataDecoderException(e);
/*      */           } 
/*      */         }
/*  526 */         nameAttribute = this.currentFieldAttributes.get(HttpHeaderValues.NAME);
/*  527 */         if (this.currentAttribute == null) {
/*      */           long size;
/*  529 */           Attribute lengthAttribute = this.currentFieldAttributes.get(HttpHeaderNames.CONTENT_LENGTH);
/*      */           
/*      */           try {
/*  532 */             size = (lengthAttribute != null) ? Long.parseLong(lengthAttribute
/*  533 */                 .getValue()) : 0L;
/*  534 */           } catch (IOException e) {
/*  535 */             throw new HttpPostRequestDecoder.ErrorDataDecoderException(e);
/*  536 */           } catch (NumberFormatException ignored) {
/*  537 */             size = 0L;
/*      */           } 
/*      */           try {
/*  540 */             if (size > 0L) {
/*  541 */               this.currentAttribute = this.factory.createAttribute(this.request, 
/*  542 */                   cleanString(nameAttribute.getValue()), size);
/*      */             } else {
/*  544 */               this.currentAttribute = this.factory.createAttribute(this.request, 
/*  545 */                   cleanString(nameAttribute.getValue()));
/*      */             } 
/*  547 */           } catch (NullPointerException e) {
/*  548 */             throw new HttpPostRequestDecoder.ErrorDataDecoderException(e);
/*  549 */           } catch (IllegalArgumentException e) {
/*  550 */             throw new HttpPostRequestDecoder.ErrorDataDecoderException(e);
/*  551 */           } catch (IOException e) {
/*  552 */             throw new HttpPostRequestDecoder.ErrorDataDecoderException(e);
/*      */           } 
/*  554 */           if (localCharset != null) {
/*  555 */             this.currentAttribute.setCharset(localCharset);
/*      */           }
/*      */         } 
/*      */         
/*  559 */         if (!loadDataMultipartOptimized(this.undecodedChunk, this.multipartDataBoundary, this.currentAttribute))
/*      */         {
/*  561 */           return null;
/*      */         }
/*  563 */         finalAttribute = this.currentAttribute;
/*  564 */         this.currentAttribute = null;
/*  565 */         this.currentFieldAttributes = null;
/*      */         
/*  567 */         this.currentStatus = HttpPostRequestDecoder.MultiPartStatus.HEADERDELIMITER;
/*  568 */         return finalAttribute;
/*      */ 
/*      */       
/*      */       case FILEUPLOAD:
/*  572 */         return getFileUpload(this.multipartDataBoundary);
/*      */ 
/*      */ 
/*      */       
/*      */       case MIXEDDELIMITER:
/*  577 */         return findMultipartDelimiter(this.multipartMixedBoundary, HttpPostRequestDecoder.MultiPartStatus.MIXEDDISPOSITION, HttpPostRequestDecoder.MultiPartStatus.HEADERDELIMITER);
/*      */ 
/*      */       
/*      */       case MIXEDDISPOSITION:
/*  581 */         return findMultipartDisposition();
/*      */ 
/*      */       
/*      */       case MIXEDFILEUPLOAD:
/*  585 */         return getFileUpload(this.multipartMixedBoundary);
/*      */       
/*      */       case PREEPILOGUE:
/*  588 */         return null;
/*      */       case EPILOGUE:
/*  590 */         return null;
/*      */     } 
/*  592 */     throw new HttpPostRequestDecoder.ErrorDataDecoderException("Shouldn't reach here.");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void skipControlCharacters(ByteBuf undecodedChunk) {
/*  602 */     if (!undecodedChunk.hasArray()) {
/*      */       try {
/*  604 */         skipControlCharactersStandard(undecodedChunk);
/*  605 */       } catch (IndexOutOfBoundsException e1) {
/*  606 */         throw new HttpPostRequestDecoder.NotEnoughDataDecoderException(e1);
/*      */       } 
/*      */       return;
/*      */     } 
/*  610 */     HttpPostBodyUtil.SeekAheadOptimize sao = new HttpPostBodyUtil.SeekAheadOptimize(undecodedChunk);
/*  611 */     while (sao.pos < sao.limit) {
/*  612 */       char c = (char)(sao.bytes[sao.pos++] & 0xFF);
/*  613 */       if (!Character.isISOControl(c) && !Character.isWhitespace(c)) {
/*  614 */         sao.setReadPosition(1);
/*      */         return;
/*      */       } 
/*      */     } 
/*  618 */     throw new HttpPostRequestDecoder.NotEnoughDataDecoderException("Access out of bounds");
/*      */   }
/*      */   
/*      */   private static void skipControlCharactersStandard(ByteBuf undecodedChunk) {
/*      */     while (true) {
/*  623 */       char c = (char)undecodedChunk.readUnsignedByte();
/*  624 */       if (!Character.isISOControl(c) && !Character.isWhitespace(c)) {
/*  625 */         undecodedChunk.readerIndex(undecodedChunk.readerIndex() - 1);
/*      */         return;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private InterfaceHttpData findMultipartDelimiter(String delimiter, HttpPostRequestDecoder.MultiPartStatus dispositionStatus, HttpPostRequestDecoder.MultiPartStatus closeDelimiterStatus) {
/*      */     String newline;
/*  646 */     int readerIndex = this.undecodedChunk.readerIndex();
/*      */     try {
/*  648 */       skipControlCharacters(this.undecodedChunk);
/*  649 */     } catch (NotEnoughDataDecoderException ignored) {
/*  650 */       this.undecodedChunk.readerIndex(readerIndex);
/*  651 */       return null;
/*      */     } 
/*  653 */     skipOneLine();
/*      */     
/*      */     try {
/*  656 */       newline = readDelimiterOptimized(this.undecodedChunk, delimiter, this.charset);
/*  657 */     } catch (NotEnoughDataDecoderException ignored) {
/*  658 */       this.undecodedChunk.readerIndex(readerIndex);
/*  659 */       return null;
/*      */     } 
/*  661 */     if (newline.equals(delimiter)) {
/*  662 */       this.currentStatus = dispositionStatus;
/*  663 */       return decodeMultipart(dispositionStatus);
/*      */     } 
/*  665 */     if (newline.equals(delimiter + "--")) {
/*      */       
/*  667 */       this.currentStatus = closeDelimiterStatus;
/*  668 */       if (this.currentStatus == HttpPostRequestDecoder.MultiPartStatus.HEADERDELIMITER) {
/*      */ 
/*      */         
/*  671 */         this.currentFieldAttributes = null;
/*  672 */         return decodeMultipart(HttpPostRequestDecoder.MultiPartStatus.HEADERDELIMITER);
/*      */       } 
/*  674 */       return null;
/*      */     } 
/*  676 */     this.undecodedChunk.readerIndex(readerIndex);
/*  677 */     throw new HttpPostRequestDecoder.ErrorDataDecoderException("No Multipart delimiter found");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private InterfaceHttpData findMultipartDisposition() {
/*  687 */     int readerIndex = this.undecodedChunk.readerIndex();
/*  688 */     if (this.currentStatus == HttpPostRequestDecoder.MultiPartStatus.DISPOSITION) {
/*  689 */       this.currentFieldAttributes = new TreeMap<CharSequence, Attribute>(CaseIgnoringComparator.INSTANCE);
/*      */     }
/*      */     
/*  692 */     while (!skipOneLine()) {
/*      */       String newline;
/*      */       try {
/*  695 */         skipControlCharacters(this.undecodedChunk);
/*  696 */         newline = readLineOptimized(this.undecodedChunk, this.charset);
/*  697 */       } catch (NotEnoughDataDecoderException ignored) {
/*  698 */         this.undecodedChunk.readerIndex(readerIndex);
/*  699 */         return null;
/*      */       } 
/*  701 */       String[] contents = splitMultipartHeader(newline);
/*  702 */       if (HttpHeaderNames.CONTENT_DISPOSITION.contentEqualsIgnoreCase(contents[0])) {
/*      */         boolean checkSecondArg;
/*  704 */         if (this.currentStatus == HttpPostRequestDecoder.MultiPartStatus.DISPOSITION) {
/*  705 */           checkSecondArg = HttpHeaderValues.FORM_DATA.contentEqualsIgnoreCase(contents[1]);
/*      */         } else {
/*      */           
/*  708 */           checkSecondArg = (HttpHeaderValues.ATTACHMENT.contentEqualsIgnoreCase(contents[1]) || HttpHeaderValues.FILE.contentEqualsIgnoreCase(contents[1]));
/*      */         } 
/*  710 */         if (checkSecondArg)
/*      */         {
/*  712 */           for (int i = 2; i < contents.length; i++) {
/*  713 */             Attribute attribute; String[] values = contents[i].split("=", 2);
/*      */             
/*      */             try {
/*  716 */               attribute = getContentDispositionAttribute(values);
/*  717 */             } catch (NullPointerException e) {
/*  718 */               throw new HttpPostRequestDecoder.ErrorDataDecoderException(e);
/*  719 */             } catch (IllegalArgumentException e) {
/*  720 */               throw new HttpPostRequestDecoder.ErrorDataDecoderException(e);
/*      */             } 
/*  722 */             this.currentFieldAttributes.put(attribute.getName(), attribute);
/*      */           }  }  continue;
/*      */       } 
/*  725 */       if (HttpHeaderNames.CONTENT_TRANSFER_ENCODING.contentEqualsIgnoreCase(contents[0])) {
/*      */         Attribute attribute;
/*      */         try {
/*  728 */           attribute = this.factory.createAttribute(this.request, HttpHeaderNames.CONTENT_TRANSFER_ENCODING.toString(), 
/*  729 */               cleanString(contents[1]));
/*  730 */         } catch (NullPointerException e) {
/*  731 */           throw new HttpPostRequestDecoder.ErrorDataDecoderException(e);
/*  732 */         } catch (IllegalArgumentException e) {
/*  733 */           throw new HttpPostRequestDecoder.ErrorDataDecoderException(e);
/*      */         } 
/*      */         
/*  736 */         this.currentFieldAttributes.put(HttpHeaderNames.CONTENT_TRANSFER_ENCODING, attribute); continue;
/*  737 */       }  if (HttpHeaderNames.CONTENT_LENGTH.contentEqualsIgnoreCase(contents[0])) {
/*      */         Attribute attribute;
/*      */         try {
/*  740 */           attribute = this.factory.createAttribute(this.request, HttpHeaderNames.CONTENT_LENGTH.toString(), 
/*  741 */               cleanString(contents[1]));
/*  742 */         } catch (NullPointerException e) {
/*  743 */           throw new HttpPostRequestDecoder.ErrorDataDecoderException(e);
/*  744 */         } catch (IllegalArgumentException e) {
/*  745 */           throw new HttpPostRequestDecoder.ErrorDataDecoderException(e);
/*      */         } 
/*      */         
/*  748 */         this.currentFieldAttributes.put(HttpHeaderNames.CONTENT_LENGTH, attribute); continue;
/*  749 */       }  if (HttpHeaderNames.CONTENT_TYPE.contentEqualsIgnoreCase(contents[0])) {
/*      */         
/*  751 */         if (HttpHeaderValues.MULTIPART_MIXED.contentEqualsIgnoreCase(contents[1])) {
/*  752 */           if (this.currentStatus == HttpPostRequestDecoder.MultiPartStatus.DISPOSITION) {
/*  753 */             String values = StringUtil.substringAfter(contents[2], '=');
/*  754 */             this.multipartMixedBoundary = "--" + values;
/*  755 */             this.currentStatus = HttpPostRequestDecoder.MultiPartStatus.MIXEDDELIMITER;
/*  756 */             return decodeMultipart(HttpPostRequestDecoder.MultiPartStatus.MIXEDDELIMITER);
/*      */           } 
/*  758 */           throw new HttpPostRequestDecoder.ErrorDataDecoderException("Mixed Multipart found in a previous Mixed Multipart");
/*      */         } 
/*      */         
/*  761 */         for (int i = 1; i < contents.length; i++) {
/*  762 */           String charsetHeader = HttpHeaderValues.CHARSET.toString();
/*  763 */           if (contents[i].regionMatches(true, 0, charsetHeader, 0, charsetHeader.length())) {
/*  764 */             Attribute attribute; String values = StringUtil.substringAfter(contents[i], '=');
/*      */             
/*      */             try {
/*  767 */               attribute = this.factory.createAttribute(this.request, charsetHeader, cleanString(values));
/*  768 */             } catch (NullPointerException e) {
/*  769 */               throw new HttpPostRequestDecoder.ErrorDataDecoderException(e);
/*  770 */             } catch (IllegalArgumentException e) {
/*  771 */               throw new HttpPostRequestDecoder.ErrorDataDecoderException(e);
/*      */             } 
/*  773 */             this.currentFieldAttributes.put(HttpHeaderValues.CHARSET, attribute);
/*  774 */           } else if (contents[i].contains("=")) {
/*  775 */             Attribute attribute; String name = StringUtil.substringBefore(contents[i], '=');
/*  776 */             String values = StringUtil.substringAfter(contents[i], '=');
/*      */             
/*      */             try {
/*  779 */               attribute = this.factory.createAttribute(this.request, cleanString(name), values);
/*  780 */             } catch (NullPointerException e) {
/*  781 */               throw new HttpPostRequestDecoder.ErrorDataDecoderException(e);
/*  782 */             } catch (IllegalArgumentException e) {
/*  783 */               throw new HttpPostRequestDecoder.ErrorDataDecoderException(e);
/*      */             } 
/*  785 */             this.currentFieldAttributes.put(name, attribute);
/*      */           } else {
/*      */             Attribute attribute;
/*      */             try {
/*  789 */               attribute = this.factory.createAttribute(this.request, 
/*  790 */                   cleanString(contents[0]), contents[i]);
/*  791 */             } catch (NullPointerException e) {
/*  792 */               Attribute attribute1; throw new HttpPostRequestDecoder.ErrorDataDecoderException(attribute1);
/*  793 */             } catch (IllegalArgumentException e) {
/*  794 */               Attribute attribute1; throw new HttpPostRequestDecoder.ErrorDataDecoderException(attribute1);
/*      */             } 
/*  796 */             this.currentFieldAttributes.put(attribute.getName(), attribute);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  803 */     Attribute filenameAttribute = this.currentFieldAttributes.get(HttpHeaderValues.FILENAME);
/*  804 */     if (this.currentStatus == HttpPostRequestDecoder.MultiPartStatus.DISPOSITION) {
/*  805 */       if (filenameAttribute != null) {
/*      */         
/*  807 */         this.currentStatus = HttpPostRequestDecoder.MultiPartStatus.FILEUPLOAD;
/*      */         
/*  809 */         return decodeMultipart(HttpPostRequestDecoder.MultiPartStatus.FILEUPLOAD);
/*      */       } 
/*      */       
/*  812 */       this.currentStatus = HttpPostRequestDecoder.MultiPartStatus.FIELD;
/*      */       
/*  814 */       return decodeMultipart(HttpPostRequestDecoder.MultiPartStatus.FIELD);
/*      */     } 
/*      */     
/*  817 */     if (filenameAttribute != null) {
/*      */       
/*  819 */       this.currentStatus = HttpPostRequestDecoder.MultiPartStatus.MIXEDFILEUPLOAD;
/*      */       
/*  821 */       return decodeMultipart(HttpPostRequestDecoder.MultiPartStatus.MIXEDFILEUPLOAD);
/*      */     } 
/*      */     
/*  824 */     throw new HttpPostRequestDecoder.ErrorDataDecoderException("Filename not found");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*  829 */   private static final String FILENAME_ENCODED = HttpHeaderValues.FILENAME.toString() + '*';
/*      */   
/*      */   private Attribute getContentDispositionAttribute(String... values) {
/*  832 */     String name = cleanString(values[0]);
/*  833 */     String value = values[1];
/*      */ 
/*      */     
/*  836 */     if (HttpHeaderValues.FILENAME.contentEquals(name)) {
/*      */       
/*  838 */       int last = value.length() - 1;
/*  839 */       if (last > 0 && value
/*  840 */         .charAt(0) == '"' && value
/*  841 */         .charAt(last) == '"') {
/*  842 */         value = value.substring(1, last);
/*      */       }
/*  844 */     } else if (FILENAME_ENCODED.equals(name)) {
/*      */       try {
/*  846 */         name = HttpHeaderValues.FILENAME.toString();
/*  847 */         String[] split = cleanString(value).split("'", 3);
/*  848 */         value = QueryStringDecoder.decodeComponent(split[2], Charset.forName(split[0]));
/*  849 */       } catch (ArrayIndexOutOfBoundsException e) {
/*  850 */         throw new HttpPostRequestDecoder.ErrorDataDecoderException(e);
/*  851 */       } catch (UnsupportedCharsetException e) {
/*  852 */         throw new HttpPostRequestDecoder.ErrorDataDecoderException(e);
/*      */       } 
/*      */     } else {
/*      */       
/*  856 */       value = cleanString(value);
/*      */     } 
/*  858 */     return this.factory.createAttribute(this.request, name, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected InterfaceHttpData getFileUpload(String delimiter) {
/*  872 */     Attribute encoding = this.currentFieldAttributes.get(HttpHeaderNames.CONTENT_TRANSFER_ENCODING);
/*  873 */     Charset localCharset = this.charset;
/*      */     
/*  875 */     HttpPostBodyUtil.TransferEncodingMechanism mechanism = HttpPostBodyUtil.TransferEncodingMechanism.BIT7;
/*  876 */     if (encoding != null) {
/*      */       String code;
/*      */       try {
/*  879 */         code = encoding.getValue().toLowerCase();
/*  880 */       } catch (IOException e) {
/*  881 */         throw new HttpPostRequestDecoder.ErrorDataDecoderException(e);
/*      */       } 
/*  883 */       if (code.equals(HttpPostBodyUtil.TransferEncodingMechanism.BIT7.value())) {
/*  884 */         localCharset = CharsetUtil.US_ASCII;
/*  885 */       } else if (code.equals(HttpPostBodyUtil.TransferEncodingMechanism.BIT8.value())) {
/*  886 */         localCharset = CharsetUtil.ISO_8859_1;
/*  887 */         mechanism = HttpPostBodyUtil.TransferEncodingMechanism.BIT8;
/*  888 */       } else if (code.equals(HttpPostBodyUtil.TransferEncodingMechanism.BINARY.value())) {
/*      */         
/*  890 */         mechanism = HttpPostBodyUtil.TransferEncodingMechanism.BINARY;
/*      */       } else {
/*  892 */         throw new HttpPostRequestDecoder.ErrorDataDecoderException("TransferEncoding Unknown: " + code);
/*      */       } 
/*      */     } 
/*  895 */     Attribute charsetAttribute = this.currentFieldAttributes.get(HttpHeaderValues.CHARSET);
/*  896 */     if (charsetAttribute != null) {
/*      */       try {
/*  898 */         localCharset = Charset.forName(charsetAttribute.getValue());
/*  899 */       } catch (IOException e) {
/*  900 */         throw new HttpPostRequestDecoder.ErrorDataDecoderException(e);
/*  901 */       } catch (UnsupportedCharsetException e) {
/*  902 */         throw new HttpPostRequestDecoder.ErrorDataDecoderException(e);
/*      */       } 
/*      */     }
/*  905 */     if (this.currentFileUpload == null) {
/*  906 */       long size; Attribute filenameAttribute = this.currentFieldAttributes.get(HttpHeaderValues.FILENAME);
/*  907 */       Attribute nameAttribute = this.currentFieldAttributes.get(HttpHeaderValues.NAME);
/*  908 */       Attribute contentTypeAttribute = this.currentFieldAttributes.get(HttpHeaderNames.CONTENT_TYPE);
/*  909 */       Attribute lengthAttribute = this.currentFieldAttributes.get(HttpHeaderNames.CONTENT_LENGTH);
/*      */       
/*      */       try {
/*  912 */         size = (lengthAttribute != null) ? Long.parseLong(lengthAttribute.getValue()) : 0L;
/*  913 */       } catch (IOException e) {
/*  914 */         throw new HttpPostRequestDecoder.ErrorDataDecoderException(e);
/*  915 */       } catch (NumberFormatException ignored) {
/*  916 */         size = 0L;
/*      */       } 
/*      */       try {
/*      */         String contentType;
/*  920 */         if (contentTypeAttribute != null) {
/*  921 */           contentType = contentTypeAttribute.getValue();
/*      */         } else {
/*  923 */           contentType = "application/octet-stream";
/*      */         } 
/*  925 */         this.currentFileUpload = this.factory.createFileUpload(this.request, 
/*  926 */             cleanString(nameAttribute.getValue()), cleanString(filenameAttribute.getValue()), contentType, mechanism
/*  927 */             .value(), localCharset, size);
/*      */       }
/*  929 */       catch (NullPointerException e) {
/*  930 */         throw new HttpPostRequestDecoder.ErrorDataDecoderException(e);
/*  931 */       } catch (IllegalArgumentException e) {
/*  932 */         throw new HttpPostRequestDecoder.ErrorDataDecoderException(e);
/*  933 */       } catch (IOException e) {
/*  934 */         throw new HttpPostRequestDecoder.ErrorDataDecoderException(e);
/*      */       } 
/*      */     } 
/*      */     
/*  938 */     if (!loadDataMultipartOptimized(this.undecodedChunk, delimiter, this.currentFileUpload))
/*      */     {
/*  940 */       return null;
/*      */     }
/*  942 */     if (this.currentFileUpload.isCompleted()) {
/*      */       
/*  944 */       if (this.currentStatus == HttpPostRequestDecoder.MultiPartStatus.FILEUPLOAD) {
/*  945 */         this.currentStatus = HttpPostRequestDecoder.MultiPartStatus.HEADERDELIMITER;
/*  946 */         this.currentFieldAttributes = null;
/*      */       } else {
/*  948 */         this.currentStatus = HttpPostRequestDecoder.MultiPartStatus.MIXEDDELIMITER;
/*  949 */         cleanMixedAttributes();
/*      */       } 
/*  951 */       FileUpload fileUpload = this.currentFileUpload;
/*  952 */       this.currentFileUpload = null;
/*  953 */       return fileUpload;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  958 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void destroy() {
/*  968 */     cleanFiles();
/*      */     
/*  970 */     for (InterfaceHttpData httpData : this.bodyListHttpData) {
/*      */       
/*  972 */       if (httpData.refCnt() > 0) {
/*  973 */         httpData.release();
/*      */       }
/*      */     } 
/*      */     
/*  977 */     this.destroyed = true;
/*      */     
/*  979 */     if (this.undecodedChunk != null && this.undecodedChunk.refCnt() > 0) {
/*  980 */       this.undecodedChunk.release();
/*  981 */       this.undecodedChunk = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void cleanFiles() {
/*  990 */     checkDestroyed();
/*      */     
/*  992 */     this.factory.cleanRequestHttpData(this.request);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeHttpDataFromClean(InterfaceHttpData data) {
/* 1000 */     checkDestroyed();
/*      */     
/* 1002 */     this.factory.removeHttpDataFromClean(this.request, data);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void cleanMixedAttributes() {
/* 1010 */     this.currentFieldAttributes.remove(HttpHeaderValues.CHARSET);
/* 1011 */     this.currentFieldAttributes.remove(HttpHeaderNames.CONTENT_LENGTH);
/* 1012 */     this.currentFieldAttributes.remove(HttpHeaderNames.CONTENT_TRANSFER_ENCODING);
/* 1013 */     this.currentFieldAttributes.remove(HttpHeaderNames.CONTENT_TYPE);
/* 1014 */     this.currentFieldAttributes.remove(HttpHeaderValues.FILENAME);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String readLineOptimized(ByteBuf undecodedChunk, Charset charset) {
/* 1026 */     int readerIndex = undecodedChunk.readerIndex();
/* 1027 */     ByteBuf line = null;
/*      */     try {
/* 1029 */       if (undecodedChunk.isReadable()) {
/* 1030 */         int posLfOrCrLf = HttpPostBodyUtil.findLineBreak(undecodedChunk, undecodedChunk.readerIndex());
/* 1031 */         if (posLfOrCrLf <= 0) {
/* 1032 */           throw new HttpPostRequestDecoder.NotEnoughDataDecoderException();
/*      */         }
/*      */         try {
/* 1035 */           line = undecodedChunk.alloc().heapBuffer(posLfOrCrLf);
/* 1036 */           line.writeBytes(undecodedChunk, posLfOrCrLf);
/*      */           
/* 1038 */           byte nextByte = undecodedChunk.readByte();
/* 1039 */           if (nextByte == 13)
/*      */           {
/* 1041 */             undecodedChunk.readByte();
/*      */           }
/* 1043 */           return line.toString(charset);
/*      */         } finally {
/* 1045 */           line.release();
/*      */         } 
/*      */       } 
/* 1048 */     } catch (IndexOutOfBoundsException e) {
/* 1049 */       undecodedChunk.readerIndex(readerIndex);
/* 1050 */       throw new HttpPostRequestDecoder.NotEnoughDataDecoderException(e);
/*      */     } 
/* 1052 */     undecodedChunk.readerIndex(readerIndex);
/* 1053 */     throw new HttpPostRequestDecoder.NotEnoughDataDecoderException();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String readDelimiterOptimized(ByteBuf undecodedChunk, String delimiter, Charset charset) {
/* 1072 */     int readerIndex = undecodedChunk.readerIndex();
/* 1073 */     byte[] bdelimiter = delimiter.getBytes(charset);
/* 1074 */     int delimiterLength = bdelimiter.length;
/*      */     try {
/* 1076 */       int delimiterPos = HttpPostBodyUtil.findDelimiter(undecodedChunk, readerIndex, bdelimiter, false);
/* 1077 */       if (delimiterPos < 0) {
/*      */         
/* 1079 */         undecodedChunk.readerIndex(readerIndex);
/* 1080 */         throw new HttpPostRequestDecoder.NotEnoughDataDecoderException();
/*      */       } 
/* 1082 */       StringBuilder sb = new StringBuilder(delimiter);
/* 1083 */       undecodedChunk.readerIndex(readerIndex + delimiterPos + delimiterLength);
/*      */       
/* 1085 */       if (undecodedChunk.isReadable()) {
/* 1086 */         byte nextByte = undecodedChunk.readByte();
/*      */         
/* 1088 */         if (nextByte == 13) {
/* 1089 */           nextByte = undecodedChunk.readByte();
/* 1090 */           if (nextByte == 10) {
/* 1091 */             return sb.toString();
/*      */           }
/*      */ 
/*      */           
/* 1095 */           undecodedChunk.readerIndex(readerIndex);
/* 1096 */           throw new HttpPostRequestDecoder.NotEnoughDataDecoderException();
/*      */         } 
/* 1098 */         if (nextByte == 10)
/* 1099 */           return sb.toString(); 
/* 1100 */         if (nextByte == 45) {
/* 1101 */           sb.append('-');
/*      */           
/* 1103 */           nextByte = undecodedChunk.readByte();
/* 1104 */           if (nextByte == 45) {
/* 1105 */             sb.append('-');
/*      */             
/* 1107 */             if (undecodedChunk.isReadable()) {
/* 1108 */               nextByte = undecodedChunk.readByte();
/* 1109 */               if (nextByte == 13) {
/* 1110 */                 nextByte = undecodedChunk.readByte();
/* 1111 */                 if (nextByte == 10) {
/* 1112 */                   return sb.toString();
/*      */                 }
/*      */ 
/*      */                 
/* 1116 */                 undecodedChunk.readerIndex(readerIndex);
/* 1117 */                 throw new HttpPostRequestDecoder.NotEnoughDataDecoderException();
/*      */               } 
/* 1119 */               if (nextByte == 10) {
/* 1120 */                 return sb.toString();
/*      */               }
/*      */ 
/*      */ 
/*      */               
/* 1125 */               undecodedChunk.readerIndex(undecodedChunk.readerIndex() - 1);
/* 1126 */               return sb.toString();
/*      */             } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1133 */             return sb.toString();
/*      */           }
/*      */         
/*      */         }
/*      */       
/*      */       } 
/* 1139 */     } catch (IndexOutOfBoundsException e) {
/* 1140 */       undecodedChunk.readerIndex(readerIndex);
/* 1141 */       throw new HttpPostRequestDecoder.NotEnoughDataDecoderException(e);
/*      */     } 
/* 1143 */     undecodedChunk.readerIndex(readerIndex);
/* 1144 */     throw new HttpPostRequestDecoder.NotEnoughDataDecoderException();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void rewriteCurrentBuffer(ByteBuf buffer, int lengthToSkip) {
/* 1157 */     if (lengthToSkip == 0) {
/*      */       return;
/*      */     }
/* 1160 */     int readerIndex = buffer.readerIndex();
/* 1161 */     int readableBytes = buffer.readableBytes();
/* 1162 */     if (readableBytes == lengthToSkip) {
/* 1163 */       buffer.readerIndex(readerIndex);
/* 1164 */       buffer.writerIndex(readerIndex);
/*      */       return;
/*      */     } 
/* 1167 */     buffer.setBytes(readerIndex, buffer, readerIndex + lengthToSkip, readableBytes - lengthToSkip);
/* 1168 */     buffer.readerIndex(readerIndex);
/* 1169 */     buffer.writerIndex(readerIndex + readableBytes - lengthToSkip);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean loadDataMultipartOptimized(ByteBuf undecodedChunk, String delimiter, HttpData httpData) {
/* 1179 */     if (!undecodedChunk.isReadable()) {
/* 1180 */       return false;
/*      */     }
/* 1182 */     int startReaderIndex = undecodedChunk.readerIndex();
/* 1183 */     byte[] bdelimiter = delimiter.getBytes(httpData.getCharset());
/* 1184 */     int posDelimiter = HttpPostBodyUtil.findDelimiter(undecodedChunk, startReaderIndex, bdelimiter, true);
/* 1185 */     if (posDelimiter < 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1190 */       int readableBytes = undecodedChunk.readableBytes();
/* 1191 */       int lastPosition = readableBytes - bdelimiter.length - 1;
/* 1192 */       if (lastPosition < 0)
/*      */       {
/* 1194 */         lastPosition = 0;
/*      */       }
/* 1196 */       posDelimiter = HttpPostBodyUtil.findLastLineBreak(undecodedChunk, startReaderIndex + lastPosition);
/*      */ 
/*      */       
/* 1199 */       if (posDelimiter < 0 && httpData
/* 1200 */         .definedLength() == httpData.length() + readableBytes - 1L && undecodedChunk
/* 1201 */         .getByte(readableBytes + startReaderIndex - 1) == 13) {
/*      */         
/* 1203 */         lastPosition = 0;
/* 1204 */         posDelimiter = readableBytes - 1;
/*      */       } 
/* 1206 */       if (posDelimiter < 0) {
/*      */         
/* 1208 */         ByteBuf byteBuf1 = undecodedChunk.copy();
/*      */         try {
/* 1210 */           httpData.addContent(byteBuf1, false);
/* 1211 */         } catch (IOException e) {
/* 1212 */           throw new HttpPostRequestDecoder.ErrorDataDecoderException(e);
/*      */         } 
/* 1214 */         undecodedChunk.readerIndex(startReaderIndex);
/* 1215 */         undecodedChunk.writerIndex(startReaderIndex);
/* 1216 */         return false;
/*      */       } 
/*      */       
/* 1219 */       posDelimiter += lastPosition;
/* 1220 */       if (posDelimiter == 0)
/*      */       {
/* 1222 */         return false;
/*      */       }
/*      */       
/* 1225 */       ByteBuf byteBuf = undecodedChunk.copy(startReaderIndex, posDelimiter);
/*      */       try {
/* 1227 */         httpData.addContent(byteBuf, false);
/* 1228 */       } catch (IOException e) {
/* 1229 */         throw new HttpPostRequestDecoder.ErrorDataDecoderException(e);
/*      */       } 
/* 1231 */       rewriteCurrentBuffer(undecodedChunk, posDelimiter);
/* 1232 */       return false;
/*      */     } 
/*      */     
/* 1235 */     ByteBuf content = undecodedChunk.copy(startReaderIndex, posDelimiter);
/*      */     try {
/* 1237 */       httpData.addContent(content, true);
/* 1238 */     } catch (IOException e) {
/* 1239 */       throw new HttpPostRequestDecoder.ErrorDataDecoderException(e);
/*      */     } 
/* 1241 */     rewriteCurrentBuffer(undecodedChunk, posDelimiter);
/* 1242 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String cleanString(String field) {
/* 1251 */     int size = field.length();
/* 1252 */     StringBuilder sb = new StringBuilder(size);
/* 1253 */     for (int i = 0; i < size; i++) {
/* 1254 */       char nextChar = field.charAt(i);
/* 1255 */       switch (nextChar) {
/*      */         case '\t':
/*      */         case ',':
/*      */         case ':':
/*      */         case ';':
/*      */         case '=':
/* 1261 */           sb.append(' ');
/*      */           break;
/*      */         
/*      */         case '"':
/*      */           break;
/*      */         default:
/* 1267 */           sb.append(nextChar);
/*      */           break;
/*      */       } 
/*      */     } 
/* 1271 */     return sb.toString().trim();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean skipOneLine() {
/* 1280 */     if (!this.undecodedChunk.isReadable()) {
/* 1281 */       return false;
/*      */     }
/* 1283 */     byte nextByte = this.undecodedChunk.readByte();
/* 1284 */     if (nextByte == 13) {
/* 1285 */       if (!this.undecodedChunk.isReadable()) {
/* 1286 */         this.undecodedChunk.readerIndex(this.undecodedChunk.readerIndex() - 1);
/* 1287 */         return false;
/*      */       } 
/* 1289 */       nextByte = this.undecodedChunk.readByte();
/* 1290 */       if (nextByte == 10) {
/* 1291 */         return true;
/*      */       }
/* 1293 */       this.undecodedChunk.readerIndex(this.undecodedChunk.readerIndex() - 2);
/* 1294 */       return false;
/*      */     } 
/* 1296 */     if (nextByte == 10) {
/* 1297 */       return true;
/*      */     }
/* 1299 */     this.undecodedChunk.readerIndex(this.undecodedChunk.readerIndex() - 1);
/* 1300 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String[] splitMultipartHeader(String sb) {
/*      */     String[] values;
/* 1310 */     ArrayList<String> headers = new ArrayList<String>(1);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1316 */     int nameStart = HttpPostBodyUtil.findNonWhitespace(sb, 0); int nameEnd;
/* 1317 */     for (nameEnd = nameStart; nameEnd < sb.length(); nameEnd++) {
/* 1318 */       char ch = sb.charAt(nameEnd);
/* 1319 */       if (ch == ':' || Character.isWhitespace(ch))
/*      */         break; 
/*      */     } 
/*      */     int colonEnd;
/* 1323 */     for (colonEnd = nameEnd; colonEnd < sb.length(); colonEnd++) {
/* 1324 */       if (sb.charAt(colonEnd) == ':') {
/* 1325 */         colonEnd++;
/*      */         break;
/*      */       } 
/*      */     } 
/* 1329 */     int valueStart = HttpPostBodyUtil.findNonWhitespace(sb, colonEnd);
/* 1330 */     int valueEnd = HttpPostBodyUtil.findEndOfString(sb);
/* 1331 */     headers.add(sb.substring(nameStart, nameEnd));
/* 1332 */     String svalue = (valueStart >= valueEnd) ? "" : sb.substring(valueStart, valueEnd);
/*      */     
/* 1334 */     if (svalue.indexOf(';') >= 0) {
/* 1335 */       values = splitMultipartHeaderValues(svalue);
/*      */     } else {
/* 1337 */       values = svalue.split(",");
/*      */     } 
/* 1339 */     for (String value : values) {
/* 1340 */       headers.add(value.trim());
/*      */     }
/* 1342 */     String[] array = new String[headers.size()];
/* 1343 */     for (int i = 0; i < headers.size(); i++) {
/* 1344 */       array[i] = headers.get(i);
/*      */     }
/* 1346 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String[] splitMultipartHeaderValues(String svalue) {
/* 1354 */     List<String> values = InternalThreadLocalMap.get().arrayList(1);
/* 1355 */     boolean inQuote = false;
/* 1356 */     boolean escapeNext = false;
/* 1357 */     int start = 0;
/* 1358 */     for (int i = 0; i < svalue.length(); i++) {
/* 1359 */       char c = svalue.charAt(i);
/* 1360 */       if (inQuote) {
/* 1361 */         if (escapeNext) {
/* 1362 */           escapeNext = false;
/*      */         }
/* 1364 */         else if (c == '\\') {
/* 1365 */           escapeNext = true;
/* 1366 */         } else if (c == '"') {
/* 1367 */           inQuote = false;
/*      */         }
/*      */       
/*      */       }
/* 1371 */       else if (c == '"') {
/* 1372 */         inQuote = true;
/* 1373 */       } else if (c == ';') {
/* 1374 */         values.add(svalue.substring(start, i));
/* 1375 */         start = i + 1;
/*      */       } 
/*      */     } 
/*      */     
/* 1379 */     values.add(svalue.substring(start));
/* 1380 */     return values.<String>toArray(new String[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int getCurrentAllocatedCapacity() {
/* 1391 */     return this.undecodedChunk.capacity();
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http-4.1.93.Final.jar!\io\netty\handler\codec\http\multipart\HttpPostMultipartRequestDecoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */