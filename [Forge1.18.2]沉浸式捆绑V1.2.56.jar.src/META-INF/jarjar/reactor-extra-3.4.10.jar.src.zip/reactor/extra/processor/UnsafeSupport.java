/*     */ package reactor.extra.processor;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ import java.nio.Buffer;
/*     */ import java.nio.ByteBuffer;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.Loggers;
/*     */ import sun.misc.Unsafe;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ enum UnsafeSupport
/*     */ {
/*     */   static final Logger logger;
/*     */   private static final Unsafe UNSAFE;
/*     */   
/*     */   static {
/*     */     Unsafe unsafe;
/*     */     Object maybeUnsafe;
/*     */   }
/*     */   
/*     */   static {
/* 519 */     logger = Loggers.getLogger(UnsafeSupport.class);
/*     */ 
/*     */     
/* 522 */     String javaSpecVersion = System.getProperty("java.specification.version");
/* 523 */     logger.debug("Starting UnsafeSupport init in Java " + javaSpecVersion);
/*     */     
/* 525 */     ByteBuffer direct = ByteBuffer.allocateDirect(1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 532 */       Field unsafeField = Unsafe.class.getDeclaredField("theUnsafe");
/* 533 */       unsafeField.setAccessible(true);
/*     */       
/* 535 */       maybeUnsafe = unsafeField.get(null);
/* 536 */     } catch (NoSuchFieldException|SecurityException|IllegalAccessException e) {
/* 537 */       maybeUnsafe = e;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 544 */     if (maybeUnsafe instanceof Throwable) {
/* 545 */       unsafe = null;
/* 546 */       logger.debug("Unsafe unavailable - Could not get it via Field sun.misc.Unsafe.theUnsafe", (Throwable)maybeUnsafe);
/*     */     } else {
/* 548 */       unsafe = (Unsafe)maybeUnsafe;
/* 549 */       logger.trace("sun.misc.Unsafe.theUnsafe ok");
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 555 */     if (unsafe != null) {
/* 556 */       Object maybeException; Unsafe finalUnsafe = unsafe;
/*     */       
/*     */       try {
/* 559 */         finalUnsafe.getClass().getDeclaredMethod("copyMemory", new Class[] { Object.class, long.class, Object.class, long.class, long.class });
/*     */         
/* 561 */         maybeException = null;
/* 562 */       } catch (NoSuchMethodException|SecurityException e) {
/* 563 */         maybeException = e;
/*     */       } 
/*     */       
/* 566 */       if (maybeException == null) {
/* 567 */         logger.trace("sun.misc.Unsafe.copyMemory ok");
/*     */       } else {
/* 569 */         unsafe = null;
/* 570 */         logger.debug("Unsafe unavailable - failed on sun.misc.Unsafe.copyMemory", (Throwable)maybeException);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 575 */     if (unsafe != null) {
/* 576 */       Object maybeAddressField; Unsafe finalUnsafe = unsafe;
/*     */       
/*     */       try {
/* 579 */         Field field = Buffer.class.getDeclaredField("address");
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 584 */         long offset = finalUnsafe.objectFieldOffset(field);
/* 585 */         long heapAddress = finalUnsafe.getLong(ByteBuffer.allocate(1), offset);
/* 586 */         long directAddress = finalUnsafe.getLong(direct, offset);
/*     */         
/* 588 */         if (heapAddress != 0L && "1.8".equals(javaSpecVersion)) {
/* 589 */           maybeAddressField = new IllegalStateException("A heap buffer must have 0 address in Java 8, got " + heapAddress);
/*     */         }
/* 591 */         else if (heapAddress == 0L && !"1.8".equals(javaSpecVersion)) {
/* 592 */           maybeAddressField = new IllegalStateException("A heap buffer must have non-zero address in Java " + javaSpecVersion);
/*     */         }
/* 594 */         else if (directAddress == 0L) {
/* 595 */           maybeAddressField = new IllegalStateException("A direct buffer must have non-zero address");
/*     */         } else {
/*     */           
/* 598 */           maybeAddressField = field;
/*     */         }
/*     */       
/* 601 */       } catch (NoSuchFieldException|SecurityException e) {
/* 602 */         maybeAddressField = e;
/*     */       } 
/*     */       
/* 605 */       if (maybeAddressField instanceof Throwable) {
/* 606 */         logger.debug("Unsafe unavailable - failed on java.nio.Buffer.address", (Throwable)maybeAddressField);
/*     */ 
/*     */ 
/*     */         
/* 610 */         unsafe = null;
/*     */       } else {
/*     */         
/* 613 */         logger.trace("java.nio.Buffer.address ok");
/* 614 */         logger.debug("Unsafe is available");
/*     */       } 
/*     */     } 
/*     */     
/* 618 */     UNSAFE = unsafe;
/*     */   }
/*     */   
/*     */   static Unsafe getUnsafe() {
/* 622 */     return UNSAFE;
/*     */   }
/*     */   
/*     */   static boolean hasUnsafe() {
/* 626 */     return (UNSAFE != null);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-extra-3.4.10.jar!\reactor\extra\processor\UnsafeSupport.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */