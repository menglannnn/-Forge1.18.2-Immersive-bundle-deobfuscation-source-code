/*     */ package reactor.extra.processor;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.RejectedExecutionException;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import java.util.concurrent.locks.LockSupport;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.stream.Stream;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Operators;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.concurrent.Queues;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public final class TopicProcessor<E>
/*     */   extends EventLoopProcessor<E>
/*     */ {
/*     */   final RingBuffer.Reader barrier;
/*     */   final RingBuffer.Sequence minimum;
/*     */   
/*     */   public static final class Builder<T>
/*     */   {
/*  97 */     int bufferSize = Queues.SMALL_BUFFER_SIZE;
/*     */     
/*     */     boolean autoCancel = true;
/*     */     
/*     */     boolean share = false;
/*     */     
/*     */     String name;
/*     */     ExecutorService executor;
/*     */     ExecutorService requestTaskExecutor;
/*     */     WaitStrategy waitStrategy;
/*     */     Supplier<T> signalSupplier;
/*     */     
/*     */     public Builder<T> name(@Nullable String name) {
/* 110 */       if (this.executor != null)
/* 111 */         throw new IllegalArgumentException("Executor service is configured, name will not be used."); 
/* 112 */       this.name = name;
/* 113 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder<T> bufferSize(int bufferSize) {
/* 122 */       if (!Queues.isPowerOfTwo(bufferSize)) {
/* 123 */         throw new IllegalArgumentException("bufferSize must be a power of 2 : " + bufferSize);
/*     */       }
/*     */       
/* 126 */       if (bufferSize < 1) {
/* 127 */         throw new IllegalArgumentException("bufferSize must be strictly positive, was: " + bufferSize);
/*     */       }
/*     */       
/* 130 */       this.bufferSize = bufferSize;
/* 131 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder<T> waitStrategy(@Nullable WaitStrategy waitStrategy) {
/* 141 */       this.waitStrategy = waitStrategy;
/* 142 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder<T> autoCancel(boolean autoCancel) {
/* 151 */       this.autoCancel = autoCancel;
/* 152 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder<T> executor(@Nullable ExecutorService executor) {
/* 163 */       this.executor = executor;
/* 164 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder<T> requestTaskExecutor(@Nullable ExecutorService requestTaskExecutor) {
/* 175 */       this.requestTaskExecutor = requestTaskExecutor;
/* 176 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder<T> share(boolean share) {
/* 187 */       this.share = share;
/* 188 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder<T> signalSupplier(@Nullable Supplier<T> signalSupplier) {
/* 197 */       this.signalSupplier = signalSupplier;
/* 198 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TopicProcessor<T> build() {
/* 207 */       this.name = (this.name != null) ? this.name : TopicProcessor.class.getSimpleName();
/* 208 */       this.waitStrategy = (this.waitStrategy != null) ? this.waitStrategy : WaitStrategy.phasedOffLiteLock(200L, 100L, TimeUnit.MILLISECONDS);
/* 209 */       ThreadFactory threadFactory = (this.executor != null) ? null : new EventLoopProcessor.EventLoopFactory(this.name, this.autoCancel);
/* 210 */       ExecutorService requestTaskExecutor = (this.requestTaskExecutor != null) ? this.requestTaskExecutor : EventLoopProcessor.defaultRequestTaskExecutor(EventLoopProcessor.defaultName(threadFactory, (Class)TopicProcessor.class));
/* 211 */       return new TopicProcessor<>(threadFactory, this.executor, requestTaskExecutor, this.bufferSize, this.waitStrategy, this.share, this.autoCancel, this.signalSupplier);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <E> Builder<E> builder() {
/* 228 */     return new Builder<>();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <E> TopicProcessor<E> create() {
/* 239 */     return builder().build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <E> TopicProcessor<E> create(String name, int bufferSize) {
/* 253 */     return builder().name(name).bufferSize(bufferSize).build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <E> TopicProcessor<E> share(String name, int bufferSize) {
/* 272 */     return builder().share(true).name(name).bufferSize(bufferSize).build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   TopicProcessor(@Nullable ThreadFactory threadFactory, @Nullable ExecutorService executor, ExecutorService requestTaskExecutor, int bufferSize, WaitStrategy waitStrategy, boolean shared, boolean autoCancel, @Nullable Supplier<E> signalSupplier) {
/* 288 */     super(bufferSize, threadFactory, executor, requestTaskExecutor, autoCancel, shared, () -> { EventLoopProcessor.Slot<E> signal = new EventLoopProcessor.Slot<>(); if (signalSupplier != null) signal.value = signalSupplier.get();  return signal; }waitStrategy);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 297 */     this.minimum = RingBuffer.newSequence(-1L);
/* 298 */     this.barrier = this.ringBuffer.newReader();
/*     */   }
/*     */ 
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super E> actual) {
/* 303 */     Objects.requireNonNull(actual, "subscribe");
/*     */     
/* 305 */     if (!alive()) {
/* 306 */       coldSource(this.ringBuffer, null, this.error, this.minimum).subscribe(actual);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 311 */     RingBuffer.Sequence pendingRequest = RingBuffer.newSequence(0L);
/* 312 */     TopicInner<E> signalProcessor = new TopicInner<>(this, pendingRequest, actual);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 318 */     if (incrementSubscribers()) {
/*     */       
/* 320 */       signalProcessor.sequence.set(this.minimum.getAsLong());
/* 321 */       this.ringBuffer.addGatingSequence(signalProcessor.sequence);
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 327 */       signalProcessor.sequence.set(this.ringBuffer.getCursor());
/* 328 */       this.ringBuffer.addGatingSequence(signalProcessor.sequence);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 335 */       this.executor.execute(signalProcessor);
/*     */     
/*     */     }
/* 338 */     catch (Throwable t) {
/* 339 */       this.ringBuffer.removeGatingSequence(signalProcessor.sequence);
/* 340 */       decrementSubscribers();
/* 341 */       if (!alive() && RejectedExecutionException.class.isAssignableFrom(t.getClass())) {
/* 342 */         coldSource(this.ringBuffer, t, this.error, this.minimum).subscribe(actual);
/*     */       } else {
/*     */         
/* 345 */         Operators.error((Subscriber)actual, t);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<E> drain() {
/* 352 */     return coldSource(this.ringBuffer, null, this.error, this.minimum);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doError(Throwable t) {
/* 357 */     this.barrier.signal();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doComplete() {
/* 364 */     this.barrier.signal();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long getPending() {
/* 370 */     return this.ringBuffer.getPending();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void requestTask(Subscription s) {
/* 375 */     this.minimum.set(this.ringBuffer.getCursor());
/* 376 */     this.ringBuffer.addGatingSequence(this.minimum);
/* 377 */     this.requestTaskExecutor.execute(
/* 378 */         createRequestTask(s, this, this.minimum::set, () -> (SUBSCRIBER_COUNT.get(this) == 0) ? this.minimum.getAsLong() : this.ringBuffer.getMinimumGatingSequence(this.minimum)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run() {
/* 386 */     if (!alive() && SUBSCRIBER_COUNT.get(this) == 0) {
/* 387 */       WaitStrategy.alert();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class TopicInner<T>
/*     */     implements Runnable, Subscription, Scannable
/*     */   {
/* 401 */     final AtomicBoolean running = new AtomicBoolean(true);
/*     */     
/* 403 */     final RingBuffer.Sequence sequence = RingBuffer.newSequence(-1L);
/*     */     
/*     */     final TopicProcessor<T> processor;
/*     */     
/*     */     final RingBuffer.Sequence pendingRequest;
/*     */     
/*     */     final CoreSubscriber<? super T> subscriber;
/*     */     
/* 411 */     final Runnable waiter = new Runnable()
/*     */       {
/*     */         public void run() {
/* 414 */           if (!TopicProcessor.TopicInner.this.running.get() || TopicProcessor.TopicInner.this.processor.isTerminated()) {
/* 415 */             WaitStrategy.alert();
/*     */           }
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     TopicInner(TopicProcessor<T> processor, RingBuffer.Sequence pendingRequest, CoreSubscriber<? super T> subscriber) {
/* 431 */       this.processor = processor;
/* 432 */       this.pendingRequest = pendingRequest;
/* 433 */       this.subscriber = subscriber;
/*     */     }
/*     */     
/*     */     void halt() {
/* 437 */       this.running.set(false);
/* 438 */       this.processor.barrier.alert();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void run() {
/*     */       try {
/* 447 */         Thread.currentThread()
/* 448 */           .setContextClassLoader(this.processor.contextClassLoader);
/* 449 */         this.subscriber.onSubscribe(this);
/*     */ 
/*     */         
/* 452 */         if (!EventLoopProcessor.waitRequestOrTerminalEvent(this.pendingRequest, this.processor.barrier, this.running, this.sequence, this.waiter)) {
/* 453 */           if (!this.running.get()) {
/*     */             return;
/*     */           }
/* 456 */           if (this.processor.terminated == 1) {
/* 457 */             if (this.processor.ringBuffer.getAsLong() == -1L) {
/* 458 */               if (this.processor.error != null) {
/* 459 */                 this.subscriber.onError(this.processor.error);
/*     */                 return;
/*     */               } 
/* 462 */               this.subscriber.onComplete();
/*     */               
/*     */               return;
/*     */             } 
/* 466 */           } else if (this.processor.terminated == 2) {
/*     */             return;
/*     */           } 
/*     */         } 
/*     */ 
/*     */         
/* 472 */         long nextSequence = this.sequence.getAsLong() + 1L;
/* 473 */         boolean unbounded = (this.pendingRequest.getAsLong() == Long.MAX_VALUE);
/*     */ 
/*     */         
/*     */         while (true) {
/*     */           try {
/* 478 */             long availableSequence = this.processor.barrier.waitFor(nextSequence, this.waiter);
/* 479 */             while (nextSequence <= availableSequence) {
/* 480 */               EventLoopProcessor.Slot<T> event = this.processor.ringBuffer.get(nextSequence);
/*     */ 
/*     */               
/* 483 */               while (!unbounded && EventLoopProcessor.getAndSub(this.pendingRequest, 1L) == 0L) {
/*     */ 
/*     */                 
/* 486 */                 if (!this.running.get() || this.processor.isTerminated()) {
/* 487 */                   WaitStrategy.alert();
/*     */                 }
/* 489 */                 LockSupport.parkNanos(1L);
/*     */               } 
/*     */ 
/*     */               
/* 493 */               this.subscriber.onNext(event.value);
/* 494 */               nextSequence++;
/*     */             } 
/*     */             
/* 497 */             this.sequence.set(availableSequence);
/*     */             
/* 499 */             if (Operators.emptySubscription() != this.processor.upstreamSubscription)
/*     */             {
/* 501 */               this.processor.readWait.signalAllWhenBlocking();
/*     */             }
/*     */           }
/* 504 */           catch (Throwable ex) {
/* 505 */             if (WaitStrategy.isAlert(ex) || Exceptions.isCancel(ex)) {
/*     */               
/* 507 */               if (!this.running.get()) {
/*     */                 break;
/*     */               }
/*     */               
/* 511 */               if (this.processor.terminated == 1) {
/* 512 */                 if (this.processor.error != null) {
/* 513 */                   this.subscriber.onError(this.processor.error);
/*     */                   break;
/*     */                 } 
/* 516 */                 if (nextSequence > this.processor.ringBuffer.getAsLong()) {
/* 517 */                   this.subscriber.onComplete();
/*     */                   
/*     */                   break;
/*     */                 } 
/* 521 */                 LockSupport.parkNanos(1L);
/*     */               }
/* 523 */               else if (this.processor.terminated == 2) {
/*     */                 break;
/*     */               } 
/* 526 */               this.processor.barrier.clearAlert();
/*     */               
/*     */               continue;
/*     */             } 
/* 530 */             throw Exceptions.propagate(ex);
/*     */           }
/*     */         
/*     */         } 
/*     */       } finally {
/*     */         
/* 536 */         this.processor.ringBuffer.removeGatingSequence(this.sequence);
/* 537 */         this.processor.decrementSubscribers();
/* 538 */         this.running.set(false);
/* 539 */         this.processor.readWait.signalAllWhenBlocking();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 546 */       if (key == Scannable.Attr.PARENT) return this.processor; 
/* 547 */       if (key == Scannable.Attr.ACTUAL) return this.subscriber; 
/* 548 */       if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(2147483647); 
/* 549 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.processor.isTerminated()); 
/* 550 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(!this.running.get()); 
/* 551 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf(this.pendingRequest.getAsLong()); 
/* 552 */       if (key == Scannable.Attr.LARGE_BUFFERED) {
/* 553 */         return Long.valueOf(this.processor.ringBuffer.getCursor() - this.sequence.getAsLong());
/*     */       }
/* 555 */       if (key == Scannable.Attr.BUFFERED) {
/* 556 */         long realBuffered = this.processor.ringBuffer.getCursor() - this.sequence.getAsLong();
/* 557 */         if (realBuffered <= 2147483647L) {
/* 558 */           return Integer.valueOf((int)realBuffered);
/*     */         }
/* 560 */         return Integer.valueOf(-2147483648);
/*     */       } 
/*     */       
/* 563 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 568 */       if (!Operators.validate(n) || !this.running.get()) {
/*     */         return;
/*     */       }
/*     */       
/* 572 */       EventLoopProcessor.addCap(this.pendingRequest, n);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 577 */       halt();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-extra-3.4.10.jar!\reactor\extra\processor\TopicProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */