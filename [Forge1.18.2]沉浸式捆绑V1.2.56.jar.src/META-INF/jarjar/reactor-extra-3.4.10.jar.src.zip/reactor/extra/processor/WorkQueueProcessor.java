/*     */ package reactor.extra.processor;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.Queue;
/*     */ import java.util.concurrent.ConcurrentLinkedQueue;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.ForkJoinPool;
/*     */ import java.util.concurrent.RejectedExecutionException;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import java.util.concurrent.ThreadPoolExecutor;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.concurrent.locks.LockSupport;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.stream.Stream;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Operators;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.Loggers;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.concurrent.Queues;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public final class WorkQueueProcessor<E>
/*     */   extends EventLoopProcessor<E>
/*     */ {
/*     */   public static final class Builder<T>
/*     */   {
/*  93 */     int bufferSize = Queues.SMALL_BUFFER_SIZE;
/*     */     
/*     */     boolean autoCancel = true;
/*     */     
/*     */     boolean share = false;
/*     */     
/*     */     String name;
/*     */     
/*     */     ExecutorService executor;
/*     */     ExecutorService requestTaskExecutor;
/*     */     WaitStrategy waitStrategy;
/*     */     
/*     */     public Builder<T> name(@Nullable String name) {
/* 106 */       if (this.executor != null)
/* 107 */         throw new IllegalArgumentException("Executor service is configured, name will not be used."); 
/* 108 */       this.name = name;
/* 109 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder<T> bufferSize(int bufferSize) {
/* 118 */       if (!Queues.isPowerOfTwo(bufferSize)) {
/* 119 */         throw new IllegalArgumentException("bufferSize must be a power of 2 : " + bufferSize);
/*     */       }
/*     */       
/* 122 */       if (bufferSize < 1) {
/* 123 */         throw new IllegalArgumentException("bufferSize must be strictly positive, was: " + bufferSize);
/*     */       }
/*     */       
/* 126 */       this.bufferSize = bufferSize;
/* 127 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder<T> waitStrategy(@Nullable WaitStrategy waitStrategy) {
/* 137 */       this.waitStrategy = waitStrategy;
/* 138 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder<T> autoCancel(boolean autoCancel) {
/* 147 */       this.autoCancel = autoCancel;
/* 148 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder<T> executor(@Nullable ExecutorService executor) {
/* 159 */       this.executor = executor;
/* 160 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder<T> requestTaskExecutor(@Nullable ExecutorService requestTaskExecutor) {
/* 170 */       this.requestTaskExecutor = requestTaskExecutor;
/* 171 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder<T> share(boolean share) {
/* 182 */       this.share = share;
/* 183 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public WorkQueueProcessor<T> build() {
/* 192 */       String name = (this.name != null) ? this.name : WorkQueueProcessor.class.getSimpleName();
/* 193 */       WaitStrategy waitStrategy = (this.waitStrategy != null) ? this.waitStrategy : WaitStrategy.liteBlocking();
/* 194 */       ThreadFactory threadFactory = (this.executor != null) ? null : new EventLoopProcessor.EventLoopFactory(name, this.autoCancel);
/*     */       
/* 196 */       ExecutorService requestTaskExecutor = (this.requestTaskExecutor != null) ? this.requestTaskExecutor : EventLoopProcessor.defaultRequestTaskExecutor(EventLoopProcessor.defaultName(threadFactory, (Class)WorkQueueProcessor.class));
/* 197 */       return new WorkQueueProcessor<>(threadFactory, this.executor, requestTaskExecutor, this.bufferSize, waitStrategy, this.share, this.autoCancel);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final <T> Builder<T> builder() {
/* 213 */     return new Builder<>();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <E> WorkQueueProcessor<E> create() {
/* 224 */     return builder().build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <E> WorkQueueProcessor<E> create(String name, int bufferSize) {
/* 238 */     return builder().name(name).bufferSize(bufferSize).build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <E> WorkQueueProcessor<E> share(String name, int bufferSize) {
/* 254 */     return builder().share(true).name(name).bufferSize(bufferSize).build();
/*     */   }
/*     */ 
/*     */   
/* 258 */   static final Supplier FACTORY = Slot::new;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 265 */   final RingBuffer.Sequence workSequence = RingBuffer.newSequence(-1L);
/*     */   
/* 267 */   final Queue<Object> claimedDisposed = new ConcurrentLinkedQueue();
/*     */ 
/*     */   
/*     */   final WaitStrategy writeWait;
/*     */ 
/*     */   
/*     */   volatile int replaying;
/*     */ 
/*     */   
/* 276 */   static final AtomicIntegerFieldUpdater<WorkQueueProcessor> REPLAYING = AtomicIntegerFieldUpdater.newUpdater(WorkQueueProcessor.class, "replaying");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   WorkQueueProcessor(@Nullable ThreadFactory threadFactory, @Nullable ExecutorService executor, ExecutorService requestTaskExecutor, int bufferSize, WaitStrategy waitStrategy, boolean share, boolean autoCancel) {
/* 285 */     super(bufferSize, threadFactory, executor, requestTaskExecutor, autoCancel, share, FACTORY, waitStrategy);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 292 */     this.writeWait = waitStrategy;
/*     */     
/* 294 */     this.ringBuffer.addGatingSequence(this.workSequence);
/*     */   }
/*     */ 
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super E> actual) {
/* 299 */     Objects.requireNonNull(actual, "subscribe");
/*     */     
/* 301 */     if (!alive()) {
/* 302 */       TopicProcessor.coldSource(this.ringBuffer, null, this.error, this.workSequence).subscribe(actual);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 307 */     WorkQueueInner<E> signalProcessor = new WorkQueueInner<>(actual, this);
/*     */ 
/*     */     
/*     */     try {
/* 311 */       incrementSubscribers();
/*     */ 
/*     */       
/* 314 */       signalProcessor.sequence.set(this.workSequence.getAsLong());
/* 315 */       this.ringBuffer.addGatingSequence(signalProcessor.sequence);
/*     */ 
/*     */       
/* 318 */       int maxSubscribers = bestEffortMaxSubscribers(this.executor);
/* 319 */       if (maxSubscribers > Integer.MIN_VALUE && this.subscriberCount > maxSubscribers) {
/* 320 */         throw new IllegalStateException("The executor service could not accommodate another subscriber, detected limit " + maxSubscribers);
/*     */       }
/*     */ 
/*     */       
/* 324 */       this.executor.execute(signalProcessor);
/*     */     }
/* 326 */     catch (Throwable t) {
/* 327 */       decrementSubscribers();
/* 328 */       this.ringBuffer.removeGatingSequence(signalProcessor.sequence);
/* 329 */       if (RejectedExecutionException.class.isAssignableFrom(t.getClass())) {
/* 330 */         TopicProcessor.coldSource(this.ringBuffer, t, this.error, this.workSequence).subscribe(actual);
/*     */       }
/*     */       else {
/*     */         
/* 334 */         Operators.error((Subscriber)actual, t);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int bestEffortMaxSubscribers(ExecutorService executor) {
/* 352 */     int maxSubscribers = Integer.MIN_VALUE;
/* 353 */     if (executor instanceof ThreadPoolExecutor) {
/* 354 */       maxSubscribers = ((ThreadPoolExecutor)executor).getMaximumPoolSize();
/*     */     }
/* 356 */     else if (executor instanceof ForkJoinPool) {
/* 357 */       maxSubscribers = ((ForkJoinPool)executor).getParallelism();
/*     */     } 
/* 359 */     return maxSubscribers;
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<E> drain() {
/* 364 */     return TopicProcessor.coldSource(this.ringBuffer, null, this.error, this.workSequence);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doError(Throwable t) {
/* 369 */     this.writeWait.signalAllWhenBlocking();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doComplete() {
/* 375 */     this.writeWait.signalAllWhenBlocking();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void requestTask(Subscription s) {
/* 381 */     this.requestTaskExecutor.execute(createRequestTask(s, this, null, this.ringBuffer::getMinimumGatingSequence));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long getPending() {
/* 387 */     return (getBufferSize() - this.ringBuffer.getPending() + this.claimedDisposed.size());
/*     */   }
/*     */ 
/*     */   
/*     */   public void run() {
/* 392 */     if (!alive()) {
/* 393 */       WaitStrategy.alert();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class WorkQueueInner<T>
/*     */     implements Runnable, Subscription, Scannable
/*     */   {
/* 407 */     final AtomicBoolean running = new AtomicBoolean(true);
/*     */ 
/*     */     
/* 410 */     final RingBuffer.Sequence sequence = RingBuffer.newSequence(-1L);
/*     */     
/* 412 */     final RingBuffer.Sequence pendingRequest = RingBuffer.newSequence(0L);
/*     */     
/*     */     final RingBuffer.Reader barrier;
/*     */     
/*     */     final WorkQueueProcessor<T> processor;
/*     */     
/*     */     final CoreSubscriber<? super T> subscriber;
/*     */     
/* 420 */     final Runnable waiter = new Runnable()
/*     */       {
/*     */         public void run() {
/* 423 */           if (WorkQueueProcessor.WorkQueueInner.this.barrier.isAlerted() || !WorkQueueProcessor.WorkQueueInner.this.isRunning() || WorkQueueProcessor.WorkQueueInner.this
/* 424 */             .replay((WorkQueueProcessor.WorkQueueInner.this.pendingRequest.getAsLong() == Long.MAX_VALUE))) {
/* 425 */             WaitStrategy.alert();
/*     */           }
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     WorkQueueInner(CoreSubscriber<? super T> subscriber, WorkQueueProcessor<T> processor) {
/* 438 */       this.processor = processor;
/* 439 */       this.subscriber = subscriber;
/*     */       
/* 441 */       this.barrier = processor.ringBuffer.newReader();
/*     */     }
/*     */     
/*     */     void halt() {
/* 445 */       this.running.set(false);
/* 446 */       this.barrier.alert();
/*     */     }
/*     */     
/*     */     boolean isRunning() {
/* 450 */       return (this.running.get() && (this.processor.terminated == 0 || (this.processor.terminated != 2 && this.processor.error == null && this.processor.ringBuffer
/*     */ 
/*     */         
/* 453 */         .getAsLong() > this.sequence.getAsLong())));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void run() {
/* 463 */       boolean processedSequence = true;
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 468 */         Thread.currentThread()
/* 469 */           .setContextClassLoader(this.processor.contextClassLoader);
/* 470 */         this.subscriber.onSubscribe(this);
/*     */         
/* 472 */         long cachedAvailableSequence = Long.MIN_VALUE;
/* 473 */         long nextSequence = this.sequence.getAsLong();
/* 474 */         EventLoopProcessor.Slot<T> event = null;
/*     */         
/* 476 */         boolean unbounded = (this.pendingRequest.getAsLong() == Long.MAX_VALUE);
/*     */         
/* 478 */         if (!EventLoopProcessor.waitRequestOrTerminalEvent(this.pendingRequest, this.barrier, this.running, this.sequence, this.waiter) && 
/* 479 */           replay(unbounded)) {
/* 480 */           if (!this.running.get()) {
/*     */             return;
/*     */           }
/* 483 */           if (this.processor.terminated == 1) {
/* 484 */             if (this.processor.ringBuffer.getAsLong() == -1L) {
/* 485 */               if (this.processor.error != null) {
/* 486 */                 this.subscriber.onError(this.processor.error);
/*     */                 return;
/*     */               } 
/* 489 */               this.subscriber.onComplete();
/*     */               
/*     */               return;
/*     */             } 
/* 493 */           } else if (this.processor.terminated == 2) {
/*     */             return;
/*     */           } 
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         while (true) {
/*     */           try {
/* 505 */             if (processedSequence) {
/* 506 */               if (!this.running.get()) {
/*     */                 break;
/*     */               }
/* 509 */               processedSequence = false;
/*     */               do {
/* 511 */                 nextSequence = this.processor.workSequence.getAsLong() + 1L;
/* 512 */                 while (!unbounded && this.pendingRequest.getAsLong() == 0L) {
/* 513 */                   if (!isRunning()) {
/* 514 */                     WaitStrategy.alert();
/*     */                   }
/* 516 */                   LockSupport.parkNanos(1L);
/*     */                 } 
/* 518 */                 this.sequence.set(nextSequence - 1L);
/*     */               }
/* 520 */               while (!this.processor.workSequence.compareAndSet(nextSequence - 1L, nextSequence));
/*     */             } 
/*     */             
/* 523 */             if (cachedAvailableSequence >= nextSequence) {
/* 524 */               event = this.processor.ringBuffer.get(nextSequence);
/*     */               
/*     */               try {
/* 527 */                 readNextEvent(unbounded);
/*     */               }
/* 529 */               catch (Exception ce) {
/* 530 */                 if (!this.running.get() || !WaitStrategy.isAlert(ce)) {
/* 531 */                   throw ce;
/*     */                 }
/* 533 */                 this.barrier.clearAlert();
/*     */               } 
/*     */               
/* 536 */               processedSequence = true;
/* 537 */               this.subscriber.onNext(event.value);
/*     */               
/*     */               continue;
/*     */             } 
/*     */             
/* 542 */             this.processor.readWait.signalAllWhenBlocking();
/*     */             
/* 544 */             cachedAvailableSequence = this.barrier.waitFor(nextSequence, this.waiter);
/*     */ 
/*     */ 
/*     */           
/*     */           }
/* 549 */           catch (InterruptedException|RuntimeException ce) {
/* 550 */             if (ce instanceof InterruptedException) {
/* 551 */               Thread.currentThread().interrupt();
/*     */             }
/* 553 */             if (Exceptions.isCancel(ce)) {
/* 554 */               reschedule(event);
/*     */               break;
/*     */             } 
/* 557 */             if (!WaitStrategy.isAlert(ce)) {
/* 558 */               throw Exceptions.propagate(ce);
/*     */             }
/*     */             
/* 561 */             this.barrier.clearAlert();
/* 562 */             if (!this.running.get()) {
/*     */               break;
/*     */             }
/* 565 */             if (this.processor.terminated == 1) {
/* 566 */               if (this.processor.error != null) {
/* 567 */                 processedSequence = true;
/* 568 */                 this.subscriber.onError(this.processor.error);
/*     */                 break;
/*     */               } 
/* 571 */               if (this.processor.ringBuffer.getPending() == 0) {
/* 572 */                 processedSequence = true;
/* 573 */                 this.subscriber.onComplete(); break;
/*     */               } 
/*     */               continue;
/*     */             } 
/* 577 */             if (this.processor.terminated == 2) {
/*     */               break;
/*     */             }
/*     */           }
/*     */         
/*     */         }
/*     */       
/*     */       }
/*     */       finally {
/*     */         
/* 587 */         this.processor.decrementSubscribers();
/* 588 */         this.running.set(false);
/*     */         
/* 590 */         if (!processedSequence) {
/* 591 */           this.processor.claimedDisposed.add(this.sequence);
/*     */         } else {
/*     */           
/* 594 */           this.processor.ringBuffer.removeGatingSequence(this.sequence);
/*     */         } 
/*     */ 
/*     */         
/* 598 */         this.processor.writeWait.signalAllWhenBlocking();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     boolean replay(boolean unbounded) {
/* 604 */       if (WorkQueueProcessor.REPLAYING.compareAndSet(this.processor, 0, 1)) {
/*     */         try {
/* 606 */           RingBuffer.Sequence s = null;
/*     */           
/*     */           while (true) {
/* 609 */             if (!this.running.get()) {
/* 610 */               this.processor.readWait.signalAllWhenBlocking();
/* 611 */               return true;
/*     */             } 
/*     */             
/* 614 */             Object v = this.processor.claimedDisposed.peek();
/*     */             
/* 616 */             if (v == null) {
/* 617 */               this.processor.readWait.signalAllWhenBlocking();
/* 618 */               return (!this.processor.alive() && this.processor.ringBuffer.getPending() == 0);
/*     */             } 
/*     */             
/* 621 */             if (v instanceof RingBuffer.Sequence) {
/* 622 */               s = (RingBuffer.Sequence)v;
/* 623 */               long cursor = s.getAsLong() + 1L;
/* 624 */               if (cursor > this.processor.ringBuffer.getAsLong()) {
/* 625 */                 this.processor.readWait.signalAllWhenBlocking();
/* 626 */                 return (!this.processor.alive() && this.processor.ringBuffer.getPending() == 0);
/*     */               } 
/*     */               
/* 629 */               this.barrier.waitFor(cursor, this.waiter);
/*     */               
/* 631 */               v = ((EventLoopProcessor.Slot)this.processor.ringBuffer.get(cursor)).value;
/*     */               
/* 633 */               if (v == null) {
/* 634 */                 this.processor.ringBuffer.removeGatingSequence(s);
/* 635 */                 this.processor.claimedDisposed.poll();
/* 636 */                 s = null;
/*     */                 
/*     */                 continue;
/*     */               } 
/*     */             } 
/* 641 */             readNextEvent(unbounded);
/* 642 */             this.subscriber.onNext(v);
/* 643 */             this.processor.claimedDisposed.poll();
/* 644 */             if (s != null) {
/* 645 */               this.processor.ringBuffer.removeGatingSequence(s);
/* 646 */               s = null;
/*     */             }
/*     */           
/*     */           } 
/* 650 */         } catch (RuntimeException ce) {
/* 651 */           if (!this.running.get() || Exceptions.isCancel(ce)) {
/* 652 */             this.running.set(false);
/* 653 */             return true;
/*     */           } 
/* 655 */           throw ce;
/*     */         }
/* 657 */         catch (InterruptedException e) {
/* 658 */           this.running.set(false);
/* 659 */           Thread.currentThread().interrupt();
/* 660 */           return true;
/*     */         } finally {
/*     */           
/* 663 */           WorkQueueProcessor.REPLAYING.compareAndSet(this.processor, 1, 0);
/*     */         } 
/*     */       }
/*     */       
/* 667 */       return (!this.processor.alive() && this.processor.ringBuffer.getPending() == 0);
/*     */     }
/*     */ 
/*     */     
/*     */     boolean reschedule(@Nullable EventLoopProcessor.Slot<T> event) {
/* 672 */       if (event != null && event.value != null) {
/*     */         
/* 674 */         this.processor.claimedDisposed.add(event.value);
/* 675 */         this.barrier.alert();
/* 676 */         this.processor.readWait.signalAllWhenBlocking();
/* 677 */         return true;
/*     */       } 
/* 679 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     void readNextEvent(boolean unbounded) {
/* 684 */       while (!unbounded && EventLoopProcessor.getAndSub(this.pendingRequest, 1L) == 0L) {
/* 685 */         if (!isRunning()) {
/* 686 */           WaitStrategy.alert();
/*     */         }
/*     */         
/* 689 */         LockSupport.parkNanos(1L);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 696 */       if (key == Scannable.Attr.PARENT) return this.processor; 
/* 697 */       if (key == Scannable.Attr.ACTUAL) return this.subscriber; 
/* 698 */       if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(2147483647); 
/* 699 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.processor.isTerminated()); 
/* 700 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(!this.running.get()); 
/* 701 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf(this.pendingRequest.getAsLong());
/*     */       
/* 703 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 708 */       if (!Operators.validate(n) || !this.running.get()) {
/*     */         return;
/*     */       }
/*     */       
/* 712 */       EventLoopProcessor.addCap(this.pendingRequest, n);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 717 */       halt();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/* 722 */   static final Logger log = Loggers.getLogger(WorkQueueProcessor.class);
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-extra-3.4.10.jar!\reactor\extra\processor\WorkQueueProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */