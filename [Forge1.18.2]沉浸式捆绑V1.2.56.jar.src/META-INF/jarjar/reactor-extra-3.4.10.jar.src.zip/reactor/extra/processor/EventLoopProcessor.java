/*     */ package reactor.extra.processor;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.time.Duration;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.concurrent.locks.LockSupport;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.LongSupplier;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.stream.Stream;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.FluxProcessor;
/*     */ import reactor.core.publisher.Operators;
/*     */ import reactor.core.publisher.SynchronousSink;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.concurrent.Queues;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ abstract class EventLoopProcessor<IN>
/*     */   extends FluxProcessor<IN, IN>
/*     */   implements Runnable
/*     */ {
/*     */   final ExecutorService executor;
/*     */   final ExecutorService requestTaskExecutor;
/*     */   final EventLoopContext contextClassLoader;
/*     */   final String name;
/*     */   final boolean autoCancel;
/*     */   final RingBuffer<Slot<IN>> ringBuffer;
/*     */   
/*     */   static <E> Flux<E> coldSource(RingBuffer<Slot<E>> ringBuffer, @Nullable Throwable t, @Nullable Throwable error, RingBuffer.Sequence start) {
/*  58 */     Flux<E> bufferIterable = generate(start::getAsLong, (seq, sink) -> {
/*     */           long s = seq.longValue() + 1L;
/*     */           
/*     */           if (s > ringBuffer.getCursor()) {
/*     */             sink.complete();
/*     */           } else {
/*     */             T t = ((Slot)ringBuffer.get(s)).value;
/*     */             if (t != null) {
/*     */               sink.next(t);
/*     */             }
/*     */           } 
/*     */           return Long.valueOf(s);
/*     */         });
/*  71 */     if (error != null) {
/*  72 */       if (t != null) {
/*  73 */         t = Exceptions.addSuppressed(t, error);
/*  74 */         return concat(new Publisher[] { (Publisher)bufferIterable, (Publisher)Flux.error(t) });
/*     */       } 
/*  76 */       return concat(new Publisher[] { (Publisher)bufferIterable, (Publisher)Flux.error(error) });
/*     */     } 
/*  78 */     return bufferIterable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Runnable createRequestTask(Subscription upstream, EventLoopProcessor<?> p, @Nullable Consumer<Long> postWaitCallback, LongSupplier readCount) {
/*  96 */     return new RequestTask(upstream, p, postWaitCallback, readCount);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean waitRequestOrTerminalEvent(LongSupplier pendingRequest, RingBuffer.Reader barrier, AtomicBoolean isRunning, LongSupplier nextSequence, Runnable waiter) {
/*     */     try {
/* 122 */       while (pendingRequest.getAsLong() <= 0L)
/*     */       {
/* 124 */         long waitedSequence = nextSequence.getAsLong() + 1L;
/* 125 */         waiter.run();
/* 126 */         barrier.waitFor(waitedSequence, waiter);
/*     */         
/* 128 */         if (!isRunning.get()) {
/* 129 */           WaitStrategy.alert();
/*     */         }
/* 131 */         LockSupport.parkNanos(1L);
/*     */       }
/*     */     
/* 134 */     } catch (InterruptedException ie) {
/* 135 */       Thread.currentThread()
/* 136 */         .interrupt();
/*     */     
/*     */     }
/* 139 */     catch (Exception e) {
/* 140 */       if (!isRunning.get() || WaitStrategy.isAlert(e)) {
/* 141 */         return false;
/*     */       }
/* 143 */       throw e;
/*     */     } 
/*     */     
/* 146 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void addCap(RingBuffer.Sequence sequence, long toAdd) {
/*     */     long u;
/*     */     long r;
/*     */     do {
/* 159 */       r = sequence.getAsLong();
/* 160 */       if (r == Long.MAX_VALUE) {
/*     */         return;
/*     */       }
/* 163 */       u = Operators.addCap(r, toAdd);
/*     */     }
/* 165 */     while (!sequence.compareAndSet(r, u));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static long getAndSub(RingBuffer.Sequence sequence, long toSub) {
/*     */     long r;
/*     */     long u;
/*     */     do {
/* 180 */       r = sequence.getAsLong();
/* 181 */       if (r == 0L || r == Long.MAX_VALUE) {
/* 182 */         return r;
/*     */       }
/* 184 */       u = Operators.subOrZero(r, toSub);
/*     */     }
/* 186 */     while (!sequence.compareAndSet(r, u));
/*     */     
/* 188 */     return r;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 198 */   final WaitStrategy readWait = WaitStrategy.liteBlocking();
/*     */ 
/*     */   
/*     */   Subscription upstreamSubscription;
/*     */   
/*     */   volatile boolean cancelled;
/*     */   
/*     */   volatile int terminated;
/*     */   
/*     */   volatile Throwable error;
/*     */   
/*     */   volatile int subscriberCount;
/*     */   
/*     */   static final int SHUTDOWN = 1;
/*     */   
/*     */   static final int FORCED_SHUTDOWN = 2;
/*     */ 
/*     */   
/*     */   EventLoopProcessor(int bufferSize, @Nullable ThreadFactory threadFactory, @Nullable ExecutorService executor, ExecutorService requestExecutor, boolean autoCancel, boolean multiproducers, Supplier<Slot<IN>> factory, WaitStrategy strategy) {
/* 217 */     if (!Queues.isPowerOfTwo(bufferSize)) {
/* 218 */       throw new IllegalArgumentException("bufferSize must be a power of 2 : " + bufferSize);
/*     */     }
/*     */     
/* 221 */     if (bufferSize < 1) {
/* 222 */       throw new IllegalArgumentException("bufferSize must be strictly positive, was: " + bufferSize);
/*     */     }
/*     */ 
/*     */     
/* 226 */     this.autoCancel = autoCancel;
/*     */     
/* 228 */     this.contextClassLoader = new EventLoopContext(multiproducers);
/*     */     
/* 230 */     this.name = defaultName(threadFactory, (Class)getClass());
/*     */     
/* 232 */     this.requestTaskExecutor = Objects.<ExecutorService>requireNonNull(requestExecutor, "requestTaskExecutor");
/*     */     
/* 234 */     if (executor == null) {
/* 235 */       this.executor = Executors.newCachedThreadPool(threadFactory);
/*     */     } else {
/*     */       
/* 238 */       this.executor = executor;
/*     */     } 
/*     */     
/* 241 */     if (multiproducers) {
/* 242 */       this.ringBuffer = RingBuffer.createMultiProducer(factory, bufferSize, strategy, this);
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 248 */       this.ringBuffer = RingBuffer.createSingleProducer(factory, bufferSize, strategy, this);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/* 265 */     if (key == Scannable.Attr.PARENT) return this.upstreamSubscription;
/*     */     
/* 267 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static String defaultName(@Nullable ThreadFactory threadFactory, Class<? extends EventLoopProcessor> clazz) {
/* 282 */     String name = (threadFactory instanceof Supplier) ? ((Supplier<T>)threadFactory).get().toString() : null;
/* 283 */     return (null != name) ? name : clazz.getSimpleName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static ExecutorService defaultRequestTaskExecutor(String name) {
/* 295 */     return Executors.newCachedThreadPool(r -> new Thread(r, name + "[request-task]"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean alive() {
/* 304 */     return (0 == this.terminated);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean awaitAndShutdown() {
/* 312 */     return awaitAndShutdown(Duration.ofSeconds(-1L));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public final boolean awaitAndShutdown(long timeout, TimeUnit timeUnit) {
/*     */     try {
/* 325 */       shutdown();
/* 326 */       return this.executor.awaitTermination(timeout, timeUnit);
/* 327 */     } catch (InterruptedException ie) {
/* 328 */       Thread.currentThread().interrupt();
/* 329 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean awaitAndShutdown(Duration timeout) {
/* 340 */     long nanos = -1L;
/* 341 */     if (!timeout.isNegative()) {
/* 342 */       nanos = timeout.toNanos();
/*     */     }
/*     */     try {
/* 345 */       shutdown();
/* 346 */       return this.executor.awaitTermination(nanos, TimeUnit.NANOSECONDS);
/* 347 */     } catch (InterruptedException ie) {
/* 348 */       Thread.currentThread().interrupt();
/* 349 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Stream<? extends Scannable> inners() {
/* 356 */     return Stream.empty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Flux<IN> drain() {
/* 366 */     return Flux.empty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Flux<IN> forceShutdown() {
/* 375 */     int t = this.terminated;
/* 376 */     if (t != 2 && TERMINATED.compareAndSet(this, t, 2)) {
/* 377 */       this.executor.shutdownNow();
/* 378 */       this.requestTaskExecutor.shutdownNow();
/*     */     } 
/* 380 */     return drain();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final long getAvailableCapacity() {
/* 387 */     return (this.ringBuffer.bufferSize() - this.ringBuffer.getPending());
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public final Throwable getError() {
/* 393 */     return this.error;
/*     */   }
/*     */ 
/*     */   
/*     */   public final String toString() {
/* 398 */     return "/Processors/" + this.name + "/" + this.contextClassLoader.hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public final int hashCode() {
/* 403 */     return this.contextClassLoader.hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSerialized() {
/* 408 */     return this.contextClassLoader.multiproducer;
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean isTerminated() {
/* 413 */     return (this.terminated > 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void onComplete() {
/* 418 */     if (TERMINATED.compareAndSet(this, 0, 1)) {
/* 419 */       this.upstreamSubscription = null;
/* 420 */       doComplete();
/* 421 */       this.executor.shutdown();
/* 422 */       this.readWait.signalAllWhenBlocking();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public final void onError(Throwable t) {
/* 428 */     Objects.requireNonNull(t, "onError");
/* 429 */     if (TERMINATED.compareAndSet(this, 0, 1)) {
/* 430 */       this.error = t;
/* 431 */       this.upstreamSubscription = null;
/* 432 */       doError(t);
/* 433 */       this.executor.shutdown();
/* 434 */       this.readWait.signalAllWhenBlocking();
/*     */     } else {
/*     */       
/* 437 */       Operators.onErrorDropped(t, Context.empty());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public final void onNext(IN o) {
/* 443 */     Objects.requireNonNull(o, "onNext");
/* 444 */     long seqId = this.ringBuffer.next();
/* 445 */     Slot<IN> signal = this.ringBuffer.get(seqId);
/* 446 */     signal.value = (T)o;
/* 447 */     this.ringBuffer.publish(seqId);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void onSubscribe(Subscription s) {
/* 452 */     if (Operators.validate(this.upstreamSubscription, s)) {
/* 453 */       this.upstreamSubscription = s;
/*     */       try {
/* 455 */         if (s != Operators.emptySubscription()) {
/* 456 */           requestTask(s);
/*     */         }
/*     */       }
/* 459 */       catch (Throwable t) {
/* 460 */         onError(Operators.onOperatorError(s, t, currentContext()));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean serializeAlways() {
/* 467 */     return !this.contextClassLoader.multiproducer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void shutdown() {
/*     */     try {
/* 476 */       onComplete();
/* 477 */       this.executor.shutdown();
/* 478 */       this.requestTaskExecutor.shutdown();
/*     */     }
/* 480 */     catch (Throwable t) {
/* 481 */       onError(Operators.onOperatorError(t, currentContext()));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public final int getBufferSize() {
/* 487 */     return this.ringBuffer.bufferSize();
/*     */   }
/*     */   
/*     */   final void cancel() {
/* 491 */     this.cancelled = true;
/* 492 */     if (TERMINATED.compareAndSet(this, 0, 1)) {
/* 493 */       this.executor.shutdown();
/*     */     }
/* 495 */     this.readWait.signalAllWhenBlocking();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doComplete() {}
/*     */ 
/*     */ 
/*     */   
/*     */   static final class RequestTask
/*     */     implements Runnable
/*     */   {
/*     */     final LongSupplier readCount;
/*     */ 
/*     */     
/*     */     final Subscription upstream;
/*     */ 
/*     */     
/*     */     final EventLoopProcessor<?> parent;
/*     */ 
/*     */     
/*     */     final Consumer<Long> postWaitCallback;
/*     */ 
/*     */ 
/*     */     
/*     */     RequestTask(Subscription upstream, EventLoopProcessor<?> p, @Nullable Consumer<Long> postWaitCallback, LongSupplier readCount) {
/* 522 */       this.parent = p;
/* 523 */       this.readCount = readCount;
/* 524 */       this.postWaitCallback = postWaitCallback;
/* 525 */       this.upstream = upstream;
/*     */     }
/*     */ 
/*     */     
/*     */     public void run() {
/* 530 */       long bufferSize = this.parent.ringBuffer.bufferSize();
/* 531 */       long limit = (bufferSize == 1L) ? bufferSize : (bufferSize - Math.max(bufferSize >> 2L, 1L));
/* 532 */       long cursor = -1L;
/*     */       try {
/* 534 */         this.parent.run();
/* 535 */         this.upstream.request(bufferSize);
/*     */ 
/*     */ 
/*     */         
/*     */         while (true) {
/* 540 */           long c = cursor + limit;
/* 541 */           cursor = this.parent.readWait.waitFor(c, this.readCount, this.parent);
/* 542 */           if (this.postWaitCallback != null) {
/* 543 */             this.postWaitCallback.accept(Long.valueOf(cursor));
/*     */           }
/*     */           
/* 546 */           this.upstream.request(limit + cursor - c);
/*     */         }
/*     */       
/* 549 */       } catch (InterruptedException e) {
/* 550 */         Thread.currentThread()
/* 551 */           .interrupt();
/*     */       }
/* 553 */       catch (Throwable t) {
/* 554 */         if (WaitStrategy.isAlert(t)) {
/* 555 */           if (this.parent.cancelled) {
/* 556 */             this.upstream.cancel();
/*     */           }
/*     */           return;
/*     */         } 
/* 560 */         this.parent.onError(Operators.onOperatorError(t, this.parent.currentContext()));
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected void requestTask(Subscription s) {}
/*     */ 
/*     */   
/*     */   final void decrementSubscribers() {
/* 570 */     Subscription subscription = this.upstreamSubscription;
/* 571 */     int subs = SUBSCRIBER_COUNT.decrementAndGet(this);
/* 572 */     if (subs == 0 && 
/* 573 */       subscription != null && this.autoCancel) {
/* 574 */       this.upstreamSubscription = null;
/* 575 */       cancel();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long downstreamCount() {
/* 582 */     return this.subscriberCount;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean incrementSubscribers() {
/* 588 */     return (SUBSCRIBER_COUNT.getAndIncrement(this) == 0);
/*     */   }
/*     */   
/*     */   static final class EventLoopContext
/*     */     extends ClassLoader {
/*     */     final boolean multiproducer;
/*     */     
/*     */     EventLoopContext(boolean multiproducer) {
/* 596 */       super(Thread.currentThread()
/* 597 */           .getContextClassLoader());
/* 598 */       this.multiproducer = multiproducer;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 606 */   static final AtomicIntegerFieldUpdater<EventLoopProcessor> SUBSCRIBER_COUNT = AtomicIntegerFieldUpdater.newUpdater(EventLoopProcessor.class, "subscriberCount");
/*     */ 
/*     */   
/* 609 */   static final AtomicIntegerFieldUpdater<EventLoopProcessor> TERMINATED = AtomicIntegerFieldUpdater.newUpdater(EventLoopProcessor.class, "terminated");
/*     */ 
/*     */   
/*     */   public abstract long getPending();
/*     */ 
/*     */   
/*     */   abstract void doError(Throwable paramThrowable);
/*     */ 
/*     */   
/*     */   public static final class Slot<T>
/*     */     implements Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 5172014386416785095L;
/*     */     public T value;
/*     */   }
/*     */   
/*     */   static final class EventLoopFactory
/*     */     implements ThreadFactory, Supplier<String>
/*     */   {
/* 628 */     static final AtomicInteger COUNT = new AtomicInteger();
/*     */     
/*     */     final String name;
/*     */     final boolean daemon;
/*     */     
/*     */     EventLoopFactory(String name, boolean daemon) {
/* 634 */       this.name = name;
/* 635 */       this.daemon = daemon;
/*     */     }
/*     */ 
/*     */     
/*     */     public Thread newThread(Runnable r) {
/* 640 */       Thread t = new Thread(r, this.name + "-" + COUNT.incrementAndGet());
/* 641 */       t.setDaemon(this.daemon);
/* 642 */       return t;
/*     */     }
/*     */ 
/*     */     
/*     */     public String get() {
/* 647 */       return this.name;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-extra-3.4.10.jar!\reactor\extra\processor\EventLoopProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */