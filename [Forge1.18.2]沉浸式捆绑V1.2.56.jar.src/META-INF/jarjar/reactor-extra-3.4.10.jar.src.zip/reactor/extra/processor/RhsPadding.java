package reactor.extra.processor;

class RhsPadding extends Value {
  protected long p9;
  
  protected long p10;
  
  protected long p11;
  
  protected long p12;
  
  protected long p13;
  
  protected long p14;
  
  protected long p15;
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-extra-3.4.10.jar!\reactor\extra\processor\RhsPadding.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */