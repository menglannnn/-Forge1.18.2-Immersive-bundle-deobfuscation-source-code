package reactor.extra.processor;

class LhsPadding {
  protected long p1;
  
  protected long p2;
  
  protected long p3;
  
  protected long p4;
  
  protected long p5;
  
  protected long p6;
  
  protected long p7;
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-extra-3.4.10.jar!\reactor\extra\processor\LhsPadding.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */