/*     */ package reactor.extra.processor;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.function.LongSupplier;
/*     */ import java.util.function.Supplier;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.concurrent.Queues;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class RingBuffer<E>
/*     */   implements LongSupplier
/*     */ {
/*     */   static final long INITIAL_CURSOR_VALUE = -1L;
/*     */   
/*     */   static <T> void addSequence(T holder, AtomicReferenceFieldUpdater<T, Sequence[]> updater, Sequence sequence) {
/*     */     Sequence[] updatedSequences;
/*     */     Sequence[] currentSequences;
/*     */     do {
/*  55 */       currentSequences = updater.get(holder);
/*  56 */       updatedSequences = Arrays.<Sequence>copyOf(currentSequences, currentSequences.length + 1);
/*     */       
/*  58 */       updatedSequences[currentSequences.length] = sequence;
/*     */     }
/*  60 */     while (!updater.compareAndSet(holder, currentSequences, updatedSequences));
/*     */   }
/*     */   
/*     */   private static <T> int countMatching(T[] values, T toMatch) {
/*  64 */     int numToRemove = 0;
/*  65 */     for (T value : values) {
/*  66 */       if (value == toMatch)
/*     */       {
/*  68 */         numToRemove++;
/*     */       }
/*     */     } 
/*  71 */     return numToRemove;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T> boolean removeSequence(T holder, AtomicReferenceFieldUpdater<T, Sequence[]> sequenceUpdater, Sequence sequence) {
/*     */     int numToRemove;
/*     */     Sequence[] oldSequences;
/*     */     Sequence[] newSequences;
/*     */     do {
/*  82 */       oldSequences = sequenceUpdater.get(holder);
/*     */       
/*  84 */       numToRemove = countMatching(oldSequences, sequence);
/*     */       
/*  86 */       if (0 == numToRemove) {
/*     */         break;
/*     */       }
/*     */       
/*  90 */       int oldSize = oldSequences.length;
/*  91 */       newSequences = new Sequence[oldSize - numToRemove];
/*     */       
/*  93 */       for (int i = 0, pos = 0; i < oldSize; i++) {
/*  94 */         Sequence testSequence = oldSequences[i];
/*  95 */         if (sequence != testSequence) {
/*  96 */           newSequences[pos++] = testSequence;
/*     */         }
/*     */       }
/*     */     
/* 100 */     } while (!sequenceUpdater.compareAndSet(holder, oldSequences, newSequences));
/*     */     
/* 102 */     return (numToRemove != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <E> RingBuffer<E> createMultiProducer(Supplier<E> factory, int bufferSize, WaitStrategy waitStrategy, Runnable spinObserver) {
/* 124 */     if (hasUnsafe()) {
/*     */       
/* 126 */       MultiProducerRingBuffer sequencer = new MultiProducerRingBuffer(bufferSize, waitStrategy, spinObserver);
/*     */       
/* 128 */       return new UnsafeRingBuffer<>(factory, sequencer);
/*     */     } 
/*     */     
/* 131 */     throw new IllegalStateException("This JVM does not support sun.misc.Unsafe");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <E> RingBuffer<E> createSingleProducer(Supplier<E> factory, int bufferSize, WaitStrategy waitStrategy) {
/* 147 */     return createSingleProducer(factory, bufferSize, waitStrategy, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <E> RingBuffer<E> createSingleProducer(Supplier<E> factory, int bufferSize, WaitStrategy waitStrategy, @Nullable Runnable spinObserver) {
/* 165 */     SingleProducerSequencer sequencer = new SingleProducerSequencer(bufferSize, waitStrategy, spinObserver);
/*     */     
/* 167 */     if (hasUnsafe() && Queues.isPowerOfTwo(bufferSize)) {
/* 168 */       return new UnsafeRingBuffer<>(factory, sequencer);
/*     */     }
/*     */     
/* 171 */     return new NotFunRingBuffer<>(factory, sequencer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static long getMinimumSequence(Sequence[] sequences, long minimum) {
/* 184 */     for (int i = 0, n = sequences.length; i < n; i++) {
/* 185 */       long value = sequences[i].getAsLong();
/* 186 */       minimum = Math.min(minimum, value);
/*     */     } 
/*     */     
/* 189 */     return minimum;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static long getMinimumSequence(@Nullable Sequence excludeSequence, Sequence[] sequences, long minimum) {
/* 202 */     for (int i = 0, n = sequences.length; i < n; i++) {
/* 203 */       if (excludeSequence == null || sequences[i] != excludeSequence) {
/* 204 */         long value = sequences[i].getAsLong();
/* 205 */         minimum = Math.min(minimum, value);
/*     */       } 
/*     */     } 
/*     */     
/* 209 */     return minimum;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T> T getUnsafe() {
/* 221 */     return (T)UnsafeSupport.getUnsafe();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int log2(int i) {
/* 232 */     int r = 0;
/* 233 */     while ((i >>= 1) != 0) {
/* 234 */       r++;
/*     */     }
/* 236 */     return r;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Sequence newSequence(long init) {
/* 245 */     if (hasUnsafe()) {
/* 246 */       return new UnsafeSequence(init);
/*     */     }
/*     */     
/* 249 */     return new AtomicSequence(init);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract void addGatingSequence(Sequence paramSequence);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract int bufferSize();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract E get(long paramLong);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getAsLong() {
/* 283 */     return getCursor();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract long getCursor();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract long getMinimumGatingSequence();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract long getMinimumGatingSequence(Sequence paramSequence);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract int getPending();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Sequence[] getSequenceReceivers() {
/* 320 */     return getSequencer().getGatingSequences();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract Reader newReader();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract long next();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract long next(int paramInt);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract void publish(long paramLong);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract boolean removeGatingSequence(Sequence paramSequence);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract RingBufferProducer getSequencer();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean hasUnsafe() {
/* 381 */     return HAS_UNSAFE;
/*     */   }
/*     */   
/*     */   static boolean hasUnsafe0() {
/* 385 */     return UnsafeSupport.hasUnsafe();
/*     */   }
/*     */   
/* 388 */   private static final boolean HAS_UNSAFE = hasUnsafe0();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class Reader
/*     */   {
/*     */     private final WaitStrategy waitStrategy;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private volatile boolean alerted = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final RingBuffer.Sequence cursorSequence;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final RingBufferProducer sequenceProducer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Reader(RingBufferProducer sequenceProducer, WaitStrategy waitStrategy, RingBuffer.Sequence cursorSequence) {
/* 435 */       this.sequenceProducer = sequenceProducer;
/* 436 */       this.waitStrategy = waitStrategy;
/* 437 */       this.cursorSequence = cursorSequence;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     long waitFor(long sequence, Runnable consumer) throws InterruptedException {
/* 450 */       if (this.alerted)
/*     */       {
/* 452 */         WaitStrategy.alert();
/*     */       }
/*     */       
/* 455 */       long availableSequence = this.waitStrategy.waitFor(sequence, this.cursorSequence, consumer);
/*     */       
/* 457 */       if (availableSequence < sequence) {
/* 458 */         return availableSequence;
/*     */       }
/*     */       
/* 461 */       return this.sequenceProducer.getHighestPublishedSequence(sequence, availableSequence);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     boolean isAlerted() {
/* 469 */       return this.alerted;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void alert() {
/* 476 */       this.alerted = true;
/* 477 */       this.waitStrategy.signalAllWhenBlocking();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void signal() {
/* 484 */       this.waitStrategy.signalAllWhenBlocking();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void clearAlert() {
/* 491 */       this.alerted = false;
/*     */     }
/*     */   }
/*     */   
/*     */   static interface Sequence extends LongSupplier {
/*     */     public static final long INITIAL_VALUE = -1L;
/*     */     
/*     */     void set(long param1Long);
/*     */     
/*     */     boolean compareAndSet(long param1Long1, long param1Long2);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-extra-3.4.10.jar!\reactor\extra\processor\RingBuffer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */