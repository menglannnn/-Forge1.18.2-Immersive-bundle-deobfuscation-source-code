/*     */ package reactor.extra.processor;
/*     */ 
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import java.util.concurrent.locks.Condition;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.LockSupport;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ import java.util.function.LongSupplier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public abstract class WaitStrategy
/*     */ {
/*     */   public static WaitStrategy blocking() {
/*  42 */     return new Blocking();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WaitStrategy busySpin() {
/*  53 */     return BusySpin.INSTANCE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isAlert(Throwable t) {
/*  62 */     return (t == AlertException.INSTANCE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WaitStrategy liteBlocking() {
/*  72 */     return new LiteBlocking();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WaitStrategy parking() {
/*  85 */     return Parking.INSTANCE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WaitStrategy parking(int retries) {
/* 100 */     return new Parking(retries);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WaitStrategy phasedOff(long spinTimeout, long yieldTimeout, TimeUnit units, WaitStrategy delegate) {
/* 116 */     return new PhasedOff(spinTimeout, yieldTimeout, units, delegate);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WaitStrategy phasedOffLiteLock(long spinTimeout, long yieldTimeout, TimeUnit units) {
/* 127 */     return phasedOff(spinTimeout, yieldTimeout, units, liteBlocking());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WaitStrategy phasedOffLock(long spinTimeout, long yieldTimeout, TimeUnit units) {
/* 138 */     return phasedOff(spinTimeout, yieldTimeout, units, blocking());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WaitStrategy phasedOffSleep(long spinTimeout, long yieldTimeout, TimeUnit units) {
/* 149 */     return phasedOff(spinTimeout, yieldTimeout, units, parking(0));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WaitStrategy sleeping() {
/* 161 */     return Sleeping.INSTANCE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WaitStrategy yielding() {
/* 173 */     return Yielding.INSTANCE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void signalAllWhenBlocking() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract long waitFor(long paramLong, LongSupplier paramLongSupplier, Runnable paramRunnable) throws InterruptedException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void alert() {
/* 202 */     throw AlertException.INSTANCE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class AlertException
/*     */     extends RuntimeException
/*     */   {
/* 213 */     public static final AlertException INSTANCE = new AlertException();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Throwable fillInStackTrace() {
/* 228 */       return this;
/*     */     }
/*     */   }
/*     */   
/*     */   static final class Blocking
/*     */     extends WaitStrategy
/*     */   {
/* 235 */     private final Lock lock = new ReentrantLock();
/* 236 */     private final Condition processorNotifyCondition = this.lock.newCondition();
/*     */ 
/*     */ 
/*     */     
/*     */     public void signalAllWhenBlocking() {
/* 241 */       this.lock.lock();
/*     */       
/*     */       try {
/* 244 */         this.processorNotifyCondition.signalAll();
/*     */       }
/*     */       finally {
/*     */         
/* 248 */         this.lock.unlock();
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public long waitFor(long sequence, LongSupplier cursorSequence, Runnable barrier) throws InterruptedException {
/*     */       long availableSequence;
/* 258 */       if ((availableSequence = cursorSequence.getAsLong()) < sequence) {
/*     */         
/* 260 */         this.lock.lock();
/*     */         
/*     */         try {
/* 263 */           while ((availableSequence = cursorSequence.getAsLong()) < sequence)
/*     */           {
/* 265 */             barrier.run();
/* 266 */             this.processorNotifyCondition.await();
/*     */           }
/*     */         
/*     */         } finally {
/*     */           
/* 271 */           this.lock.unlock();
/*     */         } 
/*     */       } 
/*     */       
/* 275 */       while ((availableSequence = cursorSequence.getAsLong()) < sequence)
/*     */       {
/* 277 */         barrier.run();
/*     */       }
/*     */       
/* 280 */       return availableSequence;
/*     */     }
/*     */   }
/*     */   
/*     */   static final class BusySpin
/*     */     extends WaitStrategy
/*     */   {
/* 287 */     static final BusySpin INSTANCE = new BusySpin();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public long waitFor(long sequence, LongSupplier cursor, Runnable barrier) throws InterruptedException {
/*     */       long availableSequence;
/* 295 */       while ((availableSequence = cursor.getAsLong()) < sequence)
/*     */       {
/* 297 */         barrier.run();
/*     */       }
/*     */       
/* 300 */       return availableSequence;
/*     */     }
/*     */   }
/*     */   
/*     */   static final class Sleeping
/*     */     extends WaitStrategy
/*     */   {
/* 307 */     static final Sleeping INSTANCE = new Sleeping();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public long waitFor(long sequence, LongSupplier cursor, Runnable barrier) throws InterruptedException {
/*     */       long availableSequence;
/* 316 */       while ((availableSequence = cursor.getAsLong()) < sequence) {
/* 317 */         barrier.run();
/* 318 */         Thread.sleep(1L);
/*     */       } 
/*     */       
/* 321 */       return availableSequence;
/*     */     }
/*     */   }
/*     */   
/*     */   static final class LiteBlocking
/*     */     extends WaitStrategy {
/* 327 */     private final Lock lock = new ReentrantLock();
/* 328 */     private final Condition processorNotifyCondition = this.lock.newCondition();
/* 329 */     private final AtomicBoolean signalNeeded = new AtomicBoolean(false);
/*     */ 
/*     */ 
/*     */     
/*     */     public void signalAllWhenBlocking() {
/* 334 */       if (this.signalNeeded.getAndSet(false)) {
/*     */         
/* 336 */         this.lock.lock();
/*     */         
/*     */         try {
/* 339 */           this.processorNotifyCondition.signalAll();
/*     */         }
/*     */         finally {
/*     */           
/* 343 */           this.lock.unlock();
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public long waitFor(long sequence, LongSupplier cursorSequence, Runnable barrier) throws InterruptedException {
/*     */       long availableSequence;
/* 354 */       if ((availableSequence = cursorSequence.getAsLong()) < sequence) {
/*     */         
/* 356 */         this.lock.lock();
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         try {
/* 362 */           this.signalNeeded.getAndSet(true);
/*     */           
/* 364 */           while ((availableSequence = cursorSequence.getAsLong()) < sequence) {
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 369 */             barrier.run();
/* 370 */             this.processorNotifyCondition.await();
/*     */             
/* 372 */             if ((availableSequence = cursorSequence.getAsLong()) >= sequence)
/*     */               break; 
/*     */           } 
/*     */         } finally {
/* 376 */           this.lock.unlock();
/*     */         } 
/*     */       } 
/*     */       
/* 380 */       while ((availableSequence = cursorSequence.getAsLong()) < sequence)
/*     */       {
/* 382 */         barrier.run();
/*     */       }
/*     */       
/* 385 */       return availableSequence;
/*     */     }
/*     */   }
/*     */   
/*     */   static final class PhasedOff
/*     */     extends WaitStrategy
/*     */   {
/*     */     private final long spinTimeoutNanos;
/*     */     private final long yieldTimeoutNanos;
/*     */     private final WaitStrategy fallbackStrategy;
/*     */     private static final int SPIN_TRIES = 10000;
/*     */     
/*     */     PhasedOff(long spinTimeout, long yieldTimeout, TimeUnit units, WaitStrategy fallbackStrategy) {
/* 398 */       this.spinTimeoutNanos = units.toNanos(spinTimeout);
/* 399 */       this.yieldTimeoutNanos = this.spinTimeoutNanos + units.toNanos(yieldTimeout);
/* 400 */       this.fallbackStrategy = fallbackStrategy;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void signalAllWhenBlocking() {
/* 406 */       this.fallbackStrategy.signalAllWhenBlocking();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public long waitFor(long sequence, LongSupplier cursor, Runnable barrier) throws InterruptedException {
/* 414 */       long startTime = 0L;
/* 415 */       int counter = 10000;
/*     */       
/*     */       while (true) {
/*     */         long availableSequence;
/* 419 */         if ((availableSequence = cursor.getAsLong()) >= sequence)
/*     */         {
/* 421 */           return availableSequence;
/*     */         }
/*     */         
/* 424 */         if (0 == --counter) {
/*     */           
/* 426 */           if (0L == startTime) {
/*     */             
/* 428 */             startTime = System.nanoTime();
/*     */           }
/*     */           else {
/*     */             
/* 432 */             long timeDelta = System.nanoTime() - startTime;
/* 433 */             if (timeDelta > this.yieldTimeoutNanos)
/*     */             {
/* 435 */               return this.fallbackStrategy.waitFor(sequence, cursor, barrier);
/*     */             }
/* 437 */             if (timeDelta > this.spinTimeoutNanos)
/*     */             {
/* 439 */               Thread.yield();
/*     */             }
/*     */           } 
/* 442 */           counter = 10000;
/*     */         } 
/* 444 */         barrier.run();
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static final class Parking
/*     */     extends WaitStrategy
/*     */   {
/* 454 */     static final Parking INSTANCE = new Parking();
/*     */     private final int retries;
/*     */     private static final int DEFAULT_RETRIES = 200;
/*     */     
/*     */     Parking() {
/* 459 */       this(200);
/*     */     }
/*     */     
/*     */     Parking(int retries) {
/* 463 */       this.retries = retries;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public long waitFor(long sequence, LongSupplier cursor, Runnable barrier) throws InterruptedException {
/* 471 */       int counter = this.retries;
/*     */       long availableSequence;
/* 473 */       while ((availableSequence = cursor.getAsLong()) < sequence)
/*     */       {
/* 475 */         counter = applyWaitMethod(barrier, counter);
/*     */       }
/*     */       
/* 478 */       return availableSequence;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private int applyWaitMethod(Runnable barrier, int counter) throws WaitStrategy.AlertException {
/* 484 */       barrier.run();
/*     */       
/* 486 */       if (counter > 100) {
/*     */         
/* 488 */         counter--;
/*     */       }
/* 490 */       else if (counter > 0) {
/*     */         
/* 492 */         counter--;
/* 493 */         Thread.yield();
/*     */       }
/*     */       else {
/*     */         
/* 497 */         LockSupport.parkNanos(1L);
/*     */       } 
/*     */       
/* 500 */       return counter;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class Yielding
/*     */     extends WaitStrategy
/*     */   {
/* 508 */     static final Yielding INSTANCE = new Yielding();
/*     */     
/*     */     private static final int SPIN_TRIES = 100;
/*     */ 
/*     */     
/*     */     public long waitFor(long sequence, LongSupplier cursor, Runnable barrier) throws InterruptedException {
/* 514 */       int counter = 100;
/*     */       long availableSequence;
/* 516 */       while ((availableSequence = cursor.getAsLong()) < sequence) {
/* 517 */         counter = applyWaitMethod(barrier, counter);
/*     */       }
/*     */       
/* 520 */       return availableSequence;
/*     */     }
/*     */ 
/*     */     
/*     */     private int applyWaitMethod(Runnable barrier, int counter) throws WaitStrategy.AlertException {
/* 525 */       barrier.run();
/*     */       
/* 527 */       if (0 == counter) {
/* 528 */         Thread.yield();
/*     */       } else {
/*     */         
/* 531 */         counter--;
/*     */       } 
/*     */       
/* 534 */       return counter;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-extra-3.4.10.jar!\reactor\extra\processor\WaitStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */