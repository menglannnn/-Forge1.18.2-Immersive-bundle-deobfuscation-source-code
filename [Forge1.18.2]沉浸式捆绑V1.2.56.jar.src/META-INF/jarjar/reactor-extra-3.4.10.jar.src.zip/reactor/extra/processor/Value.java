package reactor.extra.processor;

class Value extends LhsPadding {
  protected volatile long value;
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-extra-3.4.10.jar!\reactor\extra\processor\Value.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */