package reactor.function;

@FunctionalInterface
public interface Predicate5<T1, T2, T3, T4, T5> {
  boolean test(T1 paramT1, T2 paramT2, T3 paramT3, T4 paramT4, T5 paramT5);
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-extra-3.4.10.jar!\reactor\function\Predicate5.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */