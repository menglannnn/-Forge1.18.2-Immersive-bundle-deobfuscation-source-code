package reactor.function;

@FunctionalInterface
public interface Consumer4<T1, T2, T3, T4> {
  void accept(T1 paramT1, T2 paramT2, T3 paramT3, T4 paramT4);
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-extra-3.4.10.jar!\reactor\function\Consumer4.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */