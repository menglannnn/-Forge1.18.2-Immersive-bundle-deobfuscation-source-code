package reactor.function;

@FunctionalInterface
public interface Consumer3<T1, T2, T3> {
  void accept(T1 paramT1, T2 paramT2, T3 paramT3);
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-extra-3.4.10.jar!\reactor\function\Consumer3.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */