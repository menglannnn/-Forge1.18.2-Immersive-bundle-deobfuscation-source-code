/*     */ package reactor.scheduler.forkjoin;
/*     */ 
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.Objects;
/*     */ import java.util.Queue;
/*     */ import java.util.concurrent.Executor;
/*     */ import java.util.concurrent.ForkJoinPool;
/*     */ import java.util.concurrent.ForkJoinTask;
/*     */ import java.util.concurrent.ForkJoinWorkerThread;
/*     */ import java.util.concurrent.RejectedExecutionException;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ import java.util.function.BiConsumer;
/*     */ import java.util.function.BooleanSupplier;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.scheduler.Scheduler;
/*     */ import reactor.core.scheduler.Schedulers;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.Loggers;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ForkJoinPoolScheduler
/*     */   implements Scheduler
/*     */ {
/*     */   private static volatile BiConsumer<Thread, ? super Throwable> onHandleErrorHook;
/*     */   private final ForkJoinPool pool;
/*     */   private final Scheduler scheduler;
/*     */   private final boolean disposeScheduler;
/*     */   
/*     */   public static Scheduler create(String name) {
/*  55 */     return create(name, 
/*  56 */         Runtime.getRuntime()
/*  57 */         .availableProcessors());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Scheduler create(String name, int parallelism) {
/*  72 */     return new ForkJoinPoolScheduler(parallelism, new SchedulerForkJoinWorkerThreadFactory(name, COUNTER), 
/*     */         
/*  74 */         Schedulers.newSingle(name + "-timer", true), true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Scheduler create(int parallelism, ForkJoinPool.ForkJoinWorkerThreadFactory workerThreadFactory, Scheduler timeScheduler) {
/*  94 */     return new ForkJoinPoolScheduler(parallelism, workerThreadFactory, timeScheduler, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void handleError(Throwable ex) {
/* 101 */     Thread thread = Thread.currentThread();
/* 102 */     Throwable t = Exceptions.unwrap(ex);
/* 103 */     Exceptions.throwIfJvmFatal(t);
/* 104 */     Thread.UncaughtExceptionHandler x = thread.getUncaughtExceptionHandler();
/* 105 */     if (x != null) {
/* 106 */       x.uncaughtException(thread, t);
/*     */     } else {
/*     */       
/* 109 */       log.error("Scheduler worker failed with an uncaught exception", t);
/*     */     } 
/* 111 */     if (onHandleErrorHook != null) {
/* 112 */       onHandleErrorHook.accept(thread, t);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void onHandleError(BiConsumer<Thread, ? super Throwable> c) {
/* 125 */     log.info("Hooking new: onHandleError");
/* 126 */     onHandleErrorHook = Objects.<BiConsumer<Thread, ? super Throwable>>requireNonNull(c, "onHandleError");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void resetOnHandleError() {
/* 133 */     log.info("Reset to default: onHandleError");
/* 134 */     onHandleErrorHook = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ForkJoinPoolScheduler(int parallelism, ForkJoinPool.ForkJoinWorkerThreadFactory workerThreadFactory, Scheduler scheduler, boolean disposeScheduler) {
/* 153 */     this.pool = new ForkJoinPool(parallelism, workerThreadFactory, this::uncaughtException, true);
/*     */ 
/*     */ 
/*     */     
/* 157 */     this.scheduler = scheduler;
/* 158 */     this.disposeScheduler = disposeScheduler;
/*     */   }
/*     */ 
/*     */   
/*     */   public Scheduler.Worker createWorker() {
/* 163 */     return new Worker(this.pool, this.scheduler);
/*     */   }
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 168 */     if (this.disposeScheduler) {
/* 169 */       this.scheduler.dispose();
/*     */     }
/* 171 */     this.pool.shutdownNow();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDisposed() {
/* 176 */     return this.pool.isShutdown();
/*     */   }
/*     */ 
/*     */   
/*     */   public Disposable schedule(Runnable runnable) {
/* 181 */     return new DisposableForkJoinTask(this.pool.submit(runnable));
/*     */   }
/*     */ 
/*     */   
/*     */   public Disposable schedule(Runnable task, long delay, TimeUnit unit) {
/* 186 */     if (delay == 0L) {
/* 187 */       return schedule(task);
/*     */     }
/* 189 */     TrampolinedTask trampolinedTask = new TrampolinedTask(this.pool, task, NO_PARENT);
/* 190 */     return new CompositeDisposable(this.scheduler.schedule(trampolinedTask, delay, unit), trampolinedTask);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Disposable schedulePeriodically(Runnable task, long initialDelay, long period, TimeUnit unit) {
/* 198 */     TrampolinedTask trampolinedTask = new TrampolinedTask(this.pool, task, NO_PARENT);
/*     */     
/* 200 */     return new CompositeDisposable(this.scheduler.schedulePeriodically(trampolinedTask, initialDelay, period, unit), trampolinedTask);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void uncaughtException(Thread t, Throwable e) {
/* 207 */     log.error("Scheduler worker in group " + t.getThreadGroup()
/* 208 */         .getName() + " failed with an uncaught exception", e);
/*     */   }
/*     */   
/*     */   private static class DisposableForkJoinTask
/*     */     implements Disposable
/*     */   {
/*     */     private final ForkJoinTask<?> task;
/*     */     
/*     */     DisposableForkJoinTask(ForkJoinTask<?> task) {
/* 217 */       this.task = task;
/*     */     }
/*     */ 
/*     */     
/*     */     public void dispose() {
/* 222 */       this.task.cancel(false);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isDisposed() {
/* 227 */       return this.task.isDone();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class TrampolinedTask
/*     */     implements Runnable, Disposable
/*     */   {
/*     */     private final Executor executor;
/*     */     private final Runnable task;
/*     */     private final BooleanSupplier isParentDisposed;
/*     */     private volatile boolean disposed;
/*     */     
/*     */     public TrampolinedTask(Executor executor, Runnable task, BooleanSupplier isParentDisposed) {
/* 241 */       this.executor = executor;
/* 242 */       this.task = task;
/* 243 */       this.isParentDisposed = isParentDisposed;
/*     */     }
/*     */ 
/*     */     
/*     */     public void dispose() {
/* 248 */       this.disposed = true;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isDisposed() {
/* 253 */       return (this.disposed || this.isParentDisposed.getAsBoolean());
/*     */     }
/*     */ 
/*     */     
/*     */     public void run() {
/* 258 */       this.executor.execute(() -> {
/*     */             if (!isDisposed())
/*     */               this.task.run(); 
/*     */           });
/*     */     }
/*     */   }
/*     */   
/*     */   static final class CompositeDisposable
/*     */     implements Disposable
/*     */   {
/*     */     final Disposable a;
/*     */     final Disposable b;
/*     */     
/*     */     CompositeDisposable(Disposable a, Disposable b) {
/* 272 */       this.a = a;
/* 273 */       this.b = b;
/*     */     }
/*     */ 
/*     */     
/*     */     public void dispose() {
/* 278 */       this.a.dispose();
/* 279 */       this.b.dispose();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isDisposed() {
/* 284 */       return (this.a.isDisposed() && this.b.isDisposed());
/*     */     }
/*     */   }
/*     */   
/*     */   private static class Worker
/*     */     implements Scheduler.Worker {
/*     */     private final Executor executor;
/*     */     private final Scheduler scheduler;
/* 292 */     private final Object lock = new Object();
/* 293 */     private final Queue<Runnable> tasks = new ArrayDeque<>();
/*     */     private boolean executing = false;
/* 295 */     private final Runnable processTaskQueue = this::processTaskQueue;
/* 296 */     private final Executor workerExecutor = this::execute;
/*     */     private volatile boolean shutdown;
/* 298 */     private final BooleanSupplier isDisposed = this::isDisposed;
/*     */     
/*     */     Worker(Executor executor, Scheduler scheduler) {
/* 301 */       this.executor = executor;
/* 302 */       this.scheduler = scheduler;
/*     */     }
/*     */ 
/*     */     
/*     */     public void dispose() {
/* 307 */       if (this.shutdown) {
/*     */         return;
/*     */       }
/*     */       
/* 311 */       this.shutdown = true;
/*     */       
/* 313 */       synchronized (this.lock) {
/* 314 */         this.tasks.clear();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isDisposed() {
/* 320 */       return this.shutdown;
/*     */     }
/*     */ 
/*     */     
/*     */     public Disposable schedule(Runnable task) {
/* 325 */       if (this.shutdown) {
/* 326 */         throw Exceptions.failWithRejected();
/*     */       }
/*     */       
/* 329 */       ForkJoinPoolScheduler.DisposableWorkerTask workerTask = new ForkJoinPoolScheduler.DisposableWorkerTask(task, this.isDisposed);
/*     */       
/*     */       try {
/* 332 */         execute(workerTask);
/*     */       }
/* 334 */       catch (RejectedExecutionException ignored) {
/*     */         
/* 336 */         workerTask.dispose();
/* 337 */         throw ignored;
/*     */       } 
/*     */       
/* 340 */       return workerTask;
/*     */     }
/*     */ 
/*     */     
/*     */     public Disposable schedule(Runnable task, long delay, TimeUnit unit) {
/* 345 */       if (delay == 0L) {
/* 346 */         return schedule(task);
/*     */       }
/*     */       
/* 349 */       if (this.shutdown) {
/* 350 */         throw Exceptions.failWithRejected();
/*     */       }
/*     */       
/* 353 */       ForkJoinPoolScheduler.TrampolinedTask trampolinedTask = new ForkJoinPoolScheduler.TrampolinedTask(this.workerExecutor, task, this.isDisposed);
/*     */       
/* 355 */       return new ForkJoinPoolScheduler.CompositeDisposable(this.scheduler.schedule(trampolinedTask, delay, unit), trampolinedTask);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Disposable schedulePeriodically(Runnable task, long initialDelay, long period, TimeUnit unit) {
/* 363 */       if (this.shutdown) {
/* 364 */         throw Exceptions.failWithRejected();
/*     */       }
/*     */       
/* 367 */       ForkJoinPoolScheduler.TrampolinedTask trampolinedTask = new ForkJoinPoolScheduler.TrampolinedTask(this.workerExecutor, task, this.isDisposed);
/*     */ 
/*     */       
/* 370 */       return new ForkJoinPoolScheduler.CompositeDisposable(this.scheduler.schedulePeriodically(trampolinedTask, initialDelay, period, unit), trampolinedTask);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void execute(Runnable command) {
/*     */       boolean schedule;
/* 378 */       synchronized (this.lock) {
/* 379 */         this.tasks.add(command);
/*     */         
/* 381 */         if (this.executing) {
/* 382 */           schedule = false;
/*     */         } else {
/*     */           
/* 385 */           this.executing = true;
/* 386 */           schedule = true;
/*     */         } 
/*     */       } 
/*     */       
/* 390 */       if (schedule) {
/* 391 */         this.executor.execute(this.processTaskQueue);
/*     */       }
/*     */     }
/*     */     
/*     */     private void processTaskQueue() {
/*     */       while (true) {
/*     */         Runnable task;
/* 398 */         synchronized (this.lock) {
/* 399 */           task = this.tasks.poll();
/* 400 */           if (task == null) {
/* 401 */             this.executing = false;
/*     */             
/*     */             return;
/*     */           } 
/*     */         } 
/*     */         try {
/* 407 */           task.run();
/*     */         }
/* 409 */         catch (Throwable ex) {
/* 410 */           ForkJoinPoolScheduler.handleError(ex);
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private static class DisposableWorkerTask
/*     */     implements Disposable, Runnable {
/*     */     private final Runnable task;
/*     */     private final BooleanSupplier isParentDisposed;
/*     */     private volatile boolean disposed;
/*     */     
/*     */     private DisposableWorkerTask(Runnable task, BooleanSupplier disposed) {
/* 423 */       this.task = task;
/* 424 */       this.isParentDisposed = disposed;
/*     */     }
/*     */ 
/*     */     
/*     */     public void dispose() {
/* 429 */       this.disposed = true;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isDisposed() {
/* 434 */       return (this.disposed || this.isParentDisposed.getAsBoolean());
/*     */     }
/*     */ 
/*     */     
/*     */     public void run() {
/* 439 */       if (isDisposed()) {
/*     */         return;
/*     */       }
/*     */       
/* 443 */       this.task.run();
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class SchedulerForkJoinWorkerThread
/*     */     extends ForkJoinWorkerThread
/*     */   {
/*     */     SchedulerForkJoinWorkerThread(String name, ForkJoinPool pool) {
/* 451 */       super(pool);
/* 452 */       setName(name);
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class SchedulerForkJoinWorkerThreadFactory
/*     */     implements ForkJoinPool.ForkJoinWorkerThreadFactory
/*     */   {
/*     */     final String name;
/*     */     final AtomicLong COUNTER;
/*     */     
/*     */     SchedulerForkJoinWorkerThreadFactory(String name, AtomicLong COUNTER) {
/* 463 */       this.name = name;
/* 464 */       this.COUNTER = COUNTER;
/*     */     }
/*     */ 
/*     */     
/*     */     public ForkJoinWorkerThread newThread(ForkJoinPool pool) {
/* 469 */       return new ForkJoinPoolScheduler.SchedulerForkJoinWorkerThread(this.name + "-" + this.COUNTER.incrementAndGet(), pool);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/* 474 */   private static final AtomicLong COUNTER = new AtomicLong();
/* 475 */   private static final Logger log = Loggers.getLogger(Schedulers.class);
/*     */   private static final BooleanSupplier NO_PARENT = () -> false;
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-extra-3.4.10.jar!\reactor\scheduler\forkjoin\ForkJoinPoolScheduler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */