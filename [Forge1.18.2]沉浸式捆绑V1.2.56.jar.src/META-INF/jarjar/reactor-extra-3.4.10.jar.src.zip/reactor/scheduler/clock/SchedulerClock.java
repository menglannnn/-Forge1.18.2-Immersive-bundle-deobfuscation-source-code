/*     */ package reactor.scheduler.clock;
/*     */ 
/*     */ import java.time.Clock;
/*     */ import java.time.Instant;
/*     */ import java.time.ZoneId;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import reactor.core.scheduler.Scheduler;
/*     */ import reactor.util.annotation.NonNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SchedulerClock
/*     */   extends Clock
/*     */ {
/*     */   private static final long NANOS_PER_SECOND = 1000000000L;
/*     */   private final Scheduler scheduler;
/*     */   private final ZoneId zone;
/*     */   
/*     */   private SchedulerClock(Scheduler scheduler, ZoneId zone) {
/*  63 */     this.scheduler = scheduler;
/*  64 */     this.zone = zone;
/*     */   }
/*     */ 
/*     */   
/*     */   @NonNull
/*     */   public ZoneId getZone() {
/*  70 */     return this.zone;
/*     */   }
/*     */ 
/*     */   
/*     */   @NonNull
/*     */   public SchedulerClock withZone(ZoneId zone) {
/*  76 */     return new SchedulerClock(this.scheduler, zone);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NonNull
/*     */   public Scheduler getScheduler() {
/*  86 */     return this.scheduler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NonNull
/*     */   public SchedulerClock withScheduler(Scheduler scheduler) {
/*  97 */     return new SchedulerClock(scheduler, this.zone);
/*     */   }
/*     */ 
/*     */   
/*     */   public long millis() {
/* 102 */     return this.scheduler.now(TimeUnit.MILLISECONDS);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NonNull
/*     */   public Instant instant() {
/* 118 */     long nano = this.scheduler.now(TimeUnit.NANOSECONDS);
/* 119 */     long secs = Math.floorDiv(nano, 1000000000L);
/* 120 */     long nos = Math.floorMod(nano, 1000000000L);
/*     */     
/* 122 */     return Instant.ofEpochSecond(secs, nos);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 127 */     if (this == o) {
/* 128 */       return true;
/*     */     }
/* 130 */     if (o == null || getClass() != o.getClass()) {
/* 131 */       return false;
/*     */     }
/* 133 */     if (!super.equals(o)) {
/* 134 */       return false;
/*     */     }
/*     */     
/* 137 */     SchedulerClock that = (SchedulerClock)o;
/*     */     
/* 139 */     return (this.scheduler.equals(that.scheduler) && this.zone.equals(that.zone));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 145 */     int result = super.hashCode();
/* 146 */     result = 31 * result + this.scheduler.hashCode();
/* 147 */     result = 31 * result + this.zone.hashCode();
/* 148 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 153 */     return "SchedulerClock{scheduler=" + this.scheduler + ", zone=" + this.zone + '}';
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NonNull
/*     */   public static SchedulerClock of(@NonNull Scheduler scheduler) {
/* 166 */     return new SchedulerClock(scheduler, ZoneId.systemDefault());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NonNull
/*     */   public static SchedulerClock of(@NonNull Scheduler scheduler, @NonNull ZoneId zoneId) {
/* 180 */     return new SchedulerClock(scheduler, zoneId);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-extra-3.4.10.jar!\reactor\scheduler\clock\SchedulerClock.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */