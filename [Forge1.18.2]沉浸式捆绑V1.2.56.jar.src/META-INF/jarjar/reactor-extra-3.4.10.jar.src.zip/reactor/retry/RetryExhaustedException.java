/*    */ package reactor.retry;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class RetryExhaustedException
/*    */   extends RuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = 6961442923363481283L;
/*    */   
/*    */   public RetryExhaustedException() {}
/*    */   
/*    */   public RetryExhaustedException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
/* 38 */     super(message, cause, enableSuppression, writableStackTrace);
/*    */   }
/*    */   
/*    */   public RetryExhaustedException(String message, Throwable cause) {
/* 42 */     super(message, cause);
/*    */   }
/*    */   
/*    */   public RetryExhaustedException(String message) {
/* 46 */     super(message);
/*    */   }
/*    */   
/*    */   public RetryExhaustedException(Throwable cause) {
/* 50 */     super(cause);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-extra-3.4.10.jar!\reactor\retry\RetryExhaustedException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */