package reactor.retry;

@Deprecated
public interface RetryContext<T> extends IterationContext<T> {
  Throwable exception();
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-extra-3.4.10.jar!\reactor\retry\RetryContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */