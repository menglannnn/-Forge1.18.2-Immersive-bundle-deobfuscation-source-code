/*    */ package reactor.retry;
/*    */ 
/*    */ import java.time.Duration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultContext<T>
/*    */   implements RetryContext<T>, RepeatContext<T>
/*    */ {
/*    */   final T applicationContext;
/*    */   final long iteration;
/*    */   final Long repeatCompanionValue;
/*    */   final Throwable exception;
/*    */   final BackoffDelay backoff;
/*    */   BackoffDelay lastBackoff;
/*    */   
/*    */   public DefaultContext(T applicationContext, long iteration, BackoffDelay backoff, long repeatCompanionValue) {
/* 34 */     this(applicationContext, iteration, backoff, Long.valueOf(repeatCompanionValue), null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public DefaultContext(T applicationContext, long iteration, BackoffDelay backoff, Throwable exception) {
/* 41 */     this(applicationContext, iteration, backoff, null, exception);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private DefaultContext(T applicationContext, long iteration, BackoffDelay backoff, Long repeatCompanionValue, Throwable exception) {
/* 49 */     this.applicationContext = applicationContext;
/* 50 */     this.iteration = iteration;
/* 51 */     this.backoff = backoff;
/* 52 */     this.repeatCompanionValue = repeatCompanionValue;
/* 53 */     this.exception = exception;
/*    */   }
/*    */ 
/*    */   
/*    */   public T applicationContext() {
/* 58 */     return this.applicationContext;
/*    */   }
/*    */ 
/*    */   
/*    */   public long iteration() {
/* 63 */     return this.iteration;
/*    */   }
/*    */ 
/*    */   
/*    */   public Long companionValue() {
/* 68 */     return this.repeatCompanionValue;
/*    */   }
/*    */ 
/*    */   
/*    */   public Throwable exception() {
/* 73 */     return this.exception;
/*    */   }
/*    */ 
/*    */   
/*    */   public Duration backoff() {
/* 78 */     return (this.backoff == null) ? null : this.backoff.delay;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 83 */     if (this.exception != null) {
/* 84 */       return String.format("iteration=%d exception=%s backoff=%s", new Object[] { Long.valueOf(this.iteration), this.exception, this.backoff });
/*    */     }
/* 86 */     return String.format("iteration=%d repeatCompanionValue=%s backoff=%s", new Object[] { Long.valueOf(this.iteration), this.repeatCompanionValue, this.backoff });
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-extra-3.4.10.jar!\reactor\retry\DefaultContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */