/*     */ package reactor.retry;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Predicate;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.scheduler.Scheduler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public interface Retry<T>
/*     */   extends Function<Flux<Throwable>, Publisher<Long>>
/*     */ {
/*     */   static <T> Retry<T> any() {
/*  62 */     return DefaultRetry.create(context -> true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SafeVarargs
/*     */   static <T> Retry<T> anyOf(Class<? extends Throwable>... retriableExceptions) {
/*  76 */     Predicate<? super RetryContext<T>> predicate = context -> {
/*     */         Throwable exception = context.exception();
/*     */         if (exception == null)
/*     */           return true; 
/*     */         for (Class<? extends Throwable> clazz : retriableExceptions) {
/*     */           if (clazz.isInstance(exception))
/*     */             return true; 
/*     */         } 
/*     */         return false;
/*     */       };
/*  86 */     return DefaultRetry.create(predicate);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SafeVarargs
/*     */   static <T> Retry<T> allBut(Class<? extends Throwable>... nonRetriableExceptions) {
/* 100 */     Predicate<? super RetryContext<T>> predicate = context -> {
/*     */         Throwable exception = context.exception();
/*     */         if (exception == null)
/*     */           return true; 
/*     */         for (Class<? extends Throwable> clazz : nonRetriableExceptions) {
/*     */           if (clazz.isInstance(exception))
/*     */             return false; 
/*     */         } 
/*     */         return true;
/*     */       };
/* 110 */     return DefaultRetry.create(predicate);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T> Retry<T> onlyIf(Predicate<? super RetryContext<T>> predicate) {
/* 120 */     return DefaultRetry.<T>create(predicate).retryMax(Long.MAX_VALUE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Retry<T> retryOnce() {
/* 154 */     return retryMax(1L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Retry<T> noBackoff() {
/* 212 */     return backoff(Backoff.zero());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Retry<T> fixedBackoff(Duration backoffInterval) {
/* 224 */     return backoff(Backoff.fixed(backoffInterval));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Retry<T> exponentialBackoff(Duration firstBackoff, Duration maxBackoff) {
/* 241 */     return backoff(Backoff.exponential(firstBackoff, maxBackoff, 2, false));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Retry<T> exponentialBackoffWithJitter(Duration firstBackoff, Duration maxBackoff) {
/* 258 */     return backoff(Backoff.exponential(firstBackoff, maxBackoff, 2, false)).jitter(Jitter.random());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Retry<T> randomBackoff(Duration firstBackoff, Duration maxBackoff) {
/* 275 */     return backoff(Backoff.exponential(firstBackoff, maxBackoff, 3, true)).jitter(Jitter.random());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default <S> Flux<S> apply(Publisher<S> source) {
/* 295 */     return Flux.from(source).retryWhen(reactor.util.retry.Retry.withThrowable(this));
/*     */   }
/*     */   
/*     */   Retry<T> withApplicationContext(T paramT);
/*     */   
/*     */   Retry<T> doOnRetry(Consumer<? super RetryContext<T>> paramConsumer);
/*     */   
/*     */   Retry<T> retryMax(long paramLong);
/*     */   
/*     */   Retry<T> timeout(Duration paramDuration);
/*     */   
/*     */   Retry<T> backoff(Backoff paramBackoff);
/*     */   
/*     */   Retry<T> jitter(Jitter paramJitter);
/*     */   
/*     */   Retry<T> withBackoffScheduler(Scheduler paramScheduler);
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-extra-3.4.10.jar!\reactor\retry\Retry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */