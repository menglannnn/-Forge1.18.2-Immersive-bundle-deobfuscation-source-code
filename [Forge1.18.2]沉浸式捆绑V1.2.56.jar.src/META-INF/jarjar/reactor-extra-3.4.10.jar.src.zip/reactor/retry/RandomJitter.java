/*     */ package reactor.retry;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.util.concurrent.ThreadLocalRandom;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class RandomJitter
/*     */   implements Jitter
/*     */ {
/*     */   private final double randomFactor;
/*     */   
/*     */   public RandomJitter(double randomFactor) {
/*  33 */     if (randomFactor < 0.0D || randomFactor > 1.0D) throw new IllegalArgumentException("random factor must be between 0 and 1 (default 0.5)"); 
/*  34 */     this.randomFactor = randomFactor;
/*     */   }
/*     */ 
/*     */   
/*     */   public Duration apply(BackoffDelay backoff) {
/*     */     long jitter;
/*  40 */     if (backoff.delay.compareTo(backoff.min) < 0) {
/*  41 */       throw new IllegalArgumentException("jitter can only be applied on a delay that is >= to min backoff");
/*     */     }
/*  43 */     if (backoff.delay.compareTo(backoff.max) > 0) {
/*  44 */       throw new IllegalArgumentException("jitter can only be applied on a delay that is <= to max backoff");
/*     */     }
/*     */ 
/*     */     
/*  48 */     if (backoff.delay.isZero()) {
/*  49 */       return backoff.delay;
/*     */     }
/*     */     
/*  52 */     ThreadLocalRandom random = ThreadLocalRandom.current();
/*     */     
/*  54 */     long jitterOffset = jitterOffsetCapped(backoff);
/*  55 */     long lowBound = lowJitterBound(backoff, jitterOffset);
/*  56 */     long highBound = highJitterBound(backoff, jitterOffset);
/*     */ 
/*     */     
/*  59 */     if (highBound == lowBound) {
/*  60 */       if (highBound == 0L) { jitter = 0L; }
/*  61 */       else { jitter = random.nextLong(highBound); }
/*     */     
/*     */     } else {
/*  64 */       jitter = random.nextLong(lowBound, highBound);
/*     */     } 
/*  66 */     return backoff.delay.plusMillis(jitter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   long jitterOffsetCapped(BackoffDelay backoff) {
/*     */     try {
/*  75 */       return backoff.delay.multipliedBy((long)(100.0D * this.randomFactor))
/*  76 */         .dividedBy(100L)
/*  77 */         .toMillis();
/*     */     }
/*  79 */     catch (ArithmeticException ae) {
/*  80 */       return Math.round(9.223372036854776E18D * this.randomFactor);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   long lowJitterBound(BackoffDelay backoff, long jitterOffset) {
/*  93 */     return Math.max(backoff.min
/*  94 */         .minus(backoff.delay).toMillis(), -jitterOffset);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   long highJitterBound(BackoffDelay backoff, long jitterOffset) {
/* 107 */     return Math.min(backoff.max
/* 108 */         .minus(backoff.delay).toMillis(), jitterOffset);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 114 */     return "Jitter{RANDOM-" + this.randomFactor + "}";
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-extra-3.4.10.jar!\reactor\retry\RandomJitter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */