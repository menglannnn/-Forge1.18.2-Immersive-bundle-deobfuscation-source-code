/*     */ package reactor.retry;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.util.function.Function;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface Backoff
/*     */   extends Function<IterationContext<?>, BackoffDelay>
/*     */ {
/*  30 */   public static final Backoff ZERO_BACKOFF = new Backoff()
/*     */     {
/*     */       public BackoffDelay apply(IterationContext<?> context) {
/*  33 */         return BackoffDelay.ZERO;
/*     */       }
/*     */ 
/*     */       
/*     */       public String toString() {
/*  38 */         return "Backoff{ZERO}";
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Backoff zero() {
/*  47 */     return ZERO_BACKOFF;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Backoff fixed(final Duration backoffInterval) {
/*  56 */     return new Backoff()
/*     */       {
/*     */         public BackoffDelay apply(IterationContext<?> context) {
/*  59 */           return new BackoffDelay(backoffInterval);
/*     */         }
/*     */ 
/*     */         
/*     */         public String toString() {
/*  64 */           return "Backoff{fixed=" + backoffInterval.toMillis() + "ms}";
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Backoff exponential(final Duration firstBackoff, @Nullable final Duration maxBackoff, final int factor, boolean basedOnPreviousValue) {
/*  87 */     if (firstBackoff == null || firstBackoff.isNegative() || firstBackoff.isZero())
/*  88 */       throw new IllegalArgumentException("firstBackoff must be > 0"); 
/*  89 */     Duration cap = Duration.ofMillis(Long.MAX_VALUE);
/*  90 */     if (maxBackoff != null && maxBackoff.compareTo(cap) > 0) {
/*  91 */       throw new IllegalArgumentException("maxBackoff must be less than Long.MAX_VALUE milliseconds");
/*     */     }
/*  93 */     final Duration maxBackoffInterval = (maxBackoff != null && maxBackoff.compareTo(cap) < 0) ? maxBackoff : cap;
/*  94 */     if (maxBackoffInterval.compareTo(firstBackoff) < 0)
/*  95 */       throw new IllegalArgumentException("maxBackoff must be >= firstBackoff"); 
/*  96 */     if (!basedOnPreviousValue) {
/*  97 */       return new Backoff()
/*     */         {
/*     */           public BackoffDelay apply(IterationContext<?> context) {
/*     */             Duration nextBackoff;
/* 101 */             if (context.backoff() != null && context.backoff().compareTo(maxBackoffInterval) >= 0) {
/* 102 */               nextBackoff = maxBackoffInterval;
/*     */             } else {
/*     */               
/*     */               try {
/* 106 */                 nextBackoff = firstBackoff.multipliedBy((long)Math.pow(factor, (context.iteration() - 1L)));
/* 107 */                 if (nextBackoff.compareTo(maxBackoffInterval) >= 0) {
/* 108 */                   nextBackoff = maxBackoffInterval;
/*     */                 }
/*     */               }
/* 111 */               catch (ArithmeticException e) {
/* 112 */                 nextBackoff = maxBackoffInterval;
/*     */               } 
/*     */             } 
/* 115 */             return new BackoffDelay(firstBackoff, maxBackoffInterval, nextBackoff);
/*     */           }
/*     */ 
/*     */           
/*     */           public String toString() {
/* 120 */             return String.format("Backoff{exponential,min=%sms,max=%s,factor=%s,basedOnPreviousValue=false}", new Object[] {
/* 121 */                   Long.valueOf(this.val$firstBackoff.toMillis()), (this.val$maxBackoff == null) ? "NONE" : (this.val$maxBackoff
/* 122 */                   .toMillis() + "ms"), 
/* 123 */                   Integer.valueOf(this.val$factor)
/*     */                 });
/*     */           }
/*     */         };
/*     */     }
/* 128 */     return new Backoff()
/*     */       {
/*     */         public BackoffDelay apply(IterationContext<?> context) {
/* 131 */           Duration prevBackoff = (context.backoff() == null) ? Duration.ZERO : context.backoff();
/*     */           
/* 133 */           if (prevBackoff.compareTo(maxBackoffInterval) >= 0) {
/* 134 */             nextBackoff = maxBackoffInterval;
/*     */           } else {
/*     */             try {
/* 137 */               nextBackoff = prevBackoff.multipliedBy(factor);
/* 138 */               if (nextBackoff.compareTo(maxBackoffInterval) >= 0) {
/* 139 */                 nextBackoff = maxBackoffInterval;
/*     */               }
/*     */             }
/* 142 */             catch (ArithmeticException e) {
/* 143 */               nextBackoff = maxBackoffInterval;
/*     */             } 
/* 145 */           }  Duration nextBackoff = (nextBackoff.compareTo(firstBackoff) < 0) ? firstBackoff : nextBackoff;
/* 146 */           return new BackoffDelay(firstBackoff, maxBackoffInterval, nextBackoff);
/*     */         }
/*     */ 
/*     */         
/*     */         public String toString() {
/* 151 */           return String.format("Backoff{exponential,min=%sms,max=%s,factor=%s,basedOnPreviousValue=true}", new Object[] {
/* 152 */                 Long.valueOf(this.val$firstBackoff.toMillis()), (this.val$maxBackoff == null) ? "NONE" : (this.val$maxBackoff
/* 153 */                 .toMillis() + "ms"), 
/* 154 */                 Integer.valueOf(this.val$factor)
/*     */               });
/*     */         }
/*     */       };
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-extra-3.4.10.jar!\reactor\retry\Backoff.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */