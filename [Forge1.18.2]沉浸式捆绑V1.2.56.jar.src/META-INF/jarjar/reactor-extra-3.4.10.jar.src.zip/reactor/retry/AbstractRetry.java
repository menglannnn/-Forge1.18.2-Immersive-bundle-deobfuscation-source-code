/*     */ package reactor.retry;
/*     */ 
/*     */ import java.time.Clock;
/*     */ import java.time.Duration;
/*     */ import java.time.Instant;
/*     */ import java.util.function.Function;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.core.scheduler.Scheduler;
/*     */ import reactor.core.scheduler.Schedulers;
/*     */ import reactor.scheduler.clock.SchedulerClock;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.Loggers;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractRetry<T, S>
/*     */   implements Function<Flux<S>, Publisher<Long>>
/*     */ {
/*  36 */   static final Logger log = Loggers.getLogger(AbstractRetry.class);
/*     */   
/*  38 */   static final BackoffDelay RETRY_EXHAUSTED = new BackoffDelay(Duration.ofSeconds(-1L))
/*     */     {
/*     */       public String toString() {
/*  41 */         return "{EXHAUSTED}";
/*     */       }
/*     */     };
/*     */ 
/*     */   
/*     */   final long maxIterations;
/*     */   
/*     */   final Duration timeout;
/*     */   
/*     */   final Backoff backoff;
/*     */   
/*     */   final Jitter jitter;
/*     */   
/*     */   @Nullable
/*     */   final Scheduler backoffScheduler;
/*     */   
/*     */   final SchedulerClock clock;
/*     */   final T applicationContext;
/*     */   
/*     */   AbstractRetry(long maxIterations, Duration timeout, Backoff backoff, Jitter jitter, @Nullable Scheduler backoffScheduler, T applicationContext) {
/*  61 */     this.maxIterations = maxIterations;
/*  62 */     this.timeout = timeout;
/*  63 */     this.backoff = backoff;
/*  64 */     this.jitter = jitter;
/*  65 */     this.backoffScheduler = backoffScheduler;
/*  66 */     this.clock = SchedulerClock.of((backoffScheduler == null) ? Schedulers.parallel() : backoffScheduler);
/*  67 */     this.applicationContext = applicationContext;
/*     */   }
/*     */   
/*     */   Instant calculateTimeout() {
/*  71 */     return (this.timeout != null) ? Instant.now((Clock)this.clock).plus(this.timeout) : Instant.MAX;
/*     */   }
/*     */   
/*     */   BackoffDelay calculateBackoff(IterationContext<T> retryContext, Instant timeoutInstant) {
/*  75 */     if (retryContext.iteration() > this.maxIterations) {
/*  76 */       return RETRY_EXHAUSTED;
/*     */     }
/*  78 */     BackoffDelay nextBackoff = this.backoff.apply(retryContext);
/*  79 */     Duration minBackoff = nextBackoff.min;
/*  80 */     Duration maxBackoff = nextBackoff.max;
/*  81 */     Duration backoff = nextBackoff.delay;
/*  82 */     if (maxBackoff != null)
/*  83 */       backoff = (backoff.compareTo(maxBackoff) < 0) ? backoff : maxBackoff; 
/*  84 */     if (minBackoff != null) {
/*  85 */       backoff = (backoff.compareTo(minBackoff) > 0) ? backoff : minBackoff;
/*     */     }
/*  87 */     BackoffDelay sanitizedBackoff = new BackoffDelay(minBackoff, maxBackoff, backoff);
/*  88 */     Duration jitteredBackoff = this.jitter.apply(sanitizedBackoff);
/*     */     
/*  90 */     if (Instant.now((Clock)this.clock).plus(jitteredBackoff).isAfter(timeoutInstant)) {
/*  91 */       return RETRY_EXHAUSTED;
/*     */     }
/*  93 */     return new BackoffDelay(minBackoff, maxBackoff, jitteredBackoff);
/*     */   }
/*     */   
/*     */   Publisher<Long> retryMono(Duration delay) {
/*  97 */     if (delay == Duration.ZERO)
/*  98 */       return (Publisher<Long>)Mono.just(Long.valueOf(0L)); 
/*  99 */     if (this.backoffScheduler == null) {
/* 100 */       return (Publisher<Long>)Mono.delay(delay);
/*     */     }
/* 102 */     return (Publisher<Long>)Mono.delay(delay, this.backoffScheduler);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-extra-3.4.10.jar!\reactor\retry\AbstractRetry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */