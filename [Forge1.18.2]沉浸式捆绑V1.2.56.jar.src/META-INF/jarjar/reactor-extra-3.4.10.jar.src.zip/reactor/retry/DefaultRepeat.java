/*     */ package reactor.retry;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.time.Instant;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Predicate;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.scheduler.Scheduler;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.Loggers;
/*     */ import reactor.util.function.Tuple2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultRepeat<T>
/*     */   extends AbstractRetry<T, Long>
/*     */   implements Repeat<T>
/*     */ {
/*  33 */   static final Logger log = Loggers.getLogger(DefaultRepeat.class);
/*     */ 
/*     */   
/*     */   static final Consumer<? super RepeatContext<?>> NOOP_ON_REPEAT = r -> {
/*     */     
/*     */     };
/*     */ 
/*     */   
/*     */   final Predicate<? super RepeatContext<T>> repeatPredicate;
/*     */   
/*     */   final Consumer<? super RepeatContext<T>> onRepeat;
/*     */ 
/*     */   
/*     */   DefaultRepeat(Predicate<? super RepeatContext<T>> repeatPredicate, long maxRepeats, Duration timeout, Backoff backoff, Jitter jitter, Scheduler backoffScheduler, Consumer<? super RepeatContext<T>> onRepeat, T applicationContext) {
/*  47 */     super(maxRepeats, timeout, backoff, jitter, backoffScheduler, applicationContext);
/*  48 */     this.repeatPredicate = repeatPredicate;
/*  49 */     this.onRepeat = onRepeat;
/*     */   }
/*     */   
/*     */   public static <T> DefaultRepeat<T> create(Predicate<? super RepeatContext<T>> repeatPredicate, long n) {
/*  53 */     return new DefaultRepeat<>(repeatPredicate, n, null, 
/*     */ 
/*     */         
/*  56 */         Backoff.zero(), 
/*  57 */         Jitter.noJitter(), null, (Consumer)NOOP_ON_REPEAT, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Repeat<T> withApplicationContext(T applicationContext) {
/*  65 */     return new DefaultRepeat(this.repeatPredicate, this.maxIterations, this.timeout, this.backoff, this.jitter, this.backoffScheduler, this.onRepeat, applicationContext);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Repeat<T> doOnRepeat(Consumer<? super RepeatContext<T>> onRepeat) {
/*  71 */     return new DefaultRepeat(this.repeatPredicate, this.maxIterations, this.timeout, this.backoff, this.jitter, this.backoffScheduler, onRepeat, this.applicationContext);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Repeat<T> timeout(Duration timeout) {
/*  77 */     if (timeout.isNegative())
/*  78 */       throw new IllegalArgumentException("timeout should be >= 0"); 
/*  79 */     return new DefaultRepeat(this.repeatPredicate, this.maxIterations, timeout, this.backoff, this.jitter, this.backoffScheduler, this.onRepeat, this.applicationContext);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Repeat<T> repeatMax(long maxRepeats) {
/*  85 */     if (maxRepeats < 1L)
/*  86 */       throw new IllegalArgumentException("maxRepeats should be > 0"); 
/*  87 */     return new DefaultRepeat(this.repeatPredicate, maxRepeats, this.timeout, this.backoff, this.jitter, this.backoffScheduler, this.onRepeat, this.applicationContext);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Repeat<T> backoff(Backoff backoff) {
/*  93 */     return new DefaultRepeat(this.repeatPredicate, this.maxIterations, this.timeout, backoff, this.jitter, this.backoffScheduler, this.onRepeat, this.applicationContext);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Repeat<T> jitter(Jitter jitter) {
/*  99 */     return new DefaultRepeat(this.repeatPredicate, this.maxIterations, this.timeout, this.backoff, jitter, this.backoffScheduler, this.onRepeat, this.applicationContext);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Repeat<T> withBackoffScheduler(Scheduler scheduler) {
/* 105 */     return new DefaultRepeat(this.repeatPredicate, this.maxIterations, this.timeout, this.backoff, this.jitter, scheduler, this.onRepeat, this.applicationContext);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Publisher<Long> apply(Flux<Long> companionValues) {
/* 111 */     Instant timeoutInstant = calculateTimeout();
/* 112 */     DefaultContext<T> context = new DefaultContext<>(this.applicationContext, 0L, null, -1L);
/* 113 */     return (Publisher<Long>)companionValues
/* 114 */       .index()
/* 115 */       .map(tuple -> repeatBackoff((Long)tuple.getT2(), Long.valueOf(((Long)tuple.getT1()).longValue() + 1L), timeoutInstant, context))
/* 116 */       .takeWhile(backoff -> (backoff != RETRY_EXHAUSTED))
/* 117 */       .concatMap(backoff -> retryMono(backoff.delay));
/*     */   }
/*     */   
/*     */   BackoffDelay repeatBackoff(Long companionValue, Long iteration, Instant timeoutInstant, DefaultContext<T> context) {
/* 121 */     DefaultContext<T> tmpContext = new DefaultContext<>(this.applicationContext, iteration.longValue(), context.lastBackoff, companionValue.longValue());
/* 122 */     BackoffDelay nextBackoff = calculateBackoff(tmpContext, timeoutInstant);
/* 123 */     DefaultContext<T> repeatContext = new DefaultContext<>(this.applicationContext, iteration.longValue(), nextBackoff, companionValue.longValue());
/* 124 */     context.lastBackoff = nextBackoff;
/*     */     
/* 126 */     if (!this.repeatPredicate.test(repeatContext)) {
/* 127 */       log.debug("Stopping repeats since predicate returned false, retry context: {}", new Object[] { repeatContext });
/* 128 */       return RETRY_EXHAUSTED;
/*     */     } 
/* 130 */     if (nextBackoff == RETRY_EXHAUSTED) {
/* 131 */       log.debug("Repeats exhausted, retry context: {}", new Object[] { repeatContext });
/* 132 */       return RETRY_EXHAUSTED;
/*     */     } 
/*     */     
/* 135 */     log.debug("Scheduling repeat attempt, retry context: {}", new Object[] { repeatContext });
/* 136 */     this.onRepeat.accept(repeatContext);
/* 137 */     return nextBackoff;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 143 */     return "Repeat{times=" + this.maxIterations + ",backoff=" + this.backoff + ",jitter=" + this.jitter + "}";
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-extra-3.4.10.jar!\reactor\retry\DefaultRepeat.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */