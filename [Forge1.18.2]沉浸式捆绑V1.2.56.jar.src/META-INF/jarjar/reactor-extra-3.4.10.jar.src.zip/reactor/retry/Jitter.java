/*    */ package reactor.retry;
/*    */ 
/*    */ import java.time.Duration;
/*    */ import java.util.function.Function;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface Jitter
/*    */   extends Function<BackoffDelay, Duration>
/*    */ {
/* 29 */   public static final Jitter NO_JITTER = new Jitter()
/*    */     {
/*    */       public Duration apply(BackoffDelay delay) {
/* 32 */         return delay.delay();
/*    */       }
/*    */ 
/*    */       
/*    */       public String toString() {
/* 37 */         return "Jitter{NONE}";
/*    */       }
/*    */     };
/*    */   
/* 41 */   public static final Jitter RANDOM_JITTER = new RandomJitter(0.5D);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static Jitter noJitter() {
/* 48 */     return NO_JITTER;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static Jitter random() {
/* 58 */     return RANDOM_JITTER;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static Jitter random(double randomFactor) {
/* 68 */     return new RandomJitter(randomFactor);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-extra-3.4.10.jar!\reactor\retry\Jitter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */