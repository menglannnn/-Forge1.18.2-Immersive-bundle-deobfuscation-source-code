/*     */ package reactor.retry;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.util.function.Consumer;
/*     */ import kotlin.Deprecated;
/*     */ import kotlin.Metadata;
/*     */ import kotlin.ReplaceWith;
/*     */ import kotlin.Unit;
/*     */ import kotlin.jvm.functions.Function1;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Metadata(mv = {1, 1, 18}, bv = {1, 0, 3}, k = 2, d1 = {"\0002\n\000\n\002\030\002\n\002\b\002\n\002\020\t\n\000\n\002\030\002\n\002\b\002\n\002\020\013\n\000\n\002\030\002\n\002\030\002\n\002\020\002\n\002\030\002\n\002\b\002\032b\020\000\032\b\022\004\022\002H\0020\001\"\004\b\000\020\002*\b\022\004\022\002H\0020\0012\006\020\003\032\0020\0042\006\020\005\032\0020\0062\n\b\002\020\007\032\004\030\0010\0062\b\b\002\020\b\032\0020\t2\034\b\002\020\n\032\026\022\n\022\b\022\004\022\002H\0020\f\022\004\022\0020\r\030\0010\013H\007\032b\020\000\032\b\022\004\022\002H\0020\001\"\004\b\000\020\002*\b\022\004\022\002H\0020\0162\006\020\003\032\0020\0042\006\020\005\032\0020\0062\n\b\002\020\007\032\004\030\0010\0062\b\b\002\020\b\032\0020\t2\034\b\002\020\n\032\026\022\n\022\b\022\004\022\002H\0020\f\022\004\022\0020\r\030\0010\013H\007\032X\020\017\032\b\022\004\022\002H\0020\001\"\004\b\000\020\002*\b\022\004\022\002H\0020\0012\006\020\003\032\0020\0042\006\020\005\032\0020\0062\n\b\002\020\007\032\004\030\0010\0062\034\b\002\020\n\032\026\022\n\022\b\022\004\022\002H\0020\f\022\004\022\0020\r\030\0010\013H\007\032X\020\017\032\b\022\004\022\002H\0020\001\"\004\b\000\020\002*\b\022\004\022\002H\0020\0162\006\020\003\032\0020\0042\006\020\005\032\0020\0062\n\b\002\020\007\032\004\030\0010\0062\034\b\002\020\n\032\026\022\n\022\b\022\004\022\002H\0020\f\022\004\022\0020\r\030\0010\013H\007¨\006\020"}, d2 = {"repeatExponentialBackoff", "Lreactor/core/publisher/Flux;", "T", "times", "", "first", "Ljava/time/Duration;", "max", "jitter", "", "doOnRepeat", "Lkotlin/Function1;", "Lreactor/retry/RepeatContext;", "", "Lreactor/core/publisher/Mono;", "repeatRandomBackoff", "reactor-extra"})
/*     */ public final class RepeatExtensionsKt
/*     */ {
/*     */   @Deprecated(message = "To be removed in 3.3.0.RELEASE, replaced by module reactor-kotlin-extensions", replaceWith = @ReplaceWith(imports = {"reactor.kotlin.extra.retry.repeatExponentialBackoff"}, expression = "repeatExponentialBackoff(times, first, max, jitter, doOnRepeat)"))
/*     */   @NotNull
/*     */   public static final <T> Flux<T> repeatExponentialBackoff(@NotNull Flux $this$repeatExponentialBackoff, long times, @NotNull Duration first, @Nullable Duration max, boolean jitter, @Nullable Function1 doOnRepeat) {
/*  43 */     Intrinsics.checkParameterIsNotNull($this$repeatExponentialBackoff, "$this$repeatExponentialBackoff"); Intrinsics.checkParameterIsNotNull(first, "first"); Repeat repeat = Repeat.times(times)
/*  44 */       .exponentialBackoff(first, max)
/*  45 */       .jitter(jitter ? Jitter.random() : Jitter.noJitter());
/*     */ 
/*     */     
/*  48 */     Intrinsics.checkExpressionValueIsNotNull(repeat.apply((Publisher)$this$repeatExponentialBackoff), "repeat.apply(this)");
/*     */     
/*  50 */     Function1 function1 = doOnRepeat; Intrinsics.checkExpressionValueIsNotNull(repeat.doOnRepeat(new RepeatExtensionsKt$sam$java_util_function_Consumer$0(function1)).apply((Publisher)$this$repeatExponentialBackoff), "repeat.doOnRepeat(doOnRepeat).apply(this)"); return (doOnRepeat == null) ? repeat.apply((Publisher)$this$repeatExponentialBackoff) : repeat.doOnRepeat(new RepeatExtensionsKt$sam$java_util_function_Consumer$0(function1)).apply((Publisher)$this$repeatExponentialBackoff);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(message = "To be removed in 3.3.0.RELEASE, replaced by module reactor-kotlin-extensions", replaceWith = @ReplaceWith(imports = {"reactor.kotlin.extra.retry.repeatRandomBackoff"}, expression = "repeatRandomBackoff(times, first, max, doOnRepeat)"))
/*     */   @NotNull
/*     */   public static final <T> Flux<T> repeatRandomBackoff(@NotNull Flux $this$repeatRandomBackoff, long times, @NotNull Duration first, @Nullable Duration max, @Nullable Function1 doOnRepeat) {
/*  70 */     Intrinsics.checkParameterIsNotNull($this$repeatRandomBackoff, "$this$repeatRandomBackoff"); Intrinsics.checkParameterIsNotNull(first, "first"); Repeat repeat = Repeat.times(times)
/*  71 */       .randomBackoff(first, max);
/*     */ 
/*     */     
/*  74 */     Intrinsics.checkExpressionValueIsNotNull(repeat.apply((Publisher)$this$repeatRandomBackoff), "repeat.apply(this)");
/*     */     
/*  76 */     Function1 function1 = doOnRepeat; Intrinsics.checkExpressionValueIsNotNull(repeat.doOnRepeat(new RepeatExtensionsKt$sam$java_util_function_Consumer$0(function1)).apply((Publisher)$this$repeatRandomBackoff), "repeat.doOnRepeat(doOnRepeat).apply(this)"); return (doOnRepeat == null) ? repeat.apply((Publisher)$this$repeatRandomBackoff) : repeat.doOnRepeat(new RepeatExtensionsKt$sam$java_util_function_Consumer$0(function1)).apply((Publisher)$this$repeatRandomBackoff);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(message = "To be removed in 3.3.0.RELEASE, replaced by module reactor-kotlin-extensions", replaceWith = @ReplaceWith(imports = {"reactor.kotlin.extra.retry.repeatExponentialBackoff"}, expression = "repeatExponentialBackoff(times, first, max, jitter, doOnRepeat)"))
/*     */   @NotNull
/*     */   public static final <T> Flux<T> repeatExponentialBackoff(@NotNull Mono $this$repeatExponentialBackoff, long times, @NotNull Duration first, @Nullable Duration max, boolean jitter, @Nullable Function1 doOnRepeat) {
/*  99 */     Intrinsics.checkParameterIsNotNull($this$repeatExponentialBackoff, "$this$repeatExponentialBackoff"); Intrinsics.checkParameterIsNotNull(first, "first"); Repeat repeat = Repeat.times(times)
/* 100 */       .exponentialBackoff(first, max)
/* 101 */       .jitter(jitter ? Jitter.random() : Jitter.noJitter());
/*     */ 
/*     */     
/* 104 */     Intrinsics.checkExpressionValueIsNotNull(repeat.apply((Publisher)$this$repeatExponentialBackoff), "repeat.apply(this)");
/*     */     
/* 106 */     Function1 function1 = doOnRepeat; Intrinsics.checkExpressionValueIsNotNull(repeat.doOnRepeat(new RepeatExtensionsKt$sam$java_util_function_Consumer$0(function1)).apply((Publisher)$this$repeatExponentialBackoff), "repeat.doOnRepeat(doOnRepeat).apply(this)"); return (doOnRepeat == null) ? repeat.apply((Publisher)$this$repeatExponentialBackoff) : repeat.doOnRepeat(new RepeatExtensionsKt$sam$java_util_function_Consumer$0(function1)).apply((Publisher)$this$repeatExponentialBackoff);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(message = "To be removed in 3.3.0.RELEASE, replaced by module reactor-kotlin-extensions", replaceWith = @ReplaceWith(imports = {"reactor.kotlin.extra.retry.repeatRandomBackoff"}, expression = "repeatRandomBackoff(times, first, max, doOnRepeat)"))
/*     */   @NotNull
/*     */   public static final <T> Flux<T> repeatRandomBackoff(@NotNull Mono $this$repeatRandomBackoff, long times, @NotNull Duration first, @Nullable Duration max, @Nullable Function1 doOnRepeat) {
/* 126 */     Intrinsics.checkParameterIsNotNull($this$repeatRandomBackoff, "$this$repeatRandomBackoff"); Intrinsics.checkParameterIsNotNull(first, "first"); Repeat repeat = Repeat.times(times)
/* 127 */       .randomBackoff(first, max);
/*     */ 
/*     */     
/* 130 */     Intrinsics.checkExpressionValueIsNotNull(repeat.apply((Publisher)$this$repeatRandomBackoff), "repeat.apply(this)");
/*     */     
/* 132 */     Function1 function1 = doOnRepeat; Intrinsics.checkExpressionValueIsNotNull(repeat.doOnRepeat(new RepeatExtensionsKt$sam$java_util_function_Consumer$0(function1)).apply((Publisher)$this$repeatRandomBackoff), "repeat.doOnRepeat(doOnRepeat).apply(this)"); return (doOnRepeat == null) ? repeat.apply((Publisher)$this$repeatRandomBackoff) : repeat.doOnRepeat(new RepeatExtensionsKt$sam$java_util_function_Consumer$0(function1)).apply((Publisher)$this$repeatRandomBackoff);
/*     */   }
/*     */   
/*     */   @Metadata(mv = {1, 1, 18}, bv = {1, 0, 3}, k = 3)
/*     */   final class RepeatExtensionsKt$sam$java_util_function_Consumer$0 implements Consumer {
/*     */     RepeatExtensionsKt$sam$java_util_function_Consumer$0(RepeatExtensionsKt this$0) {
/*     */       this.function = (Function1)this$0;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-extra-3.4.10.jar!\reactor\retry\RepeatExtensionsKt.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */