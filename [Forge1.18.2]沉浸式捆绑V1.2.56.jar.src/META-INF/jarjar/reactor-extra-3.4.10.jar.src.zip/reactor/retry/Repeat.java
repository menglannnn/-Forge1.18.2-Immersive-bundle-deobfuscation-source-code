/*     */ package reactor.retry;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Predicate;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.scheduler.Scheduler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface Repeat<T>
/*     */   extends Function<Flux<Long>, Publisher<Long>>
/*     */ {
/*     */   static <T> Repeat<T> onlyIf(Predicate<? super RepeatContext<T>> predicate) {
/*  64 */     return DefaultRepeat.create(predicate, Long.MAX_VALUE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T> Repeat<T> once() {
/*  72 */     return times(1L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T> Repeat<T> times(long n) {
/*  81 */     if (n < 0L)
/*  82 */       throw new IllegalArgumentException("n should be >= 0"); 
/*  83 */     return DefaultRepeat.create(context -> true, n);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T> Repeat<T> create(Predicate<? super RepeatContext<T>> predicate, long n) {
/*  93 */     return DefaultRepeat.create(predicate, n);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Repeat<T> noBackoff() {
/* 179 */     return backoff(Backoff.zero());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Repeat<T> fixedBackoff(Duration backoffInterval) {
/* 191 */     return backoff(Backoff.fixed(backoffInterval));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Repeat<T> exponentialBackoff(Duration firstBackoff, Duration maxBackoff) {
/* 208 */     return backoff(Backoff.exponential(firstBackoff, maxBackoff, 2, false));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Repeat<T> exponentialBackoffWithJitter(Duration firstBackoff, Duration maxBackoff) {
/* 225 */     return backoff(Backoff.exponential(firstBackoff, maxBackoff, 2, false)).jitter(Jitter.random());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Repeat<T> randomBackoff(Duration firstBackoff, Duration maxBackoff) {
/* 242 */     return backoff(Backoff.exponential(firstBackoff, maxBackoff, 3, true)).jitter(Jitter.random());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default <S> Flux<S> apply(Publisher<S> source) {
/* 260 */     return Flux.from(source).repeatWhen(this);
/*     */   }
/*     */   
/*     */   Repeat<T> withApplicationContext(T paramT);
/*     */   
/*     */   Repeat<T> doOnRepeat(Consumer<? super RepeatContext<T>> paramConsumer);
/*     */   
/*     */   Repeat<T> timeout(Duration paramDuration);
/*     */   
/*     */   Repeat<T> repeatMax(long paramLong);
/*     */   
/*     */   Repeat<T> backoff(Backoff paramBackoff);
/*     */   
/*     */   Repeat<T> jitter(Jitter paramJitter);
/*     */   
/*     */   Repeat<T> withBackoffScheduler(Scheduler paramScheduler);
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-extra-3.4.10.jar!\reactor\retry\Repeat.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */