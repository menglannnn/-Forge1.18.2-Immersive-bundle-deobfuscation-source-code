/*    */ package reactor.retry;
/*    */ 
/*    */ import java.time.Duration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BackoffDelay
/*    */ {
/* 23 */   static final BackoffDelay ZERO = new BackoffDelay(Duration.ZERO)
/*    */     {
/*    */       public String toString() {
/* 26 */         return "{ZERO}";
/*    */       }
/*    */     };
/*    */   
/*    */   final Duration min;
/*    */   final Duration max;
/*    */   final Duration delay;
/*    */   
/*    */   public BackoffDelay(Duration fixedBackoff) {
/* 35 */     this(fixedBackoff, fixedBackoff, fixedBackoff);
/*    */   }
/*    */   
/*    */   public BackoffDelay(Duration min, Duration max, Duration delay) {
/* 39 */     this.min = min;
/* 40 */     this.max = max;
/* 41 */     this.delay = delay;
/*    */   }
/*    */   
/*    */   public Duration minDelay() {
/* 45 */     return this.min;
/*    */   }
/*    */   
/*    */   public Duration maxDelay() {
/* 49 */     return this.max;
/*    */   }
/*    */   
/*    */   public Duration delay() {
/* 53 */     return this.delay;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 58 */     if (this.min == this.max && this.max == this.delay) {
/* 59 */       return "{" + this.delay.toMillis() + "ms}";
/*    */     }
/*    */     
/* 62 */     return "{" + this.delay.toMillis() + "ms/" + this.max.toMillis() + "ms}";
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-extra-3.4.10.jar!\reactor\retry\BackoffDelay.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */