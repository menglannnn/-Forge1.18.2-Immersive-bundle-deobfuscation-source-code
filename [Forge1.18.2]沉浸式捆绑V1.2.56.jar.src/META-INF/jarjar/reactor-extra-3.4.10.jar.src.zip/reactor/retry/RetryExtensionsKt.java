/*     */ package reactor.retry;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.util.function.Consumer;
/*     */ import kotlin.Deprecated;
/*     */ import kotlin.Metadata;
/*     */ import kotlin.ReplaceWith;
/*     */ import kotlin.Unit;
/*     */ import kotlin.jvm.functions.Function1;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.retry.Retry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Metadata(mv = {1, 1, 18}, bv = {1, 0, 3}, k = 2, d1 = {"\0002\n\000\n\002\030\002\n\002\b\002\n\002\020\t\n\000\n\002\030\002\n\002\b\002\n\002\020\013\n\000\n\002\030\002\n\002\030\002\n\002\020\002\n\002\030\002\n\002\b\002\032b\020\000\032\b\022\004\022\002H\0020\001\"\004\b\000\020\002*\b\022\004\022\002H\0020\0012\006\020\003\032\0020\0042\006\020\005\032\0020\0062\n\b\002\020\007\032\004\030\0010\0062\b\b\002\020\b\032\0020\t2\034\b\002\020\n\032\026\022\n\022\b\022\004\022\002H\0020\f\022\004\022\0020\r\030\0010\013H\007\032b\020\000\032\b\022\004\022\002H\0020\016\"\004\b\000\020\002*\b\022\004\022\002H\0020\0162\006\020\003\032\0020\0042\006\020\005\032\0020\0062\n\b\002\020\007\032\004\030\0010\0062\b\b\002\020\b\032\0020\t2\034\b\002\020\n\032\026\022\n\022\b\022\004\022\002H\0020\f\022\004\022\0020\r\030\0010\013H\007\032X\020\017\032\b\022\004\022\002H\0020\001\"\004\b\000\020\002*\b\022\004\022\002H\0020\0012\006\020\003\032\0020\0042\006\020\005\032\0020\0062\n\b\002\020\007\032\004\030\0010\0062\034\b\002\020\n\032\026\022\n\022\b\022\004\022\002H\0020\f\022\004\022\0020\r\030\0010\013H\007\032X\020\017\032\b\022\004\022\002H\0020\016\"\004\b\000\020\002*\b\022\004\022\002H\0020\0162\006\020\003\032\0020\0042\006\020\005\032\0020\0062\n\b\002\020\007\032\004\030\0010\0062\034\b\002\020\n\032\026\022\n\022\b\022\004\022\002H\0020\f\022\004\022\0020\r\030\0010\013H\007¨\006\020"}, d2 = {"retryExponentialBackoff", "Lreactor/core/publisher/Flux;", "T", "times", "", "first", "Ljava/time/Duration;", "max", "jitter", "", "doOnRetry", "Lkotlin/Function1;", "Lreactor/retry/RetryContext;", "", "Lreactor/core/publisher/Mono;", "retryRandomBackoff", "reactor-extra"})
/*     */ public final class RetryExtensionsKt
/*     */ {
/*     */   @Deprecated(message = "To be removed in 3.3.0.RELEASE, replaced by module reactor-kotlin-extensions", replaceWith = @ReplaceWith(imports = {"reactor.kotlin.extra.retry.retryExponentialBackoff"}, expression = "retryExponentialBackoff(times, first, max, jitter, doOnRetry)"))
/*     */   @NotNull
/*     */   public static final <T> Flux<T> retryExponentialBackoff(@NotNull Flux $this$retryExponentialBackoff, long times, @NotNull Duration first, @Nullable Duration max, boolean jitter, @Nullable Function1 doOnRetry) {
/*  43 */     Intrinsics.checkParameterIsNotNull($this$retryExponentialBackoff, "$this$retryExponentialBackoff"); Intrinsics.checkParameterIsNotNull(first, "first"); Retry retry = Retry.any()
/*  44 */       .retryMax(times)
/*  45 */       .exponentialBackoff(first, max)
/*  46 */       .jitter(jitter ? Jitter.random() : Jitter.noJitter());
/*     */ 
/*     */     
/*  49 */     Intrinsics.checkExpressionValueIsNotNull(retry.apply((Publisher)$this$retryExponentialBackoff), "retry.apply(this)");
/*     */     
/*  51 */     Function1 function1 = doOnRetry; Intrinsics.checkExpressionValueIsNotNull(retry.doOnRetry(new RetryExtensionsKt$sam$java_util_function_Consumer$0(function1)).apply((Publisher)$this$retryExponentialBackoff), "retry.doOnRetry(doOnRetry).apply(this)"); return (doOnRetry == null) ? retry.apply((Publisher)$this$retryExponentialBackoff) : retry.doOnRetry(new RetryExtensionsKt$sam$java_util_function_Consumer$0(function1)).apply((Publisher)$this$retryExponentialBackoff);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(message = "To be removed in 3.3.0.RELEASE, replaced by module reactor-kotlin-extensions", replaceWith = @ReplaceWith(imports = {"reactor.kotlin.extra.retry.retryRandomBackoff"}, expression = "retryRandomBackoff(times, first, max, doOnRetry)"))
/*     */   @NotNull
/*     */   public static final <T> Flux<T> retryRandomBackoff(@NotNull Flux $this$retryRandomBackoff, long times, @NotNull Duration first, @Nullable Duration max, @Nullable Function1 doOnRetry) {
/*  71 */     Intrinsics.checkParameterIsNotNull($this$retryRandomBackoff, "$this$retryRandomBackoff"); Intrinsics.checkParameterIsNotNull(first, "first"); Retry retry = Retry.any()
/*  72 */       .retryMax(times)
/*  73 */       .randomBackoff(first, max);
/*     */ 
/*     */     
/*  76 */     Intrinsics.checkExpressionValueIsNotNull(retry.apply((Publisher)$this$retryRandomBackoff), "retry.apply(this)");
/*     */     
/*  78 */     Function1 function1 = doOnRetry; Intrinsics.checkExpressionValueIsNotNull(retry.doOnRetry(new RetryExtensionsKt$sam$java_util_function_Consumer$0(function1)).apply((Publisher)$this$retryRandomBackoff), "retry.doOnRetry(doOnRetry).apply(this)"); return (doOnRetry == null) ? retry.apply((Publisher)$this$retryRandomBackoff) : retry.doOnRetry(new RetryExtensionsKt$sam$java_util_function_Consumer$0(function1)).apply((Publisher)$this$retryRandomBackoff);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(message = "To be removed in 3.3.0.RELEASE, replaced by module reactor-kotlin-extensions", replaceWith = @ReplaceWith(imports = {"reactor.kotlin.extra.retry.retryExponentialBackoff"}, expression = "retryExponentialBackoff(times, first, max, jitter, doOnRetry)"))
/*     */   @NotNull
/*     */   public static final <T> Mono<T> retryExponentialBackoff(@NotNull Mono $this$retryExponentialBackoff, long times, @NotNull Duration first, @Nullable Duration max, boolean jitter, @Nullable Function1 doOnRetry) {
/* 100 */     Intrinsics.checkParameterIsNotNull($this$retryExponentialBackoff, "$this$retryExponentialBackoff"); Intrinsics.checkParameterIsNotNull(first, "first"); Retry retry = Retry.any()
/* 101 */       .retryMax(times)
/* 102 */       .exponentialBackoff(first, max)
/* 103 */       .jitter(jitter ? Jitter.random() : Jitter.noJitter());
/*     */ 
/*     */     
/* 106 */     Intrinsics.checkExpressionValueIsNotNull($this$retryExponentialBackoff.retryWhen(Retry.withThrowable(retry)), "this.retryWhen(reactor.u…try.withThrowable(retry))");
/*     */     
/* 108 */     Function1 function1 = doOnRetry; Intrinsics.checkExpressionValueIsNotNull($this$retryExponentialBackoff.retryWhen(Retry.withThrowable(retry.doOnRetry(new RetryExtensionsKt$sam$java_util_function_Consumer$0(function1)))), "this.retryWhen(reactor.u…ry.doOnRetry(doOnRetry)))"); return (doOnRetry == null) ? $this$retryExponentialBackoff.retryWhen(Retry.withThrowable(retry)) : $this$retryExponentialBackoff.retryWhen(Retry.withThrowable(retry.doOnRetry(new RetryExtensionsKt$sam$java_util_function_Consumer$0(function1))));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(message = "To be removed in 3.3.0.RELEASE, replaced by module reactor-kotlin-extensions", replaceWith = @ReplaceWith(imports = {"reactor.kotlin.extra.retry.retryRandomBackoff"}, expression = "retryRandomBackoff(times, first, max, doOnRetry)"))
/*     */   @NotNull
/*     */   public static final <T> Mono<T> retryRandomBackoff(@NotNull Mono $this$retryRandomBackoff, long times, @NotNull Duration first, @Nullable Duration max, @Nullable Function1 doOnRetry) {
/* 128 */     Intrinsics.checkParameterIsNotNull($this$retryRandomBackoff, "$this$retryRandomBackoff"); Intrinsics.checkParameterIsNotNull(first, "first"); Retry retry = Retry.any()
/* 129 */       .retryMax(times)
/* 130 */       .randomBackoff(first, max);
/*     */ 
/*     */     
/* 133 */     Intrinsics.checkExpressionValueIsNotNull($this$retryRandomBackoff.retryWhen(Retry.withThrowable(retry)), "this.retryWhen(reactor.u…try.withThrowable(retry))");
/*     */     
/* 135 */     Function1 function1 = doOnRetry; Intrinsics.checkExpressionValueIsNotNull($this$retryRandomBackoff.retryWhen(Retry.withThrowable(retry.doOnRetry(new RetryExtensionsKt$sam$java_util_function_Consumer$0(function1)))), "this.retryWhen(reactor.u…ry.doOnRetry(doOnRetry)))"); return (doOnRetry == null) ? $this$retryRandomBackoff.retryWhen(Retry.withThrowable(retry)) : $this$retryRandomBackoff.retryWhen(Retry.withThrowable(retry.doOnRetry(new RetryExtensionsKt$sam$java_util_function_Consumer$0(function1))));
/*     */   }
/*     */   
/*     */   @Metadata(mv = {1, 1, 18}, bv = {1, 0, 3}, k = 3)
/*     */   final class RetryExtensionsKt$sam$java_util_function_Consumer$0 implements Consumer {
/*     */     RetryExtensionsKt$sam$java_util_function_Consumer$0(RetryExtensionsKt this$0) {
/*     */       this.function = (Function1)this$0;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-extra-3.4.10.jar!\reactor\retry\RetryExtensionsKt.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */