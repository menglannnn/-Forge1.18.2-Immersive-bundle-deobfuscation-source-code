/*     */ package reactor.retry;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.time.Instant;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Predicate;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.core.scheduler.Scheduler;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.Loggers;
/*     */ import reactor.util.function.Tuple2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class DefaultRetry<T>
/*     */   extends AbstractRetry<T, Throwable>
/*     */   implements Retry<T>
/*     */ {
/*  39 */   static final Logger log = Loggers.getLogger(DefaultRetry.class);
/*     */ 
/*     */   
/*     */   static final Consumer<? super RetryContext<?>> NOOP_ON_RETRY = r -> {
/*     */     
/*     */     };
/*     */ 
/*     */   
/*     */   final Predicate<? super RetryContext<T>> retryPredicate;
/*     */   
/*     */   final Consumer<? super RetryContext<T>> onRetry;
/*     */ 
/*     */   
/*     */   DefaultRetry(Predicate<? super RetryContext<T>> retryPredicate, long maxIterations, Duration timeout, Backoff backoff, Jitter jitter, Scheduler backoffScheduler, Consumer<? super RetryContext<T>> onRetry, T applicationContext) {
/*  53 */     super(maxIterations, timeout, backoff, jitter, backoffScheduler, applicationContext);
/*  54 */     this.retryPredicate = retryPredicate;
/*  55 */     this.onRetry = onRetry;
/*     */   }
/*     */   
/*     */   public static <T> DefaultRetry<T> create(Predicate<? super RetryContext<T>> retryPredicate) {
/*  59 */     return new DefaultRetry<>(retryPredicate, Long.MAX_VALUE, null, 
/*     */ 
/*     */         
/*  62 */         Backoff.zero(), 
/*  63 */         Jitter.noJitter(), null, (Consumer)NOOP_ON_RETRY, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Retry<T> withApplicationContext(T applicationContext) {
/*  71 */     return new DefaultRetry(this.retryPredicate, this.maxIterations, this.timeout, this.backoff, this.jitter, this.backoffScheduler, this.onRetry, applicationContext);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Retry<T> doOnRetry(Consumer<? super RetryContext<T>> onRetry) {
/*  77 */     return new DefaultRetry(this.retryPredicate, this.maxIterations, this.timeout, this.backoff, this.jitter, this.backoffScheduler, onRetry, this.applicationContext);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Retry<T> retryMax(long maxIterations) {
/*  83 */     if (maxIterations < 0L)
/*  84 */       throw new IllegalArgumentException("maxIterations should be >= 0"); 
/*  85 */     return new DefaultRetry(this.retryPredicate, maxIterations, this.timeout, this.backoff, this.jitter, this.backoffScheduler, this.onRetry, this.applicationContext);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Retry<T> timeout(Duration timeout) {
/*  91 */     if (timeout.isNegative())
/*  92 */       throw new IllegalArgumentException("timeout should be >= 0"); 
/*  93 */     return new DefaultRetry(this.retryPredicate, this.maxIterations, timeout, this.backoff, this.jitter, this.backoffScheduler, this.onRetry, this.applicationContext);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Retry<T> backoff(Backoff backoff) {
/*  99 */     return new DefaultRetry(this.retryPredicate, this.maxIterations, this.timeout, backoff, this.jitter, this.backoffScheduler, this.onRetry, this.applicationContext);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Retry<T> jitter(Jitter jitter) {
/* 105 */     return new DefaultRetry(this.retryPredicate, this.maxIterations, this.timeout, this.backoff, jitter, this.backoffScheduler, this.onRetry, this.applicationContext);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Retry<T> withBackoffScheduler(Scheduler scheduler) {
/* 111 */     return new DefaultRetry(this.retryPredicate, this.maxIterations, this.timeout, this.backoff, this.jitter, scheduler, this.onRetry, this.applicationContext);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Publisher<Long> apply(Flux<Throwable> errors) {
/* 117 */     Instant timeoutInstant = calculateTimeout();
/* 118 */     DefaultContext<T> context = new DefaultContext<>(this.applicationContext, 0L, null, null);
/* 119 */     return (Publisher<Long>)errors.index()
/* 120 */       .concatMap(tuple -> retry((Throwable)tuple.getT2(), ((Long)tuple.getT1()).longValue() + 1L, timeoutInstant, context));
/*     */   }
/*     */   
/*     */   Publisher<Long> retry(Throwable e, long iteration, Instant timeoutInstant, DefaultContext<T> context) {
/* 124 */     DefaultContext<T> tmpContext = new DefaultContext<>(this.applicationContext, iteration, context.lastBackoff, e);
/* 125 */     BackoffDelay nextBackoff = calculateBackoff(tmpContext, timeoutInstant);
/* 126 */     DefaultContext<T> retryContext = new DefaultContext<>(this.applicationContext, iteration, nextBackoff, e);
/* 127 */     context.lastBackoff = nextBackoff;
/*     */     
/* 129 */     if (!this.retryPredicate.test(retryContext)) {
/* 130 */       log.debug("Stopping retries since predicate returned false, retry context: {}", new Object[] { retryContext });
/* 131 */       return (Publisher<Long>)Mono.error(e);
/*     */     } 
/* 133 */     if (nextBackoff == RETRY_EXHAUSTED) {
/* 134 */       log.debug("Retries exhausted, retry context: {}", new Object[] { retryContext });
/* 135 */       return (Publisher<Long>)Mono.error(new RetryExhaustedException(e));
/*     */     } 
/*     */     
/* 138 */     log.debug("Scheduling retry attempt, retry context: {}", new Object[] { retryContext });
/* 139 */     this.onRetry.accept(retryContext);
/* 140 */     return retryMono(nextBackoff.delay());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 146 */     return "Retry{max=" + this.maxIterations + ",backoff=" + this.backoff + ",jitter=" + this.jitter + "}";
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-extra-3.4.10.jar!\reactor\retry\DefaultRetry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */