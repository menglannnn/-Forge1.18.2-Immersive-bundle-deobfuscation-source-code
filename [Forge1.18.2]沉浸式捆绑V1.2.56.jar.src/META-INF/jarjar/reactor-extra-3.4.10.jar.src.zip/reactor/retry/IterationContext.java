package reactor.retry;

import java.time.Duration;

public interface IterationContext<T> {
  T applicationContext();
  
  long iteration();
  
  Duration backoff();
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-extra-3.4.10.jar!\reactor\retry\IterationContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */