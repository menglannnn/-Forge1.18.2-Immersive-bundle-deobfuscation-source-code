/*     */ package reactor.swing;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import org.eclipse.swt.widgets.Display;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.publisher.Operators;
/*     */ import reactor.core.scheduler.Scheduler;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public final class SwtScheduler
/*     */   implements Scheduler
/*     */ {
/*     */   final Display display;
/*     */   
/*     */   public static Scheduler from(Display display) {
/*  43 */     Objects.requireNonNull(display, "display");
/*  44 */     return new SwtScheduler(display);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   SwtScheduler(Display display) {
/*  50 */     this.display = display;
/*     */   }
/*     */ 
/*     */   
/*     */   public Disposable schedule(Runnable task) {
/*  55 */     SwtScheduledDirectAction a = new SwtScheduledDirectAction(task);
/*     */     
/*  57 */     if (!this.display.isDisposed()) {
/*  58 */       this.display.asyncExec(a);
/*     */     } else {
/*  60 */       throw Exceptions.failWithRejected();
/*     */     } 
/*     */     
/*  63 */     return a;
/*     */   }
/*     */ 
/*     */   
/*     */   public Disposable schedule(Runnable task, long delay, TimeUnit unit) {
/*  68 */     if (delay <= 0L) {
/*  69 */       return schedule(task);
/*     */     }
/*     */     
/*  72 */     if (!this.display.isDisposed()) {
/*  73 */       SwtScheduledDirectAction a = new SwtScheduledDirectAction(task);
/*     */       
/*  75 */       this.display.timerExec((int)unit.toMillis(delay), a);
/*     */       
/*  77 */       return a;
/*     */     } 
/*  79 */     throw Exceptions.failWithRejected();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Disposable schedulePeriodically(Runnable task, long initialDelay, long period, TimeUnit unit) {
/*  85 */     if (!this.display.isDisposed()) {
/*  86 */       long initialDelayMillis = unit.toMillis(initialDelay);
/*     */ 
/*     */       
/*  89 */       SwtPeriodicDirectAction a = new SwtPeriodicDirectAction(task, this.display, System.currentTimeMillis() + initialDelayMillis, unit.toMillis(period));
/*     */       
/*  91 */       if (initialDelay <= 0L) {
/*  92 */         this.display.asyncExec(a);
/*     */       } else {
/*  94 */         this.display.timerExec((int)initialDelayMillis, a);
/*     */       } 
/*     */       
/*  97 */       return a;
/*     */     } 
/*     */     
/* 100 */     throw Exceptions.failWithRejected();
/*     */   }
/*     */ 
/*     */   
/*     */   public Scheduler.Worker createWorker() {
/* 105 */     return new SwtWorker(this.display);
/*     */   }
/*     */   
/*     */   static final class SwtWorker
/*     */     implements Scheduler.Worker {
/*     */     final Display display;
/*     */     volatile boolean unsubscribed;
/*     */     
/*     */     SwtWorker(Display display) {
/* 114 */       this.display = display;
/*     */     }
/*     */ 
/*     */     
/*     */     public void dispose() {
/* 119 */       if (this.unsubscribed) {
/*     */         return;
/*     */       }
/* 122 */       this.unsubscribed = true;
/*     */     }
/*     */ 
/*     */     
/*     */     public Disposable schedule(Runnable action) {
/* 127 */       if (!this.unsubscribed && !this.display.isDisposed()) {
/* 128 */         SwtScheduledAction a = new SwtScheduledAction(action, this);
/*     */         
/* 130 */         this.display.asyncExec(a);
/*     */         
/* 132 */         return a;
/*     */       } 
/*     */       
/* 135 */       throw Exceptions.failWithRejected();
/*     */     }
/*     */ 
/*     */     
/*     */     public Disposable schedule(Runnable action, long delayTime, TimeUnit unit) {
/* 140 */       if (delayTime <= 0L) {
/* 141 */         return schedule(action);
/*     */       }
/*     */       
/* 144 */       if (!this.unsubscribed && !this.display.isDisposed()) {
/* 145 */         SwtScheduledAction a = new SwtScheduledAction(action, this);
/*     */         
/* 147 */         this.display.timerExec((int)unit.toMillis(delayTime), a);
/*     */         
/* 149 */         return a;
/*     */       } 
/*     */       
/* 152 */       throw Exceptions.failWithRejected();
/*     */     }
/*     */ 
/*     */     
/*     */     public Disposable schedulePeriodically(Runnable task, long initialDelay, long period, TimeUnit unit) {
/* 157 */       if (!this.display.isDisposed()) {
/* 158 */         long initialDelayMillis = unit.toMillis(initialDelay);
/*     */ 
/*     */         
/* 161 */         SwtScheduler.SwtPeriodicAction a = new SwtScheduler.SwtPeriodicAction(task, this, this.display, System.currentTimeMillis() + initialDelayMillis, unit.toMillis(period));
/*     */         
/* 163 */         if (initialDelay <= 0L) {
/* 164 */           this.display.asyncExec(a);
/*     */         } else {
/* 166 */           this.display.timerExec((int)initialDelayMillis, a);
/*     */         } 
/*     */         
/* 169 */         return a;
/*     */       } 
/*     */       
/* 172 */       throw Exceptions.failWithRejected();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     static final class SwtScheduledAction
/*     */       extends AtomicBoolean
/*     */       implements Runnable, Disposable
/*     */     {
/*     */       private static final long serialVersionUID = -2864452628218128444L;
/*     */       
/*     */       final Runnable action;
/*     */       
/*     */       final SwtScheduler.SwtWorker parent;
/*     */ 
/*     */       
/*     */       public SwtScheduledAction(Runnable action, SwtScheduler.SwtWorker parent) {
/* 189 */         this.action = action;
/* 190 */         this.parent = parent;
/*     */       }
/*     */ 
/*     */       
/*     */       public void run() {
/* 195 */         if (!this.parent.unsubscribed && !get()) {
/*     */           try {
/* 197 */             this.action.run();
/* 198 */           } catch (Throwable ex) {
/* 199 */             Exceptions.throwIfFatal(ex);
/* 200 */             Operators.onErrorDropped(ex, Context.empty());
/*     */           } 
/*     */         }
/*     */       }
/*     */ 
/*     */       
/*     */       public void dispose() {
/* 207 */         set(true);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   static final class SwtScheduledDirectAction
/*     */     extends AtomicBoolean
/*     */     implements Runnable, Disposable
/*     */   {
/*     */     private static final long serialVersionUID = 2378266891882031635L;
/*     */     final Runnable action;
/*     */     
/*     */     public SwtScheduledDirectAction(Runnable action) {
/* 220 */       this.action = action;
/*     */     }
/*     */ 
/*     */     
/*     */     public void run() {
/* 225 */       if (!get()) {
/*     */         try {
/* 227 */           this.action.run();
/* 228 */         } catch (Throwable ex) {
/* 229 */           Exceptions.throwIfFatal(ex);
/* 230 */           Operators.onErrorDropped(ex, Context.empty());
/*     */         } 
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void dispose() {
/* 237 */       set(true);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class SwtPeriodicDirectAction
/*     */     extends AtomicBoolean
/*     */     implements Runnable, Disposable
/*     */   {
/*     */     private static final long serialVersionUID = 1890399765810263705L;
/*     */     
/*     */     final Runnable task;
/*     */     
/*     */     final Display display;
/*     */     final long periodMillis;
/*     */     final long start;
/*     */     long count;
/*     */     
/*     */     public SwtPeriodicDirectAction(Runnable task, Display display, long start, long periodMillis) {
/* 256 */       this.task = task;
/* 257 */       this.display = display;
/* 258 */       this.start = start;
/* 259 */       this.periodMillis = periodMillis;
/*     */     }
/*     */ 
/*     */     
/*     */     public void run() {
/* 264 */       if (get()) {
/*     */         return;
/*     */       }
/*     */       
/*     */       try {
/* 269 */         this.task.run();
/* 270 */       } catch (Throwable ex) {
/* 271 */         Exceptions.throwIfFatal(ex);
/* 272 */         Operators.onErrorDropped(ex, Context.empty());
/*     */         
/*     */         return;
/*     */       } 
/* 276 */       if (get()) {
/*     */         return;
/*     */       }
/*     */       
/* 280 */       long now = System.currentTimeMillis();
/* 281 */       long next = this.start + ++this.count * this.periodMillis;
/* 282 */       long delta = Math.max(0L, next - now);
/*     */       
/* 284 */       if (delta == 0L) {
/* 285 */         this.display.asyncExec(this);
/*     */       } else {
/* 287 */         this.display.timerExec((int)delta, this);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void dispose() {
/* 293 */       set(true);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class SwtPeriodicAction
/*     */     extends AtomicBoolean
/*     */     implements Runnable, Disposable
/*     */   {
/*     */     private static final long serialVersionUID = 1890399765810263705L;
/*     */     
/*     */     final Runnable task;
/*     */     
/*     */     final Display display;
/*     */     
/*     */     final long periodMillis;
/*     */     final long start;
/*     */     final SwtScheduler.SwtWorker parent;
/*     */     long count;
/*     */     
/*     */     public SwtPeriodicAction(Runnable task, SwtScheduler.SwtWorker parent, Display display, long start, long periodMillis) {
/* 314 */       this.task = task;
/* 315 */       this.display = display;
/* 316 */       this.start = start;
/* 317 */       this.periodMillis = periodMillis;
/* 318 */       this.parent = parent;
/*     */     }
/*     */ 
/*     */     
/*     */     public void run() {
/* 323 */       if (get() || this.parent.unsubscribed) {
/*     */         return;
/*     */       }
/*     */       
/*     */       try {
/* 328 */         this.task.run();
/* 329 */       } catch (Throwable ex) {
/* 330 */         Exceptions.throwIfFatal(ex);
/* 331 */         Operators.onErrorDropped(ex, Context.empty());
/*     */         
/*     */         return;
/*     */       } 
/* 335 */       if (get() || this.parent.unsubscribed) {
/*     */         return;
/*     */       }
/*     */       
/* 339 */       long now = System.currentTimeMillis();
/* 340 */       long next = this.start + ++this.count * this.periodMillis;
/* 341 */       long delta = Math.max(0L, next - now);
/*     */       
/* 343 */       if (delta == 0L) {
/* 344 */         this.display.asyncExec(this);
/*     */       } else {
/* 346 */         this.display.timerExec((int)delta, this);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void dispose() {
/* 352 */       set(true);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-extra-3.4.10.jar!\reactor\swing\SwtScheduler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */