/*    */ package reactor.swing;
/*    */ 
/*    */ import kotlin.Deprecated;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.ReplaceWith;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import org.eclipse.swt.widgets.Display;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import reactor.core.scheduler.Scheduler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 1, 18}, bv = {1, 0, 3}, k = 2, d1 = {"\000\f\n\000\n\002\030\002\n\002\030\002\n\000\032\f\020\000\032\0020\001*\0020\002H\007¨\006\003"}, d2 = {"toScheduler", "Lreactor/core/scheduler/Scheduler;", "Lorg/eclipse/swt/widgets/Display;", "reactor-extra"})
/*    */ public final class SwtSchedulerExtensionsKt
/*    */ {
/*    */   @Deprecated(message = "To be removed in 3.3.0.RELEASE, replaced by module reactor-kotlin-extensions", replaceWith = @ReplaceWith(imports = {"reactor.kotlin.extra.swing.toScheduler"}, expression = "toScheduler()"))
/*    */   @NotNull
/*    */   public static final Scheduler toScheduler(@NotNull Display $this$toScheduler) {
/* 30 */     Intrinsics.checkParameterIsNotNull($this$toScheduler, "$this$toScheduler"); Intrinsics.checkExpressionValueIsNotNull(SwtScheduler.from($this$toScheduler), "SwtScheduler.from(this)"); return SwtScheduler.from($this$toScheduler);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-extra-3.4.10.jar!\reactor\swing\SwtSchedulerExtensionsKt.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */