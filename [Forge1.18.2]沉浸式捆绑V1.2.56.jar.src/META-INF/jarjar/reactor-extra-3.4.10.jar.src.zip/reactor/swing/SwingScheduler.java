/*     */ package reactor.swing;
/*     */ 
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import javax.swing.SwingUtilities;
/*     */ import javax.swing.Timer;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.publisher.Operators;
/*     */ import reactor.core.scheduler.Scheduler;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public final class SwingScheduler
/*     */   implements Scheduler
/*     */ {
/*     */   public static Scheduler create() {
/*  43 */     return new SwingScheduler();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Disposable schedule(Runnable task) {
/*  51 */     SwingScheduledDirectAction a = new SwingScheduledDirectAction(task);
/*     */     
/*  53 */     SwingUtilities.invokeLater(a);
/*     */     
/*  55 */     return a;
/*     */   }
/*     */ 
/*     */   
/*     */   public Disposable schedule(Runnable task, long delay, TimeUnit unit) {
/*  60 */     if (delay <= 0L) {
/*  61 */       return schedule(task);
/*     */     }
/*     */     
/*  64 */     Timer timer = new Timer((int)unit.toMillis(delay), null);
/*  65 */     timer.setRepeats(false);
/*  66 */     timer.addActionListener(e -> {
/*     */           try {
/*     */             task.run();
/*  69 */           } catch (Throwable ex) {
/*     */             Exceptions.throwIfFatal(ex);
/*     */             Operators.onErrorDropped(ex, Context.empty());
/*     */           } 
/*     */         });
/*  74 */     timer.start();
/*  75 */     return timer::stop;
/*     */   }
/*     */ 
/*     */   
/*     */   public Disposable schedulePeriodically(Runnable task, long initialDelay, long period, TimeUnit unit) {
/*  80 */     Timer timer = new Timer((int)unit.toMillis(period), null);
/*  81 */     timer.setInitialDelay((int)unit.toMillis(initialDelay));
/*     */     
/*  83 */     timer.addActionListener(e -> {
/*     */           try {
/*     */             task.run();
/*  86 */           } catch (Throwable ex) {
/*     */             timer.stop();
/*     */             Exceptions.throwIfFatal(ex);
/*     */             Operators.onErrorDropped(ex, Context.empty());
/*     */           } 
/*     */         });
/*  92 */     timer.start();
/*  93 */     return timer::stop;
/*     */   }
/*     */ 
/*     */   
/*     */   public Scheduler.Worker createWorker() {
/*  98 */     return new SwingSchedulerWorker();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static final class SwingSchedulerWorker
/*     */     implements Scheduler.Worker
/*     */   {
/*     */     volatile boolean unsubscribed;
/*     */     
/* 108 */     Set<Timer> tasks = new HashSet<>();
/*     */ 
/*     */     
/*     */     public void dispose() {
/*     */       Set<Timer> set;
/* 113 */       if (this.unsubscribed) {
/*     */         return;
/*     */       }
/* 116 */       this.unsubscribed = true;
/*     */ 
/*     */       
/* 119 */       synchronized (this) {
/* 120 */         set = this.tasks;
/* 121 */         this.tasks = null;
/*     */       } 
/*     */       
/* 124 */       if (set != null) {
/* 125 */         for (Timer t : set) {
/* 126 */           t.stop();
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     void remove(Timer timer) {
/* 132 */       if (this.unsubscribed) {
/*     */         return;
/*     */       }
/* 135 */       synchronized (this) {
/* 136 */         if (this.unsubscribed) {
/*     */           return;
/*     */         }
/*     */         
/* 140 */         this.tasks.remove(timer);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Disposable schedule(Runnable action) {
/* 147 */       if (!this.unsubscribed) {
/* 148 */         SwingScheduler.SwingScheduledDirectAction a = new SwingScheduler.SwingScheduledDirectAction(action);
/*     */         
/* 150 */         SwingUtilities.invokeLater(a);
/*     */         
/* 152 */         return a;
/*     */       } 
/* 154 */       throw Exceptions.failWithRejected();
/*     */     }
/*     */ 
/*     */     
/*     */     public Disposable schedule(Runnable action, long delayTime, TimeUnit unit) {
/* 159 */       if (delayTime <= 0L) {
/* 160 */         return schedule(action);
/*     */       }
/*     */       
/* 163 */       if (this.unsubscribed) {
/* 164 */         throw Exceptions.failWithRejected();
/*     */       }
/*     */       
/* 167 */       Timer timer = new Timer((int)unit.toMillis(delayTime), null);
/* 168 */       timer.setRepeats(false);
/*     */       
/* 170 */       synchronized (this) {
/* 171 */         if (this.unsubscribed) {
/* 172 */           throw Exceptions.failWithRejected();
/*     */         }
/* 174 */         this.tasks.add(timer);
/*     */       } 
/*     */       
/* 177 */       timer.addActionListener(e -> {
/*     */             try {
/*     */               try {
/*     */                 action.run();
/* 181 */               } catch (Throwable ex) {
/*     */                 Exceptions.throwIfFatal(ex);
/*     */                 
/*     */                 Operators.onErrorDropped(ex, Context.empty());
/*     */               } 
/*     */             } finally {
/*     */               remove(timer);
/*     */             } 
/*     */           });
/* 190 */       timer.start();
/*     */       
/* 192 */       if (this.unsubscribed) {
/* 193 */         timer.stop();
/* 194 */         throw Exceptions.failWithRejected();
/*     */       } 
/*     */       
/* 197 */       return () -> {
/*     */           timer.stop();
/*     */           remove(timer);
/*     */         };
/*     */     }
/*     */ 
/*     */     
/*     */     public Disposable schedulePeriodically(Runnable task, long initialDelay, long period, TimeUnit unit) {
/* 205 */       if (this.unsubscribed) {
/* 206 */         throw Exceptions.failWithRejected();
/*     */       }
/*     */       
/* 209 */       Timer timer = new Timer((int)unit.toMillis(period), null);
/* 210 */       timer.setInitialDelay((int)unit.toMillis(initialDelay));
/*     */       
/* 212 */       synchronized (this) {
/* 213 */         if (this.unsubscribed) {
/* 214 */           throw Exceptions.failWithRejected();
/*     */         }
/* 216 */         this.tasks.add(timer);
/*     */       } 
/*     */       
/* 219 */       timer.addActionListener(e -> {
/*     */             try {
/*     */               task.run();
/* 222 */             } catch (Throwable ex) {
/*     */               timer.stop();
/*     */               
/*     */               remove(timer);
/*     */               Exceptions.throwIfFatal(ex);
/*     */               Operators.onErrorDropped(ex, Context.empty());
/*     */             } 
/*     */           });
/* 230 */       timer.start();
/*     */       
/* 232 */       if (this.unsubscribed) {
/* 233 */         timer.stop();
/* 234 */         throw Exceptions.failWithRejected();
/*     */       } 
/*     */       
/* 237 */       return () -> {
/*     */           timer.stop();
/*     */           remove(timer);
/*     */         };
/*     */     }
/*     */   }
/*     */   
/*     */   static final class SwingScheduledDirectAction
/*     */     extends AtomicBoolean
/*     */     implements Runnable, Disposable
/*     */   {
/*     */     private static final long serialVersionUID = 2378266891882031635L;
/*     */     final Runnable action;
/*     */     
/*     */     public SwingScheduledDirectAction(Runnable action) {
/* 252 */       this.action = action;
/*     */     }
/*     */ 
/*     */     
/*     */     public void run() {
/* 257 */       if (!get()) {
/*     */         try {
/* 259 */           this.action.run();
/* 260 */         } catch (Throwable ex) {
/* 261 */           Exceptions.throwIfFatal(ex);
/* 262 */           Operators.onErrorDropped(ex, Context.empty());
/*     */         } 
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void dispose() {
/* 269 */       set(true);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-extra-3.4.10.jar!\reactor\swing\SwingScheduler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */