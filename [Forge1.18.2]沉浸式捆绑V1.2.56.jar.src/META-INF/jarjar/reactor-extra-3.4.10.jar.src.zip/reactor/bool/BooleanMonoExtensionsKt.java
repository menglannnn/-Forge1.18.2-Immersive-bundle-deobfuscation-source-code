/*    */ package reactor.bool;
/*    */ 
/*    */ import kotlin.Deprecated;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.ReplaceWith;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 1, 18}, bv = {1, 0, 3}, k = 2, d1 = {"\000\016\n\000\n\002\030\002\n\002\020\013\n\002\b\007\032&\020\000\032\b\022\004\022\0020\0020\001*\b\022\004\022\0020\0020\0012\f\020\003\032\b\022\004\022\0020\0020\001H\007\032&\020\004\032\b\022\004\022\0020\0020\001*\b\022\004\022\0020\0020\0012\f\020\003\032\b\022\004\022\0020\0020\001H\007\032&\020\005\032\b\022\004\022\0020\0020\001*\b\022\004\022\0020\0020\0012\f\020\003\032\b\022\004\022\0020\0020\001H\007\032&\020\006\032\b\022\004\022\0020\0020\001*\b\022\004\022\0020\0020\0012\f\020\003\032\b\022\004\022\0020\0020\001H\007\032&\020\007\032\b\022\004\022\0020\0020\001*\b\022\004\022\0020\0020\0012\f\020\003\032\b\022\004\022\0020\0020\001H\007\032\031\020\b\032\b\022\004\022\0020\0020\001*\b\022\004\022\0020\0020\001H\002¨\006\t"}, d2 = {"logicalAnd", "Lreactor/core/publisher/Mono;", "", "rightHand", "logicalNAnd", "logicalNOr", "logicalOr", "logicalXOr", "not", "reactor-extra"})
/*    */ public final class BooleanMonoExtensionsKt
/*    */ {
/*    */   @Deprecated(message = "To be removed in 3.3.0.RELEASE, replaced by module reactor-kotlin-extensions", replaceWith = @ReplaceWith(imports = {"reactor.kotlin.extra.bool.not"}, expression = "not()"))
/*    */   @NotNull
/*    */   public static final Mono<Boolean> not(@NotNull Mono<Boolean> $this$not) {
/* 30 */     Intrinsics.checkParameterIsNotNull($this$not, "$this$not"); Intrinsics.checkExpressionValueIsNotNull(BooleanUtils.not($this$not), "BooleanUtils.not(this)"); return BooleanUtils.not($this$not);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Deprecated(message = "To be removed in 3.3.0.RELEASE, replaced by module reactor-kotlin-extensions", replaceWith = @ReplaceWith(imports = {"reactor.kotlin.extra.bool.logicalHand"}, expression = "logicalAnd(rightHand)"))
/*    */   @NotNull
/*    */   public static final Mono<Boolean> logicalAnd(@NotNull Mono<Boolean> $this$logicalAnd, @NotNull Mono<Boolean> rightHand) {
/* 40 */     Intrinsics.checkParameterIsNotNull($this$logicalAnd, "$this$logicalAnd"); Intrinsics.checkParameterIsNotNull(rightHand, "rightHand"); Intrinsics.checkExpressionValueIsNotNull(BooleanUtils.and($this$logicalAnd, rightHand), "BooleanUtils.and(this, rightHand)"); return BooleanUtils.and($this$logicalAnd, rightHand);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Deprecated(message = "To be removed in 3.3.0.RELEASE, replaced by module reactor-kotlin-extensions", replaceWith = @ReplaceWith(imports = {"reactor.kotlin.extra.bool.logicalNAnd"}, expression = "logicalNAnd(rightHand)"))
/*    */   @NotNull
/*    */   public static final Mono<Boolean> logicalNAnd(@NotNull Mono<Boolean> $this$logicalNAnd, @NotNull Mono<Boolean> rightHand) {
/* 50 */     Intrinsics.checkParameterIsNotNull($this$logicalNAnd, "$this$logicalNAnd"); Intrinsics.checkParameterIsNotNull(rightHand, "rightHand"); Intrinsics.checkExpressionValueIsNotNull(BooleanUtils.nand($this$logicalNAnd, rightHand), "BooleanUtils.nand(this, rightHand)"); return BooleanUtils.nand($this$logicalNAnd, rightHand);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Deprecated(message = "To be removed in 3.3.0.RELEASE, replaced by module reactor-kotlin-extensions", replaceWith = @ReplaceWith(imports = {"reactor.kotlin.extra.bool.logicalOr"}, expression = "logicalOr()"))
/*    */   @NotNull
/*    */   public static final Mono<Boolean> logicalOr(@NotNull Mono<Boolean> $this$logicalOr, @NotNull Mono<Boolean> rightHand) {
/* 60 */     Intrinsics.checkParameterIsNotNull($this$logicalOr, "$this$logicalOr"); Intrinsics.checkParameterIsNotNull(rightHand, "rightHand"); Intrinsics.checkExpressionValueIsNotNull(BooleanUtils.or($this$logicalOr, rightHand), "BooleanUtils.or(this, rightHand)"); return BooleanUtils.or($this$logicalOr, rightHand);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Deprecated(message = "To be removed in 3.3.0.RELEASE, replaced by module reactor-kotlin-extensions", replaceWith = @ReplaceWith(imports = {"reactor.kotlin.extra.bool.logicalNOr"}, expression = "logicalNOr()"))
/*    */   @NotNull
/*    */   public static final Mono<Boolean> logicalNOr(@NotNull Mono<Boolean> $this$logicalNOr, @NotNull Mono<Boolean> rightHand) {
/* 70 */     Intrinsics.checkParameterIsNotNull($this$logicalNOr, "$this$logicalNOr"); Intrinsics.checkParameterIsNotNull(rightHand, "rightHand"); Intrinsics.checkExpressionValueIsNotNull(BooleanUtils.nor($this$logicalNOr, rightHand), "BooleanUtils.nor(this, rightHand)"); return BooleanUtils.nor($this$logicalNOr, rightHand);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Deprecated(message = "To be removed in 3.3.0.RELEASE, replaced by module reactor-kotlin-extensions", replaceWith = @ReplaceWith(imports = {"reactor.kotlin.extra.bool.logicalXOr"}, expression = "logicalXOr()"))
/*    */   @NotNull
/*    */   public static final Mono<Boolean> logicalXOr(@NotNull Mono<Boolean> $this$logicalXOr, @NotNull Mono<Boolean> rightHand) {
/* 80 */     Intrinsics.checkParameterIsNotNull($this$logicalXOr, "$this$logicalXOr"); Intrinsics.checkParameterIsNotNull(rightHand, "rightHand"); Intrinsics.checkExpressionValueIsNotNull(BooleanUtils.xor($this$logicalXOr, rightHand), "BooleanUtils.xor(this, rightHand)"); return BooleanUtils.xor($this$logicalXOr, rightHand);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-extra-3.4.10.jar!\reactor\bool\BooleanMonoExtensionsKt.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */