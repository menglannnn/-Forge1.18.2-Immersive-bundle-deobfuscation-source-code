/*    */ package reactor.bool;
/*    */ 
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class BooleanUtils
/*    */ {
/*    */   public static Mono<Boolean> not(Mono<Boolean> value) {
/* 38 */     return value.map(bool -> Boolean.valueOf(!bool.booleanValue()));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Mono<Boolean> and(Mono<Boolean> value1, Mono<Boolean> value2) {
/* 49 */     return Mono.zip(value1, value2, (bool1, bool2) -> Boolean.valueOf((bool1.booleanValue() && bool2.booleanValue())));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Mono<Boolean> xor(Mono<Boolean> value1, Mono<Boolean> value2) {
/* 61 */     return Mono.zip(value1, value2, (bool1, bool2) -> Boolean.valueOf((bool1 != bool2 && (bool1.booleanValue() || bool2.booleanValue()))));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Mono<Boolean> or(Mono<Boolean> value1, Mono<Boolean> value2) {
/* 72 */     return Mono.zip(value1, value2, (bool1, bool2) -> Boolean.valueOf((bool1.booleanValue() || bool2.booleanValue())));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Mono<Boolean> nand(Mono<Boolean> value1, Mono<Boolean> value2) {
/* 83 */     return not(and(value1, value2));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Mono<Boolean> nor(Mono<Boolean> value1, Mono<Boolean> value2) {
/* 94 */     return not(or(value1, value2));
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-extra-3.4.10.jar!\reactor\bool\BooleanUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */