/*     */ package reactor.math;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.util.Comparator;
/*     */ import java.util.function.Function;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MathFlux
/*     */ {
/*     */   public static Mono<Integer> sumInt(Publisher<? extends Number> source) {
/*  50 */     return sumInt(source, i -> i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final <T> Mono<Integer> sumInt(Publisher<T> source, Function<? super T, ? extends Number> mapping) {
/*  65 */     return MathMono.onAssembly(new MonoSumInt<>(source, mapping));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Mono<Long> sumLong(Publisher<? extends Number> source) {
/*  78 */     return sumLong(source, i -> i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final <T> Mono<Long> sumLong(Publisher<T> source, Function<? super T, ? extends Number> mapping) {
/*  93 */     return MathMono.onAssembly(new MonoSumLong<>(source, mapping));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Mono<Float> sumFloat(Publisher<? extends Number> source) {
/* 104 */     return sumFloat(source, i -> i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final <T> Mono<Float> sumFloat(Publisher<T> source, Function<? super T, ? extends Number> mapping) {
/* 117 */     return MathMono.onAssembly(new MonoSumFloat<>(source, mapping));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Mono<Double> sumDouble(Publisher<? extends Number> source) {
/* 128 */     return sumDouble(source, i -> i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final <T> Mono<Double> sumDouble(Publisher<T> source, Function<? super T, ? extends Number> mapping) {
/* 141 */     return MathMono.onAssembly(new MonoSumDouble<>(source, mapping));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Mono<BigInteger> sumBigInteger(Publisher<? extends Number> source) {
/* 155 */     return sumBigInteger(source, i -> i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final <T> Mono<BigInteger> sumBigInteger(Publisher<T> source, Function<? super T, ? extends Number> mapping) {
/* 172 */     return MathMono.onAssembly(new MonoSumBigInteger<>(source, mapping));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Mono<BigDecimal> sumBigDecimal(Publisher<? extends Number> source) {
/* 182 */     return sumBigDecimal(source, i -> i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final <T> Mono<BigDecimal> sumBigDecimal(Publisher<T> source, Function<? super T, ? extends Number> mapping) {
/* 195 */     return MathMono.onAssembly(new MonoSumBigDecimal<>(source, mapping));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Mono<Float> averageFloat(Publisher<? extends Number> source) {
/* 206 */     return averageFloat(source, i -> i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final <T> Mono<Float> averageFloat(Publisher<T> source, Function<? super T, ? extends Number> mapping) {
/* 219 */     return MathMono.onAssembly(new MonoAverageFloat<>(source, mapping));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Mono<Double> averageDouble(Publisher<? extends Number> source) {
/* 230 */     return averageDouble(source, i -> i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final <T> Mono<Double> averageDouble(Publisher<T> source, Function<? super T, ? extends Number> mapping) {
/* 243 */     return MathMono.onAssembly(new MonoAverageDouble<>(source, mapping));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Mono<BigInteger> averageBigInteger(Publisher<? extends Number> source) {
/* 258 */     return averageBigInteger(source, i -> i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final <T> Mono<BigInteger> averageBigInteger(Publisher<T> source, Function<? super T, ? extends Number> mapping) {
/* 277 */     return MathMono.onAssembly(new MonoAverageBigInteger<>(source, mapping));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Mono<BigDecimal> averageBigDecimal(Publisher<? extends Number> source) {
/* 288 */     return averageBigDecimal(source, i -> i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final <T> Mono<BigDecimal> averageBigDecimal(Publisher<T> source, Function<? super T, ? extends Number> mapping) {
/* 301 */     return MathMono.onAssembly(new MonoAverageBigDecimal<>(source, mapping));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final <T extends Comparable<? super T>> Mono<T> max(Publisher<T> source) {
/* 312 */     Comparator<? super T> comparator = comparableComparator();
/* 313 */     return max(source, comparator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Mono<T> max(Publisher<T> source, Comparator<? super T> comparator) {
/* 325 */     return MathMono.onAssembly(new MonoMinMax<>(source, comparator, 1));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final <T extends Comparable<? super T>> Mono<T> min(Publisher<T> source) {
/* 336 */     Comparator<? super T> comparator = comparableComparator();
/* 337 */     return min(source, comparator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Mono<T> min(Publisher<T> source, Comparator<? super T> comparator) {
/* 349 */     return MathMono.onAssembly(new MonoMinMax<>(source, comparator, -1));
/*     */   }
/*     */   
/*     */   static <T extends Comparable<? super T>> Comparator<? super T> comparableComparator() {
/* 353 */     return new Comparator<T>()
/*     */       {
/*     */         public int compare(T o1, T o2) {
/* 356 */           return o1.compareTo(o2);
/*     */         }
/*     */       };
/*     */   }
/*     */   
/*     */   static abstract class MathMono<T>
/*     */     extends Mono<T> {
/*     */     protected static <T> Mono<T> onAssembly(Mono<T> source) {
/* 364 */       return Mono.onAssembly(source);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-extra-3.4.10.jar!\reactor\math\MathFlux.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */