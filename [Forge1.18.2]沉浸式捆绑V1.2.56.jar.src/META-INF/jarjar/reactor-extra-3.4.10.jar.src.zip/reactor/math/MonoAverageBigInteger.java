/*    */ package reactor.math;
/*    */ 
/*    */ import java.math.BigDecimal;
/*    */ import java.math.BigInteger;
/*    */ import java.math.RoundingMode;
/*    */ import java.util.function.Function;
/*    */ import javax.annotation.Nullable;
/*    */ import org.reactivestreams.Publisher;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Fuseable;
/*    */ import reactor.core.Scannable;
/*    */ import reactor.core.publisher.Flux;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MonoAverageBigInteger<T>
/*    */   extends MonoFromFluxOperator<T, BigInteger>
/*    */   implements Fuseable
/*    */ {
/*    */   private final Function<? super T, ? extends Number> mapping;
/*    */   
/*    */   MonoAverageBigInteger(Publisher<T> source, Function<? super T, ? extends Number> mapping) {
/* 41 */     super(Flux.from(source));
/* 42 */     this.mapping = mapping;
/*    */   }
/*    */ 
/*    */   
/*    */   public void subscribe(CoreSubscriber<? super BigInteger> actual) {
/* 47 */     this.source.subscribe((CoreSubscriber)new AverageBigIntegerSubscriber<>(actual, this.mapping));
/*    */   }
/*    */ 
/*    */   
/*    */   private static final class AverageBigIntegerSubscriber<T>
/*    */     extends MathSubscriber<T, BigInteger>
/*    */   {
/*    */     private final Function<? super T, ? extends Number> mapping;
/*    */     
/*    */     private int count;
/* 57 */     private BigDecimal sum = BigDecimal.ZERO;
/*    */ 
/*    */     
/*    */     AverageBigIntegerSubscriber(CoreSubscriber<? super BigInteger> actual, Function<? super T, ? extends Number> mapping) {
/* 61 */       super(actual);
/* 62 */       this.mapping = mapping;
/*    */     }
/*    */ 
/*    */     
/*    */     protected void reset() {
/* 67 */       this.count = 0;
/* 68 */       this.sum = BigDecimal.ZERO;
/*    */     }
/*    */ 
/*    */     
/*    */     protected BigInteger result() {
/* 73 */       return (this.count == 0) ? null : this.sum.divide(BigDecimal.valueOf(this.count), RoundingMode.FLOOR).toBigInteger();
/*    */     }
/*    */     
/*    */     protected void updateResult(T newValue) {
/*    */       BigDecimal bigDecimalValue;
/* 78 */       Number number = this.mapping.apply(newValue);
/*    */       
/* 80 */       if (number instanceof BigDecimal) {
/* 81 */         bigDecimalValue = (BigDecimal)number;
/*    */       }
/* 83 */       else if (number instanceof BigInteger) {
/* 84 */         bigDecimalValue = new BigDecimal((BigInteger)number);
/*    */       } else {
/*    */         
/* 87 */         bigDecimalValue = new BigDecimal(number.toString());
/*    */       } 
/* 89 */       this.sum = this.sum.add(bigDecimalValue);
/* 90 */       this.count++;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-extra-3.4.10.jar!\reactor\math\MonoAverageBigInteger.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */