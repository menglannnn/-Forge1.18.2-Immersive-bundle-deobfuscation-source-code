/*    */ package reactor.math;
/*    */ 
/*    */ import org.reactivestreams.Subscription;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.publisher.Operators;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class MathSubscriber<T, R>
/*    */   extends Operators.MonoSubscriber<T, R>
/*    */ {
/*    */   Subscription s;
/*    */   boolean done;
/*    */   
/*    */   MathSubscriber(CoreSubscriber<? super R> actual) {
/* 30 */     super(actual);
/*    */   }
/*    */ 
/*    */   
/*    */   public void onSubscribe(Subscription s) {
/* 35 */     if (Operators.validate(this.s, s)) {
/* 36 */       this.s = s;
/* 37 */       this.actual.onSubscribe((Subscription)this);
/* 38 */       s.request(Long.MAX_VALUE);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void onNext(T t) {
/* 44 */     if (this.done) {
/* 45 */       Operators.onNextDropped(t, this.actual.currentContext());
/*    */       
/*    */       return;
/*    */     } 
/*    */     try {
/* 50 */       updateResult(t);
/*    */     }
/* 52 */     catch (Throwable ex) {
/* 53 */       reset();
/* 54 */       this.done = true;
/* 55 */       this.actual.onError(Operators.onOperatorError(this.s, ex, t, this.actual.currentContext()));
/*    */       return;
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void onError(Throwable t) {
/* 62 */     if (this.done) {
/* 63 */       Operators.onErrorDropped(t, this.actual.currentContext());
/*    */       return;
/*    */     } 
/* 66 */     this.done = true;
/* 67 */     reset();
/* 68 */     this.actual.onError(t);
/*    */   }
/*    */ 
/*    */   
/*    */   public void onComplete() {
/* 73 */     if (this.done) {
/*    */       return;
/*    */     }
/* 76 */     this.done = true;
/* 77 */     R r = result();
/* 78 */     if (r != null) {
/* 79 */       complete(r);
/*    */     } else {
/*    */       
/* 82 */       this.actual.onComplete();
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void cancel() {
/* 88 */     super.cancel();
/* 89 */     this.s.cancel();
/*    */   }
/*    */   
/*    */   protected abstract void reset();
/*    */   
/*    */   protected abstract R result();
/*    */   
/*    */   protected abstract void updateResult(T paramT);
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-extra-3.4.10.jar!\reactor\math\MathSubscriber.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */