/*    */ package reactor.math;
/*    */ 
/*    */ import java.util.function.Function;
/*    */ import org.reactivestreams.Publisher;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Fuseable;
/*    */ import reactor.core.publisher.Flux;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MonoSumDouble<T>
/*    */   extends MonoFromFluxOperator<T, Double>
/*    */   implements Fuseable
/*    */ {
/*    */   final Function<? super T, ? extends Number> mapping;
/*    */   
/*    */   MonoSumDouble(Publisher<? extends T> source, Function<? super T, ? extends Number> mapping) {
/* 36 */     super(Flux.from(source));
/* 37 */     this.mapping = mapping;
/*    */   }
/*    */ 
/*    */   
/*    */   public void subscribe(CoreSubscriber<? super Double> s) {
/* 42 */     this.source.subscribe((CoreSubscriber)new SumLongSubscriber<>(s, this.mapping));
/*    */   }
/*    */ 
/*    */   
/*    */   static final class SumLongSubscriber<T>
/*    */     extends MathSubscriber<T, Double>
/*    */   {
/*    */     final Function<? super T, ? extends Number> mapping;
/*    */     double sum;
/*    */     boolean hasValue;
/*    */     
/*    */     SumLongSubscriber(CoreSubscriber<? super Double> actual, Function<? super T, ? extends Number> mapping) {
/* 54 */       super(actual);
/* 55 */       this.mapping = mapping;
/*    */     }
/*    */ 
/*    */     
/*    */     protected void updateResult(T newValue) {
/* 60 */       double doubleValue = ((Number)this.mapping.apply(newValue)).doubleValue();
/* 61 */       this.sum = this.hasValue ? (this.sum + doubleValue) : doubleValue;
/* 62 */       this.hasValue = true;
/*    */     }
/*    */ 
/*    */     
/*    */     protected Double result() {
/* 67 */       return this.hasValue ? Double.valueOf(this.sum) : null;
/*    */     }
/*    */ 
/*    */     
/*    */     protected void reset() {
/* 72 */       this.sum = 0.0D;
/* 73 */       this.hasValue = false;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-extra-3.4.10.jar!\reactor\math\MonoSumDouble.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */