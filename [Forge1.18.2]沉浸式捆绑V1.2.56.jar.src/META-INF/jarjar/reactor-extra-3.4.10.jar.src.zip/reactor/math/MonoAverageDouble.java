/*    */ package reactor.math;
/*    */ 
/*    */ import java.util.function.Function;
/*    */ import org.reactivestreams.Publisher;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Fuseable;
/*    */ import reactor.core.publisher.Flux;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MonoAverageDouble<T>
/*    */   extends MonoFromFluxOperator<T, Double>
/*    */   implements Fuseable
/*    */ {
/*    */   final Function<? super T, ? extends Number> mapping;
/*    */   
/*    */   MonoAverageDouble(Publisher<? extends T> source, Function<? super T, ? extends Number> mapping) {
/* 36 */     super(Flux.from(source));
/* 37 */     this.mapping = mapping;
/*    */   }
/*    */ 
/*    */   
/*    */   public void subscribe(CoreSubscriber<? super Double> s) {
/* 42 */     this.source.subscribe((CoreSubscriber)new AverageDoubleSubscriber<>(s, this.mapping));
/*    */   }
/*    */ 
/*    */   
/*    */   static final class AverageDoubleSubscriber<T>
/*    */     extends MathSubscriber<T, Double>
/*    */   {
/*    */     final Function<? super T, ? extends Number> mapping;
/*    */     int count;
/*    */     double sum;
/*    */     
/*    */     AverageDoubleSubscriber(CoreSubscriber<? super Double> actual, Function<? super T, ? extends Number> mapping) {
/* 54 */       super(actual);
/* 55 */       this.mapping = mapping;
/*    */     }
/*    */ 
/*    */     
/*    */     protected void updateResult(T newValue) {
/* 60 */       this.count++;
/* 61 */       double doubleValue = ((Number)this.mapping.apply(newValue)).doubleValue();
/* 62 */       this.sum += doubleValue;
/*    */     }
/*    */ 
/*    */     
/*    */     protected Double result() {
/* 67 */       return (this.count == 0) ? null : Double.valueOf(this.sum / this.count);
/*    */     }
/*    */ 
/*    */     
/*    */     protected void reset() {
/* 72 */       this.count = 0;
/* 73 */       this.sum = 0.0D;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-extra-3.4.10.jar!\reactor\math\MonoAverageDouble.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */