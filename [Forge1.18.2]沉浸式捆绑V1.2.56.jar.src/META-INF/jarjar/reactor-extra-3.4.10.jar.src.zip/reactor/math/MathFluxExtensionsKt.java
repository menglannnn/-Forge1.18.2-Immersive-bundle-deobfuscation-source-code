/*     */ package reactor.math;
/*     */ 
/*     */ import java.util.Comparator;
/*     */ import java.util.function.Function;
/*     */ import kotlin.Deprecated;
/*     */ import kotlin.Metadata;
/*     */ import kotlin.ReplaceWith;
/*     */ import kotlin.jvm.functions.Function1;
/*     */ import kotlin.jvm.functions.Function2;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Metadata(mv = {1, 1, 18}, bv = {1, 0, 3}, k = 2, d1 = {"\000>\n\000\n\002\030\002\n\002\020\006\n\000\n\002\020\004\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\017\n\000\n\002\030\002\n\002\020\b\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\t\n\002\b\002\032\"\020\000\032\b\022\004\022\0020\0020\001\"\b\b\000\020\003*\0020\004*\b\022\004\022\002H\0030\005H\007\0322\020\000\032\b\022\004\022\0020\0020\001\"\004\b\000\020\003*\b\022\004\022\002H\0030\0052\022\020\006\032\016\022\004\022\002H\003\022\004\022\0020\0040\007H\007\032(\020\b\032\b\022\004\022\002H\0030\001\"\016\b\000\020\003*\b\022\004\022\002H\0030\t*\b\022\004\022\002H\0030\005H\007\0328\020\b\032\b\022\004\022\002H\0030\001\"\004\b\000\020\003*\b\022\004\022\002H\0030\0052\030\020\n\032\024\022\004\022\002H\003\022\004\022\002H\003\022\004\022\0020\f0\013H\007\0326\020\b\032\b\022\004\022\002H\0030\001\"\004\b\000\020\003*\b\022\004\022\002H\0030\0052\026\020\n\032\022\022\004\022\002H\0030\rj\b\022\004\022\002H\003`\016H\007\032(\020\017\032\b\022\004\022\002H\0030\001\"\016\b\000\020\003*\b\022\004\022\002H\0030\t*\b\022\004\022\002H\0030\005H\007\0328\020\017\032\b\022\004\022\002H\0030\001\"\004\b\000\020\003*\b\022\004\022\002H\0030\0052\030\020\n\032\024\022\004\022\002H\003\022\004\022\002H\003\022\004\022\0020\f0\013H\007\0326\020\017\032\b\022\004\022\002H\0030\001\"\004\b\000\020\003*\b\022\004\022\002H\0030\0052\026\020\n\032\022\022\004\022\002H\0030\rj\b\022\004\022\002H\003`\016H\007\032\"\020\020\032\b\022\004\022\0020\0210\001\"\b\b\000\020\003*\0020\004*\b\022\004\022\002H\0030\005H\007\0322\020\020\032\b\022\004\022\0020\0210\001\"\004\b\000\020\003*\b\022\004\022\002H\0030\0052\022\020\006\032\016\022\004\022\002H\003\022\004\022\0020\0040\007H\007\032\"\020\022\032\b\022\004\022\0020\0020\001\"\b\b\000\020\003*\0020\004*\b\022\004\022\002H\0030\005H\007\0322\020\022\032\b\022\004\022\0020\0020\001\"\004\b\000\020\003*\b\022\004\022\002H\0030\0052\022\020\006\032\016\022\004\022\002H\003\022\004\022\0020\0040\007H\007¨\006\023"}, d2 = {"average", "Lreactor/core/publisher/Mono;", "", "T", "", "Lreactor/core/publisher/Flux;", "mapper", "Lkotlin/Function1;", "max", "", "comp", "Lkotlin/Function2;", "", "Ljava/util/Comparator;", "Lkotlin/Comparator;", "min", "sum", "", "sumDouble", "reactor-extra"})
/*     */ public final class MathFluxExtensionsKt
/*     */ {
/*     */   @Deprecated(message = "To be removed in 3.3.0.RELEASE, replaced by module reactor-kotlin-extensions", replaceWith = @ReplaceWith(imports = {"reactor.kotlin.extra.math.sum"}, expression = "sum()"))
/*     */   @NotNull
/*     */   public static final <T extends Number> Mono<Long> sum(@NotNull Flux $this$sum) {
/*  35 */     Intrinsics.checkParameterIsNotNull($this$sum, "$this$sum"); Intrinsics.checkExpressionValueIsNotNull(MathFlux.sumLong((Publisher<? extends Number>)$this$sum), "MathFlux.sumLong(this)"); return MathFlux.sumLong((Publisher<? extends Number>)$this$sum);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(message = "To be removed in 3.3.0.RELEASE, replaced by module reactor-kotlin-extensions", replaceWith = @ReplaceWith(imports = {"reactor.kotlin.extra.math.sumDouble"}, expression = "sumDouble()"))
/*     */   @NotNull
/*     */   public static final <T extends Number> Mono<Double> sumDouble(@NotNull Flux $this$sumDouble) {
/*  50 */     Intrinsics.checkParameterIsNotNull($this$sumDouble, "$this$sumDouble"); Intrinsics.checkExpressionValueIsNotNull(MathFlux.sumDouble((Publisher<? extends Number>)$this$sumDouble), "MathFlux.sumDouble(this)"); return MathFlux.sumDouble((Publisher<? extends Number>)$this$sumDouble);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(message = "To be removed in 3.3.0.RELEASE, replaced by module reactor-kotlin-extensions", replaceWith = @ReplaceWith(imports = {"reactor.kotlin.extra.math.average"}, expression = "average()"))
/*     */   @NotNull
/*     */   public static final <T extends Number> Mono<Double> average(@NotNull Flux $this$average) {
/*  65 */     Intrinsics.checkParameterIsNotNull($this$average, "$this$average"); Intrinsics.checkExpressionValueIsNotNull(MathFlux.averageDouble((Publisher<? extends Number>)$this$average), "MathFlux.averageDouble(this)"); return MathFlux.averageDouble((Publisher<? extends Number>)$this$average);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(message = "To be removed in 3.3.0.RELEASE, replaced by module reactor-kotlin-extensions", replaceWith = @ReplaceWith(imports = {"reactor.kotlin.extra.math.min"}, expression = "min()"))
/*     */   @NotNull
/*     */   public static final <T extends Comparable<? super T>> Mono<T> min(@NotNull Flux $this$min) {
/*  77 */     Intrinsics.checkParameterIsNotNull($this$min, "$this$min"); Intrinsics.checkExpressionValueIsNotNull(MathFlux.min((Publisher<Comparable>)$this$min), "MathFlux.min(this)"); return (Mono)MathFlux.min((Publisher<Comparable>)$this$min);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(message = "To be removed in 3.3.0.RELEASE, replaced by module reactor-kotlin-extensions", replaceWith = @ReplaceWith(imports = {"reactor.kotlin.extra.math.max"}, expression = "max()"))
/*     */   @NotNull
/*     */   public static final <T extends Comparable<? super T>> Mono<T> max(@NotNull Flux $this$max) {
/*  88 */     Intrinsics.checkParameterIsNotNull($this$max, "$this$max"); Intrinsics.checkExpressionValueIsNotNull(MathFlux.max((Publisher<Comparable>)$this$max), "MathFlux.max(this)"); return (Mono)MathFlux.max((Publisher<Comparable>)$this$max);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(message = "To be removed in 3.3.0.RELEASE, replaced by module reactor-kotlin-extensions", replaceWith = @ReplaceWith(imports = {"reactor.kotlin.extra.math.sum"}, expression = "sum(mapper)"))
/*     */   @NotNull
/*     */   public static final <T> Mono<Long> sum(@NotNull Flux $this$sum, @NotNull Function1 mapper) {
/* 105 */     Intrinsics.checkParameterIsNotNull($this$sum, "$this$sum"); Intrinsics.checkParameterIsNotNull(mapper, "mapper"); Function1 function1 = mapper; Intrinsics.checkExpressionValueIsNotNull(MathFlux.sumLong((Publisher)$this$sum, new MathFluxExtensionsKt$sam$java_util_function_Function$0(function1)), "MathFlux.sumLong(this, Function(mapper))"); return MathFlux.sumLong((Publisher)$this$sum, new MathFluxExtensionsKt$sam$java_util_function_Function$0(function1));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(message = "To be removed in 3.3.0.RELEASE, replaced by module reactor-kotlin-extensions", replaceWith = @ReplaceWith(imports = {"reactor.kotlin.extra.math.sumDouble"}, expression = "sumDouble(mapper)"))
/*     */   @NotNull
/*     */   public static final <T> Mono<Double> sumDouble(@NotNull Flux $this$sumDouble, @NotNull Function1 mapper) {
/* 124 */     Intrinsics.checkParameterIsNotNull($this$sumDouble, "$this$sumDouble"); Intrinsics.checkParameterIsNotNull(mapper, "mapper"); Function1 function1 = mapper; Intrinsics.checkExpressionValueIsNotNull(MathFlux.sumDouble((Publisher)$this$sumDouble, new MathFluxExtensionsKt$sam$java_util_function_Function$0(function1)), "MathFlux.sumDouble(this, Function(mapper))"); return MathFlux.sumDouble((Publisher)$this$sumDouble, new MathFluxExtensionsKt$sam$java_util_function_Function$0(function1));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(message = "To be removed in 3.3.0.RELEASE, replaced by module reactor-kotlin-extensions", replaceWith = @ReplaceWith(imports = {"reactor.kotlin.extra.math.average"}, expression = "average(mapper)"))
/*     */   @NotNull
/*     */   public static final <T> Mono<Double> average(@NotNull Flux $this$average, @NotNull Function1 mapper) {
/* 140 */     Intrinsics.checkParameterIsNotNull($this$average, "$this$average"); Intrinsics.checkParameterIsNotNull(mapper, "mapper"); Function1 function1 = mapper; Intrinsics.checkExpressionValueIsNotNull(MathFlux.averageDouble((Publisher)$this$average, new MathFluxExtensionsKt$sam$java_util_function_Function$0(function1)), "MathFlux.averageDouble(this, Function(mapper))"); return MathFlux.averageDouble((Publisher)$this$average, new MathFluxExtensionsKt$sam$java_util_function_Function$0(function1));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(message = "To be removed in 3.3.0.RELEASE, replaced by module reactor-kotlin-extensions", replaceWith = @ReplaceWith(imports = {"reactor.kotlin.extra.math.min"}, expression = "min(comp)"))
/*     */   @NotNull
/*     */   public static final <T> Mono<T> min(@NotNull Flux $this$min, @NotNull Comparator<?> comp) {
/* 154 */     Intrinsics.checkParameterIsNotNull($this$min, "$this$min"); Intrinsics.checkParameterIsNotNull(comp, "comp"); Intrinsics.checkExpressionValueIsNotNull(MathFlux.min((Publisher)$this$min, comp), "MathFlux.min(this, comp)"); return (Mono)MathFlux.min((Publisher)$this$min, comp);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(message = "To be removed in 3.3.0.RELEASE, replaced by module reactor-kotlin-extensions", replaceWith = @ReplaceWith(imports = {"reactor.kotlin.extra.math.min"}, expression = "min(comp)"))
/*     */   @NotNull
/*     */   public static final <T> Mono<T> min(@NotNull Flux $this$min, @NotNull Function2 comp) {
/* 167 */     Intrinsics.checkParameterIsNotNull($this$min, "$this$min"); Intrinsics.checkParameterIsNotNull(comp, "comp"); Function2 function2 = comp; Intrinsics.checkExpressionValueIsNotNull(MathFlux.min((Publisher)$this$min, new MathFluxExtensionsKt$sam$java_util_Comparator$0(function2)), "MathFlux.min(this, Comparator(comp))"); return (Mono)MathFlux.min((Publisher)$this$min, new MathFluxExtensionsKt$sam$java_util_Comparator$0(function2));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(message = "To be removed in 3.3.0.RELEASE, replaced by module reactor-kotlin-extensions", replaceWith = @ReplaceWith(imports = {"reactor.kotlin.extra.math.max"}, expression = "max(comp)"))
/*     */   @NotNull
/*     */   public static final <T> Mono<T> max(@NotNull Flux $this$max, @NotNull Comparator<?> comp) {
/* 179 */     Intrinsics.checkParameterIsNotNull($this$max, "$this$max"); Intrinsics.checkParameterIsNotNull(comp, "comp"); Intrinsics.checkExpressionValueIsNotNull(MathFlux.max((Publisher)$this$max, comp), "MathFlux.max(this, comp)"); return (Mono)MathFlux.max((Publisher)$this$max, comp);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(message = "To be removed in 3.3.0.RELEASE, replaced by module reactor-kotlin-extensions", replaceWith = @ReplaceWith(imports = {"reactor.kotlin.extra.math.max"}, expression = "max(comp)"))
/*     */   @NotNull
/*     */   public static final <T> Mono<T> max(@NotNull Flux $this$max, @NotNull Function2 comp) {
/* 192 */     Intrinsics.checkParameterIsNotNull($this$max, "$this$max"); Intrinsics.checkParameterIsNotNull(comp, "comp"); Function2 function2 = comp; Intrinsics.checkExpressionValueIsNotNull(MathFlux.max((Publisher)$this$max, new MathFluxExtensionsKt$sam$java_util_Comparator$0(function2)), "MathFlux.max(this, Comparator(comp))"); return (Mono)MathFlux.max((Publisher)$this$max, new MathFluxExtensionsKt$sam$java_util_Comparator$0(function2));
/*     */   }
/*     */   
/*     */   @Metadata(mv = {1, 1, 18}, bv = {1, 0, 3}, k = 3)
/*     */   final class MathFluxExtensionsKt$sam$java_util_function_Function$0 implements Function {
/*     */     MathFluxExtensionsKt$sam$java_util_function_Function$0(MathFluxExtensionsKt this$0) {
/*     */       this.function = (Function1)this$0;
/*     */     }
/*     */   }
/*     */   
/*     */   @Metadata(mv = {1, 1, 18}, bv = {1, 0, 3}, k = 3)
/*     */   final class MathFluxExtensionsKt$sam$java_util_Comparator$0 implements Comparator {
/*     */     MathFluxExtensionsKt$sam$java_util_Comparator$0(MathFluxExtensionsKt this$0) {
/*     */       this.function = (Function2)this$0;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-extra-3.4.10.jar!\reactor\math\MathFluxExtensionsKt.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */