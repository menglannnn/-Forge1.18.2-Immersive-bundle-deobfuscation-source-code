/*    */ package reactor.math;
/*    */ 
/*    */ import java.util.function.Function;
/*    */ import org.reactivestreams.Publisher;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Fuseable;
/*    */ import reactor.core.publisher.Flux;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MonoSumFloat<T>
/*    */   extends MonoFromFluxOperator<T, Float>
/*    */   implements Fuseable
/*    */ {
/*    */   final Function<? super T, ? extends Number> mapping;
/*    */   
/*    */   MonoSumFloat(Publisher<? extends T> source, Function<? super T, ? extends Number> mapping) {
/* 36 */     super(Flux.from(source));
/* 37 */     this.mapping = mapping;
/*    */   }
/*    */ 
/*    */   
/*    */   public void subscribe(CoreSubscriber<? super Float> s) {
/* 42 */     this.source.subscribe((CoreSubscriber)new SumLongSubscriber<>(s, this.mapping));
/*    */   }
/*    */ 
/*    */   
/*    */   static final class SumLongSubscriber<T>
/*    */     extends MathSubscriber<T, Float>
/*    */   {
/*    */     final Function<? super T, ? extends Number> mapping;
/*    */     float sum;
/*    */     boolean hasValue;
/*    */     
/*    */     SumLongSubscriber(CoreSubscriber<? super Float> actual, Function<? super T, ? extends Number> mapping) {
/* 54 */       super(actual);
/* 55 */       this.mapping = mapping;
/*    */     }
/*    */ 
/*    */     
/*    */     protected void updateResult(T newValue) {
/* 60 */       float floatValue = ((Number)this.mapping.apply(newValue)).floatValue();
/* 61 */       this.sum = this.hasValue ? (this.sum + floatValue) : floatValue;
/* 62 */       this.hasValue = true;
/*    */     }
/*    */ 
/*    */     
/*    */     protected Float result() {
/* 67 */       return this.hasValue ? Float.valueOf(this.sum) : null;
/*    */     }
/*    */ 
/*    */     
/*    */     protected void reset() {
/* 72 */       this.sum = 0.0F;
/* 73 */       this.hasValue = false;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-extra-3.4.10.jar!\reactor\math\MonoSumFloat.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */