/*    */ package reactor.math;
/*    */ 
/*    */ import java.math.BigDecimal;
/*    */ import java.util.function.Function;
/*    */ import javax.annotation.Nullable;
/*    */ import org.reactivestreams.Publisher;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Fuseable;
/*    */ import reactor.core.Scannable;
/*    */ import reactor.core.publisher.Flux;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MonoAverageBigDecimal<T>
/*    */   extends MonoFromFluxOperator<T, BigDecimal>
/*    */   implements Fuseable
/*    */ {
/*    */   private final Function<? super T, ? extends Number> mapping;
/*    */   
/*    */   MonoAverageBigDecimal(Publisher<T> source, Function<? super T, ? extends Number> mapping) {
/* 40 */     super(Flux.from(source));
/* 41 */     this.mapping = mapping;
/*    */   }
/*    */ 
/*    */   
/*    */   public void subscribe(CoreSubscriber<? super BigDecimal> actual) {
/* 46 */     this.source.subscribe((CoreSubscriber)new AverageBigDecimalSubscriber<>(actual, this.mapping));
/*    */   }
/*    */ 
/*    */   
/*    */   private static final class AverageBigDecimalSubscriber<T>
/*    */     extends MathSubscriber<T, BigDecimal>
/*    */   {
/*    */     private final Function<? super T, ? extends Number> mapping;
/*    */     
/*    */     private int count;
/* 56 */     private BigDecimal sum = BigDecimal.ZERO;
/*    */ 
/*    */     
/*    */     AverageBigDecimalSubscriber(CoreSubscriber<? super BigDecimal> actual, Function<? super T, ? extends Number> mapping) {
/* 60 */       super(actual);
/* 61 */       this.mapping = mapping;
/*    */     }
/*    */ 
/*    */     
/*    */     protected void reset() {
/* 66 */       this.count = 0;
/* 67 */       this.sum = BigDecimal.ZERO;
/*    */     }
/*    */ 
/*    */     
/*    */     protected BigDecimal result() {
/* 72 */       return (this.count == 0) ? null : this.sum.divide(BigDecimal.valueOf(this.count));
/*    */     }
/*    */ 
/*    */     
/*    */     protected void updateResult(T newValue) {
/* 77 */       Number number = this.mapping.apply(newValue);
/*    */       
/* 79 */       BigDecimal bigDecimalValue = (number instanceof BigDecimal) ? (BigDecimal)number : new BigDecimal(number.toString());
/* 80 */       this.sum = this.sum.add(bigDecimalValue);
/* 81 */       this.count++;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-extra-3.4.10.jar!\reactor\math\MonoAverageBigDecimal.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */