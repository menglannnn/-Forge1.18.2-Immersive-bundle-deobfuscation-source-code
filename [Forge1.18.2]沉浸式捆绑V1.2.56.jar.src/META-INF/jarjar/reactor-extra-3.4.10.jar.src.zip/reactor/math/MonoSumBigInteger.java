/*    */ package reactor.math;
/*    */ 
/*    */ import java.math.BigDecimal;
/*    */ import java.math.BigInteger;
/*    */ import java.util.function.Function;
/*    */ import org.reactivestreams.Publisher;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Fuseable;
/*    */ import reactor.core.publisher.Flux;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MonoSumBigInteger<T>
/*    */   extends MonoFromFluxOperator<T, BigInteger>
/*    */   implements Fuseable
/*    */ {
/*    */   private final Function<? super T, ? extends Number> mapping;
/*    */   
/*    */   MonoSumBigInteger(Publisher<? extends T> source, Function<? super T, ? extends Number> mapping) {
/* 40 */     super(Flux.from(source));
/* 41 */     this.mapping = mapping;
/*    */   }
/*    */ 
/*    */   
/*    */   public void subscribe(CoreSubscriber<? super BigInteger> actual) {
/* 46 */     this.source.subscribe((CoreSubscriber)new SumBigIntegerSubscriber<>(actual, this.mapping));
/*    */   }
/*    */ 
/*    */   
/*    */   private static final class SumBigIntegerSubscriber<T>
/*    */     extends MathSubscriber<T, BigInteger>
/*    */   {
/*    */     private final Function<? super T, ? extends Number> mapping;
/*    */     
/*    */     BigDecimal sum;
/*    */     
/*    */     boolean hasValue;
/*    */     
/*    */     SumBigIntegerSubscriber(CoreSubscriber<? super BigInteger> actual, Function<? super T, ? extends Number> mapping) {
/* 60 */       super(actual);
/* 61 */       this.mapping = mapping;
/*    */     }
/*    */ 
/*    */     
/*    */     protected void reset() {
/* 66 */       this.sum = BigDecimal.ZERO;
/* 67 */       this.hasValue = false;
/*    */     }
/*    */ 
/*    */     
/*    */     protected BigInteger result() {
/* 72 */       return this.hasValue ? this.sum.toBigInteger() : null;
/*    */     }
/*    */     
/*    */     protected void updateResult(T newValue) {
/*    */       BigDecimal bigDecimalValue;
/* 77 */       Number number = this.mapping.apply(newValue);
/*    */       
/* 79 */       if (number instanceof BigDecimal) {
/* 80 */         bigDecimalValue = (BigDecimal)number;
/*    */       }
/* 82 */       else if (number instanceof BigInteger) {
/* 83 */         bigDecimalValue = new BigDecimal((BigInteger)number);
/*    */       } else {
/*    */         
/* 86 */         bigDecimalValue = new BigDecimal(number.toString());
/*    */       } 
/* 88 */       this.sum = this.hasValue ? this.sum.add(bigDecimalValue) : bigDecimalValue;
/* 89 */       this.hasValue = true;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-extra-3.4.10.jar!\reactor\math\MonoSumBigInteger.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */