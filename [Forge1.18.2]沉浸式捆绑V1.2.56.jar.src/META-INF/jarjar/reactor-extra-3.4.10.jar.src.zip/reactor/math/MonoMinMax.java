/*    */ package reactor.math;
/*    */ 
/*    */ import java.util.Comparator;
/*    */ import org.reactivestreams.Publisher;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Fuseable;
/*    */ import reactor.core.publisher.Flux;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MonoMinMax<T>
/*    */   extends MonoFromFluxOperator<T, T>
/*    */   implements Fuseable
/*    */ {
/*    */   final Comparator<? super T> comparator;
/*    */   final int comparisonMultiplier;
/*    */   
/*    */   MonoMinMax(Publisher<? extends T> source, Comparator<? super T> comparator, int comparisonMultiplier) {
/* 38 */     super(Flux.from(source));
/* 39 */     this.comparator = comparator;
/* 40 */     this.comparisonMultiplier = comparisonMultiplier;
/*    */   }
/*    */ 
/*    */   
/*    */   public void subscribe(CoreSubscriber<? super T> s) {
/* 45 */     this.source.subscribe((CoreSubscriber)new MinMaxSubscriber<>(s, this.comparator, this.comparisonMultiplier));
/*    */   }
/*    */ 
/*    */   
/*    */   static final class MinMaxSubscriber<T>
/*    */     extends MathSubscriber<T, T>
/*    */   {
/*    */     final Comparator<? super T> comparator;
/*    */     final int comparisonMultiplier;
/*    */     T result;
/*    */     
/*    */     MinMaxSubscriber(CoreSubscriber<? super T> actual, Comparator<? super T> comparator, int comparisonMultiplier) {
/* 57 */       super(actual);
/* 58 */       this.comparator = comparator;
/* 59 */       this.comparisonMultiplier = comparisonMultiplier;
/*    */     }
/*    */ 
/*    */     
/*    */     protected void updateResult(T newValue) {
/* 64 */       T r = this.result;
/* 65 */       if (r == null || this.comparator.compare(newValue, this.result) * this.comparisonMultiplier > 0) {
/* 66 */         r = newValue;
/*    */       }
/* 68 */       this.result = r;
/*    */     }
/*    */ 
/*    */     
/*    */     protected T result() {
/* 73 */       return this.result;
/*    */     }
/*    */ 
/*    */     
/*    */     protected void reset() {
/* 78 */       this.result = null;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-extra-3.4.10.jar!\reactor\math\MonoMinMax.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */