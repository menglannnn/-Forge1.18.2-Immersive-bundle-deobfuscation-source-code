/*    */ package reactor.math;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import javax.annotation.Nullable;
/*    */ import reactor.core.Scannable;
/*    */ import reactor.core.publisher.Flux;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class MonoFromFluxOperator<I, O>
/*    */   extends Mono<O>
/*    */   implements Scannable
/*    */ {
/*    */   protected final Flux<? extends I> source;
/*    */   
/*    */   protected MonoFromFluxOperator(Flux<? extends I> source) {
/* 44 */     this.source = Objects.<Flux<? extends I>>requireNonNull(source);
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 50 */     if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(2147483647); 
/* 51 */     if (key == Scannable.Attr.PARENT) return this.source; 
/* 52 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-extra-3.4.10.jar!\reactor\math\MonoFromFluxOperator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */