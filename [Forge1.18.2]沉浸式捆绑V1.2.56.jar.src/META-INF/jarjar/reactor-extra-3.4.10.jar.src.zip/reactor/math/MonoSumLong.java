/*    */ package reactor.math;
/*    */ 
/*    */ import java.util.function.Function;
/*    */ import org.reactivestreams.Publisher;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Fuseable;
/*    */ import reactor.core.publisher.Flux;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MonoSumLong<T>
/*    */   extends MonoFromFluxOperator<T, Long>
/*    */   implements Fuseable
/*    */ {
/*    */   final Function<? super T, ? extends Number> mapping;
/*    */   
/*    */   MonoSumLong(Publisher<? extends T> source, Function<? super T, ? extends Number> mapping) {
/* 36 */     super(Flux.from(source));
/* 37 */     this.mapping = mapping;
/*    */   }
/*    */ 
/*    */   
/*    */   public void subscribe(CoreSubscriber<? super Long> s) {
/* 42 */     this.source.subscribe((CoreSubscriber)new SumLongSubscriber<>(s, this.mapping));
/*    */   }
/*    */ 
/*    */   
/*    */   static final class SumLongSubscriber<T>
/*    */     extends MathSubscriber<T, Long>
/*    */   {
/*    */     final Function<? super T, ? extends Number> mapping;
/*    */     long sum;
/*    */     boolean hasValue;
/*    */     
/*    */     SumLongSubscriber(CoreSubscriber<? super Long> actual, Function<? super T, ? extends Number> mapping) {
/* 54 */       super(actual);
/* 55 */       this.mapping = mapping;
/*    */     }
/*    */ 
/*    */     
/*    */     protected void updateResult(T newValue) {
/* 60 */       long longValue = ((Number)this.mapping.apply(newValue)).longValue();
/* 61 */       if (this.hasValue) {
/* 62 */         boolean sumPositive = (this.sum >= 0L);
/* 63 */         this.sum += longValue;
/*    */         
/* 65 */         if (sumPositive && longValue >= 0L && this.sum < 0L) {
/* 66 */           this.sum = Long.MAX_VALUE;
/*    */         
/*    */         }
/* 69 */         else if (!sumPositive && longValue < 0L && this.sum > 0L) {
/* 70 */           this.sum = Long.MIN_VALUE;
/*    */         } 
/*    */       } else {
/*    */         
/* 74 */         this.sum = longValue;
/* 75 */         this.hasValue = true;
/*    */       } 
/*    */     }
/*    */ 
/*    */     
/*    */     protected Long result() {
/* 81 */       return this.hasValue ? Long.valueOf(this.sum) : null;
/*    */     }
/*    */ 
/*    */     
/*    */     protected void reset() {
/* 86 */       this.sum = 0L;
/* 87 */       this.hasValue = false;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-extra-3.4.10.jar!\reactor\math\MonoSumLong.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */