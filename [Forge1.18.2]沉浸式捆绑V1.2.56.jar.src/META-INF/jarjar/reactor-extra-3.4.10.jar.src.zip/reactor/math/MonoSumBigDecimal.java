/*    */ package reactor.math;
/*    */ 
/*    */ import java.math.BigDecimal;
/*    */ import java.util.function.Function;
/*    */ import javax.annotation.Nullable;
/*    */ import org.reactivestreams.Publisher;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Fuseable;
/*    */ import reactor.core.Scannable;
/*    */ import reactor.core.publisher.Flux;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MonoSumBigDecimal<T>
/*    */   extends MonoFromFluxOperator<T, BigDecimal>
/*    */   implements Fuseable
/*    */ {
/*    */   private final Function<? super T, ? extends Number> mapping;
/*    */   
/*    */   MonoSumBigDecimal(Publisher<T> source, Function<? super T, ? extends Number> mapping) {
/* 39 */     super(Flux.from(source));
/* 40 */     this.mapping = mapping;
/*    */   }
/*    */ 
/*    */   
/*    */   public void subscribe(CoreSubscriber<? super BigDecimal> actual) {
/* 45 */     this.source.subscribe((CoreSubscriber)new SumBigDecimalSubscriber<>(actual, this.mapping));
/*    */   }
/*    */ 
/*    */   
/*    */   private static final class SumBigDecimalSubscriber<T>
/*    */     extends MathSubscriber<T, BigDecimal>
/*    */   {
/*    */     private final Function<? super T, ? extends Number> mapping;
/*    */     
/*    */     BigDecimal sum;
/*    */     
/*    */     boolean hasValue;
/*    */     
/*    */     SumBigDecimalSubscriber(CoreSubscriber<? super BigDecimal> actual, Function<? super T, ? extends Number> mapping) {
/* 59 */       super(actual);
/* 60 */       this.mapping = mapping;
/*    */     }
/*    */ 
/*    */     
/*    */     protected void reset() {
/* 65 */       this.sum = BigDecimal.ZERO;
/* 66 */       this.hasValue = false;
/*    */     }
/*    */ 
/*    */     
/*    */     protected BigDecimal result() {
/* 71 */       return this.hasValue ? this.sum : null;
/*    */     }
/*    */ 
/*    */     
/*    */     protected void updateResult(T newValue) {
/* 76 */       Number number = this.mapping.apply(newValue);
/*    */       
/* 78 */       BigDecimal bigDecimalValue = (number instanceof BigDecimal) ? (BigDecimal)number : new BigDecimal(number.toString());
/* 79 */       this.sum = this.hasValue ? this.sum.add(bigDecimalValue) : bigDecimalValue;
/* 80 */       this.hasValue = true;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-extra-3.4.10.jar!\reactor\math\MonoSumBigDecimal.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */