/*    */ package reactor.math;
/*    */ 
/*    */ import java.util.function.Function;
/*    */ import org.reactivestreams.Publisher;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Fuseable;
/*    */ import reactor.core.publisher.Flux;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MonoSumInt<T>
/*    */   extends MonoFromFluxOperator<T, Integer>
/*    */   implements Fuseable
/*    */ {
/*    */   final Function<? super T, ? extends Number> mapping;
/*    */   
/*    */   MonoSumInt(Publisher<? extends T> source, Function<? super T, ? extends Number> mapping) {
/* 36 */     super(Flux.from(source));
/* 37 */     this.mapping = mapping;
/*    */   }
/*    */ 
/*    */   
/*    */   public void subscribe(CoreSubscriber<? super Integer> s) {
/* 42 */     this.source.subscribe((CoreSubscriber)new SumIntSubscriber<>(s, this.mapping));
/*    */   }
/*    */ 
/*    */   
/*    */   static final class SumIntSubscriber<T>
/*    */     extends MathSubscriber<T, Integer>
/*    */   {
/*    */     final Function<? super T, ? extends Number> mapping;
/*    */     int sum;
/*    */     boolean hasValue;
/*    */     
/*    */     SumIntSubscriber(CoreSubscriber<? super Integer> actual, Function<? super T, ? extends Number> mapping) {
/* 54 */       super(actual);
/* 55 */       this.mapping = mapping;
/*    */     }
/*    */ 
/*    */     
/*    */     protected void updateResult(T newValue) {
/* 60 */       int intValue = ((Number)this.mapping.apply(newValue)).intValue();
/* 61 */       if (this.hasValue) {
/* 62 */         boolean sumPositive = (this.sum >= 0);
/* 63 */         this.sum += intValue;
/*    */         
/* 65 */         if (sumPositive && intValue >= 0 && this.sum < 0) {
/* 66 */           this.sum = Integer.MAX_VALUE;
/*    */         
/*    */         }
/* 69 */         else if (!sumPositive && intValue < 0 && this.sum > 0) {
/* 70 */           this.sum = Integer.MIN_VALUE;
/*    */         } 
/*    */       } else {
/*    */         
/* 74 */         this.sum = intValue;
/* 75 */         this.hasValue = true;
/*    */       } 
/*    */     }
/*    */ 
/*    */     
/*    */     protected Integer result() {
/* 81 */       return this.hasValue ? Integer.valueOf(this.sum) : null;
/*    */     }
/*    */ 
/*    */     
/*    */     protected void reset() {
/* 86 */       this.sum = 0;
/* 87 */       this.hasValue = false;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-extra-3.4.10.jar!\reactor\math\MonoSumInt.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */