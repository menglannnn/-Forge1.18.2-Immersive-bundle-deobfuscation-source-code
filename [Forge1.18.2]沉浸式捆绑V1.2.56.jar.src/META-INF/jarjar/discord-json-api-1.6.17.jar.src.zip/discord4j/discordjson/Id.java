/*    */ package discord4j.discordjson;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonCreator;
/*    */ import com.fasterxml.jackson.annotation.JsonValue;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Id
/*    */ {
/*    */   private final long value;
/*    */   
/*    */   public static Id of(long value) {
/* 21 */     return new Id(value);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Id of(String value) {
/* 32 */     return new Id(value);
/*    */   }
/*    */   
/*    */   @JsonCreator
/*    */   private Id(String value) {
/* 37 */     this.value = Long.parseUnsignedLong(value);
/*    */   }
/*    */   
/*    */   @JsonCreator
/*    */   private Id(long value) {
/* 42 */     this.value = value;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @JsonValue
/*    */   public String asString() {
/* 52 */     return Long.toUnsignedString(this.value);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public long asLong() {
/* 61 */     return this.value;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 66 */     if (this == o) {
/* 67 */       return true;
/*    */     }
/* 69 */     if (o == null || getClass() != o.getClass()) {
/* 70 */       return false;
/*    */     }
/* 72 */     Id id = (Id)o;
/* 73 */     return (this.value == id.value);
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 78 */     return Long.hashCode(this.value);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 83 */     return asString();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-api-1.6.17.jar!\discord4j\discordjson\Id.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */