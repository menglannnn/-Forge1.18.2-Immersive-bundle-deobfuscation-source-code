/*    */ package discord4j.discordjson.possible;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.BeanProperty;
/*    */ import com.fasterxml.jackson.databind.JsonSerializer;
/*    */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*    */ import com.fasterxml.jackson.databind.ser.std.ReferenceTypeSerializer;
/*    */ import com.fasterxml.jackson.databind.type.ReferenceType;
/*    */ import com.fasterxml.jackson.databind.util.NameTransformer;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ public class PossibleSerializer
/*    */   extends ReferenceTypeSerializer<Possible<?>> {
/*    */   public PossibleSerializer(ReferenceType fullType, boolean staticTyping, TypeSerializer vts, JsonSerializer<Object> ser) {
/* 14 */     super(fullType, staticTyping, vts, ser);
/*    */   }
/*    */   
/*    */   public PossibleSerializer(ReferenceTypeSerializer<?> base, BeanProperty property, TypeSerializer vts, JsonSerializer<?> valueSer, NameTransformer unwrapper, Object suppressableValue, boolean suppressNulls) {
/* 18 */     super(base, property, vts, valueSer, unwrapper, suppressableValue, suppressNulls);
/*    */   }
/*    */ 
/*    */   
/*    */   protected PossibleSerializer withResolved(BeanProperty prop, TypeSerializer vts, JsonSerializer<?> valueSer, NameTransformer unwrapper) {
/* 23 */     return new PossibleSerializer(this, prop, vts, valueSer, unwrapper, this._suppressableValue, this._suppressNulls);
/*    */   }
/*    */ 
/*    */   
/*    */   public PossibleSerializer withContentInclusion(Object suppressableValue, boolean suppressNulls) {
/* 28 */     return new PossibleSerializer(this, this._property, this._valueTypeSerializer, this._valueSerializer, this._unwrapper, suppressableValue, suppressNulls);
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean _isValuePresent(Possible<?> value) {
/* 33 */     return !value.isAbsent();
/*    */   }
/*    */ 
/*    */   
/*    */   protected Object _getReferenced(Possible<?> value) {
/* 38 */     return value.get();
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   protected Object _getReferencedIfPresent(Possible<?> value) {
/* 44 */     return value.isAbsent() ? null : value.get();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-api-1.6.17.jar!\discord4j\discordjson\possible\PossibleSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */