/*    */ package discord4j.discordjson.possible;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.JavaType;
/*    */ import com.fasterxml.jackson.databind.type.ReferenceType;
/*    */ import com.fasterxml.jackson.databind.type.TypeBindings;
/*    */ import com.fasterxml.jackson.databind.type.TypeFactory;
/*    */ import com.fasterxml.jackson.databind.type.TypeModifier;
/*    */ import java.lang.reflect.Type;
/*    */ 
/*    */ 
/*    */ public class PossibleTypeModifier
/*    */   extends TypeModifier
/*    */ {
/*    */   public JavaType modifyType(JavaType type, Type jdkType, TypeBindings context, TypeFactory typeFactory) {
/* 15 */     if (type.isReferenceType() || type.isContainerType()) {
/* 16 */       return type;
/*    */     }
/*    */     
/* 19 */     if (type.isTypeOrSubTypeOf(Possible.class)) {
/* 20 */       return (JavaType)ReferenceType.upgradeFrom(type, type.containedTypeOrUnknown(0));
/*    */     }
/*    */     
/* 23 */     return type;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-api-1.6.17.jar!\discord4j\discordjson\possible\PossibleTypeModifier.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */