/*    */ package discord4j.discordjson.possible;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.BeanDescription;
/*    */ import com.fasterxml.jackson.databind.JsonSerializer;
/*    */ import com.fasterxml.jackson.databind.MapperFeature;
/*    */ import com.fasterxml.jackson.databind.SerializationConfig;
/*    */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*    */ import com.fasterxml.jackson.databind.ser.Serializers;
/*    */ import com.fasterxml.jackson.databind.type.ReferenceType;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ public class PossibleSerializers
/*    */   extends Serializers.Base
/*    */ {
/*    */   @Nullable
/*    */   public JsonSerializer<?> findReferenceSerializer(SerializationConfig config, ReferenceType type, BeanDescription beanDesc, TypeSerializer contentTypeSerializer, JsonSerializer<Object> contentValueSerializer) {
/* 17 */     boolean staticTyping = config.isEnabled(MapperFeature.USE_STATIC_TYPING);
/*    */     
/* 19 */     if (type.isTypeOrSubTypeOf(Possible.class)) {
/* 20 */       return (JsonSerializer<?>)new PossibleSerializer(type, staticTyping, contentTypeSerializer, contentValueSerializer);
/*    */     }
/* 22 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-api-1.6.17.jar!\discord4j\discordjson\possible\PossibleSerializers.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */