/*    */ package discord4j.discordjson.possible;
/*    */ 
/*    */ import com.fasterxml.jackson.core.Version;
/*    */ import com.fasterxml.jackson.databind.Module;
/*    */ import com.fasterxml.jackson.databind.deser.Deserializers;
/*    */ import com.fasterxml.jackson.databind.ser.Serializers;
/*    */ 
/*    */ public class PossibleModule extends Module {
/*    */   public String getModuleName() {
/* 10 */     return "PossibleModule";
/*    */   }
/*    */ 
/*    */   
/*    */   public Version version() {
/* 15 */     return new Version(2, 0, 0, null, null, null);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setupModule(Module.SetupContext context) {
/* 20 */     context.addSerializers((Serializers)new PossibleSerializers());
/* 21 */     context.addDeserializers((Deserializers)new PossibleDeserializers());
/* 22 */     context.addTypeModifier(new PossibleTypeModifier());
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-api-1.6.17.jar!\discord4j\discordjson\possible\PossibleModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */