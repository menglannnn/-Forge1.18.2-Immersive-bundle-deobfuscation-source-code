/*     */ package discord4j.discordjson.possible;
/*     */ 
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.function.Function;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Possible<T>
/*     */ {
/*  56 */   private static final Object ABSENT_VALUE = new Object();
/*  57 */   private static final Possible<?> ABSENT = new Possible((T)ABSENT_VALUE);
/*     */ 
/*     */ 
/*     */   
/*     */   private final T value;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Possible<T> of(T value) {
/*  67 */     return new Possible<>(Objects.requireNonNull(value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Possible<T> absent() {
/*  78 */     return (Possible)ABSENT;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Optional<T> flatOpt(Possible<Optional<T>> possible) {
/*  90 */     return possible.toOptional().flatMap(Function.identity());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Possible(T value) {
/*  96 */     this.value = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAbsent() {
/* 105 */     return (this.value == ABSENT_VALUE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T get() {
/* 114 */     if (isAbsent()) {
/* 115 */       throw new NoSuchElementException();
/*     */     }
/* 117 */     return this.value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<T> toOptional() {
/* 127 */     if (isAbsent()) {
/* 128 */       return Optional.empty();
/*     */     }
/* 130 */     return Optional.of(this.value);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object o) {
/* 135 */     if (this == o) {
/* 136 */       return true;
/*     */     }
/* 138 */     if (o == null || getClass() != o.getClass()) {
/* 139 */       return false;
/*     */     }
/* 141 */     Possible<?> possible = (Possible)o;
/* 142 */     return Objects.equals(this.value, possible.value);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 147 */     return Objects.hash(new Object[] { this.value });
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 152 */     if (isAbsent()) {
/* 153 */       return "Possible.absent";
/*     */     }
/* 155 */     return "Possible{" + this.value + '}';
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-api-1.6.17.jar!\discord4j\discordjson\possible\Possible.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */