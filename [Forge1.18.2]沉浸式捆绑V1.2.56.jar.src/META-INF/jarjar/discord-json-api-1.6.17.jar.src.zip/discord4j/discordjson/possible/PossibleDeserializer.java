/*    */ package discord4j.discordjson.possible;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.DeserializationContext;
/*    */ import com.fasterxml.jackson.databind.JavaType;
/*    */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*    */ import com.fasterxml.jackson.databind.JsonMappingException;
/*    */ import com.fasterxml.jackson.databind.deser.ValueInstantiator;
/*    */ import com.fasterxml.jackson.databind.deser.std.ReferenceTypeDeserializer;
/*    */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*    */ import java.util.Optional;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ public class PossibleDeserializer
/*    */   extends ReferenceTypeDeserializer<Possible<?>> {
/*    */   public PossibleDeserializer(JavaType fullType, @Nullable ValueInstantiator vi, TypeDeserializer typeDeser, JsonDeserializer<?> deser) {
/* 16 */     super(fullType, vi, typeDeser, deser);
/*    */   }
/*    */ 
/*    */   
/*    */   protected PossibleDeserializer withResolved(TypeDeserializer typeDeser, JsonDeserializer<?> valueDeser) {
/* 21 */     return new PossibleDeserializer(this._fullType, this._valueInstantiator, typeDeser, valueDeser);
/*    */   }
/*    */ 
/*    */   
/*    */   public Possible<?> getNullValue(DeserializationContext ctxt) {
/* 26 */     return Possible.of(Optional.empty());
/*    */   }
/*    */ 
/*    */   
/*    */   public Possible<?> referenceValue(Object contents) {
/* 31 */     return Possible.of(contents);
/*    */   }
/*    */ 
/*    */   
/*    */   public Possible<?> updateReference(Possible<?> reference, Object contents) {
/* 36 */     return Possible.of(contents);
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public Object getReferenced(Possible<?> reference) {
/* 42 */     return reference.toOptional().orElse(null);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-api-1.6.17.jar!\discord4j\discordjson\possible\PossibleDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */