/*    */ package discord4j.discordjson.possible;
/*    */ 
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ public class PossibleFilter
/*    */ {
/*    */   public boolean equals(@Nullable Object obj) {
/*  9 */     if (obj == null)
/* 10 */       return false; 
/* 11 */     if (Possible.class.isAssignableFrom(obj.getClass())) {
/* 12 */       return ((Possible)obj).isAbsent();
/*    */     }
/*    */     
/* 15 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-api-1.6.17.jar!\discord4j\discordjson\possible\PossibleFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */