/*    */ package software.bernie.shadowed.eliotlash.mclib.math;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Ternary
/*    */   implements IValue
/*    */ {
/*    */   public IValue condition;
/*    */   public IValue ifTrue;
/*    */   public IValue ifFalse;
/*    */   
/*    */   public Ternary(IValue condition, IValue ifTrue, IValue ifFalse) {
/* 15 */     this.condition = condition;
/* 16 */     this.ifTrue = ifTrue;
/* 17 */     this.ifFalse = ifFalse;
/*    */   }
/*    */ 
/*    */   
/*    */   public double get() {
/* 22 */     return (this.condition.get() != 0.0D) ? this.ifTrue.get() : this.ifFalse.get();
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 27 */     return this.condition.toString() + " ? " + this.ifTrue.toString() + " : " + this.ifFalse.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\geckolib-388172-4181370.jar!\software\bernie\shadowed\eliotlash\mclib\math\Ternary.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */