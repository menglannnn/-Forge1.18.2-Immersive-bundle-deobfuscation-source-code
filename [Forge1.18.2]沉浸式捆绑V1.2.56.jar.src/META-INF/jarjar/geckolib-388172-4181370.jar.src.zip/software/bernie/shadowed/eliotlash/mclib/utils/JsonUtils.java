/*    */ package software.bernie.shadowed.eliotlash.mclib.utils;
/*    */ 
/*    */ import com.google.gson.Gson;
/*    */ import com.google.gson.GsonBuilder;
/*    */ import com.google.gson.JsonElement;
/*    */ import com.google.gson.stream.JsonWriter;
/*    */ import java.io.StringWriter;
/*    */ 
/*    */ public class JsonUtils
/*    */ {
/*    */   public static String jsonToPretty(JsonElement element) {
/* 12 */     StringWriter writer = new StringWriter();
/* 13 */     JsonWriter jsonWriter = new JsonWriter(writer);
/* 14 */     Gson gson = (new GsonBuilder()).setPrettyPrinting().create();
/*    */     
/* 16 */     jsonWriter.setIndent("    ");
/* 17 */     gson.toJson(element, jsonWriter);
/*    */ 
/*    */     
/* 20 */     return writer.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\geckolib-388172-4181370.jar!\software\bernie\shadowed\eliotlash\mcli\\utils\JsonUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */