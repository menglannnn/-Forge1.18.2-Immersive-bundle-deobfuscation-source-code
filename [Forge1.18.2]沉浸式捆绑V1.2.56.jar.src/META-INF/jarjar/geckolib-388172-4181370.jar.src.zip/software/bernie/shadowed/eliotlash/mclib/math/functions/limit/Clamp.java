/*    */ package software.bernie.shadowed.eliotlash.mclib.math.functions.limit;
/*    */ 
/*    */ import software.bernie.shadowed.eliotlash.mclib.math.IValue;
/*    */ import software.bernie.shadowed.eliotlash.mclib.math.functions.Function;
/*    */ import software.bernie.shadowed.eliotlash.mclib.utils.MathUtils;
/*    */ 
/*    */ public class Clamp extends Function {
/*    */   public Clamp(IValue[] values, String name) throws Exception {
/*  9 */     super(values, name);
/*    */   }
/*    */ 
/*    */   
/*    */   public int getRequiredArguments() {
/* 14 */     return 3;
/*    */   }
/*    */ 
/*    */   
/*    */   public double get() {
/* 19 */     return MathUtils.clamp(getArg(0), getArg(1), getArg(2));
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\geckolib-388172-4181370.jar!\software\bernie\shadowed\eliotlash\mclib\math\functions\limit\Clamp.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */