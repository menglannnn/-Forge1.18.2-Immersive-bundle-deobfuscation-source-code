/*    */ package software.bernie.shadowed.eliotlash.mclib.math;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Group
/*    */   implements IValue
/*    */ {
/*    */   private IValue value;
/*    */   
/*    */   public Group(IValue value) {
/* 13 */     this.value = value;
/*    */   }
/*    */ 
/*    */   
/*    */   public double get() {
/* 18 */     return this.value.get();
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 23 */     return "(" + this.value.toString() + ")";
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\geckolib-388172-4181370.jar!\software\bernie\shadowed\eliotlash\mclib\math\Group.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */