/*    */ package software.bernie.shadowed.eliotlash.mclib.math;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Negate
/*    */   implements IValue
/*    */ {
/*    */   public IValue value;
/*    */   
/*    */   public Negate(IValue value) {
/* 12 */     this.value = value;
/*    */   }
/*    */ 
/*    */   
/*    */   public double get() {
/* 17 */     return (this.value.get() == 0.0D) ? 1.0D : 0.0D;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 22 */     return "!" + this.value.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\geckolib-388172-4181370.jar!\software\bernie\shadowed\eliotlash\mclib\math\Negate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */