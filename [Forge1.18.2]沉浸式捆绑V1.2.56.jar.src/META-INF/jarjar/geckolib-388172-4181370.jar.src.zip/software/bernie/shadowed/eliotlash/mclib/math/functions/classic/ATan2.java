/*    */ package software.bernie.shadowed.eliotlash.mclib.math.functions.classic;
/*    */ 
/*    */ import software.bernie.shadowed.eliotlash.mclib.math.IValue;
/*    */ import software.bernie.shadowed.eliotlash.mclib.math.functions.Function;
/*    */ 
/*    */ 
/*    */ public class ATan2
/*    */   extends Function
/*    */ {
/*    */   public ATan2(IValue[] values, String name) throws Exception {
/* 11 */     super(values, name);
/*    */   }
/*    */ 
/*    */   
/*    */   public int getRequiredArguments() {
/* 16 */     return 2;
/*    */   }
/*    */ 
/*    */   
/*    */   public double get() {
/* 21 */     return Math.atan2(getArg(0), getArg(1));
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\geckolib-388172-4181370.jar!\software\bernie\shadowed\eliotlash\mclib\math\functions\classic\ATan2.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */