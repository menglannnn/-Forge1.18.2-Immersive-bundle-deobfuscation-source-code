/*     */ package software.bernie.shadowed.eliotlash.mclib.math;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import software.bernie.shadowed.eliotlash.mclib.math.functions.Function;
/*     */ import software.bernie.shadowed.eliotlash.mclib.math.functions.classic.ACos;
/*     */ import software.bernie.shadowed.eliotlash.mclib.math.functions.classic.ASin;
/*     */ import software.bernie.shadowed.eliotlash.mclib.math.functions.classic.ATan;
/*     */ import software.bernie.shadowed.eliotlash.mclib.math.functions.classic.ATan2;
/*     */ import software.bernie.shadowed.eliotlash.mclib.math.functions.classic.Abs;
/*     */ import software.bernie.shadowed.eliotlash.mclib.math.functions.classic.Cos;
/*     */ import software.bernie.shadowed.eliotlash.mclib.math.functions.classic.Exp;
/*     */ import software.bernie.shadowed.eliotlash.mclib.math.functions.classic.Ln;
/*     */ import software.bernie.shadowed.eliotlash.mclib.math.functions.classic.Mod;
/*     */ import software.bernie.shadowed.eliotlash.mclib.math.functions.classic.Pow;
/*     */ import software.bernie.shadowed.eliotlash.mclib.math.functions.classic.Sin;
/*     */ import software.bernie.shadowed.eliotlash.mclib.math.functions.classic.Sqrt;
/*     */ import software.bernie.shadowed.eliotlash.mclib.math.functions.limit.Clamp;
/*     */ import software.bernie.shadowed.eliotlash.mclib.math.functions.limit.Max;
/*     */ import software.bernie.shadowed.eliotlash.mclib.math.functions.limit.Min;
/*     */ import software.bernie.shadowed.eliotlash.mclib.math.functions.rounding.Ceil;
/*     */ import software.bernie.shadowed.eliotlash.mclib.math.functions.rounding.Floor;
/*     */ import software.bernie.shadowed.eliotlash.mclib.math.functions.rounding.Round;
/*     */ import software.bernie.shadowed.eliotlash.mclib.math.functions.rounding.Trunc;
/*     */ import software.bernie.shadowed.eliotlash.mclib.math.functions.utility.DieRoll;
/*     */ import software.bernie.shadowed.eliotlash.mclib.math.functions.utility.DieRollInteger;
/*     */ import software.bernie.shadowed.eliotlash.mclib.math.functions.utility.HermiteBlend;
/*     */ import software.bernie.shadowed.eliotlash.mclib.math.functions.utility.Lerp;
/*     */ import software.bernie.shadowed.eliotlash.mclib.math.functions.utility.LerpRotate;
/*     */ import software.bernie.shadowed.eliotlash.mclib.math.functions.utility.Random;
/*     */ import software.bernie.shadowed.eliotlash.mclib.math.functions.utility.RandomInteger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MathBuilder
/*     */ {
/*  54 */   public Map<String, Variable> variables = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  59 */   public Map<String, Class<? extends Function>> functions = new HashMap<>();
/*     */ 
/*     */   
/*     */   public MathBuilder() {
/*  63 */     register(new Variable("PI", Math.PI));
/*  64 */     register(new Variable("E", Math.E));
/*     */ 
/*     */     
/*  67 */     this.functions.put("floor", Floor.class);
/*  68 */     this.functions.put("round", Round.class);
/*  69 */     this.functions.put("ceil", Ceil.class);
/*  70 */     this.functions.put("trunc", Trunc.class);
/*     */ 
/*     */     
/*  73 */     this.functions.put("clamp", Clamp.class);
/*  74 */     this.functions.put("max", Max.class);
/*  75 */     this.functions.put("min", Min.class);
/*     */ 
/*     */     
/*  78 */     this.functions.put("abs", Abs.class);
/*  79 */     this.functions.put("acos", ACos.class);
/*  80 */     this.functions.put("asin", ASin.class);
/*  81 */     this.functions.put("atan", ATan.class);
/*  82 */     this.functions.put("atan2", ATan2.class);
/*  83 */     this.functions.put("cos", Cos.class);
/*  84 */     this.functions.put("sin", Sin.class);
/*  85 */     this.functions.put("exp", Exp.class);
/*  86 */     this.functions.put("ln", Ln.class);
/*  87 */     this.functions.put("sqrt", Sqrt.class);
/*  88 */     this.functions.put("mod", Mod.class);
/*  89 */     this.functions.put("pow", Pow.class);
/*     */ 
/*     */     
/*  92 */     this.functions.put("lerp", Lerp.class);
/*  93 */     this.functions.put("lerprotate", LerpRotate.class);
/*  94 */     this.functions.put("hermite_blend", HermiteBlend.class);
/*  95 */     this.functions.put("die_roll", DieRoll.class);
/*  96 */     this.functions.put("die_roll_integer", DieRollInteger.class);
/*  97 */     this.functions.put("random", Random.class);
/*  98 */     this.functions.put("random_integer", RandomInteger.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void register(Variable variable) {
/* 105 */     this.variables.put(variable.getName(), variable);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IValue parse(String expression) throws Exception {
/* 113 */     return parseSymbols(breakdownChars(breakdown(expression)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] breakdown(String expression) throws Exception {
/* 121 */     if (!expression.matches("^[\\w\\d\\s_+-/*%^&|<>=!?:.,()]+$")) {
/* 122 */       throw new Exception("Given expression '" + expression + "' contains illegal characters!");
/*     */     }
/*     */ 
/*     */     
/* 126 */     expression = expression.replaceAll("\\s+", "");
/*     */     
/* 128 */     String[] chars = expression.split("(?!^)");
/*     */     
/* 130 */     int left = 0;
/* 131 */     int right = 0;
/*     */     
/* 133 */     for (String s : chars) {
/* 134 */       if (s.equals("(")) {
/* 135 */         left++;
/* 136 */       } else if (s.equals(")")) {
/* 137 */         right++;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 142 */     if (left != right) {
/* 143 */       throw new Exception("Given expression '" + expression + "' has more uneven amount of parenthesis, there are " + left + " open and " + right + " closed!");
/*     */     }
/*     */ 
/*     */     
/* 147 */     return chars;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Object> breakdownChars(String[] chars) {
/* 154 */     List<Object> symbols = new ArrayList();
/* 155 */     String buffer = "";
/* 156 */     int len = chars.length;
/*     */     
/* 158 */     for (int i = 0; i < len; i++) {
/* 159 */       String s = chars[i];
/* 160 */       boolean longOperator = (i > 0 && isOperator(chars[i - 1] + s));
/*     */       
/* 162 */       if (isOperator(s) || longOperator || s.equals(",")) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 167 */         if (s.equals("-")) {
/* 168 */           int size = symbols.size();
/*     */           
/* 170 */           boolean isFirst = (size == 0 && buffer.isEmpty());
/*     */ 
/*     */           
/* 173 */           boolean isOperatorBehind = (size > 0 && (isOperator(symbols.get(size - 1)) || symbols.get(size - 1).equals(",")) && buffer.isEmpty());
/*     */           
/* 175 */           if (isFirst || isOperatorBehind) {
/* 176 */             buffer = buffer + s;
/*     */             
/*     */             continue;
/*     */           } 
/*     */         } 
/*     */         
/* 182 */         if (longOperator) {
/* 183 */           s = chars[i - 1] + s;
/* 184 */           buffer = buffer.substring(0, buffer.length() - 1);
/*     */         } 
/*     */ 
/*     */         
/* 188 */         if (!buffer.isEmpty()) {
/* 189 */           symbols.add(buffer);
/* 190 */           buffer = "";
/*     */         } 
/*     */         
/* 193 */         symbols.add(s); continue;
/* 194 */       }  if (s.equals("(")) {
/*     */         
/* 196 */         if (!buffer.isEmpty()) {
/* 197 */           symbols.add(buffer);
/* 198 */           buffer = "";
/*     */         } 
/*     */         
/* 201 */         int counter = 1;
/*     */         
/* 203 */         for (int j = i + 1; j < len; j++) {
/* 204 */           String c = chars[j];
/*     */           
/* 206 */           if (c.equals("(")) {
/* 207 */             counter++;
/* 208 */           } else if (c.equals(")")) {
/* 209 */             counter--;
/*     */           } 
/*     */           
/* 212 */           if (counter == 0) {
/* 213 */             symbols.add(breakdownChars(buffer.split("(?!^)")));
/*     */             
/* 215 */             i = j;
/* 216 */             buffer = "";
/*     */             
/*     */             break;
/*     */           } 
/* 220 */           buffer = buffer + c;
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/* 225 */         buffer = buffer + s;
/*     */       } 
/*     */       continue;
/*     */     } 
/* 229 */     if (!buffer.isEmpty()) {
/* 230 */       symbols.add(buffer);
/*     */     }
/*     */     
/* 233 */     return symbols;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IValue parseSymbols(List<Object> symbols) throws Exception {
/* 247 */     IValue ternary = tryTernary(symbols);
/*     */     
/* 249 */     if (ternary != null) {
/* 250 */       return ternary;
/*     */     }
/*     */     
/* 253 */     int size = symbols.size();
/*     */ 
/*     */     
/* 256 */     if (size == 1) {
/* 257 */       return valueFromObject(symbols.get(0));
/*     */     }
/*     */ 
/*     */     
/* 261 */     if (size == 2) {
/* 262 */       Object first = symbols.get(0);
/* 263 */       Object second = symbols.get(1);
/*     */       
/* 265 */       if ((isVariable(first) || first.equals("-")) && second instanceof List) {
/* 266 */         return createFunction((String)first, (List<Object>)second);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 271 */     int lastOp = seekLastOperator(symbols);
/* 272 */     int op = lastOp;
/*     */     
/* 274 */     while (op != -1) {
/* 275 */       int leftOp = seekLastOperator(symbols, op - 1);
/*     */       
/* 277 */       if (leftOp != -1) {
/* 278 */         Operation left = operationForOperator((String)symbols.get(leftOp));
/* 279 */         Operation right = operationForOperator((String)symbols.get(op));
/*     */         
/* 281 */         if (right.value > left.value) {
/* 282 */           IValue leftValue = parseSymbols(symbols.subList(0, leftOp));
/* 283 */           IValue rightValue = parseSymbols(symbols.subList(leftOp + 1, size));
/*     */           
/* 285 */           return new Operator(left, leftValue, rightValue);
/* 286 */         }  if (left.value > right.value) {
/* 287 */           Operation initial = operationForOperator((String)symbols.get(lastOp));
/*     */           
/* 289 */           if (initial.value < left.value) {
/* 290 */             IValue iValue1 = parseSymbols(symbols.subList(0, lastOp));
/* 291 */             IValue iValue2 = parseSymbols(symbols.subList(lastOp + 1, size));
/*     */             
/* 293 */             return new Operator(initial, iValue1, iValue2);
/*     */           } 
/*     */           
/* 296 */           IValue leftValue = parseSymbols(symbols.subList(0, op));
/* 297 */           IValue rightValue = parseSymbols(symbols.subList(op + 1, size));
/*     */           
/* 299 */           return new Operator(right, leftValue, rightValue);
/*     */         } 
/*     */       } 
/*     */       
/* 303 */       op = leftOp;
/*     */     } 
/*     */     
/* 306 */     Operation operation = operationForOperator((String)symbols.get(lastOp));
/*     */     
/* 308 */     return new Operator(operation, parseSymbols(symbols.subList(0, lastOp)), 
/* 309 */         parseSymbols(symbols.subList(lastOp + 1, size)));
/*     */   }
/*     */   
/*     */   protected int seekLastOperator(List<Object> symbols) {
/* 313 */     return seekLastOperator(symbols, symbols.size() - 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int seekLastOperator(List<Object> symbols, int offset) {
/* 320 */     for (int i = offset; i >= 0; i--) {
/* 321 */       Object o = symbols.get(i);
/*     */       
/* 323 */       if (isOperator(o)) {
/* 324 */         return i;
/*     */       }
/*     */     } 
/*     */     
/* 328 */     return -1;
/*     */   }
/*     */   
/*     */   protected int seekFirstOperator(List<Object> symbols) {
/* 332 */     return seekFirstOperator(symbols, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int seekFirstOperator(List<Object> symbols, int offset) {
/* 339 */     for (int i = offset, size = symbols.size(); i < size; i++) {
/* 340 */       Object o = symbols.get(i);
/*     */       
/* 342 */       if (isOperator(o)) {
/* 343 */         return i;
/*     */       }
/*     */     } 
/*     */     
/* 347 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IValue tryTernary(List<Object> symbols) throws Exception {
/* 358 */     int question = -1;
/* 359 */     int questions = 0;
/* 360 */     int colon = -1;
/* 361 */     int colons = 0;
/* 362 */     int size = symbols.size();
/*     */     
/* 364 */     for (int i = 0; i < size; i++) {
/* 365 */       Object object = symbols.get(i);
/*     */       
/* 367 */       if (object instanceof String) {
/* 368 */         if (object.equals("?")) {
/* 369 */           if (question == -1) {
/* 370 */             question = i;
/*     */           }
/*     */           
/* 373 */           questions++;
/* 374 */         } else if (object.equals(":")) {
/* 375 */           if (colons + 1 == questions && colon == -1) {
/* 376 */             colon = i;
/*     */           }
/*     */           
/* 379 */           colons++;
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 384 */     if (questions == colons && question > 0 && question + 1 < colon && colon < size - 1) {
/* 385 */       return new Ternary(parseSymbols(symbols.subList(0, question)), 
/* 386 */           parseSymbols(symbols.subList(question + 1, colon)), 
/* 387 */           parseSymbols(symbols.subList(colon + 1, size)));
/*     */     }
/*     */     
/* 390 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IValue createFunction(String first, List<Object> args) throws Exception {
/* 405 */     if (first.equals("!")) {
/* 406 */       return new Negate(parseSymbols(args));
/*     */     }
/*     */     
/* 409 */     if (first.startsWith("!") && first.length() > 1) {
/* 410 */       return new Negate(createFunction(first.substring(1), args));
/*     */     }
/*     */ 
/*     */     
/* 414 */     if (first.equals("-")) {
/* 415 */       return new Negative(new Group(parseSymbols(args)));
/*     */     }
/*     */     
/* 418 */     if (first.startsWith("-") && first.length() > 1) {
/* 419 */       return new Negative(createFunction(first.substring(1), args));
/*     */     }
/*     */     
/* 422 */     if (!this.functions.containsKey(first)) {
/* 423 */       throw new Exception("Function '" + first + "' couldn't be found!");
/*     */     }
/*     */     
/* 426 */     List<IValue> values = new ArrayList<>();
/* 427 */     List<Object> buffer = new ArrayList();
/*     */     
/* 429 */     for (Object o : args) {
/* 430 */       if (o.equals(",")) {
/* 431 */         values.add(parseSymbols(buffer));
/* 432 */         buffer.clear(); continue;
/*     */       } 
/* 434 */       buffer.add(o);
/*     */     } 
/*     */ 
/*     */     
/* 438 */     if (!buffer.isEmpty()) {
/* 439 */       values.add(parseSymbols(buffer));
/*     */     }
/*     */     
/* 442 */     Class<? extends Function> function = this.functions.get(first);
/* 443 */     Constructor<? extends Function> ctor = function.getConstructor(new Class[] { IValue[].class, String.class });
/* 444 */     Function func = ctor.newInstance(new Object[] { values.toArray(new IValue[values.size()]), first });
/*     */     
/* 446 */     return (IValue)func;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IValue valueFromObject(Object object) throws Exception {
/* 456 */     if (object instanceof String) {
/* 457 */       String symbol = (String)object;
/*     */ 
/*     */       
/* 460 */       if (symbol.startsWith("!")) {
/* 461 */         return new Negate(valueFromObject(symbol.substring(1)));
/*     */       }
/*     */       
/* 464 */       if (isDecimal(symbol))
/* 465 */         return new Constant(Double.parseDouble(symbol)); 
/* 466 */       if (isVariable(symbol))
/*     */       {
/* 468 */         if (symbol.startsWith("-")) {
/* 469 */           symbol = symbol.substring(1);
/* 470 */           Variable value = getVariable(symbol);
/*     */           
/* 472 */           if (value != null) {
/* 473 */             return new Negative(value);
/*     */           }
/*     */         } else {
/* 476 */           IValue value = getVariable(symbol);
/*     */ 
/*     */           
/* 479 */           if (value != null) {
/* 480 */             return value;
/*     */           }
/*     */         } 
/*     */       }
/* 484 */     } else if (object instanceof List) {
/* 485 */       return new Group(parseSymbols((List<Object>)object));
/*     */     } 
/*     */     
/* 488 */     throw new Exception("Given object couldn't be converted to value! " + object);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Variable getVariable(String name) {
/* 495 */     return this.variables.get(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Operation operationForOperator(String op) throws Exception {
/* 502 */     for (Operation operation : Operation.values()) {
/* 503 */       if (operation.sign.equals(op)) {
/* 504 */         return operation;
/*     */       }
/*     */     } 
/*     */     
/* 508 */     throw new Exception("There is no such operator '" + op + "'!");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isVariable(Object o) {
/* 515 */     return (o instanceof String && !isDecimal((String)o) && !isOperator((String)o));
/*     */   }
/*     */   
/*     */   protected boolean isOperator(Object o) {
/* 519 */     return (o instanceof String && isOperator((String)o));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isOperator(String s) {
/* 526 */     return (Operation.OPERATORS.contains(s) || s.equals("?") || s.equals(":"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isDecimal(String s) {
/* 533 */     return s.matches("^-?\\d+(\\.\\d+)?$");
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\geckolib-388172-4181370.jar!\software\bernie\shadowed\eliotlash\mclib\math\MathBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */