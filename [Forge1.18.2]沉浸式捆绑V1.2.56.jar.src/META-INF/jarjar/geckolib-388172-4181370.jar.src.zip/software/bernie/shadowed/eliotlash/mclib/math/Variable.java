/*    */ package software.bernie.shadowed.eliotlash.mclib.math;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Variable
/*    */   implements IValue
/*    */ {
/*    */   private String name;
/*    */   private double value;
/*    */   
/*    */   public Variable(String name, double value) {
/* 18 */     this.name = name;
/* 19 */     this.value = value;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void set(double value) {
/* 26 */     this.value = value;
/*    */   }
/*    */ 
/*    */   
/*    */   public double get() {
/* 31 */     return this.value;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 35 */     return this.name;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 40 */     return this.name;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\geckolib-388172-4181370.jar!\software\bernie\shadowed\eliotlash\mclib\math\Variable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */