package software.bernie.shadowed.fasterxml.jackson.core;

public interface FormatSchema {
  String getSchemaType();
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\geckolib-388172-4181370.jar!\software\bernie\shadowed\fasterxml\jackson\core\FormatSchema.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */