package software.bernie.shadowed.fasterxml.jackson.databind.deser;

import software.bernie.shadowed.fasterxml.jackson.databind.DeserializationContext;
import software.bernie.shadowed.fasterxml.jackson.databind.JsonMappingException;
import software.bernie.shadowed.fasterxml.jackson.databind.util.AccessPattern;

public interface NullValueProvider {
  Object getNullValue(DeserializationContext paramDeserializationContext) throws JsonMappingException;
  
  AccessPattern getNullAccessPattern();
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\geckolib-388172-4181370.jar!\software\bernie\shadowed\fasterxml\jackson\databind\deser\NullValueProvider.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */