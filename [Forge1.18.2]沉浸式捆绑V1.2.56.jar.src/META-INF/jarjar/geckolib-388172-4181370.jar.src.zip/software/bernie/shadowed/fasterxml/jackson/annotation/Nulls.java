/*    */ package software.bernie.shadowed.fasterxml.jackson.annotation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum Nulls
/*    */ {
/* 17 */   SET,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 24 */   SKIP,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 30 */   FAIL,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 36 */   AS_EMPTY,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 42 */   DEFAULT;
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\geckolib-388172-4181370.jar!\software\bernie\shadowed\fasterxml\jackson\annotation\Nulls.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */