/*    */ package software.bernie.example.item;
/*    */ 
/*    */ import net.minecraft.client.renderer.BlockEntityWithoutLevelRenderer;
/*    */ import net.minecraftforge.client.IItemRenderProperties;
/*    */ import software.bernie.example.client.renderer.item.PistolRender;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class null
/*    */   implements IItemRenderProperties
/*    */ {
/* 53 */   private final BlockEntityWithoutLevelRenderer renderer = (BlockEntityWithoutLevelRenderer)new PistolRender();
/*    */ 
/*    */   
/*    */   public BlockEntityWithoutLevelRenderer getItemStackRenderer() {
/* 57 */     return this.renderer;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\geckolib-388172-4181370.jar!\software\bernie\example\item\PistolItem$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */