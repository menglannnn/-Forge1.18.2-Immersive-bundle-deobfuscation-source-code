/*    */ package software.bernie.example.item;
/*    */ 
/*    */ import net.minecraft.client.renderer.BlockEntityWithoutLevelRenderer;
/*    */ import net.minecraftforge.client.IItemRenderProperties;
/*    */ import software.bernie.example.client.renderer.item.JackInTheBoxRenderer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class null
/*    */   implements IItemRenderProperties
/*    */ {
/* 49 */   private final BlockEntityWithoutLevelRenderer renderer = (BlockEntityWithoutLevelRenderer)new JackInTheBoxRenderer();
/*    */ 
/*    */   
/*    */   public BlockEntityWithoutLevelRenderer getItemStackRenderer() {
/* 53 */     return this.renderer;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\geckolib-388172-4181370.jar!\software\bernie\example\item\JackInTheBoxItem$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */