/*    */ package software.bernie.example;
/*    */ 
/*    */ import net.minecraft.world.item.CreativeModeTab;
/*    */ import net.minecraft.world.item.ItemStack;
/*    */ import net.minecraft.world.level.ItemLike;
/*    */ import software.bernie.example.registry.ItemRegistry;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class null
/*    */   extends CreativeModeTab
/*    */ {
/*    */   null(int arg0, String arg1) {
/* 51 */     super(arg0, arg1);
/*    */   }
/*    */   public ItemStack m_6976_() {
/* 54 */     return new ItemStack((ItemLike)ItemRegistry.JACK_IN_THE_BOX.get());
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\geckolib-388172-4181370.jar!\software\bernie\example\GeckoLibMod$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */