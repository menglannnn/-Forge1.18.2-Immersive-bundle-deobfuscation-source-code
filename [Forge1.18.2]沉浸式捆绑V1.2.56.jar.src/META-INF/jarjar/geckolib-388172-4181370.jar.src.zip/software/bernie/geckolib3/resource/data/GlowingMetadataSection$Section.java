/*    */ package software.bernie.geckolib3.resource.data;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Section
/*    */   extends Record
/*    */ {
/*    */   private final int x1;
/*    */   private final int y1;
/*    */   private final int x2;
/*    */   private final int y2;
/*    */   
/*    */   public final String toString() {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> toString : (Lsoftware/bernie/geckolib3/resource/data/GlowingMetadataSection$Section;)Ljava/lang/String;
/*    */     //   6: areturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #40	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Lsoftware/bernie/geckolib3/resource/data/GlowingMetadataSection$Section;
/*    */   }
/*    */   
/*    */   public final int hashCode() {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> hashCode : (Lsoftware/bernie/geckolib3/resource/data/GlowingMetadataSection$Section;)I
/*    */     //   6: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #40	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Lsoftware/bernie/geckolib3/resource/data/GlowingMetadataSection$Section;
/*    */   }
/*    */   
/*    */   public final boolean equals(Object o) {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: aload_1
/*    */     //   2: <illegal opcode> equals : (Lsoftware/bernie/geckolib3/resource/data/GlowingMetadataSection$Section;Ljava/lang/Object;)Z
/*    */     //   7: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #40	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	8	0	this	Lsoftware/bernie/geckolib3/resource/data/GlowingMetadataSection$Section;
/*    */     //   0	8	1	o	Ljava/lang/Object;
/*    */   }
/*    */   
/*    */   public Section(int x1, int y1, int x2, int y2) {
/* 40 */     this.x1 = x1; this.y1 = y1; this.x2 = x2; this.y2 = y2; } public int x1() { return this.x1; } public int y1() { return this.y1; } public int x2() { return this.x2; } public int y2() { return this.y2; }
/*    */    public Section copy() {
/* 42 */     return new Section(this.x1, this.y1, this.x2, this.y2);
/*    */   }
/*    */   
/*    */   public void forEach(GlowingMetadataSection.BiIntConsumer action) {
/* 46 */     for (int x = this.x1; x < this.x2; x++) {
/* 47 */       for (int y = this.y1; y < this.y2; y++)
/* 48 */         action.accept(x, y); 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\geckolib-388172-4181370.jar!\software\bernie\geckolib3\resource\data\GlowingMetadataSection$Section.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */