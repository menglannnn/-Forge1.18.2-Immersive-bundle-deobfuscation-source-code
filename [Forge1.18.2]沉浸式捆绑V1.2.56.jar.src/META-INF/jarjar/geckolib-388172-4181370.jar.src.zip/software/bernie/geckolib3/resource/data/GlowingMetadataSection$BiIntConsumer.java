package software.bernie.geckolib3.resource.data;

@FunctionalInterface
public interface BiIntConsumer {
  void accept(int paramInt1, int paramInt2);
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\geckolib-388172-4181370.jar!\software\bernie\geckolib3\resource\data\GlowingMetadataSection$BiIntConsumer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */