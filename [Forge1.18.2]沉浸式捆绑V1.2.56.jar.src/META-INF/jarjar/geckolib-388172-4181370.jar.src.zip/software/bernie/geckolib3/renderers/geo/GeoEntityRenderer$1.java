/*     */ package software.bernie.geckolib3.renderers.geo;
/*     */ 
/*     */ import net.minecraft.core.Direction;
/*     */ 


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\geckolib-388172-4181370.jar!\software\bernie\geckolib3\renderers\geo\GeoEntityRenderer$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */