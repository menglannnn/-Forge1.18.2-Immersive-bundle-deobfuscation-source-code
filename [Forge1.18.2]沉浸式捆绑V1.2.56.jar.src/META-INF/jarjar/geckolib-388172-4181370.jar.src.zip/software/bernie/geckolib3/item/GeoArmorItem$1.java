/*    */ package software.bernie.geckolib3.item;
/*    */ 
/*    */ import net.minecraft.client.model.HumanoidModel;
/*    */ import net.minecraft.world.entity.Entity;
/*    */ import net.minecraft.world.entity.EquipmentSlot;
/*    */ import net.minecraft.world.entity.LivingEntity;
/*    */ import net.minecraft.world.item.ItemStack;
/*    */ import net.minecraftforge.client.IItemRenderProperties;
/*    */ import software.bernie.geckolib3.renderers.geo.GeoArmorRenderer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class null
/*    */   implements IItemRenderProperties
/*    */ {
/*    */   public HumanoidModel<?> getArmorModel(LivingEntity entityLiving, ItemStack itemStack, EquipmentSlot armorSlot, HumanoidModel<?> _default) {
/* 29 */     return (HumanoidModel<?>)GeoArmorRenderer.getRenderer(GeoArmorItem.this.getClass(), (Entity)entityLiving)
/* 30 */       .applyEntityStats(_default).setCurrentItem(entityLiving, itemStack, armorSlot)
/* 31 */       .applySlot(armorSlot);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\geckolib-388172-4181370.jar!\software\bernie\geckolib3\item\GeoArmorItem$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */