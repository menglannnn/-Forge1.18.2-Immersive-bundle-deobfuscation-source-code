/*    */ package software.bernie.geckolib3.core.builder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum EDefaultLoopTypes
/*    */   implements ILoopType
/*    */ {
/* 13 */   LOOP(true),
/* 14 */   PLAY_ONCE,
/* 15 */   HOLD_ON_LAST_FRAME;
/*    */   
/*    */   private final boolean looping;
/*    */   
/*    */   EDefaultLoopTypes(boolean looping) {
/* 20 */     this.looping = looping;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isRepeatingAfterEnd() {
/* 29 */     return this.looping;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\geckolib-388172-4181370.jar!\software\bernie\geckolib3\core\builder\ILoopType$EDefaultLoopTypes.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */