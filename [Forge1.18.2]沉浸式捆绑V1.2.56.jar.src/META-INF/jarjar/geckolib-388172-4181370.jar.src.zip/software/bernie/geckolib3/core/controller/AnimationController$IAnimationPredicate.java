package software.bernie.geckolib3.core.controller;

import software.bernie.geckolib3.core.PlayState;
import software.bernie.geckolib3.core.event.predicate.AnimationEvent;

@FunctionalInterface
public interface IAnimationPredicate<P extends software.bernie.geckolib3.core.IAnimatable> {
  PlayState test(AnimationEvent<P> paramAnimationEvent);
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\geckolib-388172-4181370.jar!\software\bernie\geckolib3\core\controller\AnimationController$IAnimationPredicate.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */