/*    */ package software.bernie.geckolib3.geo.raw.pojo;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import software.bernie.shadowed.fasterxml.jackson.core.JsonParser;
/*    */ import software.bernie.shadowed.fasterxml.jackson.core.JsonProcessingException;
/*    */ import software.bernie.shadowed.fasterxml.jackson.databind.DeserializationContext;
/*    */ import software.bernie.shadowed.fasterxml.jackson.databind.JsonDeserializer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class Deserializer
/*    */   extends JsonDeserializer<UvUnion>
/*    */ {
/*    */   public UvUnion deserialize(JsonParser jsonParser, DeserializationContext deserializationContext) throws IOException, JsonProcessingException {
/* 26 */     UvUnion value = new UvUnion();
/* 27 */     switch (UvUnion.null.$SwitchMap$com$fasterxml$jackson$core$JsonToken[jsonParser.currentToken().ordinal()]) {
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/*    */       case 1:
/* 41 */         return value;
/*    */       case 2:
/*    */         value.boxUVCoords = (double[])jsonParser.readValueAs(double[].class);
/*    */         value.isBoxUV = true;
/*    */       case 3:
/*    */         value.faceUV = (UvFaces)jsonParser.readValueAs(UvFaces.class);
/*    */         value.isBoxUV = false;
/*    */     } 
/*    */     throw new IOException("Cannot deserialize UvUnion");
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\geckolib-388172-4181370.jar!\software\bernie\geckolib3\geo\raw\pojo\UvUnion$Deserializer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */