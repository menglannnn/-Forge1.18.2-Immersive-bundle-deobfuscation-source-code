/*    */ package software.bernie.geckolib3.geo.raw.pojo;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import software.bernie.shadowed.fasterxml.jackson.core.JsonParser;
/*    */ import software.bernie.shadowed.fasterxml.jackson.core.JsonProcessingException;
/*    */ import software.bernie.shadowed.fasterxml.jackson.databind.DeserializationContext;
/*    */ import software.bernie.shadowed.fasterxml.jackson.databind.JsonDeserializer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class Deserializer
/*    */   extends JsonDeserializer<LocatorValue>
/*    */ {
/*    */   public LocatorValue deserialize(JsonParser jsonParser, DeserializationContext deserializationContext) throws IOException, JsonProcessingException {
/* 25 */     LocatorValue value = new LocatorValue();
/* 26 */     switch (LocatorValue.null.$SwitchMap$com$fasterxml$jackson$core$JsonToken[jsonParser.getCurrentToken().ordinal()]) {
/*    */       case 1:
/* 28 */         value.doubleArrayValue = (double[])jsonParser.readValueAs(double[].class);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */         
/* 36 */         return value;case 2: value.locatorClassValue = (LocatorClass)jsonParser.readValueAs(LocatorClass.class); return value;
/*    */     } 
/*    */     throw new IOException("Cannot deserialize LocatorValue");
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\geckolib-388172-4181370.jar!\software\bernie\geckolib3\geo\raw\pojo\LocatorValue$Deserializer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */