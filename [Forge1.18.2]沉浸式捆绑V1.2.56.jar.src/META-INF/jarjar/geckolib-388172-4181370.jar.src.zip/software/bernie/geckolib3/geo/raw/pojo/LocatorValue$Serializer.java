/*    */ package software.bernie.geckolib3.geo.raw.pojo;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import software.bernie.shadowed.fasterxml.jackson.core.JsonGenerator;
/*    */ import software.bernie.shadowed.fasterxml.jackson.databind.JsonSerializer;
/*    */ import software.bernie.shadowed.fasterxml.jackson.databind.SerializerProvider;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class Serializer
/*    */   extends JsonSerializer<LocatorValue>
/*    */ {
/*    */   public void serialize(LocatorValue obj, JsonGenerator jsonGenerator, SerializerProvider serializerProvider) throws IOException {
/* 44 */     if (obj.locatorClassValue != null) {
/* 45 */       jsonGenerator.writeObject(obj.locatorClassValue);
/*    */       return;
/*    */     } 
/* 48 */     if (obj.doubleArrayValue != null) {
/* 49 */       jsonGenerator.writeObject(obj.doubleArrayValue);
/*    */       return;
/*    */     } 
/* 52 */     throw new IOException("LocatorValue must not be null");
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\geckolib-388172-4181370.jar!\software\bernie\geckolib3\geo\raw\pojo\LocatorValue$Serializer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */