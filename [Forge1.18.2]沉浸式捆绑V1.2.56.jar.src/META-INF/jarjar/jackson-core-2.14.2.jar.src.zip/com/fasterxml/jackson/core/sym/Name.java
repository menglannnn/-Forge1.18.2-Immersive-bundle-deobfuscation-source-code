/*    */ package com.fasterxml.jackson.core.sym;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Name
/*    */ {
/*    */   protected final String _name;
/*    */   protected final int _hashCode;
/*    */   
/*    */   protected Name(String name, int hashCode) {
/* 17 */     this._name = name;
/* 18 */     this._hashCode = hashCode;
/*    */   }
/*    */   public String getName() {
/* 21 */     return this._name;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public abstract boolean equals(int paramInt);
/*    */ 
/*    */ 
/*    */   
/*    */   public abstract boolean equals(int paramInt1, int paramInt2);
/*    */ 
/*    */ 
/*    */   
/*    */   public abstract boolean equals(int paramInt1, int paramInt2, int paramInt3);
/*    */ 
/*    */ 
/*    */   
/*    */   public abstract boolean equals(int[] paramArrayOfint, int paramInt);
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 43 */     return this._name;
/*    */   } public final int hashCode() {
/* 45 */     return this._hashCode;
/*    */   }
/*    */   
/*    */   public boolean equals(Object o) {
/* 49 */     return (o == this);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-core-2.14.2.jar!\com\fasterxml\jackson\core\sym\Name.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */