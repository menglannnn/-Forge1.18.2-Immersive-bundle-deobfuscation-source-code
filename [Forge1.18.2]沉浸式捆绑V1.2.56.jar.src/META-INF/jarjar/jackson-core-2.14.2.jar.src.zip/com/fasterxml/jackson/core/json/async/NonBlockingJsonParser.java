/*    */ package com.fasterxml.jackson.core.json.async;
/*    */ 
/*    */ import com.fasterxml.jackson.core.async.ByteArrayFeeder;
/*    */ import com.fasterxml.jackson.core.async.NonBlockingInputFeeder;
/*    */ import com.fasterxml.jackson.core.io.IOContext;
/*    */ import com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer;
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NonBlockingJsonParser
/*    */   extends NonBlockingUtf8JsonParserBase
/*    */   implements ByteArrayFeeder
/*    */ {
/* 23 */   private byte[] _inputBuffer = NO_BYTES;
/*    */ 
/*    */   
/*    */   public NonBlockingJsonParser(IOContext ctxt, int parserFeatures, ByteQuadsCanonicalizer sym) {
/* 27 */     super(ctxt, parserFeatures, sym);
/*    */   }
/*    */ 
/*    */   
/*    */   public ByteArrayFeeder getNonBlockingInputFeeder() {
/* 32 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void feedInput(byte[] buf, int start, int end) throws IOException {
/* 38 */     if (this._inputPtr < this._inputEnd) {
/* 39 */       _reportError("Still have %d undecoded bytes, should not call 'feedInput'", Integer.valueOf(this._inputEnd - this._inputPtr));
/*    */     }
/* 41 */     if (end < start) {
/* 42 */       _reportError("Input end (%d) may not be before start (%d)", Integer.valueOf(end), Integer.valueOf(start));
/*    */     }
/*    */     
/* 45 */     if (this._endOfInput) {
/* 46 */       _reportError("Already closed, can not feed more input");
/*    */     }
/*    */     
/* 49 */     this._currInputProcessed += this._origBufferLen;
/*    */ 
/*    */     
/* 52 */     this._currInputRowStart = start - this._inputEnd - this._currInputRowStart;
/*    */ 
/*    */     
/* 55 */     this._currBufferStart = start;
/* 56 */     this._inputBuffer = buf;
/* 57 */     this._inputPtr = start;
/* 58 */     this._inputEnd = end;
/* 59 */     this._origBufferLen = end - start;
/*    */   }
/*    */ 
/*    */   
/*    */   public int releaseBuffered(OutputStream out) throws IOException {
/* 64 */     int avail = this._inputEnd - this._inputPtr;
/* 65 */     if (avail > 0) {
/* 66 */       out.write(this._inputBuffer, this._inputPtr, avail);
/*    */     }
/* 68 */     return avail;
/*    */   }
/*    */ 
/*    */   
/*    */   protected byte getNextSignedByteFromBuffer() {
/* 73 */     return this._inputBuffer[this._inputPtr++];
/*    */   }
/*    */ 
/*    */   
/*    */   protected int getNextUnsignedByteFromBuffer() {
/* 78 */     return this._inputBuffer[this._inputPtr++] & 0xFF;
/*    */   }
/*    */ 
/*    */   
/*    */   protected byte getByteFromBuffer(int ptr) {
/* 83 */     return this._inputBuffer[ptr];
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-core-2.14.2.jar!\com\fasterxml\jackson\core\json\async\NonBlockingJsonParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */