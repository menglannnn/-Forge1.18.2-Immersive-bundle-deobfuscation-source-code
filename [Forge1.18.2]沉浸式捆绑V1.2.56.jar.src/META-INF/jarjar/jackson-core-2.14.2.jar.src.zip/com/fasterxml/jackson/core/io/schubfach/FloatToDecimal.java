/*     */ package com.fasterxml.jackson.core.io.schubfach;
/*     */ 
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FloatToDecimal
/*     */ {
/*     */   static final int P = 24;
/*     */   private static final int W = 8;
/*     */   static final int Q_MIN = -149;
/*     */   static final int Q_MAX = 104;
/*     */   static final int E_MIN = -44;
/*     */   static final int E_MAX = 39;
/*     */   static final int C_TINY = 8;
/*     */   static final int K_MIN = -45;
/*     */   static final int K_MAX = 31;
/*     */   static final int H = 9;
/*     */   private static final int C_MIN = 8388608;
/*     */   private static final int BQ_MASK = 255;
/*     */   private static final int T_MASK = 8388607;
/*     */   private static final long MASK_32 = 4294967295L;
/*     */   private static final int MASK_28 = 268435455;
/*     */   private static final int NON_SPECIAL = 0;
/*     */   private static final int PLUS_ZERO = 1;
/*     */   private static final int MINUS_ZERO = 2;
/*     */   private static final int PLUS_INF = 3;
/*     */   private static final int MINUS_INF = 4;
/*     */   private static final int NAN = 5;
/*     */   public static final int MAX_CHARS = 15;
/* 112 */   private final byte[] bytes = new byte[15];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int index;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toString(float v) {
/* 129 */     return (new FloatToDecimal()).toDecimalString(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Appendable appendTo(float v, Appendable app) throws IOException {
/* 145 */     return (new FloatToDecimal()).appendDecimalTo(v, app);
/*     */   }
/*     */   
/*     */   private String toDecimalString(float v) {
/* 149 */     switch (toDecimal(v)) { case 0:
/* 150 */         return charsToString();
/* 151 */       case 1: return "0.0";
/* 152 */       case 2: return "-0.0";
/* 153 */       case 3: return "Infinity";
/* 154 */       case 4: return "-Infinity"; }
/* 155 */      return "NaN";
/*     */   }
/*     */   
/*     */   private Appendable appendDecimalTo(float v, Appendable app) throws IOException {
/*     */     char[] chars;
/*     */     int i;
/* 161 */     switch (toDecimal(v)) {
/*     */       case 0:
/* 163 */         chars = new char[this.index + 1];
/* 164 */         for (i = 0; i < chars.length; i++) {
/* 165 */           chars[i] = (char)this.bytes[i];
/*     */         }
/* 167 */         if (app instanceof StringBuilder) {
/* 168 */           return ((StringBuilder)app).append(chars);
/*     */         }
/* 170 */         if (app instanceof StringBuffer) {
/* 171 */           return ((StringBuffer)app).append(chars);
/*     */         }
/* 173 */         for (char c : chars) {
/* 174 */           app.append(c);
/*     */         }
/* 176 */         return app;
/* 177 */       case 1: return app.append("0.0");
/* 178 */       case 2: return app.append("-0.0");
/* 179 */       case 3: return app.append("Infinity");
/* 180 */       case 4: return app.append("-Infinity");
/* 181 */     }  return app.append("NaN");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int toDecimal(float v) {
/* 203 */     int bits = Float.floatToRawIntBits(v);
/* 204 */     int t = bits & 0x7FFFFF;
/* 205 */     int bq = bits >>> 23 & 0xFF;
/* 206 */     if (bq < 255) {
/* 207 */       this.index = -1;
/* 208 */       if (bits < 0) {
/* 209 */         append(45);
/*     */       }
/* 211 */       if (bq != 0) {
/*     */         
/* 213 */         int mq = 150 - bq;
/* 214 */         int c = 0x800000 | t;
/*     */         
/* 216 */         if ((((0 < mq) ? 1 : 0) & ((mq < 24) ? 1 : 0)) != 0) {
/* 217 */           int f = c >> mq;
/* 218 */           if (f << mq == c) {
/* 219 */             return toChars(f, 0);
/*     */           }
/*     */         } 
/* 222 */         return toDecimal(-mq, c, 0);
/*     */       } 
/* 224 */       if (t != 0)
/*     */       {
/* 226 */         return (t < 8) ? 
/* 227 */           toDecimal(-149, 10 * t, -1) : 
/* 228 */           toDecimal(-149, t, 0);
/*     */       }
/* 230 */       return (bits == 0) ? 1 : 2;
/*     */     } 
/* 232 */     if (t != 0) {
/* 233 */       return 5;
/*     */     }
/* 235 */     return (bits > 0) ? 3 : 4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int toDecimal(int q, int c, int dk) {
/*     */     long cbl;
/* 257 */     int k, out = c & 0x1;
/* 258 */     long cb = (c << 2);
/* 259 */     long cbr = cb + 2L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 267 */     if ((((c != 8388608) ? 1 : 0) | ((q == -149) ? 1 : 0)) != 0) {
/*     */       
/* 269 */       cbl = cb - 2L;
/* 270 */       k = MathUtils.flog10pow2(q);
/*     */     } else {
/*     */       
/* 273 */       cbl = cb - 1L;
/* 274 */       k = MathUtils.flog10threeQuartersPow2(q);
/*     */     } 
/* 276 */     int h = q + MathUtils.flog2pow10(-k) + 33;
/*     */ 
/*     */     
/* 279 */     long g = MathUtils.g1(k) + 1L;
/*     */     
/* 281 */     int vb = rop(g, cb << h);
/* 282 */     int vbl = rop(g, cbl << h);
/* 283 */     int vbr = rop(g, cbr << h);
/*     */     
/* 285 */     int s = vb >> 2;
/* 286 */     if (s >= 100) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 297 */       int sp10 = 10 * (int)(s * 1717986919L >>> 34L);
/* 298 */       int tp10 = sp10 + 10;
/* 299 */       boolean upin = (vbl + out <= sp10 << 2);
/* 300 */       boolean wpin = ((tp10 << 2) + out <= vbr);
/* 301 */       if (upin != wpin) {
/* 302 */         return toChars(upin ? sp10 : tp10, k);
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 312 */     int t = s + 1;
/* 313 */     boolean uin = (vbl + out <= s << 2);
/* 314 */     boolean win = ((t << 2) + out <= vbr);
/* 315 */     if (uin != win)
/*     */     {
/* 317 */       return toChars(uin ? s : t, k + dk);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 323 */     int cmp = vb - (s + t << 1);
/* 324 */     return toChars((cmp < 0 || (cmp == 0 && (s & 0x1) == 0)) ? s : t, k + dk);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int rop(long g, long cp) {
/* 332 */     long x1 = MathUtils.multiplyHigh(g, cp);
/* 333 */     long vbp = x1 >>> 31L;
/* 334 */     return (int)(vbp | (x1 & 0xFFFFFFFFL) + 4294967295L >>> 32L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int toChars(int f, int e) {
/* 347 */     int len = MathUtils.flog10pow2(32 - Integer.numberOfLeadingZeros(f));
/* 348 */     if (f >= MathUtils.pow10(len)) {
/* 349 */       len++;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 358 */     f *= (int)MathUtils.pow10(9 - len);
/* 359 */     e += len;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 371 */     int h = (int)(f * 1441151881L >>> 57L);
/* 372 */     int l = f - 100000000 * h;
/*     */     
/* 374 */     if (0 < e && e <= 7) {
/* 375 */       return toChars1(h, l, e);
/*     */     }
/* 377 */     if (-3 < e && e <= 0) {
/* 378 */       return toChars2(h, l, e);
/*     */     }
/* 380 */     return toChars3(h, l, e);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int toChars1(int h, int l, int e) {
/* 389 */     appendDigit(h);
/* 390 */     int y = y(l);
/*     */     
/* 392 */     int i = 1;
/* 393 */     for (; i < e; i++) {
/* 394 */       int t = 10 * y;
/* 395 */       appendDigit(t >>> 28);
/* 396 */       y = t & 0xFFFFFFF;
/*     */     } 
/* 398 */     append(46);
/* 399 */     for (; i <= 8; i++) {
/* 400 */       int t = 10 * y;
/* 401 */       appendDigit(t >>> 28);
/* 402 */       y = t & 0xFFFFFFF;
/*     */     } 
/* 404 */     removeTrailingZeroes();
/* 405 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   private int toChars2(int h, int l, int e) {
/* 410 */     appendDigit(0);
/* 411 */     append(46);
/* 412 */     for (; e < 0; e++) {
/* 413 */       appendDigit(0);
/*     */     }
/* 415 */     appendDigit(h);
/* 416 */     append8Digits(l);
/* 417 */     removeTrailingZeroes();
/* 418 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   private int toChars3(int h, int l, int e) {
/* 423 */     appendDigit(h);
/* 424 */     append(46);
/* 425 */     append8Digits(l);
/* 426 */     removeTrailingZeroes();
/* 427 */     exponent(e - 1);
/* 428 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void append8Digits(int m) {
/* 436 */     int y = y(m);
/* 437 */     for (int i = 0; i < 8; i++) {
/* 438 */       int t = 10 * y;
/* 439 */       appendDigit(t >>> 28);
/* 440 */       y = t & 0xFFFFFFF;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void removeTrailingZeroes() {
/* 445 */     while (this.bytes[this.index] == 48) {
/* 446 */       this.index--;
/*     */     }
/*     */     
/* 449 */     if (this.bytes[this.index] == 46) {
/* 450 */       this.index++;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int y(int a) {
/* 463 */     return (int)(MathUtils.multiplyHigh((a + 1) << 28L, 193428131138340668L) >>> 20L) - 1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void exponent(int e) {
/* 469 */     append(69);
/* 470 */     if (e < 0) {
/* 471 */       append(45);
/* 472 */       e = -e;
/*     */     } 
/* 474 */     if (e < 10) {
/* 475 */       appendDigit(e);
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */     
/* 482 */     int d = e * 103 >>> 10;
/* 483 */     appendDigit(d);
/* 484 */     appendDigit(e - 10 * d);
/*     */   }
/*     */   
/*     */   private void append(int c) {
/* 488 */     this.bytes[++this.index] = (byte)c;
/*     */   }
/*     */   
/*     */   private void appendDigit(int d) {
/* 492 */     this.bytes[++this.index] = (byte)(48 + d);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private String charsToString() {
/* 498 */     return new String(this.bytes, 0, 0, this.index + 1);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-core-2.14.2.jar!\com\fasterxml\jackson\core\io\schubfach\FloatToDecimal.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */