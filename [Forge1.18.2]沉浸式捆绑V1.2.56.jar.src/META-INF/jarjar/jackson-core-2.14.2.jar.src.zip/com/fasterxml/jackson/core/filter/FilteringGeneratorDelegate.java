/*      */ package com.fasterxml.jackson.core.filter;
/*      */ 
/*      */ import com.fasterxml.jackson.core.Base64Variant;
/*      */ import com.fasterxml.jackson.core.JsonGenerator;
/*      */ import com.fasterxml.jackson.core.JsonStreamContext;
/*      */ import com.fasterxml.jackson.core.SerializableString;
/*      */ import com.fasterxml.jackson.core.util.JsonGeneratorDelegate;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class FilteringGeneratorDelegate
/*      */   extends JsonGeneratorDelegate
/*      */ {
/*      */   protected TokenFilter rootFilter;
/*      */   protected boolean _allowMultipleMatches;
/*      */   protected TokenFilter.Inclusion _inclusion;
/*      */   protected TokenFilterContext _filterContext;
/*      */   protected TokenFilter _itemFilter;
/*      */   protected int _matchCount;
/*      */   
/*      */   @Deprecated
/*      */   public FilteringGeneratorDelegate(JsonGenerator d, TokenFilter f, boolean includePath, boolean allowMultipleMatches) {
/*   97 */     this(d, f, includePath ? TokenFilter.Inclusion.INCLUDE_ALL_AND_PATH : TokenFilter.Inclusion.ONLY_INCLUDE_ALL, allowMultipleMatches);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public FilteringGeneratorDelegate(JsonGenerator d, TokenFilter f, TokenFilter.Inclusion inclusion, boolean allowMultipleMatches) {
/*  112 */     super(d, false);
/*  113 */     this.rootFilter = f;
/*      */     
/*  115 */     this._itemFilter = f;
/*  116 */     this._filterContext = TokenFilterContext.createRootContext(f);
/*  117 */     this._inclusion = inclusion;
/*  118 */     this._allowMultipleMatches = allowMultipleMatches;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TokenFilter getFilter() {
/*  127 */     return this.rootFilter;
/*      */   }
/*      */   public JsonStreamContext getFilterContext() {
/*  130 */     return this._filterContext;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMatchCount() {
/*  140 */     return this._matchCount;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonStreamContext getOutputContext() {
/*  155 */     return this._filterContext;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeStartArray() throws IOException {
/*  168 */     if (this._itemFilter == null) {
/*  169 */       this._filterContext = this._filterContext.createChildArrayContext(null, false);
/*      */       return;
/*      */     } 
/*  172 */     if (this._itemFilter == TokenFilter.INCLUDE_ALL) {
/*  173 */       this._filterContext = this._filterContext.createChildArrayContext(this._itemFilter, true);
/*  174 */       this.delegate.writeStartArray();
/*      */       
/*      */       return;
/*      */     } 
/*  178 */     this._itemFilter = this._filterContext.checkValue(this._itemFilter);
/*  179 */     if (this._itemFilter == null) {
/*  180 */       this._filterContext = this._filterContext.createChildArrayContext(null, false);
/*      */       return;
/*      */     } 
/*  183 */     if (this._itemFilter != TokenFilter.INCLUDE_ALL) {
/*  184 */       this._itemFilter = this._itemFilter.filterStartArray();
/*      */     }
/*  186 */     if (this._itemFilter == TokenFilter.INCLUDE_ALL) {
/*  187 */       _checkParentPath();
/*  188 */       this._filterContext = this._filterContext.createChildArrayContext(this._itemFilter, true);
/*  189 */       this.delegate.writeStartArray();
/*  190 */     } else if (this._itemFilter != null && this._inclusion == TokenFilter.Inclusion.INCLUDE_NON_NULL) {
/*  191 */       _checkParentPath(false);
/*  192 */       this._filterContext = this._filterContext.createChildArrayContext(this._itemFilter, true);
/*  193 */       this.delegate.writeStartArray();
/*      */     } else {
/*  195 */       this._filterContext = this._filterContext.createChildArrayContext(this._itemFilter, false);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeStartArray(int size) throws IOException {
/*  203 */     if (this._itemFilter == null) {
/*  204 */       this._filterContext = this._filterContext.createChildArrayContext(null, false);
/*      */       return;
/*      */     } 
/*  207 */     if (this._itemFilter == TokenFilter.INCLUDE_ALL) {
/*  208 */       this._filterContext = this._filterContext.createChildArrayContext(this._itemFilter, true);
/*  209 */       this.delegate.writeStartArray(size);
/*      */       return;
/*      */     } 
/*  212 */     this._itemFilter = this._filterContext.checkValue(this._itemFilter);
/*  213 */     if (this._itemFilter == null) {
/*  214 */       this._filterContext = this._filterContext.createChildArrayContext(null, false);
/*      */       return;
/*      */     } 
/*  217 */     if (this._itemFilter != TokenFilter.INCLUDE_ALL) {
/*  218 */       this._itemFilter = this._itemFilter.filterStartArray();
/*      */     }
/*  220 */     if (this._itemFilter == TokenFilter.INCLUDE_ALL) {
/*  221 */       _checkParentPath();
/*  222 */       this._filterContext = this._filterContext.createChildArrayContext(this._itemFilter, true);
/*  223 */       this.delegate.writeStartArray(size);
/*  224 */     } else if (this._itemFilter != null && this._inclusion == TokenFilter.Inclusion.INCLUDE_NON_NULL) {
/*  225 */       _checkParentPath(false);
/*  226 */       this._filterContext = this._filterContext.createChildArrayContext(this._itemFilter, true);
/*  227 */       this.delegate.writeStartArray(size);
/*      */     } else {
/*  229 */       this._filterContext = this._filterContext.createChildArrayContext(this._itemFilter, false);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeStartArray(Object forValue) throws IOException {
/*  236 */     if (this._itemFilter == null) {
/*  237 */       this._filterContext = this._filterContext.createChildArrayContext(null, false);
/*      */       return;
/*      */     } 
/*  240 */     if (this._itemFilter == TokenFilter.INCLUDE_ALL) {
/*  241 */       this._filterContext = this._filterContext.createChildArrayContext(this._itemFilter, true);
/*  242 */       this.delegate.writeStartArray(forValue);
/*      */       return;
/*      */     } 
/*  245 */     this._itemFilter = this._filterContext.checkValue(this._itemFilter);
/*  246 */     if (this._itemFilter == null) {
/*  247 */       this._filterContext = this._filterContext.createChildArrayContext(null, false);
/*      */       return;
/*      */     } 
/*  250 */     if (this._itemFilter != TokenFilter.INCLUDE_ALL) {
/*  251 */       this._itemFilter = this._itemFilter.filterStartArray();
/*      */     }
/*  253 */     if (this._itemFilter == TokenFilter.INCLUDE_ALL) {
/*  254 */       _checkParentPath();
/*  255 */       this._filterContext = this._filterContext.createChildArrayContext(this._itemFilter, true);
/*  256 */       this.delegate.writeStartArray(forValue);
/*      */     } else {
/*  258 */       this._filterContext = this._filterContext.createChildArrayContext(this._itemFilter, false);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeStartArray(Object forValue, int size) throws IOException {
/*  265 */     if (this._itemFilter == null) {
/*  266 */       this._filterContext = this._filterContext.createChildArrayContext(null, false);
/*      */       return;
/*      */     } 
/*  269 */     if (this._itemFilter == TokenFilter.INCLUDE_ALL) {
/*  270 */       this._filterContext = this._filterContext.createChildArrayContext(this._itemFilter, true);
/*  271 */       this.delegate.writeStartArray(forValue, size);
/*      */       return;
/*      */     } 
/*  274 */     this._itemFilter = this._filterContext.checkValue(this._itemFilter);
/*  275 */     if (this._itemFilter == null) {
/*  276 */       this._filterContext = this._filterContext.createChildArrayContext(null, false);
/*      */       return;
/*      */     } 
/*  279 */     if (this._itemFilter != TokenFilter.INCLUDE_ALL) {
/*  280 */       this._itemFilter = this._itemFilter.filterStartArray();
/*      */     }
/*  282 */     if (this._itemFilter == TokenFilter.INCLUDE_ALL) {
/*  283 */       _checkParentPath();
/*  284 */       this._filterContext = this._filterContext.createChildArrayContext(this._itemFilter, true);
/*  285 */       this.delegate.writeStartArray(forValue, size);
/*      */     } else {
/*  287 */       this._filterContext = this._filterContext.createChildArrayContext(this._itemFilter, false);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeEndArray() throws IOException {
/*  294 */     this._filterContext = this._filterContext.closeArray(this.delegate);
/*      */     
/*  296 */     if (this._filterContext != null) {
/*  297 */       this._itemFilter = this._filterContext.getFilter();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeStartObject() throws IOException {
/*  304 */     if (this._itemFilter == null) {
/*  305 */       this._filterContext = this._filterContext.createChildObjectContext(this._itemFilter, false);
/*      */       return;
/*      */     } 
/*  308 */     if (this._itemFilter == TokenFilter.INCLUDE_ALL) {
/*  309 */       this._filterContext = this._filterContext.createChildObjectContext(this._itemFilter, true);
/*  310 */       this.delegate.writeStartObject();
/*      */       
/*      */       return;
/*      */     } 
/*  314 */     TokenFilter f = this._filterContext.checkValue(this._itemFilter);
/*  315 */     if (f == null) {
/*  316 */       this._filterContext = this._filterContext.createChildObjectContext(null, false);
/*      */       
/*      */       return;
/*      */     } 
/*  320 */     if (f != TokenFilter.INCLUDE_ALL) {
/*  321 */       f = f.filterStartObject();
/*      */     }
/*  323 */     if (f == TokenFilter.INCLUDE_ALL) {
/*  324 */       _checkParentPath();
/*  325 */       this._filterContext = this._filterContext.createChildObjectContext(f, true);
/*  326 */       this.delegate.writeStartObject();
/*  327 */     } else if (f != null && this._inclusion == TokenFilter.Inclusion.INCLUDE_NON_NULL) {
/*  328 */       _checkParentPath(false);
/*  329 */       this._filterContext = this._filterContext.createChildObjectContext(f, true);
/*  330 */       this.delegate.writeStartObject();
/*      */     } else {
/*  332 */       this._filterContext = this._filterContext.createChildObjectContext(f, false);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeStartObject(Object forValue) throws IOException {
/*  339 */     if (this._itemFilter == null) {
/*  340 */       this._filterContext = this._filterContext.createChildObjectContext(this._itemFilter, false);
/*      */       return;
/*      */     } 
/*  343 */     if (this._itemFilter == TokenFilter.INCLUDE_ALL) {
/*  344 */       this._filterContext = this._filterContext.createChildObjectContext(this._itemFilter, true);
/*  345 */       this.delegate.writeStartObject(forValue);
/*      */       
/*      */       return;
/*      */     } 
/*  349 */     TokenFilter f = this._filterContext.checkValue(this._itemFilter);
/*  350 */     if (f == null) {
/*  351 */       this._filterContext = this._filterContext.createChildObjectContext(null, false);
/*      */       
/*      */       return;
/*      */     } 
/*  355 */     if (f != TokenFilter.INCLUDE_ALL) {
/*  356 */       f = f.filterStartObject();
/*      */     }
/*  358 */     if (f == TokenFilter.INCLUDE_ALL) {
/*  359 */       _checkParentPath();
/*  360 */       this._filterContext = this._filterContext.createChildObjectContext(f, true);
/*  361 */       this.delegate.writeStartObject(forValue);
/*  362 */     } else if (f != null && this._inclusion == TokenFilter.Inclusion.INCLUDE_NON_NULL) {
/*  363 */       _checkParentPath(false);
/*  364 */       this._filterContext = this._filterContext.createChildObjectContext(f, true);
/*  365 */       this.delegate.writeStartObject(forValue);
/*      */     } else {
/*  367 */       this._filterContext = this._filterContext.createChildObjectContext(f, false);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeStartObject(Object forValue, int size) throws IOException {
/*  374 */     if (this._itemFilter == null) {
/*  375 */       this._filterContext = this._filterContext.createChildObjectContext(this._itemFilter, false);
/*      */       return;
/*      */     } 
/*  378 */     if (this._itemFilter == TokenFilter.INCLUDE_ALL) {
/*  379 */       this._filterContext = this._filterContext.createChildObjectContext(this._itemFilter, true);
/*  380 */       this.delegate.writeStartObject(forValue, size);
/*      */       
/*      */       return;
/*      */     } 
/*  384 */     TokenFilter f = this._filterContext.checkValue(this._itemFilter);
/*  385 */     if (f == null) {
/*  386 */       this._filterContext = this._filterContext.createChildObjectContext(null, false);
/*      */       
/*      */       return;
/*      */     } 
/*  390 */     if (f != TokenFilter.INCLUDE_ALL) {
/*  391 */       f = f.filterStartObject();
/*      */     }
/*  393 */     if (f == TokenFilter.INCLUDE_ALL) {
/*  394 */       _checkParentPath();
/*  395 */       this._filterContext = this._filterContext.createChildObjectContext(f, true);
/*  396 */       this.delegate.writeStartObject(forValue, size);
/*      */     } else {
/*  398 */       this._filterContext = this._filterContext.createChildObjectContext(f, false);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeEndObject() throws IOException {
/*  405 */     this._filterContext = this._filterContext.closeObject(this.delegate);
/*  406 */     if (this._filterContext != null) {
/*  407 */       this._itemFilter = this._filterContext.getFilter();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeFieldName(String name) throws IOException {
/*  414 */     TokenFilter state = this._filterContext.setFieldName(name);
/*  415 */     if (state == null) {
/*  416 */       this._itemFilter = null;
/*      */       return;
/*      */     } 
/*  419 */     if (state == TokenFilter.INCLUDE_ALL) {
/*  420 */       this._itemFilter = state;
/*  421 */       this.delegate.writeFieldName(name);
/*      */       return;
/*      */     } 
/*  424 */     state = state.includeProperty(name);
/*  425 */     this._itemFilter = state;
/*  426 */     if (state == TokenFilter.INCLUDE_ALL) {
/*  427 */       _checkPropertyParentPath();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeFieldName(SerializableString name) throws IOException {
/*  434 */     TokenFilter state = this._filterContext.setFieldName(name.getValue());
/*  435 */     if (state == null) {
/*  436 */       this._itemFilter = null;
/*      */       return;
/*      */     } 
/*  439 */     if (state == TokenFilter.INCLUDE_ALL) {
/*  440 */       this._itemFilter = state;
/*  441 */       this.delegate.writeFieldName(name);
/*      */       return;
/*      */     } 
/*  444 */     state = state.includeProperty(name.getValue());
/*  445 */     this._itemFilter = state;
/*  446 */     if (state == TokenFilter.INCLUDE_ALL) {
/*  447 */       _checkPropertyParentPath();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeFieldId(long id) throws IOException {
/*  454 */     writeFieldName(Long.toString(id));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeString(String value) throws IOException {
/*  466 */     if (this._itemFilter == null) {
/*      */       return;
/*      */     }
/*  469 */     if (this._itemFilter != TokenFilter.INCLUDE_ALL) {
/*  470 */       TokenFilter state = this._filterContext.checkValue(this._itemFilter);
/*  471 */       if (state == null) {
/*      */         return;
/*      */       }
/*  474 */       if (state != TokenFilter.INCLUDE_ALL && 
/*  475 */         !state.includeString(value)) {
/*      */         return;
/*      */       }
/*      */       
/*  479 */       _checkParentPath();
/*      */     } 
/*  481 */     this.delegate.writeString(value);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeString(char[] text, int offset, int len) throws IOException {
/*  487 */     if (this._itemFilter == null) {
/*      */       return;
/*      */     }
/*  490 */     if (this._itemFilter != TokenFilter.INCLUDE_ALL) {
/*  491 */       String value = new String(text, offset, len);
/*  492 */       TokenFilter state = this._filterContext.checkValue(this._itemFilter);
/*  493 */       if (state == null) {
/*      */         return;
/*      */       }
/*  496 */       if (state != TokenFilter.INCLUDE_ALL && 
/*  497 */         !state.includeString(value)) {
/*      */         return;
/*      */       }
/*      */       
/*  501 */       _checkParentPath();
/*      */     } 
/*  503 */     this.delegate.writeString(text, offset, len);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeString(SerializableString value) throws IOException {
/*  509 */     if (this._itemFilter == null) {
/*      */       return;
/*      */     }
/*  512 */     if (this._itemFilter != TokenFilter.INCLUDE_ALL) {
/*  513 */       TokenFilter state = this._filterContext.checkValue(this._itemFilter);
/*  514 */       if (state == null) {
/*      */         return;
/*      */       }
/*  517 */       if (state != TokenFilter.INCLUDE_ALL && 
/*  518 */         !state.includeString(value.getValue())) {
/*      */         return;
/*      */       }
/*      */       
/*  522 */       _checkParentPath();
/*      */     } 
/*  524 */     this.delegate.writeString(value);
/*      */   }
/*      */ 
/*      */   
/*      */   public void writeString(Reader reader, int len) throws IOException {
/*  529 */     if (this._itemFilter == null) {
/*      */       return;
/*      */     }
/*  532 */     if (this._itemFilter != TokenFilter.INCLUDE_ALL) {
/*  533 */       TokenFilter state = this._filterContext.checkValue(this._itemFilter);
/*  534 */       if (state == null) {
/*      */         return;
/*      */       }
/*  537 */       if (state != TokenFilter.INCLUDE_ALL)
/*      */       {
/*      */         
/*  540 */         if (!state.includeString(reader, len)) {
/*      */           return;
/*      */         }
/*      */       }
/*  544 */       _checkParentPath();
/*      */     } 
/*  546 */     this.delegate.writeString(reader, len);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeRawUTF8String(byte[] text, int offset, int length) throws IOException {
/*  552 */     if (_checkRawValueWrite()) {
/*  553 */       this.delegate.writeRawUTF8String(text, offset, length);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeUTF8String(byte[] text, int offset, int length) throws IOException {
/*  561 */     if (_checkRawValueWrite()) {
/*  562 */       this.delegate.writeUTF8String(text, offset, length);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeRaw(String text) throws IOException {
/*  575 */     if (_checkRawValueWrite()) {
/*  576 */       this.delegate.writeRaw(text);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeRaw(String text, int offset, int len) throws IOException {
/*  583 */     if (_checkRawValueWrite()) {
/*  584 */       this.delegate.writeRaw(text, offset, len);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeRaw(SerializableString text) throws IOException {
/*  591 */     if (_checkRawValueWrite()) {
/*  592 */       this.delegate.writeRaw(text);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeRaw(char[] text, int offset, int len) throws IOException {
/*  599 */     if (_checkRawValueWrite()) {
/*  600 */       this.delegate.writeRaw(text, offset, len);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeRaw(char c) throws IOException {
/*  607 */     if (_checkRawValueWrite()) {
/*  608 */       this.delegate.writeRaw(c);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeRawValue(String text) throws IOException {
/*  615 */     if (_checkRawValueWrite()) {
/*  616 */       this.delegate.writeRawValue(text);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeRawValue(String text, int offset, int len) throws IOException {
/*  623 */     if (_checkRawValueWrite()) {
/*  624 */       this.delegate.writeRawValue(text, offset, len);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeRawValue(char[] text, int offset, int len) throws IOException {
/*  631 */     if (_checkRawValueWrite()) {
/*  632 */       this.delegate.writeRawValue(text, offset, len);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeBinary(Base64Variant b64variant, byte[] data, int offset, int len) throws IOException {
/*  639 */     if (_checkBinaryWrite()) {
/*  640 */       this.delegate.writeBinary(b64variant, data, offset, len);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int writeBinary(Base64Variant b64variant, InputStream data, int dataLength) throws IOException {
/*  647 */     if (_checkBinaryWrite()) {
/*  648 */       return this.delegate.writeBinary(b64variant, data, dataLength);
/*      */     }
/*  650 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumber(short v) throws IOException {
/*  662 */     if (this._itemFilter == null) {
/*      */       return;
/*      */     }
/*  665 */     if (this._itemFilter != TokenFilter.INCLUDE_ALL) {
/*  666 */       TokenFilter state = this._filterContext.checkValue(this._itemFilter);
/*  667 */       if (state == null) {
/*      */         return;
/*      */       }
/*  670 */       if (state != TokenFilter.INCLUDE_ALL && 
/*  671 */         !state.includeNumber(v)) {
/*      */         return;
/*      */       }
/*      */       
/*  675 */       _checkParentPath();
/*      */     } 
/*  677 */     this.delegate.writeNumber(v);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumber(int v) throws IOException {
/*  683 */     if (this._itemFilter == null) {
/*      */       return;
/*      */     }
/*  686 */     if (this._itemFilter != TokenFilter.INCLUDE_ALL) {
/*  687 */       TokenFilter state = this._filterContext.checkValue(this._itemFilter);
/*  688 */       if (state == null) {
/*      */         return;
/*      */       }
/*  691 */       if (state != TokenFilter.INCLUDE_ALL && 
/*  692 */         !state.includeNumber(v)) {
/*      */         return;
/*      */       }
/*      */       
/*  696 */       _checkParentPath();
/*      */     } 
/*  698 */     this.delegate.writeNumber(v);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumber(long v) throws IOException {
/*  704 */     if (this._itemFilter == null) {
/*      */       return;
/*      */     }
/*  707 */     if (this._itemFilter != TokenFilter.INCLUDE_ALL) {
/*  708 */       TokenFilter state = this._filterContext.checkValue(this._itemFilter);
/*  709 */       if (state == null) {
/*      */         return;
/*      */       }
/*  712 */       if (state != TokenFilter.INCLUDE_ALL && 
/*  713 */         !state.includeNumber(v)) {
/*      */         return;
/*      */       }
/*      */       
/*  717 */       _checkParentPath();
/*      */     } 
/*  719 */     this.delegate.writeNumber(v);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumber(BigInteger v) throws IOException {
/*  725 */     if (this._itemFilter == null) {
/*      */       return;
/*      */     }
/*  728 */     if (this._itemFilter != TokenFilter.INCLUDE_ALL) {
/*  729 */       TokenFilter state = this._filterContext.checkValue(this._itemFilter);
/*  730 */       if (state == null) {
/*      */         return;
/*      */       }
/*  733 */       if (state != TokenFilter.INCLUDE_ALL && 
/*  734 */         !state.includeNumber(v)) {
/*      */         return;
/*      */       }
/*      */       
/*  738 */       _checkParentPath();
/*      */     } 
/*  740 */     this.delegate.writeNumber(v);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumber(double v) throws IOException {
/*  746 */     if (this._itemFilter == null) {
/*      */       return;
/*      */     }
/*  749 */     if (this._itemFilter != TokenFilter.INCLUDE_ALL) {
/*  750 */       TokenFilter state = this._filterContext.checkValue(this._itemFilter);
/*  751 */       if (state == null) {
/*      */         return;
/*      */       }
/*  754 */       if (state != TokenFilter.INCLUDE_ALL && 
/*  755 */         !state.includeNumber(v)) {
/*      */         return;
/*      */       }
/*      */       
/*  759 */       _checkParentPath();
/*      */     } 
/*  761 */     this.delegate.writeNumber(v);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumber(float v) throws IOException {
/*  767 */     if (this._itemFilter == null) {
/*      */       return;
/*      */     }
/*  770 */     if (this._itemFilter != TokenFilter.INCLUDE_ALL) {
/*  771 */       TokenFilter state = this._filterContext.checkValue(this._itemFilter);
/*  772 */       if (state == null) {
/*      */         return;
/*      */       }
/*  775 */       if (state != TokenFilter.INCLUDE_ALL && 
/*  776 */         !state.includeNumber(v)) {
/*      */         return;
/*      */       }
/*      */       
/*  780 */       _checkParentPath();
/*      */     } 
/*  782 */     this.delegate.writeNumber(v);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumber(BigDecimal v) throws IOException {
/*  788 */     if (this._itemFilter == null) {
/*      */       return;
/*      */     }
/*  791 */     if (this._itemFilter != TokenFilter.INCLUDE_ALL) {
/*  792 */       TokenFilter state = this._filterContext.checkValue(this._itemFilter);
/*  793 */       if (state == null) {
/*      */         return;
/*      */       }
/*  796 */       if (state != TokenFilter.INCLUDE_ALL && 
/*  797 */         !state.includeNumber(v)) {
/*      */         return;
/*      */       }
/*      */       
/*  801 */       _checkParentPath();
/*      */     } 
/*  803 */     this.delegate.writeNumber(v);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumber(String encodedValue) throws IOException, UnsupportedOperationException {
/*  809 */     if (this._itemFilter == null) {
/*      */       return;
/*      */     }
/*  812 */     if (this._itemFilter != TokenFilter.INCLUDE_ALL) {
/*  813 */       TokenFilter state = this._filterContext.checkValue(this._itemFilter);
/*  814 */       if (state == null) {
/*      */         return;
/*      */       }
/*  817 */       if (state != TokenFilter.INCLUDE_ALL && 
/*  818 */         !state.includeRawValue()) {
/*      */         return;
/*      */       }
/*      */       
/*  822 */       _checkParentPath();
/*      */     } 
/*  824 */     this.delegate.writeNumber(encodedValue);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumber(char[] encodedValueBuffer, int offset, int length) throws IOException, UnsupportedOperationException {
/*  830 */     if (this._itemFilter == null) {
/*      */       return;
/*      */     }
/*  833 */     if (this._itemFilter != TokenFilter.INCLUDE_ALL) {
/*  834 */       TokenFilter state = this._filterContext.checkValue(this._itemFilter);
/*  835 */       if (state == null) {
/*      */         return;
/*      */       }
/*  838 */       if (state != TokenFilter.INCLUDE_ALL && 
/*  839 */         !state.includeRawValue()) {
/*      */         return;
/*      */       }
/*      */       
/*  843 */       _checkParentPath();
/*      */     } 
/*  845 */     this.delegate.writeNumber(encodedValueBuffer, offset, length);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeBoolean(boolean v) throws IOException {
/*  851 */     if (this._itemFilter == null) {
/*      */       return;
/*      */     }
/*  854 */     if (this._itemFilter != TokenFilter.INCLUDE_ALL) {
/*  855 */       TokenFilter state = this._filterContext.checkValue(this._itemFilter);
/*  856 */       if (state == null) {
/*      */         return;
/*      */       }
/*  859 */       if (state != TokenFilter.INCLUDE_ALL && 
/*  860 */         !state.includeBoolean(v)) {
/*      */         return;
/*      */       }
/*      */       
/*  864 */       _checkParentPath();
/*      */     } 
/*  866 */     this.delegate.writeBoolean(v);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNull() throws IOException {
/*  872 */     if (this._itemFilter == null) {
/*      */       return;
/*      */     }
/*  875 */     if (this._itemFilter != TokenFilter.INCLUDE_ALL) {
/*  876 */       TokenFilter state = this._filterContext.checkValue(this._itemFilter);
/*  877 */       if (state == null) {
/*      */         return;
/*      */       }
/*  880 */       if (state != TokenFilter.INCLUDE_ALL && 
/*  881 */         !state.includeNull()) {
/*      */         return;
/*      */       }
/*      */       
/*  885 */       _checkParentPath();
/*      */     } 
/*  887 */     this.delegate.writeNull();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeOmittedField(String fieldName) throws IOException {
/*  899 */     if (this._itemFilter != null) {
/*  900 */       this.delegate.writeOmittedField(fieldName);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeObjectId(Object id) throws IOException {
/*  915 */     if (this._itemFilter != null) {
/*  916 */       this.delegate.writeObjectId(id);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void writeObjectRef(Object id) throws IOException {
/*  922 */     if (this._itemFilter != null) {
/*  923 */       this.delegate.writeObjectRef(id);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void writeTypeId(Object id) throws IOException {
/*  929 */     if (this._itemFilter != null) {
/*  930 */       this.delegate.writeTypeId(id);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _checkParentPath() throws IOException {
/* 1009 */     _checkParentPath(true);
/*      */   }
/*      */ 
/*      */   
/*      */   protected void _checkParentPath(boolean isMatch) throws IOException {
/* 1014 */     if (isMatch) {
/* 1015 */       this._matchCount++;
/*      */     }
/*      */     
/* 1018 */     if (this._inclusion == TokenFilter.Inclusion.INCLUDE_ALL_AND_PATH) {
/* 1019 */       this._filterContext.writePath(this.delegate);
/* 1020 */     } else if (this._inclusion == TokenFilter.Inclusion.INCLUDE_NON_NULL) {
/*      */       
/* 1022 */       this._filterContext.ensureFieldNameWritten(this.delegate);
/*      */     } 
/*      */     
/* 1025 */     if (isMatch && !this._allowMultipleMatches)
/*      */     {
/* 1027 */       this._filterContext.skipParentChecks();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _checkPropertyParentPath() throws IOException {
/* 1040 */     this._matchCount++;
/* 1041 */     if (this._inclusion == TokenFilter.Inclusion.INCLUDE_ALL_AND_PATH) {
/* 1042 */       this._filterContext.writePath(this.delegate);
/* 1043 */     } else if (this._inclusion == TokenFilter.Inclusion.INCLUDE_NON_NULL) {
/*      */       
/* 1045 */       this._filterContext.ensureFieldNameWritten(this.delegate);
/*      */     } 
/*      */ 
/*      */     
/* 1049 */     if (!this._allowMultipleMatches)
/*      */     {
/* 1051 */       this._filterContext.skipParentChecks();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   protected boolean _checkBinaryWrite() throws IOException {
/* 1057 */     if (this._itemFilter == null) {
/* 1058 */       return false;
/*      */     }
/* 1060 */     if (this._itemFilter == TokenFilter.INCLUDE_ALL) {
/* 1061 */       return true;
/*      */     }
/* 1063 */     if (this._itemFilter.includeBinary()) {
/* 1064 */       _checkParentPath();
/* 1065 */       return true;
/*      */     } 
/* 1067 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   protected boolean _checkRawValueWrite() throws IOException {
/* 1072 */     if (this._itemFilter == null) {
/* 1073 */       return false;
/*      */     }
/* 1075 */     if (this._itemFilter == TokenFilter.INCLUDE_ALL) {
/* 1076 */       return true;
/*      */     }
/* 1078 */     if (this._itemFilter.includeRawValue()) {
/* 1079 */       _checkParentPath();
/* 1080 */       return true;
/*      */     } 
/* 1082 */     return false;
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-core-2.14.2.jar!\com\fasterxml\jackson\core\filter\FilteringGeneratorDelegate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */