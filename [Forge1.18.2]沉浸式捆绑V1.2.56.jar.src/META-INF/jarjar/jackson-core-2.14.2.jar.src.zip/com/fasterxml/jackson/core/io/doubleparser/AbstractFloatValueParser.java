/*    */ package com.fasterxml.jackson.core.io.doubleparser;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class AbstractFloatValueParser
/*    */ {
/*    */   static final long PARSE_ERROR = -1L;
/*    */   static final long MINIMAL_NINETEEN_DIGIT_INTEGER = 1000000000000000000L;
/*    */   static final int MAX_EXPONENT_NUMBER = 1024;
/*    */   static final byte DECIMAL_POINT_CLASS = -4;
/*    */   static final byte OTHER_CLASS = -1;
/* 70 */   static final byte[] CHAR_TO_HEX_MAP = new byte[128];
/*    */   static {
/*    */     char ch;
/* 73 */     for (ch = Character.MIN_VALUE; ch < CHAR_TO_HEX_MAP.length; ch = (char)(ch + 1)) {
/* 74 */       CHAR_TO_HEX_MAP[ch] = -1;
/*    */     }
/* 76 */     for (ch = '0'; ch <= '9'; ch = (char)(ch + 1)) {
/* 77 */       CHAR_TO_HEX_MAP[ch] = (byte)(ch - 48);
/*    */     }
/* 79 */     for (ch = 'A'; ch <= 'F'; ch = (char)(ch + 1)) {
/* 80 */       CHAR_TO_HEX_MAP[ch] = (byte)(ch - 65 + 10);
/*    */     }
/* 82 */     for (ch = 'a'; ch <= 'f'; ch = (char)(ch + 1)) {
/* 83 */       CHAR_TO_HEX_MAP[ch] = (byte)(ch - 97 + 10);
/*    */     }
/* 85 */     for (ch = '.'; ch <= '.'; ch = (char)(ch + 1))
/* 86 */       CHAR_TO_HEX_MAP[ch] = -4; 
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-core-2.14.2.jar!\com\fasterxml\jackson\core\io\doubleparser\AbstractFloatValueParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */