/*     */ package com.fasterxml.jackson.core.io;
/*     */ 
/*     */ import com.fasterxml.jackson.core.io.doubleparser.FastDoubleParser;
/*     */ import com.fasterxml.jackson.core.io.doubleparser.FastFloatParser;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class NumberInput
/*     */ {
/*     */   private static final int LARGE_INT_SIZE = 1250;
/*     */   @Deprecated
/*     */   public static final String NASTY_SMALL_DOUBLE = "2.2250738585072012e-308";
/*     */   static final long L_BILLION = 1000000000L;
/*  29 */   static final String MIN_LONG_STR_NO_SIGN = String.valueOf(Long.MIN_VALUE).substring(1);
/*  30 */   static final String MAX_LONG_STR = String.valueOf(Long.MAX_VALUE);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int parseInt(char[] ch, int off, int len) {
/*  48 */     if (len > 0 && ch[off] == '+') {
/*  49 */       off++;
/*  50 */       len--;
/*     */     } 
/*     */     
/*  53 */     int num = ch[off + len - 1] - 48;
/*     */     
/*  55 */     switch (len) {
/*     */       case 9:
/*  57 */         num += (ch[off++] - 48) * 100000000;
/*     */       case 8:
/*  59 */         num += (ch[off++] - 48) * 10000000;
/*     */       case 7:
/*  61 */         num += (ch[off++] - 48) * 1000000;
/*     */       case 6:
/*  63 */         num += (ch[off++] - 48) * 100000;
/*     */       case 5:
/*  65 */         num += (ch[off++] - 48) * 10000;
/*     */       case 4:
/*  67 */         num += (ch[off++] - 48) * 1000;
/*     */       case 3:
/*  69 */         num += (ch[off++] - 48) * 100;
/*     */       case 2:
/*  71 */         num += (ch[off] - 48) * 10; break;
/*     */     } 
/*  73 */     return num;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int parseInt(String s) {
/*  95 */     char c = s.charAt(0);
/*  96 */     int len = s.length();
/*  97 */     boolean neg = (c == '-');
/*  98 */     int offset = 1;
/*     */ 
/*     */     
/* 101 */     if (neg) {
/* 102 */       if (len == 1 || len > 10) {
/* 103 */         return Integer.parseInt(s);
/*     */       }
/* 105 */       c = s.charAt(offset++);
/*     */     }
/* 107 */     else if (len > 9) {
/* 108 */       return Integer.parseInt(s);
/*     */     } 
/*     */     
/* 111 */     if (c > '9' || c < '0') {
/* 112 */       return Integer.parseInt(s);
/*     */     }
/* 114 */     int num = c - 48;
/* 115 */     if (offset < len) {
/* 116 */       c = s.charAt(offset++);
/* 117 */       if (c > '9' || c < '0') {
/* 118 */         return Integer.parseInt(s);
/*     */       }
/* 120 */       num = num * 10 + c - 48;
/* 121 */       if (offset < len) {
/* 122 */         c = s.charAt(offset++);
/* 123 */         if (c > '9' || c < '0') {
/* 124 */           return Integer.parseInt(s);
/*     */         }
/* 126 */         num = num * 10 + c - 48;
/*     */         
/* 128 */         if (offset < len) {
/*     */           do {
/* 130 */             c = s.charAt(offset++);
/* 131 */             if (c > '9' || c < '0') {
/* 132 */               return Integer.parseInt(s);
/*     */             }
/* 134 */             num = num * 10 + c - 48;
/* 135 */           } while (offset < len);
/*     */         }
/*     */       } 
/*     */     } 
/* 139 */     return neg ? -num : num;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static long parseLong(char[] ch, int off, int len) {
/* 145 */     int len1 = len - 9;
/* 146 */     long val = parseInt(ch, off, len1) * 1000000000L;
/* 147 */     return val + parseInt(ch, off + len1, 9);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long parseLong(String s) {
/* 161 */     int length = s.length();
/* 162 */     if (length <= 9) {
/* 163 */       return parseInt(s);
/*     */     }
/*     */     
/* 166 */     return Long.parseLong(s);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean inLongRange(char[] ch, int off, int len, boolean negative) {
/* 187 */     String cmpStr = negative ? MIN_LONG_STR_NO_SIGN : MAX_LONG_STR;
/* 188 */     int cmpLen = cmpStr.length();
/* 189 */     if (len < cmpLen) return true; 
/* 190 */     if (len > cmpLen) return false;
/*     */     
/* 192 */     for (int i = 0; i < cmpLen; i++) {
/* 193 */       int diff = ch[off + i] - cmpStr.charAt(i);
/* 194 */       if (diff != 0) {
/* 195 */         return (diff < 0);
/*     */       }
/*     */     } 
/* 198 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean inLongRange(String s, boolean negative) {
/* 214 */     String cmp = negative ? MIN_LONG_STR_NO_SIGN : MAX_LONG_STR;
/* 215 */     int cmpLen = cmp.length();
/* 216 */     int alen = s.length();
/* 217 */     if (alen < cmpLen) return true; 
/* 218 */     if (alen > cmpLen) return false;
/*     */ 
/*     */     
/* 221 */     for (int i = 0; i < cmpLen; i++) {
/* 222 */       int diff = s.charAt(i) - cmp.charAt(i);
/* 223 */       if (diff != 0) {
/* 224 */         return (diff < 0);
/*     */       }
/*     */     } 
/* 227 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public static int parseAsInt(String s, int def) {
/* 232 */     if (s == null) {
/* 233 */       return def;
/*     */     }
/* 235 */     s = s.trim();
/* 236 */     int len = s.length();
/* 237 */     if (len == 0) {
/* 238 */       return def;
/*     */     }
/*     */     
/* 241 */     int i = 0;
/*     */     
/* 243 */     char sign = s.charAt(0);
/* 244 */     if (sign == '+') {
/* 245 */       s = s.substring(1);
/* 246 */       len = s.length();
/* 247 */     } else if (sign == '-') {
/* 248 */       i = 1;
/*     */     } 
/* 250 */     for (; i < len; i++) {
/* 251 */       char c = s.charAt(i);
/*     */       
/* 253 */       if (c > '9' || c < '0') {
/*     */         
/*     */         try {
/*     */           
/* 257 */           return (int)parseDouble(s, true);
/* 258 */         } catch (NumberFormatException e) {
/* 259 */           return def;
/*     */         } 
/*     */       }
/*     */     } 
/*     */     try {
/* 264 */       return Integer.parseInt(s);
/* 265 */     } catch (NumberFormatException numberFormatException) {
/* 266 */       return def;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static long parseAsLong(String s, long def) {
/* 271 */     if (s == null) {
/* 272 */       return def;
/*     */     }
/* 274 */     s = s.trim();
/* 275 */     int len = s.length();
/* 276 */     if (len == 0) {
/* 277 */       return def;
/*     */     }
/*     */     
/* 280 */     int i = 0;
/*     */     
/* 282 */     char sign = s.charAt(0);
/* 283 */     if (sign == '+') {
/* 284 */       s = s.substring(1);
/* 285 */       len = s.length();
/* 286 */     } else if (sign == '-') {
/* 287 */       i = 1;
/*     */     } 
/* 289 */     for (; i < len; i++) {
/* 290 */       char c = s.charAt(i);
/*     */       
/* 292 */       if (c > '9' || c < '0') {
/*     */         
/*     */         try {
/*     */           
/* 296 */           return (long)parseDouble(s, true);
/* 297 */         } catch (NumberFormatException e) {
/* 298 */           return def;
/*     */         } 
/*     */       }
/*     */     } 
/*     */     try {
/* 303 */       return Long.parseLong(s);
/* 304 */     } catch (NumberFormatException numberFormatException) {
/* 305 */       return def;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double parseAsDouble(String s, double def) {
/* 316 */     return parseAsDouble(s, def, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double parseAsDouble(String s, double def, boolean useFastParser) {
/* 328 */     if (s == null) return def; 
/* 329 */     s = s.trim();
/* 330 */     int len = s.length();
/* 331 */     if (len == 0) {
/* 332 */       return def;
/*     */     }
/*     */     try {
/* 335 */       return parseDouble(s, useFastParser);
/* 336 */     } catch (NumberFormatException numberFormatException) {
/* 337 */       return def;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double parseDouble(String s) throws NumberFormatException {
/* 347 */     return parseDouble(s, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double parseDouble(String s, boolean useFastParser) throws NumberFormatException {
/* 358 */     return useFastParser ? FastDoubleParser.parseDouble(s) : Double.parseDouble(s);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static float parseFloat(String s) throws NumberFormatException {
/* 369 */     return parseFloat(s, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static float parseFloat(String s, boolean useFastParser) throws NumberFormatException {
/* 380 */     return useFastParser ? FastFloatParser.parseFloat(s) : Float.parseFloat(s);
/*     */   }
/*     */   
/*     */   public static BigDecimal parseBigDecimal(String s) throws NumberFormatException {
/* 384 */     return BigDecimalParser.parse(s);
/*     */   }
/*     */   
/*     */   public static BigDecimal parseBigDecimal(char[] ch, int off, int len) throws NumberFormatException {
/* 388 */     return BigDecimalParser.parse(ch, off, len);
/*     */   }
/*     */   
/*     */   public static BigDecimal parseBigDecimal(char[] ch) throws NumberFormatException {
/* 392 */     return BigDecimalParser.parse(ch);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BigInteger parseBigInteger(String s) throws NumberFormatException {
/* 402 */     if (s.length() > 1250) {
/* 403 */       return BigDecimalParser.parse(s).toBigInteger();
/*     */     }
/* 405 */     return new BigInteger(s);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-core-2.14.2.jar!\com\fasterxml\jackson\core\io\NumberInput.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */