/*      */ package com.fasterxml.jackson.core.util;
/*      */ 
/*      */ import com.fasterxml.jackson.core.io.NumberInput;
/*      */ import java.io.IOException;
/*      */ import java.io.Writer;
/*      */ import java.math.BigDecimal;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class TextBuffer
/*      */ {
/*   29 */   static final char[] NO_CHARS = new char[0];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final int MIN_SEGMENT_LEN = 500;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final int MAX_SEGMENT_LEN = 65536;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final BufferRecycler _allocator;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private char[] _inputBuffer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int _inputStart;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int _inputLen;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ArrayList<char[]> _segments;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean _hasSegments;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int _segmentSize;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private char[] _currentSegment;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int _currentSize;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String _resultString;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private char[] _resultArray;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TextBuffer(BufferRecycler allocator) {
/*  124 */     this._allocator = allocator;
/*      */   }
/*      */ 
/*      */   
/*      */   protected TextBuffer(BufferRecycler allocator, char[] initialSegment) {
/*  129 */     this._allocator = allocator;
/*  130 */     this._currentSegment = initialSegment;
/*  131 */     this._currentSize = initialSegment.length;
/*  132 */     this._inputStart = -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static TextBuffer fromInitial(char[] initialSegment) {
/*  147 */     return new TextBuffer(null, initialSegment);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void releaseBuffers() {
/*  165 */     this._inputStart = -1;
/*  166 */     this._currentSize = 0;
/*  167 */     this._inputLen = 0;
/*      */     
/*  169 */     this._inputBuffer = null;
/*      */ 
/*      */     
/*  172 */     this._resultArray = null;
/*      */     
/*  174 */     if (this._hasSegments) {
/*  175 */       clearSegments();
/*      */     }
/*      */ 
/*      */     
/*  179 */     if (this._allocator != null && 
/*  180 */       this._currentSegment != null) {
/*      */       
/*  182 */       char[] buf = this._currentSegment;
/*  183 */       this._currentSegment = null;
/*  184 */       this._allocator.releaseCharBuffer(2, buf);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void resetWithEmpty() {
/*  195 */     this._inputStart = -1;
/*  196 */     this._currentSize = 0;
/*  197 */     this._inputLen = 0;
/*      */     
/*  199 */     this._inputBuffer = null;
/*  200 */     this._resultString = null;
/*  201 */     this._resultArray = null;
/*      */ 
/*      */     
/*  204 */     if (this._hasSegments) {
/*  205 */       clearSegments();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void resetWith(char ch) {
/*  219 */     this._inputStart = -1;
/*  220 */     this._inputLen = 0;
/*      */     
/*  222 */     this._resultString = null;
/*  223 */     this._resultArray = null;
/*      */     
/*  225 */     if (this._hasSegments) {
/*  226 */       clearSegments();
/*  227 */     } else if (this._currentSegment == null) {
/*  228 */       this._currentSegment = buf(1);
/*      */     } 
/*  230 */     this._currentSegment[0] = ch;
/*  231 */     this._currentSize = this._segmentSize = 1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void resetWithShared(char[] buf, int offset, int len) {
/*  247 */     this._resultString = null;
/*  248 */     this._resultArray = null;
/*      */ 
/*      */     
/*  251 */     this._inputBuffer = buf;
/*  252 */     this._inputStart = offset;
/*  253 */     this._inputLen = len;
/*      */ 
/*      */     
/*  256 */     if (this._hasSegments) {
/*  257 */       clearSegments();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void resetWithCopy(char[] buf, int offset, int len) {
/*  263 */     this._inputBuffer = null;
/*  264 */     this._inputStart = -1;
/*  265 */     this._inputLen = 0;
/*      */     
/*  267 */     this._resultString = null;
/*  268 */     this._resultArray = null;
/*      */ 
/*      */     
/*  271 */     if (this._hasSegments) {
/*  272 */       clearSegments();
/*  273 */     } else if (this._currentSegment == null) {
/*  274 */       this._currentSegment = buf(len);
/*      */     } 
/*  276 */     this._currentSize = this._segmentSize = 0;
/*  277 */     append(buf, offset, len);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void resetWithCopy(String text, int start, int len) {
/*  283 */     this._inputBuffer = null;
/*  284 */     this._inputStart = -1;
/*  285 */     this._inputLen = 0;
/*      */     
/*  287 */     this._resultString = null;
/*  288 */     this._resultArray = null;
/*      */     
/*  290 */     if (this._hasSegments) {
/*  291 */       clearSegments();
/*  292 */     } else if (this._currentSegment == null) {
/*  293 */       this._currentSegment = buf(len);
/*      */     } 
/*  295 */     this._currentSize = this._segmentSize = 0;
/*  296 */     append(text, start, len);
/*      */   }
/*      */ 
/*      */   
/*      */   public void resetWithString(String value) {
/*  301 */     this._inputBuffer = null;
/*  302 */     this._inputStart = -1;
/*  303 */     this._inputLen = 0;
/*      */     
/*  305 */     this._resultString = value;
/*  306 */     this._resultArray = null;
/*      */     
/*  308 */     if (this._hasSegments) {
/*  309 */       clearSegments();
/*      */     }
/*  311 */     this._currentSize = 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public char[] getBufferWithoutReset() {
/*  324 */     return this._currentSegment;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private char[] buf(int needed) {
/*  331 */     if (this._allocator != null) {
/*  332 */       return this._allocator.allocCharBuffer(2, needed);
/*      */     }
/*  334 */     return new char[Math.max(needed, 500)];
/*      */   }
/*      */ 
/*      */   
/*      */   private void clearSegments() {
/*  339 */     this._hasSegments = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  347 */     this._segments.clear();
/*  348 */     this._currentSize = this._segmentSize = 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int size() {
/*  361 */     if (this._inputStart >= 0) {
/*  362 */       return this._inputLen;
/*      */     }
/*  364 */     if (this._resultArray != null) {
/*  365 */       return this._resultArray.length;
/*      */     }
/*  367 */     if (this._resultString != null) {
/*  368 */       return this._resultString.length();
/*      */     }
/*      */     
/*  371 */     return this._segmentSize + this._currentSize;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getTextOffset() {
/*  379 */     return (this._inputStart >= 0) ? this._inputStart : 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hasTextAsCharacters() {
/*  392 */     if (this._inputStart >= 0 || this._resultArray != null) return true;
/*      */     
/*  394 */     if (this._resultString != null) return false; 
/*  395 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public char[] getTextBuffer() {
/*  408 */     if (this._inputStart >= 0) return this._inputBuffer; 
/*  409 */     if (this._resultArray != null) return this._resultArray; 
/*  410 */     if (this._resultString != null) {
/*  411 */       return this._resultArray = this._resultString.toCharArray();
/*      */     }
/*      */     
/*  414 */     if (!this._hasSegments) {
/*  415 */       return (this._currentSegment == null) ? NO_CHARS : this._currentSegment;
/*      */     }
/*      */     
/*  418 */     return contentsAsArray();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String contentsAsString() {
/*  436 */     if (this._resultString == null)
/*      */     {
/*  438 */       if (this._resultArray != null) {
/*  439 */         this._resultString = new String(this._resultArray);
/*      */       
/*      */       }
/*  442 */       else if (this._inputStart >= 0) {
/*  443 */         if (this._inputLen < 1) {
/*  444 */           return this._resultString = "";
/*      */         }
/*  446 */         this._resultString = new String(this._inputBuffer, this._inputStart, this._inputLen);
/*      */       } else {
/*      */         
/*  449 */         int segLen = this._segmentSize;
/*  450 */         int currLen = this._currentSize;
/*      */         
/*  452 */         if (segLen == 0) {
/*  453 */           this._resultString = (currLen == 0) ? "" : new String(this._currentSegment, 0, currLen);
/*      */         } else {
/*  455 */           StringBuilder sb = new StringBuilder(segLen + currLen);
/*      */           
/*  457 */           if (this._segments != null) {
/*  458 */             for (int i = 0, len = this._segments.size(); i < len; i++) {
/*  459 */               char[] curr = this._segments.get(i);
/*  460 */               sb.append(curr, 0, curr.length);
/*      */             } 
/*      */           }
/*      */           
/*  464 */           sb.append(this._currentSegment, 0, this._currentSize);
/*  465 */           this._resultString = sb.toString();
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*  471 */     return this._resultString;
/*      */   }
/*      */   
/*      */   public char[] contentsAsArray() {
/*  475 */     char[] result = this._resultArray;
/*  476 */     if (result == null) {
/*  477 */       this._resultArray = result = resultArray();
/*      */     }
/*  479 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BigDecimal contentsAsDecimal() throws NumberFormatException {
/*  493 */     if (this._resultArray != null) {
/*  494 */       return NumberInput.parseBigDecimal(this._resultArray);
/*      */     }
/*      */     
/*  497 */     if (this._inputStart >= 0 && this._inputBuffer != null) {
/*  498 */       return NumberInput.parseBigDecimal(this._inputBuffer, this._inputStart, this._inputLen);
/*      */     }
/*      */     
/*  501 */     if (this._segmentSize == 0 && this._currentSegment != null) {
/*  502 */       return NumberInput.parseBigDecimal(this._currentSegment, 0, this._currentSize);
/*      */     }
/*      */     
/*  505 */     return NumberInput.parseBigDecimal(contentsAsArray());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public double contentsAsDouble() throws NumberFormatException {
/*  519 */     return contentsAsDouble(false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double contentsAsDouble(boolean useFastParser) throws NumberFormatException {
/*  533 */     return NumberInput.parseDouble(contentsAsString(), useFastParser);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public float contentsAsFloat() throws NumberFormatException {
/*  548 */     return contentsAsFloat(false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float contentsAsFloat(boolean useFastParser) throws NumberFormatException {
/*  562 */     return NumberInput.parseFloat(contentsAsString(), useFastParser);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int contentsAsInt(boolean neg) {
/*  581 */     if (this._inputStart >= 0 && this._inputBuffer != null) {
/*  582 */       if (neg) {
/*  583 */         return -NumberInput.parseInt(this._inputBuffer, this._inputStart + 1, this._inputLen - 1);
/*      */       }
/*  585 */       return NumberInput.parseInt(this._inputBuffer, this._inputStart, this._inputLen);
/*      */     } 
/*  587 */     if (neg) {
/*  588 */       return -NumberInput.parseInt(this._currentSegment, 1, this._currentSize - 1);
/*      */     }
/*  590 */     return NumberInput.parseInt(this._currentSegment, 0, this._currentSize);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long contentsAsLong(boolean neg) {
/*  609 */     if (this._inputStart >= 0 && this._inputBuffer != null) {
/*  610 */       if (neg) {
/*  611 */         return -NumberInput.parseLong(this._inputBuffer, this._inputStart + 1, this._inputLen - 1);
/*      */       }
/*  613 */       return NumberInput.parseLong(this._inputBuffer, this._inputStart, this._inputLen);
/*      */     } 
/*  615 */     if (neg) {
/*  616 */       return -NumberInput.parseLong(this._currentSegment, 1, this._currentSize - 1);
/*      */     }
/*  618 */     return NumberInput.parseLong(this._currentSegment, 0, this._currentSize);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int contentsToWriter(Writer w) throws IOException {
/*  634 */     if (this._resultArray != null) {
/*  635 */       w.write(this._resultArray);
/*  636 */       return this._resultArray.length;
/*      */     } 
/*  638 */     if (this._resultString != null) {
/*  639 */       w.write(this._resultString);
/*  640 */       return this._resultString.length();
/*      */     } 
/*      */     
/*  643 */     if (this._inputStart >= 0) {
/*  644 */       int i = this._inputLen;
/*  645 */       if (i > 0) {
/*  646 */         w.write(this._inputBuffer, this._inputStart, i);
/*      */       }
/*  648 */       return i;
/*      */     } 
/*      */     
/*  651 */     int total = 0;
/*  652 */     if (this._segments != null) {
/*  653 */       for (int i = 0, end = this._segments.size(); i < end; i++) {
/*  654 */         char[] curr = this._segments.get(i);
/*  655 */         int currLen = curr.length;
/*  656 */         w.write(curr, 0, currLen);
/*  657 */         total += currLen;
/*      */       } 
/*      */     }
/*  660 */     int len = this._currentSize;
/*  661 */     if (len > 0) {
/*  662 */       w.write(this._currentSegment, 0, len);
/*  663 */       total += len;
/*      */     } 
/*  665 */     return total;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ensureNotShared() {
/*  679 */     if (this._inputStart >= 0) {
/*  680 */       unshare(16);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void append(char c) {
/*  686 */     if (this._inputStart >= 0) {
/*  687 */       unshare(16);
/*      */     }
/*  689 */     this._resultString = null;
/*  690 */     this._resultArray = null;
/*      */     
/*  692 */     char[] curr = this._currentSegment;
/*  693 */     if (this._currentSize >= curr.length) {
/*  694 */       expand(1);
/*  695 */       curr = this._currentSegment;
/*      */     } 
/*  697 */     curr[this._currentSize++] = c;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void append(char[] c, int start, int len) {
/*  703 */     if (this._inputStart >= 0) {
/*  704 */       unshare(len);
/*      */     }
/*  706 */     this._resultString = null;
/*  707 */     this._resultArray = null;
/*      */ 
/*      */     
/*  710 */     char[] curr = this._currentSegment;
/*  711 */     int max = curr.length - this._currentSize;
/*      */     
/*  713 */     if (max >= len) {
/*  714 */       System.arraycopy(c, start, curr, this._currentSize, len);
/*  715 */       this._currentSize += len;
/*      */       
/*      */       return;
/*      */     } 
/*  719 */     if (max > 0) {
/*  720 */       System.arraycopy(c, start, curr, this._currentSize, max);
/*  721 */       start += max;
/*  722 */       len -= max;
/*      */     } 
/*      */ 
/*      */     
/*      */     do {
/*  727 */       expand(len);
/*  728 */       int amount = Math.min(this._currentSegment.length, len);
/*  729 */       System.arraycopy(c, start, this._currentSegment, 0, amount);
/*  730 */       this._currentSize += amount;
/*  731 */       start += amount;
/*  732 */       len -= amount;
/*  733 */     } while (len > 0);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void append(String str, int offset, int len) {
/*  739 */     if (this._inputStart >= 0) {
/*  740 */       unshare(len);
/*      */     }
/*  742 */     this._resultString = null;
/*  743 */     this._resultArray = null;
/*      */ 
/*      */     
/*  746 */     char[] curr = this._currentSegment;
/*  747 */     int max = curr.length - this._currentSize;
/*  748 */     if (max >= len) {
/*  749 */       str.getChars(offset, offset + len, curr, this._currentSize);
/*  750 */       this._currentSize += len;
/*      */       
/*      */       return;
/*      */     } 
/*  754 */     if (max > 0) {
/*  755 */       str.getChars(offset, offset + max, curr, this._currentSize);
/*  756 */       len -= max;
/*  757 */       offset += max;
/*      */     } 
/*      */ 
/*      */     
/*      */     do {
/*  762 */       expand(len);
/*  763 */       int amount = Math.min(this._currentSegment.length, len);
/*  764 */       str.getChars(offset, offset + amount, this._currentSegment, 0);
/*  765 */       this._currentSize += amount;
/*  766 */       offset += amount;
/*  767 */       len -= amount;
/*  768 */     } while (len > 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public char[] getCurrentSegment() {
/*  783 */     if (this._inputStart >= 0) {
/*  784 */       unshare(1);
/*      */     } else {
/*  786 */       char[] curr = this._currentSegment;
/*  787 */       if (curr == null) {
/*  788 */         this._currentSegment = buf(0);
/*  789 */       } else if (this._currentSize >= curr.length) {
/*      */         
/*  791 */         expand(1);
/*      */       } 
/*      */     } 
/*  794 */     return this._currentSegment;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public char[] emptyAndGetCurrentSegment() {
/*  800 */     this._inputStart = -1;
/*  801 */     this._currentSize = 0;
/*  802 */     this._inputLen = 0;
/*      */     
/*  804 */     this._inputBuffer = null;
/*  805 */     this._resultString = null;
/*  806 */     this._resultArray = null;
/*      */ 
/*      */     
/*  809 */     if (this._hasSegments) {
/*  810 */       clearSegments();
/*      */     }
/*  812 */     char[] curr = this._currentSegment;
/*  813 */     if (curr == null) {
/*  814 */       this._currentSegment = curr = buf(0);
/*      */     }
/*  816 */     return curr;
/*      */   }
/*      */   
/*  819 */   public int getCurrentSegmentSize() { return this._currentSize; } public void setCurrentLength(int len) {
/*  820 */     this._currentSize = len;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String setCurrentAndReturn(int len) {
/*  835 */     this._currentSize = len;
/*      */     
/*  837 */     if (this._segmentSize > 0) {
/*  838 */       return contentsAsString();
/*      */     }
/*      */     
/*  841 */     int currLen = this._currentSize;
/*  842 */     String str = (currLen == 0) ? "" : new String(this._currentSegment, 0, currLen);
/*  843 */     this._resultString = str;
/*  844 */     return str;
/*      */   }
/*      */   
/*      */   public char[] finishCurrentSegment() {
/*  848 */     if (this._segments == null) {
/*  849 */       this._segments = (ArrayList)new ArrayList<>();
/*      */     }
/*  851 */     this._hasSegments = true;
/*  852 */     this._segments.add(this._currentSegment);
/*  853 */     int oldLen = this._currentSegment.length;
/*  854 */     this._segmentSize += oldLen;
/*  855 */     this._currentSize = 0;
/*      */ 
/*      */     
/*  858 */     int newLen = oldLen + (oldLen >> 1);
/*  859 */     if (newLen < 500) {
/*  860 */       newLen = 500;
/*  861 */     } else if (newLen > 65536) {
/*  862 */       newLen = 65536;
/*      */     } 
/*  864 */     char[] curr = carr(newLen);
/*  865 */     this._currentSegment = curr;
/*  866 */     return curr;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public char[] expandCurrentSegment() {
/*  879 */     char[] curr = this._currentSegment;
/*      */     
/*  881 */     int len = curr.length;
/*  882 */     int newLen = len + (len >> 1);
/*      */     
/*  884 */     if (newLen > 65536) {
/*  885 */       newLen = len + (len >> 2);
/*      */     }
/*  887 */     return this._currentSegment = Arrays.copyOf(curr, newLen);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public char[] expandCurrentSegment(int minSize) {
/*  902 */     char[] curr = this._currentSegment;
/*  903 */     if (curr.length >= minSize) return curr; 
/*  904 */     this._currentSegment = curr = Arrays.copyOf(curr, minSize);
/*  905 */     return curr;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*  919 */     return contentsAsString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void unshare(int needExtra) {
/*  933 */     int sharedLen = this._inputLen;
/*  934 */     this._inputLen = 0;
/*  935 */     char[] inputBuf = this._inputBuffer;
/*  936 */     this._inputBuffer = null;
/*  937 */     int start = this._inputStart;
/*  938 */     this._inputStart = -1;
/*      */ 
/*      */     
/*  941 */     int needed = sharedLen + needExtra;
/*  942 */     if (this._currentSegment == null || needed > this._currentSegment.length) {
/*  943 */       this._currentSegment = buf(needed);
/*      */     }
/*  945 */     if (sharedLen > 0) {
/*  946 */       System.arraycopy(inputBuf, start, this._currentSegment, 0, sharedLen);
/*      */     }
/*  948 */     this._segmentSize = 0;
/*  949 */     this._currentSize = sharedLen;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void expand(int minNewSegmentSize) {
/*  956 */     if (this._segments == null) {
/*  957 */       this._segments = (ArrayList)new ArrayList<>();
/*      */     }
/*  959 */     char[] curr = this._currentSegment;
/*  960 */     this._hasSegments = true;
/*  961 */     this._segments.add(curr);
/*  962 */     this._segmentSize += curr.length;
/*  963 */     this._currentSize = 0;
/*  964 */     int oldLen = curr.length;
/*      */ 
/*      */     
/*  967 */     int newLen = oldLen + (oldLen >> 1);
/*  968 */     if (newLen < 500) {
/*  969 */       newLen = 500;
/*  970 */     } else if (newLen > 65536) {
/*  971 */       newLen = 65536;
/*      */     } 
/*  973 */     this._currentSegment = carr(newLen);
/*      */   }
/*      */ 
/*      */   
/*      */   private char[] resultArray() {
/*  978 */     if (this._resultString != null) {
/*  979 */       return this._resultString.toCharArray();
/*      */     }
/*      */     
/*  982 */     if (this._inputStart >= 0) {
/*  983 */       int len = this._inputLen;
/*  984 */       if (len < 1) {
/*  985 */         return NO_CHARS;
/*      */       }
/*  987 */       int start = this._inputStart;
/*  988 */       if (start == 0) {
/*  989 */         return Arrays.copyOf(this._inputBuffer, len);
/*      */       }
/*  991 */       return Arrays.copyOfRange(this._inputBuffer, start, start + len);
/*      */     } 
/*      */     
/*  994 */     int size = size();
/*  995 */     if (size < 1) {
/*  996 */       return NO_CHARS;
/*      */     }
/*  998 */     int offset = 0;
/*  999 */     char[] result = carr(size);
/* 1000 */     if (this._segments != null) {
/* 1001 */       for (int i = 0, len = this._segments.size(); i < len; i++) {
/* 1002 */         char[] curr = this._segments.get(i);
/* 1003 */         int currLen = curr.length;
/* 1004 */         System.arraycopy(curr, 0, result, offset, currLen);
/* 1005 */         offset += currLen;
/*      */       } 
/*      */     }
/* 1008 */     System.arraycopy(this._currentSegment, 0, result, offset, this._currentSize);
/* 1009 */     return result;
/*      */   }
/*      */   private char[] carr(int len) {
/* 1012 */     return new char[len];
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-core-2.14.2.jar!\com\fasterxml\jackson\cor\\util\TextBuffer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */