/*      */ package com.fasterxml.jackson.core.json;
/*      */ 
/*      */ import com.fasterxml.jackson.core.Base64Variant;
/*      */ import com.fasterxml.jackson.core.JsonGenerationException;
/*      */ import com.fasterxml.jackson.core.JsonGenerator;
/*      */ import com.fasterxml.jackson.core.JsonStreamContext;
/*      */ import com.fasterxml.jackson.core.ObjectCodec;
/*      */ import com.fasterxml.jackson.core.SerializableString;
/*      */ import com.fasterxml.jackson.core.io.CharTypes;
/*      */ import com.fasterxml.jackson.core.io.CharacterEscapes;
/*      */ import com.fasterxml.jackson.core.io.IOContext;
/*      */ import com.fasterxml.jackson.core.io.NumberOutput;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.io.Writer;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ 
/*      */ public class WriterBasedJsonGenerator extends JsonGeneratorImpl {
/*      */   protected static final int SHORT_WRITE = 32;
/*   22 */   protected static final char[] HEX_CHARS_UPPER = CharTypes.copyHexChars(true);
/*   23 */   protected static final char[] HEX_CHARS_LOWER = CharTypes.copyHexChars(false); protected final Writer _writer;
/*      */   
/*      */   private char[] getHexChars() {
/*   26 */     return this._cfgWriteHexUppercase ? HEX_CHARS_UPPER : HEX_CHARS_LOWER;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected char _quoteChar;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected char[] _outputBuffer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _outputHead;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _outputTail;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _outputEnd;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected char[] _entityBuffer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected SerializableString _currentEscape;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected char[] _copyBuffer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public WriterBasedJsonGenerator(IOContext ctxt, int features, ObjectCodec codec, Writer w) {
/*  101 */     this(ctxt, features, codec, w, '"');
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WriterBasedJsonGenerator(IOContext ctxt, int features, ObjectCodec codec, Writer w, char quoteChar) {
/*  110 */     super(ctxt, features, codec);
/*  111 */     this._writer = w;
/*  112 */     this._outputBuffer = ctxt.allocConcatBuffer();
/*  113 */     this._outputEnd = this._outputBuffer.length;
/*  114 */     this._quoteChar = quoteChar;
/*  115 */     if (quoteChar != '"') {
/*  116 */       this._outputEscapes = CharTypes.get7BitOutputEscapes(quoteChar);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getOutputTarget() {
/*  128 */     return this._writer;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getOutputBuffered() {
/*  134 */     int len = this._outputTail - this._outputHead;
/*  135 */     return Math.max(0, len);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean canWriteFormattedNumbers() {
/*  140 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeFieldName(String name) throws IOException {
/*  151 */     int status = this._writeContext.writeFieldName(name);
/*  152 */     if (status == 4) {
/*  153 */       _reportError("Can not write a field name, expecting a value");
/*      */     }
/*  155 */     _writeFieldName(name, (status == 1));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeFieldName(SerializableString name) throws IOException {
/*  162 */     int status = this._writeContext.writeFieldName(name.getValue());
/*  163 */     if (status == 4) {
/*  164 */       _reportError("Can not write a field name, expecting a value");
/*      */     }
/*  166 */     _writeFieldName(name, (status == 1));
/*      */   }
/*      */ 
/*      */   
/*      */   protected final void _writeFieldName(String name, boolean commaBefore) throws IOException {
/*  171 */     if (this._cfgPrettyPrinter != null) {
/*  172 */       _writePPFieldName(name, commaBefore);
/*      */       
/*      */       return;
/*      */     } 
/*  176 */     if (this._outputTail + 1 >= this._outputEnd) {
/*  177 */       _flushBuffer();
/*      */     }
/*  179 */     if (commaBefore) {
/*  180 */       this._outputBuffer[this._outputTail++] = ',';
/*      */     }
/*      */     
/*  183 */     if (this._cfgUnqNames) {
/*  184 */       _writeString(name);
/*      */       
/*      */       return;
/*      */     } 
/*  188 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */     
/*  190 */     _writeString(name);
/*      */     
/*  192 */     if (this._outputTail >= this._outputEnd) {
/*  193 */       _flushBuffer();
/*      */     }
/*  195 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */   }
/*      */ 
/*      */   
/*      */   protected final void _writeFieldName(SerializableString name, boolean commaBefore) throws IOException {
/*  200 */     if (this._cfgPrettyPrinter != null) {
/*  201 */       _writePPFieldName(name, commaBefore);
/*      */       
/*      */       return;
/*      */     } 
/*  205 */     if (this._outputTail + 1 >= this._outputEnd) {
/*  206 */       _flushBuffer();
/*      */     }
/*  208 */     if (commaBefore) {
/*  209 */       this._outputBuffer[this._outputTail++] = ',';
/*      */     }
/*      */     
/*  212 */     if (this._cfgUnqNames) {
/*  213 */       char[] ch = name.asQuotedChars();
/*  214 */       writeRaw(ch, 0, ch.length);
/*      */       
/*      */       return;
/*      */     } 
/*  218 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */ 
/*      */     
/*  221 */     int len = name.appendQuoted(this._outputBuffer, this._outputTail);
/*  222 */     if (len < 0) {
/*  223 */       _writeFieldNameTail(name);
/*      */       return;
/*      */     } 
/*  226 */     this._outputTail += len;
/*  227 */     if (this._outputTail >= this._outputEnd) {
/*  228 */       _flushBuffer();
/*      */     }
/*  230 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */   }
/*      */ 
/*      */   
/*      */   private final void _writeFieldNameTail(SerializableString name) throws IOException {
/*  235 */     char[] quoted = name.asQuotedChars();
/*  236 */     writeRaw(quoted, 0, quoted.length);
/*  237 */     if (this._outputTail >= this._outputEnd) {
/*  238 */       _flushBuffer();
/*      */     }
/*  240 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeStartArray() throws IOException {
/*  252 */     _verifyValueWrite("start an array");
/*  253 */     this._writeContext = this._writeContext.createChildArrayContext();
/*  254 */     if (this._cfgPrettyPrinter != null) {
/*  255 */       this._cfgPrettyPrinter.writeStartArray((JsonGenerator)this);
/*      */     } else {
/*  257 */       if (this._outputTail >= this._outputEnd) {
/*  258 */         _flushBuffer();
/*      */       }
/*  260 */       this._outputBuffer[this._outputTail++] = '[';
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeStartArray(Object currentValue) throws IOException {
/*  267 */     _verifyValueWrite("start an array");
/*  268 */     this._writeContext = this._writeContext.createChildArrayContext(currentValue);
/*  269 */     if (this._cfgPrettyPrinter != null) {
/*  270 */       this._cfgPrettyPrinter.writeStartArray((JsonGenerator)this);
/*      */     } else {
/*  272 */       if (this._outputTail >= this._outputEnd) {
/*  273 */         _flushBuffer();
/*      */       }
/*  275 */       this._outputBuffer[this._outputTail++] = '[';
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeStartArray(Object currentValue, int size) throws IOException {
/*  282 */     _verifyValueWrite("start an array");
/*  283 */     this._writeContext = this._writeContext.createChildArrayContext(currentValue);
/*  284 */     if (this._cfgPrettyPrinter != null) {
/*  285 */       this._cfgPrettyPrinter.writeStartArray((JsonGenerator)this);
/*      */     } else {
/*  287 */       if (this._outputTail >= this._outputEnd) {
/*  288 */         _flushBuffer();
/*      */       }
/*  290 */       this._outputBuffer[this._outputTail++] = '[';
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeEndArray() throws IOException {
/*  297 */     if (!this._writeContext.inArray()) {
/*  298 */       _reportError("Current context not Array but " + this._writeContext.typeDesc());
/*      */     }
/*  300 */     if (this._cfgPrettyPrinter != null) {
/*  301 */       this._cfgPrettyPrinter.writeEndArray((JsonGenerator)this, this._writeContext.getEntryCount());
/*      */     } else {
/*  303 */       if (this._outputTail >= this._outputEnd) {
/*  304 */         _flushBuffer();
/*      */       }
/*  306 */       this._outputBuffer[this._outputTail++] = ']';
/*      */     } 
/*  308 */     this._writeContext = this._writeContext.clearAndGetParent();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeStartObject() throws IOException {
/*  314 */     _verifyValueWrite("start an object");
/*  315 */     this._writeContext = this._writeContext.createChildObjectContext();
/*  316 */     if (this._cfgPrettyPrinter != null) {
/*  317 */       this._cfgPrettyPrinter.writeStartObject((JsonGenerator)this);
/*      */     } else {
/*  319 */       if (this._outputTail >= this._outputEnd) {
/*  320 */         _flushBuffer();
/*      */       }
/*  322 */       this._outputBuffer[this._outputTail++] = '{';
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeStartObject(Object forValue) throws IOException {
/*  329 */     _verifyValueWrite("start an object");
/*  330 */     JsonWriteContext ctxt = this._writeContext.createChildObjectContext(forValue);
/*  331 */     this._writeContext = ctxt;
/*  332 */     if (this._cfgPrettyPrinter != null) {
/*  333 */       this._cfgPrettyPrinter.writeStartObject((JsonGenerator)this);
/*      */     } else {
/*  335 */       if (this._outputTail >= this._outputEnd) {
/*  336 */         _flushBuffer();
/*      */       }
/*  338 */       this._outputBuffer[this._outputTail++] = '{';
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void writeStartObject(Object forValue, int size) throws IOException {
/*  344 */     writeStartObject(forValue);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeEndObject() throws IOException {
/*  350 */     if (!this._writeContext.inObject()) {
/*  351 */       _reportError("Current context not Object but " + this._writeContext.typeDesc());
/*      */     }
/*  353 */     if (this._cfgPrettyPrinter != null) {
/*  354 */       this._cfgPrettyPrinter.writeEndObject((JsonGenerator)this, this._writeContext.getEntryCount());
/*      */     } else {
/*  356 */       if (this._outputTail >= this._outputEnd) {
/*  357 */         _flushBuffer();
/*      */       }
/*  359 */       this._outputBuffer[this._outputTail++] = '}';
/*      */     } 
/*  361 */     this._writeContext = this._writeContext.clearAndGetParent();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void _writePPFieldName(String name, boolean commaBefore) throws IOException {
/*  368 */     if (commaBefore) {
/*  369 */       this._cfgPrettyPrinter.writeObjectEntrySeparator((JsonGenerator)this);
/*      */     } else {
/*  371 */       this._cfgPrettyPrinter.beforeObjectEntries((JsonGenerator)this);
/*      */     } 
/*      */     
/*  374 */     if (this._cfgUnqNames) {
/*  375 */       _writeString(name);
/*      */     } else {
/*  377 */       if (this._outputTail >= this._outputEnd) {
/*  378 */         _flushBuffer();
/*      */       }
/*  380 */       this._outputBuffer[this._outputTail++] = this._quoteChar;
/*  381 */       _writeString(name);
/*  382 */       if (this._outputTail >= this._outputEnd) {
/*  383 */         _flushBuffer();
/*      */       }
/*  385 */       this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected final void _writePPFieldName(SerializableString name, boolean commaBefore) throws IOException {
/*  391 */     if (commaBefore) {
/*  392 */       this._cfgPrettyPrinter.writeObjectEntrySeparator((JsonGenerator)this);
/*      */     } else {
/*  394 */       this._cfgPrettyPrinter.beforeObjectEntries((JsonGenerator)this);
/*      */     } 
/*  396 */     char[] quoted = name.asQuotedChars();
/*  397 */     if (this._cfgUnqNames) {
/*  398 */       writeRaw(quoted, 0, quoted.length);
/*      */     } else {
/*  400 */       if (this._outputTail >= this._outputEnd) {
/*  401 */         _flushBuffer();
/*      */       }
/*  403 */       this._outputBuffer[this._outputTail++] = this._quoteChar;
/*  404 */       writeRaw(quoted, 0, quoted.length);
/*  405 */       if (this._outputTail >= this._outputEnd) {
/*  406 */         _flushBuffer();
/*      */       }
/*  408 */       this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeString(String text) throws IOException {
/*  421 */     _verifyValueWrite("write a string");
/*  422 */     if (text == null) {
/*  423 */       _writeNull();
/*      */       return;
/*      */     } 
/*  426 */     if (this._outputTail >= this._outputEnd) {
/*  427 */       _flushBuffer();
/*      */     }
/*  429 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*  430 */     _writeString(text);
/*      */     
/*  432 */     if (this._outputTail >= this._outputEnd) {
/*  433 */       _flushBuffer();
/*      */     }
/*  435 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeString(Reader reader, int len) throws IOException {
/*  441 */     _verifyValueWrite("write a string");
/*  442 */     if (reader == null) {
/*  443 */       _reportError("null reader");
/*      */       return;
/*      */     } 
/*  446 */     int toRead = (len >= 0) ? len : Integer.MAX_VALUE;
/*      */     
/*  448 */     if (this._outputTail >= this._outputEnd) {
/*  449 */       _flushBuffer();
/*      */     }
/*  451 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */     
/*  453 */     char[] buf = _allocateCopyBuffer();
/*  454 */     while (toRead > 0) {
/*  455 */       int toReadNow = Math.min(toRead, buf.length);
/*  456 */       int numRead = reader.read(buf, 0, toReadNow);
/*  457 */       if (numRead <= 0) {
/*      */         break;
/*      */       }
/*  460 */       _writeString(buf, 0, numRead);
/*  461 */       toRead -= numRead;
/*      */     } 
/*      */     
/*  464 */     if (this._outputTail >= this._outputEnd) {
/*  465 */       _flushBuffer();
/*      */     }
/*  467 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */     
/*  469 */     if (toRead > 0 && len >= 0) {
/*  470 */       _reportError("Didn't read enough from reader");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeString(char[] text, int offset, int len) throws IOException {
/*  477 */     _verifyValueWrite("write a string");
/*  478 */     if (this._outputTail >= this._outputEnd) {
/*  479 */       _flushBuffer();
/*      */     }
/*  481 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*  482 */     _writeString(text, offset, len);
/*      */     
/*  484 */     if (this._outputTail >= this._outputEnd) {
/*  485 */       _flushBuffer();
/*      */     }
/*  487 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeString(SerializableString sstr) throws IOException {
/*  493 */     _verifyValueWrite("write a string");
/*  494 */     if (this._outputTail >= this._outputEnd) {
/*  495 */       _flushBuffer();
/*      */     }
/*  497 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*  498 */     int len = sstr.appendQuoted(this._outputBuffer, this._outputTail);
/*  499 */     if (len < 0) {
/*  500 */       _writeString2(sstr);
/*      */       return;
/*      */     } 
/*  503 */     this._outputTail += len;
/*  504 */     if (this._outputTail >= this._outputEnd) {
/*  505 */       _flushBuffer();
/*      */     }
/*  507 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void _writeString2(SerializableString sstr) throws IOException {
/*  513 */     char[] text = sstr.asQuotedChars();
/*  514 */     int len = text.length;
/*  515 */     if (len < 32) {
/*  516 */       int room = this._outputEnd - this._outputTail;
/*  517 */       if (len > room) {
/*  518 */         _flushBuffer();
/*      */       }
/*  520 */       System.arraycopy(text, 0, this._outputBuffer, this._outputTail, len);
/*  521 */       this._outputTail += len;
/*      */     } else {
/*  523 */       _flushBuffer();
/*  524 */       this._writer.write(text, 0, len);
/*      */     } 
/*  526 */     if (this._outputTail >= this._outputEnd) {
/*  527 */       _flushBuffer();
/*      */     }
/*  529 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeRawUTF8String(byte[] text, int offset, int length) throws IOException {
/*  535 */     _reportUnsupportedOperation();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeUTF8String(byte[] text, int offset, int length) throws IOException {
/*  541 */     _reportUnsupportedOperation();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeRaw(String text) throws IOException {
/*  554 */     int len = text.length();
/*  555 */     int room = this._outputEnd - this._outputTail;
/*      */     
/*  557 */     if (room == 0) {
/*  558 */       _flushBuffer();
/*  559 */       room = this._outputEnd - this._outputTail;
/*      */     } 
/*      */     
/*  562 */     if (room >= len) {
/*  563 */       text.getChars(0, len, this._outputBuffer, this._outputTail);
/*  564 */       this._outputTail += len;
/*      */     } else {
/*  566 */       writeRawLong(text);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeRaw(String text, int offset, int len) throws IOException {
/*  573 */     _checkRangeBoundsForString(text, offset, len);
/*      */ 
/*      */     
/*  576 */     int room = this._outputEnd - this._outputTail;
/*      */     
/*  578 */     if (room < len) {
/*  579 */       _flushBuffer();
/*  580 */       room = this._outputEnd - this._outputTail;
/*      */     } 
/*      */     
/*  583 */     if (room >= len) {
/*  584 */       text.getChars(offset, offset + len, this._outputBuffer, this._outputTail);
/*  585 */       this._outputTail += len;
/*      */     } else {
/*  587 */       writeRawLong(text.substring(offset, offset + len));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeRaw(SerializableString text) throws IOException {
/*  594 */     int len = text.appendUnquoted(this._outputBuffer, this._outputTail);
/*  595 */     if (len < 0) {
/*  596 */       writeRaw(text.getValue());
/*      */       return;
/*      */     } 
/*  599 */     this._outputTail += len;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeRaw(char[] cbuf, int offset, int len) throws IOException {
/*  605 */     _checkRangeBoundsForCharArray(cbuf, offset, len);
/*      */ 
/*      */     
/*  608 */     if (len < 32) {
/*  609 */       int room = this._outputEnd - this._outputTail;
/*  610 */       if (len > room) {
/*  611 */         _flushBuffer();
/*      */       }
/*  613 */       System.arraycopy(cbuf, offset, this._outputBuffer, this._outputTail, len);
/*  614 */       this._outputTail += len;
/*      */       
/*      */       return;
/*      */     } 
/*  618 */     _flushBuffer();
/*  619 */     this._writer.write(cbuf, offset, len);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeRaw(char c) throws IOException {
/*  625 */     if (this._outputTail >= this._outputEnd) {
/*  626 */       _flushBuffer();
/*      */     }
/*  628 */     this._outputBuffer[this._outputTail++] = c;
/*      */   }
/*      */ 
/*      */   
/*      */   private void writeRawLong(String text) throws IOException {
/*  633 */     int room = this._outputEnd - this._outputTail;
/*      */     
/*  635 */     text.getChars(0, room, this._outputBuffer, this._outputTail);
/*  636 */     this._outputTail += room;
/*  637 */     _flushBuffer();
/*  638 */     int offset = room;
/*  639 */     int len = text.length() - room;
/*      */     
/*  641 */     while (len > this._outputEnd) {
/*  642 */       int amount = this._outputEnd;
/*  643 */       text.getChars(offset, offset + amount, this._outputBuffer, 0);
/*  644 */       this._outputHead = 0;
/*  645 */       this._outputTail = amount;
/*  646 */       _flushBuffer();
/*  647 */       offset += amount;
/*  648 */       len -= amount;
/*      */     } 
/*      */     
/*  651 */     text.getChars(offset, offset + len, this._outputBuffer, 0);
/*  652 */     this._outputHead = 0;
/*  653 */     this._outputTail = len;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeBinary(Base64Variant b64variant, byte[] data, int offset, int len) throws IOException, JsonGenerationException {
/*  666 */     _checkRangeBoundsForByteArray(data, offset, len);
/*      */     
/*  668 */     _verifyValueWrite("write a binary value");
/*      */     
/*  670 */     if (this._outputTail >= this._outputEnd) {
/*  671 */       _flushBuffer();
/*      */     }
/*  673 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*  674 */     _writeBinary(b64variant, data, offset, offset + len);
/*      */     
/*  676 */     if (this._outputTail >= this._outputEnd) {
/*  677 */       _flushBuffer();
/*      */     }
/*  679 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int writeBinary(Base64Variant b64variant, InputStream data, int dataLength) throws IOException, JsonGenerationException {
/*      */     int bytes;
/*  687 */     _verifyValueWrite("write a binary value");
/*      */     
/*  689 */     if (this._outputTail >= this._outputEnd) {
/*  690 */       _flushBuffer();
/*      */     }
/*  692 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*  693 */     byte[] encodingBuffer = this._ioContext.allocBase64Buffer();
/*      */     
/*      */     try {
/*  696 */       if (dataLength < 0) {
/*  697 */         bytes = _writeBinary(b64variant, data, encodingBuffer);
/*      */       } else {
/*  699 */         int missing = _writeBinary(b64variant, data, encodingBuffer, dataLength);
/*  700 */         if (missing > 0) {
/*  701 */           _reportError("Too few bytes available: missing " + missing + " bytes (out of " + dataLength + ")");
/*      */         }
/*  703 */         bytes = dataLength;
/*      */       } 
/*      */     } finally {
/*  706 */       this._ioContext.releaseBase64Buffer(encodingBuffer);
/*      */     } 
/*      */     
/*  709 */     if (this._outputTail >= this._outputEnd) {
/*  710 */       _flushBuffer();
/*      */     }
/*  712 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*  713 */     return bytes;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumber(short s) throws IOException {
/*  725 */     _verifyValueWrite("write a number");
/*  726 */     if (this._cfgNumbersAsStrings) {
/*  727 */       _writeQuotedShort(s);
/*      */       
/*      */       return;
/*      */     } 
/*  731 */     if (this._outputTail + 6 >= this._outputEnd) {
/*  732 */       _flushBuffer();
/*      */     }
/*  734 */     this._outputTail = NumberOutput.outputInt(s, this._outputBuffer, this._outputTail);
/*      */   }
/*      */   
/*      */   private void _writeQuotedShort(short s) throws IOException {
/*  738 */     if (this._outputTail + 8 >= this._outputEnd) {
/*  739 */       _flushBuffer();
/*      */     }
/*  741 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*  742 */     this._outputTail = NumberOutput.outputInt(s, this._outputBuffer, this._outputTail);
/*  743 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumber(int i) throws IOException {
/*  749 */     _verifyValueWrite("write a number");
/*  750 */     if (this._cfgNumbersAsStrings) {
/*  751 */       _writeQuotedInt(i);
/*      */       
/*      */       return;
/*      */     } 
/*  755 */     if (this._outputTail + 11 >= this._outputEnd) {
/*  756 */       _flushBuffer();
/*      */     }
/*  758 */     this._outputTail = NumberOutput.outputInt(i, this._outputBuffer, this._outputTail);
/*      */   }
/*      */   
/*      */   private void _writeQuotedInt(int i) throws IOException {
/*  762 */     if (this._outputTail + 13 >= this._outputEnd) {
/*  763 */       _flushBuffer();
/*      */     }
/*  765 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*  766 */     this._outputTail = NumberOutput.outputInt(i, this._outputBuffer, this._outputTail);
/*  767 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumber(long l) throws IOException {
/*  773 */     _verifyValueWrite("write a number");
/*  774 */     if (this._cfgNumbersAsStrings) {
/*  775 */       _writeQuotedLong(l);
/*      */       return;
/*      */     } 
/*  778 */     if (this._outputTail + 21 >= this._outputEnd)
/*      */     {
/*  780 */       _flushBuffer();
/*      */     }
/*  782 */     this._outputTail = NumberOutput.outputLong(l, this._outputBuffer, this._outputTail);
/*      */   }
/*      */   
/*      */   private void _writeQuotedLong(long l) throws IOException {
/*  786 */     if (this._outputTail + 23 >= this._outputEnd) {
/*  787 */       _flushBuffer();
/*      */     }
/*  789 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*  790 */     this._outputTail = NumberOutput.outputLong(l, this._outputBuffer, this._outputTail);
/*  791 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumber(BigInteger value) throws IOException {
/*  799 */     _verifyValueWrite("write a number");
/*  800 */     if (value == null) {
/*  801 */       _writeNull();
/*  802 */     } else if (this._cfgNumbersAsStrings) {
/*  803 */       _writeQuotedRaw(value.toString());
/*      */     } else {
/*  805 */       writeRaw(value.toString());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumber(double d) throws IOException {
/*  813 */     if (this._cfgNumbersAsStrings || (
/*  814 */       NumberOutput.notFinite(d) && isEnabled(JsonGenerator.Feature.QUOTE_NON_NUMERIC_NUMBERS))) {
/*  815 */       writeString(NumberOutput.toString(d, isEnabled(JsonGenerator.Feature.USE_FAST_DOUBLE_WRITER)));
/*      */       
/*      */       return;
/*      */     } 
/*  819 */     _verifyValueWrite("write a number");
/*  820 */     writeRaw(NumberOutput.toString(d, isEnabled(JsonGenerator.Feature.USE_FAST_DOUBLE_WRITER)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumber(float f) throws IOException {
/*  827 */     if (this._cfgNumbersAsStrings || (
/*  828 */       NumberOutput.notFinite(f) && isEnabled(JsonGenerator.Feature.QUOTE_NON_NUMERIC_NUMBERS))) {
/*  829 */       writeString(NumberOutput.toString(f, isEnabled(JsonGenerator.Feature.USE_FAST_DOUBLE_WRITER)));
/*      */       
/*      */       return;
/*      */     } 
/*  833 */     _verifyValueWrite("write a number");
/*  834 */     writeRaw(NumberOutput.toString(f, isEnabled(JsonGenerator.Feature.USE_FAST_DOUBLE_WRITER)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumber(BigDecimal value) throws IOException {
/*  841 */     _verifyValueWrite("write a number");
/*  842 */     if (value == null) {
/*  843 */       _writeNull();
/*  844 */     } else if (this._cfgNumbersAsStrings) {
/*  845 */       _writeQuotedRaw(_asString(value));
/*      */     } else {
/*  847 */       writeRaw(_asString(value));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumber(String encodedValue) throws IOException {
/*  854 */     _verifyValueWrite("write a number");
/*  855 */     if (encodedValue == null) {
/*  856 */       _writeNull();
/*  857 */     } else if (this._cfgNumbersAsStrings) {
/*  858 */       _writeQuotedRaw(encodedValue);
/*      */     } else {
/*  860 */       writeRaw(encodedValue);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void writeNumber(char[] encodedValueBuffer, int offset, int length) throws IOException {
/*  866 */     _verifyValueWrite("write a number");
/*  867 */     if (this._cfgNumbersAsStrings) {
/*  868 */       _writeQuotedRaw(encodedValueBuffer, offset, length);
/*      */     } else {
/*  870 */       writeRaw(encodedValueBuffer, offset, length);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void _writeQuotedRaw(String value) throws IOException {
/*  876 */     if (this._outputTail >= this._outputEnd) {
/*  877 */       _flushBuffer();
/*      */     }
/*  879 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*  880 */     writeRaw(value);
/*  881 */     if (this._outputTail >= this._outputEnd) {
/*  882 */       _flushBuffer();
/*      */     }
/*  884 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */   }
/*      */ 
/*      */   
/*      */   private void _writeQuotedRaw(char[] text, int offset, int length) throws IOException {
/*  889 */     if (this._outputTail >= this._outputEnd) {
/*  890 */       _flushBuffer();
/*      */     }
/*  892 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*  893 */     writeRaw(text, offset, length);
/*  894 */     if (this._outputTail >= this._outputEnd) {
/*  895 */       _flushBuffer();
/*      */     }
/*  897 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeBoolean(boolean state) throws IOException {
/*  903 */     _verifyValueWrite("write a boolean value");
/*  904 */     if (this._outputTail + 5 >= this._outputEnd) {
/*  905 */       _flushBuffer();
/*      */     }
/*  907 */     int ptr = this._outputTail;
/*  908 */     char[] buf = this._outputBuffer;
/*  909 */     if (state) {
/*  910 */       buf[ptr] = 't';
/*  911 */       buf[++ptr] = 'r';
/*  912 */       buf[++ptr] = 'u';
/*  913 */       buf[++ptr] = 'e';
/*      */     } else {
/*  915 */       buf[ptr] = 'f';
/*  916 */       buf[++ptr] = 'a';
/*  917 */       buf[++ptr] = 'l';
/*  918 */       buf[++ptr] = 's';
/*  919 */       buf[++ptr] = 'e';
/*      */     } 
/*  921 */     this._outputTail = ptr + 1;
/*      */   }
/*      */ 
/*      */   
/*      */   public void writeNull() throws IOException {
/*  926 */     _verifyValueWrite("write a null");
/*  927 */     _writeNull();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void _verifyValueWrite(String typeMsg) throws IOException {
/*      */     char c;
/*  939 */     int status = this._writeContext.writeValue();
/*  940 */     if (this._cfgPrettyPrinter != null) {
/*      */       
/*  942 */       _verifyPrettyValueWrite(typeMsg, status);
/*      */       
/*      */       return;
/*      */     } 
/*  946 */     switch (status) {
/*      */       default:
/*      */         return;
/*      */       
/*      */       case 1:
/*  951 */         c = ',';
/*      */         break;
/*      */       case 2:
/*  954 */         c = ':';
/*      */         break;
/*      */       case 3:
/*  957 */         if (this._rootValueSeparator != null) {
/*  958 */           writeRaw(this._rootValueSeparator.getValue());
/*      */         }
/*      */         return;
/*      */       case 5:
/*  962 */         _reportCantWriteValueExpectName(typeMsg);
/*      */         return;
/*      */     } 
/*  965 */     if (this._outputTail >= this._outputEnd) {
/*  966 */       _flushBuffer();
/*      */     }
/*  968 */     this._outputBuffer[this._outputTail++] = c;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void flush() throws IOException {
/*  980 */     _flushBuffer();
/*  981 */     if (this._writer != null && 
/*  982 */       isEnabled(JsonGenerator.Feature.FLUSH_PASSED_TO_STREAM)) {
/*  983 */       this._writer.flush();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void close() throws IOException {
/*  991 */     super.close();
/*      */ 
/*      */ 
/*      */     
/*  995 */     IOException flushFail = null;
/*      */     try {
/*  997 */       if (this._outputBuffer != null && 
/*  998 */         isEnabled(JsonGenerator.Feature.AUTO_CLOSE_JSON_CONTENT)) {
/*      */         while (true) {
/* 1000 */           JsonStreamContext ctxt = getOutputContext();
/* 1001 */           if (ctxt.inArray()) {
/* 1002 */             writeEndArray(); continue;
/* 1003 */           }  if (ctxt.inObject()) {
/* 1004 */             writeEndObject();
/*      */             continue;
/*      */           } 
/*      */           break;
/*      */         } 
/*      */       }
/* 1010 */       _flushBuffer();
/* 1011 */     } catch (IOException e) {
/*      */ 
/*      */       
/* 1014 */       flushFail = e;
/*      */     } 
/* 1016 */     this._outputHead = 0;
/* 1017 */     this._outputTail = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1025 */     if (this._writer != null) {
/*      */       try {
/* 1027 */         if (this._ioContext.isResourceManaged() || isEnabled(JsonGenerator.Feature.AUTO_CLOSE_TARGET)) {
/* 1028 */           this._writer.close();
/* 1029 */         } else if (isEnabled(JsonGenerator.Feature.FLUSH_PASSED_TO_STREAM)) {
/*      */           
/* 1031 */           this._writer.flush();
/*      */         } 
/* 1033 */       } catch (IOException|RuntimeException e) {
/* 1034 */         if (flushFail != null) {
/* 1035 */           e.addSuppressed(flushFail);
/*      */         }
/* 1037 */         throw e;
/*      */       } 
/*      */     }
/*      */     
/* 1041 */     _releaseBuffers();
/*      */     
/* 1043 */     if (flushFail != null) {
/* 1044 */       throw flushFail;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _releaseBuffers() {
/* 1051 */     char[] buf = this._outputBuffer;
/* 1052 */     if (buf != null) {
/* 1053 */       this._outputBuffer = null;
/* 1054 */       this._ioContext.releaseConcatBuffer(buf);
/*      */     } 
/* 1056 */     buf = this._copyBuffer;
/* 1057 */     if (buf != null) {
/* 1058 */       this._copyBuffer = null;
/* 1059 */       this._ioContext.releaseNameCopyBuffer(buf);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void _writeString(String text) throws IOException {
/* 1076 */     int len = text.length();
/* 1077 */     if (len > this._outputEnd) {
/* 1078 */       _writeLongString(text);
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 1084 */     if (this._outputTail + len > this._outputEnd) {
/* 1085 */       _flushBuffer();
/*      */     }
/* 1087 */     text.getChars(0, len, this._outputBuffer, this._outputTail);
/*      */     
/* 1089 */     if (this._characterEscapes != null) {
/* 1090 */       _writeStringCustom(len);
/* 1091 */     } else if (this._maximumNonEscapedChar != 0) {
/* 1092 */       _writeStringASCII(len, this._maximumNonEscapedChar);
/*      */     } else {
/* 1094 */       _writeString2(len);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void _writeString2(int len) throws IOException {
/* 1101 */     int end = this._outputTail + len;
/* 1102 */     int[] escCodes = this._outputEscapes;
/* 1103 */     int escLen = escCodes.length;
/*      */ 
/*      */     
/* 1106 */     while (this._outputTail < end) {
/*      */       
/*      */       label17: while (true) {
/*      */         
/* 1110 */         char c = this._outputBuffer[this._outputTail];
/* 1111 */         if (c < escLen && escCodes[c] != 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1123 */           int flushLen = this._outputTail - this._outputHead;
/* 1124 */           if (flushLen > 0) {
/* 1125 */             this._writer.write(this._outputBuffer, this._outputHead, flushLen);
/*      */             
/*      */             break label17;
/*      */           } 
/*      */           
/* 1130 */           char c1 = this._outputBuffer[this._outputTail++];
/* 1131 */           _prependOrWriteCharacterEscape(c1, escCodes[c1]);
/*      */           continue;
/*      */         } 
/*      */         if (++this._outputTail >= end) {
/*      */           break;
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private void _writeLongString(String text) throws IOException {
/* 1142 */     _flushBuffer();
/*      */ 
/*      */     
/* 1145 */     int textLen = text.length();
/* 1146 */     int offset = 0;
/*      */     do {
/* 1148 */       int max = this._outputEnd;
/* 1149 */       int segmentLen = (offset + max > textLen) ? (textLen - offset) : max;
/*      */       
/* 1151 */       text.getChars(offset, offset + segmentLen, this._outputBuffer, 0);
/* 1152 */       if (this._characterEscapes != null) {
/* 1153 */         _writeSegmentCustom(segmentLen);
/* 1154 */       } else if (this._maximumNonEscapedChar != 0) {
/* 1155 */         _writeSegmentASCII(segmentLen, this._maximumNonEscapedChar);
/*      */       } else {
/* 1157 */         _writeSegment(segmentLen);
/*      */       } 
/* 1159 */       offset += segmentLen;
/* 1160 */     } while (offset < textLen);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void _writeSegment(int end) throws IOException {
/* 1174 */     int[] escCodes = this._outputEscapes;
/* 1175 */     int escLen = escCodes.length;
/*      */     
/* 1177 */     int ptr = 0;
/* 1178 */     int start = ptr;
/*      */ 
/*      */     
/* 1181 */     while (ptr < end) {
/*      */       char c;
/*      */       
/*      */       do {
/* 1185 */         c = this._outputBuffer[ptr];
/* 1186 */         if (c < escLen && escCodes[c] != 0) {
/*      */           break;
/*      */         }
/* 1189 */       } while (++ptr < end);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1198 */       int flushLen = ptr - start;
/* 1199 */       if (flushLen > 0) {
/* 1200 */         this._writer.write(this._outputBuffer, start, flushLen);
/* 1201 */         if (ptr >= end) {
/*      */           break;
/*      */         }
/*      */       } 
/* 1205 */       ptr++;
/*      */       
/* 1207 */       start = _prependOrWriteCharacterEscape(this._outputBuffer, ptr, end, c, escCodes[c]);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void _writeString(char[] text, int offset, int len) throws IOException {
/* 1217 */     if (this._characterEscapes != null) {
/* 1218 */       _writeStringCustom(text, offset, len);
/*      */       return;
/*      */     } 
/* 1221 */     if (this._maximumNonEscapedChar != 0) {
/* 1222 */       _writeStringASCII(text, offset, len, this._maximumNonEscapedChar);
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */ 
/*      */     
/* 1229 */     len += offset;
/* 1230 */     int[] escCodes = this._outputEscapes;
/* 1231 */     int escLen = escCodes.length;
/* 1232 */     while (offset < len) {
/* 1233 */       int start = offset;
/*      */       
/*      */       do {
/* 1236 */         char c1 = text[offset];
/* 1237 */         if (c1 < escLen && escCodes[c1] != 0) {
/*      */           break;
/*      */         }
/* 1240 */       } while (++offset < len);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1246 */       int newAmount = offset - start;
/* 1247 */       if (newAmount < 32) {
/*      */         
/* 1249 */         if (this._outputTail + newAmount > this._outputEnd) {
/* 1250 */           _flushBuffer();
/*      */         }
/* 1252 */         if (newAmount > 0) {
/* 1253 */           System.arraycopy(text, start, this._outputBuffer, this._outputTail, newAmount);
/* 1254 */           this._outputTail += newAmount;
/*      */         } 
/*      */       } else {
/* 1257 */         _flushBuffer();
/* 1258 */         this._writer.write(text, start, newAmount);
/*      */       } 
/*      */       
/* 1261 */       if (offset >= len) {
/*      */         break;
/*      */       }
/*      */       
/* 1265 */       char c = text[offset++];
/* 1266 */       _appendCharacterEscape(c, escCodes[c]);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void _writeStringASCII(int len, int maxNonEscaped) throws IOException, JsonGenerationException {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield _outputTail : I
/*      */     //   4: iload_1
/*      */     //   5: iadd
/*      */     //   6: istore_3
/*      */     //   7: aload_0
/*      */     //   8: getfield _outputEscapes : [I
/*      */     //   11: astore #4
/*      */     //   13: aload #4
/*      */     //   15: arraylength
/*      */     //   16: iload_2
/*      */     //   17: iconst_1
/*      */     //   18: iadd
/*      */     //   19: invokestatic min : (II)I
/*      */     //   22: istore #5
/*      */     //   24: iconst_0
/*      */     //   25: istore #6
/*      */     //   27: aload_0
/*      */     //   28: getfield _outputTail : I
/*      */     //   31: iload_3
/*      */     //   32: if_icmpge -> 152
/*      */     //   35: aload_0
/*      */     //   36: getfield _outputBuffer : [C
/*      */     //   39: aload_0
/*      */     //   40: getfield _outputTail : I
/*      */     //   43: caload
/*      */     //   44: istore #7
/*      */     //   46: iload #7
/*      */     //   48: iload #5
/*      */     //   50: if_icmpge -> 68
/*      */     //   53: aload #4
/*      */     //   55: iload #7
/*      */     //   57: iaload
/*      */     //   58: istore #6
/*      */     //   60: iload #6
/*      */     //   62: ifeq -> 80
/*      */     //   65: goto -> 98
/*      */     //   68: iload #7
/*      */     //   70: iload_2
/*      */     //   71: if_icmple -> 80
/*      */     //   74: iconst_m1
/*      */     //   75: istore #6
/*      */     //   77: goto -> 98
/*      */     //   80: aload_0
/*      */     //   81: dup
/*      */     //   82: getfield _outputTail : I
/*      */     //   85: iconst_1
/*      */     //   86: iadd
/*      */     //   87: dup_x1
/*      */     //   88: putfield _outputTail : I
/*      */     //   91: iload_3
/*      */     //   92: if_icmplt -> 35
/*      */     //   95: goto -> 152
/*      */     //   98: aload_0
/*      */     //   99: getfield _outputTail : I
/*      */     //   102: aload_0
/*      */     //   103: getfield _outputHead : I
/*      */     //   106: isub
/*      */     //   107: istore #8
/*      */     //   109: iload #8
/*      */     //   111: ifle -> 131
/*      */     //   114: aload_0
/*      */     //   115: getfield _writer : Ljava/io/Writer;
/*      */     //   118: aload_0
/*      */     //   119: getfield _outputBuffer : [C
/*      */     //   122: aload_0
/*      */     //   123: getfield _outputHead : I
/*      */     //   126: iload #8
/*      */     //   128: invokevirtual write : ([CII)V
/*      */     //   131: aload_0
/*      */     //   132: dup
/*      */     //   133: getfield _outputTail : I
/*      */     //   136: iconst_1
/*      */     //   137: iadd
/*      */     //   138: putfield _outputTail : I
/*      */     //   141: aload_0
/*      */     //   142: iload #7
/*      */     //   144: iload #6
/*      */     //   146: invokespecial _prependOrWriteCharacterEscape : (CI)V
/*      */     //   149: goto -> 27
/*      */     //   152: return
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #1284	-> 0
/*      */     //   #1285	-> 7
/*      */     //   #1286	-> 13
/*      */     //   #1287	-> 24
/*      */     //   #1290	-> 27
/*      */     //   #1295	-> 35
/*      */     //   #1296	-> 46
/*      */     //   #1297	-> 53
/*      */     //   #1298	-> 60
/*      */     //   #1299	-> 65
/*      */     //   #1301	-> 68
/*      */     //   #1302	-> 74
/*      */     //   #1303	-> 77
/*      */     //   #1305	-> 80
/*      */     //   #1306	-> 95
/*      */     //   #1309	-> 98
/*      */     //   #1310	-> 109
/*      */     //   #1311	-> 114
/*      */     //   #1313	-> 131
/*      */     //   #1314	-> 141
/*      */     //   #1315	-> 149
/*      */     //   #1316	-> 152
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   46	103	7	c	C
/*      */     //   109	40	8	flushLen	I
/*      */     //   0	153	0	this	Lcom/fasterxml/jackson/core/json/WriterBasedJsonGenerator;
/*      */     //   0	153	1	len	I
/*      */     //   0	153	2	maxNonEscaped	I
/*      */     //   7	146	3	end	I
/*      */     //   13	140	4	escCodes	[I
/*      */     //   24	129	5	escLimit	I
/*      */     //   27	126	6	escCode	I
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void _writeSegmentASCII(int end, int maxNonEscaped) throws IOException, JsonGenerationException {
/* 1321 */     int[] escCodes = this._outputEscapes;
/* 1322 */     int escLimit = Math.min(escCodes.length, maxNonEscaped + 1);
/*      */     
/* 1324 */     int ptr = 0;
/* 1325 */     int escCode = 0;
/* 1326 */     int start = ptr;
/*      */ 
/*      */     
/* 1329 */     while (ptr < end) {
/*      */       char c;
/*      */       
/*      */       do {
/* 1333 */         c = this._outputBuffer[ptr];
/* 1334 */         if (c < escLimit) {
/* 1335 */           escCode = escCodes[c];
/* 1336 */           if (escCode != 0) {
/*      */             break;
/*      */           }
/* 1339 */         } else if (c > maxNonEscaped) {
/* 1340 */           escCode = -1;
/*      */           break;
/*      */         } 
/* 1343 */       } while (++ptr < end);
/*      */ 
/*      */ 
/*      */       
/* 1347 */       int flushLen = ptr - start;
/* 1348 */       if (flushLen > 0) {
/* 1349 */         this._writer.write(this._outputBuffer, start, flushLen);
/* 1350 */         if (ptr >= end) {
/*      */           break;
/*      */         }
/*      */       } 
/* 1354 */       ptr++;
/* 1355 */       start = _prependOrWriteCharacterEscape(this._outputBuffer, ptr, end, c, escCode);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void _writeStringASCII(char[] text, int offset, int len, int maxNonEscaped) throws IOException, JsonGenerationException {
/* 1363 */     len += offset;
/* 1364 */     int[] escCodes = this._outputEscapes;
/* 1365 */     int escLimit = Math.min(escCodes.length, maxNonEscaped + 1);
/*      */     
/* 1367 */     int escCode = 0;
/*      */     
/* 1369 */     while (offset < len) {
/* 1370 */       char c; int start = offset;
/*      */ 
/*      */       
/*      */       do {
/* 1374 */         c = text[offset];
/* 1375 */         if (c < escLimit) {
/* 1376 */           escCode = escCodes[c];
/* 1377 */           if (escCode != 0) {
/*      */             break;
/*      */           }
/* 1380 */         } else if (c > maxNonEscaped) {
/* 1381 */           escCode = -1;
/*      */           break;
/*      */         } 
/* 1384 */       } while (++offset < len);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1390 */       int newAmount = offset - start;
/* 1391 */       if (newAmount < 32) {
/*      */         
/* 1393 */         if (this._outputTail + newAmount > this._outputEnd) {
/* 1394 */           _flushBuffer();
/*      */         }
/* 1396 */         if (newAmount > 0) {
/* 1397 */           System.arraycopy(text, start, this._outputBuffer, this._outputTail, newAmount);
/* 1398 */           this._outputTail += newAmount;
/*      */         } 
/*      */       } else {
/* 1401 */         _flushBuffer();
/* 1402 */         this._writer.write(text, start, newAmount);
/*      */       } 
/*      */       
/* 1405 */       if (offset >= len) {
/*      */         break;
/*      */       }
/*      */       
/* 1409 */       offset++;
/* 1410 */       _appendCharacterEscape(c, escCode);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void _writeStringCustom(int len) throws IOException, JsonGenerationException {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield _outputTail : I
/*      */     //   4: iload_1
/*      */     //   5: iadd
/*      */     //   6: istore_2
/*      */     //   7: aload_0
/*      */     //   8: getfield _outputEscapes : [I
/*      */     //   11: astore_3
/*      */     //   12: aload_0
/*      */     //   13: getfield _maximumNonEscapedChar : I
/*      */     //   16: iconst_1
/*      */     //   17: if_icmpge -> 25
/*      */     //   20: ldc 65535
/*      */     //   22: goto -> 29
/*      */     //   25: aload_0
/*      */     //   26: getfield _maximumNonEscapedChar : I
/*      */     //   29: istore #4
/*      */     //   31: aload_3
/*      */     //   32: arraylength
/*      */     //   33: iload #4
/*      */     //   35: iconst_1
/*      */     //   36: iadd
/*      */     //   37: invokestatic min : (II)I
/*      */     //   40: istore #5
/*      */     //   42: iconst_0
/*      */     //   43: istore #6
/*      */     //   45: aload_0
/*      */     //   46: getfield _characterEscapes : Lcom/fasterxml/jackson/core/io/CharacterEscapes;
/*      */     //   49: astore #7
/*      */     //   51: aload_0
/*      */     //   52: getfield _outputTail : I
/*      */     //   55: iload_2
/*      */     //   56: if_icmpge -> 198
/*      */     //   59: aload_0
/*      */     //   60: getfield _outputBuffer : [C
/*      */     //   63: aload_0
/*      */     //   64: getfield _outputTail : I
/*      */     //   67: caload
/*      */     //   68: istore #8
/*      */     //   70: iload #8
/*      */     //   72: iload #5
/*      */     //   74: if_icmpge -> 91
/*      */     //   77: aload_3
/*      */     //   78: iload #8
/*      */     //   80: iaload
/*      */     //   81: istore #6
/*      */     //   83: iload #6
/*      */     //   85: ifeq -> 126
/*      */     //   88: goto -> 144
/*      */     //   91: iload #8
/*      */     //   93: iload #4
/*      */     //   95: if_icmple -> 104
/*      */     //   98: iconst_m1
/*      */     //   99: istore #6
/*      */     //   101: goto -> 144
/*      */     //   104: aload_0
/*      */     //   105: aload #7
/*      */     //   107: iload #8
/*      */     //   109: invokevirtual getEscapeSequence : (I)Lcom/fasterxml/jackson/core/SerializableString;
/*      */     //   112: dup_x1
/*      */     //   113: putfield _currentEscape : Lcom/fasterxml/jackson/core/SerializableString;
/*      */     //   116: ifnull -> 126
/*      */     //   119: bipush #-2
/*      */     //   121: istore #6
/*      */     //   123: goto -> 144
/*      */     //   126: aload_0
/*      */     //   127: dup
/*      */     //   128: getfield _outputTail : I
/*      */     //   131: iconst_1
/*      */     //   132: iadd
/*      */     //   133: dup_x1
/*      */     //   134: putfield _outputTail : I
/*      */     //   137: iload_2
/*      */     //   138: if_icmplt -> 59
/*      */     //   141: goto -> 198
/*      */     //   144: aload_0
/*      */     //   145: getfield _outputTail : I
/*      */     //   148: aload_0
/*      */     //   149: getfield _outputHead : I
/*      */     //   152: isub
/*      */     //   153: istore #9
/*      */     //   155: iload #9
/*      */     //   157: ifle -> 177
/*      */     //   160: aload_0
/*      */     //   161: getfield _writer : Ljava/io/Writer;
/*      */     //   164: aload_0
/*      */     //   165: getfield _outputBuffer : [C
/*      */     //   168: aload_0
/*      */     //   169: getfield _outputHead : I
/*      */     //   172: iload #9
/*      */     //   174: invokevirtual write : ([CII)V
/*      */     //   177: aload_0
/*      */     //   178: dup
/*      */     //   179: getfield _outputTail : I
/*      */     //   182: iconst_1
/*      */     //   183: iadd
/*      */     //   184: putfield _outputTail : I
/*      */     //   187: aload_0
/*      */     //   188: iload #8
/*      */     //   190: iload #6
/*      */     //   192: invokespecial _prependOrWriteCharacterEscape : (CI)V
/*      */     //   195: goto -> 51
/*      */     //   198: return
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #1428	-> 0
/*      */     //   #1429	-> 7
/*      */     //   #1430	-> 12
/*      */     //   #1431	-> 31
/*      */     //   #1432	-> 42
/*      */     //   #1433	-> 45
/*      */     //   #1436	-> 51
/*      */     //   #1441	-> 59
/*      */     //   #1442	-> 70
/*      */     //   #1443	-> 77
/*      */     //   #1444	-> 83
/*      */     //   #1445	-> 88
/*      */     //   #1447	-> 91
/*      */     //   #1448	-> 98
/*      */     //   #1449	-> 101
/*      */     //   #1451	-> 104
/*      */     //   #1452	-> 119
/*      */     //   #1453	-> 123
/*      */     //   #1456	-> 126
/*      */     //   #1457	-> 141
/*      */     //   #1460	-> 144
/*      */     //   #1461	-> 155
/*      */     //   #1462	-> 160
/*      */     //   #1464	-> 177
/*      */     //   #1465	-> 187
/*      */     //   #1466	-> 195
/*      */     //   #1467	-> 198
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   70	125	8	c	C
/*      */     //   155	40	9	flushLen	I
/*      */     //   0	199	0	this	Lcom/fasterxml/jackson/core/json/WriterBasedJsonGenerator;
/*      */     //   0	199	1	len	I
/*      */     //   7	192	2	end	I
/*      */     //   12	187	3	escCodes	[I
/*      */     //   31	168	4	maxNonEscaped	I
/*      */     //   42	157	5	escLimit	I
/*      */     //   45	154	6	escCode	I
/*      */     //   51	148	7	customEscapes	Lcom/fasterxml/jackson/core/io/CharacterEscapes;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void _writeSegmentCustom(int end) throws IOException, JsonGenerationException {
/* 1472 */     int[] escCodes = this._outputEscapes;
/* 1473 */     int maxNonEscaped = (this._maximumNonEscapedChar < 1) ? 65535 : this._maximumNonEscapedChar;
/* 1474 */     int escLimit = Math.min(escCodes.length, maxNonEscaped + 1);
/* 1475 */     CharacterEscapes customEscapes = this._characterEscapes;
/*      */     
/* 1477 */     int ptr = 0;
/* 1478 */     int escCode = 0;
/* 1479 */     int start = ptr;
/*      */ 
/*      */     
/* 1482 */     while (ptr < end) {
/*      */       char c;
/*      */       
/*      */       do {
/* 1486 */         c = this._outputBuffer[ptr];
/* 1487 */         if (c < escLimit) {
/* 1488 */           escCode = escCodes[c];
/* 1489 */           if (escCode != 0)
/*      */             break; 
/*      */         } else {
/* 1492 */           if (c > maxNonEscaped) {
/* 1493 */             escCode = -1;
/*      */             break;
/*      */           } 
/* 1496 */           if ((this._currentEscape = customEscapes.getEscapeSequence(c)) != null) {
/* 1497 */             escCode = -2;
/*      */             break;
/*      */           } 
/*      */         } 
/* 1501 */       } while (++ptr < end);
/*      */ 
/*      */ 
/*      */       
/* 1505 */       int flushLen = ptr - start;
/* 1506 */       if (flushLen > 0) {
/* 1507 */         this._writer.write(this._outputBuffer, start, flushLen);
/* 1508 */         if (ptr >= end) {
/*      */           break;
/*      */         }
/*      */       } 
/* 1512 */       ptr++;
/* 1513 */       start = _prependOrWriteCharacterEscape(this._outputBuffer, ptr, end, c, escCode);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void _writeStringCustom(char[] text, int offset, int len) throws IOException, JsonGenerationException {
/* 1520 */     len += offset;
/* 1521 */     int[] escCodes = this._outputEscapes;
/* 1522 */     int maxNonEscaped = (this._maximumNonEscapedChar < 1) ? 65535 : this._maximumNonEscapedChar;
/* 1523 */     int escLimit = Math.min(escCodes.length, maxNonEscaped + 1);
/* 1524 */     CharacterEscapes customEscapes = this._characterEscapes;
/*      */     
/* 1526 */     int escCode = 0;
/*      */     
/* 1528 */     while (offset < len) {
/* 1529 */       char c; int start = offset;
/*      */ 
/*      */       
/*      */       do {
/* 1533 */         c = text[offset];
/* 1534 */         if (c < escLimit) {
/* 1535 */           escCode = escCodes[c];
/* 1536 */           if (escCode != 0)
/*      */             break; 
/*      */         } else {
/* 1539 */           if (c > maxNonEscaped) {
/* 1540 */             escCode = -1;
/*      */             break;
/*      */           } 
/* 1543 */           if ((this._currentEscape = customEscapes.getEscapeSequence(c)) != null) {
/* 1544 */             escCode = -2;
/*      */             break;
/*      */           } 
/*      */         } 
/* 1548 */       } while (++offset < len);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1554 */       int newAmount = offset - start;
/* 1555 */       if (newAmount < 32) {
/*      */         
/* 1557 */         if (this._outputTail + newAmount > this._outputEnd) {
/* 1558 */           _flushBuffer();
/*      */         }
/* 1560 */         if (newAmount > 0) {
/* 1561 */           System.arraycopy(text, start, this._outputBuffer, this._outputTail, newAmount);
/* 1562 */           this._outputTail += newAmount;
/*      */         } 
/*      */       } else {
/* 1565 */         _flushBuffer();
/* 1566 */         this._writer.write(text, start, newAmount);
/*      */       } 
/*      */       
/* 1569 */       if (offset >= len) {
/*      */         break;
/*      */       }
/*      */       
/* 1573 */       offset++;
/* 1574 */       _appendCharacterEscape(c, escCode);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void _writeBinary(Base64Variant b64variant, byte[] input, int inputPtr, int inputEnd) throws IOException, JsonGenerationException {
/* 1588 */     int safeInputEnd = inputEnd - 3;
/*      */     
/* 1590 */     int safeOutputEnd = this._outputEnd - 6;
/* 1591 */     int chunksBeforeLF = b64variant.getMaxLineLength() >> 2;
/*      */ 
/*      */     
/* 1594 */     while (inputPtr <= safeInputEnd) {
/* 1595 */       if (this._outputTail > safeOutputEnd) {
/* 1596 */         _flushBuffer();
/*      */       }
/*      */       
/* 1599 */       int b24 = input[inputPtr++] << 8;
/* 1600 */       b24 |= input[inputPtr++] & 0xFF;
/* 1601 */       b24 = b24 << 8 | input[inputPtr++] & 0xFF;
/* 1602 */       this._outputTail = b64variant.encodeBase64Chunk(b24, this._outputBuffer, this._outputTail);
/* 1603 */       if (--chunksBeforeLF <= 0) {
/*      */         
/* 1605 */         this._outputBuffer[this._outputTail++] = '\\';
/* 1606 */         this._outputBuffer[this._outputTail++] = 'n';
/* 1607 */         chunksBeforeLF = b64variant.getMaxLineLength() >> 2;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1612 */     int inputLeft = inputEnd - inputPtr;
/* 1613 */     if (inputLeft > 0) {
/* 1614 */       if (this._outputTail > safeOutputEnd) {
/* 1615 */         _flushBuffer();
/*      */       }
/* 1617 */       int b24 = input[inputPtr++] << 16;
/* 1618 */       if (inputLeft == 2) {
/* 1619 */         b24 |= (input[inputPtr++] & 0xFF) << 8;
/*      */       }
/* 1621 */       this._outputTail = b64variant.encodeBase64Partial(b24, inputLeft, this._outputBuffer, this._outputTail);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final int _writeBinary(Base64Variant b64variant, InputStream data, byte[] readBuffer, int bytesLeft) throws IOException, JsonGenerationException {
/* 1630 */     int inputPtr = 0;
/* 1631 */     int inputEnd = 0;
/* 1632 */     int lastFullOffset = -3;
/*      */ 
/*      */     
/* 1635 */     int safeOutputEnd = this._outputEnd - 6;
/* 1636 */     int chunksBeforeLF = b64variant.getMaxLineLength() >> 2;
/*      */     
/* 1638 */     while (bytesLeft > 2) {
/* 1639 */       if (inputPtr > lastFullOffset) {
/* 1640 */         inputEnd = _readMore(data, readBuffer, inputPtr, inputEnd, bytesLeft);
/* 1641 */         inputPtr = 0;
/* 1642 */         if (inputEnd < 3) {
/*      */           break;
/*      */         }
/* 1645 */         lastFullOffset = inputEnd - 3;
/*      */       } 
/* 1647 */       if (this._outputTail > safeOutputEnd) {
/* 1648 */         _flushBuffer();
/*      */       }
/* 1650 */       int b24 = readBuffer[inputPtr++] << 8;
/* 1651 */       b24 |= readBuffer[inputPtr++] & 0xFF;
/* 1652 */       b24 = b24 << 8 | readBuffer[inputPtr++] & 0xFF;
/* 1653 */       bytesLeft -= 3;
/* 1654 */       this._outputTail = b64variant.encodeBase64Chunk(b24, this._outputBuffer, this._outputTail);
/* 1655 */       if (--chunksBeforeLF <= 0) {
/* 1656 */         this._outputBuffer[this._outputTail++] = '\\';
/* 1657 */         this._outputBuffer[this._outputTail++] = 'n';
/* 1658 */         chunksBeforeLF = b64variant.getMaxLineLength() >> 2;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1663 */     if (bytesLeft > 0) {
/* 1664 */       inputEnd = _readMore(data, readBuffer, inputPtr, inputEnd, bytesLeft);
/* 1665 */       inputPtr = 0;
/* 1666 */       if (inputEnd > 0) {
/* 1667 */         int amount; if (this._outputTail > safeOutputEnd) {
/* 1668 */           _flushBuffer();
/*      */         }
/* 1670 */         int b24 = readBuffer[inputPtr++] << 16;
/*      */         
/* 1672 */         if (inputPtr < inputEnd) {
/* 1673 */           b24 |= (readBuffer[inputPtr] & 0xFF) << 8;
/* 1674 */           amount = 2;
/*      */         } else {
/* 1676 */           amount = 1;
/*      */         } 
/* 1678 */         this._outputTail = b64variant.encodeBase64Partial(b24, amount, this._outputBuffer, this._outputTail);
/* 1679 */         bytesLeft -= amount;
/*      */       } 
/*      */     } 
/* 1682 */     return bytesLeft;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final int _writeBinary(Base64Variant b64variant, InputStream data, byte[] readBuffer) throws IOException, JsonGenerationException {
/* 1690 */     int inputPtr = 0;
/* 1691 */     int inputEnd = 0;
/* 1692 */     int lastFullOffset = -3;
/* 1693 */     int bytesDone = 0;
/*      */ 
/*      */     
/* 1696 */     int safeOutputEnd = this._outputEnd - 6;
/* 1697 */     int chunksBeforeLF = b64variant.getMaxLineLength() >> 2;
/*      */ 
/*      */     
/*      */     while (true) {
/* 1701 */       if (inputPtr > lastFullOffset) {
/* 1702 */         inputEnd = _readMore(data, readBuffer, inputPtr, inputEnd, readBuffer.length);
/* 1703 */         inputPtr = 0;
/* 1704 */         if (inputEnd < 3) {
/*      */           break;
/*      */         }
/* 1707 */         lastFullOffset = inputEnd - 3;
/*      */       } 
/* 1709 */       if (this._outputTail > safeOutputEnd) {
/* 1710 */         _flushBuffer();
/*      */       }
/*      */       
/* 1713 */       int b24 = readBuffer[inputPtr++] << 8;
/* 1714 */       b24 |= readBuffer[inputPtr++] & 0xFF;
/* 1715 */       b24 = b24 << 8 | readBuffer[inputPtr++] & 0xFF;
/* 1716 */       bytesDone += 3;
/* 1717 */       this._outputTail = b64variant.encodeBase64Chunk(b24, this._outputBuffer, this._outputTail);
/* 1718 */       if (--chunksBeforeLF <= 0) {
/* 1719 */         this._outputBuffer[this._outputTail++] = '\\';
/* 1720 */         this._outputBuffer[this._outputTail++] = 'n';
/* 1721 */         chunksBeforeLF = b64variant.getMaxLineLength() >> 2;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1726 */     if (inputPtr < inputEnd) {
/* 1727 */       if (this._outputTail > safeOutputEnd) {
/* 1728 */         _flushBuffer();
/*      */       }
/* 1730 */       int b24 = readBuffer[inputPtr++] << 16;
/* 1731 */       int amount = 1;
/* 1732 */       if (inputPtr < inputEnd) {
/* 1733 */         b24 |= (readBuffer[inputPtr] & 0xFF) << 8;
/* 1734 */         amount = 2;
/*      */       } 
/* 1736 */       bytesDone += amount;
/* 1737 */       this._outputTail = b64variant.encodeBase64Partial(b24, amount, this._outputBuffer, this._outputTail);
/*      */     } 
/* 1739 */     return bytesDone;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int _readMore(InputStream in, byte[] readBuffer, int inputPtr, int inputEnd, int maxRead) throws IOException {
/* 1747 */     int i = 0;
/* 1748 */     while (inputPtr < inputEnd) {
/* 1749 */       readBuffer[i++] = readBuffer[inputPtr++];
/*      */     }
/* 1751 */     inputPtr = 0;
/* 1752 */     inputEnd = i;
/* 1753 */     maxRead = Math.min(maxRead, readBuffer.length);
/*      */     
/*      */     do {
/* 1756 */       int length = maxRead - inputEnd;
/* 1757 */       if (length == 0) {
/*      */         break;
/*      */       }
/* 1760 */       int count = in.read(readBuffer, inputEnd, length);
/* 1761 */       if (count < 0) {
/* 1762 */         return inputEnd;
/*      */       }
/* 1764 */       inputEnd += count;
/* 1765 */     } while (inputEnd < 3);
/* 1766 */     return inputEnd;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _writeNull() throws IOException {
/* 1777 */     if (this._outputTail + 4 >= this._outputEnd) {
/* 1778 */       _flushBuffer();
/*      */     }
/* 1780 */     int ptr = this._outputTail;
/* 1781 */     char[] buf = this._outputBuffer;
/* 1782 */     buf[ptr] = 'n';
/* 1783 */     buf[++ptr] = 'u';
/* 1784 */     buf[++ptr] = 'l';
/* 1785 */     buf[++ptr] = 'l';
/* 1786 */     this._outputTail = ptr + 1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void _prependOrWriteCharacterEscape(char ch, int escCode) throws IOException, JsonGenerationException {
/*      */     String escape;
/* 1803 */     if (escCode >= 0) {
/* 1804 */       if (this._outputTail >= 2) {
/* 1805 */         int ptr = this._outputTail - 2;
/* 1806 */         this._outputHead = ptr;
/* 1807 */         this._outputBuffer[ptr++] = '\\';
/* 1808 */         this._outputBuffer[ptr] = (char)escCode;
/*      */         
/*      */         return;
/*      */       } 
/* 1812 */       char[] buf = this._entityBuffer;
/* 1813 */       if (buf == null) {
/* 1814 */         buf = _allocateEntityBuffer();
/*      */       }
/* 1816 */       this._outputHead = this._outputTail;
/* 1817 */       buf[1] = (char)escCode;
/* 1818 */       this._writer.write(buf, 0, 2);
/*      */       return;
/*      */     } 
/* 1821 */     if (escCode != -2) {
/* 1822 */       char[] HEX_CHARS = getHexChars();
/* 1823 */       if (this._outputTail >= 6) {
/* 1824 */         char[] arrayOfChar = this._outputBuffer;
/* 1825 */         int ptr = this._outputTail - 6;
/* 1826 */         this._outputHead = ptr;
/* 1827 */         arrayOfChar[ptr] = '\\';
/* 1828 */         arrayOfChar[++ptr] = 'u';
/*      */         
/* 1830 */         if (ch > 'ÿ') {
/* 1831 */           int hi = ch >> 8 & 0xFF;
/* 1832 */           arrayOfChar[++ptr] = HEX_CHARS[hi >> 4];
/* 1833 */           arrayOfChar[++ptr] = HEX_CHARS[hi & 0xF];
/* 1834 */           ch = (char)(ch & 0xFF);
/*      */         } else {
/* 1836 */           arrayOfChar[++ptr] = '0';
/* 1837 */           arrayOfChar[++ptr] = '0';
/*      */         } 
/* 1839 */         arrayOfChar[++ptr] = HEX_CHARS[ch >> 4];
/* 1840 */         arrayOfChar[++ptr] = HEX_CHARS[ch & 0xF];
/*      */         
/*      */         return;
/*      */       } 
/* 1844 */       char[] buf = this._entityBuffer;
/* 1845 */       if (buf == null) {
/* 1846 */         buf = _allocateEntityBuffer();
/*      */       }
/* 1848 */       this._outputHead = this._outputTail;
/* 1849 */       if (ch > 'ÿ') {
/* 1850 */         int hi = ch >> 8 & 0xFF;
/* 1851 */         int lo = ch & 0xFF;
/* 1852 */         buf[10] = HEX_CHARS[hi >> 4];
/* 1853 */         buf[11] = HEX_CHARS[hi & 0xF];
/* 1854 */         buf[12] = HEX_CHARS[lo >> 4];
/* 1855 */         buf[13] = HEX_CHARS[lo & 0xF];
/* 1856 */         this._writer.write(buf, 8, 6);
/*      */       } else {
/* 1858 */         buf[6] = HEX_CHARS[ch >> 4];
/* 1859 */         buf[7] = HEX_CHARS[ch & 0xF];
/* 1860 */         this._writer.write(buf, 2, 6);
/*      */       } 
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 1866 */     if (this._currentEscape == null) {
/* 1867 */       escape = this._characterEscapes.getEscapeSequence(ch).getValue();
/*      */     } else {
/* 1869 */       escape = this._currentEscape.getValue();
/* 1870 */       this._currentEscape = null;
/*      */     } 
/* 1872 */     int len = escape.length();
/* 1873 */     if (this._outputTail >= len) {
/* 1874 */       int ptr = this._outputTail - len;
/* 1875 */       this._outputHead = ptr;
/* 1876 */       escape.getChars(0, len, this._outputBuffer, ptr);
/*      */       
/*      */       return;
/*      */     } 
/* 1880 */     this._outputHead = this._outputTail;
/* 1881 */     this._writer.write(escape);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int _prependOrWriteCharacterEscape(char[] buffer, int ptr, int end, char ch, int escCode) throws IOException, JsonGenerationException {
/*      */     String escape;
/* 1895 */     if (escCode >= 0) {
/* 1896 */       if (ptr > 1 && ptr < end) {
/* 1897 */         ptr -= 2;
/* 1898 */         buffer[ptr] = '\\';
/* 1899 */         buffer[ptr + 1] = (char)escCode;
/*      */       } else {
/* 1901 */         char[] ent = this._entityBuffer;
/* 1902 */         if (ent == null) {
/* 1903 */           ent = _allocateEntityBuffer();
/*      */         }
/* 1905 */         ent[1] = (char)escCode;
/* 1906 */         this._writer.write(ent, 0, 2);
/*      */       } 
/* 1908 */       return ptr;
/*      */     } 
/* 1910 */     if (escCode != -2) {
/* 1911 */       char[] HEX_CHARS = getHexChars();
/* 1912 */       if (ptr > 5 && ptr < end) {
/* 1913 */         ptr -= 6;
/* 1914 */         buffer[ptr++] = '\\';
/* 1915 */         buffer[ptr++] = 'u';
/*      */         
/* 1917 */         if (ch > 'ÿ') {
/* 1918 */           int hi = ch >> 8 & 0xFF;
/* 1919 */           buffer[ptr++] = HEX_CHARS[hi >> 4];
/* 1920 */           buffer[ptr++] = HEX_CHARS[hi & 0xF];
/* 1921 */           ch = (char)(ch & 0xFF);
/*      */         } else {
/* 1923 */           buffer[ptr++] = '0';
/* 1924 */           buffer[ptr++] = '0';
/*      */         } 
/* 1926 */         buffer[ptr++] = HEX_CHARS[ch >> 4];
/* 1927 */         buffer[ptr] = HEX_CHARS[ch & 0xF];
/* 1928 */         ptr -= 5;
/*      */       } else {
/*      */         
/* 1931 */         char[] ent = this._entityBuffer;
/* 1932 */         if (ent == null) {
/* 1933 */           ent = _allocateEntityBuffer();
/*      */         }
/* 1935 */         this._outputHead = this._outputTail;
/* 1936 */         if (ch > 'ÿ') {
/* 1937 */           int hi = ch >> 8 & 0xFF;
/* 1938 */           int lo = ch & 0xFF;
/* 1939 */           ent[10] = HEX_CHARS[hi >> 4];
/* 1940 */           ent[11] = HEX_CHARS[hi & 0xF];
/* 1941 */           ent[12] = HEX_CHARS[lo >> 4];
/* 1942 */           ent[13] = HEX_CHARS[lo & 0xF];
/* 1943 */           this._writer.write(ent, 8, 6);
/*      */         } else {
/* 1945 */           ent[6] = HEX_CHARS[ch >> 4];
/* 1946 */           ent[7] = HEX_CHARS[ch & 0xF];
/* 1947 */           this._writer.write(ent, 2, 6);
/*      */         } 
/*      */       } 
/* 1950 */       return ptr;
/*      */     } 
/*      */     
/* 1953 */     if (this._currentEscape == null) {
/* 1954 */       escape = this._characterEscapes.getEscapeSequence(ch).getValue();
/*      */     } else {
/* 1956 */       escape = this._currentEscape.getValue();
/* 1957 */       this._currentEscape = null;
/*      */     } 
/* 1959 */     int len = escape.length();
/* 1960 */     if (ptr >= len && ptr < end) {
/* 1961 */       ptr -= len;
/* 1962 */       escape.getChars(0, len, buffer, ptr);
/*      */     } else {
/* 1964 */       this._writer.write(escape);
/*      */     } 
/* 1966 */     return ptr;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void _appendCharacterEscape(char ch, int escCode) throws IOException, JsonGenerationException {
/*      */     String escape;
/* 1976 */     if (escCode >= 0) {
/* 1977 */       if (this._outputTail + 2 > this._outputEnd) {
/* 1978 */         _flushBuffer();
/*      */       }
/* 1980 */       this._outputBuffer[this._outputTail++] = '\\';
/* 1981 */       this._outputBuffer[this._outputTail++] = (char)escCode;
/*      */       return;
/*      */     } 
/* 1984 */     if (escCode != -2) {
/* 1985 */       if (this._outputTail + 5 >= this._outputEnd) {
/* 1986 */         _flushBuffer();
/*      */       }
/* 1988 */       int ptr = this._outputTail;
/* 1989 */       char[] buf = this._outputBuffer;
/* 1990 */       char[] HEX_CHARS = getHexChars();
/* 1991 */       buf[ptr++] = '\\';
/* 1992 */       buf[ptr++] = 'u';
/*      */       
/* 1994 */       if (ch > 'ÿ') {
/* 1995 */         int hi = ch >> 8 & 0xFF;
/* 1996 */         buf[ptr++] = HEX_CHARS[hi >> 4];
/* 1997 */         buf[ptr++] = HEX_CHARS[hi & 0xF];
/* 1998 */         ch = (char)(ch & 0xFF);
/*      */       } else {
/* 2000 */         buf[ptr++] = '0';
/* 2001 */         buf[ptr++] = '0';
/*      */       } 
/* 2003 */       buf[ptr++] = HEX_CHARS[ch >> 4];
/* 2004 */       buf[ptr++] = HEX_CHARS[ch & 0xF];
/* 2005 */       this._outputTail = ptr;
/*      */       
/*      */       return;
/*      */     } 
/* 2009 */     if (this._currentEscape == null) {
/* 2010 */       escape = this._characterEscapes.getEscapeSequence(ch).getValue();
/*      */     } else {
/* 2012 */       escape = this._currentEscape.getValue();
/* 2013 */       this._currentEscape = null;
/*      */     } 
/* 2015 */     int len = escape.length();
/* 2016 */     if (this._outputTail + len > this._outputEnd) {
/* 2017 */       _flushBuffer();
/* 2018 */       if (len > this._outputEnd) {
/* 2019 */         this._writer.write(escape);
/*      */         return;
/*      */       } 
/*      */     } 
/* 2023 */     escape.getChars(0, len, this._outputBuffer, this._outputTail);
/* 2024 */     this._outputTail += len;
/*      */   }
/*      */ 
/*      */   
/*      */   private char[] _allocateEntityBuffer() {
/* 2029 */     char[] buf = new char[14];
/*      */     
/* 2031 */     buf[0] = '\\';
/*      */     
/* 2033 */     buf[2] = '\\';
/* 2034 */     buf[3] = 'u';
/* 2035 */     buf[4] = '0';
/* 2036 */     buf[5] = '0';
/*      */     
/* 2038 */     buf[8] = '\\';
/* 2039 */     buf[9] = 'u';
/* 2040 */     this._entityBuffer = buf;
/* 2041 */     return buf;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private char[] _allocateCopyBuffer() {
/* 2048 */     if (this._copyBuffer == null) {
/* 2049 */       this._copyBuffer = this._ioContext.allocNameCopyBuffer(2000);
/*      */     }
/* 2051 */     return this._copyBuffer;
/*      */   }
/*      */ 
/*      */   
/*      */   protected void _flushBuffer() throws IOException {
/* 2056 */     int len = this._outputTail - this._outputHead;
/* 2057 */     if (len > 0) {
/* 2058 */       int offset = this._outputHead;
/* 2059 */       this._outputTail = this._outputHead = 0;
/* 2060 */       this._writer.write(this._outputBuffer, offset, len);
/*      */     } 
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-core-2.14.2.jar!\com\fasterxml\jackson\core\json\WriterBasedJsonGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */