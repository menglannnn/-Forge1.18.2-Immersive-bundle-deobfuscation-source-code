package com.fasterxml.jackson.core;

import java.util.Iterator;

public interface TreeNode {
  JsonToken asToken();
  
  JsonParser.NumberType numberType();
  
  int size();
  
  boolean isValueNode();
  
  boolean isContainerNode();
  
  boolean isMissingNode();
  
  boolean isArray();
  
  boolean isObject();
  
  TreeNode get(String paramString);
  
  TreeNode get(int paramInt);
  
  TreeNode path(String paramString);
  
  TreeNode path(int paramInt);
  
  Iterator<String> fieldNames();
  
  TreeNode at(JsonPointer paramJsonPointer);
  
  TreeNode at(String paramString) throws IllegalArgumentException;
  
  JsonParser traverse();
  
  JsonParser traverse(ObjectCodec paramObjectCodec);
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-core-2.14.2.jar!\com\fasterxml\jackson\core\TreeNode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */