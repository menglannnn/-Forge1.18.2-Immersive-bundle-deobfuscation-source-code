/*     */ package com.fasterxml.jackson.core.io.doubleparser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class FastFloatMath
/*     */ {
/*     */   private static final int FLOAT_EXPONENT_BIAS = 127;
/*     */   private static final int FLOAT_SIGNIFICAND_WIDTH = 24;
/*     */   private static final int FLOAT_MIN_EXPONENT_POWER_OF_TEN = -45;
/*     */   private static final int FLOAT_MAX_EXPONENT_POWER_OF_TEN = 38;
/*     */   private static final int FLOAT_MIN_EXPONENT_POWER_OF_TWO = -126;
/*     */   private static final int FLOAT_MAX_EXPONENT_POWER_OF_TWO = 127;
/*  41 */   private static final float[] FLOAT_POWER_OF_TEN = new float[] { 1.0F, 10.0F, 100.0F, 1000.0F, 10000.0F, 100000.0F, 1000000.0F, 1.0E7F, 1.0E8F, 1.0E9F, 1.0E10F };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static float decFloatLiteralToFloat(boolean isNegative, long significand, int exponent, boolean isSignificandTruncated, int exponentOfTruncatedSignificand) {
/*     */     float result;
/*  54 */     if (significand == 0L) {
/*  55 */       return isNegative ? -0.0F : 0.0F;
/*     */     }
/*     */ 
/*     */     
/*  59 */     if (isSignificandTruncated) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  65 */       if (-45 <= exponentOfTruncatedSignificand && exponentOfTruncatedSignificand <= 38) {
/*     */         
/*  67 */         float withoutRounding = tryDecToFloatWithFastAlgorithm(isNegative, significand, exponentOfTruncatedSignificand);
/*  68 */         float roundedUp = tryDecToFloatWithFastAlgorithm(isNegative, significand + 1L, exponentOfTruncatedSignificand);
/*  69 */         if (!Float.isNaN(withoutRounding) && roundedUp == withoutRounding) {
/*  70 */           return withoutRounding;
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/*  76 */       result = Float.NaN;
/*     */     
/*     */     }
/*  79 */     else if (-45 <= exponent && exponent <= 38) {
/*  80 */       result = tryDecToFloatWithFastAlgorithm(isNegative, significand, exponent);
/*     */     } else {
/*  82 */       result = Float.NaN;
/*     */     } 
/*  84 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   static float hexFloatLiteralToFloat(boolean isNegative, long significand, int exponent, boolean isSignificandTruncated, int exponentOfTruncatedSignificand) {
/*     */     float result;
/*  90 */     if (significand == 0L) {
/*  91 */       return isNegative ? -0.0F : 0.0F;
/*     */     }
/*     */     
/*  94 */     if (isSignificandTruncated) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 100 */       if (-126 <= exponentOfTruncatedSignificand && exponentOfTruncatedSignificand <= 127) {
/* 101 */         float withoutRounding = tryHexToFloatWithFastAlgorithm(isNegative, significand, exponentOfTruncatedSignificand);
/* 102 */         float roundedUp = tryHexToFloatWithFastAlgorithm(isNegative, significand + 1L, exponentOfTruncatedSignificand);
/* 103 */         if (!Double.isNaN(withoutRounding) && roundedUp == withoutRounding) {
/* 104 */           return withoutRounding;
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 109 */       result = Float.NaN;
/*     */     }
/* 111 */     else if (-126 <= exponent && exponent <= 127) {
/* 112 */       result = tryHexToFloatWithFastAlgorithm(isNegative, significand, exponent);
/*     */     } else {
/* 114 */       result = Float.NaN;
/*     */     } 
/* 116 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static float tryDecToFloatWithFastAlgorithm(boolean isNegative, long digits, int power) {
/* 138 */     if (-10 <= power && power <= 10 && Long.compareUnsigned(digits, 16777215L) <= 0) {
/*     */ 
/*     */       
/* 141 */       float d = (float)digits;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 149 */       if (power < 0) {
/* 150 */         d /= FLOAT_POWER_OF_TEN[-power];
/*     */       } else {
/* 152 */         d *= FLOAT_POWER_OF_TEN[power];
/*     */       } 
/* 154 */       return isNegative ? -d : d;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 167 */     long factorMantissa = FastDoubleMath.MANTISSA_64[power - -325];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 197 */     long exponent = (217706L * power >> 16L) + 127L + 64L;
/*     */     
/* 199 */     int lz = Long.numberOfLeadingZeros(digits);
/* 200 */     digits <<= lz;
/*     */ 
/*     */ 
/*     */     
/* 204 */     FastDoubleMath.UInt128 product = FastDoubleMath.fullMultiplication(digits, factorMantissa);
/* 205 */     long lower = product.low;
/* 206 */     long upper = product.high;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 221 */     if ((upper & 0x3FFFFFFFFFL) == 274877906943L && Long.compareUnsigned(lower + digits, lower) < 0) {
/* 222 */       long factor_mantissa_low = FastDoubleMath.MANTISSA_128[power - -325];
/*     */ 
/*     */ 
/*     */       
/* 226 */       product = FastDoubleMath.fullMultiplication(digits, factor_mantissa_low);
/* 227 */       long product_low = product.low;
/* 228 */       long product_middle2 = product.high;
/* 229 */       long product_middle1 = lower;
/* 230 */       long product_high = upper;
/* 231 */       long product_middle = product_middle1 + product_middle2;
/* 232 */       if (Long.compareUnsigned(product_middle, product_middle1) < 0) {
/* 233 */         product_high++;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 239 */       if (product_middle + 1L == 0L && (product_high & 0x7FFFFFFFFFL) == 549755813887L && product_low + 
/* 240 */         Long.compareUnsigned(digits, product_low) < 0L) {
/* 241 */         return Float.NaN;
/*     */       }
/* 243 */       upper = product_high;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 249 */     long upperbit = upper >>> 63L;
/* 250 */     long mantissa = upper >>> (int)(upperbit + 38L);
/* 251 */     lz += (int)(0x1L ^ upperbit);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 260 */     if ((upper & 0x3FFFFFFFFFL) == 274877906943L || ((upper & 0x3FFFFFFFFFL) == 0L && (mantissa & 0x3L) == 1L))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 279 */       return Float.NaN;
/*     */     }
/*     */     
/* 282 */     mantissa++;
/* 283 */     mantissa >>>= 1L;
/*     */ 
/*     */     
/* 286 */     if (mantissa >= 16777216L) {
/*     */       
/* 288 */       mantissa = 8388608L;
/* 289 */       lz--;
/*     */     } 
/*     */     
/* 292 */     mantissa &= 0xFFFFFFFFFF7FFFFFL;
/*     */ 
/*     */     
/* 295 */     long real_exponent = exponent - lz;
/*     */     
/* 297 */     if (real_exponent < 1L || real_exponent > 254L) {
/* 298 */       return Float.NaN;
/*     */     }
/*     */     
/* 301 */     int bits = (int)(mantissa | real_exponent << 23L | (isNegative ? 2147483648L : 0L));
/*     */     
/* 303 */     return Float.intBitsToFloat(bits);
/*     */   }
/*     */   
/*     */   static float tryHexToFloatWithFastAlgorithm(boolean isNegative, long digits, int power) {
/* 307 */     if (digits == 0L || power < -180) {
/* 308 */       return isNegative ? -0.0F : 0.0F;
/*     */     }
/* 310 */     if (power > 127) {
/* 311 */       return isNegative ? Float.NEGATIVE_INFINITY : Float.POSITIVE_INFINITY;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 318 */     if (Long.compareUnsigned(digits, 9007199254740991L) <= 0) {
/*     */ 
/*     */       
/* 321 */       float d = (float)digits;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 330 */       d *= Math.scalb(1.0F, power);
/* 331 */       if (isNegative) {
/* 332 */         d = -d;
/*     */       }
/* 334 */       return d;
/*     */     } 
/*     */ 
/*     */     
/* 338 */     return Float.NaN;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-core-2.14.2.jar!\com\fasterxml\jackson\core\io\doubleparser\FastFloatMath.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */