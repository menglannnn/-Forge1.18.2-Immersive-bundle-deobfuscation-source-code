/*      */ package com.fasterxml.jackson.core;
/*      */ 
/*      */ import com.fasterxml.jackson.core.format.InputAccessor;
/*      */ import com.fasterxml.jackson.core.format.MatchStrength;
/*      */ import com.fasterxml.jackson.core.io.CharacterEscapes;
/*      */ import com.fasterxml.jackson.core.io.ContentReference;
/*      */ import com.fasterxml.jackson.core.io.IOContext;
/*      */ import com.fasterxml.jackson.core.io.InputDecorator;
/*      */ import com.fasterxml.jackson.core.io.OutputDecorator;
/*      */ import com.fasterxml.jackson.core.io.SerializedString;
/*      */ import com.fasterxml.jackson.core.io.UTF8Writer;
/*      */ import com.fasterxml.jackson.core.json.ByteSourceJsonBootstrapper;
/*      */ import com.fasterxml.jackson.core.json.PackageVersion;
/*      */ import com.fasterxml.jackson.core.json.ReaderBasedJsonParser;
/*      */ import com.fasterxml.jackson.core.json.UTF8DataInputJsonParser;
/*      */ import com.fasterxml.jackson.core.json.UTF8JsonGenerator;
/*      */ import com.fasterxml.jackson.core.json.WriterBasedJsonGenerator;
/*      */ import com.fasterxml.jackson.core.json.async.NonBlockingByteBufferJsonParser;
/*      */ import com.fasterxml.jackson.core.json.async.NonBlockingJsonParser;
/*      */ import com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer;
/*      */ import com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer;
/*      */ import com.fasterxml.jackson.core.util.BufferRecycler;
/*      */ import com.fasterxml.jackson.core.util.BufferRecyclers;
/*      */ import com.fasterxml.jackson.core.util.DefaultPrettyPrinter;
/*      */ import com.fasterxml.jackson.core.util.JacksonFeature;
/*      */ import java.io.CharArrayReader;
/*      */ import java.io.DataInput;
/*      */ import java.io.DataOutput;
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.OutputStreamWriter;
/*      */ import java.io.Reader;
/*      */ import java.io.Serializable;
/*      */ import java.io.StringReader;
/*      */ import java.io.Writer;
/*      */ import java.net.URL;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class JsonFactory
/*      */   extends TokenStreamFactory
/*      */   implements Versioned, Serializable
/*      */ {
/*      */   private static final long serialVersionUID = 2L;
/*      */   public static final String FORMAT_NAME_JSON = "JSON";
/*      */   
/*      */   public enum Feature
/*      */     implements JacksonFeature
/*      */   {
/*   82 */     INTERN_FIELD_NAMES(true),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   92 */     CANONICALIZE_FIELD_NAMES(true),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  108 */     FAIL_ON_SYMBOL_HASH_OVERFLOW(true),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  125 */     USE_THREAD_LOCAL_FOR_BUFFER_RECYCLING(true);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final boolean _defaultState;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static int collectDefaults() {
/*  141 */       int flags = 0;
/*  142 */       for (Feature f : values()) {
/*  143 */         if (f.enabledByDefault()) flags |= f.getMask(); 
/*      */       } 
/*  145 */       return flags;
/*      */     }
/*      */     Feature(boolean defaultState) {
/*  148 */       this._defaultState = defaultState;
/*      */     }
/*      */     public boolean enabledByDefault() {
/*  151 */       return this._defaultState;
/*      */     } public boolean enabledIn(int flags) {
/*  153 */       return ((flags & getMask()) != 0);
/*      */     } public int getMask() {
/*  155 */       return 1 << ordinal();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  173 */   protected static final int DEFAULT_FACTORY_FEATURE_FLAGS = Feature.collectDefaults();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  179 */   protected static final int DEFAULT_PARSER_FEATURE_FLAGS = JsonParser.Feature.collectDefaults();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  185 */   protected static final int DEFAULT_GENERATOR_FEATURE_FLAGS = JsonGenerator.Feature.collectDefaults();
/*      */   
/*  187 */   public static final SerializableString DEFAULT_ROOT_VALUE_SEPARATOR = (SerializableString)DefaultPrettyPrinter.DEFAULT_ROOT_VALUE_SEPARATOR;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final char DEFAULT_QUOTE_CHAR = '"';
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  205 */   protected final transient CharsToNameCanonicalizer _rootCharSymbols = CharsToNameCanonicalizer.createRoot();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  216 */   protected final transient ByteQuadsCanonicalizer _byteSymbolCanonicalizer = ByteQuadsCanonicalizer.createRoot();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  227 */   protected int _factoryFeatures = DEFAULT_FACTORY_FEATURE_FLAGS;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  232 */   protected int _parserFeatures = DEFAULT_PARSER_FEATURE_FLAGS;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  237 */   protected int _generatorFeatures = DEFAULT_GENERATOR_FEATURE_FLAGS;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ObjectCodec _objectCodec;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected CharacterEscapes _characterEscapes;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected InputDecorator _inputDecorator;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected OutputDecorator _outputDecorator;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  280 */   protected SerializableString _rootValueSeparator = DEFAULT_ROOT_VALUE_SEPARATOR;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _maximumNonEscapedChar;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final char _quoteChar;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonFactory() {
/*  315 */     this((ObjectCodec)null);
/*      */   }
/*      */   public JsonFactory(ObjectCodec oc) {
/*  318 */     this._objectCodec = oc;
/*  319 */     this._quoteChar = '"';
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonFactory(JsonFactory src, ObjectCodec codec) {
/*  332 */     this._objectCodec = codec;
/*      */ 
/*      */     
/*  335 */     this._factoryFeatures = src._factoryFeatures;
/*  336 */     this._parserFeatures = src._parserFeatures;
/*  337 */     this._generatorFeatures = src._generatorFeatures;
/*  338 */     this._inputDecorator = src._inputDecorator;
/*  339 */     this._outputDecorator = src._outputDecorator;
/*      */ 
/*      */     
/*  342 */     this._characterEscapes = src._characterEscapes;
/*  343 */     this._rootValueSeparator = src._rootValueSeparator;
/*  344 */     this._maximumNonEscapedChar = src._maximumNonEscapedChar;
/*  345 */     this._quoteChar = src._quoteChar;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonFactory(JsonFactoryBuilder b) {
/*  356 */     this._objectCodec = null;
/*      */ 
/*      */     
/*  359 */     this._factoryFeatures = b._factoryFeatures;
/*  360 */     this._parserFeatures = b._streamReadFeatures;
/*  361 */     this._generatorFeatures = b._streamWriteFeatures;
/*  362 */     this._inputDecorator = b._inputDecorator;
/*  363 */     this._outputDecorator = b._outputDecorator;
/*      */ 
/*      */     
/*  366 */     this._characterEscapes = b._characterEscapes;
/*  367 */     this._rootValueSeparator = b._rootValueSeparator;
/*  368 */     this._maximumNonEscapedChar = b._maximumNonEscapedChar;
/*  369 */     this._quoteChar = b._quoteChar;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonFactory(TSFBuilder<?, ?> b, boolean bogus) {
/*  381 */     this._objectCodec = null;
/*      */     
/*  383 */     this._factoryFeatures = b._factoryFeatures;
/*  384 */     this._parserFeatures = b._streamReadFeatures;
/*  385 */     this._generatorFeatures = b._streamWriteFeatures;
/*  386 */     this._inputDecorator = b._inputDecorator;
/*  387 */     this._outputDecorator = b._outputDecorator;
/*      */ 
/*      */     
/*  390 */     this._characterEscapes = null;
/*  391 */     this._rootValueSeparator = null;
/*  392 */     this._maximumNonEscapedChar = 0;
/*  393 */     this._quoteChar = '"';
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TSFBuilder<?, ?> rebuild() {
/*  406 */     _requireJSONFactory("Factory implementation for format (%s) MUST override `rebuild()` method");
/*  407 */     return new JsonFactoryBuilder(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static TSFBuilder<?, ?> builder() {
/*  422 */     return new JsonFactoryBuilder();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonFactory copy() {
/*  443 */     _checkInvalidCopy(JsonFactory.class);
/*      */     
/*  445 */     return new JsonFactory(this, null);
/*      */   }
/*      */ 
/*      */   
/*      */   protected void _checkInvalidCopy(Class<?> exp) {
/*  450 */     if (getClass() != exp) {
/*  451 */       throw new IllegalStateException("Failed copy(): " + getClass().getName() + " (version: " + 
/*  452 */           version() + ") does not override copy(); it has to");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object readResolve() {
/*  472 */     return new JsonFactory(this, this._objectCodec);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean requiresPropertyOrdering() {
/*  500 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean canHandleBinaryNatively() {
/*  518 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean canUseCharArrays() {
/*  535 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean canParseAsync() {
/*  552 */     return _isJSONFactory();
/*      */   }
/*      */ 
/*      */   
/*      */   public Class<? extends FormatFeature> getFormatReadFeatureType() {
/*  557 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public Class<? extends FormatFeature> getFormatWriteFeatureType() {
/*  562 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean canUseSchema(FormatSchema schema) {
/*  586 */     if (schema == null) {
/*  587 */       return false;
/*      */     }
/*  589 */     String ourFormat = getFormatName();
/*  590 */     return (ourFormat != null && ourFormat.equals(schema.getSchemaType()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getFormatName() {
/*  609 */     if (getClass() == JsonFactory.class) {
/*  610 */       return "JSON";
/*      */     }
/*  612 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public MatchStrength hasFormat(InputAccessor acc) throws IOException {
/*  618 */     if (getClass() == JsonFactory.class) {
/*  619 */       return hasJSONFormat(acc);
/*      */     }
/*  621 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean requiresCustomCodec() {
/*  638 */     return false;
/*      */   }
/*      */   
/*      */   protected MatchStrength hasJSONFormat(InputAccessor acc) throws IOException {
/*  642 */     return ByteSourceJsonBootstrapper.hasJSONFormat(acc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Version version() {
/*  653 */     return PackageVersion.VERSION;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public final JsonFactory configure(Feature f, boolean state) {
/*  675 */     return state ? enable(f) : disable(f);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JsonFactory enable(Feature f) {
/*  690 */     this._factoryFeatures |= f.getMask();
/*  691 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JsonFactory disable(Feature f) {
/*  706 */     this._factoryFeatures &= f.getMask() ^ 0xFFFFFFFF;
/*  707 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isEnabled(Feature f) {
/*  718 */     return ((this._factoryFeatures & f.getMask()) != 0);
/*      */   }
/*      */ 
/*      */   
/*      */   public final int getParserFeatures() {
/*  723 */     return this._parserFeatures;
/*      */   }
/*      */ 
/*      */   
/*      */   public final int getGeneratorFeatures() {
/*  728 */     return this._generatorFeatures;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getFormatParserFeatures() {
/*  734 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getFormatGeneratorFeatures() {
/*  740 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final JsonFactory configure(JsonParser.Feature f, boolean state) {
/*  759 */     return state ? enable(f) : disable(f);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonFactory enable(JsonParser.Feature f) {
/*  771 */     this._parserFeatures |= f.getMask();
/*  772 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonFactory disable(JsonParser.Feature f) {
/*  784 */     this._parserFeatures &= f.getMask() ^ 0xFFFFFFFF;
/*  785 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isEnabled(JsonParser.Feature f) {
/*  797 */     return ((this._parserFeatures & f.getMask()) != 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isEnabled(StreamReadFeature f) {
/*  810 */     return ((this._parserFeatures & f.mappedFeature().getMask()) != 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputDecorator getInputDecorator() {
/*  820 */     return this._inputDecorator;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JsonFactory setInputDecorator(InputDecorator d) {
/*  834 */     this._inputDecorator = d;
/*  835 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final JsonFactory configure(JsonGenerator.Feature f, boolean state) {
/*  854 */     return state ? enable(f) : disable(f);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonFactory enable(JsonGenerator.Feature f) {
/*  866 */     this._generatorFeatures |= f.getMask();
/*  867 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonFactory disable(JsonGenerator.Feature f) {
/*  879 */     this._generatorFeatures &= f.getMask() ^ 0xFFFFFFFF;
/*  880 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isEnabled(JsonGenerator.Feature f) {
/*  892 */     return ((this._generatorFeatures & f.getMask()) != 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isEnabled(StreamWriteFeature f) {
/*  905 */     return ((this._generatorFeatures & f.mappedFeature().getMask()) != 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CharacterEscapes getCharacterEscapes() {
/*  914 */     return this._characterEscapes;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonFactory setCharacterEscapes(CharacterEscapes esc) {
/*  925 */     this._characterEscapes = esc;
/*  926 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OutputDecorator getOutputDecorator() {
/*  937 */     return this._outputDecorator;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JsonFactory setOutputDecorator(OutputDecorator d) {
/*  951 */     this._outputDecorator = d;
/*  952 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonFactory setRootValueSeparator(String sep) {
/*  965 */     this._rootValueSeparator = (sep == null) ? null : (SerializableString)new SerializedString(sep);
/*  966 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getRootValueSeparator() {
/*  973 */     return (this._rootValueSeparator == null) ? null : this._rootValueSeparator.getValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonFactory setCodec(ObjectCodec oc) {
/*  994 */     this._objectCodec = oc;
/*  995 */     return this;
/*      */   }
/*      */   public ObjectCodec getCodec() {
/*  998 */     return this._objectCodec;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createParser(File f) throws IOException, JsonParseException {
/* 1029 */     IOContext ctxt = _createContext(_createContentReference(f), true);
/* 1030 */     InputStream in = _fileInputStream(f);
/* 1031 */     return _createParser(_decorate(in, ctxt), ctxt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createParser(URL url) throws IOException, JsonParseException {
/* 1055 */     IOContext ctxt = _createContext(_createContentReference(url), true);
/* 1056 */     InputStream in = _optimizedStreamFromURL(url);
/* 1057 */     return _createParser(_decorate(in, ctxt), ctxt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createParser(InputStream in) throws IOException, JsonParseException {
/* 1083 */     IOContext ctxt = _createContext(_createContentReference(in), false);
/* 1084 */     return _createParser(_decorate(in, ctxt), ctxt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createParser(Reader r) throws IOException, JsonParseException {
/* 1104 */     IOContext ctxt = _createContext(_createContentReference(r), false);
/* 1105 */     return _createParser(_decorate(r, ctxt), ctxt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createParser(byte[] data) throws IOException, JsonParseException {
/* 1116 */     IOContext ctxt = _createContext(_createContentReference(data), true);
/* 1117 */     if (this._inputDecorator != null) {
/* 1118 */       InputStream in = this._inputDecorator.decorate(ctxt, data, 0, data.length);
/* 1119 */       if (in != null) {
/* 1120 */         return _createParser(in, ctxt);
/*      */       }
/*      */     } 
/* 1123 */     return _createParser(data, 0, data.length, ctxt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createParser(byte[] data, int offset, int len) throws IOException, JsonParseException {
/* 1138 */     _checkRangeBoundsForByteArray(data, offset, len);
/* 1139 */     IOContext ctxt = _createContext(_createContentReference(data, offset, len), true);
/*      */     
/* 1141 */     if (this._inputDecorator != null) {
/* 1142 */       InputStream in = this._inputDecorator.decorate(ctxt, data, offset, len);
/* 1143 */       if (in != null) {
/* 1144 */         return _createParser(in, ctxt);
/*      */       }
/*      */     } 
/* 1147 */     return _createParser(data, offset, len, ctxt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createParser(String content) throws IOException, JsonParseException {
/* 1158 */     int strLen = content.length();
/*      */     
/* 1160 */     if (this._inputDecorator != null || strLen > 32768 || !canUseCharArrays())
/*      */     {
/*      */       
/* 1163 */       return createParser(new StringReader(content));
/*      */     }
/* 1165 */     IOContext ctxt = _createContext(_createContentReference(content), true);
/* 1166 */     char[] buf = ctxt.allocTokenBuffer(strLen);
/* 1167 */     content.getChars(0, strLen, buf, 0);
/* 1168 */     return _createParser(buf, 0, strLen, ctxt, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createParser(char[] content) throws IOException {
/* 1179 */     return createParser(content, 0, content.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createParser(char[] content, int offset, int len) throws IOException {
/* 1189 */     _checkRangeBoundsForCharArray(content, offset, len);
/* 1190 */     if (this._inputDecorator != null) {
/* 1191 */       return createParser(new CharArrayReader(content, offset, len));
/*      */     }
/* 1193 */     return _createParser(content, offset, len, 
/* 1194 */         _createContext(_createContentReference(content, offset, len), true), false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createParser(DataInput in) throws IOException {
/* 1210 */     IOContext ctxt = _createContext(_createContentReference(in), false);
/* 1211 */     return _createParser(_decorate(in, ctxt), ctxt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createNonBlockingByteArrayParser() throws IOException {
/* 1241 */     _requireJSONFactory("Non-blocking source not (yet?) supported for this format (%s)");
/* 1242 */     IOContext ctxt = _createNonBlockingContext((Object)null);
/* 1243 */     ByteQuadsCanonicalizer can = this._byteSymbolCanonicalizer.makeChild(this._factoryFeatures);
/* 1244 */     return (JsonParser)new NonBlockingJsonParser(ctxt, this._parserFeatures, can);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createNonBlockingByteBufferParser() throws IOException {
/* 1268 */     _requireJSONFactory("Non-blocking source not (yet?) supported for this format (%s)");
/* 1269 */     IOContext ctxt = _createNonBlockingContext((Object)null);
/* 1270 */     ByteQuadsCanonicalizer can = this._byteSymbolCanonicalizer.makeChild(this._factoryFeatures);
/* 1271 */     return (JsonParser)new NonBlockingByteBufferJsonParser(ctxt, this._parserFeatures, can);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonGenerator createGenerator(OutputStream out, JsonEncoding enc) throws IOException {
/* 1307 */     IOContext ctxt = _createContext(_createContentReference(out), false);
/* 1308 */     ctxt.setEncoding(enc);
/* 1309 */     if (enc == JsonEncoding.UTF8) {
/* 1310 */       return _createUTF8Generator(_decorate(out, ctxt), ctxt);
/*      */     }
/* 1312 */     Writer w = _createWriter(out, enc, ctxt);
/* 1313 */     return _createGenerator(_decorate(w, ctxt), ctxt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonGenerator createGenerator(OutputStream out) throws IOException {
/* 1326 */     return createGenerator(out, JsonEncoding.UTF8);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonGenerator createGenerator(Writer w) throws IOException {
/* 1346 */     IOContext ctxt = _createContext(_createContentReference(w), false);
/* 1347 */     return _createGenerator(_decorate(w, ctxt), ctxt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonGenerator createGenerator(File f, JsonEncoding enc) throws IOException {
/* 1369 */     OutputStream out = _fileOutputStream(f);
/*      */     
/* 1371 */     IOContext ctxt = _createContext(_createContentReference(out), true);
/* 1372 */     ctxt.setEncoding(enc);
/* 1373 */     if (enc == JsonEncoding.UTF8) {
/* 1374 */       return _createUTF8Generator(_decorate(out, ctxt), ctxt);
/*      */     }
/* 1376 */     Writer w = _createWriter(out, enc, ctxt);
/* 1377 */     return _createGenerator(_decorate(w, ctxt), ctxt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonGenerator createGenerator(DataOutput out, JsonEncoding enc) throws IOException {
/* 1388 */     return createGenerator(_createDataOutputWrapper(out), enc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonGenerator createGenerator(DataOutput out) throws IOException {
/* 1401 */     return createGenerator(_createDataOutputWrapper(out), JsonEncoding.UTF8);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JsonParser createJsonParser(File f) throws IOException, JsonParseException {
/* 1436 */     return createParser(f);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JsonParser createJsonParser(URL url) throws IOException, JsonParseException {
/* 1464 */     return createParser(url);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JsonParser createJsonParser(InputStream in) throws IOException, JsonParseException {
/* 1495 */     return createParser(in);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JsonParser createJsonParser(Reader r) throws IOException, JsonParseException {
/* 1519 */     return createParser(r);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JsonParser createJsonParser(byte[] data) throws IOException, JsonParseException {
/* 1536 */     return createParser(data);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JsonParser createJsonParser(byte[] data, int offset, int len) throws IOException, JsonParseException {
/* 1556 */     return createParser(data, offset, len);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JsonParser createJsonParser(String content) throws IOException, JsonParseException {
/* 1574 */     return createParser(content);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JsonGenerator createJsonGenerator(OutputStream out, JsonEncoding enc) throws IOException {
/* 1611 */     return createGenerator(out, enc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JsonGenerator createJsonGenerator(Writer out) throws IOException {
/* 1635 */     return createGenerator(out);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JsonGenerator createJsonGenerator(OutputStream out) throws IOException {
/* 1654 */     return createGenerator(out, JsonEncoding.UTF8);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonParser _createParser(InputStream in, IOContext ctxt) throws IOException {
/*      */     try {
/* 1685 */       return (new ByteSourceJsonBootstrapper(ctxt, in)).constructParser(this._parserFeatures, this._objectCodec, this._byteSymbolCanonicalizer, this._rootCharSymbols, this._factoryFeatures);
/*      */     }
/* 1687 */     catch (IOException|RuntimeException e) {
/*      */       
/* 1689 */       if (ctxt.isResourceManaged()) {
/*      */         try {
/* 1691 */           in.close();
/* 1692 */         } catch (Exception e2) {
/* 1693 */           e.addSuppressed(e2);
/*      */         } 
/*      */       }
/* 1696 */       throw e;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonParser _createParser(Reader r, IOContext ctxt) throws IOException {
/* 1720 */     return (JsonParser)new ReaderBasedJsonParser(ctxt, this._parserFeatures, r, this._objectCodec, this._rootCharSymbols
/* 1721 */         .makeChild(this._factoryFeatures));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonParser _createParser(char[] data, int offset, int len, IOContext ctxt, boolean recyclable) throws IOException {
/* 1742 */     return (JsonParser)new ReaderBasedJsonParser(ctxt, this._parserFeatures, null, this._objectCodec, this._rootCharSymbols
/* 1743 */         .makeChild(this._factoryFeatures), data, offset, offset + len, recyclable);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonParser _createParser(byte[] data, int offset, int len, IOContext ctxt) throws IOException {
/* 1769 */     return (new ByteSourceJsonBootstrapper(ctxt, data, offset, len)).constructParser(this._parserFeatures, this._objectCodec, this._byteSymbolCanonicalizer, this._rootCharSymbols, this._factoryFeatures);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonParser _createParser(DataInput input, IOContext ctxt) throws IOException {
/* 1789 */     _requireJSONFactory("InputData source not (yet?) supported for this format (%s)");
/*      */ 
/*      */     
/* 1792 */     int firstByte = ByteSourceJsonBootstrapper.skipUTF8BOM(input);
/* 1793 */     ByteQuadsCanonicalizer can = this._byteSymbolCanonicalizer.makeChild(this._factoryFeatures);
/* 1794 */     return (JsonParser)new UTF8DataInputJsonParser(ctxt, this._parserFeatures, input, this._objectCodec, can, firstByte);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonGenerator _createGenerator(Writer out, IOContext ctxt) throws IOException {
/* 1824 */     WriterBasedJsonGenerator gen = new WriterBasedJsonGenerator(ctxt, this._generatorFeatures, this._objectCodec, out, this._quoteChar);
/*      */     
/* 1826 */     if (this._maximumNonEscapedChar > 0) {
/* 1827 */       gen.setHighestNonEscapedChar(this._maximumNonEscapedChar);
/*      */     }
/* 1829 */     if (this._characterEscapes != null) {
/* 1830 */       gen.setCharacterEscapes(this._characterEscapes);
/*      */     }
/* 1832 */     SerializableString rootSep = this._rootValueSeparator;
/* 1833 */     if (rootSep != DEFAULT_ROOT_VALUE_SEPARATOR) {
/* 1834 */       gen.setRootValueSeparator(rootSep);
/*      */     }
/* 1836 */     return (JsonGenerator)gen;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonGenerator _createUTF8Generator(OutputStream out, IOContext ctxt) throws IOException {
/* 1857 */     UTF8JsonGenerator gen = new UTF8JsonGenerator(ctxt, this._generatorFeatures, this._objectCodec, out, this._quoteChar);
/*      */     
/* 1859 */     if (this._maximumNonEscapedChar > 0) {
/* 1860 */       gen.setHighestNonEscapedChar(this._maximumNonEscapedChar);
/*      */     }
/* 1862 */     if (this._characterEscapes != null) {
/* 1863 */       gen.setCharacterEscapes(this._characterEscapes);
/*      */     }
/* 1865 */     SerializableString rootSep = this._rootValueSeparator;
/* 1866 */     if (rootSep != DEFAULT_ROOT_VALUE_SEPARATOR) {
/* 1867 */       gen.setRootValueSeparator(rootSep);
/*      */     }
/* 1869 */     return (JsonGenerator)gen;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected Writer _createWriter(OutputStream out, JsonEncoding enc, IOContext ctxt) throws IOException {
/* 1875 */     if (enc == JsonEncoding.UTF8) {
/* 1876 */       return (Writer)new UTF8Writer(ctxt, out);
/*      */     }
/*      */     
/* 1879 */     return new OutputStreamWriter(out, enc.getJavaName());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final InputStream _decorate(InputStream in, IOContext ctxt) throws IOException {
/* 1889 */     if (this._inputDecorator != null) {
/* 1890 */       InputStream in2 = this._inputDecorator.decorate(ctxt, in);
/* 1891 */       if (in2 != null) {
/* 1892 */         return in2;
/*      */       }
/*      */     } 
/* 1895 */     return in;
/*      */   }
/*      */   
/*      */   protected final Reader _decorate(Reader in, IOContext ctxt) throws IOException {
/* 1899 */     if (this._inputDecorator != null) {
/* 1900 */       Reader in2 = this._inputDecorator.decorate(ctxt, in);
/* 1901 */       if (in2 != null) {
/* 1902 */         return in2;
/*      */       }
/*      */     } 
/* 1905 */     return in;
/*      */   }
/*      */ 
/*      */   
/*      */   protected final DataInput _decorate(DataInput in, IOContext ctxt) throws IOException {
/* 1910 */     if (this._inputDecorator != null) {
/* 1911 */       DataInput in2 = this._inputDecorator.decorate(ctxt, in);
/* 1912 */       if (in2 != null) {
/* 1913 */         return in2;
/*      */       }
/*      */     } 
/* 1916 */     return in;
/*      */   }
/*      */   
/*      */   protected final OutputStream _decorate(OutputStream out, IOContext ctxt) throws IOException {
/* 1920 */     if (this._outputDecorator != null) {
/* 1921 */       OutputStream out2 = this._outputDecorator.decorate(ctxt, out);
/* 1922 */       if (out2 != null) {
/* 1923 */         return out2;
/*      */       }
/*      */     } 
/* 1926 */     return out;
/*      */   }
/*      */   
/*      */   protected final Writer _decorate(Writer out, IOContext ctxt) throws IOException {
/* 1930 */     if (this._outputDecorator != null) {
/* 1931 */       Writer out2 = this._outputDecorator.decorate(ctxt, out);
/* 1932 */       if (out2 != null) {
/* 1933 */         return out2;
/*      */       }
/*      */     } 
/* 1936 */     return out;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BufferRecycler _getBufferRecycler() {
/* 1958 */     if (Feature.USE_THREAD_LOCAL_FOR_BUFFER_RECYCLING.enabledIn(this._factoryFeatures)) {
/* 1959 */       return BufferRecyclers.getBufferRecycler();
/*      */     }
/* 1961 */     return new BufferRecycler();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected IOContext _createContext(ContentReference contentRef, boolean resourceManaged) {
/* 1975 */     if (contentRef == null) {
/* 1976 */       contentRef = ContentReference.unknown();
/*      */     }
/* 1978 */     return new IOContext(_getBufferRecycler(), contentRef, resourceManaged);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected IOContext _createContext(Object rawContentRef, boolean resourceManaged) {
/* 1993 */     return new IOContext(_getBufferRecycler(), 
/* 1994 */         _createContentReference(rawContentRef), resourceManaged);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected IOContext _createNonBlockingContext(Object srcRef) {
/* 2011 */     return new IOContext(_getBufferRecycler(), 
/* 2012 */         _createContentReference(srcRef), false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ContentReference _createContentReference(Object contentAccessor) {
/* 2031 */     return ContentReference.construct(!canHandleBinaryNatively(), contentAccessor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ContentReference _createContentReference(Object contentAccessor, int offset, int length) {
/* 2054 */     return ContentReference.construct(!canHandleBinaryNatively(), contentAccessor, offset, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _requireJSONFactory(String msg) {
/* 2079 */     if (!_isJSONFactory()) {
/* 2080 */       throw new UnsupportedOperationException(String.format(msg, new Object[] { getFormatName() }));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final boolean _isJSONFactory() {
/* 2087 */     return (getFormatName() == "JSON");
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-core-2.14.2.jar!\com\fasterxml\jackson\core\JsonFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */