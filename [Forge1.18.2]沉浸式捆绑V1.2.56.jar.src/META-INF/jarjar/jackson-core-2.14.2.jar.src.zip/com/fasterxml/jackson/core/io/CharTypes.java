/*     */ package com.fasterxml.jackson.core.io;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ 
/*     */ public final class CharTypes
/*     */ {
/*   7 */   protected static final char[] HC = "0123456789ABCDEF".toCharArray();
/*   8 */   protected static final char[] HClower = "0123456789abcdef".toCharArray(); protected static final byte[] HB;
/*     */   protected static final byte[] HBlower;
/*     */   
/*     */   static {
/*  12 */     int len = HC.length;
/*  13 */     HB = new byte[len];
/*  14 */     HBlower = new byte[len]; int k;
/*  15 */     for (k = 0; k < len; k++) {
/*  16 */       HB[k] = (byte)HC[k];
/*  17 */       HBlower[k] = (byte)HClower[k];
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  31 */     int[] arrayOfInt1 = new int[256];
/*     */     
/*  33 */     for (k = 0; k < 32; k++) {
/*  34 */       arrayOfInt1[k] = -1;
/*     */     }
/*     */     
/*  37 */     arrayOfInt1[34] = 1;
/*  38 */     arrayOfInt1[92] = 1;
/*  39 */     sInputCodes = arrayOfInt1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  48 */     arrayOfInt1 = new int[sInputCodes.length];
/*  49 */     System.arraycopy(sInputCodes, 0, arrayOfInt1, 0, arrayOfInt1.length);
/*  50 */     for (int c = 128; c < 256; c++) {
/*     */       int code;
/*     */ 
/*     */       
/*  54 */       if ((c & 0xE0) == 192) {
/*  55 */         code = 2;
/*  56 */       } else if ((c & 0xF0) == 224) {
/*  57 */         code = 3;
/*  58 */       } else if ((c & 0xF8) == 240) {
/*     */         
/*  60 */         code = 4;
/*     */       } else {
/*     */         
/*  63 */         code = -1;
/*     */       } 
/*  65 */       arrayOfInt1[c] = code;
/*     */     } 
/*  67 */     sInputCodesUTF8 = arrayOfInt1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  78 */     arrayOfInt1 = new int[256];
/*     */     
/*  80 */     Arrays.fill(arrayOfInt1, -1);
/*     */     int j;
/*  82 */     for (j = 33; j < 256; j++) {
/*  83 */       if (Character.isJavaIdentifierPart((char)j)) {
/*  84 */         arrayOfInt1[j] = 0;
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  90 */     arrayOfInt1[64] = 0;
/*  91 */     arrayOfInt1[35] = 0;
/*  92 */     arrayOfInt1[42] = 0;
/*  93 */     arrayOfInt1[45] = 0;
/*  94 */     arrayOfInt1[43] = 0;
/*  95 */     sInputCodesJsNames = arrayOfInt1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 105 */     arrayOfInt1 = new int[256];
/*     */     
/* 107 */     System.arraycopy(sInputCodesJsNames, 0, arrayOfInt1, 0, arrayOfInt1.length);
/* 108 */     Arrays.fill(arrayOfInt1, 128, 128, 0);
/* 109 */     sInputCodesUtf8JsNames = arrayOfInt1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 118 */     int[] buf = new int[256];
/*     */     
/* 120 */     System.arraycopy(sInputCodesUTF8, 128, buf, 128, 128);
/*     */ 
/*     */     
/* 123 */     Arrays.fill(buf, 0, 32, -1);
/* 124 */     buf[9] = 0;
/* 125 */     buf[10] = 10;
/* 126 */     buf[13] = 13;
/* 127 */     buf[42] = 42;
/* 128 */     sInputCodesComment = buf;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 139 */     buf = new int[256];
/* 140 */     System.arraycopy(sInputCodesUTF8, 128, buf, 128, 128);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 145 */     Arrays.fill(buf, 0, 32, -1);
/* 146 */     buf[32] = 1;
/* 147 */     buf[9] = 1;
/* 148 */     buf[10] = 10;
/* 149 */     buf[13] = 13;
/* 150 */     buf[47] = 47;
/* 151 */     buf[35] = 35;
/* 152 */     sInputCodesWS = buf;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 161 */     int[] table = new int[128];
/*     */     
/* 163 */     for (j = 0; j < 32; j++)
/*     */     {
/* 165 */       table[j] = -1;
/*     */     }
/*     */     
/* 168 */     table[34] = 34;
/* 169 */     table[92] = 92;
/*     */     
/* 171 */     table[8] = 98;
/* 172 */     table[9] = 116;
/* 173 */     table[12] = 102;
/* 174 */     table[10] = 110;
/* 175 */     table[13] = 114;
/* 176 */     sOutputEscapes128 = table;
/*     */   }
/*     */   
/*     */   protected static final int[] sInputCodes;
/*     */   protected static final int[] sInputCodesUTF8;
/*     */   protected static final int[] sInputCodesJsNames;
/*     */   protected static final int[] sInputCodesUtf8JsNames;
/*     */   protected static final int[] sInputCodesComment;
/*     */   protected static final int[] sInputCodesWS;
/*     */   protected static final int[] sOutputEscapes128;
/* 186 */   protected static final int[] sHexValues = new int[256];
/*     */   static {
/* 188 */     Arrays.fill(sHexValues, -1); int i;
/* 189 */     for (i = 0; i < 10; i++) {
/* 190 */       sHexValues[48 + i] = i;
/*     */     }
/* 192 */     for (i = 0; i < 6; i++) {
/* 193 */       sHexValues[97 + i] = 10 + i;
/* 194 */       sHexValues[65 + i] = 10 + i;
/*     */     } 
/*     */   }
/*     */   
/* 198 */   public static int[] getInputCodeLatin1() { return sInputCodes; } public static int[] getInputCodeUtf8() {
/* 199 */     return sInputCodesUTF8;
/*     */   }
/* 201 */   public static int[] getInputCodeLatin1JsNames() { return sInputCodesJsNames; } public static int[] getInputCodeUtf8JsNames() {
/* 202 */     return sInputCodesUtf8JsNames;
/*     */   }
/* 204 */   public static int[] getInputCodeComment() { return sInputCodesComment; } public static int[] getInputCodeWS() {
/* 205 */     return sInputCodesWS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int[] get7BitOutputEscapes() {
/* 216 */     return sOutputEscapes128;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int[] get7BitOutputEscapes(int quoteChar) {
/* 230 */     if (quoteChar == 34) {
/* 231 */       return sOutputEscapes128;
/*     */     }
/* 233 */     return AltEscapes.instance.escapesFor(quoteChar);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int charToHex(int ch) {
/* 240 */     return sHexValues[ch & 0xFF];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static char hexToChar(int ch) {
/* 246 */     return HC[ch];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void appendQuoted(StringBuilder sb, String content) {
/* 260 */     int[] escCodes = sOutputEscapes128;
/* 261 */     int escLen = escCodes.length;
/* 262 */     for (int i = 0, len = content.length(); i < len; i++) {
/* 263 */       char c = content.charAt(i);
/* 264 */       if (c >= escLen || escCodes[c] == 0) {
/* 265 */         sb.append(c);
/*     */       } else {
/*     */         
/* 268 */         sb.append('\\');
/* 269 */         int escCode = escCodes[c];
/* 270 */         if (escCode < 0) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 279 */           sb.append('u');
/* 280 */           sb.append('0');
/* 281 */           sb.append('0');
/* 282 */           int value = c;
/* 283 */           sb.append(HC[value >> 4]);
/* 284 */           sb.append(HC[value & 0xF]);
/*     */         } else {
/* 286 */           sb.append((char)escCode);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static char[] copyHexChars() {
/* 296 */     return copyHexChars(true);
/*     */   }
/*     */   
/*     */   public static char[] copyHexChars(boolean uppercase) {
/* 300 */     return uppercase ? (char[])HC.clone() : (char[])HClower.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static byte[] copyHexBytes() {
/* 308 */     return copyHexBytes(true);
/*     */   }
/*     */   
/*     */   public static byte[] copyHexBytes(boolean uppercase) {
/* 312 */     return uppercase ? (byte[])HB.clone() : (byte[])HBlower.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class AltEscapes
/*     */   {
/* 323 */     public static final AltEscapes instance = new AltEscapes();
/*     */     
/* 325 */     private int[][] _altEscapes = new int[128][];
/*     */     
/*     */     public int[] escapesFor(int quoteChar) {
/* 328 */       int[] esc = this._altEscapes[quoteChar];
/* 329 */       if (esc == null) {
/* 330 */         esc = Arrays.copyOf(CharTypes.sOutputEscapes128, 128);
/*     */         
/* 332 */         if (esc[quoteChar] == 0) {
/* 333 */           esc[quoteChar] = -1;
/*     */         }
/* 335 */         this._altEscapes[quoteChar] = esc;
/*     */       } 
/* 337 */       return esc;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-core-2.14.2.jar!\com\fasterxml\jackson\core\io\CharTypes.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */