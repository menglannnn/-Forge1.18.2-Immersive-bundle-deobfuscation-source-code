/*      */ package com.fasterxml.jackson.core.json;
/*      */ 
/*      */ import com.fasterxml.jackson.core.Base64Variant;
/*      */ import com.fasterxml.jackson.core.JsonLocation;
/*      */ import com.fasterxml.jackson.core.JsonParseException;
/*      */ import com.fasterxml.jackson.core.JsonParser;
/*      */ import com.fasterxml.jackson.core.JsonToken;
/*      */ import com.fasterxml.jackson.core.ObjectCodec;
/*      */ import com.fasterxml.jackson.core.StreamReadCapability;
/*      */ import com.fasterxml.jackson.core.base.ParserBase;
/*      */ import com.fasterxml.jackson.core.io.CharTypes;
/*      */ import com.fasterxml.jackson.core.io.IOContext;
/*      */ import com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer;
/*      */ import com.fasterxml.jackson.core.util.ByteArrayBuilder;
/*      */ import com.fasterxml.jackson.core.util.JacksonFeatureSet;
/*      */ import java.io.DataInput;
/*      */ import java.io.EOFException;
/*      */ import java.io.IOException;
/*      */ import java.io.OutputStream;
/*      */ import java.io.Writer;
/*      */ import java.util.Arrays;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class UTF8DataInputJsonParser
/*      */   extends ParserBase
/*      */ {
/*      */   static final byte BYTE_LF = 10;
/*   44 */   private static final int FEAT_MASK_TRAILING_COMMA = JsonParser.Feature.ALLOW_TRAILING_COMMA.getMask();
/*      */   
/*   46 */   private static final int FEAT_MASK_LEADING_ZEROS = JsonParser.Feature.ALLOW_NUMERIC_LEADING_ZEROS.getMask();
/*      */   
/*   48 */   private static final int FEAT_MASK_NON_NUM_NUMBERS = JsonParser.Feature.ALLOW_NON_NUMERIC_NUMBERS.getMask();
/*      */   
/*   50 */   private static final int FEAT_MASK_ALLOW_MISSING = JsonParser.Feature.ALLOW_MISSING_VALUES.getMask();
/*   51 */   private static final int FEAT_MASK_ALLOW_SINGLE_QUOTES = JsonParser.Feature.ALLOW_SINGLE_QUOTES.getMask();
/*   52 */   private static final int FEAT_MASK_ALLOW_UNQUOTED_NAMES = JsonParser.Feature.ALLOW_UNQUOTED_FIELD_NAMES.getMask();
/*   53 */   private static final int FEAT_MASK_ALLOW_JAVA_COMMENTS = JsonParser.Feature.ALLOW_COMMENTS.getMask();
/*   54 */   private static final int FEAT_MASK_ALLOW_YAML_COMMENTS = JsonParser.Feature.ALLOW_YAML_COMMENTS.getMask();
/*      */ 
/*      */   
/*   57 */   private static final int[] _icUTF8 = CharTypes.getInputCodeUtf8();
/*      */ 
/*      */ 
/*      */   
/*   61 */   protected static final int[] _icLatin1 = CharTypes.getInputCodeLatin1();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ObjectCodec _objectCodec;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final ByteQuadsCanonicalizer _symbols;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   90 */   protected int[] _quadBuffer = new int[16];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _tokenIncomplete;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int _quad1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected DataInput _inputData;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  116 */   protected int _nextByte = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public UTF8DataInputJsonParser(IOContext ctxt, int features, DataInput inputData, ObjectCodec codec, ByteQuadsCanonicalizer sym, int firstByte) {
/*  128 */     super(ctxt, features);
/*  129 */     this._objectCodec = codec;
/*  130 */     this._symbols = sym;
/*  131 */     this._inputData = inputData;
/*  132 */     this._nextByte = firstByte;
/*      */   }
/*      */ 
/*      */   
/*      */   public ObjectCodec getCodec() {
/*  137 */     return this._objectCodec;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setCodec(ObjectCodec c) {
/*  142 */     this._objectCodec = c;
/*      */   }
/*      */ 
/*      */   
/*      */   public JacksonFeatureSet<StreamReadCapability> getReadCapabilities() {
/*  147 */     return JSON_READ_CAPABILITIES;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int releaseBuffered(OutputStream out) throws IOException {
/*  158 */     return 0;
/*      */   }
/*      */ 
/*      */   
/*      */   public Object getInputSource() {
/*  163 */     return this._inputData;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _closeInput() throws IOException {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _releaseBuffers() throws IOException {
/*  184 */     super._releaseBuffers();
/*      */     
/*  186 */     this._symbols.release();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getText() throws IOException {
/*  198 */     if (this._currToken == JsonToken.VALUE_STRING) {
/*  199 */       if (this._tokenIncomplete) {
/*  200 */         this._tokenIncomplete = false;
/*  201 */         return _finishAndReturnString();
/*      */       } 
/*  203 */       return this._textBuffer.contentsAsString();
/*      */     } 
/*  205 */     return _getText2(this._currToken);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getText(Writer writer) throws IOException {
/*  211 */     JsonToken t = this._currToken;
/*  212 */     if (t == JsonToken.VALUE_STRING) {
/*  213 */       if (this._tokenIncomplete) {
/*  214 */         this._tokenIncomplete = false;
/*  215 */         _finishString();
/*      */       } 
/*  217 */       return this._textBuffer.contentsToWriter(writer);
/*      */     } 
/*  219 */     if (t == JsonToken.FIELD_NAME) {
/*  220 */       String n = this._parsingContext.getCurrentName();
/*  221 */       writer.write(n);
/*  222 */       return n.length();
/*      */     } 
/*  224 */     if (t != null) {
/*  225 */       if (t.isNumeric()) {
/*  226 */         return this._textBuffer.contentsToWriter(writer);
/*      */       }
/*  228 */       char[] ch = t.asCharArray();
/*  229 */       writer.write(ch);
/*  230 */       return ch.length;
/*      */     } 
/*  232 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getValueAsString() throws IOException {
/*  239 */     if (this._currToken == JsonToken.VALUE_STRING) {
/*  240 */       if (this._tokenIncomplete) {
/*  241 */         this._tokenIncomplete = false;
/*  242 */         return _finishAndReturnString();
/*      */       } 
/*  244 */       return this._textBuffer.contentsAsString();
/*      */     } 
/*  246 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  247 */       return getCurrentName();
/*      */     }
/*  249 */     return super.getValueAsString(null);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getValueAsString(String defValue) throws IOException {
/*  255 */     if (this._currToken == JsonToken.VALUE_STRING) {
/*  256 */       if (this._tokenIncomplete) {
/*  257 */         this._tokenIncomplete = false;
/*  258 */         return _finishAndReturnString();
/*      */       } 
/*  260 */       return this._textBuffer.contentsAsString();
/*      */     } 
/*  262 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  263 */       return getCurrentName();
/*      */     }
/*  265 */     return super.getValueAsString(defValue);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getValueAsInt() throws IOException {
/*  271 */     JsonToken t = this._currToken;
/*  272 */     if (t == JsonToken.VALUE_NUMBER_INT || t == JsonToken.VALUE_NUMBER_FLOAT) {
/*      */       
/*  274 */       if ((this._numTypesValid & 0x1) == 0) {
/*  275 */         if (this._numTypesValid == 0) {
/*  276 */           return _parseIntValue();
/*      */         }
/*  278 */         if ((this._numTypesValid & 0x1) == 0) {
/*  279 */           convertNumberToInt();
/*      */         }
/*      */       } 
/*  282 */       return this._numberInt;
/*      */     } 
/*  284 */     return super.getValueAsInt(0);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getValueAsInt(int defValue) throws IOException {
/*  290 */     JsonToken t = this._currToken;
/*  291 */     if (t == JsonToken.VALUE_NUMBER_INT || t == JsonToken.VALUE_NUMBER_FLOAT) {
/*      */       
/*  293 */       if ((this._numTypesValid & 0x1) == 0) {
/*  294 */         if (this._numTypesValid == 0) {
/*  295 */           return _parseIntValue();
/*      */         }
/*  297 */         if ((this._numTypesValid & 0x1) == 0) {
/*  298 */           convertNumberToInt();
/*      */         }
/*      */       } 
/*  301 */       return this._numberInt;
/*      */     } 
/*  303 */     return super.getValueAsInt(defValue);
/*      */   }
/*      */ 
/*      */   
/*      */   protected final String _getText2(JsonToken t) {
/*  308 */     if (t == null) {
/*  309 */       return null;
/*      */     }
/*  311 */     switch (t.id()) {
/*      */       case 5:
/*  313 */         return this._parsingContext.getCurrentName();
/*      */ 
/*      */       
/*      */       case 6:
/*      */       case 7:
/*      */       case 8:
/*  319 */         return this._textBuffer.contentsAsString();
/*      */     } 
/*  321 */     return t.asString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public char[] getTextCharacters() throws IOException {
/*  328 */     if (this._currToken != null) {
/*  329 */       switch (this._currToken.id()) {
/*      */         
/*      */         case 5:
/*  332 */           if (!this._nameCopied) {
/*  333 */             String name = this._parsingContext.getCurrentName();
/*  334 */             int nameLen = name.length();
/*  335 */             if (this._nameCopyBuffer == null) {
/*  336 */               this._nameCopyBuffer = this._ioContext.allocNameCopyBuffer(nameLen);
/*  337 */             } else if (this._nameCopyBuffer.length < nameLen) {
/*  338 */               this._nameCopyBuffer = new char[nameLen];
/*      */             } 
/*  340 */             name.getChars(0, nameLen, this._nameCopyBuffer, 0);
/*  341 */             this._nameCopied = true;
/*      */           } 
/*  343 */           return this._nameCopyBuffer;
/*      */         
/*      */         case 6:
/*  346 */           if (this._tokenIncomplete) {
/*  347 */             this._tokenIncomplete = false;
/*  348 */             _finishString();
/*      */           } 
/*      */         
/*      */         case 7:
/*      */         case 8:
/*  353 */           return this._textBuffer.getTextBuffer();
/*      */       } 
/*      */       
/*  356 */       return this._currToken.asCharArray();
/*      */     } 
/*      */     
/*  359 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getTextLength() throws IOException {
/*  365 */     if (this._currToken == JsonToken.VALUE_STRING) {
/*  366 */       if (this._tokenIncomplete) {
/*  367 */         this._tokenIncomplete = false;
/*  368 */         _finishString();
/*      */       } 
/*  370 */       return this._textBuffer.size();
/*      */     } 
/*  372 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  373 */       return this._parsingContext.getCurrentName().length();
/*      */     }
/*  375 */     if (this._currToken != null) {
/*  376 */       if (this._currToken.isNumeric()) {
/*  377 */         return this._textBuffer.size();
/*      */       }
/*  379 */       return (this._currToken.asCharArray()).length;
/*      */     } 
/*  381 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getTextOffset() throws IOException {
/*  388 */     if (this._currToken != null) {
/*  389 */       switch (this._currToken.id()) {
/*      */         case 5:
/*  391 */           return 0;
/*      */         case 6:
/*  393 */           if (this._tokenIncomplete) {
/*  394 */             this._tokenIncomplete = false;
/*  395 */             _finishString();
/*      */           } 
/*      */         
/*      */         case 7:
/*      */         case 8:
/*  400 */           return this._textBuffer.getTextOffset();
/*      */       } 
/*      */     
/*      */     }
/*  404 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] getBinaryValue(Base64Variant b64variant) throws IOException {
/*  410 */     if (this._currToken != JsonToken.VALUE_STRING && (this._currToken != JsonToken.VALUE_EMBEDDED_OBJECT || this._binaryValue == null))
/*      */     {
/*  412 */       _reportError("Current token (" + this._currToken + ") not VALUE_STRING or VALUE_EMBEDDED_OBJECT, can not access as binary");
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  417 */     if (this._tokenIncomplete) {
/*      */       try {
/*  419 */         this._binaryValue = _decodeBase64(b64variant);
/*  420 */       } catch (IllegalArgumentException iae) {
/*  421 */         throw _constructError("Failed to decode VALUE_STRING as base64 (" + b64variant + "): " + iae.getMessage());
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  426 */       this._tokenIncomplete = false;
/*      */     }
/*  428 */     else if (this._binaryValue == null) {
/*      */       
/*  430 */       ByteArrayBuilder builder = _getByteArrayBuilder();
/*  431 */       _decodeBase64(getText(), builder, b64variant);
/*  432 */       this._binaryValue = builder.toByteArray();
/*      */     } 
/*      */     
/*  435 */     return this._binaryValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int readBinaryValue(Base64Variant b64variant, OutputStream out) throws IOException {
/*  442 */     if (!this._tokenIncomplete || this._currToken != JsonToken.VALUE_STRING) {
/*  443 */       byte[] b = getBinaryValue(b64variant);
/*  444 */       out.write(b);
/*  445 */       return b.length;
/*      */     } 
/*      */     
/*  448 */     byte[] buf = this._ioContext.allocBase64Buffer();
/*      */     try {
/*  450 */       return _readBinary(b64variant, out, buf);
/*      */     } finally {
/*  452 */       this._ioContext.releaseBase64Buffer(buf);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _readBinary(Base64Variant b64variant, OutputStream out, byte[] buffer) throws IOException {
/*  459 */     int outputPtr = 0;
/*  460 */     int outputEnd = buffer.length - 3;
/*  461 */     int outputCount = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/*  467 */       int ch = this._inputData.readUnsignedByte();
/*  468 */       if (ch > 32) {
/*  469 */         int bits = b64variant.decodeBase64Char(ch);
/*  470 */         if (bits < 0) {
/*  471 */           if (ch == 34) {
/*      */             break;
/*      */           }
/*  474 */           bits = _decodeBase64Escape(b64variant, ch, 0);
/*  475 */           if (bits < 0) {
/*      */             continue;
/*      */           }
/*      */         } 
/*      */ 
/*      */         
/*  481 */         if (outputPtr > outputEnd) {
/*  482 */           outputCount += outputPtr;
/*  483 */           out.write(buffer, 0, outputPtr);
/*  484 */           outputPtr = 0;
/*      */         } 
/*      */         
/*  487 */         int decodedData = bits;
/*      */ 
/*      */         
/*  490 */         ch = this._inputData.readUnsignedByte();
/*  491 */         bits = b64variant.decodeBase64Char(ch);
/*  492 */         if (bits < 0) {
/*  493 */           bits = _decodeBase64Escape(b64variant, ch, 1);
/*      */         }
/*  495 */         decodedData = decodedData << 6 | bits;
/*      */ 
/*      */         
/*  498 */         ch = this._inputData.readUnsignedByte();
/*  499 */         bits = b64variant.decodeBase64Char(ch);
/*      */ 
/*      */         
/*  502 */         if (bits < 0) {
/*  503 */           if (bits != -2) {
/*      */             
/*  505 */             if (ch == 34) {
/*  506 */               decodedData >>= 4;
/*  507 */               buffer[outputPtr++] = (byte)decodedData;
/*  508 */               if (b64variant.usesPadding()) {
/*  509 */                 _handleBase64MissingPadding(b64variant);
/*      */               }
/*      */               break;
/*      */             } 
/*  513 */             bits = _decodeBase64Escape(b64variant, ch, 2);
/*      */           } 
/*  515 */           if (bits == -2) {
/*      */             
/*  517 */             ch = this._inputData.readUnsignedByte();
/*  518 */             if (!b64variant.usesPaddingChar(ch) && (
/*  519 */               ch != 92 || 
/*  520 */               _decodeBase64Escape(b64variant, ch, 3) != -2)) {
/*  521 */               throw reportInvalidBase64Char(b64variant, ch, 3, "expected padding character '" + b64variant.getPaddingChar() + "'");
/*      */             }
/*      */ 
/*      */             
/*  525 */             decodedData >>= 4;
/*  526 */             buffer[outputPtr++] = (byte)decodedData;
/*      */             
/*      */             continue;
/*      */           } 
/*      */         } 
/*  531 */         decodedData = decodedData << 6 | bits;
/*      */         
/*  533 */         ch = this._inputData.readUnsignedByte();
/*  534 */         bits = b64variant.decodeBase64Char(ch);
/*  535 */         if (bits < 0) {
/*  536 */           if (bits != -2) {
/*      */             
/*  538 */             if (ch == 34) {
/*  539 */               decodedData >>= 2;
/*  540 */               buffer[outputPtr++] = (byte)(decodedData >> 8);
/*  541 */               buffer[outputPtr++] = (byte)decodedData;
/*  542 */               if (b64variant.usesPadding()) {
/*  543 */                 _handleBase64MissingPadding(b64variant);
/*      */               }
/*      */               break;
/*      */             } 
/*  547 */             bits = _decodeBase64Escape(b64variant, ch, 3);
/*      */           } 
/*  549 */           if (bits == -2) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  556 */             decodedData >>= 2;
/*  557 */             buffer[outputPtr++] = (byte)(decodedData >> 8);
/*  558 */             buffer[outputPtr++] = (byte)decodedData;
/*      */             
/*      */             continue;
/*      */           } 
/*      */         } 
/*  563 */         decodedData = decodedData << 6 | bits;
/*  564 */         buffer[outputPtr++] = (byte)(decodedData >> 16);
/*  565 */         buffer[outputPtr++] = (byte)(decodedData >> 8);
/*  566 */         buffer[outputPtr++] = (byte)decodedData;
/*      */       } 
/*  568 */     }  this._tokenIncomplete = false;
/*  569 */     if (outputPtr > 0) {
/*  570 */       outputCount += outputPtr;
/*  571 */       out.write(buffer, 0, outputPtr);
/*      */     } 
/*  573 */     return outputCount;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonToken nextToken() throws IOException {
/*  589 */     if (this._closed) {
/*  590 */       return null;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  596 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  597 */       return _nextAfterName();
/*      */     }
/*      */ 
/*      */     
/*  601 */     this._numTypesValid = 0;
/*  602 */     if (this._tokenIncomplete) {
/*  603 */       _skipString();
/*      */     }
/*  605 */     int i = _skipWSOrEnd();
/*  606 */     if (i < 0) {
/*      */       
/*  608 */       close();
/*  609 */       return this._currToken = null;
/*      */     } 
/*      */     
/*  612 */     this._binaryValue = null;
/*  613 */     this._tokenInputRow = this._currInputRow;
/*      */ 
/*      */     
/*  616 */     if (i == 93 || i == 125) {
/*  617 */       _closeScope(i);
/*  618 */       return this._currToken;
/*      */     } 
/*      */ 
/*      */     
/*  622 */     if (this._parsingContext.expectComma()) {
/*  623 */       if (i != 44) {
/*  624 */         _reportUnexpectedChar(i, "was expecting comma to separate " + this._parsingContext.typeDesc() + " entries");
/*      */       }
/*  626 */       i = _skipWS();
/*      */ 
/*      */       
/*  629 */       if ((this._features & FEAT_MASK_TRAILING_COMMA) != 0 && (
/*  630 */         i == 93 || i == 125)) {
/*  631 */         _closeScope(i);
/*  632 */         return this._currToken;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  641 */     if (!this._parsingContext.inObject()) {
/*  642 */       return _nextTokenNotInObject(i);
/*      */     }
/*      */     
/*  645 */     String n = _parseName(i);
/*  646 */     this._parsingContext.setCurrentName(n);
/*  647 */     this._currToken = JsonToken.FIELD_NAME;
/*      */     
/*  649 */     i = _skipColon();
/*      */ 
/*      */     
/*  652 */     if (i == 34) {
/*  653 */       this._tokenIncomplete = true;
/*  654 */       this._nextToken = JsonToken.VALUE_STRING;
/*  655 */       return this._currToken;
/*      */     } 
/*      */ 
/*      */     
/*  659 */     switch (i)
/*      */     { case 45:
/*  661 */         t = _parseNegNumber();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  707 */         this._nextToken = t;
/*  708 */         return this._currToken;case 43: if (isEnabled(JsonReadFeature.ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS.mappedFeature())) { t = _parsePosNumber(); } else { t = _handleUnexpectedValue(i); }  this._nextToken = t; return this._currToken;case 46: t = _parseFloatThatStartsWithPeriod(false, false); this._nextToken = t; return this._currToken;case 48: case 49: case 50: case 51: case 52: case 53: case 54: case 55: case 56: case 57: t = _parseUnsignedNumber(i); this._nextToken = t; return this._currToken;case 102: _matchToken("false", 1); t = JsonToken.VALUE_FALSE; this._nextToken = t; return this._currToken;case 110: _matchToken("null", 1); t = JsonToken.VALUE_NULL; this._nextToken = t; return this._currToken;case 116: _matchToken("true", 1); t = JsonToken.VALUE_TRUE; this._nextToken = t; return this._currToken;case 91: t = JsonToken.START_ARRAY; this._nextToken = t; return this._currToken;case 123: t = JsonToken.START_OBJECT; this._nextToken = t; return this._currToken; }  JsonToken t = _handleUnexpectedValue(i); this._nextToken = t; return this._currToken;
/*      */   }
/*      */ 
/*      */   
/*      */   private final JsonToken _nextTokenNotInObject(int i) throws IOException {
/*  713 */     if (i == 34) {
/*  714 */       this._tokenIncomplete = true;
/*  715 */       return this._currToken = JsonToken.VALUE_STRING;
/*      */     } 
/*  717 */     switch (i) {
/*      */       case 91:
/*  719 */         this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/*  720 */         return this._currToken = JsonToken.START_ARRAY;
/*      */       case 123:
/*  722 */         this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*  723 */         return this._currToken = JsonToken.START_OBJECT;
/*      */       case 116:
/*  725 */         _matchToken("true", 1);
/*  726 */         return this._currToken = JsonToken.VALUE_TRUE;
/*      */       case 102:
/*  728 */         _matchToken("false", 1);
/*  729 */         return this._currToken = JsonToken.VALUE_FALSE;
/*      */       case 110:
/*  731 */         _matchToken("null", 1);
/*  732 */         return this._currToken = JsonToken.VALUE_NULL;
/*      */       case 45:
/*  734 */         return this._currToken = _parseNegNumber();
/*      */       case 43:
/*  736 */         if (isEnabled(JsonReadFeature.ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS.mappedFeature())) {
/*  737 */           return this._currToken = _parsePosNumber();
/*      */         }
/*  739 */         return this._currToken = _handleUnexpectedValue(i);
/*      */       case 46:
/*  741 */         return this._currToken = _parseFloatThatStartsWithPeriod(false, false);
/*      */       case 48:
/*      */       case 49:
/*      */       case 50:
/*      */       case 51:
/*      */       case 52:
/*      */       case 53:
/*      */       case 54:
/*      */       case 55:
/*      */       case 56:
/*      */       case 57:
/*  752 */         return this._currToken = _parseUnsignedNumber(i);
/*      */     } 
/*  754 */     return this._currToken = _handleUnexpectedValue(i);
/*      */   }
/*      */ 
/*      */   
/*      */   private final JsonToken _nextAfterName() {
/*  759 */     this._nameCopied = false;
/*  760 */     JsonToken t = this._nextToken;
/*  761 */     this._nextToken = null;
/*      */ 
/*      */     
/*  764 */     if (t == JsonToken.START_ARRAY) {
/*  765 */       this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/*  766 */     } else if (t == JsonToken.START_OBJECT) {
/*  767 */       this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */     } 
/*  769 */     return this._currToken = t;
/*      */   }
/*      */ 
/*      */   
/*      */   public void finishToken() throws IOException {
/*  774 */     if (this._tokenIncomplete) {
/*  775 */       this._tokenIncomplete = false;
/*  776 */       _finishString();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String nextFieldName() throws IOException {
/*  794 */     this._numTypesValid = 0;
/*  795 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  796 */       _nextAfterName();
/*  797 */       return null;
/*      */     } 
/*  799 */     if (this._tokenIncomplete) {
/*  800 */       _skipString();
/*      */     }
/*  802 */     int i = _skipWS();
/*  803 */     this._binaryValue = null;
/*  804 */     this._tokenInputRow = this._currInputRow;
/*      */     
/*  806 */     if (i == 93 || i == 125) {
/*  807 */       _closeScope(i);
/*  808 */       return null;
/*      */     } 
/*      */ 
/*      */     
/*  812 */     if (this._parsingContext.expectComma()) {
/*  813 */       if (i != 44) {
/*  814 */         _reportUnexpectedChar(i, "was expecting comma to separate " + this._parsingContext.typeDesc() + " entries");
/*      */       }
/*  816 */       i = _skipWS();
/*      */ 
/*      */       
/*  819 */       if ((this._features & FEAT_MASK_TRAILING_COMMA) != 0 && (
/*  820 */         i == 93 || i == 125)) {
/*  821 */         _closeScope(i);
/*  822 */         return null;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  827 */     if (!this._parsingContext.inObject()) {
/*  828 */       _nextTokenNotInObject(i);
/*  829 */       return null;
/*      */     } 
/*      */     
/*  832 */     String nameStr = _parseName(i);
/*  833 */     this._parsingContext.setCurrentName(nameStr);
/*  834 */     this._currToken = JsonToken.FIELD_NAME;
/*      */     
/*  836 */     i = _skipColon();
/*  837 */     if (i == 34) {
/*  838 */       this._tokenIncomplete = true;
/*  839 */       this._nextToken = JsonToken.VALUE_STRING;
/*  840 */       return nameStr;
/*      */     } 
/*      */     
/*  843 */     switch (i)
/*      */     { case 45:
/*  845 */         t = _parseNegNumber();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  890 */         this._nextToken = t;
/*  891 */         return nameStr;case 43: if (isEnabled(JsonReadFeature.ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS.mappedFeature())) { t = _parsePosNumber(); } else { t = _handleUnexpectedValue(i); }  this._nextToken = t; return nameStr;case 46: t = _parseFloatThatStartsWithPeriod(false, false);case 48: case 49: case 50: case 51: case 52: case 53: case 54: case 55: case 56: case 57: t = _parseUnsignedNumber(i); this._nextToken = t; return nameStr;case 102: _matchToken("false", 1); t = JsonToken.VALUE_FALSE; this._nextToken = t; return nameStr;case 110: _matchToken("null", 1); t = JsonToken.VALUE_NULL; this._nextToken = t; return nameStr;case 116: _matchToken("true", 1); t = JsonToken.VALUE_TRUE; this._nextToken = t; return nameStr;case 91: t = JsonToken.START_ARRAY; this._nextToken = t; return nameStr;case 123: t = JsonToken.START_OBJECT; this._nextToken = t; return nameStr; }  JsonToken t = _handleUnexpectedValue(i); this._nextToken = t; return nameStr;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String nextTextValue() throws IOException {
/*  898 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  899 */       this._nameCopied = false;
/*  900 */       JsonToken t = this._nextToken;
/*  901 */       this._nextToken = null;
/*  902 */       this._currToken = t;
/*  903 */       if (t == JsonToken.VALUE_STRING) {
/*  904 */         if (this._tokenIncomplete) {
/*  905 */           this._tokenIncomplete = false;
/*  906 */           return _finishAndReturnString();
/*      */         } 
/*  908 */         return this._textBuffer.contentsAsString();
/*      */       } 
/*  910 */       if (t == JsonToken.START_ARRAY) {
/*  911 */         this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/*  912 */       } else if (t == JsonToken.START_OBJECT) {
/*  913 */         this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */       } 
/*  915 */       return null;
/*      */     } 
/*  917 */     return (nextToken() == JsonToken.VALUE_STRING) ? getText() : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int nextIntValue(int defaultValue) throws IOException {
/*  924 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  925 */       this._nameCopied = false;
/*  926 */       JsonToken t = this._nextToken;
/*  927 */       this._nextToken = null;
/*  928 */       this._currToken = t;
/*  929 */       if (t == JsonToken.VALUE_NUMBER_INT) {
/*  930 */         return getIntValue();
/*      */       }
/*  932 */       if (t == JsonToken.START_ARRAY) {
/*  933 */         this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/*  934 */       } else if (t == JsonToken.START_OBJECT) {
/*  935 */         this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */       } 
/*  937 */       return defaultValue;
/*      */     } 
/*  939 */     return (nextToken() == JsonToken.VALUE_NUMBER_INT) ? getIntValue() : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long nextLongValue(long defaultValue) throws IOException {
/*  946 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  947 */       this._nameCopied = false;
/*  948 */       JsonToken t = this._nextToken;
/*  949 */       this._nextToken = null;
/*  950 */       this._currToken = t;
/*  951 */       if (t == JsonToken.VALUE_NUMBER_INT) {
/*  952 */         return getLongValue();
/*      */       }
/*  954 */       if (t == JsonToken.START_ARRAY) {
/*  955 */         this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/*  956 */       } else if (t == JsonToken.START_OBJECT) {
/*  957 */         this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */       } 
/*  959 */       return defaultValue;
/*      */     } 
/*  961 */     return (nextToken() == JsonToken.VALUE_NUMBER_INT) ? getLongValue() : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Boolean nextBooleanValue() throws IOException {
/*  968 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  969 */       this._nameCopied = false;
/*  970 */       JsonToken jsonToken = this._nextToken;
/*  971 */       this._nextToken = null;
/*  972 */       this._currToken = jsonToken;
/*  973 */       if (jsonToken == JsonToken.VALUE_TRUE) {
/*  974 */         return Boolean.TRUE;
/*      */       }
/*  976 */       if (jsonToken == JsonToken.VALUE_FALSE) {
/*  977 */         return Boolean.FALSE;
/*      */       }
/*  979 */       if (jsonToken == JsonToken.START_ARRAY) {
/*  980 */         this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/*  981 */       } else if (jsonToken == JsonToken.START_OBJECT) {
/*  982 */         this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */       } 
/*  984 */       return null;
/*      */     } 
/*      */     
/*  987 */     JsonToken t = nextToken();
/*  988 */     if (t == JsonToken.VALUE_TRUE) {
/*  989 */       return Boolean.TRUE;
/*      */     }
/*  991 */     if (t == JsonToken.VALUE_FALSE) {
/*  992 */       return Boolean.FALSE;
/*      */     }
/*  994 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected final JsonToken _parseFloatThatStartsWithPeriod() throws IOException {
/* 1005 */     return _parseFloatThatStartsWithPeriod(false, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final JsonToken _parseFloatThatStartsWithPeriod(boolean neg, boolean hasSign) throws IOException {
/* 1013 */     if (!isEnabled(JsonReadFeature.ALLOW_LEADING_DECIMAL_POINT_FOR_NUMBERS.mappedFeature())) {
/* 1014 */       return _handleUnexpectedValue(46);
/*      */     }
/* 1016 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 1017 */     int outPtr = 0;
/*      */     
/* 1019 */     if (neg) {
/* 1020 */       outBuf[outPtr++] = '-';
/*      */     }
/* 1022 */     return _parseFloat(outBuf, outPtr, 46, neg, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonToken _parseUnsignedNumber(int c) throws IOException {
/*      */     int outPtr;
/* 1050 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1055 */     if (c == 48) {
/* 1056 */       c = _handleLeadingZeroes();
/* 1057 */       if (c <= 57 && c >= 48)
/* 1058 */       { outPtr = 0; }
/* 1059 */       else { if (c == 120 || c == 88) {
/* 1060 */           return _handleInvalidNumberStart(c, false);
/*      */         }
/* 1062 */         outBuf[0] = '0';
/* 1063 */         outPtr = 1; }
/*      */     
/*      */     } else {
/* 1066 */       outBuf[0] = (char)c;
/* 1067 */       c = this._inputData.readUnsignedByte();
/* 1068 */       outPtr = 1;
/*      */     } 
/* 1070 */     int intLen = outPtr;
/*      */ 
/*      */     
/* 1073 */     while (c <= 57 && c >= 48) {
/* 1074 */       intLen++;
/* 1075 */       if (outPtr >= outBuf.length) {
/* 1076 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 1077 */         outPtr = 0;
/*      */       } 
/* 1079 */       outBuf[outPtr++] = (char)c;
/* 1080 */       c = this._inputData.readUnsignedByte();
/*      */     } 
/* 1082 */     if (c == 46 || c == 101 || c == 69) {
/* 1083 */       return _parseFloat(outBuf, outPtr, c, false, intLen);
/*      */     }
/* 1085 */     this._textBuffer.setCurrentLength(outPtr);
/*      */     
/* 1087 */     if (this._parsingContext.inRoot()) {
/* 1088 */       _verifyRootSpace();
/*      */     } else {
/* 1090 */       this._nextByte = c;
/*      */     } 
/*      */     
/* 1093 */     return resetInt(false, intLen);
/*      */   }
/*      */ 
/*      */   
/*      */   protected final JsonToken _parsePosNumber() throws IOException {
/* 1098 */     return _parseSignedNumber(false);
/*      */   }
/*      */ 
/*      */   
/*      */   protected final JsonToken _parseNegNumber() throws IOException {
/* 1103 */     return _parseSignedNumber(true);
/*      */   }
/*      */ 
/*      */   
/*      */   private final JsonToken _parseSignedNumber(boolean negative) throws IOException {
/* 1108 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 1109 */     int outPtr = 0;
/*      */     
/* 1111 */     if (negative)
/*      */     {
/* 1113 */       outBuf[outPtr++] = '-';
/*      */     }
/* 1115 */     int c = this._inputData.readUnsignedByte();
/* 1116 */     outBuf[outPtr++] = (char)c;
/*      */     
/* 1118 */     if (c <= 48) {
/*      */       
/* 1120 */       if (c == 48)
/* 1121 */       { c = _handleLeadingZeroes(); }
/* 1122 */       else { if (c == 46) {
/* 1123 */           return _parseFloatThatStartsWithPeriod(negative, true);
/*      */         }
/* 1125 */         return _handleInvalidNumberStart(c, negative, true); }
/*      */     
/*      */     } else {
/* 1128 */       if (c > 57) {
/* 1129 */         return _handleInvalidNumberStart(c, negative, true);
/*      */       }
/* 1131 */       c = this._inputData.readUnsignedByte();
/*      */     } 
/*      */     
/* 1134 */     int intLen = 1;
/*      */ 
/*      */     
/* 1137 */     while (c <= 57 && c >= 48) {
/* 1138 */       intLen++;
/* 1139 */       if (outPtr >= outBuf.length) {
/* 1140 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 1141 */         outPtr = 0;
/*      */       } 
/* 1143 */       outBuf[outPtr++] = (char)c;
/* 1144 */       c = this._inputData.readUnsignedByte();
/*      */     } 
/* 1146 */     if (c == 46 || c == 101 || c == 69) {
/* 1147 */       return _parseFloat(outBuf, outPtr, c, negative, intLen);
/*      */     }
/* 1149 */     this._textBuffer.setCurrentLength(outPtr);
/*      */     
/* 1151 */     this._nextByte = c;
/* 1152 */     if (this._parsingContext.inRoot()) {
/* 1153 */       _verifyRootSpace();
/*      */     }
/*      */     
/* 1156 */     return resetInt(negative, intLen);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _handleLeadingZeroes() throws IOException {
/* 1171 */     int ch = this._inputData.readUnsignedByte();
/*      */     
/* 1173 */     if (ch < 48 || ch > 57) {
/* 1174 */       return ch;
/*      */     }
/*      */     
/* 1177 */     if ((this._features & FEAT_MASK_LEADING_ZEROS) == 0) {
/* 1178 */       reportInvalidNumber("Leading zeroes not allowed");
/*      */     }
/*      */     
/* 1181 */     while (ch == 48) {
/* 1182 */       ch = this._inputData.readUnsignedByte();
/*      */     }
/* 1184 */     return ch;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final JsonToken _parseFloat(char[] outBuf, int outPtr, int c, boolean negative, int integerPartLength) throws IOException {
/* 1190 */     int fractLen = 0;
/*      */ 
/*      */     
/* 1193 */     if (c == 46) {
/*      */       
/* 1195 */       if (outPtr >= outBuf.length) {
/* 1196 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 1197 */         outPtr = 0;
/*      */       } 
/* 1199 */       outBuf[outPtr++] = (char)c;
/*      */ 
/*      */       
/*      */       while (true) {
/* 1203 */         c = this._inputData.readUnsignedByte();
/* 1204 */         if (c < 48 || c > 57) {
/*      */           break;
/*      */         }
/* 1207 */         fractLen++;
/* 1208 */         if (outPtr >= outBuf.length) {
/* 1209 */           outBuf = this._textBuffer.finishCurrentSegment();
/* 1210 */           outPtr = 0;
/*      */         } 
/* 1212 */         outBuf[outPtr++] = (char)c;
/*      */       } 
/*      */       
/* 1215 */       if (fractLen == 0 && 
/* 1216 */         !isEnabled(JsonReadFeature.ALLOW_TRAILING_DECIMAL_POINT_FOR_NUMBERS.mappedFeature())) {
/* 1217 */         _reportUnexpectedNumberChar(c, "Decimal point not followed by a digit");
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1222 */     int expLen = 0;
/* 1223 */     if (c == 101 || c == 69) {
/* 1224 */       if (outPtr >= outBuf.length) {
/* 1225 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 1226 */         outPtr = 0;
/*      */       } 
/* 1228 */       outBuf[outPtr++] = (char)c;
/* 1229 */       c = this._inputData.readUnsignedByte();
/*      */       
/* 1231 */       if (c == 45 || c == 43) {
/* 1232 */         if (outPtr >= outBuf.length) {
/* 1233 */           outBuf = this._textBuffer.finishCurrentSegment();
/* 1234 */           outPtr = 0;
/*      */         } 
/* 1236 */         outBuf[outPtr++] = (char)c;
/* 1237 */         c = this._inputData.readUnsignedByte();
/*      */       } 
/* 1239 */       while (c <= 57 && c >= 48) {
/* 1240 */         expLen++;
/* 1241 */         if (outPtr >= outBuf.length) {
/* 1242 */           outBuf = this._textBuffer.finishCurrentSegment();
/* 1243 */           outPtr = 0;
/*      */         } 
/* 1245 */         outBuf[outPtr++] = (char)c;
/* 1246 */         c = this._inputData.readUnsignedByte();
/*      */       } 
/*      */       
/* 1249 */       if (expLen == 0) {
/* 1250 */         _reportUnexpectedNumberChar(c, "Exponent indicator not followed by a digit");
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1256 */     this._nextByte = c;
/* 1257 */     if (this._parsingContext.inRoot()) {
/* 1258 */       _verifyRootSpace();
/*      */     }
/* 1260 */     this._textBuffer.setCurrentLength(outPtr);
/*      */ 
/*      */     
/* 1263 */     return resetFloat(negative, integerPartLength, fractLen, expLen);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _verifyRootSpace() throws IOException {
/* 1276 */     int ch = this._nextByte;
/* 1277 */     if (ch <= 32) {
/* 1278 */       this._nextByte = -1;
/* 1279 */       if (ch == 13 || ch == 10) {
/* 1280 */         this._currInputRow++;
/*      */       }
/*      */       return;
/*      */     } 
/* 1284 */     _reportMissingRootWS(ch);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final String _parseName(int i) throws IOException {
/* 1295 */     if (i != 34) {
/* 1296 */       return _handleOddName(i);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1304 */     int[] codes = _icLatin1;
/*      */     
/* 1306 */     int q = this._inputData.readUnsignedByte();
/*      */     
/* 1308 */     if (codes[q] == 0) {
/* 1309 */       i = this._inputData.readUnsignedByte();
/* 1310 */       if (codes[i] == 0) {
/* 1311 */         q = q << 8 | i;
/* 1312 */         i = this._inputData.readUnsignedByte();
/* 1313 */         if (codes[i] == 0) {
/* 1314 */           q = q << 8 | i;
/* 1315 */           i = this._inputData.readUnsignedByte();
/* 1316 */           if (codes[i] == 0) {
/* 1317 */             q = q << 8 | i;
/* 1318 */             i = this._inputData.readUnsignedByte();
/* 1319 */             if (codes[i] == 0) {
/* 1320 */               this._quad1 = q;
/* 1321 */               return _parseMediumName(i);
/*      */             } 
/* 1323 */             if (i == 34) {
/* 1324 */               return findName(q, 4);
/*      */             }
/* 1326 */             return parseName(q, i, 4);
/*      */           } 
/* 1328 */           if (i == 34) {
/* 1329 */             return findName(q, 3);
/*      */           }
/* 1331 */           return parseName(q, i, 3);
/*      */         } 
/* 1333 */         if (i == 34) {
/* 1334 */           return findName(q, 2);
/*      */         }
/* 1336 */         return parseName(q, i, 2);
/*      */       } 
/* 1338 */       if (i == 34) {
/* 1339 */         return findName(q, 1);
/*      */       }
/* 1341 */       return parseName(q, i, 1);
/*      */     } 
/* 1343 */     if (q == 34) {
/* 1344 */       return "";
/*      */     }
/* 1346 */     return parseName(0, q, 0);
/*      */   }
/*      */ 
/*      */   
/*      */   private final String _parseMediumName(int q2) throws IOException {
/* 1351 */     int[] codes = _icLatin1;
/*      */ 
/*      */     
/* 1354 */     int i = this._inputData.readUnsignedByte();
/* 1355 */     if (codes[i] != 0) {
/* 1356 */       if (i == 34) {
/* 1357 */         return findName(this._quad1, q2, 1);
/*      */       }
/* 1359 */       return parseName(this._quad1, q2, i, 1);
/*      */     } 
/* 1361 */     q2 = q2 << 8 | i;
/* 1362 */     i = this._inputData.readUnsignedByte();
/* 1363 */     if (codes[i] != 0) {
/* 1364 */       if (i == 34) {
/* 1365 */         return findName(this._quad1, q2, 2);
/*      */       }
/* 1367 */       return parseName(this._quad1, q2, i, 2);
/*      */     } 
/* 1369 */     q2 = q2 << 8 | i;
/* 1370 */     i = this._inputData.readUnsignedByte();
/* 1371 */     if (codes[i] != 0) {
/* 1372 */       if (i == 34) {
/* 1373 */         return findName(this._quad1, q2, 3);
/*      */       }
/* 1375 */       return parseName(this._quad1, q2, i, 3);
/*      */     } 
/* 1377 */     q2 = q2 << 8 | i;
/* 1378 */     i = this._inputData.readUnsignedByte();
/* 1379 */     if (codes[i] != 0) {
/* 1380 */       if (i == 34) {
/* 1381 */         return findName(this._quad1, q2, 4);
/*      */       }
/* 1383 */       return parseName(this._quad1, q2, i, 4);
/*      */     } 
/* 1385 */     return _parseMediumName2(i, q2);
/*      */   }
/*      */ 
/*      */   
/*      */   private final String _parseMediumName2(int q3, int q2) throws IOException {
/* 1390 */     int[] codes = _icLatin1;
/*      */ 
/*      */     
/* 1393 */     int i = this._inputData.readUnsignedByte();
/* 1394 */     if (codes[i] != 0) {
/* 1395 */       if (i == 34) {
/* 1396 */         return findName(this._quad1, q2, q3, 1);
/*      */       }
/* 1398 */       return parseName(this._quad1, q2, q3, i, 1);
/*      */     } 
/* 1400 */     q3 = q3 << 8 | i;
/* 1401 */     i = this._inputData.readUnsignedByte();
/* 1402 */     if (codes[i] != 0) {
/* 1403 */       if (i == 34) {
/* 1404 */         return findName(this._quad1, q2, q3, 2);
/*      */       }
/* 1406 */       return parseName(this._quad1, q2, q3, i, 2);
/*      */     } 
/* 1408 */     q3 = q3 << 8 | i;
/* 1409 */     i = this._inputData.readUnsignedByte();
/* 1410 */     if (codes[i] != 0) {
/* 1411 */       if (i == 34) {
/* 1412 */         return findName(this._quad1, q2, q3, 3);
/*      */       }
/* 1414 */       return parseName(this._quad1, q2, q3, i, 3);
/*      */     } 
/* 1416 */     q3 = q3 << 8 | i;
/* 1417 */     i = this._inputData.readUnsignedByte();
/* 1418 */     if (codes[i] != 0) {
/* 1419 */       if (i == 34) {
/* 1420 */         return findName(this._quad1, q2, q3, 4);
/*      */       }
/* 1422 */       return parseName(this._quad1, q2, q3, i, 4);
/*      */     } 
/* 1424 */     return _parseLongName(i, q2, q3);
/*      */   }
/*      */ 
/*      */   
/*      */   private final String _parseLongName(int q, int q2, int q3) throws IOException {
/* 1429 */     this._quadBuffer[0] = this._quad1;
/* 1430 */     this._quadBuffer[1] = q2;
/* 1431 */     this._quadBuffer[2] = q3;
/*      */ 
/*      */     
/* 1434 */     int[] codes = _icLatin1;
/* 1435 */     int qlen = 3;
/*      */     
/*      */     while (true) {
/* 1438 */       int i = this._inputData.readUnsignedByte();
/* 1439 */       if (codes[i] != 0) {
/* 1440 */         if (i == 34) {
/* 1441 */           return findName(this._quadBuffer, qlen, q, 1);
/*      */         }
/* 1443 */         return parseEscapedName(this._quadBuffer, qlen, q, i, 1);
/*      */       } 
/*      */       
/* 1446 */       q = q << 8 | i;
/* 1447 */       i = this._inputData.readUnsignedByte();
/* 1448 */       if (codes[i] != 0) {
/* 1449 */         if (i == 34) {
/* 1450 */           return findName(this._quadBuffer, qlen, q, 2);
/*      */         }
/* 1452 */         return parseEscapedName(this._quadBuffer, qlen, q, i, 2);
/*      */       } 
/*      */       
/* 1455 */       q = q << 8 | i;
/* 1456 */       i = this._inputData.readUnsignedByte();
/* 1457 */       if (codes[i] != 0) {
/* 1458 */         if (i == 34) {
/* 1459 */           return findName(this._quadBuffer, qlen, q, 3);
/*      */         }
/* 1461 */         return parseEscapedName(this._quadBuffer, qlen, q, i, 3);
/*      */       } 
/*      */       
/* 1464 */       q = q << 8 | i;
/* 1465 */       i = this._inputData.readUnsignedByte();
/* 1466 */       if (codes[i] != 0) {
/* 1467 */         if (i == 34) {
/* 1468 */           return findName(this._quadBuffer, qlen, q, 4);
/*      */         }
/* 1470 */         return parseEscapedName(this._quadBuffer, qlen, q, i, 4);
/*      */       } 
/*      */ 
/*      */       
/* 1474 */       if (qlen >= this._quadBuffer.length) {
/* 1475 */         this._quadBuffer = _growArrayBy(this._quadBuffer, qlen);
/*      */       }
/* 1477 */       this._quadBuffer[qlen++] = q;
/* 1478 */       q = i;
/*      */     } 
/*      */   }
/*      */   
/*      */   private final String parseName(int q1, int ch, int lastQuadBytes) throws IOException {
/* 1483 */     return parseEscapedName(this._quadBuffer, 0, q1, ch, lastQuadBytes);
/*      */   }
/*      */   
/*      */   private final String parseName(int q1, int q2, int ch, int lastQuadBytes) throws IOException {
/* 1487 */     this._quadBuffer[0] = q1;
/* 1488 */     return parseEscapedName(this._quadBuffer, 1, q2, ch, lastQuadBytes);
/*      */   }
/*      */   
/*      */   private final String parseName(int q1, int q2, int q3, int ch, int lastQuadBytes) throws IOException {
/* 1492 */     this._quadBuffer[0] = q1;
/* 1493 */     this._quadBuffer[1] = q2;
/* 1494 */     return parseEscapedName(this._quadBuffer, 2, q3, ch, lastQuadBytes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final String parseEscapedName(int[] quads, int qlen, int currQuad, int ch, int currQuadBytes) throws IOException {
/* 1510 */     int[] codes = _icLatin1;
/*      */     
/*      */     while (true) {
/* 1513 */       if (codes[ch] != 0) {
/* 1514 */         if (ch == 34) {
/*      */           break;
/*      */         }
/*      */         
/* 1518 */         if (ch != 92) {
/*      */           
/* 1520 */           _throwUnquotedSpace(ch, "name");
/*      */         } else {
/*      */           
/* 1523 */           ch = _decodeEscaped();
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1530 */         if (ch > 127) {
/*      */           
/* 1532 */           if (currQuadBytes >= 4) {
/* 1533 */             if (qlen >= quads.length) {
/* 1534 */               this._quadBuffer = quads = _growArrayBy(quads, quads.length);
/*      */             }
/* 1536 */             quads[qlen++] = currQuad;
/* 1537 */             currQuad = 0;
/* 1538 */             currQuadBytes = 0;
/*      */           } 
/* 1540 */           if (ch < 2048) {
/* 1541 */             currQuad = currQuad << 8 | 0xC0 | ch >> 6;
/* 1542 */             currQuadBytes++;
/*      */           } else {
/*      */             
/* 1545 */             currQuad = currQuad << 8 | 0xE0 | ch >> 12;
/* 1546 */             currQuadBytes++;
/*      */             
/* 1548 */             if (currQuadBytes >= 4) {
/* 1549 */               if (qlen >= quads.length) {
/* 1550 */                 this._quadBuffer = quads = _growArrayBy(quads, quads.length);
/*      */               }
/* 1552 */               quads[qlen++] = currQuad;
/* 1553 */               currQuad = 0;
/* 1554 */               currQuadBytes = 0;
/*      */             } 
/* 1556 */             currQuad = currQuad << 8 | 0x80 | ch >> 6 & 0x3F;
/* 1557 */             currQuadBytes++;
/*      */           } 
/*      */           
/* 1560 */           ch = 0x80 | ch & 0x3F;
/*      */         } 
/*      */       } 
/*      */       
/* 1564 */       if (currQuadBytes < 4) {
/* 1565 */         currQuadBytes++;
/* 1566 */         currQuad = currQuad << 8 | ch;
/*      */       } else {
/* 1568 */         if (qlen >= quads.length) {
/* 1569 */           this._quadBuffer = quads = _growArrayBy(quads, quads.length);
/*      */         }
/* 1571 */         quads[qlen++] = currQuad;
/* 1572 */         currQuad = ch;
/* 1573 */         currQuadBytes = 1;
/*      */       } 
/* 1575 */       ch = this._inputData.readUnsignedByte();
/*      */     } 
/*      */     
/* 1578 */     if (currQuadBytes > 0) {
/* 1579 */       if (qlen >= quads.length) {
/* 1580 */         this._quadBuffer = quads = _growArrayBy(quads, quads.length);
/*      */       }
/* 1582 */       quads[qlen++] = pad(currQuad, currQuadBytes);
/*      */     } 
/* 1584 */     String name = this._symbols.findName(quads, qlen);
/* 1585 */     if (name == null) {
/* 1586 */       name = addName(quads, qlen, currQuadBytes);
/*      */     }
/* 1588 */     return name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String _handleOddName(int ch) throws IOException {
/* 1606 */     if (ch == 39 && (this._features & FEAT_MASK_ALLOW_SINGLE_QUOTES) != 0) {
/* 1607 */       return _parseAposName();
/*      */     }
/* 1609 */     if ((this._features & FEAT_MASK_ALLOW_UNQUOTED_NAMES) == 0) {
/* 1610 */       char c = (char)_decodeCharForError(ch);
/* 1611 */       _reportUnexpectedChar(c, "was expecting double-quote to start field name");
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1617 */     int[] codes = CharTypes.getInputCodeUtf8JsNames();
/*      */     
/* 1619 */     if (codes[ch] != 0) {
/* 1620 */       _reportUnexpectedChar(ch, "was expecting either valid name character (for unquoted name) or double-quote (for quoted) to start field name");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1627 */     int[] quads = this._quadBuffer;
/* 1628 */     int qlen = 0;
/* 1629 */     int currQuad = 0;
/* 1630 */     int currQuadBytes = 0;
/*      */ 
/*      */     
/*      */     do {
/* 1634 */       if (currQuadBytes < 4) {
/* 1635 */         currQuadBytes++;
/* 1636 */         currQuad = currQuad << 8 | ch;
/*      */       } else {
/* 1638 */         if (qlen >= quads.length) {
/* 1639 */           this._quadBuffer = quads = _growArrayBy(quads, quads.length);
/*      */         }
/* 1641 */         quads[qlen++] = currQuad;
/* 1642 */         currQuad = ch;
/* 1643 */         currQuadBytes = 1;
/*      */       } 
/* 1645 */       ch = this._inputData.readUnsignedByte();
/* 1646 */     } while (codes[ch] == 0);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1651 */     this._nextByte = ch;
/* 1652 */     if (currQuadBytes > 0) {
/* 1653 */       if (qlen >= quads.length) {
/* 1654 */         this._quadBuffer = quads = _growArrayBy(quads, quads.length);
/*      */       }
/* 1656 */       quads[qlen++] = currQuad;
/*      */     } 
/* 1658 */     String name = this._symbols.findName(quads, qlen);
/* 1659 */     if (name == null) {
/* 1660 */       name = addName(quads, qlen, currQuadBytes);
/*      */     }
/* 1662 */     return name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String _parseAposName() throws IOException {
/* 1673 */     int ch = this._inputData.readUnsignedByte();
/* 1674 */     if (ch == 39) {
/* 1675 */       return "";
/*      */     }
/* 1677 */     int[] quads = this._quadBuffer;
/* 1678 */     int qlen = 0;
/* 1679 */     int currQuad = 0;
/* 1680 */     int currQuadBytes = 0;
/*      */ 
/*      */ 
/*      */     
/* 1684 */     int[] codes = _icLatin1;
/*      */ 
/*      */     
/* 1687 */     while (ch != 39) {
/*      */ 
/*      */ 
/*      */       
/* 1691 */       if (ch != 34 && codes[ch] != 0) {
/* 1692 */         if (ch != 92) {
/*      */ 
/*      */           
/* 1695 */           _throwUnquotedSpace(ch, "name");
/*      */         } else {
/*      */           
/* 1698 */           ch = _decodeEscaped();
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1704 */         if (ch > 127) {
/*      */           
/* 1706 */           if (currQuadBytes >= 4) {
/* 1707 */             if (qlen >= quads.length) {
/* 1708 */               this._quadBuffer = quads = _growArrayBy(quads, quads.length);
/*      */             }
/* 1710 */             quads[qlen++] = currQuad;
/* 1711 */             currQuad = 0;
/* 1712 */             currQuadBytes = 0;
/*      */           } 
/* 1714 */           if (ch < 2048) {
/* 1715 */             currQuad = currQuad << 8 | 0xC0 | ch >> 6;
/* 1716 */             currQuadBytes++;
/*      */           } else {
/*      */             
/* 1719 */             currQuad = currQuad << 8 | 0xE0 | ch >> 12;
/* 1720 */             currQuadBytes++;
/*      */             
/* 1722 */             if (currQuadBytes >= 4) {
/* 1723 */               if (qlen >= quads.length) {
/* 1724 */                 this._quadBuffer = quads = _growArrayBy(quads, quads.length);
/*      */               }
/* 1726 */               quads[qlen++] = currQuad;
/* 1727 */               currQuad = 0;
/* 1728 */               currQuadBytes = 0;
/*      */             } 
/* 1730 */             currQuad = currQuad << 8 | 0x80 | ch >> 6 & 0x3F;
/* 1731 */             currQuadBytes++;
/*      */           } 
/*      */           
/* 1734 */           ch = 0x80 | ch & 0x3F;
/*      */         } 
/*      */       } 
/*      */       
/* 1738 */       if (currQuadBytes < 4) {
/* 1739 */         currQuadBytes++;
/* 1740 */         currQuad = currQuad << 8 | ch;
/*      */       } else {
/* 1742 */         if (qlen >= quads.length) {
/* 1743 */           this._quadBuffer = quads = _growArrayBy(quads, quads.length);
/*      */         }
/* 1745 */         quads[qlen++] = currQuad;
/* 1746 */         currQuad = ch;
/* 1747 */         currQuadBytes = 1;
/*      */       } 
/* 1749 */       ch = this._inputData.readUnsignedByte();
/*      */     } 
/*      */     
/* 1752 */     if (currQuadBytes > 0) {
/* 1753 */       if (qlen >= quads.length) {
/* 1754 */         this._quadBuffer = quads = _growArrayBy(quads, quads.length);
/*      */       }
/* 1756 */       quads[qlen++] = pad(currQuad, currQuadBytes);
/*      */     } 
/* 1758 */     String name = this._symbols.findName(quads, qlen);
/* 1759 */     if (name == null) {
/* 1760 */       name = addName(quads, qlen, currQuadBytes);
/*      */     }
/* 1762 */     return name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final String findName(int q1, int lastQuadBytes) throws JsonParseException {
/* 1773 */     q1 = pad(q1, lastQuadBytes);
/*      */     
/* 1775 */     String name = this._symbols.findName(q1);
/* 1776 */     if (name != null) {
/* 1777 */       return name;
/*      */     }
/*      */     
/* 1780 */     this._quadBuffer[0] = q1;
/* 1781 */     return addName(this._quadBuffer, 1, lastQuadBytes);
/*      */   }
/*      */ 
/*      */   
/*      */   private final String findName(int q1, int q2, int lastQuadBytes) throws JsonParseException {
/* 1786 */     q2 = pad(q2, lastQuadBytes);
/*      */     
/* 1788 */     String name = this._symbols.findName(q1, q2);
/* 1789 */     if (name != null) {
/* 1790 */       return name;
/*      */     }
/*      */     
/* 1793 */     this._quadBuffer[0] = q1;
/* 1794 */     this._quadBuffer[1] = q2;
/* 1795 */     return addName(this._quadBuffer, 2, lastQuadBytes);
/*      */   }
/*      */ 
/*      */   
/*      */   private final String findName(int q1, int q2, int q3, int lastQuadBytes) throws JsonParseException {
/* 1800 */     q3 = pad(q3, lastQuadBytes);
/* 1801 */     String name = this._symbols.findName(q1, q2, q3);
/* 1802 */     if (name != null) {
/* 1803 */       return name;
/*      */     }
/* 1805 */     int[] quads = this._quadBuffer;
/* 1806 */     quads[0] = q1;
/* 1807 */     quads[1] = q2;
/* 1808 */     quads[2] = pad(q3, lastQuadBytes);
/* 1809 */     return addName(quads, 3, lastQuadBytes);
/*      */   }
/*      */ 
/*      */   
/*      */   private final String findName(int[] quads, int qlen, int lastQuad, int lastQuadBytes) throws JsonParseException {
/* 1814 */     if (qlen >= quads.length) {
/* 1815 */       this._quadBuffer = quads = _growArrayBy(quads, quads.length);
/*      */     }
/* 1817 */     quads[qlen++] = pad(lastQuad, lastQuadBytes);
/* 1818 */     String name = this._symbols.findName(quads, qlen);
/* 1819 */     if (name == null) {
/* 1820 */       return addName(quads, qlen, lastQuadBytes);
/*      */     }
/* 1822 */     return name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final String addName(int[] quads, int qlen, int lastQuadBytes) throws JsonParseException {
/* 1838 */     int lastQuad, byteLen = (qlen << 2) - 4 + lastQuadBytes;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1847 */     if (lastQuadBytes < 4) {
/* 1848 */       lastQuad = quads[qlen - 1];
/*      */       
/* 1850 */       quads[qlen - 1] = lastQuad << 4 - lastQuadBytes << 3;
/*      */     } else {
/* 1852 */       lastQuad = 0;
/*      */     } 
/*      */ 
/*      */     
/* 1856 */     char[] cbuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 1857 */     int cix = 0;
/*      */     
/* 1859 */     for (int ix = 0; ix < byteLen; ) {
/* 1860 */       int ch = quads[ix >> 2];
/* 1861 */       int byteIx = ix & 0x3;
/* 1862 */       ch = ch >> 3 - byteIx << 3 & 0xFF;
/* 1863 */       ix++;
/*      */       
/* 1865 */       if (ch > 127) {
/*      */         int needed;
/* 1867 */         if ((ch & 0xE0) == 192) {
/* 1868 */           ch &= 0x1F;
/* 1869 */           needed = 1;
/* 1870 */         } else if ((ch & 0xF0) == 224) {
/* 1871 */           ch &= 0xF;
/* 1872 */           needed = 2;
/* 1873 */         } else if ((ch & 0xF8) == 240) {
/* 1874 */           ch &= 0x7;
/* 1875 */           needed = 3;
/*      */         } else {
/* 1877 */           _reportInvalidInitial(ch);
/* 1878 */           needed = ch = 1;
/*      */         } 
/* 1880 */         if (ix + needed > byteLen) {
/* 1881 */           _reportInvalidEOF(" in field name", JsonToken.FIELD_NAME);
/*      */         }
/*      */ 
/*      */         
/* 1885 */         int ch2 = quads[ix >> 2];
/* 1886 */         byteIx = ix & 0x3;
/* 1887 */         ch2 >>= 3 - byteIx << 3;
/* 1888 */         ix++;
/*      */         
/* 1890 */         if ((ch2 & 0xC0) != 128) {
/* 1891 */           _reportInvalidOther(ch2);
/*      */         }
/* 1893 */         ch = ch << 6 | ch2 & 0x3F;
/* 1894 */         if (needed > 1) {
/* 1895 */           ch2 = quads[ix >> 2];
/* 1896 */           byteIx = ix & 0x3;
/* 1897 */           ch2 >>= 3 - byteIx << 3;
/* 1898 */           ix++;
/*      */           
/* 1900 */           if ((ch2 & 0xC0) != 128) {
/* 1901 */             _reportInvalidOther(ch2);
/*      */           }
/* 1903 */           ch = ch << 6 | ch2 & 0x3F;
/* 1904 */           if (needed > 2) {
/* 1905 */             ch2 = quads[ix >> 2];
/* 1906 */             byteIx = ix & 0x3;
/* 1907 */             ch2 >>= 3 - byteIx << 3;
/* 1908 */             ix++;
/* 1909 */             if ((ch2 & 0xC0) != 128) {
/* 1910 */               _reportInvalidOther(ch2 & 0xFF);
/*      */             }
/* 1912 */             ch = ch << 6 | ch2 & 0x3F;
/*      */           } 
/*      */         } 
/* 1915 */         if (needed > 2) {
/* 1916 */           ch -= 65536;
/* 1917 */           if (cix >= cbuf.length) {
/* 1918 */             cbuf = this._textBuffer.expandCurrentSegment();
/*      */           }
/* 1920 */           cbuf[cix++] = (char)(55296 + (ch >> 10));
/* 1921 */           ch = 0xDC00 | ch & 0x3FF;
/*      */         } 
/*      */       } 
/* 1924 */       if (cix >= cbuf.length) {
/* 1925 */         cbuf = this._textBuffer.expandCurrentSegment();
/*      */       }
/* 1927 */       cbuf[cix++] = (char)ch;
/*      */     } 
/*      */ 
/*      */     
/* 1931 */     String baseName = new String(cbuf, 0, cix);
/*      */     
/* 1933 */     if (lastQuadBytes < 4) {
/* 1934 */       quads[qlen - 1] = lastQuad;
/*      */     }
/* 1936 */     return this._symbols.addName(baseName, quads, qlen);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _finishString() throws IOException {
/* 1948 */     int outPtr = 0;
/* 1949 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 1950 */     int[] codes = _icUTF8;
/* 1951 */     int outEnd = outBuf.length;
/*      */     
/*      */     while (true) {
/* 1954 */       int c = this._inputData.readUnsignedByte();
/* 1955 */       if (codes[c] != 0) {
/* 1956 */         if (c == 34) {
/* 1957 */           this._textBuffer.setCurrentLength(outPtr);
/*      */           return;
/*      */         } 
/* 1960 */         _finishString2(outBuf, outPtr, c);
/*      */         return;
/*      */       } 
/* 1963 */       outBuf[outPtr++] = (char)c;
/* 1964 */       if (outPtr >= outEnd) {
/* 1965 */         _finishString2(outBuf, outPtr, this._inputData.readUnsignedByte());
/*      */         return;
/*      */       } 
/*      */     } 
/*      */   } private String _finishAndReturnString() throws IOException {
/* 1970 */     int outPtr = 0;
/* 1971 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 1972 */     int[] codes = _icUTF8;
/* 1973 */     int outEnd = outBuf.length;
/*      */     
/*      */     while (true) {
/* 1976 */       int c = this._inputData.readUnsignedByte();
/* 1977 */       if (codes[c] != 0) {
/* 1978 */         if (c == 34) {
/* 1979 */           return this._textBuffer.setCurrentAndReturn(outPtr);
/*      */         }
/* 1981 */         _finishString2(outBuf, outPtr, c);
/* 1982 */         return this._textBuffer.contentsAsString();
/*      */       } 
/* 1984 */       outBuf[outPtr++] = (char)c;
/* 1985 */       if (outPtr >= outEnd) {
/* 1986 */         _finishString2(outBuf, outPtr, this._inputData.readUnsignedByte());
/* 1987 */         return this._textBuffer.contentsAsString();
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private final void _finishString2(char[] outBuf, int outPtr, int c) throws IOException {
/* 1994 */     int[] codes = _icUTF8;
/* 1995 */     int outEnd = outBuf.length;
/*      */ 
/*      */     
/* 1998 */     for (;; c = this._inputData.readUnsignedByte()) {
/*      */       
/* 2000 */       while (codes[c] == 0) {
/* 2001 */         if (outPtr >= outEnd) {
/* 2002 */           outBuf = this._textBuffer.finishCurrentSegment();
/* 2003 */           outPtr = 0;
/* 2004 */           outEnd = outBuf.length;
/*      */         } 
/* 2006 */         outBuf[outPtr++] = (char)c;
/* 2007 */         c = this._inputData.readUnsignedByte();
/*      */       } 
/*      */       
/* 2010 */       if (c == 34) {
/*      */         break;
/*      */       }
/* 2013 */       switch (codes[c]) {
/*      */         case 1:
/* 2015 */           c = _decodeEscaped();
/*      */           break;
/*      */         case 2:
/* 2018 */           c = _decodeUtf8_2(c);
/*      */           break;
/*      */         case 3:
/* 2021 */           c = _decodeUtf8_3(c);
/*      */           break;
/*      */         case 4:
/* 2024 */           c = _decodeUtf8_4(c);
/*      */           
/* 2026 */           if (outPtr >= outBuf.length) {
/* 2027 */             outBuf = this._textBuffer.finishCurrentSegment();
/* 2028 */             outPtr = 0;
/* 2029 */             outEnd = outBuf.length;
/*      */           } 
/* 2031 */           outBuf[outPtr++] = (char)(0xD800 | c >> 10);
/* 2032 */           c = 0xDC00 | c & 0x3FF;
/*      */           break;
/*      */         
/*      */         default:
/* 2036 */           if (c < 32) {
/* 2037 */             _throwUnquotedSpace(c, "string value");
/*      */             break;
/*      */           } 
/* 2040 */           _reportInvalidChar(c);
/*      */           break;
/*      */       } 
/*      */       
/* 2044 */       if (outPtr >= outBuf.length) {
/* 2045 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 2046 */         outPtr = 0;
/* 2047 */         outEnd = outBuf.length;
/*      */       } 
/*      */       
/* 2050 */       outBuf[outPtr++] = (char)c;
/*      */     } 
/* 2052 */     this._textBuffer.setCurrentLength(outPtr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _skipString() throws IOException {
/* 2065 */     this._tokenIncomplete = false;
/*      */ 
/*      */     
/* 2068 */     int[] codes = _icUTF8;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/* 2076 */       int c = this._inputData.readUnsignedByte();
/* 2077 */       if (codes[c] != 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2082 */         if (c == 34) {
/*      */           break;
/*      */         }
/*      */         
/* 2086 */         switch (codes[c]) {
/*      */           case 1:
/* 2088 */             _decodeEscaped();
/*      */             continue;
/*      */           case 2:
/* 2091 */             _skipUtf8_2();
/*      */             continue;
/*      */           case 3:
/* 2094 */             _skipUtf8_3();
/*      */             continue;
/*      */           case 4:
/* 2097 */             _skipUtf8_4();
/*      */             continue;
/*      */         } 
/* 2100 */         if (c < 32) {
/* 2101 */           _throwUnquotedSpace(c, "string value");
/*      */           continue;
/*      */         } 
/* 2104 */         _reportInvalidChar(c);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonToken _handleUnexpectedValue(int c) throws IOException {
/* 2125 */     switch (c) {
/*      */       case 93:
/* 2127 */         if (!this._parsingContext.inArray()) {
/*      */           break;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 44:
/* 2136 */         if (!this._parsingContext.inRoot() && (
/* 2137 */           this._features & FEAT_MASK_ALLOW_MISSING) != 0) {
/*      */           
/* 2139 */           this._nextByte = c;
/* 2140 */           return JsonToken.VALUE_NULL;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 125:
/* 2147 */         _reportUnexpectedChar(c, "expected a value");
/*      */       case 39:
/* 2149 */         if ((this._features & FEAT_MASK_ALLOW_SINGLE_QUOTES) != 0) {
/* 2150 */           return _handleApos();
/*      */         }
/*      */         break;
/*      */       case 78:
/* 2154 */         _matchToken("NaN", 1);
/* 2155 */         if ((this._features & FEAT_MASK_NON_NUM_NUMBERS) != 0) {
/* 2156 */           return resetAsNaN("NaN", Double.NaN);
/*      */         }
/* 2158 */         _reportError("Non-standard token 'NaN': enable `JsonReadFeature.ALLOW_NON_NUMERIC_NUMBERS` to allow");
/*      */         break;
/*      */       case 73:
/* 2161 */         _matchToken("Infinity", 1);
/* 2162 */         if ((this._features & FEAT_MASK_NON_NUM_NUMBERS) != 0) {
/* 2163 */           return resetAsNaN("Infinity", Double.POSITIVE_INFINITY);
/*      */         }
/* 2165 */         _reportError("Non-standard token 'Infinity': enable `JsonReadFeature.ALLOW_NON_NUMERIC_NUMBERS` to allow");
/*      */         break;
/*      */       case 43:
/* 2168 */         return _handleInvalidNumberStart(this._inputData.readUnsignedByte(), false, true);
/*      */     } 
/*      */     
/* 2171 */     if (Character.isJavaIdentifierStart(c)) {
/* 2172 */       _reportInvalidToken(c, "" + (char)c, _validJsonTokenList());
/*      */     }
/*      */     
/* 2175 */     _reportUnexpectedChar(c, "expected a valid value " + _validJsonValueList());
/* 2176 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _handleApos() throws IOException {
/* 2181 */     int c = 0;
/*      */     
/* 2183 */     int outPtr = 0;
/* 2184 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/*      */ 
/*      */     
/* 2187 */     int[] codes = _icUTF8;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     label36: while (true) {
/* 2194 */       int outEnd = outBuf.length;
/* 2195 */       if (outPtr >= outBuf.length) {
/* 2196 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 2197 */         outPtr = 0;
/* 2198 */         outEnd = outBuf.length;
/*      */       } 
/*      */       while (true)
/* 2201 */       { c = this._inputData.readUnsignedByte();
/* 2202 */         if (c == 39) {
/*      */           break;
/*      */         }
/* 2205 */         if (codes[c] != 0 && c != 34)
/*      */         
/*      */         { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2214 */           switch (codes[c]) {
/*      */             case 1:
/* 2216 */               c = _decodeEscaped();
/*      */               break;
/*      */             case 2:
/* 2219 */               c = _decodeUtf8_2(c);
/*      */               break;
/*      */             case 3:
/* 2222 */               c = _decodeUtf8_3(c);
/*      */               break;
/*      */             case 4:
/* 2225 */               c = _decodeUtf8_4(c);
/*      */               
/* 2227 */               outBuf[outPtr++] = (char)(0xD800 | c >> 10);
/* 2228 */               if (outPtr >= outBuf.length) {
/* 2229 */                 outBuf = this._textBuffer.finishCurrentSegment();
/* 2230 */                 outPtr = 0;
/*      */               } 
/* 2232 */               c = 0xDC00 | c & 0x3FF;
/*      */               break;
/*      */             
/*      */             default:
/* 2236 */               if (c < 32) {
/* 2237 */                 _throwUnquotedSpace(c, "string value");
/*      */               }
/*      */               
/* 2240 */               _reportInvalidChar(c);
/*      */               break;
/*      */           } 
/* 2243 */           if (outPtr >= outBuf.length) {
/* 2244 */             outBuf = this._textBuffer.finishCurrentSegment();
/* 2245 */             outPtr = 0;
/*      */           } 
/*      */           
/* 2248 */           outBuf[outPtr++] = (char)c; continue; }  outBuf[outPtr++] = (char)c; if (outPtr >= outEnd)
/*      */           continue label36;  }  break;
/* 2250 */     }  this._textBuffer.setCurrentLength(outPtr);
/*      */     
/* 2252 */     return JsonToken.VALUE_STRING;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonToken _handleInvalidNumberStart(int ch, boolean neg) throws IOException {
/* 2261 */     return _handleInvalidNumberStart(ch, neg, false);
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _handleInvalidNumberStart(int ch, boolean neg, boolean hasSign) throws IOException {
/* 2266 */     while (ch == 73) {
/* 2267 */       String match; ch = this._inputData.readUnsignedByte();
/*      */       
/* 2269 */       if (ch == 78) {
/* 2270 */         match = neg ? "-INF" : "+INF";
/* 2271 */       } else if (ch == 110) {
/* 2272 */         match = neg ? "-Infinity" : "+Infinity";
/*      */       } else {
/*      */         break;
/*      */       } 
/* 2276 */       _matchToken(match, 3);
/* 2277 */       if ((this._features & FEAT_MASK_NON_NUM_NUMBERS) != 0) {
/* 2278 */         return resetAsNaN(match, neg ? Double.NEGATIVE_INFINITY : Double.POSITIVE_INFINITY);
/*      */       }
/* 2280 */       _reportError("Non-standard token '" + match + "': enable `JsonReadFeature.ALLOW_NON_NUMERIC_NUMBERS` to allow");
/*      */     } 
/* 2282 */     if (!isEnabled(JsonReadFeature.ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS.mappedFeature()) && hasSign && !neg) {
/* 2283 */       _reportUnexpectedNumberChar(43, "JSON spec does not allow numbers to have plus signs: enable `JsonReadFeature.ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS` to allow");
/*      */     }
/* 2285 */     String message = neg ? "expected digit (0-9) to follow minus sign, for valid numeric value" : "expected digit (0-9) for valid numeric value";
/*      */ 
/*      */     
/* 2288 */     _reportUnexpectedNumberChar(ch, message);
/* 2289 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   protected final void _matchToken(String matchStr, int i) throws IOException {
/* 2294 */     int len = matchStr.length();
/*      */     do {
/* 2296 */       int j = this._inputData.readUnsignedByte();
/* 2297 */       if (j == matchStr.charAt(i))
/* 2298 */         continue;  _reportInvalidToken(j, matchStr.substring(0, i));
/*      */     }
/* 2300 */     while (++i < len);
/*      */     
/* 2302 */     int ch = this._inputData.readUnsignedByte();
/* 2303 */     if (ch >= 48 && ch != 93 && ch != 125) {
/* 2304 */       _checkMatchEnd(matchStr, i, ch);
/*      */     }
/* 2306 */     this._nextByte = ch;
/*      */   }
/*      */ 
/*      */   
/*      */   private final void _checkMatchEnd(String matchStr, int i, int ch) throws IOException {
/* 2311 */     char c = (char)_decodeCharForError(ch);
/* 2312 */     if (Character.isJavaIdentifierPart(c)) {
/* 2313 */       _reportInvalidToken(c, matchStr.substring(0, i));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _skipWS() throws IOException {
/* 2325 */     int i = this._nextByte;
/* 2326 */     if (i < 0) {
/* 2327 */       i = this._inputData.readUnsignedByte();
/*      */     } else {
/* 2329 */       this._nextByte = -1;
/*      */     } 
/*      */     while (true) {
/* 2332 */       if (i > 32) {
/* 2333 */         if (i == 47 || i == 35) {
/* 2334 */           return _skipWSComment(i);
/*      */         }
/* 2336 */         return i;
/*      */       } 
/*      */ 
/*      */       
/* 2340 */       if (i == 13 || i == 10) {
/* 2341 */         this._currInputRow++;
/*      */       }
/*      */       
/* 2344 */       i = this._inputData.readUnsignedByte();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _skipWSOrEnd() throws IOException {
/* 2356 */     int i = this._nextByte;
/* 2357 */     if (i < 0) {
/*      */       try {
/* 2359 */         i = this._inputData.readUnsignedByte();
/* 2360 */       } catch (EOFException e) {
/* 2361 */         return _eofAsNextChar();
/*      */       } 
/*      */     } else {
/* 2364 */       this._nextByte = -1;
/*      */     } 
/*      */     while (true) {
/* 2367 */       if (i > 32) {
/* 2368 */         if (i == 47 || i == 35) {
/* 2369 */           return _skipWSComment(i);
/*      */         }
/* 2371 */         return i;
/*      */       } 
/*      */ 
/*      */       
/* 2375 */       if (i == 13 || i == 10) {
/* 2376 */         this._currInputRow++;
/*      */       }
/*      */       
/*      */       try {
/* 2380 */         i = this._inputData.readUnsignedByte();
/* 2381 */       } catch (EOFException e) {
/* 2382 */         return _eofAsNextChar();
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private final int _skipWSComment(int i) throws IOException {
/*      */     while (true) {
/* 2390 */       if (i > 32) {
/* 2391 */         if (i == 47) {
/* 2392 */           _skipComment();
/* 2393 */         } else if (i == 35) {
/* 2394 */           if (!_skipYAMLComment()) {
/* 2395 */             return i;
/*      */           }
/*      */         } else {
/* 2398 */           return i;
/*      */         
/*      */         }
/*      */       
/*      */       }
/* 2403 */       else if (i == 13 || i == 10) {
/* 2404 */         this._currInputRow++;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2412 */       i = this._inputData.readUnsignedByte();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private final int _skipColon() throws IOException {
/* 2418 */     int i = this._nextByte;
/* 2419 */     if (i < 0) {
/* 2420 */       i = this._inputData.readUnsignedByte();
/*      */     } else {
/* 2422 */       this._nextByte = -1;
/*      */     } 
/*      */     
/* 2425 */     if (i == 58) {
/* 2426 */       i = this._inputData.readUnsignedByte();
/* 2427 */       if (i > 32) {
/* 2428 */         if (i == 47 || i == 35) {
/* 2429 */           return _skipColon2(i, true);
/*      */         }
/* 2431 */         return i;
/*      */       } 
/* 2433 */       if (i == 32 || i == 9) {
/* 2434 */         i = this._inputData.readUnsignedByte();
/* 2435 */         if (i > 32) {
/* 2436 */           if (i == 47 || i == 35) {
/* 2437 */             return _skipColon2(i, true);
/*      */           }
/* 2439 */           return i;
/*      */         } 
/*      */       } 
/* 2442 */       return _skipColon2(i, true);
/*      */     } 
/* 2444 */     if (i == 32 || i == 9) {
/* 2445 */       i = this._inputData.readUnsignedByte();
/*      */     }
/* 2447 */     if (i == 58) {
/* 2448 */       i = this._inputData.readUnsignedByte();
/* 2449 */       if (i > 32) {
/* 2450 */         if (i == 47 || i == 35) {
/* 2451 */           return _skipColon2(i, true);
/*      */         }
/* 2453 */         return i;
/*      */       } 
/* 2455 */       if (i == 32 || i == 9) {
/* 2456 */         i = this._inputData.readUnsignedByte();
/* 2457 */         if (i > 32) {
/* 2458 */           if (i == 47 || i == 35) {
/* 2459 */             return _skipColon2(i, true);
/*      */           }
/* 2461 */           return i;
/*      */         } 
/*      */       } 
/* 2464 */       return _skipColon2(i, true);
/*      */     } 
/* 2466 */     return _skipColon2(i, false);
/*      */   }
/*      */ 
/*      */   
/*      */   private final int _skipColon2(int i, boolean gotColon) throws IOException {
/* 2471 */     for (;; i = this._inputData.readUnsignedByte()) {
/* 2472 */       if (i > 32) {
/* 2473 */         if (i == 47) {
/* 2474 */           _skipComment();
/*      */         
/*      */         }
/* 2477 */         else if (i != 35 || 
/* 2478 */           !_skipYAMLComment()) {
/*      */ 
/*      */ 
/*      */           
/* 2482 */           if (gotColon) {
/* 2483 */             return i;
/*      */           }
/* 2485 */           if (i != 58) {
/* 2486 */             _reportUnexpectedChar(i, "was expecting a colon to separate field name and value");
/*      */           }
/* 2488 */           gotColon = true;
/*      */         }
/*      */       
/*      */       }
/* 2492 */       else if (i == 13 || i == 10) {
/* 2493 */         this._currInputRow++;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _skipComment() throws IOException {
/* 2501 */     if ((this._features & FEAT_MASK_ALLOW_JAVA_COMMENTS) == 0) {
/* 2502 */       _reportUnexpectedChar(47, "maybe a (non-standard) comment? (not recognized as one since Feature 'ALLOW_COMMENTS' not enabled for parser)");
/*      */     }
/* 2504 */     int c = this._inputData.readUnsignedByte();
/* 2505 */     if (c == 47) {
/* 2506 */       _skipLine();
/* 2507 */     } else if (c == 42) {
/* 2508 */       _skipCComment();
/*      */     } else {
/* 2510 */       _reportUnexpectedChar(c, "was expecting either '*' or '/' for a comment");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _skipCComment() throws IOException {
/* 2517 */     int[] codes = CharTypes.getInputCodeComment();
/* 2518 */     int i = this._inputData.readUnsignedByte();
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/* 2523 */       int code = codes[i];
/* 2524 */       if (code != 0)
/* 2525 */         switch (code) {
/*      */           case 42:
/* 2527 */             i = this._inputData.readUnsignedByte();
/* 2528 */             if (i == 47) {
/*      */               return;
/*      */             }
/*      */             continue;
/*      */           case 10:
/*      */           case 13:
/* 2534 */             this._currInputRow++;
/*      */             break;
/*      */           case 2:
/* 2537 */             _skipUtf8_2();
/*      */             break;
/*      */           case 3:
/* 2540 */             _skipUtf8_3();
/*      */             break;
/*      */           case 4:
/* 2543 */             _skipUtf8_4();
/*      */             break;
/*      */           
/*      */           default:
/* 2547 */             _reportInvalidChar(i);
/*      */             break;
/*      */         }  
/* 2550 */       i = this._inputData.readUnsignedByte();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private final boolean _skipYAMLComment() throws IOException {
/* 2556 */     if ((this._features & FEAT_MASK_ALLOW_YAML_COMMENTS) == 0) {
/* 2557 */       return false;
/*      */     }
/* 2559 */     _skipLine();
/* 2560 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _skipLine() throws IOException {
/* 2570 */     int[] codes = CharTypes.getInputCodeComment();
/*      */     while (true) {
/* 2572 */       int i = this._inputData.readUnsignedByte();
/* 2573 */       int code = codes[i];
/* 2574 */       if (code != 0) {
/* 2575 */         switch (code) {
/*      */           case 10:
/*      */           case 13:
/* 2578 */             this._currInputRow++;
/*      */             return;
/*      */           case 42:
/*      */             continue;
/*      */           case 2:
/* 2583 */             _skipUtf8_2();
/*      */             continue;
/*      */           case 3:
/* 2586 */             _skipUtf8_3();
/*      */             continue;
/*      */           case 4:
/* 2589 */             _skipUtf8_4();
/*      */             continue;
/*      */         } 
/* 2592 */         if (code < 0)
/*      */         {
/* 2594 */           _reportInvalidChar(i);
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected char _decodeEscaped() throws IOException {
/* 2604 */     int c = this._inputData.readUnsignedByte();
/*      */     
/* 2606 */     switch (c) {
/*      */       
/*      */       case 98:
/* 2609 */         return '\b';
/*      */       case 116:
/* 2611 */         return '\t';
/*      */       case 110:
/* 2613 */         return '\n';
/*      */       case 102:
/* 2615 */         return '\f';
/*      */       case 114:
/* 2617 */         return '\r';
/*      */ 
/*      */       
/*      */       case 34:
/*      */       case 47:
/*      */       case 92:
/* 2623 */         return (char)c;
/*      */       
/*      */       case 117:
/*      */         break;
/*      */       
/*      */       default:
/* 2629 */         return _handleUnrecognizedCharacterEscape((char)_decodeCharForError(c));
/*      */     } 
/*      */ 
/*      */     
/* 2633 */     int value = 0;
/* 2634 */     for (int i = 0; i < 4; i++) {
/* 2635 */       int ch = this._inputData.readUnsignedByte();
/* 2636 */       int digit = CharTypes.charToHex(ch);
/* 2637 */       if (digit < 0) {
/* 2638 */         _reportUnexpectedChar(ch, "expected a hex-digit for character escape sequence");
/*      */       }
/* 2640 */       value = value << 4 | digit;
/*      */     } 
/* 2642 */     return (char)value;
/*      */   }
/*      */ 
/*      */   
/*      */   protected int _decodeCharForError(int firstByte) throws IOException {
/* 2647 */     int c = firstByte & 0xFF;
/* 2648 */     if (c > 127) {
/*      */       int needed;
/*      */ 
/*      */       
/* 2652 */       if ((c & 0xE0) == 192) {
/* 2653 */         c &= 0x1F;
/* 2654 */         needed = 1;
/* 2655 */       } else if ((c & 0xF0) == 224) {
/* 2656 */         c &= 0xF;
/* 2657 */         needed = 2;
/* 2658 */       } else if ((c & 0xF8) == 240) {
/*      */         
/* 2660 */         c &= 0x7;
/* 2661 */         needed = 3;
/*      */       } else {
/* 2663 */         _reportInvalidInitial(c & 0xFF);
/* 2664 */         needed = 1;
/*      */       } 
/*      */       
/* 2667 */       int d = this._inputData.readUnsignedByte();
/* 2668 */       if ((d & 0xC0) != 128) {
/* 2669 */         _reportInvalidOther(d & 0xFF);
/*      */       }
/* 2671 */       c = c << 6 | d & 0x3F;
/*      */       
/* 2673 */       if (needed > 1) {
/* 2674 */         d = this._inputData.readUnsignedByte();
/* 2675 */         if ((d & 0xC0) != 128) {
/* 2676 */           _reportInvalidOther(d & 0xFF);
/*      */         }
/* 2678 */         c = c << 6 | d & 0x3F;
/* 2679 */         if (needed > 2) {
/* 2680 */           d = this._inputData.readUnsignedByte();
/* 2681 */           if ((d & 0xC0) != 128) {
/* 2682 */             _reportInvalidOther(d & 0xFF);
/*      */           }
/* 2684 */           c = c << 6 | d & 0x3F;
/*      */         } 
/*      */       } 
/*      */     } 
/* 2688 */     return c;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _decodeUtf8_2(int c) throws IOException {
/* 2699 */     int d = this._inputData.readUnsignedByte();
/* 2700 */     if ((d & 0xC0) != 128) {
/* 2701 */       _reportInvalidOther(d & 0xFF);
/*      */     }
/* 2703 */     return (c & 0x1F) << 6 | d & 0x3F;
/*      */   }
/*      */ 
/*      */   
/*      */   private final int _decodeUtf8_3(int c1) throws IOException {
/* 2708 */     c1 &= 0xF;
/* 2709 */     int d = this._inputData.readUnsignedByte();
/* 2710 */     if ((d & 0xC0) != 128) {
/* 2711 */       _reportInvalidOther(d & 0xFF);
/*      */     }
/* 2713 */     int c = c1 << 6 | d & 0x3F;
/* 2714 */     d = this._inputData.readUnsignedByte();
/* 2715 */     if ((d & 0xC0) != 128) {
/* 2716 */       _reportInvalidOther(d & 0xFF);
/*      */     }
/* 2718 */     c = c << 6 | d & 0x3F;
/* 2719 */     return c;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _decodeUtf8_4(int c) throws IOException {
/* 2728 */     int d = this._inputData.readUnsignedByte();
/* 2729 */     if ((d & 0xC0) != 128) {
/* 2730 */       _reportInvalidOther(d & 0xFF);
/*      */     }
/* 2732 */     c = (c & 0x7) << 6 | d & 0x3F;
/* 2733 */     d = this._inputData.readUnsignedByte();
/* 2734 */     if ((d & 0xC0) != 128) {
/* 2735 */       _reportInvalidOther(d & 0xFF);
/*      */     }
/* 2737 */     c = c << 6 | d & 0x3F;
/* 2738 */     d = this._inputData.readUnsignedByte();
/* 2739 */     if ((d & 0xC0) != 128) {
/* 2740 */       _reportInvalidOther(d & 0xFF);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2746 */     return (c << 6 | d & 0x3F) - 65536;
/*      */   }
/*      */ 
/*      */   
/*      */   private final void _skipUtf8_2() throws IOException {
/* 2751 */     int c = this._inputData.readUnsignedByte();
/* 2752 */     if ((c & 0xC0) != 128) {
/* 2753 */       _reportInvalidOther(c & 0xFF);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _skipUtf8_3() throws IOException {
/* 2763 */     int c = this._inputData.readUnsignedByte();
/* 2764 */     if ((c & 0xC0) != 128) {
/* 2765 */       _reportInvalidOther(c & 0xFF);
/*      */     }
/* 2767 */     c = this._inputData.readUnsignedByte();
/* 2768 */     if ((c & 0xC0) != 128) {
/* 2769 */       _reportInvalidOther(c & 0xFF);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private final void _skipUtf8_4() throws IOException {
/* 2775 */     int d = this._inputData.readUnsignedByte();
/* 2776 */     if ((d & 0xC0) != 128) {
/* 2777 */       _reportInvalidOther(d & 0xFF);
/*      */     }
/* 2779 */     d = this._inputData.readUnsignedByte();
/* 2780 */     if ((d & 0xC0) != 128) {
/* 2781 */       _reportInvalidOther(d & 0xFF);
/*      */     }
/* 2783 */     d = this._inputData.readUnsignedByte();
/* 2784 */     if ((d & 0xC0) != 128) {
/* 2785 */       _reportInvalidOther(d & 0xFF);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _reportInvalidToken(int ch, String matchedPart) throws IOException {
/* 2797 */     _reportInvalidToken(ch, matchedPart, _validJsonTokenList());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _reportInvalidToken(int ch, String matchedPart, String msg) throws IOException {
/* 2803 */     StringBuilder sb = new StringBuilder(matchedPart);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/* 2810 */       char c = (char)_decodeCharForError(ch);
/* 2811 */       if (!Character.isJavaIdentifierPart(c)) {
/*      */         break;
/*      */       }
/* 2814 */       sb.append(c);
/* 2815 */       ch = this._inputData.readUnsignedByte();
/*      */     } 
/* 2817 */     _reportError("Unrecognized token '" + sb.toString() + "': was expecting " + msg);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _reportInvalidChar(int c) throws JsonParseException {
/* 2824 */     if (c < 32) {
/* 2825 */       _throwInvalidSpace(c);
/*      */     }
/* 2827 */     _reportInvalidInitial(c);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _reportInvalidInitial(int mask) throws JsonParseException {
/* 2833 */     _reportError("Invalid UTF-8 start byte 0x" + Integer.toHexString(mask));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void _reportInvalidOther(int mask) throws JsonParseException {
/* 2839 */     _reportError("Invalid UTF-8 middle byte 0x" + Integer.toHexString(mask));
/*      */   }
/*      */ 
/*      */   
/*      */   private static int[] _growArrayBy(int[] arr, int more) {
/* 2844 */     if (arr == null) {
/* 2845 */       return new int[more];
/*      */     }
/* 2847 */     return Arrays.copyOf(arr, arr.length + more);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final byte[] _decodeBase64(Base64Variant b64variant) throws IOException {
/* 2870 */     ByteArrayBuilder builder = _getByteArrayBuilder();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/* 2877 */       int ch = this._inputData.readUnsignedByte();
/* 2878 */       if (ch > 32) {
/* 2879 */         int bits = b64variant.decodeBase64Char(ch);
/* 2880 */         if (bits < 0) {
/* 2881 */           if (ch == 34) {
/* 2882 */             return builder.toByteArray();
/*      */           }
/* 2884 */           bits = _decodeBase64Escape(b64variant, ch, 0);
/* 2885 */           if (bits < 0) {
/*      */             continue;
/*      */           }
/*      */         } 
/* 2889 */         int decodedData = bits;
/*      */ 
/*      */         
/* 2892 */         ch = this._inputData.readUnsignedByte();
/* 2893 */         bits = b64variant.decodeBase64Char(ch);
/* 2894 */         if (bits < 0) {
/* 2895 */           bits = _decodeBase64Escape(b64variant, ch, 1);
/*      */         }
/* 2897 */         decodedData = decodedData << 6 | bits;
/*      */         
/* 2899 */         ch = this._inputData.readUnsignedByte();
/* 2900 */         bits = b64variant.decodeBase64Char(ch);
/*      */ 
/*      */         
/* 2903 */         if (bits < 0) {
/* 2904 */           if (bits != -2) {
/*      */             
/* 2906 */             if (ch == 34) {
/* 2907 */               decodedData >>= 4;
/* 2908 */               builder.append(decodedData);
/* 2909 */               if (b64variant.usesPadding()) {
/* 2910 */                 _handleBase64MissingPadding(b64variant);
/*      */               }
/* 2912 */               return builder.toByteArray();
/*      */             } 
/* 2914 */             bits = _decodeBase64Escape(b64variant, ch, 2);
/*      */           } 
/* 2916 */           if (bits == -2) {
/* 2917 */             ch = this._inputData.readUnsignedByte();
/* 2918 */             if (!b64variant.usesPaddingChar(ch) && (
/* 2919 */               ch != 92 || 
/* 2920 */               _decodeBase64Escape(b64variant, ch, 3) != -2)) {
/* 2921 */               throw reportInvalidBase64Char(b64variant, ch, 3, "expected padding character '" + b64variant.getPaddingChar() + "'");
/*      */             }
/*      */ 
/*      */             
/* 2925 */             decodedData >>= 4;
/* 2926 */             builder.append(decodedData);
/*      */             
/*      */             continue;
/*      */           } 
/*      */         } 
/* 2931 */         decodedData = decodedData << 6 | bits;
/*      */         
/* 2933 */         ch = this._inputData.readUnsignedByte();
/* 2934 */         bits = b64variant.decodeBase64Char(ch);
/* 2935 */         if (bits < 0) {
/* 2936 */           if (bits != -2) {
/*      */             
/* 2938 */             if (ch == 34) {
/* 2939 */               decodedData >>= 2;
/* 2940 */               builder.appendTwoBytes(decodedData);
/* 2941 */               if (b64variant.usesPadding()) {
/* 2942 */                 _handleBase64MissingPadding(b64variant);
/*      */               }
/* 2944 */               return builder.toByteArray();
/*      */             } 
/* 2946 */             bits = _decodeBase64Escape(b64variant, ch, 3);
/*      */           } 
/* 2948 */           if (bits == -2) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 2955 */             decodedData >>= 2;
/* 2956 */             builder.appendTwoBytes(decodedData);
/*      */             
/*      */             continue;
/*      */           } 
/*      */         } 
/* 2961 */         decodedData = decodedData << 6 | bits;
/* 2962 */         builder.appendThreeBytes(decodedData);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonLocation getTokenLocation() {
/* 2984 */     return new JsonLocation(_contentReference(), -1L, -1L, this._tokenInputRow, -1);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonLocation getCurrentLocation() {
/* 2990 */     int col = -1;
/* 2991 */     return new JsonLocation(_contentReference(), -1L, -1L, this._currInputRow, -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void _closeScope(int i) throws JsonParseException {
/* 3002 */     if (i == 93) {
/* 3003 */       if (!this._parsingContext.inArray()) {
/* 3004 */         _reportMismatchedEndMarker(i, '}');
/*      */       }
/* 3006 */       this._parsingContext = this._parsingContext.clearAndGetParent();
/* 3007 */       this._currToken = JsonToken.END_ARRAY;
/*      */     } 
/* 3009 */     if (i == 125) {
/* 3010 */       if (!this._parsingContext.inObject()) {
/* 3011 */         _reportMismatchedEndMarker(i, ']');
/*      */       }
/* 3013 */       this._parsingContext = this._parsingContext.clearAndGetParent();
/* 3014 */       this._currToken = JsonToken.END_OBJECT;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int pad(int q, int bytes) {
/* 3022 */     return (bytes == 4) ? q : (q | -1 << bytes << 3);
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-core-2.14.2.jar!\com\fasterxml\jackson\core\json\UTF8DataInputJsonParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */