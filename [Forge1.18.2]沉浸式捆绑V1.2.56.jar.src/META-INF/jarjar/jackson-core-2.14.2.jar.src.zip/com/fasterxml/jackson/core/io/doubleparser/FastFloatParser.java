/*     */ package com.fasterxml.jackson.core.io.doubleparser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FastFloatParser
/*     */ {
/*  18 */   private static final FloatBitsFromCharArray CHAR_ARRAY_PARSER = new FloatBitsFromCharArray();
/*  19 */   private static final FloatBitsFromCharSequence CHAR_SEQ_PARSER = new FloatBitsFromCharSequence();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static float parseFloat(CharSequence str) throws NumberFormatException {
/*  36 */     return parseFloat(str, 0, str.length());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static float parseFloat(CharSequence str, int offset, int length) throws NumberFormatException {
/*  52 */     long bitPattern = CHAR_SEQ_PARSER.parseFloatingPointLiteral(str, offset, length);
/*  53 */     if (bitPattern == -1L) {
/*  54 */       throw new NumberFormatException("Illegal input");
/*     */     }
/*  56 */     return Float.intBitsToFloat((int)bitPattern);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static float parseFloat(char[] str) throws NumberFormatException {
/*  67 */     return parseFloat(str, 0, str.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static float parseFloat(char[] str, int offset, int length) throws NumberFormatException {
/*  84 */     long bitPattern = CHAR_ARRAY_PARSER.parseFloatingPointLiteral(str, offset, length);
/*  85 */     if (bitPattern == -1L) {
/*  86 */       throw new NumberFormatException("Illegal input");
/*     */     }
/*  88 */     return Float.intBitsToFloat((int)bitPattern);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long parseFloatBits(CharSequence str, int offset, int length) {
/* 114 */     return CHAR_SEQ_PARSER.parseFloatingPointLiteral(str, offset, length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long parseFloatBits(char[] str, int offset, int length) {
/* 133 */     return CHAR_ARRAY_PARSER.parseFloatingPointLiteral(str, offset, length);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-core-2.14.2.jar!\com\fasterxml\jackson\core\io\doubleparser\FastFloatParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */