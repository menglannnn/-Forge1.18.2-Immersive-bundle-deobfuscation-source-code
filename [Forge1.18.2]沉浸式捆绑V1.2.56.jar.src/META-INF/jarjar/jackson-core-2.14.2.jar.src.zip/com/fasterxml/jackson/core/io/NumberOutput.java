/*     */ package com.fasterxml.jackson.core.io;
/*     */ 
/*     */ import com.fasterxml.jackson.core.io.schubfach.DoubleToDecimal;
/*     */ import com.fasterxml.jackson.core.io.schubfach.FloatToDecimal;
/*     */ 
/*     */ public final class NumberOutput
/*     */ {
/*   8 */   private static int MILLION = 1000000;
/*   9 */   private static int BILLION = 1000000000;
/*  10 */   private static long BILLION_L = 1000000000L;
/*     */   
/*  12 */   private static long MIN_INT_AS_LONG = -2147483648L;
/*  13 */   private static long MAX_INT_AS_LONG = 2147483647L;
/*     */   
/*  15 */   static final String SMALLEST_INT = String.valueOf(-2147483648);
/*  16 */   static final String SMALLEST_LONG = String.valueOf(Long.MIN_VALUE);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  24 */   private static final int[] TRIPLET_TO_CHARS = new int[1000];
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  29 */     int fullIx = 0;
/*  30 */     for (int i1 = 0; i1 < 10; i1++) {
/*  31 */       for (int i2 = 0; i2 < 10; i2++) {
/*  32 */         for (int i3 = 0; i3 < 10; i3++) {
/*  33 */           int enc = i1 + 48 << 16 | i2 + 48 << 8 | i3 + 48;
/*     */ 
/*     */           
/*  36 */           TRIPLET_TO_CHARS[fullIx++] = enc;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*  42 */   private static final String[] sSmallIntStrs = new String[] { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10" };
/*     */ 
/*     */   
/*  45 */   private static final String[] sSmallIntStrs2 = new String[] { "-1", "-2", "-3", "-4", "-5", "-6", "-7", "-8", "-9", "-10" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int outputInt(int v, char[] b, int off) {
/*  70 */     if (v < 0) {
/*  71 */       if (v == Integer.MIN_VALUE)
/*     */       {
/*     */         
/*  74 */         return _outputSmallestI(b, off);
/*     */       }
/*  76 */       b[off++] = '-';
/*  77 */       v = -v;
/*     */     } 
/*     */     
/*  80 */     if (v < MILLION) {
/*  81 */       if (v < 1000) {
/*  82 */         if (v < 10) {
/*  83 */           b[off] = (char)(48 + v);
/*  84 */           return off + 1;
/*     */         } 
/*  86 */         return _leading3(v, b, off);
/*     */       } 
/*  88 */       int i = v / 1000;
/*  89 */       v -= i * 1000;
/*  90 */       off = _leading3(i, b, off);
/*  91 */       off = _full3(v, b, off);
/*  92 */       return off;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 100 */     if (v >= BILLION) {
/* 101 */       v -= BILLION;
/* 102 */       if (v >= BILLION) {
/* 103 */         v -= BILLION;
/* 104 */         b[off++] = '2';
/*     */       } else {
/* 106 */         b[off++] = '1';
/*     */       } 
/* 108 */       return _outputFullBillion(v, b, off);
/*     */     } 
/* 110 */     int newValue = v / 1000;
/* 111 */     int ones = v - newValue * 1000;
/* 112 */     v = newValue;
/* 113 */     newValue /= 1000;
/* 114 */     int thousands = v - newValue * 1000;
/*     */     
/* 116 */     off = _leading3(newValue, b, off);
/* 117 */     off = _full3(thousands, b, off);
/* 118 */     return _full3(ones, b, off);
/*     */   }
/*     */ 
/*     */   
/*     */   public static int outputInt(int v, byte[] b, int off) {
/* 123 */     if (v < 0) {
/* 124 */       if (v == Integer.MIN_VALUE) {
/* 125 */         return _outputSmallestI(b, off);
/*     */       }
/* 127 */       b[off++] = 45;
/* 128 */       v = -v;
/*     */     } 
/*     */     
/* 131 */     if (v < MILLION) {
/* 132 */       if (v < 1000) {
/* 133 */         if (v < 10) {
/* 134 */           b[off++] = (byte)(48 + v);
/*     */         } else {
/* 136 */           off = _leading3(v, b, off);
/*     */         } 
/*     */       } else {
/* 139 */         int i = v / 1000;
/* 140 */         v -= i * 1000;
/* 141 */         off = _leading3(i, b, off);
/* 142 */         off = _full3(v, b, off);
/*     */       } 
/* 144 */       return off;
/*     */     } 
/* 146 */     if (v >= BILLION) {
/* 147 */       v -= BILLION;
/* 148 */       if (v >= BILLION) {
/* 149 */         v -= BILLION;
/* 150 */         b[off++] = 50;
/*     */       } else {
/* 152 */         b[off++] = 49;
/*     */       } 
/* 154 */       return _outputFullBillion(v, b, off);
/*     */     } 
/* 156 */     int newValue = v / 1000;
/* 157 */     int ones = v - newValue * 1000;
/* 158 */     v = newValue;
/* 159 */     newValue /= 1000;
/* 160 */     int thousands = v - newValue * 1000;
/* 161 */     off = _leading3(newValue, b, off);
/* 162 */     off = _full3(thousands, b, off);
/* 163 */     return _full3(ones, b, off);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int outputLong(long v, char[] b, int off) {
/* 182 */     if (v < 0L) {
/* 183 */       if (v > MIN_INT_AS_LONG) {
/* 184 */         return outputInt((int)v, b, off);
/*     */       }
/* 186 */       if (v == Long.MIN_VALUE) {
/* 187 */         return _outputSmallestL(b, off);
/*     */       }
/* 189 */       b[off++] = '-';
/* 190 */       v = -v;
/*     */     }
/* 192 */     else if (v <= MAX_INT_AS_LONG) {
/* 193 */       return outputInt((int)v, b, off);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 198 */     long upper = v / BILLION_L;
/* 199 */     v -= upper * BILLION_L;
/*     */ 
/*     */     
/* 202 */     if (upper < BILLION_L) {
/* 203 */       off = _outputUptoBillion((int)upper, b, off);
/*     */     } else {
/*     */       
/* 206 */       long hi = upper / BILLION_L;
/* 207 */       upper -= hi * BILLION_L;
/* 208 */       off = _leading3((int)hi, b, off);
/* 209 */       off = _outputFullBillion((int)upper, b, off);
/*     */     } 
/* 211 */     return _outputFullBillion((int)v, b, off);
/*     */   }
/*     */ 
/*     */   
/*     */   public static int outputLong(long v, byte[] b, int off) {
/* 216 */     if (v < 0L) {
/* 217 */       if (v > MIN_INT_AS_LONG) {
/* 218 */         return outputInt((int)v, b, off);
/*     */       }
/* 220 */       if (v == Long.MIN_VALUE) {
/* 221 */         return _outputSmallestL(b, off);
/*     */       }
/* 223 */       b[off++] = 45;
/* 224 */       v = -v;
/*     */     }
/* 226 */     else if (v <= MAX_INT_AS_LONG) {
/* 227 */       return outputInt((int)v, b, off);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 232 */     long upper = v / BILLION_L;
/* 233 */     v -= upper * BILLION_L;
/*     */ 
/*     */     
/* 236 */     if (upper < BILLION_L) {
/* 237 */       off = _outputUptoBillion((int)upper, b, off);
/*     */     } else {
/*     */       
/* 240 */       long hi = upper / BILLION_L;
/* 241 */       upper -= hi * BILLION_L;
/* 242 */       off = _leading3((int)hi, b, off);
/* 243 */       off = _outputFullBillion((int)upper, b, off);
/*     */     } 
/* 245 */     return _outputFullBillion((int)v, b, off);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toString(int v) {
/* 260 */     if (v < sSmallIntStrs.length) {
/* 261 */       if (v >= 0) {
/* 262 */         return sSmallIntStrs[v];
/*     */       }
/* 264 */       int v2 = -v - 1;
/* 265 */       if (v2 < sSmallIntStrs2.length) {
/* 266 */         return sSmallIntStrs2[v2];
/*     */       }
/*     */     } 
/* 269 */     return Integer.toString(v);
/*     */   }
/*     */   
/*     */   public static String toString(long v) {
/* 273 */     if (v <= 2147483647L && v >= -2147483648L) {
/* 274 */       return toString((int)v);
/*     */     }
/* 276 */     return Long.toString(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toString(double v) {
/* 284 */     return toString(v, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toString(double v, boolean useFastWriter) {
/* 294 */     return useFastWriter ? DoubleToDecimal.toString(v) : Double.toString(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toString(float v) {
/* 303 */     return toString(v, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toString(float v, boolean useFastWriter) {
/* 313 */     return useFastWriter ? FloatToDecimal.toString(v) : Float.toString(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean notFinite(double value) {
/* 334 */     return (Double.isNaN(value) || Double.isInfinite(value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean notFinite(float value) {
/* 349 */     return (Float.isNaN(value) || Float.isInfinite(value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int _outputUptoBillion(int v, char[] b, int off) {
/* 360 */     if (v < MILLION) {
/* 361 */       if (v < 1000) {
/* 362 */         return _leading3(v, b, off);
/*     */       }
/* 364 */       int i = v / 1000;
/* 365 */       int j = v - i * 1000;
/* 366 */       return _outputUptoMillion(b, off, i, j);
/*     */     } 
/* 368 */     int thousands = v / 1000;
/* 369 */     int ones = v - thousands * 1000;
/* 370 */     int millions = thousands / 1000;
/* 371 */     thousands -= millions * 1000;
/*     */     
/* 373 */     off = _leading3(millions, b, off);
/*     */     
/* 375 */     int enc = TRIPLET_TO_CHARS[thousands];
/* 376 */     b[off++] = (char)(enc >> 16);
/* 377 */     b[off++] = (char)(enc >> 8 & 0x7F);
/* 378 */     b[off++] = (char)(enc & 0x7F);
/*     */     
/* 380 */     enc = TRIPLET_TO_CHARS[ones];
/* 381 */     b[off++] = (char)(enc >> 16);
/* 382 */     b[off++] = (char)(enc >> 8 & 0x7F);
/* 383 */     b[off++] = (char)(enc & 0x7F);
/*     */     
/* 385 */     return off;
/*     */   }
/*     */ 
/*     */   
/*     */   private static int _outputFullBillion(int v, char[] b, int off) {
/* 390 */     int thousands = v / 1000;
/* 391 */     int ones = v - thousands * 1000;
/* 392 */     int millions = thousands / 1000;
/*     */     
/* 394 */     int enc = TRIPLET_TO_CHARS[millions];
/* 395 */     b[off++] = (char)(enc >> 16);
/* 396 */     b[off++] = (char)(enc >> 8 & 0x7F);
/* 397 */     b[off++] = (char)(enc & 0x7F);
/*     */     
/* 399 */     thousands -= millions * 1000;
/* 400 */     enc = TRIPLET_TO_CHARS[thousands];
/* 401 */     b[off++] = (char)(enc >> 16);
/* 402 */     b[off++] = (char)(enc >> 8 & 0x7F);
/* 403 */     b[off++] = (char)(enc & 0x7F);
/*     */     
/* 405 */     enc = TRIPLET_TO_CHARS[ones];
/* 406 */     b[off++] = (char)(enc >> 16);
/* 407 */     b[off++] = (char)(enc >> 8 & 0x7F);
/* 408 */     b[off++] = (char)(enc & 0x7F);
/*     */     
/* 410 */     return off;
/*     */   }
/*     */ 
/*     */   
/*     */   private static int _outputUptoBillion(int v, byte[] b, int off) {
/* 415 */     if (v < MILLION) {
/* 416 */       if (v < 1000) {
/* 417 */         return _leading3(v, b, off);
/*     */       }
/* 419 */       int i = v / 1000;
/* 420 */       int j = v - i * 1000;
/* 421 */       return _outputUptoMillion(b, off, i, j);
/*     */     } 
/* 423 */     int thousands = v / 1000;
/* 424 */     int ones = v - thousands * 1000;
/* 425 */     int millions = thousands / 1000;
/* 426 */     thousands -= millions * 1000;
/*     */     
/* 428 */     off = _leading3(millions, b, off);
/*     */     
/* 430 */     int enc = TRIPLET_TO_CHARS[thousands];
/* 431 */     b[off++] = (byte)(enc >> 16);
/* 432 */     b[off++] = (byte)(enc >> 8);
/* 433 */     b[off++] = (byte)enc;
/*     */     
/* 435 */     enc = TRIPLET_TO_CHARS[ones];
/* 436 */     b[off++] = (byte)(enc >> 16);
/* 437 */     b[off++] = (byte)(enc >> 8);
/* 438 */     b[off++] = (byte)enc;
/*     */     
/* 440 */     return off;
/*     */   }
/*     */ 
/*     */   
/*     */   private static int _outputFullBillion(int v, byte[] b, int off) {
/* 445 */     int thousands = v / 1000;
/* 446 */     int ones = v - thousands * 1000;
/* 447 */     int millions = thousands / 1000;
/* 448 */     thousands -= millions * 1000;
/*     */     
/* 450 */     int enc = TRIPLET_TO_CHARS[millions];
/* 451 */     b[off++] = (byte)(enc >> 16);
/* 452 */     b[off++] = (byte)(enc >> 8);
/* 453 */     b[off++] = (byte)enc;
/*     */     
/* 455 */     enc = TRIPLET_TO_CHARS[thousands];
/* 456 */     b[off++] = (byte)(enc >> 16);
/* 457 */     b[off++] = (byte)(enc >> 8);
/* 458 */     b[off++] = (byte)enc;
/*     */     
/* 460 */     enc = TRIPLET_TO_CHARS[ones];
/* 461 */     b[off++] = (byte)(enc >> 16);
/* 462 */     b[off++] = (byte)(enc >> 8);
/* 463 */     b[off++] = (byte)enc;
/*     */     
/* 465 */     return off;
/*     */   }
/*     */ 
/*     */   
/*     */   private static int _outputUptoMillion(char[] b, int off, int thousands, int ones) {
/* 470 */     int enc = TRIPLET_TO_CHARS[thousands];
/* 471 */     if (thousands > 9) {
/* 472 */       if (thousands > 99) {
/* 473 */         b[off++] = (char)(enc >> 16);
/*     */       }
/* 475 */       b[off++] = (char)(enc >> 8 & 0x7F);
/*     */     } 
/* 477 */     b[off++] = (char)(enc & 0x7F);
/*     */     
/* 479 */     enc = TRIPLET_TO_CHARS[ones];
/* 480 */     b[off++] = (char)(enc >> 16);
/* 481 */     b[off++] = (char)(enc >> 8 & 0x7F);
/* 482 */     b[off++] = (char)(enc & 0x7F);
/* 483 */     return off;
/*     */   }
/*     */ 
/*     */   
/*     */   private static int _outputUptoMillion(byte[] b, int off, int thousands, int ones) {
/* 488 */     int enc = TRIPLET_TO_CHARS[thousands];
/* 489 */     if (thousands > 9) {
/* 490 */       if (thousands > 99) {
/* 491 */         b[off++] = (byte)(enc >> 16);
/*     */       }
/* 493 */       b[off++] = (byte)(enc >> 8);
/*     */     } 
/* 495 */     b[off++] = (byte)enc;
/*     */     
/* 497 */     enc = TRIPLET_TO_CHARS[ones];
/* 498 */     b[off++] = (byte)(enc >> 16);
/* 499 */     b[off++] = (byte)(enc >> 8);
/* 500 */     b[off++] = (byte)enc;
/* 501 */     return off;
/*     */   }
/*     */ 
/*     */   
/*     */   private static int _leading3(int t, char[] b, int off) {
/* 506 */     int enc = TRIPLET_TO_CHARS[t];
/* 507 */     if (t > 9) {
/* 508 */       if (t > 99) {
/* 509 */         b[off++] = (char)(enc >> 16);
/*     */       }
/* 511 */       b[off++] = (char)(enc >> 8 & 0x7F);
/*     */     } 
/* 513 */     b[off++] = (char)(enc & 0x7F);
/* 514 */     return off;
/*     */   }
/*     */ 
/*     */   
/*     */   private static int _leading3(int t, byte[] b, int off) {
/* 519 */     int enc = TRIPLET_TO_CHARS[t];
/* 520 */     if (t > 9) {
/* 521 */       if (t > 99) {
/* 522 */         b[off++] = (byte)(enc >> 16);
/*     */       }
/* 524 */       b[off++] = (byte)(enc >> 8);
/*     */     } 
/* 526 */     b[off++] = (byte)enc;
/* 527 */     return off;
/*     */   }
/*     */ 
/*     */   
/*     */   private static int _full3(int t, char[] b, int off) {
/* 532 */     int enc = TRIPLET_TO_CHARS[t];
/* 533 */     b[off++] = (char)(enc >> 16);
/* 534 */     b[off++] = (char)(enc >> 8 & 0x7F);
/* 535 */     b[off++] = (char)(enc & 0x7F);
/* 536 */     return off;
/*     */   }
/*     */ 
/*     */   
/*     */   private static int _full3(int t, byte[] b, int off) {
/* 541 */     int enc = TRIPLET_TO_CHARS[t];
/* 542 */     b[off++] = (byte)(enc >> 16);
/* 543 */     b[off++] = (byte)(enc >> 8);
/* 544 */     b[off++] = (byte)enc;
/* 545 */     return off;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int _outputSmallestL(char[] b, int off) {
/* 552 */     int len = SMALLEST_LONG.length();
/* 553 */     SMALLEST_LONG.getChars(0, len, b, off);
/* 554 */     return off + len;
/*     */   }
/*     */ 
/*     */   
/*     */   private static int _outputSmallestL(byte[] b, int off) {
/* 559 */     int len = SMALLEST_LONG.length();
/* 560 */     for (int i = 0; i < len; i++) {
/* 561 */       b[off++] = (byte)SMALLEST_LONG.charAt(i);
/*     */     }
/* 563 */     return off;
/*     */   }
/*     */ 
/*     */   
/*     */   private static int _outputSmallestI(char[] b, int off) {
/* 568 */     int len = SMALLEST_INT.length();
/* 569 */     SMALLEST_INT.getChars(0, len, b, off);
/* 570 */     return off + len;
/*     */   }
/*     */ 
/*     */   
/*     */   private static int _outputSmallestI(byte[] b, int off) {
/* 575 */     int len = SMALLEST_INT.length();
/* 576 */     for (int i = 0; i < len; i++) {
/* 577 */       b[off++] = (byte)SMALLEST_INT.charAt(i);
/*     */     }
/* 579 */     return off;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-core-2.14.2.jar!\com\fasterxml\jackson\core\io\NumberOutput.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */