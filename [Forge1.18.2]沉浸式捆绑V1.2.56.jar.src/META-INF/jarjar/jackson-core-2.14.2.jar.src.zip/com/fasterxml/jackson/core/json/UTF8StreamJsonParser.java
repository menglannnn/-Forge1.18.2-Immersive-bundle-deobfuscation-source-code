/*      */ package com.fasterxml.jackson.core.json;
/*      */ 
/*      */ import com.fasterxml.jackson.core.Base64Variant;
/*      */ import com.fasterxml.jackson.core.JsonLocation;
/*      */ import com.fasterxml.jackson.core.JsonParseException;
/*      */ import com.fasterxml.jackson.core.JsonParser;
/*      */ import com.fasterxml.jackson.core.JsonToken;
/*      */ import com.fasterxml.jackson.core.ObjectCodec;
/*      */ import com.fasterxml.jackson.core.SerializableString;
/*      */ import com.fasterxml.jackson.core.StreamReadCapability;
/*      */ import com.fasterxml.jackson.core.base.ParserBase;
/*      */ import com.fasterxml.jackson.core.io.CharTypes;
/*      */ import com.fasterxml.jackson.core.io.IOContext;
/*      */ import com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer;
/*      */ import com.fasterxml.jackson.core.util.ByteArrayBuilder;
/*      */ import com.fasterxml.jackson.core.util.JacksonFeatureSet;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.Writer;
/*      */ 
/*      */ public class UTF8StreamJsonParser extends ParserBase {
/*      */   static final byte BYTE_LF = 10;
/*   24 */   private static final int FEAT_MASK_TRAILING_COMMA = JsonParser.Feature.ALLOW_TRAILING_COMMA.getMask();
/*      */   
/*   26 */   private static final int FEAT_MASK_LEADING_ZEROS = JsonParser.Feature.ALLOW_NUMERIC_LEADING_ZEROS.getMask();
/*      */   
/*   28 */   private static final int FEAT_MASK_NON_NUM_NUMBERS = JsonParser.Feature.ALLOW_NON_NUMERIC_NUMBERS.getMask();
/*      */   
/*   30 */   private static final int FEAT_MASK_ALLOW_MISSING = JsonParser.Feature.ALLOW_MISSING_VALUES.getMask();
/*   31 */   private static final int FEAT_MASK_ALLOW_SINGLE_QUOTES = JsonParser.Feature.ALLOW_SINGLE_QUOTES.getMask();
/*   32 */   private static final int FEAT_MASK_ALLOW_UNQUOTED_NAMES = JsonParser.Feature.ALLOW_UNQUOTED_FIELD_NAMES.getMask();
/*   33 */   private static final int FEAT_MASK_ALLOW_JAVA_COMMENTS = JsonParser.Feature.ALLOW_COMMENTS.getMask();
/*   34 */   private static final int FEAT_MASK_ALLOW_YAML_COMMENTS = JsonParser.Feature.ALLOW_YAML_COMMENTS.getMask();
/*      */ 
/*      */   
/*   37 */   private static final int[] _icUTF8 = CharTypes.getInputCodeUtf8();
/*      */ 
/*      */ 
/*      */   
/*   41 */   protected static final int[] _icLatin1 = CharTypes.getInputCodeLatin1();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ObjectCodec _objectCodec;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final ByteQuadsCanonicalizer _symbols;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   70 */   protected int[] _quadBuffer = new int[16];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _tokenIncomplete;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int _quad1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _nameStartOffset;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _nameStartRow;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _nameStartCol;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected InputStream _inputStream;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected byte[] _inputBuffer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _bufferRecyclable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public UTF8StreamJsonParser(IOContext ctxt, int features, InputStream in, ObjectCodec codec, ByteQuadsCanonicalizer sym, byte[] inputBuffer, int start, int end, boolean bufferRecyclable) {
/*  164 */     this(ctxt, features, in, codec, sym, inputBuffer, start, end, 0, bufferRecyclable);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public UTF8StreamJsonParser(IOContext ctxt, int features, InputStream in, ObjectCodec codec, ByteQuadsCanonicalizer sym, byte[] inputBuffer, int start, int end, int bytesPreProcessed, boolean bufferRecyclable) {
/*  190 */     super(ctxt, features);
/*  191 */     this._inputStream = in;
/*  192 */     this._objectCodec = codec;
/*  193 */     this._symbols = sym;
/*  194 */     this._inputBuffer = inputBuffer;
/*  195 */     this._inputPtr = start;
/*  196 */     this._inputEnd = end;
/*  197 */     this._currInputRowStart = start - bytesPreProcessed;
/*      */     
/*  199 */     this._currInputProcessed = (-start + bytesPreProcessed);
/*  200 */     this._bufferRecyclable = bufferRecyclable;
/*      */   }
/*      */ 
/*      */   
/*      */   public ObjectCodec getCodec() {
/*  205 */     return this._objectCodec;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setCodec(ObjectCodec c) {
/*  210 */     this._objectCodec = c;
/*      */   }
/*      */ 
/*      */   
/*      */   public JacksonFeatureSet<StreamReadCapability> getReadCapabilities() {
/*  215 */     return JSON_READ_CAPABILITIES;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int releaseBuffered(OutputStream out) throws IOException {
/*  227 */     int count = this._inputEnd - this._inputPtr;
/*  228 */     if (count < 1) {
/*  229 */       return 0;
/*      */     }
/*      */     
/*  232 */     int origPtr = this._inputPtr;
/*  233 */     this._inputPtr += count;
/*  234 */     out.write(this._inputBuffer, origPtr, count);
/*  235 */     return count;
/*      */   }
/*      */ 
/*      */   
/*      */   public Object getInputSource() {
/*  240 */     return this._inputStream;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final boolean _loadMore() throws IOException {
/*  251 */     if (this._inputStream != null) {
/*  252 */       int space = this._inputBuffer.length;
/*  253 */       if (space == 0) {
/*  254 */         return false;
/*      */       }
/*      */       
/*  257 */       int count = this._inputStream.read(this._inputBuffer, 0, space);
/*  258 */       if (count > 0) {
/*  259 */         int bufSize = this._inputEnd;
/*      */         
/*  261 */         this._currInputProcessed += bufSize;
/*  262 */         this._currInputRowStart -= bufSize;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  267 */         this._nameStartOffset -= bufSize;
/*      */         
/*  269 */         this._inputPtr = 0;
/*  270 */         this._inputEnd = count;
/*      */         
/*  272 */         return true;
/*      */       } 
/*      */       
/*  275 */       _closeInput();
/*      */       
/*  277 */       if (count == 0) {
/*  278 */         throw new IOException("InputStream.read() returned 0 characters when trying to read " + this._inputBuffer.length + " bytes");
/*      */       }
/*      */     } 
/*  281 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _closeInput() throws IOException {
/*  289 */     if (this._inputStream != null) {
/*  290 */       if (this._ioContext.isResourceManaged() || isEnabled(JsonParser.Feature.AUTO_CLOSE_SOURCE)) {
/*  291 */         this._inputStream.close();
/*      */       }
/*  293 */       this._inputStream = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _releaseBuffers() throws IOException {
/*  306 */     super._releaseBuffers();
/*      */     
/*  308 */     this._symbols.release();
/*  309 */     if (this._bufferRecyclable) {
/*  310 */       byte[] buf = this._inputBuffer;
/*  311 */       if (buf != null)
/*      */       {
/*      */         
/*  314 */         if (buf != NO_BYTES) {
/*  315 */           this._inputBuffer = NO_BYTES;
/*  316 */           this._ioContext.releaseReadIOBuffer(buf);
/*      */         } 
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getText() throws IOException {
/*  331 */     if (this._currToken == JsonToken.VALUE_STRING) {
/*  332 */       if (this._tokenIncomplete) {
/*  333 */         this._tokenIncomplete = false;
/*  334 */         return _finishAndReturnString();
/*      */       } 
/*  336 */       return this._textBuffer.contentsAsString();
/*      */     } 
/*  338 */     return _getText2(this._currToken);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getText(Writer writer) throws IOException {
/*  344 */     JsonToken t = this._currToken;
/*  345 */     if (t == JsonToken.VALUE_STRING) {
/*  346 */       if (this._tokenIncomplete) {
/*  347 */         this._tokenIncomplete = false;
/*  348 */         _finishString();
/*      */       } 
/*  350 */       return this._textBuffer.contentsToWriter(writer);
/*      */     } 
/*  352 */     if (t == JsonToken.FIELD_NAME) {
/*  353 */       String n = this._parsingContext.getCurrentName();
/*  354 */       writer.write(n);
/*  355 */       return n.length();
/*      */     } 
/*  357 */     if (t != null) {
/*  358 */       if (t.isNumeric()) {
/*  359 */         return this._textBuffer.contentsToWriter(writer);
/*      */       }
/*  361 */       char[] ch = t.asCharArray();
/*  362 */       writer.write(ch);
/*  363 */       return ch.length;
/*      */     } 
/*  365 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getValueAsString() throws IOException {
/*  374 */     if (this._currToken == JsonToken.VALUE_STRING) {
/*  375 */       if (this._tokenIncomplete) {
/*  376 */         this._tokenIncomplete = false;
/*  377 */         return _finishAndReturnString();
/*      */       } 
/*  379 */       return this._textBuffer.contentsAsString();
/*      */     } 
/*  381 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  382 */       return getCurrentName();
/*      */     }
/*  384 */     return super.getValueAsString(null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getValueAsString(String defValue) throws IOException {
/*  391 */     if (this._currToken == JsonToken.VALUE_STRING) {
/*  392 */       if (this._tokenIncomplete) {
/*  393 */         this._tokenIncomplete = false;
/*  394 */         return _finishAndReturnString();
/*      */       } 
/*  396 */       return this._textBuffer.contentsAsString();
/*      */     } 
/*  398 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  399 */       return getCurrentName();
/*      */     }
/*  401 */     return super.getValueAsString(defValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getValueAsInt() throws IOException {
/*  408 */     JsonToken t = this._currToken;
/*  409 */     if (t == JsonToken.VALUE_NUMBER_INT || t == JsonToken.VALUE_NUMBER_FLOAT) {
/*      */       
/*  411 */       if ((this._numTypesValid & 0x1) == 0) {
/*  412 */         if (this._numTypesValid == 0) {
/*  413 */           return _parseIntValue();
/*      */         }
/*  415 */         if ((this._numTypesValid & 0x1) == 0) {
/*  416 */           convertNumberToInt();
/*      */         }
/*      */       } 
/*  419 */       return this._numberInt;
/*      */     } 
/*  421 */     return super.getValueAsInt(0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getValueAsInt(int defValue) throws IOException {
/*  428 */     JsonToken t = this._currToken;
/*  429 */     if (t == JsonToken.VALUE_NUMBER_INT || t == JsonToken.VALUE_NUMBER_FLOAT) {
/*      */       
/*  431 */       if ((this._numTypesValid & 0x1) == 0) {
/*  432 */         if (this._numTypesValid == 0) {
/*  433 */           return _parseIntValue();
/*      */         }
/*  435 */         if ((this._numTypesValid & 0x1) == 0) {
/*  436 */           convertNumberToInt();
/*      */         }
/*      */       } 
/*  439 */       return this._numberInt;
/*      */     } 
/*  441 */     return super.getValueAsInt(defValue);
/*      */   }
/*      */ 
/*      */   
/*      */   protected final String _getText2(JsonToken t) {
/*  446 */     if (t == null) {
/*  447 */       return null;
/*      */     }
/*  449 */     switch (t.id()) {
/*      */       case 5:
/*  451 */         return this._parsingContext.getCurrentName();
/*      */ 
/*      */       
/*      */       case 6:
/*      */       case 7:
/*      */       case 8:
/*  457 */         return this._textBuffer.contentsAsString();
/*      */     } 
/*  459 */     return t.asString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public char[] getTextCharacters() throws IOException {
/*  466 */     if (this._currToken != null) {
/*  467 */       switch (this._currToken.id()) {
/*      */         
/*      */         case 5:
/*  470 */           if (!this._nameCopied) {
/*  471 */             String name = this._parsingContext.getCurrentName();
/*  472 */             int nameLen = name.length();
/*  473 */             if (this._nameCopyBuffer == null) {
/*  474 */               this._nameCopyBuffer = this._ioContext.allocNameCopyBuffer(nameLen);
/*  475 */             } else if (this._nameCopyBuffer.length < nameLen) {
/*  476 */               this._nameCopyBuffer = new char[nameLen];
/*      */             } 
/*  478 */             name.getChars(0, nameLen, this._nameCopyBuffer, 0);
/*  479 */             this._nameCopied = true;
/*      */           } 
/*  481 */           return this._nameCopyBuffer;
/*      */         
/*      */         case 6:
/*  484 */           if (this._tokenIncomplete) {
/*  485 */             this._tokenIncomplete = false;
/*  486 */             _finishString();
/*      */           } 
/*      */         
/*      */         case 7:
/*      */         case 8:
/*  491 */           return this._textBuffer.getTextBuffer();
/*      */       } 
/*      */       
/*  494 */       return this._currToken.asCharArray();
/*      */     } 
/*      */     
/*  497 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getTextLength() throws IOException {
/*  503 */     if (this._currToken != null) {
/*  504 */       switch (this._currToken.id()) {
/*      */         
/*      */         case 5:
/*  507 */           return this._parsingContext.getCurrentName().length();
/*      */         case 6:
/*  509 */           if (this._tokenIncomplete) {
/*  510 */             this._tokenIncomplete = false;
/*  511 */             _finishString();
/*      */           } 
/*      */         
/*      */         case 7:
/*      */         case 8:
/*  516 */           return this._textBuffer.size();
/*      */       } 
/*      */       
/*  519 */       return (this._currToken.asCharArray()).length;
/*      */     } 
/*      */     
/*  522 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getTextOffset() throws IOException {
/*  529 */     if (this._currToken != null) {
/*  530 */       switch (this._currToken.id()) {
/*      */         case 5:
/*  532 */           return 0;
/*      */         case 6:
/*  534 */           if (this._tokenIncomplete) {
/*  535 */             this._tokenIncomplete = false;
/*  536 */             _finishString();
/*      */           } 
/*      */         
/*      */         case 7:
/*      */         case 8:
/*  541 */           return this._textBuffer.getTextOffset();
/*      */       } 
/*      */     
/*      */     }
/*  545 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] getBinaryValue(Base64Variant b64variant) throws IOException {
/*  551 */     if (this._currToken != JsonToken.VALUE_STRING && (this._currToken != JsonToken.VALUE_EMBEDDED_OBJECT || this._binaryValue == null))
/*      */     {
/*  553 */       _reportError("Current token (" + this._currToken + ") not VALUE_STRING or VALUE_EMBEDDED_OBJECT, can not access as binary");
/*      */     }
/*      */     
/*  556 */     if (this._tokenIncomplete) {
/*      */       try {
/*  558 */         this._binaryValue = _decodeBase64(b64variant);
/*  559 */       } catch (IllegalArgumentException iae) {
/*  560 */         throw _constructError("Failed to decode VALUE_STRING as base64 (" + b64variant + "): " + iae.getMessage());
/*      */       } 
/*      */       
/*  563 */       this._tokenIncomplete = false;
/*      */     }
/*  565 */     else if (this._binaryValue == null) {
/*      */       
/*  567 */       ByteArrayBuilder builder = _getByteArrayBuilder();
/*  568 */       _decodeBase64(getText(), builder, b64variant);
/*  569 */       this._binaryValue = builder.toByteArray();
/*      */     } 
/*      */     
/*  572 */     return this._binaryValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int readBinaryValue(Base64Variant b64variant, OutputStream out) throws IOException {
/*  579 */     if (!this._tokenIncomplete || this._currToken != JsonToken.VALUE_STRING) {
/*  580 */       byte[] b = getBinaryValue(b64variant);
/*  581 */       out.write(b);
/*  582 */       return b.length;
/*      */     } 
/*      */     
/*  585 */     byte[] buf = this._ioContext.allocBase64Buffer();
/*      */     try {
/*  587 */       return _readBinary(b64variant, out, buf);
/*      */     } finally {
/*  589 */       this._ioContext.releaseBase64Buffer(buf);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _readBinary(Base64Variant b64variant, OutputStream out, byte[] buffer) throws IOException {
/*  596 */     int outputPtr = 0;
/*  597 */     int outputEnd = buffer.length - 3;
/*  598 */     int outputCount = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/*  604 */       if (this._inputPtr >= this._inputEnd) {
/*  605 */         _loadMoreGuaranteed();
/*      */       }
/*  607 */       int ch = this._inputBuffer[this._inputPtr++] & 0xFF;
/*  608 */       if (ch > 32) {
/*  609 */         int bits = b64variant.decodeBase64Char(ch);
/*  610 */         if (bits < 0) {
/*  611 */           if (ch == 34) {
/*      */             break;
/*      */           }
/*  614 */           bits = _decodeBase64Escape(b64variant, ch, 0);
/*  615 */           if (bits < 0) {
/*      */             continue;
/*      */           }
/*      */         } 
/*      */ 
/*      */         
/*  621 */         if (outputPtr > outputEnd) {
/*  622 */           outputCount += outputPtr;
/*  623 */           out.write(buffer, 0, outputPtr);
/*  624 */           outputPtr = 0;
/*      */         } 
/*      */         
/*  627 */         int decodedData = bits;
/*      */ 
/*      */ 
/*      */         
/*  631 */         if (this._inputPtr >= this._inputEnd) {
/*  632 */           _loadMoreGuaranteed();
/*      */         }
/*  634 */         ch = this._inputBuffer[this._inputPtr++] & 0xFF;
/*  635 */         bits = b64variant.decodeBase64Char(ch);
/*  636 */         if (bits < 0) {
/*  637 */           bits = _decodeBase64Escape(b64variant, ch, 1);
/*      */         }
/*  639 */         decodedData = decodedData << 6 | bits;
/*      */ 
/*      */         
/*  642 */         if (this._inputPtr >= this._inputEnd) {
/*  643 */           _loadMoreGuaranteed();
/*      */         }
/*  645 */         ch = this._inputBuffer[this._inputPtr++] & 0xFF;
/*  646 */         bits = b64variant.decodeBase64Char(ch);
/*      */ 
/*      */         
/*  649 */         if (bits < 0) {
/*  650 */           if (bits != -2) {
/*      */             
/*  652 */             if (ch == 34) {
/*  653 */               decodedData >>= 4;
/*  654 */               buffer[outputPtr++] = (byte)decodedData;
/*  655 */               if (b64variant.usesPadding()) {
/*  656 */                 this._inputPtr--;
/*  657 */                 _handleBase64MissingPadding(b64variant);
/*      */               } 
/*      */               break;
/*      */             } 
/*  661 */             bits = _decodeBase64Escape(b64variant, ch, 2);
/*      */           } 
/*  663 */           if (bits == -2) {
/*      */             
/*  665 */             if (this._inputPtr >= this._inputEnd) {
/*  666 */               _loadMoreGuaranteed();
/*      */             }
/*  668 */             ch = this._inputBuffer[this._inputPtr++] & 0xFF;
/*  669 */             if (!b64variant.usesPaddingChar(ch) && 
/*  670 */               _decodeBase64Escape(b64variant, ch, 3) != -2) {
/*  671 */               throw reportInvalidBase64Char(b64variant, ch, 3, "expected padding character '" + b64variant.getPaddingChar() + "'");
/*      */             }
/*      */ 
/*      */             
/*  675 */             decodedData >>= 4;
/*  676 */             buffer[outputPtr++] = (byte)decodedData;
/*      */             
/*      */             continue;
/*      */           } 
/*      */         } 
/*  681 */         decodedData = decodedData << 6 | bits;
/*      */         
/*  683 */         if (this._inputPtr >= this._inputEnd) {
/*  684 */           _loadMoreGuaranteed();
/*      */         }
/*  686 */         ch = this._inputBuffer[this._inputPtr++] & 0xFF;
/*  687 */         bits = b64variant.decodeBase64Char(ch);
/*  688 */         if (bits < 0) {
/*  689 */           if (bits != -2) {
/*      */             
/*  691 */             if (ch == 34) {
/*  692 */               decodedData >>= 2;
/*  693 */               buffer[outputPtr++] = (byte)(decodedData >> 8);
/*  694 */               buffer[outputPtr++] = (byte)decodedData;
/*  695 */               if (b64variant.usesPadding()) {
/*  696 */                 this._inputPtr--;
/*  697 */                 _handleBase64MissingPadding(b64variant);
/*      */               } 
/*      */               break;
/*      */             } 
/*  701 */             bits = _decodeBase64Escape(b64variant, ch, 3);
/*      */           } 
/*  703 */           if (bits == -2) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  710 */             decodedData >>= 2;
/*  711 */             buffer[outputPtr++] = (byte)(decodedData >> 8);
/*  712 */             buffer[outputPtr++] = (byte)decodedData;
/*      */             
/*      */             continue;
/*      */           } 
/*      */         } 
/*  717 */         decodedData = decodedData << 6 | bits;
/*  718 */         buffer[outputPtr++] = (byte)(decodedData >> 16);
/*  719 */         buffer[outputPtr++] = (byte)(decodedData >> 8);
/*  720 */         buffer[outputPtr++] = (byte)decodedData;
/*      */       } 
/*  722 */     }  this._tokenIncomplete = false;
/*  723 */     if (outputPtr > 0) {
/*  724 */       outputCount += outputPtr;
/*  725 */       out.write(buffer, 0, outputPtr);
/*      */     } 
/*  727 */     return outputCount;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonToken nextToken() throws IOException {
/*  747 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  748 */       return _nextAfterName();
/*      */     }
/*      */ 
/*      */     
/*  752 */     this._numTypesValid = 0;
/*  753 */     if (this._tokenIncomplete) {
/*  754 */       _skipString();
/*      */     }
/*  756 */     int i = _skipWSOrEnd();
/*  757 */     if (i < 0) {
/*      */       
/*  759 */       close();
/*  760 */       return this._currToken = null;
/*      */     } 
/*      */     
/*  763 */     this._binaryValue = null;
/*      */ 
/*      */     
/*  766 */     if (i == 93) {
/*  767 */       _closeArrayScope();
/*  768 */       return this._currToken = JsonToken.END_ARRAY;
/*      */     } 
/*  770 */     if (i == 125) {
/*  771 */       _closeObjectScope();
/*  772 */       return this._currToken = JsonToken.END_OBJECT;
/*      */     } 
/*      */ 
/*      */     
/*  776 */     if (this._parsingContext.expectComma()) {
/*  777 */       if (i != 44) {
/*  778 */         _reportUnexpectedChar(i, "was expecting comma to separate " + this._parsingContext.typeDesc() + " entries");
/*      */       }
/*  780 */       i = _skipWS();
/*      */       
/*  782 */       if ((this._features & FEAT_MASK_TRAILING_COMMA) != 0 && (
/*  783 */         i == 93 || i == 125)) {
/*  784 */         return _closeScope(i);
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  791 */     if (!this._parsingContext.inObject()) {
/*  792 */       _updateLocation();
/*  793 */       return _nextTokenNotInObject(i);
/*      */     } 
/*      */     
/*  796 */     _updateNameLocation();
/*  797 */     String n = _parseName(i);
/*  798 */     this._parsingContext.setCurrentName(n);
/*  799 */     this._currToken = JsonToken.FIELD_NAME;
/*      */     
/*  801 */     i = _skipColon();
/*  802 */     _updateLocation();
/*      */ 
/*      */     
/*  805 */     if (i == 34) {
/*  806 */       this._tokenIncomplete = true;
/*  807 */       this._nextToken = JsonToken.VALUE_STRING;
/*  808 */       return this._currToken;
/*      */     } 
/*      */ 
/*      */     
/*  812 */     switch (i)
/*      */     { case 45:
/*  814 */         t = _parseSignedNumber(true);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  860 */         this._nextToken = t;
/*  861 */         return this._currToken;case 43: if (isEnabled(JsonReadFeature.ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS.mappedFeature())) { t = _parseSignedNumber(false); } else { t = _handleUnexpectedValue(i); }  this._nextToken = t; return this._currToken;case 46: t = _parseFloatThatStartsWithPeriod(false, false); this._nextToken = t; return this._currToken;case 48: case 49: case 50: case 51: case 52: case 53: case 54: case 55: case 56: case 57: t = _parseUnsignedNumber(i); this._nextToken = t; return this._currToken;case 102: _matchFalse(); t = JsonToken.VALUE_FALSE; this._nextToken = t; return this._currToken;case 110: _matchNull(); t = JsonToken.VALUE_NULL; this._nextToken = t; return this._currToken;case 116: _matchTrue(); t = JsonToken.VALUE_TRUE; this._nextToken = t; return this._currToken;case 91: t = JsonToken.START_ARRAY; this._nextToken = t; return this._currToken;case 123: t = JsonToken.START_OBJECT; this._nextToken = t; return this._currToken; }  JsonToken t = _handleUnexpectedValue(i); this._nextToken = t; return this._currToken;
/*      */   }
/*      */ 
/*      */   
/*      */   private final JsonToken _nextTokenNotInObject(int i) throws IOException {
/*  866 */     if (i == 34) {
/*  867 */       this._tokenIncomplete = true;
/*  868 */       return this._currToken = JsonToken.VALUE_STRING;
/*      */     } 
/*  870 */     switch (i) {
/*      */       case 91:
/*  872 */         this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/*  873 */         return this._currToken = JsonToken.START_ARRAY;
/*      */       case 123:
/*  875 */         this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*  876 */         return this._currToken = JsonToken.START_OBJECT;
/*      */       case 116:
/*  878 */         _matchTrue();
/*  879 */         return this._currToken = JsonToken.VALUE_TRUE;
/*      */       case 102:
/*  881 */         _matchFalse();
/*  882 */         return this._currToken = JsonToken.VALUE_FALSE;
/*      */       case 110:
/*  884 */         _matchNull();
/*  885 */         return this._currToken = JsonToken.VALUE_NULL;
/*      */       case 45:
/*  887 */         return this._currToken = _parseSignedNumber(true);
/*      */       case 43:
/*  889 */         if (!isEnabled(JsonReadFeature.ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS.mappedFeature())) {
/*  890 */           return this._currToken = _handleUnexpectedValue(i);
/*      */         }
/*  892 */         return this._currToken = _parseSignedNumber(false);
/*      */       case 46:
/*  894 */         return this._currToken = _parseFloatThatStartsWithPeriod(false, false);
/*      */       case 48:
/*      */       case 49:
/*      */       case 50:
/*      */       case 51:
/*      */       case 52:
/*      */       case 53:
/*      */       case 54:
/*      */       case 55:
/*      */       case 56:
/*      */       case 57:
/*  905 */         return this._currToken = _parseUnsignedNumber(i);
/*      */     } 
/*  907 */     return this._currToken = _handleUnexpectedValue(i);
/*      */   }
/*      */ 
/*      */   
/*      */   private final JsonToken _nextAfterName() {
/*  912 */     this._nameCopied = false;
/*  913 */     JsonToken t = this._nextToken;
/*  914 */     this._nextToken = null;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  919 */     if (t == JsonToken.START_ARRAY) {
/*  920 */       this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/*  921 */     } else if (t == JsonToken.START_OBJECT) {
/*  922 */       this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */     } 
/*  924 */     return this._currToken = t;
/*      */   }
/*      */ 
/*      */   
/*      */   public void finishToken() throws IOException {
/*  929 */     if (this._tokenIncomplete) {
/*  930 */       this._tokenIncomplete = false;
/*  931 */       _finishString();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean nextFieldName(SerializableString str) throws IOException {
/*  945 */     this._numTypesValid = 0;
/*  946 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  947 */       _nextAfterName();
/*  948 */       return false;
/*      */     } 
/*  950 */     if (this._tokenIncomplete) {
/*  951 */       _skipString();
/*      */     }
/*  953 */     int i = _skipWSOrEnd();
/*  954 */     if (i < 0) {
/*  955 */       close();
/*  956 */       this._currToken = null;
/*  957 */       return false;
/*      */     } 
/*  959 */     this._binaryValue = null;
/*      */ 
/*      */     
/*  962 */     if (i == 93) {
/*  963 */       _closeArrayScope();
/*  964 */       this._currToken = JsonToken.END_ARRAY;
/*  965 */       return false;
/*      */     } 
/*  967 */     if (i == 125) {
/*  968 */       _closeObjectScope();
/*  969 */       this._currToken = JsonToken.END_OBJECT;
/*  970 */       return false;
/*      */     } 
/*      */ 
/*      */     
/*  974 */     if (this._parsingContext.expectComma()) {
/*  975 */       if (i != 44) {
/*  976 */         _reportUnexpectedChar(i, "was expecting comma to separate " + this._parsingContext.typeDesc() + " entries");
/*      */       }
/*  978 */       i = _skipWS();
/*      */ 
/*      */       
/*  981 */       if ((this._features & FEAT_MASK_TRAILING_COMMA) != 0 && (
/*  982 */         i == 93 || i == 125)) {
/*  983 */         _closeScope(i);
/*  984 */         return false;
/*      */       } 
/*      */     } 
/*      */     
/*  988 */     if (!this._parsingContext.inObject()) {
/*  989 */       _updateLocation();
/*  990 */       _nextTokenNotInObject(i);
/*  991 */       return false;
/*      */     } 
/*      */ 
/*      */     
/*  995 */     _updateNameLocation();
/*  996 */     if (i == 34) {
/*      */       
/*  998 */       byte[] nameBytes = str.asQuotedUTF8();
/*  999 */       int len = nameBytes.length;
/*      */ 
/*      */       
/* 1002 */       if (this._inputPtr + len + 4 < this._inputEnd) {
/*      */         
/* 1004 */         int end = this._inputPtr + len;
/* 1005 */         if (this._inputBuffer[end] == 34) {
/* 1006 */           int offset = 0;
/* 1007 */           int ptr = this._inputPtr;
/*      */           while (true) {
/* 1009 */             if (ptr == end) {
/* 1010 */               this._parsingContext.setCurrentName(str.getValue());
/* 1011 */               i = _skipColonFast(ptr + 1);
/* 1012 */               _isNextTokenNameYes(i);
/* 1013 */               return true;
/*      */             } 
/* 1015 */             if (nameBytes[offset] != this._inputBuffer[ptr]) {
/*      */               break;
/*      */             }
/* 1018 */             offset++;
/* 1019 */             ptr++;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/* 1024 */     return _isNextTokenNameMaybe(i, str);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String nextFieldName() throws IOException {
/* 1031 */     this._numTypesValid = 0;
/* 1032 */     if (this._currToken == JsonToken.FIELD_NAME) {
/* 1033 */       _nextAfterName();
/* 1034 */       return null;
/*      */     } 
/* 1036 */     if (this._tokenIncomplete) {
/* 1037 */       _skipString();
/*      */     }
/* 1039 */     int i = _skipWSOrEnd();
/* 1040 */     if (i < 0) {
/* 1041 */       close();
/* 1042 */       this._currToken = null;
/* 1043 */       return null;
/*      */     } 
/* 1045 */     this._binaryValue = null;
/*      */     
/* 1047 */     if (i == 93) {
/* 1048 */       _closeArrayScope();
/* 1049 */       this._currToken = JsonToken.END_ARRAY;
/* 1050 */       return null;
/*      */     } 
/* 1052 */     if (i == 125) {
/* 1053 */       _closeObjectScope();
/* 1054 */       this._currToken = JsonToken.END_OBJECT;
/* 1055 */       return null;
/*      */     } 
/*      */ 
/*      */     
/* 1059 */     if (this._parsingContext.expectComma()) {
/* 1060 */       if (i != 44) {
/* 1061 */         _reportUnexpectedChar(i, "was expecting comma to separate " + this._parsingContext.typeDesc() + " entries");
/*      */       }
/* 1063 */       i = _skipWS();
/*      */       
/* 1065 */       if ((this._features & FEAT_MASK_TRAILING_COMMA) != 0 && (
/* 1066 */         i == 93 || i == 125)) {
/* 1067 */         _closeScope(i);
/* 1068 */         return null;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1073 */     if (!this._parsingContext.inObject()) {
/* 1074 */       _updateLocation();
/* 1075 */       _nextTokenNotInObject(i);
/* 1076 */       return null;
/*      */     } 
/*      */     
/* 1079 */     _updateNameLocation();
/* 1080 */     String nameStr = _parseName(i);
/* 1081 */     this._parsingContext.setCurrentName(nameStr);
/* 1082 */     this._currToken = JsonToken.FIELD_NAME;
/*      */     
/* 1084 */     i = _skipColon();
/* 1085 */     _updateLocation();
/* 1086 */     if (i == 34) {
/* 1087 */       this._tokenIncomplete = true;
/* 1088 */       this._nextToken = JsonToken.VALUE_STRING;
/* 1089 */       return nameStr;
/*      */     } 
/*      */     
/* 1092 */     switch (i)
/*      */     { case 45:
/* 1094 */         t = _parseSignedNumber(true);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1140 */         this._nextToken = t;
/* 1141 */         return nameStr;case 43: if (isEnabled(JsonReadFeature.ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS.mappedFeature())) { t = _parseSignedNumber(false); } else { t = _handleUnexpectedValue(i); }  this._nextToken = t; return nameStr;case 46: t = _parseFloatThatStartsWithPeriod(false, false); this._nextToken = t; return nameStr;case 48: case 49: case 50: case 51: case 52: case 53: case 54: case 55: case 56: case 57: t = _parseUnsignedNumber(i); this._nextToken = t; return nameStr;case 102: _matchFalse(); t = JsonToken.VALUE_FALSE; this._nextToken = t; return nameStr;case 110: _matchNull(); t = JsonToken.VALUE_NULL; this._nextToken = t; return nameStr;case 116: _matchTrue(); t = JsonToken.VALUE_TRUE; this._nextToken = t; return nameStr;case 91: t = JsonToken.START_ARRAY; this._nextToken = t; return nameStr;case 123: t = JsonToken.START_OBJECT; this._nextToken = t; return nameStr; }  JsonToken t = _handleUnexpectedValue(i); this._nextToken = t; return nameStr;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _skipColonFast(int ptr) throws IOException {
/* 1147 */     int i = this._inputBuffer[ptr++];
/* 1148 */     if (i == 58) {
/* 1149 */       i = this._inputBuffer[ptr++];
/* 1150 */       if (i > 32) {
/* 1151 */         if (i != 47 && i != 35) {
/* 1152 */           this._inputPtr = ptr;
/* 1153 */           return i;
/*      */         } 
/* 1155 */       } else if (i == 32 || i == 9) {
/* 1156 */         i = this._inputBuffer[ptr++];
/* 1157 */         if (i > 32 && 
/* 1158 */           i != 47 && i != 35) {
/* 1159 */           this._inputPtr = ptr;
/* 1160 */           return i;
/*      */         } 
/*      */       } 
/*      */       
/* 1164 */       this._inputPtr = ptr - 1;
/* 1165 */       return _skipColon2(true);
/*      */     } 
/* 1167 */     if (i == 32 || i == 9) {
/* 1168 */       i = this._inputBuffer[ptr++];
/*      */     }
/* 1170 */     if (i == 58) {
/* 1171 */       i = this._inputBuffer[ptr++];
/* 1172 */       if (i > 32) {
/* 1173 */         if (i != 47 && i != 35) {
/* 1174 */           this._inputPtr = ptr;
/* 1175 */           return i;
/*      */         } 
/* 1177 */       } else if (i == 32 || i == 9) {
/* 1178 */         i = this._inputBuffer[ptr++];
/* 1179 */         if (i > 32 && 
/* 1180 */           i != 47 && i != 35) {
/* 1181 */           this._inputPtr = ptr;
/* 1182 */           return i;
/*      */         } 
/*      */       } 
/*      */       
/* 1186 */       this._inputPtr = ptr - 1;
/* 1187 */       return _skipColon2(true);
/*      */     } 
/* 1189 */     this._inputPtr = ptr - 1;
/* 1190 */     return _skipColon2(false);
/*      */   }
/*      */ 
/*      */   
/*      */   private final void _isNextTokenNameYes(int i) throws IOException {
/* 1195 */     this._currToken = JsonToken.FIELD_NAME;
/* 1196 */     _updateLocation();
/*      */     
/* 1198 */     switch (i) {
/*      */       case 34:
/* 1200 */         this._tokenIncomplete = true;
/* 1201 */         this._nextToken = JsonToken.VALUE_STRING;
/*      */         return;
/*      */       case 91:
/* 1204 */         this._nextToken = JsonToken.START_ARRAY;
/*      */         return;
/*      */       case 123:
/* 1207 */         this._nextToken = JsonToken.START_OBJECT;
/*      */         return;
/*      */       case 116:
/* 1210 */         _matchTrue();
/* 1211 */         this._nextToken = JsonToken.VALUE_TRUE;
/*      */         return;
/*      */       case 102:
/* 1214 */         _matchFalse();
/* 1215 */         this._nextToken = JsonToken.VALUE_FALSE;
/*      */         return;
/*      */       case 110:
/* 1218 */         _matchNull();
/* 1219 */         this._nextToken = JsonToken.VALUE_NULL;
/*      */         return;
/*      */       case 45:
/* 1222 */         this._nextToken = _parseSignedNumber(true);
/*      */         return;
/*      */       case 43:
/* 1225 */         if (isEnabled(JsonReadFeature.ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS.mappedFeature())) {
/* 1226 */           this._nextToken = _parseSignedNumber(false);
/*      */         } else {
/* 1228 */           this._nextToken = _handleUnexpectedValue(i);
/*      */         } 
/*      */         return;
/*      */       case 46:
/* 1232 */         this._nextToken = _parseFloatThatStartsWithPeriod(false, false);
/*      */         return;
/*      */       case 48:
/*      */       case 49:
/*      */       case 50:
/*      */       case 51:
/*      */       case 52:
/*      */       case 53:
/*      */       case 54:
/*      */       case 55:
/*      */       case 56:
/*      */       case 57:
/* 1244 */         this._nextToken = _parseUnsignedNumber(i);
/*      */         return;
/*      */     } 
/* 1247 */     this._nextToken = _handleUnexpectedValue(i);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final boolean _isNextTokenNameMaybe(int i, SerializableString str) throws IOException {
/* 1254 */     String n = _parseName(i);
/* 1255 */     this._parsingContext.setCurrentName(n);
/* 1256 */     boolean match = n.equals(str.getValue());
/* 1257 */     this._currToken = JsonToken.FIELD_NAME;
/* 1258 */     i = _skipColon();
/* 1259 */     _updateLocation();
/*      */ 
/*      */     
/* 1262 */     if (i == 34) {
/* 1263 */       this._tokenIncomplete = true;
/* 1264 */       this._nextToken = JsonToken.VALUE_STRING;
/* 1265 */       return match;
/*      */     } 
/*      */ 
/*      */     
/* 1269 */     switch (i)
/*      */     { case 91:
/* 1271 */         t = JsonToken.START_ARRAY;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1316 */         this._nextToken = t;
/* 1317 */         return match;case 123: t = JsonToken.START_OBJECT; this._nextToken = t; return match;case 116: _matchTrue(); t = JsonToken.VALUE_TRUE; this._nextToken = t; return match;case 102: _matchFalse(); t = JsonToken.VALUE_FALSE; this._nextToken = t; return match;case 110: _matchNull(); t = JsonToken.VALUE_NULL; this._nextToken = t; return match;case 45: t = _parseSignedNumber(true); this._nextToken = t; return match;case 43: if (isEnabled(JsonReadFeature.ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS.mappedFeature())) { t = _parseSignedNumber(false); } else { t = _handleUnexpectedValue(i); }  this._nextToken = t; return match;case 46: t = _parseFloatThatStartsWithPeriod(false, false); this._nextToken = t; return match;case 48: case 49: case 50: case 51: case 52: case 53: case 54: case 55: case 56: case 57: t = _parseUnsignedNumber(i); this._nextToken = t; return match; }  JsonToken t = _handleUnexpectedValue(i); this._nextToken = t; return match;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String nextTextValue() throws IOException {
/* 1324 */     if (this._currToken == JsonToken.FIELD_NAME) {
/* 1325 */       this._nameCopied = false;
/* 1326 */       JsonToken t = this._nextToken;
/* 1327 */       this._nextToken = null;
/* 1328 */       this._currToken = t;
/* 1329 */       if (t == JsonToken.VALUE_STRING) {
/* 1330 */         if (this._tokenIncomplete) {
/* 1331 */           this._tokenIncomplete = false;
/* 1332 */           return _finishAndReturnString();
/*      */         } 
/* 1334 */         return this._textBuffer.contentsAsString();
/*      */       } 
/* 1336 */       if (t == JsonToken.START_ARRAY) {
/* 1337 */         this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/* 1338 */       } else if (t == JsonToken.START_OBJECT) {
/* 1339 */         this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */       } 
/* 1341 */       return null;
/*      */     } 
/*      */     
/* 1344 */     return (nextToken() == JsonToken.VALUE_STRING) ? getText() : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int nextIntValue(int defaultValue) throws IOException {
/* 1351 */     if (this._currToken == JsonToken.FIELD_NAME) {
/* 1352 */       this._nameCopied = false;
/* 1353 */       JsonToken t = this._nextToken;
/* 1354 */       this._nextToken = null;
/* 1355 */       this._currToken = t;
/* 1356 */       if (t == JsonToken.VALUE_NUMBER_INT) {
/* 1357 */         return getIntValue();
/*      */       }
/* 1359 */       if (t == JsonToken.START_ARRAY) {
/* 1360 */         this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/* 1361 */       } else if (t == JsonToken.START_OBJECT) {
/* 1362 */         this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */       } 
/* 1364 */       return defaultValue;
/*      */     } 
/*      */     
/* 1367 */     return (nextToken() == JsonToken.VALUE_NUMBER_INT) ? getIntValue() : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long nextLongValue(long defaultValue) throws IOException {
/* 1374 */     if (this._currToken == JsonToken.FIELD_NAME) {
/* 1375 */       this._nameCopied = false;
/* 1376 */       JsonToken t = this._nextToken;
/* 1377 */       this._nextToken = null;
/* 1378 */       this._currToken = t;
/* 1379 */       if (t == JsonToken.VALUE_NUMBER_INT) {
/* 1380 */         return getLongValue();
/*      */       }
/* 1382 */       if (t == JsonToken.START_ARRAY) {
/* 1383 */         this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/* 1384 */       } else if (t == JsonToken.START_OBJECT) {
/* 1385 */         this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */       } 
/* 1387 */       return defaultValue;
/*      */     } 
/*      */     
/* 1390 */     return (nextToken() == JsonToken.VALUE_NUMBER_INT) ? getLongValue() : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Boolean nextBooleanValue() throws IOException {
/* 1397 */     if (this._currToken == JsonToken.FIELD_NAME) {
/* 1398 */       this._nameCopied = false;
/* 1399 */       JsonToken jsonToken = this._nextToken;
/* 1400 */       this._nextToken = null;
/* 1401 */       this._currToken = jsonToken;
/* 1402 */       if (jsonToken == JsonToken.VALUE_TRUE) {
/* 1403 */         return Boolean.TRUE;
/*      */       }
/* 1405 */       if (jsonToken == JsonToken.VALUE_FALSE) {
/* 1406 */         return Boolean.FALSE;
/*      */       }
/* 1408 */       if (jsonToken == JsonToken.START_ARRAY) {
/* 1409 */         this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/* 1410 */       } else if (jsonToken == JsonToken.START_OBJECT) {
/* 1411 */         this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */       } 
/* 1413 */       return null;
/*      */     } 
/*      */     
/* 1416 */     JsonToken t = nextToken();
/* 1417 */     if (t == JsonToken.VALUE_TRUE) {
/* 1418 */       return Boolean.TRUE;
/*      */     }
/* 1420 */     if (t == JsonToken.VALUE_FALSE) {
/* 1421 */       return Boolean.FALSE;
/*      */     }
/* 1423 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected final JsonToken _parseFloatThatStartsWithPeriod() throws IOException {
/* 1434 */     return _parseFloatThatStartsWithPeriod(false, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final JsonToken _parseFloatThatStartsWithPeriod(boolean neg, boolean hasSign) throws IOException {
/* 1442 */     if (!isEnabled(JsonReadFeature.ALLOW_LEADING_DECIMAL_POINT_FOR_NUMBERS.mappedFeature())) {
/* 1443 */       return _handleUnexpectedValue(46);
/*      */     }
/* 1445 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 1446 */     int outPtr = 0;
/*      */     
/* 1448 */     if (neg) {
/* 1449 */       outBuf[outPtr++] = '-';
/*      */     }
/* 1451 */     return _parseFloat(outBuf, outPtr, 46, neg, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonToken _parseUnsignedNumber(int c) throws IOException {
/* 1479 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/*      */     
/* 1481 */     if (c == 48) {
/* 1482 */       c = _verifyNoLeadingZeroes();
/*      */     }
/*      */     
/* 1485 */     outBuf[0] = (char)c;
/* 1486 */     int intLen = 1;
/* 1487 */     int outPtr = 1;
/*      */ 
/*      */     
/* 1490 */     int end = Math.min(this._inputEnd, this._inputPtr + outBuf.length - 1);
/*      */     
/*      */     while (true) {
/* 1493 */       if (this._inputPtr >= end) {
/* 1494 */         return _parseNumber2(outBuf, outPtr, false, intLen);
/*      */       }
/* 1496 */       c = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 1497 */       if (c < 48 || c > 57) {
/*      */         break;
/*      */       }
/* 1500 */       intLen++;
/* 1501 */       outBuf[outPtr++] = (char)c;
/*      */     } 
/* 1503 */     if (c == 46 || c == 101 || c == 69) {
/* 1504 */       return _parseFloat(outBuf, outPtr, c, false, intLen);
/*      */     }
/* 1506 */     this._inputPtr--;
/* 1507 */     this._textBuffer.setCurrentLength(outPtr);
/*      */     
/* 1509 */     if (this._parsingContext.inRoot()) {
/* 1510 */       _verifyRootSpace(c);
/*      */     }
/*      */     
/* 1513 */     return resetInt(false, intLen);
/*      */   }
/*      */ 
/*      */   
/*      */   private final JsonToken _parseSignedNumber(boolean negative) throws IOException {
/* 1518 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 1519 */     int outPtr = 0;
/*      */     
/* 1521 */     if (negative)
/*      */     {
/* 1523 */       outBuf[outPtr++] = '-';
/*      */     }
/*      */     
/* 1526 */     if (this._inputPtr >= this._inputEnd) {
/* 1527 */       _loadMoreGuaranteed();
/*      */     }
/* 1529 */     int c = this._inputBuffer[this._inputPtr++] & 0xFF;
/*      */     
/* 1531 */     if (c <= 48) {
/*      */       
/* 1533 */       if (c != 48) {
/* 1534 */         if (c == 46) {
/* 1535 */           return _parseFloatThatStartsWithPeriod(negative, true);
/*      */         }
/* 1537 */         return _handleInvalidNumberStart(c, negative, true);
/*      */       } 
/* 1539 */       c = _verifyNoLeadingZeroes();
/* 1540 */     } else if (c > 57) {
/* 1541 */       return _handleInvalidNumberStart(c, negative, true);
/*      */     } 
/*      */ 
/*      */     
/* 1545 */     outBuf[outPtr++] = (char)c;
/* 1546 */     int intLen = 1;
/*      */ 
/*      */ 
/*      */     
/* 1550 */     int end = Math.min(this._inputEnd, this._inputPtr + outBuf.length - outPtr);
/*      */     
/*      */     while (true) {
/* 1553 */       if (this._inputPtr >= end)
/*      */       {
/* 1555 */         return _parseNumber2(outBuf, outPtr, negative, intLen);
/*      */       }
/* 1557 */       c = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 1558 */       if (c < 48 || c > 57) {
/*      */         break;
/*      */       }
/* 1561 */       intLen++;
/* 1562 */       outBuf[outPtr++] = (char)c;
/*      */     } 
/* 1564 */     if (c == 46 || c == 101 || c == 69) {
/* 1565 */       return _parseFloat(outBuf, outPtr, c, negative, intLen);
/*      */     }
/*      */     
/* 1568 */     this._inputPtr--;
/* 1569 */     this._textBuffer.setCurrentLength(outPtr);
/*      */     
/* 1571 */     if (this._parsingContext.inRoot()) {
/* 1572 */       _verifyRootSpace(c);
/*      */     }
/*      */ 
/*      */     
/* 1576 */     return resetInt(negative, intLen);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final JsonToken _parseNumber2(char[] outBuf, int outPtr, boolean negative, int intPartLength) throws IOException {
/*      */     while (true) {
/* 1586 */       if (this._inputPtr >= this._inputEnd && !_loadMore()) {
/* 1587 */         this._textBuffer.setCurrentLength(outPtr);
/* 1588 */         return resetInt(negative, intPartLength);
/*      */       } 
/* 1590 */       int c = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 1591 */       if (c > 57 || c < 48) {
/* 1592 */         if (c == 46 || c == 101 || c == 69) {
/* 1593 */           return _parseFloat(outBuf, outPtr, c, negative, intPartLength);
/*      */         }
/*      */         break;
/*      */       } 
/* 1597 */       if (outPtr >= outBuf.length) {
/* 1598 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 1599 */         outPtr = 0;
/*      */       } 
/* 1601 */       outBuf[outPtr++] = (char)c;
/* 1602 */       intPartLength++;
/*      */     } 
/* 1604 */     this._inputPtr--;
/* 1605 */     this._textBuffer.setCurrentLength(outPtr);
/*      */     
/* 1607 */     if (this._parsingContext.inRoot()) {
/* 1608 */       _verifyRootSpace(this._inputBuffer[this._inputPtr] & 0xFF);
/*      */     }
/*      */ 
/*      */     
/* 1612 */     return resetInt(negative, intPartLength);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _verifyNoLeadingZeroes() throws IOException {
/* 1621 */     if (this._inputPtr >= this._inputEnd && !_loadMore()) {
/* 1622 */       return 48;
/*      */     }
/* 1624 */     int ch = this._inputBuffer[this._inputPtr] & 0xFF;
/*      */     
/* 1626 */     if (ch < 48 || ch > 57) {
/* 1627 */       return 48;
/*      */     }
/*      */     
/* 1630 */     if ((this._features & FEAT_MASK_LEADING_ZEROS) == 0) {
/* 1631 */       reportInvalidNumber("Leading zeroes not allowed");
/*      */     }
/*      */     
/* 1634 */     this._inputPtr++;
/* 1635 */     if (ch == 48) {
/* 1636 */       while (this._inputPtr < this._inputEnd || _loadMore()) {
/* 1637 */         ch = this._inputBuffer[this._inputPtr] & 0xFF;
/* 1638 */         if (ch < 48 || ch > 57) {
/* 1639 */           return 48;
/*      */         }
/* 1641 */         this._inputPtr++;
/* 1642 */         if (ch != 48) {
/*      */           break;
/*      */         }
/*      */       } 
/*      */     }
/* 1647 */     return ch;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final JsonToken _parseFloat(char[] outBuf, int outPtr, int c, boolean negative, int integerPartLength) throws IOException {
/* 1653 */     int fractLen = 0;
/* 1654 */     boolean eof = false;
/*      */ 
/*      */     
/* 1657 */     if (c == 46) {
/* 1658 */       if (outPtr >= outBuf.length) {
/* 1659 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 1660 */         outPtr = 0;
/*      */       } 
/* 1662 */       outBuf[outPtr++] = (char)c;
/*      */ 
/*      */       
/*      */       while (true) {
/* 1666 */         if (this._inputPtr >= this._inputEnd && !_loadMore()) {
/* 1667 */           eof = true;
/*      */           break;
/*      */         } 
/* 1670 */         c = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 1671 */         if (c < 48 || c > 57) {
/*      */           break;
/*      */         }
/* 1674 */         fractLen++;
/* 1675 */         if (outPtr >= outBuf.length) {
/* 1676 */           outBuf = this._textBuffer.finishCurrentSegment();
/* 1677 */           outPtr = 0;
/*      */         } 
/* 1679 */         outBuf[outPtr++] = (char)c;
/*      */       } 
/*      */       
/* 1682 */       if (fractLen == 0 && 
/* 1683 */         !isEnabled(JsonReadFeature.ALLOW_TRAILING_DECIMAL_POINT_FOR_NUMBERS.mappedFeature())) {
/* 1684 */         _reportUnexpectedNumberChar(c, "Decimal point not followed by a digit");
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1689 */     int expLen = 0;
/* 1690 */     if (c == 101 || c == 69) {
/* 1691 */       if (outPtr >= outBuf.length) {
/* 1692 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 1693 */         outPtr = 0;
/*      */       } 
/* 1695 */       outBuf[outPtr++] = (char)c;
/*      */       
/* 1697 */       if (this._inputPtr >= this._inputEnd) {
/* 1698 */         _loadMoreGuaranteed();
/*      */       }
/* 1700 */       c = this._inputBuffer[this._inputPtr++] & 0xFF;
/*      */       
/* 1702 */       if (c == 45 || c == 43) {
/* 1703 */         if (outPtr >= outBuf.length) {
/* 1704 */           outBuf = this._textBuffer.finishCurrentSegment();
/* 1705 */           outPtr = 0;
/*      */         } 
/* 1707 */         outBuf[outPtr++] = (char)c;
/*      */         
/* 1709 */         if (this._inputPtr >= this._inputEnd) {
/* 1710 */           _loadMoreGuaranteed();
/*      */         }
/* 1712 */         c = this._inputBuffer[this._inputPtr++] & 0xFF;
/*      */       } 
/*      */ 
/*      */       
/* 1716 */       while (c >= 48 && c <= 57) {
/* 1717 */         expLen++;
/* 1718 */         if (outPtr >= outBuf.length) {
/* 1719 */           outBuf = this._textBuffer.finishCurrentSegment();
/* 1720 */           outPtr = 0;
/*      */         } 
/* 1722 */         outBuf[outPtr++] = (char)c;
/* 1723 */         if (this._inputPtr >= this._inputEnd && !_loadMore()) {
/* 1724 */           eof = true;
/*      */           break;
/*      */         } 
/* 1727 */         c = this._inputBuffer[this._inputPtr++] & 0xFF;
/*      */       } 
/*      */       
/* 1730 */       if (expLen == 0) {
/* 1731 */         _reportUnexpectedNumberChar(c, "Exponent indicator not followed by a digit");
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1736 */     if (!eof) {
/* 1737 */       this._inputPtr--;
/*      */       
/* 1739 */       if (this._parsingContext.inRoot()) {
/* 1740 */         _verifyRootSpace(c);
/*      */       }
/*      */     } 
/* 1743 */     this._textBuffer.setCurrentLength(outPtr);
/*      */ 
/*      */     
/* 1746 */     return resetFloat(negative, integerPartLength, fractLen, expLen);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _verifyRootSpace(int ch) throws IOException {
/* 1764 */     this._inputPtr++;
/*      */     
/* 1766 */     switch (ch) {
/*      */       case 9:
/*      */       case 32:
/*      */         return;
/*      */ 
/*      */ 
/*      */       
/*      */       case 13:
/* 1774 */         this._inputPtr--;
/*      */         return;
/*      */       case 10:
/* 1777 */         this._currInputRow++;
/* 1778 */         this._currInputRowStart = this._inputPtr;
/*      */         return;
/*      */     } 
/* 1781 */     _reportMissingRootWS(ch);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final String _parseName(int i) throws IOException {
/* 1792 */     if (i != 34) {
/* 1793 */       return _handleOddName(i);
/*      */     }
/*      */     
/* 1796 */     if (this._inputPtr + 13 > this._inputEnd) {
/* 1797 */       return slowParseName();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1806 */     byte[] input = this._inputBuffer;
/* 1807 */     int[] codes = _icLatin1;
/*      */     
/* 1809 */     int q = input[this._inputPtr++] & 0xFF;
/*      */     
/* 1811 */     if (codes[q] == 0) {
/* 1812 */       i = input[this._inputPtr++] & 0xFF;
/* 1813 */       if (codes[i] == 0) {
/* 1814 */         q = q << 8 | i;
/* 1815 */         i = input[this._inputPtr++] & 0xFF;
/* 1816 */         if (codes[i] == 0) {
/* 1817 */           q = q << 8 | i;
/* 1818 */           i = input[this._inputPtr++] & 0xFF;
/* 1819 */           if (codes[i] == 0) {
/* 1820 */             q = q << 8 | i;
/* 1821 */             i = input[this._inputPtr++] & 0xFF;
/* 1822 */             if (codes[i] == 0) {
/* 1823 */               this._quad1 = q;
/* 1824 */               return parseMediumName(i);
/*      */             } 
/* 1826 */             if (i == 34) {
/* 1827 */               return findName(q, 4);
/*      */             }
/* 1829 */             return parseName(q, i, 4);
/*      */           } 
/* 1831 */           if (i == 34) {
/* 1832 */             return findName(q, 3);
/*      */           }
/* 1834 */           return parseName(q, i, 3);
/*      */         } 
/* 1836 */         if (i == 34) {
/* 1837 */           return findName(q, 2);
/*      */         }
/* 1839 */         return parseName(q, i, 2);
/*      */       } 
/* 1841 */       if (i == 34) {
/* 1842 */         return findName(q, 1);
/*      */       }
/* 1844 */       return parseName(q, i, 1);
/*      */     } 
/* 1846 */     if (q == 34) {
/* 1847 */       return "";
/*      */     }
/* 1849 */     return parseName(0, q, 0);
/*      */   }
/*      */ 
/*      */   
/*      */   protected final String parseMediumName(int q2) throws IOException {
/* 1854 */     byte[] input = this._inputBuffer;
/* 1855 */     int[] codes = _icLatin1;
/*      */ 
/*      */     
/* 1858 */     int i = input[this._inputPtr++] & 0xFF;
/* 1859 */     if (codes[i] != 0) {
/* 1860 */       if (i == 34) {
/* 1861 */         return findName(this._quad1, q2, 1);
/*      */       }
/* 1863 */       return parseName(this._quad1, q2, i, 1);
/*      */     } 
/* 1865 */     q2 = q2 << 8 | i;
/* 1866 */     i = input[this._inputPtr++] & 0xFF;
/* 1867 */     if (codes[i] != 0) {
/* 1868 */       if (i == 34) {
/* 1869 */         return findName(this._quad1, q2, 2);
/*      */       }
/* 1871 */       return parseName(this._quad1, q2, i, 2);
/*      */     } 
/* 1873 */     q2 = q2 << 8 | i;
/* 1874 */     i = input[this._inputPtr++] & 0xFF;
/* 1875 */     if (codes[i] != 0) {
/* 1876 */       if (i == 34) {
/* 1877 */         return findName(this._quad1, q2, 3);
/*      */       }
/* 1879 */       return parseName(this._quad1, q2, i, 3);
/*      */     } 
/* 1881 */     q2 = q2 << 8 | i;
/* 1882 */     i = input[this._inputPtr++] & 0xFF;
/* 1883 */     if (codes[i] != 0) {
/* 1884 */       if (i == 34) {
/* 1885 */         return findName(this._quad1, q2, 4);
/*      */       }
/* 1887 */       return parseName(this._quad1, q2, i, 4);
/*      */     } 
/* 1889 */     return parseMediumName2(i, q2);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected final String parseMediumName2(int q3, int q2) throws IOException {
/* 1895 */     byte[] input = this._inputBuffer;
/* 1896 */     int[] codes = _icLatin1;
/*      */ 
/*      */     
/* 1899 */     int i = input[this._inputPtr++] & 0xFF;
/* 1900 */     if (codes[i] != 0) {
/* 1901 */       if (i == 34) {
/* 1902 */         return findName(this._quad1, q2, q3, 1);
/*      */       }
/* 1904 */       return parseName(this._quad1, q2, q3, i, 1);
/*      */     } 
/* 1906 */     q3 = q3 << 8 | i;
/* 1907 */     i = input[this._inputPtr++] & 0xFF;
/* 1908 */     if (codes[i] != 0) {
/* 1909 */       if (i == 34) {
/* 1910 */         return findName(this._quad1, q2, q3, 2);
/*      */       }
/* 1912 */       return parseName(this._quad1, q2, q3, i, 2);
/*      */     } 
/* 1914 */     q3 = q3 << 8 | i;
/* 1915 */     i = input[this._inputPtr++] & 0xFF;
/* 1916 */     if (codes[i] != 0) {
/* 1917 */       if (i == 34) {
/* 1918 */         return findName(this._quad1, q2, q3, 3);
/*      */       }
/* 1920 */       return parseName(this._quad1, q2, q3, i, 3);
/*      */     } 
/* 1922 */     q3 = q3 << 8 | i;
/* 1923 */     i = input[this._inputPtr++] & 0xFF;
/* 1924 */     if (codes[i] != 0) {
/* 1925 */       if (i == 34) {
/* 1926 */         return findName(this._quad1, q2, q3, 4);
/*      */       }
/* 1928 */       return parseName(this._quad1, q2, q3, i, 4);
/*      */     } 
/* 1930 */     return parseLongName(i, q2, q3);
/*      */   }
/*      */ 
/*      */   
/*      */   protected final String parseLongName(int q, int q2, int q3) throws IOException {
/* 1935 */     this._quadBuffer[0] = this._quad1;
/* 1936 */     this._quadBuffer[1] = q2;
/* 1937 */     this._quadBuffer[2] = q3;
/*      */ 
/*      */     
/* 1940 */     byte[] input = this._inputBuffer;
/* 1941 */     int[] codes = _icLatin1;
/* 1942 */     int qlen = 3;
/*      */     
/* 1944 */     while (this._inputPtr + 4 <= this._inputEnd) {
/* 1945 */       int i = input[this._inputPtr++] & 0xFF;
/* 1946 */       if (codes[i] != 0) {
/* 1947 */         if (i == 34) {
/* 1948 */           return findName(this._quadBuffer, qlen, q, 1);
/*      */         }
/* 1950 */         return parseEscapedName(this._quadBuffer, qlen, q, i, 1);
/*      */       } 
/*      */       
/* 1953 */       q = q << 8 | i;
/* 1954 */       i = input[this._inputPtr++] & 0xFF;
/* 1955 */       if (codes[i] != 0) {
/* 1956 */         if (i == 34) {
/* 1957 */           return findName(this._quadBuffer, qlen, q, 2);
/*      */         }
/* 1959 */         return parseEscapedName(this._quadBuffer, qlen, q, i, 2);
/*      */       } 
/*      */       
/* 1962 */       q = q << 8 | i;
/* 1963 */       i = input[this._inputPtr++] & 0xFF;
/* 1964 */       if (codes[i] != 0) {
/* 1965 */         if (i == 34) {
/* 1966 */           return findName(this._quadBuffer, qlen, q, 3);
/*      */         }
/* 1968 */         return parseEscapedName(this._quadBuffer, qlen, q, i, 3);
/*      */       } 
/*      */       
/* 1971 */       q = q << 8 | i;
/* 1972 */       i = input[this._inputPtr++] & 0xFF;
/* 1973 */       if (codes[i] != 0) {
/* 1974 */         if (i == 34) {
/* 1975 */           return findName(this._quadBuffer, qlen, q, 4);
/*      */         }
/* 1977 */         return parseEscapedName(this._quadBuffer, qlen, q, i, 4);
/*      */       } 
/*      */ 
/*      */       
/* 1981 */       if (qlen >= this._quadBuffer.length) {
/* 1982 */         this._quadBuffer = growArrayBy(this._quadBuffer, qlen);
/*      */       }
/* 1984 */       this._quadBuffer[qlen++] = q;
/* 1985 */       q = i;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1992 */     return parseEscapedName(this._quadBuffer, qlen, 0, q, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String slowParseName() throws IOException {
/* 2000 */     if (this._inputPtr >= this._inputEnd && 
/* 2001 */       !_loadMore()) {
/* 2002 */       _reportInvalidEOF(": was expecting closing '\"' for name", JsonToken.FIELD_NAME);
/*      */     }
/*      */     
/* 2005 */     int i = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 2006 */     if (i == 34) {
/* 2007 */       return "";
/*      */     }
/* 2009 */     return parseEscapedName(this._quadBuffer, 0, 0, i, 0);
/*      */   }
/*      */   
/*      */   private final String parseName(int q1, int ch, int lastQuadBytes) throws IOException {
/* 2013 */     return parseEscapedName(this._quadBuffer, 0, q1, ch, lastQuadBytes);
/*      */   }
/*      */   
/*      */   private final String parseName(int q1, int q2, int ch, int lastQuadBytes) throws IOException {
/* 2017 */     this._quadBuffer[0] = q1;
/* 2018 */     return parseEscapedName(this._quadBuffer, 1, q2, ch, lastQuadBytes);
/*      */   }
/*      */   
/*      */   private final String parseName(int q1, int q2, int q3, int ch, int lastQuadBytes) throws IOException {
/* 2022 */     this._quadBuffer[0] = q1;
/* 2023 */     this._quadBuffer[1] = q2;
/* 2024 */     return parseEscapedName(this._quadBuffer, 2, q3, ch, lastQuadBytes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final String parseEscapedName(int[] quads, int qlen, int currQuad, int ch, int currQuadBytes) throws IOException {
/* 2037 */     int[] codes = _icLatin1;
/*      */     
/*      */     while (true) {
/* 2040 */       if (codes[ch] != 0) {
/* 2041 */         if (ch == 34) {
/*      */           break;
/*      */         }
/*      */         
/* 2045 */         if (ch != 92) {
/*      */           
/* 2047 */           _throwUnquotedSpace(ch, "name");
/*      */         } else {
/*      */           
/* 2050 */           ch = _decodeEscaped();
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 2055 */         if (ch > 127) {
/*      */           
/* 2057 */           if (currQuadBytes >= 4) {
/* 2058 */             if (qlen >= quads.length) {
/* 2059 */               this._quadBuffer = quads = growArrayBy(quads, quads.length);
/*      */             }
/* 2061 */             quads[qlen++] = currQuad;
/* 2062 */             currQuad = 0;
/* 2063 */             currQuadBytes = 0;
/*      */           } 
/* 2065 */           if (ch < 2048) {
/* 2066 */             currQuad = currQuad << 8 | 0xC0 | ch >> 6;
/* 2067 */             currQuadBytes++;
/*      */           } else {
/*      */             
/* 2070 */             currQuad = currQuad << 8 | 0xE0 | ch >> 12;
/* 2071 */             currQuadBytes++;
/*      */             
/* 2073 */             if (currQuadBytes >= 4) {
/* 2074 */               if (qlen >= quads.length) {
/* 2075 */                 this._quadBuffer = quads = growArrayBy(quads, quads.length);
/*      */               }
/* 2077 */               quads[qlen++] = currQuad;
/* 2078 */               currQuad = 0;
/* 2079 */               currQuadBytes = 0;
/*      */             } 
/* 2081 */             currQuad = currQuad << 8 | 0x80 | ch >> 6 & 0x3F;
/* 2082 */             currQuadBytes++;
/*      */           } 
/*      */           
/* 2085 */           ch = 0x80 | ch & 0x3F;
/*      */         } 
/*      */       } 
/*      */       
/* 2089 */       if (currQuadBytes < 4) {
/* 2090 */         currQuadBytes++;
/* 2091 */         currQuad = currQuad << 8 | ch;
/*      */       } else {
/* 2093 */         if (qlen >= quads.length) {
/* 2094 */           this._quadBuffer = quads = growArrayBy(quads, quads.length);
/*      */         }
/* 2096 */         quads[qlen++] = currQuad;
/* 2097 */         currQuad = ch;
/* 2098 */         currQuadBytes = 1;
/*      */       } 
/* 2100 */       if (this._inputPtr >= this._inputEnd && 
/* 2101 */         !_loadMore()) {
/* 2102 */         _reportInvalidEOF(" in field name", JsonToken.FIELD_NAME);
/*      */       }
/*      */       
/* 2105 */       ch = this._inputBuffer[this._inputPtr++] & 0xFF;
/*      */     } 
/*      */     
/* 2108 */     if (currQuadBytes > 0) {
/* 2109 */       if (qlen >= quads.length) {
/* 2110 */         this._quadBuffer = quads = growArrayBy(quads, quads.length);
/*      */       }
/* 2112 */       quads[qlen++] = _padLastQuad(currQuad, currQuadBytes);
/*      */     } 
/* 2114 */     String name = this._symbols.findName(quads, qlen);
/* 2115 */     if (name == null) {
/* 2116 */       name = addName(quads, qlen, currQuadBytes);
/*      */     }
/* 2118 */     return name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String _handleOddName(int ch) throws IOException {
/* 2137 */     if (ch == 39 && (this._features & FEAT_MASK_ALLOW_SINGLE_QUOTES) != 0) {
/* 2138 */       return _parseAposName();
/*      */     }
/*      */     
/* 2141 */     if ((this._features & FEAT_MASK_ALLOW_UNQUOTED_NAMES) == 0) {
/* 2142 */       char c = (char)_decodeCharForError(ch);
/* 2143 */       _reportUnexpectedChar(c, "was expecting double-quote to start field name");
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2149 */     int[] codes = CharTypes.getInputCodeUtf8JsNames();
/*      */     
/* 2151 */     if (codes[ch] != 0) {
/* 2152 */       _reportUnexpectedChar(ch, "was expecting either valid name character (for unquoted name) or double-quote (for quoted) to start field name");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2158 */     int[] quads = this._quadBuffer;
/* 2159 */     int qlen = 0;
/* 2160 */     int currQuad = 0;
/* 2161 */     int currQuadBytes = 0;
/*      */ 
/*      */     
/*      */     while (true) {
/* 2165 */       if (currQuadBytes < 4) {
/* 2166 */         currQuadBytes++;
/* 2167 */         currQuad = currQuad << 8 | ch;
/*      */       } else {
/* 2169 */         if (qlen >= quads.length) {
/* 2170 */           this._quadBuffer = quads = growArrayBy(quads, quads.length);
/*      */         }
/* 2172 */         quads[qlen++] = currQuad;
/* 2173 */         currQuad = ch;
/* 2174 */         currQuadBytes = 1;
/*      */       } 
/* 2176 */       if (this._inputPtr >= this._inputEnd && 
/* 2177 */         !_loadMore()) {
/* 2178 */         _reportInvalidEOF(" in field name", JsonToken.FIELD_NAME);
/*      */       }
/*      */       
/* 2181 */       ch = this._inputBuffer[this._inputPtr] & 0xFF;
/* 2182 */       if (codes[ch] != 0) {
/*      */         break;
/*      */       }
/* 2185 */       this._inputPtr++;
/*      */     } 
/*      */     
/* 2188 */     if (currQuadBytes > 0) {
/* 2189 */       if (qlen >= quads.length) {
/* 2190 */         this._quadBuffer = quads = growArrayBy(quads, quads.length);
/*      */       }
/* 2192 */       quads[qlen++] = currQuad;
/*      */     } 
/* 2194 */     String name = this._symbols.findName(quads, qlen);
/* 2195 */     if (name == null) {
/* 2196 */       name = addName(quads, qlen, currQuadBytes);
/*      */     }
/* 2198 */     return name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String _parseAposName() throws IOException {
/* 2207 */     if (this._inputPtr >= this._inputEnd && 
/* 2208 */       !_loadMore()) {
/* 2209 */       _reportInvalidEOF(": was expecting closing ''' for field name", JsonToken.FIELD_NAME);
/*      */     }
/*      */     
/* 2212 */     int ch = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 2213 */     if (ch == 39) {
/* 2214 */       return "";
/*      */     }
/* 2216 */     int[] quads = this._quadBuffer;
/* 2217 */     int qlen = 0;
/* 2218 */     int currQuad = 0;
/* 2219 */     int currQuadBytes = 0;
/*      */ 
/*      */ 
/*      */     
/* 2223 */     int[] codes = _icLatin1;
/*      */ 
/*      */     
/* 2226 */     while (ch != 39) {
/*      */ 
/*      */ 
/*      */       
/* 2230 */       if (codes[ch] != 0 && ch != 34) {
/* 2231 */         if (ch != 92) {
/*      */ 
/*      */           
/* 2234 */           _throwUnquotedSpace(ch, "name");
/*      */         } else {
/*      */           
/* 2237 */           ch = _decodeEscaped();
/*      */         } 
/*      */         
/* 2240 */         if (ch > 127) {
/*      */           
/* 2242 */           if (currQuadBytes >= 4) {
/* 2243 */             if (qlen >= quads.length) {
/* 2244 */               this._quadBuffer = quads = growArrayBy(quads, quads.length);
/*      */             }
/* 2246 */             quads[qlen++] = currQuad;
/* 2247 */             currQuad = 0;
/* 2248 */             currQuadBytes = 0;
/*      */           } 
/* 2250 */           if (ch < 2048) {
/* 2251 */             currQuad = currQuad << 8 | 0xC0 | ch >> 6;
/* 2252 */             currQuadBytes++;
/*      */           } else {
/*      */             
/* 2255 */             currQuad = currQuad << 8 | 0xE0 | ch >> 12;
/* 2256 */             currQuadBytes++;
/*      */             
/* 2258 */             if (currQuadBytes >= 4) {
/* 2259 */               if (qlen >= quads.length) {
/* 2260 */                 this._quadBuffer = quads = growArrayBy(quads, quads.length);
/*      */               }
/* 2262 */               quads[qlen++] = currQuad;
/* 2263 */               currQuad = 0;
/* 2264 */               currQuadBytes = 0;
/*      */             } 
/* 2266 */             currQuad = currQuad << 8 | 0x80 | ch >> 6 & 0x3F;
/* 2267 */             currQuadBytes++;
/*      */           } 
/*      */           
/* 2270 */           ch = 0x80 | ch & 0x3F;
/*      */         } 
/*      */       } 
/*      */       
/* 2274 */       if (currQuadBytes < 4) {
/* 2275 */         currQuadBytes++;
/* 2276 */         currQuad = currQuad << 8 | ch;
/*      */       } else {
/* 2278 */         if (qlen >= quads.length) {
/* 2279 */           this._quadBuffer = quads = growArrayBy(quads, quads.length);
/*      */         }
/* 2281 */         quads[qlen++] = currQuad;
/* 2282 */         currQuad = ch;
/* 2283 */         currQuadBytes = 1;
/*      */       } 
/* 2285 */       if (this._inputPtr >= this._inputEnd && 
/* 2286 */         !_loadMore()) {
/* 2287 */         _reportInvalidEOF(" in field name", JsonToken.FIELD_NAME);
/*      */       }
/*      */       
/* 2290 */       ch = this._inputBuffer[this._inputPtr++] & 0xFF;
/*      */     } 
/*      */     
/* 2293 */     if (currQuadBytes > 0) {
/* 2294 */       if (qlen >= quads.length) {
/* 2295 */         this._quadBuffer = quads = growArrayBy(quads, quads.length);
/*      */       }
/* 2297 */       quads[qlen++] = _padLastQuad(currQuad, currQuadBytes);
/*      */     } 
/* 2299 */     String name = this._symbols.findName(quads, qlen);
/* 2300 */     if (name == null) {
/* 2301 */       name = addName(quads, qlen, currQuadBytes);
/*      */     }
/* 2303 */     return name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final String findName(int q1, int lastQuadBytes) throws JsonParseException {
/* 2314 */     q1 = _padLastQuad(q1, lastQuadBytes);
/*      */     
/* 2316 */     String name = this._symbols.findName(q1);
/* 2317 */     if (name != null) {
/* 2318 */       return name;
/*      */     }
/*      */     
/* 2321 */     this._quadBuffer[0] = q1;
/* 2322 */     return addName(this._quadBuffer, 1, lastQuadBytes);
/*      */   }
/*      */ 
/*      */   
/*      */   private final String findName(int q1, int q2, int lastQuadBytes) throws JsonParseException {
/* 2327 */     q2 = _padLastQuad(q2, lastQuadBytes);
/*      */     
/* 2329 */     String name = this._symbols.findName(q1, q2);
/* 2330 */     if (name != null) {
/* 2331 */       return name;
/*      */     }
/*      */     
/* 2334 */     this._quadBuffer[0] = q1;
/* 2335 */     this._quadBuffer[1] = q2;
/* 2336 */     return addName(this._quadBuffer, 2, lastQuadBytes);
/*      */   }
/*      */ 
/*      */   
/*      */   private final String findName(int q1, int q2, int q3, int lastQuadBytes) throws JsonParseException {
/* 2341 */     q3 = _padLastQuad(q3, lastQuadBytes);
/* 2342 */     String name = this._symbols.findName(q1, q2, q3);
/* 2343 */     if (name != null) {
/* 2344 */       return name;
/*      */     }
/* 2346 */     int[] quads = this._quadBuffer;
/* 2347 */     quads[0] = q1;
/* 2348 */     quads[1] = q2;
/* 2349 */     quads[2] = _padLastQuad(q3, lastQuadBytes);
/* 2350 */     return addName(quads, 3, lastQuadBytes);
/*      */   }
/*      */ 
/*      */   
/*      */   private final String findName(int[] quads, int qlen, int lastQuad, int lastQuadBytes) throws JsonParseException {
/* 2355 */     if (qlen >= quads.length) {
/* 2356 */       this._quadBuffer = quads = growArrayBy(quads, quads.length);
/*      */     }
/* 2358 */     quads[qlen++] = _padLastQuad(lastQuad, lastQuadBytes);
/* 2359 */     String name = this._symbols.findName(quads, qlen);
/* 2360 */     if (name == null) {
/* 2361 */       return addName(quads, qlen, lastQuadBytes);
/*      */     }
/* 2363 */     return name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final String addName(int[] quads, int qlen, int lastQuadBytes) throws JsonParseException {
/* 2378 */     int lastQuad, byteLen = (qlen << 2) - 4 + lastQuadBytes;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2387 */     if (lastQuadBytes < 4) {
/* 2388 */       lastQuad = quads[qlen - 1];
/*      */       
/* 2390 */       quads[qlen - 1] = lastQuad << 4 - lastQuadBytes << 3;
/*      */     } else {
/* 2392 */       lastQuad = 0;
/*      */     } 
/*      */ 
/*      */     
/* 2396 */     char[] cbuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 2397 */     int cix = 0;
/*      */     
/* 2399 */     for (int ix = 0; ix < byteLen; ) {
/* 2400 */       int ch = quads[ix >> 2];
/* 2401 */       int byteIx = ix & 0x3;
/* 2402 */       ch = ch >> 3 - byteIx << 3 & 0xFF;
/* 2403 */       ix++;
/*      */       
/* 2405 */       if (ch > 127) {
/*      */         int needed;
/* 2407 */         if ((ch & 0xE0) == 192) {
/* 2408 */           ch &= 0x1F;
/* 2409 */           needed = 1;
/* 2410 */         } else if ((ch & 0xF0) == 224) {
/* 2411 */           ch &= 0xF;
/* 2412 */           needed = 2;
/* 2413 */         } else if ((ch & 0xF8) == 240) {
/* 2414 */           ch &= 0x7;
/* 2415 */           needed = 3;
/*      */         } else {
/* 2417 */           _reportInvalidInitial(ch);
/* 2418 */           needed = ch = 1;
/*      */         } 
/* 2420 */         if (ix + needed > byteLen) {
/* 2421 */           _reportInvalidEOF(" in field name", JsonToken.FIELD_NAME);
/*      */         }
/*      */ 
/*      */         
/* 2425 */         int ch2 = quads[ix >> 2];
/* 2426 */         byteIx = ix & 0x3;
/* 2427 */         ch2 >>= 3 - byteIx << 3;
/* 2428 */         ix++;
/*      */         
/* 2430 */         if ((ch2 & 0xC0) != 128) {
/* 2431 */           _reportInvalidOther(ch2);
/*      */         }
/* 2433 */         ch = ch << 6 | ch2 & 0x3F;
/* 2434 */         if (needed > 1) {
/* 2435 */           ch2 = quads[ix >> 2];
/* 2436 */           byteIx = ix & 0x3;
/* 2437 */           ch2 >>= 3 - byteIx << 3;
/* 2438 */           ix++;
/*      */           
/* 2440 */           if ((ch2 & 0xC0) != 128) {
/* 2441 */             _reportInvalidOther(ch2);
/*      */           }
/* 2443 */           ch = ch << 6 | ch2 & 0x3F;
/* 2444 */           if (needed > 2) {
/* 2445 */             ch2 = quads[ix >> 2];
/* 2446 */             byteIx = ix & 0x3;
/* 2447 */             ch2 >>= 3 - byteIx << 3;
/* 2448 */             ix++;
/* 2449 */             if ((ch2 & 0xC0) != 128) {
/* 2450 */               _reportInvalidOther(ch2 & 0xFF);
/*      */             }
/* 2452 */             ch = ch << 6 | ch2 & 0x3F;
/*      */           } 
/*      */         } 
/* 2455 */         if (needed > 2) {
/* 2456 */           ch -= 65536;
/* 2457 */           if (cix >= cbuf.length) {
/* 2458 */             cbuf = this._textBuffer.expandCurrentSegment();
/*      */           }
/* 2460 */           cbuf[cix++] = (char)(55296 + (ch >> 10));
/* 2461 */           ch = 0xDC00 | ch & 0x3FF;
/*      */         } 
/*      */       } 
/* 2464 */       if (cix >= cbuf.length) {
/* 2465 */         cbuf = this._textBuffer.expandCurrentSegment();
/*      */       }
/* 2467 */       cbuf[cix++] = (char)ch;
/*      */     } 
/*      */ 
/*      */     
/* 2471 */     String baseName = new String(cbuf, 0, cix);
/*      */     
/* 2473 */     if (lastQuadBytes < 4) {
/* 2474 */       quads[qlen - 1] = lastQuad;
/*      */     }
/* 2476 */     return this._symbols.addName(baseName, quads, qlen);
/*      */   }
/*      */ 
/*      */   
/*      */   private static final int _padLastQuad(int q, int bytes) {
/* 2481 */     return (bytes == 4) ? q : (q | -1 << bytes << 3);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _loadMoreGuaranteed() throws IOException {
/* 2491 */     if (!_loadMore()) _reportInvalidEOF();
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _finishString() throws IOException {
/* 2498 */     int ptr = this._inputPtr;
/* 2499 */     if (ptr >= this._inputEnd) {
/* 2500 */       _loadMoreGuaranteed();
/* 2501 */       ptr = this._inputPtr;
/*      */     } 
/* 2503 */     int outPtr = 0;
/* 2504 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 2505 */     int[] codes = _icUTF8;
/*      */     
/* 2507 */     int max = Math.min(this._inputEnd, ptr + outBuf.length);
/* 2508 */     byte[] inputBuffer = this._inputBuffer;
/* 2509 */     while (ptr < max) {
/* 2510 */       int c = inputBuffer[ptr] & 0xFF;
/* 2511 */       if (codes[c] != 0) {
/* 2512 */         if (c == 34) {
/* 2513 */           this._inputPtr = ptr + 1;
/* 2514 */           this._textBuffer.setCurrentLength(outPtr);
/*      */           return;
/*      */         } 
/*      */         break;
/*      */       } 
/* 2519 */       ptr++;
/* 2520 */       outBuf[outPtr++] = (char)c;
/*      */     } 
/* 2522 */     this._inputPtr = ptr;
/* 2523 */     _finishString2(outBuf, outPtr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String _finishAndReturnString() throws IOException {
/* 2530 */     int ptr = this._inputPtr;
/* 2531 */     if (ptr >= this._inputEnd) {
/* 2532 */       _loadMoreGuaranteed();
/* 2533 */       ptr = this._inputPtr;
/*      */     } 
/* 2535 */     int outPtr = 0;
/* 2536 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 2537 */     int[] codes = _icUTF8;
/*      */     
/* 2539 */     int max = Math.min(this._inputEnd, ptr + outBuf.length);
/* 2540 */     byte[] inputBuffer = this._inputBuffer;
/* 2541 */     while (ptr < max) {
/* 2542 */       int c = inputBuffer[ptr] & 0xFF;
/* 2543 */       if (codes[c] != 0) {
/* 2544 */         if (c == 34) {
/* 2545 */           this._inputPtr = ptr + 1;
/* 2546 */           return this._textBuffer.setCurrentAndReturn(outPtr);
/*      */         } 
/*      */         break;
/*      */       } 
/* 2550 */       ptr++;
/* 2551 */       outBuf[outPtr++] = (char)c;
/*      */     } 
/* 2553 */     this._inputPtr = ptr;
/* 2554 */     _finishString2(outBuf, outPtr);
/* 2555 */     return this._textBuffer.contentsAsString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _finishString2(char[] outBuf, int outPtr) throws IOException {
/* 2564 */     int[] codes = _icUTF8;
/* 2565 */     byte[] inputBuffer = this._inputBuffer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/* 2572 */       int ptr = this._inputPtr;
/* 2573 */       if (ptr >= this._inputEnd) {
/* 2574 */         _loadMoreGuaranteed();
/* 2575 */         ptr = this._inputPtr;
/*      */       } 
/* 2577 */       if (outPtr >= outBuf.length) {
/* 2578 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 2579 */         outPtr = 0;
/*      */       } 
/* 2581 */       int max = Math.min(this._inputEnd, ptr + outBuf.length - outPtr);
/* 2582 */       while (ptr < max) {
/* 2583 */         int c = inputBuffer[ptr++] & 0xFF;
/* 2584 */         if (codes[c] != 0) {
/* 2585 */           this._inputPtr = ptr;
/*      */         } else {
/*      */           
/* 2588 */           outBuf[outPtr++] = (char)c;
/*      */           
/*      */           continue;
/*      */         } 
/*      */         
/* 2593 */         if (c == 34) {
/*      */           break;
/*      */         }
/*      */         
/* 2597 */         switch (codes[c]) {
/*      */           case 1:
/* 2599 */             c = _decodeEscaped();
/*      */             break;
/*      */           case 2:
/* 2602 */             c = _decodeUtf8_2(c);
/*      */             break;
/*      */           case 3:
/* 2605 */             if (this._inputEnd - this._inputPtr >= 2) {
/* 2606 */               c = _decodeUtf8_3fast(c); break;
/*      */             } 
/* 2608 */             c = _decodeUtf8_3(c);
/*      */             break;
/*      */           
/*      */           case 4:
/* 2612 */             c = _decodeUtf8_4(c);
/*      */             
/* 2614 */             outBuf[outPtr++] = (char)(0xD800 | c >> 10);
/* 2615 */             if (outPtr >= outBuf.length) {
/* 2616 */               outBuf = this._textBuffer.finishCurrentSegment();
/* 2617 */               outPtr = 0;
/*      */             } 
/* 2619 */             c = 0xDC00 | c & 0x3FF;
/*      */             break;
/*      */           
/*      */           default:
/* 2623 */             if (c < 32) {
/*      */               
/* 2625 */               _throwUnquotedSpace(c, "string value");
/*      */               break;
/*      */             } 
/* 2628 */             _reportInvalidChar(c);
/*      */             break;
/*      */         } 
/*      */         
/* 2632 */         if (outPtr >= outBuf.length) {
/* 2633 */           outBuf = this._textBuffer.finishCurrentSegment();
/* 2634 */           outPtr = 0;
/*      */         } 
/*      */         
/* 2637 */         outBuf[outPtr++] = (char)c;
/*      */       }  this._inputPtr = ptr;
/* 2639 */     }  this._textBuffer.setCurrentLength(outPtr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _skipString() throws IOException {
/* 2652 */     this._tokenIncomplete = false;
/*      */ 
/*      */     
/* 2655 */     int[] codes = _icUTF8;
/* 2656 */     byte[] inputBuffer = this._inputBuffer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/* 2664 */       int ptr = this._inputPtr;
/* 2665 */       int max = this._inputEnd;
/* 2666 */       if (ptr >= max) {
/* 2667 */         _loadMoreGuaranteed();
/* 2668 */         ptr = this._inputPtr;
/* 2669 */         max = this._inputEnd;
/*      */       } 
/* 2671 */       while (ptr < max) {
/* 2672 */         int c = inputBuffer[ptr++] & 0xFF;
/* 2673 */         if (codes[c] != 0) {
/* 2674 */           this._inputPtr = ptr;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2681 */           if (c != 34) {
/*      */ 
/*      */ 
/*      */             
/* 2685 */             switch (codes[c]) {
/*      */               case 1:
/* 2687 */                 _decodeEscaped();
/*      */                 continue;
/*      */               case 2:
/* 2690 */                 _skipUtf8_2();
/*      */                 continue;
/*      */               case 3:
/* 2693 */                 _skipUtf8_3();
/*      */                 continue;
/*      */               case 4:
/* 2696 */                 _skipUtf8_4(c);
/*      */                 continue;
/*      */             } 
/* 2699 */             if (c < 32) {
/* 2700 */               _throwUnquotedSpace(c, "string value");
/*      */               continue;
/*      */             } 
/* 2703 */             _reportInvalidChar(c);
/*      */             continue;
/*      */           } 
/*      */           return;
/*      */         } 
/*      */       } 
/*      */       this._inputPtr = ptr;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonToken _handleUnexpectedValue(int c) throws IOException {
/* 2723 */     switch (c) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 93:
/* 2732 */         if (!this._parsingContext.inArray()) {
/*      */           break;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 44:
/* 2741 */         if (!this._parsingContext.inRoot() && (
/* 2742 */           this._features & FEAT_MASK_ALLOW_MISSING) != 0) {
/* 2743 */           this._inputPtr--;
/* 2744 */           return JsonToken.VALUE_NULL;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 125:
/* 2751 */         _reportUnexpectedChar(c, "expected a value");
/*      */       case 39:
/* 2753 */         if ((this._features & FEAT_MASK_ALLOW_SINGLE_QUOTES) != 0) {
/* 2754 */           return _handleApos();
/*      */         }
/*      */         break;
/*      */       case 78:
/* 2758 */         _matchToken("NaN", 1);
/* 2759 */         if ((this._features & FEAT_MASK_NON_NUM_NUMBERS) != 0) {
/* 2760 */           return resetAsNaN("NaN", Double.NaN);
/*      */         }
/* 2762 */         _reportError("Non-standard token 'NaN': enable `JsonReadFeature.ALLOW_NON_NUMERIC_NUMBERS` to allow");
/*      */         break;
/*      */       case 73:
/* 2765 */         _matchToken("Infinity", 1);
/* 2766 */         if ((this._features & FEAT_MASK_NON_NUM_NUMBERS) != 0) {
/* 2767 */           return resetAsNaN("Infinity", Double.POSITIVE_INFINITY);
/*      */         }
/* 2769 */         _reportError("Non-standard token 'Infinity': enable `JsonReadFeature.ALLOW_NON_NUMERIC_NUMBERS` to allow");
/*      */         break;
/*      */       case 43:
/* 2772 */         if (this._inputPtr >= this._inputEnd && 
/* 2773 */           !_loadMore()) {
/* 2774 */           _reportInvalidEOFInValue(JsonToken.VALUE_NUMBER_INT);
/*      */         }
/*      */         
/* 2777 */         return _handleInvalidNumberStart(this._inputBuffer[this._inputPtr++] & 0xFF, false, true);
/*      */     } 
/*      */     
/* 2780 */     if (Character.isJavaIdentifierStart(c)) {
/* 2781 */       _reportInvalidToken("" + (char)c, _validJsonTokenList());
/*      */     }
/*      */     
/* 2784 */     _reportUnexpectedChar(c, "expected a valid value " + _validJsonValueList());
/* 2785 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _handleApos() throws IOException {
/* 2790 */     int c = 0;
/*      */     
/* 2792 */     int outPtr = 0;
/* 2793 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/*      */ 
/*      */     
/* 2796 */     int[] codes = _icUTF8;
/* 2797 */     byte[] inputBuffer = this._inputBuffer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     while (true)
/* 2804 */     { if (this._inputPtr >= this._inputEnd) {
/* 2805 */         _loadMoreGuaranteed();
/*      */       }
/* 2807 */       if (outPtr >= outBuf.length) {
/* 2808 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 2809 */         outPtr = 0;
/*      */       } 
/* 2811 */       int max = this._inputEnd;
/*      */       
/* 2813 */       int max2 = this._inputPtr + outBuf.length - outPtr;
/* 2814 */       if (max2 < max) {
/* 2815 */         max = max2;
/*      */       }
/*      */       
/* 2818 */       while (this._inputPtr < max)
/* 2819 */       { c = inputBuffer[this._inputPtr++] & 0xFF;
/* 2820 */         if (c != 39) {
/*      */ 
/*      */           
/* 2823 */           if (codes[c] != 0 && c != 34) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 2833 */             switch (codes[c]) {
/*      */               case 1:
/* 2835 */                 c = _decodeEscaped();
/*      */                 break;
/*      */               case 2:
/* 2838 */                 c = _decodeUtf8_2(c);
/*      */                 break;
/*      */               case 3:
/* 2841 */                 if (this._inputEnd - this._inputPtr >= 2) {
/* 2842 */                   c = _decodeUtf8_3fast(c); break;
/*      */                 } 
/* 2844 */                 c = _decodeUtf8_3(c);
/*      */                 break;
/*      */               
/*      */               case 4:
/* 2848 */                 c = _decodeUtf8_4(c);
/*      */                 
/* 2850 */                 outBuf[outPtr++] = (char)(0xD800 | c >> 10);
/* 2851 */                 if (outPtr >= outBuf.length) {
/* 2852 */                   outBuf = this._textBuffer.finishCurrentSegment();
/* 2853 */                   outPtr = 0;
/*      */                 } 
/* 2855 */                 c = 0xDC00 | c & 0x3FF;
/*      */                 break;
/*      */               
/*      */               default:
/* 2859 */                 if (c < 32) {
/* 2860 */                   _throwUnquotedSpace(c, "string value");
/*      */                 }
/*      */                 
/* 2863 */                 _reportInvalidChar(c);
/*      */                 break;
/*      */             } 
/* 2866 */             if (outPtr >= outBuf.length) {
/* 2867 */               outBuf = this._textBuffer.finishCurrentSegment();
/* 2868 */               outPtr = 0;
/*      */             } 
/*      */             
/* 2871 */             outBuf[outPtr++] = (char)c; continue;
/*      */           }  outBuf[outPtr++] = (char)c; continue;
/* 2873 */         }  this._textBuffer.setCurrentLength(outPtr);
/*      */         
/* 2875 */         return JsonToken.VALUE_STRING; }  }  this._textBuffer.setCurrentLength(outPtr); return JsonToken.VALUE_STRING;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonToken _handleInvalidNumberStart(int ch, boolean neg) throws IOException {
/* 2888 */     return _handleInvalidNumberStart(ch, neg, false);
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _handleInvalidNumberStart(int ch, boolean neg, boolean hasSign) throws IOException {
/* 2893 */     while (ch == 73) {
/* 2894 */       String match; if (this._inputPtr >= this._inputEnd && 
/* 2895 */         !_loadMore()) {
/* 2896 */         _reportInvalidEOFInValue(JsonToken.VALUE_NUMBER_FLOAT);
/*      */       }
/*      */       
/* 2899 */       ch = this._inputBuffer[this._inputPtr++];
/*      */       
/* 2901 */       if (ch == 78) {
/* 2902 */         match = neg ? "-INF" : "+INF";
/* 2903 */       } else if (ch == 110) {
/* 2904 */         match = neg ? "-Infinity" : "+Infinity";
/*      */       } else {
/*      */         break;
/*      */       } 
/* 2908 */       _matchToken(match, 3);
/* 2909 */       if ((this._features & FEAT_MASK_NON_NUM_NUMBERS) != 0) {
/* 2910 */         return resetAsNaN(match, neg ? Double.NEGATIVE_INFINITY : Double.POSITIVE_INFINITY);
/*      */       }
/* 2912 */       _reportError("Non-standard token '%s': enable `JsonReadFeature.ALLOW_NON_NUMERIC_NUMBERS` to allow", match);
/*      */     } 
/*      */     
/* 2915 */     if (!isEnabled(JsonReadFeature.ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS.mappedFeature()) && hasSign && !neg) {
/* 2916 */       _reportUnexpectedNumberChar(43, "JSON spec does not allow numbers to have plus signs: enable `JsonReadFeature.ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS` to allow");
/*      */     }
/* 2918 */     String message = neg ? "expected digit (0-9) to follow minus sign, for valid numeric value" : "expected digit (0-9) for valid numeric value";
/*      */ 
/*      */     
/* 2921 */     _reportUnexpectedNumberChar(ch, message);
/* 2922 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void _matchTrue() throws IOException {
/* 2928 */     int ptr = this._inputPtr;
/* 2929 */     if (ptr + 3 < this._inputEnd) {
/* 2930 */       byte[] buf = this._inputBuffer;
/* 2931 */       if (buf[ptr++] == 114 && buf[ptr++] == 117 && buf[ptr++] == 101) {
/*      */ 
/*      */         
/* 2934 */         int ch = buf[ptr] & 0xFF;
/* 2935 */         if (ch < 48 || ch == 93 || ch == 125) {
/* 2936 */           this._inputPtr = ptr;
/*      */           return;
/*      */         } 
/*      */       } 
/*      */     } 
/* 2941 */     _matchToken2("true", 1);
/*      */   }
/*      */ 
/*      */   
/*      */   protected final void _matchFalse() throws IOException {
/* 2946 */     int ptr = this._inputPtr;
/* 2947 */     if (ptr + 4 < this._inputEnd) {
/* 2948 */       byte[] buf = this._inputBuffer;
/* 2949 */       if (buf[ptr++] == 97 && buf[ptr++] == 108 && buf[ptr++] == 115 && buf[ptr++] == 101) {
/*      */ 
/*      */ 
/*      */         
/* 2953 */         int ch = buf[ptr] & 0xFF;
/* 2954 */         if (ch < 48 || ch == 93 || ch == 125) {
/* 2955 */           this._inputPtr = ptr;
/*      */           return;
/*      */         } 
/*      */       } 
/*      */     } 
/* 2960 */     _matchToken2("false", 1);
/*      */   }
/*      */ 
/*      */   
/*      */   protected final void _matchNull() throws IOException {
/* 2965 */     int ptr = this._inputPtr;
/* 2966 */     if (ptr + 3 < this._inputEnd) {
/* 2967 */       byte[] buf = this._inputBuffer;
/* 2968 */       if (buf[ptr++] == 117 && buf[ptr++] == 108 && buf[ptr++] == 108) {
/*      */ 
/*      */         
/* 2971 */         int ch = buf[ptr] & 0xFF;
/* 2972 */         if (ch < 48 || ch == 93 || ch == 125) {
/* 2973 */           this._inputPtr = ptr;
/*      */           return;
/*      */         } 
/*      */       } 
/*      */     } 
/* 2978 */     _matchToken2("null", 1);
/*      */   }
/*      */ 
/*      */   
/*      */   protected final void _matchToken(String matchStr, int i) throws IOException {
/* 2983 */     int len = matchStr.length();
/* 2984 */     if (this._inputPtr + len >= this._inputEnd) {
/* 2985 */       _matchToken2(matchStr, i);
/*      */       return;
/*      */     } 
/*      */     do {
/* 2989 */       if (this._inputBuffer[this._inputPtr] != matchStr.charAt(i)) {
/* 2990 */         _reportInvalidToken(matchStr.substring(0, i));
/*      */       }
/* 2992 */       this._inputPtr++;
/* 2993 */     } while (++i < len);
/*      */     
/* 2995 */     int ch = this._inputBuffer[this._inputPtr] & 0xFF;
/* 2996 */     if (ch >= 48 && ch != 93 && ch != 125) {
/* 2997 */       _checkMatchEnd(matchStr, i, ch);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private final void _matchToken2(String matchStr, int i) throws IOException {
/* 3003 */     int len = matchStr.length();
/*      */     do {
/* 3005 */       if ((this._inputPtr >= this._inputEnd && !_loadMore()) || this._inputBuffer[this._inputPtr] != matchStr
/* 3006 */         .charAt(i)) {
/* 3007 */         _reportInvalidToken(matchStr.substring(0, i));
/*      */       }
/* 3009 */       this._inputPtr++;
/* 3010 */     } while (++i < len);
/*      */ 
/*      */     
/* 3013 */     if (this._inputPtr >= this._inputEnd && !_loadMore()) {
/*      */       return;
/*      */     }
/* 3016 */     int ch = this._inputBuffer[this._inputPtr] & 0xFF;
/* 3017 */     if (ch >= 48 && ch != 93 && ch != 125) {
/* 3018 */       _checkMatchEnd(matchStr, i, ch);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private final void _checkMatchEnd(String matchStr, int i, int ch) throws IOException {
/* 3024 */     char c = (char)_decodeCharForError(ch);
/* 3025 */     if (Character.isJavaIdentifierPart(c)) {
/* 3026 */       _reportInvalidToken(matchStr.substring(0, i));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _skipWS() throws IOException {
/* 3038 */     while (this._inputPtr < this._inputEnd) {
/* 3039 */       int i = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 3040 */       if (i > 32) {
/* 3041 */         if (i == 47 || i == 35) {
/* 3042 */           this._inputPtr--;
/* 3043 */           return _skipWS2();
/*      */         } 
/* 3045 */         return i;
/*      */       } 
/* 3047 */       if (i != 32) {
/* 3048 */         if (i == 10) {
/* 3049 */           this._currInputRow++;
/* 3050 */           this._currInputRowStart = this._inputPtr; continue;
/* 3051 */         }  if (i == 13) {
/* 3052 */           _skipCR(); continue;
/* 3053 */         }  if (i != 9) {
/* 3054 */           _throwInvalidSpace(i);
/*      */         }
/*      */       } 
/*      */     } 
/* 3058 */     return _skipWS2();
/*      */   }
/*      */ 
/*      */   
/*      */   private final int _skipWS2() throws IOException {
/* 3063 */     while (this._inputPtr < this._inputEnd || _loadMore()) {
/* 3064 */       int i = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 3065 */       if (i > 32) {
/* 3066 */         if (i == 47) {
/* 3067 */           _skipComment();
/*      */           continue;
/*      */         } 
/* 3070 */         if (i == 35 && 
/* 3071 */           _skipYAMLComment()) {
/*      */           continue;
/*      */         }
/*      */         
/* 3075 */         return i;
/*      */       } 
/* 3077 */       if (i != 32) {
/* 3078 */         if (i == 10) {
/* 3079 */           this._currInputRow++;
/* 3080 */           this._currInputRowStart = this._inputPtr; continue;
/* 3081 */         }  if (i == 13) {
/* 3082 */           _skipCR(); continue;
/* 3083 */         }  if (i != 9) {
/* 3084 */           _throwInvalidSpace(i);
/*      */         }
/*      */       } 
/*      */     } 
/* 3088 */     throw _constructError("Unexpected end-of-input within/between " + this._parsingContext.typeDesc() + " entries");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _skipWSOrEnd() throws IOException {
/* 3095 */     if (this._inputPtr >= this._inputEnd && 
/* 3096 */       !_loadMore()) {
/* 3097 */       return _eofAsNextChar();
/*      */     }
/*      */     
/* 3100 */     int i = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 3101 */     if (i > 32) {
/* 3102 */       if (i == 47 || i == 35) {
/* 3103 */         this._inputPtr--;
/* 3104 */         return _skipWSOrEnd2();
/*      */       } 
/* 3106 */       return i;
/*      */     } 
/* 3108 */     if (i != 32) {
/* 3109 */       if (i == 10) {
/* 3110 */         this._currInputRow++;
/* 3111 */         this._currInputRowStart = this._inputPtr;
/* 3112 */       } else if (i == 13) {
/* 3113 */         _skipCR();
/* 3114 */       } else if (i != 9) {
/* 3115 */         _throwInvalidSpace(i);
/*      */       } 
/*      */     }
/*      */     
/* 3119 */     while (this._inputPtr < this._inputEnd) {
/* 3120 */       i = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 3121 */       if (i > 32) {
/* 3122 */         if (i == 47 || i == 35) {
/* 3123 */           this._inputPtr--;
/* 3124 */           return _skipWSOrEnd2();
/*      */         } 
/* 3126 */         return i;
/*      */       } 
/* 3128 */       if (i != 32) {
/* 3129 */         if (i == 10) {
/* 3130 */           this._currInputRow++;
/* 3131 */           this._currInputRowStart = this._inputPtr; continue;
/* 3132 */         }  if (i == 13) {
/* 3133 */           _skipCR(); continue;
/* 3134 */         }  if (i != 9) {
/* 3135 */           _throwInvalidSpace(i);
/*      */         }
/*      */       } 
/*      */     } 
/* 3139 */     return _skipWSOrEnd2();
/*      */   }
/*      */ 
/*      */   
/*      */   private final int _skipWSOrEnd2() throws IOException {
/* 3144 */     while (this._inputPtr < this._inputEnd || _loadMore()) {
/* 3145 */       int i = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 3146 */       if (i > 32) {
/* 3147 */         if (i == 47) {
/* 3148 */           _skipComment();
/*      */           continue;
/*      */         } 
/* 3151 */         if (i == 35 && 
/* 3152 */           _skipYAMLComment()) {
/*      */           continue;
/*      */         }
/*      */         
/* 3156 */         return i;
/* 3157 */       }  if (i != 32) {
/* 3158 */         if (i == 10) {
/* 3159 */           this._currInputRow++;
/* 3160 */           this._currInputRowStart = this._inputPtr; continue;
/* 3161 */         }  if (i == 13) {
/* 3162 */           _skipCR(); continue;
/* 3163 */         }  if (i != 9) {
/* 3164 */           _throwInvalidSpace(i);
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/* 3169 */     return _eofAsNextChar();
/*      */   }
/*      */ 
/*      */   
/*      */   private final int _skipColon() throws IOException {
/* 3174 */     if (this._inputPtr + 4 >= this._inputEnd) {
/* 3175 */       return _skipColon2(false);
/*      */     }
/*      */     
/* 3178 */     int i = this._inputBuffer[this._inputPtr];
/* 3179 */     if (i == 58) {
/* 3180 */       i = this._inputBuffer[++this._inputPtr];
/* 3181 */       if (i > 32) {
/* 3182 */         if (i == 47 || i == 35) {
/* 3183 */           return _skipColon2(true);
/*      */         }
/* 3185 */         this._inputPtr++;
/* 3186 */         return i;
/*      */       } 
/* 3188 */       if (i == 32 || i == 9) {
/* 3189 */         i = this._inputBuffer[++this._inputPtr];
/* 3190 */         if (i > 32) {
/* 3191 */           if (i == 47 || i == 35) {
/* 3192 */             return _skipColon2(true);
/*      */           }
/* 3194 */           this._inputPtr++;
/* 3195 */           return i;
/*      */         } 
/*      */       } 
/* 3198 */       return _skipColon2(true);
/*      */     } 
/* 3200 */     if (i == 32 || i == 9) {
/* 3201 */       i = this._inputBuffer[++this._inputPtr];
/*      */     }
/* 3203 */     if (i == 58) {
/* 3204 */       i = this._inputBuffer[++this._inputPtr];
/* 3205 */       if (i > 32) {
/* 3206 */         if (i == 47 || i == 35) {
/* 3207 */           return _skipColon2(true);
/*      */         }
/* 3209 */         this._inputPtr++;
/* 3210 */         return i;
/*      */       } 
/* 3212 */       if (i == 32 || i == 9) {
/* 3213 */         i = this._inputBuffer[++this._inputPtr];
/* 3214 */         if (i > 32) {
/* 3215 */           if (i == 47 || i == 35) {
/* 3216 */             return _skipColon2(true);
/*      */           }
/* 3218 */           this._inputPtr++;
/* 3219 */           return i;
/*      */         } 
/*      */       } 
/* 3222 */       return _skipColon2(true);
/*      */     } 
/* 3224 */     return _skipColon2(false);
/*      */   }
/*      */ 
/*      */   
/*      */   private final int _skipColon2(boolean gotColon) throws IOException {
/* 3229 */     while (this._inputPtr < this._inputEnd || _loadMore()) {
/* 3230 */       int i = this._inputBuffer[this._inputPtr++] & 0xFF;
/*      */       
/* 3232 */       if (i > 32) {
/* 3233 */         if (i == 47) {
/* 3234 */           _skipComment();
/*      */           continue;
/*      */         } 
/* 3237 */         if (i == 35 && 
/* 3238 */           _skipYAMLComment()) {
/*      */           continue;
/*      */         }
/*      */         
/* 3242 */         if (gotColon) {
/* 3243 */           return i;
/*      */         }
/* 3245 */         if (i != 58) {
/* 3246 */           _reportUnexpectedChar(i, "was expecting a colon to separate field name and value");
/*      */         }
/* 3248 */         gotColon = true; continue;
/* 3249 */       }  if (i != 32) {
/* 3250 */         if (i == 10) {
/* 3251 */           this._currInputRow++;
/* 3252 */           this._currInputRowStart = this._inputPtr; continue;
/* 3253 */         }  if (i == 13) {
/* 3254 */           _skipCR(); continue;
/* 3255 */         }  if (i != 9) {
/* 3256 */           _throwInvalidSpace(i);
/*      */         }
/*      */       } 
/*      */     } 
/* 3260 */     _reportInvalidEOF(" within/between " + this._parsingContext.typeDesc() + " entries", null);
/*      */     
/* 3262 */     return -1;
/*      */   }
/*      */ 
/*      */   
/*      */   private final void _skipComment() throws IOException {
/* 3267 */     if ((this._features & FEAT_MASK_ALLOW_JAVA_COMMENTS) == 0) {
/* 3268 */       _reportUnexpectedChar(47, "maybe a (non-standard) comment? (not recognized as one since Feature 'ALLOW_COMMENTS' not enabled for parser)");
/*      */     }
/*      */     
/* 3271 */     if (this._inputPtr >= this._inputEnd && !_loadMore()) {
/* 3272 */       _reportInvalidEOF(" in a comment", null);
/*      */     }
/* 3274 */     int c = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 3275 */     if (c == 47) {
/* 3276 */       _skipLine();
/* 3277 */     } else if (c == 42) {
/* 3278 */       _skipCComment();
/*      */     } else {
/* 3280 */       _reportUnexpectedChar(c, "was expecting either '*' or '/' for a comment");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _skipCComment() throws IOException {
/* 3287 */     int[] codes = CharTypes.getInputCodeComment();
/*      */ 
/*      */ 
/*      */     
/* 3291 */     while (this._inputPtr < this._inputEnd || _loadMore()) {
/* 3292 */       int i = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 3293 */       int code = codes[i];
/* 3294 */       if (code != 0) {
/* 3295 */         switch (code) {
/*      */           case 42:
/* 3297 */             if (this._inputPtr >= this._inputEnd && !_loadMore()) {
/*      */               break;
/*      */             }
/* 3300 */             if (this._inputBuffer[this._inputPtr] == 47) {
/* 3301 */               this._inputPtr++;
/*      */               return;
/*      */             } 
/*      */             continue;
/*      */           case 10:
/* 3306 */             this._currInputRow++;
/* 3307 */             this._currInputRowStart = this._inputPtr;
/*      */             continue;
/*      */           case 13:
/* 3310 */             _skipCR();
/*      */             continue;
/*      */           case 2:
/* 3313 */             _skipUtf8_2();
/*      */             continue;
/*      */           case 3:
/* 3316 */             _skipUtf8_3();
/*      */             continue;
/*      */           case 4:
/* 3319 */             _skipUtf8_4(i);
/*      */             continue;
/*      */         } 
/*      */         
/* 3323 */         _reportInvalidChar(i);
/*      */       } 
/*      */     } 
/*      */     
/* 3327 */     _reportInvalidEOF(" in a comment", null);
/*      */   }
/*      */ 
/*      */   
/*      */   private final boolean _skipYAMLComment() throws IOException {
/* 3332 */     if ((this._features & FEAT_MASK_ALLOW_YAML_COMMENTS) == 0) {
/* 3333 */       return false;
/*      */     }
/* 3335 */     _skipLine();
/* 3336 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _skipLine() throws IOException {
/* 3344 */     int[] codes = CharTypes.getInputCodeComment();
/* 3345 */     while (this._inputPtr < this._inputEnd || _loadMore()) {
/* 3346 */       int i = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 3347 */       int code = codes[i];
/* 3348 */       if (code != 0) {
/* 3349 */         switch (code) {
/*      */           case 10:
/* 3351 */             this._currInputRow++;
/* 3352 */             this._currInputRowStart = this._inputPtr;
/*      */             return;
/*      */           case 13:
/* 3355 */             _skipCR();
/*      */             return;
/*      */           case 42:
/*      */             continue;
/*      */           case 2:
/* 3360 */             _skipUtf8_2();
/*      */             continue;
/*      */           case 3:
/* 3363 */             _skipUtf8_3();
/*      */             continue;
/*      */           case 4:
/* 3366 */             _skipUtf8_4(i);
/*      */             continue;
/*      */         } 
/* 3369 */         if (code < 0)
/*      */         {
/* 3371 */           _reportInvalidChar(i);
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected char _decodeEscaped() throws IOException {
/* 3381 */     if (this._inputPtr >= this._inputEnd && 
/* 3382 */       !_loadMore()) {
/* 3383 */       _reportInvalidEOF(" in character escape sequence", JsonToken.VALUE_STRING);
/*      */     }
/*      */     
/* 3386 */     int c = this._inputBuffer[this._inputPtr++];
/*      */     
/* 3388 */     switch (c) {
/*      */       
/*      */       case 98:
/* 3391 */         return '\b';
/*      */       case 116:
/* 3393 */         return '\t';
/*      */       case 110:
/* 3395 */         return '\n';
/*      */       case 102:
/* 3397 */         return '\f';
/*      */       case 114:
/* 3399 */         return '\r';
/*      */ 
/*      */       
/*      */       case 34:
/*      */       case 47:
/*      */       case 92:
/* 3405 */         return (char)c;
/*      */       
/*      */       case 117:
/*      */         break;
/*      */       
/*      */       default:
/* 3411 */         return _handleUnrecognizedCharacterEscape((char)_decodeCharForError(c));
/*      */     } 
/*      */ 
/*      */     
/* 3415 */     int value = 0;
/* 3416 */     for (int i = 0; i < 4; i++) {
/* 3417 */       if (this._inputPtr >= this._inputEnd && 
/* 3418 */         !_loadMore()) {
/* 3419 */         _reportInvalidEOF(" in character escape sequence", JsonToken.VALUE_STRING);
/*      */       }
/*      */       
/* 3422 */       int ch = this._inputBuffer[this._inputPtr++];
/* 3423 */       int digit = CharTypes.charToHex(ch);
/* 3424 */       if (digit < 0) {
/* 3425 */         _reportUnexpectedChar(ch & 0xFF, "expected a hex-digit for character escape sequence");
/*      */       }
/* 3427 */       value = value << 4 | digit;
/*      */     } 
/* 3429 */     return (char)value;
/*      */   }
/*      */ 
/*      */   
/*      */   protected int _decodeCharForError(int firstByte) throws IOException {
/* 3434 */     int c = firstByte & 0xFF;
/* 3435 */     if (c > 127) {
/*      */       int needed;
/*      */ 
/*      */       
/* 3439 */       if ((c & 0xE0) == 192) {
/* 3440 */         c &= 0x1F;
/* 3441 */         needed = 1;
/* 3442 */       } else if ((c & 0xF0) == 224) {
/* 3443 */         c &= 0xF;
/* 3444 */         needed = 2;
/* 3445 */       } else if ((c & 0xF8) == 240) {
/*      */         
/* 3447 */         c &= 0x7;
/* 3448 */         needed = 3;
/*      */       } else {
/* 3450 */         _reportInvalidInitial(c & 0xFF);
/* 3451 */         needed = 1;
/*      */       } 
/*      */       
/* 3454 */       int d = nextByte();
/* 3455 */       if ((d & 0xC0) != 128) {
/* 3456 */         _reportInvalidOther(d & 0xFF);
/*      */       }
/* 3458 */       c = c << 6 | d & 0x3F;
/*      */       
/* 3460 */       if (needed > 1) {
/* 3461 */         d = nextByte();
/* 3462 */         if ((d & 0xC0) != 128) {
/* 3463 */           _reportInvalidOther(d & 0xFF);
/*      */         }
/* 3465 */         c = c << 6 | d & 0x3F;
/* 3466 */         if (needed > 2) {
/* 3467 */           d = nextByte();
/* 3468 */           if ((d & 0xC0) != 128) {
/* 3469 */             _reportInvalidOther(d & 0xFF);
/*      */           }
/* 3471 */           c = c << 6 | d & 0x3F;
/*      */         } 
/*      */       } 
/*      */     } 
/* 3475 */     return c;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _decodeUtf8_2(int c) throws IOException {
/* 3486 */     if (this._inputPtr >= this._inputEnd) {
/* 3487 */       _loadMoreGuaranteed();
/*      */     }
/* 3489 */     int d = this._inputBuffer[this._inputPtr++];
/* 3490 */     if ((d & 0xC0) != 128) {
/* 3491 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 3493 */     return (c & 0x1F) << 6 | d & 0x3F;
/*      */   }
/*      */ 
/*      */   
/*      */   private final int _decodeUtf8_3(int c1) throws IOException {
/* 3498 */     if (this._inputPtr >= this._inputEnd) {
/* 3499 */       _loadMoreGuaranteed();
/*      */     }
/* 3501 */     c1 &= 0xF;
/* 3502 */     int d = this._inputBuffer[this._inputPtr++];
/* 3503 */     if ((d & 0xC0) != 128) {
/* 3504 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 3506 */     int c = c1 << 6 | d & 0x3F;
/* 3507 */     if (this._inputPtr >= this._inputEnd) {
/* 3508 */       _loadMoreGuaranteed();
/*      */     }
/* 3510 */     d = this._inputBuffer[this._inputPtr++];
/* 3511 */     if ((d & 0xC0) != 128) {
/* 3512 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 3514 */     c = c << 6 | d & 0x3F;
/* 3515 */     return c;
/*      */   }
/*      */ 
/*      */   
/*      */   private final int _decodeUtf8_3fast(int c1) throws IOException {
/* 3520 */     c1 &= 0xF;
/* 3521 */     int d = this._inputBuffer[this._inputPtr++];
/* 3522 */     if ((d & 0xC0) != 128) {
/* 3523 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 3525 */     int c = c1 << 6 | d & 0x3F;
/* 3526 */     d = this._inputBuffer[this._inputPtr++];
/* 3527 */     if ((d & 0xC0) != 128) {
/* 3528 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 3530 */     c = c << 6 | d & 0x3F;
/* 3531 */     return c;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _decodeUtf8_4(int c) throws IOException {
/* 3538 */     if (this._inputPtr >= this._inputEnd) {
/* 3539 */       _loadMoreGuaranteed();
/*      */     }
/* 3541 */     int d = this._inputBuffer[this._inputPtr++];
/* 3542 */     if ((d & 0xC0) != 128) {
/* 3543 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 3545 */     c = (c & 0x7) << 6 | d & 0x3F;
/*      */     
/* 3547 */     if (this._inputPtr >= this._inputEnd) {
/* 3548 */       _loadMoreGuaranteed();
/*      */     }
/* 3550 */     d = this._inputBuffer[this._inputPtr++];
/* 3551 */     if ((d & 0xC0) != 128) {
/* 3552 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 3554 */     c = c << 6 | d & 0x3F;
/* 3555 */     if (this._inputPtr >= this._inputEnd) {
/* 3556 */       _loadMoreGuaranteed();
/*      */     }
/* 3558 */     d = this._inputBuffer[this._inputPtr++];
/* 3559 */     if ((d & 0xC0) != 128) {
/* 3560 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3566 */     return (c << 6 | d & 0x3F) - 65536;
/*      */   }
/*      */ 
/*      */   
/*      */   private final void _skipUtf8_2() throws IOException {
/* 3571 */     if (this._inputPtr >= this._inputEnd) {
/* 3572 */       _loadMoreGuaranteed();
/*      */     }
/* 3574 */     int c = this._inputBuffer[this._inputPtr++];
/* 3575 */     if ((c & 0xC0) != 128) {
/* 3576 */       _reportInvalidOther(c & 0xFF, this._inputPtr);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _skipUtf8_3() throws IOException {
/* 3585 */     if (this._inputPtr >= this._inputEnd) {
/* 3586 */       _loadMoreGuaranteed();
/*      */     }
/*      */     
/* 3589 */     int c = this._inputBuffer[this._inputPtr++];
/* 3590 */     if ((c & 0xC0) != 128) {
/* 3591 */       _reportInvalidOther(c & 0xFF, this._inputPtr);
/*      */     }
/* 3593 */     if (this._inputPtr >= this._inputEnd) {
/* 3594 */       _loadMoreGuaranteed();
/*      */     }
/* 3596 */     c = this._inputBuffer[this._inputPtr++];
/* 3597 */     if ((c & 0xC0) != 128) {
/* 3598 */       _reportInvalidOther(c & 0xFF, this._inputPtr);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private final void _skipUtf8_4(int c) throws IOException {
/* 3604 */     if (this._inputPtr >= this._inputEnd) {
/* 3605 */       _loadMoreGuaranteed();
/*      */     }
/* 3607 */     int d = this._inputBuffer[this._inputPtr++];
/* 3608 */     if ((d & 0xC0) != 128) {
/* 3609 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 3611 */     if (this._inputPtr >= this._inputEnd) {
/* 3612 */       _loadMoreGuaranteed();
/*      */     }
/* 3614 */     d = this._inputBuffer[this._inputPtr++];
/* 3615 */     if ((d & 0xC0) != 128) {
/* 3616 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 3618 */     if (this._inputPtr >= this._inputEnd) {
/* 3619 */       _loadMoreGuaranteed();
/*      */     }
/* 3621 */     d = this._inputBuffer[this._inputPtr++];
/* 3622 */     if ((d & 0xC0) != 128) {
/* 3623 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void _skipCR() throws IOException {
/* 3637 */     if ((this._inputPtr < this._inputEnd || _loadMore()) && 
/* 3638 */       this._inputBuffer[this._inputPtr] == 10) {
/* 3639 */       this._inputPtr++;
/*      */     }
/*      */     
/* 3642 */     this._currInputRow++;
/* 3643 */     this._currInputRowStart = this._inputPtr;
/*      */   }
/*      */ 
/*      */   
/*      */   private int nextByte() throws IOException {
/* 3648 */     if (this._inputPtr >= this._inputEnd) {
/* 3649 */       _loadMoreGuaranteed();
/*      */     }
/* 3651 */     return this._inputBuffer[this._inputPtr++] & 0xFF;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _reportInvalidToken(String matchedPart, int ptr) throws IOException {
/* 3661 */     this._inputPtr = ptr;
/* 3662 */     _reportInvalidToken(matchedPart, _validJsonTokenList());
/*      */   }
/*      */   
/*      */   protected void _reportInvalidToken(String matchedPart) throws IOException {
/* 3666 */     _reportInvalidToken(matchedPart, _validJsonTokenList());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _reportInvalidToken(String matchedPart, String msg) throws IOException {
/* 3675 */     StringBuilder sb = new StringBuilder(matchedPart);
/* 3676 */     while (this._inputPtr < this._inputEnd || _loadMore()) {
/* 3677 */       int i = this._inputBuffer[this._inputPtr++];
/* 3678 */       char c = (char)_decodeCharForError(i);
/* 3679 */       if (!Character.isJavaIdentifierPart(c)) {
/*      */         break;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3687 */       sb.append(c);
/* 3688 */       if (sb.length() >= 256) {
/* 3689 */         sb.append("...");
/*      */         break;
/*      */       } 
/*      */     } 
/* 3693 */     _reportError("Unrecognized token '%s': was expecting %s", sb, msg);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _reportInvalidChar(int c) throws JsonParseException {
/* 3699 */     if (c < 32) {
/* 3700 */       _throwInvalidSpace(c);
/*      */     }
/* 3702 */     _reportInvalidInitial(c);
/*      */   }
/*      */   
/*      */   protected void _reportInvalidInitial(int mask) throws JsonParseException {
/* 3706 */     _reportError("Invalid UTF-8 start byte 0x" + Integer.toHexString(mask));
/*      */   }
/*      */   
/*      */   protected void _reportInvalidOther(int mask) throws JsonParseException {
/* 3710 */     _reportError("Invalid UTF-8 middle byte 0x" + Integer.toHexString(mask));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _reportInvalidOther(int mask, int ptr) throws JsonParseException {
/* 3716 */     this._inputPtr = ptr;
/* 3717 */     _reportInvalidOther(mask);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final byte[] _decodeBase64(Base64Variant b64variant) throws IOException {
/* 3740 */     ByteArrayBuilder builder = _getByteArrayBuilder();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/* 3746 */       if (this._inputPtr >= this._inputEnd) {
/* 3747 */         _loadMoreGuaranteed();
/*      */       }
/* 3749 */       int ch = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 3750 */       if (ch > 32) {
/* 3751 */         int bits = b64variant.decodeBase64Char(ch);
/* 3752 */         if (bits < 0) {
/* 3753 */           if (ch == 34) {
/* 3754 */             return builder.toByteArray();
/*      */           }
/* 3756 */           bits = _decodeBase64Escape(b64variant, ch, 0);
/* 3757 */           if (bits < 0) {
/*      */             continue;
/*      */           }
/*      */         } 
/* 3761 */         int decodedData = bits;
/*      */ 
/*      */ 
/*      */         
/* 3765 */         if (this._inputPtr >= this._inputEnd) {
/* 3766 */           _loadMoreGuaranteed();
/*      */         }
/* 3768 */         ch = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 3769 */         bits = b64variant.decodeBase64Char(ch);
/* 3770 */         if (bits < 0) {
/* 3771 */           bits = _decodeBase64Escape(b64variant, ch, 1);
/*      */         }
/* 3773 */         decodedData = decodedData << 6 | bits;
/*      */ 
/*      */         
/* 3776 */         if (this._inputPtr >= this._inputEnd) {
/* 3777 */           _loadMoreGuaranteed();
/*      */         }
/* 3779 */         ch = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 3780 */         bits = b64variant.decodeBase64Char(ch);
/*      */ 
/*      */         
/* 3783 */         if (bits < 0) {
/* 3784 */           if (bits != -2) {
/*      */             
/* 3786 */             if (ch == 34) {
/* 3787 */               decodedData >>= 4;
/* 3788 */               builder.append(decodedData);
/* 3789 */               if (b64variant.usesPadding()) {
/* 3790 */                 this._inputPtr--;
/* 3791 */                 _handleBase64MissingPadding(b64variant);
/*      */               } 
/* 3793 */               return builder.toByteArray();
/*      */             } 
/* 3795 */             bits = _decodeBase64Escape(b64variant, ch, 2);
/*      */           } 
/* 3797 */           if (bits == -2) {
/*      */             
/* 3799 */             if (this._inputPtr >= this._inputEnd) {
/* 3800 */               _loadMoreGuaranteed();
/*      */             }
/* 3802 */             ch = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 3803 */             if (!b64variant.usesPaddingChar(ch) && 
/* 3804 */               _decodeBase64Escape(b64variant, ch, 3) != -2) {
/* 3805 */               throw reportInvalidBase64Char(b64variant, ch, 3, "expected padding character '" + b64variant.getPaddingChar() + "'");
/*      */             }
/*      */ 
/*      */             
/* 3809 */             decodedData >>= 4;
/* 3810 */             builder.append(decodedData);
/*      */             
/*      */             continue;
/*      */           } 
/*      */         } 
/* 3815 */         decodedData = decodedData << 6 | bits;
/*      */         
/* 3817 */         if (this._inputPtr >= this._inputEnd) {
/* 3818 */           _loadMoreGuaranteed();
/*      */         }
/* 3820 */         ch = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 3821 */         bits = b64variant.decodeBase64Char(ch);
/* 3822 */         if (bits < 0) {
/* 3823 */           if (bits != -2) {
/*      */             
/* 3825 */             if (ch == 34) {
/* 3826 */               decodedData >>= 2;
/* 3827 */               builder.appendTwoBytes(decodedData);
/* 3828 */               if (b64variant.usesPadding()) {
/* 3829 */                 this._inputPtr--;
/* 3830 */                 _handleBase64MissingPadding(b64variant);
/*      */               } 
/* 3832 */               return builder.toByteArray();
/*      */             } 
/* 3834 */             bits = _decodeBase64Escape(b64variant, ch, 3);
/*      */           } 
/* 3836 */           if (bits == -2) {
/*      */ 
/*      */ 
/*      */             
/* 3840 */             decodedData >>= 2;
/* 3841 */             builder.appendTwoBytes(decodedData);
/*      */             
/*      */             continue;
/*      */           } 
/*      */         } 
/* 3846 */         decodedData = decodedData << 6 | bits;
/* 3847 */         builder.appendThreeBytes(decodedData);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonLocation getTokenLocation() {
/* 3861 */     if (this._currToken == JsonToken.FIELD_NAME) {
/* 3862 */       long total = this._currInputProcessed + (this._nameStartOffset - 1);
/* 3863 */       return new JsonLocation(_contentReference(), total, -1L, this._nameStartRow, this._nameStartCol);
/*      */     } 
/*      */     
/* 3866 */     return new JsonLocation(_contentReference(), this._tokenInputTotal - 1L, -1L, this._tokenInputRow, this._tokenInputCol);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonLocation getCurrentLocation() {
/* 3874 */     int col = this._inputPtr - this._currInputRowStart + 1;
/* 3875 */     return new JsonLocation(_contentReference(), this._currInputProcessed + this._inputPtr, -1L, this._currInputRow, col);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _updateLocation() {
/* 3883 */     this._tokenInputRow = this._currInputRow;
/* 3884 */     int ptr = this._inputPtr;
/* 3885 */     this._tokenInputTotal = this._currInputProcessed + ptr;
/* 3886 */     this._tokenInputCol = ptr - this._currInputRowStart;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _updateNameLocation() {
/* 3892 */     this._nameStartRow = this._currInputRow;
/* 3893 */     int ptr = this._inputPtr;
/* 3894 */     this._nameStartOffset = ptr;
/* 3895 */     this._nameStartCol = ptr - this._currInputRowStart;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final JsonToken _closeScope(int i) throws JsonParseException {
/* 3905 */     if (i == 125) {
/* 3906 */       _closeObjectScope();
/* 3907 */       return this._currToken = JsonToken.END_OBJECT;
/*      */     } 
/* 3909 */     _closeArrayScope();
/* 3910 */     return this._currToken = JsonToken.END_ARRAY;
/*      */   }
/*      */   
/*      */   private final void _closeArrayScope() throws JsonParseException {
/* 3914 */     _updateLocation();
/* 3915 */     if (!this._parsingContext.inArray()) {
/* 3916 */       _reportMismatchedEndMarker(93, '}');
/*      */     }
/* 3918 */     this._parsingContext = this._parsingContext.clearAndGetParent();
/*      */   }
/*      */   
/*      */   private final void _closeObjectScope() throws JsonParseException {
/* 3922 */     _updateLocation();
/* 3923 */     if (!this._parsingContext.inObject()) {
/* 3924 */       _reportMismatchedEndMarker(125, ']');
/*      */     }
/* 3926 */     this._parsingContext = this._parsingContext.clearAndGetParent();
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-core-2.14.2.jar!\com\fasterxml\jackson\core\json\UTF8StreamJsonParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */