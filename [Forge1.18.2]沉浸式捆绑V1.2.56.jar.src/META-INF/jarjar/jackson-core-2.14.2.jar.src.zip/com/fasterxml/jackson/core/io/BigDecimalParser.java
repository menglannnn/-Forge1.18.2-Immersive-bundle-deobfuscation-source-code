/*     */ package com.fasterxml.jackson.core.io;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class BigDecimalParser
/*     */ {
/*     */   private static final int MAX_CHARS_TO_REPORT = 1000;
/*     */   
/*     */   public static BigDecimal parse(String valueStr) {
/*  29 */     return parse(valueStr.toCharArray());
/*     */   }
/*     */   
/*     */   public static BigDecimal parse(char[] chars, int off, int len) {
/*     */     try {
/*  34 */       if (len < 500) {
/*  35 */         return new BigDecimal(chars, off, len);
/*     */       }
/*  37 */       return parseBigDecimal(chars, off, len, len / 10);
/*     */ 
/*     */     
/*     */     }
/*  41 */     catch (ArithmeticException|NumberFormatException e) {
/*  42 */       String stringToReport, desc = e.getMessage();
/*     */       
/*  44 */       if (desc == null) {
/*  45 */         desc = "Not a valid number representation";
/*     */       }
/*     */       
/*  48 */       if (len <= 1000) {
/*  49 */         stringToReport = new String(chars, off, len);
/*     */       } else {
/*  51 */         stringToReport = new String(Arrays.copyOfRange(chars, off, 1000)) + "(truncated, full length is " + chars.length + " chars)";
/*     */       } 
/*     */       
/*  54 */       throw new NumberFormatException("Value \"" + stringToReport + "\" can not be represented as `java.math.BigDecimal`, reason: " + desc);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static BigDecimal parse(char[] chars) {
/*  60 */     return parse(chars, 0, chars.length);
/*     */   } private static BigDecimal parseBigDecimal(char[] chars, int off, int len, int splitLen) {
/*     */     int numEndIdx;
/*     */     BigDecimal res;
/*  64 */     boolean numHasSign = false;
/*  65 */     boolean expHasSign = false;
/*  66 */     boolean neg = false;
/*  67 */     int numIdx = off;
/*  68 */     int expIdx = -1;
/*  69 */     int dotIdx = -1;
/*  70 */     int scale = 0;
/*  71 */     int endIdx = off + len;
/*     */     
/*  73 */     for (int i = off; i < endIdx; i++) {
/*  74 */       char c = chars[i];
/*  75 */       switch (c) {
/*     */         case '+':
/*  77 */           if (expIdx >= 0) {
/*  78 */             if (expHasSign) {
/*  79 */               throw new NumberFormatException("Multiple signs in exponent");
/*     */             }
/*  81 */             expHasSign = true; break;
/*     */           } 
/*  83 */           if (numHasSign) {
/*  84 */             throw new NumberFormatException("Multiple signs in number");
/*     */           }
/*  86 */           numHasSign = true;
/*  87 */           numIdx = i + 1;
/*     */           break;
/*     */         
/*     */         case '-':
/*  91 */           if (expIdx >= 0) {
/*  92 */             if (expHasSign) {
/*  93 */               throw new NumberFormatException("Multiple signs in exponent");
/*     */             }
/*  95 */             expHasSign = true; break;
/*     */           } 
/*  97 */           if (numHasSign) {
/*  98 */             throw new NumberFormatException("Multiple signs in number");
/*     */           }
/* 100 */           numHasSign = true;
/* 101 */           neg = true;
/* 102 */           numIdx = i + 1;
/*     */           break;
/*     */         
/*     */         case 'E':
/*     */         case 'e':
/* 107 */           if (expIdx >= 0) {
/* 108 */             throw new NumberFormatException("Multiple exponent markers");
/*     */           }
/* 110 */           expIdx = i;
/*     */           break;
/*     */         case '.':
/* 113 */           if (dotIdx >= 0) {
/* 114 */             throw new NumberFormatException("Multiple decimal points");
/*     */           }
/* 116 */           dotIdx = i;
/*     */           break;
/*     */         default:
/* 119 */           if (dotIdx >= 0 && expIdx == -1) {
/* 120 */             scale++;
/*     */           }
/*     */           break;
/*     */       } 
/*     */     
/*     */     } 
/* 126 */     int exp = 0;
/* 127 */     if (expIdx >= 0) {
/* 128 */       numEndIdx = expIdx;
/* 129 */       String expStr = new String(chars, expIdx + 1, endIdx - expIdx - 1);
/* 130 */       exp = Integer.parseInt(expStr);
/* 131 */       scale = adjustScale(scale, exp);
/*     */     } else {
/* 133 */       numEndIdx = endIdx;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 138 */     if (dotIdx >= 0) {
/* 139 */       int leftLen = dotIdx - numIdx;
/* 140 */       BigDecimal left = toBigDecimalRec(chars, numIdx, leftLen, exp, splitLen);
/*     */       
/* 142 */       int rightLen = numEndIdx - dotIdx - 1;
/* 143 */       BigDecimal right = toBigDecimalRec(chars, dotIdx + 1, rightLen, exp - rightLen, splitLen);
/*     */       
/* 145 */       res = left.add(right);
/*     */     } else {
/* 147 */       res = toBigDecimalRec(chars, numIdx, numEndIdx - numIdx, exp, splitLen);
/*     */     } 
/*     */     
/* 150 */     if (scale != 0) {
/* 151 */       res = res.setScale(scale);
/*     */     }
/*     */     
/* 154 */     if (neg) {
/* 155 */       res = res.negate();
/*     */     }
/*     */     
/* 158 */     return res;
/*     */   }
/*     */   
/*     */   private static int adjustScale(int scale, long exp) {
/* 162 */     long adjScale = scale - exp;
/* 163 */     if (adjScale > 2147483647L || adjScale < -2147483648L) {
/* 164 */       throw new NumberFormatException("Scale out of range: " + adjScale + " while adjusting scale " + scale + " to exponent " + exp);
/*     */     }
/*     */ 
/*     */     
/* 168 */     return (int)adjScale;
/*     */   }
/*     */ 
/*     */   
/*     */   private static BigDecimal toBigDecimalRec(char[] chars, int off, int len, int scale, int splitLen) {
/* 173 */     if (len > splitLen) {
/* 174 */       int mid = len / 2;
/* 175 */       BigDecimal left = toBigDecimalRec(chars, off, mid, scale + len - mid, splitLen);
/* 176 */       BigDecimal right = toBigDecimalRec(chars, off + mid, len - mid, scale, splitLen);
/*     */       
/* 178 */       return left.add(right);
/*     */     } 
/*     */     
/* 181 */     return (len == 0) ? BigDecimal.ZERO : (new BigDecimal(chars, off, len)).movePointRight(scale);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-core-2.14.2.jar!\com\fasterxml\jackson\core\io\BigDecimalParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */