/*      */ package com.fasterxml.jackson.core.json.async;
/*      */ 
/*      */ import com.fasterxml.jackson.core.JsonParser;
/*      */ import com.fasterxml.jackson.core.JsonToken;
/*      */ import com.fasterxml.jackson.core.io.CharTypes;
/*      */ import com.fasterxml.jackson.core.io.IOContext;
/*      */ import com.fasterxml.jackson.core.json.JsonReadFeature;
/*      */ import com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer;
/*      */ import com.fasterxml.jackson.core.util.VersionUtil;
/*      */ import java.io.IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class NonBlockingUtf8JsonParserBase
/*      */   extends NonBlockingJsonParserBase
/*      */ {
/*   25 */   private static final int FEAT_MASK_TRAILING_COMMA = JsonParser.Feature.ALLOW_TRAILING_COMMA.getMask();
/*      */   
/*   27 */   private static final int FEAT_MASK_LEADING_ZEROS = JsonParser.Feature.ALLOW_NUMERIC_LEADING_ZEROS.getMask();
/*      */   
/*   29 */   private static final int FEAT_MASK_ALLOW_MISSING = JsonParser.Feature.ALLOW_MISSING_VALUES.getMask();
/*   30 */   private static final int FEAT_MASK_ALLOW_SINGLE_QUOTES = JsonParser.Feature.ALLOW_SINGLE_QUOTES.getMask();
/*   31 */   private static final int FEAT_MASK_ALLOW_UNQUOTED_NAMES = JsonParser.Feature.ALLOW_UNQUOTED_FIELD_NAMES.getMask();
/*   32 */   private static final int FEAT_MASK_ALLOW_JAVA_COMMENTS = JsonParser.Feature.ALLOW_COMMENTS.getMask();
/*   33 */   private static final int FEAT_MASK_ALLOW_YAML_COMMENTS = JsonParser.Feature.ALLOW_YAML_COMMENTS.getMask();
/*      */ 
/*      */   
/*   36 */   private static final int[] _icUTF8 = CharTypes.getInputCodeUtf8();
/*      */ 
/*      */ 
/*      */   
/*   40 */   protected static final int[] _icLatin1 = CharTypes.getInputCodeLatin1();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _origBufferLen;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected NonBlockingUtf8JsonParserBase(IOContext ctxt, int parserFeatures, ByteQuadsCanonicalizer sym) {
/*   65 */     super(ctxt, parserFeatures, sym);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean needMoreInput() {
/*   75 */     return (this._inputPtr >= this._inputEnd && !this._endOfInput);
/*      */   }
/*      */   
/*      */   public void endOfInput() {
/*   79 */     this._endOfInput = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected char _decodeEscaped() throws IOException {
/*  103 */     VersionUtil.throwInternal();
/*  104 */     return ' ';
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonToken nextToken() throws IOException {
/*  118 */     if (this._inputPtr >= this._inputEnd) {
/*  119 */       if (this._closed) {
/*  120 */         return null;
/*      */       }
/*      */       
/*  123 */       if (this._endOfInput) {
/*      */ 
/*      */         
/*  126 */         if (this._currToken == JsonToken.NOT_AVAILABLE) {
/*  127 */           return _finishTokenWithEOF();
/*      */         }
/*  129 */         return _eofAsNextToken();
/*      */       } 
/*  131 */       return JsonToken.NOT_AVAILABLE;
/*      */     } 
/*      */     
/*  134 */     if (this._currToken == JsonToken.NOT_AVAILABLE) {
/*  135 */       return _finishToken();
/*      */     }
/*      */ 
/*      */     
/*  139 */     this._numTypesValid = 0;
/*  140 */     this._tokenInputTotal = this._currInputProcessed + this._inputPtr;
/*      */     
/*  142 */     this._binaryValue = null;
/*  143 */     int ch = getNextUnsignedByteFromBuffer();
/*      */     
/*  145 */     switch (this._majorState) {
/*      */       case 0:
/*  147 */         return _startDocument(ch);
/*      */       
/*      */       case 1:
/*  150 */         return _startValue(ch);
/*      */       
/*      */       case 2:
/*  153 */         return _startFieldName(ch);
/*      */       case 3:
/*  155 */         return _startFieldNameAfterComma(ch);
/*      */       
/*      */       case 4:
/*  158 */         return _startValueExpectColon(ch);
/*      */       
/*      */       case 5:
/*  161 */         return _startValue(ch);
/*      */       
/*      */       case 6:
/*  164 */         return _startValueExpectComma(ch);
/*      */     } 
/*      */ 
/*      */     
/*  168 */     VersionUtil.throwInternal();
/*  169 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected abstract byte getNextSignedByteFromBuffer();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected abstract int getNextUnsignedByteFromBuffer();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected abstract byte getByteFromBuffer(int paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final JsonToken _finishToken() throws IOException {
/*      */     int c;
/*  203 */     switch (this._minorState) {
/*      */       case 1:
/*  205 */         return _finishBOM(this._pending32);
/*      */       case 4:
/*  207 */         return _startFieldName(getNextUnsignedByteFromBuffer());
/*      */       case 5:
/*  209 */         return _startFieldNameAfterComma(getNextUnsignedByteFromBuffer());
/*      */ 
/*      */       
/*      */       case 7:
/*  213 */         return _parseEscapedName(this._quadLength, this._pending32, this._pendingBytes);
/*      */       case 8:
/*  215 */         return _finishFieldWithEscape();
/*      */       case 9:
/*  217 */         return _finishAposName(this._quadLength, this._pending32, this._pendingBytes);
/*      */       case 10:
/*  219 */         return _finishUnquotedName(this._quadLength, this._pending32, this._pendingBytes);
/*      */ 
/*      */ 
/*      */       
/*      */       case 12:
/*  224 */         return _startValue(getNextUnsignedByteFromBuffer());
/*      */       case 15:
/*  226 */         return _startValueAfterComma(getNextUnsignedByteFromBuffer());
/*      */       case 13:
/*  228 */         return _startValueExpectComma(getNextUnsignedByteFromBuffer());
/*      */       case 14:
/*  230 */         return _startValueExpectColon(getNextUnsignedByteFromBuffer());
/*      */       
/*      */       case 16:
/*  233 */         return _finishKeywordToken("null", this._pending32, JsonToken.VALUE_NULL);
/*      */       case 17:
/*  235 */         return _finishKeywordToken("true", this._pending32, JsonToken.VALUE_TRUE);
/*      */       case 18:
/*  237 */         return _finishKeywordToken("false", this._pending32, JsonToken.VALUE_FALSE);
/*      */       case 19:
/*  239 */         return _finishNonStdToken(this._nonStdTokenType, this._pending32);
/*      */       
/*      */       case 22:
/*  242 */         return _finishNumberPlus(getNextUnsignedByteFromBuffer());
/*      */       case 23:
/*  244 */         return _finishNumberMinus(getNextUnsignedByteFromBuffer());
/*      */       case 24:
/*  246 */         return _finishNumberLeadingZeroes();
/*      */       case 25:
/*  248 */         return _finishNumberLeadingNegZeroes();
/*      */       case 26:
/*  250 */         return _finishNumberIntegralPart(this._textBuffer.getBufferWithoutReset(), this._textBuffer
/*  251 */             .getCurrentSegmentSize());
/*      */       case 30:
/*  253 */         return _finishFloatFraction();
/*      */       case 31:
/*  255 */         return _finishFloatExponent(true, getNextUnsignedByteFromBuffer());
/*      */       case 32:
/*  257 */         return _finishFloatExponent(false, getNextUnsignedByteFromBuffer());
/*      */       
/*      */       case 40:
/*  260 */         return _finishRegularString();
/*      */       case 42:
/*  262 */         this._textBuffer.append((char)_decodeUTF8_2(this._pending32, getNextSignedByteFromBuffer()));
/*  263 */         if (this._minorStateAfterSplit == 45) {
/*  264 */           return _finishAposString();
/*      */         }
/*  266 */         return _finishRegularString();
/*      */       case 43:
/*  268 */         if (!_decodeSplitUTF8_3(this._pending32, this._pendingBytes, getNextSignedByteFromBuffer())) {
/*  269 */           return JsonToken.NOT_AVAILABLE;
/*      */         }
/*  271 */         if (this._minorStateAfterSplit == 45) {
/*  272 */           return _finishAposString();
/*      */         }
/*  274 */         return _finishRegularString();
/*      */       case 44:
/*  276 */         if (!_decodeSplitUTF8_4(this._pending32, this._pendingBytes, getNextSignedByteFromBuffer())) {
/*  277 */           return JsonToken.NOT_AVAILABLE;
/*      */         }
/*  279 */         if (this._minorStateAfterSplit == 45) {
/*  280 */           return _finishAposString();
/*      */         }
/*  282 */         return _finishRegularString();
/*      */ 
/*      */       
/*      */       case 41:
/*  286 */         c = _decodeSplitEscaped(this._quoted32, this._quotedDigits);
/*  287 */         if (c < 0) {
/*  288 */           return JsonToken.NOT_AVAILABLE;
/*      */         }
/*  290 */         this._textBuffer.append((char)c);
/*      */         
/*  292 */         if (this._minorStateAfterSplit == 45) {
/*  293 */           return _finishAposString();
/*      */         }
/*  295 */         return _finishRegularString();
/*      */       
/*      */       case 45:
/*  298 */         return _finishAposString();
/*      */       
/*      */       case 50:
/*  301 */         return _finishErrorToken();
/*      */ 
/*      */ 
/*      */       
/*      */       case 51:
/*  306 */         return _startSlashComment(this._pending32);
/*      */       case 52:
/*  308 */         return _finishCComment(this._pending32, true);
/*      */       case 53:
/*  310 */         return _finishCComment(this._pending32, false);
/*      */       case 54:
/*  312 */         return _finishCppComment(this._pending32);
/*      */       case 55:
/*  314 */         return _finishHashComment(this._pending32);
/*      */     } 
/*  316 */     VersionUtil.throwInternal();
/*  317 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final JsonToken _finishTokenWithEOF() throws IOException {
/*      */     int len;
/*  333 */     JsonToken t = this._currToken;
/*  334 */     switch (this._minorState) {
/*      */       case 3:
/*  336 */         return _eofAsNextToken();
/*      */       case 12:
/*  338 */         return _eofAsNextToken();
/*      */ 
/*      */       
/*      */       case 16:
/*  342 */         return _finishKeywordTokenWithEOF("null", this._pending32, JsonToken.VALUE_NULL);
/*      */       case 17:
/*  344 */         return _finishKeywordTokenWithEOF("true", this._pending32, JsonToken.VALUE_TRUE);
/*      */       case 18:
/*  346 */         return _finishKeywordTokenWithEOF("false", this._pending32, JsonToken.VALUE_FALSE);
/*      */       case 19:
/*  348 */         return _finishNonStdTokenWithEOF(this._nonStdTokenType, this._pending32);
/*      */       case 50:
/*  350 */         return _finishErrorTokenWithEOF();
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 24:
/*      */       case 25:
/*  357 */         return _valueCompleteInt(0, "0");
/*      */ 
/*      */       
/*      */       case 26:
/*  361 */         len = this._textBuffer.getCurrentSegmentSize();
/*  362 */         if (this._numberNegative) {
/*  363 */           len--;
/*      */         }
/*  365 */         this._intLength = len;
/*      */         
/*  367 */         return _valueComplete(JsonToken.VALUE_NUMBER_INT);
/*      */       
/*      */       case 30:
/*  370 */         this._expLength = 0;
/*      */       
/*      */       case 32:
/*  373 */         return _valueComplete(JsonToken.VALUE_NUMBER_FLOAT);
/*      */       
/*      */       case 31:
/*  376 */         _reportInvalidEOF(": was expecting fraction after exponent marker", JsonToken.VALUE_NUMBER_FLOAT);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 52:
/*      */       case 53:
/*  384 */         _reportInvalidEOF(": was expecting closing '*/' for comment", JsonToken.NOT_AVAILABLE);
/*      */ 
/*      */       
/*      */       case 54:
/*      */       case 55:
/*  389 */         return _eofAsNextToken();
/*      */     } 
/*      */ 
/*      */     
/*  393 */     _reportInvalidEOF(": was expecting rest of token (internal state: " + this._minorState + ")", this._currToken);
/*  394 */     return t;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final JsonToken _startDocument(int ch) throws IOException {
/*  405 */     ch &= 0xFF;
/*      */ 
/*      */     
/*  408 */     if (ch == 239 && this._minorState != 1) {
/*  409 */       return _finishBOM(1);
/*      */     }
/*      */ 
/*      */     
/*  413 */     while (ch <= 32) {
/*  414 */       if (ch != 32) {
/*  415 */         if (ch == 10) {
/*  416 */           this._currInputRow++;
/*  417 */           this._currInputRowStart = this._inputPtr;
/*  418 */         } else if (ch == 13) {
/*  419 */           this._currInputRowAlt++;
/*  420 */           this._currInputRowStart = this._inputPtr;
/*  421 */         } else if (ch != 9) {
/*  422 */           _throwInvalidSpace(ch);
/*      */         } 
/*      */       }
/*  425 */       if (this._inputPtr >= this._inputEnd) {
/*  426 */         this._minorState = 3;
/*  427 */         if (this._closed) {
/*  428 */           return null;
/*      */         }
/*      */         
/*  431 */         if (this._endOfInput) {
/*  432 */           return _eofAsNextToken();
/*      */         }
/*  434 */         return JsonToken.NOT_AVAILABLE;
/*      */       } 
/*  436 */       ch = getNextUnsignedByteFromBuffer();
/*      */     } 
/*  438 */     return _startValue(ch);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final JsonToken _finishBOM(int bytesHandled) throws IOException {
/*  447 */     while (this._inputPtr < this._inputEnd) {
/*  448 */       int ch = getNextUnsignedByteFromBuffer();
/*  449 */       switch (bytesHandled) {
/*      */ 
/*      */         
/*      */         case 3:
/*  453 */           this._currInputProcessed -= 3L;
/*  454 */           return _startDocument(ch);
/*      */         case 2:
/*  456 */           if (ch != 191) {
/*  457 */             _reportError("Unexpected byte 0x%02x following 0xEF 0xBB; should get 0xBF as third byte of UTF-8 BOM", Integer.valueOf(ch));
/*      */           }
/*      */           break;
/*      */         case 1:
/*  461 */           if (ch != 187) {
/*  462 */             _reportError("Unexpected byte 0x%02x following 0xEF; should get 0xBB as second byte UTF-8 BOM", Integer.valueOf(ch));
/*      */           }
/*      */           break;
/*      */       } 
/*  466 */       bytesHandled++;
/*      */     } 
/*  468 */     this._pending32 = bytesHandled;
/*  469 */     this._minorState = 1;
/*  470 */     return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final JsonToken _startFieldName(int ch) throws IOException {
/*  486 */     if (ch <= 32) {
/*  487 */       ch = _skipWS(ch);
/*  488 */       if (ch <= 0) {
/*  489 */         this._minorState = 4;
/*  490 */         return this._currToken;
/*      */       } 
/*      */     } 
/*  493 */     _updateTokenLocation();
/*  494 */     if (ch != 34) {
/*  495 */       if (ch == 125) {
/*  496 */         return _closeObjectScope();
/*      */       }
/*  498 */       return _handleOddName(ch);
/*      */     } 
/*      */     
/*  501 */     if (this._inputPtr + 13 <= this._inputEnd) {
/*  502 */       String n = _fastParseName();
/*  503 */       if (n != null) {
/*  504 */         return _fieldComplete(n);
/*      */       }
/*      */     } 
/*  507 */     return _parseEscapedName(0, 0, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final JsonToken _startFieldNameAfterComma(int ch) throws IOException {
/*  513 */     if (ch <= 32) {
/*  514 */       ch = _skipWS(ch);
/*  515 */       if (ch <= 0) {
/*  516 */         this._minorState = 5;
/*  517 */         return this._currToken;
/*      */       } 
/*      */     } 
/*  520 */     if (ch != 44) {
/*  521 */       if (ch == 125) {
/*  522 */         return _closeObjectScope();
/*      */       }
/*  524 */       if (ch == 35) {
/*  525 */         return _finishHashComment(5);
/*      */       }
/*  527 */       if (ch == 47) {
/*  528 */         return _startSlashComment(5);
/*      */       }
/*  530 */       _reportUnexpectedChar(ch, "was expecting comma to separate " + this._parsingContext.typeDesc() + " entries");
/*      */     } 
/*  532 */     int ptr = this._inputPtr;
/*  533 */     if (ptr >= this._inputEnd) {
/*  534 */       this._minorState = 4;
/*  535 */       return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */     } 
/*  537 */     ch = getByteFromBuffer(ptr);
/*  538 */     this._inputPtr = ptr + 1;
/*  539 */     if (ch <= 32) {
/*  540 */       ch = _skipWS(ch);
/*  541 */       if (ch <= 0) {
/*  542 */         this._minorState = 4;
/*  543 */         return this._currToken;
/*      */       } 
/*      */     } 
/*  546 */     _updateTokenLocation();
/*  547 */     if (ch != 34) {
/*  548 */       if (ch == 125 && (
/*  549 */         this._features & FEAT_MASK_TRAILING_COMMA) != 0) {
/*  550 */         return _closeObjectScope();
/*      */       }
/*      */       
/*  553 */       return _handleOddName(ch);
/*      */     } 
/*      */     
/*  556 */     if (this._inputPtr + 13 <= this._inputEnd) {
/*  557 */       String n = _fastParseName();
/*  558 */       if (n != null) {
/*  559 */         return _fieldComplete(n);
/*      */       }
/*      */     } 
/*  562 */     return _parseEscapedName(0, 0, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final JsonToken _startValue(int ch) throws IOException {
/*  579 */     if (ch <= 32) {
/*  580 */       ch = _skipWS(ch);
/*  581 */       if (ch <= 0) {
/*  582 */         this._minorState = 12;
/*  583 */         return this._currToken;
/*      */       } 
/*      */     } 
/*  586 */     _updateTokenLocation();
/*      */     
/*  588 */     this._parsingContext.expectComma();
/*      */     
/*  590 */     if (ch == 34) {
/*  591 */       return _startString();
/*      */     }
/*  593 */     switch (ch) {
/*      */       case 35:
/*  595 */         return _finishHashComment(12);
/*      */       case 43:
/*  597 */         return _startPositiveNumber();
/*      */       case 45:
/*  599 */         return _startNegativeNumber();
/*      */       case 47:
/*  601 */         return _startSlashComment(12);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 46:
/*  608 */         if (isEnabled(JsonReadFeature.ALLOW_LEADING_DECIMAL_POINT_FOR_NUMBERS.mappedFeature())) {
/*  609 */           return _startFloatThatStartsWithPeriod();
/*      */         }
/*      */         break;
/*      */       
/*      */       case 48:
/*  614 */         return _startNumberLeadingZero();
/*      */       case 49:
/*      */       case 50:
/*      */       case 51:
/*      */       case 52:
/*      */       case 53:
/*      */       case 54:
/*      */       case 55:
/*      */       case 56:
/*      */       case 57:
/*  624 */         return _startPositiveNumber(ch);
/*      */       case 102:
/*  626 */         return _startFalseToken();
/*      */       case 110:
/*  628 */         return _startNullToken();
/*      */       case 116:
/*  630 */         return _startTrueToken();
/*      */       case 91:
/*  632 */         return _startArrayScope();
/*      */       case 93:
/*  634 */         return _closeArrayScope();
/*      */       case 123:
/*  636 */         return _startObjectScope();
/*      */       case 125:
/*  638 */         return _closeObjectScope();
/*      */     } 
/*      */     
/*  641 */     return _startUnexpectedValue(false, ch);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final JsonToken _startValueExpectComma(int ch) throws IOException {
/*  649 */     if (ch <= 32) {
/*  650 */       ch = _skipWS(ch);
/*  651 */       if (ch <= 0) {
/*  652 */         this._minorState = 13;
/*  653 */         return this._currToken;
/*      */       } 
/*      */     } 
/*  656 */     if (ch != 44) {
/*  657 */       if (ch == 93) {
/*  658 */         return _closeArrayScope();
/*      */       }
/*  660 */       if (ch == 125) {
/*  661 */         return _closeObjectScope();
/*      */       }
/*  663 */       if (ch == 47) {
/*  664 */         return _startSlashComment(13);
/*      */       }
/*  666 */       if (ch == 35) {
/*  667 */         return _finishHashComment(13);
/*      */       }
/*  669 */       _reportUnexpectedChar(ch, "was expecting comma to separate " + this._parsingContext.typeDesc() + " entries");
/*      */     } 
/*      */ 
/*      */     
/*  673 */     this._parsingContext.expectComma();
/*      */     
/*  675 */     int ptr = this._inputPtr;
/*  676 */     if (ptr >= this._inputEnd) {
/*  677 */       this._minorState = 15;
/*  678 */       return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */     } 
/*  680 */     ch = getByteFromBuffer(ptr);
/*  681 */     this._inputPtr = ptr + 1;
/*  682 */     if (ch <= 32) {
/*  683 */       ch = _skipWS(ch);
/*  684 */       if (ch <= 0) {
/*  685 */         this._minorState = 15;
/*  686 */         return this._currToken;
/*      */       } 
/*      */     } 
/*  689 */     _updateTokenLocation();
/*  690 */     if (ch == 34) {
/*  691 */       return _startString();
/*      */     }
/*  693 */     switch (ch) {
/*      */       case 35:
/*  695 */         return _finishHashComment(15);
/*      */       case 43:
/*  697 */         return _startPositiveNumber();
/*      */       case 45:
/*  699 */         return _startNegativeNumber();
/*      */       case 47:
/*  701 */         return _startSlashComment(15);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 48:
/*  707 */         return _startNumberLeadingZero();
/*      */       case 49: case 50: case 51: case 52:
/*      */       case 53:
/*      */       case 54:
/*      */       case 55:
/*      */       case 56:
/*      */       case 57:
/*  714 */         return _startPositiveNumber(ch);
/*      */       case 102:
/*  716 */         return _startFalseToken();
/*      */       case 110:
/*  718 */         return _startNullToken();
/*      */       case 116:
/*  720 */         return _startTrueToken();
/*      */       case 91:
/*  722 */         return _startArrayScope();
/*      */       
/*      */       case 93:
/*  725 */         if ((this._features & FEAT_MASK_TRAILING_COMMA) != 0) {
/*  726 */           return _closeArrayScope();
/*      */         }
/*      */         break;
/*      */       case 123:
/*  730 */         return _startObjectScope();
/*      */       
/*      */       case 125:
/*  733 */         if ((this._features & FEAT_MASK_TRAILING_COMMA) != 0) {
/*  734 */           return _closeObjectScope();
/*      */         }
/*      */         break;
/*      */     } 
/*      */     
/*  739 */     return _startUnexpectedValue(true, ch);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final JsonToken _startValueExpectColon(int ch) throws IOException {
/*  748 */     if (ch <= 32) {
/*  749 */       ch = _skipWS(ch);
/*  750 */       if (ch <= 0) {
/*  751 */         this._minorState = 14;
/*  752 */         return this._currToken;
/*      */       } 
/*      */     } 
/*  755 */     if (ch != 58) {
/*  756 */       if (ch == 47) {
/*  757 */         return _startSlashComment(14);
/*      */       }
/*  759 */       if (ch == 35) {
/*  760 */         return _finishHashComment(14);
/*      */       }
/*      */       
/*  763 */       _reportUnexpectedChar(ch, "was expecting a colon to separate field name and value");
/*      */     } 
/*  765 */     int ptr = this._inputPtr;
/*  766 */     if (ptr >= this._inputEnd) {
/*  767 */       this._minorState = 12;
/*  768 */       return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */     } 
/*  770 */     ch = getByteFromBuffer(ptr);
/*  771 */     this._inputPtr = ptr + 1;
/*  772 */     if (ch <= 32) {
/*  773 */       ch = _skipWS(ch);
/*  774 */       if (ch <= 0) {
/*  775 */         this._minorState = 12;
/*  776 */         return this._currToken;
/*      */       } 
/*      */     } 
/*  779 */     _updateTokenLocation();
/*  780 */     if (ch == 34) {
/*  781 */       return _startString();
/*      */     }
/*  783 */     switch (ch) {
/*      */       case 35:
/*  785 */         return _finishHashComment(12);
/*      */       case 43:
/*  787 */         return _startPositiveNumber();
/*      */       case 45:
/*  789 */         return _startNegativeNumber();
/*      */       case 47:
/*  791 */         return _startSlashComment(12);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 48:
/*  797 */         return _startNumberLeadingZero();
/*      */       case 49: case 50: case 51: case 52:
/*      */       case 53:
/*      */       case 54:
/*      */       case 55:
/*      */       case 56:
/*      */       case 57:
/*  804 */         return _startPositiveNumber(ch);
/*      */       case 102:
/*  806 */         return _startFalseToken();
/*      */       case 110:
/*  808 */         return _startNullToken();
/*      */       case 116:
/*  810 */         return _startTrueToken();
/*      */       case 91:
/*  812 */         return _startArrayScope();
/*      */       case 123:
/*  814 */         return _startObjectScope();
/*      */     } 
/*      */     
/*  817 */     return _startUnexpectedValue(false, ch);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final JsonToken _startValueAfterComma(int ch) throws IOException {
/*  824 */     if (ch <= 32) {
/*  825 */       ch = _skipWS(ch);
/*  826 */       if (ch <= 0) {
/*  827 */         this._minorState = 15;
/*  828 */         return this._currToken;
/*      */       } 
/*      */     } 
/*  831 */     _updateTokenLocation();
/*  832 */     if (ch == 34) {
/*  833 */       return _startString();
/*      */     }
/*  835 */     switch (ch) {
/*      */       case 35:
/*  837 */         return _finishHashComment(15);
/*      */       case 43:
/*  839 */         return _startPositiveNumber();
/*      */       case 45:
/*  841 */         return _startNegativeNumber();
/*      */       case 47:
/*  843 */         return _startSlashComment(15);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 48:
/*  849 */         return _startNumberLeadingZero();
/*      */       case 49:
/*      */       case 50:
/*      */       case 51:
/*      */       case 52:
/*      */       case 53:
/*      */       case 54:
/*      */       case 55:
/*      */       case 56:
/*      */       case 57:
/*  859 */         return _startPositiveNumber(ch);
/*      */       case 102:
/*  861 */         return _startFalseToken();
/*      */       case 110:
/*  863 */         return _startNullToken();
/*      */       case 116:
/*  865 */         return _startTrueToken();
/*      */       case 91:
/*  867 */         return _startArrayScope();
/*      */       
/*      */       case 93:
/*  870 */         if ((this._features & FEAT_MASK_TRAILING_COMMA) != 0) {
/*  871 */           return _closeArrayScope();
/*      */         }
/*      */         break;
/*      */       case 123:
/*  875 */         return _startObjectScope();
/*      */       
/*      */       case 125:
/*  878 */         if ((this._features & FEAT_MASK_TRAILING_COMMA) != 0) {
/*  879 */           return _closeObjectScope();
/*      */         }
/*      */         break;
/*      */     } 
/*      */     
/*  884 */     return _startUnexpectedValue(true, ch);
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _startUnexpectedValue(boolean leadingComma, int ch) throws IOException {
/*  889 */     switch (ch) {
/*      */       case 93:
/*  891 */         if (!this._parsingContext.inArray()) {
/*      */           break;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 44:
/*  900 */         if (!this._parsingContext.inRoot() && (
/*  901 */           this._features & FEAT_MASK_ALLOW_MISSING) != 0) {
/*  902 */           this._inputPtr--;
/*  903 */           return _valueComplete(JsonToken.VALUE_NULL);
/*      */         } 
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 39:
/*  912 */         if ((this._features & FEAT_MASK_ALLOW_SINGLE_QUOTES) != 0) {
/*  913 */           return _startAposString();
/*      */         }
/*      */         break;
/*      */       case 43:
/*  917 */         return _finishNonStdToken(2, 1);
/*      */       case 78:
/*  919 */         return _finishNonStdToken(0, 1);
/*      */       case 73:
/*  921 */         return _finishNonStdToken(1, 1);
/*      */     } 
/*      */     
/*  924 */     _reportUnexpectedChar(ch, "expected a valid value " + _validJsonValueList());
/*  925 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _skipWS(int ch) throws IOException {
/*      */     while (true) {
/*  937 */       if (ch != 32) {
/*  938 */         if (ch == 10) {
/*  939 */           this._currInputRow++;
/*  940 */           this._currInputRowStart = this._inputPtr;
/*  941 */         } else if (ch == 13) {
/*  942 */           this._currInputRowAlt++;
/*  943 */           this._currInputRowStart = this._inputPtr;
/*  944 */         } else if (ch != 9) {
/*  945 */           _throwInvalidSpace(ch);
/*      */         } 
/*      */       }
/*  948 */       if (this._inputPtr >= this._inputEnd) {
/*  949 */         this._currToken = JsonToken.NOT_AVAILABLE;
/*  950 */         return 0;
/*      */       } 
/*  952 */       ch = getNextUnsignedByteFromBuffer();
/*  953 */       if (ch > 32)
/*  954 */         return ch; 
/*      */     } 
/*      */   }
/*      */   
/*      */   private final JsonToken _startSlashComment(int fromMinorState) throws IOException {
/*  959 */     if ((this._features & FEAT_MASK_ALLOW_JAVA_COMMENTS) == 0) {
/*  960 */       _reportUnexpectedChar(47, "maybe a (non-standard) comment? (not recognized as one since Feature 'ALLOW_COMMENTS' not enabled for parser)");
/*      */     }
/*      */ 
/*      */     
/*  964 */     if (this._inputPtr >= this._inputEnd) {
/*  965 */       this._pending32 = fromMinorState;
/*  966 */       this._minorState = 51;
/*  967 */       return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */     } 
/*  969 */     int ch = getNextSignedByteFromBuffer();
/*  970 */     if (ch == 42) {
/*  971 */       return _finishCComment(fromMinorState, false);
/*      */     }
/*  973 */     if (ch == 47) {
/*  974 */       return _finishCppComment(fromMinorState);
/*      */     }
/*  976 */     _reportUnexpectedChar(ch & 0xFF, "was expecting either '*' or '/' for a comment");
/*  977 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final JsonToken _finishHashComment(int fromMinorState) throws IOException {
/*  983 */     if ((this._features & FEAT_MASK_ALLOW_YAML_COMMENTS) == 0) {
/*  984 */       _reportUnexpectedChar(35, "maybe a (non-standard) comment? (not recognized as one since Feature 'ALLOW_YAML_COMMENTS' not enabled for parser)");
/*      */     }
/*      */     while (true) {
/*  987 */       if (this._inputPtr >= this._inputEnd) {
/*  988 */         this._minorState = 55;
/*  989 */         this._pending32 = fromMinorState;
/*  990 */         return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */       } 
/*  992 */       int ch = getNextUnsignedByteFromBuffer();
/*  993 */       if (ch < 32) {
/*  994 */         if (ch == 10) {
/*  995 */           this._currInputRow++;
/*  996 */           this._currInputRowStart = this._inputPtr; break;
/*      */         } 
/*  998 */         if (ch == 13) {
/*  999 */           this._currInputRowAlt++;
/* 1000 */           this._currInputRowStart = this._inputPtr; break;
/*      */         } 
/* 1002 */         if (ch != 9) {
/* 1003 */           _throwInvalidSpace(ch);
/*      */         }
/*      */       } 
/*      */     } 
/* 1007 */     return _startAfterComment(fromMinorState);
/*      */   }
/*      */ 
/*      */   
/*      */   private final JsonToken _finishCppComment(int fromMinorState) throws IOException {
/*      */     while (true) {
/* 1013 */       if (this._inputPtr >= this._inputEnd) {
/* 1014 */         this._minorState = 54;
/* 1015 */         this._pending32 = fromMinorState;
/* 1016 */         return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */       } 
/* 1018 */       int ch = getNextUnsignedByteFromBuffer();
/* 1019 */       if (ch < 32) {
/* 1020 */         if (ch == 10) {
/* 1021 */           this._currInputRow++;
/* 1022 */           this._currInputRowStart = this._inputPtr; break;
/*      */         } 
/* 1024 */         if (ch == 13) {
/* 1025 */           this._currInputRowAlt++;
/* 1026 */           this._currInputRowStart = this._inputPtr; break;
/*      */         } 
/* 1028 */         if (ch != 9) {
/* 1029 */           _throwInvalidSpace(ch);
/*      */         }
/*      */       } 
/*      */     } 
/* 1033 */     return _startAfterComment(fromMinorState);
/*      */   }
/*      */ 
/*      */   
/*      */   private final JsonToken _finishCComment(int fromMinorState, boolean gotStar) throws IOException {
/*      */     while (true) {
/* 1039 */       if (this._inputPtr >= this._inputEnd) {
/* 1040 */         this._minorState = gotStar ? 52 : 53;
/* 1041 */         this._pending32 = fromMinorState;
/* 1042 */         return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */       } 
/* 1044 */       int ch = getNextUnsignedByteFromBuffer();
/* 1045 */       if (ch < 32)
/* 1046 */       { if (ch == 10) {
/* 1047 */           this._currInputRow++;
/* 1048 */           this._currInputRowStart = this._inputPtr;
/* 1049 */         } else if (ch == 13) {
/* 1050 */           this._currInputRowAlt++;
/* 1051 */           this._currInputRowStart = this._inputPtr;
/* 1052 */         } else if (ch != 9) {
/* 1053 */           _throwInvalidSpace(ch);
/*      */         }  }
/* 1055 */       else { if (ch == 42) {
/* 1056 */           gotStar = true; continue;
/*      */         } 
/* 1058 */         if (ch == 47 && 
/* 1059 */           gotStar) {
/*      */           break;
/*      */         } }
/*      */       
/* 1063 */       gotStar = false;
/*      */     } 
/* 1065 */     return _startAfterComment(fromMinorState);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final JsonToken _startAfterComment(int fromMinorState) throws IOException {
/* 1071 */     if (this._inputPtr >= this._inputEnd) {
/* 1072 */       this._minorState = fromMinorState;
/* 1073 */       return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */     } 
/* 1075 */     int ch = getNextUnsignedByteFromBuffer();
/* 1076 */     switch (fromMinorState) {
/*      */       case 4:
/* 1078 */         return _startFieldName(ch);
/*      */       case 5:
/* 1080 */         return _startFieldNameAfterComma(ch);
/*      */       case 12:
/* 1082 */         return _startValue(ch);
/*      */       case 13:
/* 1084 */         return _startValueExpectComma(ch);
/*      */       case 14:
/* 1086 */         return _startValueExpectColon(ch);
/*      */       case 15:
/* 1088 */         return _startValueAfterComma(ch);
/*      */     } 
/*      */     
/* 1091 */     VersionUtil.throwInternal();
/* 1092 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonToken _startFalseToken() throws IOException {
/* 1103 */     int ptr = this._inputPtr;
/* 1104 */     if (ptr + 4 < this._inputEnd && 
/* 1105 */       getByteFromBuffer(ptr++) == 97 && 
/* 1106 */       getByteFromBuffer(ptr++) == 108 && 
/* 1107 */       getByteFromBuffer(ptr++) == 115 && 
/* 1108 */       getByteFromBuffer(ptr++) == 101) {
/* 1109 */       int ch = getByteFromBuffer(ptr) & 0xFF;
/* 1110 */       if (ch < 48 || ch == 93 || ch == 125) {
/* 1111 */         this._inputPtr = ptr;
/* 1112 */         return _valueComplete(JsonToken.VALUE_FALSE);
/*      */       } 
/*      */     } 
/*      */     
/* 1116 */     this._minorState = 18;
/* 1117 */     return _finishKeywordToken("false", 1, JsonToken.VALUE_FALSE);
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _startTrueToken() throws IOException {
/* 1122 */     int ptr = this._inputPtr;
/* 1123 */     if (ptr + 3 < this._inputEnd && 
/* 1124 */       getByteFromBuffer(ptr++) == 114 && 
/* 1125 */       getByteFromBuffer(ptr++) == 117 && 
/* 1126 */       getByteFromBuffer(ptr++) == 101) {
/* 1127 */       int ch = getByteFromBuffer(ptr) & 0xFF;
/* 1128 */       if (ch < 48 || ch == 93 || ch == 125) {
/* 1129 */         this._inputPtr = ptr;
/* 1130 */         return _valueComplete(JsonToken.VALUE_TRUE);
/*      */       } 
/*      */     } 
/*      */     
/* 1134 */     this._minorState = 17;
/* 1135 */     return _finishKeywordToken("true", 1, JsonToken.VALUE_TRUE);
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _startNullToken() throws IOException {
/* 1140 */     int ptr = this._inputPtr;
/* 1141 */     if (ptr + 3 < this._inputEnd && 
/* 1142 */       getByteFromBuffer(ptr++) == 117 && 
/* 1143 */       getByteFromBuffer(ptr++) == 108 && 
/* 1144 */       getByteFromBuffer(ptr++) == 108) {
/* 1145 */       int ch = getByteFromBuffer(ptr) & 0xFF;
/* 1146 */       if (ch < 48 || ch == 93 || ch == 125) {
/* 1147 */         this._inputPtr = ptr;
/* 1148 */         return _valueComplete(JsonToken.VALUE_NULL);
/*      */       } 
/*      */     } 
/*      */     
/* 1152 */     this._minorState = 16;
/* 1153 */     return _finishKeywordToken("null", 1, JsonToken.VALUE_NULL);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonToken _finishKeywordToken(String expToken, int matched, JsonToken result) throws IOException {
/* 1159 */     int end = expToken.length();
/*      */     
/*      */     while (true) {
/* 1162 */       if (this._inputPtr >= this._inputEnd) {
/* 1163 */         this._pending32 = matched;
/* 1164 */         return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */       } 
/* 1166 */       int ch = getByteFromBuffer(this._inputPtr);
/* 1167 */       if (matched == end) {
/* 1168 */         if (ch < 48 || ch == 93 || ch == 125) {
/* 1169 */           return _valueComplete(result);
/*      */         }
/*      */         break;
/*      */       } 
/* 1173 */       if (ch != expToken.charAt(matched)) {
/*      */         break;
/*      */       }
/* 1176 */       matched++;
/* 1177 */       this._inputPtr++;
/*      */     } 
/* 1179 */     this._minorState = 50;
/* 1180 */     this._textBuffer.resetWithCopy(expToken, 0, matched);
/* 1181 */     return _finishErrorToken();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonToken _finishKeywordTokenWithEOF(String expToken, int matched, JsonToken result) throws IOException {
/* 1187 */     if (matched == expToken.length()) {
/* 1188 */       return this._currToken = result;
/*      */     }
/* 1190 */     this._textBuffer.resetWithCopy(expToken, 0, matched);
/* 1191 */     return _finishErrorTokenWithEOF();
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _finishNonStdToken(int type, int matched) throws IOException {
/* 1196 */     String expToken = _nonStdToken(type);
/* 1197 */     int end = expToken.length();
/*      */     
/*      */     while (true) {
/* 1200 */       if (this._inputPtr >= this._inputEnd) {
/* 1201 */         this._nonStdTokenType = type;
/* 1202 */         this._pending32 = matched;
/* 1203 */         this._minorState = 19;
/* 1204 */         return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */       } 
/* 1206 */       int ch = getByteFromBuffer(this._inputPtr);
/* 1207 */       if (matched == end) {
/* 1208 */         if (ch < 48 || ch == 93 || ch == 125) {
/* 1209 */           return _valueNonStdNumberComplete(type);
/*      */         }
/*      */         break;
/*      */       } 
/* 1213 */       if (ch != expToken.charAt(matched)) {
/*      */         break;
/*      */       }
/* 1216 */       matched++;
/* 1217 */       this._inputPtr++;
/*      */     } 
/* 1219 */     this._minorState = 50;
/* 1220 */     this._textBuffer.resetWithCopy(expToken, 0, matched);
/* 1221 */     return _finishErrorToken();
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _finishNonStdTokenWithEOF(int type, int matched) throws IOException {
/* 1226 */     String expToken = _nonStdToken(type);
/* 1227 */     if (matched == expToken.length()) {
/* 1228 */       return _valueNonStdNumberComplete(type);
/*      */     }
/* 1230 */     this._textBuffer.resetWithCopy(expToken, 0, matched);
/* 1231 */     return _finishErrorTokenWithEOF();
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _finishErrorToken() throws IOException {
/* 1236 */     while (this._inputPtr < this._inputEnd) {
/* 1237 */       int i = getNextSignedByteFromBuffer();
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1242 */       char ch = (char)i;
/* 1243 */       if (Character.isJavaIdentifierPart(ch)) {
/*      */ 
/*      */         
/* 1246 */         this._textBuffer.append(ch);
/* 1247 */         if (this._textBuffer.size() < 256) {
/*      */           continue;
/*      */         }
/*      */       } 
/* 1251 */       return _reportErrorToken(this._textBuffer.contentsAsString());
/*      */     } 
/* 1253 */     return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _finishErrorTokenWithEOF() throws IOException {
/* 1258 */     return _reportErrorToken(this._textBuffer.contentsAsString());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonToken _reportErrorToken(String actualToken) throws IOException {
/* 1264 */     _reportError("Unrecognized token '%s': was expecting %s", this._textBuffer.contentsAsString(), 
/* 1265 */         _validJsonTokenList());
/* 1266 */     return JsonToken.NOT_AVAILABLE;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonToken _startFloatThatStartsWithPeriod() throws IOException {
/* 1278 */     this._numberNegative = false;
/* 1279 */     this._intLength = 0;
/* 1280 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 1281 */     return _startFloat(outBuf, 0, 46);
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _startPositiveNumber(int ch) throws IOException {
/* 1286 */     this._numberNegative = false;
/* 1287 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 1288 */     outBuf[0] = (char)ch;
/*      */     
/* 1290 */     if (this._inputPtr >= this._inputEnd) {
/* 1291 */       this._minorState = 26;
/* 1292 */       this._textBuffer.setCurrentLength(1);
/* 1293 */       return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */     } 
/*      */     
/* 1296 */     int outPtr = 1;
/*      */     
/* 1298 */     ch = getByteFromBuffer(this._inputPtr) & 0xFF;
/*      */     while (true) {
/* 1300 */       if (ch < 48) {
/* 1301 */         if (ch == 46) {
/* 1302 */           this._intLength = outPtr;
/* 1303 */           this._inputPtr++;
/* 1304 */           return _startFloat(outBuf, outPtr, ch);
/*      */         } 
/*      */         break;
/*      */       } 
/* 1308 */       if (ch > 57) {
/* 1309 */         if (ch == 101 || ch == 69) {
/* 1310 */           this._intLength = outPtr;
/* 1311 */           this._inputPtr++;
/* 1312 */           return _startFloat(outBuf, outPtr, ch);
/*      */         } 
/*      */         break;
/*      */       } 
/* 1316 */       if (outPtr >= outBuf.length)
/*      */       {
/*      */         
/* 1319 */         outBuf = this._textBuffer.expandCurrentSegment();
/*      */       }
/* 1321 */       outBuf[outPtr++] = (char)ch;
/* 1322 */       if (++this._inputPtr >= this._inputEnd) {
/* 1323 */         this._minorState = 26;
/* 1324 */         this._textBuffer.setCurrentLength(outPtr);
/* 1325 */         return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */       } 
/* 1327 */       ch = getByteFromBuffer(this._inputPtr) & 0xFF;
/*      */     } 
/* 1329 */     this._intLength = outPtr;
/* 1330 */     this._textBuffer.setCurrentLength(outPtr);
/* 1331 */     return _valueComplete(JsonToken.VALUE_NUMBER_INT);
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _startNegativeNumber() throws IOException {
/* 1336 */     this._numberNegative = true;
/* 1337 */     if (this._inputPtr >= this._inputEnd) {
/* 1338 */       this._minorState = 23;
/* 1339 */       return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */     } 
/* 1341 */     int ch = getNextUnsignedByteFromBuffer();
/* 1342 */     if (ch <= 48) {
/* 1343 */       if (ch == 48) {
/* 1344 */         return _finishNumberLeadingNegZeroes();
/*      */       }
/*      */       
/* 1347 */       _reportUnexpectedNumberChar(ch, "expected digit (0-9) to follow minus sign, for valid numeric value");
/* 1348 */     } else if (ch > 57) {
/* 1349 */       if (ch == 73) {
/* 1350 */         return _finishNonStdToken(3, 2);
/*      */       }
/* 1352 */       _reportUnexpectedNumberChar(ch, "expected digit (0-9) to follow minus sign, for valid numeric value");
/*      */     } 
/* 1354 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 1355 */     outBuf[0] = '-';
/* 1356 */     outBuf[1] = (char)ch;
/* 1357 */     if (this._inputPtr >= this._inputEnd) {
/* 1358 */       this._minorState = 26;
/* 1359 */       this._textBuffer.setCurrentLength(2);
/* 1360 */       this._intLength = 1;
/* 1361 */       return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */     } 
/* 1363 */     ch = getByteFromBuffer(this._inputPtr);
/* 1364 */     int outPtr = 2;
/*      */     
/*      */     while (true) {
/* 1367 */       if (ch < 48) {
/* 1368 */         if (ch == 46) {
/* 1369 */           this._intLength = outPtr - 1;
/* 1370 */           this._inputPtr++;
/* 1371 */           return _startFloat(outBuf, outPtr, ch);
/*      */         } 
/*      */         break;
/*      */       } 
/* 1375 */       if (ch > 57) {
/* 1376 */         if (ch == 101 || ch == 69) {
/* 1377 */           this._intLength = outPtr - 1;
/* 1378 */           this._inputPtr++;
/* 1379 */           return _startFloat(outBuf, outPtr, ch);
/*      */         } 
/*      */         break;
/*      */       } 
/* 1383 */       if (outPtr >= outBuf.length)
/*      */       {
/* 1385 */         outBuf = this._textBuffer.expandCurrentSegment();
/*      */       }
/* 1387 */       outBuf[outPtr++] = (char)ch;
/* 1388 */       if (++this._inputPtr >= this._inputEnd) {
/* 1389 */         this._minorState = 26;
/* 1390 */         this._textBuffer.setCurrentLength(outPtr);
/* 1391 */         return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */       } 
/* 1393 */       ch = getByteFromBuffer(this._inputPtr) & 0xFF;
/*      */     } 
/* 1395 */     this._intLength = outPtr - 1;
/* 1396 */     this._textBuffer.setCurrentLength(outPtr);
/* 1397 */     return _valueComplete(JsonToken.VALUE_NUMBER_INT);
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _startPositiveNumber() throws IOException {
/* 1402 */     this._numberNegative = false;
/* 1403 */     if (this._inputPtr >= this._inputEnd) {
/* 1404 */       this._minorState = 22;
/* 1405 */       return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */     } 
/* 1407 */     int ch = getNextUnsignedByteFromBuffer();
/* 1408 */     if (ch <= 48) {
/* 1409 */       if (ch == 48) {
/* 1410 */         if (!isEnabled(JsonReadFeature.ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS.mappedFeature())) {
/* 1411 */           _reportUnexpectedNumberChar(43, "JSON spec does not allow numbers to have plus signs: enable `JsonReadFeature.ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS` to allow");
/*      */         }
/* 1413 */         return _finishNumberLeadingPosZeroes();
/*      */       } 
/*      */       
/* 1416 */       _reportUnexpectedNumberChar(ch, "expected digit (0-9) to follow plus sign, for valid numeric value");
/* 1417 */     } else if (ch > 57) {
/* 1418 */       if (ch == 73) {
/* 1419 */         return _finishNonStdToken(2, 2);
/*      */       }
/* 1421 */       _reportUnexpectedNumberChar(ch, "expected digit (0-9) to follow plus sign, for valid numeric value");
/*      */     } 
/* 1423 */     if (!isEnabled(JsonReadFeature.ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS.mappedFeature())) {
/* 1424 */       _reportUnexpectedNumberChar(43, "JSON spec does not allow numbers to have plus signs: enable `JsonReadFeature.ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS` to allow");
/*      */     }
/* 1426 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 1427 */     outBuf[0] = '+';
/* 1428 */     outBuf[1] = (char)ch;
/* 1429 */     if (this._inputPtr >= this._inputEnd) {
/* 1430 */       this._minorState = 26;
/* 1431 */       this._textBuffer.setCurrentLength(2);
/* 1432 */       this._intLength = 1;
/* 1433 */       return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */     } 
/* 1435 */     ch = getByteFromBuffer(this._inputPtr);
/* 1436 */     int outPtr = 2;
/*      */     
/*      */     while (true) {
/* 1439 */       if (ch < 48) {
/* 1440 */         if (ch == 46) {
/* 1441 */           this._intLength = outPtr - 1;
/* 1442 */           this._inputPtr++;
/* 1443 */           return _startFloat(outBuf, outPtr, ch);
/*      */         } 
/*      */         break;
/*      */       } 
/* 1447 */       if (ch > 57) {
/* 1448 */         if (ch == 101 || ch == 69) {
/* 1449 */           this._intLength = outPtr - 1;
/* 1450 */           this._inputPtr++;
/* 1451 */           return _startFloat(outBuf, outPtr, ch);
/*      */         } 
/*      */         break;
/*      */       } 
/* 1455 */       if (outPtr >= outBuf.length)
/*      */       {
/* 1457 */         outBuf = this._textBuffer.expandCurrentSegment();
/*      */       }
/* 1459 */       outBuf[outPtr++] = (char)ch;
/* 1460 */       if (++this._inputPtr >= this._inputEnd) {
/* 1461 */         this._minorState = 26;
/* 1462 */         this._textBuffer.setCurrentLength(outPtr);
/* 1463 */         return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */       } 
/* 1465 */       ch = getByteFromBuffer(this._inputPtr) & 0xFF;
/*      */     } 
/* 1467 */     this._intLength = outPtr - 1;
/* 1468 */     this._textBuffer.setCurrentLength(outPtr);
/* 1469 */     return _valueComplete(JsonToken.VALUE_NUMBER_INT);
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _startNumberLeadingZero() throws IOException {
/* 1474 */     int ptr = this._inputPtr;
/* 1475 */     if (ptr >= this._inputEnd) {
/* 1476 */       this._minorState = 24;
/* 1477 */       return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1484 */     int ch = getByteFromBuffer(ptr++) & 0xFF;
/*      */     
/* 1486 */     if (ch < 48) {
/* 1487 */       if (ch == 46) {
/* 1488 */         this._inputPtr = ptr;
/* 1489 */         this._intLength = 1;
/* 1490 */         char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 1491 */         outBuf[0] = '0';
/* 1492 */         return _startFloat(outBuf, 1, ch);
/*      */       } 
/* 1494 */     } else if (ch > 57) {
/* 1495 */       if (ch == 101 || ch == 69) {
/* 1496 */         this._inputPtr = ptr;
/* 1497 */         this._intLength = 1;
/* 1498 */         char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 1499 */         outBuf[0] = '0';
/* 1500 */         return _startFloat(outBuf, 1, ch);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1505 */       if (ch != 93 && ch != 125) {
/* 1506 */         _reportUnexpectedNumberChar(ch, "expected digit (0-9), decimal point (.) or exponent indicator (e/E) to follow '0'");
/*      */       }
/*      */     }
/*      */     else {
/*      */       
/* 1511 */       return _finishNumberLeadingZeroes();
/*      */     } 
/*      */     
/* 1514 */     return _valueCompleteInt(0, "0");
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _finishNumberMinus(int ch) throws IOException {
/* 1519 */     return _finishNumberPlusMinus(ch, true);
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _finishNumberPlus(int ch) throws IOException {
/* 1524 */     return _finishNumberPlusMinus(ch, false);
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _finishNumberPlusMinus(int ch, boolean negative) throws IOException {
/* 1529 */     if (ch <= 48) {
/* 1530 */       if (ch == 48) {
/* 1531 */         if (negative) {
/* 1532 */           return _finishNumberLeadingNegZeroes();
/*      */         }
/* 1534 */         if (!isEnabled(JsonReadFeature.ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS.mappedFeature())) {
/* 1535 */           _reportUnexpectedNumberChar(43, "JSON spec does not allow numbers to have plus signs: enable `JsonReadFeature.ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS` to allow");
/*      */         }
/* 1537 */         return _finishNumberLeadingPosZeroes();
/*      */       } 
/* 1539 */       if (ch == 46 && isEnabled(JsonReadFeature.ALLOW_LEADING_DECIMAL_POINT_FOR_NUMBERS.mappedFeature())) {
/* 1540 */         if (negative) {
/* 1541 */           this._inputPtr--;
/* 1542 */           return _finishNumberLeadingNegZeroes();
/*      */         } 
/* 1544 */         if (!isEnabled(JsonReadFeature.ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS.mappedFeature())) {
/* 1545 */           _reportUnexpectedNumberChar(43, "JSON spec does not allow numbers to have plus signs: enable `JsonReadFeature.ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS` to allow");
/*      */         }
/* 1547 */         this._inputPtr--;
/* 1548 */         return _finishNumberLeadingPosZeroes();
/*      */       } 
/*      */       
/* 1551 */       String message = negative ? "expected digit (0-9) to follow minus sign, for valid numeric value" : "expected digit (0-9) for valid numeric value";
/*      */ 
/*      */       
/* 1554 */       _reportUnexpectedNumberChar(ch, message);
/* 1555 */     } else if (ch > 57) {
/* 1556 */       if (ch == 73) {
/* 1557 */         int token = negative ? 3 : 2;
/* 1558 */         return _finishNonStdToken(token, 2);
/*      */       } 
/* 1560 */       String message = negative ? "expected digit (0-9) to follow minus sign, for valid numeric value" : "expected digit (0-9) for valid numeric value";
/*      */ 
/*      */       
/* 1563 */       _reportUnexpectedNumberChar(ch, message);
/*      */     } 
/* 1565 */     if (!negative && !isEnabled(JsonReadFeature.ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS.mappedFeature())) {
/* 1566 */       _reportUnexpectedNumberChar(43, "JSON spec does not allow numbers to have plus signs: enable `JsonReadFeature.ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS` to allow");
/*      */     }
/* 1568 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 1569 */     outBuf[0] = negative ? '-' : '+';
/* 1570 */     outBuf[1] = (char)ch;
/* 1571 */     this._intLength = 1;
/* 1572 */     return _finishNumberIntegralPart(outBuf, 2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonToken _finishNumberLeadingZeroes() throws IOException {
/*      */     while (true) {
/* 1580 */       if (this._inputPtr >= this._inputEnd) {
/* 1581 */         this._minorState = 24;
/* 1582 */         return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */       } 
/* 1584 */       int ch = getNextUnsignedByteFromBuffer();
/* 1585 */       if (ch < 48) {
/* 1586 */         if (ch == 46) {
/* 1587 */           char[] arrayOfChar = this._textBuffer.emptyAndGetCurrentSegment();
/* 1588 */           arrayOfChar[0] = '0';
/* 1589 */           this._intLength = 1;
/* 1590 */           return _startFloat(arrayOfChar, 1, ch);
/*      */         }  break;
/* 1592 */       }  if (ch > 57) {
/* 1593 */         if (ch == 101 || ch == 69) {
/* 1594 */           char[] arrayOfChar = this._textBuffer.emptyAndGetCurrentSegment();
/* 1595 */           arrayOfChar[0] = '0';
/* 1596 */           this._intLength = 1;
/* 1597 */           return _startFloat(arrayOfChar, 1, ch);
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 1602 */         if (ch != 93 && ch != 125) {
/* 1603 */           _reportUnexpectedNumberChar(ch, "expected digit (0-9), decimal point (.) or exponent indicator (e/E) to follow '0'");
/*      */         }
/*      */         
/*      */         break;
/*      */       } 
/*      */       
/* 1609 */       if ((this._features & FEAT_MASK_LEADING_ZEROS) == 0) {
/* 1610 */         reportInvalidNumber("Leading zeroes not allowed");
/*      */       }
/* 1612 */       if (ch == 48) {
/*      */         continue;
/*      */       }
/* 1615 */       char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/*      */       
/* 1617 */       outBuf[0] = (char)ch;
/* 1618 */       this._intLength = 1;
/* 1619 */       return _finishNumberIntegralPart(outBuf, 1);
/*      */     } 
/* 1621 */     this._inputPtr--;
/* 1622 */     return _valueCompleteInt(0, "0");
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _finishNumberLeadingNegZeroes() throws IOException {
/* 1627 */     return _finishNumberLeadingPosNegZeroes(true);
/*      */   }
/*      */   
/*      */   protected JsonToken _finishNumberLeadingPosZeroes() throws IOException {
/* 1631 */     return _finishNumberLeadingPosNegZeroes(false);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonToken _finishNumberLeadingPosNegZeroes(boolean negative) throws IOException {
/*      */     while (true) {
/* 1638 */       if (this._inputPtr >= this._inputEnd) {
/* 1639 */         this._minorState = negative ? 25 : 24;
/* 1640 */         return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */       } 
/* 1642 */       int ch = getNextUnsignedByteFromBuffer();
/* 1643 */       if (ch < 48) {
/* 1644 */         if (ch == 46) {
/* 1645 */           char[] arrayOfChar = this._textBuffer.emptyAndGetCurrentSegment();
/* 1646 */           arrayOfChar[0] = negative ? '-' : '+';
/* 1647 */           arrayOfChar[1] = '0';
/* 1648 */           this._intLength = 1;
/* 1649 */           return _startFloat(arrayOfChar, 2, ch);
/*      */         }  break;
/* 1651 */       }  if (ch > 57) {
/* 1652 */         if (ch == 101 || ch == 69) {
/* 1653 */           char[] arrayOfChar = this._textBuffer.emptyAndGetCurrentSegment();
/* 1654 */           arrayOfChar[0] = negative ? '-' : '+';
/* 1655 */           arrayOfChar[1] = '0';
/* 1656 */           this._intLength = 1;
/* 1657 */           return _startFloat(arrayOfChar, 2, ch);
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 1662 */         if (ch != 93 && ch != 125) {
/* 1663 */           _reportUnexpectedNumberChar(ch, "expected digit (0-9), decimal point (.) or exponent indicator (e/E) to follow '0'");
/*      */         }
/*      */         
/*      */         break;
/*      */       } 
/*      */       
/* 1669 */       if ((this._features & FEAT_MASK_LEADING_ZEROS) == 0) {
/* 1670 */         reportInvalidNumber("Leading zeroes not allowed");
/*      */       }
/* 1672 */       if (ch == 48) {
/*      */         continue;
/*      */       }
/* 1675 */       char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/*      */       
/* 1677 */       outBuf[0] = negative ? '-' : '+';
/* 1678 */       outBuf[1] = (char)ch;
/* 1679 */       this._intLength = 1;
/* 1680 */       return _finishNumberIntegralPart(outBuf, 2);
/*      */     } 
/* 1682 */     this._inputPtr--;
/* 1683 */     return _valueCompleteInt(0, "0");
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _finishNumberIntegralPart(char[] outBuf, int outPtr) throws IOException {
/* 1688 */     int negMod = this._numberNegative ? -1 : 0;
/*      */     
/*      */     while (true) {
/* 1691 */       if (this._inputPtr >= this._inputEnd) {
/* 1692 */         this._minorState = 26;
/* 1693 */         this._textBuffer.setCurrentLength(outPtr);
/* 1694 */         return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */       } 
/* 1696 */       int ch = getByteFromBuffer(this._inputPtr) & 0xFF;
/* 1697 */       if (ch < 48) {
/* 1698 */         if (ch == 46) {
/* 1699 */           this._intLength = outPtr + negMod;
/* 1700 */           this._inputPtr++;
/* 1701 */           return _startFloat(outBuf, outPtr, ch);
/*      */         } 
/*      */         break;
/*      */       } 
/* 1705 */       if (ch > 57) {
/* 1706 */         if (ch == 101 || ch == 69) {
/* 1707 */           this._intLength = outPtr + negMod;
/* 1708 */           this._inputPtr++;
/* 1709 */           return _startFloat(outBuf, outPtr, ch);
/*      */         } 
/*      */         break;
/*      */       } 
/* 1713 */       this._inputPtr++;
/* 1714 */       if (outPtr >= outBuf.length)
/*      */       {
/*      */         
/* 1717 */         outBuf = this._textBuffer.expandCurrentSegment();
/*      */       }
/* 1719 */       outBuf[outPtr++] = (char)ch;
/*      */     } 
/* 1721 */     this._intLength = outPtr + negMod;
/* 1722 */     this._textBuffer.setCurrentLength(outPtr);
/* 1723 */     return _valueComplete(JsonToken.VALUE_NUMBER_INT);
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _startFloat(char[] outBuf, int outPtr, int ch) throws IOException {
/* 1728 */     int fractLen = 0;
/* 1729 */     if (ch == 46) {
/* 1730 */       if (outPtr >= outBuf.length) {
/* 1731 */         outBuf = this._textBuffer.expandCurrentSegment();
/*      */       }
/* 1733 */       outBuf[outPtr++] = '.';
/*      */       while (true) {
/* 1735 */         if (this._inputPtr >= this._inputEnd) {
/* 1736 */           this._textBuffer.setCurrentLength(outPtr);
/* 1737 */           this._minorState = 30;
/* 1738 */           this._fractLength = fractLen;
/* 1739 */           return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */         } 
/* 1741 */         ch = getNextSignedByteFromBuffer();
/* 1742 */         if (ch < 48 || ch > 57) {
/* 1743 */           ch &= 0xFF;
/*      */           
/* 1745 */           if (fractLen == 0 && 
/* 1746 */             !isEnabled(JsonReadFeature.ALLOW_TRAILING_DECIMAL_POINT_FOR_NUMBERS.mappedFeature())) {
/* 1747 */             _reportUnexpectedNumberChar(ch, "Decimal point not followed by a digit");
/*      */           }
/*      */           
/*      */           break;
/*      */         } 
/* 1752 */         if (outPtr >= outBuf.length) {
/* 1753 */           outBuf = this._textBuffer.expandCurrentSegment();
/*      */         }
/* 1755 */         outBuf[outPtr++] = (char)ch;
/* 1756 */         fractLen++;
/*      */       } 
/*      */     } 
/* 1759 */     this._fractLength = fractLen;
/* 1760 */     int expLen = 0;
/* 1761 */     if (ch == 101 || ch == 69) {
/* 1762 */       if (outPtr >= outBuf.length) {
/* 1763 */         outBuf = this._textBuffer.expandCurrentSegment();
/*      */       }
/* 1765 */       outBuf[outPtr++] = (char)ch;
/* 1766 */       if (this._inputPtr >= this._inputEnd) {
/* 1767 */         this._textBuffer.setCurrentLength(outPtr);
/* 1768 */         this._minorState = 31;
/* 1769 */         this._expLength = 0;
/* 1770 */         return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */       } 
/* 1772 */       ch = getNextSignedByteFromBuffer();
/* 1773 */       if (ch == 45 || ch == 43) {
/* 1774 */         if (outPtr >= outBuf.length) {
/* 1775 */           outBuf = this._textBuffer.expandCurrentSegment();
/*      */         }
/* 1777 */         outBuf[outPtr++] = (char)ch;
/* 1778 */         if (this._inputPtr >= this._inputEnd) {
/* 1779 */           this._textBuffer.setCurrentLength(outPtr);
/* 1780 */           this._minorState = 32;
/* 1781 */           this._expLength = 0;
/* 1782 */           return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */         } 
/* 1784 */         ch = getNextSignedByteFromBuffer();
/*      */       } 
/* 1786 */       while (ch >= 48 && ch <= 57) {
/* 1787 */         expLen++;
/* 1788 */         if (outPtr >= outBuf.length) {
/* 1789 */           outBuf = this._textBuffer.expandCurrentSegment();
/*      */         }
/* 1791 */         outBuf[outPtr++] = (char)ch;
/* 1792 */         if (this._inputPtr >= this._inputEnd) {
/* 1793 */           this._textBuffer.setCurrentLength(outPtr);
/* 1794 */           this._minorState = 32;
/* 1795 */           this._expLength = expLen;
/* 1796 */           return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */         } 
/* 1798 */         ch = getNextSignedByteFromBuffer();
/*      */       } 
/*      */       
/* 1801 */       ch &= 0xFF;
/* 1802 */       if (expLen == 0) {
/* 1803 */         _reportUnexpectedNumberChar(ch, "Exponent indicator not followed by a digit");
/*      */       }
/*      */     } 
/*      */     
/* 1807 */     this._inputPtr--;
/* 1808 */     this._textBuffer.setCurrentLength(outPtr);
/*      */     
/* 1810 */     this._expLength = expLen;
/* 1811 */     return _valueComplete(JsonToken.VALUE_NUMBER_FLOAT);
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _finishFloatFraction() throws IOException {
/* 1816 */     int fractLen = this._fractLength;
/* 1817 */     char[] outBuf = this._textBuffer.getBufferWithoutReset();
/* 1818 */     int outPtr = this._textBuffer.getCurrentSegmentSize();
/*      */ 
/*      */     
/* 1821 */     int ch = getNextSignedByteFromBuffer();
/* 1822 */     boolean loop = true;
/* 1823 */     while (loop) {
/* 1824 */       if (ch >= 48 && ch <= 57) {
/* 1825 */         fractLen++;
/* 1826 */         if (outPtr >= outBuf.length) {
/* 1827 */           outBuf = this._textBuffer.expandCurrentSegment();
/*      */         }
/* 1829 */         outBuf[outPtr++] = (char)ch;
/* 1830 */         if (this._inputPtr >= this._inputEnd) {
/* 1831 */           this._textBuffer.setCurrentLength(outPtr);
/* 1832 */           this._fractLength = fractLen;
/* 1833 */           return JsonToken.NOT_AVAILABLE;
/*      */         } 
/* 1835 */         ch = getNextSignedByteFromBuffer(); continue;
/* 1836 */       }  if (ch == 102 || ch == 100 || ch == 70 || ch == 68) {
/* 1837 */         _reportUnexpectedNumberChar(ch, "JSON does not support parsing numbers that have 'f' or 'd' suffixes"); continue;
/* 1838 */       }  if (ch == 46) {
/* 1839 */         _reportUnexpectedNumberChar(ch, "Cannot parse number with more than one decimal point"); continue;
/*      */       } 
/* 1841 */       loop = false;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1847 */     if (fractLen == 0 && 
/* 1848 */       !isEnabled(JsonReadFeature.ALLOW_TRAILING_DECIMAL_POINT_FOR_NUMBERS.mappedFeature())) {
/* 1849 */       _reportUnexpectedNumberChar(ch, "Decimal point not followed by a digit");
/*      */     }
/*      */     
/* 1852 */     this._fractLength = fractLen;
/* 1853 */     this._textBuffer.setCurrentLength(outPtr);
/*      */ 
/*      */     
/* 1856 */     if (ch == 101 || ch == 69) {
/* 1857 */       this._textBuffer.append((char)ch);
/* 1858 */       this._expLength = 0;
/* 1859 */       if (this._inputPtr >= this._inputEnd) {
/* 1860 */         this._minorState = 31;
/* 1861 */         return JsonToken.NOT_AVAILABLE;
/*      */       } 
/* 1863 */       this._minorState = 32;
/* 1864 */       return _finishFloatExponent(true, getNextUnsignedByteFromBuffer());
/*      */     } 
/*      */ 
/*      */     
/* 1868 */     this._inputPtr--;
/* 1869 */     this._textBuffer.setCurrentLength(outPtr);
/*      */     
/* 1871 */     this._expLength = 0;
/* 1872 */     return _valueComplete(JsonToken.VALUE_NUMBER_FLOAT);
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _finishFloatExponent(boolean checkSign, int ch) throws IOException {
/* 1877 */     if (checkSign) {
/* 1878 */       this._minorState = 32;
/* 1879 */       if (ch == 45 || ch == 43) {
/* 1880 */         this._textBuffer.append((char)ch);
/* 1881 */         if (this._inputPtr >= this._inputEnd) {
/* 1882 */           this._minorState = 32;
/* 1883 */           this._expLength = 0;
/* 1884 */           return JsonToken.NOT_AVAILABLE;
/*      */         } 
/* 1886 */         ch = getNextSignedByteFromBuffer();
/*      */       } 
/*      */     } 
/*      */     
/* 1890 */     char[] outBuf = this._textBuffer.getBufferWithoutReset();
/* 1891 */     int outPtr = this._textBuffer.getCurrentSegmentSize();
/* 1892 */     int expLen = this._expLength;
/*      */     
/* 1894 */     while (ch >= 48 && ch <= 57) {
/* 1895 */       expLen++;
/* 1896 */       if (outPtr >= outBuf.length) {
/* 1897 */         outBuf = this._textBuffer.expandCurrentSegment();
/*      */       }
/* 1899 */       outBuf[outPtr++] = (char)ch;
/* 1900 */       if (this._inputPtr >= this._inputEnd) {
/* 1901 */         this._textBuffer.setCurrentLength(outPtr);
/* 1902 */         this._expLength = expLen;
/* 1903 */         return JsonToken.NOT_AVAILABLE;
/*      */       } 
/* 1905 */       ch = getNextSignedByteFromBuffer();
/*      */     } 
/*      */     
/* 1908 */     ch &= 0xFF;
/* 1909 */     if (expLen == 0) {
/* 1910 */       _reportUnexpectedNumberChar(ch, "Exponent indicator not followed by a digit");
/*      */     }
/*      */     
/* 1913 */     this._inputPtr--;
/* 1914 */     this._textBuffer.setCurrentLength(outPtr);
/*      */     
/* 1916 */     this._expLength = expLen;
/* 1917 */     return _valueComplete(JsonToken.VALUE_NUMBER_FLOAT);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final String _fastParseName() throws IOException {
/* 1933 */     int[] codes = _icLatin1;
/* 1934 */     int ptr = this._inputPtr;
/*      */     
/* 1936 */     int q0 = getByteFromBuffer(ptr++) & 0xFF;
/* 1937 */     if (codes[q0] == 0) {
/* 1938 */       int i = getByteFromBuffer(ptr++) & 0xFF;
/* 1939 */       if (codes[i] == 0) {
/* 1940 */         int q = q0 << 8 | i;
/* 1941 */         i = getByteFromBuffer(ptr++) & 0xFF;
/* 1942 */         if (codes[i] == 0) {
/* 1943 */           q = q << 8 | i;
/* 1944 */           i = getByteFromBuffer(ptr++) & 0xFF;
/* 1945 */           if (codes[i] == 0) {
/* 1946 */             q = q << 8 | i;
/* 1947 */             i = getByteFromBuffer(ptr++) & 0xFF;
/* 1948 */             if (codes[i] == 0) {
/* 1949 */               this._quad1 = q;
/* 1950 */               return _parseMediumName(ptr, i);
/*      */             } 
/* 1952 */             if (i == 34) {
/* 1953 */               this._inputPtr = ptr;
/* 1954 */               return _findName(q, 4);
/*      */             } 
/* 1956 */             return null;
/*      */           } 
/* 1958 */           if (i == 34) {
/* 1959 */             this._inputPtr = ptr;
/* 1960 */             return _findName(q, 3);
/*      */           } 
/* 1962 */           return null;
/*      */         } 
/* 1964 */         if (i == 34) {
/* 1965 */           this._inputPtr = ptr;
/* 1966 */           return _findName(q, 2);
/*      */         } 
/* 1968 */         return null;
/*      */       } 
/* 1970 */       if (i == 34) {
/* 1971 */         this._inputPtr = ptr;
/* 1972 */         return _findName(q0, 1);
/*      */       } 
/* 1974 */       return null;
/*      */     } 
/* 1976 */     if (q0 == 34) {
/* 1977 */       this._inputPtr = ptr;
/* 1978 */       return "";
/*      */     } 
/* 1980 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   private final String _parseMediumName(int ptr, int q2) throws IOException {
/* 1985 */     int[] codes = _icLatin1;
/*      */ 
/*      */     
/* 1988 */     int i = getByteFromBuffer(ptr++) & 0xFF;
/* 1989 */     if (codes[i] == 0) {
/* 1990 */       q2 = q2 << 8 | i;
/* 1991 */       i = getByteFromBuffer(ptr++) & 0xFF;
/* 1992 */       if (codes[i] == 0) {
/* 1993 */         q2 = q2 << 8 | i;
/* 1994 */         i = getByteFromBuffer(ptr++) & 0xFF;
/* 1995 */         if (codes[i] == 0) {
/* 1996 */           q2 = q2 << 8 | i;
/* 1997 */           i = getByteFromBuffer(ptr++) & 0xFF;
/* 1998 */           if (codes[i] == 0) {
/* 1999 */             return _parseMediumName2(ptr, i, q2);
/*      */           }
/* 2001 */           if (i == 34) {
/* 2002 */             this._inputPtr = ptr;
/* 2003 */             return _findName(this._quad1, q2, 4);
/*      */           } 
/* 2005 */           return null;
/*      */         } 
/* 2007 */         if (i == 34) {
/* 2008 */           this._inputPtr = ptr;
/* 2009 */           return _findName(this._quad1, q2, 3);
/*      */         } 
/* 2011 */         return null;
/*      */       } 
/* 2013 */       if (i == 34) {
/* 2014 */         this._inputPtr = ptr;
/* 2015 */         return _findName(this._quad1, q2, 2);
/*      */       } 
/* 2017 */       return null;
/*      */     } 
/* 2019 */     if (i == 34) {
/* 2020 */       this._inputPtr = ptr;
/* 2021 */       return _findName(this._quad1, q2, 1);
/*      */     } 
/* 2023 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   private final String _parseMediumName2(int ptr, int q3, int q2) throws IOException {
/* 2028 */     int[] codes = _icLatin1;
/*      */ 
/*      */     
/* 2031 */     int i = getByteFromBuffer(ptr++) & 0xFF;
/* 2032 */     if (codes[i] != 0) {
/* 2033 */       if (i == 34) {
/* 2034 */         this._inputPtr = ptr;
/* 2035 */         return _findName(this._quad1, q2, q3, 1);
/*      */       } 
/* 2037 */       return null;
/*      */     } 
/* 2039 */     q3 = q3 << 8 | i;
/* 2040 */     i = getByteFromBuffer(ptr++) & 0xFF;
/* 2041 */     if (codes[i] != 0) {
/* 2042 */       if (i == 34) {
/* 2043 */         this._inputPtr = ptr;
/* 2044 */         return _findName(this._quad1, q2, q3, 2);
/*      */       } 
/* 2046 */       return null;
/*      */     } 
/* 2048 */     q3 = q3 << 8 | i;
/* 2049 */     i = getByteFromBuffer(ptr++) & 0xFF;
/* 2050 */     if (codes[i] != 0) {
/* 2051 */       if (i == 34) {
/* 2052 */         this._inputPtr = ptr;
/* 2053 */         return _findName(this._quad1, q2, q3, 3);
/*      */       } 
/* 2055 */       return null;
/*      */     } 
/* 2057 */     q3 = q3 << 8 | i;
/* 2058 */     i = getByteFromBuffer(ptr++) & 0xFF;
/* 2059 */     if (i == 34) {
/* 2060 */       this._inputPtr = ptr;
/* 2061 */       return _findName(this._quad1, q2, q3, 4);
/*      */     } 
/*      */     
/* 2064 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final JsonToken _parseEscapedName(int qlen, int currQuad, int currQuadBytes) throws IOException {
/* 2080 */     int[] quads = this._quadBuffer;
/* 2081 */     int[] codes = _icLatin1;
/*      */     
/*      */     while (true) {
/* 2084 */       if (this._inputPtr >= this._inputEnd) {
/* 2085 */         this._quadLength = qlen;
/* 2086 */         this._pending32 = currQuad;
/* 2087 */         this._pendingBytes = currQuadBytes;
/* 2088 */         this._minorState = 7;
/* 2089 */         return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */       } 
/* 2091 */       int ch = getNextUnsignedByteFromBuffer();
/* 2092 */       if (codes[ch] == 0) {
/* 2093 */         if (currQuadBytes < 4) {
/* 2094 */           currQuadBytes++;
/* 2095 */           currQuad = currQuad << 8 | ch;
/*      */           continue;
/*      */         } 
/* 2098 */         if (qlen >= quads.length) {
/* 2099 */           this._quadBuffer = quads = growArrayBy(quads, quads.length);
/*      */         }
/* 2101 */         quads[qlen++] = currQuad;
/* 2102 */         currQuad = ch;
/* 2103 */         currQuadBytes = 1;
/*      */         
/*      */         continue;
/*      */       } 
/*      */       
/* 2108 */       if (ch == 34) {
/*      */         break;
/*      */       }
/*      */       
/* 2112 */       if (ch != 92) {
/*      */         
/* 2114 */         _throwUnquotedSpace(ch, "name");
/*      */       } else {
/*      */         
/* 2117 */         ch = _decodeCharEscape();
/* 2118 */         if (ch < 0) {
/* 2119 */           this._minorState = 8;
/* 2120 */           this._minorStateAfterSplit = 7;
/* 2121 */           this._quadLength = qlen;
/* 2122 */           this._pending32 = currQuad;
/* 2123 */           this._pendingBytes = currQuadBytes;
/* 2124 */           return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2131 */       if (qlen >= quads.length) {
/* 2132 */         this._quadBuffer = quads = growArrayBy(quads, quads.length);
/*      */       }
/* 2134 */       if (ch > 127) {
/*      */         
/* 2136 */         if (currQuadBytes >= 4) {
/* 2137 */           quads[qlen++] = currQuad;
/* 2138 */           currQuad = 0;
/* 2139 */           currQuadBytes = 0;
/*      */         } 
/* 2141 */         if (ch < 2048) {
/* 2142 */           currQuad = currQuad << 8 | 0xC0 | ch >> 6;
/* 2143 */           currQuadBytes++;
/*      */         } else {
/*      */           
/* 2146 */           currQuad = currQuad << 8 | 0xE0 | ch >> 12;
/* 2147 */           currQuadBytes++;
/*      */           
/* 2149 */           if (currQuadBytes >= 4) {
/* 2150 */             quads[qlen++] = currQuad;
/* 2151 */             currQuad = 0;
/* 2152 */             currQuadBytes = 0;
/*      */           } 
/* 2154 */           currQuad = currQuad << 8 | 0x80 | ch >> 6 & 0x3F;
/* 2155 */           currQuadBytes++;
/*      */         } 
/*      */         
/* 2158 */         ch = 0x80 | ch & 0x3F;
/*      */       } 
/* 2160 */       if (currQuadBytes < 4) {
/* 2161 */         currQuadBytes++;
/* 2162 */         currQuad = currQuad << 8 | ch;
/*      */         continue;
/*      */       } 
/* 2165 */       quads[qlen++] = currQuad;
/* 2166 */       currQuad = ch;
/* 2167 */       currQuadBytes = 1;
/*      */     } 
/*      */     
/* 2170 */     if (currQuadBytes > 0) {
/* 2171 */       if (qlen >= quads.length) {
/* 2172 */         this._quadBuffer = quads = growArrayBy(quads, quads.length);
/*      */       }
/* 2174 */       quads[qlen++] = _padLastQuad(currQuad, currQuadBytes);
/* 2175 */     } else if (qlen == 0) {
/* 2176 */       return _fieldComplete("");
/*      */     } 
/* 2178 */     String name = this._symbols.findName(quads, qlen);
/* 2179 */     if (name == null) {
/* 2180 */       name = _addName(quads, qlen, currQuadBytes);
/*      */     }
/* 2182 */     return _fieldComplete(name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private JsonToken _handleOddName(int ch) throws IOException {
/* 2194 */     switch (ch) {
/*      */ 
/*      */       
/*      */       case 35:
/* 2198 */         if ((this._features & FEAT_MASK_ALLOW_YAML_COMMENTS) != 0) {
/* 2199 */           return _finishHashComment(4);
/*      */         }
/*      */         break;
/*      */       case 47:
/* 2203 */         return _startSlashComment(4);
/*      */       case 39:
/* 2205 */         if ((this._features & FEAT_MASK_ALLOW_SINGLE_QUOTES) != 0) {
/* 2206 */           return _finishAposName(0, 0, 0);
/*      */         }
/*      */         break;
/*      */       case 93:
/* 2210 */         return _closeArrayScope();
/*      */     } 
/*      */     
/* 2213 */     if ((this._features & FEAT_MASK_ALLOW_UNQUOTED_NAMES) == 0) {
/*      */ 
/*      */       
/* 2216 */       char c = (char)ch;
/* 2217 */       _reportUnexpectedChar(c, "was expecting double-quote to start field name");
/*      */     } 
/*      */ 
/*      */     
/* 2221 */     int[] codes = CharTypes.getInputCodeUtf8JsNames();
/*      */     
/* 2223 */     if (codes[ch] != 0) {
/* 2224 */       _reportUnexpectedChar(ch, "was expecting either valid name character (for unquoted name) or double-quote (for quoted) to start field name");
/*      */     }
/*      */     
/* 2227 */     return _finishUnquotedName(0, ch, 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private JsonToken _finishUnquotedName(int qlen, int currQuad, int currQuadBytes) throws IOException {
/* 2238 */     int[] quads = this._quadBuffer;
/* 2239 */     int[] codes = CharTypes.getInputCodeUtf8JsNames();
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/* 2244 */       if (this._inputPtr >= this._inputEnd) {
/* 2245 */         this._quadLength = qlen;
/* 2246 */         this._pending32 = currQuad;
/* 2247 */         this._pendingBytes = currQuadBytes;
/* 2248 */         this._minorState = 10;
/* 2249 */         return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */       } 
/* 2251 */       int ch = getByteFromBuffer(this._inputPtr) & 0xFF;
/* 2252 */       if (codes[ch] != 0) {
/*      */         break;
/*      */       }
/* 2255 */       this._inputPtr++;
/*      */       
/* 2257 */       if (currQuadBytes < 4) {
/* 2258 */         currQuadBytes++;
/* 2259 */         currQuad = currQuad << 8 | ch; continue;
/*      */       } 
/* 2261 */       if (qlen >= quads.length) {
/* 2262 */         this._quadBuffer = quads = growArrayBy(quads, quads.length);
/*      */       }
/* 2264 */       quads[qlen++] = currQuad;
/* 2265 */       currQuad = ch;
/* 2266 */       currQuadBytes = 1;
/*      */     } 
/*      */ 
/*      */     
/* 2270 */     if (currQuadBytes > 0) {
/* 2271 */       if (qlen >= quads.length) {
/* 2272 */         this._quadBuffer = quads = growArrayBy(quads, quads.length);
/*      */       }
/* 2274 */       quads[qlen++] = currQuad;
/*      */     } 
/* 2276 */     String name = this._symbols.findName(quads, qlen);
/* 2277 */     if (name == null) {
/* 2278 */       name = _addName(quads, qlen, currQuadBytes);
/*      */     }
/* 2280 */     return _fieldComplete(name);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private JsonToken _finishAposName(int qlen, int currQuad, int currQuadBytes) throws IOException {
/* 2286 */     int[] quads = this._quadBuffer;
/* 2287 */     int[] codes = _icLatin1;
/*      */     
/*      */     while (true) {
/* 2290 */       if (this._inputPtr >= this._inputEnd) {
/* 2291 */         this._quadLength = qlen;
/* 2292 */         this._pending32 = currQuad;
/* 2293 */         this._pendingBytes = currQuadBytes;
/* 2294 */         this._minorState = 9;
/* 2295 */         return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */       } 
/* 2297 */       int ch = getNextUnsignedByteFromBuffer();
/* 2298 */       if (ch == 39) {
/*      */         break;
/*      */       }
/*      */       
/* 2302 */       if (ch != 34 && codes[ch] != 0) {
/* 2303 */         if (ch != 92) {
/*      */           
/* 2305 */           _throwUnquotedSpace(ch, "name");
/*      */         } else {
/*      */           
/* 2308 */           ch = _decodeCharEscape();
/* 2309 */           if (ch < 0) {
/* 2310 */             this._minorState = 8;
/* 2311 */             this._minorStateAfterSplit = 9;
/* 2312 */             this._quadLength = qlen;
/* 2313 */             this._pending32 = currQuad;
/* 2314 */             this._pendingBytes = currQuadBytes;
/* 2315 */             return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */           } 
/*      */         } 
/* 2318 */         if (ch > 127) {
/*      */           
/* 2320 */           if (currQuadBytes >= 4) {
/* 2321 */             if (qlen >= quads.length) {
/* 2322 */               this._quadBuffer = quads = growArrayBy(quads, quads.length);
/*      */             }
/* 2324 */             quads[qlen++] = currQuad;
/* 2325 */             currQuad = 0;
/* 2326 */             currQuadBytes = 0;
/*      */           } 
/* 2328 */           if (ch < 2048) {
/* 2329 */             currQuad = currQuad << 8 | 0xC0 | ch >> 6;
/* 2330 */             currQuadBytes++;
/*      */           } else {
/*      */             
/* 2333 */             currQuad = currQuad << 8 | 0xE0 | ch >> 12;
/* 2334 */             currQuadBytes++;
/*      */             
/* 2336 */             if (currQuadBytes >= 4) {
/* 2337 */               if (qlen >= quads.length) {
/* 2338 */                 this._quadBuffer = quads = growArrayBy(quads, quads.length);
/*      */               }
/* 2340 */               quads[qlen++] = currQuad;
/* 2341 */               currQuad = 0;
/* 2342 */               currQuadBytes = 0;
/*      */             } 
/* 2344 */             currQuad = currQuad << 8 | 0x80 | ch >> 6 & 0x3F;
/* 2345 */             currQuadBytes++;
/*      */           } 
/*      */           
/* 2348 */           ch = 0x80 | ch & 0x3F;
/*      */         } 
/*      */       } 
/*      */       
/* 2352 */       if (currQuadBytes < 4) {
/* 2353 */         currQuadBytes++;
/* 2354 */         currQuad = currQuad << 8 | ch; continue;
/*      */       } 
/* 2356 */       if (qlen >= quads.length) {
/* 2357 */         this._quadBuffer = quads = growArrayBy(quads, quads.length);
/*      */       }
/* 2359 */       quads[qlen++] = currQuad;
/* 2360 */       currQuad = ch;
/* 2361 */       currQuadBytes = 1;
/*      */     } 
/*      */ 
/*      */     
/* 2365 */     if (currQuadBytes > 0) {
/* 2366 */       if (qlen >= quads.length) {
/* 2367 */         this._quadBuffer = quads = growArrayBy(quads, quads.length);
/*      */       }
/* 2369 */       quads[qlen++] = _padLastQuad(currQuad, currQuadBytes);
/* 2370 */     } else if (qlen == 0) {
/* 2371 */       return _fieldComplete("");
/*      */     } 
/* 2373 */     String name = this._symbols.findName(quads, qlen);
/* 2374 */     if (name == null) {
/* 2375 */       name = _addName(quads, qlen, currQuadBytes);
/*      */     }
/* 2377 */     return _fieldComplete(name);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected final JsonToken _finishFieldWithEscape() throws IOException {
/* 2383 */     int ch = _decodeSplitEscaped(this._quoted32, this._quotedDigits);
/* 2384 */     if (ch < 0) {
/* 2385 */       this._minorState = 8;
/* 2386 */       return JsonToken.NOT_AVAILABLE;
/*      */     } 
/* 2388 */     if (this._quadLength >= this._quadBuffer.length) {
/* 2389 */       this._quadBuffer = growArrayBy(this._quadBuffer, 32);
/*      */     }
/* 2391 */     int currQuad = this._pending32;
/* 2392 */     int currQuadBytes = this._pendingBytes;
/* 2393 */     if (ch > 127) {
/*      */       
/* 2395 */       if (currQuadBytes >= 4) {
/* 2396 */         this._quadBuffer[this._quadLength++] = currQuad;
/* 2397 */         currQuad = 0;
/* 2398 */         currQuadBytes = 0;
/*      */       } 
/* 2400 */       if (ch < 2048) {
/* 2401 */         currQuad = currQuad << 8 | 0xC0 | ch >> 6;
/* 2402 */         currQuadBytes++;
/*      */       } else {
/*      */         
/* 2405 */         currQuad = currQuad << 8 | 0xE0 | ch >> 12;
/*      */         
/* 2407 */         if (++currQuadBytes >= 4) {
/* 2408 */           this._quadBuffer[this._quadLength++] = currQuad;
/* 2409 */           currQuad = 0;
/* 2410 */           currQuadBytes = 0;
/*      */         } 
/* 2412 */         currQuad = currQuad << 8 | 0x80 | ch >> 6 & 0x3F;
/* 2413 */         currQuadBytes++;
/*      */       } 
/*      */       
/* 2416 */       ch = 0x80 | ch & 0x3F;
/*      */     } 
/* 2418 */     if (currQuadBytes < 4) {
/* 2419 */       currQuadBytes++;
/* 2420 */       currQuad = currQuad << 8 | ch;
/*      */     } else {
/* 2422 */       this._quadBuffer[this._quadLength++] = currQuad;
/* 2423 */       currQuad = ch;
/* 2424 */       currQuadBytes = 1;
/*      */     } 
/* 2426 */     if (this._minorStateAfterSplit == 9) {
/* 2427 */       return _finishAposName(this._quadLength, currQuad, currQuadBytes);
/*      */     }
/* 2429 */     return _parseEscapedName(this._quadLength, currQuad, currQuadBytes);
/*      */   }
/*      */ 
/*      */   
/*      */   private int _decodeSplitEscaped(int value, int bytesRead) throws IOException {
/* 2434 */     if (this._inputPtr >= this._inputEnd) {
/* 2435 */       this._quoted32 = value;
/* 2436 */       this._quotedDigits = bytesRead;
/* 2437 */       return -1;
/*      */     } 
/* 2439 */     int c = getNextSignedByteFromBuffer();
/* 2440 */     if (bytesRead == -1) {
/* 2441 */       char ch; switch (c) {
/*      */         
/*      */         case 98:
/* 2444 */           return 8;
/*      */         case 116:
/* 2446 */           return 9;
/*      */         case 110:
/* 2448 */           return 10;
/*      */         case 102:
/* 2450 */           return 12;
/*      */         case 114:
/* 2452 */           return 13;
/*      */ 
/*      */         
/*      */         case 34:
/*      */         case 47:
/*      */         case 92:
/* 2458 */           return c;
/*      */ 
/*      */ 
/*      */         
/*      */         case 117:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 2467 */           ch = (char)c;
/* 2468 */           return _handleUnrecognizedCharacterEscape(ch);
/*      */       } 
/*      */       
/* 2471 */       if (this._inputPtr >= this._inputEnd) {
/* 2472 */         this._quotedDigits = 0;
/* 2473 */         this._quoted32 = 0;
/* 2474 */         return -1;
/*      */       } 
/* 2476 */       c = getNextSignedByteFromBuffer();
/* 2477 */       bytesRead = 0;
/*      */     } 
/* 2479 */     c &= 0xFF;
/*      */     while (true) {
/* 2481 */       int digit = CharTypes.charToHex(c);
/* 2482 */       if (digit < 0) {
/* 2483 */         _reportUnexpectedChar(c & 0xFF, "expected a hex-digit for character escape sequence");
/*      */       }
/* 2485 */       value = value << 4 | digit;
/* 2486 */       if (++bytesRead == 4) {
/* 2487 */         return value;
/*      */       }
/* 2489 */       if (this._inputPtr >= this._inputEnd) {
/* 2490 */         this._quotedDigits = bytesRead;
/* 2491 */         this._quoted32 = value;
/* 2492 */         return -1;
/*      */       } 
/* 2494 */       c = getNextUnsignedByteFromBuffer();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonToken _startString() throws IOException {
/* 2506 */     int ptr = this._inputPtr;
/* 2507 */     int outPtr = 0;
/* 2508 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 2509 */     int[] codes = _icUTF8;
/*      */     
/* 2511 */     int max = Math.min(this._inputEnd, ptr + outBuf.length);
/* 2512 */     while (ptr < max) {
/* 2513 */       int c = getByteFromBuffer(ptr) & 0xFF;
/* 2514 */       if (codes[c] != 0) {
/* 2515 */         if (c == 34) {
/* 2516 */           this._inputPtr = ptr + 1;
/* 2517 */           this._textBuffer.setCurrentLength(outPtr);
/* 2518 */           return _valueComplete(JsonToken.VALUE_STRING);
/*      */         } 
/*      */         break;
/*      */       } 
/* 2522 */       ptr++;
/* 2523 */       outBuf[outPtr++] = (char)c;
/*      */     } 
/* 2525 */     this._textBuffer.setCurrentLength(outPtr);
/* 2526 */     this._inputPtr = ptr;
/* 2527 */     return _finishRegularString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final JsonToken _finishRegularString() throws IOException {
/* 2535 */     int[] codes = _icUTF8;
/*      */     
/* 2537 */     char[] outBuf = this._textBuffer.getBufferWithoutReset();
/* 2538 */     int outPtr = this._textBuffer.getCurrentSegmentSize();
/* 2539 */     int ptr = this._inputPtr;
/* 2540 */     int safeEnd = this._inputEnd - 5;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/* 2547 */       if (ptr >= this._inputEnd) {
/* 2548 */         this._inputPtr = ptr;
/* 2549 */         this._minorState = 40;
/* 2550 */         this._textBuffer.setCurrentLength(outPtr);
/* 2551 */         return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */       } 
/* 2553 */       if (outPtr >= outBuf.length) {
/* 2554 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 2555 */         outPtr = 0;
/*      */       } 
/* 2557 */       int max = Math.min(this._inputEnd, ptr + outBuf.length - outPtr);
/* 2558 */       while (ptr < max) {
/* 2559 */         int c = getByteFromBuffer(ptr++) & 0xFF;
/* 2560 */         if (codes[c] != 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2567 */           if (c == 34) {
/* 2568 */             this._inputPtr = ptr;
/* 2569 */             this._textBuffer.setCurrentLength(outPtr);
/* 2570 */             return _valueComplete(JsonToken.VALUE_STRING);
/*      */           } 
/*      */           
/* 2573 */           if (ptr >= safeEnd) {
/* 2574 */             this._inputPtr = ptr;
/* 2575 */             this._textBuffer.setCurrentLength(outPtr);
/* 2576 */             if (!_decodeSplitMultiByte(c, codes[c], (ptr < this._inputEnd))) {
/* 2577 */               this._minorStateAfterSplit = 40;
/* 2578 */               return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */             } 
/* 2580 */             outBuf = this._textBuffer.getBufferWithoutReset();
/* 2581 */             outPtr = this._textBuffer.getCurrentSegmentSize();
/* 2582 */             ptr = this._inputPtr;
/*      */             
/*      */             continue;
/*      */           } 
/* 2586 */           switch (codes[c]) {
/*      */             case 1:
/* 2588 */               this._inputPtr = ptr;
/* 2589 */               c = _decodeFastCharEscape();
/* 2590 */               ptr = this._inputPtr;
/*      */               break;
/*      */             case 2:
/* 2593 */               c = _decodeUTF8_2(c, getByteFromBuffer(ptr++));
/*      */               break;
/*      */             case 3:
/* 2596 */               c = _decodeUTF8_3(c, getByteFromBuffer(ptr++), getByteFromBuffer(ptr++));
/*      */               break;
/*      */             case 4:
/* 2599 */               c = _decodeUTF8_4(c, getByteFromBuffer(ptr++), getByteFromBuffer(ptr++), 
/* 2600 */                   getByteFromBuffer(ptr++));
/*      */               
/* 2602 */               outBuf[outPtr++] = (char)(0xD800 | c >> 10);
/* 2603 */               if (outPtr >= outBuf.length) {
/* 2604 */                 outBuf = this._textBuffer.finishCurrentSegment();
/* 2605 */                 outPtr = 0;
/*      */               } 
/* 2607 */               c = 0xDC00 | c & 0x3FF;
/*      */               break;
/*      */             
/*      */             default:
/* 2611 */               if (c < 32) {
/*      */                 
/* 2613 */                 _throwUnquotedSpace(c, "string value");
/*      */                 break;
/*      */               } 
/* 2616 */               _reportInvalidChar(c);
/*      */               break;
/*      */           } 
/*      */           
/* 2620 */           if (outPtr >= outBuf.length) {
/* 2621 */             outBuf = this._textBuffer.finishCurrentSegment();
/* 2622 */             outPtr = 0;
/*      */           } 
/*      */           
/* 2625 */           outBuf[outPtr++] = (char)c;
/*      */           continue;
/*      */         } 
/*      */         outBuf[outPtr++] = (char)c;
/*      */       } 
/*      */     }  } protected JsonToken _startAposString() throws IOException {
/* 2631 */     int ptr = this._inputPtr;
/* 2632 */     int outPtr = 0;
/* 2633 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 2634 */     int[] codes = _icUTF8;
/*      */     
/* 2636 */     int max = Math.min(this._inputEnd, ptr + outBuf.length);
/* 2637 */     while (ptr < max) {
/* 2638 */       int c = getByteFromBuffer(ptr) & 0xFF;
/* 2639 */       if (c == 39) {
/* 2640 */         this._inputPtr = ptr + 1;
/* 2641 */         this._textBuffer.setCurrentLength(outPtr);
/* 2642 */         return _valueComplete(JsonToken.VALUE_STRING);
/*      */       } 
/*      */       
/* 2645 */       if (codes[c] != 0) {
/*      */         break;
/*      */       }
/* 2648 */       ptr++;
/* 2649 */       outBuf[outPtr++] = (char)c;
/*      */     } 
/* 2651 */     this._textBuffer.setCurrentLength(outPtr);
/* 2652 */     this._inputPtr = ptr;
/* 2653 */     return _finishAposString();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final JsonToken _finishAposString() throws IOException {
/* 2659 */     int[] codes = _icUTF8;
/*      */     
/* 2661 */     char[] outBuf = this._textBuffer.getBufferWithoutReset();
/* 2662 */     int outPtr = this._textBuffer.getCurrentSegmentSize();
/* 2663 */     int ptr = this._inputPtr;
/* 2664 */     int safeEnd = this._inputEnd - 5;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/* 2670 */       if (ptr >= this._inputEnd) {
/* 2671 */         this._inputPtr = ptr;
/* 2672 */         this._minorState = 45;
/* 2673 */         this._textBuffer.setCurrentLength(outPtr);
/* 2674 */         return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */       } 
/* 2676 */       if (outPtr >= outBuf.length) {
/* 2677 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 2678 */         outPtr = 0;
/*      */       } 
/* 2680 */       int max = Math.min(this._inputEnd, ptr + outBuf.length - outPtr);
/* 2681 */       while (ptr < max) {
/* 2682 */         int c = getByteFromBuffer(ptr++) & 0xFF;
/* 2683 */         if (codes[c] != 0 && c != 34) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2696 */           if (ptr >= safeEnd) {
/* 2697 */             this._inputPtr = ptr;
/* 2698 */             this._textBuffer.setCurrentLength(outPtr);
/* 2699 */             if (!_decodeSplitMultiByte(c, codes[c], (ptr < this._inputEnd))) {
/* 2700 */               this._minorStateAfterSplit = 45;
/* 2701 */               return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */             } 
/* 2703 */             outBuf = this._textBuffer.getBufferWithoutReset();
/* 2704 */             outPtr = this._textBuffer.getCurrentSegmentSize();
/* 2705 */             ptr = this._inputPtr;
/*      */             
/*      */             continue;
/*      */           } 
/* 2709 */           switch (codes[c]) {
/*      */             case 1:
/* 2711 */               this._inputPtr = ptr;
/* 2712 */               c = _decodeFastCharEscape();
/* 2713 */               ptr = this._inputPtr;
/*      */               break;
/*      */             case 2:
/* 2716 */               c = _decodeUTF8_2(c, getByteFromBuffer(ptr++));
/*      */               break;
/*      */             case 3:
/* 2719 */               c = _decodeUTF8_3(c, getByteFromBuffer(ptr++), getByteFromBuffer(ptr++));
/*      */               break;
/*      */             case 4:
/* 2722 */               c = _decodeUTF8_4(c, getByteFromBuffer(ptr++), getByteFromBuffer(ptr++), 
/* 2723 */                   getByteFromBuffer(ptr++));
/*      */               
/* 2725 */               outBuf[outPtr++] = (char)(0xD800 | c >> 10);
/* 2726 */               if (outPtr >= outBuf.length) {
/* 2727 */                 outBuf = this._textBuffer.finishCurrentSegment();
/* 2728 */                 outPtr = 0;
/*      */               } 
/* 2730 */               c = 0xDC00 | c & 0x3FF;
/*      */               break;
/*      */             
/*      */             default:
/* 2734 */               if (c < 32) {
/*      */                 
/* 2736 */                 _throwUnquotedSpace(c, "string value");
/*      */                 break;
/*      */               } 
/* 2739 */               _reportInvalidChar(c);
/*      */               break;
/*      */           } 
/*      */           
/* 2743 */           if (outPtr >= outBuf.length) {
/* 2744 */             outBuf = this._textBuffer.finishCurrentSegment();
/* 2745 */             outPtr = 0;
/*      */           } 
/*      */           
/* 2748 */           outBuf[outPtr++] = (char)c; continue;
/*      */         }  if (c == 39) {
/*      */           this._inputPtr = ptr; this._textBuffer.setCurrentLength(outPtr);
/*      */           return _valueComplete(JsonToken.VALUE_STRING);
/*      */         } 
/*      */         outBuf[outPtr++] = (char)c;
/*      */       } 
/* 2755 */     }  } private final boolean _decodeSplitMultiByte(int c, int type, boolean gotNext) throws IOException { switch (type) {
/*      */       case 1:
/* 2757 */         c = _decodeSplitEscaped(0, -1);
/* 2758 */         if (c < 0) {
/* 2759 */           this._minorState = 41;
/* 2760 */           return false;
/*      */         } 
/* 2762 */         this._textBuffer.append((char)c);
/* 2763 */         return true;
/*      */       case 2:
/* 2765 */         if (gotNext) {
/*      */           
/* 2767 */           c = _decodeUTF8_2(c, getNextSignedByteFromBuffer());
/* 2768 */           this._textBuffer.append((char)c);
/* 2769 */           return true;
/*      */         } 
/* 2771 */         this._minorState = 42;
/* 2772 */         this._pending32 = c;
/* 2773 */         return false;
/*      */       case 3:
/* 2775 */         c &= 0xF;
/* 2776 */         if (gotNext) {
/* 2777 */           return _decodeSplitUTF8_3(c, 1, getNextSignedByteFromBuffer());
/*      */         }
/* 2779 */         this._minorState = 43;
/* 2780 */         this._pending32 = c;
/* 2781 */         this._pendingBytes = 1;
/* 2782 */         return false;
/*      */       case 4:
/* 2784 */         c &= 0x7;
/* 2785 */         if (gotNext) {
/* 2786 */           return _decodeSplitUTF8_4(c, 1, getNextSignedByteFromBuffer());
/*      */         }
/* 2788 */         this._pending32 = c;
/* 2789 */         this._pendingBytes = 1;
/* 2790 */         this._minorState = 44;
/* 2791 */         return false;
/*      */     } 
/* 2793 */     if (c < 32) {
/*      */       
/* 2795 */       _throwUnquotedSpace(c, "string value");
/*      */     } else {
/*      */       
/* 2798 */       _reportInvalidChar(c);
/*      */     } 
/* 2800 */     this._textBuffer.append((char)c);
/* 2801 */     return true; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final boolean _decodeSplitUTF8_3(int prev, int prevCount, int next) throws IOException {
/* 2808 */     if (prevCount == 1) {
/* 2809 */       if ((next & 0xC0) != 128) {
/* 2810 */         _reportInvalidOther(next & 0xFF, this._inputPtr);
/*      */       }
/* 2812 */       prev = prev << 6 | next & 0x3F;
/* 2813 */       if (this._inputPtr >= this._inputEnd) {
/* 2814 */         this._minorState = 43;
/* 2815 */         this._pending32 = prev;
/* 2816 */         this._pendingBytes = 2;
/* 2817 */         return false;
/*      */       } 
/* 2819 */       next = getNextSignedByteFromBuffer();
/*      */     } 
/* 2821 */     if ((next & 0xC0) != 128) {
/* 2822 */       _reportInvalidOther(next & 0xFF, this._inputPtr);
/*      */     }
/* 2824 */     this._textBuffer.append((char)(prev << 6 | next & 0x3F));
/* 2825 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final boolean _decodeSplitUTF8_4(int prev, int prevCount, int next) throws IOException {
/* 2833 */     if (prevCount == 1) {
/* 2834 */       if ((next & 0xC0) != 128) {
/* 2835 */         _reportInvalidOther(next & 0xFF, this._inputPtr);
/*      */       }
/* 2837 */       prev = prev << 6 | next & 0x3F;
/* 2838 */       if (this._inputPtr >= this._inputEnd) {
/* 2839 */         this._minorState = 44;
/* 2840 */         this._pending32 = prev;
/* 2841 */         this._pendingBytes = 2;
/* 2842 */         return false;
/*      */       } 
/* 2844 */       prevCount = 2;
/* 2845 */       next = getNextSignedByteFromBuffer();
/*      */     } 
/* 2847 */     if (prevCount == 2) {
/* 2848 */       if ((next & 0xC0) != 128) {
/* 2849 */         _reportInvalidOther(next & 0xFF, this._inputPtr);
/*      */       }
/* 2851 */       prev = prev << 6 | next & 0x3F;
/* 2852 */       if (this._inputPtr >= this._inputEnd) {
/* 2853 */         this._minorState = 44;
/* 2854 */         this._pending32 = prev;
/* 2855 */         this._pendingBytes = 3;
/* 2856 */         return false;
/*      */       } 
/* 2858 */       next = getNextSignedByteFromBuffer();
/*      */     } 
/* 2860 */     if ((next & 0xC0) != 128) {
/* 2861 */       _reportInvalidOther(next & 0xFF, this._inputPtr);
/*      */     }
/* 2863 */     int c = (prev << 6 | next & 0x3F) - 65536;
/*      */     
/* 2865 */     this._textBuffer.append((char)(0xD800 | c >> 10));
/* 2866 */     c = 0xDC00 | c & 0x3FF;
/*      */     
/* 2868 */     this._textBuffer.append((char)c);
/* 2869 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _decodeCharEscape() throws IOException {
/* 2880 */     int left = this._inputEnd - this._inputPtr;
/* 2881 */     if (left < 5) {
/* 2882 */       return _decodeSplitEscaped(0, -1);
/*      */     }
/* 2884 */     return _decodeFastCharEscape();
/*      */   }
/*      */   
/*      */   private final int _decodeFastCharEscape() throws IOException {
/*      */     char c1;
/* 2889 */     int c = getNextSignedByteFromBuffer();
/* 2890 */     switch (c) {
/*      */       
/*      */       case 98:
/* 2893 */         return 8;
/*      */       case 116:
/* 2895 */         return 9;
/*      */       case 110:
/* 2897 */         return 10;
/*      */       case 102:
/* 2899 */         return 12;
/*      */       case 114:
/* 2901 */         return 13;
/*      */ 
/*      */       
/*      */       case 34:
/*      */       case 47:
/*      */       case 92:
/* 2907 */         return (char)c;
/*      */ 
/*      */ 
/*      */       
/*      */       case 117:
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/* 2916 */         c1 = (char)c;
/* 2917 */         return _handleUnrecognizedCharacterEscape(c1);
/*      */     } 
/*      */ 
/*      */     
/* 2921 */     int ch = getNextSignedByteFromBuffer();
/* 2922 */     int digit = CharTypes.charToHex(ch);
/* 2923 */     int result = digit;
/*      */     
/* 2925 */     if (digit >= 0) {
/* 2926 */       ch = getNextSignedByteFromBuffer();
/* 2927 */       digit = CharTypes.charToHex(ch);
/* 2928 */       if (digit >= 0) {
/* 2929 */         result = result << 4 | digit;
/* 2930 */         ch = getNextSignedByteFromBuffer();
/* 2931 */         digit = CharTypes.charToHex(ch);
/* 2932 */         if (digit >= 0) {
/* 2933 */           result = result << 4 | digit;
/* 2934 */           ch = getNextSignedByteFromBuffer();
/* 2935 */           digit = CharTypes.charToHex(ch);
/* 2936 */           if (digit >= 0) {
/* 2937 */             return result << 4 | digit;
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/* 2942 */     _reportUnexpectedChar(ch & 0xFF, "expected a hex-digit for character escape sequence");
/* 2943 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _decodeUTF8_2(int c, int d) throws IOException {
/* 2954 */     if ((d & 0xC0) != 128) {
/* 2955 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 2957 */     return (c & 0x1F) << 6 | d & 0x3F;
/*      */   }
/*      */ 
/*      */   
/*      */   private final int _decodeUTF8_3(int c, int d, int e) throws IOException {
/* 2962 */     c &= 0xF;
/* 2963 */     if ((d & 0xC0) != 128) {
/* 2964 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 2966 */     c = c << 6 | d & 0x3F;
/* 2967 */     if ((e & 0xC0) != 128) {
/* 2968 */       _reportInvalidOther(e & 0xFF, this._inputPtr);
/*      */     }
/* 2970 */     return c << 6 | e & 0x3F;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _decodeUTF8_4(int c, int d, int e, int f) throws IOException {
/* 2977 */     if ((d & 0xC0) != 128) {
/* 2978 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 2980 */     c = (c & 0x7) << 6 | d & 0x3F;
/* 2981 */     if ((e & 0xC0) != 128) {
/* 2982 */       _reportInvalidOther(e & 0xFF, this._inputPtr);
/*      */     }
/* 2984 */     c = c << 6 | e & 0x3F;
/* 2985 */     if ((f & 0xC0) != 128) {
/* 2986 */       _reportInvalidOther(f & 0xFF, this._inputPtr);
/*      */     }
/* 2988 */     return (c << 6 | f & 0x3F) - 65536;
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-core-2.14.2.jar!\com\fasterxml\jackson\core\json\async\NonBlockingUtf8JsonParserBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */