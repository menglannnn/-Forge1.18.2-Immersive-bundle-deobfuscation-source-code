/*     */ package com.fasterxml.jackson.core.io.doubleparser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class AbstractFloatingPointBitsFromCharSequence
/*     */   extends AbstractFloatValueParser
/*     */ {
/*     */   private boolean isDigit(char c) {
/*  26 */     return ('0' <= c && c <= '9');
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private long parseDecFloatLiteral(CharSequence str, int index, int startIndex, int endIndex, boolean isNegative, boolean hasLeadingZero) {
/*     */     // Byte code:
/*     */     //   0: lconst_0
/*     */     //   1: lstore #7
/*     */     //   3: iload_2
/*     */     //   4: istore #9
/*     */     //   6: iconst_m1
/*     */     //   7: istore #10
/*     */     //   9: iconst_0
/*     */     //   10: istore #11
/*     */     //   12: iconst_0
/*     */     //   13: istore #12
/*     */     //   15: iload_2
/*     */     //   16: iload #4
/*     */     //   18: if_icmpge -> 134
/*     */     //   21: aload_1
/*     */     //   22: iload_2
/*     */     //   23: invokeinterface charAt : (I)C
/*     */     //   28: istore #12
/*     */     //   30: aload_0
/*     */     //   31: iload #12
/*     */     //   33: invokespecial isDigit : (C)Z
/*     */     //   36: ifeq -> 58
/*     */     //   39: ldc2_w 10
/*     */     //   42: lload #7
/*     */     //   44: lmul
/*     */     //   45: iload #12
/*     */     //   47: i2l
/*     */     //   48: ladd
/*     */     //   49: ldc2_w 48
/*     */     //   52: lsub
/*     */     //   53: lstore #7
/*     */     //   55: goto -> 128
/*     */     //   58: iload #12
/*     */     //   60: bipush #46
/*     */     //   62: if_icmpne -> 134
/*     */     //   65: iload #11
/*     */     //   67: iload #10
/*     */     //   69: iflt -> 76
/*     */     //   72: iconst_1
/*     */     //   73: goto -> 77
/*     */     //   76: iconst_0
/*     */     //   77: ior
/*     */     //   78: istore #11
/*     */     //   80: iload_2
/*     */     //   81: istore #10
/*     */     //   83: iload_2
/*     */     //   84: iload #4
/*     */     //   86: bipush #8
/*     */     //   88: isub
/*     */     //   89: if_icmpge -> 128
/*     */     //   92: aload_0
/*     */     //   93: aload_1
/*     */     //   94: iload_2
/*     */     //   95: iconst_1
/*     */     //   96: iadd
/*     */     //   97: invokespecial tryToParseEightDigits : (Ljava/lang/CharSequence;I)I
/*     */     //   100: istore #13
/*     */     //   102: iload #13
/*     */     //   104: ifge -> 110
/*     */     //   107: goto -> 128
/*     */     //   110: ldc2_w 100000000
/*     */     //   113: lload #7
/*     */     //   115: lmul
/*     */     //   116: iload #13
/*     */     //   118: i2l
/*     */     //   119: ladd
/*     */     //   120: lstore #7
/*     */     //   122: iinc #2, 8
/*     */     //   125: goto -> 83
/*     */     //   128: iinc #2, 1
/*     */     //   131: goto -> 15
/*     */     //   134: iload_2
/*     */     //   135: istore #14
/*     */     //   137: iload #10
/*     */     //   139: ifge -> 159
/*     */     //   142: iload #14
/*     */     //   144: iload #9
/*     */     //   146: isub
/*     */     //   147: istore #13
/*     */     //   149: iload #14
/*     */     //   151: istore #10
/*     */     //   153: iconst_0
/*     */     //   154: istore #15
/*     */     //   156: goto -> 177
/*     */     //   159: iload #14
/*     */     //   161: iload #9
/*     */     //   163: isub
/*     */     //   164: iconst_1
/*     */     //   165: isub
/*     */     //   166: istore #13
/*     */     //   168: iload #10
/*     */     //   170: iload #14
/*     */     //   172: isub
/*     */     //   173: iconst_1
/*     */     //   174: iadd
/*     */     //   175: istore #15
/*     */     //   177: iconst_0
/*     */     //   178: istore #16
/*     */     //   180: iload #12
/*     */     //   182: bipush #101
/*     */     //   184: if_icmpeq -> 194
/*     */     //   187: iload #12
/*     */     //   189: bipush #69
/*     */     //   191: if_icmpne -> 352
/*     */     //   194: iinc #2, 1
/*     */     //   197: iload_2
/*     */     //   198: iload #4
/*     */     //   200: if_icmpge -> 213
/*     */     //   203: aload_1
/*     */     //   204: iload_2
/*     */     //   205: invokeinterface charAt : (I)C
/*     */     //   210: goto -> 214
/*     */     //   213: iconst_0
/*     */     //   214: istore #12
/*     */     //   216: iload #12
/*     */     //   218: bipush #45
/*     */     //   220: if_icmpne -> 227
/*     */     //   223: iconst_1
/*     */     //   224: goto -> 228
/*     */     //   227: iconst_0
/*     */     //   228: istore #17
/*     */     //   230: iload #17
/*     */     //   232: ifne -> 242
/*     */     //   235: iload #12
/*     */     //   237: bipush #43
/*     */     //   239: if_icmpne -> 264
/*     */     //   242: iinc #2, 1
/*     */     //   245: iload_2
/*     */     //   246: iload #4
/*     */     //   248: if_icmpge -> 261
/*     */     //   251: aload_1
/*     */     //   252: iload_2
/*     */     //   253: invokeinterface charAt : (I)C
/*     */     //   258: goto -> 262
/*     */     //   261: iconst_0
/*     */     //   262: istore #12
/*     */     //   264: iload #11
/*     */     //   266: aload_0
/*     */     //   267: iload #12
/*     */     //   269: invokespecial isDigit : (C)Z
/*     */     //   272: ifne -> 279
/*     */     //   275: iconst_1
/*     */     //   276: goto -> 280
/*     */     //   279: iconst_0
/*     */     //   280: ior
/*     */     //   281: istore #11
/*     */     //   283: iload #16
/*     */     //   285: sipush #1024
/*     */     //   288: if_icmpge -> 304
/*     */     //   291: bipush #10
/*     */     //   293: iload #16
/*     */     //   295: imul
/*     */     //   296: iload #12
/*     */     //   298: iadd
/*     */     //   299: bipush #48
/*     */     //   301: isub
/*     */     //   302: istore #16
/*     */     //   304: iinc #2, 1
/*     */     //   307: iload_2
/*     */     //   308: iload #4
/*     */     //   310: if_icmpge -> 323
/*     */     //   313: aload_1
/*     */     //   314: iload_2
/*     */     //   315: invokeinterface charAt : (I)C
/*     */     //   320: goto -> 324
/*     */     //   323: iconst_0
/*     */     //   324: istore #12
/*     */     //   326: aload_0
/*     */     //   327: iload #12
/*     */     //   329: invokespecial isDigit : (C)Z
/*     */     //   332: ifne -> 283
/*     */     //   335: iload #17
/*     */     //   337: ifeq -> 345
/*     */     //   340: iload #16
/*     */     //   342: ineg
/*     */     //   343: istore #16
/*     */     //   345: iload #15
/*     */     //   347: iload #16
/*     */     //   349: iadd
/*     */     //   350: istore #15
/*     */     //   352: iload_2
/*     */     //   353: iload #4
/*     */     //   355: if_icmpge -> 389
/*     */     //   358: iload #12
/*     */     //   360: bipush #100
/*     */     //   362: if_icmpeq -> 386
/*     */     //   365: iload #12
/*     */     //   367: bipush #68
/*     */     //   369: if_icmpeq -> 386
/*     */     //   372: iload #12
/*     */     //   374: bipush #102
/*     */     //   376: if_icmpeq -> 386
/*     */     //   379: iload #12
/*     */     //   381: bipush #70
/*     */     //   383: if_icmpne -> 389
/*     */     //   386: iinc #2, 1
/*     */     //   389: aload_0
/*     */     //   390: aload_1
/*     */     //   391: iload_2
/*     */     //   392: iload #4
/*     */     //   394: invokespecial skipWhitespace : (Ljava/lang/CharSequence;II)I
/*     */     //   397: istore_2
/*     */     //   398: iload #11
/*     */     //   400: ifne -> 419
/*     */     //   403: iload_2
/*     */     //   404: iload #4
/*     */     //   406: if_icmplt -> 419
/*     */     //   409: iload #6
/*     */     //   411: ifne -> 423
/*     */     //   414: iload #13
/*     */     //   416: ifne -> 423
/*     */     //   419: ldc2_w -1
/*     */     //   422: lreturn
/*     */     //   423: iconst_0
/*     */     //   424: istore #18
/*     */     //   426: iload #13
/*     */     //   428: bipush #19
/*     */     //   430: if_icmple -> 528
/*     */     //   433: lconst_0
/*     */     //   434: lstore #7
/*     */     //   436: iload #9
/*     */     //   438: istore_2
/*     */     //   439: iload_2
/*     */     //   440: iload #14
/*     */     //   442: if_icmpge -> 500
/*     */     //   445: aload_1
/*     */     //   446: iload_2
/*     */     //   447: invokeinterface charAt : (I)C
/*     */     //   452: istore #12
/*     */     //   454: iload #12
/*     */     //   456: bipush #46
/*     */     //   458: if_icmpne -> 467
/*     */     //   461: iinc #18, 1
/*     */     //   464: goto -> 494
/*     */     //   467: lload #7
/*     */     //   469: ldc2_w 1000000000000000000
/*     */     //   472: invokestatic compareUnsigned : (JJ)I
/*     */     //   475: ifge -> 500
/*     */     //   478: ldc2_w 10
/*     */     //   481: lload #7
/*     */     //   483: lmul
/*     */     //   484: iload #12
/*     */     //   486: i2l
/*     */     //   487: ladd
/*     */     //   488: ldc2_w 48
/*     */     //   491: lsub
/*     */     //   492: lstore #7
/*     */     //   494: iinc #2, 1
/*     */     //   497: goto -> 439
/*     */     //   500: iload_2
/*     */     //   501: iload #14
/*     */     //   503: if_icmpge -> 510
/*     */     //   506: iconst_1
/*     */     //   507: goto -> 511
/*     */     //   510: iconst_0
/*     */     //   511: istore #17
/*     */     //   513: iload #10
/*     */     //   515: iload_2
/*     */     //   516: isub
/*     */     //   517: iload #18
/*     */     //   519: iadd
/*     */     //   520: iload #16
/*     */     //   522: iadd
/*     */     //   523: istore #19
/*     */     //   525: goto -> 534
/*     */     //   528: iconst_0
/*     */     //   529: istore #17
/*     */     //   531: iconst_0
/*     */     //   532: istore #19
/*     */     //   534: aload_0
/*     */     //   535: aload_1
/*     */     //   536: iload_3
/*     */     //   537: iload #4
/*     */     //   539: iload #5
/*     */     //   541: lload #7
/*     */     //   543: iload #15
/*     */     //   545: iload #17
/*     */     //   547: iload #19
/*     */     //   549: invokevirtual valueOfFloatLiteral : (Ljava/lang/CharSequence;IIZJIZI)J
/*     */     //   552: lreturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #56	-> 0
/*     */     //   #57	-> 3
/*     */     //   #58	-> 6
/*     */     //   #59	-> 9
/*     */     //   #60	-> 12
/*     */     //   #61	-> 15
/*     */     //   #62	-> 21
/*     */     //   #63	-> 30
/*     */     //   #65	-> 39
/*     */     //   #66	-> 58
/*     */     //   #67	-> 65
/*     */     //   #68	-> 80
/*     */     //   #69	-> 83
/*     */     //   #70	-> 92
/*     */     //   #71	-> 102
/*     */     //   #72	-> 107
/*     */     //   #75	-> 110
/*     */     //   #69	-> 122
/*     */     //   #61	-> 128
/*     */     //   #82	-> 134
/*     */     //   #84	-> 137
/*     */     //   #85	-> 142
/*     */     //   #86	-> 149
/*     */     //   #87	-> 153
/*     */     //   #89	-> 159
/*     */     //   #90	-> 168
/*     */     //   #95	-> 177
/*     */     //   #96	-> 180
/*     */     //   #97	-> 194
/*     */     //   #98	-> 216
/*     */     //   #99	-> 230
/*     */     //   #100	-> 242
/*     */     //   #102	-> 264
/*     */     //   #105	-> 283
/*     */     //   #106	-> 291
/*     */     //   #108	-> 304
/*     */     //   #109	-> 326
/*     */     //   #110	-> 335
/*     */     //   #111	-> 340
/*     */     //   #113	-> 345
/*     */     //   #118	-> 352
/*     */     //   #119	-> 386
/*     */     //   #124	-> 389
/*     */     //   #125	-> 398
/*     */     //   #127	-> 419
/*     */     //   #133	-> 423
/*     */     //   #135	-> 426
/*     */     //   #136	-> 433
/*     */     //   #137	-> 436
/*     */     //   #138	-> 445
/*     */     //   #139	-> 454
/*     */     //   #140	-> 461
/*     */     //   #142	-> 467
/*     */     //   #143	-> 478
/*     */     //   #137	-> 494
/*     */     //   #149	-> 500
/*     */     //   #150	-> 513
/*     */     //   #152	-> 528
/*     */     //   #153	-> 531
/*     */     //   #155	-> 534
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   102	20	13	eightDigits	I
/*     */     //   149	10	13	digitCount	I
/*     */     //   156	3	15	exponent	I
/*     */     //   230	122	17	neg_exp	Z
/*     */     //   513	15	17	isSignificandTruncated	Z
/*     */     //   525	3	19	exponentOfTruncatedSignificand	I
/*     */     //   0	553	0	this	Lcom/fasterxml/jackson/core/io/doubleparser/AbstractFloatingPointBitsFromCharSequence;
/*     */     //   0	553	1	str	Ljava/lang/CharSequence;
/*     */     //   0	553	2	index	I
/*     */     //   0	553	3	startIndex	I
/*     */     //   0	553	4	endIndex	I
/*     */     //   0	553	5	isNegative	Z
/*     */     //   0	553	6	hasLeadingZero	Z
/*     */     //   3	550	7	significand	J
/*     */     //   6	547	9	significandStartIndex	I
/*     */     //   9	544	10	virtualIndexOfPoint	I
/*     */     //   12	541	11	illegal	Z
/*     */     //   15	538	12	ch	C
/*     */     //   168	385	13	digitCount	I
/*     */     //   137	416	14	significandEndIndex	I
/*     */     //   177	376	15	exponent	I
/*     */     //   180	373	16	expNumber	I
/*     */     //   531	22	17	isSignificandTruncated	Z
/*     */     //   426	127	18	skipCountInTruncatedDigits	I
/*     */     //   534	19	19	exponentOfTruncatedSignificand	I
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long parseFloatingPointLiteral(CharSequence str, int offset, int length) {
/* 178 */     int endIndex = offset + length;
/* 179 */     if (offset < 0 || endIndex > str.length()) {
/* 180 */       return -1L;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 185 */     int index = skipWhitespace(str, offset, endIndex);
/* 186 */     if (index == endIndex) {
/* 187 */       return -1L;
/*     */     }
/* 189 */     char ch = str.charAt(index);
/*     */ 
/*     */ 
/*     */     
/* 193 */     boolean isNegative = (ch == '-');
/* 194 */     if (isNegative || ch == '+') {
/* 195 */       ch = (++index < endIndex) ? str.charAt(index) : Character.MIN_VALUE;
/* 196 */       if (ch == '\000') {
/* 197 */         return -1L;
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 203 */     if (ch >= 'I') {
/* 204 */       return (ch == 'N') ? 
/* 205 */         parseNaN(str, index, endIndex) : 
/* 206 */         parseInfinity(str, index, endIndex, isNegative);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 211 */     boolean hasLeadingZero = (ch == '0');
/* 212 */     if (hasLeadingZero) {
/* 213 */       ch = (++index < endIndex) ? str.charAt(index) : Character.MIN_VALUE;
/* 214 */       if (ch == 'x' || ch == 'X') {
/* 215 */         return parseHexFloatLiteral(str, index + 1, offset, endIndex, isNegative);
/*     */       }
/*     */     } 
/*     */     
/* 219 */     return parseDecFloatLiteral(str, index, offset, endIndex, isNegative, hasLeadingZero);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private long parseHexFloatLiteral(CharSequence str, int index, int startIndex, int endIndex, boolean isNegative) {
/*     */     int digitCount, i;
/*     */     boolean isSignificandTruncated;
/* 257 */     long significand = 0L;
/* 258 */     int exponent = 0;
/* 259 */     int significandStartIndex = index;
/* 260 */     int virtualIndexOfPoint = -1;
/*     */     
/* 262 */     boolean illegal = false;
/* 263 */     char ch = Character.MIN_VALUE;
/* 264 */     for (; index < endIndex; index++) {
/* 265 */       ch = str.charAt(index);
/*     */       
/* 267 */       int hexValue = (ch > '') ? -1 : AbstractFloatValueParser.CHAR_TO_HEX_MAP[ch];
/* 268 */       if (hexValue >= 0) {
/* 269 */         significand = significand << 4L | hexValue;
/* 270 */       } else if (hexValue == -4) {
/* 271 */         i = illegal | ((virtualIndexOfPoint >= 0) ? 1 : 0);
/* 272 */         virtualIndexOfPoint = index;
/*     */       } else {
/*     */         break;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 288 */     int significandEndIndex = index;
/* 289 */     if (virtualIndexOfPoint < 0) {
/* 290 */       digitCount = significandEndIndex - significandStartIndex;
/* 291 */       virtualIndexOfPoint = significandEndIndex;
/*     */     } else {
/* 293 */       digitCount = significandEndIndex - significandStartIndex - 1;
/* 294 */       exponent = Math.min(virtualIndexOfPoint - index + 1, 1024) * 4;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 299 */     int expNumber = 0;
/* 300 */     boolean hasExponent = (ch == 'p' || ch == 'P');
/* 301 */     if (hasExponent) {
/* 302 */       ch = (++index < endIndex) ? str.charAt(index) : Character.MIN_VALUE;
/* 303 */       boolean neg_exp = (ch == '-');
/* 304 */       if (neg_exp || ch == '+') {
/* 305 */         ch = (++index < endIndex) ? str.charAt(index) : Character.MIN_VALUE;
/*     */       }
/* 307 */       i |= !isDigit(ch) ? 1 : 0;
/*     */       
/*     */       while (true) {
/* 310 */         if (expNumber < 1024) {
/* 311 */           expNumber = 10 * expNumber + ch - 48;
/*     */         }
/* 313 */         ch = (++index < endIndex) ? str.charAt(index) : Character.MIN_VALUE;
/* 314 */         if (!isDigit(ch)) {
/* 315 */           if (neg_exp) {
/* 316 */             expNumber = -expNumber;
/*     */           }
/* 318 */           exponent += expNumber;
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/* 323 */     if (index < endIndex && (ch == 'd' || ch == 'D' || ch == 'f' || ch == 'F')) {
/* 324 */       index++;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 329 */     index = skipWhitespace(str, index, endIndex);
/* 330 */     if (i != 0 || index < endIndex || digitCount == 0 || !hasExponent)
/*     */     {
/*     */       
/* 333 */       return -1L;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 339 */     int skipCountInTruncatedDigits = 0;
/* 340 */     if (digitCount > 16) {
/* 341 */       significand = 0L;
/* 342 */       for (index = significandStartIndex; index < significandEndIndex; index++) {
/* 343 */         ch = str.charAt(index);
/*     */         
/* 345 */         int hexValue = (ch > '') ? -1 : AbstractFloatValueParser.CHAR_TO_HEX_MAP[ch];
/* 346 */         if (hexValue >= 0) {
/* 347 */           if (Long.compareUnsigned(significand, 1000000000000000000L) < 0) {
/* 348 */             significand = significand << 4L | hexValue;
/*     */           } else {
/*     */             break;
/*     */           } 
/*     */         } else {
/* 353 */           skipCountInTruncatedDigits++;
/*     */         } 
/*     */       } 
/* 356 */       isSignificandTruncated = (index < significandEndIndex);
/*     */     } else {
/* 358 */       isSignificandTruncated = false;
/*     */     } 
/*     */     
/* 361 */     return valueOfHexLiteral(str, startIndex, endIndex, isNegative, significand, exponent, isSignificandTruncated, virtualIndexOfPoint - index + skipCountInTruncatedDigits + expNumber);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private long parseInfinity(CharSequence str, int index, int endIndex, boolean negative) {
/* 382 */     if (index + 7 < endIndex && str
/* 383 */       .charAt(index) == 'I' && str
/* 384 */       .charAt(index + 1) == 'n' && str
/* 385 */       .charAt(index + 2) == 'f' && str
/* 386 */       .charAt(index + 3) == 'i' && str
/* 387 */       .charAt(index + 4) == 'n' && str
/* 388 */       .charAt(index + 5) == 'i' && str
/* 389 */       .charAt(index + 6) == 't' && str
/* 390 */       .charAt(index + 7) == 'y') {
/*     */       
/* 392 */       index = skipWhitespace(str, index + 8, endIndex);
/* 393 */       if (index == endIndex) {
/* 394 */         return negative ? negativeInfinity() : positiveInfinity();
/*     */       }
/*     */     } 
/* 397 */     return -1L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private long parseNaN(CharSequence str, int index, int endIndex) {
/* 419 */     if (index + 2 < endIndex && str
/*     */       
/* 421 */       .charAt(index + 1) == 'a' && str
/* 422 */       .charAt(index + 2) == 'N') {
/*     */       
/* 424 */       index = skipWhitespace(str, index + 3, endIndex);
/* 425 */       if (index == endIndex) {
/* 426 */         return nan();
/*     */       }
/*     */     } 
/* 429 */     return -1L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int skipWhitespace(CharSequence str, int index, int endIndex) {
/* 441 */     for (; index < endIndex && 
/* 442 */       str.charAt(index) <= ' '; index++);
/*     */ 
/*     */ 
/*     */     
/* 446 */     return index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int tryToParseEightDigits(CharSequence str, int offset) {
/* 455 */     long first = str.charAt(offset) | str.charAt(offset + 1) << 16L | str.charAt(offset + 2) << 32L | str.charAt(offset + 3) << 48L;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 460 */     long second = str.charAt(offset + 4) | str.charAt(offset + 5) << 16L | str.charAt(offset + 6) << 32L | str.charAt(offset + 7) << 48L;
/*     */     
/* 462 */     return FastDoubleSwar.tryToParseEightDigitsUtf16(first, second);
/*     */   }
/*     */   
/*     */   abstract long nan();
/*     */   
/*     */   abstract long negativeInfinity();
/*     */   
/*     */   abstract long positiveInfinity();
/*     */   
/*     */   abstract long valueOfFloatLiteral(CharSequence paramCharSequence, int paramInt1, int paramInt2, boolean paramBoolean1, long paramLong, int paramInt3, boolean paramBoolean2, int paramInt4);
/*     */   
/*     */   abstract long valueOfHexLiteral(CharSequence paramCharSequence, int paramInt1, int paramInt2, boolean paramBoolean1, long paramLong, int paramInt3, boolean paramBoolean2, int paramInt4);
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-core-2.14.2.jar!\com\fasterxml\jackson\core\io\doubleparser\AbstractFloatingPointBitsFromCharSequence.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */