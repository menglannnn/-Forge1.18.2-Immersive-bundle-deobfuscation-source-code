/*     */ package com.fasterxml.jackson.core.io.doubleparser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class FastDoubleSwar
/*     */ {
/*     */   public static int tryToParseEightDigitsUtf16(char[] a, int offset) {
/*  48 */     long first = a[offset] | a[offset + 1] << 16L | a[offset + 2] << 32L | a[offset + 3] << 48L;
/*     */ 
/*     */ 
/*     */     
/*  52 */     long second = a[offset + 4] | a[offset + 5] << 16L | a[offset + 6] << 32L | a[offset + 7] << 48L;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  57 */     return tryToParseEightDigitsUtf16(first, second);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int tryToParseEightDigitsUtf16(long first, long second) {
/*  75 */     long fval = first - 13511005043687472L;
/*  76 */     long sval = second - 13511005043687472L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  82 */     long fpre = first + 19703549022044230L | fval;
/*  83 */     long spre = second + 19703549022044230L | sval;
/*  84 */     if (((fpre | spre) & 0xFF80FF80FF80FF80L) != 0L) {
/*  85 */       return -1;
/*     */     }
/*     */     
/*  88 */     return (int)(sval * 281475406208040961L >>> 48L) + (int)(fval * 281475406208040961L >>> 48L) * 10000;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int tryToParseEightDigitsUtf8(byte[] a, int offset) {
/* 102 */     return tryToParseEightDigitsUtf8(readLongFromByteArrayLittleEndian(a, offset));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int tryToParseEightDigitsUtf8(long chunk) {
/* 128 */     long val = chunk - 3472328296227680304L;
/* 129 */     long predicate = (chunk + 5063812098665367110L | val) & 0x8080808080808080L;
/* 130 */     if (predicate != 0L) {
/* 131 */       return -1;
/*     */     }
/*     */ 
/*     */     
/* 135 */     val = val * 2561L >>> 8L;
/* 136 */     val = (val & 0xFF000000FFL) * 4294967296000100L + (val >>> 16L & 0xFF000000FFL) * 42949672960001L >>> 32L;
/*     */     
/* 138 */     return (int)val;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long tryToParseEightHexDigitsUtf16(char[] a, int offset) {
/* 153 */     long first = a[offset] << 48L | a[offset + 1] << 32L | a[offset + 2] << 16L | a[offset + 3];
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 158 */     long second = a[offset + 4] << 48L | a[offset + 5] << 32L | a[offset + 6] << 16L | a[offset + 7];
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 163 */     return tryToParseEightHexDigitsUtf16(first, second);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long tryToParseEightHexDigitsUtf16(long first, long second) {
/* 189 */     long lfirst = tryToParseFourHexDigitsUtf16(first);
/* 190 */     long lsecond = tryToParseFourHexDigitsUtf16(second);
/* 191 */     return lfirst << 16L | lsecond;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long tryToParseEightHexDigitsUtf8(byte[] a, int offset) {
/* 203 */     return tryToParseEightHexDigitsUtf8(readLongFromByteArrayBigEndian(a, offset));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long tryToParseEightHexDigitsUtf8(long chunk) {
/* 220 */     long vec = chunk - 3472328296227680304L;
/*     */ 
/*     */ 
/*     */     
/* 224 */     long gt_09 = vec + 8536140394893047414L;
/* 225 */     gt_09 &= 0x8080808080808080L;
/*     */ 
/*     */     
/* 228 */     long ge_30 = vec + 5714873654208057167L;
/* 229 */     ge_30 &= 0x8080808080808080L;
/*     */ 
/*     */     
/* 232 */     long le_37 = 3978709506094217015L + (vec ^ 0x7F7F7F7F7F7F7F7FL);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 239 */     if (gt_09 != (ge_30 & le_37)) {
/* 240 */       return -1L;
/*     */     }
/*     */ 
/*     */     
/* 244 */     long gt_09mask = (gt_09 >>> 7L) * 255L;
/*     */ 
/*     */     
/* 247 */     long v = vec & (gt_09mask ^ 0xFFFFFFFFFFFFFFFFL) | vec - (0x2727272727272727L & gt_09mask);
/*     */ 
/*     */     
/* 250 */     long v2 = v | v >>> 4L;
/* 251 */     long v3 = v2 & 0xFF00FF00FF00FFL;
/* 252 */     long v4 = v3 | v3 >>> 8L;
/* 253 */     long v5 = v4 >>> 16L & 0xFFFF0000L | v4 & 0xFFFFL;
/*     */     
/* 255 */     return v5;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long tryToParseFourHexDigitsUtf16(long chunk) {
/* 272 */     long vec = chunk - 13511005043687472L;
/*     */ 
/*     */ 
/*     */     
/* 276 */     long gt_09 = vec + 9220697983773212662L;
/* 277 */     gt_09 &= 0x8000800080008000L;
/*     */ 
/*     */     
/* 280 */     long ge_30 = vec + 9209720292175216591L;
/* 281 */     ge_30 &= 0x8000800080008000L;
/*     */ 
/*     */     
/* 284 */     long le_37 = 15481359945891895L + (vec ^ 0x7FFF7FFF7FFF7FFFL);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 291 */     if (gt_09 != (ge_30 & le_37)) {
/* 292 */       return -1L;
/*     */     }
/*     */ 
/*     */     
/* 296 */     long gt_09mask = (gt_09 >>> 15L) * 65535L;
/*     */ 
/*     */     
/* 299 */     long v = vec & (gt_09mask ^ 0xFFFFFFFFFFFFFFFFL) | vec - (0x27002700270027L & gt_09mask);
/*     */ 
/*     */     
/* 302 */     long v2 = v | v >>> 12L;
/* 303 */     long v5 = (v2 | v2 >>> 24L) & 0xFFFFL;
/*     */     
/* 305 */     return v5;
/*     */   }
/*     */   
/*     */   public static long readLongFromByteArrayLittleEndian(byte[] a, int offset) {
/* 309 */     return (a[offset + 7] & 0xFFL) << 56L | (a[offset + 6] & 0xFFL) << 48L | (a[offset + 5] & 0xFFL) << 40L | (a[offset + 4] & 0xFFL) << 32L | (a[offset + 3] & 0xFFL) << 24L | (a[offset + 2] & 0xFFL) << 16L | (a[offset + 1] & 0xFFL) << 8L | a[offset] & 0xFFL;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long readLongFromByteArrayBigEndian(byte[] a, int offset) {
/* 320 */     return (a[offset] & 0xFFL) << 56L | (a[offset + 1] & 0xFFL) << 48L | (a[offset + 2] & 0xFFL) << 40L | (a[offset + 3] & 0xFFL) << 32L | (a[offset + 4] & 0xFFL) << 24L | (a[offset + 5] & 0xFFL) << 16L | (a[offset + 6] & 0xFFL) << 8L | a[offset + 7] & 0xFFL;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-core-2.14.2.jar!\com\fasterxml\jackson\core\io\doubleparser\FastDoubleSwar.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */