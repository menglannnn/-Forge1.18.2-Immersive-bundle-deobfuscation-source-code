/*     */ package com.fasterxml.jackson.core.filter;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.JsonProcessingException;
/*     */ import com.fasterxml.jackson.core.JsonStreamContext;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TokenFilterContext
/*     */   extends JsonStreamContext
/*     */ {
/*     */   protected final TokenFilterContext _parent;
/*     */   protected TokenFilterContext _child;
/*     */   protected String _currentName;
/*     */   protected TokenFilter _filter;
/*     */   protected boolean _startHandled;
/*     */   protected boolean _needToHandleName;
/*     */   
/*     */   protected TokenFilterContext(int type, TokenFilterContext parent, TokenFilter filter, boolean startHandled) {
/*  72 */     this._type = type;
/*  73 */     this._parent = parent;
/*  74 */     this._filter = filter;
/*  75 */     this._index = -1;
/*  76 */     this._startHandled = startHandled;
/*  77 */     this._needToHandleName = false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected TokenFilterContext reset(int type, TokenFilter filter, boolean startWritten) {
/*  83 */     this._type = type;
/*  84 */     this._filter = filter;
/*  85 */     this._index = -1;
/*  86 */     this._currentName = null;
/*  87 */     this._startHandled = startWritten;
/*  88 */     this._needToHandleName = false;
/*  89 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TokenFilterContext createRootContext(TokenFilter filter) {
/* 100 */     return new TokenFilterContext(0, null, filter, true);
/*     */   }
/*     */   
/*     */   public TokenFilterContext createChildArrayContext(TokenFilter filter, boolean writeStart) {
/* 104 */     TokenFilterContext ctxt = this._child;
/* 105 */     if (ctxt == null) {
/* 106 */       this._child = ctxt = new TokenFilterContext(1, this, filter, writeStart);
/* 107 */       return ctxt;
/*     */     } 
/* 109 */     return ctxt.reset(1, filter, writeStart);
/*     */   }
/*     */   
/*     */   public TokenFilterContext createChildObjectContext(TokenFilter filter, boolean writeStart) {
/* 113 */     TokenFilterContext ctxt = this._child;
/* 114 */     if (ctxt == null) {
/* 115 */       this._child = ctxt = new TokenFilterContext(2, this, filter, writeStart);
/* 116 */       return ctxt;
/*     */     } 
/* 118 */     return ctxt.reset(2, filter, writeStart);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TokenFilter setFieldName(String name) throws JsonProcessingException {
/* 128 */     this._currentName = name;
/* 129 */     this._needToHandleName = true;
/* 130 */     return this._filter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TokenFilter checkValue(TokenFilter filter) {
/* 143 */     if (this._type == 2) {
/* 144 */       return filter;
/*     */     }
/*     */     
/* 147 */     int ix = ++this._index;
/* 148 */     if (this._type == 1) {
/* 149 */       return filter.includeElement(ix);
/*     */     }
/* 151 */     return filter.includeRootValue(ix);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void ensureFieldNameWritten(JsonGenerator gen) throws IOException {
/* 165 */     if (this._needToHandleName) {
/* 166 */       this._needToHandleName = false;
/* 167 */       gen.writeFieldName(this._currentName);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writePath(JsonGenerator gen) throws IOException {
/* 182 */     if (this._filter == null || this._filter == TokenFilter.INCLUDE_ALL) {
/*     */       return;
/*     */     }
/* 185 */     if (this._parent != null) {
/* 186 */       this._parent._writePath(gen);
/*     */     }
/* 188 */     if (this._startHandled) {
/*     */       
/* 190 */       if (this._needToHandleName) {
/* 191 */         gen.writeFieldName(this._currentName);
/*     */       }
/*     */     } else {
/* 194 */       this._startHandled = true;
/* 195 */       if (this._type == 2) {
/* 196 */         gen.writeStartObject();
/* 197 */         gen.writeFieldName(this._currentName);
/* 198 */       } else if (this._type == 1) {
/* 199 */         gen.writeStartArray();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void _writePath(JsonGenerator gen) throws IOException {
/* 206 */     if (this._filter == null || this._filter == TokenFilter.INCLUDE_ALL) {
/*     */       return;
/*     */     }
/* 209 */     if (this._parent != null) {
/* 210 */       this._parent._writePath(gen);
/*     */     }
/* 212 */     if (this._startHandled) {
/*     */       
/* 214 */       if (this._needToHandleName) {
/* 215 */         this._needToHandleName = false;
/* 216 */         gen.writeFieldName(this._currentName);
/*     */       } 
/*     */     } else {
/* 219 */       this._startHandled = true;
/* 220 */       if (this._type == 2) {
/* 221 */         gen.writeStartObject();
/* 222 */         if (this._needToHandleName) {
/* 223 */           this._needToHandleName = false;
/* 224 */           gen.writeFieldName(this._currentName);
/*     */         } 
/* 226 */       } else if (this._type == 1) {
/* 227 */         gen.writeStartArray();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public TokenFilterContext closeArray(JsonGenerator gen) throws IOException {
/* 234 */     if (this._startHandled) {
/* 235 */       gen.writeEndArray();
/*     */     }
/* 237 */     else if (this._filter != null && this._filter != TokenFilter.INCLUDE_ALL && 
/* 238 */       this._filter.includeEmptyArray(hasCurrentIndex())) {
/* 239 */       if (this._parent != null) {
/* 240 */         this._parent._writePath(gen);
/*     */       }
/* 242 */       gen.writeStartArray();
/* 243 */       gen.writeEndArray();
/*     */     } 
/*     */ 
/*     */     
/* 247 */     if (this._filter != null && this._filter != TokenFilter.INCLUDE_ALL) {
/* 248 */       this._filter.filterFinishArray();
/*     */     }
/* 250 */     return this._parent;
/*     */   }
/*     */ 
/*     */   
/*     */   public TokenFilterContext closeObject(JsonGenerator gen) throws IOException {
/* 255 */     if (this._startHandled) {
/* 256 */       gen.writeEndObject();
/*     */     }
/* 258 */     else if (this._filter != null && this._filter != TokenFilter.INCLUDE_ALL && 
/* 259 */       this._filter.includeEmptyObject(hasCurrentName())) {
/* 260 */       if (this._parent != null) {
/* 261 */         this._parent._writePath(gen);
/*     */       }
/* 263 */       gen.writeStartObject();
/* 264 */       gen.writeEndObject();
/*     */     } 
/*     */ 
/*     */     
/* 268 */     if (this._filter != null && this._filter != TokenFilter.INCLUDE_ALL) {
/* 269 */       this._filter.filterFinishObject();
/*     */     }
/* 271 */     return this._parent;
/*     */   }
/*     */   
/*     */   public void skipParentChecks() {
/* 275 */     this._filter = null;
/* 276 */     for (TokenFilterContext ctxt = this._parent; ctxt != null; ctxt = ctxt._parent) {
/* 277 */       this._parent._filter = null;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getCurrentValue() {
/* 288 */     return null;
/*     */   }
/*     */   
/*     */   public void setCurrentValue(Object v) {}
/*     */   
/* 293 */   public final TokenFilterContext getParent() { return this._parent; } public final String getCurrentName() {
/* 294 */     return this._currentName;
/*     */   } public boolean hasCurrentName() {
/* 296 */     return (this._currentName != null);
/*     */   }
/* 298 */   public TokenFilter getFilter() { return this._filter; } public boolean isStartHandled() {
/* 299 */     return this._startHandled;
/*     */   }
/*     */   public JsonToken nextTokenToRead() {
/* 302 */     if (!this._startHandled) {
/* 303 */       this._startHandled = true;
/* 304 */       if (this._type == 2) {
/* 305 */         return JsonToken.START_OBJECT;
/*     */       }
/*     */       
/* 308 */       return JsonToken.START_ARRAY;
/*     */     } 
/*     */     
/* 311 */     if (this._needToHandleName && this._type == 2) {
/* 312 */       this._needToHandleName = false;
/* 313 */       return JsonToken.FIELD_NAME;
/*     */     } 
/* 315 */     return null;
/*     */   }
/*     */   
/*     */   public TokenFilterContext findChildOf(TokenFilterContext parent) {
/* 319 */     if (this._parent == parent) {
/* 320 */       return this;
/*     */     }
/* 322 */     TokenFilterContext curr = this._parent;
/* 323 */     while (curr != null) {
/* 324 */       TokenFilterContext p = curr._parent;
/* 325 */       if (p == parent) {
/* 326 */         return curr;
/*     */       }
/* 328 */       curr = p;
/*     */     } 
/*     */     
/* 331 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void appendDesc(StringBuilder sb) {
/* 337 */     if (this._parent != null) {
/* 338 */       this._parent.appendDesc(sb);
/*     */     }
/* 340 */     if (this._type == 2) {
/* 341 */       sb.append('{');
/* 342 */       if (this._currentName != null) {
/* 343 */         sb.append('"');
/*     */         
/* 345 */         sb.append(this._currentName);
/* 346 */         sb.append('"');
/*     */       } else {
/* 348 */         sb.append('?');
/*     */       } 
/* 350 */       sb.append('}');
/* 351 */     } else if (this._type == 1) {
/* 352 */       sb.append('[');
/* 353 */       sb.append(getCurrentIndex());
/* 354 */       sb.append(']');
/*     */     } else {
/*     */       
/* 357 */       sb.append("/");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 366 */     StringBuilder sb = new StringBuilder(64);
/* 367 */     appendDesc(sb);
/* 368 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-core-2.14.2.jar!\com\fasterxml\jackson\core\filter\TokenFilterContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */