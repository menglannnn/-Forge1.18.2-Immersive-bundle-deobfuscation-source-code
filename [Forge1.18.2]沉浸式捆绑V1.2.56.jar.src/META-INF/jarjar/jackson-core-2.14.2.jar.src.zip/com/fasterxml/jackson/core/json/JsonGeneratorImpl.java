/*     */ package com.fasterxml.jackson.core.json;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.ObjectCodec;
/*     */ import com.fasterxml.jackson.core.SerializableString;
/*     */ import com.fasterxml.jackson.core.StreamWriteCapability;
/*     */ import com.fasterxml.jackson.core.Version;
/*     */ import com.fasterxml.jackson.core.base.GeneratorBase;
/*     */ import com.fasterxml.jackson.core.io.CharTypes;
/*     */ import com.fasterxml.jackson.core.io.CharacterEscapes;
/*     */ import com.fasterxml.jackson.core.io.IOContext;
/*     */ import com.fasterxml.jackson.core.util.DefaultPrettyPrinter;
/*     */ import com.fasterxml.jackson.core.util.JacksonFeatureSet;
/*     */ import com.fasterxml.jackson.core.util.VersionUtil;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class JsonGeneratorImpl
/*     */   extends GeneratorBase
/*     */ {
/*  32 */   protected static final int[] sOutputEscapes = CharTypes.get7BitOutputEscapes();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  40 */   protected static final JacksonFeatureSet<StreamWriteCapability> JSON_WRITE_CAPABILITIES = DEFAULT_TEXTUAL_WRITE_CAPABILITIES;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final IOContext _ioContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  63 */   protected int[] _outputEscapes = sOutputEscapes;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int _maximumNonEscapedChar;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected CharacterEscapes _characterEscapes;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  94 */   protected SerializableString _rootValueSeparator = (SerializableString)DefaultPrettyPrinter.DEFAULT_ROOT_VALUE_SEPARATOR;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean _cfgUnqNames;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean _cfgWriteHexUppercase;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonGeneratorImpl(IOContext ctxt, int features, ObjectCodec codec) {
/* 122 */     super(features, codec);
/* 123 */     this._ioContext = ctxt;
/* 124 */     if (JsonGenerator.Feature.ESCAPE_NON_ASCII.enabledIn(features))
/*     */     {
/* 126 */       this._maximumNonEscapedChar = 127;
/*     */     }
/* 128 */     this._cfgWriteHexUppercase = JsonGenerator.Feature.WRITE_HEX_UPPER_CASE.enabledIn(features);
/* 129 */     this._cfgUnqNames = !JsonGenerator.Feature.QUOTE_FIELD_NAMES.enabledIn(features);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Version version() {
/* 140 */     return VersionUtil.versionFor(getClass());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonGenerator enable(JsonGenerator.Feature f) {
/* 152 */     super.enable(f);
/* 153 */     if (f == JsonGenerator.Feature.QUOTE_FIELD_NAMES) {
/* 154 */       this._cfgUnqNames = false;
/* 155 */     } else if (f == JsonGenerator.Feature.WRITE_HEX_UPPER_CASE) {
/* 156 */       this._cfgWriteHexUppercase = true;
/*     */     } 
/* 158 */     return (JsonGenerator)this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonGenerator disable(JsonGenerator.Feature f) {
/* 164 */     super.disable(f);
/* 165 */     if (f == JsonGenerator.Feature.QUOTE_FIELD_NAMES) {
/* 166 */       this._cfgUnqNames = true;
/* 167 */     } else if (f == JsonGenerator.Feature.WRITE_HEX_UPPER_CASE) {
/* 168 */       this._cfgWriteHexUppercase = false;
/*     */     } 
/* 170 */     return (JsonGenerator)this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _checkStdFeatureChanges(int newFeatureFlags, int changedFeatures) {
/* 176 */     super._checkStdFeatureChanges(newFeatureFlags, changedFeatures);
/* 177 */     this._cfgUnqNames = !JsonGenerator.Feature.QUOTE_FIELD_NAMES.enabledIn(newFeatureFlags);
/* 178 */     this._cfgWriteHexUppercase = JsonGenerator.Feature.WRITE_HEX_UPPER_CASE.enabledIn(newFeatureFlags);
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonGenerator setHighestNonEscapedChar(int charCode) {
/* 183 */     this._maximumNonEscapedChar = (charCode < 0) ? 0 : charCode;
/* 184 */     return (JsonGenerator)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getHighestEscapedChar() {
/* 189 */     return this._maximumNonEscapedChar;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonGenerator setCharacterEscapes(CharacterEscapes esc) {
/* 195 */     this._characterEscapes = esc;
/* 196 */     if (esc == null) {
/* 197 */       this._outputEscapes = sOutputEscapes;
/*     */     } else {
/* 199 */       this._outputEscapes = esc.getEscapeCodesForAscii();
/*     */     } 
/* 201 */     return (JsonGenerator)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CharacterEscapes getCharacterEscapes() {
/* 210 */     return this._characterEscapes;
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonGenerator setRootValueSeparator(SerializableString sep) {
/* 215 */     this._rootValueSeparator = sep;
/* 216 */     return (JsonGenerator)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public JacksonFeatureSet<StreamWriteCapability> getWriteCapabilities() {
/* 221 */     return JSON_WRITE_CAPABILITIES;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _verifyPrettyValueWrite(String typeMsg, int status) throws IOException {
/* 233 */     switch (status) {
/*     */       case 1:
/* 235 */         this._cfgPrettyPrinter.writeArrayValueSeparator((JsonGenerator)this);
/*     */         return;
/*     */       case 2:
/* 238 */         this._cfgPrettyPrinter.writeObjectFieldValueSeparator((JsonGenerator)this);
/*     */         return;
/*     */       case 3:
/* 241 */         this._cfgPrettyPrinter.writeRootValueSeparator((JsonGenerator)this);
/*     */         return;
/*     */       
/*     */       case 0:
/* 245 */         if (this._writeContext.inArray()) {
/* 246 */           this._cfgPrettyPrinter.beforeArrayValues((JsonGenerator)this);
/* 247 */         } else if (this._writeContext.inObject()) {
/* 248 */           this._cfgPrettyPrinter.beforeObjectEntries((JsonGenerator)this);
/*     */         } 
/*     */         return;
/*     */       case 5:
/* 252 */         _reportCantWriteValueExpectName(typeMsg);
/*     */         return;
/*     */     } 
/* 255 */     _throwInternal();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _reportCantWriteValueExpectName(String typeMsg) throws IOException {
/* 262 */     _reportError(String.format("Can not %s, expecting field name (context: %s)", new Object[] { typeMsg, this._writeContext
/* 263 */             .typeDesc() }));
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-core-2.14.2.jar!\com\fasterxml\jackson\core\json\JsonGeneratorImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */