/*     */ package com.fasterxml.jackson.core;
/*     */ 
/*     */ import com.fasterxml.jackson.core.io.DataOutputAsStream;
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.Reader;
/*     */ import java.io.Serializable;
/*     */ import java.io.Writer;
/*     */ import java.net.URL;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TokenStreamFactory
/*     */   implements Versioned, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 2L;
/*     */   
/*     */   public abstract boolean requiresPropertyOrdering();
/*     */   
/*     */   public abstract boolean canHandleBinaryNatively();
/*     */   
/*     */   public abstract boolean canParseAsync();
/*     */   
/*     */   public abstract Class<? extends FormatFeature> getFormatReadFeatureType();
/*     */   
/*     */   public abstract Class<? extends FormatFeature> getFormatWriteFeatureType();
/*     */   
/*     */   public abstract boolean canUseSchema(FormatSchema paramFormatSchema);
/*     */   
/*     */   public abstract String getFormatName();
/*     */   
/*     */   public abstract boolean isEnabled(JsonParser.Feature paramFeature);
/*     */   
/*     */   public abstract boolean isEnabled(JsonGenerator.Feature paramFeature);
/*     */   
/*     */   public abstract int getParserFeatures();
/*     */   
/*     */   public abstract int getGeneratorFeatures();
/*     */   
/*     */   public abstract int getFormatParserFeatures();
/*     */   
/*     */   public abstract int getFormatGeneratorFeatures();
/*     */   
/*     */   public abstract JsonParser createParser(byte[] paramArrayOfbyte) throws IOException;
/*     */   
/*     */   public abstract JsonParser createParser(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException;
/*     */   
/*     */   public abstract JsonParser createParser(char[] paramArrayOfchar) throws IOException;
/*     */   
/*     */   public abstract JsonParser createParser(char[] paramArrayOfchar, int paramInt1, int paramInt2) throws IOException;
/*     */   
/*     */   public abstract JsonParser createParser(DataInput paramDataInput) throws IOException;
/*     */   
/*     */   public abstract JsonParser createParser(File paramFile) throws IOException;
/*     */   
/*     */   public abstract JsonParser createParser(InputStream paramInputStream) throws IOException;
/*     */   
/*     */   public abstract JsonParser createParser(Reader paramReader) throws IOException;
/*     */   
/*     */   public abstract JsonParser createParser(String paramString) throws IOException;
/*     */   
/*     */   public abstract JsonParser createParser(URL paramURL) throws IOException;
/*     */   
/*     */   public abstract JsonParser createNonBlockingByteArrayParser() throws IOException;
/*     */   
/*     */   public abstract JsonParser createNonBlockingByteBufferParser() throws IOException;
/*     */   
/*     */   public abstract JsonGenerator createGenerator(DataOutput paramDataOutput, JsonEncoding paramJsonEncoding) throws IOException;
/*     */   
/*     */   public abstract JsonGenerator createGenerator(DataOutput paramDataOutput) throws IOException;
/*     */   
/*     */   public abstract JsonGenerator createGenerator(File paramFile, JsonEncoding paramJsonEncoding) throws IOException;
/*     */   
/*     */   public abstract JsonGenerator createGenerator(OutputStream paramOutputStream) throws IOException;
/*     */   
/*     */   public abstract JsonGenerator createGenerator(OutputStream paramOutputStream, JsonEncoding paramJsonEncoding) throws IOException;
/*     */   
/*     */   public abstract JsonGenerator createGenerator(Writer paramWriter) throws IOException;
/*     */   
/*     */   protected OutputStream _createDataOutputWrapper(DataOutput out) {
/* 213 */     return (OutputStream)new DataOutputAsStream(out);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected InputStream _optimizedStreamFromURL(URL url) throws IOException {
/* 228 */     if ("file".equals(url.getProtocol())) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 235 */       String host = url.getHost();
/* 236 */       if (host == null || host.length() == 0) {
/*     */         
/* 238 */         String path = url.getPath();
/* 239 */         if (path.indexOf('%') < 0) {
/* 240 */           return new FileInputStream(url.getPath());
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 246 */     return url.openStream();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected InputStream _fileInputStream(File f) throws IOException {
/* 262 */     return new FileInputStream(f);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OutputStream _fileOutputStream(File f) throws IOException {
/* 278 */     return new FileOutputStream(f);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _checkRangeBoundsForByteArray(byte[] data, int offset, int len) throws IllegalArgumentException {
/* 291 */     if (data == null) {
/* 292 */       _reportRangeError("Invalid `byte[]` argument: `null`");
/*     */     }
/* 294 */     int dataLen = data.length;
/* 295 */     int end = offset + len;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 305 */     int anyNegs = offset | len | end | dataLen - end;
/* 306 */     if (anyNegs < 0) {
/* 307 */       _reportRangeError(String.format("Invalid 'offset' (%d) and/or 'len' (%d) arguments for `byte[]` of length %d", new Object[] {
/*     */               
/* 309 */               Integer.valueOf(offset), Integer.valueOf(len), Integer.valueOf(dataLen)
/*     */             }));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _checkRangeBoundsForCharArray(char[] data, int offset, int len) throws IOException {
/* 317 */     if (data == null) {
/* 318 */       _reportRangeError("Invalid `char[]` argument: `null`");
/*     */     }
/* 320 */     int dataLen = data.length;
/* 321 */     int end = offset + len;
/*     */     
/* 323 */     int anyNegs = offset | len | end | dataLen - end;
/* 324 */     if (anyNegs < 0) {
/* 325 */       _reportRangeError(String.format("Invalid 'offset' (%d) and/or 'len' (%d) arguments for `char[]` of length %d", new Object[] {
/*     */               
/* 327 */               Integer.valueOf(offset), Integer.valueOf(len), Integer.valueOf(dataLen)
/*     */             }));
/*     */     }
/*     */   }
/*     */   
/*     */   protected <T> T _reportRangeError(String msg) throws IllegalArgumentException {
/* 333 */     throw new IllegalArgumentException(msg);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-core-2.14.2.jar!\com\fasterxml\jackson\core\TokenStreamFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */