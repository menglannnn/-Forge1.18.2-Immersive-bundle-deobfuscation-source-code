/*     */ package com.fasterxml.jackson.core.io.doubleparser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FastDoubleParser
/*     */ {
/*  18 */   private static final DoubleBitsFromCharArray CHAR_ARRAY_PARSER = new DoubleBitsFromCharArray();
/*  19 */   private static final DoubleBitsFromCharSequence CHAR_SEQ_PARSER = new DoubleBitsFromCharSequence();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double parseDouble(CharSequence str) throws NumberFormatException {
/*  36 */     return parseDouble(str, 0, str.length());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double parseDouble(CharSequence str, int offset, int length) throws NumberFormatException {
/*  52 */     long bitPattern = CHAR_SEQ_PARSER.parseFloatingPointLiteral(str, offset, length);
/*  53 */     if (bitPattern == -1L) {
/*  54 */       throw new NumberFormatException("Illegal input");
/*     */     }
/*  56 */     return Double.longBitsToDouble(bitPattern);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double parseDouble(char[] str) throws NumberFormatException {
/*  67 */     return parseDouble(str, 0, str.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double parseDouble(char[] str, int offset, int length) throws NumberFormatException {
/*  84 */     long bitPattern = CHAR_ARRAY_PARSER.parseFloatingPointLiteral(str, offset, length);
/*  85 */     if (bitPattern == -1L) {
/*  86 */       throw new NumberFormatException("Illegal input");
/*     */     }
/*  88 */     return Double.longBitsToDouble(bitPattern);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long parseDoubleBits(CharSequence str, int offset, int length) {
/* 114 */     return CHAR_SEQ_PARSER.parseFloatingPointLiteral(str, offset, length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long parseDoubleBits(char[] str, int offset, int length) {
/* 133 */     return CHAR_ARRAY_PARSER.parseFloatingPointLiteral(str, offset, length);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-core-2.14.2.jar!\com\fasterxml\jackson\core\io\doubleparser\FastDoubleParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */