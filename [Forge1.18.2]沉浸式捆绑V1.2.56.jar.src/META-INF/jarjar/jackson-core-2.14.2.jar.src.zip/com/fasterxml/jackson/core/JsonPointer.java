/*     */ package com.fasterxml.jackson.core;
/*     */ 
/*     */ import com.fasterxml.jackson.core.io.NumberInput;
/*     */ import java.io.Externalizable;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInput;
/*     */ import java.io.ObjectOutput;
/*     */ import java.io.ObjectStreamException;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JsonPointer
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   public static final char SEPARATOR = '/';
/*  42 */   protected static final JsonPointer EMPTY = new JsonPointer();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final JsonPointer _nextSegment;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected volatile JsonPointer _head;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final String _asString;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final int _asStringOffset;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final String _matchingPropertyName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final int _matchingElementIndex;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int _hashCode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonPointer() {
/* 105 */     this._nextSegment = null;
/*     */     
/* 107 */     this._matchingPropertyName = null;
/* 108 */     this._matchingElementIndex = -1;
/* 109 */     this._asString = "";
/* 110 */     this._asStringOffset = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonPointer(String fullString, int fullStringOffset, String segment, JsonPointer next) {
/* 117 */     this._asString = fullString;
/* 118 */     this._asStringOffset = fullStringOffset;
/* 119 */     this._nextSegment = next;
/*     */     
/* 121 */     this._matchingPropertyName = segment;
/*     */     
/* 123 */     this._matchingElementIndex = _parseIndex(segment);
/*     */   }
/*     */ 
/*     */   
/*     */   protected JsonPointer(String fullString, int fullStringOffset, String segment, int matchIndex, JsonPointer next) {
/* 128 */     this._asString = fullString;
/* 129 */     this._asStringOffset = fullStringOffset;
/* 130 */     this._nextSegment = next;
/* 131 */     this._matchingPropertyName = segment;
/* 132 */     this._matchingElementIndex = matchIndex;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JsonPointer compile(String expr) throws IllegalArgumentException {
/* 157 */     if (expr == null || expr.length() == 0) {
/* 158 */       return EMPTY;
/*     */     }
/*     */     
/* 161 */     if (expr.charAt(0) != '/') {
/* 162 */       throw new IllegalArgumentException("Invalid input: JSON Pointer expression must start with '/': \"" + expr + "\"");
/*     */     }
/* 164 */     return _parseTail(expr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JsonPointer valueOf(String expr) {
/* 175 */     return compile(expr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JsonPointer empty() {
/* 188 */     return EMPTY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JsonPointer forPath(JsonStreamContext context, boolean includeRoot) {
/* 207 */     if (context == null) {
/* 208 */       return EMPTY;
/*     */     }
/*     */ 
/*     */     
/* 212 */     if (!context.hasPathSegment())
/*     */     {
/* 214 */       if (!includeRoot || !context.inRoot() || !context.hasCurrentIndex()) {
/* 215 */         context = context.getParent();
/*     */       }
/*     */     }
/*     */     
/* 219 */     PointerSegment next = null;
/* 220 */     int approxLength = 0;
/*     */     
/* 222 */     for (; context != null; context = context.getParent()) {
/* 223 */       if (context.inObject()) {
/* 224 */         String propName = context.getCurrentName();
/* 225 */         if (propName == null) {
/* 226 */           propName = "";
/*     */         }
/* 228 */         approxLength += 2 + propName.length();
/* 229 */         next = new PointerSegment(next, propName, -1);
/* 230 */       } else if (context.inArray() || includeRoot) {
/* 231 */         int ix = context.getCurrentIndex();
/* 232 */         approxLength += 6;
/* 233 */         next = new PointerSegment(next, null, ix);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 239 */     if (next == null) {
/* 240 */       return EMPTY;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 245 */     StringBuilder pathBuilder = new StringBuilder(approxLength);
/* 246 */     PointerSegment last = null;
/*     */     
/* 248 */     for (; next != null; next = next.next) {
/*     */       
/* 250 */       last = next;
/* 251 */       next.pathOffset = pathBuilder.length();
/* 252 */       pathBuilder.append('/');
/* 253 */       if (next.property != null) {
/* 254 */         _appendEscaped(pathBuilder, next.property);
/*     */       } else {
/* 256 */         pathBuilder.append(next.index);
/*     */       } 
/*     */     } 
/* 259 */     String fullPath = pathBuilder.toString();
/*     */ 
/*     */ 
/*     */     
/* 263 */     PointerSegment currSegment = last;
/* 264 */     JsonPointer currPtr = EMPTY;
/*     */     
/* 266 */     for (; currSegment != null; currSegment = currSegment.prev) {
/* 267 */       if (currSegment.property != null) {
/* 268 */         currPtr = new JsonPointer(fullPath, currSegment.pathOffset, currSegment.property, currPtr);
/*     */       } else {
/*     */         
/* 271 */         int index = currSegment.index;
/*     */         
/* 273 */         currPtr = new JsonPointer(fullPath, currSegment.pathOffset, String.valueOf(index), index, currPtr);
/*     */       } 
/*     */     } 
/*     */     
/* 277 */     return currPtr;
/*     */   }
/*     */ 
/*     */   
/*     */   private static void _appendEscaped(StringBuilder sb, String segment) {
/* 282 */     for (int i = 0, end = segment.length(); i < end; i++) {
/* 283 */       char c = segment.charAt(i);
/* 284 */       if (c == '/') {
/* 285 */         sb.append("~1");
/*     */       
/*     */       }
/* 288 */       else if (c == '~') {
/* 289 */         sb.append("~0");
/*     */       } else {
/*     */         
/* 292 */         sb.append(c);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int length() {
/* 312 */     return this._asString.length() - this._asStringOffset;
/*     */   }
/*     */   
/* 315 */   public boolean matches() { return (this._nextSegment == null); }
/* 316 */   public String getMatchingProperty() { return this._matchingPropertyName; } public int getMatchingIndex() {
/* 317 */     return this._matchingElementIndex;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean mayMatchProperty() {
/* 323 */     return (this._matchingPropertyName != null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean mayMatchElement() {
/* 329 */     return (this._matchingElementIndex >= 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonPointer last() {
/* 338 */     JsonPointer current = this;
/* 339 */     if (current == EMPTY) {
/* 340 */       return null;
/*     */     }
/*     */     JsonPointer next;
/* 343 */     while ((next = current._nextSegment) != EMPTY) {
/* 344 */       current = next;
/*     */     }
/* 346 */     return current;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonPointer append(JsonPointer tail) {
/* 366 */     if (this == EMPTY) {
/* 367 */       return tail;
/*     */     }
/* 369 */     if (tail == EMPTY) {
/* 370 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 375 */     String currentJsonPointer = this._asString;
/* 376 */     if (currentJsonPointer.endsWith("/"))
/*     */     {
/* 378 */       currentJsonPointer = currentJsonPointer.substring(0, currentJsonPointer.length() - 1);
/*     */     }
/* 380 */     return compile(currentJsonPointer + tail._asString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonPointer appendProperty(String property) {
/* 403 */     if (property == null || property.isEmpty()) {
/* 404 */       return this;
/*     */     }
/* 406 */     if (property.charAt(0) != '/') {
/* 407 */       property = '/' + property;
/*     */     }
/* 409 */     String currentJsonPointer = this._asString;
/* 410 */     if (currentJsonPointer.endsWith("/"))
/*     */     {
/* 412 */       currentJsonPointer = currentJsonPointer.substring(0, currentJsonPointer.length() - 1);
/*     */     }
/* 414 */     return compile(currentJsonPointer + property);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonPointer appendIndex(int index) {
/* 430 */     if (index < 0) {
/* 431 */       throw new IllegalArgumentException("Negative index cannot be appended");
/*     */     }
/* 433 */     String currentJsonPointer = this._asString;
/* 434 */     if (currentJsonPointer.endsWith("/"))
/*     */     {
/* 436 */       currentJsonPointer = currentJsonPointer.substring(0, currentJsonPointer.length() - 1);
/*     */     }
/* 438 */     return compile(currentJsonPointer + '/' + index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean matchesProperty(String name) {
/* 452 */     return (this._nextSegment != null && this._matchingPropertyName.equals(name));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonPointer matchProperty(String name) {
/* 467 */     if (this._nextSegment != null && this._matchingPropertyName.equals(name)) {
/* 468 */       return this._nextSegment;
/*     */     }
/* 470 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean matchesElement(int index) {
/* 484 */     return (index == this._matchingElementIndex && index >= 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonPointer matchElement(int index) {
/* 501 */     if (index != this._matchingElementIndex || index < 0) {
/* 502 */       return null;
/*     */     }
/* 504 */     return this._nextSegment;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonPointer tail() {
/* 521 */     return this._nextSegment;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonPointer head() {
/* 541 */     JsonPointer h = this._head;
/* 542 */     if (h == null) {
/* 543 */       if (this != EMPTY) {
/* 544 */         h = _constructHead();
/*     */       }
/* 546 */       this._head = h;
/*     */     } 
/* 548 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 558 */     if (this._asStringOffset <= 0) {
/* 559 */       return this._asString;
/*     */     }
/* 561 */     return this._asString.substring(this._asStringOffset);
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 565 */     int h = this._hashCode;
/* 566 */     if (h == 0) {
/*     */ 
/*     */ 
/*     */       
/* 570 */       h = toString().hashCode();
/* 571 */       if (h == 0) {
/* 572 */         h = -1;
/*     */       }
/* 574 */       this._hashCode = h;
/*     */     } 
/* 576 */     return h;
/*     */   }
/*     */   
/*     */   public boolean equals(Object o) {
/* 580 */     if (o == this) return true; 
/* 581 */     if (o == null) return false; 
/* 582 */     if (!(o instanceof JsonPointer)) return false; 
/* 583 */     JsonPointer other = (JsonPointer)o;
/*     */ 
/*     */ 
/*     */     
/* 587 */     return _compare(this._asString, this._asStringOffset, other._asString, other._asStringOffset);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private final boolean _compare(String str1, int offset1, String str2, int offset2) {
/* 593 */     int end1 = str1.length();
/*     */ 
/*     */     
/* 596 */     if (end1 - offset1 != str2.length() - offset2) {
/* 597 */       return false;
/*     */     }
/*     */     
/* 600 */     while (offset1 < end1) {
/* 601 */       if (str1.charAt(offset1++) != str2.charAt(offset2++)) {
/* 602 */         return false;
/*     */       }
/*     */     } 
/*     */     
/* 606 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int _parseIndex(String str) {
/* 616 */     int len = str.length();
/*     */ 
/*     */     
/* 619 */     if (len == 0 || len > 10) {
/* 620 */       return -1;
/*     */     }
/*     */     
/* 623 */     char c = str.charAt(0);
/* 624 */     if (c <= '0') {
/* 625 */       return (len == 1 && c == '0') ? 0 : -1;
/*     */     }
/* 627 */     if (c > '9') {
/* 628 */       return -1;
/*     */     }
/* 630 */     for (int i = 1; i < len; i++) {
/* 631 */       c = str.charAt(i);
/* 632 */       if (c > '9' || c < '0') {
/* 633 */         return -1;
/*     */       }
/*     */     } 
/* 636 */     if (len == 10) {
/* 637 */       long l = NumberInput.parseLong(str);
/* 638 */       if (l > 2147483647L) {
/* 639 */         return -1;
/*     */       }
/*     */     } 
/* 642 */     return NumberInput.parseInt(str);
/*     */   }
/*     */ 
/*     */   
/*     */   protected static JsonPointer _parseTail(String fullPath) {
/* 647 */     PointerParent parent = null;
/*     */ 
/*     */     
/* 650 */     int i = 1;
/* 651 */     int end = fullPath.length();
/* 652 */     int startOffset = 0;
/*     */     
/* 654 */     while (i < end) {
/* 655 */       char c = fullPath.charAt(i);
/* 656 */       if (c == '/') {
/*     */         
/* 658 */         parent = new PointerParent(parent, startOffset, fullPath.substring(startOffset + 1, i));
/* 659 */         startOffset = i;
/* 660 */         i++;
/*     */         continue;
/*     */       } 
/* 663 */       i++;
/*     */       
/* 665 */       if (c == '~' && i < end) {
/*     */ 
/*     */         
/* 668 */         StringBuilder sb = new StringBuilder(32);
/* 669 */         i = _extractEscapedSegment(fullPath, startOffset + 1, i, sb);
/* 670 */         String segment = sb.toString();
/* 671 */         if (i < 0) {
/* 672 */           return _buildPath(fullPath, startOffset, segment, parent);
/*     */         }
/* 674 */         parent = new PointerParent(parent, startOffset, segment);
/* 675 */         startOffset = i;
/* 676 */         i++;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 682 */     return _buildPath(fullPath, startOffset, fullPath.substring(startOffset + 1), parent);
/*     */   }
/*     */ 
/*     */   
/*     */   private static JsonPointer _buildPath(String fullPath, int fullPathOffset, String segment, PointerParent parent) {
/* 687 */     JsonPointer curr = new JsonPointer(fullPath, fullPathOffset, segment, EMPTY);
/* 688 */     for (; parent != null; parent = parent.parent) {
/* 689 */       curr = new JsonPointer(fullPath, parent.fullPathOffset, parent.segment, curr);
/*     */     }
/* 691 */     return curr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static int _extractEscapedSegment(String input, int firstCharOffset, int i, StringBuilder sb) {
/* 712 */     int end = input.length();
/* 713 */     int toCopy = i - 1 - firstCharOffset;
/* 714 */     if (toCopy > 0) {
/* 715 */       sb.append(input, firstCharOffset, i - 1);
/*     */     }
/* 717 */     _appendEscape(sb, input.charAt(i++));
/* 718 */     while (i < end) {
/* 719 */       char c = input.charAt(i);
/* 720 */       if (c == '/') {
/* 721 */         return i;
/*     */       }
/* 723 */       i++;
/* 724 */       if (c == '~' && i < end) {
/* 725 */         _appendEscape(sb, input.charAt(i++));
/*     */         continue;
/*     */       } 
/* 728 */       sb.append(c);
/*     */     } 
/*     */     
/* 731 */     return -1;
/*     */   }
/*     */   
/*     */   private static void _appendEscape(StringBuilder sb, char c) {
/* 735 */     if (c == '0') {
/* 736 */       c = '~';
/* 737 */     } else if (c == '1') {
/* 738 */       c = '/';
/*     */     } else {
/* 740 */       sb.append('~');
/*     */     } 
/* 742 */     sb.append(c);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonPointer _constructHead() {
/* 748 */     JsonPointer last = last();
/* 749 */     if (last == this) {
/* 750 */       return EMPTY;
/*     */     }
/*     */     
/* 753 */     int suffixLength = last.length();
/* 754 */     JsonPointer next = this._nextSegment;
/*     */     
/* 756 */     String fullString = toString();
/* 757 */     return new JsonPointer(fullString.substring(0, fullString.length() - suffixLength), 0, this._matchingPropertyName, this._matchingElementIndex, next
/*     */         
/* 759 */         ._constructHead(suffixLength, last));
/*     */   }
/*     */ 
/*     */   
/*     */   protected JsonPointer _constructHead(int suffixLength, JsonPointer last) {
/* 764 */     if (this == last) {
/* 765 */       return EMPTY;
/*     */     }
/* 767 */     JsonPointer next = this._nextSegment;
/* 768 */     String str = toString();
/*     */     
/* 770 */     return new JsonPointer(str.substring(0, str.length() - suffixLength), 0, this._matchingPropertyName, this._matchingElementIndex, next
/*     */         
/* 772 */         ._constructHead(suffixLength, last));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class PointerParent
/*     */   {
/*     */     public final PointerParent parent;
/*     */ 
/*     */     
/*     */     public final int fullPathOffset;
/*     */ 
/*     */     
/*     */     public final String segment;
/*     */ 
/*     */ 
/*     */     
/*     */     PointerParent(PointerParent pp, int fpo, String sgm) {
/* 791 */       this.parent = pp;
/* 792 */       this.fullPathOffset = fpo;
/* 793 */       this.segment = sgm;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class PointerSegment
/*     */   {
/*     */     public final PointerSegment next;
/*     */     
/*     */     public final String property;
/*     */     
/*     */     public final int index;
/*     */     
/*     */     public int pathOffset;
/*     */     
/*     */     public PointerSegment prev;
/*     */ 
/*     */     
/*     */     public PointerSegment(PointerSegment next, String pn, int ix) {
/* 813 */       this.next = next;
/* 814 */       this.property = pn;
/* 815 */       this.index = ix;
/*     */       
/* 817 */       if (next != null) {
/* 818 */         next.prev = this;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object writeReplace() {
/* 832 */     return new Serialization(toString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class Serialization
/*     */     implements Externalizable
/*     */   {
/*     */     private String _fullPath;
/*     */ 
/*     */ 
/*     */     
/*     */     public Serialization() {}
/*     */ 
/*     */ 
/*     */     
/*     */     Serialization(String fullPath) {
/* 850 */       this._fullPath = fullPath;
/*     */     }
/*     */ 
/*     */     
/*     */     public void writeExternal(ObjectOutput out) throws IOException {
/* 855 */       out.writeUTF(this._fullPath);
/*     */     }
/*     */ 
/*     */     
/*     */     public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
/* 860 */       this._fullPath = in.readUTF();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private Object readResolve() throws ObjectStreamException {
/* 866 */       return JsonPointer.compile(this._fullPath);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-core-2.14.2.jar!\com\fasterxml\jackson\core\JsonPointer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */