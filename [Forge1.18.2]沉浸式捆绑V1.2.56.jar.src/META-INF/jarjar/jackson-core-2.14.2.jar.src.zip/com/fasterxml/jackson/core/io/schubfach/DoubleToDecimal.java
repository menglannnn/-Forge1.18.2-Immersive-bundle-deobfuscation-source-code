/*     */ package com.fasterxml.jackson.core.io.schubfach;
/*     */ 
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DoubleToDecimal
/*     */ {
/*     */   static final int P = 53;
/*     */   private static final int W = 11;
/*     */   static final int Q_MIN = -1074;
/*     */   static final int Q_MAX = 971;
/*     */   static final int E_MIN = -323;
/*     */   static final int E_MAX = 309;
/*     */   static final long C_TINY = 3L;
/*     */   static final int K_MIN = -324;
/*     */   static final int K_MAX = 292;
/*     */   static final int H = 17;
/*     */   private static final long C_MIN = 4503599627370496L;
/*     */   private static final int BQ_MASK = 2047;
/*     */   private static final long T_MASK = 4503599627370495L;
/*     */   private static final long MASK_63 = 9223372036854775807L;
/*     */   private static final int MASK_28 = 268435455;
/*     */   private static final int NON_SPECIAL = 0;
/*     */   private static final int PLUS_ZERO = 1;
/*     */   private static final int MINUS_ZERO = 2;
/*     */   private static final int PLUS_INF = 3;
/*     */   private static final int MINUS_INF = 4;
/*     */   private static final int NAN = 5;
/*     */   public static final int MAX_CHARS = 24;
/* 112 */   private final byte[] bytes = new byte[24];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int index;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toString(double v) {
/* 129 */     return (new DoubleToDecimal()).toDecimalString(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Appendable appendTo(double v, Appendable app) throws IOException {
/* 145 */     return (new DoubleToDecimal()).appendDecimalTo(v, app);
/*     */   }
/*     */   
/*     */   private String toDecimalString(double v) {
/* 149 */     switch (toDecimal(v)) { case 0:
/* 150 */         return charsToString();
/* 151 */       case 1: return "0.0";
/* 152 */       case 2: return "-0.0";
/* 153 */       case 3: return "Infinity";
/* 154 */       case 4: return "-Infinity"; }
/* 155 */      return "NaN";
/*     */   }
/*     */   
/*     */   private Appendable appendDecimalTo(double v, Appendable app) throws IOException {
/*     */     char[] chars;
/*     */     int i;
/* 161 */     switch (toDecimal(v)) {
/*     */       case 0:
/* 163 */         chars = new char[this.index + 1];
/* 164 */         for (i = 0; i < chars.length; i++) {
/* 165 */           chars[i] = (char)this.bytes[i];
/*     */         }
/* 167 */         if (app instanceof StringBuilder) {
/* 168 */           return ((StringBuilder)app).append(chars);
/*     */         }
/* 170 */         if (app instanceof StringBuffer) {
/* 171 */           return ((StringBuffer)app).append(chars);
/*     */         }
/* 173 */         for (char c : chars) {
/* 174 */           app.append(c);
/*     */         }
/* 176 */         return app;
/* 177 */       case 1: return app.append("0.0");
/* 178 */       case 2: return app.append("-0.0");
/* 179 */       case 3: return app.append("Infinity");
/* 180 */       case 4: return app.append("-Infinity");
/* 181 */     }  return app.append("NaN");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int toDecimal(double v) {
/* 203 */     long bits = Double.doubleToRawLongBits(v);
/* 204 */     long t = bits & 0xFFFFFFFFFFFFFL;
/* 205 */     int bq = (int)(bits >>> 52L) & 0x7FF;
/* 206 */     if (bq < 2047) {
/* 207 */       this.index = -1;
/* 208 */       if (bits < 0L) {
/* 209 */         append(45);
/*     */       }
/* 211 */       if (bq != 0) {
/*     */         
/* 213 */         int mq = 1075 - bq;
/* 214 */         long c = 0x10000000000000L | t;
/*     */         
/* 216 */         if ((((0 < mq) ? 1 : 0) & ((mq < 53) ? 1 : 0)) != 0) {
/* 217 */           long f = c >> mq;
/* 218 */           if (f << mq == c) {
/* 219 */             return toChars(f, 0);
/*     */           }
/*     */         } 
/* 222 */         return toDecimal(-mq, c, 0);
/*     */       } 
/* 224 */       if (t != 0L)
/*     */       {
/* 226 */         return (t < 3L) ? 
/* 227 */           toDecimal(-1074, 10L * t, -1) : 
/* 228 */           toDecimal(-1074, t, 0);
/*     */       }
/* 230 */       return (bits == 0L) ? 1 : 2;
/*     */     } 
/* 232 */     if (t != 0L) {
/* 233 */       return 5;
/*     */     }
/* 235 */     return (bits > 0L) ? 3 : 4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int toDecimal(int q, long c, int dk) {
/*     */     long cbl;
/* 256 */     int k, out = (int)c & 0x1;
/* 257 */     long cb = c << 2L;
/* 258 */     long cbr = cb + 2L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 266 */     if ((((c != 4503599627370496L) ? 1 : 0) | ((q == -1074) ? 1 : 0)) != 0) {
/*     */       
/* 268 */       cbl = cb - 2L;
/* 269 */       k = MathUtils.flog10pow2(q);
/*     */     } else {
/*     */       
/* 272 */       cbl = cb - 1L;
/* 273 */       k = MathUtils.flog10threeQuartersPow2(q);
/*     */     } 
/* 275 */     int h = q + MathUtils.flog2pow10(-k) + 2;
/*     */ 
/*     */     
/* 278 */     long g1 = MathUtils.g1(k);
/* 279 */     long g0 = MathUtils.g0(k);
/*     */     
/* 281 */     long vb = rop(g1, g0, cb << h);
/* 282 */     long vbl = rop(g1, g0, cbl << h);
/* 283 */     long vbr = rop(g1, g0, cbr << h);
/*     */     
/* 285 */     long s = vb >> 2L;
/* 286 */     if (s >= 100L) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 298 */       long sp10 = 10L * MathUtils.multiplyHigh(s, 1844674407370955168L);
/* 299 */       long tp10 = sp10 + 10L;
/* 300 */       boolean upin = (vbl + out <= sp10 << 2L);
/* 301 */       boolean wpin = ((tp10 << 2L) + out <= vbr);
/* 302 */       if (upin != wpin) {
/* 303 */         return toChars(upin ? sp10 : tp10, k);
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 313 */     long t = s + 1L;
/* 314 */     boolean uin = (vbl + out <= s << 2L);
/* 315 */     boolean win = ((t << 2L) + out <= vbr);
/* 316 */     if (uin != win)
/*     */     {
/* 318 */       return toChars(uin ? s : t, k + dk);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 324 */     long cmp = vb - (s + t << 1L);
/* 325 */     return toChars((cmp < 0L || (cmp == 0L && (s & 0x1L) == 0L)) ? s : t, k + dk);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static long rop(long g1, long g0, long cp) {
/* 333 */     long x1 = MathUtils.multiplyHigh(g0, cp);
/* 334 */     long y0 = g1 * cp;
/* 335 */     long y1 = MathUtils.multiplyHigh(g1, cp);
/* 336 */     long z = (y0 >>> 1L) + x1;
/* 337 */     long vbp = y1 + (z >>> 63L);
/* 338 */     return vbp | (z & Long.MAX_VALUE) + Long.MAX_VALUE >>> 63L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int toChars(long f, int e) {
/* 351 */     int len = MathUtils.flog10pow2(64 - Long.numberOfLeadingZeros(f));
/* 352 */     if (f >= MathUtils.pow10(len)) {
/* 353 */       len++;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 362 */     f *= MathUtils.pow10(17 - len);
/* 363 */     e += len;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 379 */     long hm = MathUtils.multiplyHigh(f, 193428131138340668L) >>> 20L;
/* 380 */     int l = (int)(f - 100000000L * hm);
/* 381 */     int h = (int)(hm * 1441151881L >>> 57L);
/* 382 */     int m = (int)(hm - (100000000 * h));
/*     */     
/* 384 */     if (0 < e && e <= 7) {
/* 385 */       return toChars1(h, m, l, e);
/*     */     }
/* 387 */     if (-3 < e && e <= 0) {
/* 388 */       return toChars2(h, m, l, e);
/*     */     }
/* 390 */     return toChars3(h, m, l, e);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int toChars1(int h, int m, int l, int e) {
/* 399 */     appendDigit(h);
/* 400 */     int y = y(m);
/*     */     
/* 402 */     int i = 1;
/* 403 */     for (; i < e; i++) {
/* 404 */       int t = 10 * y;
/* 405 */       appendDigit(t >>> 28);
/* 406 */       y = t & 0xFFFFFFF;
/*     */     } 
/* 408 */     append(46);
/* 409 */     for (; i <= 8; i++) {
/* 410 */       int t = 10 * y;
/* 411 */       appendDigit(t >>> 28);
/* 412 */       y = t & 0xFFFFFFF;
/*     */     } 
/* 414 */     lowDigits(l);
/* 415 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   private int toChars2(int h, int m, int l, int e) {
/* 420 */     appendDigit(0);
/* 421 */     append(46);
/* 422 */     for (; e < 0; e++) {
/* 423 */       appendDigit(0);
/*     */     }
/* 425 */     appendDigit(h);
/* 426 */     append8Digits(m);
/* 427 */     lowDigits(l);
/* 428 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   private int toChars3(int h, int m, int l, int e) {
/* 433 */     appendDigit(h);
/* 434 */     append(46);
/* 435 */     append8Digits(m);
/* 436 */     lowDigits(l);
/* 437 */     exponent(e - 1);
/* 438 */     return 0;
/*     */   }
/*     */   
/*     */   private void lowDigits(int l) {
/* 442 */     if (l != 0) {
/* 443 */       append8Digits(l);
/*     */     }
/* 445 */     removeTrailingZeroes();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void append8Digits(int m) {
/* 453 */     int y = y(m);
/* 454 */     for (int i = 0; i < 8; i++) {
/* 455 */       int t = 10 * y;
/* 456 */       appendDigit(t >>> 28);
/* 457 */       y = t & 0xFFFFFFF;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void removeTrailingZeroes() {
/* 462 */     while (this.bytes[this.index] == 48) {
/* 463 */       this.index--;
/*     */     }
/*     */     
/* 466 */     if (this.bytes[this.index] == 46) {
/* 467 */       this.index++;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int y(int a) {
/* 480 */     return (int)(MathUtils.multiplyHigh((a + 1) << 28L, 193428131138340668L) >>> 20L) - 1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void exponent(int e) {
/* 486 */     append(69);
/* 487 */     if (e < 0) {
/* 488 */       append(45);
/* 489 */       e = -e;
/*     */     } 
/* 491 */     if (e < 10) {
/* 492 */       appendDigit(e);
/*     */       
/*     */       return;
/*     */     } 
/* 496 */     if (e >= 100) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 501 */       int i = e * 1311 >>> 17;
/* 502 */       appendDigit(i);
/* 503 */       e -= 100 * i;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 509 */     int d = e * 103 >>> 10;
/* 510 */     appendDigit(d);
/* 511 */     appendDigit(e - 10 * d);
/*     */   }
/*     */   
/*     */   private void append(int c) {
/* 515 */     this.bytes[++this.index] = (byte)c;
/*     */   }
/*     */   
/*     */   private void appendDigit(int d) {
/* 519 */     this.bytes[++this.index] = (byte)(48 + d);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private String charsToString() {
/* 525 */     return new String(this.bytes, 0, 0, this.index + 1);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-core-2.14.2.jar!\com\fasterxml\jackson\core\io\schubfach\DoubleToDecimal.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */