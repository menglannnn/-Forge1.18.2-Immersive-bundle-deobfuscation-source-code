/*     */ package com.fasterxml.jackson.core.io.doubleparser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class AbstractFloatingPointBitsFromCharArray
/*     */   extends AbstractFloatValueParser
/*     */ {
/*     */   private static boolean isDigit(char c) {
/*  26 */     return ('0' <= c && c <= '9');
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int skipWhitespace(char[] str, int index, int endIndex) {
/*  38 */     for (; index < endIndex && (
/*  39 */       str[index] & 0xFF) <= 32; index++);
/*     */ 
/*     */ 
/*     */     
/*  43 */     return index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private long parseDecFloatLiteral(char[] str, int index, int startIndex, int endIndex, boolean isNegative, boolean hasLeadingZero) {
/*     */     // Byte code:
/*     */     //   0: lconst_0
/*     */     //   1: lstore #7
/*     */     //   3: iload_2
/*     */     //   4: istore #9
/*     */     //   6: iconst_m1
/*     */     //   7: istore #10
/*     */     //   9: iconst_0
/*     */     //   10: istore #11
/*     */     //   12: iconst_0
/*     */     //   13: istore #12
/*     */     //   15: iload_2
/*     */     //   16: iload #4
/*     */     //   18: if_icmpge -> 129
/*     */     //   21: aload_1
/*     */     //   22: iload_2
/*     */     //   23: caload
/*     */     //   24: istore #12
/*     */     //   26: iload #12
/*     */     //   28: invokestatic isDigit : (C)Z
/*     */     //   31: ifeq -> 53
/*     */     //   34: ldc2_w 10
/*     */     //   37: lload #7
/*     */     //   39: lmul
/*     */     //   40: iload #12
/*     */     //   42: i2l
/*     */     //   43: ladd
/*     */     //   44: ldc2_w 48
/*     */     //   47: lsub
/*     */     //   48: lstore #7
/*     */     //   50: goto -> 123
/*     */     //   53: iload #12
/*     */     //   55: bipush #46
/*     */     //   57: if_icmpne -> 129
/*     */     //   60: iload #11
/*     */     //   62: iload #10
/*     */     //   64: iflt -> 71
/*     */     //   67: iconst_1
/*     */     //   68: goto -> 72
/*     */     //   71: iconst_0
/*     */     //   72: ior
/*     */     //   73: istore #11
/*     */     //   75: iload_2
/*     */     //   76: istore #10
/*     */     //   78: iload_2
/*     */     //   79: iload #4
/*     */     //   81: bipush #8
/*     */     //   83: isub
/*     */     //   84: if_icmpge -> 123
/*     */     //   87: aload_0
/*     */     //   88: aload_1
/*     */     //   89: iload_2
/*     */     //   90: iconst_1
/*     */     //   91: iadd
/*     */     //   92: invokespecial tryToParseEightDigits : ([CI)I
/*     */     //   95: istore #13
/*     */     //   97: iload #13
/*     */     //   99: ifge -> 105
/*     */     //   102: goto -> 123
/*     */     //   105: ldc2_w 100000000
/*     */     //   108: lload #7
/*     */     //   110: lmul
/*     */     //   111: iload #13
/*     */     //   113: i2l
/*     */     //   114: ladd
/*     */     //   115: lstore #7
/*     */     //   117: iinc #2, 8
/*     */     //   120: goto -> 78
/*     */     //   123: iinc #2, 1
/*     */     //   126: goto -> 15
/*     */     //   129: iload_2
/*     */     //   130: istore #14
/*     */     //   132: iload #10
/*     */     //   134: ifge -> 152
/*     */     //   137: iload_2
/*     */     //   138: iload #9
/*     */     //   140: isub
/*     */     //   141: istore #13
/*     */     //   143: iload_2
/*     */     //   144: istore #10
/*     */     //   146: iconst_0
/*     */     //   147: istore #15
/*     */     //   149: goto -> 168
/*     */     //   152: iload_2
/*     */     //   153: iload #9
/*     */     //   155: isub
/*     */     //   156: iconst_1
/*     */     //   157: isub
/*     */     //   158: istore #13
/*     */     //   160: iload #10
/*     */     //   162: iload_2
/*     */     //   163: isub
/*     */     //   164: iconst_1
/*     */     //   165: iadd
/*     */     //   166: istore #15
/*     */     //   168: iconst_0
/*     */     //   169: istore #16
/*     */     //   171: iload #12
/*     */     //   173: bipush #101
/*     */     //   175: if_icmpeq -> 185
/*     */     //   178: iload #12
/*     */     //   180: bipush #69
/*     */     //   182: if_icmpne -> 329
/*     */     //   185: iinc #2, 1
/*     */     //   188: iload_2
/*     */     //   189: iload #4
/*     */     //   191: if_icmpge -> 200
/*     */     //   194: aload_1
/*     */     //   195: iload_2
/*     */     //   196: caload
/*     */     //   197: goto -> 201
/*     */     //   200: iconst_0
/*     */     //   201: istore #12
/*     */     //   203: iload #12
/*     */     //   205: bipush #45
/*     */     //   207: if_icmpne -> 214
/*     */     //   210: iconst_1
/*     */     //   211: goto -> 215
/*     */     //   214: iconst_0
/*     */     //   215: istore #17
/*     */     //   217: iload #17
/*     */     //   219: ifne -> 229
/*     */     //   222: iload #12
/*     */     //   224: bipush #43
/*     */     //   226: if_icmpne -> 247
/*     */     //   229: iinc #2, 1
/*     */     //   232: iload_2
/*     */     //   233: iload #4
/*     */     //   235: if_icmpge -> 244
/*     */     //   238: aload_1
/*     */     //   239: iload_2
/*     */     //   240: caload
/*     */     //   241: goto -> 245
/*     */     //   244: iconst_0
/*     */     //   245: istore #12
/*     */     //   247: iload #11
/*     */     //   249: iload #12
/*     */     //   251: invokestatic isDigit : (C)Z
/*     */     //   254: ifne -> 261
/*     */     //   257: iconst_1
/*     */     //   258: goto -> 262
/*     */     //   261: iconst_0
/*     */     //   262: ior
/*     */     //   263: istore #11
/*     */     //   265: iload #16
/*     */     //   267: sipush #1024
/*     */     //   270: if_icmpge -> 286
/*     */     //   273: bipush #10
/*     */     //   275: iload #16
/*     */     //   277: imul
/*     */     //   278: iload #12
/*     */     //   280: iadd
/*     */     //   281: bipush #48
/*     */     //   283: isub
/*     */     //   284: istore #16
/*     */     //   286: iinc #2, 1
/*     */     //   289: iload_2
/*     */     //   290: iload #4
/*     */     //   292: if_icmpge -> 301
/*     */     //   295: aload_1
/*     */     //   296: iload_2
/*     */     //   297: caload
/*     */     //   298: goto -> 302
/*     */     //   301: iconst_0
/*     */     //   302: istore #12
/*     */     //   304: iload #12
/*     */     //   306: invokestatic isDigit : (C)Z
/*     */     //   309: ifne -> 265
/*     */     //   312: iload #17
/*     */     //   314: ifeq -> 322
/*     */     //   317: iload #16
/*     */     //   319: ineg
/*     */     //   320: istore #16
/*     */     //   322: iload #15
/*     */     //   324: iload #16
/*     */     //   326: iadd
/*     */     //   327: istore #15
/*     */     //   329: iload_2
/*     */     //   330: iload #4
/*     */     //   332: if_icmpge -> 366
/*     */     //   335: iload #12
/*     */     //   337: bipush #100
/*     */     //   339: if_icmpeq -> 363
/*     */     //   342: iload #12
/*     */     //   344: bipush #68
/*     */     //   346: if_icmpeq -> 363
/*     */     //   349: iload #12
/*     */     //   351: bipush #102
/*     */     //   353: if_icmpeq -> 363
/*     */     //   356: iload #12
/*     */     //   358: bipush #70
/*     */     //   360: if_icmpne -> 366
/*     */     //   363: iinc #2, 1
/*     */     //   366: aload_0
/*     */     //   367: aload_1
/*     */     //   368: iload_2
/*     */     //   369: iload #4
/*     */     //   371: invokespecial skipWhitespace : ([CII)I
/*     */     //   374: istore_2
/*     */     //   375: iload #11
/*     */     //   377: ifne -> 396
/*     */     //   380: iload_2
/*     */     //   381: iload #4
/*     */     //   383: if_icmplt -> 396
/*     */     //   386: iload #6
/*     */     //   388: ifne -> 400
/*     */     //   391: iload #13
/*     */     //   393: ifne -> 400
/*     */     //   396: ldc2_w -1
/*     */     //   399: lreturn
/*     */     //   400: iconst_0
/*     */     //   401: istore #18
/*     */     //   403: iload #13
/*     */     //   405: bipush #19
/*     */     //   407: if_icmple -> 501
/*     */     //   410: lconst_0
/*     */     //   411: lstore #7
/*     */     //   413: iload #9
/*     */     //   415: istore_2
/*     */     //   416: iload_2
/*     */     //   417: iload #14
/*     */     //   419: if_icmpge -> 473
/*     */     //   422: aload_1
/*     */     //   423: iload_2
/*     */     //   424: caload
/*     */     //   425: istore #12
/*     */     //   427: iload #12
/*     */     //   429: bipush #46
/*     */     //   431: if_icmpne -> 440
/*     */     //   434: iinc #18, 1
/*     */     //   437: goto -> 467
/*     */     //   440: lload #7
/*     */     //   442: ldc2_w 1000000000000000000
/*     */     //   445: invokestatic compareUnsigned : (JJ)I
/*     */     //   448: ifge -> 473
/*     */     //   451: ldc2_w 10
/*     */     //   454: lload #7
/*     */     //   456: lmul
/*     */     //   457: iload #12
/*     */     //   459: i2l
/*     */     //   460: ladd
/*     */     //   461: ldc2_w 48
/*     */     //   464: lsub
/*     */     //   465: lstore #7
/*     */     //   467: iinc #2, 1
/*     */     //   470: goto -> 416
/*     */     //   473: iload_2
/*     */     //   474: iload #14
/*     */     //   476: if_icmpge -> 483
/*     */     //   479: iconst_1
/*     */     //   480: goto -> 484
/*     */     //   483: iconst_0
/*     */     //   484: istore #17
/*     */     //   486: iload #10
/*     */     //   488: iload_2
/*     */     //   489: isub
/*     */     //   490: iload #18
/*     */     //   492: iadd
/*     */     //   493: iload #16
/*     */     //   495: iadd
/*     */     //   496: istore #19
/*     */     //   498: goto -> 507
/*     */     //   501: iconst_0
/*     */     //   502: istore #17
/*     */     //   504: iconst_0
/*     */     //   505: istore #19
/*     */     //   507: aload_0
/*     */     //   508: aload_1
/*     */     //   509: iload_3
/*     */     //   510: iload #4
/*     */     //   512: iload #5
/*     */     //   514: lload #7
/*     */     //   516: iload #15
/*     */     //   518: iload #17
/*     */     //   520: iload #19
/*     */     //   522: invokevirtual valueOfFloatLiteral : ([CIIZJIZI)J
/*     */     //   525: lreturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #73	-> 0
/*     */     //   #74	-> 3
/*     */     //   #75	-> 6
/*     */     //   #76	-> 9
/*     */     //   #77	-> 12
/*     */     //   #78	-> 15
/*     */     //   #79	-> 21
/*     */     //   #80	-> 26
/*     */     //   #82	-> 34
/*     */     //   #83	-> 53
/*     */     //   #84	-> 60
/*     */     //   #85	-> 75
/*     */     //   #86	-> 78
/*     */     //   #87	-> 87
/*     */     //   #88	-> 97
/*     */     //   #89	-> 102
/*     */     //   #92	-> 105
/*     */     //   #86	-> 117
/*     */     //   #78	-> 123
/*     */     //   #99	-> 129
/*     */     //   #101	-> 132
/*     */     //   #102	-> 137
/*     */     //   #103	-> 143
/*     */     //   #104	-> 146
/*     */     //   #106	-> 152
/*     */     //   #107	-> 160
/*     */     //   #112	-> 168
/*     */     //   #113	-> 171
/*     */     //   #114	-> 185
/*     */     //   #115	-> 203
/*     */     //   #116	-> 217
/*     */     //   #117	-> 229
/*     */     //   #119	-> 247
/*     */     //   #122	-> 265
/*     */     //   #123	-> 273
/*     */     //   #125	-> 286
/*     */     //   #126	-> 304
/*     */     //   #127	-> 312
/*     */     //   #128	-> 317
/*     */     //   #130	-> 322
/*     */     //   #135	-> 329
/*     */     //   #136	-> 363
/*     */     //   #141	-> 366
/*     */     //   #142	-> 375
/*     */     //   #144	-> 396
/*     */     //   #150	-> 400
/*     */     //   #152	-> 403
/*     */     //   #153	-> 410
/*     */     //   #154	-> 413
/*     */     //   #155	-> 422
/*     */     //   #156	-> 427
/*     */     //   #157	-> 434
/*     */     //   #159	-> 440
/*     */     //   #160	-> 451
/*     */     //   #154	-> 467
/*     */     //   #166	-> 473
/*     */     //   #167	-> 486
/*     */     //   #169	-> 501
/*     */     //   #170	-> 504
/*     */     //   #172	-> 507
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   97	20	13	eightDigits	I
/*     */     //   143	9	13	digitCount	I
/*     */     //   149	3	15	exponent	I
/*     */     //   217	112	17	neg_exp	Z
/*     */     //   486	15	17	isSignificandTruncated	Z
/*     */     //   498	3	19	exponentOfTruncatedSignificand	I
/*     */     //   0	526	0	this	Lcom/fasterxml/jackson/core/io/doubleparser/AbstractFloatingPointBitsFromCharArray;
/*     */     //   0	526	1	str	[C
/*     */     //   0	526	2	index	I
/*     */     //   0	526	3	startIndex	I
/*     */     //   0	526	4	endIndex	I
/*     */     //   0	526	5	isNegative	Z
/*     */     //   0	526	6	hasLeadingZero	Z
/*     */     //   3	523	7	significand	J
/*     */     //   6	520	9	significandStartIndex	I
/*     */     //   9	517	10	virtualIndexOfPoint	I
/*     */     //   12	514	11	illegal	Z
/*     */     //   15	511	12	ch	C
/*     */     //   160	366	13	digitCount	I
/*     */     //   132	394	14	significandEndIndex	I
/*     */     //   168	358	15	exponent	I
/*     */     //   171	355	16	expNumber	I
/*     */     //   504	22	17	isSignificandTruncated	Z
/*     */     //   403	123	18	skipCountInTruncatedDigits	I
/*     */     //   507	19	19	exponentOfTruncatedSignificand	I
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long parseFloatingPointLiteral(char[] str, int offset, int length) {
/* 195 */     int endIndex = offset + length;
/* 196 */     if (offset < 0 || endIndex > str.length) {
/* 197 */       return -1L;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 202 */     int index = skipWhitespace(str, offset, endIndex);
/* 203 */     if (index == endIndex) {
/* 204 */       return -1L;
/*     */     }
/* 206 */     char ch = str[index];
/*     */ 
/*     */ 
/*     */     
/* 210 */     boolean isNegative = (ch == '-');
/* 211 */     if (isNegative || ch == '+') {
/* 212 */       ch = (++index < endIndex) ? str[index] : Character.MIN_VALUE;
/* 213 */       if (ch == '\000') {
/* 214 */         return -1L;
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 220 */     if (ch >= 'I') {
/* 221 */       return (ch == 'N') ? 
/* 222 */         parseNaN(str, index, endIndex) : 
/* 223 */         parseInfinity(str, index, endIndex, isNegative);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 228 */     boolean hasLeadingZero = (ch == '0');
/* 229 */     if (hasLeadingZero) {
/* 230 */       ch = (++index < endIndex) ? str[index] : Character.MIN_VALUE;
/* 231 */       if (ch == 'x' || ch == 'X') {
/* 232 */         return parseHexFloatLiteral(str, index + 1, offset, endIndex, isNegative);
/*     */       }
/*     */     } 
/*     */     
/* 236 */     return parseDecFloatLiteral(str, index, offset, endIndex, isNegative, hasLeadingZero);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private long parseHexFloatLiteral(char[] str, int index, int startIndex, int endIndex, boolean isNegative) {
/*     */     int digitCount, i;
/*     */     boolean isSignificandTruncated;
/* 267 */     long significand = 0L;
/* 268 */     int exponent = 0;
/* 269 */     int significandStartIndex = index;
/* 270 */     int virtualIndexOfPoint = -1;
/*     */     
/* 272 */     boolean illegal = false;
/* 273 */     char ch = Character.MIN_VALUE;
/* 274 */     for (; index < endIndex; index++) {
/* 275 */       ch = str[index];
/*     */       
/* 277 */       int hexValue = (ch > '') ? -1 : AbstractFloatValueParser.CHAR_TO_HEX_MAP[ch];
/* 278 */       if (hexValue >= 0) {
/* 279 */         significand = significand << 4L | hexValue;
/* 280 */       } else if (hexValue == -4) {
/* 281 */         i = illegal | ((virtualIndexOfPoint >= 0) ? 1 : 0);
/* 282 */         virtualIndexOfPoint = index;
/*     */       } else {
/*     */         break;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 298 */     int significandEndIndex = index;
/* 299 */     if (virtualIndexOfPoint < 0) {
/* 300 */       digitCount = significandEndIndex - significandStartIndex;
/* 301 */       virtualIndexOfPoint = significandEndIndex;
/*     */     } else {
/* 303 */       digitCount = significandEndIndex - significandStartIndex - 1;
/* 304 */       exponent = Math.min(virtualIndexOfPoint - index + 1, 1024) * 4;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 309 */     int expNumber = 0;
/* 310 */     boolean hasExponent = (ch == 'p' || ch == 'P');
/* 311 */     if (hasExponent) {
/* 312 */       ch = (++index < endIndex) ? str[index] : Character.MIN_VALUE;
/* 313 */       boolean neg_exp = (ch == '-');
/* 314 */       if (neg_exp || ch == '+') {
/* 315 */         ch = (++index < endIndex) ? str[index] : Character.MIN_VALUE;
/*     */       }
/* 317 */       i |= !isDigit(ch) ? 1 : 0;
/*     */       
/*     */       while (true) {
/* 320 */         if (expNumber < 1024) {
/* 321 */           expNumber = 10 * expNumber + ch - 48;
/*     */         }
/* 323 */         ch = (++index < endIndex) ? str[index] : Character.MIN_VALUE;
/* 324 */         if (!isDigit(ch)) {
/* 325 */           if (neg_exp) {
/* 326 */             expNumber = -expNumber;
/*     */           }
/* 328 */           exponent += expNumber;
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/* 333 */     if (index < endIndex && (ch == 'd' || ch == 'D' || ch == 'f' || ch == 'F')) {
/* 334 */       index++;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 339 */     index = skipWhitespace(str, index, endIndex);
/* 340 */     if (i != 0 || index < endIndex || digitCount == 0 || !hasExponent)
/*     */     {
/*     */       
/* 343 */       return -1L;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 349 */     int skipCountInTruncatedDigits = 0;
/* 350 */     if (digitCount > 16) {
/* 351 */       significand = 0L;
/* 352 */       for (index = significandStartIndex; index < significandEndIndex; index++) {
/* 353 */         ch = str[index];
/*     */         
/* 355 */         int hexValue = (ch > '') ? -1 : AbstractFloatValueParser.CHAR_TO_HEX_MAP[ch];
/* 356 */         if (hexValue >= 0) {
/* 357 */           if (Long.compareUnsigned(significand, 1000000000000000000L) < 0) {
/* 358 */             significand = significand << 4L | hexValue;
/*     */           } else {
/*     */             break;
/*     */           } 
/*     */         } else {
/* 363 */           skipCountInTruncatedDigits++;
/*     */         } 
/*     */       } 
/* 366 */       isSignificandTruncated = (index < significandEndIndex);
/*     */     } else {
/* 368 */       isSignificandTruncated = false;
/*     */     } 
/*     */     
/* 371 */     return valueOfHexLiteral(str, startIndex, endIndex, isNegative, significand, exponent, isSignificandTruncated, virtualIndexOfPoint - index + skipCountInTruncatedDigits + expNumber);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private long parseInfinity(char[] str, int index, int endIndex, boolean negative) {
/* 392 */     if (index + 7 < endIndex && str[index] == 'I' && str[index + 1] == 'n' && str[index + 2] == 'f' && str[index + 3] == 'i' && str[index + 4] == 'n' && str[index + 5] == 'i' && str[index + 6] == 't' && str[index + 7] == 'y') {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 402 */       index = skipWhitespace(str, index + 8, endIndex);
/* 403 */       if (index == endIndex) {
/* 404 */         return negative ? negativeInfinity() : positiveInfinity();
/*     */       }
/*     */     } 
/* 407 */     return -1L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private long parseNaN(char[] str, int index, int endIndex) {
/* 429 */     if (index + 2 < endIndex && str[index + 1] == 'a' && str[index + 2] == 'N') {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 434 */       index = skipWhitespace(str, index + 3, endIndex);
/* 435 */       if (index == endIndex) {
/* 436 */         return nan();
/*     */       }
/*     */     } 
/* 439 */     return -1L;
/*     */   }
/*     */   
/*     */   private int tryToParseEightDigits(char[] str, int offset) {
/* 443 */     return FastDoubleSwar.tryToParseEightDigitsUtf16(str, offset);
/*     */   }
/*     */   
/*     */   abstract long nan();
/*     */   
/*     */   abstract long negativeInfinity();
/*     */   
/*     */   abstract long positiveInfinity();
/*     */   
/*     */   abstract long valueOfFloatLiteral(char[] paramArrayOfchar, int paramInt1, int paramInt2, boolean paramBoolean1, long paramLong, int paramInt3, boolean paramBoolean2, int paramInt4);
/*     */   
/*     */   abstract long valueOfHexLiteral(char[] paramArrayOfchar, int paramInt1, int paramInt2, boolean paramBoolean1, long paramLong, int paramInt3, boolean paramBoolean2, int paramInt4);
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-core-2.14.2.jar!\com\fasterxml\jackson\core\io\doubleparser\AbstractFloatingPointBitsFromCharArray.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */