/*      */ package com.fasterxml.jackson.core.base;
/*      */ 
/*      */ import com.fasterxml.jackson.core.Base64Variant;
/*      */ import com.fasterxml.jackson.core.JsonLocation;
/*      */ import com.fasterxml.jackson.core.JsonParseException;
/*      */ import com.fasterxml.jackson.core.JsonParser;
/*      */ import com.fasterxml.jackson.core.JsonProcessingException;
/*      */ import com.fasterxml.jackson.core.JsonStreamContext;
/*      */ import com.fasterxml.jackson.core.JsonToken;
/*      */ import com.fasterxml.jackson.core.StreamReadCapability;
/*      */ import com.fasterxml.jackson.core.Version;
/*      */ import com.fasterxml.jackson.core.io.ContentReference;
/*      */ import com.fasterxml.jackson.core.io.IOContext;
/*      */ import com.fasterxml.jackson.core.io.NumberInput;
/*      */ import com.fasterxml.jackson.core.json.DupDetector;
/*      */ import com.fasterxml.jackson.core.json.JsonReadContext;
/*      */ import com.fasterxml.jackson.core.json.PackageVersion;
/*      */ import com.fasterxml.jackson.core.util.ByteArrayBuilder;
/*      */ import com.fasterxml.jackson.core.util.JacksonFeatureSet;
/*      */ import com.fasterxml.jackson.core.util.TextBuffer;
/*      */ import java.io.IOException;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.util.Arrays;
/*      */ 
/*      */ public abstract class ParserBase
/*      */   extends ParserMinimalBase {
/*   28 */   protected static final JacksonFeatureSet<StreamReadCapability> JSON_READ_CAPABILITIES = DEFAULT_READ_CAPABILITIES;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final IOContext _ioContext;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _closed;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _inputPtr;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _inputEnd;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected long _currInputProcessed;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   84 */   protected int _currInputRow = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _currInputRowStart;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected long _tokenInputTotal;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  113 */   protected int _tokenInputRow = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _tokenInputCol;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonReadContext _parsingContext;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonToken _nextToken;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final TextBuffer _textBuffer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected char[] _nameCopyBuffer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _nameCopied;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ByteArrayBuilder _byteArrayBuilder;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected byte[] _binaryValue;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  188 */   protected int _numTypesValid = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _numberInt;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected long _numberLong;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected float _numberFloat;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected double _numberDouble;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected BigInteger _numberBigInt;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected BigDecimal _numberBigDecimal;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String _numberString;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _numberNegative;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _intLength;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _fractLength;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _expLength;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ParserBase(IOContext ctxt, int features) {
/*  251 */     super(features);
/*  252 */     this._ioContext = ctxt;
/*  253 */     this._textBuffer = ctxt.constructTextBuffer();
/*      */     
/*  255 */     DupDetector dups = JsonParser.Feature.STRICT_DUPLICATE_DETECTION.enabledIn(features) ? DupDetector.rootDetector(this) : null;
/*  256 */     this._parsingContext = JsonReadContext.createRootContext(dups);
/*      */   }
/*      */   public Version version() {
/*  259 */     return PackageVersion.VERSION;
/*      */   }
/*      */   
/*      */   public Object getCurrentValue() {
/*  263 */     return this._parsingContext.getCurrentValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public void setCurrentValue(Object v) {
/*  268 */     this._parsingContext.setCurrentValue(v);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser enable(JsonParser.Feature f) {
/*  279 */     this._features |= f.getMask();
/*  280 */     if (f == JsonParser.Feature.STRICT_DUPLICATE_DETECTION && 
/*  281 */       this._parsingContext.getDupDetector() == null) {
/*  282 */       this._parsingContext = this._parsingContext.withDupDetector(DupDetector.rootDetector(this));
/*      */     }
/*      */     
/*  285 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public JsonParser disable(JsonParser.Feature f) {
/*  290 */     this._features &= f.getMask() ^ 0xFFFFFFFF;
/*  291 */     if (f == JsonParser.Feature.STRICT_DUPLICATE_DETECTION) {
/*  292 */       this._parsingContext = this._parsingContext.withDupDetector(null);
/*      */     }
/*  294 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JsonParser setFeatureMask(int newMask) {
/*  300 */     int changes = this._features ^ newMask;
/*  301 */     if (changes != 0) {
/*  302 */       this._features = newMask;
/*  303 */       _checkStdFeatureChanges(newMask, changes);
/*      */     } 
/*  305 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public JsonParser overrideStdFeatures(int values, int mask) {
/*  310 */     int oldState = this._features;
/*  311 */     int newState = oldState & (mask ^ 0xFFFFFFFF) | values & mask;
/*  312 */     int changed = oldState ^ newState;
/*  313 */     if (changed != 0) {
/*  314 */       this._features = newState;
/*  315 */       _checkStdFeatureChanges(newState, changed);
/*      */     } 
/*  317 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _checkStdFeatureChanges(int newFeatureFlags, int changedFeatures) {
/*  331 */     int f = JsonParser.Feature.STRICT_DUPLICATE_DETECTION.getMask();
/*      */     
/*  333 */     if ((changedFeatures & f) != 0 && (
/*  334 */       newFeatureFlags & f) != 0) {
/*  335 */       if (this._parsingContext.getDupDetector() == null) {
/*  336 */         this._parsingContext = this._parsingContext.withDupDetector(DupDetector.rootDetector(this));
/*      */       } else {
/*  338 */         this._parsingContext = this._parsingContext.withDupDetector(null);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getCurrentName() throws IOException {
/*  356 */     if (this._currToken == JsonToken.START_OBJECT || this._currToken == JsonToken.START_ARRAY) {
/*  357 */       JsonReadContext parent = this._parsingContext.getParent();
/*  358 */       if (parent != null) {
/*  359 */         return parent.getCurrentName();
/*      */       }
/*      */     } 
/*  362 */     return this._parsingContext.getCurrentName();
/*      */   }
/*      */ 
/*      */   
/*      */   public void overrideCurrentName(String name) {
/*  367 */     JsonReadContext ctxt = this._parsingContext;
/*  368 */     if (this._currToken == JsonToken.START_OBJECT || this._currToken == JsonToken.START_ARRAY) {
/*  369 */       ctxt = ctxt.getParent();
/*      */     }
/*      */ 
/*      */     
/*      */     try {
/*  374 */       ctxt.setCurrentName(name);
/*  375 */     } catch (IOException e) {
/*  376 */       throw new IllegalStateException(e);
/*      */     } 
/*      */   }
/*      */   
/*      */   public void close() throws IOException {
/*  381 */     if (!this._closed) {
/*      */       
/*  383 */       this._inputPtr = Math.max(this._inputPtr, this._inputEnd);
/*  384 */       this._closed = true;
/*      */       try {
/*  386 */         _closeInput();
/*      */       }
/*      */       finally {
/*      */         
/*  390 */         _releaseBuffers();
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*  395 */   public boolean isClosed() { return this._closed; } public JsonReadContext getParsingContext() {
/*  396 */     return this._parsingContext;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonLocation getTokenLocation() {
/*  405 */     return new JsonLocation(_contentReference(), -1L, 
/*  406 */         getTokenCharacterOffset(), 
/*  407 */         getTokenLineNr(), 
/*  408 */         getTokenColumnNr());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonLocation getCurrentLocation() {
/*  417 */     int col = this._inputPtr - this._currInputRowStart + 1;
/*  418 */     return new JsonLocation(_contentReference(), -1L, this._currInputProcessed + this._inputPtr, this._currInputRow, col);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hasTextCharacters() {
/*  431 */     if (this._currToken == JsonToken.VALUE_STRING) return true; 
/*  432 */     if (this._currToken == JsonToken.FIELD_NAME) return this._nameCopied; 
/*  433 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] getBinaryValue(Base64Variant variant) throws IOException {
/*  440 */     if (this._binaryValue == null) {
/*  441 */       if (this._currToken != JsonToken.VALUE_STRING) {
/*  442 */         _reportError("Current token (" + this._currToken + ") not VALUE_STRING, can not access as binary");
/*      */       }
/*  444 */       ByteArrayBuilder builder = _getByteArrayBuilder();
/*  445 */       _decodeBase64(getText(), builder, variant);
/*  446 */       this._binaryValue = builder.toByteArray();
/*      */     } 
/*  448 */     return this._binaryValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getTokenCharacterOffset() {
/*  457 */     return this._tokenInputTotal; } public int getTokenLineNr() {
/*  458 */     return this._tokenInputRow;
/*      */   }
/*      */   public int getTokenColumnNr() {
/*  461 */     int col = this._tokenInputCol;
/*  462 */     return (col < 0) ? col : (col + 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _releaseBuffers() throws IOException {
/*  489 */     this._textBuffer.releaseBuffers();
/*  490 */     char[] buf = this._nameCopyBuffer;
/*  491 */     if (buf != null) {
/*  492 */       this._nameCopyBuffer = null;
/*  493 */       this._ioContext.releaseNameCopyBuffer(buf);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _handleEOF() throws JsonParseException {
/*  504 */     if (!this._parsingContext.inRoot()) {
/*  505 */       String marker = this._parsingContext.inArray() ? "Array" : "Object";
/*  506 */       _reportInvalidEOF(String.format(": expected close marker for %s (start marker at %s)", new Object[] { marker, this._parsingContext
/*      */ 
/*      */               
/*  509 */               .startLocation(_contentReference()) }), (JsonToken)null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final int _eofAsNextChar() throws JsonParseException {
/*  523 */     _handleEOF();
/*  524 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ByteArrayBuilder _getByteArrayBuilder() {
/*  535 */     if (this._byteArrayBuilder == null) {
/*  536 */       this._byteArrayBuilder = new ByteArrayBuilder();
/*      */     } else {
/*  538 */       this._byteArrayBuilder.reset();
/*      */     } 
/*  540 */     return this._byteArrayBuilder;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final JsonToken reset(boolean negative, int intLen, int fractLen, int expLen) {
/*  553 */     if (fractLen < 1 && expLen < 1) {
/*  554 */       return resetInt(negative, intLen);
/*      */     }
/*  556 */     return resetFloat(negative, intLen, fractLen, expLen);
/*      */   }
/*      */ 
/*      */   
/*      */   protected final JsonToken resetInt(boolean negative, int intLen) {
/*  561 */     this._numberNegative = negative;
/*  562 */     this._intLength = intLen;
/*  563 */     this._fractLength = 0;
/*  564 */     this._expLength = 0;
/*  565 */     this._numTypesValid = 0;
/*  566 */     return JsonToken.VALUE_NUMBER_INT;
/*      */   }
/*      */ 
/*      */   
/*      */   protected final JsonToken resetFloat(boolean negative, int intLen, int fractLen, int expLen) {
/*  571 */     this._numberNegative = negative;
/*  572 */     this._intLength = intLen;
/*  573 */     this._fractLength = fractLen;
/*  574 */     this._expLength = expLen;
/*  575 */     this._numTypesValid = 0;
/*  576 */     return JsonToken.VALUE_NUMBER_FLOAT;
/*      */   }
/*      */ 
/*      */   
/*      */   protected final JsonToken resetAsNaN(String valueStr, double value) {
/*  581 */     this._textBuffer.resetWithString(valueStr);
/*  582 */     this._numberDouble = value;
/*  583 */     this._numTypesValid = 8;
/*  584 */     return JsonToken.VALUE_NUMBER_FLOAT;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isNaN() {
/*  589 */     if (this._currToken == JsonToken.VALUE_NUMBER_FLOAT && (
/*  590 */       this._numTypesValid & 0x8) != 0) {
/*      */       
/*  592 */       double d = this._numberDouble;
/*  593 */       return (Double.isNaN(d) || Double.isInfinite(d));
/*      */     } 
/*      */     
/*  596 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Number getNumberValue() throws IOException {
/*  608 */     if (this._numTypesValid == 0) {
/*  609 */       _parseNumericValue(0);
/*      */     }
/*      */     
/*  612 */     if (this._currToken == JsonToken.VALUE_NUMBER_INT) {
/*  613 */       if ((this._numTypesValid & 0x1) != 0) {
/*  614 */         return Integer.valueOf(this._numberInt);
/*      */       }
/*  616 */       if ((this._numTypesValid & 0x2) != 0) {
/*  617 */         return Long.valueOf(this._numberLong);
/*      */       }
/*  619 */       if ((this._numTypesValid & 0x4) != 0) {
/*  620 */         return _getBigInteger();
/*      */       }
/*  622 */       _throwInternal();
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  627 */     if ((this._numTypesValid & 0x10) != 0) {
/*  628 */       return _getBigDecimal();
/*      */     }
/*  630 */     if ((this._numTypesValid & 0x20) != 0) {
/*  631 */       return Float.valueOf(this._numberFloat);
/*      */     }
/*  633 */     if ((this._numTypesValid & 0x8) == 0) {
/*  634 */       _throwInternal();
/*      */     }
/*  636 */     return Double.valueOf(this._numberDouble);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Number getNumberValueExact() throws IOException {
/*  643 */     if (this._currToken == JsonToken.VALUE_NUMBER_INT) {
/*  644 */       if (this._numTypesValid == 0) {
/*  645 */         _parseNumericValue(0);
/*      */       }
/*  647 */       if ((this._numTypesValid & 0x1) != 0) {
/*  648 */         return Integer.valueOf(this._numberInt);
/*      */       }
/*  650 */       if ((this._numTypesValid & 0x2) != 0) {
/*  651 */         return Long.valueOf(this._numberLong);
/*      */       }
/*  653 */       if ((this._numTypesValid & 0x4) != 0) {
/*  654 */         return _getBigInteger();
/*      */       }
/*  656 */       _throwInternal();
/*      */     } 
/*      */     
/*  659 */     if (this._numTypesValid == 0) {
/*  660 */       _parseNumericValue(16);
/*      */     }
/*  662 */     if ((this._numTypesValid & 0x10) != 0) {
/*  663 */       return _getBigDecimal();
/*      */     }
/*  665 */     if ((this._numTypesValid & 0x20) != 0) {
/*  666 */       return Float.valueOf(this._numberFloat);
/*      */     }
/*  668 */     if ((this._numTypesValid & 0x8) == 0) {
/*  669 */       _throwInternal();
/*      */     }
/*  671 */     return Double.valueOf(this._numberDouble);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser.NumberType getNumberType() throws IOException {
/*  677 */     if (this._numTypesValid == 0) {
/*  678 */       _parseNumericValue(0);
/*      */     }
/*  680 */     if (this._currToken == JsonToken.VALUE_NUMBER_INT) {
/*  681 */       if ((this._numTypesValid & 0x1) != 0) {
/*  682 */         return JsonParser.NumberType.INT;
/*      */       }
/*  684 */       if ((this._numTypesValid & 0x2) != 0) {
/*  685 */         return JsonParser.NumberType.LONG;
/*      */       }
/*  687 */       return JsonParser.NumberType.BIG_INTEGER;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  696 */     if ((this._numTypesValid & 0x10) != 0) {
/*  697 */       return JsonParser.NumberType.BIG_DECIMAL;
/*      */     }
/*  699 */     if ((this._numTypesValid & 0x20) != 0) {
/*  700 */       return JsonParser.NumberType.FLOAT;
/*      */     }
/*  702 */     return JsonParser.NumberType.DOUBLE;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getIntValue() throws IOException {
/*  708 */     if ((this._numTypesValid & 0x1) == 0) {
/*  709 */       if (this._numTypesValid == 0) {
/*  710 */         return _parseIntValue();
/*      */       }
/*  712 */       if ((this._numTypesValid & 0x1) == 0) {
/*  713 */         convertNumberToInt();
/*      */       }
/*      */     } 
/*  716 */     return this._numberInt;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public long getLongValue() throws IOException {
/*  722 */     if ((this._numTypesValid & 0x2) == 0) {
/*  723 */       if (this._numTypesValid == 0) {
/*  724 */         _parseNumericValue(2);
/*      */       }
/*  726 */       if ((this._numTypesValid & 0x2) == 0) {
/*  727 */         convertNumberToLong();
/*      */       }
/*      */     } 
/*  730 */     return this._numberLong;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public BigInteger getBigIntegerValue() throws IOException {
/*  736 */     if ((this._numTypesValid & 0x4) == 0) {
/*  737 */       if (this._numTypesValid == 0) {
/*  738 */         _parseNumericValue(4);
/*      */       }
/*  740 */       if ((this._numTypesValid & 0x4) == 0) {
/*  741 */         convertNumberToBigInteger();
/*      */       }
/*      */     } 
/*  744 */     return _getBigInteger();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getFloatValue() throws IOException {
/*  758 */     if ((this._numTypesValid & 0x20) == 0) {
/*  759 */       if (this._numTypesValid == 0) {
/*  760 */         _parseNumericValue(32);
/*      */       }
/*  762 */       if ((this._numTypesValid & 0x20) == 0) {
/*  763 */         convertNumberToFloat();
/*      */       }
/*      */     } 
/*  766 */     return this._numberFloat;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public double getDoubleValue() throws IOException {
/*  772 */     if ((this._numTypesValid & 0x8) == 0) {
/*  773 */       if (this._numTypesValid == 0) {
/*  774 */         _parseNumericValue(8);
/*      */       }
/*  776 */       if ((this._numTypesValid & 0x8) == 0) {
/*  777 */         convertNumberToDouble();
/*      */       }
/*      */     } 
/*  780 */     return this._numberDouble;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public BigDecimal getDecimalValue() throws IOException {
/*  786 */     if ((this._numTypesValid & 0x10) == 0) {
/*  787 */       if (this._numTypesValid == 0) {
/*  788 */         _parseNumericValue(16);
/*      */       }
/*  790 */       if ((this._numTypesValid & 0x10) == 0) {
/*  791 */         convertNumberToBigDecimal();
/*      */       }
/*      */     } 
/*  794 */     return _getBigDecimal();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _parseNumericValue(int expType) throws IOException {
/*  820 */     if (this._closed) {
/*  821 */       _reportError("Internal error: _parseNumericValue called when parser instance closed");
/*      */     }
/*      */ 
/*      */     
/*  825 */     if (this._currToken == JsonToken.VALUE_NUMBER_INT) {
/*  826 */       int len = this._intLength;
/*      */       
/*  828 */       if (len <= 9) {
/*  829 */         int i = this._textBuffer.contentsAsInt(this._numberNegative);
/*  830 */         this._numberInt = i;
/*  831 */         this._numTypesValid = 1;
/*      */         return;
/*      */       } 
/*  834 */       if (len <= 18) {
/*  835 */         long l = this._textBuffer.contentsAsLong(this._numberNegative);
/*      */         
/*  837 */         if (len == 10) {
/*  838 */           if (this._numberNegative) {
/*  839 */             if (l >= -2147483648L) {
/*  840 */               this._numberInt = (int)l;
/*  841 */               this._numTypesValid = 1;
/*      */               
/*      */               return;
/*      */             } 
/*  845 */           } else if (l <= 2147483647L) {
/*  846 */             this._numberInt = (int)l;
/*  847 */             this._numTypesValid = 1;
/*      */             
/*      */             return;
/*      */           } 
/*      */         }
/*  852 */         this._numberLong = l;
/*  853 */         this._numTypesValid = 2;
/*      */         return;
/*      */       } 
/*  856 */       _parseSlowInt(expType);
/*      */       return;
/*      */     } 
/*  859 */     if (this._currToken == JsonToken.VALUE_NUMBER_FLOAT) {
/*  860 */       _parseSlowFloat(expType);
/*      */       return;
/*      */     } 
/*  863 */     _reportError("Current token (%s) not numeric, can not use numeric value accessors", this._currToken);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _parseIntValue() throws IOException {
/*  872 */     if (this._closed) {
/*  873 */       _reportError("Internal error: _parseNumericValue called when parser instance closed");
/*      */     }
/*      */     
/*  876 */     if (this._currToken == JsonToken.VALUE_NUMBER_INT && 
/*  877 */       this._intLength <= 9) {
/*  878 */       int i = this._textBuffer.contentsAsInt(this._numberNegative);
/*  879 */       this._numberInt = i;
/*  880 */       this._numTypesValid = 1;
/*  881 */       return i;
/*      */     } 
/*      */ 
/*      */     
/*  885 */     _parseNumericValue(1);
/*  886 */     if ((this._numTypesValid & 0x1) == 0) {
/*  887 */       convertNumberToInt();
/*      */     }
/*  889 */     return this._numberInt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void _parseSlowFloat(int expType) throws IOException {
/*      */     try {
/*  902 */       if (expType == 16) {
/*  903 */         this._numberBigDecimal = null;
/*  904 */         this._numberString = this._textBuffer.contentsAsString();
/*  905 */         this._numTypesValid = 16;
/*  906 */       } else if (expType == 32) {
/*  907 */         this._numberFloat = this._textBuffer.contentsAsFloat(isEnabled(JsonParser.Feature.USE_FAST_DOUBLE_PARSER));
/*  908 */         this._numTypesValid = 32;
/*      */       } else {
/*      */         
/*  911 */         this._numberDouble = this._textBuffer.contentsAsDouble(isEnabled(JsonParser.Feature.USE_FAST_DOUBLE_PARSER));
/*  912 */         this._numTypesValid = 8;
/*      */       } 
/*  914 */     } catch (NumberFormatException nex) {
/*      */       
/*  916 */       _wrapError("Malformed numeric value (" + _longNumberDesc(this._textBuffer.contentsAsString()) + ")", nex);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void _parseSlowInt(int expType) throws IOException {
/*  922 */     String numStr = this._textBuffer.contentsAsString();
/*      */     try {
/*  924 */       int len = this._intLength;
/*  925 */       char[] buf = this._textBuffer.getTextBuffer();
/*  926 */       int offset = this._textBuffer.getTextOffset();
/*  927 */       if (this._numberNegative) {
/*  928 */         offset++;
/*      */       }
/*      */       
/*  931 */       if (NumberInput.inLongRange(buf, offset, len, this._numberNegative)) {
/*      */         
/*  933 */         this._numberLong = Long.parseLong(numStr);
/*  934 */         this._numTypesValid = 2;
/*      */       } else {
/*      */         
/*  937 */         if (expType == 1 || expType == 2) {
/*  938 */           _reportTooLongIntegral(expType, numStr);
/*      */         }
/*  940 */         if (expType == 8 || expType == 32) {
/*  941 */           this._numberDouble = NumberInput.parseDouble(numStr, isEnabled(JsonParser.Feature.USE_FAST_DOUBLE_PARSER));
/*  942 */           this._numTypesValid = 8;
/*      */         } else {
/*      */           
/*  945 */           this._numberBigInt = null;
/*  946 */           this._numberString = numStr;
/*  947 */           this._numTypesValid = 4;
/*      */         } 
/*      */       } 
/*  950 */     } catch (NumberFormatException nex) {
/*      */       
/*  952 */       _wrapError("Malformed numeric value (" + _longNumberDesc(numStr) + ")", nex);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _reportTooLongIntegral(int expType, String rawNum) throws IOException {
/*  959 */     if (expType == 1) {
/*  960 */       reportOverflowInt(rawNum);
/*      */     } else {
/*  962 */       reportOverflowLong(rawNum);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void convertNumberToInt() throws IOException {
/*  975 */     if ((this._numTypesValid & 0x2) != 0) {
/*      */       
/*  977 */       int result = (int)this._numberLong;
/*  978 */       if (result != this._numberLong) {
/*  979 */         reportOverflowInt(getText(), currentToken());
/*      */       }
/*  981 */       this._numberInt = result;
/*  982 */     } else if ((this._numTypesValid & 0x4) != 0) {
/*  983 */       BigInteger bigInteger = _getBigInteger();
/*  984 */       if (BI_MIN_INT.compareTo(bigInteger) > 0 || BI_MAX_INT
/*  985 */         .compareTo(bigInteger) < 0) {
/*  986 */         reportOverflowInt();
/*      */       }
/*  988 */       this._numberInt = bigInteger.intValue();
/*  989 */     } else if ((this._numTypesValid & 0x8) != 0) {
/*      */       
/*  991 */       if (this._numberDouble < -2.147483648E9D || this._numberDouble > 2.147483647E9D) {
/*  992 */         reportOverflowInt();
/*      */       }
/*  994 */       this._numberInt = (int)this._numberDouble;
/*  995 */     } else if ((this._numTypesValid & 0x10) != 0) {
/*  996 */       BigDecimal bigDecimal = _getBigDecimal();
/*  997 */       if (BD_MIN_INT.compareTo(bigDecimal) > 0 || BD_MAX_INT
/*  998 */         .compareTo(bigDecimal) < 0) {
/*  999 */         reportOverflowInt();
/*      */       }
/* 1001 */       this._numberInt = bigDecimal.intValue();
/*      */     } else {
/* 1003 */       _throwInternal();
/*      */     } 
/* 1005 */     this._numTypesValid |= 0x1;
/*      */   }
/*      */ 
/*      */   
/*      */   protected void convertNumberToLong() throws IOException {
/* 1010 */     if ((this._numTypesValid & 0x1) != 0) {
/* 1011 */       this._numberLong = this._numberInt;
/* 1012 */     } else if ((this._numTypesValid & 0x4) != 0) {
/* 1013 */       BigInteger bigInteger = _getBigInteger();
/* 1014 */       if (BI_MIN_LONG.compareTo(bigInteger) > 0 || BI_MAX_LONG
/* 1015 */         .compareTo(bigInteger) < 0) {
/* 1016 */         reportOverflowLong();
/*      */       }
/* 1018 */       this._numberLong = bigInteger.longValue();
/* 1019 */     } else if ((this._numTypesValid & 0x8) != 0) {
/*      */       
/* 1021 */       if (this._numberDouble < -9.223372036854776E18D || this._numberDouble > 9.223372036854776E18D) {
/* 1022 */         reportOverflowLong();
/*      */       }
/* 1024 */       this._numberLong = (long)this._numberDouble;
/* 1025 */     } else if ((this._numTypesValid & 0x10) != 0) {
/* 1026 */       BigDecimal bigDecimal = _getBigDecimal();
/* 1027 */       if (BD_MIN_LONG.compareTo(bigDecimal) > 0 || BD_MAX_LONG
/* 1028 */         .compareTo(bigDecimal) < 0) {
/* 1029 */         reportOverflowLong();
/*      */       }
/* 1031 */       this._numberLong = bigDecimal.longValue();
/*      */     } else {
/* 1033 */       _throwInternal();
/*      */     } 
/* 1035 */     this._numTypesValid |= 0x2;
/*      */   }
/*      */ 
/*      */   
/*      */   protected void convertNumberToBigInteger() throws IOException {
/* 1040 */     if ((this._numTypesValid & 0x10) != 0) {
/*      */       
/* 1042 */       this._numberBigInt = _getBigDecimal().toBigInteger();
/* 1043 */     } else if ((this._numTypesValid & 0x2) != 0) {
/* 1044 */       this._numberBigInt = BigInteger.valueOf(this._numberLong);
/* 1045 */     } else if ((this._numTypesValid & 0x1) != 0) {
/* 1046 */       this._numberBigInt = BigInteger.valueOf(this._numberInt);
/* 1047 */     } else if ((this._numTypesValid & 0x8) != 0) {
/* 1048 */       this._numberBigInt = BigDecimal.valueOf(this._numberDouble).toBigInteger();
/*      */     } else {
/* 1050 */       _throwInternal();
/*      */     } 
/* 1052 */     this._numTypesValid |= 0x4;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void convertNumberToDouble() throws IOException {
/* 1063 */     if ((this._numTypesValid & 0x10) != 0) {
/* 1064 */       this._numberDouble = _getBigDecimal().doubleValue();
/* 1065 */     } else if ((this._numTypesValid & 0x4) != 0) {
/* 1066 */       this._numberDouble = _getBigInteger().doubleValue();
/* 1067 */     } else if ((this._numTypesValid & 0x2) != 0) {
/* 1068 */       this._numberDouble = this._numberLong;
/* 1069 */     } else if ((this._numTypesValid & 0x1) != 0) {
/* 1070 */       this._numberDouble = this._numberInt;
/* 1071 */     } else if ((this._numTypesValid & 0x20) != 0) {
/* 1072 */       this._numberDouble = this._numberFloat;
/*      */     } else {
/* 1074 */       _throwInternal();
/*      */     } 
/* 1076 */     this._numTypesValid |= 0x8;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void convertNumberToFloat() throws IOException {
/* 1087 */     if ((this._numTypesValid & 0x10) != 0) {
/* 1088 */       this._numberFloat = _getBigDecimal().floatValue();
/* 1089 */     } else if ((this._numTypesValid & 0x4) != 0) {
/* 1090 */       this._numberFloat = _getBigInteger().floatValue();
/* 1091 */     } else if ((this._numTypesValid & 0x2) != 0) {
/* 1092 */       this._numberFloat = (float)this._numberLong;
/* 1093 */     } else if ((this._numTypesValid & 0x1) != 0) {
/* 1094 */       this._numberFloat = this._numberInt;
/* 1095 */     } else if ((this._numTypesValid & 0x8) != 0) {
/* 1096 */       this._numberFloat = (float)this._numberDouble;
/*      */     } else {
/* 1098 */       _throwInternal();
/*      */     } 
/* 1100 */     this._numTypesValid |= 0x20;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void convertNumberToBigDecimal() throws IOException {
/* 1111 */     if ((this._numTypesValid & 0x8) != 0) {
/*      */ 
/*      */       
/* 1114 */       this._numberBigDecimal = NumberInput.parseBigDecimal(getText());
/* 1115 */     } else if ((this._numTypesValid & 0x4) != 0) {
/* 1116 */       this._numberBigDecimal = new BigDecimal(_getBigInteger());
/* 1117 */     } else if ((this._numTypesValid & 0x2) != 0) {
/* 1118 */       this._numberBigDecimal = BigDecimal.valueOf(this._numberLong);
/* 1119 */     } else if ((this._numTypesValid & 0x1) != 0) {
/* 1120 */       this._numberBigDecimal = BigDecimal.valueOf(this._numberInt);
/*      */     } else {
/* 1122 */       _throwInternal();
/*      */     } 
/* 1124 */     this._numTypesValid |= 0x10;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected BigInteger _getBigInteger() {
/* 1134 */     if (this._numberBigInt != null)
/* 1135 */       return this._numberBigInt; 
/* 1136 */     if (this._numberString == null) {
/* 1137 */       throw new IllegalStateException("cannot get BigInteger from current parser state");
/*      */     }
/* 1139 */     this._numberBigInt = NumberInput.parseBigInteger(this._numberString);
/* 1140 */     this._numberString = null;
/* 1141 */     return this._numberBigInt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected BigDecimal _getBigDecimal() {
/* 1151 */     if (this._numberBigDecimal != null)
/* 1152 */       return this._numberBigDecimal; 
/* 1153 */     if (this._numberString == null) {
/* 1154 */       throw new IllegalStateException("cannot get BigDecimal from current parser state");
/*      */     }
/* 1156 */     this._numberBigDecimal = NumberInput.parseBigDecimal(this._numberString);
/* 1157 */     this._numberString = null;
/* 1158 */     return this._numberBigDecimal;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _reportMismatchedEndMarker(int actCh, char expCh) throws JsonParseException {
/* 1168 */     JsonReadContext ctxt = getParsingContext();
/* 1169 */     _reportError(String.format("Unexpected close marker '%s': expected '%c' (for %s starting at %s)", new Object[] {
/*      */             
/* 1171 */             Character.valueOf((char)actCh), Character.valueOf(expCh), ctxt.typeDesc(), ctxt
/* 1172 */             .startLocation(_contentReference())
/*      */           }));
/*      */   }
/*      */ 
/*      */   
/*      */   protected char _handleUnrecognizedCharacterEscape(char ch) throws JsonProcessingException {
/* 1178 */     if (isEnabled(JsonParser.Feature.ALLOW_BACKSLASH_ESCAPING_ANY_CHARACTER)) {
/* 1179 */       return ch;
/*      */     }
/*      */     
/* 1182 */     if (ch == '\'' && isEnabled(JsonParser.Feature.ALLOW_SINGLE_QUOTES)) {
/* 1183 */       return ch;
/*      */     }
/* 1185 */     _reportError("Unrecognized character escape " + _getCharDesc(ch));
/* 1186 */     return ch;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _throwUnquotedSpace(int i, String ctxtDesc) throws JsonParseException {
/* 1203 */     if (!isEnabled(JsonParser.Feature.ALLOW_UNQUOTED_CONTROL_CHARS) || i > 32) {
/* 1204 */       char c = (char)i;
/* 1205 */       String msg = "Illegal unquoted character (" + _getCharDesc(c) + "): has to be escaped using backslash to be included in " + ctxtDesc;
/* 1206 */       _reportError(msg);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String _validJsonTokenList() throws IOException {
/* 1220 */     return _validJsonValueList();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String _validJsonValueList() throws IOException {
/* 1234 */     if (isEnabled(JsonParser.Feature.ALLOW_NON_NUMERIC_NUMBERS)) {
/* 1235 */       return "(JSON String, Number (or 'NaN'/'INF'/'+INF'), Array, Object or token 'null', 'true' or 'false')";
/*      */     }
/* 1237 */     return "(JSON String, Number, Array, Object or token 'null', 'true' or 'false')";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected char _decodeEscaped() throws IOException {
/* 1256 */     throw new UnsupportedOperationException();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected final int _decodeBase64Escape(Base64Variant b64variant, int ch, int index) throws IOException {
/* 1262 */     if (ch != 92) {
/* 1263 */       throw reportInvalidBase64Char(b64variant, ch, index);
/*      */     }
/* 1265 */     int unescaped = _decodeEscaped();
/*      */     
/* 1267 */     if (unescaped <= 32 && 
/* 1268 */       index == 0) {
/* 1269 */       return -1;
/*      */     }
/*      */ 
/*      */     
/* 1273 */     int bits = b64variant.decodeBase64Char(unescaped);
/* 1274 */     if (bits < 0 && 
/* 1275 */       bits != -2) {
/* 1276 */       throw reportInvalidBase64Char(b64variant, unescaped, index);
/*      */     }
/*      */     
/* 1279 */     return bits;
/*      */   }
/*      */ 
/*      */   
/*      */   protected final int _decodeBase64Escape(Base64Variant b64variant, char ch, int index) throws IOException {
/* 1284 */     if (ch != '\\') {
/* 1285 */       throw reportInvalidBase64Char(b64variant, ch, index);
/*      */     }
/* 1287 */     char unescaped = _decodeEscaped();
/*      */     
/* 1289 */     if (unescaped <= ' ' && 
/* 1290 */       index == 0) {
/* 1291 */       return -1;
/*      */     }
/*      */ 
/*      */     
/* 1295 */     int bits = b64variant.decodeBase64Char(unescaped);
/* 1296 */     if (bits < 0)
/*      */     {
/* 1298 */       if (bits != -2 || index < 2) {
/* 1299 */         throw reportInvalidBase64Char(b64variant, unescaped, index);
/*      */       }
/*      */     }
/* 1302 */     return bits;
/*      */   }
/*      */   
/*      */   protected IllegalArgumentException reportInvalidBase64Char(Base64Variant b64variant, int ch, int bindex) throws IllegalArgumentException {
/* 1306 */     return reportInvalidBase64Char(b64variant, ch, bindex, (String)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected IllegalArgumentException reportInvalidBase64Char(Base64Variant b64variant, int ch, int bindex, String msg) throws IllegalArgumentException {
/*      */     String base;
/* 1315 */     if (ch <= 32) {
/* 1316 */       base = String.format("Illegal white space character (code 0x%s) as character #%d of 4-char base64 unit: can only used between units", new Object[] {
/* 1317 */             Integer.toHexString(ch), Integer.valueOf(bindex + 1) });
/* 1318 */     } else if (b64variant.usesPaddingChar(ch)) {
/* 1319 */       base = "Unexpected padding character ('" + b64variant.getPaddingChar() + "') as character #" + (bindex + 1) + " of 4-char base64 unit: padding only legal as 3rd or 4th character";
/* 1320 */     } else if (!Character.isDefined(ch) || Character.isISOControl(ch)) {
/*      */       
/* 1322 */       base = "Illegal character (code 0x" + Integer.toHexString(ch) + ") in base64 content";
/*      */     } else {
/* 1324 */       base = "Illegal character '" + (char)ch + "' (code 0x" + Integer.toHexString(ch) + ") in base64 content";
/*      */     } 
/* 1326 */     if (msg != null) {
/* 1327 */       base = base + ": " + msg;
/*      */     }
/* 1329 */     return new IllegalArgumentException(base);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _handleBase64MissingPadding(Base64Variant b64variant) throws IOException {
/* 1335 */     _reportError(b64variant.missingPaddingMessage());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected Object _getSourceReference() {
/* 1351 */     if (JsonParser.Feature.INCLUDE_SOURCE_IN_LOCATION.enabledIn(this._features)) {
/* 1352 */       return this._ioContext.contentReference().getRawContent();
/*      */     }
/* 1354 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ContentReference _contentReference() {
/* 1366 */     if (JsonParser.Feature.INCLUDE_SOURCE_IN_LOCATION.enabledIn(this._features)) {
/* 1367 */       return this._ioContext.contentReference();
/*      */     }
/* 1369 */     return ContentReference.unknown();
/*      */   }
/*      */ 
/*      */   
/*      */   protected static int[] growArrayBy(int[] arr, int more) {
/* 1374 */     if (arr == null) {
/* 1375 */       return new int[more];
/*      */     }
/* 1377 */     return Arrays.copyOf(arr, arr.length + more);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected void loadMoreGuaranteed() throws IOException {
/* 1389 */     if (!loadMore()) _reportInvalidEOF(); 
/*      */   }
/*      */   @Deprecated
/*      */   protected boolean loadMore() throws IOException {
/* 1393 */     return false;
/*      */   }
/*      */   
/*      */   protected void _finishString() throws IOException {}
/*      */   
/*      */   protected abstract void _closeInput() throws IOException;
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-core-2.14.2.jar!\com\fasterxml\jackson\core\base\ParserBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */