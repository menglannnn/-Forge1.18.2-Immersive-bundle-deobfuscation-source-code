/*      */ package com.fasterxml.jackson.core.json;
/*      */ 
/*      */ import com.fasterxml.jackson.core.Base64Variant;
/*      */ import com.fasterxml.jackson.core.JsonGenerationException;
/*      */ import com.fasterxml.jackson.core.JsonGenerator;
/*      */ import com.fasterxml.jackson.core.JsonStreamContext;
/*      */ import com.fasterxml.jackson.core.ObjectCodec;
/*      */ import com.fasterxml.jackson.core.SerializableString;
/*      */ import com.fasterxml.jackson.core.io.CharTypes;
/*      */ import com.fasterxml.jackson.core.io.CharacterEscapes;
/*      */ import com.fasterxml.jackson.core.io.IOContext;
/*      */ import com.fasterxml.jackson.core.io.NumberOutput;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.Reader;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ 
/*      */ public class UTF8JsonGenerator
/*      */   extends JsonGeneratorImpl {
/*      */   private static final byte BYTE_u = 117;
/*      */   private static final byte BYTE_0 = 48;
/*      */   private static final byte BYTE_LBRACKET = 91;
/*      */   private static final byte BYTE_RBRACKET = 93;
/*      */   private static final byte BYTE_LCURLY = 123;
/*      */   private static final byte BYTE_RCURLY = 125;
/*      */   private static final byte BYTE_BACKSLASH = 92;
/*      */   private static final byte BYTE_COMMA = 44;
/*      */   private static final byte BYTE_COLON = 58;
/*      */   private static final int MAX_BYTES_TO_BUFFER = 512;
/*   32 */   private static final byte[] HEX_BYTES_UPPER = CharTypes.copyHexBytes(true);
/*   33 */   private static final byte[] HEX_BYTES_LOWER = CharTypes.copyHexBytes(false);
/*      */   
/*   35 */   private static final byte[] NULL_BYTES = new byte[] { 110, 117, 108, 108 };
/*   36 */   private static final byte[] TRUE_BYTES = new byte[] { 116, 114, 117, 101 };
/*   37 */   private static final byte[] FALSE_BYTES = new byte[] { 102, 97, 108, 115, 101 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final OutputStream _outputStream;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected byte _quoteChar;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected byte[] _outputBuffer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _outputTail;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final int _outputEnd;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final int _outputMaxContiguous;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected char[] _charBuffer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final int _charBufferLength;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected byte[] _entityBuffer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _bufferRecyclable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public UTF8JsonGenerator(IOContext ctxt, int features, ObjectCodec codec, OutputStream out, char quoteChar) {
/*  122 */     super(ctxt, features, codec);
/*  123 */     this._outputStream = out;
/*  124 */     this._quoteChar = (byte)quoteChar;
/*  125 */     if (quoteChar != '"') {
/*  126 */       this._outputEscapes = CharTypes.get7BitOutputEscapes(quoteChar);
/*      */     }
/*      */     
/*  129 */     this._bufferRecyclable = true;
/*  130 */     this._outputBuffer = ctxt.allocWriteEncodingBuffer();
/*  131 */     this._outputEnd = this._outputBuffer.length;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  137 */     this._outputMaxContiguous = this._outputEnd >> 3;
/*  138 */     this._charBuffer = ctxt.allocConcatBuffer();
/*  139 */     this._charBufferLength = this._charBuffer.length;
/*      */ 
/*      */     
/*  142 */     if (isEnabled(JsonGenerator.Feature.ESCAPE_NON_ASCII)) {
/*  143 */       setHighestNonEscapedChar(127);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public UTF8JsonGenerator(IOContext ctxt, int features, ObjectCodec codec, OutputStream out, char quoteChar, byte[] outputBuffer, int outputOffset, boolean bufferRecyclable) {
/*  153 */     super(ctxt, features, codec);
/*  154 */     this._outputStream = out;
/*  155 */     this._quoteChar = (byte)quoteChar;
/*  156 */     if (quoteChar != '"') {
/*  157 */       this._outputEscapes = CharTypes.get7BitOutputEscapes(quoteChar);
/*      */     }
/*      */     
/*  160 */     this._bufferRecyclable = bufferRecyclable;
/*  161 */     this._outputTail = outputOffset;
/*  162 */     this._outputBuffer = outputBuffer;
/*  163 */     this._outputEnd = this._outputBuffer.length;
/*      */     
/*  165 */     this._outputMaxContiguous = this._outputEnd >> 3;
/*  166 */     this._charBuffer = ctxt.allocConcatBuffer();
/*  167 */     this._charBufferLength = this._charBuffer.length;
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public UTF8JsonGenerator(IOContext ctxt, int features, ObjectCodec codec, OutputStream out) {
/*  173 */     this(ctxt, features, codec, out, '"');
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public UTF8JsonGenerator(IOContext ctxt, int features, ObjectCodec codec, OutputStream out, byte[] outputBuffer, int outputOffset, boolean bufferRecyclable) {
/*  181 */     this(ctxt, features, codec, out, '"', outputBuffer, outputOffset, bufferRecyclable);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getOutputTarget() {
/*  193 */     return this._outputStream;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getOutputBuffered() {
/*  199 */     return this._outputTail;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeFieldName(String name) throws IOException {
/*  211 */     if (this._cfgPrettyPrinter != null) {
/*  212 */       _writePPFieldName(name);
/*      */       return;
/*      */     } 
/*  215 */     int status = this._writeContext.writeFieldName(name);
/*  216 */     if (status == 4) {
/*  217 */       _reportError("Can not write a field name, expecting a value");
/*      */     }
/*  219 */     if (status == 1) {
/*  220 */       if (this._outputTail >= this._outputEnd) {
/*  221 */         _flushBuffer();
/*      */       }
/*  223 */       this._outputBuffer[this._outputTail++] = 44;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  228 */     if (this._cfgUnqNames) {
/*  229 */       _writeStringSegments(name, false);
/*      */       return;
/*      */     } 
/*  232 */     int len = name.length();
/*      */     
/*  234 */     if (len > this._charBufferLength) {
/*  235 */       _writeStringSegments(name, true);
/*      */       return;
/*      */     } 
/*  238 */     if (this._outputTail >= this._outputEnd) {
/*  239 */       _flushBuffer();
/*      */     }
/*  241 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */     
/*  243 */     if (len <= this._outputMaxContiguous) {
/*  244 */       if (this._outputTail + len > this._outputEnd) {
/*  245 */         _flushBuffer();
/*      */       }
/*  247 */       _writeStringSegment(name, 0, len);
/*      */     } else {
/*  249 */       _writeStringSegments(name, 0, len);
/*      */     } 
/*      */     
/*  252 */     if (this._outputTail >= this._outputEnd) {
/*  253 */       _flushBuffer();
/*      */     }
/*  255 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeFieldName(SerializableString name) throws IOException {
/*  261 */     if (this._cfgPrettyPrinter != null) {
/*  262 */       _writePPFieldName(name);
/*      */       return;
/*      */     } 
/*  265 */     int status = this._writeContext.writeFieldName(name.getValue());
/*  266 */     if (status == 4) {
/*  267 */       _reportError("Can not write a field name, expecting a value");
/*      */     }
/*  269 */     if (status == 1) {
/*  270 */       if (this._outputTail >= this._outputEnd) {
/*  271 */         _flushBuffer();
/*      */       }
/*  273 */       this._outputBuffer[this._outputTail++] = 44;
/*      */     } 
/*  275 */     if (this._cfgUnqNames) {
/*  276 */       _writeUnq(name);
/*      */       return;
/*      */     } 
/*  279 */     if (this._outputTail >= this._outputEnd) {
/*  280 */       _flushBuffer();
/*      */     }
/*  282 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*  283 */     int len = name.appendQuotedUTF8(this._outputBuffer, this._outputTail);
/*  284 */     if (len < 0) {
/*  285 */       _writeBytes(name.asQuotedUTF8());
/*      */     } else {
/*  287 */       this._outputTail += len;
/*      */     } 
/*  289 */     if (this._outputTail >= this._outputEnd) {
/*  290 */       _flushBuffer();
/*      */     }
/*  292 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */   }
/*      */   
/*      */   private final void _writeUnq(SerializableString name) throws IOException {
/*  296 */     int len = name.appendQuotedUTF8(this._outputBuffer, this._outputTail);
/*  297 */     if (len < 0) {
/*  298 */       _writeBytes(name.asQuotedUTF8());
/*      */     } else {
/*  300 */       this._outputTail += len;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void writeStartArray() throws IOException {
/*  313 */     _verifyValueWrite("start an array");
/*  314 */     this._writeContext = this._writeContext.createChildArrayContext();
/*  315 */     if (this._cfgPrettyPrinter != null) {
/*  316 */       this._cfgPrettyPrinter.writeStartArray((JsonGenerator)this);
/*      */     } else {
/*  318 */       if (this._outputTail >= this._outputEnd) {
/*  319 */         _flushBuffer();
/*      */       }
/*  321 */       this._outputBuffer[this._outputTail++] = 91;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final void writeStartArray(Object currentValue) throws IOException {
/*  328 */     _verifyValueWrite("start an array");
/*  329 */     this._writeContext = this._writeContext.createChildArrayContext(currentValue);
/*  330 */     if (this._cfgPrettyPrinter != null) {
/*  331 */       this._cfgPrettyPrinter.writeStartArray((JsonGenerator)this);
/*      */     } else {
/*  333 */       if (this._outputTail >= this._outputEnd) {
/*  334 */         _flushBuffer();
/*      */       }
/*  336 */       this._outputBuffer[this._outputTail++] = 91;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeStartArray(Object currentValue, int size) throws IOException {
/*  343 */     _verifyValueWrite("start an array");
/*  344 */     this._writeContext = this._writeContext.createChildArrayContext(currentValue);
/*  345 */     if (this._cfgPrettyPrinter != null) {
/*  346 */       this._cfgPrettyPrinter.writeStartArray((JsonGenerator)this);
/*      */     } else {
/*  348 */       if (this._outputTail >= this._outputEnd) {
/*  349 */         _flushBuffer();
/*      */       }
/*  351 */       this._outputBuffer[this._outputTail++] = 91;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final void writeEndArray() throws IOException {
/*  358 */     if (!this._writeContext.inArray()) {
/*  359 */       _reportError("Current context not Array but " + this._writeContext.typeDesc());
/*      */     }
/*  361 */     if (this._cfgPrettyPrinter != null) {
/*  362 */       this._cfgPrettyPrinter.writeEndArray((JsonGenerator)this, this._writeContext.getEntryCount());
/*      */     } else {
/*  364 */       if (this._outputTail >= this._outputEnd) {
/*  365 */         _flushBuffer();
/*      */       }
/*  367 */       this._outputBuffer[this._outputTail++] = 93;
/*      */     } 
/*  369 */     this._writeContext = this._writeContext.clearAndGetParent();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final void writeStartObject() throws IOException {
/*  375 */     _verifyValueWrite("start an object");
/*  376 */     this._writeContext = this._writeContext.createChildObjectContext();
/*  377 */     if (this._cfgPrettyPrinter != null) {
/*  378 */       this._cfgPrettyPrinter.writeStartObject((JsonGenerator)this);
/*      */     } else {
/*  380 */       if (this._outputTail >= this._outputEnd) {
/*  381 */         _flushBuffer();
/*      */       }
/*  383 */       this._outputBuffer[this._outputTail++] = 123;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeStartObject(Object forValue) throws IOException {
/*  390 */     _verifyValueWrite("start an object");
/*  391 */     JsonWriteContext ctxt = this._writeContext.createChildObjectContext(forValue);
/*  392 */     this._writeContext = ctxt;
/*  393 */     if (this._cfgPrettyPrinter != null) {
/*  394 */       this._cfgPrettyPrinter.writeStartObject((JsonGenerator)this);
/*      */     } else {
/*  396 */       if (this._outputTail >= this._outputEnd) {
/*  397 */         _flushBuffer();
/*      */       }
/*  399 */       this._outputBuffer[this._outputTail++] = 123;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void writeStartObject(Object forValue, int size) throws IOException {
/*  405 */     writeStartObject(forValue);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final void writeEndObject() throws IOException {
/*  411 */     if (!this._writeContext.inObject()) {
/*  412 */       _reportError("Current context not Object but " + this._writeContext.typeDesc());
/*      */     }
/*  414 */     if (this._cfgPrettyPrinter != null) {
/*  415 */       this._cfgPrettyPrinter.writeEndObject((JsonGenerator)this, this._writeContext.getEntryCount());
/*      */     } else {
/*  417 */       if (this._outputTail >= this._outputEnd) {
/*  418 */         _flushBuffer();
/*      */       }
/*  420 */       this._outputBuffer[this._outputTail++] = 125;
/*      */     } 
/*  422 */     this._writeContext = this._writeContext.clearAndGetParent();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void _writePPFieldName(String name) throws IOException {
/*  429 */     int status = this._writeContext.writeFieldName(name);
/*  430 */     if (status == 4) {
/*  431 */       _reportError("Can not write a field name, expecting a value");
/*      */     }
/*  433 */     if (status == 1) {
/*  434 */       this._cfgPrettyPrinter.writeObjectEntrySeparator((JsonGenerator)this);
/*      */     } else {
/*  436 */       this._cfgPrettyPrinter.beforeObjectEntries((JsonGenerator)this);
/*      */     } 
/*  438 */     if (this._cfgUnqNames) {
/*  439 */       _writeStringSegments(name, false);
/*      */       return;
/*      */     } 
/*  442 */     int len = name.length();
/*  443 */     if (len > this._charBufferLength) {
/*  444 */       _writeStringSegments(name, true);
/*      */       return;
/*      */     } 
/*  447 */     if (this._outputTail >= this._outputEnd) {
/*  448 */       _flushBuffer();
/*      */     }
/*  450 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*  451 */     name.getChars(0, len, this._charBuffer, 0);
/*      */     
/*  453 */     if (len <= this._outputMaxContiguous) {
/*  454 */       if (this._outputTail + len > this._outputEnd) {
/*  455 */         _flushBuffer();
/*      */       }
/*  457 */       _writeStringSegment(this._charBuffer, 0, len);
/*      */     } else {
/*  459 */       _writeStringSegments(this._charBuffer, 0, len);
/*      */     } 
/*  461 */     if (this._outputTail >= this._outputEnd) {
/*  462 */       _flushBuffer();
/*      */     }
/*  464 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */   }
/*      */ 
/*      */   
/*      */   protected final void _writePPFieldName(SerializableString name) throws IOException {
/*  469 */     int status = this._writeContext.writeFieldName(name.getValue());
/*  470 */     if (status == 4) {
/*  471 */       _reportError("Can not write a field name, expecting a value");
/*      */     }
/*  473 */     if (status == 1) {
/*  474 */       this._cfgPrettyPrinter.writeObjectEntrySeparator((JsonGenerator)this);
/*      */     } else {
/*  476 */       this._cfgPrettyPrinter.beforeObjectEntries((JsonGenerator)this);
/*      */     } 
/*      */     
/*  479 */     boolean addQuotes = !this._cfgUnqNames;
/*  480 */     if (addQuotes) {
/*  481 */       if (this._outputTail >= this._outputEnd) {
/*  482 */         _flushBuffer();
/*      */       }
/*  484 */       this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */     } 
/*  486 */     int len = name.appendQuotedUTF8(this._outputBuffer, this._outputTail);
/*  487 */     if (len < 0) {
/*  488 */       _writeBytes(name.asQuotedUTF8());
/*      */     } else {
/*  490 */       this._outputTail += len;
/*      */     } 
/*  492 */     if (addQuotes) {
/*  493 */       if (this._outputTail >= this._outputEnd) {
/*  494 */         _flushBuffer();
/*      */       }
/*  496 */       this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeString(String text) throws IOException {
/*  509 */     _verifyValueWrite("write a string");
/*  510 */     if (text == null) {
/*  511 */       _writeNull();
/*      */       
/*      */       return;
/*      */     } 
/*  515 */     int len = text.length();
/*  516 */     if (len > this._outputMaxContiguous) {
/*  517 */       _writeStringSegments(text, true);
/*      */       return;
/*      */     } 
/*  520 */     if (this._outputTail + len >= this._outputEnd) {
/*  521 */       _flushBuffer();
/*      */     }
/*  523 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*  524 */     _writeStringSegment(text, 0, len);
/*  525 */     if (this._outputTail >= this._outputEnd) {
/*  526 */       _flushBuffer();
/*      */     }
/*  528 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */   }
/*      */ 
/*      */   
/*      */   public void writeString(Reader reader, int len) throws IOException {
/*  533 */     _verifyValueWrite("write a string");
/*  534 */     if (reader == null) {
/*  535 */       _reportError("null reader");
/*      */       
/*      */       return;
/*      */     } 
/*  539 */     int toRead = (len >= 0) ? len : Integer.MAX_VALUE;
/*  540 */     char[] buf = this._charBuffer;
/*      */ 
/*      */     
/*  543 */     if (this._outputTail >= this._outputEnd) {
/*  544 */       _flushBuffer();
/*      */     }
/*  546 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */ 
/*      */     
/*  549 */     while (toRead > 0) {
/*  550 */       int toReadNow = Math.min(toRead, buf.length);
/*  551 */       int numRead = reader.read(buf, 0, toReadNow);
/*  552 */       if (numRead <= 0) {
/*      */         break;
/*      */       }
/*  555 */       if (this._outputTail + len >= this._outputEnd) {
/*  556 */         _flushBuffer();
/*      */       }
/*  558 */       _writeStringSegments(buf, 0, numRead);
/*      */       
/*  560 */       toRead -= numRead;
/*      */     } 
/*      */ 
/*      */     
/*  564 */     if (this._outputTail >= this._outputEnd) {
/*  565 */       _flushBuffer();
/*      */     }
/*  567 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */     
/*  569 */     if (toRead > 0 && len >= 0) {
/*  570 */       _reportError("Didn't read enough from reader");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeString(char[] text, int offset, int len) throws IOException {
/*  577 */     _verifyValueWrite("write a string");
/*  578 */     if (this._outputTail >= this._outputEnd) {
/*  579 */       _flushBuffer();
/*      */     }
/*  581 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */     
/*  583 */     if (len <= this._outputMaxContiguous) {
/*  584 */       if (this._outputTail + len > this._outputEnd) {
/*  585 */         _flushBuffer();
/*      */       }
/*  587 */       _writeStringSegment(text, offset, len);
/*      */     } else {
/*  589 */       _writeStringSegments(text, offset, len);
/*      */     } 
/*      */     
/*  592 */     if (this._outputTail >= this._outputEnd) {
/*  593 */       _flushBuffer();
/*      */     }
/*  595 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final void writeString(SerializableString text) throws IOException {
/*  601 */     _verifyValueWrite("write a string");
/*  602 */     if (this._outputTail >= this._outputEnd) {
/*  603 */       _flushBuffer();
/*      */     }
/*  605 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*  606 */     int len = text.appendQuotedUTF8(this._outputBuffer, this._outputTail);
/*  607 */     if (len < 0) {
/*  608 */       _writeBytes(text.asQuotedUTF8());
/*      */     } else {
/*  610 */       this._outputTail += len;
/*      */     } 
/*  612 */     if (this._outputTail >= this._outputEnd) {
/*  613 */       _flushBuffer();
/*      */     }
/*  615 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeRawUTF8String(byte[] text, int offset, int len) throws IOException {
/*  621 */     _checkRangeBoundsForByteArray(text, offset, len);
/*  622 */     _verifyValueWrite("write a string");
/*  623 */     if (this._outputTail >= this._outputEnd) {
/*  624 */       _flushBuffer();
/*      */     }
/*  626 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*  627 */     _writeBytes(text, offset, len);
/*  628 */     if (this._outputTail >= this._outputEnd) {
/*  629 */       _flushBuffer();
/*      */     }
/*  631 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeUTF8String(byte[] text, int offset, int len) throws IOException {
/*  637 */     _checkRangeBoundsForByteArray(text, offset, len);
/*  638 */     _verifyValueWrite("write a string");
/*  639 */     if (this._outputTail >= this._outputEnd) {
/*  640 */       _flushBuffer();
/*      */     }
/*  642 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */     
/*  644 */     if (len <= this._outputMaxContiguous) {
/*  645 */       _writeUTF8Segment(text, offset, len);
/*      */     } else {
/*  647 */       _writeUTF8Segments(text, offset, len);
/*      */     } 
/*  649 */     if (this._outputTail >= this._outputEnd) {
/*  650 */       _flushBuffer();
/*      */     }
/*  652 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeRaw(String text) throws IOException {
/*  663 */     int len = text.length();
/*  664 */     char[] buf = this._charBuffer;
/*  665 */     if (len <= buf.length) {
/*  666 */       text.getChars(0, len, buf, 0);
/*  667 */       writeRaw(buf, 0, len);
/*      */     } else {
/*  669 */       writeRaw(text, 0, len);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeRaw(String text, int offset, int len) throws IOException {
/*  676 */     _checkRangeBoundsForString(text, offset, len);
/*      */     
/*  678 */     char[] buf = this._charBuffer;
/*  679 */     int cbufLen = buf.length;
/*      */     
/*  681 */     if (len <= cbufLen) {
/*  682 */       text.getChars(offset, offset + len, buf, 0);
/*  683 */       writeRaw(buf, 0, len);
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */ 
/*      */     
/*  690 */     int maxChunk = Math.min(cbufLen, (this._outputEnd >> 2) + (this._outputEnd >> 4));
/*      */     
/*  692 */     int maxBytes = maxChunk * 3;
/*      */     
/*  694 */     while (len > 0) {
/*  695 */       int len2 = Math.min(maxChunk, len);
/*  696 */       text.getChars(offset, offset + len2, buf, 0);
/*  697 */       if (this._outputTail + maxBytes > this._outputEnd) {
/*  698 */         _flushBuffer();
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  706 */       if (len2 > 1) {
/*  707 */         char ch = buf[len2 - 1];
/*  708 */         if (ch >= '?' && ch <= '?') {
/*  709 */           len2--;
/*      */         }
/*      */       } 
/*  712 */       _writeRawSegment(buf, 0, len2);
/*  713 */       offset += len2;
/*  714 */       len -= len2;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeRaw(SerializableString text) throws IOException {
/*  721 */     int len = text.appendUnquotedUTF8(this._outputBuffer, this._outputTail);
/*  722 */     if (len < 0) {
/*  723 */       _writeBytes(text.asUnquotedUTF8());
/*      */     } else {
/*  725 */       this._outputTail += len;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeRawValue(SerializableString text) throws IOException {
/*  732 */     _verifyValueWrite("write a raw (unencoded) value");
/*  733 */     int len = text.appendUnquotedUTF8(this._outputBuffer, this._outputTail);
/*  734 */     if (len < 0) {
/*  735 */       _writeBytes(text.asUnquotedUTF8());
/*      */     } else {
/*  737 */       this._outputTail += len;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void writeRaw(char[] cbuf, int offset, int len) throws IOException {
/*  745 */     _checkRangeBoundsForCharArray(cbuf, offset, len);
/*      */ 
/*      */ 
/*      */     
/*  749 */     int len3 = len + len + len;
/*  750 */     if (this._outputTail + len3 > this._outputEnd) {
/*      */       
/*  752 */       if (this._outputEnd < len3) {
/*  753 */         _writeSegmentedRaw(cbuf, offset, len);
/*      */         
/*      */         return;
/*      */       } 
/*  757 */       _flushBuffer();
/*      */     } 
/*      */     
/*  760 */     len += offset;
/*      */ 
/*      */ 
/*      */     
/*  764 */     while (offset < len) {
/*      */       
/*      */       while (true) {
/*  767 */         int ch = cbuf[offset];
/*  768 */         if (ch > 127) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  776 */           ch = cbuf[offset++];
/*  777 */           if (ch < 2048) {
/*  778 */             this._outputBuffer[this._outputTail++] = (byte)(0xC0 | ch >> 6);
/*  779 */             this._outputBuffer[this._outputTail++] = (byte)(0x80 | ch & 0x3F); continue;
/*      */           } 
/*  781 */           offset = _outputRawMultiByteChar(ch, cbuf, offset, len);
/*      */           continue;
/*      */         } 
/*      */         this._outputBuffer[this._outputTail++] = (byte)ch;
/*      */         if (++offset >= len)
/*      */           break; 
/*      */       } 
/*      */     }  } public void writeRaw(char ch) throws IOException {
/*  789 */     if (this._outputTail + 3 >= this._outputEnd) {
/*  790 */       _flushBuffer();
/*      */     }
/*  792 */     byte[] bbuf = this._outputBuffer;
/*  793 */     if (ch <= '') {
/*  794 */       bbuf[this._outputTail++] = (byte)ch;
/*  795 */     } else if (ch < 'ࠀ') {
/*  796 */       bbuf[this._outputTail++] = (byte)(0xC0 | ch >> 6);
/*  797 */       bbuf[this._outputTail++] = (byte)(0x80 | ch & 0x3F);
/*      */     } else {
/*  799 */       _outputRawMultiByteChar(ch, (char[])null, 0, 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _writeSegmentedRaw(char[] cbuf, int offset, int len) throws IOException {
/*  809 */     int end = this._outputEnd;
/*  810 */     byte[] bbuf = this._outputBuffer;
/*  811 */     int inputEnd = offset + len;
/*      */ 
/*      */     
/*  814 */     while (offset < inputEnd) {
/*      */       
/*      */       while (true) {
/*  817 */         int ch = cbuf[offset];
/*  818 */         if (ch >= 128) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  830 */           if (this._outputTail + 3 >= this._outputEnd) {
/*  831 */             _flushBuffer();
/*      */           }
/*  833 */           ch = cbuf[offset++];
/*  834 */           if (ch < 2048) {
/*  835 */             bbuf[this._outputTail++] = (byte)(0xC0 | ch >> 6);
/*  836 */             bbuf[this._outputTail++] = (byte)(0x80 | ch & 0x3F); continue;
/*      */           } 
/*  838 */           offset = _outputRawMultiByteChar(ch, cbuf, offset, inputEnd);
/*      */           continue;
/*      */         } 
/*      */         if (this._outputTail >= end) {
/*      */           _flushBuffer();
/*      */         }
/*      */         bbuf[this._outputTail++] = (byte)ch;
/*      */         if (++offset >= inputEnd) {
/*      */           break;
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void _writeRawSegment(char[] cbuf, int offset, int end) throws IOException {
/*  855 */     while (offset < end) {
/*      */       
/*      */       while (true) {
/*  858 */         int ch = cbuf[offset];
/*  859 */         if (ch > 127) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  867 */           ch = cbuf[offset++];
/*  868 */           if (ch < 2048) {
/*  869 */             this._outputBuffer[this._outputTail++] = (byte)(0xC0 | ch >> 6);
/*  870 */             this._outputBuffer[this._outputTail++] = (byte)(0x80 | ch & 0x3F); continue;
/*      */           } 
/*  872 */           offset = _outputRawMultiByteChar(ch, cbuf, offset, end);
/*      */           continue;
/*      */         } 
/*      */         this._outputBuffer[this._outputTail++] = (byte)ch;
/*      */         if (++offset >= end) {
/*      */           break;
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeBinary(Base64Variant b64variant, byte[] data, int offset, int len) throws IOException, JsonGenerationException {
/*  888 */     _checkRangeBoundsForByteArray(data, offset, len);
/*      */     
/*  890 */     _verifyValueWrite("write a binary value");
/*      */     
/*  892 */     if (this._outputTail >= this._outputEnd) {
/*  893 */       _flushBuffer();
/*      */     }
/*  895 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*  896 */     _writeBinary(b64variant, data, offset, offset + len);
/*      */     
/*  898 */     if (this._outputTail >= this._outputEnd) {
/*  899 */       _flushBuffer();
/*      */     }
/*  901 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int writeBinary(Base64Variant b64variant, InputStream data, int dataLength) throws IOException, JsonGenerationException {
/*      */     int bytes;
/*  909 */     _verifyValueWrite("write a binary value");
/*      */     
/*  911 */     if (this._outputTail >= this._outputEnd) {
/*  912 */       _flushBuffer();
/*      */     }
/*  914 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*  915 */     byte[] encodingBuffer = this._ioContext.allocBase64Buffer();
/*      */     
/*      */     try {
/*  918 */       if (dataLength < 0) {
/*  919 */         bytes = _writeBinary(b64variant, data, encodingBuffer);
/*      */       } else {
/*  921 */         int missing = _writeBinary(b64variant, data, encodingBuffer, dataLength);
/*  922 */         if (missing > 0) {
/*  923 */           _reportError("Too few bytes available: missing " + missing + " bytes (out of " + dataLength + ")");
/*      */         }
/*  925 */         bytes = dataLength;
/*      */       } 
/*      */     } finally {
/*  928 */       this._ioContext.releaseBase64Buffer(encodingBuffer);
/*      */     } 
/*      */     
/*  931 */     if (this._outputTail >= this._outputEnd) {
/*  932 */       _flushBuffer();
/*      */     }
/*  934 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*  935 */     return bytes;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumber(short s) throws IOException {
/*  947 */     _verifyValueWrite("write a number");
/*      */     
/*  949 */     if (this._outputTail + 6 >= this._outputEnd) {
/*  950 */       _flushBuffer();
/*      */     }
/*  952 */     if (this._cfgNumbersAsStrings) {
/*  953 */       _writeQuotedShort(s);
/*      */       return;
/*      */     } 
/*  956 */     this._outputTail = NumberOutput.outputInt(s, this._outputBuffer, this._outputTail);
/*      */   }
/*      */   
/*      */   private final void _writeQuotedShort(short s) throws IOException {
/*  960 */     if (this._outputTail + 8 >= this._outputEnd) {
/*  961 */       _flushBuffer();
/*      */     }
/*  963 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*  964 */     this._outputTail = NumberOutput.outputInt(s, this._outputBuffer, this._outputTail);
/*  965 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumber(int i) throws IOException {
/*  971 */     _verifyValueWrite("write a number");
/*      */     
/*  973 */     if (this._outputTail + 11 >= this._outputEnd) {
/*  974 */       _flushBuffer();
/*      */     }
/*  976 */     if (this._cfgNumbersAsStrings) {
/*  977 */       _writeQuotedInt(i);
/*      */       return;
/*      */     } 
/*  980 */     this._outputTail = NumberOutput.outputInt(i, this._outputBuffer, this._outputTail);
/*      */   }
/*      */ 
/*      */   
/*      */   private final void _writeQuotedInt(int i) throws IOException {
/*  985 */     if (this._outputTail + 13 >= this._outputEnd) {
/*  986 */       _flushBuffer();
/*      */     }
/*  988 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*  989 */     this._outputTail = NumberOutput.outputInt(i, this._outputBuffer, this._outputTail);
/*  990 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumber(long l) throws IOException {
/*  996 */     _verifyValueWrite("write a number");
/*  997 */     if (this._cfgNumbersAsStrings) {
/*  998 */       _writeQuotedLong(l);
/*      */       return;
/*      */     } 
/* 1001 */     if (this._outputTail + 21 >= this._outputEnd)
/*      */     {
/* 1003 */       _flushBuffer();
/*      */     }
/* 1005 */     this._outputTail = NumberOutput.outputLong(l, this._outputBuffer, this._outputTail);
/*      */   }
/*      */ 
/*      */   
/*      */   private final void _writeQuotedLong(long l) throws IOException {
/* 1010 */     if (this._outputTail + 23 >= this._outputEnd) {
/* 1011 */       _flushBuffer();
/*      */     }
/* 1013 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/* 1014 */     this._outputTail = NumberOutput.outputLong(l, this._outputBuffer, this._outputTail);
/* 1015 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumber(BigInteger value) throws IOException {
/* 1021 */     _verifyValueWrite("write a number");
/* 1022 */     if (value == null) {
/* 1023 */       _writeNull();
/* 1024 */     } else if (this._cfgNumbersAsStrings) {
/* 1025 */       _writeQuotedRaw(value.toString());
/*      */     } else {
/* 1027 */       writeRaw(value.toString());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumber(double d) throws IOException {
/* 1035 */     if (this._cfgNumbersAsStrings || (
/* 1036 */       NumberOutput.notFinite(d) && JsonGenerator.Feature.QUOTE_NON_NUMERIC_NUMBERS
/* 1037 */       .enabledIn(this._features))) {
/* 1038 */       writeString(NumberOutput.toString(d, isEnabled(JsonGenerator.Feature.USE_FAST_DOUBLE_WRITER)));
/*      */       
/*      */       return;
/*      */     } 
/* 1042 */     _verifyValueWrite("write a number");
/* 1043 */     writeRaw(NumberOutput.toString(d, isEnabled(JsonGenerator.Feature.USE_FAST_DOUBLE_WRITER)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumber(float f) throws IOException {
/* 1050 */     if (this._cfgNumbersAsStrings || (
/* 1051 */       NumberOutput.notFinite(f) && JsonGenerator.Feature.QUOTE_NON_NUMERIC_NUMBERS
/* 1052 */       .enabledIn(this._features))) {
/* 1053 */       writeString(NumberOutput.toString(f, isEnabled(JsonGenerator.Feature.USE_FAST_DOUBLE_WRITER)));
/*      */       
/*      */       return;
/*      */     } 
/* 1057 */     _verifyValueWrite("write a number");
/* 1058 */     writeRaw(NumberOutput.toString(f, isEnabled(JsonGenerator.Feature.USE_FAST_DOUBLE_WRITER)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumber(BigDecimal value) throws IOException {
/* 1065 */     _verifyValueWrite("write a number");
/* 1066 */     if (value == null) {
/* 1067 */       _writeNull();
/* 1068 */     } else if (this._cfgNumbersAsStrings) {
/* 1069 */       _writeQuotedRaw(_asString(value));
/*      */     } else {
/* 1071 */       writeRaw(_asString(value));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumber(String encodedValue) throws IOException {
/* 1078 */     _verifyValueWrite("write a number");
/* 1079 */     if (encodedValue == null) {
/* 1080 */       _writeNull();
/* 1081 */     } else if (this._cfgNumbersAsStrings) {
/* 1082 */       _writeQuotedRaw(encodedValue);
/*      */     } else {
/* 1084 */       writeRaw(encodedValue);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void writeNumber(char[] encodedValueBuffer, int offset, int length) throws IOException {
/* 1090 */     _verifyValueWrite("write a number");
/* 1091 */     if (this._cfgNumbersAsStrings) {
/* 1092 */       _writeQuotedRaw(encodedValueBuffer, offset, length);
/*      */     } else {
/* 1094 */       writeRaw(encodedValueBuffer, offset, length);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private final void _writeQuotedRaw(String value) throws IOException {
/* 1100 */     if (this._outputTail >= this._outputEnd) {
/* 1101 */       _flushBuffer();
/*      */     }
/* 1103 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/* 1104 */     writeRaw(value);
/* 1105 */     if (this._outputTail >= this._outputEnd) {
/* 1106 */       _flushBuffer();
/*      */     }
/* 1108 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */   }
/*      */ 
/*      */   
/*      */   private void _writeQuotedRaw(char[] text, int offset, int length) throws IOException {
/* 1113 */     if (this._outputTail >= this._outputEnd) {
/* 1114 */       _flushBuffer();
/*      */     }
/* 1116 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/* 1117 */     writeRaw(text, offset, length);
/* 1118 */     if (this._outputTail >= this._outputEnd) {
/* 1119 */       _flushBuffer();
/*      */     }
/* 1121 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeBoolean(boolean state) throws IOException {
/* 1127 */     _verifyValueWrite("write a boolean value");
/* 1128 */     if (this._outputTail + 5 >= this._outputEnd) {
/* 1129 */       _flushBuffer();
/*      */     }
/* 1131 */     byte[] keyword = state ? TRUE_BYTES : FALSE_BYTES;
/* 1132 */     int len = keyword.length;
/* 1133 */     System.arraycopy(keyword, 0, this._outputBuffer, this._outputTail, len);
/* 1134 */     this._outputTail += len;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNull() throws IOException {
/* 1140 */     _verifyValueWrite("write a null");
/* 1141 */     _writeNull();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void _verifyValueWrite(String typeMsg) throws IOException {
/*      */     byte b;
/* 1153 */     int status = this._writeContext.writeValue();
/* 1154 */     if (this._cfgPrettyPrinter != null) {
/*      */       
/* 1156 */       _verifyPrettyValueWrite(typeMsg, status);
/*      */       
/*      */       return;
/*      */     } 
/* 1160 */     switch (status) {
/*      */       default:
/*      */         return;
/*      */       
/*      */       case 1:
/* 1165 */         b = 44;
/*      */         break;
/*      */       case 2:
/* 1168 */         b = 58;
/*      */         break;
/*      */       case 3:
/* 1171 */         if (this._rootValueSeparator != null) {
/* 1172 */           byte[] raw = this._rootValueSeparator.asUnquotedUTF8();
/* 1173 */           if (raw.length > 0) {
/* 1174 */             _writeBytes(raw);
/*      */           }
/*      */         } 
/*      */         return;
/*      */       case 5:
/* 1179 */         _reportCantWriteValueExpectName(typeMsg);
/*      */         return;
/*      */     } 
/* 1182 */     if (this._outputTail >= this._outputEnd) {
/* 1183 */       _flushBuffer();
/*      */     }
/* 1185 */     this._outputBuffer[this._outputTail++] = b;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void flush() throws IOException {
/* 1197 */     _flushBuffer();
/* 1198 */     if (this._outputStream != null && 
/* 1199 */       isEnabled(JsonGenerator.Feature.FLUSH_PASSED_TO_STREAM)) {
/* 1200 */       this._outputStream.flush();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void close() throws IOException {
/* 1208 */     super.close();
/*      */ 
/*      */ 
/*      */     
/* 1212 */     IOException flushFail = null;
/*      */     try {
/* 1214 */       if (this._outputBuffer != null && 
/* 1215 */         isEnabled(JsonGenerator.Feature.AUTO_CLOSE_JSON_CONTENT)) {
/*      */         while (true) {
/* 1217 */           JsonStreamContext ctxt = getOutputContext();
/* 1218 */           if (ctxt.inArray()) {
/* 1219 */             writeEndArray(); continue;
/* 1220 */           }  if (ctxt.inObject()) {
/* 1221 */             writeEndObject();
/*      */             continue;
/*      */           } 
/*      */           break;
/*      */         } 
/*      */       }
/* 1227 */       _flushBuffer();
/* 1228 */     } catch (IOException e) {
/*      */ 
/*      */       
/* 1231 */       flushFail = e;
/*      */     } 
/*      */     
/* 1234 */     this._outputTail = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1242 */     if (this._outputStream != null) {
/*      */       try {
/* 1244 */         if (this._ioContext.isResourceManaged() || isEnabled(JsonGenerator.Feature.AUTO_CLOSE_TARGET)) {
/* 1245 */           this._outputStream.close();
/* 1246 */         } else if (isEnabled(JsonGenerator.Feature.FLUSH_PASSED_TO_STREAM)) {
/*      */           
/* 1248 */           this._outputStream.flush();
/*      */         } 
/* 1250 */       } catch (IOException|RuntimeException e) {
/* 1251 */         if (flushFail != null) {
/* 1252 */           e.addSuppressed(flushFail);
/*      */         }
/* 1254 */         throw e;
/*      */       } 
/*      */     }
/*      */     
/* 1258 */     _releaseBuffers();
/*      */     
/* 1260 */     if (flushFail != null) {
/* 1261 */       throw flushFail;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _releaseBuffers() {
/* 1268 */     byte[] buf = this._outputBuffer;
/* 1269 */     if (buf != null && this._bufferRecyclable) {
/* 1270 */       this._outputBuffer = null;
/* 1271 */       this._ioContext.releaseWriteEncodingBuffer(buf);
/*      */     } 
/* 1273 */     char[] cbuf = this._charBuffer;
/* 1274 */     if (cbuf != null) {
/* 1275 */       this._charBuffer = null;
/* 1276 */       this._ioContext.releaseConcatBuffer(cbuf);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _writeBytes(byte[] bytes) throws IOException {
/* 1288 */     int len = bytes.length;
/* 1289 */     if (this._outputTail + len > this._outputEnd) {
/* 1290 */       _flushBuffer();
/*      */       
/* 1292 */       if (len > 512) {
/* 1293 */         this._outputStream.write(bytes, 0, len);
/*      */         return;
/*      */       } 
/*      */     } 
/* 1297 */     System.arraycopy(bytes, 0, this._outputBuffer, this._outputTail, len);
/* 1298 */     this._outputTail += len;
/*      */   }
/*      */ 
/*      */   
/*      */   private final void _writeBytes(byte[] bytes, int offset, int len) throws IOException {
/* 1303 */     if (this._outputTail + len > this._outputEnd) {
/* 1304 */       _flushBuffer();
/*      */       
/* 1306 */       if (len > 512) {
/* 1307 */         this._outputStream.write(bytes, offset, len);
/*      */         return;
/*      */       } 
/*      */     } 
/* 1311 */     System.arraycopy(bytes, offset, this._outputBuffer, this._outputTail, len);
/* 1312 */     this._outputTail += len;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _writeStringSegments(String text, boolean addQuotes) throws IOException {
/* 1330 */     if (addQuotes) {
/* 1331 */       if (this._outputTail >= this._outputEnd) {
/* 1332 */         _flushBuffer();
/*      */       }
/* 1334 */       this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */     } 
/*      */     
/* 1337 */     int left = text.length();
/* 1338 */     int offset = 0;
/*      */     
/* 1340 */     while (left > 0) {
/* 1341 */       int len = Math.min(this._outputMaxContiguous, left);
/* 1342 */       if (this._outputTail + len > this._outputEnd) {
/* 1343 */         _flushBuffer();
/*      */       }
/* 1345 */       _writeStringSegment(text, offset, len);
/* 1346 */       offset += len;
/* 1347 */       left -= len;
/*      */     } 
/*      */     
/* 1350 */     if (addQuotes) {
/* 1351 */       if (this._outputTail >= this._outputEnd) {
/* 1352 */         _flushBuffer();
/*      */       }
/* 1354 */       this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _writeStringSegments(char[] cbuf, int offset, int totalLen) throws IOException {
/*      */     do {
/* 1367 */       int len = Math.min(this._outputMaxContiguous, totalLen);
/* 1368 */       if (this._outputTail + len > this._outputEnd) {
/* 1369 */         _flushBuffer();
/*      */       }
/* 1371 */       _writeStringSegment(cbuf, offset, len);
/* 1372 */       offset += len;
/* 1373 */       totalLen -= len;
/* 1374 */     } while (totalLen > 0);
/*      */   }
/*      */ 
/*      */   
/*      */   private final void _writeStringSegments(String text, int offset, int totalLen) throws IOException {
/*      */     do {
/* 1380 */       int len = Math.min(this._outputMaxContiguous, totalLen);
/* 1381 */       if (this._outputTail + len > this._outputEnd) {
/* 1382 */         _flushBuffer();
/*      */       }
/* 1384 */       _writeStringSegment(text, offset, len);
/* 1385 */       offset += len;
/* 1386 */       totalLen -= len;
/* 1387 */     } while (totalLen > 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _writeStringSegment(char[] cbuf, int offset, int len) throws IOException {
/* 1410 */     len += offset;
/*      */     
/* 1412 */     int outputPtr = this._outputTail;
/* 1413 */     byte[] outputBuffer = this._outputBuffer;
/* 1414 */     int[] escCodes = this._outputEscapes;
/*      */     
/* 1416 */     while (offset < len) {
/* 1417 */       int ch = cbuf[offset];
/*      */       
/* 1419 */       if (ch > 127 || escCodes[ch] != 0) {
/*      */         break;
/*      */       }
/* 1422 */       outputBuffer[outputPtr++] = (byte)ch;
/* 1423 */       offset++;
/*      */     } 
/* 1425 */     this._outputTail = outputPtr;
/* 1426 */     if (offset < len) {
/* 1427 */       if (this._characterEscapes != null) {
/* 1428 */         _writeCustomStringSegment2(cbuf, offset, len);
/* 1429 */       } else if (this._maximumNonEscapedChar == 0) {
/* 1430 */         _writeStringSegment2(cbuf, offset, len);
/*      */       } else {
/* 1432 */         _writeStringSegmentASCII2(cbuf, offset, len);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _writeStringSegment(String text, int offset, int len) throws IOException {
/* 1442 */     len += offset;
/*      */     
/* 1444 */     int outputPtr = this._outputTail;
/* 1445 */     byte[] outputBuffer = this._outputBuffer;
/* 1446 */     int[] escCodes = this._outputEscapes;
/*      */     
/* 1448 */     while (offset < len) {
/* 1449 */       int ch = text.charAt(offset);
/*      */       
/* 1451 */       if (ch > 127 || escCodes[ch] != 0) {
/*      */         break;
/*      */       }
/* 1454 */       outputBuffer[outputPtr++] = (byte)ch;
/* 1455 */       offset++;
/*      */     } 
/* 1457 */     this._outputTail = outputPtr;
/* 1458 */     if (offset < len) {
/* 1459 */       if (this._characterEscapes != null) {
/* 1460 */         _writeCustomStringSegment2(text, offset, len);
/* 1461 */       } else if (this._maximumNonEscapedChar == 0) {
/* 1462 */         _writeStringSegment2(text, offset, len);
/*      */       } else {
/* 1464 */         _writeStringSegmentASCII2(text, offset, len);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _writeStringSegment2(char[] cbuf, int offset, int end) throws IOException {
/* 1476 */     if (this._outputTail + 6 * (end - offset) > this._outputEnd) {
/* 1477 */       _flushBuffer();
/*      */     }
/*      */     
/* 1480 */     int outputPtr = this._outputTail;
/*      */     
/* 1482 */     byte[] outputBuffer = this._outputBuffer;
/* 1483 */     int[] escCodes = this._outputEscapes;
/*      */     
/* 1485 */     while (offset < end) {
/* 1486 */       int ch = cbuf[offset++];
/* 1487 */       if (ch <= 127) {
/* 1488 */         if (escCodes[ch] == 0) {
/* 1489 */           outputBuffer[outputPtr++] = (byte)ch;
/*      */           continue;
/*      */         } 
/* 1492 */         int escape = escCodes[ch];
/* 1493 */         if (escape > 0) {
/* 1494 */           outputBuffer[outputPtr++] = 92;
/* 1495 */           outputBuffer[outputPtr++] = (byte)escape;
/*      */           continue;
/*      */         } 
/* 1498 */         outputPtr = _writeGenericEscape(ch, outputPtr);
/*      */         
/*      */         continue;
/*      */       } 
/* 1502 */       if (ch <= 2047) {
/* 1503 */         outputBuffer[outputPtr++] = (byte)(0xC0 | ch >> 6);
/* 1504 */         outputBuffer[outputPtr++] = (byte)(0x80 | ch & 0x3F); continue;
/*      */       } 
/* 1506 */       outputPtr = _outputMultiByteChar(ch, outputPtr);
/*      */     } 
/*      */     
/* 1509 */     this._outputTail = outputPtr;
/*      */   }
/*      */ 
/*      */   
/*      */   private final void _writeStringSegment2(String text, int offset, int end) throws IOException {
/* 1514 */     if (this._outputTail + 6 * (end - offset) > this._outputEnd) {
/* 1515 */       _flushBuffer();
/*      */     }
/*      */     
/* 1518 */     int outputPtr = this._outputTail;
/*      */     
/* 1520 */     byte[] outputBuffer = this._outputBuffer;
/* 1521 */     int[] escCodes = this._outputEscapes;
/*      */     
/* 1523 */     while (offset < end) {
/* 1524 */       int ch = text.charAt(offset++);
/* 1525 */       if (ch <= 127) {
/* 1526 */         if (escCodes[ch] == 0) {
/* 1527 */           outputBuffer[outputPtr++] = (byte)ch;
/*      */           continue;
/*      */         } 
/* 1530 */         int escape = escCodes[ch];
/* 1531 */         if (escape > 0) {
/* 1532 */           outputBuffer[outputPtr++] = 92;
/* 1533 */           outputBuffer[outputPtr++] = (byte)escape;
/*      */           continue;
/*      */         } 
/* 1536 */         outputPtr = _writeGenericEscape(ch, outputPtr);
/*      */         
/*      */         continue;
/*      */       } 
/* 1540 */       if (ch <= 2047) {
/* 1541 */         outputBuffer[outputPtr++] = (byte)(0xC0 | ch >> 6);
/* 1542 */         outputBuffer[outputPtr++] = (byte)(0x80 | ch & 0x3F); continue;
/*      */       } 
/* 1544 */       outputPtr = _outputMultiByteChar(ch, outputPtr);
/*      */     } 
/*      */     
/* 1547 */     this._outputTail = outputPtr;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _writeStringSegmentASCII2(char[] cbuf, int offset, int end) throws IOException {
/* 1564 */     if (this._outputTail + 6 * (end - offset) > this._outputEnd) {
/* 1565 */       _flushBuffer();
/*      */     }
/* 1567 */     int outputPtr = this._outputTail;
/*      */     
/* 1569 */     byte[] outputBuffer = this._outputBuffer;
/* 1570 */     int[] escCodes = this._outputEscapes;
/* 1571 */     int maxUnescaped = this._maximumNonEscapedChar;
/*      */     
/* 1573 */     while (offset < end) {
/* 1574 */       int ch = cbuf[offset++];
/* 1575 */       if (ch <= 127) {
/* 1576 */         if (escCodes[ch] == 0) {
/* 1577 */           outputBuffer[outputPtr++] = (byte)ch;
/*      */           continue;
/*      */         } 
/* 1580 */         int escape = escCodes[ch];
/* 1581 */         if (escape > 0) {
/* 1582 */           outputBuffer[outputPtr++] = 92;
/* 1583 */           outputBuffer[outputPtr++] = (byte)escape;
/*      */           continue;
/*      */         } 
/* 1586 */         outputPtr = _writeGenericEscape(ch, outputPtr);
/*      */         
/*      */         continue;
/*      */       } 
/* 1590 */       if (ch > maxUnescaped) {
/* 1591 */         outputPtr = _writeGenericEscape(ch, outputPtr);
/*      */         continue;
/*      */       } 
/* 1594 */       if (ch <= 2047) {
/* 1595 */         outputBuffer[outputPtr++] = (byte)(0xC0 | ch >> 6);
/* 1596 */         outputBuffer[outputPtr++] = (byte)(0x80 | ch & 0x3F); continue;
/*      */       } 
/* 1598 */       outputPtr = _outputMultiByteChar(ch, outputPtr);
/*      */     } 
/*      */     
/* 1601 */     this._outputTail = outputPtr;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _writeStringSegmentASCII2(String text, int offset, int end) throws IOException {
/* 1607 */     if (this._outputTail + 6 * (end - offset) > this._outputEnd) {
/* 1608 */       _flushBuffer();
/*      */     }
/*      */     
/* 1611 */     int outputPtr = this._outputTail;
/*      */     
/* 1613 */     byte[] outputBuffer = this._outputBuffer;
/* 1614 */     int[] escCodes = this._outputEscapes;
/* 1615 */     int maxUnescaped = this._maximumNonEscapedChar;
/*      */     
/* 1617 */     while (offset < end) {
/* 1618 */       int ch = text.charAt(offset++);
/* 1619 */       if (ch <= 127) {
/* 1620 */         if (escCodes[ch] == 0) {
/* 1621 */           outputBuffer[outputPtr++] = (byte)ch;
/*      */           continue;
/*      */         } 
/* 1624 */         int escape = escCodes[ch];
/* 1625 */         if (escape > 0) {
/* 1626 */           outputBuffer[outputPtr++] = 92;
/* 1627 */           outputBuffer[outputPtr++] = (byte)escape;
/*      */           continue;
/*      */         } 
/* 1630 */         outputPtr = _writeGenericEscape(ch, outputPtr);
/*      */         
/*      */         continue;
/*      */       } 
/* 1634 */       if (ch > maxUnescaped) {
/* 1635 */         outputPtr = _writeGenericEscape(ch, outputPtr);
/*      */         continue;
/*      */       } 
/* 1638 */       if (ch <= 2047) {
/* 1639 */         outputBuffer[outputPtr++] = (byte)(0xC0 | ch >> 6);
/* 1640 */         outputBuffer[outputPtr++] = (byte)(0x80 | ch & 0x3F); continue;
/*      */       } 
/* 1642 */       outputPtr = _outputMultiByteChar(ch, outputPtr);
/*      */     } 
/*      */     
/* 1645 */     this._outputTail = outputPtr;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _writeCustomStringSegment2(char[] cbuf, int offset, int end) throws IOException {
/* 1662 */     if (this._outputTail + 6 * (end - offset) > this._outputEnd) {
/* 1663 */       _flushBuffer();
/*      */     }
/* 1665 */     int outputPtr = this._outputTail;
/*      */     
/* 1667 */     byte[] outputBuffer = this._outputBuffer;
/* 1668 */     int[] escCodes = this._outputEscapes;
/*      */     
/* 1670 */     int maxUnescaped = (this._maximumNonEscapedChar <= 0) ? 65535 : this._maximumNonEscapedChar;
/* 1671 */     CharacterEscapes customEscapes = this._characterEscapes;
/*      */     
/* 1673 */     while (offset < end) {
/* 1674 */       int ch = cbuf[offset++];
/* 1675 */       if (ch <= 127) {
/* 1676 */         if (escCodes[ch] == 0) {
/* 1677 */           outputBuffer[outputPtr++] = (byte)ch;
/*      */           continue;
/*      */         } 
/* 1680 */         int escape = escCodes[ch];
/* 1681 */         if (escape > 0) {
/* 1682 */           outputBuffer[outputPtr++] = 92;
/* 1683 */           outputBuffer[outputPtr++] = (byte)escape; continue;
/* 1684 */         }  if (escape == -2) {
/* 1685 */           SerializableString serializableString = customEscapes.getEscapeSequence(ch);
/* 1686 */           if (serializableString == null) {
/* 1687 */             _reportError("Invalid custom escape definitions; custom escape not found for character code 0x" + 
/* 1688 */                 Integer.toHexString(ch) + ", although was supposed to have one");
/*      */           }
/* 1690 */           outputPtr = _writeCustomEscape(outputBuffer, outputPtr, serializableString, end - offset);
/*      */           continue;
/*      */         } 
/* 1693 */         outputPtr = _writeGenericEscape(ch, outputPtr);
/*      */         
/*      */         continue;
/*      */       } 
/* 1697 */       if (ch > maxUnescaped) {
/* 1698 */         outputPtr = _writeGenericEscape(ch, outputPtr);
/*      */         continue;
/*      */       } 
/* 1701 */       SerializableString esc = customEscapes.getEscapeSequence(ch);
/* 1702 */       if (esc != null) {
/* 1703 */         outputPtr = _writeCustomEscape(outputBuffer, outputPtr, esc, end - offset);
/*      */         continue;
/*      */       } 
/* 1706 */       if (ch <= 2047) {
/* 1707 */         outputBuffer[outputPtr++] = (byte)(0xC0 | ch >> 6);
/* 1708 */         outputBuffer[outputPtr++] = (byte)(0x80 | ch & 0x3F); continue;
/*      */       } 
/* 1710 */       outputPtr = _outputMultiByteChar(ch, outputPtr);
/*      */     } 
/*      */     
/* 1713 */     this._outputTail = outputPtr;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _writeCustomStringSegment2(String text, int offset, int end) throws IOException {
/* 1719 */     if (this._outputTail + 6 * (end - offset) > this._outputEnd) {
/* 1720 */       _flushBuffer();
/*      */     }
/* 1722 */     int outputPtr = this._outputTail;
/*      */     
/* 1724 */     byte[] outputBuffer = this._outputBuffer;
/* 1725 */     int[] escCodes = this._outputEscapes;
/*      */     
/* 1727 */     int maxUnescaped = (this._maximumNonEscapedChar <= 0) ? 65535 : this._maximumNonEscapedChar;
/* 1728 */     CharacterEscapes customEscapes = this._characterEscapes;
/*      */     
/* 1730 */     while (offset < end) {
/* 1731 */       int ch = text.charAt(offset++);
/* 1732 */       if (ch <= 127) {
/* 1733 */         if (escCodes[ch] == 0) {
/* 1734 */           outputBuffer[outputPtr++] = (byte)ch;
/*      */           continue;
/*      */         } 
/* 1737 */         int escape = escCodes[ch];
/* 1738 */         if (escape > 0) {
/* 1739 */           outputBuffer[outputPtr++] = 92;
/* 1740 */           outputBuffer[outputPtr++] = (byte)escape; continue;
/* 1741 */         }  if (escape == -2) {
/* 1742 */           SerializableString serializableString = customEscapes.getEscapeSequence(ch);
/* 1743 */           if (serializableString == null) {
/* 1744 */             _reportError("Invalid custom escape definitions; custom escape not found for character code 0x" + 
/* 1745 */                 Integer.toHexString(ch) + ", although was supposed to have one");
/*      */           }
/* 1747 */           outputPtr = _writeCustomEscape(outputBuffer, outputPtr, serializableString, end - offset);
/*      */           continue;
/*      */         } 
/* 1750 */         outputPtr = _writeGenericEscape(ch, outputPtr);
/*      */         
/*      */         continue;
/*      */       } 
/* 1754 */       if (ch > maxUnescaped) {
/* 1755 */         outputPtr = _writeGenericEscape(ch, outputPtr);
/*      */         continue;
/*      */       } 
/* 1758 */       SerializableString esc = customEscapes.getEscapeSequence(ch);
/* 1759 */       if (esc != null) {
/* 1760 */         outputPtr = _writeCustomEscape(outputBuffer, outputPtr, esc, end - offset);
/*      */         continue;
/*      */       } 
/* 1763 */       if (ch <= 2047) {
/* 1764 */         outputBuffer[outputPtr++] = (byte)(0xC0 | ch >> 6);
/* 1765 */         outputBuffer[outputPtr++] = (byte)(0x80 | ch & 0x3F); continue;
/*      */       } 
/* 1767 */       outputPtr = _outputMultiByteChar(ch, outputPtr);
/*      */     } 
/*      */     
/* 1770 */     this._outputTail = outputPtr;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _writeCustomEscape(byte[] outputBuffer, int outputPtr, SerializableString esc, int remainingChars) throws IOException, JsonGenerationException {
/* 1776 */     byte[] raw = esc.asUnquotedUTF8();
/* 1777 */     int len = raw.length;
/* 1778 */     if (len > 6) {
/* 1779 */       return _handleLongCustomEscape(outputBuffer, outputPtr, this._outputEnd, raw, remainingChars);
/*      */     }
/*      */     
/* 1782 */     System.arraycopy(raw, 0, outputBuffer, outputPtr, len);
/* 1783 */     return outputPtr + len;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _handleLongCustomEscape(byte[] outputBuffer, int outputPtr, int outputEnd, byte[] raw, int remainingChars) throws IOException, JsonGenerationException {
/* 1790 */     int len = raw.length;
/* 1791 */     if (outputPtr + len > outputEnd) {
/* 1792 */       this._outputTail = outputPtr;
/* 1793 */       _flushBuffer();
/* 1794 */       outputPtr = this._outputTail;
/* 1795 */       if (len > outputBuffer.length) {
/* 1796 */         this._outputStream.write(raw, 0, len);
/* 1797 */         return outputPtr;
/*      */       } 
/*      */     } 
/* 1800 */     System.arraycopy(raw, 0, outputBuffer, outputPtr, len);
/* 1801 */     outputPtr += len;
/*      */     
/* 1803 */     if (outputPtr + 6 * remainingChars > outputEnd) {
/* 1804 */       this._outputTail = outputPtr;
/* 1805 */       _flushBuffer();
/* 1806 */       return this._outputTail;
/*      */     } 
/* 1808 */     return outputPtr;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _writeUTF8Segments(byte[] utf8, int offset, int totalLen) throws IOException, JsonGenerationException {
/*      */     do {
/* 1826 */       int len = Math.min(this._outputMaxContiguous, totalLen);
/* 1827 */       _writeUTF8Segment(utf8, offset, len);
/* 1828 */       offset += len;
/* 1829 */       totalLen -= len;
/* 1830 */     } while (totalLen > 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _writeUTF8Segment(byte[] utf8, int offset, int len) throws IOException, JsonGenerationException {
/* 1837 */     int[] escCodes = this._outputEscapes;
/*      */     
/* 1839 */     for (int ptr = offset, end = offset + len; ptr < end; ) {
/*      */       
/* 1841 */       int ch = utf8[ptr++];
/* 1842 */       if (ch >= 0 && escCodes[ch] != 0) {
/* 1843 */         _writeUTF8Segment2(utf8, offset, len);
/*      */         
/*      */         return;
/*      */       } 
/*      */     } 
/*      */     
/* 1849 */     if (this._outputTail + len > this._outputEnd) {
/* 1850 */       _flushBuffer();
/*      */     }
/* 1852 */     System.arraycopy(utf8, offset, this._outputBuffer, this._outputTail, len);
/* 1853 */     this._outputTail += len;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _writeUTF8Segment2(byte[] utf8, int offset, int len) throws IOException, JsonGenerationException {
/* 1859 */     int outputPtr = this._outputTail;
/*      */ 
/*      */     
/* 1862 */     if (outputPtr + len * 6 > this._outputEnd) {
/* 1863 */       _flushBuffer();
/* 1864 */       outputPtr = this._outputTail;
/*      */     } 
/*      */     
/* 1867 */     byte[] outputBuffer = this._outputBuffer;
/* 1868 */     int[] escCodes = this._outputEscapes;
/* 1869 */     len += offset;
/*      */     
/* 1871 */     while (offset < len) {
/* 1872 */       byte b = utf8[offset++];
/* 1873 */       int ch = b;
/* 1874 */       if (ch < 0 || escCodes[ch] == 0) {
/* 1875 */         outputBuffer[outputPtr++] = b;
/*      */         continue;
/*      */       } 
/* 1878 */       int escape = escCodes[ch];
/* 1879 */       if (escape > 0) {
/* 1880 */         outputBuffer[outputPtr++] = 92;
/* 1881 */         outputBuffer[outputPtr++] = (byte)escape;
/*      */         continue;
/*      */       } 
/* 1884 */       outputPtr = _writeGenericEscape(ch, outputPtr);
/*      */     } 
/*      */     
/* 1887 */     this._outputTail = outputPtr;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void _writeBinary(Base64Variant b64variant, byte[] input, int inputPtr, int inputEnd) throws IOException, JsonGenerationException {
/* 1901 */     int safeInputEnd = inputEnd - 3;
/*      */     
/* 1903 */     int safeOutputEnd = this._outputEnd - 6;
/* 1904 */     int chunksBeforeLF = b64variant.getMaxLineLength() >> 2;
/*      */ 
/*      */     
/* 1907 */     while (inputPtr <= safeInputEnd) {
/* 1908 */       if (this._outputTail > safeOutputEnd) {
/* 1909 */         _flushBuffer();
/*      */       }
/*      */       
/* 1912 */       int b24 = input[inputPtr++] << 8;
/* 1913 */       b24 |= input[inputPtr++] & 0xFF;
/* 1914 */       b24 = b24 << 8 | input[inputPtr++] & 0xFF;
/* 1915 */       this._outputTail = b64variant.encodeBase64Chunk(b24, this._outputBuffer, this._outputTail);
/* 1916 */       if (--chunksBeforeLF <= 0) {
/*      */         
/* 1918 */         this._outputBuffer[this._outputTail++] = 92;
/* 1919 */         this._outputBuffer[this._outputTail++] = 110;
/* 1920 */         chunksBeforeLF = b64variant.getMaxLineLength() >> 2;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1925 */     int inputLeft = inputEnd - inputPtr;
/* 1926 */     if (inputLeft > 0) {
/* 1927 */       if (this._outputTail > safeOutputEnd) {
/* 1928 */         _flushBuffer();
/*      */       }
/* 1930 */       int b24 = input[inputPtr++] << 16;
/* 1931 */       if (inputLeft == 2) {
/* 1932 */         b24 |= (input[inputPtr++] & 0xFF) << 8;
/*      */       }
/* 1934 */       this._outputTail = b64variant.encodeBase64Partial(b24, inputLeft, this._outputBuffer, this._outputTail);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final int _writeBinary(Base64Variant b64variant, InputStream data, byte[] readBuffer, int bytesLeft) throws IOException, JsonGenerationException {
/* 1943 */     int inputPtr = 0;
/* 1944 */     int inputEnd = 0;
/* 1945 */     int lastFullOffset = -3;
/*      */ 
/*      */     
/* 1948 */     int safeOutputEnd = this._outputEnd - 6;
/* 1949 */     int chunksBeforeLF = b64variant.getMaxLineLength() >> 2;
/*      */     
/* 1951 */     while (bytesLeft > 2) {
/* 1952 */       if (inputPtr > lastFullOffset) {
/* 1953 */         inputEnd = _readMore(data, readBuffer, inputPtr, inputEnd, bytesLeft);
/* 1954 */         inputPtr = 0;
/* 1955 */         if (inputEnd < 3) {
/*      */           break;
/*      */         }
/* 1958 */         lastFullOffset = inputEnd - 3;
/*      */       } 
/* 1960 */       if (this._outputTail > safeOutputEnd) {
/* 1961 */         _flushBuffer();
/*      */       }
/* 1963 */       int b24 = readBuffer[inputPtr++] << 8;
/* 1964 */       b24 |= readBuffer[inputPtr++] & 0xFF;
/* 1965 */       b24 = b24 << 8 | readBuffer[inputPtr++] & 0xFF;
/* 1966 */       bytesLeft -= 3;
/* 1967 */       this._outputTail = b64variant.encodeBase64Chunk(b24, this._outputBuffer, this._outputTail);
/* 1968 */       if (--chunksBeforeLF <= 0) {
/* 1969 */         this._outputBuffer[this._outputTail++] = 92;
/* 1970 */         this._outputBuffer[this._outputTail++] = 110;
/* 1971 */         chunksBeforeLF = b64variant.getMaxLineLength() >> 2;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1976 */     if (bytesLeft > 0) {
/* 1977 */       inputEnd = _readMore(data, readBuffer, inputPtr, inputEnd, bytesLeft);
/* 1978 */       inputPtr = 0;
/* 1979 */       if (inputEnd > 0) {
/* 1980 */         int amount; if (this._outputTail > safeOutputEnd) {
/* 1981 */           _flushBuffer();
/*      */         }
/* 1983 */         int b24 = readBuffer[inputPtr++] << 16;
/*      */         
/* 1985 */         if (inputPtr < inputEnd) {
/* 1986 */           b24 |= (readBuffer[inputPtr] & 0xFF) << 8;
/* 1987 */           amount = 2;
/*      */         } else {
/* 1989 */           amount = 1;
/*      */         } 
/* 1991 */         this._outputTail = b64variant.encodeBase64Partial(b24, amount, this._outputBuffer, this._outputTail);
/* 1992 */         bytesLeft -= amount;
/*      */       } 
/*      */     } 
/* 1995 */     return bytesLeft;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final int _writeBinary(Base64Variant b64variant, InputStream data, byte[] readBuffer) throws IOException, JsonGenerationException {
/* 2003 */     int inputPtr = 0;
/* 2004 */     int inputEnd = 0;
/* 2005 */     int lastFullOffset = -3;
/* 2006 */     int bytesDone = 0;
/*      */ 
/*      */     
/* 2009 */     int safeOutputEnd = this._outputEnd - 6;
/* 2010 */     int chunksBeforeLF = b64variant.getMaxLineLength() >> 2;
/*      */ 
/*      */     
/*      */     while (true) {
/* 2014 */       if (inputPtr > lastFullOffset) {
/* 2015 */         inputEnd = _readMore(data, readBuffer, inputPtr, inputEnd, readBuffer.length);
/* 2016 */         inputPtr = 0;
/* 2017 */         if (inputEnd < 3) {
/*      */           break;
/*      */         }
/* 2020 */         lastFullOffset = inputEnd - 3;
/*      */       } 
/* 2022 */       if (this._outputTail > safeOutputEnd) {
/* 2023 */         _flushBuffer();
/*      */       }
/*      */       
/* 2026 */       int b24 = readBuffer[inputPtr++] << 8;
/* 2027 */       b24 |= readBuffer[inputPtr++] & 0xFF;
/* 2028 */       b24 = b24 << 8 | readBuffer[inputPtr++] & 0xFF;
/* 2029 */       bytesDone += 3;
/* 2030 */       this._outputTail = b64variant.encodeBase64Chunk(b24, this._outputBuffer, this._outputTail);
/* 2031 */       if (--chunksBeforeLF <= 0) {
/* 2032 */         this._outputBuffer[this._outputTail++] = 92;
/* 2033 */         this._outputBuffer[this._outputTail++] = 110;
/* 2034 */         chunksBeforeLF = b64variant.getMaxLineLength() >> 2;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 2039 */     if (inputPtr < inputEnd) {
/* 2040 */       if (this._outputTail > safeOutputEnd) {
/* 2041 */         _flushBuffer();
/*      */       }
/* 2043 */       int b24 = readBuffer[inputPtr++] << 16;
/* 2044 */       int amount = 1;
/* 2045 */       if (inputPtr < inputEnd) {
/* 2046 */         b24 |= (readBuffer[inputPtr] & 0xFF) << 8;
/* 2047 */         amount = 2;
/*      */       } 
/* 2049 */       bytesDone += amount;
/* 2050 */       this._outputTail = b64variant.encodeBase64Partial(b24, amount, this._outputBuffer, this._outputTail);
/*      */     } 
/* 2052 */     return bytesDone;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _readMore(InputStream in, byte[] readBuffer, int inputPtr, int inputEnd, int maxRead) throws IOException {
/* 2060 */     int i = 0;
/* 2061 */     while (inputPtr < inputEnd) {
/* 2062 */       readBuffer[i++] = readBuffer[inputPtr++];
/*      */     }
/* 2064 */     inputPtr = 0;
/* 2065 */     inputEnd = i;
/* 2066 */     maxRead = Math.min(maxRead, readBuffer.length);
/*      */     
/*      */     do {
/* 2069 */       int length = maxRead - inputEnd;
/* 2070 */       if (length == 0) {
/*      */         break;
/*      */       }
/* 2073 */       int count = in.read(readBuffer, inputEnd, length);
/* 2074 */       if (count < 0) {
/* 2075 */         return inputEnd;
/*      */       }
/* 2077 */       inputEnd += count;
/* 2078 */     } while (inputEnd < 3);
/* 2079 */     return inputEnd;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _outputRawMultiByteChar(int ch, char[] cbuf, int inputOffset, int inputEnd) throws IOException {
/* 2097 */     if (ch >= 55296 && 
/* 2098 */       ch <= 57343) {
/*      */       
/* 2100 */       if (inputOffset >= inputEnd || cbuf == null) {
/* 2101 */         _reportError(String.format("Split surrogate on writeRaw() input (last character): first character 0x%4x", new Object[] {
/* 2102 */                 Integer.valueOf(ch) }));
/*      */       } else {
/* 2104 */         _outputSurrogates(ch, cbuf[inputOffset]);
/*      */       } 
/* 2106 */       return inputOffset + 1;
/*      */     } 
/*      */     
/* 2109 */     byte[] bbuf = this._outputBuffer;
/* 2110 */     bbuf[this._outputTail++] = (byte)(0xE0 | ch >> 12);
/* 2111 */     bbuf[this._outputTail++] = (byte)(0x80 | ch >> 6 & 0x3F);
/* 2112 */     bbuf[this._outputTail++] = (byte)(0x80 | ch & 0x3F);
/* 2113 */     return inputOffset;
/*      */   }
/*      */ 
/*      */   
/*      */   protected final void _outputSurrogates(int surr1, int surr2) throws IOException {
/* 2118 */     int c = _decodeSurrogate(surr1, surr2);
/* 2119 */     if (this._outputTail + 4 > this._outputEnd) {
/* 2120 */       _flushBuffer();
/*      */     }
/* 2122 */     byte[] bbuf = this._outputBuffer;
/* 2123 */     bbuf[this._outputTail++] = (byte)(0xF0 | c >> 18);
/* 2124 */     bbuf[this._outputTail++] = (byte)(0x80 | c >> 12 & 0x3F);
/* 2125 */     bbuf[this._outputTail++] = (byte)(0x80 | c >> 6 & 0x3F);
/* 2126 */     bbuf[this._outputTail++] = (byte)(0x80 | c & 0x3F);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _outputMultiByteChar(int ch, int outputPtr) throws IOException {
/* 2140 */     byte[] HEX_CHARS = getHexBytes();
/* 2141 */     byte[] bbuf = this._outputBuffer;
/* 2142 */     if (ch >= 55296 && ch <= 57343) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2147 */       bbuf[outputPtr++] = 92;
/* 2148 */       bbuf[outputPtr++] = 117;
/*      */       
/* 2150 */       bbuf[outputPtr++] = HEX_CHARS[ch >> 12 & 0xF];
/* 2151 */       bbuf[outputPtr++] = HEX_CHARS[ch >> 8 & 0xF];
/* 2152 */       bbuf[outputPtr++] = HEX_CHARS[ch >> 4 & 0xF];
/* 2153 */       bbuf[outputPtr++] = HEX_CHARS[ch & 0xF];
/*      */     } else {
/*      */       
/* 2156 */       bbuf[outputPtr++] = (byte)(0xE0 | ch >> 12);
/* 2157 */       bbuf[outputPtr++] = (byte)(0x80 | ch >> 6 & 0x3F);
/* 2158 */       bbuf[outputPtr++] = (byte)(0x80 | ch & 0x3F);
/*      */     } 
/* 2160 */     return outputPtr;
/*      */   }
/*      */ 
/*      */   
/*      */   private final void _writeNull() throws IOException {
/* 2165 */     if (this._outputTail + 4 >= this._outputEnd) {
/* 2166 */       _flushBuffer();
/*      */     }
/* 2168 */     System.arraycopy(NULL_BYTES, 0, this._outputBuffer, this._outputTail, 4);
/* 2169 */     this._outputTail += 4;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int _writeGenericEscape(int charToEscape, int outputPtr) throws IOException {
/* 2179 */     byte[] bbuf = this._outputBuffer;
/* 2180 */     byte[] HEX_CHARS = getHexBytes();
/* 2181 */     bbuf[outputPtr++] = 92;
/* 2182 */     bbuf[outputPtr++] = 117;
/* 2183 */     if (charToEscape > 255) {
/* 2184 */       int hi = charToEscape >> 8 & 0xFF;
/* 2185 */       bbuf[outputPtr++] = HEX_CHARS[hi >> 4];
/* 2186 */       bbuf[outputPtr++] = HEX_CHARS[hi & 0xF];
/* 2187 */       charToEscape &= 0xFF;
/*      */     } else {
/* 2189 */       bbuf[outputPtr++] = 48;
/* 2190 */       bbuf[outputPtr++] = 48;
/*      */     } 
/*      */     
/* 2193 */     bbuf[outputPtr++] = HEX_CHARS[charToEscape >> 4];
/* 2194 */     bbuf[outputPtr++] = HEX_CHARS[charToEscape & 0xF];
/* 2195 */     return outputPtr;
/*      */   }
/*      */ 
/*      */   
/*      */   protected final void _flushBuffer() throws IOException {
/* 2200 */     int len = this._outputTail;
/* 2201 */     if (len > 0) {
/* 2202 */       this._outputTail = 0;
/* 2203 */       this._outputStream.write(this._outputBuffer, 0, len);
/*      */     } 
/*      */   }
/*      */   
/*      */   private byte[] getHexBytes() {
/* 2208 */     return this._cfgWriteHexUppercase ? HEX_BYTES_UPPER : HEX_BYTES_LOWER;
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-core-2.14.2.jar!\com\fasterxml\jackson\core\json\UTF8JsonGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */