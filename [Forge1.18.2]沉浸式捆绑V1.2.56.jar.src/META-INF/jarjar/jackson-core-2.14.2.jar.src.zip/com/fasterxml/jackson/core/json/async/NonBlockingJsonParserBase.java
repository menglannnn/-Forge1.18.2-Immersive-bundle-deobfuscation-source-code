/*     */ package com.fasterxml.jackson.core.json.async;
/*     */ 
/*     */ import com.fasterxml.jackson.core.Base64Variant;
/*     */ import com.fasterxml.jackson.core.JsonLocation;
/*     */ import com.fasterxml.jackson.core.JsonParseException;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.core.ObjectCodec;
/*     */ import com.fasterxml.jackson.core.StreamReadCapability;
/*     */ import com.fasterxml.jackson.core.base.ParserBase;
/*     */ import com.fasterxml.jackson.core.io.IOContext;
/*     */ import com.fasterxml.jackson.core.json.JsonReadContext;
/*     */ import com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer;
/*     */ import com.fasterxml.jackson.core.util.ByteArrayBuilder;
/*     */ import com.fasterxml.jackson.core.util.JacksonFeatureSet;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.Writer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class NonBlockingJsonParserBase
/*     */   extends ParserBase
/*     */ {
/*     */   protected static final int MAJOR_INITIAL = 0;
/*     */   protected static final int MAJOR_ROOT = 1;
/*     */   protected static final int MAJOR_OBJECT_FIELD_FIRST = 2;
/*     */   protected static final int MAJOR_OBJECT_FIELD_NEXT = 3;
/*     */   protected static final int MAJOR_OBJECT_VALUE = 4;
/*     */   protected static final int MAJOR_ARRAY_ELEMENT_FIRST = 5;
/*     */   protected static final int MAJOR_ARRAY_ELEMENT_NEXT = 6;
/*     */   protected static final int MAJOR_CLOSED = 7;
/*     */   protected static final int MINOR_ROOT_BOM = 1;
/*     */   protected static final int MINOR_ROOT_NEED_SEPARATOR = 2;
/*     */   protected static final int MINOR_ROOT_GOT_SEPARATOR = 3;
/*     */   protected static final int MINOR_FIELD_LEADING_WS = 4;
/*     */   protected static final int MINOR_FIELD_LEADING_COMMA = 5;
/*     */   protected static final int MINOR_FIELD_NAME = 7;
/*     */   protected static final int MINOR_FIELD_NAME_ESCAPE = 8;
/*     */   protected static final int MINOR_FIELD_APOS_NAME = 9;
/*     */   protected static final int MINOR_FIELD_UNQUOTED_NAME = 10;
/*     */   protected static final int MINOR_VALUE_LEADING_WS = 12;
/*     */   protected static final int MINOR_VALUE_EXPECTING_COMMA = 13;
/*     */   protected static final int MINOR_VALUE_EXPECTING_COLON = 14;
/*     */   protected static final int MINOR_VALUE_WS_AFTER_COMMA = 15;
/*     */   protected static final int MINOR_VALUE_TOKEN_NULL = 16;
/*     */   protected static final int MINOR_VALUE_TOKEN_TRUE = 17;
/*     */   protected static final int MINOR_VALUE_TOKEN_FALSE = 18;
/*     */   protected static final int MINOR_VALUE_TOKEN_NON_STD = 19;
/*     */   protected static final int MINOR_NUMBER_PLUS = 22;
/*     */   protected static final int MINOR_NUMBER_MINUS = 23;
/*     */   protected static final int MINOR_NUMBER_ZERO = 24;
/*     */   protected static final int MINOR_NUMBER_MINUSZERO = 25;
/*     */   protected static final int MINOR_NUMBER_INTEGER_DIGITS = 26;
/*     */   protected static final int MINOR_NUMBER_FRACTION_DIGITS = 30;
/*     */   protected static final int MINOR_NUMBER_EXPONENT_MARKER = 31;
/*     */   protected static final int MINOR_NUMBER_EXPONENT_DIGITS = 32;
/*     */   protected static final int MINOR_VALUE_STRING = 40;
/*     */   protected static final int MINOR_VALUE_STRING_ESCAPE = 41;
/*     */   protected static final int MINOR_VALUE_STRING_UTF8_2 = 42;
/*     */   protected static final int MINOR_VALUE_STRING_UTF8_3 = 43;
/*     */   protected static final int MINOR_VALUE_STRING_UTF8_4 = 44;
/*     */   protected static final int MINOR_VALUE_APOS_STRING = 45;
/*     */   protected static final int MINOR_VALUE_TOKEN_ERROR = 50;
/*     */   protected static final int MINOR_COMMENT_LEADING_SLASH = 51;
/*     */   protected static final int MINOR_COMMENT_CLOSING_ASTERISK = 52;
/*     */   protected static final int MINOR_COMMENT_C = 53;
/*     */   protected static final int MINOR_COMMENT_CPP = 54;
/*     */   protected static final int MINOR_COMMENT_YAML = 55;
/*     */   protected final ByteQuadsCanonicalizer _symbols;
/* 151 */   protected int[] _quadBuffer = new int[8];
/*     */ 
/*     */ 
/*     */   
/*     */   protected int _quadLength;
/*     */ 
/*     */ 
/*     */   
/*     */   protected int _quad1;
/*     */ 
/*     */ 
/*     */   
/*     */   protected int _pending32;
/*     */ 
/*     */ 
/*     */   
/*     */   protected int _pendingBytes;
/*     */ 
/*     */ 
/*     */   
/*     */   protected int _quoted32;
/*     */ 
/*     */ 
/*     */   
/*     */   protected int _quotedDigits;
/*     */ 
/*     */ 
/*     */   
/*     */   protected int _majorState;
/*     */ 
/*     */ 
/*     */   
/*     */   protected int _majorStateAfterValue;
/*     */ 
/*     */ 
/*     */   
/*     */   protected int _minorState;
/*     */ 
/*     */ 
/*     */   
/*     */   protected int _minorStateAfterSplit;
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean _endOfInput = false;
/*     */ 
/*     */   
/*     */   protected static final int NON_STD_TOKEN_NAN = 0;
/*     */ 
/*     */   
/*     */   protected static final int NON_STD_TOKEN_INFINITY = 1;
/*     */ 
/*     */   
/*     */   protected static final int NON_STD_TOKEN_PLUS_INFINITY = 2;
/*     */ 
/*     */   
/*     */   protected static final int NON_STD_TOKEN_MINUS_INFINITY = 3;
/*     */ 
/*     */   
/* 210 */   protected static final String[] NON_STD_TOKENS = new String[] { "NaN", "Infinity", "+Infinity", "-Infinity" };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 215 */   protected static final double[] NON_STD_TOKEN_VALUES = new double[] { Double.NaN, Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int _nonStdTokenType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 237 */   protected int _currBufferStart = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 246 */   protected int _currInputRowAlt = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NonBlockingJsonParserBase(IOContext ctxt, int parserFeatures, ByteQuadsCanonicalizer sym) {
/* 257 */     super(ctxt, parserFeatures);
/* 258 */     this._symbols = sym;
/* 259 */     this._currToken = null;
/* 260 */     this._majorState = 0;
/* 261 */     this._majorStateAfterValue = 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public ObjectCodec getCodec() {
/* 266 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setCodec(ObjectCodec c) {
/* 271 */     throw new UnsupportedOperationException("Can not use ObjectMapper with non-blocking parser");
/*     */   }
/*     */   
/*     */   public boolean canParseAsync() {
/* 275 */     return true;
/*     */   }
/*     */   
/*     */   public JacksonFeatureSet<StreamReadCapability> getReadCapabilities() {
/* 279 */     return JSON_READ_CAPABILITIES;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ByteQuadsCanonicalizer symbolTableForTests() {
/* 289 */     return this._symbols;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract int releaseBuffered(OutputStream paramOutputStream) throws IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _releaseBuffers() throws IOException {
/* 304 */     super._releaseBuffers();
/*     */     
/* 306 */     this._symbols.release();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getInputSource() {
/* 313 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _closeInput() throws IOException {
/* 321 */     this._currBufferStart = 0;
/* 322 */     this._inputEnd = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasTextCharacters() {
/* 334 */     if (this._currToken == JsonToken.VALUE_STRING)
/*     */     {
/* 336 */       return this._textBuffer.hasTextAsCharacters();
/*     */     }
/* 338 */     if (this._currToken == JsonToken.FIELD_NAME)
/*     */     {
/* 340 */       return this._nameCopied;
/*     */     }
/*     */     
/* 343 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonLocation getCurrentLocation() {
/* 349 */     int col = this._inputPtr - this._currInputRowStart + 1;
/*     */     
/* 351 */     int row = Math.max(this._currInputRow, this._currInputRowAlt);
/* 352 */     return new JsonLocation(_contentReference(), this._currInputProcessed + (this._inputPtr - this._currBufferStart), -1L, row, col);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonLocation getTokenLocation() {
/* 360 */     return new JsonLocation(_contentReference(), this._tokenInputTotal, -1L, this._tokenInputRow, this._tokenInputCol);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getText() throws IOException {
/* 379 */     if (this._currToken == JsonToken.VALUE_STRING) {
/* 380 */       return this._textBuffer.contentsAsString();
/*     */     }
/* 382 */     return _getText2(this._currToken);
/*     */   }
/*     */ 
/*     */   
/*     */   protected final String _getText2(JsonToken t) {
/* 387 */     if (t == null) {
/* 388 */       return null;
/*     */     }
/* 390 */     switch (t.id()) {
/*     */       case -1:
/* 392 */         return null;
/*     */       case 5:
/* 394 */         return this._parsingContext.getCurrentName();
/*     */       
/*     */       case 6:
/*     */       case 7:
/*     */       case 8:
/* 399 */         return this._textBuffer.contentsAsString();
/*     */     } 
/* 401 */     return t.asString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getText(Writer writer) throws IOException {
/* 408 */     JsonToken t = this._currToken;
/* 409 */     if (t == JsonToken.VALUE_STRING) {
/* 410 */       return this._textBuffer.contentsToWriter(writer);
/*     */     }
/* 412 */     if (t == JsonToken.FIELD_NAME) {
/* 413 */       String n = this._parsingContext.getCurrentName();
/* 414 */       writer.write(n);
/* 415 */       return n.length();
/*     */     } 
/* 417 */     if (t != null) {
/* 418 */       if (t.isNumeric()) {
/* 419 */         return this._textBuffer.contentsToWriter(writer);
/*     */       }
/* 421 */       if (t == JsonToken.NOT_AVAILABLE) {
/* 422 */         _reportError("Current token not available: can not call this method");
/*     */       }
/* 424 */       char[] ch = t.asCharArray();
/* 425 */       writer.write(ch);
/* 426 */       return ch.length;
/*     */     } 
/* 428 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getValueAsString() throws IOException {
/* 437 */     if (this._currToken == JsonToken.VALUE_STRING) {
/* 438 */       return this._textBuffer.contentsAsString();
/*     */     }
/* 440 */     if (this._currToken == JsonToken.FIELD_NAME) {
/* 441 */       return getCurrentName();
/*     */     }
/* 443 */     return super.getValueAsString(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getValueAsString(String defValue) throws IOException {
/* 450 */     if (this._currToken == JsonToken.VALUE_STRING) {
/* 451 */       return this._textBuffer.contentsAsString();
/*     */     }
/* 453 */     if (this._currToken == JsonToken.FIELD_NAME) {
/* 454 */       return getCurrentName();
/*     */     }
/* 456 */     return super.getValueAsString(defValue);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public char[] getTextCharacters() throws IOException {
/* 462 */     if (this._currToken != null) {
/* 463 */       switch (this._currToken.id()) {
/*     */         
/*     */         case 5:
/* 466 */           if (!this._nameCopied) {
/* 467 */             String name = this._parsingContext.getCurrentName();
/* 468 */             int nameLen = name.length();
/* 469 */             if (this._nameCopyBuffer == null) {
/* 470 */               this._nameCopyBuffer = this._ioContext.allocNameCopyBuffer(nameLen);
/* 471 */             } else if (this._nameCopyBuffer.length < nameLen) {
/* 472 */               this._nameCopyBuffer = new char[nameLen];
/*     */             } 
/* 474 */             name.getChars(0, nameLen, this._nameCopyBuffer, 0);
/* 475 */             this._nameCopied = true;
/*     */           } 
/* 477 */           return this._nameCopyBuffer;
/*     */ 
/*     */         
/*     */         case 6:
/*     */         case 7:
/*     */         case 8:
/* 483 */           return this._textBuffer.getTextBuffer();
/*     */       } 
/*     */       
/* 486 */       return this._currToken.asCharArray();
/*     */     } 
/*     */     
/* 489 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTextLength() throws IOException {
/* 495 */     if (this._currToken != null) {
/* 496 */       switch (this._currToken.id()) {
/*     */         
/*     */         case 5:
/* 499 */           return this._parsingContext.getCurrentName().length();
/*     */         
/*     */         case 6:
/*     */         case 7:
/*     */         case 8:
/* 504 */           return this._textBuffer.size();
/*     */       } 
/*     */       
/* 507 */       return (this._currToken.asCharArray()).length;
/*     */     } 
/*     */     
/* 510 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTextOffset() throws IOException {
/* 517 */     if (this._currToken != null) {
/* 518 */       switch (this._currToken.id()) {
/*     */         case 5:
/* 520 */           return 0;
/*     */         
/*     */         case 6:
/*     */         case 7:
/*     */         case 8:
/* 525 */           return this._textBuffer.getTextOffset();
/*     */       } 
/*     */     
/*     */     }
/* 529 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getBinaryValue(Base64Variant b64variant) throws IOException {
/* 541 */     if (this._currToken != JsonToken.VALUE_STRING) {
/* 542 */       _reportError("Current token (%s) not VALUE_STRING or VALUE_EMBEDDED_OBJECT, can not access as binary", this._currToken);
/*     */     }
/*     */     
/* 545 */     if (this._binaryValue == null) {
/*     */       
/* 547 */       ByteArrayBuilder builder = _getByteArrayBuilder();
/* 548 */       _decodeBase64(getText(), builder, b64variant);
/* 549 */       this._binaryValue = builder.toByteArray();
/*     */     } 
/* 551 */     return this._binaryValue;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int readBinaryValue(Base64Variant b64variant, OutputStream out) throws IOException {
/* 557 */     byte[] b = getBinaryValue(b64variant);
/* 558 */     out.write(b);
/* 559 */     return b.length;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getEmbeddedObject() throws IOException {
/* 565 */     if (this._currToken == JsonToken.VALUE_EMBEDDED_OBJECT) {
/* 566 */       return this._binaryValue;
/*     */     }
/* 568 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final JsonToken _startArrayScope() throws IOException {
/* 579 */     this._parsingContext = this._parsingContext.createChildArrayContext(-1, -1);
/* 580 */     this._majorState = 5;
/* 581 */     this._majorStateAfterValue = 6;
/* 582 */     return this._currToken = JsonToken.START_ARRAY;
/*     */   }
/*     */ 
/*     */   
/*     */   protected final JsonToken _startObjectScope() throws IOException {
/* 587 */     this._parsingContext = this._parsingContext.createChildObjectContext(-1, -1);
/* 588 */     this._majorState = 2;
/* 589 */     this._majorStateAfterValue = 3;
/* 590 */     return this._currToken = JsonToken.START_OBJECT;
/*     */   }
/*     */   
/*     */   protected final JsonToken _closeArrayScope() throws IOException {
/*     */     int st;
/* 595 */     if (!this._parsingContext.inArray()) {
/* 596 */       _reportMismatchedEndMarker(93, '}');
/*     */     }
/* 598 */     JsonReadContext ctxt = this._parsingContext.getParent();
/* 599 */     this._parsingContext = ctxt;
/*     */     
/* 601 */     if (ctxt.inObject()) {
/* 602 */       st = 3;
/* 603 */     } else if (ctxt.inArray()) {
/* 604 */       st = 6;
/*     */     } else {
/* 606 */       st = 1;
/*     */     } 
/* 608 */     this._majorState = st;
/* 609 */     this._majorStateAfterValue = st;
/* 610 */     return this._currToken = JsonToken.END_ARRAY;
/*     */   }
/*     */   
/*     */   protected final JsonToken _closeObjectScope() throws IOException {
/*     */     int st;
/* 615 */     if (!this._parsingContext.inObject()) {
/* 616 */       _reportMismatchedEndMarker(125, ']');
/*     */     }
/* 618 */     JsonReadContext ctxt = this._parsingContext.getParent();
/* 619 */     this._parsingContext = ctxt;
/*     */     
/* 621 */     if (ctxt.inObject()) {
/* 622 */       st = 3;
/* 623 */     } else if (ctxt.inArray()) {
/* 624 */       st = 6;
/*     */     } else {
/* 626 */       st = 1;
/*     */     } 
/* 628 */     this._majorState = st;
/* 629 */     this._majorStateAfterValue = st;
/* 630 */     return this._currToken = JsonToken.END_OBJECT;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final String _findName(int q1, int lastQuadBytes) throws JsonParseException {
/* 641 */     q1 = _padLastQuad(q1, lastQuadBytes);
/*     */     
/* 643 */     String name = this._symbols.findName(q1);
/* 644 */     if (name != null) {
/* 645 */       return name;
/*     */     }
/*     */     
/* 648 */     this._quadBuffer[0] = q1;
/* 649 */     return _addName(this._quadBuffer, 1, lastQuadBytes);
/*     */   }
/*     */ 
/*     */   
/*     */   protected final String _findName(int q1, int q2, int lastQuadBytes) throws JsonParseException {
/* 654 */     q2 = _padLastQuad(q2, lastQuadBytes);
/*     */     
/* 656 */     String name = this._symbols.findName(q1, q2);
/* 657 */     if (name != null) {
/* 658 */       return name;
/*     */     }
/*     */     
/* 661 */     this._quadBuffer[0] = q1;
/* 662 */     this._quadBuffer[1] = q2;
/* 663 */     return _addName(this._quadBuffer, 2, lastQuadBytes);
/*     */   }
/*     */ 
/*     */   
/*     */   protected final String _findName(int q1, int q2, int q3, int lastQuadBytes) throws JsonParseException {
/* 668 */     q3 = _padLastQuad(q3, lastQuadBytes);
/* 669 */     String name = this._symbols.findName(q1, q2, q3);
/* 670 */     if (name != null) {
/* 671 */       return name;
/*     */     }
/* 673 */     int[] quads = this._quadBuffer;
/* 674 */     quads[0] = q1;
/* 675 */     quads[1] = q2;
/* 676 */     quads[2] = _padLastQuad(q3, lastQuadBytes);
/* 677 */     return _addName(quads, 3, lastQuadBytes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final String _addName(int[] quads, int qlen, int lastQuadBytes) throws JsonParseException {
/* 691 */     int lastQuad, byteLen = (qlen << 2) - 4 + lastQuadBytes;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 700 */     if (lastQuadBytes < 4) {
/* 701 */       lastQuad = quads[qlen - 1];
/*     */       
/* 703 */       quads[qlen - 1] = lastQuad << 4 - lastQuadBytes << 3;
/*     */     } else {
/* 705 */       lastQuad = 0;
/*     */     } 
/*     */ 
/*     */     
/* 709 */     char[] cbuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 710 */     int cix = 0;
/*     */     
/* 712 */     for (int ix = 0; ix < byteLen; ) {
/* 713 */       int ch = quads[ix >> 2];
/* 714 */       int byteIx = ix & 0x3;
/* 715 */       ch = ch >> 3 - byteIx << 3 & 0xFF;
/* 716 */       ix++;
/*     */       
/* 718 */       if (ch > 127) {
/*     */         int needed;
/* 720 */         if ((ch & 0xE0) == 192) {
/* 721 */           ch &= 0x1F;
/* 722 */           needed = 1;
/* 723 */         } else if ((ch & 0xF0) == 224) {
/* 724 */           ch &= 0xF;
/* 725 */           needed = 2;
/* 726 */         } else if ((ch & 0xF8) == 240) {
/* 727 */           ch &= 0x7;
/* 728 */           needed = 3;
/*     */         } else {
/* 730 */           _reportInvalidInitial(ch);
/* 731 */           needed = ch = 1;
/*     */         } 
/* 733 */         if (ix + needed > byteLen) {
/* 734 */           _reportInvalidEOF(" in field name", JsonToken.FIELD_NAME);
/*     */         }
/*     */ 
/*     */         
/* 738 */         int ch2 = quads[ix >> 2];
/* 739 */         byteIx = ix & 0x3;
/* 740 */         ch2 >>= 3 - byteIx << 3;
/* 741 */         ix++;
/*     */         
/* 743 */         if ((ch2 & 0xC0) != 128) {
/* 744 */           _reportInvalidOther(ch2);
/*     */         }
/* 746 */         ch = ch << 6 | ch2 & 0x3F;
/* 747 */         if (needed > 1) {
/* 748 */           ch2 = quads[ix >> 2];
/* 749 */           byteIx = ix & 0x3;
/* 750 */           ch2 >>= 3 - byteIx << 3;
/* 751 */           ix++;
/*     */           
/* 753 */           if ((ch2 & 0xC0) != 128) {
/* 754 */             _reportInvalidOther(ch2);
/*     */           }
/* 756 */           ch = ch << 6 | ch2 & 0x3F;
/* 757 */           if (needed > 2) {
/* 758 */             ch2 = quads[ix >> 2];
/* 759 */             byteIx = ix & 0x3;
/* 760 */             ch2 >>= 3 - byteIx << 3;
/* 761 */             ix++;
/* 762 */             if ((ch2 & 0xC0) != 128) {
/* 763 */               _reportInvalidOther(ch2 & 0xFF);
/*     */             }
/* 765 */             ch = ch << 6 | ch2 & 0x3F;
/*     */           } 
/*     */         } 
/* 768 */         if (needed > 2) {
/* 769 */           ch -= 65536;
/* 770 */           if (cix >= cbuf.length) {
/* 771 */             cbuf = this._textBuffer.expandCurrentSegment();
/*     */           }
/* 773 */           cbuf[cix++] = (char)(55296 + (ch >> 10));
/* 774 */           ch = 0xDC00 | ch & 0x3FF;
/*     */         } 
/*     */       } 
/* 777 */       if (cix >= cbuf.length) {
/* 778 */         cbuf = this._textBuffer.expandCurrentSegment();
/*     */       }
/* 780 */       cbuf[cix++] = (char)ch;
/*     */     } 
/*     */ 
/*     */     
/* 784 */     String baseName = new String(cbuf, 0, cix);
/*     */     
/* 786 */     if (lastQuadBytes < 4) {
/* 787 */       quads[qlen - 1] = lastQuad;
/*     */     }
/* 789 */     return this._symbols.addName(baseName, quads, qlen);
/*     */   }
/*     */ 
/*     */   
/*     */   protected static final int _padLastQuad(int q, int bytes) {
/* 794 */     return (bytes == 4) ? q : (q | -1 << bytes << 3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final JsonToken _eofAsNextToken() throws IOException {
/* 806 */     this._majorState = 7;
/* 807 */     if (!this._parsingContext.inRoot()) {
/* 808 */       _handleEOF();
/*     */     }
/* 810 */     close();
/* 811 */     return this._currToken = null;
/*     */   }
/*     */ 
/*     */   
/*     */   protected final JsonToken _fieldComplete(String name) throws IOException {
/* 816 */     this._majorState = 4;
/* 817 */     this._parsingContext.setCurrentName(name);
/* 818 */     return this._currToken = JsonToken.FIELD_NAME;
/*     */   }
/*     */ 
/*     */   
/*     */   protected final JsonToken _valueComplete(JsonToken t) throws IOException {
/* 823 */     this._majorState = this._majorStateAfterValue;
/* 824 */     this._currToken = t;
/* 825 */     return t;
/*     */   }
/*     */ 
/*     */   
/*     */   protected final JsonToken _valueCompleteInt(int value, String asText) throws IOException {
/* 830 */     this._textBuffer.resetWithString(asText);
/* 831 */     this._intLength = asText.length();
/* 832 */     this._numTypesValid = 1;
/* 833 */     this._numberInt = value;
/* 834 */     this._majorState = this._majorStateAfterValue;
/* 835 */     JsonToken t = JsonToken.VALUE_NUMBER_INT;
/* 836 */     this._currToken = t;
/* 837 */     return t;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected final JsonToken _valueNonStdNumberComplete(int type) throws IOException {
/* 843 */     String tokenStr = NON_STD_TOKENS[type];
/* 844 */     this._textBuffer.resetWithString(tokenStr);
/* 845 */     if (!isEnabled(JsonParser.Feature.ALLOW_NON_NUMERIC_NUMBERS)) {
/* 846 */       _reportError("Non-standard token '%s': enable `JsonReadFeature.ALLOW_NON_NUMERIC_NUMBERS` to allow", tokenStr);
/*     */     }
/*     */     
/* 849 */     this._intLength = 0;
/* 850 */     this._numTypesValid = 8;
/* 851 */     this._numberDouble = NON_STD_TOKEN_VALUES[type];
/* 852 */     this._majorState = this._majorStateAfterValue;
/* 853 */     return this._currToken = JsonToken.VALUE_NUMBER_FLOAT;
/*     */   }
/*     */   
/*     */   protected final String _nonStdToken(int type) {
/* 857 */     return NON_STD_TOKENS[type];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void _updateTokenLocation() {
/* 868 */     this._tokenInputRow = Math.max(this._currInputRow, this._currInputRowAlt);
/* 869 */     int ptr = this._inputPtr;
/* 870 */     this._tokenInputCol = ptr - this._currInputRowStart;
/* 871 */     this._tokenInputTotal = this._currInputProcessed + (ptr - this._currBufferStart);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void _reportInvalidChar(int c) throws JsonParseException {
/* 876 */     if (c < 32) {
/* 877 */       _throwInvalidSpace(c);
/*     */     }
/* 879 */     _reportInvalidInitial(c);
/*     */   }
/*     */   
/*     */   protected void _reportInvalidInitial(int mask) throws JsonParseException {
/* 883 */     _reportError("Invalid UTF-8 start byte 0x" + Integer.toHexString(mask));
/*     */   }
/*     */   
/*     */   protected void _reportInvalidOther(int mask, int ptr) throws JsonParseException {
/* 887 */     this._inputPtr = ptr;
/* 888 */     _reportInvalidOther(mask);
/*     */   }
/*     */   
/*     */   protected void _reportInvalidOther(int mask) throws JsonParseException {
/* 892 */     _reportError("Invalid UTF-8 middle byte 0x" + Integer.toHexString(mask));
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-core-2.14.2.jar!\com\fasterxml\jackson\core\json\async\NonBlockingJsonParserBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */