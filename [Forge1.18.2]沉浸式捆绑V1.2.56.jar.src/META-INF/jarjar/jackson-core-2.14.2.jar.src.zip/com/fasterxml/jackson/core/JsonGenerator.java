/*      */ package com.fasterxml.jackson.core;
/*      */ 
/*      */ import com.fasterxml.jackson.core.io.CharacterEscapes;
/*      */ import com.fasterxml.jackson.core.type.WritableTypeId;
/*      */ import com.fasterxml.jackson.core.util.JacksonFeature;
/*      */ import com.fasterxml.jackson.core.util.JacksonFeatureSet;
/*      */ import com.fasterxml.jackson.core.util.VersionUtil;
/*      */ import java.io.Closeable;
/*      */ import java.io.Flushable;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.util.concurrent.atomic.AtomicBoolean;
/*      */ import java.util.concurrent.atomic.AtomicInteger;
/*      */ import java.util.concurrent.atomic.AtomicLong;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class JsonGenerator
/*      */   implements Closeable, Flushable, Versioned
/*      */ {
/*   41 */   protected static final JacksonFeatureSet<StreamWriteCapability> DEFAULT_WRITE_CAPABILITIES = JacksonFeatureSet.fromDefaults((JacksonFeature[])StreamWriteCapability.values());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   49 */   protected static final JacksonFeatureSet<StreamWriteCapability> DEFAULT_TEXTUAL_WRITE_CAPABILITIES = DEFAULT_WRITE_CAPABILITIES
/*   50 */     .with(StreamWriteCapability.CAN_WRITE_FORMATTED_NUMBERS);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   58 */   protected static final JacksonFeatureSet<StreamWriteCapability> DEFAULT_BINARY_WRITE_CAPABILITIES = DEFAULT_WRITE_CAPABILITIES
/*   59 */     .with(StreamWriteCapability.CAN_WRITE_BINARY_NATIVELY);
/*      */ 
/*      */   
/*      */   protected PrettyPrinter _cfgPrettyPrinter;
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract JsonGenerator setCodec(ObjectCodec paramObjectCodec);
/*      */ 
/*      */   
/*      */   public abstract ObjectCodec getCodec();
/*      */ 
/*      */   
/*      */   public abstract Version version();
/*      */ 
/*      */   
/*      */   public abstract JsonStreamContext getOutputContext();
/*      */ 
/*      */   
/*      */   public enum Feature
/*      */   {
/*   80 */     AUTO_CLOSE_TARGET(true),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   92 */     AUTO_CLOSE_JSON_CONTENT(true),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  105 */     FLUSH_PASSED_TO_STREAM(true),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  120 */     QUOTE_FIELD_NAMES(true),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  137 */     QUOTE_NON_NUMERIC_NUMBERS(true),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  159 */     ESCAPE_NON_ASCII(false),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  184 */     WRITE_NUMBERS_AS_STRINGS(false),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  201 */     WRITE_BIGDECIMAL_AS_PLAIN(false),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  220 */     STRICT_DUPLICATE_DETECTION(false),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  242 */     IGNORE_UNKNOWN(false),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  252 */     USE_FAST_DOUBLE_WRITER(false),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  266 */     WRITE_HEX_UPPER_CASE(true);
/*      */ 
/*      */ 
/*      */     
/*      */     private final boolean _defaultState;
/*      */ 
/*      */ 
/*      */     
/*      */     private final int _mask;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static int collectDefaults() {
/*  280 */       int flags = 0;
/*  281 */       for (Feature f : values()) {
/*  282 */         if (f.enabledByDefault()) {
/*  283 */           flags |= f.getMask();
/*      */         }
/*      */       } 
/*  286 */       return flags;
/*      */     }
/*      */     
/*      */     Feature(boolean defaultState) {
/*  290 */       this._defaultState = defaultState;
/*  291 */       this._mask = 1 << ordinal();
/*      */     }
/*      */     public boolean enabledByDefault() {
/*  294 */       return this._defaultState;
/*      */     }
/*      */     public boolean enabledIn(int flags) {
/*  297 */       return ((flags & this._mask) != 0);
/*      */     } public int getMask() {
/*  299 */       return this._mask;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getOutputTarget() {
/*  384 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object currentValue() {
/*  404 */     return getCurrentValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void assignCurrentValue(Object v) {
/*  419 */     setCurrentValue(v);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getCurrentValue() {
/*  430 */     JsonStreamContext ctxt = getOutputContext();
/*  431 */     return (ctxt == null) ? null : ctxt.getCurrentValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCurrentValue(Object v) {
/*  442 */     JsonStreamContext ctxt = getOutputContext();
/*  443 */     if (ctxt != null) {
/*  444 */       ctxt.setCurrentValue(v);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract JsonGenerator enable(Feature paramFeature);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract JsonGenerator disable(Feature paramFeature);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final JsonGenerator configure(Feature f, boolean state) {
/*  484 */     if (state) { enable(f); } else { disable(f); }
/*  485 */      return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract boolean isEnabled(Feature paramFeature);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isEnabled(StreamWriteFeature f) {
/*  509 */     return isEnabled(f.mappedFeature());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract int getFeatureMask();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public abstract JsonGenerator setFeatureMask(int paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonGenerator overrideStdFeatures(int values, int mask) {
/*  555 */     int oldState = getFeatureMask();
/*  556 */     int newState = oldState & (mask ^ 0xFFFFFFFF) | values & mask;
/*  557 */     return setFeatureMask(newState);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getFormatFeatures() {
/*  569 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonGenerator overrideFormatFeatures(int values, int mask) {
/*  591 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSchema(FormatSchema schema) {
/*  616 */     throw new UnsupportedOperationException(String.format("Generator of type %s does not support schema of type '%s'", new Object[] {
/*      */             
/*  618 */             getClass().getName(), schema.getSchemaType()
/*      */           }));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public FormatSchema getSchema() {
/*  627 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonGenerator setPrettyPrinter(PrettyPrinter pp) {
/*  649 */     this._cfgPrettyPrinter = pp;
/*  650 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PrettyPrinter getPrettyPrinter() {
/*  660 */     return this._cfgPrettyPrinter;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract JsonGenerator useDefaultPrettyPrinter();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonGenerator setHighestNonEscapedChar(int charCode) {
/*  695 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getHighestEscapedChar() {
/*  709 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CharacterEscapes getCharacterEscapes() {
/*  717 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonGenerator setCharacterEscapes(CharacterEscapes esc) {
/*  729 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonGenerator setRootValueSeparator(SerializableString sep) {
/*  743 */     throw new UnsupportedOperationException();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getOutputBuffered() {
/*  771 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean canUseSchema(FormatSchema schema) {
/*  788 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean canWriteObjectId() {
/*  808 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean canWriteTypeId() {
/*  828 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean canWriteBinaryNatively() {
/*  845 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean canOmitFields() {
/*  858 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean canWriteFormattedNumbers() {
/*  877 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JacksonFeatureSet<StreamWriteCapability> getWriteCapabilities() {
/*  888 */     return DEFAULT_WRITE_CAPABILITIES;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void writeStartArray() throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void writeStartArray(int size) throws IOException {
/*  934 */     writeStartArray();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeStartArray(Object forValue) throws IOException {
/*  951 */     writeStartArray();
/*  952 */     setCurrentValue(forValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeStartArray(Object forValue, int size) throws IOException {
/*  974 */     writeStartArray(size);
/*  975 */     setCurrentValue(forValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void writeEndArray() throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void writeStartObject() throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeStartObject(Object forValue) throws IOException {
/* 1025 */     writeStartObject();
/* 1026 */     setCurrentValue(forValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeStartObject(Object forValue, int size) throws IOException {
/* 1056 */     writeStartObject(forValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void writeEndObject() throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void writeFieldName(String paramString) throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void writeFieldName(SerializableString paramSerializableString) throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeFieldId(long id) throws IOException {
/* 1124 */     writeFieldName(Long.toString(id));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeArray(int[] array, int offset, int length) throws IOException {
/* 1149 */     if (array == null) {
/* 1150 */       throw new IllegalArgumentException("null array");
/*      */     }
/* 1152 */     _verifyOffsets(array.length, offset, length);
/* 1153 */     writeStartArray(array, length);
/* 1154 */     for (int i = offset, end = offset + length; i < end; i++) {
/* 1155 */       writeNumber(array[i]);
/*      */     }
/* 1157 */     writeEndArray();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeArray(long[] array, int offset, int length) throws IOException {
/* 1176 */     if (array == null) {
/* 1177 */       throw new IllegalArgumentException("null array");
/*      */     }
/* 1179 */     _verifyOffsets(array.length, offset, length);
/* 1180 */     writeStartArray(array, length);
/* 1181 */     for (int i = offset, end = offset + length; i < end; i++) {
/* 1182 */       writeNumber(array[i]);
/*      */     }
/* 1184 */     writeEndArray();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeArray(double[] array, int offset, int length) throws IOException {
/* 1203 */     if (array == null) {
/* 1204 */       throw new IllegalArgumentException("null array");
/*      */     }
/* 1206 */     _verifyOffsets(array.length, offset, length);
/* 1207 */     writeStartArray(array, length);
/* 1208 */     for (int i = offset, end = offset + length; i < end; i++) {
/* 1209 */       writeNumber(array[i]);
/*      */     }
/* 1211 */     writeEndArray();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeArray(String[] array, int offset, int length) throws IOException {
/* 1230 */     if (array == null) {
/* 1231 */       throw new IllegalArgumentException("null array");
/*      */     }
/* 1233 */     _verifyOffsets(array.length, offset, length);
/* 1234 */     writeStartArray(array, length);
/* 1235 */     for (int i = offset, end = offset + length; i < end; i++) {
/* 1236 */       writeString(array[i]);
/*      */     }
/* 1238 */     writeEndArray();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void writeString(String paramString) throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeString(Reader reader, int len) throws IOException {
/* 1286 */     _reportUnsupportedOperation();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void writeString(char[] paramArrayOfchar, int paramInt1, int paramInt2) throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void writeString(SerializableString paramSerializableString) throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void writeRawUTF8String(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void writeUTF8String(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void writeRaw(String paramString) throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void writeRaw(String paramString, int paramInt1, int paramInt2) throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void writeRaw(char[] paramArrayOfchar, int paramInt1, int paramInt2) throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void writeRaw(char paramChar) throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeRaw(SerializableString raw) throws IOException {
/* 1484 */     writeRaw(raw.getValue());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void writeRawValue(String paramString) throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void writeRawValue(String paramString, int paramInt1, int paramInt2) throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void writeRawValue(char[] paramArrayOfchar, int paramInt1, int paramInt2) throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeRawValue(SerializableString raw) throws IOException {
/* 1519 */     writeRawValue(raw.getValue());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void writeBinary(Base64Variant paramBase64Variant, byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeBinary(byte[] data, int offset, int len) throws IOException {
/* 1565 */     writeBinary(Base64Variants.getDefaultVariant(), data, offset, len);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeBinary(byte[] data) throws IOException {
/* 1580 */     writeBinary(Base64Variants.getDefaultVariant(), data, 0, data.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int writeBinary(InputStream data, int dataLength) throws IOException {
/* 1603 */     return writeBinary(Base64Variants.getDefaultVariant(), data, dataLength);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract int writeBinary(Base64Variant paramBase64Variant, InputStream paramInputStream, int paramInt) throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumber(short v) throws IOException {
/* 1651 */     writeNumber(v);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void writeNumber(int paramInt) throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void writeNumber(long paramLong) throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void writeNumber(BigInteger paramBigInteger) throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void writeNumber(double paramDouble) throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void writeNumber(float paramFloat) throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void writeNumber(BigDecimal paramBigDecimal) throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void writeNumber(String paramString) throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumber(char[] encodedValueBuffer, int offset, int len) throws IOException {
/* 1778 */     writeNumber(new String(encodedValueBuffer, offset, len));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void writeBoolean(boolean paramBoolean) throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void writeNull() throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeEmbeddedObject(Object object) throws IOException {
/* 1831 */     if (object == null) {
/* 1832 */       writeNull();
/*      */       return;
/*      */     } 
/* 1835 */     if (object instanceof byte[]) {
/* 1836 */       writeBinary((byte[])object);
/*      */       return;
/*      */     } 
/* 1839 */     throw new JsonGenerationException("No native support for writing embedded objects of type " + object
/* 1840 */         .getClass().getName(), this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeObjectId(Object id) throws IOException {
/* 1869 */     throw new JsonGenerationException("No native support for writing Object Ids", this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeObjectRef(Object referenced) throws IOException {
/* 1889 */     throw new JsonGenerationException("No native support for writing Object Ids", this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeTypeId(Object id) throws IOException {
/* 1911 */     throw new JsonGenerationException("No native support for writing Type Ids", this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WritableTypeId writeTypePrefix(WritableTypeId typeIdDef) throws IOException {
/* 1940 */     Object id = typeIdDef.id;
/*      */     
/* 1942 */     JsonToken valueShape = typeIdDef.valueShape;
/* 1943 */     if (canWriteTypeId()) {
/* 1944 */       typeIdDef.wrapperWritten = false;
/*      */       
/* 1946 */       writeTypeId(id);
/*      */     }
/*      */     else {
/*      */       
/* 1950 */       String idStr = (id instanceof String) ? (String)id : String.valueOf(id);
/* 1951 */       typeIdDef.wrapperWritten = true;
/*      */       
/* 1953 */       WritableTypeId.Inclusion incl = typeIdDef.include;
/*      */       
/* 1955 */       if (valueShape != JsonToken.START_OBJECT && incl
/* 1956 */         .requiresObjectContext()) {
/* 1957 */         typeIdDef.include = incl = WritableTypeId.Inclusion.WRAPPER_ARRAY;
/*      */       }
/*      */       
/* 1960 */       switch (incl) {
/*      */         case PARENT_PROPERTY:
/*      */         case PAYLOAD_PROPERTY:
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case METADATA_PROPERTY:
/* 1972 */           writeStartObject(typeIdDef.forValue);
/* 1973 */           writeStringField(typeIdDef.asProperty, idStr);
/* 1974 */           return typeIdDef;
/*      */ 
/*      */         
/*      */         case WRAPPER_OBJECT:
/* 1978 */           writeStartObject();
/* 1979 */           writeFieldName(idStr);
/*      */           break;
/*      */         
/*      */         default:
/* 1983 */           writeStartArray();
/* 1984 */           writeString(idStr);
/*      */           break;
/*      */       } 
/*      */     } 
/* 1988 */     if (valueShape == JsonToken.START_OBJECT) {
/* 1989 */       writeStartObject(typeIdDef.forValue);
/* 1990 */     } else if (valueShape == JsonToken.START_ARRAY) {
/*      */       
/* 1992 */       writeStartArray();
/*      */     } 
/* 1994 */     return typeIdDef;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WritableTypeId writeTypeSuffix(WritableTypeId typeIdDef) throws IOException {
/* 2016 */     JsonToken valueShape = typeIdDef.valueShape;
/*      */     
/* 2018 */     if (valueShape == JsonToken.START_OBJECT) {
/* 2019 */       writeEndObject();
/* 2020 */     } else if (valueShape == JsonToken.START_ARRAY) {
/* 2021 */       writeEndArray();
/*      */     } 
/*      */     
/* 2024 */     if (typeIdDef.wrapperWritten) {
/* 2025 */       Object id; String idStr; switch (typeIdDef.include) {
/*      */         case WRAPPER_ARRAY:
/* 2027 */           writeEndArray();
/*      */ 
/*      */ 
/*      */         
/*      */         case PARENT_PROPERTY:
/* 2032 */           id = typeIdDef.id;
/* 2033 */           idStr = (id instanceof String) ? (String)id : String.valueOf(id);
/* 2034 */           writeStringField(typeIdDef.asProperty, idStr);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case PAYLOAD_PROPERTY:
/*      */         case METADATA_PROPERTY:
/* 2047 */           return typeIdDef;
/*      */       } 
/*      */       writeEndObject();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writePOJO(Object pojo) throws IOException {
/* 2075 */     writeObject(pojo);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void writeObject(Object paramObject) throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void writeTree(TreeNode paramTreeNode) throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeBinaryField(String fieldName, byte[] data) throws IOException {
/* 2130 */     writeFieldName(fieldName);
/* 2131 */     writeBinary(data);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeBooleanField(String fieldName, boolean value) throws IOException {
/* 2149 */     writeFieldName(fieldName);
/* 2150 */     writeBoolean(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNullField(String fieldName) throws IOException {
/* 2167 */     writeFieldName(fieldName);
/* 2168 */     writeNull();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeStringField(String fieldName, String value) throws IOException {
/* 2186 */     writeFieldName(fieldName);
/* 2187 */     writeString(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumberField(String fieldName, short value) throws IOException {
/* 2207 */     writeFieldName(fieldName);
/* 2208 */     writeNumber(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumberField(String fieldName, int value) throws IOException {
/* 2226 */     writeFieldName(fieldName);
/* 2227 */     writeNumber(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumberField(String fieldName, long value) throws IOException {
/* 2245 */     writeFieldName(fieldName);
/* 2246 */     writeNumber(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumberField(String fieldName, BigInteger value) throws IOException {
/* 2266 */     writeFieldName(fieldName);
/* 2267 */     writeNumber(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumberField(String fieldName, float value) throws IOException {
/* 2285 */     writeFieldName(fieldName);
/* 2286 */     writeNumber(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumberField(String fieldName, double value) throws IOException {
/* 2304 */     writeFieldName(fieldName);
/* 2305 */     writeNumber(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumberField(String fieldName, BigDecimal value) throws IOException {
/* 2324 */     writeFieldName(fieldName);
/* 2325 */     writeNumber(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeArrayFieldStart(String fieldName) throws IOException {
/* 2347 */     writeFieldName(fieldName);
/* 2348 */     writeStartArray();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeObjectFieldStart(String fieldName) throws IOException {
/* 2370 */     writeFieldName(fieldName);
/* 2371 */     writeStartObject();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writePOJOField(String fieldName, Object pojo) throws IOException {
/* 2393 */     writeObjectField(fieldName, pojo);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeObjectField(String fieldName, Object pojo) throws IOException {
/* 2407 */     writeFieldName(fieldName);
/* 2408 */     writeObject(pojo);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeOmittedField(String fieldName) throws IOException {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void copyCurrentEvent(JsonParser p) throws IOException {
/*      */     JsonParser.NumberType n;
/* 2452 */     JsonToken t = p.currentToken();
/* 2453 */     int token = (t == null) ? -1 : t.id();
/* 2454 */     switch (token) {
/*      */       case -1:
/* 2456 */         _reportError("No current event to copy");
/*      */         return;
/*      */       case 1:
/* 2459 */         writeStartObject();
/*      */         return;
/*      */       case 2:
/* 2462 */         writeEndObject();
/*      */         return;
/*      */       case 3:
/* 2465 */         writeStartArray();
/*      */         return;
/*      */       case 4:
/* 2468 */         writeEndArray();
/*      */         return;
/*      */       case 5:
/* 2471 */         writeFieldName(p.getCurrentName());
/*      */         return;
/*      */       case 6:
/* 2474 */         if (p.hasTextCharacters()) {
/* 2475 */           writeString(p.getTextCharacters(), p.getTextOffset(), p.getTextLength());
/*      */         } else {
/* 2477 */           writeString(p.getText());
/*      */         } 
/*      */         return;
/*      */       
/*      */       case 7:
/* 2482 */         n = p.getNumberType();
/* 2483 */         if (n == JsonParser.NumberType.INT) {
/* 2484 */           writeNumber(p.getIntValue());
/* 2485 */         } else if (n == JsonParser.NumberType.BIG_INTEGER) {
/* 2486 */           writeNumber(p.getBigIntegerValue());
/*      */         } else {
/* 2488 */           writeNumber(p.getLongValue());
/*      */         } 
/*      */         return;
/*      */ 
/*      */       
/*      */       case 8:
/* 2494 */         n = p.getNumberType();
/* 2495 */         if (n == JsonParser.NumberType.BIG_DECIMAL) {
/* 2496 */           writeNumber(p.getDecimalValue());
/* 2497 */         } else if (n == JsonParser.NumberType.FLOAT) {
/* 2498 */           writeNumber(p.getFloatValue());
/*      */         } else {
/* 2500 */           writeNumber(p.getDoubleValue());
/*      */         } 
/*      */         return;
/*      */       
/*      */       case 9:
/* 2505 */         writeBoolean(true);
/*      */         return;
/*      */       case 10:
/* 2508 */         writeBoolean(false);
/*      */         return;
/*      */       case 11:
/* 2511 */         writeNull();
/*      */         return;
/*      */       case 12:
/* 2514 */         writeObject(p.getEmbeddedObject());
/*      */         return;
/*      */     } 
/* 2517 */     throw new IllegalStateException("Internal error: unknown current token, " + t);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void copyCurrentStructure(JsonParser p) throws IOException {
/* 2558 */     JsonToken t = p.currentToken();
/*      */     
/* 2560 */     int id = (t == null) ? -1 : t.id();
/* 2561 */     if (id == 5) {
/* 2562 */       writeFieldName(p.getCurrentName());
/* 2563 */       t = p.nextToken();
/* 2564 */       id = (t == null) ? -1 : t.id();
/*      */     } 
/*      */     
/* 2567 */     switch (id) {
/*      */       case 1:
/* 2569 */         writeStartObject();
/* 2570 */         _copyCurrentContents(p);
/*      */         return;
/*      */       case 3:
/* 2573 */         writeStartArray();
/* 2574 */         _copyCurrentContents(p);
/*      */         return;
/*      */     } 
/*      */     
/* 2578 */     copyCurrentEvent(p);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _copyCurrentContents(JsonParser p) throws IOException {
/* 2585 */     int depth = 1;
/*      */     
/*      */     JsonToken t;
/*      */     
/* 2589 */     while ((t = p.nextToken()) != null) {
/* 2590 */       JsonParser.NumberType n; switch (t.id()) {
/*      */         case 5:
/* 2592 */           writeFieldName(p.getCurrentName());
/*      */           continue;
/*      */         
/*      */         case 3:
/* 2596 */           writeStartArray();
/* 2597 */           depth++;
/*      */           continue;
/*      */         
/*      */         case 1:
/* 2601 */           writeStartObject();
/* 2602 */           depth++;
/*      */           continue;
/*      */         
/*      */         case 4:
/* 2606 */           writeEndArray();
/* 2607 */           if (--depth == 0) {
/*      */             return;
/*      */           }
/*      */           continue;
/*      */         case 2:
/* 2612 */           writeEndObject();
/* 2613 */           if (--depth == 0) {
/*      */             return;
/*      */           }
/*      */           continue;
/*      */         
/*      */         case 6:
/* 2619 */           if (p.hasTextCharacters()) {
/* 2620 */             writeString(p.getTextCharacters(), p.getTextOffset(), p.getTextLength()); continue;
/*      */           } 
/* 2622 */           writeString(p.getText());
/*      */           continue;
/*      */ 
/*      */         
/*      */         case 7:
/* 2627 */           n = p.getNumberType();
/* 2628 */           if (n == JsonParser.NumberType.INT) {
/* 2629 */             writeNumber(p.getIntValue()); continue;
/* 2630 */           }  if (n == JsonParser.NumberType.BIG_INTEGER) {
/* 2631 */             writeNumber(p.getBigIntegerValue()); continue;
/*      */           } 
/* 2633 */           writeNumber(p.getLongValue());
/*      */           continue;
/*      */ 
/*      */ 
/*      */         
/*      */         case 8:
/* 2639 */           n = p.getNumberType();
/* 2640 */           if (n == JsonParser.NumberType.BIG_DECIMAL) {
/* 2641 */             writeNumber(p.getDecimalValue()); continue;
/* 2642 */           }  if (n == JsonParser.NumberType.FLOAT) {
/* 2643 */             writeNumber(p.getFloatValue()); continue;
/*      */           } 
/* 2645 */           writeNumber(p.getDoubleValue());
/*      */           continue;
/*      */ 
/*      */         
/*      */         case 9:
/* 2650 */           writeBoolean(true);
/*      */           continue;
/*      */         case 10:
/* 2653 */           writeBoolean(false);
/*      */           continue;
/*      */         case 11:
/* 2656 */           writeNull();
/*      */           continue;
/*      */         case 12:
/* 2659 */           writeObject(p.getEmbeddedObject());
/*      */           continue;
/*      */       } 
/* 2662 */       throw new IllegalStateException("Internal error: unknown current token, " + t);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void flush() throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract boolean isClosed();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void close() throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _reportError(String msg) throws JsonGenerationException {
/* 2733 */     throw new JsonGenerationException(msg, this);
/*      */   }
/*      */   protected final void _throwInternal() {
/* 2736 */     VersionUtil.throwInternal();
/*      */   }
/*      */   protected void _reportUnsupportedOperation() {
/* 2739 */     throw new UnsupportedOperationException("Operation not supported by generator of type " + getClass().getName());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void _verifyOffsets(int arrayLength, int offset, int length) {
/* 2745 */     if (offset < 0 || offset + length > arrayLength) {
/* 2746 */       throw new IllegalArgumentException(String.format("invalid argument(s) (offset=%d, length=%d) for input array of %d element", new Object[] {
/*      */               
/* 2748 */               Integer.valueOf(offset), Integer.valueOf(length), Integer.valueOf(arrayLength)
/*      */             }));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _writeSimpleObject(Object value) throws IOException {
/* 2767 */     if (value == null) {
/* 2768 */       writeNull();
/*      */       return;
/*      */     } 
/* 2771 */     if (value instanceof String) {
/* 2772 */       writeString((String)value);
/*      */       return;
/*      */     } 
/* 2775 */     if (value instanceof Number) {
/* 2776 */       Number n = (Number)value;
/* 2777 */       if (n instanceof Integer) {
/* 2778 */         writeNumber(n.intValue()); return;
/*      */       } 
/* 2780 */       if (n instanceof Long) {
/* 2781 */         writeNumber(n.longValue()); return;
/*      */       } 
/* 2783 */       if (n instanceof Double) {
/* 2784 */         writeNumber(n.doubleValue()); return;
/*      */       } 
/* 2786 */       if (n instanceof Float) {
/* 2787 */         writeNumber(n.floatValue()); return;
/*      */       } 
/* 2789 */       if (n instanceof Short) {
/* 2790 */         writeNumber(n.shortValue()); return;
/*      */       } 
/* 2792 */       if (n instanceof Byte) {
/* 2793 */         writeNumber((short)n.byteValue()); return;
/*      */       } 
/* 2795 */       if (n instanceof BigInteger) {
/* 2796 */         writeNumber((BigInteger)n); return;
/*      */       } 
/* 2798 */       if (n instanceof BigDecimal) {
/* 2799 */         writeNumber((BigDecimal)n);
/*      */         
/*      */         return;
/*      */       } 
/* 2803 */       if (n instanceof AtomicInteger) {
/* 2804 */         writeNumber(((AtomicInteger)n).get()); return;
/*      */       } 
/* 2806 */       if (n instanceof AtomicLong) {
/* 2807 */         writeNumber(((AtomicLong)n).get()); return;
/*      */       } 
/*      */     } else {
/* 2810 */       if (value instanceof byte[]) {
/* 2811 */         writeBinary((byte[])value); return;
/*      */       } 
/* 2813 */       if (value instanceof Boolean) {
/* 2814 */         writeBoolean(((Boolean)value).booleanValue()); return;
/*      */       } 
/* 2816 */       if (value instanceof AtomicBoolean) {
/* 2817 */         writeBoolean(((AtomicBoolean)value).get()); return;
/*      */       } 
/*      */     } 
/* 2820 */     throw new IllegalStateException("No ObjectCodec defined for the generator, can only serialize simple wrapper types (type passed " + value
/* 2821 */         .getClass().getName() + ")");
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-core-2.14.2.jar!\com\fasterxml\jackson\core\JsonGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */