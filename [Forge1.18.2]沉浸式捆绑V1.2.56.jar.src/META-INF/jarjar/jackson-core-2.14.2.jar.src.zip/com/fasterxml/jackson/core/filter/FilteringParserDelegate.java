/*      */ package com.fasterxml.jackson.core.filter;
/*      */ 
/*      */ import com.fasterxml.jackson.core.Base64Variant;
/*      */ import com.fasterxml.jackson.core.JsonLocation;
/*      */ import com.fasterxml.jackson.core.JsonParser;
/*      */ import com.fasterxml.jackson.core.JsonStreamContext;
/*      */ import com.fasterxml.jackson.core.JsonToken;
/*      */ import com.fasterxml.jackson.core.util.JsonParserDelegate;
/*      */ import java.io.IOException;
/*      */ import java.io.OutputStream;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class FilteringParserDelegate
/*      */   extends JsonParserDelegate
/*      */ {
/*      */   protected TokenFilter rootFilter;
/*      */   protected boolean _allowMultipleMatches;
/*      */   protected TokenFilter.Inclusion _inclusion;
/*      */   protected JsonToken _currToken;
/*      */   protected JsonToken _lastClearedToken;
/*      */   protected TokenFilterContext _headContext;
/*      */   protected TokenFilterContext _exposedContext;
/*      */   protected TokenFilter _itemFilter;
/*      */   protected int _matchCount;
/*      */   
/*      */   @Deprecated
/*      */   public FilteringParserDelegate(JsonParser p, TokenFilter f, boolean includePath, boolean allowMultipleMatches) {
/*  108 */     this(p, f, includePath ? TokenFilter.Inclusion.INCLUDE_ALL_AND_PATH : TokenFilter.Inclusion.ONLY_INCLUDE_ALL, allowMultipleMatches);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public FilteringParserDelegate(JsonParser p, TokenFilter f, TokenFilter.Inclusion inclusion, boolean allowMultipleMatches) {
/*  120 */     super(p);
/*  121 */     this.rootFilter = f;
/*      */     
/*  123 */     this._itemFilter = f;
/*  124 */     this._headContext = TokenFilterContext.createRootContext(f);
/*  125 */     this._inclusion = inclusion;
/*  126 */     this._allowMultipleMatches = allowMultipleMatches;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TokenFilter getFilter() {
/*  135 */     return this.rootFilter;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMatchCount() {
/*  144 */     return this._matchCount;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonToken getCurrentToken() {
/*  153 */     return this._currToken; } public JsonToken currentToken() {
/*  154 */     return this._currToken;
/*      */   }
/*      */   @Deprecated
/*      */   public final int getCurrentTokenId() {
/*  158 */     return currentTokenId();
/*      */   }
/*      */   public final int currentTokenId() {
/*  161 */     JsonToken t = this._currToken;
/*  162 */     return (t == null) ? 0 : t.id();
/*      */   }
/*      */   public boolean hasCurrentToken() {
/*  165 */     return (this._currToken != null);
/*      */   } public boolean hasTokenId(int id) {
/*  167 */     JsonToken t = this._currToken;
/*  168 */     if (t == null) {
/*  169 */       return (0 == id);
/*      */     }
/*  171 */     return (t.id() == id);
/*      */   }
/*      */   
/*      */   public final boolean hasToken(JsonToken t) {
/*  175 */     return (this._currToken == t);
/*      */   }
/*      */   
/*  178 */   public boolean isExpectedStartArrayToken() { return (this._currToken == JsonToken.START_ARRAY); } public boolean isExpectedStartObjectToken() {
/*  179 */     return (this._currToken == JsonToken.START_OBJECT);
/*      */   } public JsonLocation getCurrentLocation() {
/*  181 */     return this.delegate.getCurrentLocation();
/*      */   }
/*      */   
/*      */   public JsonStreamContext getParsingContext() {
/*  185 */     return _filterContext();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getCurrentName() throws IOException {
/*  191 */     JsonStreamContext ctxt = _filterContext();
/*  192 */     if (this._currToken == JsonToken.START_OBJECT || this._currToken == JsonToken.START_ARRAY) {
/*  193 */       JsonStreamContext parent = ctxt.getParent();
/*  194 */       return (parent == null) ? null : parent.getCurrentName();
/*      */     } 
/*  196 */     return ctxt.getCurrentName();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String currentName() throws IOException {
/*  202 */     JsonStreamContext ctxt = _filterContext();
/*  203 */     if (this._currToken == JsonToken.START_OBJECT || this._currToken == JsonToken.START_ARRAY) {
/*  204 */       JsonStreamContext parent = ctxt.getParent();
/*  205 */       return (parent == null) ? null : parent.getCurrentName();
/*      */     } 
/*  207 */     return ctxt.getCurrentName();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearCurrentToken() {
/*  218 */     if (this._currToken != null) {
/*  219 */       this._lastClearedToken = this._currToken;
/*  220 */       this._currToken = null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public JsonToken getLastClearedToken() {
/*  225 */     return this._lastClearedToken;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void overrideCurrentName(String name) {
/*  232 */     throw new UnsupportedOperationException("Can not currently override name during filtering read");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonToken nextToken() throws IOException {
/*      */     boolean returnEnd;
/*      */     String name;
/*  252 */     if (!this._allowMultipleMatches && this._currToken != null && this._exposedContext == null)
/*      */     {
/*      */       
/*  255 */       if (this._currToken.isScalarValue() && !this._headContext.isStartHandled() && this._inclusion == TokenFilter.Inclusion.ONLY_INCLUDE_ALL && this._itemFilter == TokenFilter.INCLUDE_ALL)
/*      */       {
/*      */         
/*  258 */         return this._currToken = null;
/*      */       }
/*      */     }
/*      */     
/*  262 */     TokenFilterContext ctxt = this._exposedContext;
/*      */     
/*  264 */     if (ctxt != null) {
/*      */       while (true) {
/*  266 */         JsonToken jsonToken = ctxt.nextTokenToRead();
/*  267 */         if (jsonToken != null) {
/*  268 */           this._currToken = jsonToken;
/*  269 */           return jsonToken;
/*      */         } 
/*      */         
/*  272 */         if (ctxt == this._headContext) {
/*  273 */           this._exposedContext = null;
/*  274 */           if (ctxt.inArray()) {
/*  275 */             jsonToken = this.delegate.getCurrentToken();
/*  276 */             this._currToken = jsonToken;
/*  277 */             if (this._currToken == JsonToken.END_ARRAY) {
/*  278 */               this._headContext = this._headContext.getParent();
/*  279 */               this._itemFilter = this._headContext.getFilter();
/*      */             } 
/*  281 */             return jsonToken;
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  287 */           jsonToken = this.delegate.currentToken();
/*  288 */           if (jsonToken == JsonToken.END_OBJECT) {
/*  289 */             this._headContext = this._headContext.getParent();
/*  290 */             this._itemFilter = this._headContext.getFilter();
/*      */           } 
/*  292 */           if (jsonToken != JsonToken.FIELD_NAME) {
/*  293 */             this._currToken = jsonToken;
/*  294 */             return jsonToken;
/*      */           } 
/*      */           
/*      */           break;
/*      */         } 
/*  299 */         ctxt = this._headContext.findChildOf(ctxt);
/*  300 */         this._exposedContext = ctxt;
/*  301 */         if (ctxt == null) {
/*  302 */           throw _constructError("Unexpected problem: chain of filtered context broken");
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*  308 */     JsonToken t = this.delegate.nextToken();
/*  309 */     if (t == null) {
/*      */       
/*  311 */       this._currToken = t;
/*  312 */       return t;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  318 */     switch (t.id())
/*      */     { case 3:
/*  320 */         f = this._itemFilter;
/*  321 */         if (f == TokenFilter.INCLUDE_ALL) {
/*  322 */           this._headContext = this._headContext.createChildArrayContext(f, true);
/*  323 */           return this._currToken = t;
/*      */         } 
/*  325 */         if (f == null) {
/*  326 */           this.delegate.skipChildren();
/*      */         }
/*      */         else {
/*      */           
/*  330 */           f = this._headContext.checkValue(f);
/*  331 */           if (f == null) {
/*  332 */             this.delegate.skipChildren();
/*      */           } else {
/*      */             
/*  335 */             if (f != TokenFilter.INCLUDE_ALL) {
/*  336 */               f = f.filterStartArray();
/*      */             }
/*  338 */             this._itemFilter = f;
/*  339 */             if (f == TokenFilter.INCLUDE_ALL) {
/*  340 */               this._headContext = this._headContext.createChildArrayContext(f, true);
/*  341 */               return this._currToken = t;
/*  342 */             }  if (f != null && this._inclusion == TokenFilter.Inclusion.INCLUDE_NON_NULL) {
/*      */               
/*  344 */               this._headContext = this._headContext.createChildArrayContext(f, true);
/*  345 */               return this._currToken = t;
/*      */             } 
/*  347 */             this._headContext = this._headContext.createChildArrayContext(f, false);
/*      */ 
/*      */             
/*  350 */             if (this._inclusion == TokenFilter.Inclusion.INCLUDE_ALL_AND_PATH) {
/*  351 */               t = _nextTokenWithBuffering(this._headContext);
/*  352 */               if (t != null) {
/*  353 */                 this._currToken = t;
/*  354 */                 return t;
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  476 */         return _nextToken2();case 1: f = this._itemFilter; if (f == TokenFilter.INCLUDE_ALL) { this._headContext = this._headContext.createChildObjectContext(f, true); return this._currToken = t; }  if (f == null) { this.delegate.skipChildren(); } else { f = this._headContext.checkValue(f); if (f == null) { this.delegate.skipChildren(); } else { if (f != TokenFilter.INCLUDE_ALL) f = f.filterStartObject();  this._itemFilter = f; if (f == TokenFilter.INCLUDE_ALL) { this._headContext = this._headContext.createChildObjectContext(f, true); return this._currToken = t; }  if (f != null && this._inclusion == TokenFilter.Inclusion.INCLUDE_NON_NULL) { this._headContext = this._headContext.createChildObjectContext(f, true); return this._currToken = t; }  this._headContext = this._headContext.createChildObjectContext(f, false); if (this._inclusion == TokenFilter.Inclusion.INCLUDE_ALL_AND_PATH) { t = _nextTokenWithBuffering(this._headContext); if (t != null) { this._currToken = t; return t; }  }  }  }  return _nextToken2();case 2: case 4: returnEnd = this._headContext.isStartHandled(); f = this._headContext.getFilter(); if (f != null && f != TokenFilter.INCLUDE_ALL) f.filterFinishArray();  this._headContext = this._headContext.getParent(); this._itemFilter = this._headContext.getFilter(); if (returnEnd) return this._currToken = t;  return _nextToken2();case 5: name = this.delegate.getCurrentName(); f = this._headContext.setFieldName(name); if (f == TokenFilter.INCLUDE_ALL) { this._itemFilter = f; return this._currToken = t; }  if (f == null) { this.delegate.nextToken(); this.delegate.skipChildren(); } else { f = f.includeProperty(name); if (f == null) { this.delegate.nextToken(); this.delegate.skipChildren(); } else { this._itemFilter = f; if (f == TokenFilter.INCLUDE_ALL) if (_verifyAllowedMatches()) { if (this._inclusion == TokenFilter.Inclusion.INCLUDE_ALL_AND_PATH) return this._currToken = t;  } else { this.delegate.nextToken(); this.delegate.skipChildren(); }   if (this._inclusion != TokenFilter.Inclusion.ONLY_INCLUDE_ALL) { t = _nextTokenWithBuffering(this._headContext); if (t != null) { this._currToken = t; return t; }  }  }  }  return _nextToken2(); }  TokenFilter f = this._itemFilter; if (f == TokenFilter.INCLUDE_ALL) return this._currToken = t;  if (f != null) { f = this._headContext.checkValue(f); if ((f == TokenFilter.INCLUDE_ALL || (f != null && f.includeValue(this.delegate))) && _verifyAllowedMatches()) return this._currToken = t;  }  return _nextToken2();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final JsonToken _nextToken2() throws IOException {
/*      */     while (true) {
/*      */       boolean returnEnd;
/*      */       String name;
/*  487 */       JsonToken t = this.delegate.nextToken();
/*  488 */       if (t == null) {
/*  489 */         this._currToken = t;
/*  490 */         return t;
/*      */       } 
/*      */ 
/*      */       
/*  494 */       switch (t.id()) {
/*      */         case 3:
/*  496 */           f = this._itemFilter;
/*  497 */           if (f == TokenFilter.INCLUDE_ALL) {
/*  498 */             this._headContext = this._headContext.createChildArrayContext(f, true);
/*  499 */             return this._currToken = t;
/*      */           } 
/*  501 */           if (f == null) {
/*  502 */             this.delegate.skipChildren();
/*      */             
/*      */             continue;
/*      */           } 
/*  506 */           f = this._headContext.checkValue(f);
/*  507 */           if (f == null) {
/*  508 */             this.delegate.skipChildren();
/*      */             continue;
/*      */           } 
/*  511 */           if (f != TokenFilter.INCLUDE_ALL) {
/*  512 */             f = f.filterStartArray();
/*      */           }
/*  514 */           this._itemFilter = f;
/*  515 */           if (f == TokenFilter.INCLUDE_ALL) {
/*  516 */             this._headContext = this._headContext.createChildArrayContext(f, true);
/*  517 */             return this._currToken = t;
/*  518 */           }  if (f != null && this._inclusion == TokenFilter.Inclusion.INCLUDE_NON_NULL) {
/*  519 */             this._headContext = this._headContext.createChildArrayContext(f, true);
/*  520 */             return this._currToken = t;
/*      */           } 
/*  522 */           this._headContext = this._headContext.createChildArrayContext(f, false);
/*      */           
/*  524 */           if (this._inclusion == TokenFilter.Inclusion.INCLUDE_ALL_AND_PATH) {
/*  525 */             t = _nextTokenWithBuffering(this._headContext);
/*  526 */             if (t != null) {
/*  527 */               this._currToken = t;
/*  528 */               return t;
/*      */             } 
/*      */           } 
/*      */           continue;
/*      */         
/*      */         case 1:
/*  534 */           f = this._itemFilter;
/*  535 */           if (f == TokenFilter.INCLUDE_ALL) {
/*  536 */             this._headContext = this._headContext.createChildObjectContext(f, true);
/*  537 */             return this._currToken = t;
/*      */           } 
/*  539 */           if (f == null) {
/*  540 */             this.delegate.skipChildren();
/*      */             
/*      */             continue;
/*      */           } 
/*  544 */           f = this._headContext.checkValue(f);
/*  545 */           if (f == null) {
/*  546 */             this.delegate.skipChildren();
/*      */             continue;
/*      */           } 
/*  549 */           if (f != TokenFilter.INCLUDE_ALL) {
/*  550 */             f = f.filterStartObject();
/*      */           }
/*  552 */           this._itemFilter = f;
/*  553 */           if (f == TokenFilter.INCLUDE_ALL) {
/*  554 */             this._headContext = this._headContext.createChildObjectContext(f, true);
/*  555 */             return this._currToken = t;
/*  556 */           }  if (f != null && this._inclusion == TokenFilter.Inclusion.INCLUDE_NON_NULL) {
/*  557 */             this._headContext = this._headContext.createChildObjectContext(f, true);
/*  558 */             return this._currToken = t;
/*      */           } 
/*  560 */           this._headContext = this._headContext.createChildObjectContext(f, false);
/*  561 */           if (this._inclusion == TokenFilter.Inclusion.INCLUDE_ALL_AND_PATH) {
/*  562 */             t = _nextTokenWithBuffering(this._headContext);
/*  563 */             if (t != null) {
/*  564 */               this._currToken = t;
/*  565 */               return t;
/*      */             } 
/*      */           } 
/*      */           continue;
/*      */ 
/*      */         
/*      */         case 4:
/*  572 */           returnEnd = this._headContext.isStartHandled();
/*  573 */           f = this._headContext.getFilter();
/*  574 */           if (f != null && f != TokenFilter.INCLUDE_ALL) {
/*  575 */             boolean includeEmpty = f.includeEmptyArray(this._headContext.hasCurrentIndex());
/*  576 */             f.filterFinishArray();
/*  577 */             if (includeEmpty) {
/*  578 */               return _nextBuffered(this._headContext);
/*      */             }
/*      */           } 
/*  581 */           this._headContext = this._headContext.getParent();
/*  582 */           this._itemFilter = this._headContext.getFilter();
/*  583 */           if (returnEnd) {
/*  584 */             return this._currToken = t;
/*      */           }
/*      */           continue;
/*      */ 
/*      */         
/*      */         case 2:
/*  590 */           returnEnd = this._headContext.isStartHandled();
/*  591 */           f = this._headContext.getFilter();
/*  592 */           if (f != null && f != TokenFilter.INCLUDE_ALL) {
/*  593 */             boolean includeEmpty = f.includeEmptyArray(this._headContext.hasCurrentName());
/*  594 */             f.filterFinishObject();
/*  595 */             if (includeEmpty)
/*  596 */               return _nextBuffered(this._headContext); 
/*      */           } 
/*  598 */           this._headContext = this._headContext.getParent();
/*  599 */           this._itemFilter = this._headContext.getFilter();
/*  600 */           if (returnEnd) {
/*  601 */             return this._currToken = t;
/*      */           }
/*      */           continue;
/*      */ 
/*      */ 
/*      */         
/*      */         case 5:
/*  608 */           name = this.delegate.getCurrentName();
/*  609 */           f = this._headContext.setFieldName(name);
/*  610 */           if (f == TokenFilter.INCLUDE_ALL) {
/*  611 */             this._itemFilter = f;
/*  612 */             return this._currToken = t;
/*      */           } 
/*  614 */           if (f == null) {
/*  615 */             this.delegate.nextToken();
/*  616 */             this.delegate.skipChildren();
/*      */             continue;
/*      */           } 
/*  619 */           f = f.includeProperty(name);
/*  620 */           if (f == null) {
/*  621 */             this.delegate.nextToken();
/*  622 */             this.delegate.skipChildren();
/*      */             continue;
/*      */           } 
/*  625 */           this._itemFilter = f;
/*  626 */           if (f == TokenFilter.INCLUDE_ALL) {
/*  627 */             if (_verifyAllowedMatches()) {
/*  628 */               if (this._inclusion == TokenFilter.Inclusion.INCLUDE_ALL_AND_PATH)
/*  629 */                 return this._currToken = t; 
/*      */               continue;
/*      */             } 
/*  632 */             this.delegate.nextToken();
/*  633 */             this.delegate.skipChildren();
/*      */             
/*      */             continue;
/*      */           } 
/*  637 */           if (this._inclusion != TokenFilter.Inclusion.ONLY_INCLUDE_ALL) {
/*  638 */             t = _nextTokenWithBuffering(this._headContext);
/*  639 */             if (t != null) {
/*  640 */               this._currToken = t;
/*  641 */               return t;
/*      */             } 
/*      */           } 
/*      */           continue;
/*      */       } 
/*      */ 
/*      */       
/*  648 */       TokenFilter f = this._itemFilter;
/*  649 */       if (f == TokenFilter.INCLUDE_ALL) {
/*  650 */         return this._currToken = t;
/*      */       }
/*  652 */       if (f != null) {
/*  653 */         f = this._headContext.checkValue(f);
/*  654 */         if ((f == TokenFilter.INCLUDE_ALL || (f != null && f
/*  655 */           .includeValue(this.delegate))) && 
/*  656 */           _verifyAllowedMatches()) {
/*  657 */           return this._currToken = t;
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final JsonToken _nextTokenWithBuffering(TokenFilterContext buffRoot) throws IOException {
/*      */     while (true) {
/*      */       boolean gotEnd;
/*      */       String name;
/*      */       boolean returnEnd;
/*  673 */       JsonToken t = this.delegate.nextToken();
/*  674 */       if (t == null) {
/*  675 */         return t;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  683 */       switch (t.id()) {
/*      */         case 3:
/*  685 */           f = this._headContext.checkValue(this._itemFilter);
/*  686 */           if (f == null) {
/*  687 */             this.delegate.skipChildren();
/*      */             continue;
/*      */           } 
/*  690 */           if (f != TokenFilter.INCLUDE_ALL) {
/*  691 */             f = f.filterStartArray();
/*      */           }
/*  693 */           this._itemFilter = f;
/*  694 */           if (f == TokenFilter.INCLUDE_ALL) {
/*  695 */             this._headContext = this._headContext.createChildArrayContext(f, true);
/*  696 */             return _nextBuffered(buffRoot);
/*  697 */           }  if (f != null && this._inclusion == TokenFilter.Inclusion.INCLUDE_NON_NULL) {
/*      */             
/*  699 */             this._headContext = this._headContext.createChildArrayContext(f, true);
/*  700 */             return _nextBuffered(buffRoot);
/*      */           } 
/*  702 */           this._headContext = this._headContext.createChildArrayContext(f, false);
/*      */           continue;
/*      */         
/*      */         case 1:
/*  706 */           f = this._itemFilter;
/*  707 */           if (f == TokenFilter.INCLUDE_ALL) {
/*  708 */             this._headContext = this._headContext.createChildObjectContext(f, true);
/*  709 */             return t;
/*      */           } 
/*  711 */           if (f == null) {
/*  712 */             this.delegate.skipChildren();
/*      */             
/*      */             continue;
/*      */           } 
/*  716 */           f = this._headContext.checkValue(f);
/*  717 */           if (f == null) {
/*  718 */             this.delegate.skipChildren();
/*      */             continue;
/*      */           } 
/*  721 */           if (f != TokenFilter.INCLUDE_ALL) {
/*  722 */             f = f.filterStartObject();
/*      */           }
/*  724 */           this._itemFilter = f;
/*  725 */           if (f == TokenFilter.INCLUDE_ALL) {
/*  726 */             this._headContext = this._headContext.createChildObjectContext(f, true);
/*  727 */             return _nextBuffered(buffRoot);
/*  728 */           }  if (f != null && this._inclusion == TokenFilter.Inclusion.INCLUDE_NON_NULL) {
/*      */             
/*  730 */             this._headContext = this._headContext.createChildArrayContext(f, true);
/*  731 */             return _nextBuffered(buffRoot);
/*      */           } 
/*  733 */           this._headContext = this._headContext.createChildObjectContext(f, false);
/*      */           continue;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 4:
/*  740 */           f = this._headContext.getFilter();
/*  741 */           if (f != null && f != TokenFilter.INCLUDE_ALL) {
/*  742 */             boolean includeEmpty = f.includeEmptyArray(this._headContext.hasCurrentIndex());
/*  743 */             f.filterFinishArray();
/*  744 */             if (includeEmpty) {
/*  745 */               return _nextBuffered(buffRoot);
/*      */             }
/*      */           } 
/*  748 */           gotEnd = (this._headContext == buffRoot);
/*  749 */           returnEnd = (gotEnd && this._headContext.isStartHandled());
/*      */           
/*  751 */           this._headContext = this._headContext.getParent();
/*  752 */           this._itemFilter = this._headContext.getFilter();
/*      */           
/*  754 */           if (returnEnd) {
/*  755 */             return t;
/*      */           }
/*  757 */           if (gotEnd) {
/*  758 */             return null;
/*      */           }
/*      */           continue;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 2:
/*  766 */           f = this._headContext.getFilter();
/*  767 */           if (f != null && f != TokenFilter.INCLUDE_ALL) {
/*  768 */             boolean includeEmpty = f.includeEmptyObject(this._headContext.hasCurrentName());
/*  769 */             f.filterFinishObject();
/*  770 */             if (includeEmpty) {
/*  771 */               this._headContext._currentName = (this._headContext._parent == null) ? null : this._headContext._parent._currentName;
/*      */ 
/*      */               
/*  774 */               this._headContext._needToHandleName = false;
/*  775 */               return _nextBuffered(buffRoot);
/*      */             } 
/*      */           } 
/*  778 */           gotEnd = (this._headContext == buffRoot);
/*  779 */           returnEnd = (gotEnd && this._headContext.isStartHandled());
/*      */           
/*  781 */           this._headContext = this._headContext.getParent();
/*  782 */           this._itemFilter = this._headContext.getFilter();
/*      */           
/*  784 */           if (returnEnd) {
/*  785 */             return t;
/*      */           }
/*  787 */           if (gotEnd) {
/*  788 */             return null;
/*      */           }
/*      */           continue;
/*      */ 
/*      */ 
/*      */         
/*      */         case 5:
/*  795 */           name = this.delegate.getCurrentName();
/*  796 */           f = this._headContext.setFieldName(name);
/*  797 */           if (f == TokenFilter.INCLUDE_ALL) {
/*  798 */             this._itemFilter = f;
/*  799 */             return _nextBuffered(buffRoot);
/*      */           } 
/*  801 */           if (f == null) {
/*  802 */             this.delegate.nextToken();
/*  803 */             this.delegate.skipChildren();
/*      */             continue;
/*      */           } 
/*  806 */           f = f.includeProperty(name);
/*  807 */           if (f == null) {
/*  808 */             this.delegate.nextToken();
/*  809 */             this.delegate.skipChildren();
/*      */             continue;
/*      */           } 
/*  812 */           this._itemFilter = f;
/*  813 */           if (f == TokenFilter.INCLUDE_ALL) {
/*  814 */             if (_verifyAllowedMatches()) {
/*  815 */               return _nextBuffered(buffRoot);
/*      */             }
/*      */ 
/*      */             
/*  819 */             this._itemFilter = this._headContext.setFieldName(name);
/*      */           } 
/*      */           continue;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  826 */       TokenFilter f = this._itemFilter;
/*  827 */       if (f == TokenFilter.INCLUDE_ALL) {
/*  828 */         return _nextBuffered(buffRoot);
/*      */       }
/*  830 */       if (f != null) {
/*  831 */         f = this._headContext.checkValue(f);
/*  832 */         if ((f == TokenFilter.INCLUDE_ALL || (f != null && f
/*  833 */           .includeValue(this.delegate))) && 
/*  834 */           _verifyAllowedMatches()) {
/*  835 */           return _nextBuffered(buffRoot);
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private JsonToken _nextBuffered(TokenFilterContext buffRoot) throws IOException {
/*  847 */     this._exposedContext = buffRoot;
/*  848 */     TokenFilterContext ctxt = buffRoot;
/*  849 */     JsonToken t = ctxt.nextTokenToRead();
/*  850 */     if (t != null) {
/*  851 */       return t;
/*      */     }
/*      */     
/*      */     while (true) {
/*  855 */       if (ctxt == this._headContext) {
/*  856 */         throw _constructError("Internal error: failed to locate expected buffered tokens");
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  863 */       ctxt = this._exposedContext.findChildOf(ctxt);
/*  864 */       this._exposedContext = ctxt;
/*  865 */       if (ctxt == null) {
/*  866 */         throw _constructError("Unexpected problem: chain of filtered context broken");
/*      */       }
/*  868 */       t = this._exposedContext.nextTokenToRead();
/*  869 */       if (t != null) {
/*  870 */         return t;
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   private final boolean _verifyAllowedMatches() throws IOException {
/*  876 */     if (this._matchCount == 0 || this._allowMultipleMatches) {
/*  877 */       this._matchCount++;
/*  878 */       return true;
/*      */     } 
/*  880 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonToken nextValue() throws IOException {
/*  886 */     JsonToken t = nextToken();
/*  887 */     if (t == JsonToken.FIELD_NAME) {
/*  888 */       t = nextToken();
/*      */     }
/*  890 */     return t;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser skipChildren() throws IOException {
/*  901 */     if (this._currToken != JsonToken.START_OBJECT && this._currToken != JsonToken.START_ARRAY)
/*      */     {
/*  903 */       return (JsonParser)this;
/*      */     }
/*  905 */     int open = 1;
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/*  910 */       JsonToken t = nextToken();
/*  911 */       if (t == null) {
/*  912 */         return (JsonParser)this;
/*      */       }
/*  914 */       if (t.isStructStart()) {
/*  915 */         open++; continue;
/*  916 */       }  if (t.isStructEnd() && 
/*  917 */         --open == 0) {
/*  918 */         return (JsonParser)this;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getText() throws IOException {
/*  934 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  935 */       return currentName();
/*      */     }
/*  937 */     return this.delegate.getText();
/*      */   }
/*      */   
/*      */   public boolean hasTextCharacters() {
/*  941 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  942 */       return false;
/*      */     }
/*  944 */     return this.delegate.hasTextCharacters();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public char[] getTextCharacters() throws IOException {
/*  950 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  951 */       return currentName().toCharArray();
/*      */     }
/*  953 */     return this.delegate.getTextCharacters();
/*      */   }
/*      */   
/*      */   public int getTextLength() throws IOException {
/*  957 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  958 */       return currentName().length();
/*      */     }
/*  960 */     return this.delegate.getTextLength();
/*      */   }
/*      */   public int getTextOffset() throws IOException {
/*  963 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  964 */       return 0;
/*      */     }
/*  966 */     return this.delegate.getTextOffset();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BigInteger getBigIntegerValue() throws IOException {
/*  976 */     return this.delegate.getBigIntegerValue();
/*      */   }
/*      */   public boolean getBooleanValue() throws IOException {
/*  979 */     return this.delegate.getBooleanValue();
/*      */   }
/*      */   public byte getByteValue() throws IOException {
/*  982 */     return this.delegate.getByteValue();
/*      */   }
/*      */   public short getShortValue() throws IOException {
/*  985 */     return this.delegate.getShortValue();
/*      */   }
/*      */   public BigDecimal getDecimalValue() throws IOException {
/*  988 */     return this.delegate.getDecimalValue();
/*      */   }
/*      */   public double getDoubleValue() throws IOException {
/*  991 */     return this.delegate.getDoubleValue();
/*      */   }
/*      */   public float getFloatValue() throws IOException {
/*  994 */     return this.delegate.getFloatValue();
/*      */   }
/*      */   public int getIntValue() throws IOException {
/*  997 */     return this.delegate.getIntValue();
/*      */   }
/*      */   public long getLongValue() throws IOException {
/* 1000 */     return this.delegate.getLongValue();
/*      */   }
/*      */   public JsonParser.NumberType getNumberType() throws IOException {
/* 1003 */     return this.delegate.getNumberType();
/*      */   }
/*      */   public Number getNumberValue() throws IOException {
/* 1006 */     return this.delegate.getNumberValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getValueAsInt() throws IOException {
/* 1014 */     return this.delegate.getValueAsInt();
/* 1015 */   } public int getValueAsInt(int defaultValue) throws IOException { return this.delegate.getValueAsInt(defaultValue); }
/* 1016 */   public long getValueAsLong() throws IOException { return this.delegate.getValueAsLong(); }
/* 1017 */   public long getValueAsLong(long defaultValue) throws IOException { return this.delegate.getValueAsLong(defaultValue); }
/* 1018 */   public double getValueAsDouble() throws IOException { return this.delegate.getValueAsDouble(); }
/* 1019 */   public double getValueAsDouble(double defaultValue) throws IOException { return this.delegate.getValueAsDouble(defaultValue); }
/* 1020 */   public boolean getValueAsBoolean() throws IOException { return this.delegate.getValueAsBoolean(); } public boolean getValueAsBoolean(boolean defaultValue) throws IOException {
/* 1021 */     return this.delegate.getValueAsBoolean(defaultValue);
/*      */   }
/*      */   public String getValueAsString() throws IOException {
/* 1024 */     if (this._currToken == JsonToken.FIELD_NAME) {
/* 1025 */       return currentName();
/*      */     }
/* 1027 */     return this.delegate.getValueAsString();
/*      */   }
/*      */   public String getValueAsString(String defaultValue) throws IOException {
/* 1030 */     if (this._currToken == JsonToken.FIELD_NAME) {
/* 1031 */       return currentName();
/*      */     }
/* 1033 */     return this.delegate.getValueAsString(defaultValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getEmbeddedObject() throws IOException {
/* 1042 */     return this.delegate.getEmbeddedObject();
/* 1043 */   } public byte[] getBinaryValue(Base64Variant b64variant) throws IOException { return this.delegate.getBinaryValue(b64variant); }
/* 1044 */   public int readBinaryValue(Base64Variant b64variant, OutputStream out) throws IOException { return this.delegate.readBinaryValue(b64variant, out); } public JsonLocation getTokenLocation() {
/* 1045 */     return this.delegate.getTokenLocation();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonStreamContext _filterContext() {
/* 1054 */     if (this._exposedContext != null) {
/* 1055 */       return this._exposedContext;
/*      */     }
/* 1057 */     return this._headContext;
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-core-2.14.2.jar!\com\fasterxml\jackson\core\filter\FilteringParserDelegate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */