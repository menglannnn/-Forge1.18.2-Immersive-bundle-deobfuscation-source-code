/*    */ package com.fasterxml.jackson.core.io;
/*    */ 
/*    */ import com.fasterxml.jackson.core.util.BufferRecycler;
/*    */ import com.fasterxml.jackson.core.util.TextBuffer;
/*    */ import java.io.IOException;
/*    */ import java.io.Writer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SegmentedStringWriter
/*    */   extends Writer
/*    */ {
/*    */   private final TextBuffer _buffer;
/*    */   
/*    */   public SegmentedStringWriter(BufferRecycler br) {
/* 22 */     this._buffer = new TextBuffer(br);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Writer append(char c) {
/* 33 */     write(c);
/* 34 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public Writer append(CharSequence csq) {
/* 39 */     String str = csq.toString();
/* 40 */     this._buffer.append(str, 0, str.length());
/* 41 */     return this;
/*    */   }
/*    */   public void close() {}
/*    */   
/*    */   public Writer append(CharSequence csq, int start, int end) {
/* 46 */     String str = csq.subSequence(start, end).toString();
/* 47 */     this._buffer.append(str, 0, str.length());
/* 48 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public void flush() {}
/*    */   
/*    */   public void write(char[] cbuf) {
/* 55 */     this._buffer.append(cbuf, 0, cbuf.length);
/*    */   }
/*    */   public void write(char[] cbuf, int off, int len) {
/* 58 */     this._buffer.append(cbuf, off, len);
/*    */   }
/*    */   public void write(int c) {
/* 61 */     this._buffer.append((char)c);
/*    */   }
/*    */   public void write(String str) {
/* 64 */     this._buffer.append(str, 0, str.length());
/*    */   }
/*    */   public void write(String str, int off, int len) {
/* 67 */     this._buffer.append(str, off, len);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getAndClear() {
/* 85 */     String result = this._buffer.contentsAsString();
/* 86 */     this._buffer.releaseBuffers();
/* 87 */     return result;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-core-2.14.2.jar!\com\fasterxml\jackson\core\io\SegmentedStringWriter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */