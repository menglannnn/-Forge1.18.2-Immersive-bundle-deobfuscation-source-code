/*      */ package com.fasterxml.jackson.core.json;
/*      */ import com.fasterxml.jackson.core.Base64Variant;
/*      */ import com.fasterxml.jackson.core.JsonLocation;
/*      */ import com.fasterxml.jackson.core.JsonParseException;
/*      */ import com.fasterxml.jackson.core.JsonParser;
/*      */ import com.fasterxml.jackson.core.JsonToken;
/*      */ import com.fasterxml.jackson.core.ObjectCodec;
/*      */ import com.fasterxml.jackson.core.SerializableString;
/*      */ import com.fasterxml.jackson.core.StreamReadCapability;
/*      */ import com.fasterxml.jackson.core.base.ParserBase;
/*      */ import com.fasterxml.jackson.core.io.CharTypes;
/*      */ import com.fasterxml.jackson.core.io.IOContext;
/*      */ import com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer;
/*      */ import com.fasterxml.jackson.core.util.ByteArrayBuilder;
/*      */ import com.fasterxml.jackson.core.util.JacksonFeatureSet;
/*      */ import com.fasterxml.jackson.core.util.TextBuffer;
/*      */ import java.io.IOException;
/*      */ import java.io.OutputStream;
/*      */ import java.io.Reader;
/*      */ import java.io.Writer;
/*      */ 
/*      */ public class ReaderBasedJsonParser extends ParserBase {
/*   23 */   private static final int FEAT_MASK_TRAILING_COMMA = JsonParser.Feature.ALLOW_TRAILING_COMMA.getMask();
/*      */ 
/*      */   
/*   26 */   private static final int FEAT_MASK_LEADING_ZEROS = JsonParser.Feature.ALLOW_NUMERIC_LEADING_ZEROS.getMask();
/*      */ 
/*      */   
/*   29 */   private static final int FEAT_MASK_NON_NUM_NUMBERS = JsonParser.Feature.ALLOW_NON_NUMERIC_NUMBERS.getMask();
/*      */ 
/*      */   
/*   32 */   private static final int FEAT_MASK_ALLOW_MISSING = JsonParser.Feature.ALLOW_MISSING_VALUES.getMask();
/*   33 */   private static final int FEAT_MASK_ALLOW_SINGLE_QUOTES = JsonParser.Feature.ALLOW_SINGLE_QUOTES.getMask();
/*   34 */   private static final int FEAT_MASK_ALLOW_UNQUOTED_NAMES = JsonParser.Feature.ALLOW_UNQUOTED_FIELD_NAMES.getMask();
/*      */   
/*   36 */   private static final int FEAT_MASK_ALLOW_JAVA_COMMENTS = JsonParser.Feature.ALLOW_COMMENTS.getMask();
/*   37 */   private static final int FEAT_MASK_ALLOW_YAML_COMMENTS = JsonParser.Feature.ALLOW_YAML_COMMENTS.getMask();
/*      */ 
/*      */ 
/*      */   
/*   41 */   protected static final int[] _icLatin1 = CharTypes.getInputCodeLatin1();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Reader _reader;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected char[] _inputBuffer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _bufferRecyclable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ObjectCodec _objectCodec;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final CharsToNameCanonicalizer _symbols;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final int _hashSeed;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _tokenIncomplete;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected long _nameStartOffset;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _nameStartRow;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _nameStartCol;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ReaderBasedJsonParser(IOContext ctxt, int features, Reader r, ObjectCodec codec, CharsToNameCanonicalizer st, char[] inputBuffer, int start, int end, boolean bufferRecyclable) {
/*  145 */     super(ctxt, features);
/*  146 */     this._reader = r;
/*  147 */     this._objectCodec = codec;
/*  148 */     this._inputBuffer = inputBuffer;
/*  149 */     this._inputPtr = start;
/*  150 */     this._inputEnd = end;
/*  151 */     this._currInputRowStart = start;
/*      */     
/*  153 */     this._currInputProcessed = -start;
/*  154 */     this._symbols = st;
/*  155 */     this._hashSeed = st.hashSeed();
/*  156 */     this._bufferRecyclable = bufferRecyclable;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ReaderBasedJsonParser(IOContext ctxt, int features, Reader r, ObjectCodec codec, CharsToNameCanonicalizer st) {
/*  172 */     super(ctxt, features);
/*  173 */     this._reader = r;
/*  174 */     this._inputBuffer = ctxt.allocTokenBuffer();
/*  175 */     this._inputPtr = 0;
/*  176 */     this._inputEnd = 0;
/*  177 */     this._objectCodec = codec;
/*  178 */     this._symbols = st;
/*  179 */     this._hashSeed = st.hashSeed();
/*  180 */     this._bufferRecyclable = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectCodec getCodec() {
/*  189 */     return this._objectCodec; } public void setCodec(ObjectCodec c) {
/*  190 */     this._objectCodec = c;
/*      */   }
/*      */   
/*      */   public JacksonFeatureSet<StreamReadCapability> getReadCapabilities() {
/*  194 */     return JSON_READ_CAPABILITIES;
/*      */   }
/*      */ 
/*      */   
/*      */   public int releaseBuffered(Writer w) throws IOException {
/*  199 */     int count = this._inputEnd - this._inputPtr;
/*  200 */     if (count < 1) return 0;
/*      */     
/*  202 */     int origPtr = this._inputPtr;
/*  203 */     this._inputPtr += count;
/*  204 */     w.write(this._inputBuffer, origPtr, count);
/*  205 */     return count;
/*      */   }
/*      */   public Object getInputSource() {
/*  208 */     return this._reader;
/*      */   }
/*      */   @Deprecated
/*      */   protected char getNextChar(String eofMsg) throws IOException {
/*  212 */     return getNextChar(eofMsg, (JsonToken)null);
/*      */   }
/*      */   
/*      */   protected char getNextChar(String eofMsg, JsonToken forToken) throws IOException {
/*  216 */     if (this._inputPtr >= this._inputEnd && 
/*  217 */       !_loadMore()) {
/*  218 */       _reportInvalidEOF(eofMsg, forToken);
/*      */     }
/*      */     
/*  221 */     return this._inputBuffer[this._inputPtr++];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _closeInput() throws IOException {
/*  233 */     if (this._reader != null) {
/*  234 */       if (this._ioContext.isResourceManaged() || isEnabled(JsonParser.Feature.AUTO_CLOSE_SOURCE)) {
/*  235 */         this._reader.close();
/*      */       }
/*  237 */       this._reader = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _releaseBuffers() throws IOException {
/*  250 */     super._releaseBuffers();
/*      */     
/*  252 */     this._symbols.release();
/*      */     
/*  254 */     if (this._bufferRecyclable) {
/*  255 */       char[] buf = this._inputBuffer;
/*  256 */       if (buf != null) {
/*  257 */         this._inputBuffer = null;
/*  258 */         this._ioContext.releaseTokenBuffer(buf);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _loadMoreGuaranteed() throws IOException {
/*  270 */     if (!_loadMore()) _reportInvalidEOF();
/*      */   
/*      */   }
/*      */   
/*      */   protected boolean _loadMore() throws IOException {
/*  275 */     if (this._reader != null) {
/*  276 */       int count = this._reader.read(this._inputBuffer, 0, this._inputBuffer.length);
/*  277 */       if (count > 0) {
/*  278 */         int bufSize = this._inputEnd;
/*  279 */         this._currInputProcessed += bufSize;
/*  280 */         this._currInputRowStart -= bufSize;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  285 */         this._nameStartOffset -= bufSize;
/*      */         
/*  287 */         this._inputPtr = 0;
/*  288 */         this._inputEnd = count;
/*      */         
/*  290 */         return true;
/*      */       } 
/*      */       
/*  293 */       _closeInput();
/*      */       
/*  295 */       if (count == 0) {
/*  296 */         throw new IOException("Reader returned 0 characters when trying to read " + this._inputEnd);
/*      */       }
/*      */     } 
/*  299 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String getText() throws IOException {
/*  317 */     if (this._currToken == JsonToken.VALUE_STRING) {
/*  318 */       if (this._tokenIncomplete) {
/*  319 */         this._tokenIncomplete = false;
/*  320 */         _finishString();
/*      */       } 
/*  322 */       return this._textBuffer.contentsAsString();
/*      */     } 
/*  324 */     return _getText2(this._currToken);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getText(Writer writer) throws IOException {
/*  330 */     JsonToken t = this._currToken;
/*  331 */     if (t == JsonToken.VALUE_STRING) {
/*  332 */       if (this._tokenIncomplete) {
/*  333 */         this._tokenIncomplete = false;
/*  334 */         _finishString();
/*      */       } 
/*  336 */       return this._textBuffer.contentsToWriter(writer);
/*      */     } 
/*  338 */     if (t == JsonToken.FIELD_NAME) {
/*  339 */       String n = this._parsingContext.getCurrentName();
/*  340 */       writer.write(n);
/*  341 */       return n.length();
/*      */     } 
/*  343 */     if (t != null) {
/*  344 */       if (t.isNumeric()) {
/*  345 */         return this._textBuffer.contentsToWriter(writer);
/*      */       }
/*  347 */       char[] ch = t.asCharArray();
/*  348 */       writer.write(ch);
/*  349 */       return ch.length;
/*      */     } 
/*  351 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String getValueAsString() throws IOException {
/*  360 */     if (this._currToken == JsonToken.VALUE_STRING) {
/*  361 */       if (this._tokenIncomplete) {
/*  362 */         this._tokenIncomplete = false;
/*  363 */         _finishString();
/*      */       } 
/*  365 */       return this._textBuffer.contentsAsString();
/*      */     } 
/*  367 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  368 */       return getCurrentName();
/*      */     }
/*  370 */     return super.getValueAsString(null);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final String getValueAsString(String defValue) throws IOException {
/*  376 */     if (this._currToken == JsonToken.VALUE_STRING) {
/*  377 */       if (this._tokenIncomplete) {
/*  378 */         this._tokenIncomplete = false;
/*  379 */         _finishString();
/*      */       } 
/*  381 */       return this._textBuffer.contentsAsString();
/*      */     } 
/*  383 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  384 */       return getCurrentName();
/*      */     }
/*  386 */     return super.getValueAsString(defValue);
/*      */   }
/*      */   
/*      */   protected final String _getText2(JsonToken t) {
/*  390 */     if (t == null) {
/*  391 */       return null;
/*      */     }
/*  393 */     switch (t.id()) {
/*      */       case 5:
/*  395 */         return this._parsingContext.getCurrentName();
/*      */ 
/*      */       
/*      */       case 6:
/*      */       case 7:
/*      */       case 8:
/*  401 */         return this._textBuffer.contentsAsString();
/*      */     } 
/*  403 */     return t.asString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final char[] getTextCharacters() throws IOException {
/*  410 */     if (this._currToken != null) {
/*  411 */       switch (this._currToken.id()) {
/*      */         case 5:
/*  413 */           if (!this._nameCopied) {
/*  414 */             String name = this._parsingContext.getCurrentName();
/*  415 */             int nameLen = name.length();
/*  416 */             if (this._nameCopyBuffer == null) {
/*  417 */               this._nameCopyBuffer = this._ioContext.allocNameCopyBuffer(nameLen);
/*  418 */             } else if (this._nameCopyBuffer.length < nameLen) {
/*  419 */               this._nameCopyBuffer = new char[nameLen];
/*      */             } 
/*  421 */             name.getChars(0, nameLen, this._nameCopyBuffer, 0);
/*  422 */             this._nameCopied = true;
/*      */           } 
/*  424 */           return this._nameCopyBuffer;
/*      */         case 6:
/*  426 */           if (this._tokenIncomplete) {
/*  427 */             this._tokenIncomplete = false;
/*  428 */             _finishString();
/*      */           } 
/*      */         
/*      */         case 7:
/*      */         case 8:
/*  433 */           return this._textBuffer.getTextBuffer();
/*      */       } 
/*  435 */       return this._currToken.asCharArray();
/*      */     } 
/*      */     
/*  438 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getTextLength() throws IOException {
/*  444 */     if (this._currToken != null) {
/*  445 */       switch (this._currToken.id()) {
/*      */         case 5:
/*  447 */           return this._parsingContext.getCurrentName().length();
/*      */         case 6:
/*  449 */           if (this._tokenIncomplete) {
/*  450 */             this._tokenIncomplete = false;
/*  451 */             _finishString();
/*      */           } 
/*      */         
/*      */         case 7:
/*      */         case 8:
/*  456 */           return this._textBuffer.size();
/*      */       } 
/*  458 */       return (this._currToken.asCharArray()).length;
/*      */     } 
/*      */     
/*  461 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getTextOffset() throws IOException {
/*  468 */     if (this._currToken != null) {
/*  469 */       switch (this._currToken.id()) {
/*      */         case 5:
/*  471 */           return 0;
/*      */         case 6:
/*  473 */           if (this._tokenIncomplete) {
/*  474 */             this._tokenIncomplete = false;
/*  475 */             _finishString();
/*      */           } 
/*      */         
/*      */         case 7:
/*      */         case 8:
/*  480 */           return this._textBuffer.getTextOffset();
/*      */       } 
/*      */     
/*      */     }
/*  484 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] getBinaryValue(Base64Variant b64variant) throws IOException {
/*  490 */     if (this._currToken == JsonToken.VALUE_EMBEDDED_OBJECT && this._binaryValue != null) {
/*  491 */       return this._binaryValue;
/*      */     }
/*  493 */     if (this._currToken != JsonToken.VALUE_STRING) {
/*  494 */       _reportError("Current token (" + this._currToken + ") not VALUE_STRING or VALUE_EMBEDDED_OBJECT, can not access as binary");
/*      */     }
/*      */     
/*  497 */     if (this._tokenIncomplete) {
/*      */       try {
/*  499 */         this._binaryValue = _decodeBase64(b64variant);
/*  500 */       } catch (IllegalArgumentException iae) {
/*  501 */         throw _constructError("Failed to decode VALUE_STRING as base64 (" + b64variant + "): " + iae.getMessage());
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  506 */       this._tokenIncomplete = false;
/*      */     }
/*  508 */     else if (this._binaryValue == null) {
/*      */       
/*  510 */       ByteArrayBuilder builder = _getByteArrayBuilder();
/*  511 */       _decodeBase64(getText(), builder, b64variant);
/*  512 */       this._binaryValue = builder.toByteArray();
/*      */     } 
/*      */     
/*  515 */     return this._binaryValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int readBinaryValue(Base64Variant b64variant, OutputStream out) throws IOException {
/*  522 */     if (!this._tokenIncomplete || this._currToken != JsonToken.VALUE_STRING) {
/*  523 */       byte[] b = getBinaryValue(b64variant);
/*  524 */       out.write(b);
/*  525 */       return b.length;
/*      */     } 
/*      */     
/*  528 */     byte[] buf = this._ioContext.allocBase64Buffer();
/*      */     try {
/*  530 */       return _readBinary(b64variant, out, buf);
/*      */     } finally {
/*  532 */       this._ioContext.releaseBase64Buffer(buf);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected int _readBinary(Base64Variant b64variant, OutputStream out, byte[] buffer) throws IOException {
/*  538 */     int outputPtr = 0;
/*  539 */     int outputEnd = buffer.length - 3;
/*  540 */     int outputCount = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/*  546 */       if (this._inputPtr >= this._inputEnd) {
/*  547 */         _loadMoreGuaranteed();
/*      */       }
/*  549 */       char ch = this._inputBuffer[this._inputPtr++];
/*  550 */       if (ch > ' ') {
/*  551 */         int bits = b64variant.decodeBase64Char(ch);
/*  552 */         if (bits < 0) {
/*  553 */           if (ch == '"') {
/*      */             break;
/*      */           }
/*  556 */           bits = _decodeBase64Escape(b64variant, ch, 0);
/*  557 */           if (bits < 0) {
/*      */             continue;
/*      */           }
/*      */         } 
/*      */ 
/*      */         
/*  563 */         if (outputPtr > outputEnd) {
/*  564 */           outputCount += outputPtr;
/*  565 */           out.write(buffer, 0, outputPtr);
/*  566 */           outputPtr = 0;
/*      */         } 
/*      */         
/*  569 */         int decodedData = bits;
/*      */ 
/*      */ 
/*      */         
/*  573 */         if (this._inputPtr >= this._inputEnd) {
/*  574 */           _loadMoreGuaranteed();
/*      */         }
/*  576 */         ch = this._inputBuffer[this._inputPtr++];
/*  577 */         bits = b64variant.decodeBase64Char(ch);
/*  578 */         if (bits < 0) {
/*  579 */           bits = _decodeBase64Escape(b64variant, ch, 1);
/*      */         }
/*  581 */         decodedData = decodedData << 6 | bits;
/*      */ 
/*      */         
/*  584 */         if (this._inputPtr >= this._inputEnd) {
/*  585 */           _loadMoreGuaranteed();
/*      */         }
/*  587 */         ch = this._inputBuffer[this._inputPtr++];
/*  588 */         bits = b64variant.decodeBase64Char(ch);
/*      */ 
/*      */         
/*  591 */         if (bits < 0) {
/*  592 */           if (bits != -2) {
/*      */             
/*  594 */             if (ch == '"') {
/*  595 */               decodedData >>= 4;
/*  596 */               buffer[outputPtr++] = (byte)decodedData;
/*  597 */               if (b64variant.usesPadding()) {
/*  598 */                 this._inputPtr--;
/*  599 */                 _handleBase64MissingPadding(b64variant);
/*      */               } 
/*      */               break;
/*      */             } 
/*  603 */             bits = _decodeBase64Escape(b64variant, ch, 2);
/*      */           } 
/*  605 */           if (bits == -2) {
/*      */             
/*  607 */             if (this._inputPtr >= this._inputEnd) {
/*  608 */               _loadMoreGuaranteed();
/*      */             }
/*  610 */             ch = this._inputBuffer[this._inputPtr++];
/*  611 */             if (!b64variant.usesPaddingChar(ch) && 
/*  612 */               _decodeBase64Escape(b64variant, ch, 3) != -2) {
/*  613 */               throw reportInvalidBase64Char(b64variant, ch, 3, "expected padding character '" + b64variant.getPaddingChar() + "'");
/*      */             }
/*      */ 
/*      */             
/*  617 */             decodedData >>= 4;
/*  618 */             buffer[outputPtr++] = (byte)decodedData;
/*      */             
/*      */             continue;
/*      */           } 
/*      */         } 
/*  623 */         decodedData = decodedData << 6 | bits;
/*      */         
/*  625 */         if (this._inputPtr >= this._inputEnd) {
/*  626 */           _loadMoreGuaranteed();
/*      */         }
/*  628 */         ch = this._inputBuffer[this._inputPtr++];
/*  629 */         bits = b64variant.decodeBase64Char(ch);
/*  630 */         if (bits < 0) {
/*  631 */           if (bits != -2) {
/*      */             
/*  633 */             if (ch == '"') {
/*  634 */               decodedData >>= 2;
/*  635 */               buffer[outputPtr++] = (byte)(decodedData >> 8);
/*  636 */               buffer[outputPtr++] = (byte)decodedData;
/*  637 */               if (b64variant.usesPadding()) {
/*  638 */                 this._inputPtr--;
/*  639 */                 _handleBase64MissingPadding(b64variant);
/*      */               } 
/*      */               break;
/*      */             } 
/*  643 */             bits = _decodeBase64Escape(b64variant, ch, 3);
/*      */           } 
/*  645 */           if (bits == -2) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  652 */             decodedData >>= 2;
/*  653 */             buffer[outputPtr++] = (byte)(decodedData >> 8);
/*  654 */             buffer[outputPtr++] = (byte)decodedData;
/*      */             
/*      */             continue;
/*      */           } 
/*      */         } 
/*  659 */         decodedData = decodedData << 6 | bits;
/*  660 */         buffer[outputPtr++] = (byte)(decodedData >> 16);
/*  661 */         buffer[outputPtr++] = (byte)(decodedData >> 8);
/*  662 */         buffer[outputPtr++] = (byte)decodedData;
/*      */       } 
/*  664 */     }  this._tokenIncomplete = false;
/*  665 */     if (outputPtr > 0) {
/*  666 */       outputCount += outputPtr;
/*  667 */       out.write(buffer, 0, outputPtr);
/*      */     } 
/*  669 */     return outputCount;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final JsonToken nextToken() throws IOException {
/*      */     JsonToken t;
/*  689 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  690 */       return _nextAfterName();
/*      */     }
/*      */ 
/*      */     
/*  694 */     this._numTypesValid = 0;
/*  695 */     if (this._tokenIncomplete) {
/*  696 */       _skipString();
/*      */     }
/*  698 */     int i = _skipWSOrEnd();
/*  699 */     if (i < 0) {
/*      */ 
/*      */       
/*  702 */       close();
/*  703 */       return this._currToken = null;
/*      */     } 
/*      */     
/*  706 */     this._binaryValue = null;
/*      */ 
/*      */     
/*  709 */     if (i == 93 || i == 125) {
/*  710 */       _closeScope(i);
/*  711 */       return this._currToken;
/*      */     } 
/*      */ 
/*      */     
/*  715 */     if (this._parsingContext.expectComma()) {
/*  716 */       i = _skipComma(i);
/*      */ 
/*      */       
/*  719 */       if ((this._features & FEAT_MASK_TRAILING_COMMA) != 0 && (
/*  720 */         i == 93 || i == 125)) {
/*  721 */         _closeScope(i);
/*  722 */         return this._currToken;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  730 */     boolean inObject = this._parsingContext.inObject();
/*  731 */     if (inObject) {
/*      */       
/*  733 */       _updateNameLocation();
/*  734 */       String name = (i == 34) ? _parseName() : _handleOddName(i);
/*  735 */       this._parsingContext.setCurrentName(name);
/*  736 */       this._currToken = JsonToken.FIELD_NAME;
/*  737 */       i = _skipColon();
/*      */     } 
/*  739 */     _updateLocation();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  745 */     switch (i) {
/*      */       case 34:
/*  747 */         this._tokenIncomplete = true;
/*  748 */         t = JsonToken.VALUE_STRING;
/*      */         break;
/*      */       case 91:
/*  751 */         if (!inObject) {
/*  752 */           this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/*      */         }
/*  754 */         t = JsonToken.START_ARRAY;
/*      */         break;
/*      */       case 123:
/*  757 */         if (!inObject) {
/*  758 */           this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */         }
/*  760 */         t = JsonToken.START_OBJECT;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 125:
/*  765 */         _reportUnexpectedChar(i, "expected a value");
/*      */       case 116:
/*  767 */         _matchTrue();
/*  768 */         t = JsonToken.VALUE_TRUE;
/*      */         break;
/*      */       case 102:
/*  771 */         _matchFalse();
/*  772 */         t = JsonToken.VALUE_FALSE;
/*      */         break;
/*      */       case 110:
/*  775 */         _matchNull();
/*  776 */         t = JsonToken.VALUE_NULL;
/*      */         break;
/*      */       
/*      */       case 45:
/*  780 */         t = _parseSignedNumber(true);
/*      */         break;
/*      */       case 43:
/*  783 */         if (isEnabled(JsonReadFeature.ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS.mappedFeature())) {
/*  784 */           t = _parseSignedNumber(false); break;
/*      */         } 
/*  786 */         t = _handleOddValue(i);
/*      */         break;
/*      */       
/*      */       case 46:
/*  790 */         t = _parseFloatThatStartsWithPeriod(false);
/*      */         break;
/*      */       case 48:
/*      */       case 49:
/*      */       case 50:
/*      */       case 51:
/*      */       case 52:
/*      */       case 53:
/*      */       case 54:
/*      */       case 55:
/*      */       case 56:
/*      */       case 57:
/*  802 */         t = _parseUnsignedNumber(i);
/*      */         break;
/*      */       default:
/*  805 */         t = _handleOddValue(i);
/*      */         break;
/*      */     } 
/*      */     
/*  809 */     if (inObject) {
/*  810 */       this._nextToken = t;
/*  811 */       return this._currToken;
/*      */     } 
/*  813 */     this._currToken = t;
/*  814 */     return t;
/*      */   }
/*      */ 
/*      */   
/*      */   private final JsonToken _nextAfterName() {
/*  819 */     this._nameCopied = false;
/*  820 */     JsonToken t = this._nextToken;
/*  821 */     this._nextToken = null;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  826 */     if (t == JsonToken.START_ARRAY) {
/*  827 */       this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/*  828 */     } else if (t == JsonToken.START_OBJECT) {
/*  829 */       this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */     } 
/*  831 */     return this._currToken = t;
/*      */   }
/*      */ 
/*      */   
/*      */   public void finishToken() throws IOException {
/*  836 */     if (this._tokenIncomplete) {
/*  837 */       this._tokenIncomplete = false;
/*  838 */       _finishString();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean nextFieldName(SerializableString sstr) throws IOException {
/*  854 */     this._numTypesValid = 0;
/*  855 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  856 */       _nextAfterName();
/*  857 */       return false;
/*      */     } 
/*  859 */     if (this._tokenIncomplete) {
/*  860 */       _skipString();
/*      */     }
/*  862 */     int i = _skipWSOrEnd();
/*  863 */     if (i < 0) {
/*  864 */       close();
/*  865 */       this._currToken = null;
/*  866 */       return false;
/*      */     } 
/*  868 */     this._binaryValue = null;
/*      */ 
/*      */     
/*  871 */     if (i == 93 || i == 125) {
/*  872 */       _closeScope(i);
/*  873 */       return false;
/*      */     } 
/*      */     
/*  876 */     if (this._parsingContext.expectComma()) {
/*  877 */       i = _skipComma(i);
/*      */ 
/*      */       
/*  880 */       if ((this._features & FEAT_MASK_TRAILING_COMMA) != 0 && (
/*  881 */         i == 93 || i == 125)) {
/*  882 */         _closeScope(i);
/*  883 */         return false;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  888 */     if (!this._parsingContext.inObject()) {
/*  889 */       _updateLocation();
/*  890 */       _nextTokenNotInObject(i);
/*  891 */       return false;
/*      */     } 
/*      */     
/*  894 */     _updateNameLocation();
/*  895 */     if (i == 34) {
/*      */       
/*  897 */       char[] nameChars = sstr.asQuotedChars();
/*  898 */       int len = nameChars.length;
/*      */ 
/*      */       
/*  901 */       if (this._inputPtr + len + 4 < this._inputEnd) {
/*      */         
/*  903 */         int end = this._inputPtr + len;
/*  904 */         if (this._inputBuffer[end] == '"') {
/*  905 */           int offset = 0;
/*  906 */           int ptr = this._inputPtr;
/*      */           while (true) {
/*  908 */             if (ptr == end) {
/*  909 */               this._parsingContext.setCurrentName(sstr.getValue());
/*  910 */               _isNextTokenNameYes(_skipColonFast(ptr + 1));
/*  911 */               return true;
/*      */             } 
/*  913 */             if (nameChars[offset] != this._inputBuffer[ptr]) {
/*      */               break;
/*      */             }
/*  916 */             offset++;
/*  917 */             ptr++;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*  922 */     return _isNextTokenNameMaybe(i, sstr.getValue());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String nextFieldName() throws IOException {
/*  930 */     this._numTypesValid = 0;
/*  931 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  932 */       _nextAfterName();
/*  933 */       return null;
/*      */     } 
/*  935 */     if (this._tokenIncomplete) {
/*  936 */       _skipString();
/*      */     }
/*  938 */     int i = _skipWSOrEnd();
/*  939 */     if (i < 0) {
/*  940 */       close();
/*  941 */       this._currToken = null;
/*  942 */       return null;
/*      */     } 
/*  944 */     this._binaryValue = null;
/*  945 */     if (i == 93 || i == 125) {
/*  946 */       _closeScope(i);
/*  947 */       return null;
/*      */     } 
/*  949 */     if (this._parsingContext.expectComma()) {
/*  950 */       i = _skipComma(i);
/*  951 */       if ((this._features & FEAT_MASK_TRAILING_COMMA) != 0 && (
/*  952 */         i == 93 || i == 125)) {
/*  953 */         _closeScope(i);
/*  954 */         return null;
/*      */       } 
/*      */     } 
/*      */     
/*  958 */     if (!this._parsingContext.inObject()) {
/*  959 */       _updateLocation();
/*  960 */       _nextTokenNotInObject(i);
/*  961 */       return null;
/*      */     } 
/*      */     
/*  964 */     _updateNameLocation();
/*  965 */     String name = (i == 34) ? _parseName() : _handleOddName(i);
/*  966 */     this._parsingContext.setCurrentName(name);
/*  967 */     this._currToken = JsonToken.FIELD_NAME;
/*  968 */     i = _skipColon();
/*      */     
/*  970 */     _updateLocation();
/*  971 */     if (i == 34) {
/*  972 */       this._tokenIncomplete = true;
/*  973 */       this._nextToken = JsonToken.VALUE_STRING;
/*  974 */       return name;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  981 */     switch (i)
/*      */     { case 45:
/*  983 */         t = _parseSignedNumber(true);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1029 */         this._nextToken = t;
/* 1030 */         return name;case 43: if (isEnabled(JsonReadFeature.ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS.mappedFeature())) { t = _parseSignedNumber(false); } else { t = _handleOddValue(i); }  this._nextToken = t; return name;case 46: t = _parseFloatThatStartsWithPeriod(false); this._nextToken = t; return name;case 48: case 49: case 50: case 51: case 52: case 53: case 54: case 55: case 56: case 57: t = _parseUnsignedNumber(i); this._nextToken = t; return name;case 102: _matchFalse(); t = JsonToken.VALUE_FALSE; this._nextToken = t; return name;case 110: _matchNull(); t = JsonToken.VALUE_NULL; this._nextToken = t; return name;case 116: _matchTrue(); t = JsonToken.VALUE_TRUE; this._nextToken = t; return name;case 91: t = JsonToken.START_ARRAY; this._nextToken = t; return name;case 123: t = JsonToken.START_OBJECT; this._nextToken = t; return name; }  JsonToken t = _handleOddValue(i); this._nextToken = t; return name;
/*      */   }
/*      */ 
/*      */   
/*      */   private final void _isNextTokenNameYes(int i) throws IOException {
/* 1035 */     this._currToken = JsonToken.FIELD_NAME;
/* 1036 */     _updateLocation();
/*      */     
/* 1038 */     switch (i) {
/*      */       case 34:
/* 1040 */         this._tokenIncomplete = true;
/* 1041 */         this._nextToken = JsonToken.VALUE_STRING;
/*      */         return;
/*      */       case 91:
/* 1044 */         this._nextToken = JsonToken.START_ARRAY;
/*      */         return;
/*      */       case 123:
/* 1047 */         this._nextToken = JsonToken.START_OBJECT;
/*      */         return;
/*      */       case 116:
/* 1050 */         _matchToken("true", 1);
/* 1051 */         this._nextToken = JsonToken.VALUE_TRUE;
/*      */         return;
/*      */       case 102:
/* 1054 */         _matchToken("false", 1);
/* 1055 */         this._nextToken = JsonToken.VALUE_FALSE;
/*      */         return;
/*      */       case 110:
/* 1058 */         _matchToken("null", 1);
/* 1059 */         this._nextToken = JsonToken.VALUE_NULL;
/*      */         return;
/*      */       case 45:
/* 1062 */         this._nextToken = _parseSignedNumber(true);
/*      */         return;
/*      */       case 43:
/* 1065 */         if (isEnabled(JsonReadFeature.ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS.mappedFeature())) {
/* 1066 */           this._nextToken = _parseSignedNumber(false);
/*      */         } else {
/* 1068 */           this._nextToken = _handleOddValue(i);
/*      */         } 
/*      */         return;
/*      */       case 46:
/* 1072 */         this._nextToken = _parseFloatThatStartsWithPeriod(false);
/*      */         return;
/*      */       case 48:
/*      */       case 49:
/*      */       case 50:
/*      */       case 51:
/*      */       case 52:
/*      */       case 53:
/*      */       case 54:
/*      */       case 55:
/*      */       case 56:
/*      */       case 57:
/* 1084 */         this._nextToken = _parseUnsignedNumber(i);
/*      */         return;
/*      */     } 
/* 1087 */     this._nextToken = _handleOddValue(i);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _isNextTokenNameMaybe(int i, String nameToMatch) throws IOException {
/* 1093 */     String name = (i == 34) ? _parseName() : _handleOddName(i);
/* 1094 */     this._parsingContext.setCurrentName(name);
/* 1095 */     this._currToken = JsonToken.FIELD_NAME;
/* 1096 */     i = _skipColon();
/* 1097 */     _updateLocation();
/* 1098 */     if (i == 34) {
/* 1099 */       this._tokenIncomplete = true;
/* 1100 */       this._nextToken = JsonToken.VALUE_STRING;
/* 1101 */       return nameToMatch.equals(name);
/*      */     } 
/*      */ 
/*      */     
/* 1105 */     switch (i)
/*      */     { case 45:
/* 1107 */         t = _parseSignedNumber(true);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1153 */         this._nextToken = t;
/* 1154 */         return nameToMatch.equals(name);case 43: if (isEnabled(JsonReadFeature.ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS.mappedFeature())) { t = _parseSignedNumber(false); } else { t = _handleOddValue(i); }  this._nextToken = t; return nameToMatch.equals(name);case 46: t = _parseFloatThatStartsWithPeriod(false); this._nextToken = t; return nameToMatch.equals(name);case 48: case 49: case 50: case 51: case 52: case 53: case 54: case 55: case 56: case 57: t = _parseUnsignedNumber(i); this._nextToken = t; return nameToMatch.equals(name);case 102: _matchFalse(); t = JsonToken.VALUE_FALSE; this._nextToken = t; return nameToMatch.equals(name);case 110: _matchNull(); t = JsonToken.VALUE_NULL; this._nextToken = t; return nameToMatch.equals(name);case 116: _matchTrue(); t = JsonToken.VALUE_TRUE; this._nextToken = t; return nameToMatch.equals(name);case 91: t = JsonToken.START_ARRAY; this._nextToken = t; return nameToMatch.equals(name);case 123: t = JsonToken.START_OBJECT; this._nextToken = t; return nameToMatch.equals(name); }  JsonToken t = _handleOddValue(i); this._nextToken = t; return nameToMatch.equals(name);
/*      */   }
/*      */ 
/*      */   
/*      */   private final JsonToken _nextTokenNotInObject(int i) throws IOException {
/* 1159 */     if (i == 34) {
/* 1160 */       this._tokenIncomplete = true;
/* 1161 */       return this._currToken = JsonToken.VALUE_STRING;
/*      */     } 
/* 1163 */     switch (i) {
/*      */       case 91:
/* 1165 */         this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/* 1166 */         return this._currToken = JsonToken.START_ARRAY;
/*      */       case 123:
/* 1168 */         this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/* 1169 */         return this._currToken = JsonToken.START_OBJECT;
/*      */       case 116:
/* 1171 */         _matchToken("true", 1);
/* 1172 */         return this._currToken = JsonToken.VALUE_TRUE;
/*      */       case 102:
/* 1174 */         _matchToken("false", 1);
/* 1175 */         return this._currToken = JsonToken.VALUE_FALSE;
/*      */       case 110:
/* 1177 */         _matchToken("null", 1);
/* 1178 */         return this._currToken = JsonToken.VALUE_NULL;
/*      */       case 45:
/* 1180 */         return this._currToken = _parseSignedNumber(true);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 46:
/* 1186 */         return this._currToken = _parseFloatThatStartsWithPeriod(false);
/*      */       case 48:
/*      */       case 49:
/*      */       case 50:
/*      */       case 51:
/*      */       case 52:
/*      */       case 53:
/*      */       case 54:
/*      */       case 55:
/*      */       case 56:
/*      */       case 57:
/* 1197 */         return this._currToken = _parseUnsignedNumber(i);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 44:
/* 1209 */         if (!this._parsingContext.inRoot() && (
/* 1210 */           this._features & FEAT_MASK_ALLOW_MISSING) != 0) {
/* 1211 */           this._inputPtr--;
/* 1212 */           return this._currToken = JsonToken.VALUE_NULL;
/*      */         } 
/*      */         break;
/*      */     } 
/* 1216 */     return this._currToken = _handleOddValue(i);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final String nextTextValue() throws IOException {
/* 1222 */     if (this._currToken == JsonToken.FIELD_NAME) {
/* 1223 */       this._nameCopied = false;
/* 1224 */       JsonToken t = this._nextToken;
/* 1225 */       this._nextToken = null;
/* 1226 */       this._currToken = t;
/* 1227 */       if (t == JsonToken.VALUE_STRING) {
/* 1228 */         if (this._tokenIncomplete) {
/* 1229 */           this._tokenIncomplete = false;
/* 1230 */           _finishString();
/*      */         } 
/* 1232 */         return this._textBuffer.contentsAsString();
/*      */       } 
/* 1234 */       if (t == JsonToken.START_ARRAY) {
/* 1235 */         this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/* 1236 */       } else if (t == JsonToken.START_OBJECT) {
/* 1237 */         this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */       } 
/* 1239 */       return null;
/*      */     } 
/*      */     
/* 1242 */     return (nextToken() == JsonToken.VALUE_STRING) ? getText() : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int nextIntValue(int defaultValue) throws IOException {
/* 1249 */     if (this._currToken == JsonToken.FIELD_NAME) {
/* 1250 */       this._nameCopied = false;
/* 1251 */       JsonToken t = this._nextToken;
/* 1252 */       this._nextToken = null;
/* 1253 */       this._currToken = t;
/* 1254 */       if (t == JsonToken.VALUE_NUMBER_INT) {
/* 1255 */         return getIntValue();
/*      */       }
/* 1257 */       if (t == JsonToken.START_ARRAY) {
/* 1258 */         this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/* 1259 */       } else if (t == JsonToken.START_OBJECT) {
/* 1260 */         this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */       } 
/* 1262 */       return defaultValue;
/*      */     } 
/*      */     
/* 1265 */     return (nextToken() == JsonToken.VALUE_NUMBER_INT) ? getIntValue() : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final long nextLongValue(long defaultValue) throws IOException {
/* 1272 */     if (this._currToken == JsonToken.FIELD_NAME) {
/* 1273 */       this._nameCopied = false;
/* 1274 */       JsonToken t = this._nextToken;
/* 1275 */       this._nextToken = null;
/* 1276 */       this._currToken = t;
/* 1277 */       if (t == JsonToken.VALUE_NUMBER_INT) {
/* 1278 */         return getLongValue();
/*      */       }
/* 1280 */       if (t == JsonToken.START_ARRAY) {
/* 1281 */         this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/* 1282 */       } else if (t == JsonToken.START_OBJECT) {
/* 1283 */         this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */       } 
/* 1285 */       return defaultValue;
/*      */     } 
/*      */     
/* 1288 */     return (nextToken() == JsonToken.VALUE_NUMBER_INT) ? getLongValue() : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Boolean nextBooleanValue() throws IOException {
/* 1295 */     if (this._currToken == JsonToken.FIELD_NAME) {
/* 1296 */       this._nameCopied = false;
/* 1297 */       JsonToken jsonToken = this._nextToken;
/* 1298 */       this._nextToken = null;
/* 1299 */       this._currToken = jsonToken;
/* 1300 */       if (jsonToken == JsonToken.VALUE_TRUE) {
/* 1301 */         return Boolean.TRUE;
/*      */       }
/* 1303 */       if (jsonToken == JsonToken.VALUE_FALSE) {
/* 1304 */         return Boolean.FALSE;
/*      */       }
/* 1306 */       if (jsonToken == JsonToken.START_ARRAY) {
/* 1307 */         this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/* 1308 */       } else if (jsonToken == JsonToken.START_OBJECT) {
/* 1309 */         this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */       } 
/* 1311 */       return null;
/*      */     } 
/* 1313 */     JsonToken t = nextToken();
/* 1314 */     if (t != null) {
/* 1315 */       int id = t.id();
/* 1316 */       if (id == 9) return Boolean.TRUE; 
/* 1317 */       if (id == 10) return Boolean.FALSE; 
/*      */     } 
/* 1319 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected final JsonToken _parseFloatThatStartsWithPeriod() throws IOException {
/* 1330 */     return _parseFloatThatStartsWithPeriod(false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final JsonToken _parseFloatThatStartsWithPeriod(boolean neg) throws IOException {
/* 1337 */     if (!isEnabled(JsonReadFeature.ALLOW_LEADING_DECIMAL_POINT_FOR_NUMBERS.mappedFeature())) {
/* 1338 */       return _handleOddValue(46);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1346 */     int startPtr = this._inputPtr - 1;
/* 1347 */     if (neg) {
/* 1348 */       startPtr--;
/*      */     }
/* 1350 */     return _parseFloat(46, startPtr, this._inputPtr, neg, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final JsonToken _parseUnsignedNumber(int ch) throws IOException {
/* 1383 */     int ptr = this._inputPtr;
/* 1384 */     int startPtr = ptr - 1;
/* 1385 */     int inputLen = this._inputEnd;
/*      */ 
/*      */     
/* 1388 */     if (ch == 48) {
/* 1389 */       return _parseNumber2(false, startPtr);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1398 */     int intLen = 1;
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/* 1403 */       if (ptr >= inputLen) {
/* 1404 */         this._inputPtr = startPtr;
/* 1405 */         return _parseNumber2(false, startPtr);
/*      */       } 
/* 1407 */       ch = this._inputBuffer[ptr++];
/* 1408 */       if (ch < 48 || ch > 57) {
/*      */         break;
/*      */       }
/* 1411 */       intLen++;
/*      */     } 
/* 1413 */     if (ch == 46 || ch == 101 || ch == 69) {
/* 1414 */       this._inputPtr = ptr;
/* 1415 */       return _parseFloat(ch, startPtr, ptr, false, intLen);
/*      */     } 
/*      */ 
/*      */     
/* 1419 */     this._inputPtr = --ptr;
/*      */     
/* 1421 */     if (this._parsingContext.inRoot()) {
/* 1422 */       _verifyRootSpace(ch);
/*      */     }
/* 1424 */     int len = ptr - startPtr;
/* 1425 */     this._textBuffer.resetWithShared(this._inputBuffer, startPtr, len);
/* 1426 */     return resetInt(false, intLen);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final JsonToken _parseFloat(int ch, int startPtr, int ptr, boolean neg, int intLen) throws IOException {
/* 1432 */     int inputLen = this._inputEnd;
/* 1433 */     int fractLen = 0;
/*      */ 
/*      */     
/* 1436 */     if (ch == 46) {
/*      */       
/*      */       while (true) {
/* 1439 */         if (ptr >= inputLen) {
/* 1440 */           return _parseNumber2(neg, startPtr);
/*      */         }
/* 1442 */         ch = this._inputBuffer[ptr++];
/* 1443 */         if (ch < 48 || ch > 57) {
/*      */           break;
/*      */         }
/* 1446 */         fractLen++;
/*      */       } 
/*      */       
/* 1449 */       if (fractLen == 0 && 
/* 1450 */         !isEnabled(JsonReadFeature.ALLOW_TRAILING_DECIMAL_POINT_FOR_NUMBERS.mappedFeature())) {
/* 1451 */         _reportUnexpectedNumberChar(ch, "Decimal point not followed by a digit");
/*      */       }
/*      */     } 
/*      */     
/* 1455 */     int expLen = 0;
/* 1456 */     if (ch == 101 || ch == 69) {
/* 1457 */       if (ptr >= inputLen) {
/* 1458 */         this._inputPtr = startPtr;
/* 1459 */         return _parseNumber2(neg, startPtr);
/*      */       } 
/*      */       
/* 1462 */       ch = this._inputBuffer[ptr++];
/* 1463 */       if (ch == 45 || ch == 43) {
/* 1464 */         if (ptr >= inputLen) {
/* 1465 */           this._inputPtr = startPtr;
/* 1466 */           return _parseNumber2(neg, startPtr);
/*      */         } 
/* 1468 */         ch = this._inputBuffer[ptr++];
/*      */       } 
/* 1470 */       while (ch <= 57 && ch >= 48) {
/* 1471 */         expLen++;
/* 1472 */         if (ptr >= inputLen) {
/* 1473 */           this._inputPtr = startPtr;
/* 1474 */           return _parseNumber2(neg, startPtr);
/*      */         } 
/* 1476 */         ch = this._inputBuffer[ptr++];
/*      */       } 
/*      */       
/* 1479 */       if (expLen == 0) {
/* 1480 */         _reportUnexpectedNumberChar(ch, "Exponent indicator not followed by a digit");
/*      */       }
/*      */     } 
/*      */     
/* 1484 */     this._inputPtr = --ptr;
/*      */     
/* 1486 */     if (this._parsingContext.inRoot()) {
/* 1487 */       _verifyRootSpace(ch);
/*      */     }
/* 1489 */     int len = ptr - startPtr;
/* 1490 */     this._textBuffer.resetWithShared(this._inputBuffer, startPtr, len);
/*      */     
/* 1492 */     return resetFloat(neg, intLen, fractLen, expLen);
/*      */   }
/*      */ 
/*      */   
/*      */   private final JsonToken _parseSignedNumber(boolean negative) throws IOException {
/* 1497 */     int ptr = this._inputPtr;
/*      */ 
/*      */     
/* 1500 */     int startPtr = negative ? (ptr - 1) : ptr;
/* 1501 */     int inputEnd = this._inputEnd;
/*      */     
/* 1503 */     if (ptr >= inputEnd) {
/* 1504 */       return _parseNumber2(negative, startPtr);
/*      */     }
/* 1506 */     int ch = this._inputBuffer[ptr++];
/*      */     
/* 1508 */     if (ch > 57 || ch < 48) {
/* 1509 */       this._inputPtr = ptr;
/* 1510 */       if (ch == 46) {
/* 1511 */         return _parseFloatThatStartsWithPeriod(negative);
/*      */       }
/* 1513 */       return _handleInvalidNumberStart(ch, negative, true);
/*      */     } 
/*      */     
/* 1516 */     if (ch == 48) {
/* 1517 */       return _parseNumber2(negative, startPtr);
/*      */     }
/* 1519 */     int intLen = 1;
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/* 1524 */       if (ptr >= inputEnd) {
/* 1525 */         return _parseNumber2(negative, startPtr);
/*      */       }
/* 1527 */       ch = this._inputBuffer[ptr++];
/* 1528 */       if (ch < 48 || ch > 57) {
/*      */         break;
/*      */       }
/* 1531 */       intLen++;
/*      */     } 
/*      */     
/* 1534 */     if (ch == 46 || ch == 101 || ch == 69) {
/* 1535 */       this._inputPtr = ptr;
/* 1536 */       return _parseFloat(ch, startPtr, ptr, negative, intLen);
/*      */     } 
/*      */     
/* 1539 */     this._inputPtr = --ptr;
/* 1540 */     if (this._parsingContext.inRoot()) {
/* 1541 */       _verifyRootSpace(ch);
/*      */     }
/* 1543 */     int len = ptr - startPtr;
/* 1544 */     this._textBuffer.resetWithShared(this._inputBuffer, startPtr, len);
/* 1545 */     return resetInt(negative, intLen);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final JsonToken _parseNumber2(boolean neg, int startPtr) throws IOException {
/* 1566 */     this._inputPtr = neg ? (startPtr + 1) : startPtr;
/* 1567 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 1568 */     int outPtr = 0;
/*      */ 
/*      */     
/* 1571 */     if (neg) {
/* 1572 */       outBuf[outPtr++] = '-';
/*      */     }
/*      */ 
/*      */     
/* 1576 */     int intLen = 0;
/*      */     
/* 1578 */     char c = (this._inputPtr < this._inputEnd) ? this._inputBuffer[this._inputPtr++] : getNextChar("No digit following minus sign", JsonToken.VALUE_NUMBER_INT);
/*      */     
/* 1580 */     if (c == '0') {
/* 1581 */       c = _verifyNoLeadingZeroes();
/*      */     }
/* 1583 */     boolean eof = false;
/*      */ 
/*      */ 
/*      */     
/* 1587 */     while (c >= '0' && c <= '9') {
/* 1588 */       intLen++;
/* 1589 */       if (outPtr >= outBuf.length) {
/* 1590 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 1591 */         outPtr = 0;
/*      */       } 
/* 1593 */       outBuf[outPtr++] = c;
/* 1594 */       if (this._inputPtr >= this._inputEnd && !_loadMore()) {
/*      */         
/* 1596 */         c = Character.MIN_VALUE;
/* 1597 */         eof = true;
/*      */         break;
/*      */       } 
/* 1600 */       c = this._inputBuffer[this._inputPtr++];
/*      */     } 
/*      */     
/* 1603 */     if (intLen == 0)
/*      */     {
/* 1605 */       if (!isEnabled(JsonReadFeature.ALLOW_LEADING_DECIMAL_POINT_FOR_NUMBERS.mappedFeature())) {
/* 1606 */         return _handleInvalidNumberStart(c, neg);
/*      */       }
/*      */     }
/*      */     
/* 1610 */     int fractLen = -1;
/*      */     
/* 1612 */     if (c == '.') {
/* 1613 */       fractLen = 0;
/* 1614 */       if (outPtr >= outBuf.length) {
/* 1615 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 1616 */         outPtr = 0;
/*      */       } 
/* 1618 */       outBuf[outPtr++] = c;
/*      */ 
/*      */       
/*      */       while (true) {
/* 1622 */         if (this._inputPtr >= this._inputEnd && !_loadMore()) {
/* 1623 */           eof = true;
/*      */           break;
/*      */         } 
/* 1626 */         c = this._inputBuffer[this._inputPtr++];
/* 1627 */         if (c < '0' || c > '9') {
/*      */           break;
/*      */         }
/* 1630 */         fractLen++;
/* 1631 */         if (outPtr >= outBuf.length) {
/* 1632 */           outBuf = this._textBuffer.finishCurrentSegment();
/* 1633 */           outPtr = 0;
/*      */         } 
/* 1635 */         outBuf[outPtr++] = c;
/*      */       } 
/*      */       
/* 1638 */       if (fractLen == 0 && 
/* 1639 */         !isEnabled(JsonReadFeature.ALLOW_TRAILING_DECIMAL_POINT_FOR_NUMBERS.mappedFeature())) {
/* 1640 */         _reportUnexpectedNumberChar(c, "Decimal point not followed by a digit");
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1645 */     int expLen = -1;
/* 1646 */     if (c == 'e' || c == 'E') {
/* 1647 */       expLen = 0;
/* 1648 */       if (outPtr >= outBuf.length) {
/* 1649 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 1650 */         outPtr = 0;
/*      */       } 
/* 1652 */       outBuf[outPtr++] = c;
/*      */ 
/*      */       
/* 1655 */       c = (this._inputPtr < this._inputEnd) ? this._inputBuffer[this._inputPtr++] : getNextChar("expected a digit for number exponent", JsonToken.VALUE_NUMBER_FLOAT);
/*      */       
/* 1657 */       if (c == '-' || c == '+') {
/* 1658 */         if (outPtr >= outBuf.length) {
/* 1659 */           outBuf = this._textBuffer.finishCurrentSegment();
/* 1660 */           outPtr = 0;
/*      */         } 
/* 1662 */         outBuf[outPtr++] = c;
/*      */ 
/*      */         
/* 1665 */         c = (this._inputPtr < this._inputEnd) ? this._inputBuffer[this._inputPtr++] : getNextChar("expected a digit for number exponent", JsonToken.VALUE_NUMBER_FLOAT);
/*      */       } 
/*      */ 
/*      */       
/* 1669 */       while (c <= '9' && c >= '0') {
/* 1670 */         expLen++;
/* 1671 */         if (outPtr >= outBuf.length) {
/* 1672 */           outBuf = this._textBuffer.finishCurrentSegment();
/* 1673 */           outPtr = 0;
/*      */         } 
/* 1675 */         outBuf[outPtr++] = c;
/* 1676 */         if (this._inputPtr >= this._inputEnd && !_loadMore()) {
/* 1677 */           eof = true;
/*      */           break;
/*      */         } 
/* 1680 */         c = this._inputBuffer[this._inputPtr++];
/*      */       } 
/*      */       
/* 1683 */       if (expLen == 0) {
/* 1684 */         _reportUnexpectedNumberChar(c, "Exponent indicator not followed by a digit");
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1689 */     if (!eof) {
/* 1690 */       this._inputPtr--;
/* 1691 */       if (this._parsingContext.inRoot()) {
/* 1692 */         _verifyRootSpace(c);
/*      */       }
/*      */     } 
/* 1695 */     this._textBuffer.setCurrentLength(outPtr);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1700 */     if (fractLen < 0 && expLen < 0) {
/* 1701 */       return resetInt(neg, intLen);
/*      */     }
/* 1703 */     return resetFloat(neg, intLen, fractLen, expLen);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final char _verifyNoLeadingZeroes() throws IOException {
/* 1711 */     if (this._inputPtr < this._inputEnd) {
/* 1712 */       char ch = this._inputBuffer[this._inputPtr];
/*      */       
/* 1714 */       if (ch < '0' || ch > '9') {
/* 1715 */         return '0';
/*      */       }
/*      */     } 
/*      */     
/* 1719 */     return _verifyNLZ2();
/*      */   }
/*      */ 
/*      */   
/*      */   private char _verifyNLZ2() throws IOException {
/* 1724 */     if (this._inputPtr >= this._inputEnd && !_loadMore()) {
/* 1725 */       return '0';
/*      */     }
/* 1727 */     char ch = this._inputBuffer[this._inputPtr];
/* 1728 */     if (ch < '0' || ch > '9') {
/* 1729 */       return '0';
/*      */     }
/* 1731 */     if ((this._features & FEAT_MASK_LEADING_ZEROS) == 0) {
/* 1732 */       reportInvalidNumber("Leading zeroes not allowed");
/*      */     }
/*      */     
/* 1735 */     this._inputPtr++;
/* 1736 */     if (ch == '0') {
/* 1737 */       while (this._inputPtr < this._inputEnd || _loadMore()) {
/* 1738 */         ch = this._inputBuffer[this._inputPtr];
/* 1739 */         if (ch < '0' || ch > '9') {
/* 1740 */           return '0';
/*      */         }
/* 1742 */         this._inputPtr++;
/* 1743 */         if (ch != '0') {
/*      */           break;
/*      */         }
/*      */       } 
/*      */     }
/* 1748 */     return ch;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonToken _handleInvalidNumberStart(int ch, boolean negative) throws IOException {
/* 1755 */     return _handleInvalidNumberStart(ch, negative, false);
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _handleInvalidNumberStart(int ch, boolean negative, boolean hasSign) throws IOException {
/* 1760 */     if (ch == 73) {
/* 1761 */       if (this._inputPtr >= this._inputEnd && 
/* 1762 */         !_loadMore()) {
/* 1763 */         _reportInvalidEOFInValue(JsonToken.VALUE_NUMBER_INT);
/*      */       }
/*      */       
/* 1766 */       ch = this._inputBuffer[this._inputPtr++];
/* 1767 */       if (ch == 78) {
/* 1768 */         String match = negative ? "-INF" : "+INF";
/* 1769 */         _matchToken(match, 3);
/* 1770 */         if ((this._features & FEAT_MASK_NON_NUM_NUMBERS) != 0) {
/* 1771 */           return resetAsNaN(match, negative ? Double.NEGATIVE_INFINITY : Double.POSITIVE_INFINITY);
/*      */         }
/* 1773 */         _reportError("Non-standard token '" + match + "': enable `JsonReadFeature.ALLOW_NON_NUMERIC_NUMBERS` to allow");
/* 1774 */       } else if (ch == 110) {
/* 1775 */         String match = negative ? "-Infinity" : "+Infinity";
/* 1776 */         _matchToken(match, 3);
/* 1777 */         if ((this._features & FEAT_MASK_NON_NUM_NUMBERS) != 0) {
/* 1778 */           return resetAsNaN(match, negative ? Double.NEGATIVE_INFINITY : Double.POSITIVE_INFINITY);
/*      */         }
/* 1780 */         _reportError("Non-standard token '" + match + "': enable `JsonReadFeature.ALLOW_NON_NUMERIC_NUMBERS` to allow");
/*      */       } 
/*      */     } 
/* 1783 */     if (!isEnabled(JsonReadFeature.ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS.mappedFeature()) && hasSign && !negative) {
/* 1784 */       _reportUnexpectedNumberChar(43, "JSON spec does not allow numbers to have plus signs: enable `JsonReadFeature.ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS` to allow");
/*      */     }
/* 1786 */     String message = negative ? "expected digit (0-9) to follow minus sign, for valid numeric value" : "expected digit (0-9) for valid numeric value";
/*      */ 
/*      */     
/* 1789 */     _reportUnexpectedNumberChar(ch, message);
/* 1790 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _verifyRootSpace(int ch) throws IOException {
/* 1808 */     this._inputPtr++;
/* 1809 */     switch (ch) {
/*      */       case 9:
/*      */       case 32:
/*      */         return;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 13:
/* 1820 */         this._inputPtr--;
/*      */         return;
/*      */       case 10:
/* 1823 */         this._currInputRow++;
/* 1824 */         this._currInputRowStart = this._inputPtr;
/*      */         return;
/*      */     } 
/* 1827 */     _reportMissingRootWS(ch);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final String _parseName() throws IOException {
/* 1840 */     int ptr = this._inputPtr;
/* 1841 */     int hash = this._hashSeed;
/* 1842 */     int[] codes = _icLatin1;
/*      */     
/* 1844 */     while (ptr < this._inputEnd) {
/* 1845 */       int ch = this._inputBuffer[ptr];
/* 1846 */       if (ch < codes.length && codes[ch] != 0) {
/* 1847 */         if (ch == 34) {
/* 1848 */           int i = this._inputPtr;
/* 1849 */           this._inputPtr = ptr + 1;
/* 1850 */           return this._symbols.findSymbol(this._inputBuffer, i, ptr - i, hash);
/*      */         } 
/*      */         break;
/*      */       } 
/* 1854 */       hash = hash * 33 + ch;
/* 1855 */       ptr++;
/*      */     } 
/* 1857 */     int start = this._inputPtr;
/* 1858 */     this._inputPtr = ptr;
/* 1859 */     return _parseName2(start, hash, 34);
/*      */   }
/*      */ 
/*      */   
/*      */   private String _parseName2(int startPtr, int hash, int endChar) throws IOException {
/* 1864 */     this._textBuffer.resetWithShared(this._inputBuffer, startPtr, this._inputPtr - startPtr);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1869 */     char[] outBuf = this._textBuffer.getCurrentSegment();
/* 1870 */     int outPtr = this._textBuffer.getCurrentSegmentSize();
/*      */     
/*      */     while (true) {
/* 1873 */       if (this._inputPtr >= this._inputEnd && 
/* 1874 */         !_loadMore()) {
/* 1875 */         _reportInvalidEOF(" in field name", JsonToken.FIELD_NAME);
/*      */       }
/*      */       
/* 1878 */       char c = this._inputBuffer[this._inputPtr++];
/* 1879 */       int i = c;
/* 1880 */       if (i <= 92) {
/* 1881 */         if (i == 92) {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1886 */           c = _decodeEscaped();
/* 1887 */         } else if (i <= endChar) {
/* 1888 */           if (i == endChar) {
/*      */             break;
/*      */           }
/* 1891 */           if (i < 32) {
/* 1892 */             _throwUnquotedSpace(i, "name");
/*      */           }
/*      */         } 
/*      */       }
/* 1896 */       hash = hash * 33 + c;
/*      */       
/* 1898 */       outBuf[outPtr++] = c;
/*      */ 
/*      */       
/* 1901 */       if (outPtr >= outBuf.length) {
/* 1902 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 1903 */         outPtr = 0;
/*      */       } 
/*      */     } 
/* 1906 */     this._textBuffer.setCurrentLength(outPtr);
/*      */     
/* 1908 */     TextBuffer tb = this._textBuffer;
/* 1909 */     char[] buf = tb.getTextBuffer();
/* 1910 */     int start = tb.getTextOffset();
/* 1911 */     int len = tb.size();
/* 1912 */     return this._symbols.findSymbol(buf, start, len, hash);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String _handleOddName(int i) throws IOException {
/*      */     boolean firstOk;
/* 1932 */     if (i == 39 && (this._features & FEAT_MASK_ALLOW_SINGLE_QUOTES) != 0) {
/* 1933 */       return _parseAposName();
/*      */     }
/*      */     
/* 1936 */     if ((this._features & FEAT_MASK_ALLOW_UNQUOTED_NAMES) == 0) {
/* 1937 */       _reportUnexpectedChar(i, "was expecting double-quote to start field name");
/*      */     }
/* 1939 */     int[] codes = CharTypes.getInputCodeLatin1JsNames();
/* 1940 */     int maxCode = codes.length;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1945 */     if (i < maxCode) {
/* 1946 */       firstOk = (codes[i] == 0);
/*      */     } else {
/* 1948 */       firstOk = Character.isJavaIdentifierPart((char)i);
/*      */     } 
/* 1950 */     if (!firstOk) {
/* 1951 */       _reportUnexpectedChar(i, "was expecting either valid name character (for unquoted name) or double-quote (for quoted) to start field name");
/*      */     }
/* 1953 */     int ptr = this._inputPtr;
/* 1954 */     int hash = this._hashSeed;
/* 1955 */     int inputLen = this._inputEnd;
/*      */     
/* 1957 */     if (ptr < inputLen) {
/*      */       do {
/* 1959 */         int ch = this._inputBuffer[ptr];
/* 1960 */         if (ch < maxCode) {
/* 1961 */           if (codes[ch] != 0) {
/* 1962 */             int j = this._inputPtr - 1;
/* 1963 */             this._inputPtr = ptr;
/* 1964 */             return this._symbols.findSymbol(this._inputBuffer, j, ptr - j, hash);
/*      */           } 
/* 1966 */         } else if (!Character.isJavaIdentifierPart((char)ch)) {
/* 1967 */           int j = this._inputPtr - 1;
/* 1968 */           this._inputPtr = ptr;
/* 1969 */           return this._symbols.findSymbol(this._inputBuffer, j, ptr - j, hash);
/*      */         } 
/* 1971 */         hash = hash * 33 + ch;
/* 1972 */         ++ptr;
/* 1973 */       } while (ptr < inputLen);
/*      */     }
/* 1975 */     int start = this._inputPtr - 1;
/* 1976 */     this._inputPtr = ptr;
/* 1977 */     return _handleOddName2(start, hash, codes);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected String _parseAposName() throws IOException {
/* 1983 */     int ptr = this._inputPtr;
/* 1984 */     int hash = this._hashSeed;
/* 1985 */     int inputLen = this._inputEnd;
/*      */     
/* 1987 */     if (ptr < inputLen) {
/* 1988 */       int[] codes = _icLatin1;
/* 1989 */       int maxCode = codes.length;
/*      */       
/*      */       do {
/* 1992 */         int ch = this._inputBuffer[ptr];
/* 1993 */         if (ch == 39) {
/* 1994 */           int i = this._inputPtr;
/* 1995 */           this._inputPtr = ptr + 1;
/* 1996 */           return this._symbols.findSymbol(this._inputBuffer, i, ptr - i, hash);
/*      */         } 
/* 1998 */         if (ch < maxCode && codes[ch] != 0) {
/*      */           break;
/*      */         }
/* 2001 */         hash = hash * 33 + ch;
/* 2002 */         ++ptr;
/* 2003 */       } while (ptr < inputLen);
/*      */     } 
/*      */     
/* 2006 */     int start = this._inputPtr;
/* 2007 */     this._inputPtr = ptr;
/*      */     
/* 2009 */     return _parseName2(start, hash, 39);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonToken _handleOddValue(int i) throws IOException {
/* 2026 */     switch (i) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 39:
/* 2033 */         if ((this._features & FEAT_MASK_ALLOW_SINGLE_QUOTES) != 0) {
/* 2034 */           return _handleApos();
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 93:
/* 2042 */         if (!this._parsingContext.inArray()) {
/*      */           break;
/*      */         }
/*      */ 
/*      */       
/*      */       case 44:
/* 2048 */         if (!this._parsingContext.inRoot() && (
/* 2049 */           this._features & FEAT_MASK_ALLOW_MISSING) != 0) {
/* 2050 */           this._inputPtr--;
/* 2051 */           return JsonToken.VALUE_NULL;
/*      */         } 
/*      */         break;
/*      */       
/*      */       case 78:
/* 2056 */         _matchToken("NaN", 1);
/* 2057 */         if ((this._features & FEAT_MASK_NON_NUM_NUMBERS) != 0) {
/* 2058 */           return resetAsNaN("NaN", Double.NaN);
/*      */         }
/* 2060 */         _reportError("Non-standard token 'NaN': enable `JsonReadFeature.ALLOW_NON_NUMERIC_NUMBERS` to allow");
/*      */         break;
/*      */       case 73:
/* 2063 */         _matchToken("Infinity", 1);
/* 2064 */         if ((this._features & FEAT_MASK_NON_NUM_NUMBERS) != 0) {
/* 2065 */           return resetAsNaN("Infinity", Double.POSITIVE_INFINITY);
/*      */         }
/* 2067 */         _reportError("Non-standard token 'Infinity': enable `JsonReadFeature.ALLOW_NON_NUMERIC_NUMBERS` to allow");
/*      */         break;
/*      */       case 43:
/* 2070 */         if (this._inputPtr >= this._inputEnd && 
/* 2071 */           !_loadMore()) {
/* 2072 */           _reportInvalidEOFInValue(JsonToken.VALUE_NUMBER_INT);
/*      */         }
/*      */         
/* 2075 */         return _handleInvalidNumberStart(this._inputBuffer[this._inputPtr++], false, true);
/*      */     } 
/*      */     
/* 2078 */     if (Character.isJavaIdentifierStart(i)) {
/* 2079 */       _reportInvalidToken("" + (char)i, _validJsonTokenList());
/*      */     }
/*      */     
/* 2082 */     _reportUnexpectedChar(i, "expected a valid value " + _validJsonValueList());
/* 2083 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _handleApos() throws IOException {
/* 2088 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 2089 */     int outPtr = this._textBuffer.getCurrentSegmentSize();
/*      */     
/*      */     while (true) {
/* 2092 */       if (this._inputPtr >= this._inputEnd && 
/* 2093 */         !_loadMore()) {
/* 2094 */         _reportInvalidEOF(": was expecting closing quote for a string value", JsonToken.VALUE_STRING);
/*      */       }
/*      */ 
/*      */       
/* 2098 */       char c = this._inputBuffer[this._inputPtr++];
/* 2099 */       int i = c;
/* 2100 */       if (i <= 92) {
/* 2101 */         if (i == 92) {
/*      */ 
/*      */ 
/*      */           
/* 2105 */           c = _decodeEscaped();
/* 2106 */         } else if (i <= 39) {
/* 2107 */           if (i == 39) {
/*      */             break;
/*      */           }
/* 2110 */           if (i < 32) {
/* 2111 */             _throwUnquotedSpace(i, "string value");
/*      */           }
/*      */         } 
/*      */       }
/*      */       
/* 2116 */       if (outPtr >= outBuf.length) {
/* 2117 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 2118 */         outPtr = 0;
/*      */       } 
/*      */       
/* 2121 */       outBuf[outPtr++] = c;
/*      */     } 
/* 2123 */     this._textBuffer.setCurrentLength(outPtr);
/* 2124 */     return JsonToken.VALUE_STRING;
/*      */   }
/*      */ 
/*      */   
/*      */   private String _handleOddName2(int startPtr, int hash, int[] codes) throws IOException {
/* 2129 */     this._textBuffer.resetWithShared(this._inputBuffer, startPtr, this._inputPtr - startPtr);
/* 2130 */     char[] outBuf = this._textBuffer.getCurrentSegment();
/* 2131 */     int outPtr = this._textBuffer.getCurrentSegmentSize();
/* 2132 */     int maxCode = codes.length;
/*      */ 
/*      */     
/* 2135 */     while (this._inputPtr < this._inputEnd || 
/* 2136 */       _loadMore()) {
/*      */ 
/*      */ 
/*      */       
/* 2140 */       char c = this._inputBuffer[this._inputPtr];
/* 2141 */       int i = c;
/* 2142 */       if ((i < maxCode) ? (
/* 2143 */         codes[i] != 0) : 
/*      */ 
/*      */         
/* 2146 */         !Character.isJavaIdentifierPart(c)) {
/*      */         break;
/*      */       }
/* 2149 */       this._inputPtr++;
/* 2150 */       hash = hash * 33 + i;
/*      */       
/* 2152 */       outBuf[outPtr++] = c;
/*      */ 
/*      */       
/* 2155 */       if (outPtr >= outBuf.length) {
/* 2156 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 2157 */         outPtr = 0;
/*      */       } 
/*      */     } 
/* 2160 */     this._textBuffer.setCurrentLength(outPtr);
/*      */     
/* 2162 */     TextBuffer tb = this._textBuffer;
/* 2163 */     char[] buf = tb.getTextBuffer();
/* 2164 */     int start = tb.getTextOffset();
/* 2165 */     int len = tb.size();
/*      */     
/* 2167 */     return this._symbols.findSymbol(buf, start, len, hash);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void _finishString() throws IOException {
/* 2178 */     int ptr = this._inputPtr;
/* 2179 */     int inputLen = this._inputEnd;
/*      */     
/* 2181 */     if (ptr < inputLen) {
/* 2182 */       int[] codes = _icLatin1;
/* 2183 */       int maxCode = codes.length;
/*      */       
/*      */       do {
/* 2186 */         int ch = this._inputBuffer[ptr];
/* 2187 */         if (ch < maxCode && codes[ch] != 0) {
/* 2188 */           if (ch == 34) {
/* 2189 */             this._textBuffer.resetWithShared(this._inputBuffer, this._inputPtr, ptr - this._inputPtr);
/* 2190 */             this._inputPtr = ptr + 1;
/*      */             
/*      */             return;
/*      */           } 
/*      */           break;
/*      */         } 
/* 2196 */         ++ptr;
/* 2197 */       } while (ptr < inputLen);
/*      */     } 
/*      */ 
/*      */     
/* 2201 */     this._textBuffer.resetWithCopy(this._inputBuffer, this._inputPtr, ptr - this._inputPtr);
/* 2202 */     this._inputPtr = ptr;
/* 2203 */     _finishString2();
/*      */   }
/*      */ 
/*      */   
/*      */   protected void _finishString2() throws IOException {
/* 2208 */     char[] outBuf = this._textBuffer.getCurrentSegment();
/* 2209 */     int outPtr = this._textBuffer.getCurrentSegmentSize();
/* 2210 */     int[] codes = _icLatin1;
/* 2211 */     int maxCode = codes.length;
/*      */     
/*      */     while (true) {
/* 2214 */       if (this._inputPtr >= this._inputEnd && 
/* 2215 */         !_loadMore()) {
/* 2216 */         _reportInvalidEOF(": was expecting closing quote for a string value", JsonToken.VALUE_STRING);
/*      */       }
/*      */ 
/*      */       
/* 2220 */       char c = this._inputBuffer[this._inputPtr++];
/* 2221 */       int i = c;
/* 2222 */       if (i < maxCode && codes[i] != 0) {
/* 2223 */         if (i == 34)
/*      */           break; 
/* 2225 */         if (i == 92) {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2230 */           c = _decodeEscaped();
/* 2231 */         } else if (i < 32) {
/* 2232 */           _throwUnquotedSpace(i, "string value");
/*      */         } 
/*      */       } 
/*      */       
/* 2236 */       if (outPtr >= outBuf.length) {
/* 2237 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 2238 */         outPtr = 0;
/*      */       } 
/*      */       
/* 2241 */       outBuf[outPtr++] = c;
/*      */     } 
/* 2243 */     this._textBuffer.setCurrentLength(outPtr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void _skipString() throws IOException {
/* 2256 */     this._tokenIncomplete = false;
/*      */     
/* 2258 */     int inPtr = this._inputPtr;
/* 2259 */     int inLen = this._inputEnd;
/* 2260 */     char[] inBuf = this._inputBuffer;
/*      */     
/*      */     while (true) {
/* 2263 */       if (inPtr >= inLen) {
/* 2264 */         this._inputPtr = inPtr;
/* 2265 */         if (!_loadMore()) {
/* 2266 */           _reportInvalidEOF(": was expecting closing quote for a string value", JsonToken.VALUE_STRING);
/*      */         }
/*      */         
/* 2269 */         inPtr = this._inputPtr;
/* 2270 */         inLen = this._inputEnd;
/*      */       } 
/* 2272 */       char c = inBuf[inPtr++];
/* 2273 */       int i = c;
/* 2274 */       if (i <= 92) {
/* 2275 */         if (i == 92) {
/*      */ 
/*      */           
/* 2278 */           this._inputPtr = inPtr;
/* 2279 */           _decodeEscaped();
/* 2280 */           inPtr = this._inputPtr;
/* 2281 */           inLen = this._inputEnd; continue;
/* 2282 */         }  if (i <= 34) {
/* 2283 */           if (i == 34) {
/* 2284 */             this._inputPtr = inPtr;
/*      */             break;
/*      */           } 
/* 2287 */           if (i < 32) {
/* 2288 */             this._inputPtr = inPtr;
/* 2289 */             _throwUnquotedSpace(i, "string value");
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void _skipCR() throws IOException {
/* 2305 */     if ((this._inputPtr < this._inputEnd || _loadMore()) && 
/* 2306 */       this._inputBuffer[this._inputPtr] == '\n') {
/* 2307 */       this._inputPtr++;
/*      */     }
/*      */     
/* 2310 */     this._currInputRow++;
/* 2311 */     this._currInputRowStart = this._inputPtr;
/*      */   }
/*      */ 
/*      */   
/*      */   private final int _skipColon() throws IOException {
/* 2316 */     if (this._inputPtr + 4 >= this._inputEnd) {
/* 2317 */       return _skipColon2(false);
/*      */     }
/* 2319 */     char c = this._inputBuffer[this._inputPtr];
/* 2320 */     if (c == ':') {
/* 2321 */       int i = this._inputBuffer[++this._inputPtr];
/* 2322 */       if (i > 32) {
/* 2323 */         if (i == 47 || i == 35) {
/* 2324 */           return _skipColon2(true);
/*      */         }
/* 2326 */         this._inputPtr++;
/* 2327 */         return i;
/*      */       } 
/* 2329 */       if (i == 32 || i == 9) {
/* 2330 */         i = this._inputBuffer[++this._inputPtr];
/* 2331 */         if (i > 32) {
/* 2332 */           if (i == 47 || i == 35) {
/* 2333 */             return _skipColon2(true);
/*      */           }
/* 2335 */           this._inputPtr++;
/* 2336 */           return i;
/*      */         } 
/*      */       } 
/* 2339 */       return _skipColon2(true);
/*      */     } 
/* 2341 */     if (c == ' ' || c == '\t') {
/* 2342 */       c = this._inputBuffer[++this._inputPtr];
/*      */     }
/* 2344 */     if (c == ':') {
/* 2345 */       int i = this._inputBuffer[++this._inputPtr];
/* 2346 */       if (i > 32) {
/* 2347 */         if (i == 47 || i == 35) {
/* 2348 */           return _skipColon2(true);
/*      */         }
/* 2350 */         this._inputPtr++;
/* 2351 */         return i;
/*      */       } 
/* 2353 */       if (i == 32 || i == 9) {
/* 2354 */         i = this._inputBuffer[++this._inputPtr];
/* 2355 */         if (i > 32) {
/* 2356 */           if (i == 47 || i == 35) {
/* 2357 */             return _skipColon2(true);
/*      */           }
/* 2359 */           this._inputPtr++;
/* 2360 */           return i;
/*      */         } 
/*      */       } 
/* 2363 */       return _skipColon2(true);
/*      */     } 
/* 2365 */     return _skipColon2(false);
/*      */   }
/*      */ 
/*      */   
/*      */   private final int _skipColon2(boolean gotColon) throws IOException {
/* 2370 */     while (this._inputPtr < this._inputEnd || _loadMore()) {
/* 2371 */       int i = this._inputBuffer[this._inputPtr++];
/* 2372 */       if (i > 32) {
/* 2373 */         if (i == 47) {
/* 2374 */           _skipComment();
/*      */           continue;
/*      */         } 
/* 2377 */         if (i == 35 && 
/* 2378 */           _skipYAMLComment()) {
/*      */           continue;
/*      */         }
/*      */         
/* 2382 */         if (gotColon) {
/* 2383 */           return i;
/*      */         }
/* 2385 */         if (i != 58) {
/* 2386 */           _reportUnexpectedChar(i, "was expecting a colon to separate field name and value");
/*      */         }
/* 2388 */         gotColon = true;
/*      */         continue;
/*      */       } 
/* 2391 */       if (i < 32) {
/* 2392 */         if (i == 10) {
/* 2393 */           this._currInputRow++;
/* 2394 */           this._currInputRowStart = this._inputPtr; continue;
/* 2395 */         }  if (i == 13) {
/* 2396 */           _skipCR(); continue;
/* 2397 */         }  if (i != 9) {
/* 2398 */           _throwInvalidSpace(i);
/*      */         }
/*      */       } 
/*      */     } 
/* 2402 */     _reportInvalidEOF(" within/between " + this._parsingContext.typeDesc() + " entries", null);
/*      */     
/* 2404 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _skipColonFast(int ptr) throws IOException {
/* 2410 */     int i = this._inputBuffer[ptr++];
/* 2411 */     if (i == 58) {
/* 2412 */       i = this._inputBuffer[ptr++];
/* 2413 */       if (i > 32) {
/* 2414 */         if (i != 47 && i != 35) {
/* 2415 */           this._inputPtr = ptr;
/* 2416 */           return i;
/*      */         } 
/* 2418 */       } else if (i == 32 || i == 9) {
/* 2419 */         i = this._inputBuffer[ptr++];
/* 2420 */         if (i > 32 && 
/* 2421 */           i != 47 && i != 35) {
/* 2422 */           this._inputPtr = ptr;
/* 2423 */           return i;
/*      */         } 
/*      */       } 
/*      */       
/* 2427 */       this._inputPtr = ptr - 1;
/* 2428 */       return _skipColon2(true);
/*      */     } 
/* 2430 */     if (i == 32 || i == 9) {
/* 2431 */       i = this._inputBuffer[ptr++];
/*      */     }
/* 2433 */     boolean gotColon = (i == 58);
/* 2434 */     if (gotColon) {
/* 2435 */       i = this._inputBuffer[ptr++];
/* 2436 */       if (i > 32) {
/* 2437 */         if (i != 47 && i != 35) {
/* 2438 */           this._inputPtr = ptr;
/* 2439 */           return i;
/*      */         } 
/* 2441 */       } else if (i == 32 || i == 9) {
/* 2442 */         i = this._inputBuffer[ptr++];
/* 2443 */         if (i > 32 && 
/* 2444 */           i != 47 && i != 35) {
/* 2445 */           this._inputPtr = ptr;
/* 2446 */           return i;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 2451 */     this._inputPtr = ptr - 1;
/* 2452 */     return _skipColon2(gotColon);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _skipComma(int i) throws IOException {
/* 2458 */     if (i != 44) {
/* 2459 */       _reportUnexpectedChar(i, "was expecting comma to separate " + this._parsingContext.typeDesc() + " entries");
/*      */     }
/* 2461 */     while (this._inputPtr < this._inputEnd) {
/* 2462 */       i = this._inputBuffer[this._inputPtr++];
/* 2463 */       if (i > 32) {
/* 2464 */         if (i == 47 || i == 35) {
/* 2465 */           this._inputPtr--;
/* 2466 */           return _skipAfterComma2();
/*      */         } 
/* 2468 */         return i;
/*      */       } 
/* 2470 */       if (i < 32) {
/* 2471 */         if (i == 10) {
/* 2472 */           this._currInputRow++;
/* 2473 */           this._currInputRowStart = this._inputPtr; continue;
/* 2474 */         }  if (i == 13) {
/* 2475 */           _skipCR(); continue;
/* 2476 */         }  if (i != 9) {
/* 2477 */           _throwInvalidSpace(i);
/*      */         }
/*      */       } 
/*      */     } 
/* 2481 */     return _skipAfterComma2();
/*      */   }
/*      */ 
/*      */   
/*      */   private final int _skipAfterComma2() throws IOException {
/* 2486 */     while (this._inputPtr < this._inputEnd || _loadMore()) {
/* 2487 */       int i = this._inputBuffer[this._inputPtr++];
/* 2488 */       if (i > 32) {
/* 2489 */         if (i == 47) {
/* 2490 */           _skipComment();
/*      */           continue;
/*      */         } 
/* 2493 */         if (i == 35 && 
/* 2494 */           _skipYAMLComment()) {
/*      */           continue;
/*      */         }
/*      */         
/* 2498 */         return i;
/*      */       } 
/* 2500 */       if (i < 32) {
/* 2501 */         if (i == 10) {
/* 2502 */           this._currInputRow++;
/* 2503 */           this._currInputRowStart = this._inputPtr; continue;
/* 2504 */         }  if (i == 13) {
/* 2505 */           _skipCR(); continue;
/* 2506 */         }  if (i != 9) {
/* 2507 */           _throwInvalidSpace(i);
/*      */         }
/*      */       } 
/*      */     } 
/* 2511 */     throw _constructError("Unexpected end-of-input within/between " + this._parsingContext.typeDesc() + " entries");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _skipWSOrEnd() throws IOException {
/* 2518 */     if (this._inputPtr >= this._inputEnd && 
/* 2519 */       !_loadMore()) {
/* 2520 */       return _eofAsNextChar();
/*      */     }
/*      */     
/* 2523 */     int i = this._inputBuffer[this._inputPtr++];
/* 2524 */     if (i > 32) {
/* 2525 */       if (i == 47 || i == 35) {
/* 2526 */         this._inputPtr--;
/* 2527 */         return _skipWSOrEnd2();
/*      */       } 
/* 2529 */       return i;
/*      */     } 
/* 2531 */     if (i != 32) {
/* 2532 */       if (i == 10) {
/* 2533 */         this._currInputRow++;
/* 2534 */         this._currInputRowStart = this._inputPtr;
/* 2535 */       } else if (i == 13) {
/* 2536 */         _skipCR();
/* 2537 */       } else if (i != 9) {
/* 2538 */         _throwInvalidSpace(i);
/*      */       } 
/*      */     }
/*      */     
/* 2542 */     while (this._inputPtr < this._inputEnd) {
/* 2543 */       i = this._inputBuffer[this._inputPtr++];
/* 2544 */       if (i > 32) {
/* 2545 */         if (i == 47 || i == 35) {
/* 2546 */           this._inputPtr--;
/* 2547 */           return _skipWSOrEnd2();
/*      */         } 
/* 2549 */         return i;
/*      */       } 
/* 2551 */       if (i != 32) {
/* 2552 */         if (i == 10) {
/* 2553 */           this._currInputRow++;
/* 2554 */           this._currInputRowStart = this._inputPtr; continue;
/* 2555 */         }  if (i == 13) {
/* 2556 */           _skipCR(); continue;
/* 2557 */         }  if (i != 9) {
/* 2558 */           _throwInvalidSpace(i);
/*      */         }
/*      */       } 
/*      */     } 
/* 2562 */     return _skipWSOrEnd2();
/*      */   }
/*      */ 
/*      */   
/*      */   private int _skipWSOrEnd2() throws IOException {
/*      */     while (true) {
/* 2568 */       if (this._inputPtr >= this._inputEnd && 
/* 2569 */         !_loadMore()) {
/* 2570 */         return _eofAsNextChar();
/*      */       }
/*      */       
/* 2573 */       int i = this._inputBuffer[this._inputPtr++];
/* 2574 */       if (i > 32) {
/* 2575 */         if (i == 47) {
/* 2576 */           _skipComment();
/*      */           continue;
/*      */         } 
/* 2579 */         if (i == 35 && 
/* 2580 */           _skipYAMLComment()) {
/*      */           continue;
/*      */         }
/*      */         
/* 2584 */         return i;
/* 2585 */       }  if (i != 32) {
/* 2586 */         if (i == 10) {
/* 2587 */           this._currInputRow++;
/* 2588 */           this._currInputRowStart = this._inputPtr; continue;
/* 2589 */         }  if (i == 13) {
/* 2590 */           _skipCR(); continue;
/* 2591 */         }  if (i != 9) {
/* 2592 */           _throwInvalidSpace(i);
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void _skipComment() throws IOException {
/* 2600 */     if ((this._features & FEAT_MASK_ALLOW_JAVA_COMMENTS) == 0) {
/* 2601 */       _reportUnexpectedChar(47, "maybe a (non-standard) comment? (not recognized as one since Feature 'ALLOW_COMMENTS' not enabled for parser)");
/*      */     }
/*      */     
/* 2604 */     if (this._inputPtr >= this._inputEnd && !_loadMore()) {
/* 2605 */       _reportInvalidEOF(" in a comment", null);
/*      */     }
/* 2607 */     char c = this._inputBuffer[this._inputPtr++];
/* 2608 */     if (c == '/') {
/* 2609 */       _skipLine();
/* 2610 */     } else if (c == '*') {
/* 2611 */       _skipCComment();
/*      */     } else {
/* 2613 */       _reportUnexpectedChar(c, "was expecting either '*' or '/' for a comment");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void _skipCComment() throws IOException {
/* 2620 */     while (this._inputPtr < this._inputEnd || _loadMore()) {
/* 2621 */       int i = this._inputBuffer[this._inputPtr++];
/* 2622 */       if (i <= 42) {
/* 2623 */         if (i == 42) {
/* 2624 */           if (this._inputPtr >= this._inputEnd && !_loadMore()) {
/*      */             break;
/*      */           }
/* 2627 */           if (this._inputBuffer[this._inputPtr] == '/') {
/* 2628 */             this._inputPtr++;
/*      */             return;
/*      */           } 
/*      */           continue;
/*      */         } 
/* 2633 */         if (i < 32) {
/* 2634 */           if (i == 10) {
/* 2635 */             this._currInputRow++;
/* 2636 */             this._currInputRowStart = this._inputPtr; continue;
/* 2637 */           }  if (i == 13) {
/* 2638 */             _skipCR(); continue;
/* 2639 */           }  if (i != 9) {
/* 2640 */             _throwInvalidSpace(i);
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/* 2645 */     _reportInvalidEOF(" in a comment", null);
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean _skipYAMLComment() throws IOException {
/* 2650 */     if ((this._features & FEAT_MASK_ALLOW_YAML_COMMENTS) == 0) {
/* 2651 */       return false;
/*      */     }
/* 2653 */     _skipLine();
/* 2654 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void _skipLine() throws IOException {
/* 2660 */     while (this._inputPtr < this._inputEnd || _loadMore()) {
/* 2661 */       int i = this._inputBuffer[this._inputPtr++];
/* 2662 */       if (i < 32) {
/* 2663 */         if (i == 10) {
/* 2664 */           this._currInputRow++;
/* 2665 */           this._currInputRowStart = this._inputPtr; break;
/*      */         } 
/* 2667 */         if (i == 13) {
/* 2668 */           _skipCR(); break;
/*      */         } 
/* 2670 */         if (i != 9) {
/* 2671 */           _throwInvalidSpace(i);
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected char _decodeEscaped() throws IOException {
/* 2680 */     if (this._inputPtr >= this._inputEnd && 
/* 2681 */       !_loadMore()) {
/* 2682 */       _reportInvalidEOF(" in character escape sequence", JsonToken.VALUE_STRING);
/*      */     }
/*      */     
/* 2685 */     char c = this._inputBuffer[this._inputPtr++];
/*      */     
/* 2687 */     switch (c) {
/*      */       
/*      */       case 'b':
/* 2690 */         return '\b';
/*      */       case 't':
/* 2692 */         return '\t';
/*      */       case 'n':
/* 2694 */         return '\n';
/*      */       case 'f':
/* 2696 */         return '\f';
/*      */       case 'r':
/* 2698 */         return '\r';
/*      */ 
/*      */       
/*      */       case '"':
/*      */       case '/':
/*      */       case '\\':
/* 2704 */         return c;
/*      */       
/*      */       case 'u':
/*      */         break;
/*      */       
/*      */       default:
/* 2710 */         return _handleUnrecognizedCharacterEscape(c);
/*      */     } 
/*      */ 
/*      */     
/* 2714 */     int value = 0;
/* 2715 */     for (int i = 0; i < 4; i++) {
/* 2716 */       if (this._inputPtr >= this._inputEnd && 
/* 2717 */         !_loadMore()) {
/* 2718 */         _reportInvalidEOF(" in character escape sequence", JsonToken.VALUE_STRING);
/*      */       }
/*      */       
/* 2721 */       int ch = this._inputBuffer[this._inputPtr++];
/* 2722 */       int digit = CharTypes.charToHex(ch);
/* 2723 */       if (digit < 0) {
/* 2724 */         _reportUnexpectedChar(ch, "expected a hex-digit for character escape sequence");
/*      */       }
/* 2726 */       value = value << 4 | digit;
/*      */     } 
/* 2728 */     return (char)value;
/*      */   }
/*      */   
/*      */   private final void _matchTrue() throws IOException {
/* 2732 */     int ptr = this._inputPtr;
/* 2733 */     if (ptr + 3 < this._inputEnd) {
/* 2734 */       char[] b = this._inputBuffer;
/* 2735 */       if (b[ptr] == 'r' && b[++ptr] == 'u' && b[++ptr] == 'e') {
/* 2736 */         char c = b[++ptr];
/* 2737 */         if (c < '0' || c == ']' || c == '}') {
/* 2738 */           this._inputPtr = ptr;
/*      */           
/*      */           return;
/*      */         } 
/*      */       } 
/*      */     } 
/* 2744 */     _matchToken("true", 1);
/*      */   }
/*      */   
/*      */   private final void _matchFalse() throws IOException {
/* 2748 */     int ptr = this._inputPtr;
/* 2749 */     if (ptr + 4 < this._inputEnd) {
/* 2750 */       char[] b = this._inputBuffer;
/* 2751 */       if (b[ptr] == 'a' && b[++ptr] == 'l' && b[++ptr] == 's' && b[++ptr] == 'e') {
/* 2752 */         char c = b[++ptr];
/* 2753 */         if (c < '0' || c == ']' || c == '}') {
/* 2754 */           this._inputPtr = ptr;
/*      */           
/*      */           return;
/*      */         } 
/*      */       } 
/*      */     } 
/* 2760 */     _matchToken("false", 1);
/*      */   }
/*      */   
/*      */   private final void _matchNull() throws IOException {
/* 2764 */     int ptr = this._inputPtr;
/* 2765 */     if (ptr + 3 < this._inputEnd) {
/* 2766 */       char[] b = this._inputBuffer;
/* 2767 */       if (b[ptr] == 'u' && b[++ptr] == 'l' && b[++ptr] == 'l') {
/* 2768 */         char c = b[++ptr];
/* 2769 */         if (c < '0' || c == ']' || c == '}') {
/* 2770 */           this._inputPtr = ptr;
/*      */           
/*      */           return;
/*      */         } 
/*      */       } 
/*      */     } 
/* 2776 */     _matchToken("null", 1);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void _matchToken(String matchStr, int i) throws IOException {
/* 2782 */     int len = matchStr.length();
/* 2783 */     if (this._inputPtr + len >= this._inputEnd) {
/* 2784 */       _matchToken2(matchStr, i);
/*      */       
/*      */       return;
/*      */     } 
/*      */     while (true) {
/* 2789 */       if (this._inputBuffer[this._inputPtr] != matchStr.charAt(i)) {
/* 2790 */         _reportInvalidToken(matchStr.substring(0, i));
/*      */       }
/* 2792 */       this._inputPtr++;
/* 2793 */       if (++i >= len) {
/* 2794 */         int ch = this._inputBuffer[this._inputPtr];
/* 2795 */         if (ch >= 48 && ch != 93 && ch != 125)
/* 2796 */           _checkMatchEnd(matchStr, i, ch); 
/*      */         return;
/*      */       } 
/*      */     } 
/*      */   }
/*      */   private final void _matchToken2(String matchStr, int i) throws IOException {
/* 2802 */     int len = matchStr.length();
/*      */     do {
/* 2804 */       if ((this._inputPtr >= this._inputEnd && !_loadMore()) || this._inputBuffer[this._inputPtr] != matchStr
/* 2805 */         .charAt(i)) {
/* 2806 */         _reportInvalidToken(matchStr.substring(0, i));
/*      */       }
/* 2808 */       this._inputPtr++;
/* 2809 */     } while (++i < len);
/*      */ 
/*      */     
/* 2812 */     if (this._inputPtr >= this._inputEnd && !_loadMore()) {
/*      */       return;
/*      */     }
/* 2815 */     int ch = this._inputBuffer[this._inputPtr];
/* 2816 */     if (ch >= 48 && ch != 93 && ch != 125) {
/* 2817 */       _checkMatchEnd(matchStr, i, ch);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private final void _checkMatchEnd(String matchStr, int i, int c) throws IOException {
/* 2823 */     char ch = (char)c;
/* 2824 */     if (Character.isJavaIdentifierPart(ch)) {
/* 2825 */       _reportInvalidToken(matchStr.substring(0, i));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected byte[] _decodeBase64(Base64Variant b64variant) throws IOException {
/* 2849 */     ByteArrayBuilder builder = _getByteArrayBuilder();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/* 2856 */       if (this._inputPtr >= this._inputEnd) {
/* 2857 */         _loadMoreGuaranteed();
/*      */       }
/* 2859 */       char ch = this._inputBuffer[this._inputPtr++];
/* 2860 */       if (ch > ' ') {
/* 2861 */         int bits = b64variant.decodeBase64Char(ch);
/* 2862 */         if (bits < 0) {
/* 2863 */           if (ch == '"') {
/* 2864 */             return builder.toByteArray();
/*      */           }
/* 2866 */           bits = _decodeBase64Escape(b64variant, ch, 0);
/* 2867 */           if (bits < 0) {
/*      */             continue;
/*      */           }
/*      */         } 
/* 2871 */         int decodedData = bits;
/*      */ 
/*      */ 
/*      */         
/* 2875 */         if (this._inputPtr >= this._inputEnd) {
/* 2876 */           _loadMoreGuaranteed();
/*      */         }
/* 2878 */         ch = this._inputBuffer[this._inputPtr++];
/* 2879 */         bits = b64variant.decodeBase64Char(ch);
/* 2880 */         if (bits < 0) {
/* 2881 */           bits = _decodeBase64Escape(b64variant, ch, 1);
/*      */         }
/* 2883 */         decodedData = decodedData << 6 | bits;
/*      */ 
/*      */         
/* 2886 */         if (this._inputPtr >= this._inputEnd) {
/* 2887 */           _loadMoreGuaranteed();
/*      */         }
/* 2889 */         ch = this._inputBuffer[this._inputPtr++];
/* 2890 */         bits = b64variant.decodeBase64Char(ch);
/*      */ 
/*      */         
/* 2893 */         if (bits < 0) {
/* 2894 */           if (bits != -2) {
/*      */             
/* 2896 */             if (ch == '"') {
/* 2897 */               decodedData >>= 4;
/* 2898 */               builder.append(decodedData);
/* 2899 */               if (b64variant.usesPadding()) {
/* 2900 */                 this._inputPtr--;
/* 2901 */                 _handleBase64MissingPadding(b64variant);
/*      */               } 
/* 2903 */               return builder.toByteArray();
/*      */             } 
/* 2905 */             bits = _decodeBase64Escape(b64variant, ch, 2);
/*      */           } 
/* 2907 */           if (bits == -2) {
/*      */             
/* 2909 */             if (this._inputPtr >= this._inputEnd) {
/* 2910 */               _loadMoreGuaranteed();
/*      */             }
/* 2912 */             ch = this._inputBuffer[this._inputPtr++];
/* 2913 */             if (!b64variant.usesPaddingChar(ch) && 
/* 2914 */               _decodeBase64Escape(b64variant, ch, 3) != -2) {
/* 2915 */               throw reportInvalidBase64Char(b64variant, ch, 3, "expected padding character '" + b64variant.getPaddingChar() + "'");
/*      */             }
/*      */ 
/*      */             
/* 2919 */             decodedData >>= 4;
/* 2920 */             builder.append(decodedData);
/*      */             
/*      */             continue;
/*      */           } 
/*      */         } 
/*      */         
/* 2926 */         decodedData = decodedData << 6 | bits;
/*      */         
/* 2928 */         if (this._inputPtr >= this._inputEnd) {
/* 2929 */           _loadMoreGuaranteed();
/*      */         }
/* 2931 */         ch = this._inputBuffer[this._inputPtr++];
/* 2932 */         bits = b64variant.decodeBase64Char(ch);
/* 2933 */         if (bits < 0) {
/* 2934 */           if (bits != -2) {
/*      */             
/* 2936 */             if (ch == '"') {
/* 2937 */               decodedData >>= 2;
/* 2938 */               builder.appendTwoBytes(decodedData);
/* 2939 */               if (b64variant.usesPadding()) {
/* 2940 */                 this._inputPtr--;
/* 2941 */                 _handleBase64MissingPadding(b64variant);
/*      */               } 
/* 2943 */               return builder.toByteArray();
/*      */             } 
/* 2945 */             bits = _decodeBase64Escape(b64variant, ch, 3);
/*      */           } 
/* 2947 */           if (bits == -2) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 2953 */             decodedData >>= 2;
/* 2954 */             builder.appendTwoBytes(decodedData);
/*      */             
/*      */             continue;
/*      */           } 
/*      */         } 
/*      */         
/* 2960 */         decodedData = decodedData << 6 | bits;
/* 2961 */         builder.appendThreeBytes(decodedData);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonLocation getTokenLocation() {
/* 2974 */     if (this._currToken == JsonToken.FIELD_NAME) {
/* 2975 */       long total = this._currInputProcessed + this._nameStartOffset - 1L;
/* 2976 */       return new JsonLocation(_contentReference(), -1L, total, this._nameStartRow, this._nameStartCol);
/*      */     } 
/*      */     
/* 2979 */     return new JsonLocation(_contentReference(), -1L, this._tokenInputTotal - 1L, this._tokenInputRow, this._tokenInputCol);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonLocation getCurrentLocation() {
/* 2985 */     int col = this._inputPtr - this._currInputRowStart + 1;
/* 2986 */     return new JsonLocation(_contentReference(), -1L, this._currInputProcessed + this._inputPtr, this._currInputRow, col);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _updateLocation() {
/* 2994 */     int ptr = this._inputPtr;
/* 2995 */     this._tokenInputTotal = this._currInputProcessed + ptr;
/* 2996 */     this._tokenInputRow = this._currInputRow;
/* 2997 */     this._tokenInputCol = ptr - this._currInputRowStart;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _updateNameLocation() {
/* 3003 */     int ptr = this._inputPtr;
/* 3004 */     this._nameStartOffset = ptr;
/* 3005 */     this._nameStartRow = this._currInputRow;
/* 3006 */     this._nameStartCol = ptr - this._currInputRowStart;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _reportInvalidToken(String matchedPart) throws IOException {
/* 3016 */     _reportInvalidToken(matchedPart, _validJsonTokenList());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _reportInvalidToken(String matchedPart, String msg) throws IOException {
/* 3025 */     StringBuilder sb = new StringBuilder(matchedPart);
/* 3026 */     while (this._inputPtr < this._inputEnd || _loadMore()) {
/* 3027 */       char c = this._inputBuffer[this._inputPtr];
/* 3028 */       if (!Character.isJavaIdentifierPart(c)) {
/*      */         break;
/*      */       }
/* 3031 */       this._inputPtr++;
/* 3032 */       sb.append(c);
/* 3033 */       if (sb.length() >= 256) {
/* 3034 */         sb.append("...");
/*      */         break;
/*      */       } 
/*      */     } 
/* 3038 */     _reportError("Unrecognized token '%s': was expecting %s", sb, msg);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void _closeScope(int i) throws JsonParseException {
/* 3048 */     if (i == 93) {
/* 3049 */       _updateLocation();
/* 3050 */       if (!this._parsingContext.inArray()) {
/* 3051 */         _reportMismatchedEndMarker(i, '}');
/*      */       }
/* 3053 */       this._parsingContext = this._parsingContext.clearAndGetParent();
/* 3054 */       this._currToken = JsonToken.END_ARRAY;
/*      */     } 
/* 3056 */     if (i == 125) {
/* 3057 */       _updateLocation();
/* 3058 */       if (!this._parsingContext.inObject()) {
/* 3059 */         _reportMismatchedEndMarker(i, ']');
/*      */       }
/* 3061 */       this._parsingContext = this._parsingContext.clearAndGetParent();
/* 3062 */       this._currToken = JsonToken.END_OBJECT;
/*      */     } 
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-core-2.14.2.jar!\com\fasterxml\jackson\core\json\ReaderBasedJsonParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */