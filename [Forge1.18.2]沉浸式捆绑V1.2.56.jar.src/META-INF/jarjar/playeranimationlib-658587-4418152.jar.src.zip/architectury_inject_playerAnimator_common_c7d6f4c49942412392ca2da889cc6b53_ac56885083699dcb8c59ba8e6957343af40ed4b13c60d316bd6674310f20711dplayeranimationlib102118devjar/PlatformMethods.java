package architectury_inject_playerAnimator_common_c7d6f4c49942412392ca2da889cc6b53_ac56885083699dcb8c59ba8e6957343af40ed4b13c60d316bd6674310f20711dplayeranimationlib102118devjar;

public final class PlatformMethods {
  public static String getCurrentTarget() {
    return "forge";
  }
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\architectury_inject_playerAnimator_common_c7d6f4c49942412392ca2da889cc6b53_ac56885083699dcb8c59ba8e6957343af40ed4b13c60d316bd6674310f20711dplayeranimationlib102118devjar\PlatformMethods.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */