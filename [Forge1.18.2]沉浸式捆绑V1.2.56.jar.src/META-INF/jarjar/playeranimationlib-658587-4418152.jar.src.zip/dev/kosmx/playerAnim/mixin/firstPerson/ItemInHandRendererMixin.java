/*    */ package dev.kosmx.playerAnim.mixin.firstPerson;
/*    */ import com.mojang.blaze3d.vertex.PoseStack;
/*    */ import dev.kosmx.playerAnim.api.firstPerson.FirstPersonConfiguration;
/*    */ import dev.kosmx.playerAnim.api.firstPerson.FirstPersonMode;
/*    */ import dev.kosmx.playerAnim.impl.IAnimatedPlayer;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.player.LocalPlayer;
/*    */ import net.minecraft.client.renderer.ItemInHandRenderer;
/*    */ import net.minecraft.client.renderer.MultiBufferSource;
/*    */ import net.minecraft.client.renderer.block.model.ItemTransforms;
/*    */ import net.minecraft.world.entity.LivingEntity;
/*    */ import net.minecraft.world.item.ItemStack;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ @Mixin({ItemInHandRenderer.class})
/*    */ public class ItemInHandRendererMixin {
/*    */   @Inject(method = {"renderHandsWithItems"}, at = {@At("HEAD")}, cancellable = true)
/*    */   private void disableDefaultItemIfNeeded(float f, PoseStack poseStack, MultiBufferSource.BufferSource bufferSource, LocalPlayer localPlayer, int i, CallbackInfo ci) {
/* 22 */     if (localPlayer instanceof IAnimatedPlayer) { IAnimatedPlayer player = (IAnimatedPlayer)localPlayer; if (player.playerAnimator_getAnimation().getFirstPersonMode() == FirstPersonMode.THIRD_PERSON_MODEL) {
/* 23 */         ci.cancel();
/*    */       } }
/*    */   
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Inject(method = {"renderItem"}, at = {@At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/entity/ItemRenderer;renderStatic(Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/client/renderer/block/model/ItemTransforms$TransformType;ZLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;Lnet/minecraft/world/level/Level;III)V")}, cancellable = true)
/*    */   private void cancelItemRender(LivingEntity entity, ItemStack itemStack, ItemTransforms.TransformType transformType, boolean bl, PoseStack poseStack, MultiBufferSource multiBufferSource, int i, CallbackInfo ci) {
/* 36 */     if (entity != Minecraft.m_91087_().m_91288_()) {
/*    */       return;
/*    */     }
/* 39 */     if (FirstPersonMode.isFirstPersonPass() && entity instanceof IAnimatedPlayer) { IAnimatedPlayer player = (IAnimatedPlayer)entity;
/* 40 */       FirstPersonConfiguration config = player.playerAnimator_getAnimation().getFirstPersonConfiguration();
/* 41 */       if (transformType == ItemTransforms.TransformType.FIRST_PERSON_RIGHT_HAND || transformType == ItemTransforms.TransformType.THIRD_PERSON_RIGHT_HAND) {
/* 42 */         if (!config.isShowRightItem()) {
/* 43 */           ci.cancel();
/*    */         }
/*    */       }
/* 46 */       else if (!config.isShowLeftItem()) {
/* 47 */         ci.cancel();
/*    */       }  }
/*    */   
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\mixin\firstPerson\ItemInHandRendererMixin.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */