/*    */ package dev.kosmx.playerAnim.mixin.firstPerson;
/*    */ 
/*    */ import com.mojang.blaze3d.vertex.PoseStack;
/*    */ import dev.kosmx.playerAnim.api.firstPerson.FirstPersonMode;
/*    */ import java.util.List;
/*    */ import net.minecraft.client.renderer.MultiBufferSource;
/*    */ import net.minecraft.client.renderer.entity.LivingEntityRenderer;
/*    */ import net.minecraft.world.entity.LivingEntity;
/*    */ import org.spongepowered.asm.mixin.Final;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Redirect;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin(value = {LivingEntityRenderer.class}, priority = 2000)
/*    */ public class LivingEntityRendererMixin
/*    */ {
/*    */   @Shadow
/*    */   @Final
/*    */   protected List<Object> f_115291_;
/*    */   
/*    */   @Redirect(method = {"render(Lnet/minecraft/world/entity/LivingEntity;FFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V"}, at = @At(value = "FIELD", target = "Lnet/minecraft/client/renderer/entity/LivingEntityRenderer;layers:Ljava/util/List;", opcode = 180))
/*    */   private List<Object> filterLayers(LivingEntityRenderer instance, LivingEntity entity, float f, float g, PoseStack poseStack, MultiBufferSource multiBufferSource, int i) {
/* 27 */     if (entity instanceof net.minecraft.client.player.LocalPlayer && FirstPersonMode.isFirstPersonPass())
/* 28 */       return this.f_115291_.stream().filter(layer -> layer instanceof net.minecraft.client.renderer.entity.layers.PlayerItemInHandLayer).toList(); 
/* 29 */     return this.f_115291_;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\mixin\firstPerson\LivingEntityRendererMixin.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */