package dev.kosmx.playerAnim.mixin.firstPerson;

import net.minecraft.client.Camera;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({Camera.class})
public interface CameraAccessor {
  @Accessor
  void setDetached(boolean paramBoolean);
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\mixin\firstPerson\CameraAccessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */