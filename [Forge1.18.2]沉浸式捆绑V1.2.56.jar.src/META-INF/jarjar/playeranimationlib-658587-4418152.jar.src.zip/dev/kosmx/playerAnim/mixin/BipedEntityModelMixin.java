/*     */ package dev.kosmx.playerAnim.mixin;
/*     */ import com.mojang.blaze3d.vertex.PoseStack;
/*     */ import com.mojang.blaze3d.vertex.VertexConsumer;
/*     */ import dev.kosmx.playerAnim.core.impl.AnimationProcessor;
/*     */ import dev.kosmx.playerAnim.core.util.SetableSupplier;
/*     */ import dev.kosmx.playerAnim.impl.Helper;
/*     */ import dev.kosmx.playerAnim.impl.IMutableModel;
/*     */ import dev.kosmx.playerAnim.impl.IUpperPartHelper;
/*     */ import dev.kosmx.playerAnim.impl.animation.IBendHelper;
/*     */ import java.util.function.Function;
/*     */ import net.minecraft.client.model.HumanoidModel;
/*     */ import net.minecraft.client.model.geom.ModelPart;
/*     */ import net.minecraft.client.renderer.RenderType;
/*     */ import net.minecraft.core.Direction;
/*     */ import net.minecraft.resources.ResourceLocation;
/*     */ import net.minecraft.world.entity.LivingEntity;
/*     */ import org.spongepowered.asm.mixin.Final;
/*     */ import org.spongepowered.asm.mixin.Mixin;
/*     */ import org.spongepowered.asm.mixin.Shadow;
/*     */ import org.spongepowered.asm.mixin.injection.At;
/*     */ import org.spongepowered.asm.mixin.injection.Inject;
/*     */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*     */ 
/*     */ @Mixin({HumanoidModel.class})
/*     */ public abstract class BipedEntityModelMixin<T extends LivingEntity> extends AgeableListModel<T> implements IMutableModel {
/*     */   @Final
/*     */   @Shadow
/*     */   public ModelPart f_102811_;
/*     */   @Final
/*     */   @Shadow
/*     */   public ModelPart f_102812_;
/*     */   @Unique
/*  33 */   private SetableSupplier<AnimationProcessor> animation = new SetableSupplier();
/*     */   @Final
/*     */   @Shadow
/*     */   public ModelPart f_102810_;
/*     */   @Inject(method = {"<init>(Lnet/minecraft/client/model/geom/ModelPart;Ljava/util/function/Function;)V"}, at = {@At("RETURN")})
/*  38 */   private void initBend(ModelPart modelPart, Function<ResourceLocation, RenderType> function, CallbackInfo ci) { IBendHelper.INSTANCE.initBend(modelPart.m_171324_("body"), Direction.DOWN);
/*  39 */     IBendHelper.INSTANCE.initBend(modelPart.m_171324_("right_arm"), Direction.UP);
/*  40 */     IBendHelper.INSTANCE.initBend(modelPart.m_171324_("left_arm"), Direction.UP);
/*  41 */     IBendHelper.INSTANCE.initBend(modelPart.m_171324_("right_leg"), Direction.UP);
/*  42 */     IBendHelper.INSTANCE.initBend(modelPart.m_171324_("left_leg"), Direction.UP);
/*  43 */     ((IUpperPartHelper)this.f_102811_).setUpperPart(true);
/*  44 */     ((IUpperPartHelper)this.f_102812_).setUpperPart(true);
/*  45 */     ((IUpperPartHelper)this.f_102808_).setUpperPart(true);
/*  46 */     ((IUpperPartHelper)this.f_102809_).setUpperPart(true); } @Shadow
/*     */   @Final
/*     */   public ModelPart f_102808_; @Shadow
/*     */   @Final
/*     */   public ModelPart f_102809_; public void setEmoteSupplier(SetableSupplier<AnimationProcessor> emoteSupplier) {
/*  51 */     this.animation = emoteSupplier;
/*     */   }
/*     */   
/*     */   @Inject(method = {"copyPropertiesTo"}, at = {@At("RETURN")})
/*     */   private void copyMutatedAttributes(HumanoidModel<T> bipedEntityModel, CallbackInfo ci) {
/*  56 */     if (this.animation != null) {
/*  57 */       ((IMutableModel)bipedEntityModel).setEmoteSupplier(this.animation);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @Intrinsic(displace = true)
/*     */   public void m_7695_(PoseStack matrices, VertexConsumer vertices, int light, int overlay, float red, float green, float blue, float alpha) {
/*  64 */     if (Helper.isBendEnabled() && this.animation.get() != null && ((AnimationProcessor)this.animation.get()).isActive())
/*  65 */     { m_5607_().forEach(part -> {
/*     */             if (!((IUpperPartHelper)part).isUpperPart()) {
/*     */               part.m_104306_(matrices, vertices, light, overlay, red, green, blue, alpha);
/*     */             }
/*     */           });
/*  70 */       m_5608_().forEach(part -> {
/*     */             if (!((IUpperPartHelper)part).isUpperPart()) {
/*     */               part.m_104306_(matrices, vertices, light, overlay, red, green, blue, alpha);
/*     */             }
/*     */           });
/*     */       
/*  76 */       SetableSupplier<AnimationProcessor> emoteSupplier = this.animation;
/*  77 */       matrices.m_85836_();
/*  78 */       IBendHelper.rotateMatrixStack(matrices, ((AnimationProcessor)emoteSupplier.get()).getBend("body"));
/*  79 */       m_5607_().forEach(part -> {
/*     */             if (((IUpperPartHelper)part).isUpperPart()) {
/*     */               part.m_104306_(matrices, vertices, light, overlay, red, green, blue, alpha);
/*     */             }
/*     */           });
/*  84 */       m_5608_().forEach(part -> {
/*     */             if (((IUpperPartHelper)part).isUpperPart()) {
/*     */               part.m_104306_(matrices, vertices, light, overlay, red, green, blue, alpha);
/*     */             }
/*     */           });
/*  89 */       matrices.m_85849_(); }
/*  90 */     else { super.m_7695_(matrices, vertices, light, overlay, red, green, blue, alpha); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SetableSupplier<AnimationProcessor> getEmoteSupplier() {
/* 102 */     return this.animation;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\mixin\BipedEntityModelMixin.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */