/*    */ package dev.kosmx.playerAnim.mixin;
/*    */ 
/*    */ import com.mojang.blaze3d.vertex.PoseStack;
/*    */ import com.mojang.math.Vector3f;
/*    */ import dev.kosmx.playerAnim.api.TransformType;
/*    */ import dev.kosmx.playerAnim.core.util.Pair;
/*    */ import dev.kosmx.playerAnim.core.util.Vec3f;
/*    */ import dev.kosmx.playerAnim.impl.Helper;
/*    */ import dev.kosmx.playerAnim.impl.IAnimatedPlayer;
/*    */ import dev.kosmx.playerAnim.impl.animation.AnimationApplier;
/*    */ import net.minecraft.client.renderer.MultiBufferSource;
/*    */ import net.minecraft.client.renderer.block.model.ItemTransforms;
/*    */ import net.minecraft.client.renderer.entity.layers.ItemInHandLayer;
/*    */ import net.minecraft.world.entity.HumanoidArm;
/*    */ import net.minecraft.world.entity.LivingEntity;
/*    */ import net.minecraft.world.item.ItemStack;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ @Mixin({ItemInHandLayer.class})
/*    */ public class HeldItemMixin
/*    */ {
/*    */   @Inject(method = {"renderArmWithItem"}, at = {@At(value = "INVOKE", target = "Lcom/mojang/blaze3d/vertex/PoseStack;mulPose(Lcom/mojang/math/Quaternion;)V", ordinal = 0)})
/*    */   private void renderMixin(LivingEntity livingEntity, ItemStack stack, ItemTransforms.TransformType transformationMode, HumanoidArm arm, PoseStack matrices, MultiBufferSource vertexConsumers, int light, CallbackInfo ci) {
/* 27 */     if (Helper.isBendEnabled() && livingEntity instanceof IAnimatedPlayer) { IAnimatedPlayer player = (IAnimatedPlayer)livingEntity;
/* 28 */       if (player.playerAnimator_getAnimation().isActive()) {
/* 29 */         AnimationApplier animationApplier = player.playerAnimator_getAnimation();
/*    */         
/* 31 */         Vec3f data = animationApplier.get3DTransform((arm == HumanoidArm.LEFT) ? "leftArm" : "rightArm", TransformType.BEND, new Vec3f(0.0F, 0.0F, 0.0F));
/*    */         
/* 33 */         Pair<Float, Float> pair = new Pair(data.getX(), data.getY());
/*    */         
/* 35 */         float offset = 0.25F;
/* 36 */         matrices.m_85837_(0.0D, offset, 0.0D);
/* 37 */         float bend = ((Float)pair.getRight()).floatValue();
/* 38 */         float axisf = -((Float)pair.getLeft()).floatValue();
/* 39 */         Vector3f axis = new Vector3f((float)Math.cos(axisf), 0.0F, (float)Math.sin(axisf));
/*    */         
/* 41 */         matrices.m_85845_(axis.m_122270_(bend));
/* 42 */         matrices.m_85837_(0.0D, -offset, 0.0D);
/*    */       }  }
/*    */   
/*    */   }
/*    */ 
/*    */   
/*    */   @Inject(method = {"renderArmWithItem"}, at = {@At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/ItemInHandRenderer;renderItem(Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/client/renderer/block/model/ItemTransforms$TransformType;ZLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V")})
/*    */   private void changeItemLocation(LivingEntity livingEntity, ItemStack itemStack, ItemTransforms.TransformType transformType, HumanoidArm arm, PoseStack matrices, MultiBufferSource multiBufferSource, int i, CallbackInfo ci) {
/* 50 */     if (livingEntity instanceof IAnimatedPlayer) { IAnimatedPlayer player = (IAnimatedPlayer)livingEntity;
/* 51 */       if (player.playerAnimator_getAnimation().isActive()) {
/* 52 */         AnimationApplier animationApplier = player.playerAnimator_getAnimation();
/*    */         
/* 54 */         Vec3f rot = animationApplier.get3DTransform((arm == HumanoidArm.LEFT) ? "leftItem" : "rightItem", TransformType.ROTATION, Vec3f.ZERO);
/* 55 */         Vec3f pos = animationApplier.get3DTransform((arm == HumanoidArm.LEFT) ? "leftItem" : "rightItem", TransformType.POSITION, Vec3f.ZERO).scale(0.0625F);
/*    */         
/* 57 */         matrices.m_85837_(((Float)pos.getX()).floatValue(), ((Float)pos.getY()).floatValue(), ((Float)pos.getZ()).floatValue());
/*    */         
/* 59 */         matrices.m_85845_(Vector3f.f_122227_.m_122270_(((Float)rot.getZ()).floatValue()));
/* 60 */         matrices.m_85845_(Vector3f.f_122225_.m_122270_(((Float)rot.getY()).floatValue()));
/* 61 */         matrices.m_85845_(Vector3f.f_122223_.m_122270_(((Float)rot.getX()).floatValue()));
/*    */       }  }
/*    */   
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\mixin\HeldItemMixin.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */