/*     */ package dev.kosmx.playerAnim.mixin;
/*     */ 
/*     */ import dev.kosmx.playerAnim.core.impl.AnimationProcessor;
/*     */ import dev.kosmx.playerAnim.core.util.SetableSupplier;
/*     */ import dev.kosmx.playerAnim.impl.IAnimatedPlayer;
/*     */ import dev.kosmx.playerAnim.impl.IMutableModel;
/*     */ import dev.kosmx.playerAnim.impl.IPlayerModel;
/*     */ import dev.kosmx.playerAnim.impl.IUpperPartHelper;
/*     */ import dev.kosmx.playerAnim.impl.animation.AnimationApplier;
/*     */ import dev.kosmx.playerAnim.impl.animation.IBendHelper;
/*     */ import java.util.function.Function;
/*     */ import net.minecraft.client.model.HumanoidModel;
/*     */ import net.minecraft.client.model.PlayerModel;
/*     */ import net.minecraft.client.model.geom.ModelPart;
/*     */ import net.minecraft.client.renderer.RenderType;
/*     */ import net.minecraft.core.Direction;
/*     */ import net.minecraft.resources.ResourceLocation;
/*     */ import net.minecraft.world.entity.LivingEntity;
/*     */ import org.spongepowered.asm.mixin.Final;
/*     */ import org.spongepowered.asm.mixin.Mixin;
/*     */ import org.spongepowered.asm.mixin.Shadow;
/*     */ import org.spongepowered.asm.mixin.Unique;
/*     */ import org.spongepowered.asm.mixin.injection.At;
/*     */ import org.spongepowered.asm.mixin.injection.Inject;
/*     */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Mixin(value = {PlayerModel.class}, priority = 2000)
/*     */ public class PlayerModelMixin<T extends LivingEntity>
/*     */   extends HumanoidModel<T>
/*     */   implements IPlayerModel
/*     */ {
/*     */   @Shadow
/*     */   @Final
/*     */   public ModelPart f_103378_;
/*     */   @Shadow
/*     */   @Final
/*     */   public ModelPart f_103375_;
/*     */   @Unique
/*  42 */   private final SetableSupplier<AnimationProcessor> emoteSupplier = new SetableSupplier(); @Shadow
/*     */   @Final
/*     */   public ModelPart f_103374_; @Shadow
/*     */   @Final
/*     */   public ModelPart f_103377_; @Shadow
/*     */   @Final
/*     */   public ModelPart f_103376_; @Unique
/*  49 */   private boolean firstPersonNext = false; public PlayerModelMixin(ModelPart modelPart, Function<ResourceLocation, RenderType> function) { super(modelPart, function); }
/*     */ 
/*     */   
/*     */   @Inject(method = {"<init>"}, at = {@At("RETURN")})
/*     */   private void initBendableStuff(ModelPart modelPart, boolean bl, CallbackInfo ci) {
/*  54 */     IMutableModel thisWithMixin = (IMutableModel)this;
/*  55 */     this.emoteSupplier.set(null);
/*     */     
/*  57 */     thisWithMixin.setEmoteSupplier(this.emoteSupplier);
/*     */     
/*  59 */     addBendMutator(this.f_103378_, Direction.DOWN);
/*  60 */     addBendMutator(this.f_103377_, Direction.UP);
/*  61 */     addBendMutator(this.f_103375_, Direction.UP);
/*  62 */     addBendMutator(this.f_103376_, Direction.UP);
/*  63 */     addBendMutator(this.f_103374_, Direction.UP);
/*     */     
/*  65 */     ((IUpperPartHelper)this.f_103375_).setUpperPart(true);
/*  66 */     ((IUpperPartHelper)this.f_103374_).setUpperPart(true);
/*     */   }
/*     */ 
/*     */   
/*     */   @Unique
/*     */   private void addBendMutator(ModelPart part, Direction d) {
/*  72 */     IBendHelper.INSTANCE.initBend(part, d);
/*     */   }
/*     */   
/*     */   @Unique
/*     */   private void setDefaultPivot() {
/*  77 */     this.f_102814_.m_104227_(1.9F, 12.0F, 0.0F);
/*  78 */     this.f_102813_.m_104227_(-1.9F, 12.0F, 0.0F);
/*  79 */     this.f_102808_.m_104227_(0.0F, 0.0F, 0.0F);
/*  80 */     this.f_102811_.f_104202_ = 0.0F;
/*  81 */     this.f_102811_.f_104200_ = -5.0F;
/*  82 */     this.f_102812_.f_104202_ = 0.0F;
/*  83 */     this.f_102812_.f_104200_ = 5.0F;
/*  84 */     this.f_102810_.f_104203_ = 0.0F;
/*  85 */     this.f_102813_.f_104202_ = 0.1F;
/*  86 */     this.f_102814_.f_104202_ = 0.1F;
/*  87 */     this.f_102813_.f_104201_ = 12.0F;
/*  88 */     this.f_102814_.f_104201_ = 12.0F;
/*  89 */     this.f_102808_.f_104201_ = 0.0F;
/*  90 */     this.f_102808_.f_104205_ = 0.0F;
/*  91 */     this.f_102810_.f_104201_ = 0.0F;
/*  92 */     this.f_102810_.f_104200_ = 0.0F;
/*  93 */     this.f_102810_.f_104202_ = 0.0F;
/*  94 */     this.f_102810_.f_104204_ = 0.0F;
/*  95 */     this.f_102810_.f_104205_ = 0.0F;
/*     */   }
/*     */   
/*     */   @Inject(method = {"setupAnim(Lnet/minecraft/world/entity/LivingEntity;FFFFF)V"}, at = {@At("HEAD")})
/*     */   private void setDefaultBeforeRender(T livingEntity, float f, float g, float h, float i, float j, CallbackInfo ci) {
/* 100 */     setDefaultPivot();
/*     */   }
/*     */   
/*     */   @Inject(method = {"setupAnim(Lnet/minecraft/world/entity/LivingEntity;FFFFF)V"}, at = {@At(value = "INVOKE", target = "Lnet/minecraft/client/model/geom/ModelPart;copyFrom(Lnet/minecraft/client/model/geom/ModelPart;)V", ordinal = 0)})
/*     */   private void setEmote(T livingEntity, float f, float g, float h, float i, float j, CallbackInfo ci) {
/* 105 */     if (!this.firstPersonNext && livingEntity instanceof net.minecraft.client.player.AbstractClientPlayer && ((IAnimatedPlayer)livingEntity).playerAnimator_getAnimation().isActive()) {
/* 106 */       AnimationApplier emote = ((IAnimatedPlayer)livingEntity).playerAnimator_getAnimation();
/* 107 */       this.emoteSupplier.set(emote);
/*     */       
/* 109 */       emote.updatePart("head", this.f_102808_);
/* 110 */       this.f_102809_.m_104315_(this.f_102808_);
/*     */       
/* 112 */       emote.updatePart("leftArm", this.f_102812_);
/* 113 */       emote.updatePart("rightArm", this.f_102811_);
/* 114 */       emote.updatePart("leftLeg", this.f_102814_);
/* 115 */       emote.updatePart("rightLeg", this.f_102813_);
/* 116 */       emote.updatePart("torso", this.f_102810_);
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 121 */       this.firstPersonNext = false;
/* 122 */       this.emoteSupplier.set(null);
/* 123 */       resetBend(this.f_102810_);
/* 124 */       resetBend(this.f_102812_);
/* 125 */       resetBend(this.f_102811_);
/* 126 */       resetBend(this.f_102814_);
/* 127 */       resetBend(this.f_102813_);
/*     */     } 
/*     */   }
/*     */   
/*     */   @Unique
/*     */   private static void resetBend(ModelPart part) {
/* 133 */     IBendHelper.INSTANCE.bend(part, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void playerAnimator_prepForFirstPersonRender() {
/* 141 */     this.firstPersonNext = true;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\mixin\PlayerModelMixin.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */