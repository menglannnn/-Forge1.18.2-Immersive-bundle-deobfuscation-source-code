/*    */ package dev.kosmx.playerAnim.mixin;
/*    */ 
/*    */ import dev.kosmx.playerAnim.impl.IUpperPartHelper;
/*    */ import net.minecraft.client.model.geom.ModelPart;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ 
/*    */ @Mixin({ModelPart.class})
/*    */ public class ModelPartMixin
/*    */   implements IUpperPartHelper {
/*    */   private boolean Emotecraft_upper = false;
/*    */   
/*    */   public boolean isUpperPart() {
/* 13 */     return this.Emotecraft_upper;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setUpperPart(boolean bl) {
/* 18 */     this.Emotecraft_upper = bl;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\mixin\ModelPartMixin.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */