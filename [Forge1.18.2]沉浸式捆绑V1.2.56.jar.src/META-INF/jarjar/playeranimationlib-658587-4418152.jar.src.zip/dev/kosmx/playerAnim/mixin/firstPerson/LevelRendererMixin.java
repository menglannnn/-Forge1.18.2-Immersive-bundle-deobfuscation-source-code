/*    */ package dev.kosmx.playerAnim.mixin.firstPerson;
/*    */ 
/*    */ import com.mojang.blaze3d.vertex.PoseStack;
/*    */ import com.mojang.math.Matrix4f;
/*    */ import dev.kosmx.playerAnim.api.firstPerson.FirstPersonMode;
/*    */ import dev.kosmx.playerAnim.impl.IAnimatedPlayer;
/*    */ import net.minecraft.client.Camera;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.renderer.GameRenderer;
/*    */ import net.minecraft.client.renderer.LevelRenderer;
/*    */ import net.minecraft.client.renderer.LightTexture;
/*    */ import net.minecraft.client.renderer.MultiBufferSource;
/*    */ import net.minecraft.world.entity.Entity;
/*    */ import net.minecraft.world.entity.LivingEntity;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Unique;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({LevelRenderer.class})
/*    */ public class LevelRendererMixin
/*    */ {
/*    */   @Unique
/*    */   private boolean defaultCameraState = false;
/*    */   
/*    */   @Inject(method = {"renderLevel"}, at = {@At(value = "INVOKE", target = "Lnet/minecraft/client/Camera;isDetached()Z")})
/*    */   private void fakeThirdPersonMode(PoseStack poseStack, float f, long l, boolean bl, Camera camera, GameRenderer gameRenderer, LightTexture lightTexture, Matrix4f matrix4f, CallbackInfo ci) {
/* 32 */     this.defaultCameraState = camera.m_90594_();
/* 33 */     Entity entity = camera.m_90592_(); if (entity instanceof IAnimatedPlayer) { IAnimatedPlayer player = (IAnimatedPlayer)entity; if (player.playerAnimator_getAnimation().getFirstPersonMode() == FirstPersonMode.THIRD_PERSON_MODEL) {
/* 34 */         FirstPersonMode.setFirstPersonPass((!camera.m_90594_() && (!(camera.m_90592_() instanceof LivingEntity) || !((LivingEntity)camera.m_90592_()).m_5803_())));
/* 35 */         ((CameraAccessor)camera).setDetached(true);
/*    */       }  }
/*    */   
/*    */   } @Inject(method = {"renderLevel"}, at = {@At(value = "INVOKE", target = "Lnet/minecraft/client/Camera;isDetached()Z", shift = At.Shift.AFTER)})
/*    */   private void resetThirdPerson(PoseStack poseStack, float f, long l, boolean bl, Camera camera, GameRenderer gameRenderer, LightTexture lightTexture, Matrix4f matrix4f, CallbackInfo ci) {
/* 40 */     ((CameraAccessor)camera).setDetached(this.defaultCameraState);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Inject(method = {"renderEntity"}, at = {@At("TAIL")})
/*    */   private void dontRenderEntity_End(Entity entity, double cameraX, double cameraY, double cameraZ, float tickDelta, PoseStack matrices, MultiBufferSource vertexConsumers, CallbackInfo ci) {
/* 48 */     Camera camera = (Minecraft.m_91087_()).f_91063_.m_109153_();
/* 49 */     if (entity == camera.m_90592_())
/* 50 */       FirstPersonMode.setFirstPersonPass(false); 
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\mixin\firstPerson\LevelRendererMixin.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */