/*    */ package dev.kosmx.playerAnim.mixin;
/*    */ 
/*    */ import dev.kosmx.playerAnim.impl.IUpperPartHelper;
/*    */ import net.minecraft.client.model.HumanoidModel;
/*    */ import net.minecraft.client.renderer.entity.RenderLayerParent;
/*    */ import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
/*    */ import net.minecraft.world.entity.LivingEntity;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ @Mixin({HumanoidArmorLayer.class})
/*    */ public class ArmorFeatureRendererMixin<T extends LivingEntity, M extends HumanoidModel<T>, A extends HumanoidModel<T>>
/*    */ {
/*    */   @Inject(method = {"<init>"}, at = {@At("RETURN")})
/*    */   private void initInject(RenderLayerParent<T, M> context, A leggingsModel, A bodyModel, CallbackInfo ci) {
/* 18 */     ((IUpperPartHelper)this).setUpperPart(false);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\mixin\ArmorFeatureRendererMixin.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */