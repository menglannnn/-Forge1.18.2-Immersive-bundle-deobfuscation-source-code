/*    */ package dev.kosmx.playerAnim.mixin.firstPerson;
/*    */ 
/*    */ import com.mojang.blaze3d.vertex.PoseStack;
/*    */ import dev.kosmx.playerAnim.api.firstPerson.FirstPersonMode;
/*    */ import net.minecraft.client.renderer.MultiBufferSource;
/*    */ import net.minecraft.client.renderer.entity.EntityRenderDispatcher;
/*    */ import net.minecraft.world.entity.Entity;
/*    */ import net.minecraft.world.level.LevelReader;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ @Mixin({EntityRenderDispatcher.class})
/*    */ public class EntityRenderDispatcherMixin
/*    */ {
/*    */   @Inject(method = {"renderShadow"}, at = {@At("HEAD")}, cancellable = true)
/*    */   private static void renderShadow_HEAD_PlayerAnimator(PoseStack matrices, MultiBufferSource vertexConsumers, Entity entity, float opacity, float tickDelta, LevelReader world, float radius, CallbackInfo ci) {
/* 19 */     if (entity instanceof net.minecraft.world.entity.player.Player && FirstPersonMode.isFirstPersonPass())
/*    */     {
/*    */       
/* 22 */       ci.cancel();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\mixin\firstPerson\EntityRenderDispatcherMixin.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */