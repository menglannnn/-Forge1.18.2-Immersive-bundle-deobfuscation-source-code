/*    */ package dev.kosmx.playerAnim.mixin;
/*    */ 
/*    */ import dev.kosmx.playerAnim.api.layered.AnimationStack;
/*    */ import dev.kosmx.playerAnim.api.layered.IAnimation;
/*    */ import dev.kosmx.playerAnim.impl.IAnimatedPlayer;
/*    */ import dev.kosmx.playerAnim.impl.animation.AnimationApplier;
/*    */ import dev.kosmx.playerAnim.minecraftApi.PlayerAnimationAccess;
/*    */ import dev.kosmx.playerAnim.minecraftApi.PlayerAnimationFactory;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import net.minecraft.client.player.AbstractClientPlayer;
/*    */ import net.minecraft.resources.ResourceLocation;
/*    */ import net.minecraft.world.entity.player.Player;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Unique;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ @Mixin({Player.class})
/*    */ public abstract class PlayerEntityMixin
/*    */   implements IAnimatedPlayer
/*    */ {
/*    */   @Unique
/* 27 */   private final Map<ResourceLocation, IAnimation> modAnimationData = new HashMap<>();
/*    */   
/*    */   @Unique
/* 30 */   private final AnimationStack animationStack = createAnimationStack(); @Unique
/* 31 */   private final AnimationApplier animationApplier = new AnimationApplier((IAnimation)this.animationStack);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Unique
/*    */   private AnimationStack createAnimationStack() {
/* 39 */     AnimationStack stack = new AnimationStack();
/* 40 */     if (AbstractClientPlayer.class.isInstance(this)) {
/* 41 */       PlayerAnimationFactory.ANIMATION_DATA_FACTORY.prepareAnimations((AbstractClientPlayer)this, stack, this.modAnimationData);
/* 42 */       ((PlayerAnimationAccess.AnimationRegister)PlayerAnimationAccess.REGISTER_ANIMATION_EVENT.invoker()).registerAnimation((AbstractClientPlayer)this, stack);
/*    */     } 
/* 44 */     return stack;
/*    */   }
/*    */ 
/*    */   
/*    */   public AnimationStack getAnimationStack() {
/* 49 */     return this.animationStack;
/*    */   }
/*    */ 
/*    */   
/*    */   public AnimationApplier playerAnimator_getAnimation() {
/* 54 */     return this.animationApplier;
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   public IAnimation playerAnimator_getAnimation(@NotNull ResourceLocation id) {
/* 59 */     return this.modAnimationData.get(id);
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   public IAnimation playerAnimator_setAnimation(@NotNull ResourceLocation id, @Nullable IAnimation animation) {
/* 64 */     if (animation == null) {
/* 65 */       return this.modAnimationData.remove(id);
/*    */     }
/* 67 */     return this.modAnimationData.put(id, animation);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @Inject(method = {"tick"}, at = {@At("HEAD")})
/*    */   private void tick(CallbackInfo ci) {
/* 74 */     if (AbstractClientPlayer.class.isInstance(this))
/* 75 */       this.animationStack.tick(); 
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\mixin\PlayerEntityMixin.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */