/*    */ package dev.kosmx.playerAnim.mixin;
/*    */ 
/*    */ import com.mojang.blaze3d.vertex.PoseStack;
/*    */ import dev.kosmx.playerAnim.impl.Helper;
/*    */ import dev.kosmx.playerAnim.impl.IAnimatedPlayer;
/*    */ import dev.kosmx.playerAnim.impl.IUpperPartHelper;
/*    */ import dev.kosmx.playerAnim.impl.animation.IBendHelper;
/*    */ import java.util.Iterator;
/*    */ import net.minecraft.client.model.EntityModel;
/*    */ import net.minecraft.client.renderer.MultiBufferSource;
/*    */ import net.minecraft.client.renderer.entity.EntityRenderer;
/*    */ import net.minecraft.client.renderer.entity.EntityRendererProvider;
/*    */ import net.minecraft.client.renderer.entity.LivingEntityRenderer;
/*    */ import net.minecraft.client.renderer.entity.RenderLayerParent;
/*    */ import net.minecraft.client.renderer.entity.layers.RenderLayer;
/*    */ import net.minecraft.world.entity.Entity;
/*    */ import net.minecraft.world.entity.LivingEntity;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.Redirect;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({LivingEntityRenderer.class})
/*    */ public abstract class LivingEntityRenderRedirect_bendOnly<T extends Entity, M extends EntityModel<T>>
/*    */   extends EntityRenderer<T>
/*    */   implements RenderLayerParent<T, M>
/*    */ {
/*    */   protected LivingEntityRenderRedirect_bendOnly(EntityRendererProvider.Context context) {
/* 43 */     super(context);
/*    */   }
/*    */ 
/*    */   
/*    */   @Inject(method = {"render(Lnet/minecraft/world/entity/LivingEntity;FFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V"}, at = {@At(value = "INVOKE", target = "Ljava/util/List;iterator()Ljava/util/Iterator;")})
/*    */   private void initialPush(LivingEntity livingEntity, float f, float g, PoseStack poseStack, MultiBufferSource multiBufferSource, int i, CallbackInfo ci) {
/* 49 */     if (Helper.isBendEnabled()) poseStack.m_85836_();
/*    */   
/*    */   }
/*    */   
/*    */   @Inject(method = {"render(Lnet/minecraft/world/entity/LivingEntity;FFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V"}, at = {@At(value = "INVOKE", target = "Ljava/util/Iterator;hasNext()Z")})
/*    */   private void popMatrixStack(LivingEntity livingEntity, float f, float g, PoseStack poseStack, MultiBufferSource multiBufferSource, int i, CallbackInfo ci) {
/* 55 */     if (Helper.isBendEnabled()) poseStack.m_85849_();
/*    */   
/*    */   }
/*    */   
/*    */   @Redirect(method = {"render(Lnet/minecraft/world/entity/LivingEntity;FFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V"}, at = @At(value = "INVOKE", target = "Ljava/util/Iterator;next()Ljava/lang/Object;"))
/*    */   private Object transformMatrixStack(Iterator<RenderLayer<T, M>> instance, LivingEntity livingEntity, float f, float g, PoseStack poseStack, MultiBufferSource multiBufferSource, int i) {
/* 61 */     if (Helper.isBendEnabled()) {
/* 62 */       poseStack.m_85836_();
/* 63 */       RenderLayer<T, M> layer = instance.next();
/* 64 */       if (livingEntity instanceof net.minecraft.world.entity.player.Player && livingEntity instanceof IAnimatedPlayer && ((IAnimatedPlayer)livingEntity).playerAnimator_getAnimation().isActive() && ((IUpperPartHelper)layer).isUpperPart()) {
/* 65 */         IBendHelper.rotateMatrixStack(poseStack, ((IAnimatedPlayer)livingEntity).playerAnimator_getAnimation().getBend("body"));
/*    */       }
/* 67 */       return layer;
/*    */     } 
/* 69 */     return instance.next();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\mixin\LivingEntityRenderRedirect_bendOnly.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */