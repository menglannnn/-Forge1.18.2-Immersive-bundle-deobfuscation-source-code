/*    */ package dev.kosmx.playerAnim.mixin;
/*    */ import com.mojang.blaze3d.vertex.PoseStack;
/*    */ import com.mojang.math.Vector3f;
/*    */ import dev.kosmx.playerAnim.api.TransformType;
/*    */ import dev.kosmx.playerAnim.api.firstPerson.FirstPersonConfiguration;
/*    */ import dev.kosmx.playerAnim.api.firstPerson.FirstPersonMode;
/*    */ import dev.kosmx.playerAnim.core.util.Vec3f;
/*    */ import dev.kosmx.playerAnim.impl.IAnimatedPlayer;
/*    */ import dev.kosmx.playerAnim.impl.IPlayerModel;
/*    */ import dev.kosmx.playerAnim.impl.animation.AnimationApplier;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.model.EntityModel;
/*    */ import net.minecraft.client.model.PlayerModel;
/*    */ import net.minecraft.client.model.geom.ModelPart;
/*    */ import net.minecraft.client.player.AbstractClientPlayer;
/*    */ import net.minecraft.client.renderer.MultiBufferSource;
/*    */ import net.minecraft.client.renderer.entity.EntityRendererProvider;
/*    */ import net.minecraft.client.renderer.entity.LivingEntityRenderer;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ @Mixin({PlayerRenderer.class})
/*    */ public abstract class PlayerRendererMixin extends LivingEntityRenderer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
/*    */   public PlayerRendererMixin(EntityRendererProvider.Context context, PlayerModel<AbstractClientPlayer> entityModel, float f) {
/* 27 */     super(context, (EntityModel)entityModel, f);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Inject(method = {"render(Lnet/minecraft/client/player/AbstractClientPlayer;FFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V"}, at = {@At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/entity/LivingEntityRenderer;render(Lnet/minecraft/world/entity/LivingEntity;FFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V")})
/*    */   private void hideBonesInFirstPerson(AbstractClientPlayer entity, float f, float g, PoseStack matrixStack, MultiBufferSource vertexConsumerProvider, int i, CallbackInfo ci) {
/* 35 */     if (FirstPersonMode.isFirstPersonPass()) {
/* 36 */       AnimationApplier animationApplier = ((IAnimatedPlayer)entity).playerAnimator_getAnimation();
/* 37 */       FirstPersonConfiguration config = animationApplier.getFirstPersonConfiguration();
/*    */       
/* 39 */       if (entity == Minecraft.m_91087_().m_91288_()) {
/*    */         
/* 41 */         setAllPartsVisible(false);
/*    */         
/* 43 */         boolean showRightArm = config.isShowRightArm();
/* 44 */         boolean showLeftArm = config.isShowLeftArm();
/* 45 */         ((PlayerModel)this.f_115290_).f_102811_.f_104207_ = showRightArm;
/* 46 */         ((PlayerModel)this.f_115290_).f_103375_.f_104207_ = showRightArm;
/* 47 */         ((PlayerModel)this.f_115290_).f_102812_.f_104207_ = showLeftArm;
/* 48 */         ((PlayerModel)this.f_115290_).f_103374_.f_104207_ = showLeftArm;
/*    */       } 
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @Unique
/*    */   private void setAllPartsVisible(boolean visible) {
/* 57 */     ((PlayerModel)this.f_115290_).f_102808_.f_104207_ = visible;
/* 58 */     ((PlayerModel)this.f_115290_).f_102810_.f_104207_ = visible;
/* 59 */     ((PlayerModel)this.f_115290_).f_102814_.f_104207_ = visible;
/* 60 */     ((PlayerModel)this.f_115290_).f_102813_.f_104207_ = visible;
/* 61 */     ((PlayerModel)this.f_115290_).f_102811_.f_104207_ = visible;
/* 62 */     ((PlayerModel)this.f_115290_).f_102812_.f_104207_ = visible;
/*    */     
/* 64 */     ((PlayerModel)this.f_115290_).f_102809_.f_104207_ = visible;
/* 65 */     ((PlayerModel)this.f_115290_).f_103374_.f_104207_ = visible;
/* 66 */     ((PlayerModel)this.f_115290_).f_103375_.f_104207_ = visible;
/* 67 */     ((PlayerModel)this.f_115290_).f_103376_.f_104207_ = visible;
/* 68 */     ((PlayerModel)this.f_115290_).f_103377_.f_104207_ = visible;
/* 69 */     ((PlayerModel)this.f_115290_).f_103378_.f_104207_ = visible;
/*    */   }
/*    */ 
/*    */   
/*    */   @Inject(method = {"setupRotations(Lnet/minecraft/client/player/AbstractClientPlayer;Lcom/mojang/blaze3d/vertex/PoseStack;FFF)V"}, at = {@At("RETURN")})
/*    */   private void applyBodyTransforms(AbstractClientPlayer abstractClientPlayerEntity, PoseStack matrixStack, float f, float bodyYaw, float tickDelta, CallbackInfo ci) {
/* 75 */     AnimationApplier animationPlayer = ((IAnimatedPlayer)abstractClientPlayerEntity).playerAnimator_getAnimation();
/* 76 */     animationPlayer.setTickDelta(tickDelta);
/* 77 */     if (animationPlayer.isActive()) {
/*    */ 
/*    */       
/* 80 */       Vec3f vec3d = animationPlayer.get3DTransform("body", TransformType.POSITION, Vec3f.ZERO);
/* 81 */       matrixStack.m_85837_(((Float)vec3d.getX()).floatValue(), ((Float)vec3d.getY()).floatValue() + 0.7D, ((Float)vec3d.getZ()).floatValue());
/* 82 */       Vec3f vec3f = animationPlayer.get3DTransform("body", TransformType.ROTATION, Vec3f.ZERO);
/* 83 */       matrixStack.m_85845_(Vector3f.f_122227_.m_122270_(((Float)vec3f.getZ()).floatValue()));
/* 84 */       matrixStack.m_85845_(Vector3f.f_122225_.m_122270_(((Float)vec3f.getY()).floatValue()));
/* 85 */       matrixStack.m_85845_(Vector3f.f_122223_.m_122270_(((Float)vec3f.getX()).floatValue()));
/* 86 */       matrixStack.m_85837_(0.0D, -0.7D, 0.0D);
/*    */     } 
/*    */   }
/*    */   
/*    */   @Inject(method = {"renderHand"}, at = {@At(value = "INVOKE", target = "Lnet/minecraft/client/model/PlayerModel;setupAnim(Lnet/minecraft/world/entity/LivingEntity;FFFFF)V")})
/*    */   private void notifyModelOfFirstPerson(PoseStack poseStack, MultiBufferSource multiBufferSource, int i, AbstractClientPlayer abstractClientPlayer, ModelPart modelPart, ModelPart modelPart2, CallbackInfo ci) {
/* 92 */     EntityModel entityModel = m_7200_(); if (entityModel instanceof IPlayerModel) { IPlayerModel playerModel = (IPlayerModel)entityModel; if (!((IAnimatedPlayer)abstractClientPlayer).playerAnimator_getAnimation().getFirstPersonMode().isEnabled())
/* 93 */         playerModel.playerAnimator_prepForFirstPersonRender();  }
/*    */   
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\mixin\PlayerRendererMixin.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */