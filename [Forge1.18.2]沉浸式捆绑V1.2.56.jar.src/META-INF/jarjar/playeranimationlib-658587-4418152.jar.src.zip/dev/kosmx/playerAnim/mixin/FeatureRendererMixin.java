/*    */ package dev.kosmx.playerAnim.mixin;
/*    */ 
/*    */ import dev.kosmx.playerAnim.impl.IUpperPartHelper;
/*    */ import net.minecraft.client.renderer.entity.RenderLayerParent;
/*    */ import net.minecraft.client.renderer.entity.layers.RenderLayer;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Unique;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ @Mixin({RenderLayer.class})
/*    */ public class FeatureRendererMixin
/*    */   implements IUpperPartHelper {
/*    */   @Unique
/*    */   private boolean isUpperPart = true;
/*    */   
/*    */   @Inject(method = {"<init>"}, at = {@At("RETURN")})
/*    */   private void init(RenderLayerParent renderLayerParent, CallbackInfo ci) {
/* 20 */     if (getClass().getPackageName().contains("skinlayers") && !getClass().getSimpleName().toLowerCase().contains("head")) {
/* 21 */       this.isUpperPart = false;
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isUpperPart() {
/* 27 */     return this.isUpperPart;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setUpperPart(boolean bl) {
/* 32 */     this.isUpperPart = bl;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\mixin\FeatureRendererMixin.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */