/*    */ package dev.kosmx.playerAnim.minecraftApi;
/*    */ 
/*    */ import dev.kosmx.playerAnim.api.layered.IAnimation;
/*    */ import dev.kosmx.playerAnim.impl.IAnimatedPlayer;
/*    */ import net.minecraft.resources.ResourceLocation;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PlayerAssociatedAnimationData
/*    */ {
/*    */   @NotNull
/*    */   private final IAnimatedPlayer player;
/*    */   
/*    */   public PlayerAssociatedAnimationData(@NotNull IAnimatedPlayer player) {
/* 74 */     this.player = player;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public IAnimation get(@NotNull ResourceLocation id) {
/* 84 */     return this.player.playerAnimator_getAnimation(id);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public IAnimation set(@NotNull ResourceLocation id, @Nullable IAnimation animation) {
/* 95 */     return this.player.playerAnimator_setAnimation(id, animation);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\minecraftApi\PlayerAnimationAccess$PlayerAssociatedAnimationData.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */