/*    */ package dev.kosmx.playerAnim.minecraftApi;
/*    */ 
/*    */ import dev.kosmx.playerAnim.api.layered.IAnimation;
/*    */ import net.minecraft.resources.ResourceLocation;
/*    */ import org.jetbrains.annotations.ApiStatus.Internal;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Internal
/*    */ final class DataHolder
/*    */   extends Record
/*    */ {
/*    */   @Nullable
/*    */   private final ResourceLocation id;
/*    */   private final int priority;
/*    */   @NotNull
/*    */   private final IAnimation animation;
/*    */   
/*    */   @NotNull
/*    */   public IAnimation animation() {
/* 41 */     return this.animation; } public int priority() { return this.priority; } @Nullable public ResourceLocation id() { return this.id; } private DataHolder(@Nullable ResourceLocation id, int priority, @NotNull IAnimation animation) {
/* 42 */     this.id = id; this.priority = priority; this.animation = animation;
/*    */   }
/*    */   
/*    */   public final boolean equals(Object o) {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: aload_1
/*    */     //   2: <illegal opcode> equals : (Ldev/kosmx/playerAnim/minecraftApi/PlayerAnimationFactory$FactoryHolder$DataHolder;Ljava/lang/Object;)Z
/*    */     //   7: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #41	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	8	0	this	Ldev/kosmx/playerAnim/minecraftApi/PlayerAnimationFactory$FactoryHolder$DataHolder;
/*    */     //   0	8	1	o	Ljava/lang/Object;
/*    */   }
/*    */   
/*    */   public final int hashCode() {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> hashCode : (Ldev/kosmx/playerAnim/minecraftApi/PlayerAnimationFactory$FactoryHolder$DataHolder;)I
/*    */     //   6: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #41	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Ldev/kosmx/playerAnim/minecraftApi/PlayerAnimationFactory$FactoryHolder$DataHolder;
/*    */   }
/*    */   
/*    */   public final String toString() {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> toString : (Ldev/kosmx/playerAnim/minecraftApi/PlayerAnimationFactory$FactoryHolder$DataHolder;)Ljava/lang/String;
/*    */     //   6: areturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #41	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Ldev/kosmx/playerAnim/minecraftApi/PlayerAnimationFactory$FactoryHolder$DataHolder;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\minecraftApi\PlayerAnimationFactory$FactoryHolder$DataHolder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */