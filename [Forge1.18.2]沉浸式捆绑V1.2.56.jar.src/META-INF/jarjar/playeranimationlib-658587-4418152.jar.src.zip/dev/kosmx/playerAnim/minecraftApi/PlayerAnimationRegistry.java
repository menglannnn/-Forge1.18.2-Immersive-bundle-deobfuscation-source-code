/*     */ package dev.kosmx.playerAnim.minecraftApi;
/*     */ 
/*     */ import dev.kosmx.playerAnim.core.data.KeyframeAnimation;
/*     */ import dev.kosmx.playerAnim.core.data.gson.AnimationSerializing;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.util.HashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import net.minecraft.network.chat.Component;
/*     */ import net.minecraft.network.chat.MutableComponent;
/*     */ import net.minecraft.resources.ResourceLocation;
/*     */ import net.minecraft.server.packs.resources.ResourceManager;
/*     */ import net.minecraftforge.api.distmarker.Dist;
/*     */ import net.minecraftforge.api.distmarker.OnlyIn;
/*     */ import org.jetbrains.annotations.ApiStatus.Internal;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ import org.slf4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @OnlyIn(Dist.CLIENT)
/*     */ public final class PlayerAnimationRegistry
/*     */ {
/*  43 */   private static final HashMap<ResourceLocation, KeyframeAnimation> animations = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static KeyframeAnimation getAnimation(@NotNull ResourceLocation identifier) {
/*  52 */     return animations.get(identifier);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public static Optional<KeyframeAnimation> getAnimationOptional(@NotNull ResourceLocation identifier) {
/*  62 */     return Optional.ofNullable(getAnimation(identifier));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Map<ResourceLocation, KeyframeAnimation> getAnimations() {
/*  69 */     return Map.copyOf(animations);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Map<String, KeyframeAnimation> getModAnimations(String modid) {
/*  78 */     HashMap<String, KeyframeAnimation> map = new HashMap<>();
/*  79 */     for (Map.Entry<ResourceLocation, KeyframeAnimation> entry : animations.entrySet()) {
/*  80 */       if (((ResourceLocation)entry.getKey()).m_135827_().equals(modid)) {
/*  81 */         map.put(((ResourceLocation)entry.getKey()).m_135815_(), entry.getValue());
/*     */       }
/*     */     } 
/*  84 */     return map;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Internal
/*     */   public static void resourceLoaderCallback(@NotNull ResourceManager manager, Logger logger) {
/*  93 */     animations.clear();
/*  94 */     for (ResourceLocation resource : manager.m_6540_("player_animation", location -> location.endsWith(".json"))) { 
/*  95 */       try { InputStream input = manager.m_142591_(resource).m_6679_();
/*     */ 
/*     */         
/*  98 */         try { for (KeyframeAnimation animation : AnimationSerializing.deserializeAnimation(input))
/*     */           {
/*     */             
/* 101 */             animations.put(new ResourceLocation(resource.m_135827_(), serializeTextToString((String)animation.extraData.get("name")).toLowerCase(Locale.ROOT)), animation);
/*     */           }
/* 103 */           if (input != null) input.close();  } catch (Throwable throwable) { if (input != null) try { input.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (IOException e)
/* 104 */       { logger.error("Error while loading payer animation: " + resource);
/* 105 */         logger.error(e.getMessage());
/* 106 */         StringWriter sw = new StringWriter();
/* 107 */         PrintWriter pw = new PrintWriter(sw);
/* 108 */         e.printStackTrace(pw);
/* 109 */         String sStackTrace = sw.toString();
/* 110 */         logger.error(sStackTrace); }
/*     */        }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String serializeTextToString(String arg) {
/*     */     try {
/* 121 */       MutableComponent component = Component.Serializer.m_130701_(arg);
/* 122 */       if (component != null) {
/* 123 */         return component.getString();
/*     */       }
/* 125 */     } catch (Exception exception) {}
/* 126 */     return arg.replace("\"", "");
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\minecraftApi\PlayerAnimationRegistry.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */