/*    */ package dev.kosmx.playerAnim.minecraftApi;
/*    */ 
/*    */ import dev.kosmx.playerAnim.api.layered.AnimationStack;
/*    */ import dev.kosmx.playerAnim.api.layered.IAnimation;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.Optional;
/*    */ import java.util.function.Function;
/*    */ import net.minecraft.client.player.AbstractClientPlayer;
/*    */ import net.minecraft.resources.ResourceLocation;
/*    */ import org.jetbrains.annotations.ApiStatus.Internal;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FactoryHolder
/*    */ {
/* 29 */   private static final List<Function<AbstractClientPlayer, DataHolder>> factories = new ArrayList<>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void registerFactory(@Nullable ResourceLocation id, int priority, @NotNull PlayerAnimationFactory factory)
/*    */   {
/* 38 */     factories.add(player -> (DataHolder)Optional.<IAnimation>ofNullable(factory.invoke(player)).map(()).orElse(null)); } @Internal private static final class DataHolder extends Record { @Nullable
/*    */     private final ResourceLocation id; private final int priority; @NotNull
/*    */     private final IAnimation animation; @NotNull
/* 41 */     public IAnimation animation() { return this.animation; } public int priority() { return this.priority; } @Nullable public ResourceLocation id() { return this.id; }
/*    */     public final boolean equals(Object o) { // Byte code:
/*    */       //   0: aload_0
/*    */       //   1: aload_1
/*    */       //   2: <illegal opcode> equals : (Ldev/kosmx/playerAnim/minecraftApi/PlayerAnimationFactory$FactoryHolder$DataHolder;Ljava/lang/Object;)Z
/*    */       //   7: ireturn
/*    */       // Line number table:
/*    */       //   Java source line number -> byte code offset
/*    */       //   #41	-> 0
/*    */       // Local variable table:
/*    */       //   start	length	slot	name	descriptor
/*    */       //   0	8	0	this	Ldev/kosmx/playerAnim/minecraftApi/PlayerAnimationFactory$FactoryHolder$DataHolder;
/*    */       //   0	8	1	o	Ljava/lang/Object; } public final int hashCode() { // Byte code:
/*    */       //   0: aload_0
/*    */       //   1: <illegal opcode> hashCode : (Ldev/kosmx/playerAnim/minecraftApi/PlayerAnimationFactory$FactoryHolder$DataHolder;)I
/*    */       //   6: ireturn
/*    */       // Line number table:
/*    */       //   Java source line number -> byte code offset
/*    */       //   #41	-> 0
/*    */       // Local variable table:
/*    */       //   start	length	slot	name	descriptor
/* 42 */       //   0	7	0	this	Ldev/kosmx/playerAnim/minecraftApi/PlayerAnimationFactory$FactoryHolder$DataHolder; } private DataHolder(@Nullable ResourceLocation id, int priority, @NotNull IAnimation animation) { this.id = id; this.priority = priority; this.animation = animation; } public final String toString() {
/*    */       // Byte code:
/*    */       //   0: aload_0
/*    */       //   1: <illegal opcode> toString : (Ldev/kosmx/playerAnim/minecraftApi/PlayerAnimationFactory$FactoryHolder$DataHolder;)Ljava/lang/String;
/*    */       //   6: areturn
/*    */       // Line number table:
/*    */       //   Java source line number -> byte code offset
/*    */       //   #41	-> 0
/*    */       // Local variable table:
/*    */       //   start	length	slot	name	descriptor
/*    */       //   0	7	0	this	Ldev/kosmx/playerAnim/minecraftApi/PlayerAnimationFactory$FactoryHolder$DataHolder;
/*    */     } } @Internal
/*    */   public void prepareAnimations(AbstractClientPlayer player, AnimationStack playerStack, Map<ResourceLocation, IAnimation> animationMap) {
/* 46 */     for (Function<AbstractClientPlayer, DataHolder> factory : factories) {
/* 47 */       DataHolder dataHolder = factory.apply(player);
/* 48 */       if (dataHolder != null) {
/* 49 */         playerStack.addAnimLayer(dataHolder.priority(), dataHolder.animation());
/* 50 */         if (dataHolder.id() != null)
/* 51 */           animationMap.put(dataHolder.id(), dataHolder.animation()); 
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\minecraftApi\PlayerAnimationFactory$FactoryHolder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */