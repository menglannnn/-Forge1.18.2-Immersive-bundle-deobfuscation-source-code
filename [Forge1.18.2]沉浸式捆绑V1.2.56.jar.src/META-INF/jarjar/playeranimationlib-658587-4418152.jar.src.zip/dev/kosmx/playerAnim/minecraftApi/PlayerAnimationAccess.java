/*    */ package dev.kosmx.playerAnim.minecraftApi;
/*    */ 
/*    */ import dev.kosmx.playerAnim.api.IPlayer;
/*    */ import dev.kosmx.playerAnim.api.layered.AnimationStack;
/*    */ import dev.kosmx.playerAnim.api.layered.IAnimation;
/*    */ import dev.kosmx.playerAnim.core.impl.event.Event;
/*    */ import dev.kosmx.playerAnim.impl.IAnimatedPlayer;
/*    */ import net.minecraft.client.player.AbstractClientPlayer;
/*    */ import net.minecraft.resources.ResourceLocation;
/*    */ import net.minecraftforge.api.distmarker.Dist;
/*    */ import net.minecraftforge.api.distmarker.OnlyIn;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @OnlyIn(Dist.CLIENT)
/*    */ public final class PlayerAnimationAccess
/*    */ {
/*    */   public static AnimationStack getPlayerAnimLayer(AbstractClientPlayer player) throws IllegalArgumentException {
/* 27 */     if (player instanceof IPlayer)
/* 28 */       return ((IPlayer)player).getAnimationStack(); 
/* 29 */     throw new IllegalArgumentException("" + player + " is not a player or library mixins failed");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static PlayerAssociatedAnimationData getPlayerAssociatedData(@NotNull AbstractClientPlayer player) {
/* 41 */     if (player instanceof IAnimatedPlayer) { IAnimatedPlayer animatedPlayer = (IAnimatedPlayer)player;
/* 42 */       return new PlayerAssociatedAnimationData(animatedPlayer); }
/* 43 */      throw new IllegalArgumentException("" + player + " is not a player or library mixins failed");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 52 */   public static final Event<AnimationRegister> REGISTER_ANIMATION_EVENT = new Event(AnimationRegister.class, listeners -> ());
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static class PlayerAssociatedAnimationData
/*    */   {
/*    */     @NotNull
/*    */     private final IAnimatedPlayer player;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     public PlayerAssociatedAnimationData(@NotNull IAnimatedPlayer player) {
/* 74 */       this.player = player;
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     @Nullable
/*    */     public IAnimation get(@NotNull ResourceLocation id) {
/* 84 */       return this.player.playerAnimator_getAnimation(id);
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     @Nullable
/*    */     public IAnimation set(@NotNull ResourceLocation id, @Nullable IAnimation animation) {
/* 95 */       return this.player.playerAnimator_setAnimation(id, animation);
/*    */     }
/*    */   }
/*    */   
/*    */   @FunctionalInterface
/*    */   public static interface AnimationRegister {
/*    */     void registerAnimation(@NotNull AbstractClientPlayer param1AbstractClientPlayer, @NotNull AnimationStack param1AnimationStack);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\minecraftApi\PlayerAnimationAccess.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */