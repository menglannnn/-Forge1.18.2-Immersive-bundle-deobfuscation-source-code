package dev.kosmx.playerAnim.minecraftApi;

import dev.kosmx.playerAnim.api.layered.AnimationStack;
import net.minecraft.client.player.AbstractClientPlayer;
import org.jetbrains.annotations.NotNull;

@FunctionalInterface
public interface AnimationRegister {
  void registerAnimation(@NotNull AbstractClientPlayer paramAbstractClientPlayer, @NotNull AnimationStack paramAnimationStack);
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\minecraftApi\PlayerAnimationAccess$AnimationRegister.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */