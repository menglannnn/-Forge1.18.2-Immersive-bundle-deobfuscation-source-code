/*    */ package dev.kosmx.playerAnim.minecraftApi.layers;
/*    */ 
/*    */ import dev.kosmx.playerAnim.api.layered.modifier.MirrorModifier;
/*    */ import net.minecraft.world.entity.HumanoidArm;
/*    */ import net.minecraft.world.entity.player.Player;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LeftHandedHelperModifier
/*    */   extends MirrorModifier
/*    */ {
/*    */   private final Player player;
/*    */   
/*    */   public LeftHandedHelperModifier(Player player) {
/* 15 */     this.player = player;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isEnabled() {
/* 20 */     return (super.isEnabled() && this.player.m_5737_() == HumanoidArm.LEFT);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\minecraftApi\layers\LeftHandedHelperModifier.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */