/*     */ package dev.kosmx.playerAnim.api.layered;
/*     */ 
/*     */ import dev.kosmx.playerAnim.api.TransformType;
/*     */ import dev.kosmx.playerAnim.api.firstPerson.FirstPersonConfiguration;
/*     */ import dev.kosmx.playerAnim.api.firstPerson.FirstPersonMode;
/*     */ import dev.kosmx.playerAnim.core.util.Pair;
/*     */ import dev.kosmx.playerAnim.core.util.Vec3f;
/*     */ import java.util.ArrayList;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnimationStack
/*     */   implements IAnimation
/*     */ {
/*  18 */   private final ArrayList<Pair<Integer, IAnimation>> layers = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isActive() {
/*  26 */     for (Pair<Integer, IAnimation> layer : this.layers) {
/*  27 */       if (((IAnimation)layer.getRight()).isActive()) return true; 
/*     */     } 
/*  29 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void tick() {
/*  34 */     for (Pair<Integer, IAnimation> layer : this.layers) {
/*  35 */       if (((IAnimation)layer.getRight()).isActive()) {
/*  36 */         ((IAnimation)layer.getRight()).tick();
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public Vec3f get3DTransform(@NotNull String modelName, @NotNull TransformType type, float tickDelta, @NotNull Vec3f value0) {
/*  43 */     for (Pair<Integer, IAnimation> layer : this.layers) {
/*  44 */       if (((IAnimation)layer.getRight()).isActive() && (!FirstPersonMode.isFirstPersonPass() || ((IAnimation)layer.getRight()).getFirstPersonMode(tickDelta).isEnabled())) {
/*  45 */         value0 = ((IAnimation)layer.getRight()).get3DTransform(modelName, type, tickDelta, value0);
/*     */       }
/*     */     } 
/*  48 */     return value0;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setupAnim(float tickDelta) {
/*  53 */     for (Pair<Integer, IAnimation> layer : this.layers) {
/*  54 */       ((IAnimation)layer.getRight()).setupAnim(tickDelta);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addAnimLayer(int priority, IAnimation layer) {
/*  67 */     int search = 0;
/*     */     
/*  69 */     while (this.layers.size() > search && ((Integer)((Pair)this.layers.get(search)).getLeft()).intValue() < priority) {
/*  70 */       search++;
/*     */     }
/*  72 */     this.layers.add(search, new Pair(Integer.valueOf(priority), layer));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean removeLayer(IAnimation layer) {
/*  81 */     return this.layers.removeIf(integerIAnimationPair -> (integerIAnimationPair.getRight() == layer));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean removeLayer(int layerLevel) {
/*  90 */     return this.layers.removeIf(integerIAnimationPair -> (((Integer)integerIAnimationPair.getLeft()).intValue() == layerLevel));
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public FirstPersonMode getFirstPersonMode(float tickDelta) {
/*  95 */     for (int i = this.layers.size(); i > 0; ) {
/*  96 */       Pair<Integer, IAnimation> layer = this.layers.get(--i);
/*  97 */       if (((IAnimation)layer.getRight()).isActive()) {
/*  98 */         FirstPersonMode mode = ((IAnimation)layer.getRight()).getFirstPersonMode(tickDelta);
/*  99 */         if (mode != FirstPersonMode.NONE) return mode; 
/*     */       } 
/*     */     } 
/* 102 */     return FirstPersonMode.NONE;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public FirstPersonConfiguration getFirstPersonConfiguration(float tickDelta) {
/* 107 */     for (int i = this.layers.size(); i > 0; ) {
/* 108 */       Pair<Integer, IAnimation> layer = this.layers.get(--i);
/* 109 */       if (((IAnimation)layer.getRight()).isActive()) {
/* 110 */         FirstPersonMode mode = ((IAnimation)layer.getRight()).getFirstPersonMode(tickDelta);
/* 111 */         if (mode != FirstPersonMode.NONE) return ((IAnimation)layer.getRight()).getFirstPersonConfiguration(tickDelta); 
/*     */       } 
/*     */     } 
/* 114 */     return super.getFirstPersonConfiguration(tickDelta);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\api\layered\AnimationStack.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */