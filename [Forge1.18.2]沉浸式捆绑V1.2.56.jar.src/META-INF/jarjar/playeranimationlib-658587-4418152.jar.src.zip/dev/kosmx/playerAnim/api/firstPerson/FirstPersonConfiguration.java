/*    */ package dev.kosmx.playerAnim.api.firstPerson;
/*    */ public class FirstPersonConfiguration {
/*    */   boolean showRightArm;
/*    */   boolean showLeftArm;
/*    */   boolean showRightItem;
/*    */   boolean showLeftItem;
/*    */   
/*  8 */   public FirstPersonConfiguration setShowRightArm(boolean showRightArm) { this.showRightArm = showRightArm; return this; } public FirstPersonConfiguration setShowLeftArm(boolean showLeftArm) { this.showLeftArm = showLeftArm; return this; } public FirstPersonConfiguration setShowRightItem(boolean showRightItem) { this.showRightItem = showRightItem; return this; } public FirstPersonConfiguration setShowLeftItem(boolean showLeftItem) { this.showLeftItem = showLeftItem; return this; } public boolean equals(Object o) { if (o == this) return true;  if (!(o instanceof FirstPersonConfiguration)) return false;  FirstPersonConfiguration other = (FirstPersonConfiguration)o; return !other.canEqual(this) ? false : ((isShowRightArm() != other.isShowRightArm()) ? false : ((isShowLeftArm() != other.isShowLeftArm()) ? false : ((isShowRightItem() != other.isShowRightItem()) ? false : (!(isShowLeftItem() != other.isShowLeftItem()))))); } protected boolean canEqual(Object other) { return other instanceof FirstPersonConfiguration; } public int hashCode() { int PRIME = 59; result = 1; result = result * 59 + (isShowRightArm() ? 79 : 97); result = result * 59 + (isShowLeftArm() ? 79 : 97); result = result * 59 + (isShowRightItem() ? 79 : 97); return result * 59 + (isShowLeftItem() ? 79 : 97); } public String toString() { return "FirstPersonConfiguration(showRightArm=" + isShowRightArm() + ", showLeftArm=" + isShowLeftArm() + ", showRightItem=" + isShowRightItem() + ", showLeftItem=" + isShowLeftItem() + ")"; }
/*    */ 
/*    */   
/*    */   public FirstPersonConfiguration()
/*    */   {
/* 13 */     this.showRightArm = false;
/* 14 */     this.showLeftArm = false;
/* 15 */     this.showRightItem = true;
/* 16 */     this.showLeftItem = true; } public FirstPersonConfiguration(boolean showRightArm, boolean showLeftArm, boolean showRightItem, boolean showLeftItem) { this.showRightArm = false; this.showLeftArm = false; this.showRightItem = true; this.showLeftItem = true; this.showRightArm = showRightArm; this.showLeftArm = showLeftArm; this.showRightItem = showRightItem; this.showLeftItem = showLeftItem; } public boolean isShowLeftItem() { return this.showLeftItem; }
/*    */ 
/*    */   
/*    */   public boolean isShowRightArm() {
/*    */     return this.showRightArm;
/*    */   }
/*    */   
/*    */   public boolean isShowLeftArm() {
/*    */     return this.showLeftArm;
/*    */   }
/*    */   
/*    */   public boolean isShowRightItem() {
/*    */     return this.showRightItem;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\api\firstPerson\FirstPersonConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */