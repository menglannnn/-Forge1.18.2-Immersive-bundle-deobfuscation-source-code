/*    */ package dev.kosmx.playerAnim.api.layered;
/*    */ 
/*    */ import dev.kosmx.playerAnim.api.TransformType;
/*    */ import dev.kosmx.playerAnim.api.firstPerson.FirstPersonConfiguration;
/*    */ import dev.kosmx.playerAnim.api.firstPerson.FirstPersonMode;
/*    */ import dev.kosmx.playerAnim.core.util.Vec3f;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AnimationContainer<T extends IAnimation>
/*    */   implements IAnimation
/*    */ {
/*    */   @Nullable
/*    */   protected T anim;
/*    */   
/*    */   public AnimationContainer(@Nullable T anim) {
/* 22 */     this.anim = anim;
/*    */   }
/*    */   
/*    */   public AnimationContainer() {
/* 26 */     this.anim = null;
/*    */   }
/*    */   
/*    */   public void setAnim(@Nullable T newAnim) {
/* 30 */     this.anim = newAnim;
/*    */   }
/*    */   @Nullable
/*    */   public T getAnim() {
/* 34 */     return this.anim;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isActive() {
/* 39 */     return (this.anim != null && this.anim.isActive());
/*    */   }
/*    */ 
/*    */   
/*    */   public void tick() {
/* 44 */     if (this.anim != null) this.anim.tick(); 
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Vec3f get3DTransform(@NotNull String modelName, @NotNull TransformType type, float tickDelta, @NotNull Vec3f value0) {
/* 49 */     return (this.anim == null) ? value0 : this.anim.get3DTransform(modelName, type, tickDelta, value0);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setupAnim(float tickDelta) {
/* 54 */     if (this.anim != null) this.anim.setupAnim(tickDelta); 
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public FirstPersonMode getFirstPersonMode(float tickDelta) {
/* 59 */     return (this.anim != null) ? this.anim.getFirstPersonMode(tickDelta) : FirstPersonMode.NONE;
/*    */   }
/*    */ 
/*    */   
/*    */   @NotNull
/*    */   public FirstPersonConfiguration getFirstPersonConfiguration(float tickDelta) {
/* 65 */     return (this.anim != null) ? this.anim.getFirstPersonConfiguration(tickDelta) : super.getFirstPersonConfiguration(tickDelta);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\api\layered\AnimationContainer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */