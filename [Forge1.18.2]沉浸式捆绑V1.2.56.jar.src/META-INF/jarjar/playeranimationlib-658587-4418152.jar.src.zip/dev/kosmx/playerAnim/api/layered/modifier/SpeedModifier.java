/*    */ package dev.kosmx.playerAnim.api.layered.modifier;
/*    */ 
/*    */ import dev.kosmx.playerAnim.api.TransformType;
/*    */ import dev.kosmx.playerAnim.core.util.Vec3f;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SpeedModifier
/*    */   extends AbstractModifier
/*    */ {
/* 15 */   public float speed = 1.0F;
/*    */   
/* 17 */   private float delta = 0.0F;
/*    */   
/* 19 */   private float shiftedDelta = 0.0F;
/*    */ 
/*    */   
/*    */   public SpeedModifier(float speed) {
/* 23 */     if (!Float.isFinite(speed)) throw new IllegalArgumentException("Speed must be a finite number"); 
/* 24 */     this.speed = speed;
/*    */   }
/*    */ 
/*    */   
/*    */   public void tick() {
/* 29 */     float delta = 1.0F - this.delta;
/* 30 */     this.delta = 0.0F;
/* 31 */     step(delta);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setupAnim(float tickDelta) {
/* 36 */     float delta = tickDelta - this.delta;
/* 37 */     this.delta = tickDelta;
/* 38 */     step(delta);
/*    */   }
/*    */   
/*    */   protected void step(float delta) {
/* 42 */     delta *= this.speed;
/* 43 */     delta += this.shiftedDelta;
/* 44 */     while (delta > 1.0F) {
/* 45 */       delta--;
/* 46 */       super.tick();
/*    */     } 
/* 48 */     super.setupAnim(delta);
/* 49 */     this.shiftedDelta = delta;
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Vec3f get3DTransform(@NotNull String modelName, @NotNull TransformType type, float tickDelta, @NotNull Vec3f value0) {
/* 54 */     return super.get3DTransform(modelName, type, this.shiftedDelta, value0);
/*    */   }
/*    */   
/*    */   public SpeedModifier() {}
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\api\layered\modifier\SpeedModifier.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */