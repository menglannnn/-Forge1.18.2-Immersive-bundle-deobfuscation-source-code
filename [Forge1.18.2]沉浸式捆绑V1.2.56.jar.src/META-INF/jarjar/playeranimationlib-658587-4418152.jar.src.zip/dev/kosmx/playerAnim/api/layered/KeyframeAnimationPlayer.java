/*     */ package dev.kosmx.playerAnim.api.layered;
/*     */ 
/*     */ import dev.kosmx.playerAnim.api.TransformType;
/*     */ import dev.kosmx.playerAnim.api.firstPerson.FirstPersonConfiguration;
/*     */ import dev.kosmx.playerAnim.api.firstPerson.FirstPersonMode;
/*     */ import dev.kosmx.playerAnim.core.data.KeyframeAnimation;
/*     */ import dev.kosmx.playerAnim.core.util.MathHelper;
/*     */ import dev.kosmx.playerAnim.core.util.Pair;
/*     */ import dev.kosmx.playerAnim.core.util.Vec3f;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class KeyframeAnimationPlayer
/*     */   implements IAnimation
/*     */ {
/*     */   private final KeyframeAnimation data;
/*     */   private boolean isRunning = true;
/*     */   private int currentTick;
/*     */   private boolean isLoopStarted = false;
/*     */   protected float tickDelta;
/*     */   public final HashMap<String, BodyPart> bodyParts;
/*  45 */   public int perspective = 0;
/*     */   
/*     */   @NotNull
/*  48 */   private FirstPersonConfiguration firstPersonConfiguration = new FirstPersonConfiguration(); public KeyframeAnimationPlayer setFirstPersonConfiguration(@NotNull FirstPersonConfiguration firstPersonConfiguration) { if (firstPersonConfiguration == null) throw new NullPointerException("firstPersonConfiguration is marked non-null but is null");  this.firstPersonConfiguration = firstPersonConfiguration; return this; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public FirstPersonConfiguration getFirstPersonConfiguration(float tickDelta) {
/*  56 */     return this.firstPersonConfiguration;
/*     */   }
/*     */   @NotNull
/*  59 */   private FirstPersonMode firstPersonMode = FirstPersonMode.NONE; public KeyframeAnimationPlayer setFirstPersonMode(@NotNull FirstPersonMode firstPersonMode) { if (firstPersonMode == null) throw new NullPointerException("firstPersonMode is marked non-null but is null");  this.firstPersonMode = firstPersonMode; return this; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public FirstPersonMode getFirstPersonMode(float tickDelta) {
/*  67 */     return this.firstPersonMode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public KeyframeAnimationPlayer(@NotNull KeyframeAnimation animation, int t, boolean mutable) {
/*  78 */     if (animation == null) throw new IllegalArgumentException("Animation can not be null"); 
/*  79 */     this.data = animation;
/*     */     
/*  81 */     this.bodyParts = new HashMap<>(animation.getBodyParts().size());
/*  82 */     for (Map.Entry<String, KeyframeAnimation.StateCollection> part : (Iterable<Map.Entry<String, KeyframeAnimation.StateCollection>>)animation.getBodyParts().entrySet()) {
/*  83 */       this.bodyParts.put(part.getKey(), new BodyPart(mutable ? ((KeyframeAnimation.StateCollection)part.getValue()).copy() : part.getValue()));
/*     */     }
/*     */     
/*  86 */     this.currentTick = t;
/*  87 */     if (isInfinite() && t > this.data.returnToTick) {
/*  88 */       this.currentTick = (t - this.data.returnToTick) % (this.data.endTick - this.data.returnToTick + 1) + this.data.returnToTick;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public KeyframeAnimationPlayer(@NotNull KeyframeAnimation animation, int t) {
/*  99 */     this(animation, t, false);
/*     */   }
/*     */   
/*     */   public KeyframeAnimationPlayer(@NotNull KeyframeAnimation animation) {
/* 103 */     this(animation, 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public void tick() {
/* 108 */     if (this.isRunning) {
/* 109 */       this.currentTick++;
/* 110 */       if (this.data.isInfinite && this.currentTick > this.data.endTick) {
/* 111 */         this.currentTick = this.data.returnToTick;
/* 112 */         this.isLoopStarted = true;
/*     */       } 
/* 114 */       if (this.currentTick >= this.data.stopTick) {
/* 115 */         stop();
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public int getTick() {
/* 121 */     return this.currentTick;
/*     */   }
/*     */ 
/*     */   
/*     */   public void stop() {
/* 126 */     this.isRunning = false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isActive() {
/* 131 */     return this.isRunning;
/*     */   } @NotNull
/*     */   public Vec3f get3DTransform(@NotNull String modelName, @NotNull TransformType type, float tickDelta, @NotNull Vec3f value0) {
/*     */     Vec3f vec3f;
/*     */     Pair<Float, Float> bend;
/* 136 */     BodyPart part = this.bodyParts.get(modelName);
/* 137 */     if (part == null) return value0; 
/* 138 */     switch (type) {
/*     */       case POSITION:
/* 140 */         return part.getBodyOffset(value0);
/*     */       case ROTATION:
/* 142 */         vec3f = part.getBodyRotation(value0);
/* 143 */         return new Vec3f(((Float)vec3f.getX()).floatValue(), ((Float)vec3f.getY()).floatValue(), ((Float)vec3f.getZ()).floatValue());
/*     */       case BEND:
/* 145 */         bend = part.getBend(new Pair(value0.getX(), value0.getY()));
/* 146 */         return new Vec3f(((Float)bend.getLeft()).floatValue(), ((Float)bend.getRight()).floatValue(), 0.0F);
/*     */     } 
/* 148 */     return value0;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setupAnim(float tickDelta) {
/* 154 */     this.tickDelta = tickDelta;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isLoopStarted() {
/* 163 */     return this.isLoopStarted;
/*     */   }
/*     */ 
/*     */   
/*     */   public KeyframeAnimation getData() {
/* 168 */     return this.data;
/*     */   }
/*     */   
/*     */   public BodyPart getPart(String string) {
/* 172 */     BodyPart part = this.bodyParts.get(string);
/* 173 */     return (part == null) ? new BodyPart(null) : part;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getStopTick() {
/* 178 */     return this.data.stopTick;
/*     */   }
/*     */   
/*     */   public int getCurrentTick() {
/* 182 */     return this.currentTick;
/*     */   }
/*     */   
/*     */   public boolean isInfinite() {
/* 186 */     return this.data.isInfinite;
/*     */   }
/*     */ 
/*     */   
/*     */   public class BodyPart
/*     */   {
/*     */     @Nullable
/*     */     public final KeyframeAnimation.StateCollection part;
/*     */     public final KeyframeAnimationPlayer.Axis x;
/*     */     public final KeyframeAnimationPlayer.Axis y;
/*     */     public final KeyframeAnimationPlayer.Axis z;
/*     */     public final KeyframeAnimationPlayer.RotationAxis pitch;
/*     */     public final KeyframeAnimationPlayer.RotationAxis yaw;
/*     */     public final KeyframeAnimationPlayer.RotationAxis roll;
/*     */     public final KeyframeAnimationPlayer.RotationAxis bendAxis;
/*     */     public final KeyframeAnimationPlayer.RotationAxis bend;
/*     */     
/*     */     public BodyPart(KeyframeAnimation.StateCollection part) {
/* 204 */       this.part = part;
/* 205 */       if (part != null) {
/* 206 */         this.x = new KeyframeAnimationPlayer.Axis(part.x);
/* 207 */         this.y = new KeyframeAnimationPlayer.Axis(part.y);
/* 208 */         this.z = new KeyframeAnimationPlayer.Axis(part.z);
/* 209 */         this.pitch = new KeyframeAnimationPlayer.RotationAxis(part.pitch);
/* 210 */         this.yaw = new KeyframeAnimationPlayer.RotationAxis(part.yaw);
/* 211 */         this.roll = new KeyframeAnimationPlayer.RotationAxis(part.roll);
/* 212 */         this.bendAxis = new KeyframeAnimationPlayer.RotationAxis(part.bendDirection);
/* 213 */         this.bend = new KeyframeAnimationPlayer.RotationAxis(part.bend);
/*     */       } else {
/*     */         
/* 216 */         this.x = null;
/* 217 */         this.y = null;
/* 218 */         this.z = null;
/* 219 */         this.pitch = null;
/* 220 */         this.yaw = null;
/* 221 */         this.roll = null;
/* 222 */         this.bendAxis = null;
/* 223 */         this.bend = null;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public Pair<Float, Float> getBend(Pair<Float, Float> value0) {
/* 229 */       if (this.bend == null) return value0; 
/* 230 */       return new Pair(Float.valueOf(this.bendAxis.getValueAtCurrentTick(((Float)value0.getLeft()).floatValue())), Float.valueOf(this.bend.getValueAtCurrentTick(((Float)value0.getRight()).floatValue())));
/*     */     }
/*     */     
/*     */     public Vec3f getBodyOffset(Vec3f value0) {
/* 234 */       if (this.part == null) return value0; 
/* 235 */       float x = this.x.getValueAtCurrentTick(((Float)value0.getX()).floatValue());
/* 236 */       float y = this.y.getValueAtCurrentTick(((Float)value0.getY()).floatValue());
/* 237 */       float z = this.z.getValueAtCurrentTick(((Float)value0.getZ()).floatValue());
/* 238 */       return new Vec3f(x, y, z);
/*     */     }
/*     */     
/*     */     public Vec3f getBodyRotation(Vec3f value0) {
/* 242 */       if (this.part == null) return value0; 
/* 243 */       return new Vec3f(this.pitch
/* 244 */           .getValueAtCurrentTick(((Float)value0.getX()).floatValue()), this.yaw
/* 245 */           .getValueAtCurrentTick(((Float)value0.getY()).floatValue()), this.roll
/* 246 */           .getValueAtCurrentTick(((Float)value0.getZ()).floatValue()));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public class Axis
/*     */   {
/*     */     protected final KeyframeAnimation.StateCollection.State keyframes;
/*     */ 
/*     */     
/*     */     public Axis(KeyframeAnimation.StateCollection.State keyframes) {
/* 257 */       this.keyframes = keyframes;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private KeyframeAnimation.KeyFrame findBefore(int pos, float currentState) {
/* 271 */       if (pos == -1) {
/* 272 */         return (KeyframeAnimationPlayer.this.currentTick < KeyframeAnimationPlayer.this.data.beginTick) ? 
/* 273 */           new KeyframeAnimation.KeyFrame(0, currentState) : (
/* 274 */           (KeyframeAnimationPlayer.this.currentTick < KeyframeAnimationPlayer.this.data.endTick) ? 
/* 275 */           new KeyframeAnimation.KeyFrame(KeyframeAnimationPlayer.this.data.beginTick, this.keyframes.defaultValue) : 
/* 276 */           new KeyframeAnimation.KeyFrame(KeyframeAnimationPlayer.this.data.endTick, this.keyframes.defaultValue));
/*     */       }
/* 278 */       KeyframeAnimation.KeyFrame frame = this.keyframes.getKeyFrames().get(pos);
/* 279 */       if (!KeyframeAnimationPlayer.this.isInfinite() && KeyframeAnimationPlayer.this.currentTick >= (KeyframeAnimationPlayer.this.getData()).endTick && pos == this.keyframes.length() - 1 && frame.tick < (KeyframeAnimationPlayer.this.getData()).endTick) {
/* 280 */         return new KeyframeAnimation.KeyFrame((KeyframeAnimationPlayer.this.getData()).endTick, frame.value, frame.ease);
/*     */       }
/* 282 */       return frame;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private KeyframeAnimation.KeyFrame findAfter(int pos, float currentState) {
/* 295 */       if (this.keyframes.length() > pos + 1) {
/* 296 */         return this.keyframes.getKeyFrames().get(pos + 1);
/*     */       }
/*     */       
/* 299 */       if (KeyframeAnimationPlayer.this.isInfinite()) {
/* 300 */         return new KeyframeAnimation.KeyFrame((KeyframeAnimationPlayer.this.getData()).endTick + 1, this.keyframes.defaultValue);
/*     */       }
/*     */       
/* 303 */       if (KeyframeAnimationPlayer.this.currentTick < (KeyframeAnimationPlayer.this.getData()).endTick && this.keyframes.length() > 0) {
/* 304 */         KeyframeAnimation.KeyFrame lastFrame = this.keyframes.getKeyFrames().get(this.keyframes.length() - 1);
/* 305 */         return new KeyframeAnimation.KeyFrame((KeyframeAnimationPlayer.this.getData()).endTick, lastFrame.value, lastFrame.ease);
/*     */       } 
/*     */       
/* 308 */       return (KeyframeAnimationPlayer.this.currentTick >= KeyframeAnimationPlayer.this.data.endTick) ? 
/* 309 */         new KeyframeAnimation.KeyFrame(KeyframeAnimationPlayer.this.data.stopTick, currentState) : (
/* 310 */         (KeyframeAnimationPlayer.this.currentTick >= (KeyframeAnimationPlayer.this.getData()).beginTick) ? 
/* 311 */         new KeyframeAnimation.KeyFrame((KeyframeAnimationPlayer.this.getData()).endTick, this.keyframes.defaultValue) : 
/* 312 */         new KeyframeAnimation.KeyFrame((KeyframeAnimationPlayer.this.getData()).beginTick, this.keyframes.defaultValue));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public float getValueAtCurrentTick(float currentValue) {
/* 323 */       if (this.keyframes != null && this.keyframes.isEnabled()) {
/* 324 */         int pos = this.keyframes.findAtTick(KeyframeAnimationPlayer.this.currentTick);
/* 325 */         KeyframeAnimation.KeyFrame keyBefore = findBefore(pos, currentValue);
/* 326 */         if (KeyframeAnimationPlayer.this.isLoopStarted && keyBefore.tick < KeyframeAnimationPlayer.this.data.returnToTick) {
/* 327 */           keyBefore = findBefore(this.keyframes.findAtTick(KeyframeAnimationPlayer.this.data.endTick), currentValue);
/*     */         }
/* 329 */         KeyframeAnimation.KeyFrame keyAfter = findAfter(pos, currentValue);
/* 330 */         if (KeyframeAnimationPlayer.this.data.isInfinite && keyAfter.tick > KeyframeAnimationPlayer.this.data.endTick) {
/* 331 */           keyAfter = findAfter(this.keyframes.findAtTick(KeyframeAnimationPlayer.this.data.returnToTick - 1), currentValue);
/*     */         }
/* 333 */         return getValueFromKeyframes(keyBefore, keyAfter);
/*     */       } 
/* 335 */       return currentValue;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected final float getValueFromKeyframes(KeyframeAnimation.KeyFrame before, KeyframeAnimation.KeyFrame after) {
/* 346 */       int tickBefore = before.tick;
/* 347 */       int tickAfter = after.tick;
/* 348 */       if (tickBefore >= tickAfter)
/* 349 */         if (KeyframeAnimationPlayer.this.currentTick < tickBefore) { tickBefore -= KeyframeAnimationPlayer.this.data.endTick - KeyframeAnimationPlayer.this.data.returnToTick + 1; }
/* 350 */         else { tickAfter += KeyframeAnimationPlayer.this.data.endTick - KeyframeAnimationPlayer.this.data.returnToTick + 1; }
/*     */          
/* 352 */       if (tickBefore == tickAfter) return before.value; 
/* 353 */       float f = (KeyframeAnimationPlayer.this.currentTick + KeyframeAnimationPlayer.this.tickDelta - tickBefore) / (tickAfter - tickBefore);
/* 354 */       return MathHelper.lerp((KeyframeAnimationPlayer.this.data.isEasingBefore ? after.ease : before.ease).invoke(f), before.value, after.value);
/*     */     }
/*     */   }
/*     */   
/*     */   public class RotationAxis
/*     */     extends Axis
/*     */   {
/*     */     public RotationAxis(KeyframeAnimation.StateCollection.State keyframes) {
/* 362 */       super(keyframes);
/*     */     }
/*     */ 
/*     */     
/*     */     public float getValueAtCurrentTick(float currentValue) {
/* 367 */       return MathHelper.clampToRadian(super.getValueAtCurrentTick(MathHelper.clampToRadian(currentValue)));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\api\layered\KeyframeAnimationPlayer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */