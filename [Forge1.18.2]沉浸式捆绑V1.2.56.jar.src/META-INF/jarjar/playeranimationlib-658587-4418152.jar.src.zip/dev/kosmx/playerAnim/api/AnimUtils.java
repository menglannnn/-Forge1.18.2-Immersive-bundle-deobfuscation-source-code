/*    */ package dev.kosmx.playerAnim.api;
/*    */ 
/*    */ import dev.kosmx.playerAnim.api.layered.AnimationStack;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AnimUtils
/*    */ {
/*    */   public static AnimationStack getPlayerAnimLayer(Object player) throws IllegalArgumentException {
/* 16 */     if (player instanceof IPlayer)
/* 17 */       return ((IPlayer)player).getAnimationStack(); 
/* 18 */     throw new IllegalArgumentException(player + " is not a player or library mixins failed");
/*    */   }
/*    */   
/*    */   @Deprecated
/*    */   public static boolean disableFirstPersonAnim = true;
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\api\AnimUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */