/*    */ package dev.kosmx.playerAnim.api.layered;
/*    */ 
/*    */ import dev.kosmx.playerAnim.api.TransformType;
/*    */ import dev.kosmx.playerAnim.api.firstPerson.FirstPersonConfiguration;
/*    */ import dev.kosmx.playerAnim.api.firstPerson.FirstPersonMode;
/*    */ import dev.kosmx.playerAnim.core.util.Vec3f;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface IAnimation
/*    */ {
/*    */   default void tick() {}
/*    */   
/*    */   boolean isActive();
/*    */   
/*    */   @NotNull
/*    */   Vec3f get3DTransform(@NotNull String paramString, @NotNull TransformType paramTransformType, float paramFloat, @NotNull Vec3f paramVec3f);
/*    */   
/*    */   void setupAnim(float paramFloat);
/*    */   
/*    */   @NotNull
/*    */   default FirstPersonMode getFirstPersonMode(float tickDelta) {
/* 51 */     return FirstPersonMode.NONE;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @NotNull
/*    */   default FirstPersonConfiguration getFirstPersonConfiguration(float tickDelta) {
/* 60 */     return new FirstPersonConfiguration();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\api\layered\IAnimation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */