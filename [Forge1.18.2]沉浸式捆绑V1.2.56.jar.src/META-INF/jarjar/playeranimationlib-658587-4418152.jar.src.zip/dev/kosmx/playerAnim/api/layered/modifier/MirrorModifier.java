/*    */ package dev.kosmx.playerAnim.api.layered.modifier;
/*    */ 
/*    */ import dev.kosmx.playerAnim.api.TransformType;
/*    */ import dev.kosmx.playerAnim.api.firstPerson.FirstPersonConfiguration;
/*    */ import dev.kosmx.playerAnim.core.util.Vec3f;
/*    */ import java.util.Collections;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class MirrorModifier
/*    */   extends AbstractModifier
/*    */ {
/*    */   public static final Map<String, String> mirrorMap;
/*    */   
/*    */   public MirrorModifier(boolean enabled) {
/* 17 */     this.enabled = enabled;
/*    */   }
/*    */ 
/*    */   
/*    */   private boolean enabled = true;
/*    */ 
/*    */   
/*    */   public boolean isEnabled() {
/* 25 */     return this.enabled; } public void setEnabled(boolean enabled) {
/* 26 */     this.enabled = enabled;
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Vec3f get3DTransform(@NotNull String modelName, @NotNull TransformType type, float tickDelta, @NotNull Vec3f value0) {
/* 31 */     if (!isEnabled()) return super.get3DTransform(modelName, type, tickDelta, value0);
/*    */     
/* 33 */     if (mirrorMap.containsKey(modelName)) modelName = mirrorMap.get(modelName); 
/* 34 */     value0 = transformVector(value0, type);
/*    */     
/* 36 */     Vec3f vec3f = super.get3DTransform(modelName, type, tickDelta, value0);
/* 37 */     return transformVector(vec3f, type);
/*    */   }
/*    */ 
/*    */   
/*    */   @NotNull
/*    */   public FirstPersonConfiguration getFirstPersonConfiguration(float tickDelta) {
/* 43 */     FirstPersonConfiguration configuration = super.getFirstPersonConfiguration(tickDelta);
/* 44 */     if (isEnabled())
/* 45 */       return (new FirstPersonConfiguration())
/* 46 */         .setShowLeftArm(configuration.isShowRightArm())
/* 47 */         .setShowRightArm(configuration.isShowLeftArm())
/* 48 */         .setShowLeftItem(configuration.isShowRightItem())
/* 49 */         .setShowRightItem(configuration.isShowLeftItem()); 
/* 50 */     return configuration;
/*    */   }
/*    */   
/*    */   protected Vec3f transformVector(Vec3f value0, TransformType type) {
/* 54 */     switch (type) {
/*    */       case POSITION:
/* 56 */         return new Vec3f(-((Float)value0.getX()).floatValue(), ((Float)value0.getY()).floatValue(), ((Float)value0.getZ()).floatValue());
/*    */       case ROTATION:
/* 58 */         return new Vec3f(((Float)value0.getX()).floatValue(), -((Float)value0.getY()).floatValue(), -((Float)value0.getZ()).floatValue());
/*    */       case BEND:
/* 60 */         return new Vec3f(((Float)value0.getX()).floatValue(), -((Float)value0.getY()).floatValue(), ((Float)value0.getZ()).floatValue());
/*    */     } 
/* 62 */     return value0;
/*    */   }
/*    */ 
/*    */   
/*    */   static {
/* 67 */     HashMap<String, String> partMap = new HashMap<>();
/* 68 */     partMap.put("leftArm", "rightArm");
/* 69 */     partMap.put("leftLeg", "rightLeg");
/* 70 */     partMap.put("leftItem", "rightItem");
/* 71 */     partMap.put("rightArm", "leftArm");
/* 72 */     partMap.put("rightLeg", "leftLeg");
/* 73 */     partMap.put("rightItem", "leftItem");
/* 74 */     mirrorMap = Collections.unmodifiableMap(partMap);
/*    */   }
/*    */   
/*    */   public MirrorModifier() {}
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\api\layered\modifier\MirrorModifier.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */