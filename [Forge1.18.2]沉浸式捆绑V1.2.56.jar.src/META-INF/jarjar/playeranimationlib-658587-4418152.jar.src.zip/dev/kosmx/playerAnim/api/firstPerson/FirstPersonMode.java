/*    */ package dev.kosmx.playerAnim.api.firstPerson;
/*    */ 
/*    */ import org.jetbrains.annotations.ApiStatus.Internal;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum FirstPersonMode
/*    */ {
/* 11 */   NONE(false),
/*    */ 
/*    */ 
/*    */   
/* 15 */   VANILLA(true),
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 20 */   THIRD_PERSON_MODEL(true),
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 25 */   DISABLED(false); private final boolean enabled;
/*    */   
/*    */   public boolean isEnabled() {
/* 28 */     return this.enabled;
/*    */   }
/*    */   private static final ThreadLocal<Boolean> firstPersonPass;
/*    */   
/*    */   FirstPersonMode(boolean enabled) {
/* 33 */     this.enabled = enabled;
/*    */   }
/*    */ 
/*    */   
/*    */   static {
/* 38 */     firstPersonPass = ThreadLocal.withInitial(() -> Boolean.valueOf(false));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static boolean isFirstPersonPass() {
/* 45 */     return ((Boolean)firstPersonPass.get()).booleanValue();
/*    */   }
/*    */   
/*    */   @Internal
/*    */   public static void setFirstPersonPass(boolean newValue) {
/* 50 */     firstPersonPass.set(Boolean.valueOf(newValue));
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\api\firstPerson\FirstPersonMode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */