/*     */ package dev.kosmx.playerAnim.api.layered;
/*     */ 
/*     */ import dev.kosmx.playerAnim.api.TransformType;
/*     */ import dev.kosmx.playerAnim.api.firstPerson.FirstPersonConfiguration;
/*     */ import dev.kosmx.playerAnim.api.firstPerson.FirstPersonMode;
/*     */ import dev.kosmx.playerAnim.api.layered.modifier.AbstractFadeModifier;
/*     */ import dev.kosmx.playerAnim.api.layered.modifier.AbstractModifier;
/*     */ import dev.kosmx.playerAnim.core.util.Vec3f;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModifierLayer<T extends IAnimation>
/*     */   implements IAnimation
/*     */ {
/*  28 */   private final List<AbstractModifier> modifiers = new ArrayList<>(); @Nullable
/*     */   public T getAnimation() {
/*  30 */     return this.animation;
/*     */   }
/*     */   @Nullable
/*     */   T animation;
/*     */   public ModifierLayer(@Nullable T animation, AbstractModifier... modifiers) {
/*  35 */     this.animation = animation;
/*  36 */     Collections.addAll(this.modifiers, modifiers);
/*     */   }
/*     */   
/*     */   public ModifierLayer() {
/*  40 */     this(null, new AbstractModifier[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   public void tick() {
/*  45 */     for (int i = 0; i < this.modifiers.size(); i++) {
/*  46 */       if (((AbstractModifier)this.modifiers.get(i)).canRemove()) {
/*  47 */         removeModifier(i--);
/*     */       }
/*     */     } 
/*  50 */     if (this.modifiers.size() > 0)
/*  51 */     { ((AbstractModifier)this.modifiers.get(0)).tick(); }
/*  52 */     else if (this.animation != null) { this.animation.tick(); }
/*     */   
/*     */   }
/*     */   public void addModifier(@NotNull AbstractModifier modifier, int idx) {
/*  56 */     modifier.setHost(this);
/*  57 */     this.modifiers.add(idx, modifier);
/*  58 */     linkModifiers();
/*     */   }
/*     */   
/*     */   public void addModifierBefore(@NotNull AbstractModifier modifier) {
/*  62 */     addModifier(modifier, 0);
/*     */   }
/*     */   
/*     */   public void addModifierLast(@NotNull AbstractModifier modifier) {
/*  66 */     addModifier(modifier, this.modifiers.size());
/*     */   }
/*     */   
/*     */   public void removeModifier(int idx) {
/*  70 */     this.modifiers.remove(idx);
/*  71 */     linkModifiers();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAnimation(@Nullable T animation) {
/*  76 */     this.animation = animation;
/*  77 */     linkModifiers();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void replaceAnimationWithFade(@NotNull AbstractFadeModifier fadeModifier, @Nullable T newAnimation) {
/*  87 */     replaceAnimationWithFade(fadeModifier, newAnimation, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void replaceAnimationWithFade(@NotNull AbstractFadeModifier fadeModifier, @Nullable T newAnimation, boolean fadeFromNothing) {
/*  97 */     if (fadeFromNothing || (getAnimation() != null && getAnimation().isActive())) {
/*  98 */       fadeModifier.setBeginAnimation((IAnimation)getAnimation());
/*  99 */       addModifierLast((AbstractModifier)fadeModifier);
/*     */     } 
/* 101 */     setAnimation(newAnimation);
/*     */   }
/*     */   
/*     */   public int size() {
/* 105 */     return this.modifiers.size();
/*     */   }
/*     */   
/*     */   protected void linkModifiers() {
/* 109 */     Iterator<AbstractModifier> modifierIterator = this.modifiers.iterator();
/* 110 */     if (modifierIterator.hasNext()) {
/* 111 */       AbstractModifier tmp = modifierIterator.next();
/* 112 */       while (modifierIterator.hasNext()) {
/* 113 */         AbstractModifier tmp2 = modifierIterator.next();
/* 114 */         tmp.setAnim((IAnimation)tmp2);
/* 115 */         tmp = tmp2;
/*     */       } 
/* 117 */       tmp.setAnim((IAnimation)this.animation);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isActive() {
/* 124 */     if (this.modifiers.size() > 0)
/* 125 */       return ((AbstractModifier)this.modifiers.get(0)).isActive(); 
/* 126 */     if (this.animation != null) return this.animation.isActive(); 
/* 127 */     return false;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public Vec3f get3DTransform(@NotNull String modelName, @NotNull TransformType type, float tickDelta, @NotNull Vec3f value0) {
/* 132 */     if (this.modifiers.size() > 0)
/* 133 */       return ((AbstractModifier)this.modifiers.get(0)).get3DTransform(modelName, type, tickDelta, value0); 
/* 134 */     if (this.animation != null) return this.animation.get3DTransform(modelName, type, tickDelta, value0); 
/* 135 */     return value0;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setupAnim(float tickDelta) {
/* 140 */     if (this.modifiers.size() > 0)
/* 141 */     { ((AbstractModifier)this.modifiers.get(0)).setupAnim(tickDelta); }
/* 142 */     else if (this.animation != null) { this.animation.setupAnim(tickDelta); }
/*     */   
/*     */   }
/*     */   @NotNull
/*     */   public FirstPersonMode getFirstPersonMode(float tickDelta) {
/* 147 */     if (this.modifiers.size() > 0)
/* 148 */       return ((AbstractModifier)this.modifiers.get(0)).getFirstPersonMode(tickDelta); 
/* 149 */     if (this.animation != null) return this.animation.getFirstPersonMode(tickDelta); 
/* 150 */     return super.getFirstPersonMode(tickDelta);
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public FirstPersonConfiguration getFirstPersonConfiguration(float tickDelta) {
/* 155 */     if (this.modifiers.size() > 0)
/* 156 */       return ((AbstractModifier)this.modifiers.get(0)).getFirstPersonConfiguration(tickDelta); 
/* 157 */     if (this.animation != null) return this.animation.getFirstPersonConfiguration(tickDelta); 
/* 158 */     return super.getFirstPersonConfiguration(tickDelta);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\api\layered\ModifierLayer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */