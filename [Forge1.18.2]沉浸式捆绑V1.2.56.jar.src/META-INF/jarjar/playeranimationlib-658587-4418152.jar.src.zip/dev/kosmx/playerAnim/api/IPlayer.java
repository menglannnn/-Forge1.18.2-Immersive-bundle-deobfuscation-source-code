package dev.kosmx.playerAnim.api;

import dev.kosmx.playerAnim.api.layered.AnimationStack;

public interface IPlayer {
  AnimationStack getAnimationStack();
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\api\IPlayer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */