/*     */ package dev.kosmx.playerAnim.api.layered.modifier;
/*     */ 
/*     */ import dev.kosmx.playerAnim.api.TransformType;
/*     */ import dev.kosmx.playerAnim.api.layered.IAnimation;
/*     */ import dev.kosmx.playerAnim.core.util.Ease;
/*     */ import dev.kosmx.playerAnim.core.util.Vec3f;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractFadeModifier
/*     */   extends AbstractModifier
/*     */ {
/*  18 */   protected int time = 0;
/*     */   
/*     */   protected int length;
/*     */   
/*     */   @Nullable
/*     */   protected IAnimation beginAnimation;
/*     */   
/*     */   public void setBeginAnimation(@Nullable IAnimation beginAnimation) {
/*  26 */     this.beginAnimation = beginAnimation;
/*     */   }
/*     */   
/*     */   protected AbstractFadeModifier(int length) {
/*  30 */     this.length = length;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isActive() {
/*  35 */     return (super.isActive() || (this.beginAnimation != null && this.beginAnimation.isActive()));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canRemove() {
/*  40 */     return (this.length <= this.time);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setupAnim(float tickDelta) {
/*  45 */     super.setupAnim(tickDelta);
/*  46 */     if (this.beginAnimation != null) this.beginAnimation.setupAnim(tickDelta);
/*     */   
/*     */   }
/*     */   
/*     */   public void tick() {
/*  51 */     super.tick();
/*  52 */     if (this.beginAnimation != null) this.beginAnimation.tick(); 
/*  53 */     this.time++;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public Vec3f get3DTransform(@NotNull String modelName, @NotNull TransformType type, float tickDelta, @NotNull Vec3f value0) {
/*  58 */     if (calculateProgress(tickDelta) > 1.0F) {
/*  59 */       return super.get3DTransform(modelName, type, tickDelta, value0);
/*     */     }
/*  61 */     Vec3f animatedVec = super.get3DTransform(modelName, type, tickDelta, value0);
/*  62 */     float a = getAlpha(modelName, type, calculateProgress(tickDelta));
/*  63 */     Vec3f source = (this.beginAnimation != null && this.beginAnimation.isActive()) ? this.beginAnimation.get3DTransform(modelName, type, tickDelta, value0) : value0;
/*  64 */     return animatedVec.scale(a).add(source.scale(1.0F - a));
/*     */   }
/*     */   
/*     */   protected float calculateProgress(float f) {
/*  68 */     float actualTime = this.time + f;
/*  69 */     return actualTime / this.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AbstractFadeModifier standardFadeIn(int length, final Ease ease) {
/*  88 */     return new AbstractFadeModifier(length)
/*     */       {
/*     */         protected float getAlpha(String modelName, TransformType type, float progress) {
/*  91 */           return ease.invoke(progress);
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AbstractFadeModifier functionalFadeIn(int length, final EasingFunction function) {
/* 103 */     return new AbstractFadeModifier(length)
/*     */       {
/*     */         protected float getAlpha(String modelName, TransformType type, float progress) {
/* 106 */           return function.ease(modelName, type, progress);
/*     */         }
/*     */       };
/*     */   }
/*     */   
/*     */   protected abstract float getAlpha(String paramString, TransformType paramTransformType, float paramFloat);
/*     */   
/*     */   @FunctionalInterface
/*     */   public static interface EasingFunction {
/*     */     float ease(String param1String, TransformType param1TransformType, float param1Float);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\api\layered\modifier\AbstractFadeModifier.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */