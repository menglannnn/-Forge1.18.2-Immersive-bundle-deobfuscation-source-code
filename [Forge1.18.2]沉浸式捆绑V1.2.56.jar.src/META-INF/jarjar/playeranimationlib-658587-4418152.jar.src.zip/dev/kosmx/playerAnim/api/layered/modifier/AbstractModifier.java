/*    */ package dev.kosmx.playerAnim.api.layered.modifier;
/*    */ 
/*    */ import dev.kosmx.playerAnim.api.layered.AnimationContainer;
/*    */ import dev.kosmx.playerAnim.api.layered.IAnimation;
/*    */ import dev.kosmx.playerAnim.api.layered.ModifierLayer;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractModifier
/*    */   extends AnimationContainer<IAnimation>
/*    */ {
/*    */   @Nullable
/*    */   protected ModifierLayer host;
/*    */   
/*    */   public void setHost(@Nullable ModifierLayer host) {
/* 18 */     this.host = host;
/*    */   }
/*    */   
/*    */   public AbstractModifier() {
/* 22 */     super(null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean canRemove() {
/* 29 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\api\layered\modifier\AbstractModifier.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */