/*     */ package dev.kosmx.playerAnim.api.layered.modifier;
/*     */ 
/*     */ import dev.kosmx.playerAnim.api.TransformType;
/*     */ import dev.kosmx.playerAnim.api.layered.IAnimation;
/*     */ import dev.kosmx.playerAnim.api.layered.KeyframeAnimationPlayer;
/*     */ import dev.kosmx.playerAnim.core.util.Vec3f;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.function.Function;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AdjustmentModifier
/*     */   extends AbstractModifier
/*     */ {
/*     */   public static final class PartModifier
/*     */   {
/*     */     private final Vec3f rotation;
/*     */     private final Vec3f offset;
/*     */     
/*     */     public PartModifier(Vec3f rotation, Vec3f offset) {
/*  58 */       this.rotation = rotation;
/*  59 */       this.offset = offset;
/*     */     }
/*     */     
/*     */     public Vec3f rotation() {
/*  63 */       return this.rotation;
/*     */     }
/*     */     
/*     */     public Vec3f offset() {
/*  67 */       return this.offset;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/*  72 */       if (obj == this) return true; 
/*  73 */       if (obj == null || obj.getClass() != getClass()) return false; 
/*  74 */       PartModifier that = (PartModifier)obj;
/*  75 */       return (Objects.equals(this.rotation, that.rotation) && 
/*  76 */         Objects.equals(this.offset, that.offset));
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/*  81 */       return Objects.hash(new Object[] { this.rotation, this.offset });
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/*  86 */       return "PartModifier[rotation=" + this.rotation + ", offset=" + this.offset + ']';
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean enabled = true;
/*     */   
/*     */   protected Function<String, Optional<PartModifier>> source;
/*     */   
/*     */   protected int instructedFadeout;
/*     */   
/*     */   private int remainingFadeout;
/*     */ 
/*     */   
/*     */   protected float getFadeIn(float delta) {
/* 101 */     float fadeIn = 1.0F;
/* 102 */     IAnimation animation = getAnim();
/* 103 */     if (animation instanceof KeyframeAnimationPlayer) {
/* 104 */       KeyframeAnimationPlayer player = (KeyframeAnimationPlayer)this.anim;
/* 105 */       float currentTick = player.getTick() + delta;
/* 106 */       fadeIn = currentTick / (player.getData()).beginTick;
/* 107 */       fadeIn = Math.min(fadeIn, 1.0F);
/*     */     } 
/* 109 */     return fadeIn;
/*     */   }
/*     */ 
/*     */   
/*     */   public void tick() {
/* 114 */     super.tick();
/*     */     
/* 116 */     if (this.remainingFadeout > 0) {
/* 117 */       this.remainingFadeout--;
/* 118 */       if (this.remainingFadeout <= 0)
/* 119 */         this.instructedFadeout = 0; 
/*     */     } 
/*     */   }
/*     */   
/*     */   public AdjustmentModifier(Function<String, Optional<PartModifier>> source) {
/* 124 */     this.instructedFadeout = 0;
/* 125 */     this.remainingFadeout = 0;
/*     */     this.source = source;
/*     */   } public void fadeOut(int fadeOut) {
/* 128 */     this.instructedFadeout = fadeOut;
/* 129 */     this.remainingFadeout = fadeOut + 1;
/*     */   }
/*     */   
/*     */   protected float getFadeOut(float delta) {
/* 133 */     float fadeOut = 1.0F;
/* 134 */     if (this.remainingFadeout > 0 && this.instructedFadeout > 0) {
/* 135 */       float current = Math.max(this.remainingFadeout - delta, 0.0F);
/* 136 */       fadeOut = current / this.instructedFadeout;
/* 137 */       fadeOut = Math.min(fadeOut, 1.0F);
/* 138 */       return fadeOut;
/*     */     } 
/* 140 */     IAnimation animation = getAnim();
/* 141 */     if (animation instanceof KeyframeAnimationPlayer) {
/* 142 */       KeyframeAnimationPlayer player = (KeyframeAnimationPlayer)this.anim;
/*     */       
/* 144 */       float currentTick = player.getTick() + delta;
/* 145 */       float position = -1.0F * (currentTick - (player.getData()).stopTick);
/* 146 */       float length = ((player.getData()).stopTick - (player.getData()).endTick);
/* 147 */       if (length > 0.0F) {
/* 148 */         fadeOut = position / length;
/* 149 */         fadeOut = Math.min(fadeOut, 1.0F);
/*     */       } 
/*     */     } 
/* 152 */     return fadeOut;
/*     */   }
/*     */ 
/*     */   
/*     */   public Vec3f get3DTransform(String modelName, TransformType type, float tickDelta, Vec3f value0) {
/* 157 */     if (!this.enabled) {
/* 158 */       return super.get3DTransform(modelName, type, tickDelta, value0);
/*     */     }
/*     */     
/* 161 */     Optional<PartModifier> partModifier = this.source.apply(modelName);
/*     */     
/* 163 */     Vec3f modifiedVector = value0;
/* 164 */     float fade = getFadeIn(tickDelta) * getFadeOut(tickDelta);
/* 165 */     if (partModifier.isPresent()) {
/* 166 */       modifiedVector = super.get3DTransform(modelName, type, tickDelta, modifiedVector);
/* 167 */       return transformVector(modifiedVector, type, partModifier.get(), fade);
/*     */     } 
/* 169 */     return super.get3DTransform(modelName, type, tickDelta, value0);
/*     */   }
/*     */ 
/*     */   
/*     */   protected Vec3f transformVector(Vec3f vector, TransformType type, PartModifier partModifier, float fade) {
/* 174 */     switch (type) {
/*     */       case POSITION:
/* 176 */         return vector.add(partModifier.offset().scale(fade));
/*     */       case ROTATION:
/* 178 */         return vector.add(partModifier.rotation().scale(fade));
/*     */     } 
/*     */ 
/*     */     
/* 182 */     return vector;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\api\layered\modifier\AdjustmentModifier.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */