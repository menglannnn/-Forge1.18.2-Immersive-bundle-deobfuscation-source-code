/*    */ package dev.kosmx.playerAnim.api.layered;
/*    */ 
/*    */ import dev.kosmx.playerAnim.api.TransformType;
/*    */ import dev.kosmx.playerAnim.core.util.Pair;
/*    */ import dev.kosmx.playerAnim.core.util.Vec3f;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class PlayerAnimationFrame
/*    */   implements IAnimation
/*    */ {
/* 20 */   protected PlayerPart head = new PlayerPart();
/* 21 */   protected PlayerPart body = new PlayerPart();
/* 22 */   protected PlayerPart rightArm = new PlayerPart();
/* 23 */   protected PlayerPart leftArm = new PlayerPart();
/* 24 */   protected PlayerPart rightLeg = new PlayerPart();
/* 25 */   protected PlayerPart leftLeg = new PlayerPart();
/* 26 */   protected PlayerPart rightItem = new PlayerPart();
/* 27 */   protected PlayerPart leftItem = new PlayerPart();
/*    */   
/* 29 */   HashMap<String, PlayerPart> parts = new HashMap<>();
/*    */   
/*    */   public PlayerAnimationFrame() {
/* 32 */     this.parts.put("head", this.head);
/* 33 */     this.parts.put("body", this.body);
/* 34 */     this.parts.put("rightArm", this.rightArm);
/* 35 */     this.parts.put("leftArm", this.leftArm);
/* 36 */     this.parts.put("rightLeg", this.rightLeg);
/* 37 */     this.parts.put("leftLeg", this.leftLeg);
/* 38 */     this.parts.put("rightItem", this.rightItem);
/* 39 */     this.parts.put("leftItem", this.leftItem);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void tick() {
/* 45 */     super.tick();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isActive() {
/* 50 */     for (Map.Entry<String, PlayerPart> entry : this.parts.entrySet()) {
/* 51 */       PlayerPart part = entry.getValue();
/* 52 */       if (part.bend != null || part.pos != null || part.rot != null) return true; 
/*    */     } 
/* 54 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void resetPose() {
/* 62 */     for (Map.Entry<String, PlayerPart> entry : this.parts.entrySet()) {
/* 63 */       ((PlayerPart)entry.getValue()).setNull();
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   @NotNull
/*    */   public Vec3f get3DTransform(@NotNull String modelName, @NotNull TransformType type, float tickDelta, @NotNull Vec3f value0) {
/* 70 */     PlayerPart part = this.parts.get(modelName);
/* 71 */     if (part == null) return value0; 
/* 72 */     switch (type) {
/*    */       case POSITION:
/* 74 */         return (part.pos == null) ? value0 : part.pos;
/*    */       case ROTATION:
/* 76 */         return (part.rot == null) ? value0 : part.rot;
/*    */       case BEND:
/* 78 */         return (part.bend == null) ? value0 : new Vec3f(((Float)part.bend.getLeft()).floatValue(), ((Float)part.bend.getRight()).floatValue(), 0.0F);
/*    */     } 
/* 80 */     return value0;
/*    */   }
/*    */   
/*    */   public static class PlayerPart
/*    */   {
/*    */     public Vec3f pos;
/*    */     public Vec3f rot;
/*    */     public Pair<Float, Float> bend;
/*    */     
/*    */     protected void setNull() {
/* 90 */       this.pos = this.rot = null;
/* 91 */       this.bend = null;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\api\layered\PlayerAnimationFrame.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */