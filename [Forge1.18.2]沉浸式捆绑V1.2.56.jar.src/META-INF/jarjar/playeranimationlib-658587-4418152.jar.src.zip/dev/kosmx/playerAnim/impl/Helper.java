/*    */ package dev.kosmx.playerAnim.impl;
/*    */ 
/*    */ import dev.architectury.injectables.annotations.ExpectPlatform;
/*    */ import dev.architectury.injectables.annotations.ExpectPlatform.Transformed;
/*    */ import dev.kosmx.playerAnim.impl.forge.HelperImpl;
/*    */ import java.util.concurrent.atomic.AtomicBoolean;
/*    */ import org.jetbrains.annotations.ApiStatus.Internal;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ @Internal
/*    */ public final class Helper
/*    */ {
/*    */   @Nullable
/* 16 */   private static AtomicBoolean isBendyLibLoaded = null;
/*    */   
/*    */   public static boolean isBendEnabled() {
/* 19 */     if (isBendyLibLoaded == null) isBendyLibLoaded = new AtomicBoolean(isBendyLibPresent()); 
/* 20 */     return isBendyLibLoaded.get();
/*    */   }
/*    */   
/*    */   @ExpectPlatform
/*    */   @Transformed
/*    */   public static boolean isBendyLibPresent() {
/*    */     return HelperImpl.isBendyLibPresent();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\impl\Helper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */