package dev.kosmx.playerAnim.impl;

import dev.kosmx.playerAnim.core.impl.AnimationProcessor;
import dev.kosmx.playerAnim.core.util.SetableSupplier;
import org.jetbrains.annotations.ApiStatus.Internal;

@Internal
public interface IMutableModel {
  void setEmoteSupplier(SetableSupplier<AnimationProcessor> paramSetableSupplier);
  
  SetableSupplier<AnimationProcessor> getEmoteSupplier();
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\impl\IMutableModel.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */