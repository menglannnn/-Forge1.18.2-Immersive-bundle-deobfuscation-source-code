package dev.kosmx.playerAnim.impl;

import org.jetbrains.annotations.ApiStatus.Internal;

@Internal
public interface IUpperPartHelper {
  boolean isUpperPart();
  
  void setUpperPart(boolean paramBoolean);
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\impl\IUpperPartHelper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */