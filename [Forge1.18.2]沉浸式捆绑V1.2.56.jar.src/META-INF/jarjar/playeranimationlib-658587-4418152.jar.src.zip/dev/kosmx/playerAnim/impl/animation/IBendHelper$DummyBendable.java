package dev.kosmx.playerAnim.impl.animation;

import dev.kosmx.playerAnim.core.util.Pair;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.core.Direction;
import org.jetbrains.annotations.Nullable;

public class DummyBendable implements IBendHelper {
  public void bend(ModelPart modelPart, float a, float b) {}
  
  public void bend(ModelPart modelPart, @Nullable Pair<Float, Float> pair) {}
  
  public void initBend(ModelPart modelPart, Direction direction) {}
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\impl\animation\IBendHelper$DummyBendable.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */