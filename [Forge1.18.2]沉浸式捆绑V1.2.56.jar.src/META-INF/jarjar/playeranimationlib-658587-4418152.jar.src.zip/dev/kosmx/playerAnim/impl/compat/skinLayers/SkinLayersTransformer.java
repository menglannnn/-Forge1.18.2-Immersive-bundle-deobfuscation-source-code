/*    */ package dev.kosmx.playerAnim.impl.compat.skinLayers;
/*    */ import com.mojang.blaze3d.vertex.PoseStack;
/*    */ import dev.kosmx.playerAnim.impl.IAnimatedPlayer;
/*    */ import dev.kosmx.playerAnim.impl.IUpperPartHelper;
/*    */ import dev.kosmx.playerAnim.impl.animation.IBendHelper;
/*    */ import net.minecraft.client.model.geom.ModelPart;
/*    */ import net.minecraft.client.player.AbstractClientPlayer;
/*    */ import org.jetbrains.annotations.ApiStatus.Internal;
/*    */ import org.slf4j.Logger;
/*    */ 
/*    */ @Internal
/*    */ public class SkinLayersTransformer {
/*    */   public static void init(Logger logger) {
/* 14 */     logger.info("Loading 3D skin compat");
/*    */     
/* 16 */     LayerFeatureTransformerAPI.setLayerTransformer((player, matrixStack, modelPart) -> {
/*    */           if (((IUpperPartHelper)modelPart).isUpperPart())
/*    */             IBendHelper.rotateMatrixStack(matrixStack, ((IAnimatedPlayer)player).playerAnimator_getAnimation().getBend("body")); 
/*    */         });
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\impl\compat\skinLayers\SkinLayersTransformer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */