/*    */ package dev.kosmx.playerAnim.impl;
/*    */ 
/*    */ import dev.kosmx.playerAnim.api.IPlayer;
/*    */ import dev.kosmx.playerAnim.api.layered.IAnimation;
/*    */ import dev.kosmx.playerAnim.impl.animation.AnimationApplier;
/*    */ import net.minecraft.resources.ResourceLocation;
/*    */ import org.jetbrains.annotations.ApiStatus.Internal;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Internal
/*    */ public interface IAnimatedPlayer
/*    */   extends IPlayer
/*    */ {
/*    */   @Deprecated(forRemoval = true)
/*    */   default AnimationApplier getAnimation() {
/* 24 */     return playerAnimator_getAnimation();
/*    */   }
/*    */   
/*    */   AnimationApplier playerAnimator_getAnimation();
/*    */   
/*    */   @Nullable
/*    */   IAnimation playerAnimator_getAnimation(@NotNull ResourceLocation paramResourceLocation);
/*    */   
/*    */   @Nullable
/*    */   IAnimation playerAnimator_setAnimation(@NotNull ResourceLocation paramResourceLocation, @Nullable IAnimation paramIAnimation);
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\impl\IAnimatedPlayer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */