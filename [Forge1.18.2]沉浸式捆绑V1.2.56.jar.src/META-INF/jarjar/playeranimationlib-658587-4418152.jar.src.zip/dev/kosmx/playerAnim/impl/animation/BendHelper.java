/*    */ package dev.kosmx.playerAnim.impl.animation;
/*    */ 
/*    */ import dev.kosmx.playerAnim.core.util.Pair;
/*    */ import io.github.kosmx.bendylib.ICuboidBuilder;
/*    */ import io.github.kosmx.bendylib.ModelPartAccessor;
/*    */ import io.github.kosmx.bendylib.MutableCuboid;
/*    */ import io.github.kosmx.bendylib.impl.BendableCuboid;
/*    */ import io.github.kosmx.bendylib.impl.ICuboid;
/*    */ import net.minecraft.client.model.geom.ModelPart;
/*    */ import net.minecraft.core.Direction;
/*    */ import org.jetbrains.annotations.ApiStatus.Internal;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ @Internal
/*    */ public class BendHelper
/*    */   implements IBendHelper {
/*    */   public void bend(ModelPart modelPart, float a, float b) {
/* 18 */     ModelPartAccessor.optionalGetCuboid(modelPart, 0).ifPresent(mutableCuboid -> ((BendableCuboid)mutableCuboid.getAndActivateMutator("bend")).applyBend(a, b));
/*    */   }
/*    */ 
/*    */   
/*    */   public void bend(ModelPart modelPart, @Nullable Pair<Float, Float> pair) {
/* 23 */     if (pair != null) {
/* 24 */       bend(modelPart, ((Float)pair.getLeft()).floatValue(), ((Float)pair.getRight()).floatValue());
/*    */     }
/*    */     else {
/*    */       
/* 28 */       ModelPartAccessor.optionalGetCuboid(modelPart, 0).ifPresent(mutableCuboid -> mutableCuboid.getAndActivateMutator(null));
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void initBend(ModelPart modelPart, Direction direction) {
/* 34 */     ModelPartAccessor.optionalGetCuboid(modelPart, 0).ifPresent(mutableModelPart -> mutableModelPart.registerMutator("bend", ()));
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\impl\animation\BendHelper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */