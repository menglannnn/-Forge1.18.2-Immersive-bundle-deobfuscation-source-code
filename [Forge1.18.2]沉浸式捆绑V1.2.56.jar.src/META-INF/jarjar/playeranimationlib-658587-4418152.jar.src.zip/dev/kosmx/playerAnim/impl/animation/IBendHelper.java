/*    */ package dev.kosmx.playerAnim.impl.animation;
/*    */ 
/*    */ import com.mojang.blaze3d.vertex.PoseStack;
/*    */ import com.mojang.math.Vector3f;
/*    */ import dev.kosmx.playerAnim.core.util.Pair;
/*    */ import dev.kosmx.playerAnim.impl.Helper;
/*    */ import net.minecraft.client.model.geom.ModelPart;
/*    */ import net.minecraft.core.Direction;
/*    */ import org.jetbrains.annotations.ApiStatus.Internal;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ 
/*    */ @Internal
/*    */ public interface IBendHelper
/*    */ {
/* 16 */   public static final IBendHelper INSTANCE = Helper.isBendEnabled() ? new BendHelper() : new DummyBendable();
/*    */   static void rotateMatrixStack(PoseStack matrices, Pair<Float, Float> pair) {
/* 18 */     float offset = 0.375F;
/* 19 */     matrices.m_85837_(0.0D, offset, 0.0D);
/* 20 */     float bend = ((Float)pair.getRight()).floatValue();
/* 21 */     float axisf = -((Float)pair.getLeft()).floatValue();
/* 22 */     Vector3f axis = new Vector3f((float)Math.cos(axisf), 0.0F, (float)Math.sin(axisf));
/*    */     
/* 24 */     matrices.m_85845_(axis.m_122270_(bend));
/* 25 */     matrices.m_85837_(0.0D, -offset, 0.0D);
/*    */   }
/*    */   
/*    */   void bend(ModelPart paramModelPart, float paramFloat1, float paramFloat2);
/*    */   
/*    */   void bend(ModelPart paramModelPart, @Nullable Pair<Float, Float> paramPair);
/*    */   
/*    */   void initBend(ModelPart paramModelPart, Direction paramDirection);
/*    */   
/*    */   public static class DummyBendable implements IBendHelper {
/*    */     public void bend(ModelPart modelPart, float a, float b) {}
/*    */     
/*    */     public void bend(ModelPart modelPart, @Nullable Pair<Float, Float> pair) {}
/*    */     
/*    */     public void initBend(ModelPart modelPart, Direction direction) {}
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\impl\animation\IBendHelper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */