/*    */ package dev.kosmx.playerAnim.impl.animation;
/*    */ 
/*    */ import dev.kosmx.playerAnim.api.TransformType;
/*    */ import dev.kosmx.playerAnim.api.layered.IAnimation;
/*    */ import dev.kosmx.playerAnim.core.impl.AnimationProcessor;
/*    */ import dev.kosmx.playerAnim.core.util.MathHelper;
/*    */ import dev.kosmx.playerAnim.core.util.Pair;
/*    */ import dev.kosmx.playerAnim.core.util.Vec3f;
/*    */ import net.minecraft.client.model.geom.ModelPart;
/*    */ import org.jetbrains.annotations.ApiStatus.Internal;
/*    */ 
/*    */ @Internal
/*    */ public class AnimationApplier
/*    */   extends AnimationProcessor {
/*    */   public AnimationApplier(IAnimation animation) {
/* 16 */     super(animation);
/*    */   }
/*    */   
/*    */   public void updatePart(String partName, ModelPart part) {
/* 20 */     Vec3f pos = get3DTransform(partName, TransformType.POSITION, new Vec3f(part.f_104200_, part.f_104201_, part.f_104202_));
/* 21 */     part.f_104200_ = ((Float)pos.getX()).floatValue();
/* 22 */     part.f_104201_ = ((Float)pos.getY()).floatValue();
/* 23 */     part.f_104202_ = ((Float)pos.getZ()).floatValue();
/* 24 */     Vec3f rot = get3DTransform(partName, TransformType.ROTATION, new Vec3f(
/* 25 */           MathHelper.clampToRadian(part.f_104203_), 
/* 26 */           MathHelper.clampToRadian(part.f_104204_), 
/* 27 */           MathHelper.clampToRadian(part.f_104205_)));
/* 28 */     part.m_171327_(((Float)rot.getX()).floatValue(), ((Float)rot.getY()).floatValue(), ((Float)rot.getZ()).floatValue());
/* 29 */     if (!partName.equals("head"))
/* 30 */       if (partName.equals("torso")) {
/* 31 */         Pair<Float, Float> torsoBend = getBend(partName);
/* 32 */         Pair<Float, Float> bodyBend = getBend("body");
/* 33 */         IBendHelper.INSTANCE.bend(part, new Pair(Float.valueOf(((Float)torsoBend.getLeft()).floatValue() + ((Float)bodyBend.getLeft()).floatValue()), Float.valueOf(((Float)torsoBend.getRight()).floatValue() + ((Float)bodyBend.getRight()).floatValue())));
/*    */       } else {
/* 35 */         IBendHelper.INSTANCE.bend(part, getBend(partName));
/*    */       }  
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\impl\animation\AnimationApplier.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */