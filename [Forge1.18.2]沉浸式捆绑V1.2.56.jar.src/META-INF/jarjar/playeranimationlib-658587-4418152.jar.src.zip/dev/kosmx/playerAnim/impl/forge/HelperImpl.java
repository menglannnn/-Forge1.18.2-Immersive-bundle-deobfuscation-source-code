/*    */ package dev.kosmx.playerAnim.impl.forge;
/*    */ 
/*    */ import org.jetbrains.annotations.ApiStatus.Internal;
/*    */ import org.spongepowered.asm.service.MixinService;
/*    */ 
/*    */ 
/*    */ @Internal
/*    */ public class HelperImpl
/*    */ {
/*    */   public static boolean isBendyLibPresent() {
/* 11 */     return hasClass("io.github.kosmx.bendylib.impl.ICuboid");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   private static boolean hasClass(String name) {
/*    */     try {
/* 18 */       MixinService.getService().getBytecodeProvider().getClassNode(name);
/* 19 */       return true;
/* 20 */     } catch (ClassNotFoundException|java.io.IOException e) {
/* 21 */       return false;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\impl\forge\HelperImpl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */