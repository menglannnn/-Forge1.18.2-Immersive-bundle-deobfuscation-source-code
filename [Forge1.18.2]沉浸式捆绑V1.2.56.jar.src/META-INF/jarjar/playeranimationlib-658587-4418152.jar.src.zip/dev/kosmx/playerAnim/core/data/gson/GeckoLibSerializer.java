/*     */ package dev.kosmx.playerAnim.core.data.gson;
/*     */ 
/*     */ import com.google.gson.JsonArray;
/*     */ import com.google.gson.JsonElement;
/*     */ import com.google.gson.JsonObject;
/*     */ import com.google.gson.JsonParseException;
/*     */ import dev.kosmx.playerAnim.core.data.AnimationFormat;
/*     */ import dev.kosmx.playerAnim.core.data.KeyframeAnimation;
/*     */ import dev.kosmx.playerAnim.core.util.Ease;
/*     */ import dev.kosmx.playerAnim.core.util.Easing;
/*     */ import java.io.IOException;
/*     */ import java.io.StringReader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GeckoLibSerializer
/*     */ {
/*     */   public static List<KeyframeAnimation> serialize(JsonObject node) {
/*     */     try {
/*  25 */       return readAnimations(node.get("animations").getAsJsonObject());
/*  26 */     } catch (NumberFormatException e) {
/*  27 */       throw new JsonParseException(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static List<KeyframeAnimation> readAnimations(JsonObject jsonEmotes) {
/*  32 */     List<KeyframeAnimation> emotes = new ArrayList<>();
/*  33 */     jsonEmotes.entrySet().forEach(stringJsonElementEntry -> {
/*     */           KeyframeAnimation.AnimationBuilder builder = new KeyframeAnimation.AnimationBuilder(AnimationFormat.JSON_MC_ANIM);
/*     */           String name = (String)stringJsonElementEntry.getKey();
/*     */           JsonObject node = ((JsonElement)stringJsonElementEntry.getValue()).getAsJsonObject();
/*     */           builder.name = name;
/*     */           if (node.has("animation_length")) {
/*     */             builder.endTick = (int)Math.ceil((node.get("animation_length").getAsFloat() * 20.0F));
/*     */             if (node.has("loop")) {
/*  41 */               builder.isLooped = (node.get("loop").getAsJsonPrimitive().isBoolean() && node.get("loop").getAsBoolean());
/*     */               
/*     */               if (!builder.isLooped && node.get("loop").getAsJsonPrimitive().isString() && node.get("loop").getAsString().equals("hold_on_last_frame")) {
/*     */                 builder.isLooped = true;
/*     */                 
/*     */                 builder.returnTick = builder.endTick;
/*     */               } else {
/*     */                 builder.endTick--;
/*     */               } 
/*     */             } 
/*     */             
/*     */             builder.fullyEnableParts();
/*     */             
/*     */             builder.optimizeEmote();
/*     */             keyframeSerializer(builder, node.get("bones").getAsJsonObject());
/*     */           } else if (node.has("loop") && node.get("loop").getAsBoolean()) {
/*     */             builder.endTick = builder.stopTick = 1;
/*     */             builder.isLooped = true;
/*     */             builder.returnTick = 0;
/*     */             keyframeSerializer(builder, node.get("bones").getAsJsonObject());
/*     */           } else {
/*     */             throw new JsonParseException("Could not recognise GeckoLib animation: " + name);
/*     */           } 
/*     */           emotes.add(builder.build());
/*     */         });
/*  66 */     return emotes;
/*     */   }
/*     */   
/*     */   private static void keyframeSerializer(KeyframeAnimation.AnimationBuilder emoteData, JsonObject node) {
/*  70 */     for (Map.Entry<String, JsonElement> entry : (Iterable<Map.Entry<String, JsonElement>>)node.entrySet()) {
/*  71 */       readBone(emoteData.getOrCreatePart(snake2Camel(entry.getKey())), ((JsonElement)entry.getValue()).getAsJsonObject(), emoteData);
/*     */     }
/*     */   }
/*     */   
/*     */   private static void readBone(KeyframeAnimation.StateCollection stateCollection, JsonObject node, KeyframeAnimation.AnimationBuilder emoteData) {
/*  76 */     if (node.has("rotation")) {
/*  77 */       JsonElement jsonRotation = node.get("rotation");
/*  78 */       if (jsonRotation.isJsonArray()) {
/*  79 */         readCollection(getRots(stateCollection), 0, Ease.LINEAR, jsonRotation.getAsJsonArray(), emoteData, false);
/*     */       } else {
/*     */         
/*  82 */         jsonRotation.getAsJsonObject().entrySet().forEach(entry -> {
/*     */               if (((String)entry.getKey()).equals("vector")) {
/*     */                 readCollection(getRots(stateCollection), 0, Ease.LINEAR, ((JsonElement)entry.getValue()).getAsJsonArray(), emoteData, false);
/*     */               } else if (!((String)entry.getKey()).equals("easing")) {
/*     */                 int tick = (int)(Float.parseFloat((String)entry.getKey()) * 20.0F);
/*     */                 
/*     */                 if (((JsonElement)entry.getValue()).isJsonArray()) {
/*     */                   readCollection(getRots(stateCollection), tick, Ease.CONSTANT, ((JsonElement)entry.getValue()).getAsJsonArray(), emoteData, false);
/*     */                 } else {
/*     */                   readDataAtTick(((JsonElement)entry.getValue()).getAsJsonObject(), stateCollection, tick, emoteData, false);
/*     */                 } 
/*     */               } 
/*     */             });
/*     */       } 
/*     */     } 
/*     */     
/*  98 */     if (node.has("position")) {
/*  99 */       JsonElement jsonPosition = node.get("position");
/* 100 */       if (jsonPosition.isJsonArray()) {
/* 101 */         readCollection(getOffs(stateCollection), 0, Ease.LINEAR, jsonPosition.getAsJsonArray(), emoteData, true);
/*     */       } else {
/*     */         
/* 104 */         jsonPosition.getAsJsonObject().entrySet().forEach(entry -> {
/*     */               if (((String)entry.getKey()).equals("vector")) {
/*     */                 readCollection(getOffs(stateCollection), 0, Ease.LINEAR, ((JsonElement)entry.getValue()).getAsJsonArray(), emoteData, true);
/*     */               } else if (!((String)entry.getKey()).equals("easing")) {
/*     */                 int tick = (int)(Float.parseFloat((String)entry.getKey()) * 20.0F);
/*     */                 if (((JsonElement)entry.getValue()).isJsonArray()) {
/*     */                   readCollection(getOffs(stateCollection), tick, Ease.LINEAR, ((JsonElement)entry.getValue()).getAsJsonArray(), emoteData, true);
/*     */                 } else {
/*     */                   readDataAtTick(((JsonElement)entry.getValue()).getAsJsonObject(), stateCollection, tick, emoteData, true);
/*     */                 } 
/*     */               } 
/*     */             });
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static void readDataAtTick(JsonObject currentNode, KeyframeAnimation.StateCollection stateCollection, int tick, KeyframeAnimation.AnimationBuilder emoteData, boolean isPos) {
/* 122 */     Ease ease = Ease.LINEAR;
/* 123 */     if (currentNode.has("lerp_mode")) {
/* 124 */       String lerp = currentNode.get("lerp_mode").getAsString();
/* 125 */       ease = lerp.equals("catmullrom") ? Ease.INOUTSINE : Easing.easeFromString(lerp);
/*     */     } 
/* 127 */     KeyframeAnimation.StateCollection.State[] targetVec = isPos ? getOffs(stateCollection) : getRots(stateCollection);
/* 128 */     if (currentNode.has("easing")) ease = Easing.easeFromString(currentNode.get("easing").getAsString()); 
/* 129 */     if (currentNode.has("pre"))
/* 130 */       readCollection(targetVec, tick, ease, getVector(currentNode.get("pre")), emoteData, isPos); 
/* 131 */     if (currentNode.has("vector"))
/* 132 */       readCollection(targetVec, tick, ease, currentNode.get("vector").getAsJsonArray(), emoteData, isPos); 
/* 133 */     if (currentNode.has("post"))
/* 134 */       readCollection(targetVec, tick, ease, getVector(currentNode.get("post")), emoteData, isPos); 
/*     */   }
/*     */   
/*     */   public static JsonArray getVector(JsonElement element) {
/* 138 */     if (element.isJsonArray()) return element.getAsJsonArray(); 
/* 139 */     return ((JsonObject)element).get("vector").getAsJsonArray();
/*     */   }
/*     */   
/*     */   private static void readCollection(KeyframeAnimation.StateCollection.State[] a, int tick, Ease ease, JsonArray array, KeyframeAnimation.AnimationBuilder emoteData, boolean isPos) {
/* 143 */     if (a.length != 3) throw new ArrayStoreException("wrong array length"); 
/* 144 */     for (int i = 0; i < 3; i++) {
/* 145 */       float value = array.get(i).getAsFloat();
/* 146 */       if (isPos) {
/* 147 */         if (a[0] == emoteData.body.x) {
/* 148 */           value /= 16.0F;
/* 149 */           if (i == 0) value = -value;
/*     */         
/* 151 */         } else if (i == 1) {
/* 152 */           value = -value;
/*     */         }
/*     */       
/* 155 */       } else if (a[0] == emoteData.body.pitch && i != 2) {
/* 156 */         value = -value;
/*     */       } 
/*     */       
/* 159 */       value += (a[i]).defaultValue;
/* 160 */       a[i].addKeyFrame(tick, value, ease, 0, true);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String snake2Camel(String original) {
/* 170 */     StringBuilder builder = new StringBuilder();
/* 171 */     StringReader reader = new StringReader(original);
/*     */     
/* 173 */     boolean upperNext = false; try {
/*     */       int c;
/* 175 */       while ((c = reader.read()) != -1) {
/* 176 */         if (c == 95) {
/* 177 */           upperNext = true;
/*     */           continue;
/*     */         } 
/* 180 */         if (upperNext) {
/* 181 */           builder.appendCodePoint(Character.toUpperCase(c));
/*     */         } else {
/* 183 */           builder.appendCodePoint(c);
/*     */         } 
/* 185 */         upperNext = false;
/*     */       } 
/* 187 */     } catch (IOException ignore) {
/* 188 */       return original;
/*     */     } 
/* 190 */     return builder.toString();
/*     */   }
/*     */   
/*     */   private static KeyframeAnimation.StateCollection.State[] getRots(KeyframeAnimation.StateCollection stateCollection) {
/* 194 */     return new KeyframeAnimation.StateCollection.State[] { stateCollection.pitch, stateCollection.yaw, stateCollection.roll };
/*     */   }
/*     */   
/*     */   private static KeyframeAnimation.StateCollection.State[] getOffs(KeyframeAnimation.StateCollection stateCollection) {
/* 198 */     return new KeyframeAnimation.StateCollection.State[] { stateCollection.x, stateCollection.y, stateCollection.z };
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\core\data\gson\GeckoLibSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */