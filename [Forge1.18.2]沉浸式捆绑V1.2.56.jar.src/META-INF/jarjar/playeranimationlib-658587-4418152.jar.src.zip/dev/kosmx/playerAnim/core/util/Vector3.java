/*    */ package dev.kosmx.playerAnim.core.util;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import javax.annotation.concurrent.Immutable;
/*    */ 
/*    */ 
/*    */ 
/*    */ @Immutable
/*    */ public class Vector3<N extends Number>
/*    */ {
/*    */   N x;
/*    */   N y;
/*    */   N z;
/*    */   
/*    */   public Vector3(N x, N y, N z) {
/* 16 */     this.x = x;
/* 17 */     this.y = y;
/* 18 */     this.z = z;
/*    */   }
/*    */   
/*    */   public N getX() {
/* 22 */     return this.x;
/*    */   }
/*    */   
/*    */   public N getY() {
/* 26 */     return this.y;
/*    */   }
/*    */   
/*    */   public N getZ() {
/* 30 */     return this.z;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 35 */     if (this == o) return true; 
/* 36 */     if (!(o instanceof Vector3)) return false; 
/* 37 */     Vector3<?> vector3 = (Vector3)o;
/* 38 */     return (Objects.equals(this.x, vector3.x) && Objects.equals(this.y, vector3.y) && Objects.equals(this.z, vector3.z));
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 43 */     return Objects.hash(new Object[] { this.x, this.y, this.z });
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 48 */     return "Vec3f[" + getX() + "; " + getY() + "; " + getZ() + "]";
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\cor\\util\Vector3.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */