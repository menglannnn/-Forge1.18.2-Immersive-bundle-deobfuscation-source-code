/*    */ package dev.kosmx.playerAnim.core.data.quarktool;
/*    */ 
/*    */ import dev.kosmx.playerAnim.core.util.Ease;
/*    */ 
/*    */ public class Move
/*    */   implements Playable {
/*    */   private final Ease ease;
/*    */   private final float value;
/*    */   private float valueBefore;
/*    */   private float valueAfter;
/*    */   private boolean isInitialized = false;
/*    */   private PartMap.PartValue part;
/*    */   private final int length;
/*    */   
/*    */   public Move(PartMap.PartValue part, float value, int length, Ease ease) {
/* 16 */     this.ease = ease;
/* 17 */     this.length = length;
/* 18 */     this.value = value;
/* 19 */     this.part = part;
/*    */   }
/*    */ 
/*    */   
/*    */   public int playForward(int time) throws QuarkParsingError {
/* 24 */     if (!this.isInitialized) {
/* 25 */       this.isInitialized = true;
/* 26 */       this.valueBefore = this.part.getValue();
/* 27 */       this.valueAfter = this.value;
/* 28 */       this.part.addValue(time, time + this.length, this.valueAfter, this.ease);
/*    */     } else {
/* 30 */       this.part.hold();
/* 31 */       this.part.addValue(time, this.valueBefore, this.ease);
/* 32 */       this.part.addValue(time + this.length, this.valueAfter, Ease.CONSTANT);
/*    */     } 
/*    */     
/* 35 */     return time + this.length;
/*    */   }
/*    */ 
/*    */   
/*    */   public int playBackward(int time) throws QuarkParsingError {
/* 40 */     if (!this.isInitialized) throw new QuarkParsingError(); 
/* 41 */     this.part.hold();
/* 42 */     this.part.addValue(time, this.valueAfter, InverseEase.inverse(this.ease));
/* 43 */     this.part.addValue(time + this.length, this.valueBefore, Ease.CONSTANT);
/*    */     
/* 45 */     return time + this.length;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\core\data\quarktool\Move.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */