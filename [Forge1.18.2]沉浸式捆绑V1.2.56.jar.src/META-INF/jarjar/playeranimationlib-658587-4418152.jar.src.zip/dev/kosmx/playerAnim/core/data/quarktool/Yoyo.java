/*    */ package dev.kosmx.playerAnim.core.data.quarktool;
/*    */ 
/*    */ public class Yoyo extends Repeat {
/*    */   public Yoyo(Playable parent, int delay, int count) throws QuarkParsingError {
/*  5 */     super(parent, delay, count);
/*    */   }
/*    */ 
/*    */   
/*    */   public int playForward(int time) throws QuarkParsingError {
/* 10 */     int i = 0;
/* 11 */     int t = time;
/*    */     while (true) {
/* 13 */       if (i++ > this.count) return t; 
/* 14 */       if (i != 1) t += this.delay; 
/* 15 */       t = this.playable.playForward(t);
/* 16 */       if (i++ > this.count) return t; 
/* 17 */       t += this.delay;
/* 18 */       t = this.playable.playBackward(t);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\core\data\quarktool\Yoyo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */