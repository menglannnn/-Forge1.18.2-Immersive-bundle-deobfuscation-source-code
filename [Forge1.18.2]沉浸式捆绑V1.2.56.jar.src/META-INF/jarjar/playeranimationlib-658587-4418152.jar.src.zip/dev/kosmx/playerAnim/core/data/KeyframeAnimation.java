/*     */ package dev.kosmx.playerAnim.core.data;
/*     */ 
/*     */ import dev.kosmx.playerAnim.core.data.opennbs.NBS;
/*     */ import dev.kosmx.playerAnim.core.util.Ease;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.UUID;
/*     */ import java.util.function.Supplier;
/*     */ import javax.annotation.concurrent.Immutable;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Immutable
/*     */ public final class KeyframeAnimation
/*     */   implements Supplier<UUID>
/*     */ {
/*  35 */   public static final StateCollection.State EMPTY_STATE = new StateCollection.State("empty", 0.0F, 0.0F, false); public final int beginTick; public final int endTick; public final int stopTick; public final boolean isInfinite;
/*     */   public final int returnToTick;
/*     */   private final Map<String, StateCollection> bodyParts;
/*     */   public final boolean isEasingBefore;
/*     */   public final boolean nsfw;
/*     */   private final UUID uuid;
/*     */   public final boolean isUUIDGenerated;
/*     */   
/*     */   public Map<String, StateCollection> getBodyParts() {
/*  44 */     return this.bodyParts;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  60 */   public final HashMap<String, Object> extraData = new HashMap<>();
/*     */ 
/*     */ 
/*     */   
/*     */   public final AnimationFormat animationFormat;
/*     */ 
/*     */ 
/*     */   
/*     */   private KeyframeAnimation(int beginTick, int endTick, int stopTick, boolean isInfinite, int returnToTick, HashMap<String, StateCollection> bodyParts, boolean isEasingBefore, boolean nsfw, UUID uuid, AnimationFormat emoteFormat, HashMap<String, Object> extraData) {
/*  69 */     this.beginTick = Math.max(beginTick, 0);
/*  70 */     this.endTick = Math.max(beginTick + 1, endTick);
/*  71 */     this.stopTick = (stopTick <= endTick) ? (endTick + 3) : stopTick;
/*  72 */     this.isInfinite = isInfinite;
/*  73 */     if (isInfinite && (returnToTick < 0 || returnToTick > endTick)) throw new IllegalArgumentException("Trying to construct invalid animation"); 
/*  74 */     this.returnToTick = returnToTick;
/*  75 */     HashMap<String, StateCollection> bodyMap = new HashMap<>();
/*  76 */     for (Map.Entry<String, StateCollection> entry : bodyParts.entrySet()) {
/*  77 */       bodyMap.put(entry.getKey(), ((StateCollection)entry.getValue()).copy());
/*     */     }
/*  79 */     bodyMap.forEach((s, stateCollection) -> stateCollection.verifyAndLock(getLength()));
/*  80 */     this.bodyParts = Collections.unmodifiableMap(bodyMap);
/*     */     
/*  82 */     this.isEasingBefore = isEasingBefore;
/*  83 */     this.nsfw = nsfw;
/*  84 */     if (uuid == null) {
/*  85 */       this.isUUIDGenerated = true;
/*  86 */       uuid = generateUuid();
/*     */     } else {
/*  88 */       this.isUUIDGenerated = false;
/*     */     } 
/*  90 */     this.uuid = uuid;
/*  91 */     this.animationFormat = emoteFormat;
/*  92 */     assert emoteFormat != null;
/*  93 */     this.extraData.putAll(extraData);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 104 */     if (this == o) return true; 
/* 105 */     if (!(o instanceof KeyframeAnimation)) return false;
/*     */     
/* 107 */     KeyframeAnimation emoteData = (KeyframeAnimation)o;
/*     */     
/* 109 */     if (this.beginTick != emoteData.beginTick) return false; 
/* 110 */     if (this.endTick != emoteData.endTick) return false; 
/* 111 */     if (this.stopTick != emoteData.stopTick) return false; 
/* 112 */     if (this.isInfinite != emoteData.isInfinite) return false; 
/* 113 */     if (this.returnToTick != emoteData.returnToTick) return false; 
/* 114 */     if (this.isEasingBefore != emoteData.isEasingBefore) return false;
/*     */ 
/*     */     
/* 117 */     return this.bodyParts.equals(emoteData.bodyParts);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 122 */     int result = this.beginTick;
/* 123 */     result = 31 * result + this.endTick;
/* 124 */     result = 31 * result + this.stopTick;
/* 125 */     result = 31 * result + (this.isInfinite ? 1 : 0);
/* 126 */     result = 31 * result + this.returnToTick;
/* 127 */     result = 31 * result + (this.isEasingBefore ? 1 : 0);
/* 128 */     result = 31 * result + this.bodyParts.hashCode();
/* 129 */     return result;
/*     */   }
/*     */   
/*     */   private UUID generateUuid() {
/* 133 */     int result = this.beginTick;
/* 134 */     result = 31 * result + this.endTick;
/* 135 */     result = 31 * result + this.stopTick;
/* 136 */     result = 31 * result + (this.isInfinite ? 1 : 0);
/* 137 */     result = 31 * result + this.returnToTick;
/* 138 */     result = 31 * result + (this.isEasingBefore ? 1 : 0);
/*     */     
/* 140 */     long dataHash = result * 31L + this.bodyParts.hashCode();
/*     */     
/* 142 */     long nameHash = this.extraData.hashCode();
/* 143 */     long descHash = 0L;
/* 144 */     long authHash = result * 31L + this.extraData.hashCode();
/*     */ 
/*     */ 
/*     */     
/* 148 */     return new UUID(dataHash << (int)(32L + nameHash), descHash << (int)(32L + authHash));
/*     */   }
/*     */ 
/*     */   
/*     */   public KeyframeAnimation copy() {
/* 153 */     return mutableCopy().build();
/*     */   }
/*     */   
/*     */   public AnimationBuilder mutableCopy() {
/* 157 */     HashMap<String, StateCollection> newParts = new HashMap<>();
/* 158 */     for (Map.Entry<String, StateCollection> part : this.bodyParts.entrySet()) {
/* 159 */       newParts.put(part.getKey(), ((StateCollection)part.getValue()).copy());
/*     */     }
/* 161 */     return new AnimationBuilder(this.beginTick, this.endTick, this.stopTick, this.isInfinite, this.returnToTick, newParts, this.isEasingBefore, this.nsfw, this.uuid, this.animationFormat, this.extraData);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPlayingAt(int tick) {
/* 166 */     return (this.isInfinite || (tick < this.stopTick && tick > 0));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UUID getUuid() {
/* 175 */     return this.uuid;
/*     */   }
/*     */ 
/*     */   
/*     */   public UUID get() {
/* 180 */     return this.uuid;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLength() {
/* 189 */     return this.stopTick;
/*     */   }
/*     */   
/*     */   public boolean isInfinite() {
/* 193 */     return this.isInfinite;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public StateCollection getPart(String partID) {
/* 199 */     return this.bodyParts.get(partID);
/*     */   }
/*     */   
/*     */   public Optional<StateCollection> getPartOptional(String id) {
/* 203 */     return Optional.ofNullable(getPart(id));
/*     */   }
/*     */   
/*     */   public static final class StateCollection { public final State x;
/*     */     public final State y;
/*     */     public final State z;
/*     */     public final State pitch;
/*     */     public final State yaw;
/*     */     public final State roll;
/*     */     @Nullable
/*     */     public final State bend;
/*     */     @Nullable
/*     */     public final State bendDirection;
/*     */     public final boolean isBendable;
/*     */     
/*     */     public boolean isBendable() {
/* 219 */       return this.isBendable;
/*     */     }
/*     */     
/*     */     public StateCollection(float x, float y, float z, float pitch, float yaw, float roll, float translationThreshold, boolean bendable) {
/* 223 */       this.x = new State("x", x, translationThreshold, false);
/* 224 */       this.y = new State("y", y, translationThreshold, false);
/* 225 */       this.z = new State("z", z, translationThreshold, false);
/* 226 */       this.pitch = new State("pitch", pitch, 0.0F, true);
/* 227 */       this.yaw = new State("yaw", yaw, 0.0F, true);
/* 228 */       this.roll = new State("roll", roll, 0.0F, true);
/* 229 */       if (bendable) {
/* 230 */         this.bendDirection = new State("axis", 0.0F, 0.0F, true);
/* 231 */         this.bend = new State("bend", 0.0F, 0.0F, true);
/*     */       } else {
/* 233 */         this.bend = null;
/* 234 */         this.bendDirection = null;
/*     */       } 
/* 236 */       this.isBendable = bendable;
/*     */     }
/*     */     
/*     */     public StateCollection(StateCollection stateCollection) {
/* 240 */       this.x = stateCollection.x.copy();
/* 241 */       this.y = stateCollection.y.copy();
/* 242 */       this.z = stateCollection.z.copy();
/* 243 */       this.pitch = stateCollection.pitch.copy();
/* 244 */       this.yaw = stateCollection.yaw.copy();
/* 245 */       this.roll = stateCollection.roll.copy();
/* 246 */       this.isBendable = stateCollection.isBendable;
/* 247 */       if (stateCollection.isBendable) {
/* 248 */         this.bendDirection = stateCollection.bendDirection.copy();
/* 249 */         this.bend = stateCollection.bend.copy();
/*     */       } else {
/* 251 */         this.bend = null;
/* 252 */         this.bendDirection = null;
/*     */       } 
/*     */     }
/*     */     
/*     */     public StateCollection(float threshold) {
/* 257 */       this(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, threshold, true);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/* 262 */       if (this == o) return true; 
/* 263 */       if (!(o instanceof StateCollection)) return false;
/*     */       
/* 265 */       StateCollection that = (StateCollection)o;
/*     */       
/* 267 */       if (this.isBendable != that.isBendable) return false; 
/* 268 */       if (!this.x.equals(that.x)) return false; 
/* 269 */       if (!this.y.equals(that.y)) return false; 
/* 270 */       if (!this.z.equals(that.z)) return false; 
/* 271 */       if (!this.pitch.equals(that.pitch)) return false; 
/* 272 */       if (!this.yaw.equals(that.yaw)) return false; 
/* 273 */       if (!this.roll.equals(that.roll)) return false; 
/* 274 */       if (!Objects.equals(this.bend, that.bend)) return false; 
/* 275 */       return Objects.equals(this.bendDirection, that.bendDirection);
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 280 */       int result = 0;
/* 281 */       result = 31 * result + this.x.hashCode();
/* 282 */       result = 31 * result + this.y.hashCode();
/* 283 */       result = 31 * result + this.z.hashCode();
/* 284 */       result = 31 * result + this.pitch.hashCode();
/* 285 */       result = 31 * result + this.yaw.hashCode();
/* 286 */       result = 31 * result + this.roll.hashCode();
/* 287 */       result = 31 * result + ((this.bend != null) ? this.bend.hashCode() : 0);
/* 288 */       result = 31 * result + ((this.bendDirection != null) ? this.bendDirection.hashCode() : 0);
/* 289 */       result = 31 * result + (this.isBendable ? 1 : 0);
/* 290 */       return result;
/*     */     }
/*     */ 
/*     */     
/*     */     public void fullyEnablePart(boolean always) {
/* 295 */       if (always || this.x.isEnabled || this.y.isEnabled || this.z.isEnabled || this.pitch.isEnabled || this.yaw.isEnabled || this.roll.isEnabled || (this.isBendable && (this.bend.isEnabled || this.bendDirection.isEnabled))) {
/* 296 */         setEnabled(true);
/*     */       }
/*     */     }
/*     */     
/*     */     public void setEnabled(boolean enabled) {
/* 301 */       this.x.setEnabled(enabled);
/* 302 */       this.y.setEnabled(enabled);
/* 303 */       this.z.setEnabled(enabled);
/* 304 */       this.pitch.setEnabled(enabled);
/* 305 */       this.yaw.setEnabled(enabled);
/* 306 */       this.roll.setEnabled(enabled);
/* 307 */       if (this.isBendable) {
/* 308 */         this.bend.setEnabled(enabled);
/* 309 */         this.bendDirection.setEnabled(enabled);
/*     */       } 
/*     */     }
/*     */     
/*     */     public boolean isEnabled() {
/* 314 */       return (this.x.isEnabled() || this.y
/* 315 */         .isEnabled() || this.z
/* 316 */         .isEnabled() || this.pitch
/* 317 */         .isEnabled() || this.yaw
/* 318 */         .isEnabled() || this.roll
/* 319 */         .isEnabled() || (this.bend != null && this.bend
/* 320 */         .isEnabled()) || (this.bendDirection != null && this.bend
/* 321 */         .isEnabled()));
/*     */     }
/*     */     
/*     */     public void verifyAndLock(int maxLength) {
/* 325 */       this.x.lockAndVerify(maxLength);
/* 326 */       this.y.lockAndVerify(maxLength);
/* 327 */       this.z.lockAndVerify(maxLength);
/* 328 */       this.pitch.lockAndVerify(maxLength);
/* 329 */       this.yaw.lockAndVerify(maxLength);
/* 330 */       this.roll.lockAndVerify(maxLength);
/* 331 */       if (this.bend != null) this.bend.lockAndVerify(maxLength); 
/* 332 */       if (this.bendDirection != null) this.bendDirection.lockAndVerify(maxLength);
/*     */     
/*     */     }
/*     */     
/*     */     private void optimize(boolean isLooped, int ret) {
/* 337 */       this.x.optimize(isLooped, ret);
/* 338 */       this.y.optimize(isLooped, ret);
/* 339 */       this.z.optimize(isLooped, ret);
/* 340 */       this.pitch.optimize(isLooped, ret);
/* 341 */       this.yaw.optimize(isLooped, ret);
/* 342 */       this.roll.optimize(isLooped, ret);
/* 343 */       if (this.isBendable) {
/* 344 */         this.bend.optimize(isLooped, ret);
/* 345 */         this.bendDirection.optimize(isLooped, ret);
/*     */       } 
/*     */     }
/*     */     
/*     */     public StateCollection copy() {
/* 350 */       return new StateCollection(this);
/*     */     }
/*     */     
/*     */     public static final class State {
/*     */       private boolean isModifiable = true;
/*     */       public final float defaultValue;
/*     */       public final float threshold;
/* 357 */       private List<KeyframeAnimation.KeyFrame> keyFrames = new ArrayList<>(); public final String name; private final boolean isAngle; public List<KeyframeAnimation.KeyFrame> getKeyFrames() { return this.keyFrames; }
/*     */       
/*     */       private boolean isEnabled = false;
/*     */       public boolean isEnabled() {
/* 361 */         return this.isEnabled;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public State(State state) {
/* 370 */         this.defaultValue = state.defaultValue;
/* 371 */         this.threshold = state.threshold;
/* 372 */         this.keyFrames.addAll(state.keyFrames);
/* 373 */         this.name = state.name;
/* 374 */         this.isAngle = state.isAngle;
/* 375 */         setEnabled(state.isEnabled);
/*     */       }
/*     */ 
/*     */       
/*     */       public boolean equals(Object o) {
/* 380 */         if (this == o) return true; 
/* 381 */         if (!(o instanceof State)) return false;
/*     */         
/* 383 */         State state = (State)o;
/*     */         
/* 385 */         if (Float.compare(state.defaultValue, this.defaultValue) != 0) return false; 
/* 386 */         if (this.isAngle != state.isAngle) return false; 
/* 387 */         if (!this.keyFrames.equals(state.keyFrames)) return false; 
/* 388 */         if (this.isEnabled != state.isEnabled) return false; 
/* 389 */         return Objects.equals(this.name, state.name);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       private void lock() {
/* 396 */         this.isModifiable = false;
/* 397 */         this.keyFrames = Collections.unmodifiableList(this.keyFrames);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public void lockAndVerify(int maxLength) {
/* 405 */         for (KeyframeAnimation.KeyFrame keyFrame : getKeyFrames()) {
/* 406 */           if (keyFrame == null || keyFrame.tick < 0 || keyFrame.ease == null || !Float.isFinite(keyFrame.value)) throw new IllegalArgumentException("Animation is invalid: " + keyFrame); 
/*     */         } 
/* 408 */         lock();
/*     */       }
/*     */       
/*     */       public void setEnabled(boolean newValue) {
/* 412 */         if (this.isModifiable) {
/* 413 */           this.isEnabled = newValue;
/*     */         } else {
/* 415 */           throw new AssertionError("Can not modify locked things");
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/*     */       public int hashCode() {
/* 421 */         int result = (this.defaultValue != 0.0F) ? Float.floatToIntBits(this.defaultValue) : 0;
/* 422 */         result = 31 * result + this.keyFrames.hashCode();
/* 423 */         result = 31 * result + (this.isAngle ? 1 : 0);
/* 424 */         result = 31 * result + (this.isEnabled ? 1 : 0);
/* 425 */         return result;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       private State(String name, float defaultValue, float threshold, boolean isAngle) {
/* 435 */         this.defaultValue = defaultValue;
/* 436 */         this.threshold = threshold;
/* 437 */         this.name = name;
/* 438 */         this.isAngle = isAngle;
/*     */       }
/*     */       
/*     */       public int length() {
/* 442 */         return this.keyFrames.size();
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public int findAtTick(int tick) {
/* 452 */         int i = -1;
/* 453 */         while (this.keyFrames.size() > i + 1 && ((KeyframeAnimation.KeyFrame)this.keyFrames.get(i + 1)).tick <= tick) {
/* 454 */           i++;
/*     */         }
/* 456 */         return i;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public boolean addKeyFrame(int tick, float value, Ease ease, int rotate, boolean degrees) {
/* 470 */         if (degrees && this.isAngle) value *= 0.017453292F; 
/* 471 */         boolean bl = addKeyFrame(new KeyframeAnimation.KeyFrame(tick, value, ease));
/* 472 */         if (this.isAngle && rotate != 0) {
/* 473 */           bl = (addKeyFrame(new KeyframeAnimation.KeyFrame(tick, (float)(value + 6.283185307179586D * rotate), ease)) && bl);
/*     */         }
/* 475 */         return bl;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public boolean addKeyFrame(int tick, float value, Ease ease) {
/* 487 */         if (Float.isNaN(value)) throw new IllegalArgumentException("value can't be NaN"); 
/* 488 */         return addKeyFrame(new KeyframeAnimation.KeyFrame(tick, value, ease));
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       private boolean addKeyFrame(KeyframeAnimation.KeyFrame keyFrame) {
/* 498 */         setEnabled(true);
/* 499 */         int i = findAtTick(keyFrame.tick) + 1;
/* 500 */         this.keyFrames.add(i, keyFrame);
/* 501 */         return (this.isAngle || Math.abs(this.defaultValue - keyFrame.value) <= this.threshold);
/*     */       }
/*     */       
/*     */       public void replace(KeyframeAnimation.KeyFrame keyFrame, int pos) {
/* 505 */         this.keyFrames.remove(pos);
/* 506 */         this.keyFrames.add(pos, keyFrame);
/*     */       }
/*     */       
/*     */       public void replaceEase(int pos, Ease ease) {
/* 510 */         KeyframeAnimation.KeyFrame original = this.keyFrames.get(pos);
/* 511 */         replace(new KeyframeAnimation.KeyFrame(original.tick, original.value, ease), pos);
/*     */       }
/*     */       
/*     */       private void optimize(boolean isLooped, int returnToTick) {
/* 515 */         for (int i = 1; i < this.keyFrames.size() - 1; i++) {
/* 516 */           if (((KeyframeAnimation.KeyFrame)this.keyFrames.get(i - 1)).value == ((KeyframeAnimation.KeyFrame)this.keyFrames.get(i)).value)
/*     */           {
/*     */             
/* 519 */             if (this.keyFrames.size() > i + 1 && ((KeyframeAnimation.KeyFrame)this.keyFrames.get(i)).value == ((KeyframeAnimation.KeyFrame)this.keyFrames.get(i + 1)).value)
/*     */             {
/*     */               
/* 522 */               if (!isLooped || ((KeyframeAnimation.KeyFrame)this.keyFrames.get(i - 1)).tick >= returnToTick || ((KeyframeAnimation.KeyFrame)this.keyFrames.get(i)).tick < returnToTick)
/*     */               {
/*     */                 
/* 525 */                 this.keyFrames.remove(i--); }  }  } 
/*     */         } 
/*     */       }
/*     */       
/*     */       public State copy() {
/* 530 */         return new State(this); } } } public static final class State { private boolean isModifiable = true; public final float defaultValue; public final float threshold; private List<KeyframeAnimation.KeyFrame> keyFrames = new ArrayList<>(); public final String name; private final boolean isAngle; public List<KeyframeAnimation.KeyFrame> getKeyFrames() { return this.keyFrames; } private boolean isEnabled = false; public boolean isEnabled() { return this.isEnabled; } public State(State state) { this.defaultValue = state.defaultValue; this.threshold = state.threshold; this.keyFrames.addAll(state.keyFrames); this.name = state.name; this.isAngle = state.isAngle; setEnabled(state.isEnabled); } public boolean equals(Object o) { if (this == o) return true;  if (!(o instanceof State)) return false;  State state = (State)o; if (Float.compare(state.defaultValue, this.defaultValue) != 0) return false;  if (this.isAngle != state.isAngle) return false;  if (!this.keyFrames.equals(state.keyFrames)) return false;  if (this.isEnabled != state.isEnabled) return false;  return Objects.equals(this.name, state.name); } private void lock() { this.isModifiable = false; this.keyFrames = Collections.unmodifiableList(this.keyFrames); } public State copy() { return new State(this); }
/*     */     public void lockAndVerify(int maxLength) { for (KeyframeAnimation.KeyFrame keyFrame : getKeyFrames()) { if (keyFrame == null || keyFrame.tick < 0 || keyFrame.ease == null || !Float.isFinite(keyFrame.value)) throw new IllegalArgumentException("Animation is invalid: " + keyFrame);  }  lock(); }
/*     */     public void setEnabled(boolean newValue) { if (this.isModifiable) { this.isEnabled = newValue; } else { throw new AssertionError("Can not modify locked things"); }  }
/*     */     public int hashCode() { int result = (this.defaultValue != 0.0F) ? Float.floatToIntBits(this.defaultValue) : 0; result = 31 * result + this.keyFrames.hashCode(); result = 31 * result + (this.isAngle ? 1 : 0); result = 31 * result + (this.isEnabled ? 1 : 0); return result; }
/*     */     private State(String name, float defaultValue, float threshold, boolean isAngle) { this.defaultValue = defaultValue; this.threshold = threshold; this.name = name; this.isAngle = isAngle; }
/*     */     public int length() { return this.keyFrames.size(); }
/*     */     public int findAtTick(int tick) { int i = -1; while (this.keyFrames.size() > i + 1 && ((KeyframeAnimation.KeyFrame)this.keyFrames.get(i + 1)).tick <= tick) i++;  return i; }
/*     */     public boolean addKeyFrame(int tick, float value, Ease ease, int rotate, boolean degrees) { if (degrees && this.isAngle) value *= 0.017453292F;  boolean bl = addKeyFrame(new KeyframeAnimation.KeyFrame(tick, value, ease)); if (this.isAngle && rotate != 0) bl = (addKeyFrame(new KeyframeAnimation.KeyFrame(tick, (float)(value + 6.283185307179586D * rotate), ease)) && bl);  return bl; }
/*     */     public boolean addKeyFrame(int tick, float value, Ease ease) { if (Float.isNaN(value)) throw new IllegalArgumentException("value can't be NaN");  return addKeyFrame(new KeyframeAnimation.KeyFrame(tick, value, ease)); }
/*     */     private boolean addKeyFrame(KeyframeAnimation.KeyFrame keyFrame) { setEnabled(true); int i = findAtTick(keyFrame.tick) + 1; this.keyFrames.add(i, keyFrame); return (this.isAngle || Math.abs(this.defaultValue - keyFrame.value) <= this.threshold); } public void replace(KeyframeAnimation.KeyFrame keyFrame, int pos) { this.keyFrames.remove(pos); this.keyFrames.add(pos, keyFrame); } public void replaceEase(int pos, Ease ease) { KeyframeAnimation.KeyFrame original = this.keyFrames.get(pos); replace(new KeyframeAnimation.KeyFrame(original.tick, original.value, ease), pos); } private void optimize(boolean isLooped, int returnToTick) { for (int i = 1; i < this.keyFrames.size() - 1; i++) { if (((KeyframeAnimation.KeyFrame)this.keyFrames.get(i - 1)).value == ((KeyframeAnimation.KeyFrame)this.keyFrames.get(i)).value) if (this.keyFrames.size() > i + 1 && ((KeyframeAnimation.KeyFrame)this.keyFrames.get(i)).value == ((KeyframeAnimation.KeyFrame)this.keyFrames.get(i + 1)).value) if (!isLooped || ((KeyframeAnimation.KeyFrame)this.keyFrames.get(i - 1)).tick >= returnToTick || ((KeyframeAnimation.KeyFrame)this.keyFrames.get(i)).tick < returnToTick)
/*     */               this.keyFrames.remove(i--);    }  } }
/*     */    @Immutable public static final class KeyFrame
/*     */   {
/* 543 */     public final int tick; public KeyFrame(int tick, float value, Ease ease) { this.tick = tick;
/* 544 */       this.value = value;
/* 545 */       this.ease = ease; }
/*     */     
/*     */     public final float value; public final Ease ease;
/*     */     
/*     */     public boolean equals(Object other) {
/* 550 */       if (other instanceof KeyFrame)
/* 551 */         return (((KeyFrame)other).ease == this.ease && ((KeyFrame)other).tick == this.tick && ((KeyFrame)other).value == this.value); 
/* 552 */       return super.equals(other);
/*     */     }
/*     */     
/*     */     public KeyFrame(int tick, float value) {
/* 556 */       this(tick, value, Ease.INOUTSINE);
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 561 */       int result = this.tick;
/* 562 */       result = 31 * result + Float.hashCode(this.value);
/* 563 */       result = 31 * result + this.ease.getId();
/* 564 */       return result;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 569 */       return "KeyFrame{tick=" + this.tick + ", value=" + this.value + ", ease=" + this.ease + '}';
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class AnimationBuilder
/*     */   {
/* 582 */     public static float staticThreshold = 8.0F;
/*     */     
/*     */     public final KeyframeAnimation.StateCollection head;
/*     */     
/*     */     public final KeyframeAnimation.StateCollection body;
/*     */     
/*     */     public final KeyframeAnimation.StateCollection rightArm;
/*     */     public final KeyframeAnimation.StateCollection leftArm;
/*     */     public final KeyframeAnimation.StateCollection rightLeg;
/*     */     public final KeyframeAnimation.StateCollection leftLeg;
/*     */     public final KeyframeAnimation.StateCollection leftItem;
/*     */     public final KeyframeAnimation.StateCollection rightItem;
/*     */     public final KeyframeAnimation.StateCollection torso;
/*     */     public boolean isEasingBefore = false;
/*     */     public boolean nsfw = false;
/* 597 */     private final HashMap<String, KeyframeAnimation.StateCollection> bodyParts = new HashMap<>();
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/* 602 */     public UUID uuid = null;
/*     */ 
/*     */     
/* 605 */     public int beginTick = 0;
/*     */     public int endTick;
/* 607 */     public int stopTick = 0;
/*     */     
/*     */     public boolean isLooped = false;
/*     */     
/*     */     public int returnTick;
/*     */     final AnimationFormat emoteEmoteFormat;
/*     */     private final float validationThreshold;
/* 614 */     public String name = null;
/*     */ 
/*     */     
/*     */     @Nullable
/* 618 */     public String description = null;
/*     */     @Nullable
/* 620 */     public String author = null;
/*     */     
/*     */     @Nullable
/* 623 */     public NBS song = null;
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public ByteBuffer iconData;
/*     */     
/* 629 */     public HashMap<String, Object> extraData = new HashMap<>();
/*     */     
/*     */     public AnimationBuilder(AnimationFormat source) {
/* 632 */       this(staticThreshold, source);
/*     */     }
/*     */     
/*     */     public AnimationBuilder(float validationThreshold, AnimationFormat emoteFormat) {
/* 636 */       this.validationThreshold = validationThreshold;
/* 637 */       this.head = new KeyframeAnimation.StateCollection(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, validationThreshold, false);
/* 638 */       this.body = new KeyframeAnimation.StateCollection(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, validationThreshold / 8.0F, true);
/* 639 */       this.rightArm = new KeyframeAnimation.StateCollection(-5.0F, 2.0F, 0.0F, 0.0F, 0.0F, 0.0F, validationThreshold, true);
/* 640 */       this.leftArm = new KeyframeAnimation.StateCollection(5.0F, 2.0F, 0.0F, 0.0F, 0.0F, 0.0F, validationThreshold, true);
/* 641 */       this.leftLeg = new KeyframeAnimation.StateCollection(1.9F, 12.0F, 0.1F, 0.0F, 0.0F, 0.0F, validationThreshold, true);
/* 642 */       this.rightLeg = new KeyframeAnimation.StateCollection(-1.9F, 12.0F, 0.1F, 0.0F, 0.0F, 0.0F, validationThreshold, true);
/* 643 */       this.leftItem = new KeyframeAnimation.StateCollection(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, validationThreshold, false);
/* 644 */       this.rightItem = new KeyframeAnimation.StateCollection(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, validationThreshold, false);
/* 645 */       this.torso = new KeyframeAnimation.StateCollection(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, validationThreshold, true);
/*     */       
/* 647 */       this.bodyParts.put("head", this.head);
/* 648 */       this.bodyParts.put("body", this.body);
/* 649 */       this.bodyParts.put("rightArm", this.rightArm);
/* 650 */       this.bodyParts.put("rightLeg", this.rightLeg);
/* 651 */       this.bodyParts.put("leftArm", this.leftArm);
/* 652 */       this.bodyParts.put("leftLeg", this.leftLeg);
/* 653 */       this.bodyParts.put("leftItem", this.leftItem);
/* 654 */       this.bodyParts.put("rightItem", this.rightItem);
/* 655 */       this.bodyParts.put("torso", this.torso);
/* 656 */       this.emoteEmoteFormat = emoteFormat;
/*     */     }
/*     */ 
/*     */     
/*     */     private AnimationBuilder(int beginTick, int endTick, int stopTick, boolean isInfinite, int returnToTick, HashMap<String, KeyframeAnimation.StateCollection> bodyParts, boolean isEasingBefore, boolean nsfw, @Nullable UUID uuid, AnimationFormat emoteFormat, HashMap<String, Object> extraData) {
/* 661 */       this.validationThreshold = staticThreshold;
/* 662 */       this.bodyParts.putAll(bodyParts);
/*     */       
/* 664 */       this.head = bodyParts.get("head");
/* 665 */       this.body = bodyParts.get("body");
/* 666 */       this.rightArm = bodyParts.get("rightArm");
/* 667 */       this.rightLeg = bodyParts.get("rightLeg");
/* 668 */       this.leftArm = bodyParts.get("leftArm");
/* 669 */       this.leftLeg = bodyParts.get("leftLeg");
/* 670 */       this.leftItem = bodyParts.get("leftItem");
/* 671 */       this.rightItem = bodyParts.get("rightItem");
/* 672 */       this.torso = bodyParts.get("torso");
/*     */       
/* 674 */       this.beginTick = beginTick;
/* 675 */       this.endTick = endTick;
/* 676 */       this.stopTick = stopTick;
/* 677 */       this.isLooped = isInfinite;
/* 678 */       this.returnTick = returnToTick;
/* 679 */       this.isEasingBefore = isEasingBefore;
/* 680 */       this.nsfw = nsfw;
/* 681 */       this.uuid = uuid;
/* 682 */       this.extraData.putAll(extraData);
/* 683 */       this.name = (extraData.containsKey("name") && extraData.get("name") instanceof String) ? (String)extraData.get("name") : null;
/* 684 */       this.description = (extraData.containsKey("description") && extraData.get("description") instanceof String) ? (String)extraData.get("description") : null;
/* 685 */       this.author = (extraData.containsKey("author") && extraData.get("author") instanceof String) ? (String)extraData.get("author") : null;
/* 686 */       this.emoteEmoteFormat = emoteFormat;
/* 687 */       this.iconData = (extraData.containsKey("iconData") && extraData.get("iconData") instanceof ByteBuffer) ? (ByteBuffer)extraData.get("iconData") : null;
/* 688 */       this.song = (extraData.containsKey("song") && extraData.get("song") instanceof NBS) ? (NBS)extraData.get("song") : null;
/*     */     }
/*     */ 
/*     */     
/*     */     public AnimationBuilder setDescription(String s) {
/* 693 */       this.description = s;
/* 694 */       return this;
/*     */     }
/*     */     
/*     */     public AnimationBuilder setName(String s) {
/* 698 */       this.name = s;
/* 699 */       return this;
/*     */     }
/*     */     
/*     */     public AnimationBuilder setAuthor(String s) {
/* 703 */       this.author = s;
/* 704 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public KeyframeAnimation.StateCollection getOrCreateNewPart(String name, float x, float y, float z, float pitch, float yaw, float roll, boolean bendable) {
/* 721 */       if (!this.bodyParts.containsKey(name)) {
/* 722 */         this.bodyParts.put(name, new KeyframeAnimation.StateCollection(x, y, z, pitch, yaw, roll, this.validationThreshold, bendable));
/*     */       }
/* 724 */       return this.bodyParts.get(name);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public KeyframeAnimation.StateCollection getPart(String name) {
/* 735 */       return this.bodyParts.get(name);
/*     */     }
/*     */     
/*     */     public KeyframeAnimation.StateCollection getOrCreatePart(String name) {
/* 739 */       if (!this.bodyParts.containsKey(name)) {
/* 740 */         this.bodyParts.put(name, new KeyframeAnimation.StateCollection(this.validationThreshold));
/*     */       }
/* 742 */       return this.bodyParts.get(name);
/*     */     }
/*     */     
/*     */     public AnimationBuilder fullyEnableParts() {
/* 746 */       for (Map.Entry<String, KeyframeAnimation.StateCollection> part : this.bodyParts.entrySet()) {
/* 747 */         ((KeyframeAnimation.StateCollection)part.getValue()).fullyEnablePart(false);
/*     */       }
/* 749 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AnimationBuilder optimizeEmote() {
/* 757 */       for (Map.Entry<String, KeyframeAnimation.StateCollection> part : this.bodyParts.entrySet()) {
/* 758 */         ((KeyframeAnimation.StateCollection)part.getValue()).optimize(this.isLooped, this.returnTick);
/*     */       }
/* 760 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public KeyframeAnimation build() throws IllegalArgumentException {
/* 769 */       if (this.name != null) this.extraData.put("name", this.name); 
/* 770 */       if (this.description != null) this.extraData.put("description", this.description); 
/* 771 */       if (this.author != null) this.extraData.put("author", this.author); 
/* 772 */       if (this.iconData != null) this.extraData.put("iconData", this.iconData); 
/* 773 */       if (this.song != null) this.extraData.put("song", this.song);
/*     */       
/* 775 */       return new KeyframeAnimation(this.beginTick, this.endTick, this.stopTick, this.isLooped, this.returnTick, this.bodyParts, this.isEasingBefore, this.nsfw, this.uuid, this.emoteEmoteFormat, this.extraData);
/*     */     }
/*     */     
/*     */     public AnimationBuilder setUuid(UUID uuid) {
/* 779 */       this.uuid = uuid;
/* 780 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 785 */       return "AnimationBuilder{uuid=" + this.uuid + ", extra=" + this.extraData + '}';
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 795 */     return "KeyframeAnimation{uuid=" + this.uuid + ", length=" + 
/*     */       
/* 797 */       getLength() + ", extra=" + this.extraData + '}';
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\core\data\KeyframeAnimation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */