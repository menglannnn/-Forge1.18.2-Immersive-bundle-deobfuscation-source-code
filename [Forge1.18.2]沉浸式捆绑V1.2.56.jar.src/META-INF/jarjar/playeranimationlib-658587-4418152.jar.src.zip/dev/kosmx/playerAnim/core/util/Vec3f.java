/*    */ package dev.kosmx.playerAnim.core.util;
/*    */ 
/*    */ import javax.annotation.concurrent.Immutable;
/*    */ 
/*    */ @Immutable
/*    */ public class Vec3f
/*    */   extends Vector3<Float> {
/*  8 */   public static final Vec3f ZERO = new Vec3f(0.0F, 0.0F, 0.0F);
/*    */   
/*    */   public Vec3f(float x, float y, float z) {
/* 11 */     super(Float.valueOf(x), Float.valueOf(y), Float.valueOf(z));
/*    */   }
/*    */   
/*    */   public double squaredDistanceTo(Vec3d vec3d) {
/* 15 */     double a = this.x.floatValue() - vec3d.x.doubleValue();
/* 16 */     double b = this.y.floatValue() - vec3d.y.doubleValue();
/* 17 */     double c = this.z.floatValue() - vec3d.z.doubleValue();
/* 18 */     return a * a + b * b + c * c;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Vec3f scale(float scalar) {
/* 27 */     return new Vec3f(getX().floatValue() * scalar, getY().floatValue() * scalar, getZ().floatValue() * scalar);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Vec3f add(Vec3f other) {
/* 36 */     return new Vec3f(getX().floatValue() + other.getX().floatValue(), getY().floatValue() + other.getY().floatValue(), getZ().floatValue() + other.getZ().floatValue());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public float dotProduct(Vec3f other) {
/* 45 */     return getX().floatValue() * other.getX().floatValue() + getY().floatValue() * other.getY().floatValue() + getZ().floatValue() * other.getZ().floatValue();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Vec3f crossProduct(Vec3f other) {
/* 54 */     return new Vec3f(
/* 55 */         getY().floatValue() * other.getZ().floatValue() - getZ().floatValue() * other.getY().floatValue(), 
/* 56 */         getZ().floatValue() * other.getX().floatValue() - getX().floatValue() * other.getZ().floatValue(), 
/* 57 */         getX().floatValue() * other.getY().floatValue() - getY().floatValue() * other.getX().floatValue());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Vec3f subtract(Vec3f rhs) {
/* 68 */     return add(rhs.scale(-1.0F));
/*    */   }
/*    */   
/*    */   public double distanceTo(Vec3d vec3d) {
/* 72 */     return Math.sqrt(squaredDistanceTo(vec3d));
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\cor\\util\Vec3f.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */