/*    */ package dev.kosmx.playerAnim.core.data.opennbs;
/*    */ 
/*    */ import dev.kosmx.playerAnim.core.data.opennbs.format.CustomInstrument;
/*    */ import dev.kosmx.playerAnim.core.data.opennbs.format.Header;
/*    */ import dev.kosmx.playerAnim.core.data.opennbs.format.Layer;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NBS
/*    */ {
/*    */   public final Header header;
/*    */   final ArrayList<Layer> layers;
/*    */   int length;
/*    */   byte customInstrumentCount;
/*    */   final ArrayList<CustomInstrument> customInstruments;
/*    */   
/*    */   public NBS(Header header, ArrayList<Layer> layers, ArrayList<CustomInstrument> customInstruments) {
/* 20 */     if (header.Layer_count != layers.size())
/* 21 */       if (layers.size() == 0) {
/* 22 */         for (int i = 0; i < header.Layer_count; i++) {
/* 23 */           layers.add(new Layer());
/*    */         }
/*    */       } else {
/* 26 */         throw new IllegalArgumentException("Layer count have to be same in the header with the layers size");
/*    */       }  
/* 28 */     this.header = header;
/* 29 */     this.layers = layers;
/* 30 */     this.customInstruments = customInstruments;
/*    */   }
/*    */   
/*    */   public ArrayList<Layer> getLayers() {
/* 34 */     return this.layers;
/*    */   }
/*    */   
/*    */   List<Layer.Note> getNotesUntilTick(int tickFrom, int tickTo) {
/* 38 */     ArrayList<Layer.Note> notes = new ArrayList<>();
/* 39 */     for (Layer layer : this.layers) {
/* 40 */       if (tickFrom > tickTo) {
/* 41 */         notes.addAll(layer.getNotesFrom(tickFrom, this.length));
/* 42 */         notes.addAll(layer.getNotesFrom(this.header.Loop_on_off() ? (this.header.Loop_start_tick - 1) : -1, tickTo));
/*    */         continue;
/*    */       } 
/* 45 */       notes.addAll(layer.getNotesFrom(tickFrom, tickTo));
/*    */     } 
/*    */     
/* 48 */     return notes;
/*    */   }
/*    */   
/*    */   public int getLength() {
/* 52 */     return this.length;
/*    */   }
/*    */   
/*    */   public void setLength(int length) {
/* 56 */     this.length = (length / this.header.Time_signature + 1) * this.header.Time_signature;
/*    */   }
/*    */   
/*    */   public static class Builder {
/* 60 */     public Header header = new Header();
/* 61 */     public ArrayList<Layer> layers = new ArrayList<>();
/*    */     public ArrayList<CustomInstrument> customInstruments;
/*    */     
/*    */     public NBS build() {
/* 65 */       return new NBS(this.header, this.layers, this.customInstruments);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\core\data\opennbs\NBS.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */