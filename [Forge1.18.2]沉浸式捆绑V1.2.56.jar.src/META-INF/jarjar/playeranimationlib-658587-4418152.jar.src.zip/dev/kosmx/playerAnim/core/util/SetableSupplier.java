/*    */ package dev.kosmx.playerAnim.core.util;
/*    */ 
/*    */ import java.util.function.Supplier;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SetableSupplier<T>
/*    */   implements Supplier<T>
/*    */ {
/*    */   T object;
/*    */   
/*    */   public void set(T object) {
/* 16 */     this.object = object;
/*    */   }
/*    */ 
/*    */   
/*    */   public T get() {
/* 21 */     return this.object;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\cor\\util\SetableSupplier.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */