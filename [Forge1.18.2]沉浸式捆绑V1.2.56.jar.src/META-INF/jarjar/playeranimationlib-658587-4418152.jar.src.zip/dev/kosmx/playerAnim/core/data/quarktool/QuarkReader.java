/*     */ package dev.kosmx.playerAnim.core.data.quarktool;
/*     */ 
/*     */ import dev.kosmx.playerAnim.core.data.AnimationFormat;
/*     */ import dev.kosmx.playerAnim.core.data.KeyframeAnimation;
/*     */ import java.io.BufferedReader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.stream.Stream;
/*     */ 
/*     */ public class QuarkReader
/*     */ {
/*  13 */   private final KeyframeAnimation.AnimationBuilder emote = new KeyframeAnimation.AnimationBuilder(AnimationFormat.QUARK);
/*     */   private boolean isSuccess = false;
/*     */   private String name;
/*  16 */   final PartMap head = new PartMap(this.emote.head);
/*  17 */   final PartMap torso = new PartMap(this.emote.body);
/*  18 */   final PartMap rightLeg = new PartMap(this.emote.rightLeg);
/*  19 */   final PartMap leftLeg = new PartMap(this.emote.leftLeg);
/*  20 */   final PartMap rightArm = new PartMap(this.emote.rightArm);
/*  21 */   final PartMap leftArm = new PartMap(this.emote.leftArm);
/*     */   private Playable animation;
/*     */   
/*     */   public void deserialize(BufferedReader reader, String name) throws QuarkParsingError {
/*  25 */     this.name = name;
/*  26 */     List<List<String>> strings = new ArrayList<>();
/*  27 */     Stream<String> stream = reader.lines();
/*  28 */     stream.forEach(s -> strings.add(read(s.replaceAll("\t", ""))));
/*     */ 
/*     */     
/*  31 */     int i = 0;
/*  32 */     while (i < strings.size()) {
/*  33 */       if (((List)strings.get(i)).size() == 0 || ((String)((List<String>)strings.get(i)).get(0)).charAt(0) == '#') {
/*  34 */         i++;
/*     */         continue;
/*     */       } 
/*  37 */       i = getMethod(strings.get(i), i, strings);
/*     */     } 
/*  39 */     if (this.animation == null) {
/*  40 */       throw new QuarkParsingError();
/*     */     }
/*  42 */     int length = this.animation.playForward(0);
/*  43 */     this.isSuccess = true;
/*  44 */     this.emote.endTick = length;
/*     */   }
/*     */   
/*     */   public KeyframeAnimation getEmote() {
/*  48 */     if (this.isSuccess)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  56 */       return this.emote
/*  57 */         .setName("{\"color\":\"white\",\"text\":\"" + this.name + "\"}")
/*  58 */         .setDescription("{\"color\":\"gray\",\"text\":\"Imported from quark\"}")
/*  59 */         .build(); } 
/*  60 */     return null;
/*     */   }
/*     */   
/*     */   public static List<String> read(String s) {
/*  64 */     int i = 0;
/*  65 */     while (i < s.length() && s.charAt(i) == ' ') {
/*  66 */       i++;
/*     */     }
/*  68 */     s = (new StringBuffer(s)).replace(0, i, "").toString();
/*  69 */     List<String> list = new ArrayList<>(Arrays.asList(s.split(" ")));
/*  70 */     list.removeIf(s1 -> s1.equals(""));
/*     */ 
/*     */     
/*  73 */     return list;
/*     */   }
/*     */   
/*     */   public int getMethod(List<String> str, int i, List<List<String>> strings) throws QuarkParsingError {
/*  77 */     if (((String)str.get(0)).equals("name")) {
/*  78 */       this.name = str.get(1);
/*  79 */     } else if (((String)str.get(0)).equals("animation")) {
/*  80 */       Section anim = new Section(this, i, strings);
/*  81 */       if (anim.getMoveOperator() == null)
/*  82 */       { this.animation = anim; }
/*  83 */       else { this.animation = anim.getMoveOperator(); }
/*  84 */        return anim.getLine();
/*     */     } 
/*  86 */     return i + 1;
/*     */   }
/*     */   
/*     */   public PartMap getBPFromStr(String[] inf) throws QuarkParsingError {
/*  90 */     if (inf.length == 2) {
/*  91 */       if (inf[0].equals("body")) return this.torso; 
/*  92 */       if (inf[0].equals("head")) return this.head; 
/*  93 */       throw new QuarkParsingError();
/*  94 */     }  if (inf.length == 3) {
/*  95 */       if (inf[0].equals("right")) {
/*  96 */         if (inf[1].equals("arm")) return this.rightArm; 
/*  97 */         if (inf[1].equals("leg")) return this.rightLeg; 
/*  98 */         throw new QuarkParsingError();
/*  99 */       }  if (inf[0].equals("left")) {
/* 100 */         if (inf[1].equals("arm")) return this.leftArm; 
/* 101 */         if (inf[1].equals("leg")) return this.leftLeg; 
/* 102 */         throw new QuarkParsingError();
/* 103 */       }  throw new QuarkParsingError();
/* 104 */     }  throw new QuarkParsingError();
/*     */   }
/*     */   
/*     */   public PartMap.PartValue getPFromStr(String str) throws QuarkParsingError {
/* 108 */     String[] inf = str.split("_");
/* 109 */     return getPFromStrHelper(inf[inf.length - 1], getBPFromStr(inf));
/*     */   }
/*     */   
/*     */   private PartMap.PartValue getPFromStrHelper(String string, PartMap part) throws QuarkParsingError {
/* 113 */     if (string.equals("x")) return part.x; 
/* 114 */     if (string.equals("y")) return part.y; 
/* 115 */     if (string.equals("z")) return part.z; 
/* 116 */     throw new QuarkParsingError();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\core\data\quarktool\QuarkReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */