/*     */ package dev.kosmx.playerAnim.core.util;
/*     */ 
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Easing
/*     */ {
/*     */   private static final float c1 = 1.70158F;
/*     */   private static final float c2 = 2.5949094F;
/*     */   private static final float c3 = 2.70158F;
/*     */   private static final float c4 = 2.0943952F;
/*     */   private static final float c5 = 1.3962634F;
/*     */   private static final float n1 = 7.5625F;
/*     */   private static final float d1 = 2.75F;
/*     */   
/*     */   @Deprecated
/*     */   public static float easingFromEnum(@Nullable Ease type, float f) {
/*  19 */     return (type != null) ? type.invoke(f) : f;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Ease easeFromString(String string) {
/*     */     try {
/*  28 */       if (string.equals("step")) return Ease.CONSTANT; 
/*  29 */       if (string.substring(0, 4).equalsIgnoreCase("EASE")) {
/*  30 */         string = string.substring(4);
/*     */       }
/*  32 */       return Ease.valueOf(string.toUpperCase());
/*  33 */     } catch (Exception exception) {
/*     */ 
/*     */       
/*  36 */       return Ease.LINEAR;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static float inSine(float f) {
/*  50 */     return (float)(1.0D - Math.cos(f * Math.PI / 2.0D));
/*     */   }
/*     */   
/*     */   public static float outSine(float f) {
/*  54 */     return (float)Math.sin(f * Math.PI / 2.0D);
/*     */   }
/*     */   
/*     */   public static float inOutSine(float f) {
/*  58 */     return (float)(-(Math.cos(Math.PI * f) - 1.0D) / 2.0D);
/*     */   }
/*     */   
/*     */   public static float inCubic(float f) {
/*  62 */     return f * f * f;
/*     */   }
/*     */   
/*     */   public static float outCubic(float f) {
/*  66 */     return (float)(1.0D - Math.pow((1.0F - f), 3.0D));
/*     */   }
/*     */   
/*     */   public static float inOutCubic(float x) {
/*  70 */     return (float)((x < 0.5D) ? (4.0F * x * x * x) : (1.0D - Math.pow((-2.0F * x + 2.0F), 3.0D) / 2.0D));
/*     */   }
/*     */   
/*     */   public static float inQuad(float x) {
/*  74 */     return x * x;
/*     */   }
/*     */   
/*     */   public static float outQuad(float x) {
/*  78 */     return 1.0F - (1.0F - x) * (1.0F - x);
/*     */   }
/*     */   
/*     */   public static float inOutQuad(float x) {
/*  82 */     return (float)((x < 0.5D) ? (2.0F * x * x) : (1.0D - Math.pow((-2.0F * x + 2.0F), 2.0D) / 2.0D));
/*     */   }
/*     */   
/*     */   public static float inQuart(float x) {
/*  86 */     return x * x * x * x;
/*     */   }
/*     */   
/*     */   public static float outQuart(float x) {
/*  90 */     return (float)(1.0D - Math.pow((1.0F - x), 4.0D));
/*     */   }
/*     */   
/*     */   public static float inOutQuart(float x) {
/*  94 */     return (float)((x < 0.5D) ? (8.0F * x * x * x * x) : (1.0D - Math.pow((-2.0F * x + 2.0F), 4.0D) / 2.0D));
/*     */   }
/*     */   
/*     */   public static float inQuint(float x) {
/*  98 */     return x * x * x * x * x;
/*     */   }
/*     */   
/*     */   public static float outQuint(float x) {
/* 102 */     return (float)(1.0D - Math.pow((1.0F - x), 5.0D));
/*     */   }
/*     */   
/*     */   public static float inOutQuint(float x) {
/* 106 */     return (float)((x < 0.5D) ? (16.0F * x * x * x * x * x) : (1.0D - Math.pow((-2.0F * x + 2.0F), 5.0D) / 2.0D));
/*     */   }
/*     */   
/*     */   public static float inExpo(float x) {
/* 110 */     return (float)((x == 0.0F) ? 0.0D : Math.pow(2.0D, (10.0F * x - 10.0F)));
/*     */   }
/*     */   
/*     */   public static float outExpo(float x) {
/* 114 */     return (float)((x == 1.0F) ? 1.0D : (1.0D - Math.pow(2.0D, (-10.0F * x))));
/*     */   }
/*     */   
/*     */   public static float inOutExpo(float x) {
/* 118 */     return (float)((x == 0.0F) ? 0.0D : ((x == 1.0F) ? 1.0D : ((x < 0.5D) ? (Math.pow(2.0D, (20.0F * x - 10.0F)) / 2.0D) : ((2.0D - Math.pow(2.0D, (-20.0F * x + 10.0F))) / 2.0D))));
/*     */   }
/*     */   
/*     */   public static float inCirc(float x) {
/* 122 */     return (float)(1.0D - Math.sqrt(1.0D - Math.pow(x, 2.0D)));
/*     */   }
/*     */   
/*     */   public static float outCirc(float x) {
/* 126 */     return (float)Math.sqrt(1.0D - Math.pow((x - 1.0F), 2.0D));
/*     */   }
/*     */   
/*     */   public static float inOutCirc(float x) {
/* 130 */     return (float)((x < 0.5D) ? ((1.0D - Math.sqrt(1.0D - Math.pow((2.0F * x), 2.0D))) / 2.0D) : ((Math.sqrt(1.0D - Math.pow((-2.0F * x + 2.0F), 2.0D)) + 1.0D) / 2.0D));
/*     */   }
/*     */   
/*     */   public static float inBack(float x) {
/* 134 */     return 2.70158F * x * x * x - 1.70158F * x * x;
/*     */   }
/*     */   
/*     */   public static float outBack(float x) {
/* 138 */     return (float)(1.0D + 2.701580047607422D * Math.pow((x - 1.0F), 3.0D) + 1.7015800476074219D * Math.pow((x - 1.0F), 2.0D));
/*     */   }
/*     */   
/*     */   public static float inOutBack(float x) {
/* 142 */     return (float)((x < 0.5D) ? (Math.pow((2.0F * x), 2.0D) * (7.189819F * x - 2.5949094F) / 2.0D) : ((Math.pow((2.0F * x - 2.0F), 2.0D) * (3.5949094F * (x * 2.0F - 2.0F) + 2.5949094F) + 2.0D) / 2.0D));
/*     */   }
/*     */   
/*     */   public static float inElastic(float x) {
/* 146 */     return (float)((x == 0.0F) ? 0.0D : ((x == 1.0F) ? 1.0D : (-Math.pow(2.0D, (10.0F * x - 10.0F)) * Math.sin(((x * 10.0F) - 10.75D) * 2.094395160675049D))));
/*     */   }
/*     */   
/*     */   public static float outElastic(float x) {
/* 150 */     return (float)((x == 0.0F) ? 0.0D : ((x == 1.0F) ? 1.0D : (Math.pow(2.0D, (-10.0F * x)) * Math.sin(((x * 10.0F) - 0.75D) * 2.094395160675049D) + 1.0D)));
/*     */   }
/*     */   
/*     */   public static float inOutElastic(float x) {
/* 154 */     return (float)((x == 0.0F) ? 0.0D : ((x == 1.0F) ? 1.0D : ((x < 0.5D) ? (-(Math.pow(2.0D, (20.0F * x - 10.0F)) * Math.sin(((20.0F * x) - 11.125D) * 1.3962633609771729D)) / 2.0D) : (Math.pow(2.0D, (-20.0F * x + 10.0F)) * Math.sin(((20.0F * x) - 11.125D) * 1.3962633609771729D) / 2.0D + 1.0D))));
/*     */   }
/*     */   
/*     */   public static float inBounce(float x) {
/* 158 */     return 1.0F - outBounce(1.0F - x);
/*     */   }
/*     */   
/*     */   public static float outBounce(float x) {
/* 162 */     if (x < 0.36363637F)
/* 163 */       return 7.5625F * x * x; 
/* 164 */     if (x < 0.72727275F)
/* 165 */       return (float)((7.5625F * (x = (float)(x - 0.5454545454545454D)) * x) + 0.75D); 
/* 166 */     if (x < 0.9090909090909091D) {
/* 167 */       return (float)((7.5625F * (x = (float)(x - 0.8181818181818182D)) * x) + 0.9375D);
/*     */     }
/* 169 */     return (float)((7.5625F * (x = (float)(x - 0.9545454545454546D)) * x) + 0.984375D);
/*     */   }
/*     */ 
/*     */   
/*     */   public static float inOutBounce(float x) {
/* 174 */     return (x < 0.5D) ? ((1.0F - outBounce(1.0F - 2.0F * x)) / 2.0F) : ((1.0F + outBounce(2.0F * x - 1.0F)) / 2.0F);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\cor\\util\Easing.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */