/*     */ package dev.kosmx.playerAnim.core.data.opennbs.format;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Layer
/*     */ {
/*     */   public String name;
/*     */   public byte lock;
/*     */   
/*     */   public boolean getLock() {
/*  16 */     return (this.lock != 0);
/*     */   }
/*     */   public void setLock(boolean newValue) {
/*  19 */     this.lock = (byte)(newValue ? 1 : 0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*  24 */   public byte volume = 100;
/*     */ 
/*     */ 
/*     */   
/*  28 */   public byte stereo = 100;
/*     */   
/*  30 */   private int lastUsedTickPos = 0;
/*     */   
/*  32 */   public final ArrayList<Note> notes = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int findAtTick(int tick) {
/*  41 */     int i = -1;
/*  42 */     if (this.notes.size() > this.lastUsedTickPos + 1 && ((Note)this.notes.get(this.lastUsedTickPos + 1)).tick <= tick) i = this.lastUsedTickPos; 
/*  43 */     while (this.notes.size() > i + 1 && ((Note)this.notes.get(i + 1)).tick <= tick) {
/*  44 */       i++;
/*     */     }
/*  46 */     this.lastUsedTickPos = i;
/*  47 */     return i;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public Note addNote(int tick) {
/*  52 */     if (getLock()) {
/*  53 */       return null;
/*     */     }
/*  55 */     int i = findAtTick(tick);
/*  56 */     if (i > 0 && ((Note)this.notes.get(i)).tick == tick) {
/*  57 */       return null;
/*     */     }
/*  59 */     Note note = new Note(tick);
/*  60 */     this.notes.add(i + 1, note);
/*  61 */     return note;
/*     */   }
/*     */   
/*     */   public ArrayList<Note> getNotesFrom(int fromTick, int toTick) {
/*  65 */     ArrayList<Note> returnNotes = new ArrayList<>();
/*  66 */     int posAtBegin = findAtTick(fromTick);
/*  67 */     if (this.notes.size() >= posAtBegin) {
/*  68 */       posAtBegin++;
/*     */     }
/*  70 */     int posAtEnd = findAtTick(toTick);
/*  71 */     if (this.notes.size() >= posAtEnd) {
/*  72 */       posAtEnd++;
/*     */     }
/*  74 */     if (posAtBegin < 0) {
/*  75 */       posAtBegin = 0;
/*     */     }
/*  77 */     for (; posAtBegin < posAtEnd; posAtBegin++) {
/*  78 */       returnNotes.add(this.notes.get(posAtBegin));
/*     */     }
/*  80 */     return returnNotes;
/*     */   }
/*     */   
/*     */   public ArrayList<Note> getNotesFrom(int toTick) {
/*  84 */     return getNotesFrom(this.lastUsedTickPos, toTick);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public class Note
/*     */   {
/*     */     public byte instrument;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public byte key;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 115 */     public byte velocity = 100;
/*     */ 
/*     */ 
/*     */     
/* 119 */     public byte panning = 100;
/*     */ 
/*     */ 
/*     */     
/* 123 */     public short pitch = 0;
/*     */ 
/*     */     
/*     */     public final int tick;
/*     */ 
/*     */ 
/*     */     
/*     */     public Note(int tick) {
/* 131 */       this.tick = tick;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public float getPitch() {
/* 138 */       return (float)Math.pow(2.0D, (this.key + this.pitch / 100 - 45) / 12.0D);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public float getVolume() {
/* 145 */       return this.velocity / 10000.0F * Layer.this.volume;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\core\data\opennbs\format\Layer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */