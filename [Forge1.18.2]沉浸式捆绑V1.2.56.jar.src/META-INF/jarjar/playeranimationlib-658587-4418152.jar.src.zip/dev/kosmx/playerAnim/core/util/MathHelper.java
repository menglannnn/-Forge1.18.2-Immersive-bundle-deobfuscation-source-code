/*    */ package dev.kosmx.playerAnim.core.util;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.nio.ByteBuffer;
/*    */ import java.util.LinkedList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MathHelper
/*    */ {
/*    */   public static float lerp(float delta, float start, float end) {
/* 14 */     return start + delta * (end - start);
/*    */   }
/*    */   
/*    */   public static double lerp(double delta, double start, double end) {
/* 18 */     return start + delta * (end - start);
/*    */   }
/*    */   
/*    */   public static int colorHelper(int r, int g, int b, int a) {
/* 22 */     return (a & 0xFF) << 24 | (r & 0xFF) << 16 | (g & 0xFF) << 8 | b & 0xFF;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static float clampToRadian(float f) {
/* 31 */     double a = 6.283185307179586D;
/* 32 */     double b = (f + Math.PI) % 6.283185307179586D;
/* 33 */     if (b < 0.0D) {
/* 34 */       b += 6.283185307179586D;
/*    */     }
/* 36 */     return (float)(b - Math.PI);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static ByteBuffer readFromIStream(InputStream stream) throws IOException {
/* 48 */     List<Pair<Integer, byte[]>> listOfBites = new LinkedList<>();
/* 49 */     int totalSize = 0;
/*    */     while (true) {
/* 51 */       int estimatedSize = stream.available();
/* 52 */       byte[] bytes = new byte[Math.max(1, estimatedSize)];
/* 53 */       int i = stream.read(bytes);
/* 54 */       if (i < 1)
/* 55 */         break;  totalSize += i;
/* 56 */       listOfBites.add((Pair)new Pair<>(Integer.valueOf(i), bytes));
/*    */     } 
/* 58 */     ByteBuffer byteBuffer = ByteBuffer.allocate(totalSize);
/* 59 */     for (Pair<Integer, byte[]> i : listOfBites) {
/* 60 */       byteBuffer.put(i.getRight(), 0, ((Integer)i.getLeft()).intValue());
/*    */     }
/* 62 */     byteBuffer.position(0);
/* 63 */     return byteBuffer;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\cor\\util\MathHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */