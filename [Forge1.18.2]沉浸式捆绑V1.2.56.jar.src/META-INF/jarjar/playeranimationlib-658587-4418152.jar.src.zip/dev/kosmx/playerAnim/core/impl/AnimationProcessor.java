/*    */ package dev.kosmx.playerAnim.core.impl;
/*    */ 
/*    */ import dev.kosmx.playerAnim.api.TransformType;
/*    */ import dev.kosmx.playerAnim.api.firstPerson.FirstPersonConfiguration;
/*    */ import dev.kosmx.playerAnim.api.firstPerson.FirstPersonMode;
/*    */ import dev.kosmx.playerAnim.api.layered.IAnimation;
/*    */ import dev.kosmx.playerAnim.core.util.Pair;
/*    */ import dev.kosmx.playerAnim.core.util.Vec3f;
/*    */ import org.jetbrains.annotations.ApiStatus.Internal;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Internal
/*    */ public class AnimationProcessor
/*    */ {
/*    */   private final IAnimation animation;
/* 20 */   private float tickDelta = 0.0F;
/*    */   
/*    */   public AnimationProcessor(IAnimation animation) {
/* 23 */     this.animation = animation;
/*    */   }
/*    */   
/*    */   public void tick() {
/* 27 */     this.animation.tick();
/*    */   }
/*    */   
/*    */   public boolean isActive() {
/* 31 */     return this.animation.isActive();
/*    */   }
/*    */   
/*    */   public Vec3f get3DTransform(String modelName, TransformType type, Vec3f value0) {
/* 35 */     return this.animation.get3DTransform(modelName, type, this.tickDelta, value0);
/*    */   }
/*    */   
/*    */   public void setTickDelta(float tickDelta) {
/* 39 */     this.tickDelta = tickDelta;
/* 40 */     this.animation.setupAnim(tickDelta);
/*    */   }
/*    */   
/*    */   public boolean isFirstPersonAnimationDisabled() {
/* 44 */     return !this.animation.getFirstPersonMode(this.tickDelta).isEnabled();
/*    */   }
/*    */   @NotNull
/*    */   public FirstPersonMode getFirstPersonMode() {
/* 48 */     return this.animation.getFirstPersonMode(this.tickDelta);
/*    */   }
/*    */   @NotNull
/*    */   public FirstPersonConfiguration getFirstPersonConfiguration() {
/* 52 */     return this.animation.getFirstPersonConfiguration(this.tickDelta);
/*    */   }
/*    */   
/*    */   public Pair<Float, Float> getBend(String modelName) {
/* 56 */     Vec3f bendVec = get3DTransform(modelName, TransformType.BEND, Vec3f.ZERO);
/* 57 */     return new Pair(bendVec.getX(), bendVec.getY());
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\core\impl\AnimationProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */