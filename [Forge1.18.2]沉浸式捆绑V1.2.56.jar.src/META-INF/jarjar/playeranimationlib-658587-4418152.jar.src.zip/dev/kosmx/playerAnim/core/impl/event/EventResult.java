/*    */ package dev.kosmx.playerAnim.core.impl.event;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum EventResult
/*    */ {
/* 11 */   PASS,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 16 */   SUCCESS,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 21 */   FAIL,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 26 */   CONSUME;
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\core\impl\event\EventResult.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */