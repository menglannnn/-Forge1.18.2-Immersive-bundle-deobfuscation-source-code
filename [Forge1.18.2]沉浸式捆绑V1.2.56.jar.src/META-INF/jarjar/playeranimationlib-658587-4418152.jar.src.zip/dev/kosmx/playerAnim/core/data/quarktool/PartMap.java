/*    */ package dev.kosmx.playerAnim.core.data.quarktool;
/*    */ 
/*    */ import dev.kosmx.playerAnim.core.data.KeyframeAnimation;
/*    */ import dev.kosmx.playerAnim.core.util.Ease;
/*    */ 
/*    */ public class PartMap
/*    */ {
/*    */   public KeyframeAnimation.StateCollection part;
/*    */   public PartValue x;
/*    */   public PartValue y;
/*    */   public PartValue z;
/*    */   
/*    */   public PartMap(KeyframeAnimation.StateCollection part) {
/* 14 */     this.part = part;
/* 15 */     this.x = new PartValue(this.part.pitch);
/* 16 */     this.y = new PartValue(this.part.yaw);
/* 17 */     this.z = new PartValue(this.part.roll);
/*    */   }
/*    */   
/*    */   static class PartValue
/*    */   {
/*    */     private float value;
/*    */     private int lastTick;
/*    */     private final KeyframeAnimation.StateCollection.State timeline;
/*    */     
/*    */     private PartValue(KeyframeAnimation.StateCollection.State timeline) {
/* 27 */       this.timeline = timeline;
/*    */     }
/*    */     
/*    */     public void addValue(int tick, float value, Ease ease) {
/* 31 */       this.lastTick = tick;
/* 32 */       this.timeline.addKeyFrame(tick, value, ease);
/*    */     }
/*    */     
/*    */     public void addValue(int tickFrom, int tickTo, float value, Ease ease) throws QuarkParsingError {
/* 36 */       if (tickFrom < this.lastTick)
/* 37 */         throw new QuarkParsingError(); 
/* 38 */       if (tickFrom == this.lastTick && this.timeline.getKeyFrames().size() != 0) {
/* 39 */         this.timeline.replaceEase(this.timeline.findAtTick(tickFrom), ease);
/*    */       } else {
/*    */         
/* 42 */         this.timeline.addKeyFrame(tickFrom, this.value, ease);
/*    */       } 
/* 44 */       this.value = value;
/* 45 */       this.lastTick = tickTo;
/* 46 */       this.timeline.addKeyFrame(tickTo, this.value, Ease.CONSTANT);
/*    */     }
/*    */     
/*    */     public float getValue() {
/* 50 */       return this.value;
/*    */     }
/*    */ 
/*    */     
/*    */     public void hold() {
/* 55 */       this.timeline.replaceEase(this.timeline.length() - 1, Ease.CONSTANT);
/*    */     }
/*    */     
/*    */     public void setValue(float valueAfter) {
/* 59 */       this.value = valueAfter;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\core\data\quarktool\PartMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */