/*     */ package dev.kosmx.playerAnim.core.data.opennbs;
/*     */ 
/*     */ import dev.kosmx.playerAnim.core.data.opennbs.format.Header;
/*     */ import dev.kosmx.playerAnim.core.data.opennbs.format.Layer;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.IOException;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NBSFileUtils
/*     */ {
/*     */   static final int maxWorkingVersion = 5;
/*     */   
/*     */   public static NBS read(DataInputStream stream) throws IOException {
/*  20 */     if (readShort(stream) != 0) {
/*  21 */       throw new IOException("Can't read old NBS format.");
/*     */     }
/*  23 */     NBS.Builder songBuilder = new NBS.Builder();
/*  24 */     Header header = songBuilder.header;
/*  25 */     header.NBS_version = stream.readByte();
/*  26 */     int version = header.NBS_version;
/*  27 */     if (version > 5) throw new IOException("Can't read newer NBS format than 5."); 
/*  28 */     header.Vanilla_instrument_count = stream.readByte();
/*  29 */     if (version >= 3) header.Song_length = readShort(stream); 
/*  30 */     header.Layer_count = readShort(stream);
/*  31 */     header.Song_name = readString(stream);
/*  32 */     header.Song_author = readString(stream);
/*  33 */     header.Song_original_author = readString(stream);
/*  34 */     header.Song_description = readString(stream);
/*  35 */     header.Song_tempo = readShort(stream);
/*  36 */     header.Auto_saving = stream.readByte();
/*  37 */     header.Auto_saving_duration = stream.readByte();
/*  38 */     header.Time_signature = stream.readByte();
/*  39 */     header.Minutes_spent = readInt(stream);
/*  40 */     header.Left_clicks = readInt(stream);
/*  41 */     header.Right_clicks = readInt(stream);
/*  42 */     header.Note_blocks_added = readInt(stream);
/*  43 */     header.Note_blocks_removed = readInt(stream);
/*  44 */     header.MIDI_Schematic_file_name = readString(stream);
/*  45 */     if (version >= 4) {
/*  46 */       header.Loop_on_off = stream.readByte();
/*  47 */       header.Max_loop_count = stream.readByte();
/*  48 */       header.Loop_start_tick = readShort(stream);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  53 */     for (int i = 0; i < header.Layer_count; i++) {
/*  54 */       songBuilder.layers.add(new Layer());
/*     */     }
/*     */     
/*  57 */     int maxLength = 0;
/*     */     
/*  59 */     int tick = -1; short jumpToTheNextTick;
/*  60 */     for (jumpToTheNextTick = readShort(stream); jumpToTheNextTick != 0; jumpToTheNextTick = readShort(stream)) {
/*  61 */       tick += jumpToTheNextTick; int jumpToTheNextLayer;
/*  62 */       for (int layer = -1; jumpToTheNextLayer != 0; jumpToTheNextLayer = readShort(stream)) {
/*  63 */         layer += jumpToTheNextLayer;
/*  64 */         Layer.Note note = ((Layer)songBuilder.layers.get(layer)).addNote(tick);
/*  65 */         if (note == null) {
/*  66 */           throw new IOException("Creeper, Aww man");
/*     */         }
/*  68 */         note.instrument = stream.readByte();
/*  69 */         note.key = stream.readByte();
/*  70 */         if (version >= 4) {
/*  71 */           note.velocity = stream.readByte();
/*  72 */           note.panning = stream.readByte();
/*  73 */           note.pitch = readShort(stream);
/*     */         } 
/*  75 */         maxLength = Math.max(maxLength, tick);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/*  80 */     for (Layer layer : songBuilder.layers) {
/*  81 */       layer.name = readString(stream);
/*  82 */       if (version >= 4) layer.lock = stream.readByte(); 
/*  83 */       layer.volume = stream.readByte();
/*  84 */       layer.stereo = stream.readByte();
/*     */     } 
/*  86 */     if (stream.readByte() != 0) {
/*  87 */       throw new IOException("NBSUtils can not handle custom instruments (yet)");
/*     */     }
/*     */     
/*  90 */     NBS song = songBuilder.build();
/*  91 */     song.setLength(maxLength);
/*  92 */     return song;
/*     */   }
/*     */   
/*     */   static String readString(DataInputStream stream) throws IOException {
/*  96 */     int len = readInt(stream);
/*  97 */     if (len < 0) {
/*  98 */       throw new IOException("The string's length is less than zero. You wanna me to read it backwards???");
/*     */     }
/* 100 */     byte[] bytes = new byte[len];
/* 101 */     if (stream.read(bytes) != len) {
/* 102 */       throw new IOException("Invalid string");
/*     */     }
/* 104 */     return new String(bytes, StandardCharsets.UTF_8);
/*     */   }
/*     */   
/*     */   static int readInt(DataInputStream stream) throws IOException {
/* 108 */     int i = 0;
/* 109 */     for (int n = 0; n < 4; n++) {
/* 110 */       i |= stream.read() << 8 * n;
/*     */     }
/* 112 */     return i;
/*     */   }
/*     */   static short readShort(DataInputStream stream) throws IOException {
/* 115 */     short i = 0;
/* 116 */     for (int n = 0; n < 2; n++) {
/* 117 */       i = (short)(i | stream.read() << 8 * n);
/*     */     }
/* 119 */     return i;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\core\data\opennbs\NBSFileUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */