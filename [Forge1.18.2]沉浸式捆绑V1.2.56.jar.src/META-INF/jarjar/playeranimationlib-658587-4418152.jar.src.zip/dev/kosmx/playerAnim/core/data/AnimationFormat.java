/*    */ package dev.kosmx.playerAnim.core.data;
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum AnimationFormat
/*    */ {
/*  7 */   JSON_EMOTECRAFT("json"),
/*  8 */   JSON_MC_ANIM("json"),
/*  9 */   QUARK("emote"),
/* 10 */   BINARY("emotecraft"),
/* 11 */   SERVER(null),
/* 12 */   UNKNOWN(null);
/*    */   
/*    */   private final String extension;
/*    */ 
/*    */   
/*    */   AnimationFormat(String extension) {
/* 18 */     this.extension = extension;
/*    */   }
/*    */   
/*    */   public String getExtension() {
/* 22 */     return this.extension;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\core\data\AnimationFormat.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */