/*    */ package dev.kosmx.playerAnim.core.data.quarktool;
/*    */ 
/*    */ import dev.kosmx.playerAnim.core.util.Ease;
/*    */ 
/*    */ public class Reset implements Playable {
/*    */   private Playable[] parts;
/*    */   
/*    */   public Reset(QuarkReader reader, String all, int len) throws QuarkParsingError {
/*  9 */     if (all.equals("all")) {
/* 10 */       this.parts = new Playable[18];
/* 11 */       addParts(0, reader.head, len);
/* 12 */       addParts(3, reader.rightArm, len);
/* 13 */       addParts(6, reader.rightLeg, len);
/* 14 */       addParts(9, reader.leftArm, len);
/* 15 */       addParts(12, reader.leftLeg, len);
/* 16 */       addParts(15, reader.torso, len);
/*    */     } else {
/* 18 */       this.parts = new Playable[3];
/* 19 */       addParts(0, reader.getBPFromStr(all.split("_")), len);
/*    */     } 
/*    */   }
/*    */   
/*    */   private void addParts(int i, PartMap part, int len) {
/* 24 */     this.parts[i] = new Move(part.x, 0.0F, len, Ease.INOUTQUAD);
/* 25 */     this.parts[i + 1] = new Move(part.y, 0.0F, len, Ease.INOUTQUAD);
/* 26 */     this.parts[i + 2] = new Move(part.z, 0.0F, len, Ease.INOUTQUAD);
/*    */   }
/*    */ 
/*    */   
/*    */   public int playForward(int time) throws QuarkParsingError {
/* 31 */     return 0;
/*    */   }
/*    */ 
/*    */   
/*    */   public int playBackward(int time) throws QuarkParsingError {
/* 36 */     return 0;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\core\data\quarktool\Reset.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */