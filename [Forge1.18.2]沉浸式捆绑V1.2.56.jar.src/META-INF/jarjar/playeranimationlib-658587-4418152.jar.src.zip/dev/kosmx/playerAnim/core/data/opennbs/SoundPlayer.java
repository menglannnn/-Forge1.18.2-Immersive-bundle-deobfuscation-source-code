/*    */ package dev.kosmx.playerAnim.core.data.opennbs;
/*    */ 
/*    */ import dev.kosmx.playerAnim.core.data.opennbs.format.Layer;
/*    */ import java.util.List;
/*    */ import java.util.function.Consumer;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SoundPlayer
/*    */ {
/*    */   final NBS song;
/*    */   final float songPerMCTick;
/* 16 */   int mcTick = 0;
/* 17 */   int soundTick = -1;
/*    */   
/*    */   boolean isPlaying = true;
/*    */   final Consumer<Layer.Note> playSound;
/*    */   
/*    */   public SoundPlayer(NBS song, Consumer<Layer.Note> soundPlayer, int tickToBegin) {
/* 23 */     this.song = song;
/* 24 */     this.songPerMCTick = song.header.Song_tempo / 2000.0F;
/* 25 */     this.playSound = soundPlayer;
/* 26 */     this.mcTick = tickToBegin;
/*    */   }
/*    */   
/*    */   public void tick() {
/* 30 */     int newSongTick = (int)(this.mcTick++ * this.songPerMCTick);
/* 31 */     if (newSongTick > this.song.header.Loop_start_tick && this.song.header.Loop_on_off()) {
/* 32 */       if (this.song.header.Max_loop_count != 0) {
/* 33 */         int loop = this.song.header.Max_loop_count & 0xFF;
/* 34 */         if ((newSongTick - this.song.header.Loop_start_tick) / (this.song.getLength() - this.song.header.Loop_start_tick) > loop) {
/* 35 */           stop();
/*    */           return;
/*    */         } 
/*    */       } 
/* 39 */       newSongTick = (newSongTick - this.song.header.Loop_start_tick) % (this.song.getLength() - this.song.header.Loop_start_tick) + this.song.header.Loop_start_tick;
/*    */     }
/* 41 */     else if (newSongTick > this.song.getLength()) {
/* 42 */       stop();
/*    */       return;
/*    */     } 
/* 45 */     if (newSongTick == this.soundTick) {
/*    */       return;
/*    */     }
/* 48 */     List<Layer.Note> notesToPlay = this.song.getNotesUntilTick(this.soundTick, newSongTick);
/*    */     
/* 50 */     notesToPlay.forEach(this.playSound);
/*    */     
/* 52 */     this.soundTick = newSongTick;
/*    */   }
/*    */ 
/*    */   
/*    */   public void stop() {
/* 57 */     this.isPlaying = false;
/*    */   }
/*    */ 
/*    */   
/*    */   public static boolean isPlayingSong(@Nullable SoundPlayer player) {
/* 62 */     return (player != null && player.isPlaying);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\core\data\opennbs\SoundPlayer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */