/*     */ package dev.kosmx.playerAnim.core.data;
/*     */ 
/*     */ import dev.kosmx.playerAnim.core.util.Ease;
/*     */ import java.io.IOException;
/*     */ import java.nio.BufferOverflowException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.UUID;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AnimationBinary
/*     */ {
/*     */   private static final byte keyframeSize = 9;
/*     */   
/*     */   public static <T extends ByteBuffer> T write(KeyframeAnimation animation, T buf, int version) throws BufferOverflowException {
/*  42 */     buf.putInt(animation.beginTick);
/*  43 */     buf.putInt(animation.endTick);
/*  44 */     buf.putInt(animation.stopTick);
/*  45 */     putBoolean((ByteBuffer)buf, animation.isInfinite());
/*  46 */     buf.putInt(animation.returnToTick);
/*  47 */     putBoolean((ByteBuffer)buf, animation.isEasingBefore);
/*  48 */     putBoolean((ByteBuffer)buf, animation.nsfw);
/*  49 */     buf.put((byte)9);
/*  50 */     if (version >= 2) {
/*  51 */       buf.putInt(animation.getBodyParts().size());
/*  52 */       for (Map.Entry<String, KeyframeAnimation.StateCollection> part : animation.getBodyParts().entrySet()) {
/*  53 */         putString((ByteBuffer)buf, part.getKey());
/*  54 */         writePart((ByteBuffer)buf, part.getValue(), version);
/*     */       } 
/*     */     } else {
/*  57 */       writePart((ByteBuffer)buf, animation.getPart("head"), version);
/*  58 */       writePart((ByteBuffer)buf, animation.getPart("body"), version);
/*  59 */       writePart((ByteBuffer)buf, animation.getPart("rightArm"), version);
/*  60 */       writePart((ByteBuffer)buf, animation.getPart("leftArm"), version);
/*  61 */       writePart((ByteBuffer)buf, animation.getPart("rightLeg"), version);
/*  62 */       writePart((ByteBuffer)buf, animation.getPart("leftLeg"), version);
/*     */     } 
/*  64 */     buf.putLong(animation.getUuid().getMostSignificantBits());
/*  65 */     buf.putLong(animation.getUuid().getLeastSignificantBits());
/*     */     
/*  67 */     return buf;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends ByteBuffer> T write(KeyframeAnimation animation, T buf) throws BufferOverflowException {
/*  79 */     return write(animation, buf, getCurrentVersion());
/*     */   }
/*     */ 
/*     */   
/*     */   private static void writePart(ByteBuffer buf, KeyframeAnimation.StateCollection part, int version) {
/*  84 */     writeKeyframes(buf, part.x, version);
/*  85 */     writeKeyframes(buf, part.y, version);
/*  86 */     writeKeyframes(buf, part.z, version);
/*  87 */     writeKeyframes(buf, part.pitch, version);
/*  88 */     writeKeyframes(buf, part.yaw, version);
/*  89 */     writeKeyframes(buf, part.roll, version);
/*  90 */     if (part.isBendable) {
/*  91 */       writeKeyframes(buf, part.bendDirection, version);
/*  92 */       writeKeyframes(buf, part.bend, version);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void writeKeyframes(ByteBuffer buf, KeyframeAnimation.StateCollection.State part, int version) {
/*  97 */     List<KeyframeAnimation.KeyFrame> list = part.getKeyFrames();
/*  98 */     if (version >= 2) {
/*  99 */       putBoolean(buf, part.isEnabled());
/* 100 */       buf.putInt(list.size());
/*     */     } else {
/* 102 */       buf.putInt(part.isEnabled() ? list.size() : -1);
/*     */     } 
/* 104 */     if (part.isEnabled() || version >= 2) {
/* 105 */       for (KeyframeAnimation.KeyFrame move : list) {
/* 106 */         buf.putInt(move.tick);
/* 107 */         buf.putFloat(move.value);
/* 108 */         buf.put(move.ease.getId());
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static KeyframeAnimation read(ByteBuffer buf, int version) throws IOException {
/* 124 */     KeyframeAnimation.AnimationBuilder animation = new KeyframeAnimation.AnimationBuilder(AnimationFormat.BINARY);
/* 125 */     animation.beginTick = buf.getInt();
/* 126 */     animation.endTick = buf.getInt();
/* 127 */     animation.stopTick = buf.getInt();
/* 128 */     animation.isLooped = getBoolean(buf);
/* 129 */     animation.returnTick = buf.getInt();
/* 130 */     animation.isEasingBefore = getBoolean(buf);
/* 131 */     animation.nsfw = getBoolean(buf);
/* 132 */     int keyframeSize = buf.get();
/* 133 */     if (keyframeSize <= 0) throw new IOException("keyframe size must be greater than 0, current: " + keyframeSize); 
/* 134 */     boolean valid = true;
/* 135 */     if (version >= 2) {
/* 136 */       int count = buf.getInt();
/* 137 */       for (int i = 0; i < count; i++) {
/* 138 */         String name = getString(buf);
/* 139 */         KeyframeAnimation.StateCollection part = animation.getOrCreatePart(name);
/* 140 */         valid = (readPart(buf, part, version, keyframeSize) && valid);
/*     */       } 
/*     */     } else {
/* 143 */       valid = readPart(buf, animation.head, version, keyframeSize);
/* 144 */       valid = (readPart(buf, animation.body, version, keyframeSize) && valid);
/* 145 */       valid = (readPart(buf, animation.rightArm, version, keyframeSize) && valid);
/* 146 */       valid = (readPart(buf, animation.leftArm, version, keyframeSize) && valid);
/* 147 */       valid = (readPart(buf, animation.rightLeg, version, keyframeSize) && valid);
/* 148 */       valid = (readPart(buf, animation.leftLeg, version, keyframeSize) && valid);
/*     */     } 
/* 150 */     long msb = buf.getLong();
/* 151 */     long lsb = buf.getLong();
/* 152 */     animation.uuid = new UUID(msb, lsb);
/* 153 */     animation.extraData.put("valid", Boolean.valueOf(valid));
/*     */     
/* 155 */     return animation.build();
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean readPart(ByteBuffer buf, KeyframeAnimation.StateCollection part, int version, int keyframeSize) {
/* 160 */     boolean bl = readKeyframes(buf, part.x, version, keyframeSize);
/* 161 */     bl = (readKeyframes(buf, part.y, version, keyframeSize) && bl);
/* 162 */     bl = (readKeyframes(buf, part.z, version, keyframeSize) && bl);
/* 163 */     bl = (readKeyframes(buf, part.pitch, version, keyframeSize) && bl);
/* 164 */     bl = (readKeyframes(buf, part.yaw, version, keyframeSize) && bl);
/* 165 */     bl = (readKeyframes(buf, part.roll, version, keyframeSize) && bl);
/* 166 */     if (part.isBendable()) {
/* 167 */       bl = (readKeyframes(buf, part.bendDirection, version, keyframeSize) && bl);
/* 168 */       bl = (readKeyframes(buf, part.bend, version, keyframeSize) && bl);
/*     */     } 
/* 170 */     return bl;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean readKeyframes(ByteBuffer buf, KeyframeAnimation.StateCollection.State part, int version, int keyframeSize) {
/*     */     int length;
/* 177 */     boolean enabled, valid = true;
/*     */     
/* 179 */     if (version >= 2) {
/* 180 */       enabled = getBoolean(buf);
/* 181 */       length = buf.getInt();
/*     */     } else {
/* 183 */       length = buf.getInt();
/* 184 */       enabled = (length >= 0);
/*     */     } 
/* 186 */     for (int i = 0; i < length; i++) {
/*     */       
/* 188 */       int currentPos = buf.position();
/* 189 */       if (!part.addKeyFrame(buf.getInt(), buf.getFloat(), Ease.getEase(buf.get()))) {
/* 190 */         valid = false;
/*     */       }
/* 192 */       buf.position(currentPos + keyframeSize);
/*     */     } 
/* 194 */     part.setEnabled(enabled);
/* 195 */     return valid;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getCurrentVersion() {
/* 203 */     return 2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int calculateSize(KeyframeAnimation animation, int version) {
/* 210 */     int size = 36;
/* 211 */     if (version < 2) {
/* 212 */       size += partSize(animation.getPart("head"), version);
/* 213 */       size += partSize(animation.getPart("body"), version);
/* 214 */       size += partSize(animation.getPart("rightArm"), version);
/* 215 */       size += partSize(animation.getPart("leftArm"), version);
/* 216 */       size += partSize(animation.getPart("rightLeg"), version);
/* 217 */       size += partSize(animation.getPart("leftLeg"), version);
/*     */     } else {
/* 219 */       size += 4;
/* 220 */       for (Map.Entry<String, KeyframeAnimation.StateCollection> entry : animation.getBodyParts().entrySet()) {
/* 221 */         size += stringSize(entry.getKey()) + partSize(entry.getValue(), version);
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 227 */     return size;
/*     */   }
/*     */   
/*     */   private static int stringSize(String str) {
/* 231 */     byte[] bytes = str.getBytes(StandardCharsets.UTF_8);
/* 232 */     return bytes.length + 4;
/*     */   }
/*     */   
/*     */   private static int partSize(@Nullable KeyframeAnimation.StateCollection part, int version) {
/* 236 */     int size = 0;
/* 237 */     size += axisSize(part.x, version);
/* 238 */     size += axisSize(part.y, version);
/* 239 */     size += axisSize(part.z, version);
/* 240 */     size += axisSize(part.pitch, version);
/* 241 */     size += axisSize(part.yaw, version);
/* 242 */     size += axisSize(part.roll, version);
/* 243 */     if (part.isBendable) {
/* 244 */       size += axisSize(part.bend, version);
/* 245 */       size += axisSize(part.bendDirection, version);
/*     */     } 
/* 247 */     return size;
/*     */   }
/*     */   
/*     */   private static int axisSize(KeyframeAnimation.StateCollection.State axis, int version) {
/* 251 */     return axis.getKeyFrames().size() * 9 + ((version >= 2) ? 5 : 4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void putBoolean(ByteBuffer byteBuffer, boolean bl) {
/* 261 */     byteBuffer.put((byte)(bl ? 1 : 0));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean getBoolean(ByteBuffer buf) {
/* 270 */     return (buf.get() != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void putString(ByteBuffer buf, String str) {
/* 280 */     byte[] bytes = str.getBytes(StandardCharsets.UTF_8);
/* 281 */     buf.putInt(bytes.length);
/* 282 */     buf.put(bytes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getString(ByteBuffer buf) {
/* 291 */     int len = buf.getInt();
/* 292 */     byte[] bytes = new byte[len];
/* 293 */     buf.get(bytes);
/* 294 */     return new String(bytes, StandardCharsets.UTF_8);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\core\data\AnimationBinary.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */