/*    */ package dev.kosmx.playerAnim.core.util;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.HashMap;
/*    */ import java.util.Iterator;
/*    */ import java.util.UUID;
/*    */ import java.util.function.Predicate;
/*    */ import java.util.function.Supplier;
/*    */ 
/*    */ public class UUIDMap<T extends Supplier<UUID>>
/*    */   extends HashMap<UUID, T> implements Iterable<T> {
/*    */   public T put(T v) {
/* 13 */     return put(v.get(), v);
/*    */   }
/*    */   
/*    */   public void addAll(Collection<T> m) {
/* 17 */     for (Supplier supplier : m) {
/* 18 */       put((T)supplier);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Iterator<T> iterator() {
/* 25 */     return values().iterator();
/*    */   }
/*    */   
/*    */   public void add(T value) {
/* 29 */     put(value);
/*    */   }
/*    */   
/*    */   public boolean contains(T value) {
/* 33 */     return containsKey(value.get());
/*    */   }
/*    */   
/*    */   public void removeIf(Predicate<T> predicate) {
/* 37 */     values().removeIf(predicate);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\cor\\util\UUIDMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */