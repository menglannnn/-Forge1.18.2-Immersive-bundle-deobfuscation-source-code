/*    */ package dev.kosmx.playerAnim.core.data.quarktool;
/*    */ 
/*    */ public class Pause implements Playable {
/*    */   private final int len;
/*    */   
/*    */   public Pause(int len) {
/*  7 */     this.len = len;
/*    */   }
/*    */ 
/*    */   
/*    */   public int playForward(int time) {
/* 12 */     return time + this.len;
/*    */   }
/*    */ 
/*    */   
/*    */   public int playBackward(int time) {
/* 17 */     return time + this.len;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\core\data\quarktool\Pause.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */