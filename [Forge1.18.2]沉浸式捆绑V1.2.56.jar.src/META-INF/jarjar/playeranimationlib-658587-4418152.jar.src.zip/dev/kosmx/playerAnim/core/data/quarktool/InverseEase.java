/*    */ package dev.kosmx.playerAnim.core.data.quarktool;
/*    */ 
/*    */ import dev.kosmx.playerAnim.core.util.Ease;
/*    */ import dev.kosmx.playerAnim.core.util.Easing;
/*    */ 
/*    */ public class InverseEase {
/*    */   public static Ease inverse(Ease ease) {
/*  8 */     String str = ease.toString();
/*  9 */     if (str.substring(0, 2).equals("IN") && !str.substring(0, 5).equals("INOUT"))
/* 10 */       return Easing.easeFromString("OUT" + str.substring(2)); 
/* 11 */     if (str.substring(0, 3).equals("OUT"))
/* 12 */       return Easing.easeFromString("IN" + str.substring(3)); 
/* 13 */     return ease;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\core\data\quarktool\InverseEase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */