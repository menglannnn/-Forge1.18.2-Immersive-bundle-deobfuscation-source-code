/*    */ package dev.kosmx.playerAnim.core.data.gson;
/*    */ 
/*    */ import com.google.gson.Gson;
/*    */ import com.google.gson.GsonBuilder;
/*    */ import dev.kosmx.playerAnim.core.data.KeyframeAnimation;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.InputStreamReader;
/*    */ import java.io.Reader;
/*    */ import java.io.Writer;
/*    */ import java.nio.charset.StandardCharsets;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AnimationSerializing
/*    */ {
/*    */   public static final Gson SERIALIZER;
/*    */   
/*    */   public static List<KeyframeAnimation> deserializeAnimation(Reader stream) {
/* 32 */     return (List<KeyframeAnimation>)SERIALIZER.fromJson(stream, AnimationJson.getListedTypeToken());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static List<KeyframeAnimation> deserializeAnimation(InputStream stream) throws IOException {
/* 41 */     InputStreamReader reader = new InputStreamReader(stream, StandardCharsets.UTF_8); try {
/* 42 */       List<KeyframeAnimation> list = deserializeAnimation(reader);
/* 43 */       reader.close();
/*    */       return list;
/*    */     } catch (Throwable throwable) {
/*    */       try {
/*    */         reader.close();
/*    */       } catch (Throwable throwable1) {
/*    */         throwable.addSuppressed(throwable1);
/*    */       } 
/*    */       throw throwable;
/*    */     } 
/*    */   } public static String serializeAnimation(KeyframeAnimation animation) {
/* 54 */     return SERIALIZER.toJson(animation, KeyframeAnimation.class);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Writer writeAnimation(KeyframeAnimation animation, Writer writer) throws IOException {
/* 65 */     writer.write(serializeAnimation(animation));
/* 66 */     return writer;
/*    */   }
/*    */   
/*    */   static {
/* 70 */     GsonBuilder builder = new GsonBuilder();
/* 71 */     builder.setPrettyPrinting();
/* 72 */     AnimationJson animationJson = new AnimationJson();
/* 73 */     builder.registerTypeAdapter(AnimationJson.getListedTypeToken(), animationJson);
/* 74 */     builder.registerTypeAdapter(KeyframeAnimation.class, animationJson);
/* 75 */     SERIALIZER = builder.create();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\core\data\gson\AnimationSerializing.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */