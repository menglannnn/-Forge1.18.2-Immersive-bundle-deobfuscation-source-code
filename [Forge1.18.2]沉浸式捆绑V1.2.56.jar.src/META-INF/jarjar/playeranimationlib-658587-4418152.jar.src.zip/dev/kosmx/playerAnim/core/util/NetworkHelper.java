/*    */ package dev.kosmx.playerAnim.core.util;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.nio.ByteBuffer;
/*    */ import java.nio.charset.StandardCharsets;
/*    */ import java.util.UUID;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class NetworkHelper
/*    */ {
/*    */   public static String readString(ByteBuffer buf) throws IOException {
/* 15 */     int len = buf.getInt();
/* 16 */     if (len < 0) {
/* 17 */       throw new IOException("The received encoded string buffer length is less than zero! Weird string!");
/*    */     }
/* 19 */     byte[] b = new byte[len];
/* 20 */     buf.get(b);
/*    */     
/* 22 */     return new String(b, StandardCharsets.UTF_8);
/*    */   }
/*    */   
/*    */   public static void writeString(ByteBuffer buf, String str) {
/* 26 */     byte[] b = str.getBytes(StandardCharsets.UTF_8);
/* 27 */     buf.putInt(b.length);
/* 28 */     buf.put(b);
/*    */   }
/*    */ 
/*    */   
/*    */   public static String readVarString(ByteBuffer buf) throws IOException {
/* 33 */     int j = readVarInt(buf);
/* 34 */     if (j < 0) {
/* 35 */       throw new IOException("The received encoded string buffer length is less than zero! Weird string!");
/*    */     }
/* 37 */     byte[] bytes = new byte[j];
/* 38 */     buf.get(bytes);
/* 39 */     return new String(bytes, StandardCharsets.UTF_8);
/*    */   }
/*    */   
/*    */   public static void writeVarString(ByteBuffer buf, String str) {
/* 43 */     byte[] bytes = str.getBytes(StandardCharsets.UTF_8);
/* 44 */     writeVarInt(buf, bytes.length);
/* 45 */     buf.put(bytes);
/*    */   }
/*    */   
/*    */   public static UUID readUUID(ByteBuffer buf) {
/* 49 */     long a = buf.getLong();
/* 50 */     long b = buf.getLong();
/* 51 */     return new UUID(a, b);
/*    */   }
/*    */   public static void writeUUID(ByteBuffer buf, UUID uuid) {
/* 54 */     buf.putLong(uuid.getMostSignificantBits());
/* 55 */     buf.putLong(uuid.getLeastSignificantBits());
/*    */   }
/*    */   
/*    */   public static int readVarInt(ByteBuffer buf) {
/*    */     byte b;
/* 60 */     int i = 0;
/* 61 */     int j = 0;
/*    */ 
/*    */     
/*    */     do {
/* 65 */       b = buf.get();
/* 66 */       i |= (b & Byte.MAX_VALUE) << j++ * 7;
/* 67 */       if (j > 5) {
/* 68 */         throw new RuntimeException("VarInt too big");
/*    */       }
/* 70 */     } while ((b & 0x80) == 128);
/*    */     
/* 72 */     return i;
/*    */   }
/*    */ 
/*    */   
/*    */   public static void writeVarInt(ByteBuffer buf, int i) {
/* 77 */     while ((i & 0xFFFFFF80) != 0) {
/* 78 */       buf.put((byte)(i & 0x7F | 0x80));
/* 79 */       i >>>= 7;
/*    */     } 
/*    */     
/* 82 */     buf.put((byte)i);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\cor\\util\NetworkHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */