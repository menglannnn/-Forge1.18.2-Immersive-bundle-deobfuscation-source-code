/*    */ package dev.kosmx.playerAnim.core.util;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import javax.annotation.concurrent.Immutable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Immutable
/*    */ public class Pair<L, R>
/*    */ {
/*    */   final L left;
/*    */   final R right;
/*    */   
/*    */   public Pair(L left, R right) {
/* 24 */     this.left = left;
/* 25 */     this.right = right;
/*    */   }
/*    */   
/*    */   public L getLeft() {
/* 29 */     return this.left;
/*    */   }
/*    */   public R getRight() {
/* 32 */     return this.right;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 38 */     if (o instanceof Pair) {
/* 39 */       Pair o2 = (Pair)o;
/* 40 */       return (Objects.equals(this.left, o2.left) && Objects.equals(this.right, o2.right));
/*    */     } 
/* 42 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 47 */     int hash = 0;
/* 48 */     hash = hash * 31 + ((this.left == null) ? 0 : this.left.hashCode());
/* 49 */     hash = hash * 31 + ((this.right == null) ? 0 : this.right.hashCode());
/* 50 */     return hash;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 55 */     return "Pair{left=" + this.left + ", right=" + this.right + '}';
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\cor\\util\Pair.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */