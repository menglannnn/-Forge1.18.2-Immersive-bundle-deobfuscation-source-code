/*     */ package dev.kosmx.playerAnim.core.data.opennbs.network;
/*     */ 
/*     */ import dev.kosmx.playerAnim.core.data.opennbs.NBS;
/*     */ import dev.kosmx.playerAnim.core.data.opennbs.format.Header;
/*     */ import dev.kosmx.playerAnim.core.data.opennbs.format.Layer;
/*     */ import dev.kosmx.playerAnim.core.util.NetworkHelper;
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ 
/*     */ public class NBSPacket
/*     */ {
/*     */   NBS song;
/*     */   boolean sendExtraData = false;
/*  14 */   int version = 1;
/*  15 */   final int packetVersion = 1;
/*     */   
/*     */   boolean valid = true;
/*     */   
/*     */   public NBSPacket(NBS song) {
/*  20 */     this.song = song;
/*     */   }
/*     */ 
/*     */   
/*     */   public NBSPacket() {}
/*     */ 
/*     */   
/*     */   public NBS getSong() {
/*  28 */     return this.song;
/*     */   }
/*     */   
/*     */   public void write(ByteBuffer buf) {
/*  32 */     buf.putInt(1);
/*  33 */     buf.put((byte)(this.sendExtraData ? 1 : 0));
/*  34 */     buf.put(this.song.header.Vanilla_instrument_count);
/*  35 */     if (this.sendExtraData) {
/*  36 */       buf.putShort(this.song.header.Song_length);
/*  37 */       NetworkHelper.writeString(buf, this.song.header.Song_name);
/*  38 */       NetworkHelper.writeString(buf, this.song.header.Song_author);
/*  39 */       NetworkHelper.writeString(buf, this.song.header.Song_original_author);
/*  40 */       NetworkHelper.writeString(buf, this.song.header.Song_description);
/*     */     } 
/*  42 */     buf.putShort(this.song.header.Song_tempo);
/*  43 */     if (this.sendExtraData) {
/*  44 */       buf.put(this.song.header.Auto_saving);
/*  45 */       buf.put(this.song.header.Auto_saving_duration);
/*     */     } 
/*  47 */     buf.put(this.song.header.Time_signature);
/*  48 */     if (this.sendExtraData) {
/*     */       
/*  50 */       buf.putInt(this.song.header.Minutes_spent);
/*  51 */       buf.putInt(this.song.header.Left_clicks);
/*  52 */       buf.putInt(this.song.header.Right_clicks);
/*  53 */       buf.putInt(this.song.header.Note_blocks_added);
/*  54 */       buf.putInt(this.song.header.Note_blocks_removed);
/*  55 */       NetworkHelper.writeString(buf, this.song.header.MIDI_Schematic_file_name);
/*     */     } 
/*  57 */     buf.put(this.song.header.Loop_on_off);
/*  58 */     buf.put(this.song.header.Max_loop_count);
/*  59 */     buf.putShort(this.song.header.Loop_start_tick);
/*  60 */     buf.putShort((short)this.song.getLayers().size());
/*  61 */     writeLayersAndNotes(buf);
/*     */   }
/*     */   public void writeLayersAndNotes(ByteBuffer buf) {
/*  64 */     for (Layer layer : this.song.getLayers()) {
/*  65 */       if (this.sendExtraData) {
/*  66 */         NetworkHelper.writeString(buf, layer.name);
/*  67 */         buf.put(layer.lock);
/*     */       } 
/*  69 */       buf.put(layer.volume);
/*  70 */       buf.put(layer.stereo);
/*  71 */       int tick = -1;
/*  72 */       for (Layer.Note note : layer.notes) {
/*  73 */         buf.putShort((short)(note.tick - tick));
/*  74 */         tick = note.tick;
/*  75 */         buf.put(note.instrument);
/*  76 */         buf.put(note.key);
/*  77 */         buf.put(note.velocity);
/*  78 */         buf.put(note.panning);
/*  79 */         buf.putShort(note.pitch);
/*     */       } 
/*  81 */       buf.putShort((short)0);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean read(ByteBuffer buf) throws IOException {
/*  91 */     this.version = buf.getInt();
/*  92 */     this.sendExtraData = (buf.get() != 0);
/*  93 */     NBS.Builder builder = new NBS.Builder();
/*  94 */     Header header = builder.header;
/*  95 */     header.Vanilla_instrument_count = buf.get();
/*  96 */     if (this.sendExtraData) {
/*  97 */       header.Song_length = buf.getShort();
/*  98 */       header.Song_name = NetworkHelper.readString(buf);
/*  99 */       header.Song_author = NetworkHelper.readString(buf);
/* 100 */       header.Song_original_author = NetworkHelper.readString(buf);
/* 101 */       header.Song_description = NetworkHelper.readString(buf);
/*     */     } 
/* 103 */     header.Song_tempo = buf.getShort();
/* 104 */     if (this.sendExtraData) {
/* 105 */       header.Auto_saving = buf.get();
/* 106 */       header.Auto_saving_duration = buf.get();
/*     */     } 
/* 108 */     header.Time_signature = buf.get();
/* 109 */     if (this.sendExtraData) {
/* 110 */       header.Minutes_spent = buf.getInt();
/* 111 */       header.Left_clicks = buf.getInt();
/* 112 */       header.Right_clicks = buf.getInt();
/* 113 */       header.Note_blocks_added = buf.getInt();
/* 114 */       header.Note_blocks_removed = buf.getInt();
/* 115 */       header.MIDI_Schematic_file_name = NetworkHelper.readString(buf);
/*     */     } 
/* 117 */     header.Loop_on_off = buf.get();
/* 118 */     header.Max_loop_count = buf.get();
/* 119 */     header.Loop_start_tick = buf.getShort();
/*     */     
/* 121 */     header.Layer_count = buf.getShort();
/*     */     
/* 123 */     this.song = builder.build();
/*     */     
/* 125 */     readLayersAndNotes(buf);
/*     */     
/* 127 */     return this.valid;
/*     */   }
/*     */   
/*     */   void readLayersAndNotes(ByteBuffer buf) throws IOException {
/* 131 */     int length = 0;
/* 132 */     for (Layer layer : this.song.getLayers()) {
/* 133 */       boolean locked = false;
/* 134 */       if (this.sendExtraData) {
/* 135 */         layer.name = NetworkHelper.readString(buf);
/* 136 */         locked = (buf.get() != 0);
/*     */       } 
/* 138 */       layer.volume = buf.get();
/* 139 */       layer.stereo = buf.get();
/*     */       
/* 141 */       int tick = -1; int step;
/* 142 */       for (step = buf.getShort(); step != 0; step = buf.getShort()) {
/* 143 */         tick += step;
/* 144 */         Layer.Note note = layer.addNote(tick);
/* 145 */         if (note == null) {
/* 146 */           this.valid = false;
/*     */           return;
/*     */         } 
/* 149 */         note.instrument = buf.get();
/* 150 */         note.key = buf.get();
/* 151 */         note.velocity = buf.get();
/* 152 */         note.panning = buf.get();
/* 153 */         note.pitch = buf.getShort();
/* 154 */         length = Math.max(length, tick);
/*     */       } 
/* 156 */       layer.setLock(locked);
/*     */     } 
/* 158 */     this.song.setLength(length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int calculateMessageSize(NBS song) {
/* 167 */     int size = 15;
/*     */ 
/*     */ 
/*     */     
/* 171 */     for (Layer layer : song.getLayers()) {
/* 172 */       size += getLayerMessageSize(layer);
/*     */     }
/*     */     
/* 175 */     return size;
/*     */   }
/*     */ 
/*     */   
/*     */   public static int getLayerMessageSize(Layer layer) {
/* 180 */     return 4 + layer.notes.size() * 8;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\core\data\opennbs\network\NBSPacket.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */