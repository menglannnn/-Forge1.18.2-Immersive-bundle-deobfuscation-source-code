/*     */ package dev.kosmx.playerAnim.core.data.gson;
/*     */ 
/*     */ import com.google.gson.JsonArray;
/*     */ import com.google.gson.JsonDeserializationContext;
/*     */ import com.google.gson.JsonDeserializer;
/*     */ import com.google.gson.JsonElement;
/*     */ import com.google.gson.JsonObject;
/*     */ import com.google.gson.JsonParseException;
/*     */ import com.google.gson.JsonParser;
/*     */ import com.google.gson.JsonPrimitive;
/*     */ import com.google.gson.JsonSerializationContext;
/*     */ import com.google.gson.JsonSerializer;
/*     */ import com.google.gson.reflect.TypeToken;
/*     */ import dev.kosmx.playerAnim.core.data.AnimationFormat;
/*     */ import dev.kosmx.playerAnim.core.data.KeyframeAnimation;
/*     */ import dev.kosmx.playerAnim.core.util.Easing;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.UUID;
/*     */ 
/*     */ public class AnimationJson implements JsonDeserializer<List<KeyframeAnimation>>, JsonSerializer<KeyframeAnimation> {
/*     */   private static final int modVersion = 3;
/*     */   
/*     */   public static Type getListedTypeToken() {
/*  27 */     return (new TypeToken<List<KeyframeAnimation>>() {  }).getType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<KeyframeAnimation> deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
/*  35 */     JsonObject node = json.getAsJsonObject();
/*     */     
/*  37 */     if (!node.has("emote")) {
/*  38 */       return GeckoLibSerializer.serialize(node);
/*     */     }
/*     */     
/*  41 */     int version = 1;
/*  42 */     if (node.has("version")) version = node.get("version").getAsInt();
/*     */     
/*  44 */     KeyframeAnimation.AnimationBuilder emote = emoteDeserializer(node.getAsJsonObject("emote"), version);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  49 */     for (Map.Entry<String, JsonElement> entry : (Iterable<Map.Entry<String, JsonElement>>)node.entrySet()) {
/*  50 */       String string = entry.getKey();
/*  51 */       if (string.equals("uuid") || string.equals("comment") || string.equals("version"))
/*  52 */         continue;  JsonElement value = entry.getValue();
/*  53 */       if (value.isJsonPrimitive()) {
/*  54 */         JsonPrimitive p = value.getAsJsonPrimitive();
/*  55 */         if (p.isBoolean()) {
/*  56 */           emote.extraData.put(string, Boolean.valueOf(p.getAsBoolean())); continue;
/*  57 */         }  if (p.isString()) {
/*  58 */           emote.extraData.put(string, p.getAsString()); continue;
/*  59 */         }  if (p.isNumber()) {
/*  60 */           emote.extraData.put(string, Double.valueOf(p.getAsDouble())); continue;
/*  61 */         }  emote.extraData.put(string, p.toString());
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/*  66 */     emote.name = node.get("name").toString();
/*  67 */     if (node.has("author")) {
/*  68 */       emote.author = node.get("author").toString();
/*     */     }
/*     */     
/*  71 */     if (node.has("description")) {
/*  72 */       emote.description = node.get("description").toString();
/*     */     }
/*     */     
/*  75 */     if (3 < version) {
/*  76 */       throw new JsonParseException(emote.name + " is version " + version + ". PlayerAnimator library can only process version " + '\003' + ".");
/*     */     }
/*     */ 
/*     */     
/*  80 */     if (node.has("uuid")) {
/*  81 */       emote.uuid = UUID.fromString(node.get("uuid").getAsString());
/*     */     }
/*     */     
/*  84 */     emote.optimizeEmote();
/*  85 */     List<KeyframeAnimation> list = new ArrayList<>();
/*  86 */     list.add(emote.build());
/*  87 */     return list;
/*     */   }
/*     */   
/*     */   private KeyframeAnimation.AnimationBuilder emoteDeserializer(JsonObject node, int version) throws JsonParseException {
/*  91 */     KeyframeAnimation.AnimationBuilder builder = new KeyframeAnimation.AnimationBuilder(AnimationFormat.JSON_EMOTECRAFT);
/*  92 */     if (node.has("beginTick")) {
/*  93 */       builder.beginTick = node.get("beginTick").getAsInt();
/*     */     }
/*  95 */     builder.endTick = node.get("endTick").getAsInt();
/*  96 */     if (builder.endTick <= 0) throw new JsonParseException("endTick must be bigger than 0"); 
/*  97 */     if (node.has("isLoop") && node.has("returnTick")) {
/*  98 */       builder.isLooped = node.get("isLoop").getAsBoolean();
/*  99 */       builder.returnTick = node.get("returnTick").getAsInt();
/* 100 */       if (builder.isLooped && (builder.returnTick > builder.endTick || builder.returnTick < 0)) {
/* 101 */         throw new JsonParseException("return tick have to be smaller than endTick and not smaller than 0");
/*     */       }
/*     */     } 
/* 104 */     if (node.has("nsfw")) {
/* 105 */       builder.nsfw = node.get("nsfw").getAsBoolean();
/*     */     }
/*     */ 
/*     */     
/* 109 */     builder.stopTick = node.has("stopTick") ? node.get("stopTick").getAsInt() : builder.endTick;
/* 110 */     boolean degrees = (!node.has("degrees") || node.get("degrees").getAsBoolean());
/*     */     
/* 112 */     if (node.has("easeBeforeKeyframe")) builder.isEasingBefore = node.get("easeBeforeKeyframe").getAsBoolean(); 
/* 113 */     moveDeserializer(builder, node.getAsJsonArray("moves"), degrees, version);
/*     */     
/* 115 */     builder.fullyEnableParts();
/*     */     
/* 117 */     return builder;
/*     */   }
/*     */   
/*     */   private void moveDeserializer(KeyframeAnimation.AnimationBuilder emote, JsonArray node, boolean degrees, int version) {
/* 121 */     for (JsonElement n : node) {
/* 122 */       JsonObject obj = n.getAsJsonObject();
/* 123 */       int tick = obj.get("tick").getAsInt();
/* 124 */       String easing = obj.has("easing") ? obj.get("easing").getAsString() : "linear";
/* 125 */       int turn = obj.has("turn") ? obj.get("turn").getAsInt() : 0;
/* 126 */       for (Map.Entry<String, JsonElement> entry : (Iterable<Map.Entry<String, JsonElement>>)obj.entrySet()) {
/* 127 */         if (((String)entry.getKey()).equals("tick") || ((String)entry.getKey()).equals("comment") || ((String)entry.getKey()).equals("easing") || ((String)entry.getKey()).equals("turn")) {
/*     */           continue;
/*     */         }
/* 130 */         addBodyPartIfExists(emote, entry.getKey(), entry.getValue(), degrees, tick, easing, turn, version);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void addBodyPartIfExists(KeyframeAnimation.AnimationBuilder emote, String name, JsonElement node, boolean degrees, int tick, String easing, int turn, int version) {
/* 136 */     if (version < 3 && name.equals("torso")) name = "body"; 
/* 137 */     KeyframeAnimation.StateCollection part = emote.getOrCreatePart(name);
/* 138 */     JsonObject partNode = node.getAsJsonObject();
/*     */     
/* 140 */     addPartIfExists(part.x, "x", partNode, degrees, tick, easing, turn);
/* 141 */     addPartIfExists(part.y, "y", partNode, degrees, tick, easing, turn);
/* 142 */     addPartIfExists(part.z, "z", partNode, degrees, tick, easing, turn);
/* 143 */     addPartIfExists(part.pitch, "pitch", partNode, degrees, tick, easing, turn);
/* 144 */     addPartIfExists(part.yaw, "yaw", partNode, degrees, tick, easing, turn);
/* 145 */     addPartIfExists(part.roll, "roll", partNode, degrees, tick, easing, turn);
/* 146 */     addPartIfExists(part.bend, "bend", partNode, degrees, tick, easing, turn);
/* 147 */     addPartIfExists(part.bendDirection, "axis", partNode, degrees, tick, easing, turn);
/*     */   }
/*     */   
/*     */   private void addPartIfExists(KeyframeAnimation.StateCollection.State part, String name, JsonObject node, boolean degrees, int tick, String easing, int turn) {
/* 151 */     if (node.has(name)) {
/* 152 */       part.addKeyFrame(tick, node.get(name).getAsFloat(), Easing.easeFromString(easing), turn, degrees);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonElement serialize(KeyframeAnimation emote, Type typeOfSrc, JsonSerializationContext context) {
/* 171 */     JsonObject node = new JsonObject();
/* 172 */     KeyframeAnimation.StateCollection torso = emote.getPart("torso");
/* 173 */     if (torso != null && torso.isEnabled()) {
/* 174 */       node.addProperty("version", Integer.valueOf(3));
/*     */     } else {
/* 176 */       node.addProperty("version", Integer.valueOf(emote.isEasingBefore ? 2 : 1));
/*     */     } 
/* 178 */     emote.extraData.forEach((s, o) -> {
/*     */           if (o instanceof String) {
/*     */             node.add(s, asJson((String)o));
/*     */           } else if (o instanceof Number) {
/*     */             node.addProperty(s, (Number)o);
/*     */           } else if (o instanceof Boolean) {
/*     */             node.addProperty(s, Boolean.valueOf(((Boolean)o).booleanValue()));
/*     */           } else if (o instanceof JsonElement) {
/*     */             node.add(s, (JsonElement)o);
/*     */           } 
/*     */         });
/* 189 */     node.add("emote", (JsonElement)emoteSerializer(emote));
/* 190 */     return (JsonElement)node;
/*     */   }
/*     */   
/*     */   public static JsonElement asJson(String str) {
/* 194 */     return JsonParser.parseString(str);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JsonObject emoteSerializer(KeyframeAnimation emote) {
/* 207 */     JsonObject node = new JsonObject();
/* 208 */     node.addProperty("beginTick", Integer.valueOf(emote.beginTick));
/* 209 */     node.addProperty("endTick", Integer.valueOf(emote.endTick));
/* 210 */     node.addProperty("stopTick", Integer.valueOf(emote.stopTick));
/* 211 */     node.addProperty("isLoop", Boolean.valueOf(emote.isInfinite));
/* 212 */     node.addProperty("returnTick", Integer.valueOf(emote.returnToTick));
/* 213 */     node.addProperty("nsfw", Boolean.valueOf(emote.nsfw));
/* 214 */     node.addProperty("degrees", Boolean.valueOf(false));
/* 215 */     if (emote.isEasingBefore) node.addProperty("easeBeforeKeyframe", Boolean.valueOf(true)); 
/* 216 */     node.add("moves", (JsonElement)moveSerializer(emote));
/* 217 */     return node;
/*     */   }
/*     */   
/*     */   public static JsonArray moveSerializer(KeyframeAnimation emote) {
/* 221 */     JsonArray node = new JsonArray();
/* 222 */     emote.getBodyParts().forEach((s, stateCollection) -> bodyPartSerializer(node, stateCollection, s));
/* 223 */     return node;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void bodyPartSerializer(JsonArray node, KeyframeAnimation.StateCollection bodyPart, String partName) {
/* 232 */     partSerialize(node, bodyPart.x, partName);
/* 233 */     partSerialize(node, bodyPart.y, partName);
/* 234 */     partSerialize(node, bodyPart.z, partName);
/* 235 */     partSerialize(node, bodyPart.pitch, partName);
/* 236 */     partSerialize(node, bodyPart.yaw, partName);
/* 237 */     partSerialize(node, bodyPart.roll, partName);
/* 238 */     if (bodyPart.isBendable) {
/* 239 */       partSerialize(node, bodyPart.bend, partName);
/* 240 */       partSerialize(node, bodyPart.bendDirection, partName);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void partSerialize(JsonArray array, KeyframeAnimation.StateCollection.State part, String partName) {
/* 245 */     for (KeyframeAnimation.KeyFrame keyFrame : part.getKeyFrames()) {
/* 246 */       JsonObject node = new JsonObject();
/* 247 */       node.addProperty("tick", Integer.valueOf(keyFrame.tick));
/* 248 */       node.addProperty("easing", keyFrame.ease.toString());
/* 249 */       JsonObject jsonMove = new JsonObject();
/* 250 */       jsonMove.addProperty(part.name, Float.valueOf(keyFrame.value));
/* 251 */       node.add(partName, (JsonElement)jsonMove);
/* 252 */       array.add((JsonElement)node);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\core\data\gson\AnimationJson.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */