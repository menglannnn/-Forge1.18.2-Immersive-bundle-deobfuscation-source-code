/*    */ package dev.kosmx.playerAnim.core.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Vec3d
/*    */   extends Vector3<Double>
/*    */ {
/*    */   public Vec3d(Double x, Double y, Double z) {
/*  9 */     super(x, y, z);
/*    */   }
/*    */   
/*    */   public double squaredDistanceTo(Vec3d vec3d) {
/* 13 */     double a = this.x.doubleValue() - vec3d.x.doubleValue();
/* 14 */     double b = this.y.doubleValue() - vec3d.y.doubleValue();
/* 15 */     double c = this.z.doubleValue() - vec3d.z.doubleValue();
/* 16 */     return a * a + b * b + c * c;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Vec3d scale(double scalar) {
/* 25 */     return new Vec3d(Double.valueOf(getX().doubleValue() * scalar), Double.valueOf(getY().doubleValue() * scalar), Double.valueOf(getZ().doubleValue() * scalar));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Vec3d add(Vec3d other) {
/* 34 */     return new Vec3d(Double.valueOf(getX().doubleValue() + other.getX().doubleValue()), Double.valueOf(getY().doubleValue() + other.getY().doubleValue()), Double.valueOf(getZ().doubleValue() + other.getZ().doubleValue()));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public double dotProduct(Vec3d other) {
/* 43 */     return getX().doubleValue() * other.getX().doubleValue() + getY().doubleValue() * other.getY().doubleValue() + getZ().doubleValue() * other.getZ().doubleValue();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Vec3d crossProduct(Vec3d other) {
/* 52 */     return new Vec3d(
/* 53 */         Double.valueOf(getY().doubleValue() * other.getZ().doubleValue() - getZ().doubleValue() * other.getY().doubleValue()), 
/* 54 */         Double.valueOf(getZ().doubleValue() * other.getX().doubleValue() - getX().doubleValue() * other.getZ().doubleValue()), 
/* 55 */         Double.valueOf(getX().doubleValue() * other.getY().doubleValue() - getY().doubleValue() * other.getX().doubleValue()));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Vec3d subtract(Vec3d rhs) {
/* 66 */     return add(rhs.scale(-1.0D));
/*    */   }
/*    */   
/*    */   public double distanceTo(Vec3d vec3d) {
/* 70 */     return Math.sqrt(squaredDistanceTo(vec3d));
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\cor\\util\Vec3d.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */