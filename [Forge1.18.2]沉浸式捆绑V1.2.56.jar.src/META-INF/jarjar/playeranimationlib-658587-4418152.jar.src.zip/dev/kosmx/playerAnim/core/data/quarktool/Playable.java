package dev.kosmx.playerAnim.core.data.quarktool;

public interface Playable {
  int playForward(int paramInt) throws QuarkParsingError;
  
  int playBackward(int paramInt) throws QuarkParsingError;
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\core\data\quarktool\Playable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */