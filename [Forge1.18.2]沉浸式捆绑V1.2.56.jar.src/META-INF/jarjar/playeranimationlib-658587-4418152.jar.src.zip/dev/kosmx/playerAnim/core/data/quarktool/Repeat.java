/*    */ package dev.kosmx.playerAnim.core.data.quarktool;
/*    */ 
/*    */ public class Repeat
/*    */   implements Playable {
/*    */   protected final Playable playable;
/*    */   protected final int delay;
/*    */   protected int count;
/*    */   
/*    */   public Repeat(Playable parent, int delay, int count) throws QuarkParsingError {
/* 10 */     this.playable = parent;
/* 11 */     if (count < 0 || count > 128) throw new QuarkParsingError(); 
/* 12 */     this.count = count;
/* 13 */     this.delay = delay;
/*    */   }
/*    */   
/*    */   public int playForward(int time) throws QuarkParsingError {
/* 17 */     for (int i = 0; i <= this.count; i++) {
/* 18 */       time = this.playable.playForward(time);
/* 19 */       time += this.delay;
/*    */     } 
/* 21 */     return time;
/*    */   }
/*    */ 
/*    */   
/*    */   public int playBackward(int time) throws QuarkParsingError {
/* 26 */     throw new QuarkParsingError();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\core\data\quarktool\Repeat.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */