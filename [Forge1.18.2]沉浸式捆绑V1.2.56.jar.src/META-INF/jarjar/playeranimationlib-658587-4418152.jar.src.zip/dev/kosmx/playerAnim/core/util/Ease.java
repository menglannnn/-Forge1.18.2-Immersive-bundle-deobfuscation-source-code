/*    */ package dev.kosmx.playerAnim.core.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum Ease
/*    */ {
/*  8 */   CONSTANT(1, f -> 0.0F),
/*  9 */   INSINE(6, Easing::inSine), OUTSINE(7, Easing::outSine), INOUTSINE(8, Easing::inOutSine),
/* 10 */   INCUBIC(9, Easing::inCubic), OUTCUBIC(10, Easing::outCubic), INOUTCUBIC(11, Easing::inOutCubic),
/* 11 */   INQUAD(12, Easing::inQuad), OUTQUAD(13, Easing::outQuad), INOUTQUAD(14, Easing::inOutQuad),
/* 12 */   INQUART(15, Easing::inQuart), OUTQUART(16, Easing::outQuart), INOUTQUART(17, Easing::inOutQuart),
/* 13 */   INQUINT(18, Easing::inQuint), OUTQUINT(19, Easing::outQuint), INOUTQUINT(20, Easing::inOutQuint),
/* 14 */   INEXPO(21, Easing::inExpo), OUTEXPO(22, Easing::outExpo), INOUTEXPO(23, Easing::inOutExpo),
/* 15 */   INCIRC(24, Easing::inCirc), OUTCIRC(25, Easing::outCirc), INOUTCIRC(26, Easing::inOutCirc),
/* 16 */   INBACK(27, Easing::inBack), OUTBACK(28, Easing::outBack), INOUTBACK(29, Easing::inOutBack),
/* 17 */   INELASTIC(30, Easing::inElastic), OUTELASTIC(31, Easing::outElastic), INOUTELASTIC(32, Easing::inOutElastic),
/* 18 */   INBOUNCE(33, Easing::inBounce), OUTBOUNCE(34, Easing::outBack), INOUTBOUNCE(35, Easing::inOutBounce), LINEAR(35, Easing::inOutBounce);
/*    */   
/*    */   static {
/*    */     LINEAR = new Ease("LINEAR", 0, 0, f -> f);
/*    */   }
/*    */   
/*    */   final byte id;
/*    */   private final _F impl;
/*    */   
/*    */   Ease(byte id, _F impl) {
/* 28 */     this.id = id;
/* 29 */     this.impl = impl;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public byte getId() {
/* 41 */     return this.id;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public float invoke(float f) {
/* 50 */     return this.impl.invoke(f);
/*    */   }
/*    */ 
/*    */   
/*    */   public static Ease getEase(byte b) {
/* 55 */     for (Ease ease : values()) {
/* 56 */       if (ease.id == b) return ease; 
/*    */     } 
/* 58 */     return LINEAR;
/*    */   }
/*    */   
/*    */   private static interface _F {
/*    */     float invoke(float param1Float);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\cor\\util\Ease.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */