/*    */ package dev.kosmx.playerAnim.core.data.quarktool;
/*    */ 
/*    */ public class QuarkParsingError extends Exception {
/*    */   final String message;
/*    */   
/*    */   public QuarkParsingError(String message, int i) {
/*  7 */     this.message = "at line " + i + " " + message;
/*    */   }
/*    */   
/*    */   public QuarkParsingError() {
/* 11 */     this.message = null;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\core\data\quarktool\QuarkParsingError.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */