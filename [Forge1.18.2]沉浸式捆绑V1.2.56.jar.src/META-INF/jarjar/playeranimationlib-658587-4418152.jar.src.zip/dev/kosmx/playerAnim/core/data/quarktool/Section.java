/*     */ package dev.kosmx.playerAnim.core.data.quarktool;
/*     */ 
/*     */ import dev.kosmx.playerAnim.core.util.Ease;
/*     */ import dev.kosmx.playerAnim.core.util.Easing;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ public class Section
/*     */   implements Playable {
/*     */   public boolean isForward = true;
/*  12 */   public final List<Playable> elements = new ArrayList<>();
/*     */   private final boolean isParallel;
/*     */   private int line;
/*     */   @Nullable
/*     */   private Playable moveOperator;
/*     */   
/*     */   public Section(QuarkReader animData, int line, List<List<String>> text) throws QuarkParsingError {
/*  19 */     this.line = line;
/*  20 */     this.isParallel = ((String)((List<String>)text.get(line)).get(1)).equals("parallel"); while (true) {
/*     */       Section section; Playable moveOp;
/*  22 */       this.line++;
/*  23 */       if (this.line >= text.size()) throw new QuarkParsingError(); 
/*  24 */       if (((List)text.get(this.line)).size() == 0 || ((String)((List<String>)text.get(this.line)).get(0)).charAt(0) == '#')
/*  25 */         continue;  String id = ((List<String>)text.get(this.line)).get(0);
/*  26 */       List<String> block = text.get(this.line);
/*  27 */       switch (id) {
/*     */         case "end":
/*     */           return;
/*     */         case "section":
/*  31 */           section = new Section(animData, this.line, text);
/*  32 */           moveOp = section.getMoveOperator();
/*  33 */           if (moveOp == null) {
/*  34 */             this.elements.add(section);
/*     */           } else {
/*  36 */             this.elements.add(moveOp);
/*     */           } 
/*  38 */           this.line = section.getLine();
/*     */           continue;
/*     */         case "move":
/*     */           try {
/*     */             Ease ease;
/*  43 */             int pos = block.size() - 3;
/*  44 */             if (block.size() < 4) throw new QuarkParsingError();
/*     */             
/*  46 */             if (block.size() == 5)
/*  47 */             { ease = Easing.easeFromString(block.get(4)); }
/*  48 */             else if (block.size() == 8 || (block.size() == 7 && ((String)block.get(5)).equals("pause")))
/*  49 */             { ease = Easing.easeFromString(block.get(4)); }
/*  50 */             else { ease = Ease.INOUTQUAD; }
/*  51 */              Move move = new Move(animData.getPFromStr(block.get(1)), Float.parseFloat(block.get(3)), (int)(Integer.parseInt(block.get(2)) * 0.02D), ease);
/*  52 */             switch ((String)block.get(pos)) {
/*     */               case "repeat":
/*  54 */                 this.elements.add(new Repeat(move, (int)(Integer.parseInt(block.get(pos + 2)) * 0.02D), Integer.parseInt(block.get(pos + 1))));
/*     */                 continue;
/*     */               case "yoyo":
/*  57 */                 this.elements.add(new Yoyo(move, (int)(Integer.parseInt(block.get(pos + 2)) * 0.02D), Integer.parseInt(block.get(pos + 1))));
/*     */                 continue;
/*     */               case "pause":
/*  60 */                 this.elements.add(new Pauseable(move, (int)(Integer.parseInt(block.get(pos + 1)) * 0.02D)));
/*     */                 continue;
/*     */             } 
/*  63 */             this.elements.add(move);
/*     */           
/*     */           }
/*  66 */           catch (NumberFormatException e) {
/*  67 */             throw new QuarkParsingError("While trying to add move, error has happened: " + e.getMessage(), this.line);
/*     */           } 
/*     */           continue;
/*     */         case "repeat":
/*     */           try {
/*  72 */             setMoveOperator(new Repeat(this, (int)(Integer.parseInt(block.get(2)) * 0.02D), Integer.parseInt(block.get(1))));
/*  73 */           } catch (NumberFormatException e) {
/*  74 */             throw new QuarkParsingError("While trying to add repeat, error has happened: " + e.getMessage(), this.line);
/*     */           } 
/*     */           continue;
/*     */         case "yoyo":
/*     */           try {
/*  79 */             setMoveOperator(new Yoyo(this, (int)(Integer.parseInt(block.get(2)) * 0.02D), Integer.parseInt(block.get(1))));
/*  80 */           } catch (NumberFormatException e) {
/*  81 */             throw new QuarkParsingError("While trying to add yoyo, error has happened: " + e.getMessage(), this.line);
/*     */           } 
/*     */           continue;
/*     */         case "pause":
/*     */           try {
/*  86 */             this.elements.add(new Pause((int)(Integer.parseInt(block.get(1)) * 0.02D)));
/*  87 */           } catch (NumberFormatException e) {
/*  88 */             throw new QuarkParsingError("While trying to add yoyo, error has happened: " + e.getMessage(), this.line);
/*     */           }  continue;
/*     */         case "reset":
/*     */           continue;
/*     */       } 
/*     */       break;
/*     */     } 
/*  95 */     throw new QuarkParsingError();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMoveOperator(Playable object) throws QuarkParsingError {
/* 101 */     if (this.moveOperator != null) throw new QuarkParsingError(); 
/* 102 */     this.moveOperator = object;
/*     */   }
/*     */   
/*     */   public int getLine() {
/* 106 */     return this.line;
/*     */   }
/*     */   
/*     */   private int playObject(Playable object, int time) throws QuarkParsingError {
/* 110 */     return this.isForward ? object.playForward(time) : object.playBackward(time);
/*     */   }
/*     */   
/*     */   private int play(int time) throws QuarkParsingError {
/* 114 */     if (this.isParallel) return playParallel(time); 
/* 115 */     return playSequel(time);
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public Playable getMoveOperator() {
/* 120 */     return this.moveOperator;
/*     */   }
/*     */ 
/*     */   
/*     */   public int playForward(int time) throws QuarkParsingError {
/* 125 */     this.isForward = true;
/* 126 */     return play(time);
/*     */   }
/*     */ 
/*     */   
/*     */   public int playBackward(int time) throws QuarkParsingError {
/* 131 */     this.isForward = false;
/* 132 */     return play(time);
/*     */   }
/*     */   
/*     */   private int playParallel(int time) throws QuarkParsingError {
/* 136 */     int length = time;
/* 137 */     for (Playable object : this.elements) {
/*     */       int t;
/* 139 */       if (this.isForward) { t = object.playForward(time); }
/* 140 */       else { t = object.playBackward(time); }
/* 141 */        if (t > length) length = t; 
/*     */     } 
/* 143 */     return length;
/*     */   }
/*     */   
/*     */   private int playSequel(int time) throws QuarkParsingError {
/* 147 */     int t = time;
/* 148 */     int i = this.isForward ? 0 : (this.elements.size() - 1);
/*     */     while (true) {
/* 150 */       if (i < 0)
/* 151 */         return t; 
/* 152 */       if (i >= this.elements.size()) {
/* 153 */         return t;
/*     */       }
/* 155 */       t = playObject(this.elements.get(i), t);
/* 156 */       i += this.isForward ? 1 : -1;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\core\data\quarktool\Section.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */