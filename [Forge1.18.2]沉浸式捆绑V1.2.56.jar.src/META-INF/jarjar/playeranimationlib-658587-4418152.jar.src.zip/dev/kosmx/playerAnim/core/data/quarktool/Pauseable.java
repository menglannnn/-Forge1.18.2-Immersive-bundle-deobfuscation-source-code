/*    */ package dev.kosmx.playerAnim.core.data.quarktool;
/*    */ 
/*    */ public class Pauseable
/*    */   implements Playable {
/*    */   private final Playable playable;
/*    */   private final int len;
/*    */   
/*    */   public Pauseable(Playable playable, int len) {
/*  9 */     this.playable = playable;
/* 10 */     this.len = len;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int playForward(int time) throws QuarkParsingError {
/* 16 */     return this.playable.playForward(time + this.len);
/*    */   }
/*    */ 
/*    */   
/*    */   public int playBackward(int time) throws QuarkParsingError {
/* 21 */     return this.playable.playBackward(time) + this.len;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\core\data\quarktool\Pauseable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */