/*    */ package dev.kosmx.playerAnim.core.impl.event;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Event<T>
/*    */ {
/* 11 */   final ArrayList<T> listeners = new ArrayList<>();
/*    */   final Invoker<T> _invoker;
/*    */   
/*    */   public Event(Class<T> clazz, Invoker<T> invoker) {
/* 15 */     this._invoker = invoker;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final T invoker() {
/* 25 */     return this._invoker.invoker(this.listeners);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void register(T listener) {
/* 34 */     if (listener == null) throw new NullPointerException("listener can not be null"); 
/* 35 */     this.listeners.add(listener);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void unregister(T listener) {
/* 43 */     this.listeners.remove(listener);
/*    */   }
/*    */   
/*    */   @FunctionalInterface
/*    */   public static interface Invoker<T> {
/*    */     T invoker(Iterable<T> param1Iterable);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\core\impl\event\Event.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */