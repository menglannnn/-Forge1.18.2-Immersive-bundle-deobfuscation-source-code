/*    */ package dev.kosmx.playerAnim.forge;
/*    */ import dev.kosmx.playerAnim.impl.Helper;
/*    */ import dev.kosmx.playerAnim.impl.compat.skinLayers.SkinLayersTransformer;
/*    */ import dev.kosmx.playerAnim.minecraftApi.PlayerAnimationRegistry;
/*    */ import net.minecraft.server.packs.resources.PreparableReloadListener;
/*    */ import net.minecraft.server.packs.resources.ResourceManager;
/*    */ import net.minecraftforge.api.distmarker.Dist;
/*    */ import net.minecraftforge.client.event.RegisterClientReloadListenersEvent;
/*    */ import net.minecraftforge.eventbus.api.SubscribeEvent;
/*    */ import net.minecraftforge.fml.ModList;
/*    */ import net.minecraftforge.fml.common.Mod;
/*    */ import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
/*    */ import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ @EventBusSubscriber(modid = "playeranimator", bus = Mod.EventBusSubscriber.Bus.MOD, value = {Dist.CLIENT})
/*    */ public class ForgeClientEvent {
/*    */   @SubscribeEvent
/*    */   public static void clientSetup(FMLClientSetupEvent event) {
/* 20 */     if (Helper.isBendEnabled() && ModList.get().isLoaded("skinlayers3d")) {
/*    */       try {
/* 22 */         SkinLayersTransformer.init(ForgeModInterface.LOGGER);
/* 23 */       } catch (Error e) {
/* 24 */         ForgeModInterface.LOGGER.error("Failed to initialize 3D skin layers compat: " + e.getMessage());
/*    */       } 
/*    */     }
/*    */   }
/*    */   
/*    */   @SubscribeEvent
/*    */   public static void resourceLoadingListener(@NotNull RegisterClientReloadListenersEvent event) {
/* 31 */     event.registerReloadListener((PreparableReloadListener)(manager -> PlayerAnimationRegistry.resourceLoaderCallback(manager, ForgeModInterface.LOGGER)));
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\forge\ForgeClientEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */