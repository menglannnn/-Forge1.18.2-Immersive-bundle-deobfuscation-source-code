/*    */ package dev.kosmx.playerAnim.forge;
/*    */ 
/*    */ import net.minecraftforge.fml.common.Mod;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ @Mod("playeranimator")
/*    */ public class ForgeModInterface
/*    */ {
/* 10 */   public static final Logger LOGGER = LoggerFactory.getLogger("player-animator");
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\playeranimationlib-658587-4418152.jar!\dev\kosmx\playerAnim\forge\ForgeModInterface.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */