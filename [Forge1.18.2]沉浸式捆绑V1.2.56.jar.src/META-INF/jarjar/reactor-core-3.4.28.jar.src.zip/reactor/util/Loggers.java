/*     */ package reactor.util;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.WeakHashMap;
/*     */ import java.util.function.Function;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import java.util.regex.Matcher;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Loggers
/*     */ {
/*     */   public static final String FALLBACK_PROPERTY = "reactor.logging.fallback";
/*     */   private static Function<String, ? extends Logger> LOGGER_FACTORY;
/*     */   
/*     */   static {
/*  56 */     resetLoggerFactory();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void resetLoggerFactory() {
/*     */     try {
/*  72 */       useSl4jLoggers();
/*     */     }
/*  74 */     catch (Throwable t) {
/*  75 */       if (isFallbackToJdk()) {
/*  76 */         useJdkLoggers();
/*     */       } else {
/*     */         
/*  79 */         useConsoleLoggers();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean isFallbackToJdk() {
/*  92 */     return "JDK".equalsIgnoreCase(System.getProperty("reactor.logging.fallback"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void useConsoleLoggers() {
/* 106 */     String name = Loggers.class.getName();
/* 107 */     Function<String, Logger> loggerFactory = new ConsoleLoggerFactory(false);
/* 108 */     LOGGER_FACTORY = loggerFactory;
/* 109 */     ((Logger)loggerFactory.apply(name)).debug("Using Console logging");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void useVerboseConsoleLoggers() {
/* 122 */     String name = Loggers.class.getName();
/* 123 */     Function<String, Logger> loggerFactory = new ConsoleLoggerFactory(true);
/* 124 */     LOGGER_FACTORY = loggerFactory;
/* 125 */     ((Logger)loggerFactory.apply(name)).debug("Using Verbose Console logging");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void useCustomLoggers(Function<String, ? extends Logger> loggerFactory) {
/* 145 */     String name = Loggers.class.getName();
/* 146 */     LOGGER_FACTORY = loggerFactory;
/* 147 */     ((Logger)loggerFactory.apply(name)).debug("Using custom logging");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void useJdkLoggers() {
/* 158 */     String name = Loggers.class.getName();
/* 159 */     Function<String, Logger> loggerFactory = new JdkLoggerFactory();
/* 160 */     LOGGER_FACTORY = loggerFactory;
/* 161 */     ((Logger)loggerFactory.apply(name)).debug("Using JDK logging framework");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void useSl4jLoggers() {
/* 173 */     String name = Loggers.class.getName();
/* 174 */     Function<String, Logger> loggerFactory = new Slf4JLoggerFactory();
/* 175 */     LOGGER_FACTORY = loggerFactory;
/* 176 */     ((Logger)loggerFactory.apply(name)).debug("Using Slf4j logging framework");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Logger getLogger(String name) {
/* 191 */     return LOGGER_FACTORY.apply(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Logger getLogger(Class<?> cls) {
/* 203 */     return LOGGER_FACTORY.apply(cls.getName());
/*     */   }
/*     */   
/*     */   private static class Slf4JLoggerFactory implements Function<String, Logger> {
/*     */     private Slf4JLoggerFactory() {}
/*     */     
/*     */     public Logger apply(String name) {
/* 210 */       return new Loggers.Slf4JLogger(LoggerFactory.getLogger(name));
/*     */     }
/*     */   }
/*     */   
/*     */   private static class Slf4JLogger
/*     */     implements Logger {
/*     */     private final Logger logger;
/*     */     
/*     */     public Slf4JLogger(Logger logger) {
/* 219 */       this.logger = logger;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getName() {
/* 224 */       return this.logger.getName();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isTraceEnabled() {
/* 229 */       return this.logger.isTraceEnabled();
/*     */     }
/*     */ 
/*     */     
/*     */     public void trace(String msg) {
/* 234 */       this.logger.trace(msg);
/*     */     }
/*     */ 
/*     */     
/*     */     public void trace(String format, Object... arguments) {
/* 239 */       this.logger.trace(format, arguments);
/*     */     }
/*     */ 
/*     */     
/*     */     public void trace(String msg, Throwable t) {
/* 244 */       this.logger.trace(msg, t);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isDebugEnabled() {
/* 249 */       return this.logger.isDebugEnabled();
/*     */     }
/*     */ 
/*     */     
/*     */     public void debug(String msg) {
/* 254 */       this.logger.debug(msg);
/*     */     }
/*     */ 
/*     */     
/*     */     public void debug(String format, Object... arguments) {
/* 259 */       this.logger.debug(format, arguments);
/*     */     }
/*     */ 
/*     */     
/*     */     public void debug(String msg, Throwable t) {
/* 264 */       this.logger.debug(msg, t);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isInfoEnabled() {
/* 269 */       return this.logger.isInfoEnabled();
/*     */     }
/*     */ 
/*     */     
/*     */     public void info(String msg) {
/* 274 */       this.logger.info(msg);
/*     */     }
/*     */ 
/*     */     
/*     */     public void info(String format, Object... arguments) {
/* 279 */       this.logger.info(format, arguments);
/*     */     }
/*     */ 
/*     */     
/*     */     public void info(String msg, Throwable t) {
/* 284 */       this.logger.info(msg, t);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isWarnEnabled() {
/* 289 */       return this.logger.isWarnEnabled();
/*     */     }
/*     */ 
/*     */     
/*     */     public void warn(String msg) {
/* 294 */       this.logger.warn(msg);
/*     */     }
/*     */ 
/*     */     
/*     */     public void warn(String format, Object... arguments) {
/* 299 */       this.logger.warn(format, arguments);
/*     */     }
/*     */ 
/*     */     
/*     */     public void warn(String msg, Throwable t) {
/* 304 */       this.logger.warn(msg, t);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isErrorEnabled() {
/* 309 */       return this.logger.isErrorEnabled();
/*     */     }
/*     */ 
/*     */     
/*     */     public void error(String msg) {
/* 314 */       this.logger.error(msg);
/*     */     }
/*     */ 
/*     */     
/*     */     public void error(String format, Object... arguments) {
/* 319 */       this.logger.error(format, arguments);
/*     */     }
/*     */ 
/*     */     
/*     */     public void error(String msg, Throwable t) {
/* 324 */       this.logger.error(msg, t);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class JdkLogger
/*     */     implements Logger
/*     */   {
/*     */     private final Logger logger;
/*     */ 
/*     */     
/*     */     public JdkLogger(Logger logger) {
/* 336 */       this.logger = logger;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getName() {
/* 341 */       return this.logger.getName();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isTraceEnabled() {
/* 346 */       return this.logger.isLoggable(Level.FINEST);
/*     */     }
/*     */ 
/*     */     
/*     */     public void trace(String msg) {
/* 351 */       this.logger.log(Level.FINEST, msg);
/*     */     }
/*     */ 
/*     */     
/*     */     public void trace(String format, Object... arguments) {
/* 356 */       this.logger.log(Level.FINEST, format(format, arguments));
/*     */     }
/*     */ 
/*     */     
/*     */     public void trace(String msg, Throwable t) {
/* 361 */       this.logger.log(Level.FINEST, msg, t);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isDebugEnabled() {
/* 366 */       return this.logger.isLoggable(Level.FINE);
/*     */     }
/*     */ 
/*     */     
/*     */     public void debug(String msg) {
/* 371 */       this.logger.log(Level.FINE, msg);
/*     */     }
/*     */ 
/*     */     
/*     */     public void debug(String format, Object... arguments) {
/* 376 */       this.logger.log(Level.FINE, format(format, arguments));
/*     */     }
/*     */ 
/*     */     
/*     */     public void debug(String msg, Throwable t) {
/* 381 */       this.logger.log(Level.FINE, msg, t);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isInfoEnabled() {
/* 386 */       return this.logger.isLoggable(Level.INFO);
/*     */     }
/*     */ 
/*     */     
/*     */     public void info(String msg) {
/* 391 */       this.logger.log(Level.INFO, msg);
/*     */     }
/*     */ 
/*     */     
/*     */     public void info(String format, Object... arguments) {
/* 396 */       this.logger.log(Level.INFO, format(format, arguments));
/*     */     }
/*     */ 
/*     */     
/*     */     public void info(String msg, Throwable t) {
/* 401 */       this.logger.log(Level.INFO, msg, t);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isWarnEnabled() {
/* 406 */       return this.logger.isLoggable(Level.WARNING);
/*     */     }
/*     */ 
/*     */     
/*     */     public void warn(String msg) {
/* 411 */       this.logger.log(Level.WARNING, msg);
/*     */     }
/*     */ 
/*     */     
/*     */     public void warn(String format, Object... arguments) {
/* 416 */       this.logger.log(Level.WARNING, format(format, arguments));
/*     */     }
/*     */ 
/*     */     
/*     */     public void warn(String msg, Throwable t) {
/* 421 */       this.logger.log(Level.WARNING, msg, t);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isErrorEnabled() {
/* 426 */       return this.logger.isLoggable(Level.SEVERE);
/*     */     }
/*     */ 
/*     */     
/*     */     public void error(String msg) {
/* 431 */       this.logger.log(Level.SEVERE, msg);
/*     */     }
/*     */ 
/*     */     
/*     */     public void error(String format, Object... arguments) {
/* 436 */       this.logger.log(Level.SEVERE, format(format, arguments));
/*     */     }
/*     */ 
/*     */     
/*     */     public void error(String msg, Throwable t) {
/* 441 */       this.logger.log(Level.SEVERE, msg, t);
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     final String format(@Nullable String from, @Nullable Object... arguments) {
/* 446 */       if (from != null) {
/* 447 */         String computed = from;
/* 448 */         if (arguments != null && arguments.length != 0) {
/* 449 */           for (Object argument : arguments) {
/* 450 */             computed = computed.replaceFirst("\\{\\}", Matcher.quoteReplacement(String.valueOf(argument)));
/*     */           }
/*     */         }
/* 453 */         return computed;
/*     */       } 
/* 455 */       return null;
/*     */     }
/*     */   }
/*     */   
/*     */   private static class JdkLoggerFactory implements Function<String, Logger> {
/*     */     private JdkLoggerFactory() {}
/*     */     
/*     */     public Logger apply(String name) {
/* 463 */       return new Loggers.JdkLogger(Logger.getLogger(name));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class ConsoleLogger
/*     */     implements Logger
/*     */   {
/*     */     private final Loggers.ConsoleLoggerKey identifier;
/*     */     
/*     */     private final PrintStream err;
/*     */     
/*     */     private final PrintStream log;
/*     */     
/*     */     ConsoleLogger(Loggers.ConsoleLoggerKey identifier, PrintStream log, PrintStream err) {
/* 478 */       this.identifier = identifier;
/* 479 */       this.log = log;
/* 480 */       this.err = err;
/*     */     }
/*     */     
/*     */     ConsoleLogger(String name, PrintStream log, PrintStream err, boolean verbose) {
/* 484 */       this(new Loggers.ConsoleLoggerKey(name, verbose, null), log, err);
/*     */     }
/*     */     
/*     */     ConsoleLogger(Loggers.ConsoleLoggerKey identifier) {
/* 488 */       this(identifier, System.out, System.err);
/*     */     }
/*     */ 
/*     */     
/*     */     public String getName() {
/* 493 */       return this.identifier.name;
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     final String format(@Nullable String from, @Nullable Object... arguments) {
/* 498 */       if (from != null) {
/* 499 */         String computed = from;
/* 500 */         if (arguments != null && arguments.length != 0) {
/* 501 */           for (Object argument : arguments) {
/* 502 */             computed = computed.replaceFirst("\\{\\}", Matcher.quoteReplacement(String.valueOf(argument)));
/*     */           }
/*     */         }
/* 505 */         return computed;
/*     */       } 
/* 507 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isTraceEnabled() {
/* 512 */       return this.identifier.verbose;
/*     */     }
/*     */ 
/*     */     
/*     */     public synchronized void trace(String msg) {
/* 517 */       if (!this.identifier.verbose) {
/*     */         return;
/*     */       }
/* 520 */       this.log.format("[TRACE] (%s) %s\n", new Object[] { Thread.currentThread().getName(), msg });
/*     */     }
/*     */ 
/*     */     
/*     */     public synchronized void trace(String format, Object... arguments) {
/* 525 */       if (!this.identifier.verbose) {
/*     */         return;
/*     */       }
/* 528 */       this.log.format("[TRACE] (%s) %s\n", new Object[] { Thread.currentThread().getName(), format(format, arguments) });
/*     */     }
/*     */     
/*     */     public synchronized void trace(String msg, Throwable t) {
/* 532 */       if (!this.identifier.verbose) {
/*     */         return;
/*     */       }
/* 535 */       this.log.format("[TRACE] (%s) %s - %s\n", new Object[] { Thread.currentThread().getName(), msg, t });
/* 536 */       t.printStackTrace(this.log);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isDebugEnabled() {
/* 541 */       return this.identifier.verbose;
/*     */     }
/*     */ 
/*     */     
/*     */     public synchronized void debug(String msg) {
/* 546 */       if (!this.identifier.verbose) {
/*     */         return;
/*     */       }
/* 549 */       this.log.format("[DEBUG] (%s) %s\n", new Object[] { Thread.currentThread().getName(), msg });
/*     */     }
/*     */ 
/*     */     
/*     */     public synchronized void debug(String format, Object... arguments) {
/* 554 */       if (!this.identifier.verbose) {
/*     */         return;
/*     */       }
/* 557 */       this.log.format("[DEBUG] (%s) %s\n", new Object[] { Thread.currentThread().getName(), format(format, arguments) });
/*     */     }
/*     */ 
/*     */     
/*     */     public synchronized void debug(String msg, Throwable t) {
/* 562 */       if (!this.identifier.verbose) {
/*     */         return;
/*     */       }
/* 565 */       this.log.format("[DEBUG] (%s) %s - %s\n", new Object[] { Thread.currentThread().getName(), msg, t });
/* 566 */       t.printStackTrace(this.log);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isInfoEnabled() {
/* 571 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     public synchronized void info(String msg) {
/* 576 */       this.log.format("[ INFO] (%s) %s\n", new Object[] { Thread.currentThread().getName(), msg });
/*     */     }
/*     */ 
/*     */     
/*     */     public synchronized void info(String format, Object... arguments) {
/* 581 */       this.log.format("[ INFO] (%s) %s\n", new Object[] { Thread.currentThread().getName(), format(format, arguments) });
/*     */     }
/*     */ 
/*     */     
/*     */     public synchronized void info(String msg, Throwable t) {
/* 586 */       this.log.format("[ INFO] (%s) %s - %s\n", new Object[] { Thread.currentThread().getName(), msg, t });
/* 587 */       t.printStackTrace(this.log);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isWarnEnabled() {
/* 592 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     public synchronized void warn(String msg) {
/* 597 */       this.err.format("[ WARN] (%s) %s\n", new Object[] { Thread.currentThread().getName(), msg });
/*     */     }
/*     */ 
/*     */     
/*     */     public synchronized void warn(String format, Object... arguments) {
/* 602 */       this.err.format("[ WARN] (%s) %s\n", new Object[] { Thread.currentThread().getName(), format(format, arguments) });
/*     */     }
/*     */ 
/*     */     
/*     */     public synchronized void warn(String msg, Throwable t) {
/* 607 */       this.err.format("[ WARN] (%s) %s - %s\n", new Object[] { Thread.currentThread().getName(), msg, t });
/* 608 */       t.printStackTrace(this.err);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isErrorEnabled() {
/* 613 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     public synchronized void error(String msg) {
/* 618 */       this.err.format("[ERROR] (%s) %s\n", new Object[] { Thread.currentThread().getName(), msg });
/*     */     }
/*     */ 
/*     */     
/*     */     public synchronized void error(String format, Object... arguments) {
/* 623 */       this.err.format("[ERROR] (%s) %s\n", new Object[] { Thread.currentThread().getName(), format(format, arguments) });
/*     */     }
/*     */ 
/*     */     
/*     */     public synchronized void error(String msg, Throwable t) {
/* 628 */       this.err.format("[ERROR] (%s) %s - %s\n", new Object[] { Thread.currentThread().getName(), msg, t });
/* 629 */       t.printStackTrace(this.err);
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 634 */       return "ConsoleLogger[name=" + getName() + ", verbose=" + this.identifier.verbose + "]";
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class ConsoleLoggerKey
/*     */   {
/*     */     private final String name;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final boolean verbose;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private ConsoleLoggerKey(String name, boolean verbose) {
/* 655 */       this.name = name;
/* 656 */       this.verbose = verbose;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/* 661 */       if (this == o) {
/* 662 */         return true;
/*     */       }
/* 664 */       if (o == null || getClass() != o.getClass()) {
/* 665 */         return false;
/*     */       }
/* 667 */       ConsoleLoggerKey key = (ConsoleLoggerKey)o;
/* 668 */       return (this.verbose == key.verbose && Objects.equals(this.name, key.name));
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 673 */       return Objects.hash(new Object[] { this.name, Boolean.valueOf(this.verbose) });
/*     */     }
/*     */   }
/*     */   
/*     */   static final class ConsoleLoggerFactory
/*     */     implements Function<String, Logger> {
/* 679 */     private static final Map<Loggers.ConsoleLoggerKey, WeakReference<Logger>> consoleLoggers = new WeakHashMap<>();
/*     */     
/*     */     final boolean verbose;
/*     */ 
/*     */     
/*     */     ConsoleLoggerFactory(boolean verbose) {
/* 685 */       this.verbose = verbose;
/*     */     }
/*     */ 
/*     */     
/*     */     public Logger apply(String name) {
/* 690 */       Loggers.ConsoleLoggerKey key = new Loggers.ConsoleLoggerKey(name, this.verbose);
/* 691 */       synchronized (consoleLoggers) {
/* 692 */         WeakReference<Logger> ref = consoleLoggers.get(key);
/* 693 */         Logger cached = (ref == null) ? null : ref.get();
/* 694 */         if (cached == null) {
/* 695 */           cached = new Loggers.ConsoleLogger(key);
/* 696 */           consoleLoggers.put(key, new WeakReference<>(cached));
/*     */         } 
/*     */         
/* 699 */         return cached;
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reacto\\util\Loggers.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */