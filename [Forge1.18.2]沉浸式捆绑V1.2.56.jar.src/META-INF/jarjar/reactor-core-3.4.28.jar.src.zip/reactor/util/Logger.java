/*     */ package reactor.util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface Logger
/*     */ {
/*     */   String getName();
/*     */   
/*     */   boolean isTraceEnabled();
/*     */   
/*     */   void trace(String paramString);
/*     */   
/*     */   void trace(String paramString, Object... paramVarArgs);
/*     */   
/*     */   void trace(String paramString, Throwable paramThrowable);
/*     */   
/*     */   boolean isDebugEnabled();
/*     */   
/*     */   void debug(String paramString);
/*     */   
/*     */   void debug(String paramString, Object... paramVarArgs);
/*     */   
/*     */   void debug(String paramString, Throwable paramThrowable);
/*     */   
/*     */   boolean isInfoEnabled();
/*     */   
/*     */   void info(String paramString);
/*     */   
/*     */   void info(String paramString, Object... paramVarArgs);
/*     */   
/*     */   void info(String paramString, Throwable paramThrowable);
/*     */   
/*     */   default void infoOrDebug(ChoiceOfMessageSupplier messageSupplier) {
/* 176 */     if (isDebugEnabled()) {
/* 177 */       debug(messageSupplier.get(true));
/*     */     }
/* 179 */     else if (isInfoEnabled()) {
/* 180 */       info(messageSupplier.get(false));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void infoOrDebug(ChoiceOfMessageSupplier messageSupplier, Throwable cause) {
/* 199 */     if (isDebugEnabled()) {
/* 200 */       debug(messageSupplier.get(true), cause);
/*     */     }
/* 202 */     else if (isInfoEnabled()) {
/* 203 */       info(messageSupplier.get(false), cause);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isWarnEnabled();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void warn(String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void warn(String paramString, Object... paramVarArgs);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void warn(String paramString, Throwable paramThrowable);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void warnOrDebug(ChoiceOfMessageSupplier messageSupplier) {
/* 258 */     if (isDebugEnabled()) {
/* 259 */       debug(messageSupplier.get(true));
/*     */     }
/* 261 */     else if (isWarnEnabled()) {
/* 262 */       warn(messageSupplier.get(false));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void warnOrDebug(ChoiceOfMessageSupplier messageSupplier, Throwable cause) {
/* 281 */     if (isDebugEnabled()) {
/* 282 */       debug(messageSupplier.get(true), cause);
/*     */     }
/* 284 */     else if (isWarnEnabled()) {
/* 285 */       warn(messageSupplier.get(false), cause);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isErrorEnabled();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void error(String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void error(String paramString, Object... paramVarArgs);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void error(String paramString, Throwable paramThrowable);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void errorOrDebug(ChoiceOfMessageSupplier messageSupplier) {
/* 340 */     if (isDebugEnabled()) {
/* 341 */       debug(messageSupplier.get(true));
/*     */     }
/* 343 */     else if (isErrorEnabled()) {
/* 344 */       error(messageSupplier.get(false));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void errorOrDebug(ChoiceOfMessageSupplier messageSupplier, Throwable cause) {
/* 363 */     if (isDebugEnabled()) {
/* 364 */       debug(messageSupplier.get(true), cause);
/*     */     }
/* 366 */     else if (isErrorEnabled()) {
/* 367 */       error(messageSupplier.get(false), cause);
/*     */     } 
/*     */   }
/*     */   
/*     */   @FunctionalInterface
/*     */   public static interface ChoiceOfMessageSupplier {
/*     */     String get(boolean param1Boolean);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reacto\\util\Logger.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */