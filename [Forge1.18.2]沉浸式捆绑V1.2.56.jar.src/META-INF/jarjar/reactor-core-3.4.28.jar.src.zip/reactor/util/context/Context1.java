/*    */ package reactor.util.context;
/*    */ 
/*    */ import java.util.AbstractMap;
/*    */ import java.util.Map;
/*    */ import java.util.NoSuchElementException;
/*    */ import java.util.Objects;
/*    */ import java.util.function.BiConsumer;
/*    */ import java.util.stream.Stream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class Context1
/*    */   implements CoreContext
/*    */ {
/*    */   final Object key;
/*    */   final Object value;
/*    */   
/*    */   Context1(Object key, Object value) {
/* 32 */     this.key = Objects.requireNonNull(key, "key");
/* 33 */     this.value = Objects.requireNonNull(value, "value");
/*    */   }
/*    */ 
/*    */   
/*    */   public Context put(Object key, Object value) {
/* 38 */     Objects.requireNonNull(key, "key");
/* 39 */     Objects.requireNonNull(value, "value");
/*    */     
/* 41 */     if (this.key.equals(key)) {
/* 42 */       return new Context1(key, value);
/*    */     }
/*    */     
/* 45 */     return new Context2(this.key, this.value, key, value);
/*    */   }
/*    */ 
/*    */   
/*    */   public Context delete(Object key) {
/* 50 */     Objects.requireNonNull(key, "key");
/* 51 */     if (this.key.equals(key)) {
/* 52 */       return Context.empty();
/*    */     }
/* 54 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean hasKey(Object key) {
/* 59 */     return this.key.equals(key);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public <T> T get(Object key) {
/* 65 */     if (hasKey(key)) {
/* 66 */       return (T)this.value;
/*    */     }
/* 68 */     throw new NoSuchElementException("Context does not contain key: " + key);
/*    */   }
/*    */ 
/*    */   
/*    */   public Stream<Map.Entry<Object, Object>> stream() {
/* 73 */     return Stream.of(new AbstractMap.SimpleImmutableEntry<>(this.key, this.value));
/*    */   }
/*    */ 
/*    */   
/*    */   public void forEach(BiConsumer<Object, Object> action) {
/* 78 */     action.accept(this.key, this.value);
/*    */   }
/*    */ 
/*    */   
/*    */   public Context putAllInto(Context base) {
/* 83 */     return base.put(this.key, this.value);
/*    */   }
/*    */ 
/*    */   
/*    */   public void unsafePutAllInto(ContextN other) {
/* 88 */     other.accept(this.key, this.value);
/*    */   }
/*    */ 
/*    */   
/*    */   public int size() {
/* 93 */     return 1;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 98 */     return "Context1{" + this.key + '=' + this.value + '}';
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reacto\\util\context\Context1.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */