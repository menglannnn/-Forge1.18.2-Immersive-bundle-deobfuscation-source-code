/*     */ package reactor.util.context;
/*     */ 
/*     */ import java.util.AbstractMap;
/*     */ import java.util.Map;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Objects;
/*     */ import java.util.function.BiConsumer;
/*     */ import java.util.stream.Stream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class Context3
/*     */   implements CoreContext
/*     */ {
/*     */   final Object key1;
/*     */   final Object value1;
/*     */   final Object key2;
/*     */   final Object value2;
/*     */   final Object key3;
/*     */   final Object value3;
/*     */   
/*     */   Context3(Object key1, Object value1, Object key2, Object value2, Object key3, Object value3) {
/*  38 */     if (Objects.<T>requireNonNull((T)key1, "key1").equals(key2) || key1.equals(key3)) {
/*  39 */       throw new IllegalArgumentException("Key #1 (" + key1 + ") is duplicated");
/*     */     }
/*  41 */     if (Objects.<T>requireNonNull((T)key2, "key2").equals(key3)) {
/*  42 */       throw new IllegalArgumentException("Key #2 (" + key2 + ") is duplicated");
/*     */     }
/*  44 */     this.key1 = key1;
/*  45 */     this.value1 = Objects.requireNonNull(value1, "value1");
/*  46 */     this.key2 = key2;
/*  47 */     this.value2 = Objects.requireNonNull(value2, "value2");
/*  48 */     this.key3 = Objects.requireNonNull(key3, "key3");
/*  49 */     this.value3 = Objects.requireNonNull(value3, "value3");
/*     */   }
/*     */ 
/*     */   
/*     */   public Context put(Object key, Object value) {
/*  54 */     Objects.requireNonNull(key, "key");
/*  55 */     Objects.requireNonNull(value, "value");
/*     */     
/*  57 */     if (this.key1.equals(key)) {
/*  58 */       return new Context3(key, value, this.key2, this.value2, this.key3, this.value3);
/*     */     }
/*     */     
/*  61 */     if (this.key2.equals(key)) {
/*  62 */       return new Context3(this.key1, this.value1, key, value, this.key3, this.value3);
/*     */     }
/*     */     
/*  65 */     if (this.key3.equals(key)) {
/*  66 */       return new Context3(this.key1, this.value1, this.key2, this.value2, key, value);
/*     */     }
/*     */     
/*  69 */     return new Context4(this.key1, this.value1, this.key2, this.value2, this.key3, this.value3, key, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public Context delete(Object key) {
/*  74 */     Objects.requireNonNull(key, "key");
/*     */     
/*  76 */     if (this.key1.equals(key)) {
/*  77 */       return new Context2(this.key2, this.value2, this.key3, this.value3);
/*     */     }
/*     */     
/*  80 */     if (this.key2.equals(key)) {
/*  81 */       return new Context2(this.key1, this.value1, this.key3, this.value3);
/*     */     }
/*     */     
/*  84 */     if (this.key3.equals(key)) {
/*  85 */       return new Context2(this.key1, this.value1, this.key2, this.value2);
/*     */     }
/*     */     
/*  88 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasKey(Object key) {
/*  93 */     return (this.key1.equals(key) || this.key2.equals(key) || this.key3.equals(key));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T get(Object key) {
/*  99 */     if (this.key1.equals(key)) {
/* 100 */       return (T)this.value1;
/*     */     }
/* 102 */     if (this.key2.equals(key)) {
/* 103 */       return (T)this.value2;
/*     */     }
/* 105 */     if (this.key3.equals(key)) {
/* 106 */       return (T)this.value3;
/*     */     }
/* 108 */     throw new NoSuchElementException("Context does not contain key: " + key);
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/* 113 */     return 3;
/*     */   }
/*     */ 
/*     */   
/*     */   public Stream<Map.Entry<Object, Object>> stream() {
/* 118 */     return Stream.of((Map.Entry<Object, Object>[])new Map.Entry[] { new AbstractMap.SimpleImmutableEntry<>(this.key1, this.value1), new AbstractMap.SimpleImmutableEntry<>(this.key2, this.value2), new AbstractMap.SimpleImmutableEntry<>(this.key3, this.value3) });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void forEach(BiConsumer<Object, Object> action) {
/* 126 */     action.accept(this.key1, this.value1);
/* 127 */     action.accept(this.key2, this.value2);
/* 128 */     action.accept(this.key3, this.value3);
/*     */   }
/*     */ 
/*     */   
/*     */   public Context putAllInto(Context base) {
/* 133 */     return base
/* 134 */       .put(this.key1, this.value1)
/* 135 */       .put(this.key2, this.value2)
/* 136 */       .put(this.key3, this.value3);
/*     */   }
/*     */ 
/*     */   
/*     */   public void unsafePutAllInto(ContextN other) {
/* 141 */     other.accept(this.key1, this.value1);
/* 142 */     other.accept(this.key2, this.value2);
/* 143 */     other.accept(this.key3, this.value3);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 148 */     return "Context3{" + this.key1 + '=' + this.value1 + ", " + this.key2 + '=' + this.value2 + ", " + this.key3 + '=' + this.value3 + '}';
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reacto\\util\context\Context3.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */