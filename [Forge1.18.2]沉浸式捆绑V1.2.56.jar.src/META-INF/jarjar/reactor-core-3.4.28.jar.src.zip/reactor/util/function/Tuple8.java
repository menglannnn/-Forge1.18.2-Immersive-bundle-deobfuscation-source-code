/*     */ package reactor.util.function;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.function.Function;
/*     */ import reactor.util.annotation.NonNull;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Tuple8<T1, T2, T3, T4, T5, T6, T7, T8>
/*     */   extends Tuple7<T1, T2, T3, T4, T5, T6, T7>
/*     */ {
/*     */   private static final long serialVersionUID = -8746796646535446242L;
/*     */   @NonNull
/*     */   final T8 t8;
/*     */   
/*     */   Tuple8(T1 t1, T2 t2, T3 t3, T4 t4, T5 t5, T6 t6, T7 t7, T8 t8) {
/*  47 */     super(t1, t2, t3, t4, t5, t6, t7);
/*  48 */     this.t8 = Objects.requireNonNull(t8, "t8");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T8 getT8() {
/*  57 */     return this.t8;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <R> Tuple8<R, T2, T3, T4, T5, T6, T7, T8> mapT1(Function<T1, R> mapper) {
/*  69 */     return new Tuple8((T1)mapper.apply(this.t1), this.t2, this.t3, this.t4, this.t5, this.t6, this.t7, this.t8);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <R> Tuple8<T1, R, T3, T4, T5, T6, T7, T8> mapT2(Function<T2, R> mapper) {
/*  81 */     return new Tuple8(this.t1, (T2)mapper.apply(this.t2), this.t3, this.t4, this.t5, this.t6, this.t7, this.t8);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <R> Tuple8<T1, T2, R, T4, T5, T6, T7, T8> mapT3(Function<T3, R> mapper) {
/*  93 */     return new Tuple8(this.t1, this.t2, (T3)mapper.apply(this.t3), this.t4, this.t5, this.t6, this.t7, this.t8);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <R> Tuple8<T1, T2, T3, R, T5, T6, T7, T8> mapT4(Function<T4, R> mapper) {
/* 105 */     return new Tuple8(this.t1, this.t2, this.t3, (T4)mapper.apply(this.t4), this.t5, this.t6, this.t7, this.t8);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <R> Tuple8<T1, T2, T3, T4, R, T6, T7, T8> mapT5(Function<T5, R> mapper) {
/* 117 */     return new Tuple8(this.t1, this.t2, this.t3, this.t4, (T5)mapper.apply(this.t5), this.t6, this.t7, this.t8);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <R> Tuple8<T1, T2, T3, T4, T5, R, T7, T8> mapT6(Function<T6, R> mapper) {
/* 129 */     return new Tuple8(this.t1, this.t2, this.t3, this.t4, this.t5, (T6)mapper.apply(this.t6), this.t7, this.t8);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <R> Tuple8<T1, T2, T3, T4, T5, T6, R, T8> mapT7(Function<T7, R> mapper) {
/* 141 */     return new Tuple8(this.t1, this.t2, this.t3, this.t4, this.t5, this.t6, (T7)mapper.apply(this.t7), this.t8);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <R> Tuple8<T1, T2, T3, T4, T5, T6, T7, R> mapT8(Function<T8, R> mapper) {
/* 153 */     return new Tuple8(this.t1, this.t2, this.t3, this.t4, this.t5, this.t6, this.t7, (T8)mapper.apply(this.t8));
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object get(int index) {
/* 159 */     switch (index) {
/*     */       case 0:
/* 161 */         return this.t1;
/*     */       case 1:
/* 163 */         return this.t2;
/*     */       case 2:
/* 165 */         return this.t3;
/*     */       case 3:
/* 167 */         return this.t4;
/*     */       case 4:
/* 169 */         return this.t5;
/*     */       case 5:
/* 171 */         return this.t6;
/*     */       case 6:
/* 173 */         return this.t7;
/*     */       case 7:
/* 175 */         return this.t8;
/*     */     } 
/* 177 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] toArray() {
/* 183 */     return new Object[] { this.t1, this.t2, this.t3, this.t4, this.t5, this.t6, this.t7, this.t8 };
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object o) {
/* 188 */     if (this == o) return true; 
/* 189 */     if (!(o instanceof Tuple8)) return false; 
/* 190 */     if (!super.equals(o)) return false;
/*     */ 
/*     */     
/* 193 */     Tuple8 tuple8 = (Tuple8)o;
/*     */     
/* 195 */     return this.t8.equals(tuple8.t8);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 201 */     int result = super.hashCode();
/* 202 */     result = 31 * result + this.t8.hashCode();
/* 203 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/* 208 */     return 8;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reacto\\util\function\Tuple8.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */