/*     */ package reactor.util.function;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.function.Function;
/*     */ import reactor.util.annotation.NonNull;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Tuple2<T1, T2>
/*     */   implements Iterable<Object>, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -3518082018884860684L;
/*     */   @NonNull
/*     */   final T1 t1;
/*     */   @NonNull
/*     */   final T2 t2;
/*     */   
/*     */   Tuple2(T1 t1, T2 t2) {
/*  47 */     this.t1 = Objects.requireNonNull(t1, "t1");
/*  48 */     this.t2 = Objects.requireNonNull(t2, "t2");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T1 getT1() {
/*  57 */     return this.t1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T2 getT2() {
/*  66 */     return this.t2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <R> Tuple2<R, T2> mapT1(Function<T1, R> mapper) {
/*  78 */     return new Tuple2((T1)mapper.apply(this.t1), this.t2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <R> Tuple2<T1, R> mapT2(Function<T2, R> mapper) {
/*  90 */     return new Tuple2(this.t1, (T2)mapper.apply(this.t2));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object get(int index) {
/* 101 */     switch (index) {
/*     */       case 0:
/* 103 */         return this.t1;
/*     */       case 1:
/* 105 */         return this.t2;
/*     */     } 
/* 107 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Object> toList() {
/* 119 */     return Arrays.asList(toArray());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] toArray() {
/* 129 */     return new Object[] { this.t1, this.t2 };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<Object> iterator() {
/* 145 */     return Collections.<Object>unmodifiableList(toList()).iterator();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object o) {
/* 150 */     if (this == o) {
/* 151 */       return true;
/*     */     }
/* 153 */     if (o == null || getClass() != o.getClass()) {
/* 154 */       return false;
/*     */     }
/*     */     
/* 157 */     Tuple2<?, ?> tuple2 = (Tuple2<?, ?>)o;
/*     */     
/* 159 */     return (this.t1.equals(tuple2.t1) && this.t2.equals(tuple2.t2));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 165 */     int result = size();
/* 166 */     result = 31 * result + this.t1.hashCode();
/* 167 */     result = 31 * result + this.t2.hashCode();
/* 168 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/* 177 */     return 2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String toString() {
/* 187 */     return Tuples.tupleStringRepresentation(toArray()).insert(0, '[').append(']').toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reacto\\util\function\Tuple2.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */