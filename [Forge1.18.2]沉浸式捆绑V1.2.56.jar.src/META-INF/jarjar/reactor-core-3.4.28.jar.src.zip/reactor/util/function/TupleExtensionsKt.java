/*    */ package reactor.util.function;
/*    */ 
/*    */ import kotlin.Deprecated;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.ReplaceWith;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 1, 18}, bv = {1, 0, 3}, k = 2, d1 = {"\000<\n\002\b\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\032\"\020\000\032\002H\001\"\004\b\000\020\001*\f\022\004\022\002H\001\022\002\b\0030\002H\002¢\006\002\020\003\032\"\020\004\032\002H\001\"\004\b\000\020\001*\f\022\002\b\003\022\004\022\002H\0010\002H\002¢\006\002\020\003\032&\020\005\032\002H\001\"\004\b\000\020\001*\020\022\002\b\003\022\002\b\003\022\004\022\002H\0010\006H\002¢\006\002\020\007\032*\020\b\032\002H\001\"\004\b\000\020\001*\024\022\002\b\003\022\002\b\003\022\002\b\003\022\004\022\002H\0010\tH\002¢\006\002\020\n\032.\020\013\032\002H\001\"\004\b\000\020\001*\030\022\002\b\003\022\002\b\003\022\002\b\003\022\002\b\003\022\004\022\002H\0010\fH\002¢\006\002\020\r\0322\020\016\032\002H\001\"\004\b\000\020\001*\034\022\002\b\003\022\002\b\003\022\002\b\003\022\002\b\003\022\002\b\003\022\004\022\002H\0010\017H\002¢\006\002\020\020\0326\020\021\032\002H\001\"\004\b\000\020\001* \022\002\b\003\022\002\b\003\022\002\b\003\022\002\b\003\022\002\b\003\022\002\b\003\022\004\022\002H\0010\022H\002¢\006\002\020\023\032:\020\024\032\002H\001\"\004\b\000\020\001*$\022\002\b\003\022\002\b\003\022\002\b\003\022\002\b\003\022\002\b\003\022\002\b\003\022\002\b\003\022\004\022\002H\0010\025H\002¢\006\002\020\026¨\006\027"}, d2 = {"component1", "T", "Lreactor/util/function/Tuple2;", "(Lreactor/util/function/Tuple2;)Ljava/lang/Object;", "component2", "component3", "Lreactor/util/function/Tuple3;", "(Lreactor/util/function/Tuple3;)Ljava/lang/Object;", "component4", "Lreactor/util/function/Tuple4;", "(Lreactor/util/function/Tuple4;)Ljava/lang/Object;", "component5", "Lreactor/util/function/Tuple5;", "(Lreactor/util/function/Tuple5;)Ljava/lang/Object;", "component6", "Lreactor/util/function/Tuple6;", "(Lreactor/util/function/Tuple6;)Ljava/lang/Object;", "component7", "Lreactor/util/function/Tuple7;", "(Lreactor/util/function/Tuple7;)Ljava/lang/Object;", "component8", "Lreactor/util/function/Tuple8;", "(Lreactor/util/function/Tuple8;)Ljava/lang/Object;", "reactor-core"})
/*    */ public final class TupleExtensionsKt
/*    */ {
/*    */   @Deprecated(message = "To be removed in 3.3.0.RELEASE, replaced by module reactor-kotlin-extensions and import reactor.kotlin.core.util.function.component1", replaceWith = @ReplaceWith(imports = {"reactor.kotlin.core.util.function.component1"}, expression = "component1()"))
/*    */   public static final <T> T component1(@NotNull Tuple2 $this$component1) {
/* 28 */     Intrinsics.checkParameterIsNotNull($this$component1, "$this$component1"); return (T)$this$component1.t1;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Deprecated(message = "To be removed in 3.3.0.RELEASE, replaced by module reactor-kotlin-extensions and import reactor.kotlin.core.util.function.component2", replaceWith = @ReplaceWith(imports = {"reactor.kotlin.core.util.function.component2"}, expression = "component2()"))
/*    */   public static final <T> T component2(@NotNull Tuple2 $this$component2) {
/* 38 */     Intrinsics.checkParameterIsNotNull($this$component2, "$this$component2"); return (T)$this$component2.t2;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Deprecated(message = "To be removed in 3.3.0.RELEASE, replaced by module reactor-kotlin-extensions and import reactor.kotlin.core.util.function.component3", replaceWith = @ReplaceWith(imports = {"reactor.kotlin.core.util.function.component3"}, expression = "component3()"))
/*    */   public static final <T> T component3(@NotNull Tuple3 $this$component3) {
/* 48 */     Intrinsics.checkParameterIsNotNull($this$component3, "$this$component3"); return (T)$this$component3.t3;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Deprecated(message = "To be removed in 3.3.0.RELEASE, replaced by module reactor-kotlin-extensions and import reactor.kotlin.core.util.function.component4", replaceWith = @ReplaceWith(imports = {"reactor.kotlin.core.util.function.component4"}, expression = "component4()"))
/*    */   public static final <T> T component4(@NotNull Tuple4 $this$component4) {
/* 58 */     Intrinsics.checkParameterIsNotNull($this$component4, "$this$component4"); return (T)$this$component4.t4;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Deprecated(message = "To be removed in 3.3.0.RELEASE, replaced by module reactor-kotlin-extensions and import reactor.kotlin.core.util.function.component5", replaceWith = @ReplaceWith(imports = {"reactor.kotlin.core.util.function.component5"}, expression = "component5()"))
/*    */   public static final <T> T component5(@NotNull Tuple5 $this$component5) {
/* 68 */     Intrinsics.checkParameterIsNotNull($this$component5, "$this$component5"); return (T)$this$component5.t5;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Deprecated(message = "To be removed in 3.3.0.RELEASE, replaced by module reactor-kotlin-extensions and import reactor.kotlin.core.util.function.component6", replaceWith = @ReplaceWith(imports = {"reactor.kotlin.core.util.function.component6"}, expression = "component6()"))
/*    */   public static final <T> T component6(@NotNull Tuple6 $this$component6) {
/* 78 */     Intrinsics.checkParameterIsNotNull($this$component6, "$this$component6"); return (T)$this$component6.t6;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Deprecated(message = "To be removed in 3.3.0.RELEASE, replaced by module reactor-kotlin-extensions and import reactor.kotlin.core.util.function.component7", replaceWith = @ReplaceWith(imports = {"reactor.kotlin.core.util.function.component7"}, expression = "component7()"))
/*    */   public static final <T> T component7(@NotNull Tuple7 $this$component7) {
/* 88 */     Intrinsics.checkParameterIsNotNull($this$component7, "$this$component7"); return (T)$this$component7.t7;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Deprecated(message = "To be removed in 3.3.0.RELEASE, replaced by module reactor-kotlin-extensions and import reactor.kotlin.core.util.function.component8", replaceWith = @ReplaceWith(imports = {"reactor.kotlin.core.util.function.component8"}, expression = "component8()"))
/*    */   public static final <T> T component8(@NotNull Tuple8 $this$component8) {
/* 98 */     Intrinsics.checkParameterIsNotNull($this$component8, "$this$component8"); return (T)$this$component8.t8;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reacto\\util\function\TupleExtensionsKt.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */