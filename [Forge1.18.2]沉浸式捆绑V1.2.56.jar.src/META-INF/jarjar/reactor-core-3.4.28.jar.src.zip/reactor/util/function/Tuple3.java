/*     */ package reactor.util.function;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.function.Function;
/*     */ import reactor.util.annotation.NonNull;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Tuple3<T1, T2, T3>
/*     */   extends Tuple2<T1, T2>
/*     */ {
/*     */   private static final long serialVersionUID = -4430274211524723033L;
/*     */   @NonNull
/*     */   final T3 t3;
/*     */   
/*     */   Tuple3(T1 t1, T2 t2, T3 t3) {
/*  41 */     super(t1, t2);
/*  42 */     this.t3 = Objects.requireNonNull(t3, "t3");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T3 getT3() {
/*  51 */     return this.t3;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <R> Tuple3<R, T2, T3> mapT1(Function<T1, R> mapper) {
/*  63 */     return new Tuple3((T1)mapper.apply(this.t1), this.t2, this.t3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <R> Tuple3<T1, R, T3> mapT2(Function<T2, R> mapper) {
/*  75 */     return new Tuple3(this.t1, (T2)mapper.apply(this.t2), this.t3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <R> Tuple3<T1, T2, R> mapT3(Function<T3, R> mapper) {
/*  87 */     return new Tuple3(this.t1, this.t2, (T3)mapper.apply(this.t3));
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object get(int index) {
/*  93 */     switch (index) {
/*     */       case 0:
/*  95 */         return this.t1;
/*     */       case 1:
/*  97 */         return this.t2;
/*     */       case 2:
/*  99 */         return this.t3;
/*     */     } 
/* 101 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] toArray() {
/* 107 */     return new Object[] { this.t1, this.t2, this.t3 };
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object o) {
/* 112 */     if (this == o) return true; 
/* 113 */     if (!(o instanceof Tuple3)) return false; 
/* 114 */     if (!super.equals(o)) return false;
/*     */ 
/*     */     
/* 117 */     Tuple3 tuple3 = (Tuple3)o;
/*     */     
/* 119 */     return this.t3.equals(tuple3.t3);
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/* 124 */     return 3;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 129 */     int result = super.hashCode();
/* 130 */     result = 31 * result + this.t3.hashCode();
/* 131 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reacto\\util\function\Tuple3.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */