/*     */ package reactor.util.retry;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.util.Objects;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Predicate;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.context.ContextView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RetrySpec
/*     */   extends Retry
/*     */ {
/*  55 */   static final Duration MAX_BACKOFF = Duration.ofMillis(Long.MAX_VALUE);
/*     */   static {
/*  57 */     NO_OP_BIFUNCTION = ((rs, m) -> m);
/*     */ 
/*     */ 
/*     */     
/*  61 */     RETRY_EXCEPTION_GENERATOR = ((builder, rs) -> Exceptions.retryExhausted("Retries exhausted: " + (builder.isTransientErrors ? (rs.totalRetriesInARow() + "/" + builder.maxAttempts + " in a row (" + rs.totalRetries() + " total)") : (rs.totalRetries() + "/" + builder.maxAttempts)), rs.failure()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final Consumer<Retry.RetrySignal> NO_OP_CONSUMER = rs -> {
/*     */     
/*     */     };
/*     */ 
/*     */ 
/*     */   
/*     */   static final BiFunction<Retry.RetrySignal, Mono<Void>, Mono<Void>> NO_OP_BIFUNCTION;
/*     */ 
/*     */ 
/*     */   
/*     */   static final BiFunction<RetrySpec, Retry.RetrySignal, Throwable> RETRY_EXCEPTION_GENERATOR;
/*     */ 
/*     */ 
/*     */   
/*     */   public final long maxAttempts;
/*     */ 
/*     */   
/*     */   public final Predicate<Throwable> errorFilter;
/*     */ 
/*     */   
/*     */   public final boolean isTransientErrors;
/*     */ 
/*     */   
/*     */   final Consumer<Retry.RetrySignal> doPreRetry;
/*     */ 
/*     */   
/*     */   final Consumer<Retry.RetrySignal> doPostRetry;
/*     */ 
/*     */   
/*     */   final BiFunction<Retry.RetrySignal, Mono<Void>, Mono<Void>> asyncPreRetry;
/*     */ 
/*     */   
/*     */   final BiFunction<Retry.RetrySignal, Mono<Void>, Mono<Void>> asyncPostRetry;
/*     */ 
/*     */   
/*     */   final BiFunction<RetrySpec, Retry.RetrySignal, Throwable> retryExhaustedGenerator;
/*     */ 
/*     */ 
/*     */   
/*     */   RetrySpec(ContextView retryContext, long max, Predicate<? super Throwable> aThrowablePredicate, boolean isTransientErrors, Consumer<Retry.RetrySignal> doPreRetry, Consumer<Retry.RetrySignal> doPostRetry, BiFunction<Retry.RetrySignal, Mono<Void>, Mono<Void>> asyncPreRetry, BiFunction<Retry.RetrySignal, Mono<Void>, Mono<Void>> asyncPostRetry, BiFunction<RetrySpec, Retry.RetrySignal, Throwable> retryExhaustedGenerator) {
/* 107 */     super(retryContext);
/* 108 */     this.maxAttempts = max;
/* 109 */     this.errorFilter = aThrowablePredicate::test;
/* 110 */     this.isTransientErrors = isTransientErrors;
/* 111 */     this.doPreRetry = doPreRetry;
/* 112 */     this.doPostRetry = doPostRetry;
/* 113 */     this.asyncPreRetry = asyncPreRetry;
/* 114 */     this.asyncPostRetry = asyncPostRetry;
/* 115 */     this.retryExhaustedGenerator = retryExhaustedGenerator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RetrySpec withRetryContext(ContextView retryContext) {
/* 125 */     return new RetrySpec(retryContext, this.maxAttempts, this.errorFilter, this.isTransientErrors, this.doPreRetry, this.doPostRetry, this.asyncPreRetry, this.asyncPostRetry, this.retryExhaustedGenerator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RetrySpec maxAttempts(long maxAttempts) {
/* 146 */     return new RetrySpec(this.retryContext, maxAttempts, this.errorFilter, this.isTransientErrors, this.doPreRetry, this.doPostRetry, this.asyncPreRetry, this.asyncPostRetry, this.retryExhaustedGenerator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RetrySpec filter(Predicate<? super Throwable> errorFilter) {
/* 167 */     return new RetrySpec(this.retryContext, this.maxAttempts, 
/*     */ 
/*     */         
/* 170 */         Objects.<Predicate<? super Throwable>>requireNonNull(errorFilter, "errorFilter"), this.isTransientErrors, this.doPreRetry, this.doPostRetry, this.asyncPreRetry, this.asyncPostRetry, this.retryExhaustedGenerator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RetrySpec modifyErrorFilter(Function<Predicate<Throwable>, Predicate<? super Throwable>> predicateAdjuster) {
/* 200 */     Objects.requireNonNull(predicateAdjuster, "predicateAdjuster");
/* 201 */     Predicate<? super Throwable> newPredicate = Objects.<Predicate<? super Throwable>>requireNonNull(predicateAdjuster.apply(this.errorFilter), "predicateAdjuster must return a new predicate");
/*     */     
/* 203 */     return new RetrySpec(this.retryContext, this.maxAttempts, newPredicate, this.isTransientErrors, this.doPreRetry, this.doPostRetry, this.asyncPreRetry, this.asyncPostRetry, this.retryExhaustedGenerator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RetrySpec doBeforeRetry(Consumer<Retry.RetrySignal> doBeforeRetry) {
/* 226 */     return new RetrySpec(this.retryContext, this.maxAttempts, this.errorFilter, this.isTransientErrors, this.doPreRetry
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 231 */         .andThen(doBeforeRetry), this.doPostRetry, this.asyncPreRetry, this.asyncPostRetry, this.retryExhaustedGenerator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RetrySpec doAfterRetry(Consumer<Retry.RetrySignal> doAfterRetry) {
/* 248 */     return new RetrySpec(this.retryContext, this.maxAttempts, this.errorFilter, this.isTransientErrors, this.doPreRetry, this.doPostRetry
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 254 */         .andThen(doAfterRetry), this.asyncPreRetry, this.asyncPostRetry, this.retryExhaustedGenerator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RetrySpec doBeforeRetryAsync(Function<Retry.RetrySignal, Mono<Void>> doAsyncBeforeRetry) {
/* 269 */     return new RetrySpec(this.retryContext, this.maxAttempts, this.errorFilter, this.isTransientErrors, this.doPreRetry, this.doPostRetry, (rs, m) -> ((Mono)this.asyncPreRetry.apply(rs, m)).then(doAsyncBeforeRetry.apply(rs)), this.asyncPostRetry, this.retryExhaustedGenerator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RetrySpec doAfterRetryAsync(Function<Retry.RetrySignal, Mono<Void>> doAsyncAfterRetry) {
/* 290 */     return new RetrySpec(this.retryContext, this.maxAttempts, this.errorFilter, this.isTransientErrors, this.doPreRetry, this.doPostRetry, this.asyncPreRetry, (rs, m) -> ((Mono)this.asyncPostRetry.apply(rs, m)).then(doAsyncAfterRetry.apply(rs)), this.retryExhaustedGenerator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RetrySpec onRetryExhaustedThrow(BiFunction<RetrySpec, Retry.RetrySignal, Throwable> retryExhaustedGenerator) {
/* 313 */     return new RetrySpec(this.retryContext, this.maxAttempts, this.errorFilter, this.isTransientErrors, this.doPreRetry, this.doPostRetry, this.asyncPreRetry, this.asyncPostRetry, 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 322 */         Objects.<BiFunction<RetrySpec, Retry.RetrySignal, Throwable>>requireNonNull(retryExhaustedGenerator, "retryExhaustedGenerator"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RetrySpec transientErrors(boolean isTransientErrors) {
/* 339 */     return new RetrySpec(this.retryContext, this.maxAttempts, this.errorFilter, isTransientErrors, this.doPreRetry, this.doPostRetry, this.asyncPreRetry, this.asyncPostRetry, this.retryExhaustedGenerator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Flux<Long> generateCompanion(Flux<Retry.RetrySignal> flux) {
/* 357 */     return Flux.deferContextual(cv -> flux.contextWrite(cv).concatMap(()).onErrorStop());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T> Mono<T> applyHooks(Retry.RetrySignal copyOfSignal, Mono<T> originalCompanion, Consumer<Retry.RetrySignal> doPreRetry, Consumer<Retry.RetrySignal> doPostRetry, BiFunction<Retry.RetrySignal, Mono<Void>, Mono<Void>> asyncPreRetry, BiFunction<Retry.RetrySignal, Mono<Void>, Mono<Void>> asyncPostRetry, ContextView cv) {
/*     */     Mono<Void> postRetrySyncMono;
/* 394 */     if (doPreRetry != NO_OP_CONSUMER) {
/*     */       try {
/* 396 */         doPreRetry.accept(copyOfSignal);
/*     */       }
/* 398 */       catch (Throwable e) {
/* 399 */         return Mono.error(e);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 404 */     if (doPostRetry != NO_OP_CONSUMER) {
/* 405 */       postRetrySyncMono = Mono.fromRunnable(() -> doPostRetry.accept(copyOfSignal));
/*     */     } else {
/*     */       
/* 408 */       postRetrySyncMono = Mono.empty();
/*     */     } 
/*     */     
/* 411 */     Mono<Void> preRetryMono = (asyncPreRetry == NO_OP_BIFUNCTION) ? Mono.empty() : asyncPreRetry.apply(copyOfSignal, Mono.empty());
/* 412 */     Mono<Void> postRetryMono = (asyncPostRetry != NO_OP_BIFUNCTION) ? asyncPostRetry.apply(copyOfSignal, postRetrySyncMono) : postRetrySyncMono;
/*     */     
/* 414 */     return preRetryMono.then(originalCompanion).flatMap(postRetryMono::thenReturn).contextWrite(cv);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reacto\\util\retry\RetrySpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */