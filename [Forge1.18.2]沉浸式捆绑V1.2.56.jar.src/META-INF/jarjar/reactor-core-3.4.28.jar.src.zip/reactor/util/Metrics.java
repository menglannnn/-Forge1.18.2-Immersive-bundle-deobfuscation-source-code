/*    */ package reactor.util;
/*    */ 
/*    */ import io.micrometer.core.instrument.MeterRegistry;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Metrics
/*    */ {
/*    */   static final boolean isMicrometerAvailable;
/*    */   
/*    */   static {
/*    */     boolean micrometer;
/*    */     try {
/* 36 */       io.micrometer.core.instrument.Metrics.globalRegistry.getRegistries();
/* 37 */       micrometer = true;
/*    */     }
/* 39 */     catch (Throwable t) {
/* 40 */       micrometer = false;
/*    */     } 
/* 42 */     isMicrometerAvailable = micrometer;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static final boolean isInstrumentationAvailable() {
/* 52 */     return isMicrometerAvailable;
/*    */   }
/*    */   
/*    */   public static class MicrometerConfiguration
/*    */   {
/* 57 */     private static MeterRegistry registry = (MeterRegistry)io.micrometer.core.instrument.Metrics.globalRegistry;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     public static MeterRegistry useRegistry(MeterRegistry registry) {
/* 64 */       MeterRegistry previous = MicrometerConfiguration.registry;
/* 65 */       MicrometerConfiguration.registry = registry;
/* 66 */       return previous;
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     public static MeterRegistry getRegistry() {
/* 74 */       return registry;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reacto\\util\Metrics.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */