/*     */ package reactor.core;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Spliterators;
/*     */ import java.util.function.Function;
/*     */ import java.util.regex.Pattern;
/*     */ import java.util.stream.Collector;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.Stream;
/*     */ import java.util.stream.StreamSupport;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.function.Tuple2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @FunctionalInterface
/*     */ public interface Scannable
/*     */ {
/*  59 */   public static final Pattern OPERATOR_NAME_UNRELATED_WORDS_PATTERN = Pattern.compile("Parallel|Flux|Mono|Publisher|Subscriber|Fuseable|Operator|Conditional");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Attr<T>
/*     */   {
/*  84 */     public static final Attr<Scannable> ACTUAL = new Attr(null, Scannable::from);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  95 */     public static final Attr<Boolean> ACTUAL_METADATA = new Attr((T)Boolean.valueOf(false));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 107 */     public static final Attr<Integer> BUFFERED = new Attr((T)Integer.valueOf(0));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 116 */     public static final Attr<Integer> CAPACITY = new Attr((T)Integer.valueOf(0));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 124 */     public static final Attr<Boolean> CANCELLED = new Attr((T)Boolean.valueOf(false));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 133 */     public static final Attr<Boolean> DELAY_ERROR = new Attr((T)Boolean.valueOf(false));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 139 */     public static final Attr<Throwable> ERROR = new Attr(null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 152 */     public static final Attr<Long> LARGE_BUFFERED = new Attr(null);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 157 */     public static final Attr<String> NAME = new Attr(null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 169 */     public static final Attr<Scannable> PARENT = new Attr(null, Scannable::from);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 179 */     public static final Attr<Scannable> RUN_ON = new Attr(null, Scannable::from);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 190 */     public static final Attr<Integer> PREFETCH = new Attr((T)Integer.valueOf(0));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 197 */     public static final Attr<Long> REQUESTED_FROM_DOWNSTREAM = new Attr((T)Long.valueOf(0L));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 205 */     public static final Attr<Boolean> TERMINATED = new Attr((T)Boolean.valueOf(false));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 211 */     public static final Attr<Stream<Tuple2<String, String>>> TAGS = new Attr(null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 219 */     public static final Attr<RunStyle> RUN_STYLE = new Attr((T)RunStyle.UNKNOWN);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 226 */     public static final Attr<String> LIFTER = new Attr(null);
/*     */ 
/*     */     
/*     */     final T defaultValue;
/*     */     
/*     */     final Function<Object, ? extends T> safeConverter;
/*     */ 
/*     */     
/*     */     public enum RunStyle
/*     */     {
/* 236 */       UNKNOWN,
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 241 */       ASYNC,
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 246 */       SYNC;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public T defaultValue() {
/* 258 */       return this.defaultValue;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     boolean isConversionSafe() {
/* 269 */       return (this.safeConverter != null);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     T tryConvert(@Nullable Object o) {
/* 284 */       if (o == null) {
/* 285 */         return null;
/*     */       }
/* 287 */       if (this.safeConverter == null) {
/* 288 */         T t = (T)o;
/* 289 */         return t;
/*     */       } 
/* 291 */       return this.safeConverter.apply(o);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected Attr(@Nullable T defaultValue) {
/* 298 */       this(defaultValue, null);
/*     */     }
/*     */ 
/*     */     
/*     */     protected Attr(@Nullable T defaultValue, @Nullable Function<Object, ? extends T> safeConverter) {
/* 303 */       this.defaultValue = defaultValue;
/* 304 */       this.safeConverter = safeConverter;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 311 */     static final Scannable UNAVAILABLE_SCAN = new Scannable()
/*     */       {
/*     */         public Object scanUnsafe(Scannable.Attr key) {
/* 314 */           return null;
/*     */         }
/*     */ 
/*     */         
/*     */         public boolean isScanAvailable() {
/* 319 */           return false;
/*     */         }
/*     */ 
/*     */         
/*     */         public String toString() {
/* 324 */           return "UNAVAILABLE_SCAN";
/*     */         }
/*     */ 
/*     */         
/*     */         public String stepName() {
/* 329 */           return "UNAVAILABLE_SCAN";
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 337 */     static final Scannable NULL_SCAN = new Scannable()
/*     */       {
/*     */         public Object scanUnsafe(Scannable.Attr key) {
/* 340 */           return null;
/*     */         }
/*     */ 
/*     */         
/*     */         public boolean isScanAvailable() {
/* 345 */           return false;
/*     */         }
/*     */ 
/*     */         
/*     */         public String toString() {
/* 350 */           return "NULL_SCAN";
/*     */         }
/*     */ 
/*     */         
/*     */         public String stepName() {
/* 355 */           return "NULL_SCAN";
/*     */         }
/*     */       };
/*     */ 
/*     */     
/*     */     static Stream<? extends Scannable> recurse(Scannable _s, final Attr<Scannable> key) {
/* 361 */       final Scannable s = Scannable.from(_s.scan(key));
/* 362 */       if (!s.isScanAvailable()) {
/* 363 */         return Stream.empty();
/*     */       }
/* 365 */       return StreamSupport.stream(Spliterators.spliteratorUnknownSize(new Iterator<Scannable>() {
/* 366 */               Scannable c = s;
/*     */ 
/*     */               
/*     */               public boolean hasNext() {
/* 370 */                 return (this.c != null && this.c.isScanAvailable());
/*     */               }
/*     */ 
/*     */               
/*     */               public Scannable next() {
/* 375 */                 Scannable _c = this.c;
/* 376 */                 this.c = Scannable.from(this.c.scan(key));
/* 377 */                 return _c;
/*     */               }
/*     */             },  0), false);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Scannable from(@Nullable Object o) {
/* 394 */     if (o == null) {
/* 395 */       return Attr.NULL_SCAN;
/*     */     }
/* 397 */     if (o instanceof Scannable) {
/* 398 */       return (Scannable)o;
/*     */     }
/* 400 */     return Attr.UNAVAILABLE_SCAN;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Stream<? extends Scannable> actuals() {
/* 411 */     return Attr.recurse(this, Attr.ACTUAL);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Stream<? extends Scannable> inners() {
/* 420 */     return Stream.empty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default boolean isScanAvailable() {
/* 429 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default String name() {
/* 440 */     String thisName = scan(Attr.NAME);
/* 441 */     if (thisName != null) {
/* 442 */       return thisName;
/*     */     }
/*     */     
/* 445 */     return parents()
/* 446 */       .<String>map(s -> (String)s.<String>scan(Attr.NAME))
/* 447 */       .filter(Objects::nonNull)
/* 448 */       .findFirst()
/* 449 */       .orElse(stepName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default String stepName() {
/* 462 */     String name = getClass().getName();
/* 463 */     int innerClassIndex = name.indexOf('$');
/* 464 */     if (innerClassIndex != -1) {
/* 465 */       name = name.substring(0, innerClassIndex);
/*     */     }
/* 467 */     int stripPackageIndex = name.lastIndexOf('.');
/* 468 */     if (stripPackageIndex != -1) {
/* 469 */       name = name.substring(stripPackageIndex + 1);
/*     */     }
/*     */ 
/*     */     
/* 473 */     String stripped = OPERATOR_NAME_UNRELATED_WORDS_PATTERN.matcher(name).replaceAll("");
/*     */     
/* 475 */     if (!stripped.isEmpty()) {
/* 476 */       return stripped.substring(0, 1).toLowerCase() + stripped.substring(1);
/*     */     }
/* 478 */     return stripped;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Stream<String> steps() {
/* 495 */     List<Scannable> chain = new ArrayList<>();
/* 496 */     chain.addAll(parents().collect((Collector)Collectors.toList()));
/* 497 */     Collections.reverse(chain);
/* 498 */     chain.add(this);
/* 499 */     chain.addAll(actuals().collect((Collector)Collectors.toList()));
/*     */     
/* 501 */     List<String> chainNames = new ArrayList<>(chain.size());
/* 502 */     for (int i = 0; i < chain.size(); i++) {
/* 503 */       Scannable step = chain.get(i);
/* 504 */       Scannable stepAfter = null;
/* 505 */       if (i < chain.size() - 1) {
/* 506 */         stepAfter = chain.get(i + 1);
/*     */       }
/*     */       
/* 509 */       if (stepAfter != null && ((Boolean)stepAfter.<Boolean>scan(Attr.ACTUAL_METADATA)).booleanValue()) {
/* 510 */         chainNames.add(stepAfter.stepName());
/* 511 */         i++;
/*     */       } else {
/*     */         
/* 514 */         chainNames.add(step.stepName());
/*     */       } 
/*     */     } 
/*     */     
/* 518 */     return chainNames.stream();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Stream<? extends Scannable> parents() {
/* 529 */     return Attr.recurse(this, Attr.PARENT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   default <T> T scan(Attr<T> key) {
/* 562 */     T value = key.tryConvert(scanUnsafe(key));
/* 563 */     if (value == null)
/* 564 */       return key.defaultValue(); 
/* 565 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default <T> T scanOrDefault(Attr<T> key, T defaultValue) {
/* 582 */     T v = key.tryConvert(scanUnsafe(key));
/*     */     
/* 584 */     if (v == null) {
/* 585 */       return Objects.requireNonNull(defaultValue, "defaultValue");
/*     */     }
/* 587 */     return v;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Stream<Tuple2<String, String>> tags() {
/* 598 */     Stream<Tuple2<String, String>> parentTags = parents().flatMap(s -> (Stream)s.<Stream>scan((Attr)Attr.TAGS));
/*     */     
/* 600 */     Stream<Tuple2<String, String>> thisTags = scan(Attr.TAGS);
/*     */     
/* 602 */     if (thisTags == null) {
/* 603 */       return parentTags;
/*     */     }
/*     */     
/* 606 */     return Stream.concat(thisTags, parentTags);
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   Object scanUnsafe(Attr paramAttr);
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\Scannable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */