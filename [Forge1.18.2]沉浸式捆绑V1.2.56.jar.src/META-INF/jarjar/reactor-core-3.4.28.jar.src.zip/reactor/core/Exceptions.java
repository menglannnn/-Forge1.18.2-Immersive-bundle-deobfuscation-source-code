/*     */ package reactor.core;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.RejectedExecutionException;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.Loggers;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Exceptions
/*     */ {
/*  41 */   private static final Logger LOGGER = Loggers.getLogger(Exceptions.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String BACKPRESSURE_ERROR_QUEUE_FULL = "Queue is full: Reactive Streams source doesn't respect backpressure";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  54 */   public static final Throwable TERMINATED = new StaticThrowable("Operator has been terminated");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> boolean addThrowable(AtomicReferenceFieldUpdater<T, Throwable> field, T instance, Throwable exception) {
/*     */     while (true) {
/*  80 */       Throwable update, current = field.get(instance);
/*     */       
/*  82 */       if (current == TERMINATED) {
/*  83 */         return false;
/*     */       }
/*     */       
/*  86 */       if (current instanceof CompositeException) {
/*     */         
/*  88 */         current.addSuppressed(exception);
/*  89 */         return true;
/*     */       } 
/*     */ 
/*     */       
/*  93 */       if (current == null) {
/*  94 */         update = exception;
/*     */       } else {
/*  96 */         update = multiple(new Throwable[] { current, exception });
/*     */       } 
/*     */       
/*  99 */       if (field.compareAndSet(instance, current, update)) {
/* 100 */         return true;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RuntimeException multiple(Throwable... throwables) {
/* 124 */     CompositeException multiple = new CompositeException();
/*     */     
/* 126 */     if (throwables != null) {
/* 127 */       for (Throwable t : throwables)
/*     */       {
/* 129 */         multiple.addSuppressed(t);
/*     */       }
/*     */     }
/* 132 */     return multiple;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RuntimeException multiple(Iterable<Throwable> throwables) {
/* 154 */     CompositeException multiple = new CompositeException();
/*     */     
/* 156 */     if (throwables != null) {
/* 157 */       for (Throwable t : throwables)
/*     */       {
/* 159 */         multiple.addSuppressed(t);
/*     */       }
/*     */     }
/* 162 */     return multiple;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RuntimeException bubble(Throwable t) {
/* 175 */     throwIfFatal(t);
/* 176 */     return new BubblingException(t);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IllegalStateException duplicateOnSubscribeException() {
/* 184 */     return new IllegalStateException("Spec. Rule 2.12 - Subscriber.onSubscribe MUST NOT be called more than once (based on object equality)");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static UnsupportedOperationException errorCallbackNotImplemented(Throwable cause) {
/* 198 */     Objects.requireNonNull(cause, "cause");
/* 199 */     return new ErrorCallbackNotImplemented(cause);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RuntimeException failWithCancel() {
/* 212 */     return new CancelException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IllegalStateException failWithOverflow() {
/* 224 */     return new OverflowException("The receiver is overrun by more signals than expected (bounded queue...)");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IllegalStateException failWithOverflow(String message) {
/* 237 */     return new OverflowException(message);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RejectedExecutionException failWithRejected() {
/* 246 */     return REJECTED_EXECUTION;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RejectedExecutionException failWithRejectedNotTimeCapable() {
/* 256 */     return NOT_TIME_CAPABLE_REJECTED_EXECUTION;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RejectedExecutionException failWithRejected(Throwable cause) {
/* 268 */     if (cause instanceof ReactorRejectedExecutionException) {
/* 269 */       return (RejectedExecutionException)cause;
/*     */     }
/* 271 */     return new ReactorRejectedExecutionException("Scheduler unavailable", cause);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RejectedExecutionException failWithRejected(String message) {
/* 281 */     return new ReactorRejectedExecutionException(message);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RuntimeException retryExhausted(String message, @Nullable Throwable cause) {
/* 294 */     return (cause == null) ? new RetryExhaustedException(message) : new RetryExhaustedException(message, cause);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isOverflow(@Nullable Throwable t) {
/* 303 */     return t instanceof OverflowException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isBubbling(@Nullable Throwable t) {
/* 312 */     return t instanceof BubblingException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isCancel(@Nullable Throwable t) {
/* 321 */     return t instanceof CancelException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isErrorCallbackNotImplemented(@Nullable Throwable t) {
/* 333 */     return t instanceof ErrorCallbackNotImplemented;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isMultiple(@Nullable Throwable t) {
/* 343 */     return t instanceof CompositeException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isRetryExhausted(@Nullable Throwable t) {
/* 354 */     return t instanceof RetryExhaustedException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isTraceback(@Nullable Throwable t) {
/* 364 */     if (t == null) {
/* 365 */       return false;
/*     */     }
/*     */     
/* 368 */     return "reactor.core.publisher.FluxOnAssembly.OnAssemblyException".equals(t.getClass().getCanonicalName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IllegalArgumentException nullOrNegativeRequestException(long elements) {
/* 378 */     return new IllegalArgumentException("Spec. Rule 3.9 - Cannot request a non strictly positive number: " + elements);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RuntimeException propagate(Throwable t) {
/* 392 */     throwIfFatal(t);
/* 393 */     if (t instanceof RuntimeException) {
/* 394 */       return (RuntimeException)t;
/*     */     }
/* 396 */     return new ReactiveException(t);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static <T> Throwable terminate(AtomicReferenceFieldUpdater<T, Throwable> field, T instance) {
/* 412 */     Throwable current = field.get(instance);
/* 413 */     if (current != TERMINATED) {
/* 414 */       current = field.getAndSet(instance, TERMINATED);
/*     */     }
/* 416 */     return current;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isJvmFatal(@Nullable Throwable t) {
/* 440 */     return (t instanceof VirtualMachineError || t instanceof ThreadDeath || t instanceof LinkageError);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isFatal(@Nullable Throwable t) {
/* 471 */     return (isFatalButNotJvmFatal(t) || isJvmFatal(t));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean isFatalButNotJvmFatal(@Nullable Throwable t) {
/* 478 */     return (t instanceof BubblingException || t instanceof ErrorCallbackNotImplemented);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void throwIfFatal(@Nullable Throwable t) {
/* 491 */     if (t == null) {
/*     */       return;
/*     */     }
/* 494 */     if (isFatalButNotJvmFatal(t)) {
/* 495 */       LOGGER.warn("throwIfFatal detected a fatal exception, which is thrown and logged below:", t);
/* 496 */       throw (RuntimeException)t;
/*     */     } 
/* 498 */     if (isJvmFatal(t)) {
/* 499 */       LOGGER.warn("throwIfFatal detected a jvm fatal exception, which is thrown and logged below:", t);
/* 500 */       throw (Error)t;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void throwIfJvmFatal(@Nullable Throwable t) {
/* 513 */     if (t == null) {
/*     */       return;
/*     */     }
/* 516 */     if (isJvmFatal(t)) {
/* 517 */       LOGGER.warn("throwIfJvmFatal detected a jvm fatal exception, which is thrown and logged below:", t);
/* 518 */       assert t instanceof Error;
/* 519 */       throw (Error)t;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Throwable unwrap(Throwable t) {
/* 532 */     Throwable _t = t;
/* 533 */     while (_t instanceof ReactiveException) {
/* 534 */       _t = _t.getCause();
/*     */     }
/* 536 */     return (_t == null) ? t : _t;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<Throwable> unwrapMultiple(@Nullable Throwable potentialMultiple) {
/* 558 */     if (potentialMultiple == null) {
/* 559 */       return Collections.emptyList();
/*     */     }
/*     */     
/* 562 */     if (isMultiple(potentialMultiple)) {
/* 563 */       return Arrays.asList(potentialMultiple.getSuppressed());
/*     */     }
/*     */     
/* 566 */     return Collections.singletonList(potentialMultiple);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<Throwable> unwrapMultipleExcludingTracebacks(@Nullable Throwable potentialMultiple) {
/* 586 */     if (potentialMultiple == null) {
/* 587 */       return Collections.emptyList();
/*     */     }
/*     */     
/* 590 */     if (isMultiple(potentialMultiple)) {
/* 591 */       Throwable[] suppressed = potentialMultiple.getSuppressed();
/* 592 */       List<Throwable> filtered = new ArrayList<>(suppressed.length);
/* 593 */       for (Throwable t : suppressed) {
/* 594 */         if (!isTraceback(t))
/*     */         {
/*     */           
/* 597 */           filtered.add(t); } 
/*     */       } 
/* 599 */       return filtered;
/*     */     } 
/*     */     
/* 602 */     return Collections.singletonList(potentialMultiple);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final RuntimeException addSuppressed(RuntimeException original, Throwable suppressed) {
/* 623 */     if (original == suppressed) {
/* 624 */       return original;
/*     */     }
/* 626 */     if (original == REJECTED_EXECUTION || original == NOT_TIME_CAPABLE_REJECTED_EXECUTION) {
/* 627 */       RejectedExecutionException ree = new RejectedExecutionException(original.getMessage());
/* 628 */       ree.addSuppressed(suppressed);
/* 629 */       return ree;
/*     */     } 
/*     */     
/* 632 */     original.addSuppressed(suppressed);
/* 633 */     return original;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Throwable addSuppressed(Throwable original, Throwable suppressed) {
/* 657 */     if (original == suppressed) {
/* 658 */       return original;
/*     */     }
/*     */     
/* 661 */     if (original == TERMINATED) {
/* 662 */       return original;
/*     */     }
/*     */     
/* 665 */     if (original == REJECTED_EXECUTION || original == NOT_TIME_CAPABLE_REJECTED_EXECUTION) {
/* 666 */       RejectedExecutionException ree = new RejectedExecutionException(original.getMessage());
/* 667 */       ree.addSuppressed(suppressed);
/* 668 */       return ree;
/*     */     } 
/*     */     
/* 671 */     original.addSuppressed(suppressed);
/* 672 */     return original;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 679 */   static final RejectedExecutionException REJECTED_EXECUTION = new StaticRejectedExecutionException("Scheduler unavailable");
/*     */   
/* 681 */   static final RejectedExecutionException NOT_TIME_CAPABLE_REJECTED_EXECUTION = new StaticRejectedExecutionException("Scheduler is not capable of time-based scheduling");
/*     */   
/*     */   static class CompositeException extends ReactiveException {
/*     */     private static final long serialVersionUID = 8070744939537687606L;
/*     */     
/*     */     CompositeException() {
/* 687 */       super("Multiple exceptions");
/*     */     }
/*     */   }
/*     */   
/*     */   static class BubblingException
/*     */     extends ReactiveException {
/*     */     private static final long serialVersionUID = 2491425277432776142L;
/*     */     
/*     */     BubblingException(String message) {
/* 696 */       super(message);
/*     */     }
/*     */     
/*     */     BubblingException(Throwable cause) {
/* 700 */       super(cause);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static class ReactiveException
/*     */     extends RuntimeException
/*     */   {
/*     */     private static final long serialVersionUID = 2491425227432776143L;
/*     */ 
/*     */     
/*     */     ReactiveException(Throwable cause) {
/* 712 */       super(cause);
/*     */     }
/*     */     
/*     */     ReactiveException(String message) {
/* 716 */       super(message);
/*     */     }
/*     */ 
/*     */     
/*     */     public synchronized Throwable fillInStackTrace() {
/* 721 */       return (getCause() != null) ? getCause().fillInStackTrace() : super
/* 722 */         .fillInStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */   static final class ErrorCallbackNotImplemented
/*     */     extends UnsupportedOperationException {
/*     */     private static final long serialVersionUID = 2491425227432776143L;
/*     */     
/*     */     ErrorCallbackNotImplemented(Throwable cause) {
/* 731 */       super(cause);
/*     */     }
/*     */ 
/*     */     
/*     */     public synchronized Throwable fillInStackTrace() {
/* 736 */       return this;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class CancelException
/*     */     extends BubblingException
/*     */   {
/*     */     private static final long serialVersionUID = 2491425227432776144L;
/*     */ 
/*     */ 
/*     */     
/*     */     CancelException() {
/* 751 */       super("The subscriber has denied dispatching");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static final class OverflowException
/*     */     extends IllegalStateException
/*     */   {
/*     */     OverflowException(String s) {
/* 761 */       super(s);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class RetryExhaustedException
/*     */     extends IllegalStateException
/*     */   {
/*     */     RetryExhaustedException(String message) {
/* 775 */       super(message);
/*     */     }
/*     */     
/*     */     RetryExhaustedException(String message, Throwable cause) {
/* 779 */       super(message, cause);
/*     */     }
/*     */   }
/*     */   
/*     */   static class ReactorRejectedExecutionException
/*     */     extends RejectedExecutionException {
/*     */     ReactorRejectedExecutionException(String message, Throwable cause) {
/* 786 */       super(message, cause);
/*     */     }
/*     */     
/*     */     ReactorRejectedExecutionException(String message) {
/* 790 */       super(message);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class StaticRejectedExecutionException
/*     */     extends RejectedExecutionException
/*     */   {
/*     */     StaticRejectedExecutionException(String message, Throwable cause) {
/* 801 */       super(message, cause);
/*     */     }
/*     */     
/*     */     StaticRejectedExecutionException(String message) {
/* 805 */       super(message);
/*     */     }
/*     */ 
/*     */     
/*     */     public synchronized Throwable fillInStackTrace() {
/* 810 */       return this;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class StaticThrowable
/*     */     extends Error
/*     */   {
/*     */     StaticThrowable(String message) {
/* 823 */       super(message, null, false, false);
/*     */     }
/*     */     
/*     */     StaticThrowable(String message, Throwable cause) {
/* 827 */       super(message, cause, false, false);
/*     */     }
/*     */     
/*     */     StaticThrowable(Throwable cause) {
/* 831 */       super(cause.toString(), cause, false, false);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\Exceptions.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */