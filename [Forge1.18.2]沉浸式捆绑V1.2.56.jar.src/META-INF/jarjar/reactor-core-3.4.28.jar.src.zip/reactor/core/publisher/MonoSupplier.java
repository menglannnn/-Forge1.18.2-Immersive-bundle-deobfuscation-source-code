/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.time.Duration;
/*    */ import java.util.Objects;
/*    */ import java.util.concurrent.Callable;
/*    */ import java.util.function.Supplier;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Fuseable;
/*    */ import reactor.core.Scannable;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MonoSupplier<T>
/*    */   extends Mono<T>
/*    */   implements Callable<T>, Fuseable, SourceProducer<T>
/*    */ {
/*    */   final Supplier<? extends T> supplier;
/*    */   
/*    */   MonoSupplier(Supplier<? extends T> callable) {
/* 42 */     this.supplier = Objects.<Supplier<? extends T>>requireNonNull(callable, "callable");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void subscribe(CoreSubscriber<? super T> actual) {
/* 48 */     Operators.MonoSubscriber<T, T> sds = new Operators.MonoSubscriber<>(actual);
/*    */     
/* 50 */     actual.onSubscribe(sds);
/*    */     
/* 52 */     if (sds.isCancelled()) {
/*    */       return;
/*    */     }
/*    */     
/*    */     try {
/* 57 */       T t = this.supplier.get();
/* 58 */       if (t == null) {
/* 59 */         sds.onComplete();
/*    */       } else {
/*    */         
/* 62 */         sds.complete(t);
/*    */       }
/*    */     
/* 65 */     } catch (Throwable e) {
/* 66 */       actual.onError(Operators.onOperatorError(e, actual.currentContext()));
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public T block(Duration m) {
/* 73 */     return this.supplier.get();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public T block() {
/* 80 */     return block(Duration.ZERO);
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public T call() throws Exception {
/* 86 */     return this.supplier.get();
/*    */   }
/*    */ 
/*    */   
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 91 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 92 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\MonoSupplier.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */