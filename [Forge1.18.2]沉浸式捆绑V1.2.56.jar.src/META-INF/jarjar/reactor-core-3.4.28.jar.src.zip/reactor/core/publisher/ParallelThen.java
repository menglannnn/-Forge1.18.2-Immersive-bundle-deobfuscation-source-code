/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ParallelThen
/*     */   extends Mono<Void>
/*     */   implements Scannable, Fuseable
/*     */ {
/*     */   final ParallelFlux<?> source;
/*     */   
/*     */   ParallelThen(ParallelFlux<?> source) {
/*  37 */     this.source = source;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  43 */     if (key == Scannable.Attr.PARENT) return this.source; 
/*  44 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */     
/*  46 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super Void> actual) {
/*  51 */     ThenMain parent = new ThenMain(actual, this.source.parallelism());
/*  52 */     actual.onSubscribe(parent);
/*     */     
/*  54 */     this.source.subscribe((CoreSubscriber<?>[])parent.subscribers);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class ThenMain
/*     */     extends Operators.MonoSubscriber<Object, Void>
/*     */   {
/*     */     final ParallelThen.ThenInner[] subscribers;
/*     */     
/*     */     volatile int remaining;
/*     */     
/*  65 */     static final AtomicIntegerFieldUpdater<ThenMain> REMAINING = AtomicIntegerFieldUpdater.newUpdater(ThenMain.class, "remaining");
/*     */ 
/*     */ 
/*     */     
/*     */     volatile Throwable error;
/*     */ 
/*     */     
/*  72 */     static final AtomicReferenceFieldUpdater<ThenMain, Throwable> ERROR = AtomicReferenceFieldUpdater.newUpdater(ThenMain.class, Throwable.class, "error");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     ThenMain(CoreSubscriber<? super Void> subscriber, int n) {
/*  78 */       super(subscriber);
/*  79 */       ParallelThen.ThenInner[] a = new ParallelThen.ThenInner[n];
/*  80 */       for (int i = 0; i < n; i++) {
/*  81 */         a[i] = new ParallelThen.ThenInner(this);
/*     */       }
/*  83 */       this.subscribers = a;
/*  84 */       REMAINING.lazySet(this, n);
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/*  90 */       if (key == Scannable.Attr.ERROR) return this.error; 
/*  91 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf((REMAINING.get(this) == 0)); 
/*  92 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/*  94 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/*  99 */       for (ParallelThen.ThenInner inner : this.subscribers) {
/* 100 */         inner.cancel();
/*     */       }
/* 102 */       super.cancel();
/*     */     }
/*     */     
/*     */     void innerError(Throwable ex) {
/* 106 */       if (ERROR.compareAndSet(this, null, ex)) {
/* 107 */         cancel();
/* 108 */         this.actual.onError(ex);
/*     */       }
/* 110 */       else if (this.error != ex) {
/* 111 */         Operators.onErrorDropped(ex, this.actual.currentContext());
/*     */       } 
/*     */     }
/*     */     
/*     */     void innerComplete() {
/* 116 */       if (REMAINING.decrementAndGet(this) == 0) {
/* 117 */         this.actual.onComplete();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class ThenInner
/*     */     implements InnerConsumer<Object>
/*     */   {
/*     */     final ParallelThen.ThenMain parent;
/*     */     
/*     */     volatile Subscription s;
/* 129 */     static final AtomicReferenceFieldUpdater<ThenInner, Subscription> S = AtomicReferenceFieldUpdater.newUpdater(ThenInner.class, Subscription.class, "s");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     ThenInner(ParallelThen.ThenMain parent) {
/* 135 */       this.parent = parent;
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/* 140 */       return this.parent.currentContext();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 146 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf((this.s == Operators.cancelledSubscription())); 
/* 147 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 148 */       if (key == Scannable.Attr.ACTUAL) return this.parent; 
/* 149 */       if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(2147483647); 
/* 150 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 152 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 157 */       if (Operators.setOnce(S, this, s)) {
/* 158 */         s.request(Long.MAX_VALUE);
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onNext(Object t) {
/* 165 */       Operators.onDiscard(t, this.parent.currentContext());
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 170 */       this.parent.innerError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 175 */       this.parent.innerComplete();
/*     */     }
/*     */     
/*     */     void cancel() {
/* 179 */       Operators.terminate(S, this);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\ParallelThen.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */