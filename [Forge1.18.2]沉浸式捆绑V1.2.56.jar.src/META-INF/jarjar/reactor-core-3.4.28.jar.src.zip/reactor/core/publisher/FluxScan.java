/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.function.BiFunction;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxScan<T>
/*     */   extends InternalFluxOperator<T, T>
/*     */ {
/*     */   final BiFunction<T, ? super T, T> accumulator;
/*     */   
/*     */   FluxScan(Flux<? extends T> source, BiFunction<T, ? super T, T> accumulator) {
/*  49 */     super(source);
/*  50 */     this.accumulator = Objects.<BiFunction<T, ? super T, T>>requireNonNull(accumulator, "accumulator");
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/*  55 */     return new ScanSubscriber<>(actual, this.accumulator);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  60 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  61 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class ScanSubscriber<T>
/*     */     implements InnerOperator<T, T>
/*     */   {
/*     */     final CoreSubscriber<? super T> actual;
/*     */     
/*     */     final BiFunction<T, ? super T, T> accumulator;
/*     */     
/*     */     Subscription s;
/*     */     
/*     */     T value;
/*     */     boolean done;
/*     */     
/*     */     ScanSubscriber(CoreSubscriber<? super T> actual, BiFunction<T, ? super T, T> accumulator) {
/*  78 */       this.actual = actual;
/*  79 */       this.accumulator = accumulator;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/*  84 */       if (Operators.validate(this.s, s)) {
/*  85 */         this.s = s;
/*     */         
/*  87 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/*  93 */       if (this.done) {
/*  94 */         Operators.onNextDropped(t, this.actual.currentContext());
/*     */         
/*     */         return;
/*     */       } 
/*  98 */       T v = this.value;
/*     */       
/* 100 */       if (v != null) {
/*     */         try {
/* 102 */           t = Objects.requireNonNull(this.accumulator.apply(v, t), "The accumulator returned a null value");
/*     */         
/*     */         }
/* 105 */         catch (Throwable e) {
/* 106 */           onError(Operators.onOperatorError(this.s, e, t, this.actual.currentContext()));
/*     */           return;
/*     */         } 
/*     */       }
/* 110 */       this.value = t;
/* 111 */       this.actual.onNext(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 116 */       if (this.done) {
/* 117 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*     */         return;
/*     */       } 
/* 120 */       this.done = true;
/* 121 */       this.value = null;
/* 122 */       this.actual.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 127 */       if (this.done) {
/*     */         return;
/*     */       }
/* 130 */       this.done = true;
/* 131 */       this.value = null;
/* 132 */       this.actual.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 138 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 139 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 140 */       if (key == Scannable.Attr.BUFFERED) return Integer.valueOf((this.value != null) ? 1 : 0); 
/* 141 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 143 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 148 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 153 */       this.s.request(n);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 158 */       this.s.cancel();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\FluxScan.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */