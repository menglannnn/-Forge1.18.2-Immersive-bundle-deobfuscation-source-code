/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import reactor.core.CorePublisher;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class FluxFromMonoOperator<I, O>
/*     */   extends Flux<O>
/*     */   implements Scannable, OptimizableOperator<O, I>
/*     */ {
/*     */   protected final Mono<? extends I> source;
/*     */   @Nullable
/*     */   final OptimizableOperator<?, I> optimizableOperator;
/*     */   
/*     */   protected FluxFromMonoOperator(Mono<? extends I> source) {
/*  50 */     this.source = Objects.<Mono<? extends I>>requireNonNull(source);
/*  51 */     if (source instanceof OptimizableOperator) {
/*     */       
/*  53 */       OptimizableOperator<?, I> optimSource = (OptimizableOperator)source;
/*  54 */       this.optimizableOperator = optimSource;
/*     */     } else {
/*     */       
/*  57 */       this.optimizableOperator = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  64 */     if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(getPrefetch()); 
/*  65 */     if (key == Scannable.Attr.PARENT) return this.source; 
/*  66 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void subscribe(CoreSubscriber<? super O> subscriber) {
/*  73 */     OptimizableOperator<I, O> operator = this;
/*     */     try {
/*     */       while (true) {
/*  76 */         subscriber = operator.subscribeOrReturn(subscriber);
/*  77 */         if (subscriber == null) {
/*     */           return;
/*     */         }
/*     */         
/*  81 */         OptimizableOperator<?, ? extends O> newSource = operator.nextOptimizableSource();
/*  82 */         if (newSource == null) {
/*  83 */           operator.source().subscribe(subscriber);
/*     */           return;
/*     */         } 
/*  86 */         OptimizableOperator<?, ? extends O> optimizableOperator1 = newSource;
/*     */       }
/*     */     
/*  89 */     } catch (Throwable e) {
/*  90 */       Operators.reportThrowInSubscribe(subscriber, e);
/*     */       return;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public abstract CoreSubscriber<? super I> subscribeOrReturn(CoreSubscriber<? super O> paramCoreSubscriber) throws Throwable;
/*     */ 
/*     */   
/*     */   public final CorePublisher<? extends I> source() {
/* 101 */     return this.source;
/*     */   }
/*     */ 
/*     */   
/*     */   public final OptimizableOperator<?, ? extends I> nextOptimizableSource() {
/* 106 */     return this.optimizableOperator;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\FluxFromMonoOperator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */