/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.Exceptions;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BaseSubscriber<T>
/*     */   implements CoreSubscriber<T>, Subscription, Disposable
/*     */ {
/*     */   volatile Subscription subscription;
/*  55 */   static AtomicReferenceFieldUpdater<BaseSubscriber, Subscription> S = AtomicReferenceFieldUpdater.newUpdater(BaseSubscriber.class, Subscription.class, "subscription");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Subscription upstream() {
/*  62 */     return this.subscription;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDisposed() {
/*  67 */     return (this.subscription == Operators.cancelledSubscription());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispose() {
/*  76 */     cancel();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void hookOnSubscribe(Subscription subscription) {
/*  89 */     subscription.request(Long.MAX_VALUE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void hookOnNext(T value) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void hookOnComplete() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void hookOnError(Throwable throwable) {
/* 118 */     throw Exceptions.errorCallbackNotImplemented(throwable);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void hookOnCancel() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void hookFinally(SignalType type) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void onSubscribe(Subscription s) {
/* 146 */     if (Operators.setOnce(S, this, s)) {
/*     */       try {
/* 148 */         hookOnSubscribe(s);
/*     */       }
/* 150 */       catch (Throwable throwable) {
/* 151 */         onError(Operators.onOperatorError(s, throwable, currentContext()));
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public final void onNext(T value) {
/* 158 */     Objects.requireNonNull(value, "onNext");
/*     */     try {
/* 160 */       hookOnNext(value);
/*     */     }
/* 162 */     catch (Throwable throwable) {
/* 163 */       onError(Operators.onOperatorError(this.subscription, throwable, value, currentContext()));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public final void onError(Throwable t) {
/* 169 */     Objects.requireNonNull(t, "onError");
/*     */     
/* 171 */     if (S.getAndSet(this, Operators.cancelledSubscription()) == 
/* 172 */       Operators.cancelledSubscription()) {
/*     */       
/* 174 */       Operators.onErrorDropped(t, currentContext());
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*     */     try {
/* 180 */       hookOnError(t);
/*     */     }
/* 182 */     catch (Throwable e) {
/* 183 */       e = Exceptions.addSuppressed(e, t);
/* 184 */       Operators.onErrorDropped(e, currentContext());
/*     */     } finally {
/*     */       
/* 187 */       safeHookFinally(SignalType.ON_ERROR);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public final void onComplete() {
/* 193 */     if (S.getAndSet(this, Operators.cancelledSubscription()) != 
/* 194 */       Operators.cancelledSubscription()) {
/*     */       
/*     */       try {
/* 197 */         hookOnComplete();
/*     */       }
/* 199 */       catch (Throwable throwable) {
/*     */         
/* 201 */         hookOnError(Operators.onOperatorError(throwable, currentContext()));
/*     */       } finally {
/*     */         
/* 204 */         safeHookFinally(SignalType.ON_COMPLETE);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public final void request(long n) {
/* 211 */     if (Operators.validate(n)) {
/* 212 */       Subscription s = this.subscription;
/* 213 */       if (s != null) {
/* 214 */         s.request(n);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void requestUnbounded() {
/* 223 */     request(Long.MAX_VALUE);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void cancel() {
/* 228 */     if (Operators.terminate(S, this)) {
/*     */       try {
/* 230 */         hookOnCancel();
/*     */       }
/* 232 */       catch (Throwable throwable) {
/* 233 */         hookOnError(Operators.onOperatorError(this.subscription, throwable, currentContext()));
/*     */       } finally {
/*     */         
/* 236 */         safeHookFinally(SignalType.CANCEL);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   void safeHookFinally(SignalType type) {
/*     */     try {
/* 243 */       hookFinally(type);
/*     */     }
/* 245 */     catch (Throwable finallyFailure) {
/* 246 */       Operators.onErrorDropped(finallyFailure, currentContext());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 252 */     return getClass().getSimpleName();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\BaseSubscriber.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */