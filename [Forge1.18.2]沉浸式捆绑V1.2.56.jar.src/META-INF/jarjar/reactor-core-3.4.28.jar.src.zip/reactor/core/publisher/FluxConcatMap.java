/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.Queue;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Supplier;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxConcatMap<T, R>
/*     */   extends InternalFluxOperator<T, R>
/*     */ {
/*     */   final Function<? super T, ? extends Publisher<? extends R>> mapper;
/*     */   final Supplier<? extends Queue<T>> queueSupplier;
/*     */   final int prefetch;
/*     */   final ErrorMode errorMode;
/*     */   
/*     */   enum ErrorMode
/*     */   {
/*  64 */     IMMEDIATE,
/*     */ 
/*     */     
/*  67 */     BOUNDARY,
/*     */ 
/*     */     
/*  70 */     END;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T, R> CoreSubscriber<T> subscriber(CoreSubscriber<? super R> s, Function<? super T, ? extends Publisher<? extends R>> mapper, Supplier<? extends Queue<T>> queueSupplier, int prefetch, ErrorMode errorMode) {
/*  77 */     switch (errorMode) {
/*     */       case BOUNDARY:
/*  79 */         return new ConcatMapDelayed<>(s, mapper, queueSupplier, prefetch, false);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case END:
/*  85 */         return new ConcatMapDelayed<>(s, mapper, queueSupplier, prefetch, true);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  91 */     return new ConcatMapImmediate<>(s, mapper, queueSupplier, prefetch);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   FluxConcatMap(Flux<? extends T> source, Function<? super T, ? extends Publisher<? extends R>> mapper, Supplier<? extends Queue<T>> queueSupplier, int prefetch, ErrorMode errorMode) {
/* 100 */     super(source);
/* 101 */     if (prefetch <= 0) {
/* 102 */       throw new IllegalArgumentException("prefetch > 0 required but it was " + prefetch);
/*     */     }
/* 104 */     this.mapper = Objects.<Function<? super T, ? extends Publisher<? extends R>>>requireNonNull(mapper, "mapper");
/* 105 */     this.queueSupplier = Objects.<Supplier<? extends Queue<T>>>requireNonNull(queueSupplier, "queueSupplier");
/* 106 */     this.prefetch = prefetch;
/* 107 */     this.errorMode = Objects.<ErrorMode>requireNonNull(errorMode, "errorMode");
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPrefetch() {
/* 112 */     return this.prefetch;
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super R> actual) {
/* 117 */     if (FluxFlatMap.trySubscribeScalarMap((Publisher<? extends T>)this.source, actual, this.mapper, false, true)) {
/* 118 */       return null;
/*     */     }
/*     */     
/* 121 */     return subscriber(actual, this.mapper, this.queueSupplier, this.prefetch, this.errorMode);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/* 126 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 127 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class ConcatMapImmediate<T, R>
/*     */     implements FluxConcatMapSupport<T, R>
/*     */   {
/*     */     final CoreSubscriber<? super R> actual;
/*     */     
/*     */     final Context ctx;
/*     */     
/*     */     final FluxConcatMap.ConcatMapInner<R> inner;
/*     */     
/*     */     final Function<? super T, ? extends Publisher<? extends R>> mapper;
/*     */     
/*     */     final Supplier<? extends Queue<T>> queueSupplier;
/*     */     
/*     */     final int prefetch;
/*     */     
/*     */     final int limit;
/*     */     
/*     */     Subscription s;
/*     */     
/*     */     int consumed;
/*     */     
/*     */     volatile Queue<T> queue;
/*     */     
/*     */     volatile boolean done;
/*     */     
/*     */     volatile boolean cancelled;
/*     */     
/*     */     volatile Throwable error;
/* 159 */     static final AtomicReferenceFieldUpdater<ConcatMapImmediate, Throwable> ERROR = AtomicReferenceFieldUpdater.newUpdater(ConcatMapImmediate.class, Throwable.class, "error");
/*     */ 
/*     */     
/*     */     volatile boolean active;
/*     */ 
/*     */     
/*     */     volatile int wip;
/*     */ 
/*     */     
/* 168 */     static final AtomicIntegerFieldUpdater<ConcatMapImmediate> WIP = AtomicIntegerFieldUpdater.newUpdater(ConcatMapImmediate.class, "wip");
/*     */ 
/*     */     
/*     */     volatile int guard;
/*     */     
/* 173 */     static final AtomicIntegerFieldUpdater<ConcatMapImmediate> GUARD = AtomicIntegerFieldUpdater.newUpdater(ConcatMapImmediate.class, "guard");
/*     */ 
/*     */     
/*     */     int sourceMode;
/*     */ 
/*     */     
/*     */     ConcatMapImmediate(CoreSubscriber<? super R> actual, Function<? super T, ? extends Publisher<? extends R>> mapper, Supplier<? extends Queue<T>> queueSupplier, int prefetch) {
/* 180 */       this.actual = actual;
/* 181 */       this.ctx = actual.currentContext();
/* 182 */       this.mapper = mapper;
/* 183 */       this.queueSupplier = queueSupplier;
/* 184 */       this.prefetch = prefetch;
/* 185 */       this.limit = Operators.unboundedOrLimit(prefetch);
/* 186 */       this.inner = new FluxConcatMap.ConcatMapInner<>(this);
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 192 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 193 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf((this.done || this.error == Exceptions.TERMINATED)); 
/* 194 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(this.cancelled); 
/* 195 */       if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(this.prefetch); 
/* 196 */       if (key == Scannable.Attr.BUFFERED) return Integer.valueOf((this.queue != null) ? this.queue.size() : 0); 
/* 197 */       if (key == Scannable.Attr.ERROR) return this.error; 
/* 198 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 200 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 205 */       if (Operators.validate(this.s, s)) {
/* 206 */         this.s = s;
/*     */         
/* 208 */         if (s instanceof Fuseable.QueueSubscription) {
/* 209 */           Fuseable.QueueSubscription<T> f = (Fuseable.QueueSubscription<T>)s;
/*     */           
/* 211 */           int m = f.requestFusion(7);
/* 212 */           if (m == 1) {
/* 213 */             this.sourceMode = 1;
/* 214 */             this.queue = (Queue<T>)f;
/* 215 */             this.done = true;
/*     */             
/* 217 */             this.actual.onSubscribe(this);
/*     */             
/* 219 */             drain();
/*     */             return;
/*     */           } 
/* 222 */           if (m == 2) {
/* 223 */             this.sourceMode = 2;
/* 224 */             this.queue = (Queue<T>)f;
/*     */           } else {
/*     */             
/* 227 */             this.queue = this.queueSupplier.get();
/*     */           } 
/*     */         } else {
/*     */           
/* 231 */           this.queue = this.queueSupplier.get();
/*     */         } 
/*     */         
/* 234 */         this.actual.onSubscribe(this);
/*     */         
/* 236 */         s.request(Operators.unboundedOrPrefetch(this.prefetch));
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 242 */       if (this.sourceMode == 2) {
/* 243 */         drain();
/*     */       }
/* 245 */       else if (!this.queue.offer(t)) {
/* 246 */         onError(Operators.onOperatorError(this.s, Exceptions.failWithOverflow("Queue is full: Reactive Streams source doesn't respect backpressure"), t, this.ctx));
/*     */         
/* 248 */         Operators.onDiscard(t, this.ctx);
/*     */       } else {
/*     */         
/* 251 */         drain();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 257 */       if (Exceptions.addThrowable(ERROR, this, t)) {
/* 258 */         this.inner.cancel();
/*     */         
/* 260 */         if (GUARD.getAndIncrement(this) == 0) {
/* 261 */           t = Exceptions.terminate(ERROR, this);
/* 262 */           if (t != Exceptions.TERMINATED) {
/* 263 */             this.actual.onError(t);
/* 264 */             Operators.onDiscardQueueWithClear(this.queue, this.ctx, null);
/*     */           } 
/*     */         } 
/*     */       } else {
/*     */         
/* 269 */         Operators.onErrorDropped(t, this.ctx);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 275 */       this.done = true;
/* 276 */       drain();
/*     */     }
/*     */ 
/*     */     
/*     */     public void innerNext(R value) {
/* 281 */       if (this.guard == 0 && GUARD.compareAndSet(this, 0, 1)) {
/* 282 */         this.actual.onNext(value);
/* 283 */         if (GUARD.compareAndSet(this, 1, 0)) {
/*     */           return;
/*     */         }
/* 286 */         Throwable e = Exceptions.terminate(ERROR, this);
/* 287 */         if (e != Exceptions.TERMINATED) {
/* 288 */           this.actual.onError(e);
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void innerComplete() {
/* 295 */       this.active = false;
/* 296 */       drain();
/*     */     }
/*     */ 
/*     */     
/*     */     public void innerError(Throwable e) {
/* 301 */       e = Operators.onNextInnerError(e, currentContext(), this.s);
/* 302 */       if (e != null) {
/* 303 */         if (Exceptions.addThrowable(ERROR, this, e)) {
/* 304 */           this.s.cancel();
/*     */           
/* 306 */           if (GUARD.getAndIncrement(this) == 0) {
/* 307 */             e = Exceptions.terminate(ERROR, this);
/* 308 */             if (e != Exceptions.TERMINATED) {
/* 309 */               this.actual.onError(e);
/* 310 */               Operators.onDiscardQueueWithClear(this.queue, this.ctx, null);
/*     */             } 
/*     */           } 
/*     */         } else {
/*     */           
/* 315 */           Operators.onErrorDropped(e, this.ctx);
/*     */         } 
/*     */       } else {
/*     */         
/* 319 */         this.active = false;
/* 320 */         drain();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super R> actual() {
/* 326 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 331 */       this.inner.request(n);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 336 */       if (!this.cancelled) {
/* 337 */         this.cancelled = true;
/*     */         
/* 339 */         this.inner.cancel();
/* 340 */         this.s.cancel();
/* 341 */         Operators.onDiscardQueueWithClear(this.queue, this.ctx, null);
/*     */       } 
/*     */     }
/*     */     
/*     */     void drain() {
/* 346 */       if (WIP.getAndIncrement(this) == 0)
/*     */         while (true) {
/* 348 */           if (this.cancelled) {
/*     */             return;
/*     */           }
/*     */           
/* 352 */           if (!this.active) {
/* 353 */             T v; boolean d = this.done;
/*     */ 
/*     */ 
/*     */             
/*     */             try {
/* 358 */               v = this.queue.poll();
/*     */             }
/* 360 */             catch (Throwable e) {
/* 361 */               this.actual.onError(Operators.onOperatorError(this.s, e, this.ctx));
/*     */               
/*     */               return;
/*     */             } 
/* 365 */             boolean empty = (v == null);
/*     */             
/* 367 */             if (d && empty) {
/* 368 */               this.actual.onComplete();
/*     */               
/*     */               return;
/*     */             } 
/* 372 */             if (!empty) {
/*     */               Publisher<? extends R> p;
/*     */               
/*     */               try {
/* 376 */                 p = Objects.<Publisher<? extends R>>requireNonNull(this.mapper.apply(v), "The mapper returned a null Publisher");
/*     */               
/*     */               }
/* 379 */               catch (Throwable e) {
/* 380 */                 Operators.onDiscard(v, this.ctx);
/* 381 */                 Throwable e_ = Operators.onNextError(v, e, this.ctx, this.s);
/* 382 */                 if (e_ != null) {
/* 383 */                   this.actual.onError(Operators.onOperatorError(this.s, e, v, this.ctx));
/*     */ 
/*     */                   
/*     */                   return;
/*     */                 } 
/*     */                 
/*     */                 continue;
/*     */               } 
/*     */               
/* 392 */               if (this.sourceMode != 1) {
/* 393 */                 int c = this.consumed + 1;
/* 394 */                 if (c == this.limit) {
/* 395 */                   this.consumed = 0;
/* 396 */                   this.s.request(c);
/*     */                 } else {
/*     */                   
/* 399 */                   this.consumed = c;
/*     */                 } 
/*     */               } 
/*     */               
/* 403 */               if (p instanceof Callable) {
/* 404 */                 R vr; Callable<R> callable = (Callable)p;
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/*     */                 try {
/* 410 */                   vr = callable.call();
/*     */                 }
/* 412 */                 catch (Throwable e) {
/* 413 */                   Throwable e_ = Operators.onNextError(v, e, this.ctx, this.s);
/* 414 */                   if (e_ != null) {
/* 415 */                     this.actual.onError(Operators.onOperatorError(this.s, e, v, this.ctx));
/*     */                     
/* 417 */                     Operators.onDiscardQueueWithClear(this.queue, this.ctx, null);
/*     */                     
/*     */                     return;
/*     */                   } 
/*     */                   
/*     */                   continue;
/*     */                 } 
/*     */                 
/* 425 */                 if (vr == null) {
/*     */                   continue;
/*     */                 }
/*     */                 
/* 429 */                 if (this.inner.isUnbounded()) {
/* 430 */                   if (this.guard == 0 && GUARD.compareAndSet(this, 0, 1)) {
/* 431 */                     this.actual.onNext(vr);
/* 432 */                     if (!GUARD.compareAndSet(this, 1, 0)) {
/*     */                       
/* 434 */                       Throwable e = Exceptions.terminate(ERROR, this);
/* 435 */                       if (e != Exceptions.TERMINATED) {
/* 436 */                         this.actual.onError(e);
/*     */                       }
/*     */                       
/*     */                       return;
/*     */                     } 
/*     */                   } 
/*     */                   continue;
/*     */                 } 
/* 444 */                 this.active = true;
/* 445 */                 this.inner.set(new FluxConcatMap.WeakScalarSubscription<>(vr, this.inner));
/*     */               
/*     */               }
/*     */               else {
/*     */                 
/* 450 */                 this.active = true;
/* 451 */                 p.subscribe((Subscriber)this.inner);
/*     */               } 
/*     */             } 
/*     */           } 
/* 455 */           if (WIP.decrementAndGet(this) == 0) {
/*     */             break;
/*     */           }
/*     */         }  
/*     */     }
/*     */   }
/*     */   
/*     */   static final class WeakScalarSubscription<T>
/*     */     implements Subscription
/*     */   {
/*     */     final CoreSubscriber<? super T> actual;
/*     */     final T value;
/*     */     boolean once;
/*     */     
/*     */     WeakScalarSubscription(T value, CoreSubscriber<? super T> actual) {
/* 470 */       this.value = value;
/* 471 */       this.actual = actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 476 */       if (n > 0L && !this.once) {
/* 477 */         this.once = true;
/* 478 */         CoreSubscriber<? super T> coreSubscriber = this.actual;
/* 479 */         coreSubscriber.onNext(this.value);
/* 480 */         coreSubscriber.onComplete();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 486 */       Operators.onDiscard(this.value, this.actual.currentContext());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class ConcatMapDelayed<T, R>
/*     */     implements FluxConcatMapSupport<T, R>
/*     */   {
/*     */     final CoreSubscriber<? super R> actual;
/*     */     
/*     */     final FluxConcatMap.ConcatMapInner<R> inner;
/*     */     
/*     */     final Function<? super T, ? extends Publisher<? extends R>> mapper;
/*     */     
/*     */     final Supplier<? extends Queue<T>> queueSupplier;
/*     */     
/*     */     final int prefetch;
/*     */     
/*     */     final int limit;
/*     */     
/*     */     final boolean veryEnd;
/*     */     
/*     */     Subscription s;
/*     */     
/*     */     int consumed;
/*     */     
/*     */     volatile Queue<T> queue;
/*     */     
/*     */     volatile boolean done;
/*     */     
/*     */     volatile boolean cancelled;
/*     */     
/*     */     volatile Throwable error;
/*     */     
/* 520 */     static final AtomicReferenceFieldUpdater<ConcatMapDelayed, Throwable> ERROR = AtomicReferenceFieldUpdater.newUpdater(ConcatMapDelayed.class, Throwable.class, "error");
/*     */ 
/*     */     
/*     */     volatile boolean active;
/*     */ 
/*     */     
/*     */     volatile int wip;
/*     */ 
/*     */     
/* 529 */     static final AtomicIntegerFieldUpdater<ConcatMapDelayed> WIP = AtomicIntegerFieldUpdater.newUpdater(ConcatMapDelayed.class, "wip");
/*     */ 
/*     */     
/*     */     int sourceMode;
/*     */ 
/*     */ 
/*     */     
/*     */     ConcatMapDelayed(CoreSubscriber<? super R> actual, Function<? super T, ? extends Publisher<? extends R>> mapper, Supplier<? extends Queue<T>> queueSupplier, int prefetch, boolean veryEnd) {
/* 537 */       this.actual = actual;
/* 538 */       this.mapper = mapper;
/* 539 */       this.queueSupplier = queueSupplier;
/* 540 */       this.prefetch = prefetch;
/* 541 */       this.limit = Operators.unboundedOrLimit(prefetch);
/* 542 */       this.veryEnd = veryEnd;
/* 543 */       this.inner = new FluxConcatMap.ConcatMapInner<>(this);
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super R> actual() {
/* 548 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 554 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 555 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 556 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(this.cancelled); 
/* 557 */       if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(this.prefetch); 
/* 558 */       if (key == Scannable.Attr.BUFFERED) return Integer.valueOf((this.queue != null) ? this.queue.size() : 0); 
/* 559 */       if (key == Scannable.Attr.ERROR) return this.error; 
/* 560 */       if (key == Scannable.Attr.DELAY_ERROR) return Boolean.valueOf(true); 
/* 561 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 563 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 568 */       if (Operators.validate(this.s, s)) {
/* 569 */         this.s = s;
/*     */         
/* 571 */         if (s instanceof Fuseable.QueueSubscription) {
/* 572 */           Fuseable.QueueSubscription<T> f = (Fuseable.QueueSubscription<T>)s;
/*     */ 
/*     */           
/* 575 */           int m = f.requestFusion(7);
/*     */           
/* 577 */           if (m == 1) {
/* 578 */             this.sourceMode = 1;
/* 579 */             this.queue = (Queue<T>)f;
/* 580 */             this.done = true;
/*     */             
/* 582 */             this.actual.onSubscribe(this);
/*     */             
/* 584 */             drain();
/*     */             return;
/*     */           } 
/* 587 */           if (m == 2) {
/* 588 */             this.sourceMode = 2;
/* 589 */             this.queue = (Queue<T>)f;
/*     */           } else {
/*     */             
/* 592 */             this.queue = this.queueSupplier.get();
/*     */           } 
/*     */         } else {
/*     */           
/* 596 */           this.queue = this.queueSupplier.get();
/*     */         } 
/*     */         
/* 599 */         this.actual.onSubscribe(this);
/*     */         
/* 601 */         s.request(Operators.unboundedOrPrefetch(this.prefetch));
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 607 */       if (this.sourceMode == 2) {
/* 608 */         drain();
/*     */       }
/* 610 */       else if (!this.queue.offer(t)) {
/* 611 */         Context ctx = this.actual.currentContext();
/* 612 */         onError(Operators.onOperatorError(this.s, Exceptions.failWithOverflow("Queue is full: Reactive Streams source doesn't respect backpressure"), t, ctx));
/*     */         
/* 614 */         Operators.onDiscard(t, ctx);
/*     */       } else {
/*     */         
/* 617 */         drain();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 623 */       if (Exceptions.addThrowable(ERROR, this, t)) {
/* 624 */         this.done = true;
/* 625 */         drain();
/*     */       } else {
/*     */         
/* 628 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 634 */       this.done = true;
/* 635 */       drain();
/*     */     }
/*     */ 
/*     */     
/*     */     public void innerNext(R value) {
/* 640 */       this.actual.onNext(value);
/*     */     }
/*     */ 
/*     */     
/*     */     public void innerComplete() {
/* 645 */       this.active = false;
/* 646 */       drain();
/*     */     }
/*     */ 
/*     */     
/*     */     public void innerError(Throwable e) {
/* 651 */       e = Operators.onNextInnerError(e, currentContext(), this.s);
/* 652 */       if (e != null) {
/* 653 */         if (Exceptions.addThrowable(ERROR, this, e)) {
/* 654 */           if (!this.veryEnd) {
/* 655 */             this.s.cancel();
/* 656 */             this.done = true;
/*     */           } 
/* 658 */           this.active = false;
/* 659 */           drain();
/*     */         } else {
/*     */           
/* 662 */           Operators.onErrorDropped(e, this.actual.currentContext());
/*     */         } 
/*     */       } else {
/*     */         
/* 666 */         this.active = false;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 672 */       this.inner.request(n);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 677 */       if (!this.cancelled) {
/* 678 */         this.cancelled = true;
/*     */         
/* 680 */         this.inner.cancel();
/* 681 */         this.s.cancel();
/* 682 */         Operators.onDiscardQueueWithClear(this.queue, this.actual.currentContext(), null);
/*     */       } 
/*     */     }
/*     */     
/*     */     void drain() {
/* 687 */       if (WIP.getAndIncrement(this) == 0) {
/* 688 */         Context ctx = null;
/*     */         while (true) {
/* 690 */           if (this.cancelled) {
/*     */             return;
/*     */           }
/*     */           
/* 694 */           if (!this.active) {
/*     */             T v;
/* 696 */             boolean d = this.done;
/*     */             
/* 698 */             if (d && !this.veryEnd) {
/* 699 */               Throwable ex = this.error;
/* 700 */               if (ex != null) {
/* 701 */                 ex = Exceptions.terminate(ERROR, this);
/* 702 */                 if (ex != Exceptions.TERMINATED) {
/* 703 */                   this.actual.onError(ex);
/*     */                 }
/*     */ 
/*     */                 
/*     */                 return;
/*     */               } 
/*     */             } 
/*     */             
/*     */             try {
/* 712 */               v = this.queue.poll();
/*     */             }
/* 714 */             catch (Throwable e) {
/* 715 */               this.actual.onError(Operators.onOperatorError(this.s, e, this.actual.currentContext()));
/*     */               
/*     */               return;
/*     */             } 
/* 719 */             boolean empty = (v == null);
/*     */             
/* 721 */             if (d && empty) {
/* 722 */               Throwable ex = Exceptions.terminate(ERROR, this);
/* 723 */               if (ex != null && ex != Exceptions.TERMINATED) {
/* 724 */                 this.actual.onError(ex);
/*     */               } else {
/*     */                 
/* 727 */                 this.actual.onComplete();
/*     */               } 
/*     */               
/*     */               return;
/*     */             } 
/* 732 */             if (!empty) {
/*     */               Publisher<? extends R> p;
/*     */               
/*     */               try {
/* 736 */                 p = Objects.<Publisher<? extends R>>requireNonNull(this.mapper.apply(v), "The mapper returned a null Publisher");
/*     */               
/*     */               }
/* 739 */               catch (Throwable e) {
/* 740 */                 if (ctx == null) {
/* 741 */                   ctx = this.actual.currentContext();
/*     */                 }
/* 743 */                 Operators.onDiscard(v, ctx);
/* 744 */                 Throwable e_ = Operators.onNextError(v, e, ctx, this.s);
/* 745 */                 if (e_ != null) {
/* 746 */                   this.actual.onError(Operators.onOperatorError(this.s, e, v, ctx));
/*     */                   
/*     */                   return;
/*     */                 } 
/*     */                 
/*     */                 continue;
/*     */               } 
/*     */               
/* 754 */               if (this.sourceMode != 1) {
/* 755 */                 int c = this.consumed + 1;
/* 756 */                 if (c == this.limit) {
/* 757 */                   this.consumed = 0;
/* 758 */                   this.s.request(c);
/*     */                 } else {
/*     */                   
/* 761 */                   this.consumed = c;
/*     */                 } 
/*     */               } 
/*     */               
/* 765 */               if (p instanceof Callable) {
/* 766 */                 R vr; Callable<R> supplier = (Callable)p;
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/*     */                 try {
/* 772 */                   vr = supplier.call();
/*     */                 }
/* 774 */                 catch (Throwable e) {
/*     */                   
/* 776 */                   if (ctx == null) {
/* 777 */                     ctx = this.actual.currentContext();
/*     */                   }
/* 779 */                   Throwable e_ = Operators.onNextError(v, e, ctx);
/* 780 */                   if (e_ == null) {
/*     */                     continue;
/*     */                   }
/*     */                   
/* 784 */                   if (this.veryEnd && Exceptions.addThrowable(ERROR, this, e_)) {
/*     */                     continue;
/*     */                   }
/*     */                   
/* 788 */                   this.actual.onError(Operators.onOperatorError(this.s, e_, v, ctx));
/*     */                   
/*     */                   return;
/*     */                 } 
/*     */                 
/* 793 */                 if (vr == null) {
/*     */                   continue;
/*     */                 }
/*     */                 
/* 797 */                 if (this.inner.isUnbounded()) {
/* 798 */                   this.actual.onNext(vr);
/*     */                   
/*     */                   continue;
/*     */                 } 
/* 802 */                 this.active = true;
/* 803 */                 this.inner.set(new FluxConcatMap.WeakScalarSubscription<>(vr, this.inner));
/*     */               }
/*     */               else {
/*     */                 
/* 807 */                 this.active = true;
/* 808 */                 p.subscribe((Subscriber)this.inner);
/*     */               } 
/*     */             } 
/*     */           } 
/* 812 */           if (WIP.decrementAndGet(this) == 0) {
/*     */             break;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class ConcatMapInner<R>
/*     */     extends Operators.MultiSubscriptionSubscriber<R, R>
/*     */   {
/*     */     final FluxConcatMap.FluxConcatMapSupport<?, R> parent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     long produced;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     ConcatMapInner(FluxConcatMap.FluxConcatMapSupport<?, R> parent) {
/* 841 */       super(Operators.emptySubscriber());
/* 842 */       this.parent = parent;
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/* 847 */       return this.parent.currentContext();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 853 */       if (key == Scannable.Attr.ACTUAL) return this.parent; 
/* 854 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 856 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(R t) {
/* 861 */       this.produced++;
/*     */       
/* 863 */       this.parent.innerNext(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 868 */       long p = this.produced;
/*     */       
/* 870 */       if (p != 0L) {
/* 871 */         this.produced = 0L;
/* 872 */         produced(p);
/*     */       } 
/*     */       
/* 875 */       this.parent.innerError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 880 */       long p = this.produced;
/*     */       
/* 882 */       if (p != 0L) {
/* 883 */         this.produced = 0L;
/* 884 */         produced(p);
/*     */       } 
/*     */       
/* 887 */       this.parent.innerComplete();
/*     */     }
/*     */   }
/*     */   
/*     */   static interface FluxConcatMapSupport<I, T> extends InnerOperator<I, T> {
/*     */     void innerNext(T param1T);
/*     */     
/*     */     void innerComplete();
/*     */     
/*     */     void innerError(Throwable param1Throwable);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\FluxConcatMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */