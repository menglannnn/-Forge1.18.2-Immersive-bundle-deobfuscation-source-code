/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.Queue;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.stream.Stream;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxPublishMulticast<T, R>
/*     */   extends InternalFluxOperator<T, R>
/*     */   implements Fuseable
/*     */ {
/*     */   final Function<? super Flux<T>, ? extends Publisher<? extends R>> transform;
/*     */   final Supplier<? extends Queue<T>> queueSupplier;
/*     */   final int prefetch;
/*     */   
/*     */   FluxPublishMulticast(Flux<? extends T> source, Function<? super Flux<T>, ? extends Publisher<? extends R>> transform, int prefetch, Supplier<? extends Queue<T>> queueSupplier) {
/*  61 */     super(source);
/*  62 */     if (prefetch < 1) {
/*  63 */       throw new IllegalArgumentException("prefetch > 0 required but it was " + prefetch);
/*     */     }
/*  65 */     this.prefetch = prefetch;
/*  66 */     this.transform = Objects.<Function<? super Flux<T>, ? extends Publisher<? extends R>>>requireNonNull(transform, "transform");
/*  67 */     this.queueSupplier = Objects.<Supplier<? extends Queue<T>>>requireNonNull(queueSupplier, "queueSupplier");
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPrefetch() {
/*  72 */     return this.prefetch;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super R> actual) {
/*  79 */     FluxPublishMulticaster<T> multicast = new FluxPublishMulticaster<>(this.prefetch, this.queueSupplier, actual.currentContext());
/*     */     
/*  81 */     Publisher<? extends R> out = Objects.<Publisher<? extends R>>requireNonNull(this.transform.apply(multicast), "The transform returned a null Publisher");
/*     */ 
/*     */     
/*  84 */     if (out instanceof Fuseable) {
/*  85 */       out.subscribe((Subscriber)new CancelFuseableMulticaster<>(actual, multicast));
/*     */     } else {
/*     */       
/*  88 */       out.subscribe((Subscriber)new CancelMulticaster<>(actual, multicast));
/*     */     } 
/*     */     
/*  91 */     return multicast;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  96 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  97 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class FluxPublishMulticaster<T>
/*     */     extends Flux<T>
/*     */     implements InnerConsumer<T>, PublishMulticasterParent
/*     */   {
/*     */     final int limit;
/*     */     
/*     */     final int prefetch;
/*     */     
/*     */     final Supplier<? extends Queue<T>> queueSupplier;
/*     */     
/*     */     Queue<T> queue;
/*     */     
/*     */     volatile Subscription s;
/* 114 */     static final AtomicReferenceFieldUpdater<FluxPublishMulticaster, Subscription> S = AtomicReferenceFieldUpdater.newUpdater(FluxPublishMulticaster.class, Subscription.class, "s");
/*     */ 
/*     */ 
/*     */     
/*     */     volatile int wip;
/*     */ 
/*     */     
/* 121 */     static final AtomicIntegerFieldUpdater<FluxPublishMulticaster> WIP = AtomicIntegerFieldUpdater.newUpdater(FluxPublishMulticaster.class, "wip");
/*     */ 
/*     */     
/*     */     volatile FluxPublishMulticast.PublishMulticastInner<T>[] subscribers;
/*     */     
/* 126 */     static final AtomicReferenceFieldUpdater<FluxPublishMulticaster, FluxPublishMulticast.PublishMulticastInner[]> SUBSCRIBERS = (AtomicReferenceFieldUpdater)AtomicReferenceFieldUpdater.newUpdater(FluxPublishMulticaster.class, (Class)FluxPublishMulticast.PublishMulticastInner[].class, "subscribers");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 132 */     static final FluxPublishMulticast.PublishMulticastInner[] EMPTY = new FluxPublishMulticast.PublishMulticastInner[0];
/*     */ 
/*     */     
/* 135 */     static final FluxPublishMulticast.PublishMulticastInner[] TERMINATED = new FluxPublishMulticast.PublishMulticastInner[0];
/*     */ 
/*     */     
/*     */     volatile boolean done;
/*     */ 
/*     */     
/*     */     volatile boolean connected;
/*     */     
/*     */     Throwable error;
/*     */     
/*     */     final Context context;
/*     */     
/*     */     int produced;
/*     */     
/*     */     int sourceMode;
/*     */ 
/*     */     
/*     */     FluxPublishMulticaster(int prefetch, Supplier<? extends Queue<T>> queueSupplier, Context ctx) {
/* 153 */       this.prefetch = prefetch;
/* 154 */       this.limit = Operators.unboundedOrLimit(prefetch);
/* 155 */       this.queueSupplier = queueSupplier;
/* 156 */       SUBSCRIBERS.lazySet(this, EMPTY);
/* 157 */       this.context = ctx;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 163 */       if (key == Scannable.Attr.PARENT) {
/* 164 */         return this.s;
/*     */       }
/* 166 */       if (key == Scannable.Attr.ERROR) {
/* 167 */         return this.error;
/*     */       }
/* 169 */       if (key == Scannable.Attr.CANCELLED) {
/* 170 */         return Boolean.valueOf((this.s == Operators.cancelledSubscription()));
/*     */       }
/* 172 */       if (key == Scannable.Attr.TERMINATED) {
/* 173 */         return Boolean.valueOf(this.done);
/*     */       }
/* 175 */       if (key == Scannable.Attr.PREFETCH) {
/* 176 */         return Integer.valueOf(this.prefetch);
/*     */       }
/* 178 */       if (key == Scannable.Attr.BUFFERED) {
/* 179 */         return Integer.valueOf((this.queue != null) ? this.queue.size() : 0);
/*     */       }
/* 181 */       if (key == Scannable.Attr.RUN_STYLE) {
/* 182 */         return Scannable.Attr.RunStyle.SYNC;
/*     */       }
/*     */       
/* 185 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public Stream<? extends Scannable> inners() {
/* 190 */       return Stream.of((Scannable[])this.subscribers);
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/* 195 */       return this.context;
/*     */     }
/*     */ 
/*     */     
/*     */     public void subscribe(CoreSubscriber<? super T> actual) {
/* 200 */       FluxPublishMulticast.PublishMulticastInner<T> pcs = new FluxPublishMulticast.PublishMulticastInner<>(this, actual);
/* 201 */       actual.onSubscribe(pcs);
/*     */       
/* 203 */       if (add(pcs)) {
/* 204 */         if (pcs.requested == Long.MIN_VALUE) {
/* 205 */           remove(pcs);
/*     */           return;
/*     */         } 
/* 208 */         drain();
/*     */       } else {
/*     */         
/* 211 */         Throwable ex = this.error;
/* 212 */         if (ex != null) {
/* 213 */           actual.onError(ex);
/*     */         } else {
/*     */           
/* 216 */           actual.onComplete();
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 223 */       if (Operators.setOnce(S, this, s)) {
/*     */         
/* 225 */         if (s instanceof Fuseable.QueueSubscription) {
/* 226 */           Fuseable.QueueSubscription<T> qs = (Fuseable.QueueSubscription<T>)s;
/*     */ 
/*     */           
/* 229 */           int m = qs.requestFusion(3);
/* 230 */           if (m == 1) {
/* 231 */             this.sourceMode = m;
/*     */             
/* 233 */             this.queue = (Queue<T>)qs;
/* 234 */             this.done = true;
/* 235 */             this.connected = true;
/*     */             
/* 237 */             drain();
/*     */             
/*     */             return;
/*     */           } 
/* 241 */           if (m == 2) {
/* 242 */             this.sourceMode = m;
/*     */             
/* 244 */             this.queue = (Queue<T>)qs;
/* 245 */             this.connected = true;
/*     */             
/* 247 */             s.request(Operators.unboundedOrPrefetch(this.prefetch));
/*     */             
/*     */             return;
/*     */           } 
/*     */         } 
/*     */         
/* 253 */         this.queue = this.queueSupplier.get();
/* 254 */         this.connected = true;
/*     */         
/* 256 */         s.request(Operators.unboundedOrPrefetch(this.prefetch));
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 262 */       if (this.done) {
/* 263 */         Operators.onNextDropped(t, this.context);
/*     */         
/*     */         return;
/*     */       } 
/* 267 */       if (this.sourceMode != 2 && 
/* 268 */         !this.queue.offer(t)) {
/* 269 */         onError(Operators.onOperatorError(this.s, 
/* 270 */               Exceptions.failWithOverflow("Queue is full: Reactive Streams source doesn't respect backpressure"), t, this.context));
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/* 276 */       drain();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 281 */       if (this.done) {
/* 282 */         Operators.onErrorDropped(t, this.context);
/*     */         return;
/*     */       } 
/* 285 */       this.error = t;
/* 286 */       this.done = true;
/* 287 */       drain();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 292 */       this.done = true;
/* 293 */       drain();
/*     */     }
/*     */     
/*     */     void drain() {
/* 297 */       if (WIP.getAndIncrement(this) != 0) {
/*     */         return;
/*     */       }
/*     */       
/* 301 */       if (this.sourceMode == 1) {
/* 302 */         drainSync();
/*     */       } else {
/*     */         
/* 305 */         drainAsync();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     void drainSync() {
/* 311 */       int missed = 1;
/*     */ 
/*     */       
/*     */       do {
/* 315 */         if (this.connected) {
/*     */           
/* 317 */           if (this.s == Operators.cancelledSubscription()) {
/* 318 */             this.queue.clear();
/*     */             
/*     */             return;
/*     */           } 
/* 322 */           Queue<T> queue = this.queue;
/*     */           
/* 324 */           FluxPublishMulticast.PublishMulticastInner<T>[] a = this.subscribers;
/* 325 */           int n = a.length;
/*     */           
/* 327 */           if (n != 0) {
/*     */             FluxPublishMulticast.PublishMulticastInner[] arrayOfPublishMulticastInner;
/* 329 */             long r = Long.MAX_VALUE;
/*     */             
/* 331 */             for (int i = 0; i < n; i++) {
/* 332 */               long u = (a[i]).requested;
/* 333 */               if (u != Long.MIN_VALUE) {
/* 334 */                 r = Math.min(r, u);
/*     */               }
/*     */             } 
/*     */             
/* 338 */             long e = 0L;
/*     */             
/* 340 */             while (e != r) {
/*     */               T v;
/* 342 */               if (this.s == Operators.cancelledSubscription()) {
/* 343 */                 queue.clear();
/*     */ 
/*     */                 
/*     */                 return;
/*     */               } 
/*     */               
/*     */               try {
/* 350 */                 v = queue.poll();
/*     */               }
/* 352 */               catch (Throwable ex) {
/* 353 */                 this.error = Operators.onOperatorError(this.s, ex, this.context);
/* 354 */                 queue.clear();
/* 355 */                 arrayOfPublishMulticastInner = SUBSCRIBERS.getAndSet(this, TERMINATED);
/* 356 */                 n = arrayOfPublishMulticastInner.length;
/* 357 */                 for (int k = 0; k < n; k++) {
/* 358 */                   (arrayOfPublishMulticastInner[k]).actual.onError(ex);
/*     */                 }
/*     */                 
/*     */                 return;
/*     */               } 
/* 363 */               if (v == null) {
/* 364 */                 arrayOfPublishMulticastInner = SUBSCRIBERS.getAndSet(this, TERMINATED);
/* 365 */                 n = arrayOfPublishMulticastInner.length;
/* 366 */                 for (int k = 0; k < n; k++) {
/* 367 */                   (arrayOfPublishMulticastInner[k]).actual.onComplete();
/*     */                 }
/*     */                 
/*     */                 return;
/*     */               } 
/* 372 */               for (int j = 0; j < n; j++) {
/* 373 */                 (arrayOfPublishMulticastInner[j]).actual.onNext(v);
/*     */               }
/*     */               
/* 376 */               e++;
/*     */             } 
/*     */             
/* 379 */             if (this.s == Operators.cancelledSubscription()) {
/* 380 */               queue.clear();
/*     */               return;
/*     */             } 
/* 383 */             if (queue.isEmpty()) {
/* 384 */               arrayOfPublishMulticastInner = SUBSCRIBERS.getAndSet(this, TERMINATED);
/* 385 */               n = arrayOfPublishMulticastInner.length;
/* 386 */               for (int j = 0; j < n; j++) {
/* 387 */                 (arrayOfPublishMulticastInner[j]).actual.onComplete();
/*     */               }
/*     */               
/*     */               return;
/*     */             } 
/* 392 */             if (e != 0L) {
/* 393 */               for (int j = 0; j < n; j++) {
/* 394 */                 arrayOfPublishMulticastInner[j].produced(e);
/*     */               }
/*     */             }
/*     */           } 
/*     */         } 
/*     */         
/* 400 */         missed = WIP.addAndGet(this, -missed);
/* 401 */       } while (missed != 0);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void drainAsync() {
/* 409 */       int missed = 1;
/*     */       
/* 411 */       int p = this.produced;
/*     */ 
/*     */       
/*     */       do {
/* 415 */         if (this.connected) {
/* 416 */           if (this.s == Operators.cancelledSubscription()) {
/* 417 */             this.queue.clear();
/*     */             
/*     */             return;
/*     */           } 
/* 421 */           Queue<T> queue = this.queue;
/*     */           
/* 423 */           FluxPublishMulticast.PublishMulticastInner<T>[] a = this.subscribers;
/* 424 */           int n = a.length;
/*     */           
/* 426 */           if (n != 0) {
/*     */             FluxPublishMulticast.PublishMulticastInner[] arrayOfPublishMulticastInner;
/* 428 */             long r = Long.MAX_VALUE;
/*     */             
/* 430 */             for (int i = 0; i < n; i++) {
/* 431 */               long u = (a[i]).requested;
/* 432 */               if (u != Long.MIN_VALUE) {
/* 433 */                 r = Math.min(r, u);
/*     */               }
/*     */             } 
/*     */             
/* 437 */             long e = 0L;
/*     */             
/* 439 */             while (e != r) {
/* 440 */               T v; if (this.s == Operators.cancelledSubscription()) {
/* 441 */                 queue.clear();
/*     */                 
/*     */                 return;
/*     */               } 
/* 445 */               boolean d = this.done;
/*     */ 
/*     */ 
/*     */               
/*     */               try {
/* 450 */                 v = queue.poll();
/*     */               }
/* 452 */               catch (Throwable ex) {
/* 453 */                 queue.clear();
/* 454 */                 this.error = Operators.onOperatorError(this.s, ex, this.context);
/* 455 */                 arrayOfPublishMulticastInner = SUBSCRIBERS.getAndSet(this, TERMINATED);
/* 456 */                 n = arrayOfPublishMulticastInner.length;
/* 457 */                 for (int k = 0; k < n; k++) {
/* 458 */                   (arrayOfPublishMulticastInner[k]).actual.onError(ex);
/*     */                 }
/*     */                 
/*     */                 return;
/*     */               } 
/* 463 */               boolean empty = (v == null);
/*     */               
/* 465 */               if (d) {
/* 466 */                 Throwable ex = this.error;
/* 467 */                 if (ex != null) {
/* 468 */                   queue.clear();
/* 469 */                   arrayOfPublishMulticastInner = SUBSCRIBERS.getAndSet(this, TERMINATED);
/* 470 */                   n = arrayOfPublishMulticastInner.length;
/* 471 */                   for (int k = 0; k < n; k++) {
/* 472 */                     (arrayOfPublishMulticastInner[k]).actual.onError(ex);
/*     */                   }
/*     */                   
/*     */                   return;
/*     */                 } 
/* 477 */                 if (empty) {
/* 478 */                   arrayOfPublishMulticastInner = SUBSCRIBERS.getAndSet(this, TERMINATED);
/* 479 */                   n = arrayOfPublishMulticastInner.length;
/* 480 */                   for (int k = 0; k < n; k++) {
/* 481 */                     (arrayOfPublishMulticastInner[k]).actual.onComplete();
/*     */                   }
/*     */                   
/*     */                   return;
/*     */                 } 
/*     */               } 
/* 487 */               if (empty) {
/*     */                 break;
/*     */               }
/*     */               
/* 491 */               for (int j = 0; j < n; j++) {
/* 492 */                 (arrayOfPublishMulticastInner[j]).actual.onNext(v);
/*     */               }
/*     */               
/* 495 */               e++;
/*     */               
/* 497 */               if (++p == this.limit) {
/* 498 */                 this.s.request(p);
/* 499 */                 p = 0;
/*     */               } 
/*     */             } 
/*     */             
/* 503 */             if (e == r) {
/* 504 */               if (this.s == Operators.cancelledSubscription()) {
/* 505 */                 queue.clear();
/*     */                 
/*     */                 return;
/*     */               } 
/* 509 */               boolean d = this.done;
/*     */               
/* 511 */               if (d) {
/* 512 */                 Throwable ex = this.error;
/* 513 */                 if (ex != null) {
/* 514 */                   queue.clear();
/* 515 */                   arrayOfPublishMulticastInner = SUBSCRIBERS.getAndSet(this, TERMINATED);
/* 516 */                   n = arrayOfPublishMulticastInner.length;
/* 517 */                   for (int j = 0; j < n; j++) {
/* 518 */                     (arrayOfPublishMulticastInner[j]).actual.onError(ex);
/*     */                   }
/*     */                   
/*     */                   return;
/*     */                 } 
/* 523 */                 if (queue.isEmpty()) {
/* 524 */                   arrayOfPublishMulticastInner = SUBSCRIBERS.getAndSet(this, TERMINATED);
/* 525 */                   n = arrayOfPublishMulticastInner.length;
/* 526 */                   for (int j = 0; j < n; j++) {
/* 527 */                     (arrayOfPublishMulticastInner[j]).actual.onComplete();
/*     */                   }
/*     */                   
/*     */                   return;
/*     */                 } 
/*     */               } 
/*     */             } 
/*     */             
/* 535 */             if (e != 0L) {
/* 536 */               for (int j = 0; j < n; j++) {
/* 537 */                 arrayOfPublishMulticastInner[j].produced(e);
/*     */               }
/*     */             }
/*     */           } 
/*     */         } 
/*     */ 
/*     */         
/* 544 */         this.produced = p;
/*     */         
/* 546 */         missed = WIP.addAndGet(this, -missed);
/* 547 */       } while (missed != 0);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     boolean add(FluxPublishMulticast.PublishMulticastInner<T> s) {
/*     */       while (true) {
/* 555 */         FluxPublishMulticast.PublishMulticastInner<T>[] a = this.subscribers;
/*     */         
/* 557 */         if (a == TERMINATED) {
/* 558 */           return false;
/*     */         }
/*     */         
/* 561 */         int n = a.length;
/*     */         
/* 563 */         FluxPublishMulticast.PublishMulticastInner[] arrayOfPublishMulticastInner = new FluxPublishMulticast.PublishMulticastInner[n + 1];
/*     */         
/* 565 */         System.arraycopy(a, 0, arrayOfPublishMulticastInner, 0, n);
/* 566 */         arrayOfPublishMulticastInner[n] = s;
/* 567 */         if (SUBSCRIBERS.compareAndSet(this, a, arrayOfPublishMulticastInner))
/* 568 */           return true; 
/*     */       } 
/*     */     }
/*     */     
/*     */     void remove(FluxPublishMulticast.PublishMulticastInner<T> s) {
/*     */       FluxPublishMulticast.PublishMulticastInner<T>[] a;
/*     */       FluxPublishMulticast.PublishMulticastInner[] arrayOfPublishMulticastInner;
/*     */       do {
/* 576 */         a = this.subscribers;
/*     */         
/* 578 */         if (a == TERMINATED || a == EMPTY) {
/*     */           return;
/*     */         }
/*     */         
/* 582 */         int n = a.length;
/* 583 */         int j = -1;
/*     */         
/* 585 */         for (int i = 0; i < n; i++) {
/* 586 */           if (a[i] == s) {
/* 587 */             j = i;
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/* 592 */         if (j < 0) {
/*     */           return;
/*     */         }
/*     */ 
/*     */         
/* 597 */         if (n == 1) {
/* 598 */           arrayOfPublishMulticastInner = EMPTY;
/*     */         } else {
/*     */           
/* 601 */           arrayOfPublishMulticastInner = new FluxPublishMulticast.PublishMulticastInner[n - 1];
/* 602 */           System.arraycopy(a, 0, arrayOfPublishMulticastInner, 0, j);
/* 603 */           System.arraycopy(a, j + 1, arrayOfPublishMulticastInner, j, n - j - 1);
/*     */         } 
/* 605 */       } while (!SUBSCRIBERS.compareAndSet(this, a, arrayOfPublishMulticastInner));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void terminate() {
/* 614 */       Operators.terminate(S, this);
/* 615 */       if (WIP.getAndIncrement(this) == 0 && 
/* 616 */         this.connected) {
/* 617 */         this.queue.clear();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class PublishMulticastInner<T>
/*     */     implements InnerProducer<T>
/*     */   {
/*     */     final FluxPublishMulticast.FluxPublishMulticaster<T> parent;
/*     */     
/*     */     final CoreSubscriber<? super T> actual;
/*     */     
/*     */     volatile long requested;
/*     */     
/* 632 */     static final AtomicLongFieldUpdater<PublishMulticastInner> REQUESTED = AtomicLongFieldUpdater.newUpdater(PublishMulticastInner.class, "requested");
/*     */ 
/*     */ 
/*     */     
/*     */     PublishMulticastInner(FluxPublishMulticast.FluxPublishMulticaster<T> parent, CoreSubscriber<? super T> actual) {
/* 637 */       this.parent = parent;
/* 638 */       this.actual = actual;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 644 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) {
/* 645 */         return Long.valueOf(Math.max(0L, this.requested));
/*     */       }
/* 647 */       if (key == Scannable.Attr.PARENT) {
/* 648 */         return this.parent;
/*     */       }
/* 650 */       if (key == Scannable.Attr.CANCELLED) {
/* 651 */         return Boolean.valueOf((Long.MIN_VALUE == this.requested));
/*     */       }
/* 653 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 655 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 660 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 665 */       if (Operators.validate(n)) {
/* 666 */         Operators.addCapCancellable(REQUESTED, this, n);
/* 667 */         this.parent.drain();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 673 */       if (REQUESTED.getAndSet(this, Long.MIN_VALUE) != Long.MIN_VALUE) {
/* 674 */         this.parent.remove(this);
/* 675 */         this.parent.drain();
/*     */       } 
/*     */     }
/*     */     
/*     */     void produced(long n) {
/* 680 */       Operators.producedCancellable(REQUESTED, this, n);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static interface PublishMulticasterParent
/*     */   {
/*     */     void terminate();
/*     */   }
/*     */ 
/*     */   
/*     */   static final class CancelMulticaster<T>
/*     */     implements InnerOperator<T, T>, Fuseable.QueueSubscription<T>
/*     */   {
/*     */     final CoreSubscriber<? super T> actual;
/*     */     
/*     */     final FluxPublishMulticast.PublishMulticasterParent parent;
/*     */     
/*     */     Subscription s;
/*     */     
/*     */     CancelMulticaster(CoreSubscriber<? super T> actual, FluxPublishMulticast.PublishMulticasterParent parent) {
/* 701 */       this.actual = actual;
/* 702 */       this.parent = parent;
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 707 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 713 */       if (key == Scannable.Attr.PARENT) {
/* 714 */         return this.s;
/*     */       }
/* 716 */       if (key == Scannable.Attr.RUN_STYLE) {
/* 717 */         return Scannable.Attr.RunStyle.SYNC;
/*     */       }
/*     */       
/* 720 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 725 */       this.s.request(n);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 730 */       this.s.cancel();
/* 731 */       this.parent.terminate();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 736 */       if (Operators.validate(this.s, s)) {
/* 737 */         this.s = s;
/* 738 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 744 */       this.actual.onNext(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 749 */       this.actual.onError(t);
/* 750 */       this.parent.terminate();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 755 */       this.actual.onComplete();
/* 756 */       this.parent.terminate();
/*     */     }
/*     */ 
/*     */     
/*     */     public int requestFusion(int requestedMode) {
/* 761 */       return 0;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void clear() {}
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isEmpty() {
/* 772 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int size() {
/* 778 */       return 0;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public T poll() {
/* 785 */       return null;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class CancelFuseableMulticaster<T>
/*     */     implements InnerOperator<T, T>, Fuseable.QueueSubscription<T>
/*     */   {
/*     */     final CoreSubscriber<? super T> actual;
/*     */     
/*     */     final FluxPublishMulticast.PublishMulticasterParent parent;
/*     */     
/*     */     Fuseable.QueueSubscription<T> s;
/*     */     
/*     */     CancelFuseableMulticaster(CoreSubscriber<? super T> actual, FluxPublishMulticast.PublishMulticasterParent parent) {
/* 800 */       this.actual = actual;
/* 801 */       this.parent = parent;
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 806 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 812 */       if (key == Scannable.Attr.PARENT) {
/* 813 */         return this.s;
/*     */       }
/* 815 */       if (key == Scannable.Attr.RUN_STYLE) {
/* 816 */         return Scannable.Attr.RunStyle.SYNC;
/*     */       }
/*     */       
/* 819 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 824 */       this.s.request(n);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 829 */       this.s.cancel();
/* 830 */       this.parent.terminate();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 836 */       if (Operators.validate((Subscription)this.s, s)) {
/* 837 */         this.s = Operators.as(s);
/* 838 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 844 */       this.actual.onNext(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 849 */       this.actual.onError(t);
/* 850 */       this.parent.terminate();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 855 */       this.actual.onComplete();
/* 856 */       this.parent.terminate();
/*     */     }
/*     */ 
/*     */     
/*     */     public int requestFusion(int requestedMode) {
/* 861 */       return this.s.requestFusion(requestedMode);
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public T poll() {
/* 867 */       return (T)this.s.poll();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isEmpty() {
/* 872 */       return this.s.isEmpty();
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 877 */       return this.s.size();
/*     */     }
/*     */ 
/*     */     
/*     */     public void clear() {
/* 882 */       this.s.clear();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\FluxPublishMulticast.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */