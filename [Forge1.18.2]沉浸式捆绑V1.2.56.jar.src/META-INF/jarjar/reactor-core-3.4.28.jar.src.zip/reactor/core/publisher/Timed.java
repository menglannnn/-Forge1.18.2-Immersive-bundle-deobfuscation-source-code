package reactor.core.publisher;

import java.time.Duration;
import java.time.Instant;
import java.util.function.Supplier;

public interface Timed<T> extends Supplier<T> {
  T get();
  
  Duration elapsed();
  
  Duration elapsedSinceSubscription();
  
  Instant timestamp();
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\Timed.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */