/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.util.function.Consumer;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.scheduler.Scheduler;
/*     */ import reactor.core.scheduler.Schedulers;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ConnectableFlux<T>
/*     */   extends Flux<T>
/*     */ {
/*     */   public final Flux<T> autoConnect() {
/*  47 */     return autoConnect(1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Flux<T> autoConnect(int minSubscribers) {
/*  65 */     return autoConnect(minSubscribers, NOOP_DISCONNECT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Flux<T> autoConnect(int minSubscribers, Consumer<? super Disposable> cancelSupport) {
/*  80 */     if (minSubscribers == 0) {
/*  81 */       connect(cancelSupport);
/*  82 */       return this;
/*     */     } 
/*  84 */     if (this instanceof reactor.core.Fuseable) {
/*  85 */       return onAssembly(new FluxAutoConnectFuseable<>(this, minSubscribers, cancelSupport));
/*     */     }
/*     */ 
/*     */     
/*  89 */     return onAssembly(new FluxAutoConnect<>(this, minSubscribers, cancelSupport));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Disposable connect() {
/*  99 */     Disposable[] out = { null };
/* 100 */     connect(r -> out[0] = r);
/* 101 */     return out[0];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ConnectableFlux<T> hide() {
/* 120 */     return new ConnectableFluxHide<>(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Flux<T> refCount() {
/* 133 */     return refCount(1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Flux<T> refCount(int minSubscribers) {
/* 148 */     return onAssembly(new FluxRefCount<>(this, minSubscribers));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Flux<T> refCount(int minSubscribers, Duration gracePeriod) {
/* 168 */     return refCount(minSubscribers, gracePeriod, Schedulers.parallel());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Flux<T> refCount(int minSubscribers, Duration gracePeriod, Scheduler scheduler) {
/* 189 */     return onAssembly(new FluxRefCountGrace<>(this, minSubscribers, gracePeriod, scheduler));
/*     */   }
/*     */   
/*     */   static final Consumer<Disposable> NOOP_DISCONNECT = runnable -> {
/*     */     
/*     */     };
/*     */   
/*     */   public abstract void connect(Consumer<? super Disposable> paramConsumer);
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\ConnectableFlux.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */