/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.RejectedExecutionException;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.core.scheduler.Scheduler;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MonoDelayElement<T>
/*     */   extends InternalMonoOperator<T, T>
/*     */ {
/*     */   final Scheduler timedScheduler;
/*     */   final long delay;
/*     */   final TimeUnit unit;
/*     */   
/*     */   MonoDelayElement(Mono<? extends T> source, long delay, TimeUnit unit, Scheduler timedScheduler) {
/*  47 */     super(source);
/*  48 */     this.delay = delay;
/*  49 */     this.unit = Objects.<TimeUnit>requireNonNull(unit, "unit");
/*  50 */     this.timedScheduler = Objects.<Scheduler>requireNonNull(timedScheduler, "timedScheduler");
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/*  55 */     return new DelayElementSubscriber<>(actual, this.timedScheduler, this.delay, this.unit);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  60 */     if (key == Scannable.Attr.RUN_ON) return this.timedScheduler; 
/*  61 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.ASYNC;
/*     */     
/*  63 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class DelayElementSubscriber<T>
/*     */     extends Operators.MonoSubscriber<T, T>
/*     */   {
/*     */     final long delay;
/*     */     
/*     */     final Scheduler scheduler;
/*     */     final TimeUnit unit;
/*     */     Subscription s;
/*     */     volatile Disposable task;
/*     */     boolean done;
/*     */     
/*     */     DelayElementSubscriber(CoreSubscriber<? super T> actual, Scheduler scheduler, long delay, TimeUnit unit) {
/*  79 */       super(actual);
/*  80 */       this.scheduler = scheduler;
/*  81 */       this.delay = delay;
/*  82 */       this.unit = unit;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/*  88 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/*  89 */       if (key == Scannable.Attr.PARENT) return this.s; 
/*  90 */       if (key == Scannable.Attr.RUN_ON) return this.scheduler; 
/*  91 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.ASYNC;
/*     */       
/*  93 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/*  98 */       super.cancel();
/*  99 */       if (this.task != null) {
/* 100 */         this.task.dispose();
/*     */       }
/* 102 */       if (this.s != Operators.cancelledSubscription()) {
/* 103 */         this.s.cancel();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 109 */       if (Operators.validate(this.s, s)) {
/* 110 */         this.s = s;
/*     */         
/* 112 */         this.actual.onSubscribe(this);
/* 113 */         s.request(Long.MAX_VALUE);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 119 */       if (this.done) {
/* 120 */         Operators.onNextDropped(t, this.actual.currentContext());
/*     */         return;
/*     */       } 
/* 123 */       this.done = true;
/*     */       try {
/* 125 */         this.task = this.scheduler.schedule(() -> complete((T)t), this.delay, this.unit);
/*     */       }
/* 127 */       catch (RejectedExecutionException ree) {
/* 128 */         this.actual.onError(Operators.onRejectedExecution(ree, this, null, t, this.actual
/* 129 */               .currentContext()));
/*     */         return;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 136 */       if (this.done) {
/*     */         return;
/*     */       }
/* 139 */       this.done = true;
/* 140 */       this.actual.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 145 */       if (this.done) {
/* 146 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*     */         return;
/*     */       } 
/* 149 */       this.done = true;
/* 150 */       this.actual.onError(t);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\MonoDelayElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */